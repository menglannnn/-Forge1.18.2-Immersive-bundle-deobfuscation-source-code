/*    */ package top.theillusivec4.curios.client;
/*    */ 
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.resources.ResourceLocation;
/*    */ import net.minecraft.server.packs.resources.PreparableReloadListener;
/*    */ import net.minecraft.server.packs.resources.ReloadableResourceManager;
/*    */ import net.minecraft.server.packs.resources.ResourceManager;
/*    */ import net.minecraft.world.inventory.InventoryMenu;
/*    */ import net.minecraftforge.client.event.TextureStitchEvent;
/*    */ import top.theillusivec4.curios.api.SlotTypePreset;
/*    */ 
/*    */ public class CuriosClientMod
/*    */ {
/* 14 */   private static final CuriosSpriteListener SPRITE_LISTENER = new CuriosSpriteListener();
/*    */ 
/*    */   
/*    */   public static void init() {
/* 18 */     Minecraft mc = Minecraft.m_91087_();
/*    */     
/* 20 */     if (mc != null) {
/* 21 */       ResourceManager manager = mc.m_91098_();
/*    */       
/* 23 */       if (manager instanceof ReloadableResourceManager) { ReloadableResourceManager reloader = (ReloadableResourceManager)manager;
/* 24 */         reloader.m_7217_((PreparableReloadListener)SPRITE_LISTENER); }
/*    */     
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public static void stitch(TextureStitchEvent.Pre evt) {
/* 31 */     if (evt.getAtlas().m_118330_() == InventoryMenu.f_39692_) {
/*    */       
/* 33 */       for (SlotTypePreset preset : SlotTypePreset.values()) {
/* 34 */         evt.addSprite(new ResourceLocation("curios", "item/empty_" + preset
/*    */               
/* 36 */               .getIdentifier() + "_slot"));
/*    */       }
/* 38 */       evt.addSprite(new ResourceLocation("curios", "item/empty_cosmetic_slot"));
/* 39 */       evt.addSprite(new ResourceLocation("curios", "item/empty_curio_slot"));
/*    */       
/* 41 */       for (ResourceLocation sprite : SPRITE_LISTENER.getSprites())
/* 42 */         evt.addSprite(sprite); 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\curios-309927-4590652.jar!\top\theillusivec4\curios\client\CuriosClientMod.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */