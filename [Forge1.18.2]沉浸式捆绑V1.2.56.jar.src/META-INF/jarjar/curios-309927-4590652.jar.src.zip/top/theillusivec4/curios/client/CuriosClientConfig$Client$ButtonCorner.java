/*     */ package top.theillusivec4.curios.client;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum ButtonCorner
/*     */ {
/*  77 */   TOP_LEFT(26, -75, 73, -62), TOP_RIGHT(61, -75, 95, -62), BOTTOM_LEFT(26, -20, 73, -29),
/*  78 */   BOTTOM_RIGHT(61, -20, 95, -29);
/*     */   
/*     */   final int xoffset;
/*     */   final int yoffset;
/*     */   final int creativeXoffset;
/*     */   final int creativeYoffset;
/*     */   
/*     */   ButtonCorner(int x, int y, int creativeX, int creativeY) {
/*  86 */     this.xoffset = x;
/*  87 */     this.yoffset = y;
/*  88 */     this.creativeXoffset = creativeX;
/*  89 */     this.creativeYoffset = creativeY;
/*     */   }
/*     */   
/*     */   public int getXoffset() {
/*  93 */     return this.xoffset;
/*     */   }
/*     */   
/*     */   public int getYoffset() {
/*  97 */     return this.yoffset;
/*     */   }
/*     */   
/*     */   public int getCreativeXoffset() {
/* 101 */     return this.creativeXoffset;
/*     */   }
/*     */   
/*     */   public int getCreativeYoffset() {
/* 105 */     return this.creativeYoffset;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\curios-309927-4590652.jar!\top\theillusivec4\curios\client\CuriosClientConfig$Client$ButtonCorner.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */