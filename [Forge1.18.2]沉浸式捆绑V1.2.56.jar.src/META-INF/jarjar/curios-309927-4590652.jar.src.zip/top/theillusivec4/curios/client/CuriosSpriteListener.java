/*    */ package top.theillusivec4.curios.client;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import java.util.HashSet;
/*    */ import java.util.Set;
/*    */ import javax.annotation.Nonnull;
/*    */ import net.minecraft.resources.ResourceLocation;
/*    */ import net.minecraft.server.packs.resources.ResourceManager;
/*    */ import net.minecraft.server.packs.resources.SimplePreparableReloadListener;
/*    */ import net.minecraft.util.profiling.ProfilerFiller;
/*    */ 
/*    */ public class CuriosSpriteListener
/*    */   extends SimplePreparableReloadListener<Void>
/*    */ {
/* 15 */   private final Set<ResourceLocation> registeredSprites = new HashSet<>();
/*    */   
/*    */   public Set<ResourceLocation> getSprites() {
/* 18 */     return this.registeredSprites;
/*    */   }
/*    */ 
/*    */   
/*    */   @Nonnull
/*    */   protected Void prepare(ResourceManager resourceManagerIn, @Nonnull ProfilerFiller profilerIn) {
/* 24 */     Collection<ResourceLocation> resources = resourceManagerIn.m_6540_("textures/slot", fileName -> 
/* 25 */         (ResourceLocation.m_135830_(fileName) && fileName.endsWith(".png")));
/*    */     
/* 27 */     Set<ResourceLocation> result = new HashSet<>();
/*    */     
/* 29 */     for (ResourceLocation resource : resources) {
/* 30 */       String prefix = "textures/slot/";
/* 31 */       String namespace = resource.m_135827_();
/* 32 */       String path = resource.m_135815_();
/*    */       
/* 34 */       if (namespace.equals("curios") && path.startsWith(prefix)) {
/* 35 */         result.add(new ResourceLocation(namespace, path
/* 36 */               .substring("textures/".length(), path.length() - ".png".length())));
/*    */       }
/*    */     } 
/* 39 */     this.registeredSprites.clear();
/* 40 */     this.registeredSprites.addAll(result);
/* 41 */     return null;
/*    */   }
/*    */   
/*    */   protected void apply(@Nonnull Void p_10793_, @Nonnull ResourceManager p_10794_, @Nonnull ProfilerFiller p_10795_) {}
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\curios-309927-4590652.jar!\top\theillusivec4\curios\client\CuriosSpriteListener.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */