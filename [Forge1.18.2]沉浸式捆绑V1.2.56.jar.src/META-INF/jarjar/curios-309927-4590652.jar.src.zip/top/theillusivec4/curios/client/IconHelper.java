/*    */ package top.theillusivec4.curios.client;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import net.minecraft.resources.ResourceLocation;
/*    */ import top.theillusivec4.curios.api.type.util.IIconHelper;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IconHelper
/*    */   implements IIconHelper
/*    */ {
/* 29 */   private Map<String, ResourceLocation> idToIcon = new HashMap<>();
/*    */ 
/*    */   
/*    */   public void clearIcons() {
/* 33 */     this.idToIcon.clear();
/*    */   }
/*    */ 
/*    */   
/*    */   public void addIcon(String identifier, ResourceLocation resourceLocation) {
/* 38 */     this.idToIcon.putIfAbsent(identifier, resourceLocation);
/*    */   }
/*    */ 
/*    */   
/*    */   public ResourceLocation getIcon(String identifier) {
/* 43 */     return this.idToIcon.getOrDefault(identifier, new ResourceLocation("item/empty_curio_slot"));
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\curios-309927-4590652.jar!\top\theillusivec4\curios\client\IconHelper.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */