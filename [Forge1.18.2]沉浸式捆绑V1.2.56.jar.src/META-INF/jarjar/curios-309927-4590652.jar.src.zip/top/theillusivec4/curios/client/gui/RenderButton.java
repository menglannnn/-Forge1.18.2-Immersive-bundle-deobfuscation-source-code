/*    */ package top.theillusivec4.curios.client.gui;
/*    */ 
/*    */ import com.mojang.blaze3d.systems.RenderSystem;
/*    */ import com.mojang.blaze3d.vertex.PoseStack;
/*    */ import javax.annotation.Nonnull;
/*    */ import net.minecraft.client.gui.components.Button;
/*    */ import net.minecraft.client.gui.components.ImageButton;
/*    */ import net.minecraft.resources.ResourceLocation;
/*    */ import top.theillusivec4.curios.common.inventory.CurioSlot;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RenderButton
/*    */   extends ImageButton
/*    */ {
/*    */   private final ResourceLocation resourceLocation;
/*    */   private final int yTexStart;
/*    */   private final int xTexStart;
/*    */   private final CurioSlot slot;
/*    */   
/*    */   public RenderButton(CurioSlot slot, int xIn, int yIn, int widthIn, int heightIn, int xTexStartIn, int yTexStartIn, int yDiffTextIn, ResourceLocation resourceLocationIn, Button.OnPress onPressIn) {
/* 40 */     super(xIn, yIn, widthIn, heightIn, xTexStartIn, yTexStartIn, yDiffTextIn, resourceLocationIn, 256, 256, onPressIn);
/*    */     
/* 42 */     this.resourceLocation = resourceLocationIn;
/* 43 */     this.yTexStart = yTexStartIn;
/* 44 */     this.xTexStart = xTexStartIn;
/* 45 */     this.slot = slot;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void m_6305_(@Nonnull PoseStack matrixStack, int mouseX, int mouseY, float partialTicks) {}
/*    */ 
/*    */ 
/*    */   
/*    */   public void renderButtonOverlay(@Nonnull PoseStack matrixStack, int mouseX, int mouseY, float partialTicks) {
/* 55 */     RenderSystem.m_157456_(0, this.resourceLocation);
/* 56 */     RenderSystem.m_69465_();
/* 57 */     int j = this.xTexStart;
/*    */     
/* 59 */     if (!this.slot.getRenderStatus()) {
/* 60 */       j += 8;
/*    */     }
/* 62 */     m_93133_(matrixStack, this.f_93620_, this.f_93621_, j, this.yTexStart, this.f_93618_, this.f_93619_, 256, 256);
/*    */     
/* 64 */     RenderSystem.m_69482_();
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\curios-309927-4590652.jar!\top\theillusivec4\curios\client\gui\RenderButton.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */