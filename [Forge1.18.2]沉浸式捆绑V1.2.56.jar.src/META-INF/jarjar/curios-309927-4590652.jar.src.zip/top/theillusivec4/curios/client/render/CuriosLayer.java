/*    */ package top.theillusivec4.curios.client.render;
/*    */ 
/*    */ import com.mojang.blaze3d.vertex.PoseStack;
/*    */ import javax.annotation.Nonnull;
/*    */ import net.minecraft.client.model.EntityModel;
/*    */ import net.minecraft.client.renderer.MultiBufferSource;
/*    */ import net.minecraft.client.renderer.entity.RenderLayerParent;
/*    */ import net.minecraft.client.renderer.entity.layers.RenderLayer;
/*    */ import net.minecraft.core.NonNullList;
/*    */ import net.minecraft.world.entity.Entity;
/*    */ import net.minecraft.world.entity.LivingEntity;
/*    */ import net.minecraft.world.item.ItemStack;
/*    */ import top.theillusivec4.curios.api.CuriosApi;
/*    */ import top.theillusivec4.curios.api.SlotContext;
/*    */ import top.theillusivec4.curios.api.client.CuriosRendererRegistry;
/*    */ import top.theillusivec4.curios.api.client.ICurioRenderer;
/*    */ import top.theillusivec4.curios.api.type.capability.ICuriosItemHandler;
/*    */ import top.theillusivec4.curios.api.type.inventory.ICurioStacksHandler;
/*    */ import top.theillusivec4.curios.api.type.inventory.IDynamicStackHandler;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CuriosLayer<T extends LivingEntity, M extends EntityModel<T>>
/*    */   extends RenderLayer<T, M>
/*    */ {
/*    */   private final RenderLayerParent<T, M> renderLayerParent;
/*    */   
/*    */   public CuriosLayer(RenderLayerParent<T, M> renderer) {
/* 42 */     super(renderer);
/* 43 */     this.renderLayerParent = renderer;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void render(@Nonnull PoseStack matrixStack, @Nonnull MultiBufferSource renderTypeBuffer, int light, @Nonnull T livingEntity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
/* 50 */     matrixStack.m_85836_();
/* 51 */     CuriosApi.getCuriosHelper().getCuriosHandler((LivingEntity)livingEntity)
/* 52 */       .ifPresent(handler -> handler.getCurios().forEach(()));
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 78 */     matrixStack.m_85849_();
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\curios-309927-4590652.jar!\top\theillusivec4\curios\client\render\CuriosLayer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */