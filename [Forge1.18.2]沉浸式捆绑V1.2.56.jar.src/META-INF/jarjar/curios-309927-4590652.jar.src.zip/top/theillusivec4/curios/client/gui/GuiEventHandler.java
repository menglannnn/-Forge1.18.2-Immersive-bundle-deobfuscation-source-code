/*    */ package top.theillusivec4.curios.client.gui;
/*    */ 
/*    */ import com.mojang.blaze3d.platform.InputConstants;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.gui.components.events.GuiEventListener;
/*    */ import net.minecraft.client.gui.screens.Screen;
/*    */ import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
/*    */ import net.minecraft.client.gui.screens.inventory.CreativeModeInventoryScreen;
/*    */ import net.minecraft.client.gui.screens.inventory.InventoryScreen;
/*    */ import net.minecraft.util.Tuple;
/*    */ import net.minecraft.world.inventory.Slot;
/*    */ import net.minecraft.world.item.CreativeModeTab;
/*    */ import net.minecraftforge.client.event.ScreenEvent;
/*    */ import net.minecraftforge.eventbus.api.SubscribeEvent;
/*    */ import net.minecraftforge.network.PacketDistributor;
/*    */ import top.theillusivec4.curios.common.network.NetworkHandler;
/*    */ import top.theillusivec4.curios.common.network.client.CPacketDestroy;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GuiEventHandler
/*    */ {
/*    */   @SubscribeEvent
/*    */   public void onInventoryGuiInit(ScreenEvent.InitScreenEvent.Post evt) {
/* 42 */     Screen screen = evt.getScreen();
/*    */     
/* 44 */     if (screen instanceof InventoryScreen || screen instanceof CreativeModeInventoryScreen) {
/* 45 */       AbstractContainerScreen<?> gui = (AbstractContainerScreen)screen;
/* 46 */       boolean isCreative = screen instanceof CreativeModeInventoryScreen;
/* 47 */       Tuple<Integer, Integer> offsets = CuriosScreen.getButtonOffset(isCreative);
/* 48 */       int x = ((Integer)offsets.m_14418_()).intValue();
/* 49 */       int y = ((Integer)offsets.m_14419_()).intValue();
/* 50 */       int size = isCreative ? 10 : 14;
/* 51 */       int textureOffsetX = isCreative ? 64 : 50;
/* 52 */       int yOffset = isCreative ? 68 : 83;
/* 53 */       evt.addListener((GuiEventListener)new CuriosButton(gui, gui.getGuiLeft() + x, gui.getGuiTop() + y + yOffset, size, size, textureOffsetX, 0, size, CuriosScreen.CURIO_INVENTORY));
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   @SubscribeEvent
/*    */   public void onInventoryGuiDrawBackground(ScreenEvent.DrawScreenEvent.Pre evt) {
/*    */     InventoryScreen gui;
/* 61 */     Screen screen = evt.getScreen(); if (screen instanceof InventoryScreen) { gui = (InventoryScreen)screen; }
/*    */     else
/*    */     { return; }
/* 64 */      gui.f_98831_ = evt.getMouseX();
/* 65 */     gui.f_98832_ = evt.getMouseY();
/*    */   }
/*    */   
/*    */   @SubscribeEvent
/*    */   public void onMouseClick(ScreenEvent.MouseClickedEvent.Pre evt) {
/* 70 */     long handle = Minecraft.m_91087_().m_91268_().m_85439_();
/* 71 */     boolean isLeftShiftDown = InputConstants.m_84830_(handle, 340);
/* 72 */     boolean isRightShiftDown = InputConstants.m_84830_(handle, 344);
/* 73 */     boolean isShiftDown = (isLeftShiftDown || isRightShiftDown);
/*    */     
/* 75 */     Screen screen = evt.getScreen(); if (screen instanceof CreativeModeInventoryScreen) { CreativeModeInventoryScreen gui = (CreativeModeInventoryScreen)screen; if (isShiftDown) {
/*    */ 
/*    */ 
/*    */         
/* 79 */         if (gui.m_98628_() != CreativeModeTab.f_40761_.m_40775_()) {
/*    */           return;
/*    */         }
/* 82 */         Slot destroyItemSlot = gui.f_98512_;
/* 83 */         Slot slot = gui.m_97744_(evt.getMouseX(), evt.getMouseY());
/*    */         
/* 85 */         if (destroyItemSlot != null && slot == destroyItemSlot)
/* 86 */           NetworkHandler.INSTANCE.send(PacketDistributor.SERVER.noArg(), new CPacketDestroy()); 
/*    */         return;
/*    */       }  }
/*    */   
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\curios-309927-4590652.jar!\top\theillusivec4\curios\client\gui\GuiEventHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */