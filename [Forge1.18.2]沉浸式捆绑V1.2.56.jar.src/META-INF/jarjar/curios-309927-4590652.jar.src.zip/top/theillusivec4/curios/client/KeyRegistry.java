/*    */ package top.theillusivec4.curios.client;
/*    */ 
/*    */ import net.minecraft.client.KeyMapping;
/*    */ import net.minecraftforge.client.ClientRegistry;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class KeyRegistry
/*    */ {
/*    */   public static KeyMapping openCurios;
/*    */   
/*    */   public static void registerKeys() {
/* 31 */     openCurios = registerKeybinding(new KeyMapping("key.curios.open.desc", 71, "key.curios.category"));
/*    */   }
/*    */ 
/*    */   
/*    */   private static KeyMapping registerKeybinding(KeyMapping key) {
/* 36 */     ClientRegistry.registerKeyBinding(key);
/* 37 */     return key;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\curios-309927-4590652.jar!\top\theillusivec4\curios\client\KeyRegistry.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */