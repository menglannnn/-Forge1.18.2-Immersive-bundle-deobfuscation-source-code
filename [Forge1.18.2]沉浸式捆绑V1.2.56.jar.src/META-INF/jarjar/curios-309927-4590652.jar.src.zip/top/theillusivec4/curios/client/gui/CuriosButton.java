/*    */ package top.theillusivec4.curios.client.gui;
/*    */ 
/*    */ import com.mojang.blaze3d.vertex.PoseStack;
/*    */ import javax.annotation.Nonnull;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.gui.components.Button;
/*    */ import net.minecraft.client.gui.components.ImageButton;
/*    */ import net.minecraft.client.gui.screens.Screen;
/*    */ import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
/*    */ import net.minecraft.client.gui.screens.inventory.CreativeModeInventoryScreen;
/*    */ import net.minecraft.client.gui.screens.inventory.InventoryScreen;
/*    */ import net.minecraft.client.gui.screens.recipebook.RecipeBookComponent;
/*    */ import net.minecraft.resources.ResourceLocation;
/*    */ import net.minecraft.util.Tuple;
/*    */ import net.minecraft.world.entity.player.Player;
/*    */ import net.minecraft.world.item.CreativeModeTab;
/*    */ import net.minecraft.world.item.ItemStack;
/*    */ import net.minecraftforge.network.PacketDistributor;
/*    */ import top.theillusivec4.curios.common.network.NetworkHandler;
/*    */ import top.theillusivec4.curios.common.network.client.CPacketOpenCurios;
/*    */ import top.theillusivec4.curios.common.network.client.CPacketOpenVanilla;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CuriosButton
/*    */   extends ImageButton
/*    */ {
/*    */   private final AbstractContainerScreen<?> parentGui;
/*    */   private boolean isRecipeBookVisible = false;
/*    */   
/*    */   CuriosButton(AbstractContainerScreen<?> parentGui, int xIn, int yIn, int widthIn, int heightIn, int textureOffsetX, int textureOffsetY, int yDiffText, ResourceLocation resource) {
/* 47 */     super(xIn, yIn, widthIn, heightIn, textureOffsetX, textureOffsetY, yDiffText, resource, button -> {
/*    */           Minecraft mc = Minecraft.m_91087_();
/*    */           
/*    */           if (mc.f_91074_ != null) {
/*    */             ItemStack stack = mc.f_91074_.f_36096_.m_142621_();
/*    */             
/*    */             mc.f_91074_.f_36096_.m_142503_(ItemStack.f_41583_);
/*    */             
/*    */             if (parentGui instanceof CuriosScreen) {
/*    */               InventoryScreen inventory = new InventoryScreen((Player)mc.f_91074_);
/*    */               
/*    */               mc.m_91152_((Screen)inventory);
/*    */               
/*    */               mc.f_91074_.f_36096_.m_142503_(stack);
/*    */               
/*    */               NetworkHandler.INSTANCE.send(PacketDistributor.SERVER.noArg(), new CPacketOpenVanilla(stack));
/*    */             } else {
/*    */               if (parentGui instanceof InventoryScreen) {
/*    */                 InventoryScreen inventory = (InventoryScreen)parentGui;
/*    */                 RecipeBookComponent recipeBookGui = inventory.m_5564_();
/*    */                 if (recipeBookGui.m_100385_()) {
/*    */                   recipeBookGui.m_100384_();
/*    */                 }
/*    */               } 
/*    */               NetworkHandler.INSTANCE.send(PacketDistributor.SERVER.noArg(), new CPacketOpenCurios(stack));
/*    */             } 
/*    */           } 
/*    */         });
/* 75 */     this.parentGui = parentGui;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void m_6305_(@Nonnull PoseStack matrixStack, int mouseX, int mouseY, float partialTicks) {
/* 82 */     Tuple<Integer, Integer> offsets = CuriosScreen.getButtonOffset(this.parentGui instanceof CreativeModeInventoryScreen);
/* 83 */     this.f_93620_ = this.parentGui.getGuiLeft() + ((Integer)offsets.m_14418_()).intValue();
/* 84 */     int yOffset = (this.parentGui instanceof CreativeModeInventoryScreen) ? 68 : 83;
/* 85 */     this.f_93621_ = this.parentGui.getGuiTop() + ((Integer)offsets.m_14419_()).intValue() + yOffset;
/*    */     
/* 87 */     AbstractContainerScreen<?> abstractContainerScreen = this.parentGui; if (abstractContainerScreen instanceof CreativeModeInventoryScreen) { CreativeModeInventoryScreen gui = (CreativeModeInventoryScreen)abstractContainerScreen;
/* 88 */       boolean isInventoryTab = (gui.m_98628_() == CreativeModeTab.f_40761_.m_40775_());
/* 89 */       this.f_93623_ = isInventoryTab;
/*    */       
/* 91 */       if (!isInventoryTab) {
/*    */         return;
/*    */       } }
/*    */     
/* 95 */     super.m_6305_(matrixStack, mouseX, mouseY, partialTicks);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\curios-309927-4590652.jar!\top\theillusivec4\curios\client\gui\CuriosButton.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */