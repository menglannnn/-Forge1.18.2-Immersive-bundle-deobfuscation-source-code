/*     */ package top.theillusivec4.curios.client;
/*     */ 
/*     */ import java.util.function.Function;
/*     */ import net.minecraftforge.common.ForgeConfigSpec;
/*     */ import org.apache.commons.lang3.tuple.Pair;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CuriosClientConfig
/*     */ {
/*     */   public static final ForgeConfigSpec CLIENT_SPEC;
/*     */   public static final Client CLIENT;
/*     */   private static final String CONFIG_PREFIX = "gui.curios.config.";
/*     */   
/*     */   static {
/*  37 */     Pair<Client, ForgeConfigSpec> specPair = (new ForgeConfigSpec.Builder()).configure(Client::new);
/*  38 */     CLIENT_SPEC = (ForgeConfigSpec)specPair.getRight();
/*  39 */     CLIENT = (Client)specPair.getLeft();
/*     */   }
/*     */ 
/*     */   
/*     */   public static class Client
/*     */   {
/*     */     public final ForgeConfigSpec.BooleanValue renderCurios;
/*     */     public final ForgeConfigSpec.IntValue buttonXOffset;
/*     */     public final ForgeConfigSpec.IntValue buttonYOffset;
/*     */     public final ForgeConfigSpec.IntValue creativeButtonXOffset;
/*     */     public final ForgeConfigSpec.IntValue creativeButtonYOffset;
/*     */     public final ForgeConfigSpec.EnumValue<ButtonCorner> buttonCorner;
/*     */     
/*     */     Client(ForgeConfigSpec.Builder builder) {
/*  53 */       builder.comment("Client only settings, mostly things related to rendering").push("client");
/*     */       
/*  55 */       this
/*  56 */         .renderCurios = builder.comment("Set to true to enable rendering curios").translation("gui.curios.config.renderCurios").define("renderCurios", true);
/*  57 */       this
/*     */         
/*  59 */         .buttonXOffset = builder.comment("The X-Offset for the Curios GUI button").translation("gui.curios.config.buttonXOffset").defineInRange("buttonXOffset", 0, -100, 100);
/*  60 */       this
/*     */         
/*  62 */         .buttonYOffset = builder.comment("The Y-Offset for the Curios GUI button").translation("gui.curios.config.buttonYOffset").defineInRange("buttonYOffset", 0, -100, 100);
/*  63 */       this
/*     */         
/*  65 */         .creativeButtonXOffset = builder.comment("The X-Offset for the Creative Curios GUI button").translation("gui.curios.config.creativeButtonXOffset").defineInRange("creativeButtonXOffset", 0, -100, 100);
/*  66 */       this
/*     */         
/*  68 */         .creativeButtonYOffset = builder.comment("The Y-Offset for the Creative Curios GUI button").translation("gui.curios.config.creativeButtonYOffset").defineInRange("creativeButtonYOffset", 0, -100, 100);
/*  69 */       this
/*     */         
/*  71 */         .buttonCorner = builder.comment("The corner for the Curios GUI button").translation("gui.curios.config.buttonCorner").defineEnum("buttonCorner", ButtonCorner.TOP_LEFT);
/*     */       
/*  73 */       builder.pop();
/*     */     }
/*     */     
/*     */     public enum ButtonCorner {
/*  77 */       TOP_LEFT(26, -75, 73, -62), TOP_RIGHT(61, -75, 95, -62), BOTTOM_LEFT(26, -20, 73, -29),
/*  78 */       BOTTOM_RIGHT(61, -20, 95, -29);
/*     */       
/*     */       final int xoffset;
/*     */       final int yoffset;
/*     */       final int creativeXoffset;
/*     */       final int creativeYoffset;
/*     */       
/*     */       ButtonCorner(int x, int y, int creativeX, int creativeY) {
/*  86 */         this.xoffset = x;
/*  87 */         this.yoffset = y;
/*  88 */         this.creativeXoffset = creativeX;
/*  89 */         this.creativeYoffset = creativeY;
/*     */       }
/*     */       
/*     */       public int getXoffset() {
/*  93 */         return this.xoffset;
/*     */       }
/*     */       
/*     */       public int getYoffset() {
/*  97 */         return this.yoffset;
/*     */       }
/*     */       
/*     */       public int getCreativeXoffset() {
/* 101 */         return this.creativeXoffset;
/*     */       }
/*     */       
/*     */       public int getCreativeYoffset() {
/* 105 */         return this.creativeYoffset; } } } public enum ButtonCorner { public int getCreativeYoffset() { return this.creativeYoffset; }
/*     */ 
/*     */     
/*     */     TOP_LEFT(26, -75, 73, -62),
/*     */     TOP_RIGHT(61, -75, 95, -62),
/*     */     BOTTOM_LEFT(26, -20, 73, -29),
/*     */     BOTTOM_RIGHT(61, -20, 95, -29);
/*     */     final int xoffset;
/*     */     final int yoffset;
/*     */     final int creativeXoffset;
/*     */     final int creativeYoffset;
/*     */     
/*     */     ButtonCorner(int x, int y, int creativeX, int creativeY) {
/*     */       this.xoffset = x;
/*     */       this.yoffset = y;
/*     */       this.creativeXoffset = creativeX;
/*     */       this.creativeYoffset = creativeY;
/*     */     }
/*     */     
/*     */     public int getXoffset() {
/*     */       return this.xoffset;
/*     */     }
/*     */     
/*     */     public int getYoffset() {
/*     */       return this.yoffset;
/*     */     }
/*     */     
/*     */     public int getCreativeXoffset() {
/*     */       return this.creativeXoffset;
/*     */     } }
/*     */ 
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\curios-309927-4590652.jar!\top\theillusivec4\curios\client\CuriosClientConfig.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */