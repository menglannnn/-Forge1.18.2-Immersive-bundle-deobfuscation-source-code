/*     */ package top.theillusivec4.curios.client;
/*     */ 
/*     */ import com.google.common.collect.Multimap;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.UUID;
/*     */ import net.minecraft.ChatFormatting;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.nbt.CompoundTag;
/*     */ import net.minecraft.network.chat.Component;
/*     */ import net.minecraft.network.chat.MutableComponent;
/*     */ import net.minecraft.network.chat.TextComponent;
/*     */ import net.minecraft.network.chat.TranslatableComponent;
/*     */ import net.minecraft.world.entity.LivingEntity;
/*     */ import net.minecraft.world.entity.MobType;
/*     */ import net.minecraft.world.entity.ai.attributes.Attribute;
/*     */ import net.minecraft.world.entity.ai.attributes.AttributeInstance;
/*     */ import net.minecraft.world.entity.ai.attributes.AttributeModifier;
/*     */ import net.minecraft.world.entity.ai.attributes.Attributes;
/*     */ import net.minecraft.world.entity.player.Player;
/*     */ import net.minecraft.world.item.ItemStack;
/*     */ import net.minecraft.world.item.enchantment.EnchantmentHelper;
/*     */ import net.minecraftforge.common.util.LazyOptional;
/*     */ import net.minecraftforge.event.TickEvent;
/*     */ import net.minecraftforge.event.entity.player.ItemTooltipEvent;
/*     */ import net.minecraftforge.eventbus.api.SubscribeEvent;
/*     */ import net.minecraftforge.network.PacketDistributor;
/*     */ import top.theillusivec4.curios.api.CuriosApi;
/*     */ import top.theillusivec4.curios.api.SlotContext;
/*     */ import top.theillusivec4.curios.api.type.capability.ICurio;
/*     */ import top.theillusivec4.curios.common.CuriosHelper;
/*     */ import top.theillusivec4.curios.common.network.NetworkHandler;
/*     */ import top.theillusivec4.curios.common.network.client.CPacketOpenCurios;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClientEventHandler
/*     */ {
/*  60 */   private static final UUID ATTACK_DAMAGE_MODIFIER = UUID.fromString("CB3F55D3-645C-4F38-A497-9C13A33DB5CF");
/*     */   
/*  62 */   private static final UUID ATTACK_SPEED_MODIFIER = UUID.fromString("FA233E1C-4180-4865-B01B-BCCE9785ACA3");
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onKeyInput(TickEvent.ClientTickEvent evt) {
/*  67 */     if (evt.phase != TickEvent.Phase.END) {
/*     */       return;
/*     */     }
/*     */     
/*  71 */     Minecraft mc = Minecraft.m_91087_();
/*     */     
/*  73 */     if (KeyRegistry.openCurios.m_90859_() && mc.m_91302_()) {
/*  74 */       NetworkHandler.INSTANCE.send(PacketDistributor.SERVER.noArg(), new CPacketOpenCurios(ItemStack.f_41583_));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onTooltip(ItemTooltipEvent evt) {
/*  81 */     ItemStack stack = evt.getItemStack();
/*  82 */     Player player = evt.getPlayer();
/*     */     
/*  84 */     if (!stack.m_41619_()) {
/*  85 */       List<Component> tooltip = evt.getToolTip();
/*  86 */       CompoundTag tag = stack.m_41783_();
/*  87 */       int i = 0;
/*     */       
/*  89 */       if (tag != null && tag.m_128425_("HideFlags", 99)) {
/*  90 */         i = tag.m_128451_("HideFlags");
/*     */       }
/*     */       
/*  93 */       Set<String> curioTags = CuriosApi.getCuriosHelper().getCurioTags(stack.m_41720_());
/*  94 */       List<String> slots = new ArrayList<>(curioTags);
/*     */       
/*  96 */       if (!slots.isEmpty()) {
/*  97 */         List<Component> tagTooltips = new ArrayList<>();
/*     */         
/*  99 */         MutableComponent slotsTooltip = (new TranslatableComponent("curios.slot")).m_130946_(": ").m_130940_(ChatFormatting.GOLD);
/*     */         
/* 101 */         for (int j = 0; j < slots.size(); j++) {
/* 102 */           String key = "curios.identifier." + (String)slots.get(j);
/* 103 */           TranslatableComponent translatableComponent = new TranslatableComponent(key);
/*     */           
/* 105 */           if (j < slots.size() - 1) {
/* 106 */             mutableComponent = translatableComponent.m_130946_(", ");
/*     */           }
/*     */           
/* 109 */           MutableComponent mutableComponent = mutableComponent.m_130940_(ChatFormatting.YELLOW);
/* 110 */           slotsTooltip.m_7220_((Component)mutableComponent);
/*     */         } 
/* 112 */         tagTooltips.add(slotsTooltip);
/*     */         
/* 114 */         LazyOptional<ICurio> optionalCurio = CuriosApi.getCuriosHelper().getCurio(stack);
/* 115 */         optionalCurio.ifPresent(curio -> {
/*     */               List<Component> actualSlotsTooltip = curio.getSlotsTooltip(tagTooltips);
/*     */               
/*     */               if (!actualSlotsTooltip.isEmpty()) {
/*     */                 tooltip.addAll(1, actualSlotsTooltip);
/*     */               }
/*     */             });
/*     */         
/* 123 */         if (!optionalCurio.isPresent()) {
/* 124 */           tooltip.addAll(1, tagTooltips);
/*     */         }
/* 126 */         List<Component> attributeTooltip = new ArrayList<>();
/*     */         
/* 128 */         for (String identifier : slots) {
/*     */           
/* 130 */           Multimap<Attribute, AttributeModifier> multimap = CuriosApi.getCuriosHelper().getAttributeModifiers(new SlotContext(identifier, (LivingEntity)player, 0, false, true), 
/* 131 */               UUID.randomUUID(), stack);
/*     */           
/* 133 */           if (!multimap.isEmpty() && (i & 0x2) == 0) {
/* 134 */             boolean init = false;
/*     */             
/* 136 */             for (Map.Entry<Attribute, AttributeModifier> entry : (Iterable<Map.Entry<Attribute, AttributeModifier>>)multimap.entries()) {
/*     */ 
/*     */               
/* 139 */               if (entry.getKey() == null) {
/*     */                 continue;
/*     */               }
/*     */               
/* 143 */               if (!init) {
/* 144 */                 attributeTooltip.add(TextComponent.f_131282_);
/* 145 */                 attributeTooltip.add((new TranslatableComponent("curios.modifiers." + identifier))
/* 146 */                     .m_130940_(ChatFormatting.GOLD));
/* 147 */                 init = true;
/*     */               } 
/* 149 */               AttributeModifier attributemodifier = entry.getValue();
/* 150 */               double amount = attributemodifier.m_22218_();
/* 151 */               boolean flag = false;
/*     */               
/* 153 */               if (player != null) {
/*     */                 double d1;
/* 155 */                 if (attributemodifier.m_22209_() == ATTACK_DAMAGE_MODIFIER) {
/* 156 */                   AttributeInstance att = player.m_21051_(Attributes.f_22281_);
/*     */                   
/* 158 */                   if (att != null) {
/* 159 */                     amount += att.m_22115_();
/*     */                   }
/* 161 */                   amount += 
/* 162 */                     EnchantmentHelper.m_44833_(stack, MobType.f_21640_);
/* 163 */                   flag = true;
/* 164 */                 } else if (attributemodifier.m_22209_() == ATTACK_SPEED_MODIFIER) {
/* 165 */                   AttributeInstance att = player.m_21051_(Attributes.f_22283_);
/*     */                   
/* 167 */                   if (att != null) {
/* 168 */                     amount += att.m_22115_();
/*     */                   }
/* 170 */                   flag = true;
/*     */                 } 
/*     */ 
/*     */ 
/*     */                 
/* 175 */                 if (attributemodifier.m_22217_() != AttributeModifier.Operation.MULTIPLY_BASE && attributemodifier
/* 176 */                   .m_22217_() != AttributeModifier.Operation.MULTIPLY_TOTAL) {
/*     */ 
/*     */                   
/* 179 */                   if (((Attribute)entry.getKey()).equals(Attributes.f_22278_)) {
/* 180 */                     d1 = amount * 10.0D;
/*     */                   } else {
/* 182 */                     d1 = amount;
/*     */                   } 
/*     */                 } else {
/* 185 */                   d1 = amount * 100.0D;
/*     */                 } 
/*     */                 
/* 188 */                 CuriosHelper.SlotAttributeWrapper slotAttributeWrapper = (CuriosHelper.SlotAttributeWrapper)entry.getKey(); if (slotAttributeWrapper instanceof CuriosHelper.SlotAttributeWrapper) { CuriosHelper.SlotAttributeWrapper wrapper = slotAttributeWrapper;
/*     */                   
/* 190 */                   if (amount > 0.0D) {
/* 191 */                     attributeTooltip.add((new TranslatableComponent("curios.modifiers.slots.plus." + attributemodifier
/*     */                           
/* 193 */                           .m_22217_().m_22235_(), new Object[] { ItemStack.f_41584_
/* 194 */                             .format(d1), new TranslatableComponent("curios.identifier." + wrapper.identifier)
/*     */                           
/* 196 */                           })).m_130940_(ChatFormatting.BLUE)); continue;
/*     */                   } 
/* 198 */                   d1 *= -1.0D;
/* 199 */                   attributeTooltip.add((new TranslatableComponent("curios.modifiers.slots.take." + attributemodifier
/*     */                         
/* 201 */                         .m_22217_().m_22235_(), new Object[] { ItemStack.f_41584_
/* 202 */                           .format(d1), new TranslatableComponent("curios.identifier." + wrapper.identifier)
/*     */                         
/* 204 */                         })).m_130940_(ChatFormatting.RED)); continue; }
/*     */                 
/* 206 */                 if (flag) {
/* 207 */                   attributeTooltip.add((new TextComponent(" "))
/* 208 */                       .m_7220_((Component)new TranslatableComponent("attribute.modifier.equals." + attributemodifier
/* 209 */                           .m_22217_().m_22235_(), new Object[] { ItemStack.f_41584_
/* 210 */                             .format(d1), new TranslatableComponent(((Attribute)entry
/* 211 */                               .getKey()).m_22087_())
/* 212 */                           })).m_130940_(ChatFormatting.DARK_GREEN)); continue;
/* 213 */                 }  if (amount > 0.0D) {
/* 214 */                   attributeTooltip.add((new TranslatableComponent("attribute.modifier.plus." + attributemodifier
/* 215 */                         .m_22217_().m_22235_(), new Object[] { ItemStack.f_41584_
/* 216 */                           .format(d1), new TranslatableComponent(((Attribute)entry
/* 217 */                             .getKey()).m_22087_())
/* 218 */                         })).m_130940_(ChatFormatting.BLUE)); continue;
/* 219 */                 }  if (amount < 0.0D) {
/* 220 */                   d1 *= -1.0D;
/* 221 */                   attributeTooltip.add((new TranslatableComponent("attribute.modifier.take." + attributemodifier
/* 222 */                         .m_22217_().m_22235_(), new Object[] { ItemStack.f_41584_
/* 223 */                           .format(d1), new TranslatableComponent(((Attribute)entry
/* 224 */                             .getKey()).m_22087_())
/* 225 */                         })).m_130940_(ChatFormatting.RED));
/*     */                 } 
/*     */               } 
/*     */             } 
/*     */           } 
/*     */         } 
/* 231 */         optionalCurio.ifPresent(curio -> {
/*     */               List<Component> actualAttributeTooltips = curio.getAttributesTooltip(attributeTooltip);
/*     */ 
/*     */               
/*     */               if (!actualAttributeTooltips.isEmpty()) {
/*     */                 tooltip.addAll(actualAttributeTooltips);
/*     */               }
/*     */             });
/*     */         
/* 240 */         if (!optionalCurio.isPresent())
/* 241 */           tooltip.addAll(attributeTooltip); 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\curios-309927-4590652.jar!\top\theillusivec4\curios\client\ClientEventHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */