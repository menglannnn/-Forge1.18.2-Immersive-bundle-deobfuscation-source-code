/*     */ package top.theillusivec4.curios.client.gui;
/*     */ 
/*     */ import com.mojang.blaze3d.platform.InputConstants;
/*     */ import com.mojang.blaze3d.systems.RenderSystem;
/*     */ import com.mojang.blaze3d.vertex.PoseStack;
/*     */ import javax.annotation.Nonnull;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.gui.components.Button;
/*     */ import net.minecraft.client.gui.components.ImageButton;
/*     */ import net.minecraft.client.gui.components.Widget;
/*     */ import net.minecraft.client.gui.components.events.GuiEventListener;
/*     */ import net.minecraft.client.gui.narration.NarratableEntry;
/*     */ import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
/*     */ import net.minecraft.client.gui.screens.inventory.InventoryScreen;
/*     */ import net.minecraft.client.gui.screens.recipebook.RecipeBookComponent;
/*     */ import net.minecraft.client.gui.screens.recipebook.RecipeUpdateListener;
/*     */ import net.minecraft.client.player.LocalPlayer;
/*     */ import net.minecraft.network.chat.Component;
/*     */ import net.minecraft.network.chat.TextComponent;
/*     */ import net.minecraft.network.chat.TranslatableComponent;
/*     */ import net.minecraft.resources.ResourceLocation;
/*     */ import net.minecraft.util.Mth;
/*     */ import net.minecraft.util.Tuple;
/*     */ import net.minecraft.world.entity.LivingEntity;
/*     */ import net.minecraft.world.entity.player.Inventory;
/*     */ import net.minecraft.world.inventory.AbstractContainerMenu;
/*     */ import net.minecraft.world.inventory.ClickType;
/*     */ import net.minecraft.world.inventory.RecipeBookMenu;
/*     */ import net.minecraft.world.inventory.Slot;
/*     */ import net.minecraftforge.network.PacketDistributor;
/*     */ import top.theillusivec4.curios.api.CuriosApi;
/*     */ import top.theillusivec4.curios.api.type.capability.ICuriosItemHandler;
/*     */ import top.theillusivec4.curios.client.CuriosClientConfig;
/*     */ import top.theillusivec4.curios.client.KeyRegistry;
/*     */ import top.theillusivec4.curios.common.inventory.CurioSlot;
/*     */ import top.theillusivec4.curios.common.inventory.container.CuriosContainer;
/*     */ import top.theillusivec4.curios.common.network.NetworkHandler;
/*     */ import top.theillusivec4.curios.common.network.client.CPacketToggleRender;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CuriosScreen
/*     */   extends AbstractContainerScreen<CuriosContainer>
/*     */   implements RecipeUpdateListener
/*     */ {
/*  60 */   static final ResourceLocation CURIO_INVENTORY = new ResourceLocation("curios", "textures/gui/inventory.png");
/*     */   
/*  62 */   static final ResourceLocation RECIPE_BUTTON_TEXTURE = new ResourceLocation("minecraft:textures/gui/recipe_button.png");
/*     */ 
/*     */   
/*  65 */   private static final ResourceLocation CREATIVE_INVENTORY_TABS = new ResourceLocation("textures/gui/container/creative_inventory/tabs.png");
/*     */ 
/*     */   
/*     */   private static float currentScroll;
/*     */   
/*  70 */   private final RecipeBookComponent recipeBookGui = new RecipeBookComponent();
/*     */   
/*     */   public boolean hasScrollBar;
/*     */   
/*     */   public boolean widthTooNarrow;
/*     */   
/*     */   private CuriosButton buttonCurios;
/*     */   private boolean isScrolling;
/*     */   private boolean buttonClicked;
/*     */   private boolean isRenderButtonHovered;
/*     */   
/*     */   public CuriosScreen(CuriosContainer curiosContainer, Inventory playerInventory, Component title) {
/*  82 */     super((AbstractContainerMenu)curiosContainer, playerInventory, title);
/*  83 */     this.f_96546_ = true;
/*     */   }
/*     */   
/*     */   public static Tuple<Integer, Integer> getButtonOffset(boolean isCreative) {
/*  87 */     CuriosClientConfig.Client client = CuriosClientConfig.CLIENT;
/*  88 */     CuriosClientConfig.Client.ButtonCorner corner = (CuriosClientConfig.Client.ButtonCorner)client.buttonCorner.get();
/*  89 */     int x = 0;
/*  90 */     int y = 0;
/*     */     
/*  92 */     if (isCreative) {
/*  93 */       x += corner.getCreativeXoffset() + ((Integer)client.creativeButtonXOffset.get()).intValue();
/*  94 */       y += corner.getCreativeYoffset() + ((Integer)client.creativeButtonYOffset.get()).intValue();
/*     */     } else {
/*  96 */       x += corner.getXoffset() + ((Integer)client.buttonXOffset.get()).intValue();
/*  97 */       y += corner.getYoffset() + ((Integer)client.buttonYOffset.get()).intValue();
/*     */     } 
/*  99 */     return new Tuple(Integer.valueOf(x), Integer.valueOf(y));
/*     */   }
/*     */ 
/*     */   
/*     */   public void m_7856_() {
/* 104 */     super.m_7856_();
/*     */     
/* 106 */     if (this.f_96541_ != null) {
/*     */       
/* 108 */       if (this.f_96541_.f_91074_ != null) {
/* 109 */         this
/* 110 */           .hasScrollBar = ((Boolean)CuriosApi.getCuriosHelper().getCuriosHandler((LivingEntity)this.f_96541_.f_91074_).map(handler -> Boolean.valueOf((handler.getVisibleSlots() > 8))).orElse(Boolean.valueOf(false))).booleanValue();
/*     */         
/* 112 */         if (this.hasScrollBar) {
/* 113 */           ((CuriosContainer)this.f_97732_).scrollTo(currentScroll);
/*     */         }
/*     */       } 
/* 116 */       int neededWidth = 431;
/*     */       
/* 118 */       if (this.hasScrollBar) {
/* 119 */         neededWidth += 30;
/*     */       }
/*     */       
/* 122 */       if (((CuriosContainer)this.f_97732_).hasCosmeticColumn()) {
/* 123 */         neededWidth += 40;
/*     */       }
/* 125 */       this.widthTooNarrow = (this.f_96543_ < neededWidth);
/* 126 */       this.recipeBookGui
/* 127 */         .m_100309_(this.f_96543_, this.f_96544_, this.f_96541_, this.widthTooNarrow, (RecipeBookMenu)this.f_97732_);
/* 128 */       updateScreenPosition();
/* 129 */       m_7787_((GuiEventListener)this.recipeBookGui);
/* 130 */       m_94718_((GuiEventListener)this.recipeBookGui);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 142 */       if ((getMinecraft()).f_91074_ != null && (getMinecraft()).f_91074_.m_7500_() && this.recipeBookGui
/* 143 */         .m_100385_()) {
/* 144 */         this.recipeBookGui.m_100384_();
/* 145 */         updateScreenPosition();
/*     */       } 
/*     */       
/* 148 */       Tuple<Integer, Integer> offsets = getButtonOffset(false);
/* 149 */       this
/* 150 */         .buttonCurios = new CuriosButton(this, getGuiLeft() + ((Integer)offsets.m_14418_()).intValue(), this.f_96544_ / 2 + ((Integer)offsets.m_14419_()).intValue(), 14, 14, 50, 0, 14, CURIO_INVENTORY);
/* 151 */       m_142416_((GuiEventListener)this.buttonCurios);
/*     */       
/* 153 */       if (!((CuriosContainer)this.f_97732_).player.m_7500_()) {
/* 154 */         m_142416_((GuiEventListener)new ImageButton(this.f_97735_ + 104, this.f_96544_ / 2 - 22, 20, 18, 0, 0, 19, RECIPE_BUTTON_TEXTURE, button -> {
/*     */                 this.recipeBookGui.m_100384_();
/*     */                 
/*     */                 updateScreenPosition();
/*     */                 
/*     */                 ((ImageButton)button).m_94278_(this.f_97735_ + 104, this.f_96544_ / 2 - 22);
/*     */                 
/*     */                 this.buttonCurios.m_94278_(this.f_97735_ + ((Integer)offsets.m_14418_()).intValue(), this.f_96544_ / 2 + ((Integer)offsets.m_14419_()).intValue());
/*     */               }));
/*     */       }
/* 164 */       updateRenderButtons();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void updateRenderButtons() {
/* 169 */     this.f_169368_.removeIf(widget -> widget instanceof RenderButton);
/* 170 */     this.f_96540_.removeIf(widget -> widget instanceof RenderButton);
/* 171 */     this.f_169369_.removeIf(widget -> widget instanceof RenderButton);
/*     */     
/* 173 */     for (Slot inventorySlot : ((CuriosContainer)this.f_97732_).f_38839_) {
/*     */       
/* 175 */       if (inventorySlot instanceof CurioSlot && !(inventorySlot instanceof top.theillusivec4.curios.common.inventory.CosmeticCurioSlot)) {
/* 176 */         m_142416_((GuiEventListener)new RenderButton((CurioSlot)inventorySlot, this.f_97735_ + inventorySlot.f_40220_ + 11, this.f_97736_ + inventorySlot.f_40221_ - 3, 8, 8, 75, 0, 8, CURIO_INVENTORY, button -> NetworkHandler.INSTANCE.send(PacketDistributor.SERVER.noArg(), new CPacketToggleRender(((CurioSlot)inventorySlot).getIdentifier(), inventorySlot.getSlotIndex()))));
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void updateScreenPosition() {
/*     */     int i;
/* 189 */     if (this.recipeBookGui.m_100385_() && !this.widthTooNarrow) {
/* 190 */       int offset = 148;
/*     */       
/* 192 */       if (this.hasScrollBar) {
/* 193 */         offset -= 30;
/*     */       }
/*     */       
/* 196 */       if (((CuriosContainer)this.f_97732_).hasCosmeticColumn()) {
/* 197 */         offset -= 40;
/*     */       }
/* 199 */       i = 177 + (this.f_96543_ - this.f_97726_ - offset) / 2;
/*     */     } else {
/* 201 */       i = (this.f_96543_ - this.f_97726_) / 2;
/*     */     } 
/* 203 */     this.f_97735_ = i;
/* 204 */     updateRenderButtons();
/*     */   }
/*     */ 
/*     */   
/*     */   public void m_181908_() {
/* 209 */     super.m_181908_();
/* 210 */     this.recipeBookGui.m_100386_();
/*     */   }
/*     */   
/*     */   private boolean inScrollBar(double mouseX, double mouseY) {
/* 214 */     int i = this.f_97735_;
/* 215 */     int j = this.f_97736_;
/* 216 */     int k = i - 34;
/* 217 */     int l = j + 12;
/* 218 */     int i1 = k + 14;
/* 219 */     int j1 = l + 139;
/*     */     
/* 221 */     if (((CuriosContainer)this.f_97732_).hasCosmeticColumn()) {
/* 222 */       i1 -= 19;
/* 223 */       k -= 19;
/*     */     } 
/* 225 */     return (mouseX >= k && mouseY >= l && mouseX < i1 && mouseY < j1);
/*     */   }
/*     */ 
/*     */   
/*     */   public void m_6305_(@Nonnull PoseStack matrixStack, int mouseX, int mouseY, float partialTicks) {
/* 230 */     m_7333_(matrixStack);
/*     */     
/* 232 */     if (this.recipeBookGui.m_100385_() && this.widthTooNarrow) {
/* 233 */       m_7286_(matrixStack, partialTicks, mouseX, mouseY);
/* 234 */       this.recipeBookGui.m_6305_(matrixStack, mouseX, mouseY, partialTicks);
/*     */     } else {
/* 236 */       this.recipeBookGui.m_6305_(matrixStack, mouseX, mouseY, partialTicks);
/* 237 */       super.m_6305_(matrixStack, mouseX, mouseY, partialTicks);
/* 238 */       this.recipeBookGui
/* 239 */         .m_6545_(matrixStack, this.f_97735_, this.f_97736_, true, partialTicks);
/*     */       
/* 241 */       boolean isButtonHovered = false;
/*     */       
/* 243 */       for (Widget button : this.f_169369_) {
/*     */         
/* 245 */         if (button instanceof RenderButton) {
/* 246 */           ((RenderButton)button).renderButtonOverlay(matrixStack, mouseX, mouseY, partialTicks);
/*     */           
/* 248 */           if (((RenderButton)button).m_198029_()) {
/* 249 */             isButtonHovered = true;
/*     */           }
/*     */         } 
/*     */       } 
/* 253 */       this.isRenderButtonHovered = isButtonHovered;
/* 254 */       LocalPlayer clientPlayer = (Minecraft.m_91087_()).f_91074_;
/*     */       
/* 256 */       if (!this.isRenderButtonHovered && clientPlayer != null && clientPlayer.f_36095_
/* 257 */         .m_142621_().m_41619_() && getSlotUnderMouse() != null) {
/* 258 */         Slot slot = getSlotUnderMouse();
/*     */         
/* 260 */         if (slot instanceof CurioSlot) { CurioSlot slotCurio = (CurioSlot)slot; if (!slot.m_6657_()) {
/* 261 */             m_96602_(matrixStack, (Component)new TextComponent(slotCurio.getSlotName()), mouseX, mouseY);
/*     */           } }
/*     */       
/*     */       } 
/*     */     } 
/* 266 */     m_7025_(matrixStack, mouseX, mouseY);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void m_7025_(@Nonnull PoseStack matrixStack, int mouseX, int mouseY) {
/* 271 */     Minecraft mc = this.f_96541_;
/*     */     
/* 273 */     if (mc != null) {
/* 274 */       LocalPlayer clientPlayer = mc.f_91074_;
/*     */       
/* 276 */       if (clientPlayer != null && clientPlayer.f_36095_.m_142621_().m_41619_())
/*     */       {
/* 278 */         if (this.isRenderButtonHovered) {
/* 279 */           m_96602_(matrixStack, (Component)new TranslatableComponent("gui.curios.toggle"), mouseX, mouseY);
/*     */         }
/* 281 */         else if (this.f_97734_ != null && this.f_97734_.m_6657_()) {
/* 282 */           m_6057_(matrixStack, this.f_97734_.m_7993_(), mouseX, mouseY);
/*     */         } 
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean m_7933_(int p_keyPressed_1_, int p_keyPressed_2_, int p_keyPressed_3_) {
/* 291 */     if (this.recipeBookGui.m_100385_() && this.widthTooNarrow) {
/* 292 */       this.recipeBookGui.m_100384_();
/* 293 */       updateScreenPosition();
/* 294 */       return true;
/* 295 */     }  if (KeyRegistry.openCurios
/* 296 */       .isActiveAndMatches(InputConstants.m_84827_(p_keyPressed_1_, p_keyPressed_2_))) {
/* 297 */       LocalPlayer playerEntity = (getMinecraft()).f_91074_;
/*     */       
/* 299 */       if (playerEntity != null) {
/* 300 */         playerEntity.m_6915_();
/*     */       }
/* 302 */       return true;
/*     */     } 
/* 304 */     return super.m_7933_(p_keyPressed_1_, p_keyPressed_2_, p_keyPressed_3_);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void m_7027_(@Nonnull PoseStack matrixStack, int mouseX, int mouseY) {
/* 312 */     if (this.f_96541_ != null && this.f_96541_.f_91074_ != null) {
/* 313 */       this.f_96547_.m_92889_(matrixStack, this.f_96539_, 97.0F, 6.0F, 4210752);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void m_7286_(@Nonnull PoseStack matrixStack, float partialTicks, int mouseX, int mouseY) {
/* 325 */     if (this.f_96541_ != null && this.f_96541_.f_91074_ != null) {
/* 326 */       RenderSystem.m_157429_(1.0F, 1.0F, 1.0F, 1.0F);
/* 327 */       RenderSystem.m_157456_(0, f_97725_);
/* 328 */       int i = this.f_97735_;
/* 329 */       int j = this.f_97736_;
/* 330 */       m_93228_(matrixStack, i, j, 0, 0, this.f_97726_, this.f_97727_);
/* 331 */       InventoryScreen.m_98850_(i + 51, j + 75, 30, (i + 51) - mouseX, (j + 75 - 50) - mouseY, (LivingEntity)this.f_96541_.f_91074_);
/*     */       
/* 333 */       CuriosApi.getCuriosHelper().getCuriosHandler((LivingEntity)this.f_96541_.f_91074_).ifPresent(handler -> {
/*     */             int slotCount = handler.getVisibleSlots();
/*     */             if (slotCount > 0) {
/*     */               int upperHeight = 7 + Math.min(slotCount, 9) * 18;
/*     */               RenderSystem.m_157429_(1.0F, 1.0F, 1.0F, 1.0F);
/*     */               RenderSystem.m_157456_(0, CURIO_INVENTORY);
/*     */               int xTexOffset = 0;
/*     */               int width = 27;
/*     */               int xOffset = -26;
/*     */               if (((CuriosContainer)this.f_97732_).hasCosmeticColumn()) {
/*     */                 xTexOffset = 92;
/*     */                 width = 46;
/*     */                 xOffset -= 19;
/*     */               } 
/*     */               m_93228_(matrixStack, i + xOffset, j + 4, xTexOffset, 0, width, upperHeight);
/*     */               if (slotCount <= 8) {
/*     */                 m_93228_(matrixStack, i + xOffset, j + 4 + upperHeight, xTexOffset, 151, width, 7);
/*     */               } else {
/*     */                 m_93228_(matrixStack, i + xOffset - 16, j + 4, 27, 0, 23, 158);
/*     */                 RenderSystem.m_157456_(0, CREATIVE_INVENTORY_TABS);
/*     */                 m_93228_(matrixStack, i + xOffset - 8, j + 12 + (int)(127.0F * currentScroll), 232, 0, 12, 15);
/*     */               } 
/*     */               for (Slot slot : ((CuriosContainer)this.f_97732_).f_38839_) {
/*     */                 if (slot instanceof top.theillusivec4.curios.common.inventory.CosmeticCurioSlot) {
/*     */                   int x = this.f_97735_ + slot.f_40220_ - 1;
/*     */                   int y = this.f_97736_ + slot.f_40221_ - 1;
/*     */                   RenderSystem.m_157456_(0, CURIO_INVENTORY);
/*     */                   m_93228_(matrixStack, x, y, 138, 0, 18, 18);
/*     */                 } 
/*     */               } 
/*     */             } 
/*     */           });
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean m_6774_(int rectX, int rectY, int rectWidth, int rectHeight, double pointX, double pointY) {
/* 382 */     if (this.isRenderButtonHovered) {
/* 383 */       return false;
/*     */     }
/* 385 */     return ((!this.widthTooNarrow || !this.recipeBookGui.m_100385_()) && super
/* 386 */       .m_6774_(rectX, rectY, rectWidth, rectHeight, pointX, pointY));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean m_6375_(double mouseX, double mouseY, int mouseButton) {
/* 395 */     if (this.recipeBookGui.m_6375_(mouseX, mouseY, mouseButton))
/* 396 */       return true; 
/* 397 */     if (inScrollBar(mouseX, mouseY)) {
/* 398 */       this.isScrolling = needsScrollBars();
/* 399 */       return true;
/*     */     } 
/* 401 */     return ((this.widthTooNarrow && this.recipeBookGui.m_100385_()) || super
/* 402 */       .m_6375_(mouseX, mouseY, mouseButton));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean m_6348_(double mouseReleased1, double mouseReleased3, int mouseReleased5) {
/* 408 */     if (mouseReleased5 == 0) {
/* 409 */       this.isScrolling = false;
/*     */     }
/*     */     
/* 412 */     if (this.buttonClicked) {
/* 413 */       this.buttonClicked = false;
/* 414 */       return true;
/*     */     } 
/* 416 */     return super.m_6348_(mouseReleased1, mouseReleased3, mouseReleased5);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean m_7979_(double pMouseDragged1, double pMouseDragged3, int pMouseDragged5, double pMouseDragged6, double pMouseDragged8) {
/* 424 */     if (this.isScrolling) {
/* 425 */       int i = this.f_97736_ + 8;
/* 426 */       int j = i + 148;
/* 427 */       currentScroll = ((float)pMouseDragged3 - i - 7.5F) / ((j - i) - 15.0F);
/* 428 */       currentScroll = Mth.m_14036_(currentScroll, 0.0F, 1.0F);
/* 429 */       ((CuriosContainer)this.f_97732_).scrollTo(currentScroll);
/* 430 */       return true;
/*     */     } 
/* 432 */     return super.m_7979_(pMouseDragged1, pMouseDragged3, pMouseDragged5, pMouseDragged6, pMouseDragged8);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean m_6050_(double pMouseScrolled1, double pMouseScrolled3, double pMouseScrolled5) {
/* 441 */     if (!needsScrollBars()) {
/* 442 */       return false;
/*     */     }
/* 444 */     int i = ((Integer)((CuriosContainer)this.f_97732_).curiosHandler.map(ICuriosItemHandler::getVisibleSlots).orElse(Integer.valueOf(1))).intValue();
/* 445 */     currentScroll = (float)(currentScroll - pMouseScrolled5 / i);
/* 446 */     currentScroll = Mth.m_14036_(currentScroll, 0.0F, 1.0F);
/* 447 */     ((CuriosContainer)this.f_97732_).scrollTo(currentScroll);
/* 448 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean needsScrollBars() {
/* 453 */     return ((CuriosContainer)this.f_97732_).canScroll();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean m_7467_(double mouseX, double mouseY, int guiLeftIn, int guiTopIn, int mouseButton) {
/* 459 */     boolean flag = (mouseX < guiLeftIn || mouseY < guiTopIn || mouseX >= (guiLeftIn + this.f_97726_) || mouseY >= (guiTopIn + this.f_97727_));
/*     */     
/* 461 */     return (this.recipeBookGui
/* 462 */       .m_100297_(mouseX, mouseY, this.f_97735_, this.f_97736_, this.f_97726_, this.f_97727_, mouseButton) && flag);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void m_6597_(@Nonnull Slot slotIn, int slotId, int mouseButton, @Nonnull ClickType type) {
/* 470 */     super.m_6597_(slotIn, slotId, mouseButton, type);
/* 471 */     this.recipeBookGui.m_6904_(slotIn);
/*     */   }
/*     */ 
/*     */   
/*     */   public void m_6916_() {
/* 476 */     this.recipeBookGui.m_100387_();
/*     */   }
/*     */ 
/*     */   
/*     */   public void m_7861_() {
/* 481 */     this.recipeBookGui.m_100373_();
/* 482 */     super.m_7861_();
/*     */   }
/*     */ 
/*     */   
/*     */   @Nonnull
/*     */   public RecipeBookComponent m_5564_() {
/* 488 */     return this.recipeBookGui;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\curios-309927-4590652.jar!\top\theillusivec4\curios\client\gui\CuriosScreen.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */