/*     */ package top.theillusivec4.curios.common.inventory.container;
/*     */ 
/*     */ import com.mojang.datafixers.util.Pair;
/*     */ import java.util.Map;
/*     */ import java.util.Optional;
/*     */ import javax.annotation.Nonnull;
/*     */ import net.minecraft.network.FriendlyByteBuf;
/*     */ import net.minecraft.network.protocol.Packet;
/*     */ import net.minecraft.network.protocol.game.ClientboundContainerSetSlotPacket;
/*     */ import net.minecraft.resources.ResourceLocation;
/*     */ import net.minecraft.server.MinecraftServer;
/*     */ import net.minecraft.server.level.ServerPlayer;
/*     */ import net.minecraft.world.Container;
/*     */ import net.minecraft.world.entity.Entity;
/*     */ import net.minecraft.world.entity.EquipmentSlot;
/*     */ import net.minecraft.world.entity.LivingEntity;
/*     */ import net.minecraft.world.entity.Mob;
/*     */ import net.minecraft.world.entity.player.Inventory;
/*     */ import net.minecraft.world.entity.player.Player;
/*     */ import net.minecraft.world.entity.player.StackedContents;
/*     */ import net.minecraft.world.inventory.AbstractContainerMenu;
/*     */ import net.minecraft.world.inventory.CraftingContainer;
/*     */ import net.minecraft.world.inventory.InventoryMenu;
/*     */ import net.minecraft.world.inventory.RecipeBookType;
/*     */ import net.minecraft.world.inventory.ResultContainer;
/*     */ import net.minecraft.world.inventory.ResultSlot;
/*     */ import net.minecraft.world.inventory.Slot;
/*     */ import net.minecraft.world.item.ItemStack;
/*     */ import net.minecraft.world.item.crafting.CraftingRecipe;
/*     */ import net.minecraft.world.item.crafting.Recipe;
/*     */ import net.minecraft.world.item.crafting.RecipeType;
/*     */ import net.minecraft.world.item.enchantment.EnchantmentHelper;
/*     */ import net.minecraftforge.api.distmarker.Dist;
/*     */ import net.minecraftforge.api.distmarker.OnlyIn;
/*     */ import net.minecraftforge.common.util.LazyOptional;
/*     */ import net.minecraftforge.network.PacketDistributor;
/*     */ import top.theillusivec4.curios.api.CuriosApi;
/*     */ import top.theillusivec4.curios.api.type.capability.ICuriosItemHandler;
/*     */ import top.theillusivec4.curios.api.type.inventory.ICurioStacksHandler;
/*     */ import top.theillusivec4.curios.api.type.inventory.IDynamicStackHandler;
/*     */ import top.theillusivec4.curios.common.CuriosRegistry;
/*     */ import top.theillusivec4.curios.common.inventory.CosmeticCurioSlot;
/*     */ import top.theillusivec4.curios.common.inventory.CurioSlot;
/*     */ import top.theillusivec4.curios.common.network.NetworkHandler;
/*     */ import top.theillusivec4.curios.common.network.client.CPacketScroll;
/*     */ import top.theillusivec4.curios.common.network.server.SPacketScroll;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CuriosContainer
/*     */   extends InventoryMenu
/*     */ {
/*  65 */   private static final ResourceLocation[] ARMOR_SLOT_TEXTURES = new ResourceLocation[] { InventoryMenu.f_39696_, InventoryMenu.f_39695_, InventoryMenu.f_39694_, InventoryMenu.f_39693_ };
/*     */ 
/*     */   
/*  68 */   private static final EquipmentSlot[] VALID_EQUIPMENT_SLOTS = new EquipmentSlot[] { EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET };
/*     */ 
/*     */   
/*     */   public final LazyOptional<ICuriosItemHandler> curiosHandler;
/*     */   
/*     */   public final Player player;
/*     */   
/*     */   private final boolean isLocalWorld;
/*     */   
/*  77 */   private CraftingContainer craftMatrix = new CraftingContainer((AbstractContainerMenu)this, 2, 2);
/*  78 */   private ResultContainer craftResult = new ResultContainer();
/*     */   private int lastScrollIndex;
/*     */   private boolean cosmeticColumn;
/*     */   
/*     */   public CuriosContainer(int windowId, Inventory playerInventory, FriendlyByteBuf packetBuffer) {
/*  83 */     this(windowId, playerInventory);
/*     */   }
/*     */   
/*     */   public CuriosContainer(int windowId, Inventory playerInventory) {
/*  87 */     super(playerInventory, playerInventory.f_35978_.f_19853_.f_46443_, playerInventory.f_35978_);
/*  88 */     this.f_38843_ = CuriosRegistry.CONTAINER_TYPE;
/*  89 */     this.f_38840_ = windowId;
/*  90 */     this.f_38841_.clear();
/*  91 */     this.f_38839_.clear();
/*  92 */     this.player = playerInventory.f_35978_;
/*  93 */     this.isLocalWorld = this.player.f_19853_.f_46443_;
/*  94 */     this.curiosHandler = CuriosApi.getCuriosHelper().getCuriosHandler((LivingEntity)this.player);
/*  95 */     m_38897_((Slot)new ResultSlot(playerInventory.f_35978_, this.craftMatrix, (Container)this.craftResult, 0, 154, 28));
/*     */ 
/*     */ 
/*     */     
/*  99 */     for (int i = 0; i < 2; i++) {
/*     */       
/* 101 */       for (int j = 0; j < 2; j++) {
/* 102 */         m_38897_(new Slot((Container)this.craftMatrix, j + i * 2, 98 + j * 18, 18 + i * 18));
/*     */       }
/*     */     } 
/*     */     
/* 106 */     for (int k = 0; k < 4; k++) {
/* 107 */       final EquipmentSlot equipmentslottype = VALID_EQUIPMENT_SLOTS[k];
/* 108 */       m_38897_(new Slot((Container)playerInventory, 36 + 3 - k, 8, 8 + k * 18)
/*     */           {
/*     */             public int m_6641_()
/*     */             {
/* 112 */               return 1;
/*     */             }
/*     */ 
/*     */             
/*     */             public boolean m_5857_(@Nonnull ItemStack stack) {
/* 117 */               return stack.canEquip(equipmentslottype, (Entity)CuriosContainer.this.player);
/*     */             }
/*     */ 
/*     */             
/*     */             public boolean m_8010_(@Nonnull Player playerIn) {
/* 122 */               ItemStack itemstack = m_7993_();
/* 123 */               return ((itemstack.m_41619_() || playerIn.m_7500_() || 
/* 124 */                 !EnchantmentHelper.m_44920_(itemstack)) && super.m_8010_(playerIn));
/*     */             }
/*     */ 
/*     */ 
/*     */             
/*     */             @OnlyIn(Dist.CLIENT)
/*     */             public Pair<ResourceLocation, ResourceLocation> m_7543_() {
/* 131 */               return Pair.of(InventoryMenu.f_39692_, CuriosContainer.ARMOR_SLOT_TEXTURES[equipmentslottype
/* 132 */                     .m_20749_()]);
/*     */             }
/*     */           });
/*     */     } 
/*     */     
/* 137 */     for (int l = 0; l < 3; l++) {
/*     */       
/* 139 */       for (int j1 = 0; j1 < 9; j1++) {
/* 140 */         m_38897_(new Slot((Container)playerInventory, j1 + (l + 1) * 9, 8 + j1 * 18, 84 + l * 18));
/*     */       }
/*     */     } 
/*     */     
/* 144 */     for (int i1 = 0; i1 < 9; i1++) {
/* 145 */       m_38897_(new Slot((Container)playerInventory, i1, 8 + i1 * 18, 142));
/*     */     }
/* 147 */     m_38897_(new Slot((Container)playerInventory, 40, 77, 62)
/*     */         {
/*     */           @OnlyIn(Dist.CLIENT)
/*     */           public Pair<ResourceLocation, ResourceLocation> m_7543_() {
/* 151 */             return 
/* 152 */               Pair.of(InventoryMenu.f_39692_, InventoryMenu.f_39697_);
/*     */           }
/*     */         });
/*     */     
/* 156 */     this.curiosHandler.ifPresent(curios -> {
/*     */           Map<String, ICurioStacksHandler> curioMap = curios.getCurios();
/*     */           
/*     */           int slots = 0;
/*     */           
/*     */           int yOffset = 12;
/*     */           
/*     */           for (String identifier : curioMap.keySet()) {
/*     */             ICurioStacksHandler stacksHandler = curioMap.get(identifier);
/*     */             
/*     */             IDynamicStackHandler stackHandler = stacksHandler.getStacks();
/*     */             
/*     */             if (stacksHandler.isVisible()) {
/*     */               int i = 0;
/*     */               while (i < stackHandler.getSlots() && slots < 8) {
/*     */                 m_38897_((Slot)new CurioSlot(this.player, stackHandler, i, identifier, -18, yOffset, stacksHandler.getRenders()));
/*     */                 yOffset += 18;
/*     */                 slots++;
/*     */                 i++;
/*     */               } 
/*     */             } 
/*     */           } 
/*     */           yOffset = 12;
/*     */           slots = 0;
/*     */           for (String identifier : curioMap.keySet()) {
/*     */             ICurioStacksHandler stacksHandler = curioMap.get(identifier);
/*     */             IDynamicStackHandler stackHandler = stacksHandler.getStacks();
/*     */             if (stacksHandler.isVisible()) {
/*     */               int i = 0;
/*     */               while (i < stackHandler.getSlots() && slots < 8) {
/*     */                 if (stacksHandler.hasCosmetic()) {
/*     */                   IDynamicStackHandler cosmeticHandler = stacksHandler.getCosmeticStacks();
/*     */                   this.cosmeticColumn = true;
/*     */                   m_38897_((Slot)new CosmeticCurioSlot(this.player, cosmeticHandler, i, identifier, -37, yOffset));
/*     */                 } 
/*     */                 yOffset += 18;
/*     */                 slots++;
/*     */                 i++;
/*     */               } 
/*     */             } 
/*     */           } 
/*     */         });
/* 198 */     scrollToIndex(0);
/*     */   }
/*     */   
/*     */   public boolean hasCosmeticColumn() {
/* 202 */     return this.cosmeticColumn;
/*     */   }
/*     */   
/*     */   public void resetSlots() {
/* 206 */     scrollToIndex(this.lastScrollIndex);
/*     */   }
/*     */ 
/*     */   
/*     */   public void scrollToIndex(int indexIn) {
/* 211 */     this.curiosHandler.ifPresent(curios -> {
/*     */           Map<String, ICurioStacksHandler> curioMap = curios.getCurios();
/*     */           int slots = 0;
/*     */           int yOffset = 12;
/*     */           int index = 0;
/*     */           int startingIndex = indexIn;
/*     */           this.f_38839_.subList(46, this.f_38839_.size()).clear();
/*     */           this.f_38841_.subList(46, this.f_38841_.size()).clear();
/*     */           this.f_150394_.subList(46, this.f_150394_.size()).clear();
/*     */           for (String identifier : curioMap.keySet()) {
/*     */             ICurioStacksHandler stacksHandler = curioMap.get(identifier);
/*     */             IDynamicStackHandler stackHandler = stacksHandler.getStacks();
/*     */             if (stacksHandler.isVisible()) {
/*     */               int i = 0;
/*     */               while (i < stackHandler.getSlots() && slots < 8) {
/*     */                 if (index >= startingIndex) {
/*     */                   slots++;
/*     */                 }
/*     */                 index++;
/*     */                 i++;
/*     */               } 
/*     */             } 
/*     */           } 
/*     */           startingIndex = Math.min(startingIndex, Math.max(0, index - 8));
/*     */           index = 0;
/*     */           slots = 0;
/*     */           for (String identifier : curioMap.keySet()) {
/*     */             ICurioStacksHandler stacksHandler = curioMap.get(identifier);
/*     */             IDynamicStackHandler stackHandler = stacksHandler.getStacks();
/*     */             if (stacksHandler.isVisible()) {
/*     */               int i = 0;
/*     */               while (i < stackHandler.getSlots() && slots < 8) {
/*     */                 if (index >= startingIndex) {
/*     */                   m_38897_((Slot)new CurioSlot(this.player, stackHandler, i, identifier, -18, yOffset, stacksHandler.getRenders()));
/*     */                   yOffset += 18;
/*     */                   slots++;
/*     */                 } 
/*     */                 index++;
/*     */                 i++;
/*     */               } 
/*     */             } 
/*     */           } 
/*     */           index = 0;
/*     */           slots = 0;
/*     */           yOffset = 12;
/*     */           for (String identifier : curioMap.keySet()) {
/*     */             ICurioStacksHandler stacksHandler = curioMap.get(identifier);
/*     */             IDynamicStackHandler stackHandler = stacksHandler.getStacks();
/*     */             if (stacksHandler.isVisible()) {
/*     */               int i = 0;
/*     */               while (i < stackHandler.getSlots() && slots < 8) {
/*     */                 if (index >= startingIndex) {
/*     */                   if (stacksHandler.hasCosmetic()) {
/*     */                     IDynamicStackHandler cosmeticHandler = stacksHandler.getCosmeticStacks();
/*     */                     this.cosmeticColumn = true;
/*     */                     m_38897_((Slot)new CosmeticCurioSlot(this.player, cosmeticHandler, i, identifier, -37, yOffset));
/*     */                   } 
/*     */                   yOffset += 18;
/*     */                   slots++;
/*     */                 } 
/*     */                 index++;
/*     */                 i++;
/*     */               } 
/*     */             } 
/*     */           } 
/*     */           if (!this.isLocalWorld) {
/*     */             NetworkHandler.INSTANCE.send(PacketDistributor.PLAYER.with(()), new SPacketScroll(this.f_38840_, indexIn));
/*     */           }
/*     */           this.lastScrollIndex = indexIn;
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void scrollTo(float pos) {
/* 298 */     this.curiosHandler.ifPresent(curios -> {
/*     */           int k = curios.getVisibleSlots() - 8;
/*     */           int j = (int)((pos * k) + 0.5D);
/*     */           if (j < 0) {
/*     */             j = 0;
/*     */           }
/*     */           if (j == this.lastScrollIndex) {
/*     */             return;
/*     */           }
/*     */           if (this.isLocalWorld) {
/*     */             NetworkHandler.INSTANCE.send(PacketDistributor.SERVER.noArg(), new CPacketScroll(this.f_38840_, j));
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void m_6199_(@Nonnull Container inventoryIn) {
/* 320 */     if (!this.player.f_19853_.f_46443_) {
/* 321 */       ServerPlayer playerMP = (ServerPlayer)this.player;
/* 322 */       ItemStack stack = ItemStack.f_41583_;
/* 323 */       MinecraftServer server = this.player.f_19853_.m_142572_();
/*     */       
/* 325 */       if (server == null) {
/*     */         return;
/*     */       }
/*     */       
/* 329 */       Optional<CraftingRecipe> recipe = server.m_129894_().m_44015_(RecipeType.f_44107_, (Container)this.craftMatrix, this.player.f_19853_);
/*     */       
/* 331 */       if (recipe.isPresent()) {
/* 332 */         CraftingRecipe craftingRecipe = recipe.get();
/* 333 */         if (this.craftResult.m_40135_(this.player.f_19853_, playerMP, (Recipe)craftingRecipe)) {
/* 334 */           stack = craftingRecipe.m_5874_((Container)this.craftMatrix);
/*     */         }
/*     */       } 
/* 337 */       this.craftResult.m_6836_(0, stack);
/* 338 */       m_150404_(0, stack);
/* 339 */       playerMP.f_8906_.m_141995_((Packet)new ClientboundContainerSetSlotPacket(this.f_38840_, 
/* 340 */             m_182425_(), 0, stack));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void m_6877_(@Nonnull Player playerIn) {
/* 347 */     super.m_6877_(playerIn);
/* 348 */     this.craftResult.m_6211_();
/*     */     
/* 350 */     if (!playerIn.f_19853_.f_46443_) {
/* 351 */       m_150411_(playerIn, (Container)this.craftMatrix);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canScroll() {
/* 357 */     return 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 363 */       (((Integer)this.curiosHandler.map(curios -> (curios.getVisibleSlots() > 8) ? Integer.valueOf(1) : Integer.valueOf(0)).orElse(Integer.valueOf(0))).intValue() == 1);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean m_6875_(@Nonnull Player playerIn) {
/* 369 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void m_182406_(int pSlotId, int pStateId, @Nonnull ItemStack pStack) {
/* 375 */     if (this.f_38839_.size() > pSlotId) {
/* 376 */       super.m_182406_(pSlotId, pStateId, pStack);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   @Nonnull
/*     */   public ItemStack m_7648_(@Nonnull Player playerIn, int index) {
/* 383 */     ItemStack itemstack = ItemStack.f_41583_;
/* 384 */     Slot slot = (Slot)this.f_38839_.get(index);
/*     */     
/* 386 */     if (slot.m_6657_()) {
/* 387 */       ItemStack itemstack1 = slot.m_7993_();
/* 388 */       itemstack = itemstack1.m_41777_();
/* 389 */       EquipmentSlot entityequipmentslot = Mob.m_147233_(itemstack);
/* 390 */       if (index == 0) {
/*     */         
/* 392 */         if (!m_38903_(itemstack1, 9, 45, true)) {
/* 393 */           return ItemStack.f_41583_;
/*     */         }
/* 395 */         slot.m_40234_(itemstack1, itemstack);
/* 396 */       } else if (index < 5) {
/*     */         
/* 398 */         if (!m_38903_(itemstack1, 9, 45, false)) {
/* 399 */           return ItemStack.f_41583_;
/*     */         }
/* 401 */       } else if (index < 9) {
/*     */         
/* 403 */         if (!m_38903_(itemstack1, 9, 45, false)) {
/* 404 */           return ItemStack.f_41583_;
/*     */         }
/* 406 */       } else if (entityequipmentslot.m_20743_() == EquipmentSlot.Type.ARMOR && 
/* 407 */         !((Slot)this.f_38839_.get(8 - entityequipmentslot.m_20749_())).m_6657_()) {
/* 408 */         int i = 8 - entityequipmentslot.m_20749_();
/*     */         
/* 410 */         if (!m_38903_(itemstack1, i, i + 1, false)) {
/* 411 */           return ItemStack.f_41583_;
/*     */         }
/* 413 */       } else if (index < 46 && 
/* 414 */         !CuriosApi.getCuriosHelper().getCurioTags(itemstack.m_41720_()).isEmpty()) {
/*     */         
/* 416 */         if (!m_38903_(itemstack1, 46, this.f_38839_.size(), false)) {
/* 417 */           return ItemStack.f_41583_;
/*     */         }
/* 419 */       } else if (entityequipmentslot == EquipmentSlot.OFFHAND && 
/* 420 */         !((Slot)this.f_38839_.get(45)).m_6657_()) {
/*     */         
/* 422 */         if (!m_38903_(itemstack1, 45, 46, false)) {
/* 423 */           return ItemStack.f_41583_;
/*     */         }
/* 425 */       } else if (index < 36) {
/* 426 */         if (!m_38903_(itemstack1, 36, 45, false)) {
/* 427 */           return ItemStack.f_41583_;
/*     */         }
/* 429 */       } else if (index < 45) {
/* 430 */         if (!m_38903_(itemstack1, 9, 36, false)) {
/* 431 */           return ItemStack.f_41583_;
/*     */         }
/* 433 */       } else if (!m_38903_(itemstack1, 9, 45, false)) {
/* 434 */         return ItemStack.f_41583_;
/*     */       } 
/*     */       
/* 437 */       if (itemstack1.m_41619_()) {
/* 438 */         slot.m_5852_(ItemStack.f_41583_);
/*     */       } else {
/* 440 */         slot.m_6654_();
/*     */       } 
/*     */       
/* 443 */       if (itemstack1.m_41613_() == itemstack.m_41613_()) {
/* 444 */         return ItemStack.f_41583_;
/*     */       }
/* 446 */       slot.m_142406_(playerIn, itemstack1);
/*     */       
/* 448 */       if (index == 0) {
/* 449 */         playerIn.m_36176_(itemstack1, false);
/*     */       }
/*     */     } 
/*     */     
/* 453 */     return itemstack;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nonnull
/*     */   public RecipeBookType m_5867_() {
/* 459 */     return RecipeBookType.CRAFTING;
/*     */   }
/*     */ 
/*     */   
/*     */   public void m_5816_(@Nonnull StackedContents itemHelperIn) {
/* 464 */     this.craftMatrix.m_5809_(itemHelperIn);
/*     */   }
/*     */ 
/*     */   
/*     */   public void m_6650_() {
/* 469 */     this.craftMatrix.m_6211_();
/* 470 */     this.craftResult.m_6211_();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean m_6032_(Recipe<? super CraftingContainer> recipeIn) {
/* 475 */     return recipeIn.m_5818_((Container)this.craftMatrix, this.player.f_19853_);
/*     */   }
/*     */ 
/*     */   
/*     */   public int m_6636_() {
/* 480 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public int m_6635_() {
/* 485 */     return this.craftMatrix.m_39347_();
/*     */   }
/*     */ 
/*     */   
/*     */   public int m_6656_() {
/* 490 */     return this.craftMatrix.m_39346_();
/*     */   }
/*     */ 
/*     */   
/*     */   public int m_6653_() {
/* 495 */     return 5;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\curios-309927-4590652.jar!\top\theillusivec4\curios\common\inventory\container\CuriosContainer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */