/*    */ package top.theillusivec4.curios.common.inventory;
/*    */ 
/*    */ import net.minecraft.client.resources.language.I18n;
/*    */ import net.minecraft.core.NonNullList;
/*    */ import net.minecraft.resources.ResourceLocation;
/*    */ import net.minecraft.world.entity.player.Player;
/*    */ import net.minecraft.world.inventory.InventoryMenu;
/*    */ import net.minecraftforge.api.distmarker.Dist;
/*    */ import net.minecraftforge.api.distmarker.OnlyIn;
/*    */ import top.theillusivec4.curios.api.type.inventory.IDynamicStackHandler;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CosmeticCurioSlot
/*    */   extends CurioSlot
/*    */ {
/*    */   public CosmeticCurioSlot(Player player, IDynamicStackHandler handler, int index, String identifier, int xPosition, int yPosition) {
/* 36 */     super(player, handler, index, identifier, xPosition, yPosition, NonNullList.m_122779_());
/* 37 */     setBackground(InventoryMenu.f_39692_, new ResourceLocation("curios", "item/empty_cosmetic_slot"));
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean getRenderStatus() {
/* 43 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   @OnlyIn(Dist.CLIENT)
/*    */   public String getSlotName() {
/* 49 */     return I18n.m_118938_("curios.cosmetic", new Object[0]) + " " + I18n.m_118938_("curios.cosmetic", new Object[0]);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\curios-309927-4590652.jar!\top\theillusivec4\curios\common\inventory\CosmeticCurioSlot.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */