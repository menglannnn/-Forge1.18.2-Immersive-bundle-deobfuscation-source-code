/*     */ package top.theillusivec4.curios.common.inventory;
/*     */ 
/*     */ import com.google.common.collect.HashMultimap;
/*     */ import com.google.common.collect.Multimap;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ import java.util.UUID;
/*     */ import net.minecraft.core.NonNullList;
/*     */ import net.minecraft.nbt.CompoundTag;
/*     */ import net.minecraft.nbt.ListTag;
/*     */ import net.minecraft.nbt.Tag;
/*     */ import net.minecraft.world.entity.LivingEntity;
/*     */ import net.minecraft.world.entity.ai.attributes.Attribute;
/*     */ import net.minecraft.world.entity.ai.attributes.AttributeModifier;
/*     */ import net.minecraft.world.entity.player.Player;
/*     */ import net.minecraft.world.item.ItemStack;
/*     */ import net.minecraftforge.common.MinecraftForge;
/*     */ import net.minecraftforge.eventbus.api.Event;
/*     */ import top.theillusivec4.curios.api.CuriosApi;
/*     */ import top.theillusivec4.curios.api.SlotContext;
/*     */ import top.theillusivec4.curios.api.event.SlotModifiersUpdatedEvent;
/*     */ import top.theillusivec4.curios.api.type.capability.ICurio;
/*     */ import top.theillusivec4.curios.api.type.capability.ICuriosItemHandler;
/*     */ import top.theillusivec4.curios.api.type.inventory.ICurioStacksHandler;
/*     */ import top.theillusivec4.curios.api.type.inventory.IDynamicStackHandler;
/*     */ import top.theillusivec4.curios.common.CuriosHelper;
/*     */ import top.theillusivec4.curios.common.inventory.container.CuriosContainer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CurioStacksHandler
/*     */   implements ICurioStacksHandler
/*     */ {
/*  54 */   private static final UUID LEGACY_UUID = UUID.fromString("0b0eabbd-4220-4e9f-bafb-34100da2bd7e");
/*     */   
/*     */   private final ICuriosItemHandler itemHandler;
/*     */   private final String identifier;
/*  58 */   private final Map<UUID, AttributeModifier> modifiers = new HashMap<>();
/*  59 */   private final Set<AttributeModifier> persistentModifiers = new HashSet<>();
/*  60 */   private final Set<AttributeModifier> cachedModifiers = new HashSet<>();
/*     */   
/*  62 */   private final Multimap<AttributeModifier.Operation, AttributeModifier> modifiersByOperation = (Multimap<AttributeModifier.Operation, AttributeModifier>)HashMultimap.create();
/*     */   
/*     */   private int baseSize;
/*     */   private IDynamicStackHandler stackHandler;
/*     */   private IDynamicStackHandler cosmeticStackHandler;
/*     */   private boolean visible;
/*     */   private boolean cosmetic;
/*     */   private boolean update;
/*     */   private NonNullList<Boolean> renderHandler;
/*     */   
/*     */   public CurioStacksHandler(ICuriosItemHandler itemHandler, String identifier) {
/*  73 */     this(itemHandler, identifier, 1, true, false);
/*     */   }
/*     */ 
/*     */   
/*     */   public CurioStacksHandler(ICuriosItemHandler itemHandler, String identifier, int size, boolean visible, boolean cosmetic) {
/*  78 */     this.baseSize = size;
/*  79 */     this.visible = visible;
/*  80 */     this.cosmetic = cosmetic;
/*  81 */     this.itemHandler = itemHandler;
/*  82 */     this.identifier = identifier;
/*  83 */     this.stackHandler = new DynamicStackHandler(size);
/*  84 */     this.cosmeticStackHandler = new DynamicStackHandler(size);
/*  85 */     this.renderHandler = NonNullList.m_122780_(size, Boolean.valueOf(true));
/*     */   }
/*     */ 
/*     */   
/*     */   public IDynamicStackHandler getStacks() {
/*  90 */     update();
/*  91 */     return this.stackHandler;
/*     */   }
/*     */ 
/*     */   
/*     */   public IDynamicStackHandler getCosmeticStacks() {
/*  96 */     update();
/*  97 */     return this.cosmeticStackHandler;
/*     */   }
/*     */ 
/*     */   
/*     */   public NonNullList<Boolean> getRenders() {
/* 102 */     update();
/* 103 */     return this.renderHandler;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getSlots() {
/* 108 */     update();
/* 109 */     return this.stackHandler.getSlots();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getSizeShift() {
/* 114 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isVisible() {
/* 119 */     return this.visible;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasCosmetic() {
/* 124 */     return this.cosmetic;
/*     */   }
/*     */ 
/*     */   
/*     */   public void grow(int amount) {
/* 129 */     amount = Math.max(0, amount);
/*     */     
/* 131 */     if (amount > 0) {
/* 132 */       addLegacyChange(amount);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void shrink(int amount) {
/* 138 */     amount = Math.max(0, amount);
/*     */     
/* 140 */     if (amount > 0) {
/* 141 */       addLegacyChange(Math.min(getSlots(), amount) * -1);
/*     */     }
/*     */   }
/*     */   
/*     */   private void addLegacyChange(int shift) {
/* 146 */     AttributeModifier mod = getModifiers().get(LEGACY_UUID);
/* 147 */     int current = (mod != null) ? (int)mod.m_22218_() : 0;
/* 148 */     current += shift;
/* 149 */     AttributeModifier newModifier = new AttributeModifier(LEGACY_UUID, "legacy", current, AttributeModifier.Operation.ADDITION);
/*     */     
/* 151 */     this.modifiers.put(newModifier.m_22209_(), newModifier);
/*     */     
/* 153 */     Collection<AttributeModifier> modifiers = getModifiersByOperation(newModifier.m_22217_());
/* 154 */     modifiers.remove(newModifier);
/* 155 */     modifiers.add(newModifier);
/* 156 */     this.persistentModifiers.remove(newModifier);
/* 157 */     this.persistentModifiers.add(newModifier);
/* 158 */     flagUpdate();
/*     */   }
/*     */ 
/*     */   
/*     */   public CompoundTag serializeNBT() {
/* 163 */     CompoundTag compoundNBT = new CompoundTag();
/* 164 */     compoundNBT.m_128405_("SavedBaseSize", this.baseSize);
/* 165 */     compoundNBT.m_128365_("Stacks", (Tag)this.stackHandler.serializeNBT());
/* 166 */     compoundNBT.m_128365_("Cosmetics", (Tag)this.cosmeticStackHandler.serializeNBT());
/*     */     
/* 168 */     ListTag nbtTagList = new ListTag();
/*     */     
/* 170 */     for (int i = 0; i < this.renderHandler.size(); i++) {
/* 171 */       CompoundTag tag = new CompoundTag();
/* 172 */       tag.m_128405_("Slot", i);
/* 173 */       tag.m_128379_("Render", ((Boolean)this.renderHandler.get(i)).booleanValue());
/* 174 */       nbtTagList.add(tag);
/*     */     } 
/* 176 */     CompoundTag nbt = new CompoundTag();
/* 177 */     nbt.m_128365_("Renders", (Tag)nbtTagList);
/* 178 */     nbt.m_128405_("Size", this.renderHandler.size());
/* 179 */     compoundNBT.m_128365_("Renders", (Tag)nbt);
/* 180 */     compoundNBT.m_128379_("HasCosmetic", this.cosmetic);
/* 181 */     compoundNBT.m_128379_("Visible", this.visible);
/*     */     
/* 183 */     if (!this.persistentModifiers.isEmpty()) {
/* 184 */       ListTag list = new ListTag();
/*     */       
/* 186 */       for (AttributeModifier attributeModifier : this.persistentModifiers) {
/* 187 */         list.add(attributeModifier.m_22219_());
/*     */       }
/* 189 */       compoundNBT.m_128365_("PersistentModifiers", (Tag)list);
/*     */     } 
/*     */     
/* 192 */     if (!this.modifiers.isEmpty()) {
/* 193 */       ListTag list = new ListTag();
/* 194 */       this.modifiers.forEach((uuid, modifier) -> {
/*     */             if (!this.persistentModifiers.contains(modifier)) {
/*     */               list.add(modifier.m_22219_());
/*     */             }
/*     */           });
/* 199 */       compoundNBT.m_128365_("CachedModifiers", (Tag)list);
/*     */     } 
/* 201 */     return compoundNBT;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void deserializeNBT(CompoundTag nbt) {
/* 207 */     if (nbt.m_128441_("SavedBaseSize")) {
/* 208 */       this.baseSize = nbt.m_128451_("SavedBaseSize");
/*     */     }
/*     */     
/* 211 */     if (nbt.m_128441_("Stacks")) {
/* 212 */       this.stackHandler.deserializeNBT(nbt.m_128469_("Stacks"));
/*     */     }
/*     */     
/* 215 */     if (nbt.m_128441_("Cosmetics")) {
/* 216 */       this.cosmeticStackHandler.deserializeNBT(nbt.m_128469_("Cosmetics"));
/*     */     }
/*     */     
/* 219 */     if (nbt.m_128441_("Renders")) {
/* 220 */       CompoundTag tag = nbt.m_128469_("Renders");
/* 221 */       this.renderHandler = NonNullList.m_122780_(
/* 222 */           nbt.m_128425_("Size", 3) ? nbt.m_128451_("Size") : this.stackHandler.getSlots(), 
/* 223 */           Boolean.valueOf(true));
/* 224 */       ListTag tagList = tag.m_128437_("Renders", 10);
/*     */       
/* 226 */       for (int i = 0; i < tagList.size(); i++) {
/* 227 */         CompoundTag tags = tagList.m_128728_(i);
/* 228 */         int slot = tags.m_128451_("Slot");
/*     */         
/* 230 */         if (slot >= 0 && slot < this.renderHandler.size()) {
/* 231 */           this.renderHandler.set(slot, Boolean.valueOf(tags.m_128471_("Render")));
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 236 */     if (nbt.m_128441_("SizeShift")) {
/* 237 */       int sizeShift = nbt.m_128451_("SizeShift");
/*     */       
/* 239 */       if (sizeShift != 0) {
/* 240 */         addLegacyChange(sizeShift);
/*     */       }
/*     */     } 
/* 243 */     this.cosmetic = nbt.m_128441_("HasCosmetic") ? nbt.m_128471_("HasCosmetic") : this.cosmetic;
/* 244 */     this.visible = nbt.m_128441_("Visible") ? nbt.m_128471_("Visible") : this.visible;
/*     */     
/* 246 */     if (nbt.m_128425_("PersistentModifiers", 9)) {
/* 247 */       ListTag list = nbt.m_128437_("PersistentModifiers", 10);
/*     */       
/* 249 */       for (int i = 0; i < list.size(); i++) {
/* 250 */         AttributeModifier attributeModifier = AttributeModifier.m_22212_(list.m_128728_(i));
/*     */         
/* 252 */         if (attributeModifier != null) {
/* 253 */           addPermanentModifier(attributeModifier);
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 258 */     if (nbt.m_128425_("CachedModifiers", 9)) {
/* 259 */       ListTag list = nbt.m_128437_("CachedModifiers", 10);
/*     */       
/* 261 */       for (int i = 0; i < list.size(); i++) {
/* 262 */         AttributeModifier attributeModifier = AttributeModifier.m_22212_(list.m_128728_(i));
/*     */         
/* 264 */         if (attributeModifier != null) {
/* 265 */           this.cachedModifiers.add(attributeModifier);
/* 266 */           addTransientModifier(attributeModifier);
/*     */         } 
/*     */       } 
/*     */     } 
/* 270 */     update();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getIdentifier() {
/* 275 */     return this.identifier;
/*     */   }
/*     */   
/*     */   public CompoundTag getSyncTag() {
/* 279 */     CompoundTag compoundNBT = new CompoundTag();
/* 280 */     compoundNBT.m_128365_("Stacks", (Tag)this.stackHandler.serializeNBT());
/* 281 */     compoundNBT.m_128365_("Cosmetics", (Tag)this.cosmeticStackHandler.serializeNBT());
/*     */     
/* 283 */     ListTag nbtTagList = new ListTag();
/*     */     
/* 285 */     for (int i = 0; i < this.renderHandler.size(); i++) {
/* 286 */       CompoundTag tag = new CompoundTag();
/* 287 */       tag.m_128405_("Slot", i);
/* 288 */       tag.m_128379_("Render", ((Boolean)this.renderHandler.get(i)).booleanValue());
/* 289 */       nbtTagList.add(tag);
/*     */     } 
/* 291 */     CompoundTag nbt = new CompoundTag();
/* 292 */     nbt.m_128365_("Renders", (Tag)nbtTagList);
/* 293 */     nbt.m_128405_("Size", this.renderHandler.size());
/* 294 */     compoundNBT.m_128365_("Renders", (Tag)nbt);
/* 295 */     compoundNBT.m_128379_("HasCosmetic", this.cosmetic);
/* 296 */     compoundNBT.m_128379_("Visible", this.visible);
/* 297 */     compoundNBT.m_128405_("BaseSize", this.baseSize);
/*     */     
/* 299 */     if (!this.modifiers.isEmpty()) {
/* 300 */       ListTag list = new ListTag();
/*     */       
/* 302 */       for (Map.Entry<UUID, AttributeModifier> modifier : this.modifiers.entrySet()) {
/* 303 */         list.add(((AttributeModifier)modifier.getValue()).m_22219_());
/*     */       }
/* 305 */       compoundNBT.m_128365_("Modifiers", (Tag)list);
/*     */     } 
/* 307 */     return compoundNBT;
/*     */   }
/*     */ 
/*     */   
/*     */   public void applySyncTag(CompoundTag tag) {
/* 312 */     if (tag.m_128441_("BaseSize")) {
/* 313 */       this.baseSize = tag.m_128451_("BaseSize");
/*     */     }
/*     */     
/* 316 */     if (tag.m_128441_("Stacks")) {
/* 317 */       this.stackHandler.deserializeNBT(tag.m_128469_("Stacks"));
/*     */     }
/*     */     
/* 320 */     if (tag.m_128441_("Cosmetics")) {
/* 321 */       this.cosmeticStackHandler.deserializeNBT(tag.m_128469_("Cosmetics"));
/*     */     }
/*     */     
/* 324 */     if (tag.m_128441_("Renders")) {
/* 325 */       CompoundTag compoundNBT = tag.m_128469_("Renders");
/* 326 */       this.renderHandler = NonNullList.m_122780_(
/* 327 */           compoundNBT.m_128425_("Size", 3) ? compoundNBT.m_128451_("Size") : 
/* 328 */           this.stackHandler.getSlots(), Boolean.valueOf(true));
/* 329 */       ListTag tagList = compoundNBT.m_128437_("Renders", 10);
/*     */       
/* 331 */       for (int i = 0; i < tagList.size(); i++) {
/* 332 */         CompoundTag tags = tagList.m_128728_(i);
/* 333 */         int slot = tags.m_128451_("Slot");
/*     */         
/* 335 */         if (slot >= 0 && slot < this.renderHandler.size()) {
/* 336 */           this.renderHandler.set(slot, Boolean.valueOf(tags.m_128471_("Render")));
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 341 */     if (tag.m_128441_("SizeShift")) {
/* 342 */       int sizeShift = tag.m_128451_("SizeShift");
/*     */       
/* 344 */       if (sizeShift != 0) {
/* 345 */         addLegacyChange(sizeShift);
/*     */       }
/*     */     } 
/* 348 */     this.cosmetic = tag.m_128441_("HasCosmetic") ? tag.m_128471_("HasCosmetic") : this.cosmetic;
/* 349 */     this.visible = tag.m_128441_("Visible") ? tag.m_128471_("Visible") : this.visible;
/* 350 */     this.modifiers.clear();
/* 351 */     this.persistentModifiers.clear();
/* 352 */     this.modifiersByOperation.clear();
/*     */     
/* 354 */     if (tag.m_128425_("Modifiers", 9)) {
/* 355 */       ListTag list = tag.m_128437_("Modifiers", 10);
/*     */       
/* 357 */       for (int i = 0; i < list.size(); i++) {
/* 358 */         AttributeModifier attributeModifier = AttributeModifier.m_22212_(list.m_128728_(i));
/*     */         
/* 360 */         if (attributeModifier != null) {
/* 361 */           addTransientModifier(attributeModifier);
/*     */         }
/*     */       } 
/*     */     } 
/* 365 */     flagUpdate();
/* 366 */     update();
/*     */   }
/*     */ 
/*     */   
/*     */   public void copyModifiers(ICurioStacksHandler other) {
/* 371 */     this.modifiers.clear();
/* 372 */     this.cachedModifiers.clear();
/* 373 */     this.modifiersByOperation.clear();
/* 374 */     this.persistentModifiers.clear();
/* 375 */     other.getModifiers().forEach((uuid, modifier) -> addTransientModifier(modifier));
/* 376 */     this.cachedModifiers.addAll(other.getCachedModifiers());
/*     */     
/* 378 */     for (AttributeModifier persistentModifier : other.getPermanentModifiers()) {
/* 379 */       addPermanentModifier(persistentModifier);
/*     */     }
/* 381 */     update();
/*     */   }
/*     */   
/*     */   public Map<UUID, AttributeModifier> getModifiers() {
/* 385 */     return this.modifiers;
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<AttributeModifier> getPermanentModifiers() {
/* 390 */     return this.persistentModifiers;
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<AttributeModifier> getCachedModifiers() {
/* 395 */     return this.cachedModifiers;
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection<AttributeModifier> getModifiersByOperation(AttributeModifier.Operation operation) {
/* 400 */     return this.modifiersByOperation.get(operation);
/*     */   }
/*     */   
/*     */   public void addTransientModifier(AttributeModifier modifier) {
/* 404 */     this.modifiers.put(modifier.m_22209_(), modifier);
/* 405 */     getModifiersByOperation(modifier.m_22217_()).add(modifier);
/* 406 */     flagUpdate();
/*     */   }
/*     */   
/*     */   public void addPermanentModifier(AttributeModifier modifier) {
/* 410 */     addTransientModifier(modifier);
/* 411 */     this.persistentModifiers.add(modifier);
/*     */   }
/*     */   
/*     */   public void removeModifier(UUID uuid) {
/* 415 */     AttributeModifier modifier = this.modifiers.remove(uuid);
/*     */     
/* 417 */     if (modifier != null) {
/* 418 */       this.persistentModifiers.remove(modifier);
/* 419 */       getModifiersByOperation(modifier.m_22217_()).remove(modifier);
/* 420 */       flagUpdate();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void flagUpdate() {
/* 425 */     this.update = true;
/*     */     
/* 427 */     if (this.itemHandler != null) {
/* 428 */       this.itemHandler.getUpdatingInventories().remove(this);
/* 429 */       this.itemHandler.getUpdatingInventories().add(this);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void clearModifiers() {
/* 434 */     Set<UUID> ids = new HashSet<>(this.modifiers.keySet());
/*     */     
/* 436 */     for (UUID id : ids) {
/* 437 */       removeModifier(id);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void clearCachedModifiers() {
/* 443 */     for (AttributeModifier cachedModifier : this.cachedModifiers) {
/* 444 */       removeModifier(cachedModifier.m_22209_());
/*     */     }
/* 446 */     this.cachedModifiers.clear();
/* 447 */     flagUpdate();
/*     */   }
/*     */ 
/*     */   
/*     */   public void update() {
/* 452 */     if (this.update) {
/* 453 */       this.update = false;
/* 454 */       double baseSize = this.baseSize;
/*     */       
/* 456 */       for (AttributeModifier mod : getModifiersByOperation(AttributeModifier.Operation.ADDITION))
/*     */       {
/* 458 */         baseSize += mod.m_22218_();
/*     */       }
/* 460 */       double size = baseSize;
/*     */       
/* 462 */       for (AttributeModifier mod : getModifiersByOperation(AttributeModifier.Operation.MULTIPLY_BASE))
/*     */       {
/* 464 */         size += this.baseSize * mod.m_22218_();
/*     */       }
/*     */       
/* 467 */       for (AttributeModifier mod : getModifiersByOperation(AttributeModifier.Operation.MULTIPLY_TOTAL))
/*     */       {
/* 469 */         size *= mod.m_22218_();
/*     */       }
/*     */       
/* 472 */       if (size != getSlots()) {
/* 473 */         resize((int)size);
/*     */         
/* 475 */         if (this.itemHandler != null && this.itemHandler.getWearer() != null) {
/* 476 */           MinecraftForge.EVENT_BUS.post((Event)new SlotModifiersUpdatedEvent(this.itemHandler
/* 477 */                 .getWearer(), Set.of(this.identifier)));
/*     */           
/* 479 */           LivingEntity livingEntity = this.itemHandler.getWearer(); if (livingEntity instanceof Player) { Player player = (Player)livingEntity; if (player.f_36096_ instanceof CuriosContainer)
/*     */             {
/* 481 */               ((CuriosContainer)player.f_36096_).resetSlots(); }  }
/*     */         
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void resize(int newSize) {
/* 489 */     int currentSize = getSlots();
/*     */     
/* 491 */     if (currentSize != newSize) {
/* 492 */       int change = newSize - currentSize;
/*     */       
/* 494 */       if (currentSize > newSize) {
/* 495 */         change *= -1;
/* 496 */         loseStacks(this.stackHandler, this.identifier, change);
/* 497 */         this.stackHandler.shrink(change);
/* 498 */         this.cosmeticStackHandler.shrink(change);
/* 499 */         NonNullList<Boolean> newList = NonNullList.m_122780_(newSize, Boolean.valueOf(true));
/*     */         
/* 501 */         for (int i = 0; i < newList.size() && i < this.renderHandler.size(); i++) {
/* 502 */           newList.set(i, this.renderHandler.get(i));
/*     */         }
/* 504 */         this.renderHandler = newList;
/*     */       } else {
/* 506 */         this.stackHandler.grow(change);
/* 507 */         this.cosmeticStackHandler.grow(change);
/* 508 */         NonNullList<Boolean> newList = NonNullList.m_122780_(newSize, Boolean.valueOf(true));
/*     */         
/* 510 */         for (int i = 0; i < newList.size() && i < this.renderHandler.size(); i++) {
/* 511 */           newList.set(i, this.renderHandler.get(i));
/*     */         }
/* 513 */         this.renderHandler = newList;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void loseStacks(IDynamicStackHandler stackHandler, String identifier, int amount) {
/* 520 */     if (this.itemHandler == null) {
/*     */       return;
/*     */     }
/* 523 */     List<ItemStack> drops = new ArrayList<>();
/*     */     
/* 525 */     int i = Math.max(0, stackHandler.getSlots() - amount);
/* 526 */     for (; i >= 0 && i < stackHandler.getSlots(); i++) {
/* 527 */       ItemStack stack = stackHandler.getStackInSlot(i);
/* 528 */       drops.add(stackHandler.getStackInSlot(i));
/* 529 */       LivingEntity entity = this.itemHandler.getWearer();
/* 530 */       SlotContext slotContext = new SlotContext(identifier, entity, i, false, this.visible);
/*     */       
/* 532 */       if (!stack.m_41619_()) {
/* 533 */         UUID uuid = UUID.nameUUIDFromBytes((identifier + identifier).getBytes());
/*     */         
/* 535 */         Multimap<Attribute, AttributeModifier> map = CuriosApi.getCuriosHelper().getAttributeModifiers(slotContext, uuid, stack);
/* 536 */         HashMultimap hashMultimap = HashMultimap.create();
/* 537 */         Set<CuriosHelper.SlotAttributeWrapper> toRemove = new HashSet<>();
/*     */         
/* 539 */         for (Attribute attribute : map.keySet()) {
/*     */           
/* 541 */           if (attribute instanceof CuriosHelper.SlotAttributeWrapper) { CuriosHelper.SlotAttributeWrapper wrapper = (CuriosHelper.SlotAttributeWrapper)attribute;
/* 542 */             hashMultimap.putAll(wrapper.identifier, map.get(attribute));
/* 543 */             toRemove.add(wrapper); }
/*     */         
/*     */         } 
/*     */         
/* 547 */         for (Attribute attribute : toRemove) {
/* 548 */           map.removeAll(attribute);
/*     */         }
/* 550 */         this.itemHandler.getWearer().m_21204_().m_22161_(map);
/* 551 */         this.itemHandler.removeSlotModifiers((Multimap)hashMultimap);
/* 552 */         CuriosApi.getCuriosHelper().getCurio(stack)
/* 553 */           .ifPresent(curio -> curio.onUnequip(slotContext, ItemStack.f_41583_));
/*     */       } 
/* 555 */       stackHandler.setStackInSlot(i, ItemStack.f_41583_);
/*     */     } 
/* 557 */     Objects.requireNonNull(this.itemHandler); drops.forEach(this.itemHandler::loseInvalidStack);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 562 */     if (this == o) {
/* 563 */       return true;
/*     */     }
/* 565 */     if (o == null || getClass() != o.getClass()) {
/* 566 */       return false;
/*     */     }
/* 568 */     CurioStacksHandler that = (CurioStacksHandler)o;
/* 569 */     return this.identifier.equals(that.identifier);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 574 */     return Objects.hash(new Object[] { this.identifier });
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\curios-309927-4590652.jar!\top\theillusivec4\curios\common\inventory\CurioStacksHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */