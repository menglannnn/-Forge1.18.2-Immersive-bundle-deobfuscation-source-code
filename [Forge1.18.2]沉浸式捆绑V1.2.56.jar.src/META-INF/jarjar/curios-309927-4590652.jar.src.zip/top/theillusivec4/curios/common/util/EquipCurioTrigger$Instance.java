/*    */ package top.theillusivec4.curios.common.util;
/*    */ 
/*    */ import javax.annotation.Nonnull;
/*    */ import net.minecraft.advancements.critereon.AbstractCriterionTriggerInstance;
/*    */ import net.minecraft.advancements.critereon.EntityPredicate;
/*    */ import net.minecraft.advancements.critereon.ItemPredicate;
/*    */ import net.minecraft.advancements.critereon.LocationPredicate;
/*    */ import net.minecraft.resources.ResourceLocation;
/*    */ import net.minecraft.server.level.ServerLevel;
/*    */ import net.minecraft.world.item.ItemStack;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class Instance
/*    */   extends AbstractCriterionTriggerInstance
/*    */ {
/*    */   private final ItemPredicate item;
/*    */   private final LocationPredicate location;
/*    */   
/*    */   Instance(EntityPredicate.Composite playerPred, ItemPredicate count, LocationPredicate indexPos) {
/* 61 */     super(EquipCurioTrigger.ID, playerPred);
/* 62 */     this.item = count;
/* 63 */     this.location = indexPos;
/*    */   }
/*    */ 
/*    */   
/*    */   @Nonnull
/*    */   public ResourceLocation m_7294_() {
/* 69 */     return EquipCurioTrigger.ID;
/*    */   }
/*    */   
/*    */   boolean test(ItemStack stack, ServerLevel world, double x, double y, double z) {
/* 73 */     return (this.item.m_45049_(stack) && this.location.m_52617_(world, x, y, z));
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\curios-309927-4590652.jar!\top\theillusivec4\curios\commo\\util\EquipCurioTrigger$Instance.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */