/*    */ package top.theillusivec4.curios.common;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import net.minecraftforge.common.ForgeConfigSpec;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Server
/*    */ {
/*    */   public CuriosConfig.CuriosSettings curiosSettings;
/*    */   
/*    */   public Server(ForgeConfigSpec.Builder builder) {
/* 53 */     builder.comment("List of curio slot type settings")
/* 54 */       .define("curiosSettings", new ArrayList());
/* 55 */     builder.build();
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\curios-309927-4590652.jar!\top\theillusivec4\curios\common\CuriosConfig$Server.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */