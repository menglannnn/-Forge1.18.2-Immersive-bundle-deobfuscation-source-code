/*     */ package top.theillusivec4.curios.common.inventory;
/*     */ 
/*     */ import javax.annotation.Nonnull;
/*     */ import net.minecraft.client.resources.language.I18n;
/*     */ import net.minecraft.core.NonNullList;
/*     */ import net.minecraft.resources.ResourceLocation;
/*     */ import net.minecraft.world.entity.LivingEntity;
/*     */ import net.minecraft.world.entity.player.Player;
/*     */ import net.minecraft.world.inventory.InventoryMenu;
/*     */ import net.minecraft.world.item.ItemStack;
/*     */ import net.minecraft.world.item.enchantment.EnchantmentHelper;
/*     */ import net.minecraftforge.api.distmarker.Dist;
/*     */ import net.minecraftforge.api.distmarker.OnlyIn;
/*     */ import net.minecraftforge.common.MinecraftForge;
/*     */ import net.minecraftforge.eventbus.api.Event;
/*     */ import net.minecraftforge.items.IItemHandler;
/*     */ import net.minecraftforge.items.SlotItemHandler;
/*     */ import top.theillusivec4.curios.api.CuriosApi;
/*     */ import top.theillusivec4.curios.api.SlotContext;
/*     */ import top.theillusivec4.curios.api.event.CurioEquipEvent;
/*     */ import top.theillusivec4.curios.api.event.CurioUnequipEvent;
/*     */ import top.theillusivec4.curios.api.type.capability.ICurio;
/*     */ import top.theillusivec4.curios.api.type.inventory.IDynamicStackHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CurioSlot
/*     */   extends SlotItemHandler
/*     */ {
/*     */   private final String identifier;
/*     */   private final Player player;
/*     */   private final SlotContext slotContext;
/*     */   private NonNullList<Boolean> renderStatuses;
/*     */   
/*     */   public CurioSlot(Player player, IDynamicStackHandler handler, int index, String identifier, int xPosition, int yPosition, NonNullList<Boolean> renders) {
/*  52 */     super((IItemHandler)handler, index, xPosition, yPosition);
/*  53 */     this.identifier = identifier;
/*  54 */     this.renderStatuses = renders;
/*  55 */     this.player = player;
/*  56 */     this
/*  57 */       .slotContext = new SlotContext(identifier, (LivingEntity)player, index, this instanceof CosmeticCurioSlot, (this instanceof CosmeticCurioSlot || ((Boolean)renders.get(index)).booleanValue()));
/*  58 */     setBackground(InventoryMenu.f_39692_, 
/*  59 */         player.m_20193_().m_5776_() ? 
/*  60 */         CuriosApi.getIconHelper().getIcon(identifier) : 
/*  61 */         new ResourceLocation("curios", "item/empty_curio_slot"));
/*     */   }
/*     */   
/*     */   public String getIdentifier() {
/*  65 */     return this.identifier;
/*     */   }
/*     */   
/*     */   public boolean getRenderStatus() {
/*  69 */     return (this.renderStatuses.size() > getSlotIndex() && ((Boolean)this.renderStatuses
/*  70 */       .get(getSlotIndex())).booleanValue());
/*     */   }
/*     */   
/*     */   @OnlyIn(Dist.CLIENT)
/*     */   public String getSlotName() {
/*  75 */     return I18n.m_118938_("curios.identifier." + this.identifier, new Object[0]);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean m_5857_(@Nonnull ItemStack stack) {
/*  80 */     CurioEquipEvent equipEvent = new CurioEquipEvent(stack, this.slotContext);
/*  81 */     MinecraftForge.EVENT_BUS.post((Event)equipEvent);
/*  82 */     Event.Result result = equipEvent.getResult();
/*     */     
/*  84 */     if (result == Event.Result.DENY) {
/*  85 */       return false;
/*     */     }
/*  87 */     return (result == Event.Result.ALLOW || (
/*  88 */       CuriosApi.getCuriosHelper().isStackValid(this.slotContext, stack) && (
/*  89 */       (Boolean)CuriosApi.getCuriosHelper().getCurio(stack).map(curio -> Boolean.valueOf(curio.canEquip(this.slotContext)))
/*  90 */       .orElse(Boolean.valueOf(true))).booleanValue() && super.m_5857_(stack)));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean m_8010_(Player playerIn) {
/*  95 */     ItemStack stack = m_7993_();
/*  96 */     CurioUnequipEvent unequipEvent = new CurioUnequipEvent(stack, this.slotContext);
/*  97 */     MinecraftForge.EVENT_BUS.post((Event)unequipEvent);
/*  98 */     Event.Result result = unequipEvent.getResult();
/*     */     
/* 100 */     if (result == Event.Result.DENY) {
/* 101 */       return false;
/*     */     }
/* 103 */     return (result == Event.Result.ALLOW || ((stack
/* 104 */       .m_41619_() || playerIn.m_7500_() || !EnchantmentHelper.m_44920_(stack)) && (
/* 105 */       (Boolean)CuriosApi.getCuriosHelper().getCurio(stack).map(curio -> Boolean.valueOf(curio.canUnequip(this.slotContext)))
/* 106 */       .orElse(Boolean.valueOf(true))).booleanValue() && super.m_8010_(playerIn)));
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\curios-309927-4590652.jar!\top\theillusivec4\curios\common\inventory\CurioSlot.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */