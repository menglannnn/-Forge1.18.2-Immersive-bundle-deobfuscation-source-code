/*    */ package top.theillusivec4.curios.common.network.server;
/*    */ 
/*    */ import java.util.function.Supplier;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.player.LocalPlayer;
/*    */ import net.minecraft.network.FriendlyByteBuf;
/*    */ import net.minecraft.world.item.ItemStack;
/*    */ import net.minecraftforge.network.NetworkEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SPacketGrabbedItem
/*    */ {
/*    */   private final ItemStack stack;
/*    */   
/*    */   public SPacketGrabbedItem(ItemStack stackIn) {
/* 34 */     this.stack = stackIn;
/*    */   }
/*    */   
/*    */   public static void encode(SPacketGrabbedItem msg, FriendlyByteBuf buf) {
/* 38 */     buf.m_130055_(msg.stack);
/*    */   }
/*    */   
/*    */   public static SPacketGrabbedItem decode(FriendlyByteBuf buf) {
/* 42 */     return new SPacketGrabbedItem(buf.m_130267_());
/*    */   }
/*    */ 
/*    */   
/*    */   public static void handle(SPacketGrabbedItem msg, Supplier<NetworkEvent.Context> ctx) {
/* 47 */     ((NetworkEvent.Context)ctx.get()).enqueueWork(() -> {
/*    */           LocalPlayer clientPlayer = (Minecraft.m_91087_()).f_91074_;
/*    */           
/*    */           if (clientPlayer != null) {
/*    */             clientPlayer.f_36096_.m_142503_(msg.stack);
/*    */           }
/*    */         });
/* 54 */     ((NetworkEvent.Context)ctx.get()).setPacketHandled(true);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\curios-309927-4590652.jar!\top\theillusivec4\curios\common\network\server\SPacketGrabbedItem.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */