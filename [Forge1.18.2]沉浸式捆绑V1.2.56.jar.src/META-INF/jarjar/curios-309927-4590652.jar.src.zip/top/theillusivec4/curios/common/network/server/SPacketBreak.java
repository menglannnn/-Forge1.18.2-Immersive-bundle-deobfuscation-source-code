/*    */ package top.theillusivec4.curios.common.network.server;
/*    */ 
/*    */ import java.util.function.Supplier;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.multiplayer.ClientLevel;
/*    */ import net.minecraft.core.NonNullList;
/*    */ import net.minecraft.network.FriendlyByteBuf;
/*    */ import net.minecraft.world.entity.Entity;
/*    */ import net.minecraft.world.entity.LivingEntity;
/*    */ import net.minecraft.world.item.ItemStack;
/*    */ import net.minecraftforge.common.util.LazyOptional;
/*    */ import net.minecraftforge.network.NetworkEvent;
/*    */ import top.theillusivec4.curios.api.CuriosApi;
/*    */ import top.theillusivec4.curios.api.SlotContext;
/*    */ import top.theillusivec4.curios.api.type.capability.ICurio;
/*    */ import top.theillusivec4.curios.api.type.capability.ICuriosItemHandler;
/*    */ import top.theillusivec4.curios.api.type.inventory.ICurioStacksHandler;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SPacketBreak
/*    */ {
/*    */   private int entityId;
/*    */   private int slotId;
/*    */   private String curioId;
/*    */   
/*    */   public SPacketBreak(int entityId, String curioId, int slotId) {
/* 43 */     this.entityId = entityId;
/* 44 */     this.slotId = slotId;
/* 45 */     this.curioId = curioId;
/*    */   }
/*    */   
/*    */   public static void encode(SPacketBreak msg, FriendlyByteBuf buf) {
/* 49 */     buf.writeInt(msg.entityId);
/* 50 */     buf.m_130070_(msg.curioId);
/* 51 */     buf.writeInt(msg.slotId);
/*    */   }
/*    */   
/*    */   public static SPacketBreak decode(FriendlyByteBuf buf) {
/* 55 */     return new SPacketBreak(buf.readInt(), buf.m_130136_(25), buf.readInt());
/*    */   }
/*    */   
/*    */   public static void handle(SPacketBreak msg, Supplier<NetworkEvent.Context> ctx) {
/* 59 */     ((NetworkEvent.Context)ctx.get()).enqueueWork(() -> {
/*    */           ClientLevel world = (Minecraft.m_91087_()).f_91073_;
/*    */ 
/*    */ 
/*    */ 
/*    */           
/*    */           if (world != null) {
/*    */             Entity entity = (Minecraft.m_91087_()).f_91073_.m_6815_(msg.entityId);
/*    */ 
/*    */ 
/*    */             
/*    */             if (entity instanceof LivingEntity) {
/*    */               LivingEntity livingEntity = (LivingEntity)entity;
/*    */ 
/*    */ 
/*    */               
/*    */               CuriosApi.getCuriosHelper().getCuriosHandler(livingEntity).ifPresent(());
/*    */             } 
/*    */           } 
/*    */         });
/*    */ 
/*    */ 
/*    */     
/* 82 */     ((NetworkEvent.Context)ctx.get()).setPacketHandled(true);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\curios-309927-4590652.jar!\top\theillusivec4\curios\common\network\server\SPacketBreak.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */