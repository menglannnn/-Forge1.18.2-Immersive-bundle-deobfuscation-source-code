/*     */ package top.theillusivec4.curios.common.network.server.sync;
/*     */ 
/*     */ import java.util.function.Supplier;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.multiplayer.ClientLevel;
/*     */ import net.minecraft.core.NonNullList;
/*     */ import net.minecraft.nbt.CompoundTag;
/*     */ import net.minecraft.network.FriendlyByteBuf;
/*     */ import net.minecraft.world.entity.Entity;
/*     */ import net.minecraft.world.entity.LivingEntity;
/*     */ import net.minecraft.world.item.ItemStack;
/*     */ import net.minecraftforge.network.NetworkEvent;
/*     */ import top.theillusivec4.curios.api.CuriosApi;
/*     */ import top.theillusivec4.curios.api.SlotContext;
/*     */ import top.theillusivec4.curios.api.type.capability.ICurio;
/*     */ import top.theillusivec4.curios.api.type.capability.ICuriosItemHandler;
/*     */ import top.theillusivec4.curios.api.type.inventory.ICurioStacksHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SPacketSyncStack
/*     */ {
/*     */   private int entityId;
/*     */   private int slotId;
/*     */   private String curioId;
/*     */   private ItemStack stack;
/*     */   private int handlerType;
/*     */   private CompoundTag compound;
/*     */   
/*     */   public SPacketSyncStack(int entityId, String curioId, int slotId, ItemStack stack, HandlerType handlerType, CompoundTag data) {
/*  46 */     this.entityId = entityId;
/*  47 */     this.slotId = slotId;
/*  48 */     this.stack = stack.m_41777_();
/*  49 */     this.curioId = curioId;
/*  50 */     this.handlerType = handlerType.ordinal();
/*  51 */     this.compound = data;
/*     */   }
/*     */   
/*     */   public static void encode(SPacketSyncStack msg, FriendlyByteBuf buf) {
/*  55 */     buf.writeInt(msg.entityId);
/*  56 */     buf.m_130070_(msg.curioId);
/*  57 */     buf.writeInt(msg.slotId);
/*  58 */     buf.m_130055_(msg.stack);
/*  59 */     buf.writeInt(msg.handlerType);
/*  60 */     buf.m_130079_(msg.compound);
/*     */   }
/*     */   
/*     */   public static SPacketSyncStack decode(FriendlyByteBuf buf) {
/*  64 */     return new SPacketSyncStack(buf.readInt(), buf.m_130136_(25), buf.readInt(), buf
/*  65 */         .m_130267_(), HandlerType.fromValue(buf.readInt()), buf.m_130260_());
/*     */   }
/*     */   
/*     */   public static void handle(SPacketSyncStack msg, Supplier<NetworkEvent.Context> ctx) {
/*  69 */     ((NetworkEvent.Context)ctx.get()).enqueueWork(() -> {
/*     */           ClientLevel world = (Minecraft.m_91087_()).f_91073_;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           if (world != null) {
/*     */             Entity entity = world.m_6815_(msg.entityId);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/*     */             if (entity instanceof LivingEntity) {
/*     */               CuriosApi.getCuriosHelper().getCuriosHandler((LivingEntity)entity).ifPresent(());
/*     */             }
/*     */           } 
/*     */         });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  99 */     ((NetworkEvent.Context)ctx.get()).setPacketHandled(true);
/*     */   }
/*     */   
/*     */   public enum HandlerType {
/* 103 */     EQUIPMENT, COSMETIC;
/*     */     
/*     */     public static HandlerType fromValue(int value) {
/*     */       try {
/* 107 */         return values()[value];
/* 108 */       } catch (ArrayIndexOutOfBoundsException e) {
/* 109 */         throw new IllegalArgumentException("Unknown handler value: " + value);
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\curios-309927-4590652.jar!\top\theillusivec4\curios\common\network\server\sync\SPacketSyncStack.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */