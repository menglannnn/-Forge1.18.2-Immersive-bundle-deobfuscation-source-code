/*     */ package top.theillusivec4.curios.common.slottype;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import net.minecraft.resources.ResourceLocation;
/*     */ import top.theillusivec4.curios.api.type.ISlotType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SlotType
/*     */   implements ISlotType
/*     */ {
/*     */   private final String identifier;
/*     */   private final int priority;
/*     */   private final int size;
/*     */   private final boolean visible;
/*     */   private final boolean cosmetic;
/*     */   private final ResourceLocation icon;
/*     */   
/*     */   private SlotType(Builder builder) {
/*  37 */     this.identifier = builder.identifier;
/*  38 */     this.priority = (builder.priority != null) ? builder.priority.intValue() : 100;
/*  39 */     this.size = (builder.size != null) ? builder.size.intValue() : 1;
/*  40 */     this.visible = builder.visible;
/*  41 */     this.cosmetic = builder.cosmetic;
/*  42 */     this
/*  43 */       .icon = (builder.icon != null) ? builder.icon : new ResourceLocation("curios", "item/empty_curio_slot");
/*     */   }
/*     */ 
/*     */   
/*     */   public String getIdentifier() {
/*  48 */     return this.identifier;
/*     */   }
/*     */ 
/*     */   
/*     */   public ResourceLocation getIcon() {
/*  53 */     return this.icon;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getPriority() {
/*  58 */     return this.priority;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getSize() {
/*  63 */     return this.size;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isVisible() {
/*  68 */     return this.visible;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasCosmetic() {
/*  73 */     return this.cosmetic;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/*  78 */     if (this == o) {
/*  79 */       return true;
/*     */     }
/*  81 */     if (o == null || getClass() != o.getClass()) {
/*  82 */       return false;
/*     */     }
/*  84 */     SlotType that = (SlotType)o;
/*  85 */     return this.identifier.equals(that.identifier);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  90 */     return Objects.hash(new Object[] { this.identifier });
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int compareTo(ISlotType otherType) {
/*  96 */     if (this.priority == otherType.getPriority())
/*  97 */       return this.identifier.compareTo(otherType.getIdentifier()); 
/*  98 */     if (this.priority > otherType.getPriority()) {
/*  99 */       return 1;
/*     */     }
/* 101 */     return -1;
/*     */   }
/*     */ 
/*     */   
/*     */   public static class Builder
/*     */   {
/*     */     private final String identifier;
/*     */     private Integer priority;
/*     */     private Integer size;
/*     */     private boolean visible = true;
/*     */     private boolean cosmetic = false;
/* 112 */     private ResourceLocation icon = null;
/*     */     
/*     */     public Builder(String identifier) {
/* 115 */       this.identifier = identifier;
/*     */     }
/*     */     
/*     */     public Builder copyFrom(Builder builder) {
/* 119 */       this.priority = builder.priority;
/* 120 */       this.size = builder.size;
/* 121 */       this.visible = builder.visible;
/* 122 */       this.cosmetic = builder.cosmetic;
/* 123 */       this.icon = builder.icon;
/* 124 */       return this;
/*     */     }
/*     */     
/*     */     public Builder icon(ResourceLocation icon) {
/* 128 */       this.icon = icon;
/* 129 */       return this;
/*     */     }
/*     */     
/*     */     public Builder priority(Integer priority) {
/* 133 */       return priority(priority, false);
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder priority(Integer priority, boolean force) {
/* 138 */       if (priority != null)
/*     */       {
/* 140 */         if (this.priority != null) {
/* 141 */           this.priority = Integer.valueOf(force ? priority.intValue() : Math.min(this.priority.intValue(), priority.intValue()));
/*     */         } else {
/* 143 */           this.priority = priority;
/*     */         } 
/*     */       }
/* 146 */       return this;
/*     */     }
/*     */     
/*     */     public Builder size(int size) {
/* 150 */       return size(size, false);
/*     */     }
/*     */     
/*     */     public Builder size(int size, boolean force) {
/* 154 */       this.size = Integer.valueOf((force || this.size == null) ? size : Math.max(this.size.intValue(), size));
/* 155 */       return this;
/*     */     }
/*     */     
/*     */     public Builder visible(boolean visible) {
/* 159 */       return visible(visible, false);
/*     */     }
/*     */     
/*     */     public Builder visible(boolean visible, boolean force) {
/* 163 */       this.visible = force ? visible : ((this.visible && visible));
/* 164 */       return this;
/*     */     }
/*     */     
/*     */     public Builder hasCosmetic(boolean cosmetic) {
/* 168 */       return hasCosmetic(cosmetic, false);
/*     */     }
/*     */     
/*     */     public Builder hasCosmetic(boolean cosmetic, boolean force) {
/* 172 */       this.cosmetic = force ? cosmetic : ((this.cosmetic || cosmetic));
/* 173 */       return this;
/*     */     }
/*     */     
/*     */     public SlotType build() {
/* 177 */       return new SlotType(this);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\curios-309927-4590652.jar!\top\theillusivec4\curios\common\slottype\SlotType.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */