/*    */ package top.theillusivec4.curios.common;
/*    */ 
/*    */ import net.minecraft.world.inventory.MenuType;
/*    */ import net.minecraftforge.common.extensions.IForgeMenuType;
/*    */ import net.minecraftforge.event.RegistryEvent;
/*    */ import net.minecraftforge.eventbus.api.SubscribeEvent;
/*    */ import net.minecraftforge.fml.common.Mod;
/*    */ import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
/*    */ import net.minecraftforge.network.IContainerFactory;
/*    */ import net.minecraftforge.registries.ObjectHolder;
/*    */ import top.theillusivec4.curios.common.inventory.container.CuriosContainer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @EventBusSubscriber(modid = "curios", bus = Mod.EventBusSubscriber.Bus.MOD)
/*    */ public class CuriosRegistry
/*    */ {
/*    */   @ObjectHolder("curios:curios_container")
/* 38 */   public static final MenuType<CuriosContainer> CONTAINER_TYPE = null;
/*    */ 
/*    */   
/*    */   @SubscribeEvent
/*    */   public static void registerContainer(RegistryEvent.Register<MenuType<?>> evt) {
/* 43 */     evt.getRegistry().register(
/* 44 */         IForgeMenuType.create(CuriosContainer::new).setRegistryName("curios_container"));
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\curios-309927-4590652.jar!\top\theillusivec4\curios\common\CuriosRegistry.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */