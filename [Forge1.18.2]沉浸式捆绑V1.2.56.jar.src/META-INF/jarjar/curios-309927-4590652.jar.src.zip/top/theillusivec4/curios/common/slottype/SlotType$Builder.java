/*     */ package top.theillusivec4.curios.common.slottype;
/*     */ 
/*     */ import net.minecraft.resources.ResourceLocation;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Builder
/*     */ {
/*     */   private final String identifier;
/*     */   private Integer priority;
/*     */   private Integer size;
/*     */   private boolean visible = true;
/*     */   private boolean cosmetic = false;
/* 112 */   private ResourceLocation icon = null;
/*     */   
/*     */   public Builder(String identifier) {
/* 115 */     this.identifier = identifier;
/*     */   }
/*     */   
/*     */   public Builder copyFrom(Builder builder) {
/* 119 */     this.priority = builder.priority;
/* 120 */     this.size = builder.size;
/* 121 */     this.visible = builder.visible;
/* 122 */     this.cosmetic = builder.cosmetic;
/* 123 */     this.icon = builder.icon;
/* 124 */     return this;
/*     */   }
/*     */   
/*     */   public Builder icon(ResourceLocation icon) {
/* 128 */     this.icon = icon;
/* 129 */     return this;
/*     */   }
/*     */   
/*     */   public Builder priority(Integer priority) {
/* 133 */     return priority(priority, false);
/*     */   }
/*     */ 
/*     */   
/*     */   public Builder priority(Integer priority, boolean force) {
/* 138 */     if (priority != null)
/*     */     {
/* 140 */       if (this.priority != null) {
/* 141 */         this.priority = Integer.valueOf(force ? priority.intValue() : Math.min(this.priority.intValue(), priority.intValue()));
/*     */       } else {
/* 143 */         this.priority = priority;
/*     */       } 
/*     */     }
/* 146 */     return this;
/*     */   }
/*     */   
/*     */   public Builder size(int size) {
/* 150 */     return size(size, false);
/*     */   }
/*     */   
/*     */   public Builder size(int size, boolean force) {
/* 154 */     this.size = Integer.valueOf((force || this.size == null) ? size : Math.max(this.size.intValue(), size));
/* 155 */     return this;
/*     */   }
/*     */   
/*     */   public Builder visible(boolean visible) {
/* 159 */     return visible(visible, false);
/*     */   }
/*     */   
/*     */   public Builder visible(boolean visible, boolean force) {
/* 163 */     this.visible = force ? visible : ((this.visible && visible));
/* 164 */     return this;
/*     */   }
/*     */   
/*     */   public Builder hasCosmetic(boolean cosmetic) {
/* 168 */     return hasCosmetic(cosmetic, false);
/*     */   }
/*     */   
/*     */   public Builder hasCosmetic(boolean cosmetic, boolean force) {
/* 172 */     this.cosmetic = force ? cosmetic : ((this.cosmetic || cosmetic));
/* 173 */     return this;
/*     */   }
/*     */   
/*     */   public SlotType build() {
/* 177 */     return new SlotType(this);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\curios-309927-4590652.jar!\top\theillusivec4\curios\common\slottype\SlotType$Builder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */