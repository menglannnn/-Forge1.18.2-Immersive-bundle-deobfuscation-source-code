/*    */ package top.theillusivec4.curios.common.integration.jei;
/*    */ 
/*    */ import javax.annotation.Nonnull;
/*    */ import mezz.jei.api.IModPlugin;
/*    */ import mezz.jei.api.JeiPlugin;
/*    */ import mezz.jei.api.registration.IGuiHandlerRegistration;
/*    */ import net.minecraft.resources.ResourceLocation;
/*    */ import top.theillusivec4.curios.client.gui.CuriosScreen;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @JeiPlugin
/*    */ public class CuriosJeiPlugin
/*    */   implements IModPlugin
/*    */ {
/*    */   @Nonnull
/*    */   public ResourceLocation getPluginUid() {
/* 36 */     return new ResourceLocation("curios", "curios");
/*    */   }
/*    */ 
/*    */   
/*    */   public void registerGuiHandlers(IGuiHandlerRegistration registration) {
/* 41 */     registration.addGuiContainerHandler(CuriosScreen.class, new CuriosContainerHandler());
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\curios-309927-4590652.jar!\top\theillusivec4\curios\common\integration\jei\CuriosJeiPlugin.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */