/*     */ package top.theillusivec4.curios.common.slottype;
/*     */ 
/*     */ import com.google.common.collect.ImmutableMap;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.TreeMap;
/*     */ import java.util.stream.Collector;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.stream.Stream;
/*     */ import net.minecraft.resources.ResourceLocation;
/*     */ import net.minecraftforge.fml.InterModComms;
/*     */ import top.theillusivec4.curios.Curios;
/*     */ import top.theillusivec4.curios.api.CuriosApi;
/*     */ import top.theillusivec4.curios.api.SlotTypeMessage;
/*     */ import top.theillusivec4.curios.api.SlotTypePreset;
/*     */ import top.theillusivec4.curios.common.CuriosConfig;
/*     */ import top.theillusivec4.curios.server.command.CurioArgumentType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SlotTypeManager
/*     */ {
/*  47 */   private static Map<String, SlotType.Builder> imcBuilders = new HashMap<>();
/*  48 */   private static Map<String, SlotType.Builder> configBuilders = new HashMap<>();
/*  49 */   private static Map<String, Set<String>> idsToMods = new HashMap<>();
/*     */   
/*     */   public static Map<String, Set<String>> getIdsToMods() {
/*  52 */     return (Map<String, Set<String>>)ImmutableMap.copyOf(idsToMods);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void buildImcSlotTypes(Stream<InterModComms.IMCMessage> register, Stream<InterModComms.IMCMessage> modify) {
/*  57 */     imcBuilders.clear();
/*  58 */     processImc(register, true);
/*  59 */     processImc(modify, false);
/*     */   }
/*     */   
/*     */   public static void buildConfigSlotTypes() {
/*  63 */     configBuilders.clear();
/*  64 */     List<CuriosConfig.CuriosSettings.CuriosSetting> settings = CuriosConfig.curios;
/*     */     
/*  66 */     if (settings == null) {
/*     */       return;
/*     */     }
/*     */     
/*  70 */     settings.forEach(setting -> {
/*     */           String id = setting.identifier;
/*     */           
/*     */           if (id == null || id.isEmpty()) {
/*     */             Curios.LOGGER.error("Missing identifier in curios config, skipping...");
/*     */             
/*     */             return;
/*     */           } 
/*     */           
/*     */           SlotType.Builder builder = imcBuilders.get(id);
/*     */           
/*     */           boolean force = (setting.override != null) ? setting.override.booleanValue() : false;
/*     */           
/*     */           if (builder == null) {
/*     */             builder = new SlotType.Builder(id);
/*     */             
/*     */             SlotTypeMessage.Builder preset = SlotTypePreset.findPreset(id).map(SlotTypePreset::getMessageBuilder).orElse(null);
/*     */             
/*     */             if (preset != null) {
/*     */               SlotTypeMessage msg = preset.build();
/*     */               
/*     */               builder.icon(msg.getIcon()).priority(msg.getPriority()).size(msg.getSize()).visible(msg.isVisible()).hasCosmetic(msg.hasCosmetic());
/*     */             } 
/*     */           } else {
/*     */             builder = (new SlotType.Builder(id)).copyFrom(builder);
/*     */           } 
/*     */           
/*     */           configBuilders.putIfAbsent(id, builder);
/*     */           
/*     */           ((Set<String>)idsToMods.computeIfAbsent(id, ())).add("config");
/*     */           if (setting.priority != null) {
/*     */             builder.priority(setting.priority, force);
/*     */           }
/*     */           if (setting.icon != null && !setting.icon.isEmpty()) {
/*     */             builder.icon(new ResourceLocation(setting.icon));
/*     */           }
/*     */           if (setting.size != null) {
/*     */             builder.size(setting.size.intValue(), force);
/*     */           }
/*     */           if (setting.visible != null) {
/*     */             builder.visible(setting.visible.booleanValue(), force);
/*     */           }
/*     */           if (setting.hasCosmetic != null) {
/*     */             builder.hasCosmetic(setting.hasCosmetic.booleanValue(), force);
/*     */           }
/*     */         });
/* 116 */     imcBuilders.forEach((key, builder) -> configBuilders.putIfAbsent(key, builder));
/*     */   }
/*     */   
/*     */   public static void buildSlotTypes() {
/* 120 */     Map<String, SlotType.Builder> builders = !configBuilders.isEmpty() ? configBuilders : imcBuilders;
/* 121 */     builders.values().forEach(builder -> CuriosApi.getSlotHelper().addSlotType(builder.build()));
/* 122 */     CurioArgumentType.slotIds = CuriosApi.getSlotHelper().getSlotTypeIds();
/*     */   }
/*     */   
/*     */   private static void processImc(Stream<InterModComms.IMCMessage> messages, boolean create) {
/* 126 */     TreeMap<String, List<SlotTypeMessage>> messageMap = new TreeMap<>();
/* 127 */     List<InterModComms.IMCMessage> messageList = messages.collect((Collector)Collectors.toList());
/*     */     
/* 129 */     messageList.forEach(msg -> {
/*     */           Object messageObject = msg.getMessageSupplier().get();
/*     */ 
/*     */           
/*     */           if (messageObject instanceof SlotTypeMessage) {
/*     */             ((List<SlotTypeMessage>)messageMap.computeIfAbsent(msg.getSenderModId(), ())).add((SlotTypeMessage)messageObject);
/*     */           } else if (messageObject instanceof Iterable) {
/*     */             Iterable<?> iterable = (Iterable)messageObject;
/*     */ 
/*     */             
/*     */             Iterator<?> iter = iterable.iterator();
/*     */ 
/*     */             
/*     */             if (iter.hasNext()) {
/*     */               Object firstChild = iter.next();
/*     */               
/*     */               if (firstChild instanceof SlotTypeMessage) {
/*     */                 ((List<SlotTypeMessage>)messageMap.computeIfAbsent(msg.getSenderModId(), ())).add((SlotTypeMessage)firstChild);
/*     */                 
/*     */                 iter.forEachRemaining(());
/*     */               } 
/*     */             } 
/*     */           } 
/*     */         });
/*     */     
/* 154 */     for (Map.Entry<String, List<SlotTypeMessage>> entry : messageMap.entrySet()) {
/* 155 */       String modId = entry.getKey();
/*     */       
/* 157 */       for (SlotTypeMessage msg : entry.getValue()) {
/* 158 */         String id = msg.getIdentifier();
/* 159 */         SlotType.Builder builder = imcBuilders.get(id);
/*     */         
/* 161 */         if (builder == null && create) {
/* 162 */           builder = new SlotType.Builder(id);
/* 163 */           imcBuilders.put(id, builder);
/* 164 */           ((Set<String>)idsToMods.computeIfAbsent(id, k -> new HashSet())).add(modId);
/*     */         } 
/*     */         
/* 167 */         if (builder != null) {
/* 168 */           builder.size(msg.getSize()).visible(msg.isVisible()).hasCosmetic(msg.hasCosmetic());
/*     */           
/* 170 */           SlotTypeMessage.Builder preset = SlotTypePreset.findPreset(id).map(SlotTypePreset::getMessageBuilder).orElse(null);
/* 171 */           SlotTypeMessage presetMsg = (preset != null) ? preset.build() : null;
/*     */           
/* 173 */           if (msg.getIcon() == null && presetMsg != null) {
/* 174 */             builder.icon(presetMsg.getIcon());
/*     */           } else {
/* 176 */             builder.icon(msg.getIcon());
/*     */           } 
/*     */           
/* 179 */           if (msg.getPriority() == null && presetMsg != null) {
/* 180 */             builder.priority(presetMsg.getPriority()); continue;
/*     */           } 
/* 182 */           builder.priority(msg.getPriority());
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\curios-309927-4590652.jar!\top\theillusivec4\curios\common\slottype\SlotTypeManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */