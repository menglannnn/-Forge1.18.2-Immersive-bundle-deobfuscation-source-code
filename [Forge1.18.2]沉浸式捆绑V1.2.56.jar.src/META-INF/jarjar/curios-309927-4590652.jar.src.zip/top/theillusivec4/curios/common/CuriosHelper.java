/*     */ package top.theillusivec4.curios.common;
/*     */ 
/*     */ import com.google.common.collect.HashMultimap;
/*     */ import com.google.common.collect.Multimap;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Optional;
/*     */ import java.util.Set;
/*     */ import java.util.UUID;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Predicate;
/*     */ import java.util.stream.Collectors;
/*     */ import javax.annotation.Nonnull;
/*     */ import net.minecraft.core.NonNullList;
/*     */ import net.minecraft.nbt.CompoundTag;
/*     */ import net.minecraft.nbt.ListTag;
/*     */ import net.minecraft.nbt.Tag;
/*     */ import net.minecraft.resources.ResourceLocation;
/*     */ import net.minecraft.tags.TagKey;
/*     */ import net.minecraft.world.entity.LivingEntity;
/*     */ import net.minecraft.world.entity.ai.attributes.Attribute;
/*     */ import net.minecraft.world.entity.ai.attributes.AttributeModifier;
/*     */ import net.minecraft.world.item.Item;
/*     */ import net.minecraft.world.item.ItemStack;
/*     */ import net.minecraftforge.common.util.LazyOptional;
/*     */ import net.minecraftforge.items.IItemHandlerModifiable;
/*     */ import net.minecraftforge.items.wrapper.CombinedInvWrapper;
/*     */ import net.minecraftforge.registries.ForgeRegistries;
/*     */ import net.minecraftforge.registries.IForgeRegistryEntry;
/*     */ import org.apache.commons.lang3.tuple.ImmutableTriple;
/*     */ import org.apache.logging.log4j.util.TriConsumer;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ import top.theillusivec4.curios.api.CuriosApi;
/*     */ import top.theillusivec4.curios.api.CuriosCapability;
/*     */ import top.theillusivec4.curios.api.SlotContext;
/*     */ import top.theillusivec4.curios.api.SlotResult;
/*     */ import top.theillusivec4.curios.api.SlotTypePreset;
/*     */ import top.theillusivec4.curios.api.type.capability.ICurio;
/*     */ import top.theillusivec4.curios.api.type.capability.ICuriosItemHandler;
/*     */ import top.theillusivec4.curios.api.type.inventory.ICurioStacksHandler;
/*     */ import top.theillusivec4.curios.api.type.inventory.IDynamicStackHandler;
/*     */ import top.theillusivec4.curios.api.type.util.ICuriosHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CuriosHelper
/*     */   implements ICuriosHelper
/*     */ {
/*  66 */   private static final Map<String, SlotAttributeWrapper> SLOT_ATTRIBUTES = new HashMap<>();
/*     */   
/*     */   private static TriConsumer<String, Integer, LivingEntity> brokenCurioConsumerLegacy;
/*     */   
/*     */   private static Consumer<SlotContext> brokenCurioConsumer;
/*     */   
/*     */   public LazyOptional<ICurio> getCurio(ItemStack stack) {
/*  73 */     return stack.getCapability(CuriosCapability.ITEM);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public LazyOptional<ICuriosItemHandler> getCuriosHandler(@Nonnull LivingEntity livingEntity) {
/*  79 */     return livingEntity.getCapability(CuriosCapability.INVENTORY);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<String> getCurioTags(Item item) {
/*  85 */     return (Set<String>)item.m_204114_().m_203616_().map(TagKey::f_203868_)
/*  86 */       .filter(resourceLocation -> resourceLocation.m_135827_().equals("curios"))
/*  87 */       .map(ResourceLocation::m_135815_).collect(Collectors.toSet());
/*     */   }
/*     */ 
/*     */   
/*     */   public LazyOptional<IItemHandlerModifiable> getEquippedCurios(LivingEntity livingEntity) {
/*  92 */     return CuriosApi.getCuriosHelper().getCuriosHandler(livingEntity).lazyMap(handler -> {
/*     */           Map<String, ICurioStacksHandler> curios = handler.getCurios();
/*     */           IItemHandlerModifiable[] itemHandlers = new IItemHandlerModifiable[curios.size()];
/*     */           int index = 0;
/*     */           for (ICurioStacksHandler stacksHandler : curios.values()) {
/*     */             if (index < itemHandlers.length) {
/*     */               itemHandlers[index] = (IItemHandlerModifiable)stacksHandler.getStacks();
/*     */               index++;
/*     */             } 
/*     */           } 
/*     */           return (IItemHandlerModifiable)new CombinedInvWrapper(itemHandlers);
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEquippedCurio(@NotNull LivingEntity livingEntity, String identifier, int index, ItemStack stack) {
/* 111 */     getCuriosHandler(livingEntity).ifPresent(handler -> {
/*     */           Map<String, ICurioStacksHandler> curios = handler.getCurios();
/*     */           ICurioStacksHandler stacksHandler = curios.get(identifier);
/*     */           if (stacksHandler != null) {
/*     */             IDynamicStackHandler stackHandler = stacksHandler.getStacks();
/*     */             if (index < stackHandler.getSlots()) {
/*     */               stackHandler.setStackInSlot(index, stack);
/*     */             }
/*     */           } 
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<SlotResult> findFirstCurio(@Nonnull LivingEntity livingEntity, Item item) {
/* 127 */     return findFirstCurio(livingEntity, stack -> (stack.m_41720_() == item));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<SlotResult> findFirstCurio(@Nonnull LivingEntity livingEntity, Predicate<ItemStack> filter) {
/* 151 */     SlotResult result = getCuriosHandler(livingEntity).map(handler -> { Map<String, ICurioStacksHandler> curios = handler.getCurios(); for (String id : curios.keySet()) { ICurioStacksHandler stacksHandler = curios.get(id); IDynamicStackHandler stackHandler = stacksHandler.getStacks(); for (int i = 0; i < stackHandler.getSlots(); i++) { ItemStack stack = stackHandler.getStackInSlot(i); if (!stack.m_41619_() && filter.test(stack)) { NonNullList<Boolean> renderStates = stacksHandler.getRenders(); return new SlotResult(new SlotContext(id, livingEntity, i, false, (renderStates.size() > i && ((Boolean)renderStates.get(i)).booleanValue())), stack); }  }  }  return new SlotResult(null, ItemStack.f_41583_); }).orElse(new SlotResult(null, ItemStack.f_41583_));
/* 152 */     return (result.stack().m_41619_() || result.slotContext() == null) ? Optional.<SlotResult>empty() : 
/* 153 */       Optional.<SlotResult>of(result);
/*     */   }
/*     */ 
/*     */   
/*     */   public List<SlotResult> findCurios(@Nonnull LivingEntity livingEntity, Item item) {
/* 158 */     return findCurios(livingEntity, stack -> (stack.m_41720_() == item));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public List<SlotResult> findCurios(@Nonnull LivingEntity livingEntity, Predicate<ItemStack> filter) {
/* 164 */     List<SlotResult> result = new ArrayList<>();
/* 165 */     getCuriosHandler(livingEntity).ifPresent(handler -> {
/*     */           Map<String, ICurioStacksHandler> curios = handler.getCurios();
/*     */           
/*     */           for (String id : curios.keySet()) {
/*     */             ICurioStacksHandler stacksHandler = curios.get(id);
/*     */             
/*     */             IDynamicStackHandler stackHandler = stacksHandler.getStacks();
/*     */             
/*     */             for (int i = 0; i < stackHandler.getSlots(); i++) {
/*     */               ItemStack stack = stackHandler.getStackInSlot(i);
/*     */               if (!stack.m_41619_() && filter.test(stack)) {
/*     */                 NonNullList<Boolean> renderStates = stacksHandler.getRenders();
/* 177 */                 result.add(new SlotResult(new SlotContext(id, livingEntity, i, false, (renderStates.size() > i && ((Boolean)renderStates.get(i)).booleanValue())), stack));
/*     */               } 
/*     */             } 
/*     */           } 
/*     */         });
/*     */     
/* 183 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public List<SlotResult> findCurios(@NotNull LivingEntity livingEntity, String... identifiers) {
/* 188 */     List<SlotResult> result = new ArrayList<>();
/* 189 */     Set<String> ids = new HashSet<>(List.of(identifiers));
/* 190 */     getCuriosHandler(livingEntity).ifPresent(handler -> {
/*     */           Map<String, ICurioStacksHandler> curios = handler.getCurios();
/*     */           
/*     */           for (String id : curios.keySet()) {
/*     */             if (ids.contains(id)) {
/*     */               ICurioStacksHandler stacksHandler = curios.get(id);
/*     */               
/*     */               IDynamicStackHandler stackHandler = stacksHandler.getStacks();
/*     */               
/*     */               for (int i = 0; i < stackHandler.getSlots(); i++) {
/*     */                 ItemStack stack = stackHandler.getStackInSlot(i);
/*     */                 
/*     */                 if (!stack.m_41619_()) {
/*     */                   NonNullList<Boolean> renderStates = stacksHandler.getRenders();
/* 204 */                   result.add(new SlotResult(new SlotContext(id, livingEntity, i, false, (renderStates.size() > i && ((Boolean)renderStates.get(i)).booleanValue())), stack));
/*     */                 } 
/*     */               } 
/*     */             } 
/*     */           } 
/*     */         });
/*     */     
/* 211 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<SlotResult> findCurio(@Nonnull LivingEntity livingEntity, String identifier, int index) {
/* 235 */     SlotResult result = getCuriosHandler(livingEntity).map(handler -> { Map<String, ICurioStacksHandler> curios = handler.getCurios(); ICurioStacksHandler stacksHandler = curios.get(identifier); if (stacksHandler != null) { IDynamicStackHandler stackHandler = stacksHandler.getStacks(); if (index < stackHandler.getSlots()) { ItemStack stack = stackHandler.getStackInSlot(index); if (!stack.m_41619_()) { NonNullList<Boolean> renderStates = stacksHandler.getRenders(); return new SlotResult(new SlotContext(identifier, livingEntity, index, false, (renderStates.size() > index && ((Boolean)renderStates.get(index)).booleanValue())), stack); }  }  }  return new SlotResult(null, ItemStack.f_41583_); }).orElse(new SlotResult(null, ItemStack.f_41583_));
/* 236 */     return (result.stack().m_41619_() || result.slotContext() == null) ? Optional.<SlotResult>empty() : 
/* 237 */       Optional.<SlotResult>of(result);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nonnull
/*     */   public Optional<ImmutableTriple<String, Integer, ItemStack>> findEquippedCurio(Item item, @Nonnull LivingEntity livingEntity) {
/* 245 */     return findEquippedCurio(stack -> (stack.m_41720_() == item), livingEntity);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nonnull
/*     */   public Optional<ImmutableTriple<String, Integer, ItemStack>> findEquippedCurio(Predicate<ItemStack> filter, @Nonnull LivingEntity livingEntity) {
/* 270 */     ImmutableTriple<String, Integer, ItemStack> result = getCuriosHandler(livingEntity).map(handler -> { Map<String, ICurioStacksHandler> curios = handler.getCurios(); for (String id : curios.keySet()) { ICurioStacksHandler stacksHandler = curios.get(id); IDynamicStackHandler stackHandler = stacksHandler.getStacks(); for (int i = 0; i < stackHandler.getSlots(); i++) { ItemStack stack = stackHandler.getStackInSlot(i); if (!stack.m_41619_() && filter.test(stack)) return new ImmutableTriple(id, Integer.valueOf(i), stack);  }  }  return new ImmutableTriple("", Integer.valueOf(0), ItemStack.f_41583_); }).orElse(new ImmutableTriple("", Integer.valueOf(0), ItemStack.f_41583_));
/*     */     
/* 272 */     return ((String)result.getLeft()).isEmpty() ? Optional.<ImmutableTriple<String, Integer, ItemStack>>empty() : Optional.<ImmutableTriple<String, Integer, ItemStack>>of(result);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Multimap<Attribute, AttributeModifier> getAttributeModifiers(String identifier, ItemStack stack) {
/* 278 */     return getAttributeModifiers(new SlotContext(identifier, null, 0, false, true), 
/* 279 */         UUID.randomUUID(), stack);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Multimap<Attribute, AttributeModifier> getAttributeModifiers(SlotContext slotContext, UUID uuid, ItemStack stack) {
/* 287 */     if (stack.m_41783_() != null && stack.m_41783_().m_128425_("CurioAttributeModifiers", 9)) {
/* 288 */       HashMultimap hashMultimap = HashMultimap.create();
/* 289 */       ListTag listnbt = stack.m_41783_().m_128437_("CurioAttributeModifiers", 10);
/* 290 */       String identifier = slotContext.identifier();
/*     */       
/* 292 */       for (int i = 0; i < listnbt.size(); i++) {
/* 293 */         CompoundTag compoundnbt = listnbt.m_128728_(i);
/*     */         
/* 295 */         if (compoundnbt.m_128461_("Slot").equals(identifier)) {
/* 296 */           ResourceLocation rl = ResourceLocation.m_135820_(compoundnbt.m_128461_("AttributeName"));
/* 297 */           UUID id = uuid;
/*     */           
/* 299 */           if (rl != null) {
/*     */             
/* 301 */             if (compoundnbt.m_128441_("UUID")) {
/* 302 */               id = compoundnbt.m_128342_("UUID");
/*     */             }
/*     */             
/* 305 */             if (id.getLeastSignificantBits() != 0L && id.getMostSignificantBits() != 0L) {
/*     */               
/* 307 */               AttributeModifier.Operation operation = AttributeModifier.Operation.m_22236_(compoundnbt.m_128451_("Operation"));
/* 308 */               double amount = compoundnbt.m_128459_("Amount");
/* 309 */               String name = compoundnbt.m_128461_("Name");
/*     */               
/* 311 */               if (rl.m_135827_().equals("curios")) {
/* 312 */                 String identifier1 = rl.m_135815_();
/*     */                 
/* 314 */                 if (CuriosApi.getSlotHelper().getSlotType(identifier1).isPresent()) {
/* 315 */                   CuriosApi.getCuriosHelper()
/* 316 */                     .addSlotModifier((Multimap)hashMultimap, identifier1, id, amount, operation);
/*     */                 }
/*     */               } else {
/* 319 */                 Attribute attribute = (Attribute)ForgeRegistries.ATTRIBUTES.getValue(rl);
/*     */                 
/* 321 */                 if (attribute != null) {
/* 322 */                   hashMultimap.put(attribute, new AttributeModifier(id, name, amount, operation));
/*     */                 }
/*     */               } 
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/* 329 */       return (Multimap<Attribute, AttributeModifier>)hashMultimap;
/*     */     } 
/* 331 */     return (Multimap<Attribute, AttributeModifier>)getCurio(stack).map(curio -> curio.getAttributeModifiers(slotContext, uuid))
/* 332 */       .orElse(HashMultimap.create());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void addSlotModifier(Multimap<Attribute, AttributeModifier> map, String identifier, UUID uuid, double amount, AttributeModifier.Operation operation) {
/* 338 */     map.put(getOrCreateSlotAttribute(identifier), new AttributeModifier(uuid, identifier, amount, operation));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addSlotModifier(ItemStack stack, String identifier, String name, UUID uuid, double amount, AttributeModifier.Operation operation, String slot) {
/* 345 */     addModifier(stack, getOrCreateSlotAttribute(identifier), name, uuid, amount, operation, slot);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void addModifier(ItemStack stack, Attribute attribute, String name, UUID uuid, double amount, AttributeModifier.Operation operation, String slot) {
/* 351 */     CompoundTag tag = stack.m_41784_();
/*     */     
/* 353 */     if (!tag.m_128425_("CurioAttributeModifiers", 9)) {
/* 354 */       tag.m_128365_("CurioAttributeModifiers", (Tag)new ListTag());
/*     */     }
/* 356 */     ListTag listtag = tag.m_128437_("CurioAttributeModifiers", 10);
/* 357 */     CompoundTag compoundtag = new CompoundTag();
/* 358 */     compoundtag.m_128359_("Name", name);
/* 359 */     compoundtag.m_128347_("Amount", amount);
/* 360 */     compoundtag.m_128405_("Operation", operation.m_22235_());
/*     */     
/* 362 */     if (uuid != null) {
/* 363 */       compoundtag.m_128362_("UUID", uuid);
/*     */     }
/* 365 */     String id = "";
/*     */     
/* 367 */     if (attribute instanceof SlotAttributeWrapper) { SlotAttributeWrapper wrapper = (SlotAttributeWrapper)attribute;
/* 368 */       id = "curios:" + wrapper.identifier; }
/*     */     else
/* 370 */     { ResourceLocation rl = ForgeRegistries.ATTRIBUTES.getKey((IForgeRegistryEntry)attribute);
/*     */       
/* 372 */       if (rl != null) {
/* 373 */         id = rl.toString();
/*     */       } }
/*     */ 
/*     */     
/* 377 */     if (!id.isEmpty()) {
/* 378 */       compoundtag.m_128359_("AttributeName", id);
/*     */     }
/* 380 */     compoundtag.m_128359_("Slot", slot);
/* 381 */     listtag.add(compoundtag);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isStackValid(SlotContext slotContext, ItemStack stack) {
/* 386 */     String id = slotContext.identifier();
/* 387 */     Set<String> tags = getCurioTags(stack.m_41720_());
/* 388 */     return ((!tags.isEmpty() && id.equals(SlotTypePreset.CURIO.getIdentifier())) || tags
/* 389 */       .contains(id) || tags.contains(SlotTypePreset.CURIO.getIdentifier()));
/*     */   }
/*     */ 
/*     */   
/*     */   public void onBrokenCurio(SlotContext slotContext) {
/* 394 */     brokenCurioConsumer.accept(slotContext);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBrokenCurioConsumer(Consumer<SlotContext> consumer) {
/* 400 */     if (brokenCurioConsumer == null) {
/* 401 */       brokenCurioConsumer = consumer;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void onBrokenCurio(String id, int index, LivingEntity damager) {
/* 407 */     brokenCurioConsumerLegacy.accept(id, Integer.valueOf(index), damager);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBrokenCurioConsumer(TriConsumer<String, Integer, LivingEntity> consumer) {
/* 413 */     if (brokenCurioConsumerLegacy == null) {
/* 414 */       brokenCurioConsumerLegacy = consumer;
/*     */     }
/*     */   }
/*     */   
/*     */   public static SlotAttributeWrapper getOrCreateSlotAttribute(String identifier) {
/* 419 */     return SLOT_ATTRIBUTES.computeIfAbsent(identifier, SlotAttributeWrapper::new);
/*     */   }
/*     */   
/*     */   public static class SlotAttributeWrapper
/*     */     extends Attribute {
/*     */     public final String identifier;
/*     */     
/*     */     private SlotAttributeWrapper(String identifier) {
/* 427 */       super("curios.slot." + identifier, 0.0D);
/* 428 */       this.identifier = identifier;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\curios-309927-4590652.jar!\top\theillusivec4\curios\common\CuriosHelper.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */