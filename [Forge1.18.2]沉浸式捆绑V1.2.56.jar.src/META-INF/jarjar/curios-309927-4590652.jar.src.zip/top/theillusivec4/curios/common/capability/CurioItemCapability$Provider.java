/*    */ package top.theillusivec4.curios.common.capability;
/*    */ 
/*    */ import javax.annotation.Nonnull;
/*    */ import javax.annotation.Nullable;
/*    */ import net.minecraft.core.Direction;
/*    */ import net.minecraftforge.common.capabilities.Capability;
/*    */ import net.minecraftforge.common.capabilities.ICapabilityProvider;
/*    */ import net.minecraftforge.common.util.LazyOptional;
/*    */ import top.theillusivec4.curios.api.CuriosCapability;
/*    */ import top.theillusivec4.curios.api.type.capability.ICurio;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Provider
/*    */   implements ICapabilityProvider
/*    */ {
/*    */   final LazyOptional<ICurio> capability;
/*    */   
/*    */   Provider(ICurio curio) {
/* 42 */     this.capability = LazyOptional.of(() -> curio);
/*    */   }
/*    */ 
/*    */   
/*    */   @Nonnull
/*    */   public <T> LazyOptional<T> getCapability(@Nonnull Capability<T> cap, @Nullable Direction side) {
/* 48 */     return CuriosCapability.ITEM.orEmpty(cap, this.capability);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\curios-309927-4590652.jar!\top\theillusivec4\curios\common\capability\CurioItemCapability$Provider.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */