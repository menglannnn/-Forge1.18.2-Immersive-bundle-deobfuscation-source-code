/*     */ package top.theillusivec4.curios.common.network.server.sync;
/*     */ 
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.function.Supplier;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.multiplayer.ClientLevel;
/*     */ import net.minecraft.nbt.CompoundTag;
/*     */ import net.minecraft.network.FriendlyByteBuf;
/*     */ import net.minecraft.world.entity.Entity;
/*     */ import net.minecraft.world.entity.LivingEntity;
/*     */ import net.minecraft.world.entity.player.Player;
/*     */ import net.minecraftforge.common.MinecraftForge;
/*     */ import net.minecraftforge.eventbus.api.Event;
/*     */ import net.minecraftforge.network.NetworkEvent;
/*     */ import top.theillusivec4.curios.api.CuriosApi;
/*     */ import top.theillusivec4.curios.api.event.SlotModifiersUpdatedEvent;
/*     */ import top.theillusivec4.curios.api.type.capability.ICuriosItemHandler;
/*     */ import top.theillusivec4.curios.api.type.inventory.ICurioStacksHandler;
/*     */ import top.theillusivec4.curios.common.inventory.container.CuriosContainer;
/*     */ 
/*     */ public class SPacketSyncModifiers
/*     */ {
/*     */   private int entityId;
/*     */   
/*     */   public SPacketSyncModifiers(int entityId, Set<ICurioStacksHandler> updates) {
/*  28 */     Map<String, CompoundTag> result = new LinkedHashMap<>();
/*     */     
/*  30 */     for (ICurioStacksHandler stacksHandler : updates) {
/*  31 */       result.put(stacksHandler.getIdentifier(), stacksHandler.getSyncTag());
/*     */     }
/*  33 */     this.entityId = entityId;
/*  34 */     this.entrySize = result.size();
/*  35 */     this.updates = result;
/*     */   }
/*     */   private int entrySize; private Map<String, CompoundTag> updates;
/*     */   public SPacketSyncModifiers(Map<String, CompoundTag> map, int entityId) {
/*  39 */     this.entityId = entityId;
/*  40 */     this.entrySize = map.size();
/*  41 */     this.updates = map;
/*     */   }
/*     */   
/*     */   public static void encode(SPacketSyncModifiers msg, FriendlyByteBuf buf) {
/*  45 */     buf.writeInt(msg.entityId);
/*  46 */     buf.writeInt(msg.entrySize);
/*     */     
/*  48 */     for (Map.Entry<String, CompoundTag> entry : msg.updates.entrySet()) {
/*  49 */       buf.m_130070_(entry.getKey());
/*  50 */       buf.m_130079_(entry.getValue());
/*     */     } 
/*     */   }
/*     */   
/*     */   public static SPacketSyncModifiers decode(FriendlyByteBuf buf) {
/*  55 */     int entityId = buf.readInt();
/*  56 */     int entrySize = buf.readInt();
/*  57 */     Map<String, CompoundTag> map = new LinkedHashMap<>();
/*     */     
/*  59 */     for (int i = 0; i < entrySize; i++) {
/*  60 */       String key = buf.m_130136_(25);
/*  61 */       map.put(key, buf.m_130260_());
/*     */     } 
/*  63 */     return new SPacketSyncModifiers(map, entityId);
/*     */   }
/*     */   
/*     */   public static void handle(SPacketSyncModifiers msg, Supplier<NetworkEvent.Context> ctx) {
/*  67 */     ((NetworkEvent.Context)ctx.get()).enqueueWork(() -> {
/*     */           ClientLevel world = (Minecraft.m_91087_()).f_91073_;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           if (world != null) {
/*     */             Entity entity = world.m_6815_(msg.entityId);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/*     */             if (entity instanceof LivingEntity) {
/*     */               LivingEntity livingEntity = (LivingEntity)entity;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */               
/*     */               CuriosApi.getCuriosHelper().getCuriosHandler(livingEntity).ifPresent(());
/*     */             } 
/*     */           } 
/*     */         });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 102 */     ((NetworkEvent.Context)ctx.get()).setPacketHandled(true);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\curios-309927-4590652.jar!\top\theillusivec4\curios\common\network\server\sync\SPacketSyncModifiers.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */