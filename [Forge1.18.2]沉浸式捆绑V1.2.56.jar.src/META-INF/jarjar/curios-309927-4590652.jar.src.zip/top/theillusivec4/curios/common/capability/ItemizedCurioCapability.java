/*     */ package top.theillusivec4.curios.common.capability;
/*     */ 
/*     */ import com.google.common.collect.Multimap;
/*     */ import java.util.List;
/*     */ import java.util.UUID;
/*     */ import javax.annotation.Nonnull;
/*     */ import net.minecraft.nbt.CompoundTag;
/*     */ import net.minecraft.network.chat.Component;
/*     */ import net.minecraft.world.damagesource.DamageSource;
/*     */ import net.minecraft.world.entity.LivingEntity;
/*     */ import net.minecraft.world.entity.ai.attributes.Attribute;
/*     */ import net.minecraft.world.entity.ai.attributes.AttributeModifier;
/*     */ import net.minecraft.world.entity.monster.EnderMan;
/*     */ import net.minecraft.world.item.ItemStack;
/*     */ import net.minecraft.world.level.storage.loot.LootContext;
/*     */ import top.theillusivec4.curios.api.SlotContext;
/*     */ import top.theillusivec4.curios.api.type.capability.ICurio;
/*     */ import top.theillusivec4.curios.api.type.capability.ICurioItem;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ItemizedCurioCapability
/*     */   implements ICurio
/*     */ {
/*     */   private final ItemStack stack;
/*     */   private final ICurioItem curioItem;
/*     */   
/*     */   public ItemizedCurioCapability(ICurioItem curio, ItemStack stack) {
/*  44 */     this.curioItem = curio;
/*  45 */     this.stack = stack;
/*     */   }
/*     */ 
/*     */   
/*     */   public ItemStack getStack() {
/*  50 */     return this.stack;
/*     */   }
/*     */ 
/*     */   
/*     */   public void curioTick(SlotContext slotContext) {
/*  55 */     this.curioItem.curioTick(slotContext, getStack());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canEquip(SlotContext slotContext) {
/*  60 */     return this.curioItem.canEquip(slotContext, getStack());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canUnequip(SlotContext slotContext) {
/*  65 */     return this.curioItem.canUnequip(slotContext, getStack());
/*     */   }
/*     */ 
/*     */   
/*     */   public List<Component> getSlotsTooltip(List<Component> tooltips) {
/*  70 */     return this.curioItem.getSlotsTooltip(tooltips, getStack());
/*     */   }
/*     */ 
/*     */   
/*     */   public void curioBreak(SlotContext slotContext) {
/*  75 */     this.curioItem.curioBreak(slotContext, getStack());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canSync(SlotContext slotContext) {
/*  80 */     return this.curioItem.canSync(slotContext, getStack());
/*     */   }
/*     */ 
/*     */   
/*     */   @Nonnull
/*     */   public CompoundTag writeSyncData(SlotContext slotContext) {
/*  86 */     return this.curioItem.writeSyncData(slotContext, getStack());
/*     */   }
/*     */ 
/*     */   
/*     */   public void readSyncData(SlotContext slotContext, CompoundTag compound) {
/*  91 */     this.curioItem.readSyncData(slotContext, compound, getStack());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nonnull
/*     */   public ICurio.DropRule getDropRule(SlotContext slotContext, DamageSource source, int lootingLevel, boolean recentlyHit) {
/*  98 */     return this.curioItem
/*  99 */       .getDropRule(slotContext, source, lootingLevel, recentlyHit, getStack());
/*     */   }
/*     */ 
/*     */   
/*     */   public List<Component> getAttributesTooltip(List<Component> tooltips) {
/* 104 */     return this.curioItem.getAttributesTooltip(tooltips, getStack());
/*     */   }
/*     */ 
/*     */   
/*     */   public int getFortuneLevel(SlotContext slotContext, LootContext lootContext) {
/* 109 */     return this.curioItem.getFortuneLevel(slotContext, lootContext, getStack());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getLootingLevel(SlotContext slotContext, DamageSource source, LivingEntity target, int baseLooting) {
/* 115 */     return this.curioItem
/* 116 */       .getLootingLevel(slotContext, source, target, baseLooting, getStack());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Multimap<Attribute, AttributeModifier> getAttributeModifiers(SlotContext slotContext, UUID uuid) {
/* 122 */     return this.curioItem.getAttributeModifiers(slotContext, uuid, getStack());
/*     */   }
/*     */ 
/*     */   
/*     */   public void onEquipFromUse(SlotContext slotContext) {
/* 127 */     this.curioItem.onEquipFromUse(slotContext, getStack());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canEquipFromUse(SlotContext slotContext) {
/* 132 */     return this.curioItem.canEquipFromUse(slotContext, getStack());
/*     */   }
/*     */ 
/*     */   
/*     */   public void onEquip(SlotContext slotContext, ItemStack prevStack) {
/* 137 */     this.curioItem.onEquip(slotContext, prevStack, getStack());
/*     */   }
/*     */ 
/*     */   
/*     */   public void onUnequip(SlotContext slotContext, ItemStack newStack) {
/* 142 */     this.curioItem.onUnequip(slotContext, newStack, getStack());
/*     */   }
/*     */ 
/*     */   
/*     */   @Nonnull
/*     */   public ICurio.SoundInfo getEquipSound(SlotContext slotContext) {
/* 148 */     return this.curioItem.getEquipSound(slotContext, getStack());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean makesPiglinsNeutral(SlotContext slotContext) {
/* 153 */     return this.curioItem.makesPiglinsNeutral(slotContext, getStack());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canWalkOnPowderedSnow(SlotContext slotContext) {
/* 158 */     return this.curioItem.canWalkOnPowderedSnow(slotContext, getStack());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEnderMask(SlotContext slotContext, EnderMan enderMan) {
/* 163 */     return this.curioItem.isEnderMask(slotContext, enderMan, getStack());
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\curios-309927-4590652.jar!\top\theillusivec4\curios\common\capability\ItemizedCurioCapability.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */