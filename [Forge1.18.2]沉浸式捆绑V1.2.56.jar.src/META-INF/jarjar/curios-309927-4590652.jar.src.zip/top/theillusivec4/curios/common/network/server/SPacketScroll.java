/*    */ package top.theillusivec4.curios.common.network.server;
/*    */ 
/*    */ import java.util.function.Supplier;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.gui.screens.Screen;
/*    */ import net.minecraft.client.player.LocalPlayer;
/*    */ import net.minecraft.network.FriendlyByteBuf;
/*    */ import net.minecraft.world.inventory.AbstractContainerMenu;
/*    */ import net.minecraftforge.network.NetworkEvent;
/*    */ import top.theillusivec4.curios.client.gui.CuriosScreen;
/*    */ import top.theillusivec4.curios.common.inventory.container.CuriosContainer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SPacketScroll
/*    */ {
/*    */   private int windowId;
/*    */   private int index;
/*    */   
/*    */   public SPacketScroll(int windowId, int index) {
/* 38 */     this.windowId = windowId;
/* 39 */     this.index = index;
/*    */   }
/*    */   
/*    */   public static void encode(SPacketScroll msg, FriendlyByteBuf buf) {
/* 43 */     buf.writeInt(msg.windowId);
/* 44 */     buf.writeInt(msg.index);
/*    */   }
/*    */   
/*    */   public static SPacketScroll decode(FriendlyByteBuf buf) {
/* 48 */     return new SPacketScroll(buf.readInt(), buf.readInt());
/*    */   }
/*    */   
/*    */   public static void handle(SPacketScroll msg, Supplier<NetworkEvent.Context> ctx) {
/* 52 */     ((NetworkEvent.Context)ctx.get()).enqueueWork(() -> {
/*    */           Minecraft mc = Minecraft.m_91087_();
/*    */           
/*    */           LocalPlayer clientPlayer = mc.f_91074_;
/*    */           
/*    */           Screen screen = mc.f_91080_;
/*    */           
/*    */           if (clientPlayer != null) {
/*    */             AbstractContainerMenu container = clientPlayer.f_36096_;
/*    */             if (container instanceof CuriosContainer && container.f_38840_ == msg.windowId) {
/*    */               ((CuriosContainer)container).scrollToIndex(msg.index);
/*    */             }
/*    */           } 
/*    */           if (screen instanceof CuriosScreen) {
/*    */             ((CuriosScreen)screen).updateRenderButtons();
/*    */           }
/*    */         });
/* 69 */     ((NetworkEvent.Context)ctx.get()).setPacketHandled(true);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\curios-309927-4590652.jar!\top\theillusivec4\curios\common\network\server\SPacketScroll.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */