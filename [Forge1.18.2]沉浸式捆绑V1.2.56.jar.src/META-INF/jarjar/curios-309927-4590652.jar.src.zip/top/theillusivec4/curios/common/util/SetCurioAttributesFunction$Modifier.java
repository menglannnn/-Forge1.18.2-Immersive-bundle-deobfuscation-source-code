/*     */ package top.theillusivec4.curios.common.util;
/*     */ 
/*     */ import com.google.gson.JsonArray;
/*     */ import com.google.gson.JsonDeserializationContext;
/*     */ import com.google.gson.JsonElement;
/*     */ import com.google.gson.JsonObject;
/*     */ import com.google.gson.JsonPrimitive;
/*     */ import com.google.gson.JsonSerializationContext;
/*     */ import com.google.gson.JsonSyntaxException;
/*     */ import java.util.UUID;
/*     */ import javax.annotation.Nullable;
/*     */ import net.minecraft.resources.ResourceLocation;
/*     */ import net.minecraft.util.GsonHelper;
/*     */ import net.minecraft.world.entity.ai.attributes.Attribute;
/*     */ import net.minecraft.world.entity.ai.attributes.AttributeModifier;
/*     */ import net.minecraft.world.level.storage.loot.providers.number.NumberProvider;
/*     */ import net.minecraftforge.registries.ForgeRegistries;
/*     */ import net.minecraftforge.registries.IForgeRegistryEntry;
/*     */ import top.theillusivec4.curios.api.CuriosApi;
/*     */ import top.theillusivec4.curios.common.CuriosHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class Modifier
/*     */ {
/*     */   final String name;
/*     */   final Attribute attribute;
/*     */   final AttributeModifier.Operation operation;
/*     */   final NumberProvider amount;
/*     */   @Nullable
/*     */   final UUID id;
/*     */   final String[] slots;
/*     */   
/*     */   Modifier(String name, Attribute attribute, AttributeModifier.Operation operation, NumberProvider amount, String[] slots, @Nullable UUID uuid) {
/*  96 */     this.name = name;
/*  97 */     this.attribute = attribute;
/*  98 */     this.operation = operation;
/*  99 */     this.amount = amount;
/* 100 */     this.id = uuid;
/* 101 */     this.slots = slots;
/*     */   }
/*     */   public JsonObject serialize(JsonSerializationContext context) {
/*     */     ResourceLocation rl;
/* 105 */     JsonObject jsonobject = new JsonObject();
/* 106 */     jsonobject.addProperty("name", this.name);
/*     */ 
/*     */     
/* 109 */     Attribute attribute = this.attribute; if (attribute instanceof CuriosHelper.SlotAttributeWrapper) { CuriosHelper.SlotAttributeWrapper wrapper = (CuriosHelper.SlotAttributeWrapper)attribute;
/* 110 */       rl = new ResourceLocation("curios", wrapper.identifier); }
/*     */     else
/* 112 */     { rl = ForgeRegistries.ATTRIBUTES.getKey((IForgeRegistryEntry)this.attribute); }
/*     */ 
/*     */     
/* 115 */     if (rl != null) {
/* 116 */       jsonobject.addProperty("attribute", rl.toString());
/*     */     }
/* 118 */     jsonobject.addProperty("operation", operationToString(this.operation));
/* 119 */     jsonobject.add("amount", context.serialize(this.amount));
/*     */     
/* 121 */     if (this.id != null) {
/* 122 */       jsonobject.addProperty("id", this.id.toString());
/*     */     }
/*     */     
/* 125 */     if (this.slots.length == 1) {
/* 126 */       jsonobject.addProperty("slot", this.slots[0]);
/*     */     } else {
/* 128 */       JsonArray jsonarray = new JsonArray();
/*     */       
/* 130 */       for (String slot : this.slots) {
/* 131 */         jsonarray.add((JsonElement)new JsonPrimitive(slot));
/*     */       }
/* 133 */       jsonobject.add("slot", (JsonElement)jsonarray);
/*     */     } 
/* 135 */     return jsonobject;
/*     */   }
/*     */   public static Modifier deserialize(JsonObject object, JsonDeserializationContext context) {
/*     */     Attribute attribute;
/* 139 */     String slots[], s = GsonHelper.m_13906_(object, "name");
/*     */     
/* 141 */     ResourceLocation resourcelocation = new ResourceLocation(GsonHelper.m_13906_(object, "attribute"));
/*     */ 
/*     */     
/* 144 */     if (resourcelocation.m_135827_().equals("curios")) {
/* 145 */       String identifier = resourcelocation.m_135815_();
/*     */       
/* 147 */       if (CuriosApi.getSlotHelper().getSlotType(identifier).isEmpty()) {
/* 148 */         throw new JsonSyntaxException("Unknown curios slot type: " + identifier);
/*     */       }
/* 150 */       CuriosHelper.SlotAttributeWrapper slotAttributeWrapper = CuriosHelper.getOrCreateSlotAttribute(identifier);
/*     */     } else {
/* 152 */       attribute = (Attribute)ForgeRegistries.ATTRIBUTES.getValue(resourcelocation);
/*     */     } 
/*     */     
/* 155 */     if (attribute == null) {
/* 156 */       throw new JsonSyntaxException("Unknown attribute: " + resourcelocation);
/*     */     }
/*     */     
/* 159 */     AttributeModifier.Operation operation = operationFromString(GsonHelper.m_13906_(object, "operation"));
/*     */     
/* 161 */     NumberProvider numberprovider = (NumberProvider)GsonHelper.m_13836_(object, "amount", context, NumberProvider.class);
/* 162 */     UUID uuid = null;
/*     */ 
/*     */     
/* 165 */     if (GsonHelper.m_13813_(object, "slot")) {
/* 166 */       slots = new String[] { GsonHelper.m_13906_(object, "slot") };
/*     */     } else {
/*     */       
/* 169 */       if (!GsonHelper.m_13885_(object, "slot")) {
/* 170 */         throw new JsonSyntaxException("Invalid or missing attribute modifier slot; must be either string or array of strings.");
/*     */       }
/*     */       
/* 173 */       JsonArray jsonarray = GsonHelper.m_13933_(object, "slot");
/* 174 */       slots = new String[jsonarray.size()];
/* 175 */       int i = 0;
/*     */       
/* 177 */       for (JsonElement jsonelement : jsonarray) {
/* 178 */         slots[i++] = GsonHelper.m_13805_(jsonelement, "slot");
/*     */       }
/*     */       
/* 181 */       if (slots.length == 0) {
/* 182 */         throw new JsonSyntaxException("Invalid attribute modifier slot; must contain at least one entry.");
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 187 */     if (object.has("id")) {
/* 188 */       String s1 = GsonHelper.m_13906_(object, "id");
/*     */       
/*     */       try {
/* 191 */         uuid = UUID.fromString(s1);
/* 192 */       } catch (IllegalArgumentException illegalargumentexception) {
/* 193 */         throw new JsonSyntaxException("Invalid attribute modifier id '" + s1 + "' (must be UUID format, with dashes)");
/*     */       } 
/*     */     } 
/*     */     
/* 197 */     return new Modifier(s, attribute, operation, numberprovider, slots, uuid);
/*     */   }
/*     */ 
/*     */   
/*     */   private static String operationToString(AttributeModifier.Operation operation) {
/* 202 */     switch (SetCurioAttributesFunction.null.$SwitchMap$net$minecraft$world$entity$ai$attributes$AttributeModifier$Operation[operation.ordinal()]) { default: throw new IncompatibleClassChangeError();case 1: case 2: case 3: break; }  return 
/*     */ 
/*     */       
/* 205 */       "multiply_total";
/*     */   }
/*     */ 
/*     */   
/*     */   private static AttributeModifier.Operation operationFromString(String operation) {
/* 210 */     switch (operation) { case "addition": 
/*     */       case "multiply_base":
/*     */       
/*     */       case "multiply_total":
/* 214 */        }  throw new JsonSyntaxException("Unknown attribute modifier operation " + operation);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\curios-309927-4590652.jar!\top\theillusivec4\curios\commo\\util\SetCurioAttributesFunction$Modifier.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */