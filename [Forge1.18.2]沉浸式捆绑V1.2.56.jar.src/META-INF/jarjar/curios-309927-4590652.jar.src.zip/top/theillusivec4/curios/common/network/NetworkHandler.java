/*     */ package top.theillusivec4.curios.common.network;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.function.BiConsumer;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Supplier;
/*     */ import net.minecraft.network.FriendlyByteBuf;
/*     */ import net.minecraft.resources.ResourceLocation;
/*     */ import net.minecraftforge.network.NetworkEvent;
/*     */ import net.minecraftforge.network.NetworkRegistry;
/*     */ import net.minecraftforge.network.PacketDistributor;
/*     */ import net.minecraftforge.network.simple.SimpleChannel;
/*     */ import top.theillusivec4.curios.api.CuriosApi;
/*     */ import top.theillusivec4.curios.api.SlotContext;
/*     */ import top.theillusivec4.curios.common.network.client.CPacketDestroy;
/*     */ import top.theillusivec4.curios.common.network.client.CPacketOpenCurios;
/*     */ import top.theillusivec4.curios.common.network.client.CPacketOpenVanilla;
/*     */ import top.theillusivec4.curios.common.network.client.CPacketScroll;
/*     */ import top.theillusivec4.curios.common.network.client.CPacketToggleRender;
/*     */ import top.theillusivec4.curios.common.network.server.SPacketBreak;
/*     */ import top.theillusivec4.curios.common.network.server.SPacketGrabbedItem;
/*     */ import top.theillusivec4.curios.common.network.server.SPacketScroll;
/*     */ import top.theillusivec4.curios.common.network.server.SPacketSetIcons;
/*     */ import top.theillusivec4.curios.common.network.server.sync.SPacketSyncCurios;
/*     */ import top.theillusivec4.curios.common.network.server.sync.SPacketSyncModifiers;
/*     */ import top.theillusivec4.curios.common.network.server.sync.SPacketSyncOperation;
/*     */ import top.theillusivec4.curios.common.network.server.sync.SPacketSyncRender;
/*     */ import top.theillusivec4.curios.common.network.server.sync.SPacketSyncStack;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NetworkHandler
/*     */ {
/*     */   private static final String PTC_VERSION = "1";
/*     */   public static SimpleChannel INSTANCE;
/*  54 */   private static int id = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void register() {
/*  60 */     INSTANCE = NetworkRegistry.ChannelBuilder.named(new ResourceLocation("curios", "main")).networkProtocolVersion(() -> "1").clientAcceptedVersions("1"::equals).serverAcceptedVersions("1"::equals).simpleChannel();
/*     */ 
/*     */     
/*  63 */     register(CPacketOpenCurios.class, CPacketOpenCurios::encode, CPacketOpenCurios::decode, CPacketOpenCurios::handle);
/*     */     
/*  65 */     register(CPacketOpenVanilla.class, CPacketOpenVanilla::encode, CPacketOpenVanilla::decode, CPacketOpenVanilla::handle);
/*     */     
/*  67 */     register(CPacketScroll.class, CPacketScroll::encode, CPacketScroll::decode, CPacketScroll::handle);
/*     */     
/*  69 */     register(CPacketDestroy.class, CPacketDestroy::encode, CPacketDestroy::decode, CPacketDestroy::handle);
/*     */     
/*  71 */     register(CPacketToggleRender.class, CPacketToggleRender::encode, CPacketToggleRender::decode, CPacketToggleRender::handle);
/*     */ 
/*     */ 
/*     */     
/*  75 */     register(SPacketSyncStack.class, SPacketSyncStack::encode, SPacketSyncStack::decode, SPacketSyncStack::handle);
/*     */     
/*  77 */     register(SPacketScroll.class, SPacketScroll::encode, SPacketScroll::decode, SPacketScroll::handle);
/*     */     
/*  79 */     register(SPacketSyncOperation.class, SPacketSyncOperation::encode, SPacketSyncOperation::decode, SPacketSyncOperation::handle);
/*     */     
/*  81 */     register(SPacketSyncCurios.class, SPacketSyncCurios::encode, SPacketSyncCurios::decode, SPacketSyncCurios::handle);
/*     */     
/*  83 */     register(SPacketBreak.class, SPacketBreak::encode, SPacketBreak::decode, SPacketBreak::handle);
/*  84 */     register(SPacketGrabbedItem.class, SPacketGrabbedItem::encode, SPacketGrabbedItem::decode, SPacketGrabbedItem::handle);
/*     */     
/*  86 */     register(SPacketSetIcons.class, SPacketSetIcons::encode, SPacketSetIcons::decode, SPacketSetIcons::handle);
/*     */     
/*  88 */     register(SPacketSyncRender.class, SPacketSyncRender::encode, SPacketSyncRender::decode, SPacketSyncRender::handle);
/*     */     
/*  90 */     register(SPacketSyncModifiers.class, SPacketSyncModifiers::encode, SPacketSyncModifiers::decode, SPacketSyncModifiers::handle);
/*     */ 
/*     */ 
/*     */     
/*  94 */     CuriosApi.getCuriosHelper().setBrokenCurioConsumer(slotContext -> {
/*     */           Objects.requireNonNull(slotContext);
/*     */           INSTANCE.send(PacketDistributor.TRACKING_ENTITY_AND_SELF.with(slotContext::entity), new SPacketBreak(slotContext.entity().m_142049_(), slotContext.identifier(), slotContext.index()));
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static <M> void register(Class<M> messageType, BiConsumer<M, FriendlyByteBuf> encoder, Function<FriendlyByteBuf, M> decoder, BiConsumer<M, Supplier<NetworkEvent.Context>> messageConsumer) {
/* 103 */     INSTANCE.registerMessage(id++, messageType, encoder, decoder, messageConsumer);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\curios-309927-4590652.jar!\top\theillusivec4\curios\common\network\NetworkHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */