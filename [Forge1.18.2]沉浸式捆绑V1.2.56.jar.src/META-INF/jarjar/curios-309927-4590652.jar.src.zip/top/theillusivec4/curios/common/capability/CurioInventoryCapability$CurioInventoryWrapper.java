/*     */ package top.theillusivec4.curios.common.capability;
/*     */ 
/*     */ import com.google.common.collect.HashMultimap;
/*     */ import com.google.common.collect.Multimap;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Optional;
/*     */ import java.util.Set;
/*     */ import java.util.SortedMap;
/*     */ import java.util.SortedSet;
/*     */ import java.util.TreeMap;
/*     */ import java.util.TreeSet;
/*     */ import java.util.UUID;
/*     */ import javax.annotation.Nullable;
/*     */ import net.minecraft.core.NonNullList;
/*     */ import net.minecraft.nbt.CompoundTag;
/*     */ import net.minecraft.nbt.ListTag;
/*     */ import net.minecraft.nbt.Tag;
/*     */ import net.minecraft.world.damagesource.DamageSource;
/*     */ import net.minecraft.world.entity.LivingEntity;
/*     */ import net.minecraft.world.entity.ai.attributes.Attribute;
/*     */ import net.minecraft.world.entity.ai.attributes.AttributeModifier;
/*     */ import net.minecraft.world.entity.player.Player;
/*     */ import net.minecraft.world.item.ItemStack;
/*     */ import net.minecraft.world.level.storage.loot.LootContext;
/*     */ import net.minecraftforge.items.ItemHandlerHelper;
/*     */ import net.minecraftforge.items.ItemStackHandler;
/*     */ import top.theillusivec4.curios.api.CuriosApi;
/*     */ import top.theillusivec4.curios.api.SlotContext;
/*     */ import top.theillusivec4.curios.api.type.ISlotType;
/*     */ import top.theillusivec4.curios.api.type.capability.ICurio;
/*     */ import top.theillusivec4.curios.api.type.capability.ICuriosItemHandler;
/*     */ import top.theillusivec4.curios.api.type.inventory.ICurioStacksHandler;
/*     */ import top.theillusivec4.curios.api.type.inventory.IDynamicStackHandler;
/*     */ import top.theillusivec4.curios.api.type.util.ICuriosHelper;
/*     */ import top.theillusivec4.curios.api.type.util.ISlotHelper;
/*     */ import top.theillusivec4.curios.common.CuriosHelper;
/*     */ import top.theillusivec4.curios.common.inventory.CurioStacksHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CurioInventoryWrapper
/*     */   implements ICuriosItemHandler
/*     */ {
/*  75 */   Map<String, ICurioStacksHandler> curios = new LinkedHashMap<>();
/*  76 */   NonNullList<ItemStack> invalidStacks = NonNullList.m_122779_();
/*     */   Player wearer;
/*  78 */   Set<ICurioStacksHandler> updates = new HashSet<>();
/*     */   
/*     */   public CurioInventoryWrapper(Player playerEntity) {
/*  81 */     this.wearer = playerEntity;
/*  82 */     reset();
/*     */   }
/*     */ 
/*     */   
/*     */   public void reset() {
/*  87 */     ISlotHelper slotHelper = CuriosApi.getSlotHelper();
/*     */     
/*  89 */     if (slotHelper != null && this.wearer != null && 
/*  90 */       !this.wearer.m_20193_().m_5776_()) {
/*  91 */       this.curios.clear();
/*  92 */       this.invalidStacks.clear();
/*  93 */       SortedSet<ISlotType> sorted = new TreeSet<>(slotHelper.getSlotTypes((LivingEntity)this.wearer));
/*     */       
/*  95 */       for (ISlotType slotType : sorted) {
/*  96 */         this.curios.put(slotType.getIdentifier(), new CurioStacksHandler(this, slotType
/*  97 */               .getIdentifier(), slotType.getSize(), slotType
/*  98 */               .isVisible(), slotType.hasCosmetic()));
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int getSlots() {
/* 105 */     int totalSlots = 0;
/*     */     
/* 107 */     for (ICurioStacksHandler stacks : this.curios.values()) {
/* 108 */       totalSlots += stacks.getSlots();
/*     */     }
/* 110 */     return totalSlots;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getVisibleSlots() {
/* 115 */     int totalSlots = 0;
/*     */     
/* 117 */     for (ICurioStacksHandler stacks : this.curios.values()) {
/*     */       
/* 119 */       if (stacks.isVisible()) {
/* 120 */         totalSlots += stacks.getSlots();
/*     */       }
/*     */     } 
/* 123 */     return totalSlots;
/*     */   }
/*     */ 
/*     */   
/*     */   public Optional<ICurioStacksHandler> getStacksHandler(String identifier) {
/* 128 */     return Optional.ofNullable(this.curios.get(identifier));
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<String, ICurioStacksHandler> getCurios() {
/* 133 */     return Collections.unmodifiableMap(this.curios);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setCurios(Map<String, ICurioStacksHandler> curios) {
/* 138 */     this.curios = curios;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void growSlotType(String identifier, int amount) {
/* 144 */     if (amount > 0) {
/* 145 */       getStacksHandler(identifier).ifPresent(stackHandler -> stackHandler.grow(amount));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void shrinkSlotType(String identifier, int amount) {
/* 152 */     if (amount > 0) {
/* 153 */       getStacksHandler(identifier).ifPresent(stackHandler -> stackHandler.shrink(amount));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public LivingEntity getWearer() {
/* 160 */     return (LivingEntity)this.wearer;
/*     */   }
/*     */ 
/*     */   
/*     */   public void loseInvalidStack(ItemStack stack) {
/* 165 */     this.invalidStacks.add(stack);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void handleInvalidStacks() {
/* 171 */     if (this.wearer != null && !this.invalidStacks.isEmpty()) {
/* 172 */       this.invalidStacks.forEach(drop -> ItemHandlerHelper.giveItemToPlayer(this.wearer, drop));
/* 173 */       this.invalidStacks = NonNullList.m_122779_();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int getFortuneLevel(@Nullable LootContext lootContext) {
/* 179 */     int fortuneLevel = 0;
/* 180 */     for (Iterator<Map.Entry<String, ICurioStacksHandler>> iterator = getCurios().entrySet().iterator(); iterator.hasNext(); ) { Map.Entry<String, ICurioStacksHandler> entry = iterator.next();
/* 181 */       IDynamicStackHandler stacks = ((ICurioStacksHandler)entry.getValue()).getStacks();
/*     */       
/* 183 */       for (int i = 0; i < stacks.getSlots(); i++) {
/* 184 */         int index = i;
/* 185 */         fortuneLevel += ((Integer)CuriosApi.getCuriosHelper().getCurio(stacks.getStackInSlot(i)).map(curio -> {
/*     */               NonNullList<Boolean> renderStates = ((ICurioStacksHandler)entry.getValue()).getRenders();
/*     */               
/* 188 */               return Integer.valueOf(curio.getFortuneLevel(new SlotContext((String)entry.getKey(), (LivingEntity)this.wearer, index, false, (renderStates.size() > index && ((Boolean)renderStates.get(index)).booleanValue())), lootContext));
/*     */ 
/*     */             
/* 191 */             }).orElse(Integer.valueOf(0))).intValue();
/*     */       }  }
/*     */     
/* 194 */     return fortuneLevel;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getLootingLevel(DamageSource source, LivingEntity target, int baseLooting) {
/* 199 */     int lootingLevel = 0;
/* 200 */     for (Iterator<Map.Entry<String, ICurioStacksHandler>> iterator = getCurios().entrySet().iterator(); iterator.hasNext(); ) { Map.Entry<String, ICurioStacksHandler> entry = iterator.next();
/* 201 */       IDynamicStackHandler stacks = ((ICurioStacksHandler)entry.getValue()).getStacks();
/*     */       
/* 203 */       for (int i = 0; i < stacks.getSlots(); i++) {
/* 204 */         int index = i;
/* 205 */         lootingLevel += ((Integer)CuriosApi.getCuriosHelper().getCurio(stacks.getStackInSlot(i)).map(curio -> {
/*     */               NonNullList<Boolean> renderStates = ((ICurioStacksHandler)entry.getValue()).getRenders();
/*     */               
/* 208 */               return Integer.valueOf(curio.getLootingLevel(new SlotContext((String)entry.getKey(), (LivingEntity)this.wearer, index, false, (renderStates.size() > index && ((Boolean)renderStates.get(index)).booleanValue())), source, target, baseLooting));
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 213 */             }).orElse(Integer.valueOf(0))).intValue();
/*     */       }  }
/*     */     
/* 216 */     return lootingLevel;
/*     */   }
/*     */ 
/*     */   
/*     */   public ListTag saveInventory(boolean clear) {
/* 221 */     ListTag taglist = new ListTag();
/*     */     
/* 223 */     for (Map.Entry<String, ICurioStacksHandler> entry : this.curios.entrySet()) {
/* 224 */       CompoundTag tag = new CompoundTag();
/* 225 */       ICurioStacksHandler stacksHandler = entry.getValue();
/* 226 */       IDynamicStackHandler stacks = stacksHandler.getStacks();
/* 227 */       IDynamicStackHandler cosmetics = stacksHandler.getCosmeticStacks();
/* 228 */       tag.m_128365_("Stacks", (Tag)stacks.serializeNBT());
/* 229 */       tag.m_128365_("Cosmetics", (Tag)cosmetics.serializeNBT());
/* 230 */       tag.m_128359_("Identifier", entry.getKey());
/* 231 */       taglist.add(tag);
/*     */       
/* 233 */       if (clear) {
/*     */         int i;
/* 235 */         for (i = 0; i < stacks.getSlots(); i++) {
/* 236 */           stacks.setStackInSlot(i, ItemStack.f_41583_);
/*     */         }
/*     */         
/* 239 */         for (i = 0; i < cosmetics.getSlots(); i++) {
/* 240 */           cosmetics.setStackInSlot(i, ItemStack.f_41583_);
/*     */         }
/*     */       } 
/*     */     } 
/* 244 */     return taglist;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void loadInventory(ListTag data) {
/* 250 */     if (data != null)
/*     */     {
/* 252 */       for (int i = 0; i < data.size(); i++) {
/* 253 */         CompoundTag tag = data.m_128728_(i);
/* 254 */         String identifier = tag.m_128461_("Identifier");
/* 255 */         ICurioStacksHandler stacksHandler = this.curios.get(identifier);
/*     */         
/* 257 */         if (stacksHandler != null) {
/* 258 */           CompoundTag stacksData = tag.m_128469_("Stacks");
/* 259 */           ItemStackHandler loaded = new ItemStackHandler();
/* 260 */           IDynamicStackHandler stacks = stacksHandler.getStacks();
/*     */           
/* 262 */           if (!stacksData.m_128456_()) {
/* 263 */             loaded.deserializeNBT(stacksData);
/* 264 */             loadStacks(stacksHandler, loaded, stacks);
/*     */           } 
/* 266 */           stacksData = tag.m_128469_("Cosmetics");
/*     */           
/* 268 */           if (!stacksData.m_128456_()) {
/* 269 */             loaded.deserializeNBT(stacksData);
/* 270 */             stacks = stacksHandler.getCosmeticStacks();
/* 271 */             loadStacks(stacksHandler, loaded, stacks);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<ICurioStacksHandler> getUpdatingInventories() {
/* 280 */     return this.updates;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void addTransientSlotModifiers(Multimap<String, AttributeModifier> modifiers) {
/* 286 */     for (Map.Entry<String, Collection<AttributeModifier>> entry : (Iterable<Map.Entry<String, Collection<AttributeModifier>>>)modifiers.asMap().entrySet()) {
/* 287 */       String id = entry.getKey();
/*     */       
/* 289 */       for (AttributeModifier attributeModifier : entry.getValue()) {
/* 290 */         ICurioStacksHandler stacksHandler = this.curios.get(id);
/*     */         
/* 292 */         if (stacksHandler != null) {
/* 293 */           stacksHandler.addTransientModifier(attributeModifier);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void addPermanentSlotModifiers(Multimap<String, AttributeModifier> modifiers) {
/* 302 */     for (Map.Entry<String, Collection<AttributeModifier>> entry : (Iterable<Map.Entry<String, Collection<AttributeModifier>>>)modifiers.asMap().entrySet()) {
/* 303 */       String id = entry.getKey();
/*     */       
/* 305 */       for (AttributeModifier attributeModifier : entry.getValue()) {
/* 306 */         ICurioStacksHandler stacksHandler = this.curios.get(id);
/*     */         
/* 308 */         if (stacksHandler != null) {
/* 309 */           stacksHandler.addPermanentModifier(attributeModifier);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeSlotModifiers(Multimap<String, AttributeModifier> modifiers) {
/* 318 */     for (Map.Entry<String, Collection<AttributeModifier>> entry : (Iterable<Map.Entry<String, Collection<AttributeModifier>>>)modifiers.asMap().entrySet()) {
/* 319 */       String id = entry.getKey();
/*     */       
/* 321 */       for (AttributeModifier attributeModifier : entry.getValue()) {
/* 322 */         ICurioStacksHandler stacksHandler = this.curios.get(id);
/*     */         
/* 324 */         if (stacksHandler != null) {
/* 325 */           stacksHandler.removeModifier(attributeModifier.m_22209_());
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void clearSlotModifiers() {
/* 334 */     for (Map.Entry<String, ICurioStacksHandler> entry : this.curios.entrySet()) {
/* 335 */       ((ICurioStacksHandler)entry.getValue()).clearModifiers();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void clearCachedSlotModifiers() {
/* 341 */     HashMultimap hashMultimap = HashMultimap.create();
/*     */     
/* 343 */     for (Map.Entry<String, ICurioStacksHandler> entry : this.curios.entrySet()) {
/* 344 */       ICurioStacksHandler stacksHandler = entry.getValue();
/* 345 */       Set<AttributeModifier> modifiers = stacksHandler.getCachedModifiers();
/*     */       
/* 347 */       if (!modifiers.isEmpty()) {
/* 348 */         IDynamicStackHandler stacks = stacksHandler.getStacks();
/* 349 */         NonNullList<Boolean> renderStates = stacksHandler.getRenders();
/* 350 */         String id = entry.getKey();
/*     */         
/* 352 */         for (int i = 0; i < stacks.getSlots(); i++) {
/* 353 */           ItemStack stack = stacks.getStackInSlot(i);
/*     */           
/* 355 */           if (!stack.m_41619_()) {
/*     */             
/* 357 */             SlotContext slotContext = new SlotContext(id, getWearer(), i, false, (renderStates.size() > i && ((Boolean)renderStates.get(i)).booleanValue()));
/* 358 */             UUID uuid = UUID.nameUUIDFromBytes((id + id).getBytes());
/*     */             
/* 360 */             Multimap<Attribute, AttributeModifier> map = CuriosApi.getCuriosHelper().getAttributeModifiers(slotContext, uuid, stack);
/*     */             
/* 362 */             for (Attribute attribute : map.keySet()) {
/*     */               
/* 364 */               if (attribute instanceof CuriosHelper.SlotAttributeWrapper) { CuriosHelper.SlotAttributeWrapper wrapper = (CuriosHelper.SlotAttributeWrapper)attribute;
/* 365 */                 hashMultimap.putAll(wrapper.identifier, map.get(attribute)); }
/*     */             
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 373 */     for (Map.Entry<String, Collection<AttributeModifier>> entry : (Iterable<Map.Entry<String, Collection<AttributeModifier>>>)hashMultimap.asMap().entrySet()) {
/* 374 */       String id = entry.getKey();
/* 375 */       ICurioStacksHandler stacksHandler = this.curios.get(id);
/*     */       
/* 377 */       if (stacksHandler != null) {
/*     */         
/* 379 */         for (AttributeModifier attributeModifier : entry.getValue()) {
/* 380 */           stacksHandler.getCachedModifiers().remove(attributeModifier);
/*     */         }
/* 382 */         stacksHandler.clearCachedModifiers();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Multimap<String, AttributeModifier> getModifiers() {
/* 389 */     HashMultimap hashMultimap = HashMultimap.create();
/*     */     
/* 391 */     for (Map.Entry<String, ICurioStacksHandler> entry : this.curios.entrySet()) {
/* 392 */       hashMultimap.putAll(entry.getKey(), ((ICurioStacksHandler)entry.getValue()).getModifiers().values());
/*     */     }
/* 394 */     return (Multimap<String, AttributeModifier>)hashMultimap;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void loadStacks(ICurioStacksHandler stacksHandler, ItemStackHandler loaded, IDynamicStackHandler stacks) {
/* 400 */     for (int j = 0; j < stacksHandler.getSlots() && j < loaded.getSlots(); j++) {
/* 401 */       ItemStack stack = stacks.getStackInSlot(j);
/* 402 */       ItemStack loadedStack = loaded.getStackInSlot(j);
/*     */       
/* 404 */       if (stack.m_41619_()) {
/* 405 */         stacks.setStackInSlot(j, loadedStack);
/*     */       } else {
/* 407 */         loseInvalidStack(stack);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Tag writeTag() {
/* 414 */     CompoundTag compound = new CompoundTag();
/*     */     
/* 416 */     ListTag taglist = new ListTag();
/* 417 */     getCurios().forEach((key, stacksHandler) -> {
/*     */           CompoundTag tag = new CompoundTag();
/*     */           tag.m_128365_("StacksHandler", (Tag)stacksHandler.serializeNBT());
/*     */           tag.m_128359_("Identifier", key);
/*     */           taglist.add(tag);
/*     */         });
/* 423 */     compound.m_128365_("Curios", (Tag)taglist);
/* 424 */     return (Tag)compound;
/*     */   }
/*     */ 
/*     */   
/*     */   public void readTag(Tag nbt) {
/* 429 */     ListTag tagList = ((CompoundTag)nbt).m_128437_("Curios", 10);
/* 430 */     ISlotHelper slotHelper = CuriosApi.getSlotHelper();
/* 431 */     ICuriosHelper curiosHelper = CuriosApi.getCuriosHelper();
/* 432 */     LivingEntity livingEntity = getWearer();
/*     */     
/* 434 */     if (!tagList.isEmpty() && slotHelper != null) {
/* 435 */       Map<String, ICurioStacksHandler> curios = new LinkedHashMap<>();
/* 436 */       SortedMap<ISlotType, ICurioStacksHandler> sortedCurios = new TreeMap<>();
/*     */       
/* 438 */       SortedSet<ISlotType> sorted = new TreeSet<>(CuriosApi.getSlotHelper().getSlotTypes((LivingEntity)this.wearer));
/*     */       
/* 440 */       for (ISlotType slotType : sorted) {
/* 441 */         sortedCurios.put(slotType, new CurioStacksHandler(this, slotType
/* 442 */               .getIdentifier(), slotType.getSize(), slotType
/* 443 */               .isVisible(), slotType.hasCosmetic()));
/*     */       }
/*     */       
/* 446 */       for (int i = 0; i < tagList.size(); i++) {
/* 447 */         CompoundTag tag = tagList.m_128728_(i);
/* 448 */         String identifier = tag.m_128461_("Identifier");
/* 449 */         CurioStacksHandler prevStacksHandler = new CurioStacksHandler(this, identifier);
/* 450 */         prevStacksHandler.deserializeNBT(tag.m_128469_("StacksHandler"));
/*     */ 
/*     */         
/* 453 */         Optional<ISlotType> optionalType = CuriosApi.getSlotHelper().getSlotType(identifier);
/* 454 */         optionalType.ifPresent(type -> {
/*     */               CurioStacksHandler newStacksHandler = new CurioStacksHandler(this, type.getIdentifier(), type.getSize(), type.isVisible(), type.hasCosmetic());
/*     */               
/*     */               newStacksHandler.copyModifiers((ICurioStacksHandler)prevStacksHandler);
/*     */               
/*     */               int index = 0;
/*     */               
/*     */               while (index < newStacksHandler.getSlots() && index < prevStacksHandler.getSlots()) {
/*     */                 ItemStack prevStack = prevStacksHandler.getStacks().getStackInSlot(index);
/*     */                 
/*     */                 NonNullList<Boolean> renderStates = newStacksHandler.getRenders();
/* 465 */                 SlotContext slotContext = new SlotContext(identifier, livingEntity, index, false, (renderStates.size() > index && ((Boolean)renderStates.get(index)).booleanValue()));
/*     */                 
/*     */                 if (!prevStack.m_41619_()) {
/*     */                   if (curiosHelper.isStackValid(slotContext, prevStack)) {
/*     */                     newStacksHandler.getStacks().setStackInSlot(index, prevStack);
/*     */                   } else {
/*     */                     loseInvalidStack(prevStack);
/*     */                   } 
/*     */                 }
/*     */                 
/*     */                 ItemStack prevCosmetic = prevStacksHandler.getCosmeticStacks().getStackInSlot(index);
/*     */                 
/*     */                 slotContext = new SlotContext(identifier, livingEntity, index, true, true);
/*     */                 
/*     */                 if (!prevCosmetic.m_41619_()) {
/*     */                   if (curiosHelper.isStackValid(slotContext, prevCosmetic)) {
/*     */                     newStacksHandler.getCosmeticStacks().setStackInSlot(index, prevStacksHandler.getCosmeticStacks().getStackInSlot(index));
/*     */                   } else {
/*     */                     loseInvalidStack(prevCosmetic);
/*     */                   } 
/*     */                 }
/*     */                 
/*     */                 index++;
/*     */               } 
/*     */               
/*     */               while (index < prevStacksHandler.getSlots()) {
/*     */                 loseInvalidStack(prevStacksHandler.getStacks().getStackInSlot(index));
/*     */                 
/*     */                 loseInvalidStack(prevStacksHandler.getCosmeticStacks().getStackInSlot(index));
/*     */                 
/*     */                 index++;
/*     */               } 
/*     */               
/*     */               sortedCurios.put(type, newStacksHandler);
/*     */               
/*     */               int j = 0;
/*     */               
/*     */               while (j < newStacksHandler.getRenders().size() && j < prevStacksHandler.getRenders().size()) {
/*     */                 newStacksHandler.getRenders().set(j, prevStacksHandler.getRenders().get(j));
/*     */                 
/*     */                 j++;
/*     */               } 
/*     */             });
/* 508 */         if (optionalType.isEmpty()) {
/* 509 */           IDynamicStackHandler stackHandler = prevStacksHandler.getStacks();
/* 510 */           IDynamicStackHandler cosmeticStackHandler = prevStacksHandler.getCosmeticStacks();
/*     */           
/* 512 */           for (int j = 0; j < stackHandler.getSlots(); j++) {
/* 513 */             ItemStack stack = stackHandler.getStackInSlot(j);
/*     */             
/* 515 */             if (!stack.m_41619_()) {
/* 516 */               loseInvalidStack(stack);
/*     */             }
/*     */             
/* 519 */             ItemStack cosmeticStack = cosmeticStackHandler.getStackInSlot(j);
/*     */             
/* 521 */             if (!cosmeticStack.m_41619_()) {
/* 522 */               loseInvalidStack(cosmeticStack);
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/* 527 */       sortedCurios.forEach((slotType, stacksHandler) -> curios.put(slotType.getIdentifier(), stacksHandler));
/*     */       
/* 529 */       setCurios(curios);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\curios-309927-4590652.jar!\top\theillusivec4\curios\common\capability\CurioInventoryCapability$CurioInventoryWrapper.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */