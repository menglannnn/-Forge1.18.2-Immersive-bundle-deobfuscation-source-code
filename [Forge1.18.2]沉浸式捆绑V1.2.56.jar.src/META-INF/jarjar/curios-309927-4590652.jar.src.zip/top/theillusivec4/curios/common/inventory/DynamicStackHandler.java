/*    */ package top.theillusivec4.curios.common.inventory;
/*    */ 
/*    */ import javax.annotation.Nonnull;
/*    */ import net.minecraft.core.NonNullList;
/*    */ import net.minecraft.world.item.ItemStack;
/*    */ import net.minecraftforge.items.ItemStackHandler;
/*    */ import top.theillusivec4.curios.api.type.inventory.IDynamicStackHandler;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DynamicStackHandler
/*    */   extends ItemStackHandler
/*    */   implements IDynamicStackHandler
/*    */ {
/*    */   protected NonNullList<ItemStack> previousStacks;
/*    */   
/*    */   public DynamicStackHandler(int size) {
/* 33 */     super(size);
/* 34 */     this.previousStacks = NonNullList.m_122780_(size, ItemStack.f_41583_);
/*    */   }
/*    */ 
/*    */   
/*    */   public void setPreviousStackInSlot(int slot, @Nonnull ItemStack stack) {
/* 39 */     validateSlotIndex(slot);
/* 40 */     this.previousStacks.set(slot, stack);
/* 41 */     onContentsChanged(slot);
/*    */   }
/*    */ 
/*    */   
/*    */   public int getSlots() {
/* 46 */     return this.stacks.size();
/*    */   }
/*    */ 
/*    */   
/*    */   @Nonnull
/*    */   public ItemStack getPreviousStackInSlot(int slot) {
/* 52 */     validateSlotIndex(slot);
/* 53 */     return (ItemStack)this.previousStacks.get(slot);
/*    */   }
/*    */ 
/*    */   
/*    */   public void grow(int amount) {
/* 58 */     this.stacks = getResizedList(this.stacks.size() + amount, this.stacks);
/* 59 */     this.previousStacks = getResizedList(this.previousStacks.size() + amount, this.previousStacks);
/*    */   }
/*    */ 
/*    */   
/*    */   public void shrink(int amount) {
/* 64 */     this.stacks = getResizedList(this.stacks.size() - amount, this.stacks);
/* 65 */     this.previousStacks = getResizedList(this.previousStacks.size() - amount, this.previousStacks);
/*    */   }
/*    */   
/*    */   private static NonNullList<ItemStack> getResizedList(int size, NonNullList<ItemStack> stacks) {
/* 69 */     NonNullList<ItemStack> newList = NonNullList.m_122780_(Math.max(0, size), ItemStack.f_41583_);
/*    */     
/* 71 */     for (int i = 0; i < newList.size() && i < stacks.size(); i++) {
/* 72 */       newList.set(i, stacks.get(i));
/*    */     }
/* 74 */     return newList;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\curios-309927-4590652.jar!\top\theillusivec4\curios\common\inventory\DynamicStackHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */