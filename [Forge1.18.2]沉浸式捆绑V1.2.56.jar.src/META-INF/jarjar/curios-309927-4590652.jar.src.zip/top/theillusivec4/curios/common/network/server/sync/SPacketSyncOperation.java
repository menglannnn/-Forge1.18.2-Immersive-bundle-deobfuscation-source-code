/*     */ package top.theillusivec4.curios.common.network.server.sync;
/*     */ 
/*     */ import java.util.Set;
/*     */ import java.util.function.Supplier;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.multiplayer.ClientLevel;
/*     */ import net.minecraft.network.FriendlyByteBuf;
/*     */ import net.minecraft.world.entity.Entity;
/*     */ import net.minecraft.world.entity.LivingEntity;
/*     */ import net.minecraft.world.entity.player.Player;
/*     */ import net.minecraftforge.common.MinecraftForge;
/*     */ import net.minecraftforge.eventbus.api.Event;
/*     */ import net.minecraftforge.network.NetworkEvent;
/*     */ import top.theillusivec4.curios.api.CuriosApi;
/*     */ import top.theillusivec4.curios.api.event.SlotModifiersUpdatedEvent;
/*     */ import top.theillusivec4.curios.api.type.capability.ICuriosItemHandler;
/*     */ import top.theillusivec4.curios.common.inventory.container.CuriosContainer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SPacketSyncOperation
/*     */ {
/*     */   private int entityId;
/*     */   private String curioId;
/*     */   private int operation;
/*     */   private int amount;
/*     */   private boolean visible;
/*     */   private boolean cosmetic;
/*     */   
/*     */   public SPacketSyncOperation(int entityId, String curioId, Operation operation) {
/*  46 */     this(entityId, curioId, operation, 0);
/*     */   }
/*     */   
/*     */   public SPacketSyncOperation(int entityId, String curioId, Operation operation, int amount) {
/*  50 */     this(entityId, curioId, operation, amount, true, false);
/*     */   }
/*     */ 
/*     */   
/*     */   public SPacketSyncOperation(int entityId, String curioId, Operation operation, int amount, boolean visible, boolean cosmetic) {
/*  55 */     this.entityId = entityId;
/*  56 */     this.curioId = curioId;
/*  57 */     this.amount = amount;
/*  58 */     this.operation = operation.ordinal();
/*  59 */     this.visible = visible;
/*  60 */     this.cosmetic = cosmetic;
/*     */   }
/*     */   
/*     */   public static void encode(SPacketSyncOperation msg, FriendlyByteBuf buf) {
/*  64 */     buf.writeInt(msg.entityId);
/*  65 */     buf.m_130070_(msg.curioId);
/*  66 */     buf.writeInt(msg.operation);
/*  67 */     buf.writeInt(msg.amount);
/*  68 */     buf.writeBoolean(msg.visible);
/*  69 */     buf.writeBoolean(msg.cosmetic);
/*     */   }
/*     */   
/*     */   public static SPacketSyncOperation decode(FriendlyByteBuf buf) {
/*  73 */     return new SPacketSyncOperation(buf.readInt(), buf.m_130136_(25), 
/*  74 */         Operation.fromValue(buf.readInt()), buf.readInt(), buf.readBoolean(), buf.readBoolean());
/*     */   }
/*     */ 
/*     */   
/*     */   public static void handle(SPacketSyncOperation msg, Supplier<NetworkEvent.Context> ctx) {
/*  79 */     ((NetworkEvent.Context)ctx.get()).enqueueWork(() -> {
/*     */           ClientLevel world = (Minecraft.m_91087_()).f_91073_;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           if (world != null) {
/*     */             Entity entity = world.m_6815_(msg.entityId);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/*     */             if (entity instanceof LivingEntity) {
/*     */               LivingEntity livingEntity = (LivingEntity)entity;
/*     */ 
/*     */ 
/*     */ 
/*     */               
/*     */               CuriosApi.getCuriosHelper().getCuriosHandler(livingEntity).ifPresent(());
/*     */             } 
/*     */           } 
/*     */         });
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 107 */     ((NetworkEvent.Context)ctx.get()).setPacketHandled(true);
/*     */   }
/*     */   
/*     */   public enum Operation {
/* 111 */     SHRINK, GROW;
/*     */     
/*     */     public static Operation fromValue(int value) {
/*     */       try {
/* 115 */         return values()[value];
/* 116 */       } catch (ArrayIndexOutOfBoundsException e) {
/* 117 */         throw new IllegalArgumentException("Unknown operation value: " + value);
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\curios-309927-4590652.jar!\top\theillusivec4\curios\common\network\server\sync\SPacketSyncOperation.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */