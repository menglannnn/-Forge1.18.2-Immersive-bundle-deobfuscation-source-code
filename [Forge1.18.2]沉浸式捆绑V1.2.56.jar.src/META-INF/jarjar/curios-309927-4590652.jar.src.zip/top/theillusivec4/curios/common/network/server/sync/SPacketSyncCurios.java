/*     */ package top.theillusivec4.curios.common.network.server.sync;
/*     */ 
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import java.util.function.Supplier;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.multiplayer.ClientLevel;
/*     */ import net.minecraft.nbt.CompoundTag;
/*     */ import net.minecraft.network.FriendlyByteBuf;
/*     */ import net.minecraft.world.entity.Entity;
/*     */ import net.minecraft.world.entity.LivingEntity;
/*     */ import net.minecraftforge.network.NetworkEvent;
/*     */ import top.theillusivec4.curios.api.CuriosApi;
/*     */ import top.theillusivec4.curios.api.type.capability.ICuriosItemHandler;
/*     */ import top.theillusivec4.curios.api.type.inventory.ICurioStacksHandler;
/*     */ import top.theillusivec4.curios.common.inventory.CurioStacksHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SPacketSyncCurios
/*     */ {
/*     */   private int entityId;
/*     */   private int entrySize;
/*     */   private Map<String, CompoundTag> map;
/*     */   
/*     */   public SPacketSyncCurios(int entityId, Map<String, ICurioStacksHandler> map) {
/*  43 */     Map<String, CompoundTag> result = new LinkedHashMap<>();
/*     */     
/*  45 */     for (Map.Entry<String, ICurioStacksHandler> entry : map.entrySet()) {
/*  46 */       result.put(entry.getKey(), ((ICurioStacksHandler)entry.getValue()).getSyncTag());
/*     */     }
/*  48 */     this.entityId = entityId;
/*  49 */     this.entrySize = map.size();
/*  50 */     this.map = result;
/*     */   }
/*     */   
/*     */   public SPacketSyncCurios(Map<String, CompoundTag> map, int entityId) {
/*  54 */     this.entityId = entityId;
/*  55 */     this.entrySize = map.size();
/*  56 */     this.map = map;
/*     */   }
/*     */   
/*     */   public static void encode(SPacketSyncCurios msg, FriendlyByteBuf buf) {
/*  60 */     buf.writeInt(msg.entityId);
/*  61 */     buf.writeInt(msg.entrySize);
/*     */     
/*  63 */     for (Map.Entry<String, CompoundTag> entry : msg.map.entrySet()) {
/*  64 */       buf.m_130070_(entry.getKey());
/*  65 */       buf.m_130079_(entry.getValue());
/*     */     } 
/*     */   }
/*     */   
/*     */   public static SPacketSyncCurios decode(FriendlyByteBuf buf) {
/*  70 */     int entityId = buf.readInt();
/*  71 */     int entrySize = buf.readInt();
/*  72 */     Map<String, CompoundTag> map = new LinkedHashMap<>();
/*     */     
/*  74 */     for (int i = 0; i < entrySize; i++) {
/*  75 */       String key = buf.m_130136_(25);
/*  76 */       map.put(key, buf.m_130260_());
/*     */     } 
/*  78 */     return new SPacketSyncCurios(map, entityId);
/*     */   }
/*     */   
/*     */   public static void handle(SPacketSyncCurios msg, Supplier<NetworkEvent.Context> ctx) {
/*  82 */     ((NetworkEvent.Context)ctx.get()).enqueueWork(() -> {
/*     */           ClientLevel world = (Minecraft.m_91087_()).f_91073_;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           if (world != null) {
/*     */             Entity entity = world.m_6815_(msg.entityId);
/*     */ 
/*     */ 
/*     */ 
/*     */             
/*     */             if (entity instanceof LivingEntity) {
/*     */               CuriosApi.getCuriosHelper().getCuriosHandler((LivingEntity)entity).ifPresent(());
/*     */             }
/*     */           } 
/*     */         });
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 104 */     ((NetworkEvent.Context)ctx.get()).setPacketHandled(true);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\curios-309927-4590652.jar!\top\theillusivec4\curios\common\network\server\sync\SPacketSyncCurios.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */