/*     */ package top.theillusivec4.curios.common.event;
/*     */ 
/*     */ import com.google.common.collect.HashMultimap;
/*     */ import com.google.common.collect.ImmutableList;
/*     */ import com.google.common.collect.Multimap;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.UUID;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import java.util.function.Predicate;
/*     */ import net.minecraft.core.NonNullList;
/*     */ import net.minecraft.nbt.CompoundTag;
/*     */ import net.minecraft.resources.ResourceLocation;
/*     */ import net.minecraft.server.level.ServerLevel;
/*     */ import net.minecraft.server.level.ServerPlayer;
/*     */ import net.minecraft.server.players.PlayerList;
/*     */ import net.minecraft.util.Mth;
/*     */ import net.minecraft.util.Tuple;
/*     */ import net.minecraft.world.InteractionResult;
/*     */ import net.minecraft.world.damagesource.DamageSource;
/*     */ import net.minecraft.world.entity.Entity;
/*     */ import net.minecraft.world.entity.ExperienceOrb;
/*     */ import net.minecraft.world.entity.LivingEntity;
/*     */ import net.minecraft.world.entity.ai.attributes.Attribute;
/*     */ import net.minecraft.world.entity.ai.attributes.AttributeModifier;
/*     */ import net.minecraft.world.entity.item.ItemEntity;
/*     */ import net.minecraft.world.entity.player.Player;
/*     */ import net.minecraft.world.item.Item;
/*     */ import net.minecraft.world.item.ItemStack;
/*     */ import net.minecraft.world.item.enchantment.EnchantmentHelper;
/*     */ import net.minecraft.world.item.enchantment.Enchantments;
/*     */ import net.minecraft.world.level.GameRules;
/*     */ import net.minecraft.world.level.LevelReader;
/*     */ import net.minecraftforge.common.MinecraftForge;
/*     */ import net.minecraftforge.common.util.LazyOptional;
/*     */ import net.minecraftforge.event.AttachCapabilitiesEvent;
/*     */ import net.minecraftforge.event.TickEvent;
/*     */ import net.minecraftforge.event.entity.EntityJoinWorldEvent;
/*     */ import net.minecraftforge.event.entity.living.LivingDropsEvent;
/*     */ import net.minecraftforge.event.entity.living.LivingEvent;
/*     */ import net.minecraftforge.event.entity.living.LootingLevelEvent;
/*     */ import net.minecraftforge.event.entity.player.PlayerEvent;
/*     */ import net.minecraftforge.event.entity.player.PlayerInteractEvent;
/*     */ import net.minecraftforge.event.entity.player.PlayerXpEvent;
/*     */ import net.minecraftforge.event.world.BlockEvent;
/*     */ import net.minecraftforge.eventbus.api.Event;
/*     */ import net.minecraftforge.eventbus.api.EventPriority;
/*     */ import net.minecraftforge.eventbus.api.SubscribeEvent;
/*     */ import net.minecraftforge.items.ItemHandlerHelper;
/*     */ import net.minecraftforge.network.PacketDistributor;
/*     */ import top.theillusivec4.curios.api.CuriosApi;
/*     */ import top.theillusivec4.curios.api.CuriosCapability;
/*     */ import top.theillusivec4.curios.api.SlotContext;
/*     */ import top.theillusivec4.curios.api.event.CurioChangeEvent;
/*     */ import top.theillusivec4.curios.api.event.CurioDropsEvent;
/*     */ import top.theillusivec4.curios.api.event.CurioEquipEvent;
/*     */ import top.theillusivec4.curios.api.event.DropRulesEvent;
/*     */ import top.theillusivec4.curios.api.type.ISlotType;
/*     */ import top.theillusivec4.curios.api.type.capability.ICurio;
/*     */ import top.theillusivec4.curios.api.type.capability.ICurioItem;
/*     */ import top.theillusivec4.curios.api.type.capability.ICuriosItemHandler;
/*     */ import top.theillusivec4.curios.api.type.inventory.ICurioStacksHandler;
/*     */ import top.theillusivec4.curios.api.type.inventory.IDynamicStackHandler;
/*     */ import top.theillusivec4.curios.api.type.util.ICuriosHelper;
/*     */ import top.theillusivec4.curios.common.CuriosHelper;
/*     */ import top.theillusivec4.curios.common.capability.CurioInventoryCapability;
/*     */ import top.theillusivec4.curios.common.capability.CurioItemCapability;
/*     */ import top.theillusivec4.curios.common.capability.ItemizedCurioCapability;
/*     */ import top.theillusivec4.curios.common.network.NetworkHandler;
/*     */ import top.theillusivec4.curios.common.network.server.SPacketSetIcons;
/*     */ import top.theillusivec4.curios.common.network.server.sync.SPacketSyncCurios;
/*     */ import top.theillusivec4.curios.common.network.server.sync.SPacketSyncModifiers;
/*     */ import top.theillusivec4.curios.common.network.server.sync.SPacketSyncStack;
/*     */ import top.theillusivec4.curios.common.util.EquipCurioTrigger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CuriosEventHandler
/*     */ {
/*     */   public static boolean dirtyTags = false;
/*     */   
/*     */   private static void handleDrops(String identifier, LivingEntity livingEntity, List<Tuple<Predicate<ItemStack>, ICurio.DropRule>> dropRules, NonNullList<Boolean> renders, IDynamicStackHandler stacks, boolean cosmetic, Collection<ItemEntity> drops, boolean keepInventory, LivingDropsEvent evt) {
/* 109 */     for (int i = 0; i < stacks.getSlots(); i++) {
/* 110 */       ItemStack stack = stacks.getStackInSlot(i);
/*     */       
/* 112 */       SlotContext slotContext = new SlotContext(identifier, livingEntity, i, cosmetic, (renders.size() > i && ((Boolean)renders.get(i)).booleanValue()));
/*     */       
/* 114 */       if (!stack.m_41619_()) {
/* 115 */         ICurio.DropRule dropRuleOverride = null;
/*     */         
/* 117 */         for (Tuple<Predicate<ItemStack>, ICurio.DropRule> override : dropRules) {
/*     */           
/* 119 */           if (((Predicate<ItemStack>)override.m_14418_()).test(stack)) {
/* 120 */             dropRuleOverride = (ICurio.DropRule)override.m_14419_();
/*     */           }
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/* 126 */         ICurio.DropRule dropRule = (dropRuleOverride != null) ? dropRuleOverride : CuriosApi.getCuriosHelper().getCurio(stack).map(curio -> curio.getDropRule(slotContext, evt.getSource(), evt.getLootingLevel(), evt.isRecentlyHit())).orElse(ICurio.DropRule.DEFAULT);
/*     */         
/* 128 */         if ((dropRule != ICurio.DropRule.DEFAULT || !keepInventory) && dropRule != ICurio.DropRule.ALWAYS_KEEP) {
/*     */ 
/*     */ 
/*     */           
/* 132 */           if (!EnchantmentHelper.m_44924_(stack) && dropRule != ICurio.DropRule.DESTROY) {
/* 133 */             drops.add(getDroppedItem(stack, livingEntity));
/*     */           }
/* 135 */           stacks.setStackInSlot(i, ItemStack.f_41583_);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   private static ItemEntity getDroppedItem(ItemStack droppedItem, LivingEntity livingEntity) {
/* 141 */     double d0 = livingEntity.m_20186_() - 0.30000001192092896D + livingEntity.m_20192_();
/*     */     
/* 143 */     ItemEntity entityitem = new ItemEntity(livingEntity.f_19853_, livingEntity.m_20185_(), d0, livingEntity.m_20189_(), droppedItem);
/* 144 */     entityitem.m_32010_(40);
/* 145 */     float f = livingEntity.f_19853_.f_46441_.nextFloat() * 0.5F;
/* 146 */     float f1 = livingEntity.f_19853_.f_46441_.nextFloat() * 6.2831855F;
/* 147 */     entityitem.m_20334_((-Mth.m_14031_(f1) * f), 0.20000000298023224D, (Mth.m_14089_(f1) * f));
/* 148 */     return entityitem;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean handleMending(Player player, IDynamicStackHandler stacks, PlayerXpEvent.PickupXp evt) {
/* 154 */     for (int i = 0; i < stacks.getSlots(); i++) {
/* 155 */       ItemStack stack = stacks.getStackInSlot(i);
/*     */       
/* 157 */       if (!stack.m_41619_() && 
/* 158 */         EnchantmentHelper.m_44843_(Enchantments.f_44962_, stack) > 0 && stack
/* 159 */         .m_41768_()) {
/* 160 */         evt.setCanceled(true);
/* 161 */         ExperienceOrb orb = evt.getOrb();
/* 162 */         player.f_36101_ = 2;
/* 163 */         player.m_7938_((Entity)orb, 1);
/* 164 */         int toRepair = Math.min(orb.f_20770_ * 2, stack.m_41773_());
/* 165 */         orb.f_20770_ -= toRepair / 2;
/* 166 */         stack.m_41721_(stack.m_41773_() - toRepair);
/*     */         
/* 168 */         if (orb.f_20770_ > 0) {
/* 169 */           player.m_6756_(orb.f_20770_);
/*     */         }
/* 171 */         orb.m_142687_(Entity.RemovalReason.KILLED);
/* 172 */         return true;
/*     */       } 
/*     */     } 
/* 175 */     return false;
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void playerLoggedIn(PlayerEvent.PlayerLoggedInEvent evt) {
/* 180 */     Player playerEntity = evt.getPlayer();
/*     */     
/* 182 */     if (playerEntity instanceof ServerPlayer) {
/* 183 */       Collection<ISlotType> slotTypes = CuriosApi.getSlotHelper().getSlotTypes();
/* 184 */       Map<String, ResourceLocation> icons = new HashMap<>();
/* 185 */       slotTypes.forEach(type -> icons.put(type.getIdentifier(), type.getIcon()));
/* 186 */       NetworkHandler.INSTANCE
/* 187 */         .send(PacketDistributor.PLAYER.with(() -> (ServerPlayer)playerEntity), new SPacketSetIcons(icons));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void attachEntitiesCapabilities(AttachCapabilitiesEvent<Entity> evt) {
/* 195 */     if (evt.getObject() instanceof Player) {
/* 196 */       evt.addCapability(CuriosCapability.ID_INVENTORY, 
/* 197 */           CurioInventoryCapability.createProvider((Player)evt.getObject()));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void attachStackCapabilities(AttachCapabilitiesEvent<ItemStack> evt) {
/* 207 */     ItemStack stack = (ItemStack)evt.getObject();
/*     */     
/* 209 */     Item item = stack.m_41720_(); if (item instanceof ICurioItem) { ICurioItem itemCurio = (ICurioItem)item;
/*     */       
/* 211 */       if (itemCurio.hasCurioCapability(stack)) {
/* 212 */         ItemizedCurioCapability itemizedCapability = new ItemizedCurioCapability(itemCurio, stack);
/* 213 */         evt.addCapability(CuriosCapability.ID_ITEM, 
/* 214 */             CurioItemCapability.createProvider((ICurio)itemizedCapability));
/*     */       }  }
/*     */   
/*     */   }
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void entityJoinWorld(EntityJoinWorldEvent evt) {
/* 222 */     Entity entity = evt.getEntity();
/*     */     
/* 224 */     if (entity instanceof ServerPlayer) { ServerPlayer serverPlayerEntity = (ServerPlayer)entity;
/* 225 */       CuriosApi.getCuriosHelper().getCuriosHandler((LivingEntity)serverPlayerEntity).ifPresent(handler -> {
/*     */             ServerPlayer mp = (ServerPlayer)entity;
/*     */             NetworkHandler.INSTANCE.send(PacketDistributor.PLAYER.with(()), new SPacketSyncCurios(mp.m_142049_(), handler.getCurios()));
/*     */           }); }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void playerStartTracking(PlayerEvent.StartTracking evt) {
/* 236 */     Entity target = evt.getTarget();
/* 237 */     Player player = evt.getPlayer();
/*     */     
/* 239 */     if (player instanceof ServerPlayer && target instanceof LivingEntity) { LivingEntity livingBase = (LivingEntity)target;
/* 240 */       CuriosApi.getCuriosHelper().getCuriosHandler(livingBase).ifPresent(handler -> NetworkHandler.INSTANCE.send(PacketDistributor.PLAYER.with(()), new SPacketSyncCurios(target.m_142049_(), handler.getCurios()))); }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void playerClone(PlayerEvent.Clone evt) {
/* 249 */     Player player = evt.getPlayer();
/* 250 */     Player oldPlayer = evt.getOriginal();
/* 251 */     oldPlayer.revive();
/*     */     
/* 253 */     LazyOptional<ICuriosItemHandler> oldHandler = CuriosApi.getCuriosHelper().getCuriosHandler((LivingEntity)oldPlayer);
/*     */     
/* 255 */     LazyOptional<ICuriosItemHandler> newHandler = CuriosApi.getCuriosHelper().getCuriosHandler((LivingEntity)player);
/* 256 */     oldHandler.ifPresent(oldCurios -> newHandler.ifPresent(()));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent(priority = EventPriority.HIGHEST)
/*     */   public void playerDrops(LivingDropsEvent evt) {
/* 263 */     LivingEntity livingEntity = evt.getEntityLiving();
/*     */     
/* 265 */     if (!livingEntity.m_5833_())
/*     */     {
/* 267 */       CuriosApi.getCuriosHelper().getCuriosHandler(livingEntity).ifPresent(handler -> {
/*     */             Collection<ItemEntity> drops = evt.getDrops();
/*     */             Collection<ItemEntity> curioDrops = new ArrayList<>();
/*     */             Map<String, ICurioStacksHandler> curios = handler.getCurios();
/*     */             DropRulesEvent dropRulesEvent = new DropRulesEvent(livingEntity, handler, evt.getSource(), evt.getLootingLevel(), evt.isRecentlyHit());
/*     */             MinecraftForge.EVENT_BUS.post((Event)dropRulesEvent);
/*     */             ImmutableList immutableList = dropRulesEvent.getOverrides();
/*     */             boolean keepInventory = livingEntity.f_19853_.m_46469_().m_46207_(GameRules.f_46133_);
/*     */             curios.forEach(());
/*     */             if (!MinecraftForge.EVENT_BUS.post((Event)new CurioDropsEvent(livingEntity, handler, evt.getSource(), curioDrops, evt.getLootingLevel(), evt.isRecentlyHit()))) {
/*     */               drops.addAll(curioDrops);
/*     */             }
/*     */           });
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void playerXPPickUp(PlayerXpEvent.PickupXp evt) {
/* 298 */     Player player = evt.getPlayer();
/*     */     
/* 300 */     if (!player.f_19853_.f_46443_) {
/* 301 */       CuriosApi.getCuriosHelper().getCuriosHandler((LivingEntity)player).ifPresent(handler -> {
/*     */             Map<String, ICurioStacksHandler> curios = handler.getCurios();
/*     */             for (ICurioStacksHandler stacksHandler : curios.values()) {
/*     */               if (handleMending(player, stacksHandler.getStacks(), evt) || handleMending(player, stacksHandler.getCosmeticStacks(), evt)) {
/*     */                 return;
/*     */               }
/*     */             } 
/*     */           });
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void curioRightClick(PlayerInteractEvent.RightClickItem evt) {
/* 316 */     Player player = evt.getPlayer();
/* 317 */     ItemStack stack = evt.getItemStack();
/* 318 */     ICuriosHelper curiosHelper = CuriosApi.getCuriosHelper();
/* 319 */     curiosHelper.getCurio(stack).ifPresent(curio -> curiosHelper.getCuriosHandler((LivingEntity)player).ifPresent(()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void worldTick(TickEvent.WorldTickEvent evt) {
/* 366 */     if (evt.world instanceof ServerLevel && dirtyTags) {
/* 367 */       PlayerList list = ((ServerLevel)evt.world).m_142572_().m_6846_();
/* 368 */       ICuriosHelper curiosHelper = CuriosApi.getCuriosHelper();
/*     */       
/* 370 */       for (Iterator<ServerPlayer> iterator = list.m_11314_().iterator(); iterator.hasNext(); ) { ServerPlayer player = iterator.next();
/* 371 */         curiosHelper.getCuriosHandler((LivingEntity)player).ifPresent(handler -> {
/*     */               for (Map.Entry<String, ICurioStacksHandler> entry : (Iterable<Map.Entry<String, ICurioStacksHandler>>)handler.getCurios().entrySet()) {
/*     */                 ICurioStacksHandler stacksHandler = entry.getValue();
/*     */                 
/*     */                 String id = entry.getKey();
/*     */                 
/*     */                 IDynamicStackHandler stacks = stacksHandler.getStacks();
/*     */                 
/*     */                 IDynamicStackHandler cosmeticStacks = stacksHandler.getCosmeticStacks();
/*     */                 replaceInvalidStacks(curiosHelper, player, id, stacks, false, stacksHandler.getRenders());
/*     */                 replaceInvalidStacks(curiosHelper, player, id, cosmeticStacks, true, stacksHandler.getRenders());
/*     */               } 
/*     */             }); }
/*     */       
/* 385 */       dirtyTags = false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static void replaceInvalidStacks(ICuriosHelper curiosHelper, ServerPlayer player, String id, IDynamicStackHandler stacks, boolean cosmetic, NonNullList<Boolean> renders) {
/* 392 */     for (int i = 0; i < stacks.getSlots(); i++) {
/* 393 */       ItemStack stack = stacks.getStackInSlot(i);
/*     */       
/* 395 */       SlotContext slotContext = new SlotContext(id, (LivingEntity)player, i, cosmetic, (renders.size() > i && ((Boolean)renders.get(i)).booleanValue()));
/*     */       
/* 397 */       if (!stack.m_41619_() && !curiosHelper.isStackValid(slotContext, stack)) {
/* 398 */         stacks.setStackInSlot(i, ItemStack.f_41583_);
/* 399 */         ItemHandlerHelper.giveItemToPlayer((Player)player, stack);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void looting(LootingLevelEvent evt) {
/* 406 */     DamageSource source = evt.getDamageSource();
/*     */     
/* 408 */     if (source != null) { Entity entity = source.m_7639_(); if (entity instanceof LivingEntity) { LivingEntity living = (LivingEntity)entity;
/* 409 */         evt.setLootingLevel(evt.getLootingLevel() + (
/* 410 */             (Integer)CuriosApi.getCuriosHelper().getCuriosHandler(living).map(handler -> Integer.valueOf(handler.getLootingLevel(source, evt.getEntityLiving(), evt.getLootingLevel())))
/* 411 */             .orElse(Integer.valueOf(0))).intValue()); }
/*     */        }
/*     */   
/*     */   }
/*     */   @SubscribeEvent(priority = EventPriority.HIGHEST)
/*     */   public void onBreakBlock(BlockEvent.BreakEvent evt) {
/* 417 */     Player player = evt.getPlayer();
/* 418 */     AtomicInteger fortuneLevel = new AtomicInteger();
/* 419 */     ICuriosHelper curiosHelper = CuriosApi.getCuriosHelper();
/* 420 */     curiosHelper.getCuriosHandler((LivingEntity)player).ifPresent(handler -> {
/*     */           for (Map.Entry<String, ICurioStacksHandler> entry : (Iterable<Map.Entry<String, ICurioStacksHandler>>)handler.getCurios().entrySet()) {
/*     */             IDynamicStackHandler stacks = ((ICurioStacksHandler)entry.getValue()).getStacks();
/*     */             
/*     */             for (int i = 0; i < stacks.getSlots(); i++) {
/*     */               NonNullList<Boolean> renderStates = ((ICurioStacksHandler)entry.getValue()).getRenders();
/*     */               
/* 427 */               SlotContext slotContext = new SlotContext(entry.getKey(), (LivingEntity)player, i, false, (renderStates.size() > i && ((Boolean)renderStates.get(i)).booleanValue()));
/*     */ 
/*     */ 
/*     */               
/*     */               fortuneLevel.addAndGet(((Integer)curiosHelper.getCurio(stacks.getStackInSlot(i)).map(()).orElse(Integer.valueOf(0))).intValue());
/*     */             } 
/*     */           } 
/*     */         });
/*     */ 
/*     */     
/* 437 */     int bonusLevel = EnchantmentHelper.m_44843_(Enchantments.f_44987_, player.m_21205_());
/*     */     
/* 439 */     int silklevel = EnchantmentHelper.m_44843_(Enchantments.f_44985_, player.m_21205_());
/* 440 */     evt.setExpToDrop(evt.getState()
/* 441 */         .getExpDrop((LevelReader)evt.getWorld(), evt.getPos(), bonusLevel + fortuneLevel.get(), silklevel));
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void tick(LivingEvent.LivingUpdateEvent evt) {
/* 446 */     LivingEntity livingEntity = evt.getEntityLiving();
/*     */     
/* 448 */     CuriosApi.getCuriosHelper().getCuriosHandler(livingEntity).ifPresent(handler -> {
/*     */           handler.clearCachedSlotModifiers();
/*     */           
/*     */           handler.handleInvalidStacks();
/*     */           
/*     */           Map<String, ICurioStacksHandler> curios = handler.getCurios();
/*     */           for (Map.Entry<String, ICurioStacksHandler> entry : curios.entrySet()) {
/*     */             ICurioStacksHandler stacksHandler = entry.getValue();
/*     */             String identifier = entry.getKey();
/*     */             IDynamicStackHandler stackHandler = stacksHandler.getStacks();
/*     */             IDynamicStackHandler cosmeticStackHandler = stacksHandler.getCosmeticStacks();
/*     */             for (int i = 0; i < stacksHandler.getSlots(); i++) {
/*     */               NonNullList<Boolean> renderStates = stacksHandler.getRenders();
/* 461 */               SlotContext slotContext = new SlotContext(identifier, livingEntity, i, false, (renderStates.size() > i && ((Boolean)renderStates.get(i)).booleanValue()));
/*     */               
/*     */               ItemStack stack = stackHandler.getStackInSlot(i);
/*     */               
/*     */               LazyOptional<ICurio> currentCurio = CuriosApi.getCuriosHelper().getCurio(stack);
/*     */               
/*     */               int index = i;
/*     */               
/*     */               if (!stack.m_41619_()) {
/*     */                 stack.m_41666_(livingEntity.f_19853_, (Entity)livingEntity, -1, false);
/*     */                 
/*     */                 currentCurio.ifPresent(());
/*     */                 
/*     */                 if (livingEntity.f_19853_.f_46443_) {
/*     */                   currentCurio.ifPresent(());
/*     */                 }
/*     */               } 
/*     */               if (!livingEntity.f_19853_.f_46443_) {
/*     */                 ItemStack prevStack = stackHandler.getPreviousStackInSlot(i);
/*     */                 if (!ItemStack.m_41728_(stack, prevStack)) {
/*     */                   LazyOptional<ICurio> prevCurio = CuriosApi.getCuriosHelper().getCurio(prevStack);
/* 482 */                   syncCurios(livingEntity, stack, currentCurio, prevCurio, identifier, index, false, (renderStates.size() > index && ((Boolean)renderStates.get(index)).booleanValue()), SPacketSyncStack.HandlerType.EQUIPMENT);
/*     */                   MinecraftForge.EVENT_BUS.post((Event)new CurioChangeEvent(livingEntity, identifier, i, prevStack, stack));
/*     */                   UUID uuid = UUID.nameUUIDFromBytes((identifier + identifier).getBytes());
/*     */                   if (!prevStack.m_41619_()) {
/*     */                     Multimap<Attribute, AttributeModifier> map = CuriosApi.getCuriosHelper().getAttributeModifiers(slotContext, uuid, prevStack);
/*     */                     HashMultimap hashMultimap = HashMultimap.create();
/*     */                     Set<CuriosHelper.SlotAttributeWrapper> toRemove = new HashSet<>();
/*     */                     for (Attribute attribute : map.keySet()) {
/*     */                       if (attribute instanceof CuriosHelper.SlotAttributeWrapper) {
/*     */                         CuriosHelper.SlotAttributeWrapper wrapper = (CuriosHelper.SlotAttributeWrapper)attribute;
/*     */                         hashMultimap.putAll(wrapper.identifier, map.get(attribute));
/*     */                         toRemove.add(wrapper);
/*     */                       } 
/*     */                     } 
/*     */                     for (Attribute attribute : toRemove) {
/*     */                       map.removeAll(attribute);
/*     */                     }
/*     */                     livingEntity.m_21204_().m_22161_(map);
/*     */                     handler.removeSlotModifiers((Multimap)hashMultimap);
/*     */                     prevCurio.ifPresent(());
/*     */                   } 
/*     */                   if (!stack.m_41619_()) {
/*     */                     Multimap<Attribute, AttributeModifier> map = CuriosApi.getCuriosHelper().getAttributeModifiers(slotContext, uuid, stack);
/*     */                     HashMultimap hashMultimap = HashMultimap.create();
/*     */                     Set<CuriosHelper.SlotAttributeWrapper> toRemove = new HashSet<>();
/*     */                     for (Attribute attribute : map.keySet()) {
/*     */                       if (attribute instanceof CuriosHelper.SlotAttributeWrapper) {
/*     */                         CuriosHelper.SlotAttributeWrapper wrapper = (CuriosHelper.SlotAttributeWrapper)attribute;
/*     */                         hashMultimap.putAll(wrapper.identifier, map.get(attribute));
/*     */                         toRemove.add(wrapper);
/*     */                       } 
/*     */                     } 
/*     */                     for (Attribute attribute : toRemove) {
/*     */                       map.removeAll(attribute);
/*     */                     }
/*     */                     livingEntity.m_21204_().m_22178_(map);
/*     */                     handler.addTransientSlotModifiers((Multimap)hashMultimap);
/*     */                     currentCurio.ifPresent(());
/*     */                     if (livingEntity instanceof ServerPlayer) {
/*     */                       EquipCurioTrigger.INSTANCE.trigger((ServerPlayer)livingEntity, stack, (ServerLevel)livingEntity.f_19853_, livingEntity.m_20185_(), livingEntity.m_20186_(), livingEntity.m_20189_());
/*     */                     }
/*     */                   } 
/*     */                   stackHandler.setPreviousStackInSlot(i, stack.m_41777_());
/*     */                 } 
/*     */                 ItemStack cosmeticStack = cosmeticStackHandler.getStackInSlot(i);
/*     */                 ItemStack prevCosmeticStack = cosmeticStackHandler.getPreviousStackInSlot(i);
/*     */                 if (!ItemStack.m_41728_(cosmeticStack, prevCosmeticStack)) {
/*     */                   syncCurios(livingEntity, cosmeticStack, CuriosApi.getCuriosHelper().getCurio(cosmeticStack), CuriosApi.getCuriosHelper().getCurio(prevCosmeticStack), identifier, index, true, true, SPacketSyncStack.HandlerType.COSMETIC);
/*     */                   cosmeticStackHandler.setPreviousStackInSlot(index, cosmeticStack.m_41777_());
/*     */                 } 
/*     */                 Set<ICurioStacksHandler> updates = handler.getUpdatingInventories();
/*     */                 if (!updates.isEmpty()) {
/*     */                   NetworkHandler.INSTANCE.send(PacketDistributor.TRACKING_ENTITY_AND_SELF.with(()), new SPacketSyncModifiers(livingEntity.m_142049_(), updates));
/*     */                   updates.clear();
/*     */                 } 
/*     */               } 
/*     */             } 
/*     */           } 
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void syncCurios(LivingEntity livingEntity, ItemStack stack, LazyOptional<ICurio> currentCurio, LazyOptional<ICurio> prevCurio, String identifier, int index, boolean cosmetic, boolean visible, SPacketSyncStack.HandlerType type) {
/* 567 */     SlotContext slotContext = new SlotContext(identifier, livingEntity, index, cosmetic, visible);
/*     */     
/* 569 */     boolean syncable = (((Boolean)currentCurio.map(curio -> Boolean.valueOf(curio.canSync(slotContext))).orElse(Boolean.valueOf(false))).booleanValue() || ((Boolean)prevCurio.map(curio -> Boolean.valueOf(curio.canSync(slotContext))).orElse(Boolean.valueOf(false))).booleanValue());
/*     */ 
/*     */ 
/*     */     
/* 573 */     CompoundTag syncTag = syncable ? currentCurio.map(curio -> { CompoundTag tag = curio.writeSyncData(slotContext); return (tag != null) ? tag : new CompoundTag(); }).orElse(new CompoundTag()) : new CompoundTag();
/* 574 */     NetworkHandler.INSTANCE
/* 575 */       .send(PacketDistributor.TRACKING_ENTITY_AND_SELF.with(() -> livingEntity), new SPacketSyncStack(livingEntity
/* 576 */           .m_142049_(), identifier, index, stack, type, syncTag));
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\curios-309927-4590652.jar!\top\theillusivec4\curios\common\event\CuriosEventHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */