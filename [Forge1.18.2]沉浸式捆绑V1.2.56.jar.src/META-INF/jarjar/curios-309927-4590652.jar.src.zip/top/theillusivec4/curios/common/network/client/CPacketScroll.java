/*    */ package top.theillusivec4.curios.common.network.client;
/*    */ 
/*    */ import java.util.function.Supplier;
/*    */ import net.minecraft.network.FriendlyByteBuf;
/*    */ import net.minecraft.server.level.ServerPlayer;
/*    */ import net.minecraft.world.inventory.AbstractContainerMenu;
/*    */ import net.minecraftforge.network.NetworkEvent;
/*    */ import top.theillusivec4.curios.common.inventory.container.CuriosContainer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CPacketScroll
/*    */ {
/*    */   private int windowId;
/*    */   private int index;
/*    */   
/*    */   public CPacketScroll(int windowId, int index) {
/* 35 */     this.windowId = windowId;
/* 36 */     this.index = index;
/*    */   }
/*    */   
/*    */   public static void encode(CPacketScroll msg, FriendlyByteBuf buf) {
/* 40 */     buf.writeInt(msg.windowId);
/* 41 */     buf.writeInt(msg.index);
/*    */   }
/*    */   
/*    */   public static CPacketScroll decode(FriendlyByteBuf buf) {
/* 45 */     return new CPacketScroll(buf.readInt(), buf.readInt());
/*    */   }
/*    */   
/*    */   public static void handle(CPacketScroll msg, Supplier<NetworkEvent.Context> ctx) {
/* 49 */     ((NetworkEvent.Context)ctx.get()).enqueueWork(() -> {
/*    */           ServerPlayer sender = ((NetworkEvent.Context)ctx.get()).getSender();
/*    */           
/*    */           if (sender != null) {
/*    */             AbstractContainerMenu container = sender.f_36096_;
/*    */             
/*    */             if (container instanceof CuriosContainer && container.f_38840_ == msg.windowId) {
/*    */               ((CuriosContainer)container).scrollToIndex(msg.index);
/*    */             }
/*    */           } 
/*    */         });
/* 60 */     ((NetworkEvent.Context)ctx.get()).setPacketHandled(true);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\curios-309927-4590652.jar!\top\theillusivec4\curios\common\network\client\CPacketScroll.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */