/*    */ package top.theillusivec4.curios.common;
/*    */ 
/*    */ import com.electronwill.nightconfig.core.CommentedConfig;
/*    */ import com.electronwill.nightconfig.core.UnmodifiableConfig;
/*    */ import com.electronwill.nightconfig.core.conversion.ObjectConverter;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import java.util.function.Function;
/*    */ import java.util.function.Supplier;
/*    */ import net.minecraftforge.common.ForgeConfigSpec;
/*    */ import org.apache.commons.lang3.tuple.Pair;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CuriosConfig
/*    */ {
/*    */   public static final ForgeConfigSpec SERVER_SPEC;
/*    */   public static final Server SERVER;
/* 34 */   public static List<CuriosSettings.CuriosSetting> curios = new ArrayList<>();
/*    */ 
/*    */   
/*    */   static {
/* 38 */     Pair<Server, ForgeConfigSpec> specPair = (new ForgeConfigSpec.Builder()).configure(Server::new);
/* 39 */     SERVER_SPEC = (ForgeConfigSpec)specPair.getRight();
/* 40 */     SERVER = (Server)specPair.getLeft();
/*    */   }
/*    */   
/*    */   public static void transformCurios(CommentedConfig configData) {
/* 44 */     SERVER.curiosSettings = (CuriosSettings)(new ObjectConverter()).toObject((UnmodifiableConfig)configData, CuriosSettings::new);
/* 45 */     curios = SERVER.curiosSettings.curiosSettings;
/*    */   }
/*    */   
/*    */   public static class Server
/*    */   {
/*    */     public CuriosConfig.CuriosSettings curiosSettings;
/*    */     
/*    */     public Server(ForgeConfigSpec.Builder builder) {
/* 53 */       builder.comment("List of curio slot type settings")
/* 54 */         .define("curiosSettings", new ArrayList());
/* 55 */       builder.build();
/*    */     }
/*    */   }
/*    */   
/*    */   public static class CuriosSettings {
/*    */     public List<CuriosSetting> curiosSettings;
/*    */     
/*    */     public static class CuriosSetting {
/*    */       public String identifier;
/*    */       public String icon;
/*    */       public Integer priority;
/*    */       public Integer size;
/*    */       public Boolean visible;
/*    */       public Boolean hasCosmetic;
/*    */       public Boolean override;
/*    */     }
/*    */   }
/*    */   
/*    */   public static class CuriosSetting {
/*    */     public String identifier;
/*    */     public String icon;
/*    */     public Integer priority;
/*    */     public Integer size;
/*    */     public Boolean visible;
/*    */     public Boolean hasCosmetic;
/*    */     public Boolean override;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\curios-309927-4590652.jar!\top\theillusivec4\curios\common\CuriosConfig.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */