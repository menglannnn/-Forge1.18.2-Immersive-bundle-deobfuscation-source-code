/*    */ package top.theillusivec4.curios.common.network.client;
/*    */ 
/*    */ import java.util.function.Supplier;
/*    */ import net.minecraft.core.NonNullList;
/*    */ import net.minecraft.network.FriendlyByteBuf;
/*    */ import net.minecraft.server.level.ServerPlayer;
/*    */ import net.minecraft.world.entity.Entity;
/*    */ import net.minecraft.world.entity.LivingEntity;
/*    */ import net.minecraftforge.network.NetworkEvent;
/*    */ import net.minecraftforge.network.PacketDistributor;
/*    */ import top.theillusivec4.curios.api.CuriosApi;
/*    */ import top.theillusivec4.curios.api.type.capability.ICuriosItemHandler;
/*    */ import top.theillusivec4.curios.api.type.inventory.ICurioStacksHandler;
/*    */ import top.theillusivec4.curios.common.network.NetworkHandler;
/*    */ import top.theillusivec4.curios.common.network.server.sync.SPacketSyncRender;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CPacketToggleRender
/*    */ {
/*    */   String id;
/*    */   int index;
/*    */   
/*    */   public CPacketToggleRender(String id, int index) {
/* 38 */     this.id = id;
/* 39 */     this.index = index;
/*    */   }
/*    */   
/*    */   public static void encode(CPacketToggleRender msg, FriendlyByteBuf buf) {
/* 43 */     buf.m_130070_(msg.id);
/* 44 */     buf.writeInt(msg.index);
/*    */   }
/*    */   
/*    */   public static CPacketToggleRender decode(FriendlyByteBuf buf) {
/* 48 */     return new CPacketToggleRender(buf.m_130136_(100), buf.readInt());
/*    */   }
/*    */   
/*    */   public static void handle(CPacketToggleRender msg, Supplier<NetworkEvent.Context> ctx) {
/* 52 */     ((NetworkEvent.Context)ctx.get()).enqueueWork(() -> {
/*    */           ServerPlayer sender = ((NetworkEvent.Context)ctx.get()).getSender();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */           
/*    */           if (sender != null) {
/*    */             CuriosApi.getCuriosHelper().getCuriosHandler((LivingEntity)sender).ifPresent(());
/*    */           }
/*    */         });
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 70 */     ((NetworkEvent.Context)ctx.get()).setPacketHandled(true);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\curios-309927-4590652.jar!\top\theillusivec4\curios\common\network\client\CPacketToggleRender.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */