/*    */ package top.theillusivec4.curios.common.network.server;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.HashSet;
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ import java.util.function.Supplier;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.multiplayer.ClientLevel;
/*    */ import net.minecraft.network.FriendlyByteBuf;
/*    */ import net.minecraft.resources.ResourceLocation;
/*    */ import net.minecraftforge.network.NetworkEvent;
/*    */ import top.theillusivec4.curios.api.CuriosApi;
/*    */ import top.theillusivec4.curios.server.command.CurioArgumentType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SPacketSetIcons
/*    */ {
/*    */   private int entrySize;
/*    */   private Map<String, ResourceLocation> map;
/*    */   
/*    */   public SPacketSetIcons(Map<String, ResourceLocation> map) {
/* 41 */     this.entrySize = map.size();
/* 42 */     this.map = map;
/*    */   }
/*    */   
/*    */   public static void encode(SPacketSetIcons msg, FriendlyByteBuf buf) {
/* 46 */     buf.writeInt(msg.entrySize);
/*    */     
/* 48 */     for (Map.Entry<String, ResourceLocation> entry : msg.map.entrySet()) {
/* 49 */       buf.m_130070_(entry.getKey());
/* 50 */       buf.m_130070_(((ResourceLocation)entry.getValue()).toString());
/*    */     } 
/*    */   }
/*    */   
/*    */   public static SPacketSetIcons decode(FriendlyByteBuf buf) {
/* 55 */     int entrySize = buf.readInt();
/* 56 */     Map<String, ResourceLocation> map = new HashMap<>();
/*    */     
/* 58 */     for (int i = 0; i < entrySize; i++) {
/* 59 */       map.put(buf.m_130136_(25), new ResourceLocation(buf.m_130136_(100)));
/*    */     }
/* 61 */     return new SPacketSetIcons(map);
/*    */   }
/*    */   
/*    */   public static void handle(SPacketSetIcons msg, Supplier<NetworkEvent.Context> ctx) {
/* 65 */     ((NetworkEvent.Context)ctx.get()).enqueueWork(() -> {
/*    */           ClientLevel world = (Minecraft.m_91087_()).f_91073_;
/*    */           
/*    */           Set<String> slotIds = new HashSet<>();
/*    */           
/*    */           if (world != null) {
/*    */             CuriosApi.getIconHelper().clearIcons();
/*    */             for (Map.Entry<String, ResourceLocation> entry : msg.map.entrySet()) {
/*    */               CuriosApi.getIconHelper().addIcon(entry.getKey(), entry.getValue());
/*    */               slotIds.add(entry.getKey());
/*    */             } 
/*    */           } 
/*    */           CurioArgumentType.slotIds = slotIds;
/*    */         });
/* 79 */     ((NetworkEvent.Context)ctx.get()).setPacketHandled(true);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\curios-309927-4590652.jar!\top\theillusivec4\curios\common\network\server\SPacketSetIcons.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */