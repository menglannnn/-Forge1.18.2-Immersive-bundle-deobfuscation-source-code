/*     */ package top.theillusivec4.curios.common.util;
/*     */ import com.google.common.collect.ImmutableList;
/*     */ import com.google.common.collect.ImmutableSet;
/*     */ import com.google.common.collect.Lists;
/*     */ import com.google.gson.JsonArray;
/*     */ import com.google.gson.JsonDeserializationContext;
/*     */ import com.google.gson.JsonElement;
/*     */ import com.google.gson.JsonObject;
/*     */ import com.google.gson.JsonPrimitive;
/*     */ import com.google.gson.JsonSerializationContext;
/*     */ import com.google.gson.JsonSyntaxException;
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ import java.util.Set;
/*     */ import java.util.UUID;
/*     */ import java.util.stream.Stream;
/*     */ import javax.annotation.Nonnull;
/*     */ import javax.annotation.Nullable;
/*     */ import net.minecraft.Util;
/*     */ import net.minecraft.core.Registry;
/*     */ import net.minecraft.resources.ResourceLocation;
/*     */ import net.minecraft.util.GsonHelper;
/*     */ import net.minecraft.world.entity.ai.attributes.Attribute;
/*     */ import net.minecraft.world.entity.ai.attributes.AttributeModifier;
/*     */ import net.minecraft.world.item.ItemStack;
/*     */ import net.minecraft.world.level.storage.loot.LootContext;
/*     */ import net.minecraft.world.level.storage.loot.functions.LootItemConditionalFunction;
/*     */ import net.minecraft.world.level.storage.loot.functions.LootItemFunctionType;
/*     */ import net.minecraft.world.level.storage.loot.functions.LootItemFunctions;
/*     */ import net.minecraft.world.level.storage.loot.parameters.LootContextParam;
/*     */ import net.minecraft.world.level.storage.loot.predicates.LootItemCondition;
/*     */ import net.minecraft.world.level.storage.loot.providers.number.NumberProvider;
/*     */ import net.minecraftforge.registries.ForgeRegistries;
/*     */ import net.minecraftforge.registries.IForgeRegistryEntry;
/*     */ import top.theillusivec4.curios.api.CuriosApi;
/*     */ import top.theillusivec4.curios.common.CuriosHelper;
/*     */ 
/*     */ public class SetCurioAttributesFunction extends LootItemConditionalFunction {
/*  39 */   public static LootItemFunctionType TYPE = null;
/*     */   
/*     */   final List<Modifier> modifiers;
/*     */   
/*     */   SetCurioAttributesFunction(LootItemCondition[] conditions, List<Modifier> modifiers) {
/*  44 */     super(conditions);
/*  45 */     this.modifiers = (List<Modifier>)ImmutableList.copyOf(modifiers);
/*     */   }
/*     */   
/*     */   public static void register() {
/*  49 */     TYPE = (LootItemFunctionType)Registry.m_122965_(Registry.f_122876_, new ResourceLocation("curios", "set_curio_attributes"), new LootItemFunctionType((net.minecraft.world.level.storage.loot.Serializer)new Serializer()));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nonnull
/*     */   public LootItemFunctionType m_7162_() {
/*  56 */     return LootItemFunctions.f_80743_;
/*     */   }
/*     */   
/*     */   @Nonnull
/*     */   public Set<LootContextParam<?>> m_6231_() {
/*  61 */     return (Set<LootContextParam<?>>)this.modifiers.stream()
/*  62 */       .flatMap(mod -> mod.amount.m_6231_().stream())
/*  63 */       .collect(ImmutableSet.toImmutableSet());
/*     */   }
/*     */   
/*     */   @Nonnull
/*     */   public ItemStack m_7372_(@Nonnull ItemStack stack, LootContext context) {
/*  68 */     Random random = context.m_78933_();
/*     */     
/*  70 */     for (Modifier modifier : this.modifiers) {
/*  71 */       UUID uuid = modifier.id;
/*  72 */       String slot = (String)Util.m_137545_((Object[])modifier.slots, random);
/*     */       
/*  74 */       Attribute attribute = modifier.attribute; if (attribute instanceof CuriosHelper.SlotAttributeWrapper) { CuriosHelper.SlotAttributeWrapper wrapper = (CuriosHelper.SlotAttributeWrapper)attribute;
/*  75 */         CuriosApi.getCuriosHelper().addSlotModifier(stack, wrapper.identifier, modifier.name, uuid, modifier.amount
/*  76 */             .m_142688_(context), modifier.operation, slot); continue; }
/*     */       
/*  78 */       CuriosApi.getCuriosHelper().addModifier(stack, modifier.attribute, modifier.name, uuid, modifier.amount
/*  79 */           .m_142688_(context), modifier.operation, slot);
/*     */     } 
/*     */     
/*  82 */     return stack;
/*     */   }
/*     */   
/*     */   static class Modifier
/*     */   {
/*     */     final String name;
/*     */     final Attribute attribute;
/*     */     final AttributeModifier.Operation operation;
/*     */     final NumberProvider amount;
/*     */     @Nullable
/*     */     final UUID id;
/*     */     final String[] slots;
/*     */     
/*     */     Modifier(String name, Attribute attribute, AttributeModifier.Operation operation, NumberProvider amount, String[] slots, @Nullable UUID uuid) {
/*  96 */       this.name = name;
/*  97 */       this.attribute = attribute;
/*  98 */       this.operation = operation;
/*  99 */       this.amount = amount;
/* 100 */       this.id = uuid;
/* 101 */       this.slots = slots;
/*     */     }
/*     */     public JsonObject serialize(JsonSerializationContext context) {
/*     */       ResourceLocation rl;
/* 105 */       JsonObject jsonobject = new JsonObject();
/* 106 */       jsonobject.addProperty("name", this.name);
/*     */ 
/*     */       
/* 109 */       Attribute attribute = this.attribute; if (attribute instanceof CuriosHelper.SlotAttributeWrapper) { CuriosHelper.SlotAttributeWrapper wrapper = (CuriosHelper.SlotAttributeWrapper)attribute;
/* 110 */         rl = new ResourceLocation("curios", wrapper.identifier); }
/*     */       else
/* 112 */       { rl = ForgeRegistries.ATTRIBUTES.getKey((IForgeRegistryEntry)this.attribute); }
/*     */ 
/*     */       
/* 115 */       if (rl != null) {
/* 116 */         jsonobject.addProperty("attribute", rl.toString());
/*     */       }
/* 118 */       jsonobject.addProperty("operation", operationToString(this.operation));
/* 119 */       jsonobject.add("amount", context.serialize(this.amount));
/*     */       
/* 121 */       if (this.id != null) {
/* 122 */         jsonobject.addProperty("id", this.id.toString());
/*     */       }
/*     */       
/* 125 */       if (this.slots.length == 1) {
/* 126 */         jsonobject.addProperty("slot", this.slots[0]);
/*     */       } else {
/* 128 */         JsonArray jsonarray = new JsonArray();
/*     */         
/* 130 */         for (String slot : this.slots) {
/* 131 */           jsonarray.add((JsonElement)new JsonPrimitive(slot));
/*     */         }
/* 133 */         jsonobject.add("slot", (JsonElement)jsonarray);
/*     */       } 
/* 135 */       return jsonobject;
/*     */     }
/*     */     public static Modifier deserialize(JsonObject object, JsonDeserializationContext context) {
/*     */       Attribute attribute;
/* 139 */       String slots[], s = GsonHelper.m_13906_(object, "name");
/*     */       
/* 141 */       ResourceLocation resourcelocation = new ResourceLocation(GsonHelper.m_13906_(object, "attribute"));
/*     */ 
/*     */       
/* 144 */       if (resourcelocation.m_135827_().equals("curios")) {
/* 145 */         String identifier = resourcelocation.m_135815_();
/*     */         
/* 147 */         if (CuriosApi.getSlotHelper().getSlotType(identifier).isEmpty()) {
/* 148 */           throw new JsonSyntaxException("Unknown curios slot type: " + identifier);
/*     */         }
/* 150 */         CuriosHelper.SlotAttributeWrapper slotAttributeWrapper = CuriosHelper.getOrCreateSlotAttribute(identifier);
/*     */       } else {
/* 152 */         attribute = (Attribute)ForgeRegistries.ATTRIBUTES.getValue(resourcelocation);
/*     */       } 
/*     */       
/* 155 */       if (attribute == null) {
/* 156 */         throw new JsonSyntaxException("Unknown attribute: " + resourcelocation);
/*     */       }
/*     */       
/* 159 */       AttributeModifier.Operation operation = operationFromString(GsonHelper.m_13906_(object, "operation"));
/*     */       
/* 161 */       NumberProvider numberprovider = (NumberProvider)GsonHelper.m_13836_(object, "amount", context, NumberProvider.class);
/* 162 */       UUID uuid = null;
/*     */ 
/*     */       
/* 165 */       if (GsonHelper.m_13813_(object, "slot")) {
/* 166 */         slots = new String[] { GsonHelper.m_13906_(object, "slot") };
/*     */       } else {
/*     */         
/* 169 */         if (!GsonHelper.m_13885_(object, "slot")) {
/* 170 */           throw new JsonSyntaxException("Invalid or missing attribute modifier slot; must be either string or array of strings.");
/*     */         }
/*     */         
/* 173 */         JsonArray jsonarray = GsonHelper.m_13933_(object, "slot");
/* 174 */         slots = new String[jsonarray.size()];
/* 175 */         int i = 0;
/*     */         
/* 177 */         for (JsonElement jsonelement : jsonarray) {
/* 178 */           slots[i++] = GsonHelper.m_13805_(jsonelement, "slot");
/*     */         }
/*     */         
/* 181 */         if (slots.length == 0) {
/* 182 */           throw new JsonSyntaxException("Invalid attribute modifier slot; must contain at least one entry.");
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 187 */       if (object.has("id")) {
/* 188 */         String s1 = GsonHelper.m_13906_(object, "id");
/*     */         
/*     */         try {
/* 191 */           uuid = UUID.fromString(s1);
/* 192 */         } catch (IllegalArgumentException illegalargumentexception) {
/* 193 */           throw new JsonSyntaxException("Invalid attribute modifier id '" + s1 + "' (must be UUID format, with dashes)");
/*     */         } 
/*     */       } 
/*     */       
/* 197 */       return new Modifier(s, attribute, operation, numberprovider, slots, uuid);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private static String operationToString(AttributeModifier.Operation operation) {
/*     */       // Byte code:
/*     */       //   0: getstatic top/theillusivec4/curios/common/util/SetCurioAttributesFunction$1.$SwitchMap$net$minecraft$world$entity$ai$attributes$AttributeModifier$Operation : [I
/*     */       //   3: aload_0
/*     */       //   4: invokevirtual ordinal : ()I
/*     */       //   7: iaload
/*     */       //   8: tableswitch default -> 36, 1 -> 44, 2 -> 50, 3 -> 56
/*     */       //   36: new java/lang/IncompatibleClassChangeError
/*     */       //   39: dup
/*     */       //   40: invokespecial <init> : ()V
/*     */       //   43: athrow
/*     */       //   44: ldc_w 'addition'
/*     */       //   47: goto -> 59
/*     */       //   50: ldc_w 'multiply_base'
/*     */       //   53: goto -> 59
/*     */       //   56: ldc_w 'multiply_total'
/*     */       //   59: areturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #202	-> 0
/*     */       //   #203	-> 44
/*     */       //   #204	-> 50
/*     */       //   #205	-> 56
/*     */       //   #202	-> 59
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	60	0	operation	Lnet/minecraft/world/entity/ai/attributes/AttributeModifier$Operation;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private static AttributeModifier.Operation operationFromString(String operation) {
/* 210 */       switch (operation) { case "addition": 
/*     */         case "multiply_base":
/*     */         
/*     */         case "multiply_total":
/* 214 */          }  throw new JsonSyntaxException("Unknown attribute modifier operation " + operation);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Serializer
/*     */     extends LootItemConditionalFunction.Serializer<SetCurioAttributesFunction>
/*     */   {
/*     */     public void serialize(@Nonnull JsonObject object, @Nonnull SetCurioAttributesFunction function, @Nonnull JsonSerializationContext context) {
/* 226 */       super.m_6170_(object, function, context);
/* 227 */       JsonArray jsonarray = new JsonArray();
/*     */       
/* 229 */       for (SetCurioAttributesFunction.Modifier modifier : function.modifiers) {
/* 230 */         jsonarray.add((JsonElement)modifier.serialize(context));
/*     */       }
/* 232 */       object.add("modifiers", (JsonElement)jsonarray);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     @Nonnull
/*     */     public SetCurioAttributesFunction deserialize(@Nonnull JsonObject object, @Nonnull JsonDeserializationContext context, @Nonnull LootItemCondition[] conditions) {
/* 239 */       JsonArray jsonarray = GsonHelper.m_13933_(object, "modifiers");
/* 240 */       List<SetCurioAttributesFunction.Modifier> list = Lists.newArrayListWithExpectedSize(jsonarray.size());
/*     */       
/* 242 */       for (JsonElement jsonelement : jsonarray) {
/* 243 */         list.add(
/* 244 */             SetCurioAttributesFunction.Modifier.deserialize(GsonHelper.m_13918_(jsonelement, "modifier"), context));
/*     */       }
/*     */       
/* 247 */       if (list.isEmpty()) {
/* 248 */         throw new JsonSyntaxException("Invalid attribute modifiers array; cannot be empty");
/*     */       }
/* 250 */       return new SetCurioAttributesFunction(conditions, list);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\curios-309927-4590652.jar!\top\theillusivec4\curios\commo\\util\SetCurioAttributesFunction.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */