/*    */ package top.theillusivec4.curios.common.network.server.sync;
/*    */ 
/*    */ import java.util.function.Supplier;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.multiplayer.ClientLevel;
/*    */ import net.minecraft.core.NonNullList;
/*    */ import net.minecraft.network.FriendlyByteBuf;
/*    */ import net.minecraft.world.entity.Entity;
/*    */ import net.minecraft.world.entity.LivingEntity;
/*    */ import net.minecraftforge.network.NetworkEvent;
/*    */ import top.theillusivec4.curios.api.CuriosApi;
/*    */ import top.theillusivec4.curios.api.type.capability.ICuriosItemHandler;
/*    */ import top.theillusivec4.curios.api.type.inventory.ICurioStacksHandler;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SPacketSyncRender
/*    */ {
/*    */   private int entityId;
/*    */   private int slotId;
/*    */   private String curioId;
/*    */   private boolean value;
/*    */   
/*    */   public SPacketSyncRender(int entityId, String curioId, int slotId, boolean value) {
/* 40 */     this.entityId = entityId;
/* 41 */     this.slotId = slotId;
/* 42 */     this.curioId = curioId;
/* 43 */     this.value = value;
/*    */   }
/*    */   
/*    */   public static void encode(SPacketSyncRender msg, FriendlyByteBuf buf) {
/* 47 */     buf.writeInt(msg.entityId);
/* 48 */     buf.m_130070_(msg.curioId);
/* 49 */     buf.writeInt(msg.slotId);
/* 50 */     buf.writeBoolean(msg.value);
/*    */   }
/*    */   
/*    */   public static SPacketSyncRender decode(FriendlyByteBuf buf) {
/* 54 */     return new SPacketSyncRender(buf.readInt(), buf.m_130136_(25), buf.readInt(), buf
/* 55 */         .readBoolean());
/*    */   }
/*    */   
/*    */   public static void handle(SPacketSyncRender msg, Supplier<NetworkEvent.Context> ctx) {
/* 59 */     ((NetworkEvent.Context)ctx.get()).enqueueWork(() -> {
/*    */           ClientLevel world = (Minecraft.m_91087_()).f_91073_;
/*    */ 
/*    */ 
/*    */ 
/*    */           
/*    */           if (world != null) {
/*    */             Entity entity = world.m_6815_(msg.entityId);
/*    */ 
/*    */ 
/*    */             
/*    */             if (entity instanceof LivingEntity) {
/*    */               CuriosApi.getCuriosHelper().getCuriosHandler((LivingEntity)entity).ifPresent(());
/*    */             }
/*    */           } 
/*    */         });
/*    */ 
/*    */ 
/*    */     
/* 78 */     ((NetworkEvent.Context)ctx.get()).setPacketHandled(true);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\curios-309927-4590652.jar!\top\theillusivec4\curios\common\network\server\sync\SPacketSyncRender.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */