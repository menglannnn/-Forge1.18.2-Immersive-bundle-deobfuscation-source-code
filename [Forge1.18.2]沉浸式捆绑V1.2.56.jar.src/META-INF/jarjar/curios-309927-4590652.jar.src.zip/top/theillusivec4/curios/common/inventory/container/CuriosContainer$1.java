/*     */ package top.theillusivec4.curios.common.inventory.container;
/*     */ 
/*     */ import com.mojang.datafixers.util.Pair;
/*     */ import javax.annotation.Nonnull;
/*     */ import net.minecraft.resources.ResourceLocation;
/*     */ import net.minecraft.world.Container;
/*     */ import net.minecraft.world.entity.Entity;
/*     */ import net.minecraft.world.entity.EquipmentSlot;
/*     */ import net.minecraft.world.entity.player.Player;
/*     */ import net.minecraft.world.inventory.InventoryMenu;
/*     */ import net.minecraft.world.inventory.Slot;
/*     */ import net.minecraft.world.item.ItemStack;
/*     */ import net.minecraft.world.item.enchantment.EnchantmentHelper;
/*     */ import net.minecraftforge.api.distmarker.Dist;
/*     */ import net.minecraftforge.api.distmarker.OnlyIn;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class null
/*     */   extends Slot
/*     */ {
/*     */   null(Container pContainer, int pIndex, int pX, int pY) {
/* 108 */     super(pContainer, pIndex, pX, pY);
/*     */   }
/*     */   
/*     */   public int m_6641_() {
/* 112 */     return 1;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean m_5857_(@Nonnull ItemStack stack) {
/* 117 */     return stack.canEquip(equipmentslottype, (Entity)CuriosContainer.this.player);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean m_8010_(@Nonnull Player playerIn) {
/* 122 */     ItemStack itemstack = m_7993_();
/* 123 */     return ((itemstack.m_41619_() || playerIn.m_7500_() || 
/* 124 */       !EnchantmentHelper.m_44920_(itemstack)) && super.m_8010_(playerIn));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @OnlyIn(Dist.CLIENT)
/*     */   public Pair<ResourceLocation, ResourceLocation> m_7543_() {
/* 131 */     return Pair.of(InventoryMenu.f_39692_, CuriosContainer.ARMOR_SLOT_TEXTURES[equipmentslottype
/* 132 */           .m_20749_()]);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\curios-309927-4590652.jar!\top\theillusivec4\curios\common\inventory\container\CuriosContainer$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */