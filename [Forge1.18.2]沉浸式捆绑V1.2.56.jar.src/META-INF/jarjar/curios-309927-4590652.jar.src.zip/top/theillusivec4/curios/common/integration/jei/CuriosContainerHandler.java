/*    */ package top.theillusivec4.curios.common.integration.jei;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import javax.annotation.Nonnull;
/*    */ import mezz.jei.api.gui.handlers.IGuiContainerHandler;
/*    */ import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
/*    */ import net.minecraft.client.gui.screens.recipebook.RecipeBookComponent;
/*    */ import net.minecraft.client.gui.screens.recipebook.RecipeBookTabButton;
/*    */ import net.minecraft.client.player.LocalPlayer;
/*    */ import net.minecraft.client.renderer.Rect2i;
/*    */ import net.minecraft.world.entity.LivingEntity;
/*    */ import top.theillusivec4.curios.api.CuriosApi;
/*    */ import top.theillusivec4.curios.api.type.capability.ICuriosItemHandler;
/*    */ import top.theillusivec4.curios.client.gui.CuriosScreen;
/*    */ import top.theillusivec4.curios.common.inventory.container.CuriosContainer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CuriosContainerHandler
/*    */   implements IGuiContainerHandler<CuriosScreen>
/*    */ {
/*    */   @Nonnull
/*    */   public List<Rect2i> getGuiExtraAreas(CuriosScreen containerScreen) {
/* 39 */     LocalPlayer player = (containerScreen.getMinecraft()).f_91074_;
/*    */     
/* 41 */     if (player != null) {
/* 42 */       return CuriosApi.getCuriosHelper().getCuriosHandler((LivingEntity)(containerScreen.getMinecraft()).f_91074_)
/* 43 */         .map(handler -> {
/*    */             List<Rect2i> areas = new ArrayList<>();
/*    */             
/*    */             int slotCount = handler.getVisibleSlots();
/*    */             
/*    */             if (slotCount <= 0) {
/*    */               return areas;
/*    */             }
/*    */             
/*    */             int width = (slotCount > 8) ? 42 : 26;
/*    */             
/*    */             if (((CuriosContainer)containerScreen.m_6262_()).hasCosmeticColumn()) {
/*    */               width += 18;
/*    */             }
/*    */             
/*    */             int height = 7 + slotCount * 18;
/*    */             int left = containerScreen.getGuiLeft() - width;
/*    */             int top = containerScreen.getGuiTop() + 4;
/*    */             areas.add(new Rect2i(left, top, width, height));
/*    */             RecipeBookComponent guiRecipeBook = containerScreen.m_5564_();
/*    */             if (guiRecipeBook.m_100385_()) {
/*    */               int i = (containerScreen.f_96543_ - 147) / 2 - (containerScreen.widthTooNarrow ? 0 : 86);
/*    */               int j = (containerScreen.f_96544_ - 166) / 2;
/*    */               areas.add(new Rect2i(i, j, 147, 166));
/*    */               for (RecipeBookTabButton tab : guiRecipeBook.f_100279_) {
/*    */                 if (tab.f_93623_) {
/*    */                   areas.add(new Rect2i(tab.f_93620_, tab.f_93621_, tab.m_5711_(), tab.m_93252_()));
/*    */                 }
/*    */               } 
/*    */               return areas;
/*    */             } 
/*    */             return areas;
/* 75 */           }).orElse(Collections.emptyList());
/*    */     }
/* 77 */     return Collections.emptyList();
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\curios-309927-4590652.jar!\top\theillusivec4\curios\common\integration\jei\CuriosContainerHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */