/*    */ package top.theillusivec4.curios.common.network.client;
/*    */ 
/*    */ import java.util.function.Supplier;
/*    */ import net.minecraft.network.FriendlyByteBuf;
/*    */ import net.minecraft.server.level.ServerPlayer;
/*    */ import net.minecraft.world.item.ItemStack;
/*    */ import net.minecraftforge.network.NetworkEvent;
/*    */ import net.minecraftforge.network.PacketDistributor;
/*    */ import top.theillusivec4.curios.common.network.NetworkHandler;
/*    */ import top.theillusivec4.curios.common.network.server.SPacketGrabbedItem;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CPacketOpenVanilla
/*    */ {
/*    */   private final ItemStack carried;
/*    */   
/*    */   public CPacketOpenVanilla(ItemStack stack) {
/* 36 */     this.carried = stack;
/*    */   }
/*    */   
/*    */   public static void encode(CPacketOpenVanilla msg, FriendlyByteBuf buf) {
/* 40 */     buf.m_130055_(msg.carried);
/*    */   }
/*    */   
/*    */   public static CPacketOpenVanilla decode(FriendlyByteBuf buf) {
/* 44 */     return new CPacketOpenVanilla(buf.m_130267_());
/*    */   }
/*    */   
/*    */   public static void handle(CPacketOpenVanilla msg, Supplier<NetworkEvent.Context> ctx) {
/* 48 */     ((NetworkEvent.Context)ctx.get()).enqueueWork(() -> {
/*    */           ServerPlayer sender = ((NetworkEvent.Context)ctx.get()).getSender();
/*    */           
/*    */           if (sender != null) {
/*    */             ItemStack stack = sender.m_7500_() ? msg.carried : sender.f_36096_.m_142621_();
/*    */             
/*    */             sender.f_36096_.m_142503_(ItemStack.f_41583_);
/*    */             
/*    */             sender.m_9230_();
/*    */             
/*    */             if (!stack.m_41619_()) {
/*    */               if (!sender.m_7500_()) {
/*    */                 sender.f_36096_.m_142503_(stack);
/*    */               }
/*    */               NetworkHandler.INSTANCE.send(PacketDistributor.PLAYER.with(()), new SPacketGrabbedItem(stack));
/*    */             } 
/*    */           } 
/*    */         });
/* 66 */     ((NetworkEvent.Context)ctx.get()).setPacketHandled(true);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\curios-309927-4590652.jar!\top\theillusivec4\curios\common\network\client\CPacketOpenVanilla.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */