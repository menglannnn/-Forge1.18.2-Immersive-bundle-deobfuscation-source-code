/*     */ package top.theillusivec4.curios.mixin;
/*     */ import java.util.Map;
/*     */ import net.minecraft.core.NonNullList;
/*     */ import net.minecraft.tags.ItemTags;
/*     */ import net.minecraft.world.entity.Entity;
/*     */ import net.minecraft.world.entity.LivingEntity;
/*     */ import net.minecraft.world.entity.monster.EnderMan;
/*     */ import net.minecraft.world.entity.player.Player;
/*     */ import net.minecraft.world.item.ItemStack;
/*     */ import net.minecraft.world.level.storage.loot.LootContext;
/*     */ import net.minecraft.world.level.storage.loot.parameters.LootContextParams;
/*     */ import net.minecraftforge.items.IItemHandlerModifiable;
/*     */ import net.minecraftforge.registries.ForgeRegistries;
/*     */ import net.minecraftforge.registries.tags.ITagManager;
/*     */ import top.theillusivec4.curios.api.CuriosApi;
/*     */ import top.theillusivec4.curios.api.SlotContext;
/*     */ import top.theillusivec4.curios.api.type.capability.ICurio;
/*     */ import top.theillusivec4.curios.api.type.capability.ICuriosItemHandler;
/*     */ import top.theillusivec4.curios.api.type.inventory.ICurioStacksHandler;
/*     */ import top.theillusivec4.curios.api.type.inventory.IDynamicStackHandler;
/*     */ 
/*     */ public class CuriosMixinHooks {
/*  23 */   private static final ITagManager<Item> ITEM_TAGS = ForgeRegistries.ITEMS.tags();
/*     */   
/*     */   public static boolean hasEnderMask(LivingEntity livingEntity, EnderMan enderMan) {
/*  26 */     return ((Boolean)CuriosApi.getCuriosHelper().getCuriosHandler(livingEntity).map(handler -> {
/*     */           for (Map.Entry<String, ICurioStacksHandler> entry : (Iterable<Map.Entry<String, ICurioStacksHandler>>)handler.getCurios().entrySet()) {
/*     */             IDynamicStackHandler stacks = ((ICurioStacksHandler)entry.getValue()).getStacks();
/*     */ 
/*     */             
/*     */             for (int i = 0; i < stacks.getSlots(); i++) {
/*     */               int index = i;
/*     */ 
/*     */               
/*     */               NonNullList<Boolean> renderStates = ((ICurioStacksHandler)entry.getValue()).getRenders();
/*     */               
/*     */               boolean hasMask = ((Boolean)CuriosApi.getCuriosHelper().getCurio(stacks.getStackInSlot(i)).map(()).orElse(Boolean.valueOf(false))).booleanValue();
/*     */               
/*     */               if (hasMask) {
/*     */                 return Boolean.valueOf(true);
/*     */               }
/*     */             } 
/*     */           } 
/*     */           
/*     */           return Boolean.valueOf(false);
/*  46 */         }).orElse(Boolean.valueOf(false))).booleanValue();
/*     */   }
/*     */   
/*     */   public static boolean canNeutralizePiglins(LivingEntity livingEntity) {
/*  50 */     return ((Boolean)CuriosApi.getCuriosHelper().getCuriosHandler(livingEntity).map(handler -> {
/*     */           for (Map.Entry<String, ICurioStacksHandler> entry : (Iterable<Map.Entry<String, ICurioStacksHandler>>)handler.getCurios().entrySet()) {
/*     */             IDynamicStackHandler stacks = ((ICurioStacksHandler)entry.getValue()).getStacks();
/*     */ 
/*     */             
/*     */             for (int i = 0; i < stacks.getSlots(); i++) {
/*     */               int index = i;
/*     */ 
/*     */               
/*     */               NonNullList<Boolean> renderStates = ((ICurioStacksHandler)entry.getValue()).getRenders();
/*     */               
/*     */               boolean canNeutralize = ((Boolean)CuriosApi.getCuriosHelper().getCurio(stacks.getStackInSlot(i)).map(()).orElse(Boolean.valueOf(false))).booleanValue();
/*     */               
/*     */               if (canNeutralize) {
/*     */                 return Boolean.valueOf(true);
/*     */               }
/*     */             } 
/*     */           } 
/*     */           
/*     */           return Boolean.valueOf(false);
/*  70 */         }).orElse(Boolean.valueOf(false))).booleanValue();
/*     */   }
/*     */   
/*     */   public static boolean canWalkOnPowderSnow(LivingEntity livingEntity) {
/*  74 */     return ((Boolean)CuriosApi.getCuriosHelper().getCuriosHandler(livingEntity).map(handler -> {
/*     */           for (Map.Entry<String, ICurioStacksHandler> entry : (Iterable<Map.Entry<String, ICurioStacksHandler>>)handler.getCurios().entrySet()) {
/*     */             IDynamicStackHandler stacks = ((ICurioStacksHandler)entry.getValue()).getStacks();
/*     */ 
/*     */             
/*     */             for (int i = 0; i < stacks.getSlots(); i++) {
/*     */               int index = i;
/*     */ 
/*     */               
/*     */               NonNullList<Boolean> renderStates = ((ICurioStacksHandler)entry.getValue()).getRenders();
/*     */               
/*     */               boolean canWalk = ((Boolean)CuriosApi.getCuriosHelper().getCurio(stacks.getStackInSlot(i)).map(()).orElse(Boolean.valueOf(false))).booleanValue();
/*     */               
/*     */               if (canWalk) {
/*     */                 return Boolean.valueOf(true);
/*     */               }
/*     */             } 
/*     */           } 
/*     */           
/*     */           return Boolean.valueOf(false);
/*  94 */         }).orElse(Boolean.valueOf(false))).booleanValue();
/*     */   }
/*     */   
/*     */   public static int getFortuneLevel(Player player) {
/*  98 */     return ((Integer)CuriosApi.getCuriosHelper().getCuriosHandler((LivingEntity)player)
/*  99 */       .map(handler -> Integer.valueOf(handler.getFortuneLevel(null))).orElse(Integer.valueOf(0))).intValue();
/*     */   }
/*     */   
/*     */   public static int getFortuneLevel(LootContext lootContext) {
/* 103 */     Entity entity = (Entity)lootContext.m_78953_(LootContextParams.f_81455_);
/*     */     
/* 105 */     if (entity instanceof LivingEntity) { LivingEntity livingEntity = (LivingEntity)entity;
/* 106 */       return ((Integer)CuriosApi.getCuriosHelper().getCuriosHandler(livingEntity)
/* 107 */         .map(handler -> Integer.valueOf(handler.getFortuneLevel(lootContext))).orElse(Integer.valueOf(0))).intValue(); }
/*     */     
/* 109 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean isFreezeImmune(LivingEntity livingEntity) {
/* 114 */     return ((Boolean)CuriosApi.getCuriosHelper().getEquippedCurios(livingEntity).map(curios -> {
/*     */           for (int i = 0; i < curios.getSlots(); i++) {
/*     */             ItemStack stack = curios.getStackInSlot(i);
/*     */ 
/*     */             
/*     */             if (ITEM_TAGS != null && ITEM_TAGS.getTag(ItemTags.f_144320_).contains(stack.m_41720_())) {
/*     */               return Boolean.valueOf(true);
/*     */             }
/*     */           } 
/*     */           
/*     */           return Boolean.valueOf(false);
/* 125 */         }).orElse(Boolean.valueOf(false))).booleanValue();
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\curios-309927-4590652.jar!\top\theillusivec4\curios\mixin\CuriosMixinHooks.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */