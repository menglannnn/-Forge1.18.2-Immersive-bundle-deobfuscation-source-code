/*    */ package top.theillusivec4.curios.mixin.core;
/*    */ 
/*    */ import net.minecraft.world.entity.LivingEntity;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
/*    */ import top.theillusivec4.curios.mixin.CuriosMixinHooks;
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin({LivingEntity.class})
/*    */ public class MixinLivingEntity
/*    */ {
/*    */   @Inject(at = {@At("TAIL")}, method = {"canFreeze()Z"}, cancellable = true)
/*    */   public void curio$canFreeze(CallbackInfoReturnable<Boolean> cir) {
/* 17 */     if (CuriosMixinHooks.isFreezeImmune((LivingEntity)this))
/* 18 */       cir.setReturnValue(Boolean.valueOf(false)); 
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\curios-309927-4590652.jar!\top\theillusivec4\curios\mixin\core\MixinLivingEntity.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */