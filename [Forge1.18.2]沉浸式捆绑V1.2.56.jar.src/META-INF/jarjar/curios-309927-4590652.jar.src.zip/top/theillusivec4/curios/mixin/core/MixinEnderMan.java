/*    */ package top.theillusivec4.curios.mixin.core;
/*    */ 
/*    */ import net.minecraft.world.entity.LivingEntity;
/*    */ import net.minecraft.world.entity.monster.EnderMan;
/*    */ import net.minecraft.world.entity.player.Player;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
/*    */ import top.theillusivec4.curios.mixin.CuriosMixinHooks;
/*    */ 
/*    */ 
/*    */ @Mixin({EnderMan.class})
/*    */ public class MixinEnderMan
/*    */ {
/*    */   @Inject(at = {@At("HEAD")}, method = {"isLookingAtMe"}, cancellable = true)
/*    */   public void curio$isLookingAtMe(Player player, CallbackInfoReturnable<Boolean> cir) {
/* 18 */     if (CuriosMixinHooks.hasEnderMask((LivingEntity)player, (EnderMan)this))
/* 19 */       cir.setReturnValue(Boolean.valueOf(false)); 
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\curios-309927-4590652.jar!\top\theillusivec4\curios\mixin\core\MixinEnderMan.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */