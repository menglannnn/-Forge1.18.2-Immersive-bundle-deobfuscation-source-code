/*    */ package top.theillusivec4.curios.mixin.core;
/*    */ 
/*    */ import net.minecraft.world.entity.Entity;
/*    */ import net.minecraft.world.entity.LivingEntity;
/*    */ import net.minecraft.world.level.block.PowderSnowBlock;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
/*    */ import top.theillusivec4.curios.mixin.CuriosMixinHooks;
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin({PowderSnowBlock.class})
/*    */ public class MixinPowderSnowBlock
/*    */ {
/*    */   @Inject(at = {@At("RETURN")}, method = {"canEntityWalkOnPowderSnow"}, cancellable = true)
/*    */   private static void curios$canEntityWalkOnPowderSnow(Entity entity, CallbackInfoReturnable<Boolean> cir) {
/* 19 */     if (entity instanceof LivingEntity) { LivingEntity livingEntity = (LivingEntity)entity; if (CuriosMixinHooks.canWalkOnPowderSnow(livingEntity))
/* 20 */         cir.setReturnValue(Boolean.valueOf(true));  }
/*    */   
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\curios-309927-4590652.jar!\top\theillusivec4\curios\mixin\core\MixinPowderSnowBlock.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */