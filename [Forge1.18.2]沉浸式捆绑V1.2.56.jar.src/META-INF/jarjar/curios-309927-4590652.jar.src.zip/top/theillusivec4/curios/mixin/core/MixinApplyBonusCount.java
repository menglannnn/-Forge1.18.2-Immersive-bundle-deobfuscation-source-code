/*    */ package top.theillusivec4.curios.mixin.core;
/*    */ 
/*    */ import net.minecraft.world.item.ItemStack;
/*    */ import net.minecraft.world.item.enchantment.Enchantment;
/*    */ import net.minecraft.world.item.enchantment.Enchantments;
/*    */ import net.minecraft.world.level.storage.loot.LootContext;
/*    */ import net.minecraft.world.level.storage.loot.functions.ApplyBonusCount;
/*    */ import org.spongepowered.asm.mixin.Final;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.Shadow;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.ModifyVariable;
/*    */ import top.theillusivec4.curios.mixin.CuriosMixinHooks;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin({ApplyBonusCount.class})
/*    */ public class MixinApplyBonusCount
/*    */ {
/*    */   @Shadow
/*    */   @Final
/*    */   Enchantment f_79899_;
/*    */   
/*    */   @ModifyVariable(at = @At(value = "INVOKE_ASSIGN", target = "net/minecraft/world/item/enchantment/EnchantmentHelper.getItemEnchantmentLevel(Lnet/minecraft/world/item/enchantment/Enchantment;Lnet/minecraft/world/item/ItemStack;)I"), method = {"run"})
/*    */   private int curios$applyFortune(int enchantmentLevel, ItemStack stack, LootContext lootContext) {
/* 29 */     if (this.f_79899_ == Enchantments.f_44987_) {
/* 30 */       return enchantmentLevel + CuriosMixinHooks.getFortuneLevel(lootContext);
/*    */     }
/* 32 */     return enchantmentLevel;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\curios-309927-4590652.jar!\top\theillusivec4\curios\mixin\core\MixinApplyBonusCount.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */