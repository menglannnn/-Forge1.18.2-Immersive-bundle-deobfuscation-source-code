/*    */ package top.theillusivec4.curios.mixin.core;
/*    */ 
/*    */ import net.minecraft.world.entity.LivingEntity;
/*    */ import net.minecraft.world.entity.monster.piglin.PiglinAi;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
/*    */ import top.theillusivec4.curios.mixin.CuriosMixinHooks;
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin({PiglinAi.class})
/*    */ public class MixinPiglinAi
/*    */ {
/*    */   @Inject(at = {@At("RETURN")}, method = {"isWearingGold"}, cancellable = true)
/*    */   private static void curios$isWearingGold(LivingEntity livingEntity, CallbackInfoReturnable<Boolean> cir) {
/* 18 */     if (CuriosMixinHooks.canNeutralizePiglins(livingEntity))
/* 19 */       cir.setReturnValue(Boolean.valueOf(true)); 
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\curios-309927-4590652.jar!\top\theillusivec4\curios\mixin\core\MixinPiglinAi.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */