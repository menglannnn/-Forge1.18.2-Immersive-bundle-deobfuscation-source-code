/*     */ package top.theillusivec4.curios;
/*     */ 
/*     */ import net.minecraft.client.gui.screens.MenuScreens;
/*     */ import net.minecraft.client.renderer.entity.LivingEntityRenderer;
/*     */ import net.minecraft.client.renderer.entity.RenderLayerParent;
/*     */ import net.minecraft.client.renderer.entity.layers.RenderLayer;
/*     */ import net.minecraftforge.api.distmarker.Dist;
/*     */ import net.minecraftforge.client.event.EntityRenderersEvent;
/*     */ import net.minecraftforge.client.event.TextureStitchEvent;
/*     */ import net.minecraftforge.common.MinecraftForge;
/*     */ import net.minecraftforge.eventbus.api.SubscribeEvent;
/*     */ import net.minecraftforge.fml.common.Mod;
/*     */ import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
/*     */ import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
/*     */ import top.theillusivec4.curios.api.CuriosApi;
/*     */ import top.theillusivec4.curios.api.client.CuriosRendererRegistry;
/*     */ import top.theillusivec4.curios.api.type.util.IIconHelper;
/*     */ import top.theillusivec4.curios.client.ClientEventHandler;
/*     */ import top.theillusivec4.curios.client.CuriosClientMod;
/*     */ import top.theillusivec4.curios.client.IconHelper;
/*     */ import top.theillusivec4.curios.client.KeyRegistry;
/*     */ import top.theillusivec4.curios.client.gui.GuiEventHandler;
/*     */ import top.theillusivec4.curios.client.render.CuriosLayer;
/*     */ import top.theillusivec4.curios.common.CuriosRegistry;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @EventBusSubscriber(modid = "curios", value = {Dist.CLIENT}, bus = Mod.EventBusSubscriber.Bus.MOD)
/*     */ public class ClientProxy
/*     */ {
/*     */   @SubscribeEvent
/*     */   public static void stitchTextures(TextureStitchEvent.Pre evt) {
/* 179 */     CuriosClientMod.stitch(evt);
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public static void setupClient(FMLClientSetupEvent evt) {
/* 184 */     CuriosApi.setIconHelper((IIconHelper)new IconHelper());
/* 185 */     MinecraftForge.EVENT_BUS.register(new ClientEventHandler());
/* 186 */     MinecraftForge.EVENT_BUS.register(new GuiEventHandler());
/* 187 */     MenuScreens.m_96206_(CuriosRegistry.CONTAINER_TYPE, top.theillusivec4.curios.client.gui.CuriosScreen::new);
/* 188 */     KeyRegistry.registerKeys();
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public static void addLayers(EntityRenderersEvent.AddLayers evt) {
/* 193 */     addPlayerLayer(evt, "default");
/* 194 */     addPlayerLayer(evt, "slim");
/* 195 */     CuriosRendererRegistry.load();
/*     */   }
/*     */ 
/*     */   
/*     */   private static void addPlayerLayer(EntityRenderersEvent.AddLayers evt, String skin) {
/* 200 */     LivingEntityRenderer livingEntityRenderer = evt.getSkin(skin);
/*     */     
/* 202 */     if (livingEntityRenderer instanceof LivingEntityRenderer) { LivingEntityRenderer livingRenderer = livingEntityRenderer;
/* 203 */       livingRenderer.m_115326_((RenderLayer)new CuriosLayer((RenderLayerParent)livingRenderer)); }
/*     */   
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\curios-309927-4590652.jar!\top\theillusivec4\curios\Curios$ClientProxy.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */