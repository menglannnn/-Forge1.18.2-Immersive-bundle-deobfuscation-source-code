/*     */ package top.theillusivec4.curios;
/*     */ 
/*     */ import com.electronwill.nightconfig.core.CommentedConfig;
/*     */ import java.lang.invoke.SerializedLambda;
/*     */ import javax.annotation.Nonnull;
/*     */ import net.minecraft.advancements.CriteriaTriggers;
/*     */ import net.minecraft.advancements.CriterionTrigger;
/*     */ import net.minecraft.client.gui.screens.MenuScreens;
/*     */ import net.minecraft.client.renderer.entity.LivingEntityRenderer;
/*     */ import net.minecraft.client.renderer.entity.RenderLayerParent;
/*     */ import net.minecraft.client.renderer.entity.layers.RenderLayer;
/*     */ import net.minecraft.commands.synchronization.ArgumentSerializer;
/*     */ import net.minecraft.commands.synchronization.ArgumentTypes;
/*     */ import net.minecraft.commands.synchronization.EmptyArgumentSerializer;
/*     */ import net.minecraft.server.packs.resources.PreparableReloadListener;
/*     */ import net.minecraft.server.packs.resources.ResourceManager;
/*     */ import net.minecraft.server.packs.resources.SimplePreparableReloadListener;
/*     */ import net.minecraft.util.profiling.ProfilerFiller;
/*     */ import net.minecraftforge.api.distmarker.Dist;
/*     */ import net.minecraftforge.client.event.EntityRenderersEvent;
/*     */ import net.minecraftforge.client.event.TextureStitchEvent;
/*     */ import net.minecraftforge.common.MinecraftForge;
/*     */ import net.minecraftforge.common.capabilities.RegisterCapabilitiesEvent;
/*     */ import net.minecraftforge.event.AddReloadListenerEvent;
/*     */ import net.minecraftforge.event.RegisterCommandsEvent;
/*     */ import net.minecraftforge.event.server.ServerAboutToStartEvent;
/*     */ import net.minecraftforge.event.server.ServerStoppedEvent;
/*     */ import net.minecraftforge.eventbus.api.IEventBus;
/*     */ import net.minecraftforge.eventbus.api.SubscribeEvent;
/*     */ import net.minecraftforge.fml.DistExecutor;
/*     */ import net.minecraftforge.fml.ModLoadingContext;
/*     */ import net.minecraftforge.fml.common.Mod;
/*     */ import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
/*     */ import net.minecraftforge.fml.config.IConfigSpec;
/*     */ import net.minecraftforge.fml.config.ModConfig;
/*     */ import net.minecraftforge.fml.event.config.ModConfigEvent;
/*     */ import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
/*     */ import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
/*     */ import net.minecraftforge.fml.event.lifecycle.InterModProcessEvent;
/*     */ import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import top.theillusivec4.curios.api.CuriosApi;
/*     */ import top.theillusivec4.curios.api.client.CuriosRendererRegistry;
/*     */ import top.theillusivec4.curios.api.type.capability.ICurio;
/*     */ import top.theillusivec4.curios.api.type.capability.ICuriosItemHandler;
/*     */ import top.theillusivec4.curios.api.type.util.ICuriosHelper;
/*     */ import top.theillusivec4.curios.api.type.util.IIconHelper;
/*     */ import top.theillusivec4.curios.api.type.util.ISlotHelper;
/*     */ import top.theillusivec4.curios.client.ClientEventHandler;
/*     */ import top.theillusivec4.curios.client.CuriosClientConfig;
/*     */ import top.theillusivec4.curios.client.CuriosClientMod;
/*     */ import top.theillusivec4.curios.client.IconHelper;
/*     */ import top.theillusivec4.curios.client.KeyRegistry;
/*     */ import top.theillusivec4.curios.client.gui.GuiEventHandler;
/*     */ import top.theillusivec4.curios.client.render.CuriosLayer;
/*     */ import top.theillusivec4.curios.common.CuriosConfig;
/*     */ import top.theillusivec4.curios.common.CuriosHelper;
/*     */ import top.theillusivec4.curios.common.CuriosRegistry;
/*     */ import top.theillusivec4.curios.common.event.CuriosEventHandler;
/*     */ import top.theillusivec4.curios.common.network.NetworkHandler;
/*     */ import top.theillusivec4.curios.common.slottype.SlotTypeManager;
/*     */ import top.theillusivec4.curios.common.util.EquipCurioTrigger;
/*     */ import top.theillusivec4.curios.common.util.SetCurioAttributesFunction;
/*     */ import top.theillusivec4.curios.server.SlotHelper;
/*     */ import top.theillusivec4.curios.server.command.CurioArgumentType;
/*     */ import top.theillusivec4.curios.server.command.CuriosCommand;
/*     */ import top.theillusivec4.curios.server.command.CuriosSelectorOptions;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Mod("curios")
/*     */ public class Curios
/*     */ {
/*     */   public static final String MODID = "curios";
/*  88 */   public static final Logger LOGGER = LogManager.getLogger();
/*     */   
/*     */   public Curios() {
/*  91 */     DistExecutor.safeRunWhenOn(Dist.CLIENT, () -> CuriosClientMod::init);
/*  92 */     IEventBus eventBus = FMLJavaModLoadingContext.get().getModEventBus();
/*  93 */     eventBus.addListener(this::setup);
/*  94 */     eventBus.addListener(this::config);
/*  95 */     eventBus.addListener(this::process);
/*  96 */     eventBus.addListener(this::registerCaps);
/*  97 */     MinecraftForge.EVENT_BUS.addListener(this::serverAboutToStart);
/*  98 */     MinecraftForge.EVENT_BUS.addListener(this::serverStopped);
/*  99 */     MinecraftForge.EVENT_BUS.addListener(this::registerCommands);
/* 100 */     MinecraftForge.EVENT_BUS.addListener(this::reload);
/* 101 */     ModLoadingContext.get().registerConfig(ModConfig.Type.CLIENT, (IConfigSpec)CuriosClientConfig.CLIENT_SPEC);
/* 102 */     ModLoadingContext.get().registerConfig(ModConfig.Type.SERVER, (IConfigSpec)CuriosConfig.SERVER_SPEC);
/*     */   }
/*     */   
/*     */   private void setup(FMLCommonSetupEvent evt) {
/* 106 */     CuriosApi.setCuriosHelper((ICuriosHelper)new CuriosHelper());
/* 107 */     MinecraftForge.EVENT_BUS.register(new CuriosEventHandler());
/* 108 */     NetworkHandler.register();
/* 109 */     evt.enqueueWork(() -> {
/*     */           ArgumentTypes.m_121601_("curios:slot_type", CurioArgumentType.class, (ArgumentSerializer)new EmptyArgumentSerializer(CurioArgumentType::slot));
/*     */           CriteriaTriggers.m_10595_((CriterionTrigger)EquipCurioTrigger.INSTANCE);
/*     */           CuriosSelectorOptions.register();
/*     */           SetCurioAttributesFunction.register();
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   private void registerCaps(RegisterCapabilitiesEvent evt) {
/* 119 */     evt.register(ICuriosItemHandler.class);
/* 120 */     evt.register(ICurio.class);
/*     */   }
/*     */   
/*     */   private void process(InterModProcessEvent evt) {
/* 124 */     SlotTypeManager.buildImcSlotTypes(evt.getIMCStream("register_type"::equals), evt
/* 125 */         .getIMCStream("modify_type"::equals));
/*     */   }
/*     */   
/*     */   private void serverAboutToStart(ServerAboutToStartEvent evt) {
/* 129 */     CuriosApi.setSlotHelper((ISlotHelper)new SlotHelper());
/* 130 */     SlotTypeManager.buildSlotTypes();
/*     */   }
/*     */   
/*     */   private void serverStopped(ServerStoppedEvent evt) {
/* 134 */     CuriosApi.setSlotHelper(null);
/*     */   }
/*     */   
/*     */   private void registerCommands(RegisterCommandsEvent evt) {
/* 138 */     CuriosCommand.register(evt.getDispatcher());
/*     */   }
/*     */   
/*     */   private void reload(AddReloadListenerEvent evt) {
/* 142 */     evt.addListener((PreparableReloadListener)new SimplePreparableReloadListener<Void>()
/*     */         {
/*     */           @Nonnull
/*     */           protected Void prepare(@Nonnull ResourceManager resourceManagerIn, @Nonnull ProfilerFiller profilerIn)
/*     */           {
/* 147 */             return null;
/*     */           }
/*     */ 
/*     */ 
/*     */           
/*     */           protected void apply(@Nonnull Void objectIn, @Nonnull ResourceManager resourceManagerIn, @Nonnull ProfilerFiller profilerIn) {
/* 153 */             CuriosEventHandler.dirtyTags = true;
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   private void config(ModConfigEvent.Loading evt) {
/* 160 */     if (evt.getConfig().getModId().equals("curios"))
/*     */     {
/* 162 */       if (evt.getConfig().getType() == ModConfig.Type.SERVER) {
/* 163 */         IConfigSpec<?> spec = evt.getConfig().getSpec();
/* 164 */         CommentedConfig commentedConfig = evt.getConfig().getConfigData();
/*     */         
/* 166 */         if (spec == CuriosConfig.SERVER_SPEC) {
/* 167 */           CuriosConfig.transformCurios(commentedConfig);
/* 168 */           SlotTypeManager.buildConfigSlotTypes();
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   @EventBusSubscriber(modid = "curios", value = {Dist.CLIENT}, bus = Mod.EventBusSubscriber.Bus.MOD)
/*     */   public static class ClientProxy
/*     */   {
/*     */     @SubscribeEvent
/*     */     public static void stitchTextures(TextureStitchEvent.Pre evt) {
/* 179 */       CuriosClientMod.stitch(evt);
/*     */     }
/*     */     
/*     */     @SubscribeEvent
/*     */     public static void setupClient(FMLClientSetupEvent evt) {
/* 184 */       CuriosApi.setIconHelper((IIconHelper)new IconHelper());
/* 185 */       MinecraftForge.EVENT_BUS.register(new ClientEventHandler());
/* 186 */       MinecraftForge.EVENT_BUS.register(new GuiEventHandler());
/* 187 */       MenuScreens.m_96206_(CuriosRegistry.CONTAINER_TYPE, top.theillusivec4.curios.client.gui.CuriosScreen::new);
/* 188 */       KeyRegistry.registerKeys();
/*     */     }
/*     */     
/*     */     @SubscribeEvent
/*     */     public static void addLayers(EntityRenderersEvent.AddLayers evt) {
/* 193 */       addPlayerLayer(evt, "default");
/* 194 */       addPlayerLayer(evt, "slim");
/* 195 */       CuriosRendererRegistry.load();
/*     */     }
/*     */ 
/*     */     
/*     */     private static void addPlayerLayer(EntityRenderersEvent.AddLayers evt, String skin) {
/* 200 */       LivingEntityRenderer livingEntityRenderer = evt.getSkin(skin);
/*     */       
/* 202 */       if (livingEntityRenderer instanceof LivingEntityRenderer) { LivingEntityRenderer livingRenderer = livingEntityRenderer;
/* 203 */         livingRenderer.m_115326_((RenderLayer)new CuriosLayer((RenderLayerParent)livingRenderer)); }
/*     */     
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\curios-309927-4590652.jar!\top\theillusivec4\curios\Curios.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */