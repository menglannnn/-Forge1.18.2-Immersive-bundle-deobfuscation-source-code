/*    */ package top.theillusivec4.curios.server.command;
/*    */ 
/*    */ import com.mojang.brigadier.Message;
/*    */ import com.mojang.brigadier.StringReader;
/*    */ import com.mojang.brigadier.arguments.ArgumentType;
/*    */ import com.mojang.brigadier.context.CommandContext;
/*    */ import com.mojang.brigadier.exceptions.CommandSyntaxException;
/*    */ import com.mojang.brigadier.exceptions.DynamicCommandExceptionType;
/*    */ import com.mojang.brigadier.suggestion.Suggestions;
/*    */ import com.mojang.brigadier.suggestion.SuggestionsBuilder;
/*    */ import java.util.Arrays;
/*    */ import java.util.Collection;
/*    */ import java.util.HashSet;
/*    */ import java.util.Set;
/*    */ import java.util.concurrent.CompletableFuture;
/*    */ import net.minecraft.commands.CommandSourceStack;
/*    */ import net.minecraft.commands.SharedSuggestionProvider;
/*    */ import net.minecraft.network.chat.TranslatableComponent;
/*    */ import top.theillusivec4.curios.api.CuriosApi;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CurioArgumentType
/*    */   implements ArgumentType<String>
/*    */ {
/* 41 */   public static Set<String> slotIds = new HashSet<>();
/*    */   
/* 43 */   private static final Collection<String> EXAMPLES = Arrays.asList(new String[] { "ring", "head" }); static {
/* 44 */     UNKNOWN_TYPE = new DynamicCommandExceptionType(type -> new TranslatableComponent("argument.curios.type.unknown", new Object[] { type }));
/*    */   }
/*    */   private static final DynamicCommandExceptionType UNKNOWN_TYPE;
/*    */   public static CurioArgumentType slot() {
/* 48 */     return new CurioArgumentType();
/*    */   }
/*    */   
/*    */   public static String getSlot(CommandContext<CommandSourceStack> context, String name) {
/* 52 */     return (String)context.getArgument(name, String.class);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public <S> CompletableFuture<Suggestions> listSuggestions(CommandContext<S> context, SuggestionsBuilder builder) {
/* 58 */     return SharedSuggestionProvider.m_82970_(slotIds, builder);
/*    */   }
/*    */ 
/*    */   
/*    */   public Collection<String> getExamples() {
/* 63 */     return EXAMPLES;
/*    */   }
/*    */ 
/*    */   
/*    */   public String parse(StringReader reader) throws CommandSyntaxException {
/* 68 */     String s = reader.readUnquotedString();
/*    */     
/* 70 */     if (CuriosApi.getSlotHelper() != null && !slotIds.contains(s)) {
/* 71 */       throw UNKNOWN_TYPE.create(s);
/*    */     }
/* 73 */     return s;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\curios-309927-4590652.jar!\top\theillusivec4\curios\server\command\CurioArgumentType.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */