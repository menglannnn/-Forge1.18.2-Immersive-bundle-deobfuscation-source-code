/*     */ package top.theillusivec4.curios.server;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Optional;
/*     */ import java.util.Set;
/*     */ import java.util.SortedMap;
/*     */ import java.util.TreeMap;
/*     */ import javax.annotation.Nonnull;
/*     */ import net.minecraft.world.entity.LivingEntity;
/*     */ import top.theillusivec4.curios.api.CuriosApi;
/*     */ import top.theillusivec4.curios.api.type.ISlotType;
/*     */ import top.theillusivec4.curios.api.type.capability.ICuriosItemHandler;
/*     */ import top.theillusivec4.curios.api.type.inventory.ICurioStacksHandler;
/*     */ import top.theillusivec4.curios.api.type.util.ISlotHelper;
/*     */ import top.theillusivec4.curios.common.inventory.CurioStacksHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SlotHelper
/*     */   implements ISlotHelper
/*     */ {
/*  40 */   private Map<String, ISlotType> idToType = new HashMap<>();
/*     */ 
/*     */   
/*     */   public void addSlotType(ISlotType slotType) {
/*  44 */     this.idToType.put(slotType.getIdentifier(), slotType);
/*     */   }
/*     */ 
/*     */   
/*     */   public Optional<ISlotType> getSlotType(String identifier) {
/*  49 */     return Optional.ofNullable(this.idToType.get(identifier));
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection<ISlotType> getSlotTypes() {
/*  54 */     return Collections.unmodifiableCollection(this.idToType.values());
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection<ISlotType> getSlotTypes(LivingEntity livingEntity) {
/*  59 */     return getSlotTypes();
/*     */   }
/*     */ 
/*     */   
/*     */   public SortedMap<ISlotType, ICurioStacksHandler> createSlots() {
/*  64 */     SortedMap<ISlotType, ICurioStacksHandler> curios = new TreeMap<>();
/*  65 */     getSlotTypes().forEach(type -> curios.put(type, new CurioStacksHandler(null, type.getIdentifier(), type.getSize(), type.isVisible(), type.hasCosmetic())));
/*     */ 
/*     */     
/*  68 */     return curios;
/*     */   }
/*     */ 
/*     */   
/*     */   public SortedMap<ISlotType, ICurioStacksHandler> createSlots(LivingEntity livingEntity) {
/*  73 */     SortedMap<ISlotType, ICurioStacksHandler> curios = new TreeMap<>();
/*  74 */     CuriosApi.getCuriosHelper().getCuriosHandler(livingEntity).ifPresent(handler -> getSlotTypes().forEach(()));
/*     */ 
/*     */ 
/*     */     
/*  78 */     return curios;
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<String> getSlotTypeIds() {
/*  83 */     return Collections.unmodifiableSet(this.idToType.keySet());
/*     */   }
/*     */ 
/*     */   
/*     */   public int getSlotsForType(@Nonnull LivingEntity livingEntity, String identifier) {
/*  88 */     return ((Integer)CuriosApi.getCuriosHelper().getCuriosHandler(livingEntity).map(handler -> (Integer)handler.getStacksHandler(identifier).map(ICurioStacksHandler::getSlots).orElse(Integer.valueOf(0)))
/*     */       
/*  90 */       .orElse(Integer.valueOf(0))).intValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setSlotsForType(String id, LivingEntity livingEntity, int amount) {
/*  95 */     int difference = amount - getSlotsForType(livingEntity, id);
/*     */     
/*  97 */     if (difference > 0) {
/*  98 */       growSlotType(id, difference, livingEntity);
/*  99 */     } else if (difference < 0) {
/* 100 */       shrinkSlotType(id, Math.abs(difference), livingEntity);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void growSlotType(String id, LivingEntity livingEntity) {
/* 106 */     growSlotType(id, 1, livingEntity);
/*     */   }
/*     */ 
/*     */   
/*     */   public void growSlotType(String id, int amount, LivingEntity livingEntity) {
/* 111 */     CuriosApi.getCuriosHelper().getCuriosHandler(livingEntity)
/* 112 */       .ifPresent(handler -> handler.growSlotType(id, amount));
/*     */   }
/*     */ 
/*     */   
/*     */   public void shrinkSlotType(String id, LivingEntity livingEntity) {
/* 117 */     shrinkSlotType(id, 1, livingEntity);
/*     */   }
/*     */ 
/*     */   
/*     */   public void shrinkSlotType(String id, int amount, LivingEntity livingEntity) {
/* 122 */     CuriosApi.getCuriosHelper().getCuriosHandler(livingEntity)
/* 123 */       .ifPresent(handler -> handler.shrinkSlotType(id, amount));
/*     */   }
/*     */ 
/*     */   
/*     */   public void unlockSlotType(String id, LivingEntity livingEntity) {
/* 128 */     CuriosApi.getCuriosHelper().getCuriosHandler(livingEntity).ifPresent(handler -> {
/*     */           if (((Boolean)handler.getStacksHandler(id).map(()).orElse(Boolean.valueOf(false))).booleanValue()) {
/*     */             handler.growSlotType(id, 1);
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void lockSlotType(String id, LivingEntity livingEntity) {
/* 139 */     CuriosApi.getCuriosHelper().getCuriosHandler(livingEntity).ifPresent(handler -> {
/*     */           int amount = ((Integer)handler.getStacksHandler(id).map(ICurioStacksHandler::getSlots).orElse(Integer.valueOf(0))).intValue();
/*     */           if (amount > 0)
/*     */             handler.shrinkSlotType(id, amount); 
/*     */         });
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\curios-309927-4590652.jar!\top\theillusivec4\curios\server\SlotHelper.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */