/*     */ package top.theillusivec4.curios.server.command;
/*     */ 
/*     */ import com.mojang.brigadier.CommandDispatcher;
/*     */ import com.mojang.brigadier.arguments.ArgumentType;
/*     */ import com.mojang.brigadier.arguments.IntegerArgumentType;
/*     */ import com.mojang.brigadier.builder.LiteralArgumentBuilder;
/*     */ import com.mojang.brigadier.builder.RequiredArgumentBuilder;
/*     */ import com.mojang.brigadier.context.CommandContext;
/*     */ import com.mojang.brigadier.exceptions.CommandSyntaxException;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import net.minecraft.commands.CommandSourceStack;
/*     */ import net.minecraft.commands.Commands;
/*     */ import net.minecraft.commands.arguments.EntityArgument;
/*     */ import net.minecraft.commands.arguments.item.ItemArgument;
/*     */ import net.minecraft.commands.arguments.item.ItemInput;
/*     */ import net.minecraft.network.chat.Component;
/*     */ import net.minecraft.network.chat.TextComponent;
/*     */ import net.minecraft.network.chat.TranslatableComponent;
/*     */ import net.minecraft.server.level.ServerPlayer;
/*     */ import net.minecraft.world.entity.LivingEntity;
/*     */ import net.minecraft.world.item.ItemStack;
/*     */ import net.minecraftforge.network.PacketDistributor;
/*     */ import top.theillusivec4.curios.api.CuriosApi;
/*     */ import top.theillusivec4.curios.api.type.capability.ICuriosItemHandler;
/*     */ import top.theillusivec4.curios.api.type.inventory.ICurioStacksHandler;
/*     */ import top.theillusivec4.curios.common.network.NetworkHandler;
/*     */ import top.theillusivec4.curios.common.network.server.sync.SPacketSyncCurios;
/*     */ import top.theillusivec4.curios.common.slottype.SlotTypeManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CuriosCommand
/*     */ {
/*     */   public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
/*  50 */     LiteralArgumentBuilder<CommandSourceStack> curiosCommand = (LiteralArgumentBuilder<CommandSourceStack>)Commands.m_82127_("curios").requires(player -> player.m_6761_(2));
/*     */     
/*  52 */     curiosCommand.then(Commands.m_82127_("list").executes(context -> {
/*     */             Map<String, Set<String>> map = SlotTypeManager.getIdsToMods();
/*     */             
/*     */             for (Map.Entry<String, Set<String>> entry : map.entrySet()) {
/*     */               ((CommandSourceStack)context.getSource()).m_81354_((Component)new TextComponent((String)entry.getKey() + " - " + (String)entry.getKey()), false);
/*     */             }
/*     */             
/*     */             return 1;
/*     */           }));
/*     */     
/*  62 */     curiosCommand.then(Commands.m_82127_("replace").then(
/*  63 */           Commands.m_82129_("slot", CurioArgumentType.slot()).then(
/*  64 */             Commands.m_82129_("index", (ArgumentType)IntegerArgumentType.integer()).then(
/*  65 */               Commands.m_82129_("player", (ArgumentType)EntityArgument.m_91466_()).then(
/*  66 */                 Commands.m_82127_("with").then((
/*  67 */                   (RequiredArgumentBuilder)Commands.m_82129_("item", (ArgumentType)ItemArgument.m_120960_()).executes(context -> replaceItemForPlayer((CommandSourceStack)context.getSource(), EntityArgument.m_91474_(context, "player"), CurioArgumentType.getSlot(context, "slot"), IntegerArgumentType.getInteger(context, "index"), ItemArgument.m_120963_(context, "item"))))
/*     */ 
/*     */ 
/*     */ 
/*     */                   
/*  72 */                   .then(
/*  73 */                     Commands.m_82129_("count", (ArgumentType)IntegerArgumentType.integer()).executes(context -> replaceItemForPlayer((CommandSourceStack)context.getSource(), EntityArgument.m_91474_(context, "player"), CurioArgumentType.getSlot(context, "slot"), IntegerArgumentType.getInteger(context, "index"), ItemArgument.m_120963_(context, "item"), IntegerArgumentType.getInteger(context, "count"))))))))));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  81 */     curiosCommand.then(Commands.m_82127_("set").then(
/*  82 */           Commands.m_82129_("slot", CurioArgumentType.slot()).then((
/*  83 */             (RequiredArgumentBuilder)Commands.m_82129_("player", (ArgumentType)EntityArgument.m_91466_()).executes(context -> setSlotsForPlayer((CommandSourceStack)context.getSource(), EntityArgument.m_91474_(context, "player"), CurioArgumentType.getSlot(context, "slot"), 1)))
/*     */ 
/*     */             
/*  86 */             .then(
/*  87 */               Commands.m_82129_("amount", (ArgumentType)IntegerArgumentType.integer()).executes(context -> setSlotsForPlayer((CommandSourceStack)context.getSource(), EntityArgument.m_91474_(context, "player"), CurioArgumentType.getSlot(context, "slot"), IntegerArgumentType.getInteger(context, "amount")))))));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  93 */     curiosCommand.then(Commands.m_82127_("add").then(
/*  94 */           Commands.m_82129_("slot", CurioArgumentType.slot()).then((
/*  95 */             (RequiredArgumentBuilder)Commands.m_82129_("player", (ArgumentType)EntityArgument.m_91466_()).executes(context -> growSlotForPlayer((CommandSourceStack)context.getSource(), EntityArgument.m_91474_(context, "player"), CurioArgumentType.getSlot(context, "slot"), 1)))
/*     */ 
/*     */             
/*  98 */             .then(
/*  99 */               Commands.m_82129_("amount", (ArgumentType)IntegerArgumentType.integer()).executes(context -> growSlotForPlayer((CommandSourceStack)context.getSource(), EntityArgument.m_91474_(context, "player"), CurioArgumentType.getSlot(context, "slot"), IntegerArgumentType.getInteger(context, "amount")))))));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 105 */     curiosCommand.then(Commands.m_82127_("remove").then(
/* 106 */           Commands.m_82129_("slot", CurioArgumentType.slot()).then((
/* 107 */             (RequiredArgumentBuilder)Commands.m_82129_("player", (ArgumentType)EntityArgument.m_91466_()).executes(context -> shrinkSlotForPlayer((CommandSourceStack)context.getSource(), EntityArgument.m_91474_(context, "player"), CurioArgumentType.getSlot(context, "slot"), 1)))
/*     */ 
/*     */             
/* 110 */             .then(
/* 111 */               Commands.m_82129_("amount", (ArgumentType)IntegerArgumentType.integer()).executes(context -> shrinkSlotForPlayer((CommandSourceStack)context.getSource(), EntityArgument.m_91474_(context, "player"), CurioArgumentType.getSlot(context, "slot"), IntegerArgumentType.getInteger(context, "amount")))))));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 117 */     curiosCommand.then(Commands.m_82127_("clear").then((
/* 118 */           (RequiredArgumentBuilder)Commands.m_82129_("player", (ArgumentType)EntityArgument.m_91466_()).executes(context -> clearSlotsForPlayer((CommandSourceStack)context.getSource(), EntityArgument.m_91474_(context, "player"), "")))
/*     */           
/* 120 */           .then(
/* 121 */             Commands.m_82129_("slot", CurioArgumentType.slot()).executes(context -> clearSlotsForPlayer((CommandSourceStack)context.getSource(), EntityArgument.m_91474_(context, "player"), CurioArgumentType.getSlot(context, "slot"))))));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 126 */     curiosCommand.then(Commands.m_82127_("drop").then((
/* 127 */           (RequiredArgumentBuilder)Commands.m_82129_("player", (ArgumentType)EntityArgument.m_91466_()).executes(context -> dropSlotsForPlayer((CommandSourceStack)context.getSource(), EntityArgument.m_91474_(context, "player"), "")))
/*     */           
/* 129 */           .then(
/* 130 */             Commands.m_82129_("slot", CurioArgumentType.slot()).executes(context -> dropSlotsForPlayer((CommandSourceStack)context.getSource(), EntityArgument.m_91474_(context, "player"), CurioArgumentType.getSlot(context, "slot"))))));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 135 */     curiosCommand.then(Commands.m_82127_("reset").then(
/* 136 */           Commands.m_82129_("player", (ArgumentType)EntityArgument.m_91466_()).executes(context -> resetSlotsForPlayer((CommandSourceStack)context.getSource(), EntityArgument.m_91474_(context, "player")))));
/*     */ 
/*     */ 
/*     */     
/* 140 */     dispatcher.register(curiosCommand);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static int replaceItemForPlayer(CommandSourceStack source, ServerPlayer player, String slot, int index, ItemInput item) throws CommandSyntaxException {
/* 146 */     return replaceItemForPlayer(source, player, slot, index, item, 1);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static int replaceItemForPlayer(CommandSourceStack source, ServerPlayer player, String slot, int index, ItemInput item, int count) throws CommandSyntaxException {
/* 152 */     ItemStack stack = item.m_120980_(count, false);
/* 153 */     CuriosApi.getCuriosHelper().setEquippedCurio((LivingEntity)player, slot, index, stack);
/* 154 */     source.m_81354_((Component)new TranslatableComponent("commands.curios.replace.success", new Object[] { slot, player
/* 155 */             .m_5446_(), stack
/* 156 */             .m_41611_() }), true);
/* 157 */     return 1;
/*     */   }
/*     */ 
/*     */   
/*     */   private static int setSlotsForPlayer(CommandSourceStack source, ServerPlayer playerMP, String slot, int amount) {
/* 162 */     CuriosApi.getSlotHelper().setSlotsForType(slot, (LivingEntity)playerMP, amount);
/* 163 */     source.m_81354_((Component)new TranslatableComponent("commands.curios.set.success", new Object[] { slot, 
/* 164 */             Integer.valueOf(CuriosApi.getSlotHelper().getSlotsForType((LivingEntity)playerMP, slot)), playerMP.m_5446_() }), true);
/*     */     
/* 166 */     return 1;
/*     */   }
/*     */ 
/*     */   
/*     */   private static int growSlotForPlayer(CommandSourceStack source, ServerPlayer playerMP, String slot, int amount) {
/* 171 */     CuriosApi.getSlotHelper().growSlotType(slot, amount, (LivingEntity)playerMP);
/* 172 */     source.m_81354_((Component)new TranslatableComponent("commands.curios.add.success", new Object[] { Integer.valueOf(amount), slot, playerMP
/* 173 */             .m_5446_() }), true);
/* 174 */     return 1;
/*     */   }
/*     */ 
/*     */   
/*     */   private static int shrinkSlotForPlayer(CommandSourceStack source, ServerPlayer playerMP, String slot, int amount) {
/* 179 */     CuriosApi.getSlotHelper().shrinkSlotType(slot, amount, (LivingEntity)playerMP);
/* 180 */     source.m_81354_((Component)new TranslatableComponent("commands.curios.remove.success", new Object[] { Integer.valueOf(amount), slot, playerMP
/* 181 */             .m_5446_() }), true);
/* 182 */     return 1;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static int dropSlotsForPlayer(CommandSourceStack source, ServerPlayer playerMP, String slot) {
/* 188 */     CuriosApi.getCuriosHelper().getCuriosHandler((LivingEntity)playerMP).ifPresent(handler -> {
/*     */           Map<String, ICurioStacksHandler> curios = handler.getCurios();
/*     */ 
/*     */           
/*     */           if (!slot.isEmpty() && curios.get(slot) != null) {
/*     */             drop(curios.get(slot), playerMP);
/*     */           } else {
/*     */             for (String id : curios.keySet()) {
/*     */               drop(curios.get(id), playerMP);
/*     */             }
/*     */           } 
/*     */         });
/*     */     
/* 201 */     if (slot.isEmpty()) {
/* 202 */       source.m_81354_((Component)new TranslatableComponent("commands.curios.dropAll.success", new Object[] { playerMP
/* 203 */               .m_5446_() }), true);
/*     */     } else {
/* 205 */       source.m_81354_((Component)new TranslatableComponent("commands.curios.drop.success", new Object[] { slot, playerMP
/* 206 */               .m_5446_() }), true);
/*     */     } 
/* 208 */     return 1;
/*     */   }
/*     */ 
/*     */   
/*     */   private static void drop(ICurioStacksHandler stacksHandler, ServerPlayer serverPlayer) {
/* 213 */     for (int i = 0; i < stacksHandler.getSlots(); i++) {
/* 214 */       ItemStack stack1 = stacksHandler.getStacks().getStackInSlot(i);
/* 215 */       stacksHandler.getStacks().setStackInSlot(i, ItemStack.f_41583_);
/* 216 */       ItemStack stack2 = stacksHandler.getCosmeticStacks().getStackInSlot(i);
/* 217 */       stacksHandler.getCosmeticStacks().setStackInSlot(i, ItemStack.f_41583_);
/*     */       
/* 219 */       if (!stack1.m_41619_()) {
/* 220 */         serverPlayer.m_7197_(stack1, true, false);
/*     */       }
/*     */       
/* 223 */       if (!stack2.m_41619_()) {
/* 224 */         serverPlayer.m_7197_(stack2, true, false);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static int clearSlotsForPlayer(CommandSourceStack source, ServerPlayer playerMP, String slot) {
/* 232 */     CuriosApi.getCuriosHelper().getCuriosHandler((LivingEntity)playerMP).ifPresent(handler -> {
/*     */           Map<String, ICurioStacksHandler> curios = handler.getCurios();
/*     */ 
/*     */           
/*     */           if (!slot.isEmpty() && curios.get(slot) != null) {
/*     */             clear(curios.get(slot));
/*     */           } else {
/*     */             for (String id : curios.keySet()) {
/*     */               clear(curios.get(id));
/*     */             }
/*     */           } 
/*     */         });
/*     */     
/* 245 */     if (slot.isEmpty()) {
/* 246 */       source.m_81354_((Component)new TranslatableComponent("commands.curios.clearAll.success", new Object[] { playerMP
/* 247 */               .m_5446_() }), true);
/*     */     } else {
/* 249 */       source.m_81354_((Component)new TranslatableComponent("commands.curios.clear.success", new Object[] { slot, playerMP
/* 250 */               .m_5446_() }), true);
/*     */     } 
/* 252 */     return 1;
/*     */   }
/*     */   
/*     */   private static int resetSlotsForPlayer(CommandSourceStack source, ServerPlayer playerMP) {
/* 256 */     CuriosApi.getCuriosHelper().getCuriosHandler((LivingEntity)playerMP).ifPresent(handler -> {
/*     */           handler.reset();
/*     */           
/*     */           NetworkHandler.INSTANCE.send(PacketDistributor.PLAYER.with(()), new SPacketSyncCurios(playerMP.m_142049_(), handler.getCurios()));
/*     */         });
/* 261 */     source.m_81354_((Component)new TranslatableComponent("commands.curios.reset.success", new Object[] { playerMP
/* 262 */             .m_5446_() }), true);
/*     */     
/* 264 */     return 1;
/*     */   }
/*     */ 
/*     */   
/*     */   private static void clear(ICurioStacksHandler stacksHandler) {
/* 269 */     for (int i = 0; i < stacksHandler.getSlots(); i++) {
/* 270 */       stacksHandler.getStacks().setStackInSlot(i, ItemStack.f_41583_);
/* 271 */       stacksHandler.getCosmeticStacks().setStackInSlot(i, ItemStack.f_41583_);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\curios-309927-4590652.jar!\top\theillusivec4\curios\server\command\CuriosCommand.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */