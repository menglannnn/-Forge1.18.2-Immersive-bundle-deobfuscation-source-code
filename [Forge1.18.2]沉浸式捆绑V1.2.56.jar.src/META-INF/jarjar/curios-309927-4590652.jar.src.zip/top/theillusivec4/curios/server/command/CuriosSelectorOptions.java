/*     */ package top.theillusivec4.curios.server.command;
/*     */ 
/*     */ import com.mojang.brigadier.StringReader;
/*     */ import com.mojang.brigadier.exceptions.CommandSyntaxException;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import net.minecraft.commands.arguments.selector.EntitySelectorParser;
/*     */ import net.minecraft.commands.arguments.selector.options.EntitySelectorOptions;
/*     */ import net.minecraft.nbt.CompoundTag;
/*     */ import net.minecraft.nbt.ListTag;
/*     */ import net.minecraft.nbt.TagParser;
/*     */ import net.minecraft.network.chat.Component;
/*     */ import net.minecraft.network.chat.TranslatableComponent;
/*     */ import net.minecraft.world.entity.Entity;
/*     */ import net.minecraft.world.entity.LivingEntity;
/*     */ import net.minecraft.world.item.ItemStack;
/*     */ import top.theillusivec4.curios.api.CuriosApi;
/*     */ import top.theillusivec4.curios.api.type.capability.ICuriosItemHandler;
/*     */ import top.theillusivec4.curios.api.type.inventory.ICurioStacksHandler;
/*     */ 
/*     */ public class CuriosSelectorOptions {
/*     */   public static void register() {
/*  24 */     EntitySelectorOptions.m_121453_("curios", CuriosSelectorOptions::curioArgument, entitySelectorParser -> true, (Component)new TranslatableComponent("argument.entity.options.curios.description"));
/*     */   }
/*     */ 
/*     */   
/*     */   private static void curioArgument(EntitySelectorParser parser) throws CommandSyntaxException {
/*  29 */     StringReader reader = parser.m_121346_();
/*  30 */     boolean invert = parser.m_121330_();
/*  31 */     CompoundTag compoundtag = (new TagParser(reader)).m_129373_();
/*  32 */     ListTag listTag = compoundtag.m_128437_("slot", 8);
/*  33 */     Set<String> slots = new HashSet<>();
/*     */     
/*  35 */     for (int i = 0; i < listTag.size(); i++) {
/*  36 */       slots.add(listTag.m_128778_(i));
/*     */     }
/*  38 */     listTag = compoundtag.m_128437_("index", 3);
/*  39 */     int min = 0;
/*  40 */     int max = -1;
/*     */     
/*  42 */     if (listTag.size() == 2) {
/*  43 */       min = Math.max(0, listTag.m_128763_(0));
/*  44 */       max = Math.max(min + 1, listTag.m_128763_(1));
/*     */     } 
/*     */     
/*  47 */     ItemStack stack = compoundtag.m_128441_("item") ? ItemStack.m_41712_(compoundtag.m_128469_("item")) : null;
/*     */     
/*  49 */     if (stack != null) {
/*  50 */       stack.m_41764_(Math.max(1, stack.m_41613_()));
/*     */     }
/*  52 */     boolean exclusive = compoundtag.m_128471_("exclusive");
/*  53 */     int finalMin = min;
/*  54 */     int finalMax = max;
/*  55 */     parser.m_121272_(entity -> matches(entity, slots, finalMin, finalMax, stack, invert, exclusive));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean matches(Entity entity, Set<String> slots, int min, int max, ItemStack stack, boolean invert, boolean exclusive) {
/*  62 */     if (entity instanceof LivingEntity) { LivingEntity livingEntity = (LivingEntity)entity;
/*  63 */       return ((Boolean)CuriosApi.getCuriosHelper().getCuriosHandler(livingEntity).map(handler -> {
/*     */             Map<String, ICurioStacksHandler> curios = handler.getCurios();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/*     */             return (stack != null) ? (exclusive ? Boolean.valueOf(hasOnlyItem(curios, slots, min, max, stack, invert)) : Boolean.valueOf(hasItem(curios, slots, min, max, stack, invert))) : (!slots.isEmpty() ? (exclusive ? Boolean.valueOf(hasOnlySlot(curios, slots, max, invert)) : Boolean.valueOf(hasSlot(curios, slots, max, invert))) : Boolean.valueOf(true));
/*  82 */           }).orElse(Boolean.valueOf(false))).booleanValue(); }
/*     */     
/*  84 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean hasOnlySlot(Map<String, ICurioStacksHandler> curios, Set<String> slots, int max, boolean invert) {
/*  91 */     boolean foundSlot = false;
/*     */     
/*  93 */     if (invert) {
/*     */       
/*  95 */       for (Map.Entry<String, ICurioStacksHandler> entry : curios.entrySet()) {
/*     */         
/*  97 */         if (matches(slots, max, entry.getKey(), entry.getValue())) {
/*  98 */           foundSlot = true; continue;
/*  99 */         }  if (foundSlot) {
/* 100 */           return true;
/*     */         }
/*     */       } 
/* 103 */       return false;
/*     */     } 
/*     */     
/* 106 */     for (Map.Entry<String, ICurioStacksHandler> entry : curios.entrySet()) {
/*     */       
/* 108 */       if (matches(slots, max, entry.getKey(), entry.getValue())) {
/* 109 */         foundSlot = true; continue;
/* 110 */       }  if (foundSlot) {
/* 111 */         return false;
/*     */       }
/*     */     } 
/* 114 */     return foundSlot;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean hasSlot(Map<String, ICurioStacksHandler> curios, Set<String> slots, int max, boolean invert) {
/* 121 */     for (Map.Entry<String, ICurioStacksHandler> entry : curios.entrySet()) {
/*     */       
/* 123 */       if (matches(slots, max, entry.getKey(), entry.getValue())) {
/* 124 */         return !invert;
/*     */       }
/*     */     } 
/* 127 */     return invert;
/*     */   }
/*     */ 
/*     */   
/*     */   private static boolean matches(Set<String> slots, int max, String id, ICurioStacksHandler stacks) {
/* 132 */     int size = stacks.getSlots();
/* 133 */     return (slots.contains(id) && size > 0 && (max == -1 || size >= max));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean hasOnlyItem(Map<String, ICurioStacksHandler> curios, Set<String> slots, int min, int max, ItemStack stack, boolean invert) {
/* 139 */     boolean foundItem = false;
/*     */     
/* 141 */     if (invert) {
/*     */       
/* 143 */       for (Map.Entry<String, ICurioStacksHandler> entry : curios.entrySet()) {
/*     */         
/* 145 */         if (slots.isEmpty() || slots.contains(entry.getKey())) {
/* 146 */           ICurioStacksHandler stacks = entry.getValue();
/* 147 */           int limit = (max == -1) ? stacks.getSlots() : Math.min(stacks.getSlots(), max);
/*     */           
/* 149 */           for (int i = min; i < limit; i++) {
/* 150 */             ItemStack current = stacks.getStacks().getStackInSlot(i);
/*     */             
/* 152 */             if (ItemStack.m_41728_(current, stack)) {
/* 153 */               foundItem = true;
/* 154 */             } else if (foundItem) {
/* 155 */               return true;
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/* 160 */       return false;
/*     */     } 
/*     */     
/* 163 */     for (Map.Entry<String, ICurioStacksHandler> entry : curios.entrySet()) {
/*     */       
/* 165 */       if (slots.isEmpty() || slots.contains(entry.getKey())) {
/* 166 */         ICurioStacksHandler stacks = entry.getValue();
/* 167 */         int limit = (max == -1) ? stacks.getSlots() : Math.min(stacks.getSlots(), max);
/*     */         
/* 169 */         for (int i = min; i < limit; i++) {
/* 170 */           ItemStack current = stacks.getStacks().getStackInSlot(i);
/*     */           
/* 172 */           if (ItemStack.m_41728_(current, stack)) {
/* 173 */             foundItem = true;
/* 174 */           } else if (foundItem) {
/* 175 */             return false;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 180 */     return foundItem;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean hasItem(Map<String, ICurioStacksHandler> curios, Set<String> slots, int min, int max, ItemStack stack, boolean invert) {
/* 187 */     for (Map.Entry<String, ICurioStacksHandler> entry : curios.entrySet()) {
/*     */       
/* 189 */       if (slots.isEmpty() || slots.contains(entry.getKey())) {
/* 190 */         ICurioStacksHandler stacks = entry.getValue();
/* 191 */         int limit = (max == -1) ? stacks.getSlots() : Math.min(stacks.getSlots(), max);
/*     */         
/* 193 */         for (int i = min; i < limit; i++) {
/* 194 */           ItemStack current = stacks.getStacks().getStackInSlot(i);
/*     */           
/* 196 */           if (ItemStack.m_41728_(current, stack)) {
/* 197 */             return !invert;
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/* 202 */     return invert;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\curios-309927-4590652.jar!\top\theillusivec4\curios\server\command\CuriosSelectorOptions.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */