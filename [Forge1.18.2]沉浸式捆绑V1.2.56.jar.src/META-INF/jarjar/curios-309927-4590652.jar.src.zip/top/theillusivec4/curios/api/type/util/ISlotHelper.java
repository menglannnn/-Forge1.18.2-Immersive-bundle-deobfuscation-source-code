package top.theillusivec4.curios.api.type.util;

import java.util.Collection;
import java.util.Optional;
import java.util.Set;
import java.util.SortedMap;
import net.minecraft.world.entity.LivingEntity;
import top.theillusivec4.curios.api.type.ISlotType;
import top.theillusivec4.curios.api.type.inventory.ICurioStacksHandler;

public interface ISlotHelper {
  void addSlotType(ISlotType paramISlotType);
  
  Optional<ISlotType> getSlotType(String paramString);
  
  Collection<ISlotType> getSlotTypes();
  
  Collection<ISlotType> getSlotTypes(LivingEntity paramLivingEntity);
  
  Set<String> getSlotTypeIds();
  
  int getSlotsForType(LivingEntity paramLivingEntity, String paramString);
  
  void setSlotsForType(String paramString, LivingEntity paramLivingEntity, int paramInt);
  
  @Deprecated
  SortedMap<ISlotType, ICurioStacksHandler> createSlots(LivingEntity paramLivingEntity);
  
  @Deprecated
  SortedMap<ISlotType, ICurioStacksHandler> createSlots();
  
  @Deprecated
  void growSlotType(String paramString, LivingEntity paramLivingEntity);
  
  @Deprecated
  void growSlotType(String paramString, int paramInt, LivingEntity paramLivingEntity);
  
  @Deprecated
  void shrinkSlotType(String paramString, LivingEntity paramLivingEntity);
  
  @Deprecated
  void shrinkSlotType(String paramString, int paramInt, LivingEntity paramLivingEntity);
  
  @Deprecated
  void unlockSlotType(String paramString, LivingEntity paramLivingEntity);
  
  @Deprecated
  void lockSlotType(String paramString, LivingEntity paramLivingEntity);
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\curios-309927-4590652.jar!\top\theillusivec4\curios\api\typ\\util\ISlotHelper.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */