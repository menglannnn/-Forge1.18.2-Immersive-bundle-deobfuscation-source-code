/*     */ package top.theillusivec4.curios.api.client;
/*     */ 
/*     */ import com.mojang.blaze3d.vertex.PoseStack;
/*     */ import com.mojang.math.Vector3f;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.model.EntityModel;
/*     */ import net.minecraft.client.model.HumanoidModel;
/*     */ import net.minecraft.client.model.geom.ModelPart;
/*     */ import net.minecraft.client.renderer.MultiBufferSource;
/*     */ import net.minecraft.client.renderer.entity.EntityRenderer;
/*     */ import net.minecraft.client.renderer.entity.LivingEntityRenderer;
/*     */ import net.minecraft.client.renderer.entity.RenderLayerParent;
/*     */ import net.minecraft.world.entity.Entity;
/*     */ import net.minecraft.world.entity.LivingEntity;
/*     */ import net.minecraft.world.item.ItemStack;
/*     */ import top.theillusivec4.curios.api.SlotContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface ICurioRenderer
/*     */ {
/*     */   <T extends LivingEntity, M extends EntityModel<T>> void render(ItemStack paramItemStack, SlotContext paramSlotContext, PoseStack paramPoseStack, RenderLayerParent<T, M> paramRenderLayerParent, MultiBufferSource paramMultiBufferSource, int paramInt, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6);
/*     */   
/*     */   static void translateIfSneaking(PoseStack matrixStack, LivingEntity livingEntity) {
/*  44 */     if (livingEntity.m_6047_()) {
/*  45 */       matrixStack.m_85837_(0.0D, 0.1875D, 0.0D);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void rotateIfSneaking(PoseStack matrixStack, LivingEntity livingEntity) {
/*  58 */     if (livingEntity.m_6047_()) {
/*  59 */       matrixStack.m_85845_(Vector3f.f_122223_.m_122240_(28.647888F));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void followHeadRotations(LivingEntity livingEntity, ModelPart... renderers) {
/*  77 */     EntityRenderer<? super LivingEntity> render = Minecraft.m_91087_().m_91290_().m_114382_((Entity)livingEntity);
/*     */     
/*  79 */     if (render instanceof LivingEntityRenderer) {
/*     */       
/*  81 */       LivingEntityRenderer<LivingEntity, EntityModel<LivingEntity>> livingRenderer = (LivingEntityRenderer)render;
/*  82 */       EntityModel<LivingEntity> model = livingRenderer.m_7200_();
/*     */       
/*  84 */       if (model instanceof HumanoidModel)
/*     */       {
/*  86 */         for (ModelPart renderer : renderers) {
/*  87 */           renderer.m_104315_(((HumanoidModel)model).f_102808_);
/*     */         }
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SafeVarargs
/*     */   static void followBodyRotations(LivingEntity livingEntity, HumanoidModel<LivingEntity>... models) {
/* 107 */     EntityRenderer<? super LivingEntity> render = Minecraft.m_91087_().m_91290_().m_114382_((Entity)livingEntity);
/*     */     
/* 109 */     if (render instanceof LivingEntityRenderer) {
/*     */       
/* 111 */       LivingEntityRenderer<LivingEntity, EntityModel<LivingEntity>> livingRenderer = (LivingEntityRenderer)render;
/* 112 */       EntityModel<LivingEntity> entityModel = livingRenderer.m_7200_();
/*     */       
/* 114 */       if (entityModel instanceof HumanoidModel)
/*     */       {
/* 116 */         for (HumanoidModel<LivingEntity> model : models) {
/* 117 */           HumanoidModel<LivingEntity> bipedModel = (HumanoidModel<LivingEntity>)entityModel;
/* 118 */           bipedModel.m_102872_(model);
/*     */         } 
/*     */       }
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\curios-309927-4590652.jar!\top\theillusivec4\curios\api\client\ICurioRenderer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */