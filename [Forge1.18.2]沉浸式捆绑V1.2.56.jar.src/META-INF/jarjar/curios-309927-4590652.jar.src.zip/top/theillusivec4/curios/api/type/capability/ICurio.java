/*     */ package top.theillusivec4.curios.api.type.capability;
/*     */ 
/*     */ import com.google.common.collect.HashMultimap;
/*     */ import com.google.common.collect.Multimap;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.UUID;
/*     */ import javax.annotation.Nonnull;
/*     */ import javax.annotation.Nullable;
/*     */ import net.minecraft.core.particles.ItemParticleOption;
/*     */ import net.minecraft.core.particles.ParticleOptions;
/*     */ import net.minecraft.core.particles.ParticleTypes;
/*     */ import net.minecraft.nbt.CompoundTag;
/*     */ import net.minecraft.network.chat.Component;
/*     */ import net.minecraft.sounds.SoundEvent;
/*     */ import net.minecraft.sounds.SoundEvents;
/*     */ import net.minecraft.world.damagesource.DamageSource;
/*     */ import net.minecraft.world.entity.LivingEntity;
/*     */ import net.minecraft.world.entity.ai.attributes.Attribute;
/*     */ import net.minecraft.world.entity.ai.attributes.AttributeModifier;
/*     */ import net.minecraft.world.entity.monster.EnderMan;
/*     */ import net.minecraft.world.entity.player.Player;
/*     */ import net.minecraft.world.item.ItemStack;
/*     */ import net.minecraft.world.item.enchantment.EnchantmentHelper;
/*     */ import net.minecraft.world.item.enchantment.Enchantments;
/*     */ import net.minecraft.world.level.storage.loot.LootContext;
/*     */ import net.minecraft.world.phys.Vec3;
/*     */ import top.theillusivec4.curios.api.SlotContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface ICurio
/*     */ {
/*     */   ItemStack getStack();
/*     */   
/*     */   default void curioTick(SlotContext slotContext) {
/*  63 */     curioTick(slotContext.identifier(), slotContext.index(), slotContext.entity());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default void onEquip(SlotContext slotContext, ItemStack prevStack) {
/*  73 */     onEquip(slotContext.identifier(), slotContext.index(), slotContext.entity());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default void onUnequip(SlotContext slotContext, ItemStack newStack) {
/*  83 */     onUnequip(slotContext.identifier(), slotContext.index(), slotContext.entity());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default boolean canEquip(SlotContext slotContext) {
/*  93 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default boolean canUnequip(SlotContext slotContext) {
/* 103 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default List<Component> getSlotsTooltip(List<Component> tooltips) {
/* 117 */     return getTagsTooltip(tooltips);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Multimap<Attribute, AttributeModifier> getAttributeModifiers(SlotContext slotContext, UUID uuid) {
/* 133 */     return getAttributeModifiers(slotContext.identifier());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default void onEquipFromUse(SlotContext slotContext) {
/* 147 */     playRightClickEquipSound(slotContext.entity());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nonnull
/*     */   default SoundInfo getEquipSound(SlotContext slotContext) {
/* 158 */     return new SoundInfo(SoundEvents.f_11675_, 1.0F, 1.0F);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default boolean canEquipFromUse(SlotContext slotContext) {
/* 169 */     return canRightClickEquip();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default void curioBreak(SlotContext slotContext) {
/* 179 */     curioBreak(getStack(), slotContext.entity());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default boolean canSync(SlotContext slotContext) {
/* 191 */     return canSync(slotContext.identifier(), slotContext.index(), slotContext.entity());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   default CompoundTag writeSyncData(SlotContext slotContext) {
/* 203 */     return writeSyncData();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default void readSyncData(SlotContext slotContext, CompoundTag compound) {
/* 214 */     readSyncData(compound);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nonnull
/*     */   default DropRule getDropRule(SlotContext slotContext, DamageSource source, int lootingLevel, boolean recentlyHit) {
/* 230 */     return getDropRule(slotContext.entity());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default List<Component> getAttributesTooltip(List<Component> tooltips) {
/* 242 */     return showAttributesTooltip("") ? tooltips : new ArrayList<>();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default int getFortuneLevel(SlotContext slotContext, @Nullable LootContext lootContext) {
/* 254 */     return getFortuneBonus(slotContext.identifier(), slotContext.entity(), getStack(), slotContext
/* 255 */         .index());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default int getLootingLevel(SlotContext slotContext, DamageSource source, LivingEntity target, int baseLooting) {
/* 270 */     return getLootingBonus(slotContext.identifier(), slotContext.entity(), getStack(), slotContext
/* 271 */         .index());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default boolean makesPiglinsNeutral(SlotContext slotContext) {
/* 282 */     return getStack().makesPiglinsNeutral(slotContext.entity());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default boolean canWalkOnPowderedSnow(SlotContext slotContext) {
/* 293 */     return getStack().canWalkOnPowderedSnow(slotContext.entity());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default boolean isEnderMask(SlotContext slotContext, EnderMan enderMan) {
/* 306 */     LivingEntity livingEntity = slotContext.entity(); if (livingEntity instanceof Player) { Player player = (Player)livingEntity;
/* 307 */       return getStack().isEnderMask(player, enderMan); }
/*     */     
/* 309 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum DropRule
/*     */   {
/* 325 */     DEFAULT, ALWAYS_DROP, ALWAYS_KEEP, DESTROY; }
/*     */   public static final class SoundInfo extends Record { private final SoundEvent soundEvent; private final float volume; private final float pitch;
/*     */     
/* 328 */     public SoundInfo(SoundEvent soundEvent, float volume, float pitch) { this.soundEvent = soundEvent; this.volume = volume; this.pitch = pitch; } public final String toString() { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> toString : (Ltop/theillusivec4/curios/api/type/capability/ICurio$SoundInfo;)Ljava/lang/String;
/*     */       //   6: areturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #328	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/* 328 */       //   0	7	0	this	Ltop/theillusivec4/curios/api/type/capability/ICurio$SoundInfo; } public SoundEvent soundEvent() { return this.soundEvent; } public final int hashCode() { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> hashCode : (Ltop/theillusivec4/curios/api/type/capability/ICurio$SoundInfo;)I
/*     */       //   6: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #328	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	7	0	this	Ltop/theillusivec4/curios/api/type/capability/ICurio$SoundInfo; } public final boolean equals(Object o) { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: aload_1
/*     */       //   2: <illegal opcode> equals : (Ltop/theillusivec4/curios/api/type/capability/ICurio$SoundInfo;Ljava/lang/Object;)Z
/*     */       //   7: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #328	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	8	0	this	Ltop/theillusivec4/curios/api/type/capability/ICurio$SoundInfo;
/* 328 */       //   0	8	1	o	Ljava/lang/Object; } public float volume() { return this.volume; } public float pitch() { return this.pitch; }
/*     */     
/*     */     @Deprecated
/*     */     public SoundEvent getSoundEvent() {
/* 332 */       return this.soundEvent;
/*     */     }
/*     */     
/*     */     @Deprecated
/*     */     public float getVolume() {
/* 337 */       return this.volume;
/*     */     }
/*     */     
/*     */     @Deprecated
/*     */     public float getPitch() {
/* 342 */       return this.pitch;
/*     */     } }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void playBreakAnimation(ItemStack stack, LivingEntity livingEntity) {
/* 351 */     if (!stack.m_41619_()) {
/*     */       
/* 353 */       if (!livingEntity.m_20067_()) {
/* 354 */         livingEntity.f_19853_
/* 355 */           .m_7785_(livingEntity.m_20185_(), livingEntity.m_20186_(), livingEntity.m_20189_(), SoundEvents.f_12018_, livingEntity
/* 356 */             .m_5720_(), 0.8F, 0.8F + livingEntity.f_19853_.f_46441_
/* 357 */             .nextFloat() * 0.4F, false);
/*     */       }
/*     */       
/* 360 */       for (int i = 0; i < 5; i++) {
/*     */         
/* 362 */         Vec3 vec3d = new Vec3((livingEntity.m_21187_().nextFloat() - 0.5D) * 0.1D, Math.random() * 0.1D + 0.1D, 0.0D);
/* 363 */         vec3d = vec3d.m_82496_(-livingEntity.m_146909_() * 0.017453292F);
/* 364 */         vec3d = vec3d.m_82524_(-livingEntity.m_146908_() * 0.017453292F);
/* 365 */         double d0 = -livingEntity.m_21187_().nextFloat() * 0.6D - 0.3D;
/* 366 */         Vec3 vec3d1 = new Vec3((livingEntity.m_21187_().nextFloat() - 0.5D) * 0.3D, d0, 0.6D);
/*     */         
/* 368 */         vec3d1 = vec3d1.m_82496_(-livingEntity.m_146909_() * 0.017453292F);
/* 369 */         vec3d1 = vec3d1.m_82524_(-livingEntity.m_146908_() * 0.017453292F);
/* 370 */         vec3d1 = vec3d1.m_82520_(livingEntity.m_20185_(), livingEntity
/* 371 */             .m_20186_() + livingEntity.m_20192_(), livingEntity.m_20189_());
/* 372 */         livingEntity.f_19853_
/* 373 */           .m_7106_((ParticleOptions)new ItemParticleOption(ParticleTypes.f_123752_, stack), vec3d1.f_82479_, vec3d1.f_82480_, vec3d1.f_82481_, vec3d.f_82479_, vec3d.f_82480_ + 0.05D, vec3d.f_82481_);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   default void curioTick(String identifier, int index, LivingEntity livingEntity) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   default void curioAnimate(String identifier, int index, LivingEntity livingEntity) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   default void curioBreak(ItemStack stack, LivingEntity livingEntity) {
/* 402 */     playBreakAnimation(stack, livingEntity);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   default void onEquip(String identifier, int index, LivingEntity livingEntity) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   default void onUnequip(String identifier, int index, LivingEntity livingEntity) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   default boolean canEquip(String identifier, LivingEntity livingEntity) {
/* 426 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   default boolean canUnequip(String identifier, LivingEntity livingEntity) {
/* 434 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   default List<Component> getTagsTooltip(List<Component> tagTooltips) {
/* 442 */     return tagTooltips;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   default int getFortuneBonus(String identifier, LivingEntity livingEntity, ItemStack curio, int index) {
/* 451 */     return EnchantmentHelper.m_44843_(Enchantments.f_44987_, curio);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   default int getLootingBonus(String identifier, LivingEntity livingEntity, ItemStack curio, int index) {
/* 460 */     return EnchantmentHelper.m_44843_(Enchantments.f_44982_, curio);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   default boolean showAttributesTooltip(String identifier) {
/* 468 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nonnull
/*     */   @Deprecated
/*     */   default DropRule getDropRule(LivingEntity livingEntity) {
/* 477 */     return DropRule.DEFAULT;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   default boolean canSync(String identifier, int index, LivingEntity livingEntity) {
/* 485 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @Nullable
/*     */   default CompoundTag writeSyncData() {
/* 494 */     return new CompoundTag();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   default void readSyncData(CompoundTag compound) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   default boolean canRightClickEquip() {
/* 511 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   default void playRightClickEquipSound(LivingEntity livingEntity) {
/* 523 */     SoundInfo soundInfo = getEquipSound(new SlotContext("", livingEntity, 0, false, true));
/* 524 */     livingEntity.f_19853_.m_5594_(null, livingEntity.m_142538_(), soundInfo.getSoundEvent(), livingEntity
/* 525 */         .m_5720_(), soundInfo.getVolume(), soundInfo.getPitch());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   default Multimap<Attribute, AttributeModifier> getAttributeModifiers(String identifier) {
/* 534 */     return (Multimap<Attribute, AttributeModifier>)HashMultimap.create();
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\curios-309927-4590652.jar!\top\theillusivec4\curios\api\type\capability\ICurio.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */