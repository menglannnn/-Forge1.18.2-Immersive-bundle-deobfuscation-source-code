/*    */ package top.theillusivec4.curios.api;
/*    */ 
/*    */ import top.theillusivec4.curios.api.type.util.ICuriosHelper;
/*    */ import top.theillusivec4.curios.api.type.util.IIconHelper;
/*    */ import top.theillusivec4.curios.api.type.util.ISlotHelper;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class CuriosApi
/*    */ {
/*    */   public static final String MODID = "curios";
/*    */   private static IIconHelper iconHelper;
/*    */   private static ISlotHelper slotHelper;
/*    */   private static ICuriosHelper curiosHelper;
/*    */   
/*    */   public static IIconHelper getIconHelper() {
/* 35 */     return iconHelper;
/*    */   }
/*    */   
/*    */   public static ISlotHelper getSlotHelper() {
/* 39 */     return slotHelper;
/*    */   }
/*    */   
/*    */   public static ICuriosHelper getCuriosHelper() {
/* 43 */     return curiosHelper;
/*    */   }
/*    */ 
/*    */   
/*    */   public static void setIconHelper(IIconHelper helper) {
/* 48 */     if (iconHelper == null) {
/* 49 */       iconHelper = helper;
/*    */     }
/*    */   }
/*    */   
/*    */   public static void setSlotHelper(ISlotHelper helper) {
/* 54 */     slotHelper = helper;
/*    */   }
/*    */ 
/*    */   
/*    */   public static void setCuriosHelper(ICuriosHelper helper) {
/* 59 */     if (curiosHelper == null)
/* 60 */       curiosHelper = helper; 
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\curios-309927-4590652.jar!\top\theillusivec4\curios\api\CuriosApi.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */