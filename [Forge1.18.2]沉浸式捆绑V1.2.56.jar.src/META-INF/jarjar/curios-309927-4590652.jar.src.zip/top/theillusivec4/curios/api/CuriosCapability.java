/*    */ package top.theillusivec4.curios.api;
/*    */ 
/*    */ import net.minecraft.resources.ResourceLocation;
/*    */ import net.minecraftforge.common.capabilities.Capability;
/*    */ import net.minecraftforge.common.capabilities.CapabilityManager;
/*    */ import net.minecraftforge.common.capabilities.CapabilityToken;
/*    */ import top.theillusivec4.curios.api.type.capability.ICurio;
/*    */ import top.theillusivec4.curios.api.type.capability.ICuriosItemHandler;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CuriosCapability
/*    */ {
/* 32 */   public static final Capability<ICuriosItemHandler> INVENTORY = CapabilityManager.get(new CapabilityToken<ICuriosItemHandler>() {
/*    */       
/*    */       });
/* 35 */   public static final Capability<ICurio> ITEM = CapabilityManager.get(new CapabilityToken<ICurio>() {
/*    */       
/*    */       });
/* 38 */   public static final ResourceLocation ID_INVENTORY = new ResourceLocation("curios", "inventory");
/*    */   
/* 40 */   public static final ResourceLocation ID_ITEM = new ResourceLocation("curios", "item");
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\curios-309927-4590652.jar!\top\theillusivec4\curios\api\CuriosCapability.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */