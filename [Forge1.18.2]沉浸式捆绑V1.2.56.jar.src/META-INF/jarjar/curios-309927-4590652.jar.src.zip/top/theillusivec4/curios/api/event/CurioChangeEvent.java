/*    */ package top.theillusivec4.curios.api.event;
/*    */ 
/*    */ import javax.annotation.Nonnull;
/*    */ import net.minecraft.world.entity.LivingEntity;
/*    */ import net.minecraft.world.item.ItemStack;
/*    */ import net.minecraftforge.event.entity.living.LivingEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CurioChangeEvent
/*    */   extends LivingEvent
/*    */ {
/*    */   private final String type;
/*    */   private final ItemStack from;
/*    */   private final ItemStack to;
/*    */   private final int index;
/*    */   
/*    */   public CurioChangeEvent(LivingEntity living, String type, int index, @Nonnull ItemStack from, @Nonnull ItemStack to) {
/* 57 */     super(living);
/* 58 */     this.type = type;
/* 59 */     this.from = from;
/* 60 */     this.to = to;
/* 61 */     this.index = index;
/*    */   }
/*    */   
/*    */   public String getIdentifier() {
/* 65 */     return this.type;
/*    */   }
/*    */   
/*    */   public int getSlotIndex() {
/* 69 */     return this.index;
/*    */   }
/*    */   
/*    */   @Nonnull
/*    */   public ItemStack getFrom() {
/* 74 */     return this.from;
/*    */   }
/*    */   
/*    */   @Nonnull
/*    */   public ItemStack getTo() {
/* 79 */     return this.to;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\curios-309927-4590652.jar!\top\theillusivec4\curios\api\event\CurioChangeEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */