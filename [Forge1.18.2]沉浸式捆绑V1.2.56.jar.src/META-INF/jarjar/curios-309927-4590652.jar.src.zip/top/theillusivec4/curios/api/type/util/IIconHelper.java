package top.theillusivec4.curios.api.type.util;

import net.minecraft.resources.ResourceLocation;

public interface IIconHelper {
  void clearIcons();
  
  void addIcon(String paramString, ResourceLocation paramResourceLocation);
  
  ResourceLocation getIcon(String paramString);
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\curios-309927-4590652.jar!\top\theillusivec4\curios\api\typ\\util\IIconHelper.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */