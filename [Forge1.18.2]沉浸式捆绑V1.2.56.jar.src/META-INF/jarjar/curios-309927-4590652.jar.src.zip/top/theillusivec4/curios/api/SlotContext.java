/*    */ package top.theillusivec4.curios.api;public final class SlotContext extends Record { private final String identifier; private final LivingEntity entity; private final int index;
/*    */   private final boolean cosmetic;
/*    */   private final boolean visible;
/*    */   
/*  5 */   public SlotContext(String identifier, LivingEntity entity, int index, boolean cosmetic, boolean visible) { this.identifier = identifier; this.entity = entity; this.index = index; this.cosmetic = cosmetic; this.visible = visible; } public final String toString() { // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: <illegal opcode> toString : (Ltop/theillusivec4/curios/api/SlotContext;)Ljava/lang/String;
/*    */     //   6: areturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #5	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*  5 */     //   0	7	0	this	Ltop/theillusivec4/curios/api/SlotContext; } public String identifier() { return this.identifier; } public final int hashCode() { // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: <illegal opcode> hashCode : (Ltop/theillusivec4/curios/api/SlotContext;)I
/*    */     //   6: ireturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #5	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	7	0	this	Ltop/theillusivec4/curios/api/SlotContext; } public final boolean equals(Object o) { // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: aload_1
/*    */     //   2: <illegal opcode> equals : (Ltop/theillusivec4/curios/api/SlotContext;Ljava/lang/Object;)Z
/*    */     //   7: ireturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #5	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	8	0	this	Ltop/theillusivec4/curios/api/SlotContext;
/*  5 */     //   0	8	1	o	Ljava/lang/Object; } public LivingEntity entity() { return this.entity; } public int index() { return this.index; } public boolean cosmetic() { return this.cosmetic; } public boolean visible() { return this.visible; }
/*    */ 
/*    */   
/*    */   @Deprecated
/*    */   public String getIdentifier() {
/* 10 */     return this.identifier;
/*    */   }
/*    */   
/*    */   @Deprecated
/*    */   public int getIndex() {
/* 15 */     return this.index;
/*    */   }
/*    */   
/*    */   @Deprecated
/*    */   public LivingEntity getWearer() {
/* 20 */     return this.entity;
/*    */   } }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\curios-309927-4590652.jar!\top\theillusivec4\curios\api\SlotContext.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */