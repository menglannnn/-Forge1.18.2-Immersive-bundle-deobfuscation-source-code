/*    */ package top.theillusivec4.curios.api.type;
/*    */ 
/*    */ import net.minecraft.resources.ResourceLocation;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface ISlotType
/*    */   extends Comparable<ISlotType>
/*    */ {
/*    */   String getIdentifier();
/*    */   
/*    */   ResourceLocation getIcon();
/*    */   
/*    */   int getPriority();
/*    */   
/*    */   int getSize();
/*    */   
/*    */   @Deprecated
/*    */   default boolean isLocked() {
/* 51 */     return (getSize() == 0);
/*    */   }
/*    */   
/*    */   boolean isVisible();
/*    */   
/*    */   boolean hasCosmetic();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\curios-309927-4590652.jar!\top\theillusivec4\curios\api\type\ISlotType.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */