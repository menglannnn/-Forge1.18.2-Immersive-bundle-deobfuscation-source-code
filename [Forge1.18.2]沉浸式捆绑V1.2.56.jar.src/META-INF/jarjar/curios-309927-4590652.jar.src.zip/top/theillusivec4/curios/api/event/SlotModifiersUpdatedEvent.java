/*    */ package top.theillusivec4.curios.api.event;
/*    */ 
/*    */ import com.google.common.collect.ImmutableSet;
/*    */ import java.util.Set;
/*    */ import net.minecraft.world.entity.LivingEntity;
/*    */ import net.minecraftforge.event.entity.living.LivingEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SlotModifiersUpdatedEvent
/*    */   extends LivingEvent
/*    */ {
/*    */   private final Set<String> types;
/*    */   
/*    */   public SlotModifiersUpdatedEvent(LivingEntity livingEntity, Set<String> types) {
/* 28 */     super(livingEntity);
/* 29 */     this.types = types;
/*    */   }
/*    */   
/*    */   public Set<String> getTypes() {
/* 33 */     return (Set<String>)ImmutableSet.copyOf(this.types);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\curios-309927-4590652.jar!\top\theillusivec4\curios\api\event\SlotModifiersUpdatedEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */