/*    */ package top.theillusivec4.curios.api.event;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import net.minecraft.world.damagesource.DamageSource;
/*    */ import net.minecraft.world.entity.LivingEntity;
/*    */ import net.minecraft.world.entity.item.ItemEntity;
/*    */ import net.minecraftforge.event.entity.living.LivingEvent;
/*    */ import net.minecraftforge.eventbus.api.Cancelable;
/*    */ import top.theillusivec4.curios.api.type.capability.ICuriosItemHandler;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Cancelable
/*    */ public class CurioDropsEvent
/*    */   extends LivingEvent
/*    */ {
/*    */   private final DamageSource source;
/*    */   private final Collection<ItemEntity> drops;
/*    */   private final int lootingLevel;
/*    */   private final boolean recentlyHit;
/*    */   private final ICuriosItemHandler curioHandler;
/*    */   
/*    */   public CurioDropsEvent(LivingEntity entity, ICuriosItemHandler handler, DamageSource source, Collection<ItemEntity> drops, int lootingLevel, boolean recentlyHit) {
/* 60 */     super(entity);
/* 61 */     this.source = source;
/* 62 */     this.drops = drops;
/* 63 */     this.lootingLevel = lootingLevel;
/* 64 */     this.recentlyHit = recentlyHit;
/* 65 */     this.curioHandler = handler;
/*    */   }
/*    */   
/*    */   public ICuriosItemHandler getCurioHandler() {
/* 69 */     return this.curioHandler;
/*    */   }
/*    */   
/*    */   public DamageSource getSource() {
/* 73 */     return this.source;
/*    */   }
/*    */   
/*    */   public Collection<ItemEntity> getDrops() {
/* 77 */     return this.drops;
/*    */   }
/*    */   
/*    */   public int getLootingLevel() {
/* 81 */     return this.lootingLevel;
/*    */   }
/*    */   
/*    */   public boolean isRecentlyHit() {
/* 85 */     return this.recentlyHit;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\curios-309927-4590652.jar!\top\theillusivec4\curios\api\event\CurioDropsEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */