/*     */ package top.theillusivec4.curios.api.type.capability;
/*     */ 
/*     */ import com.google.common.collect.Multimap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Optional;
/*     */ import java.util.Set;
/*     */ import javax.annotation.Nullable;
/*     */ import net.minecraft.nbt.ListTag;
/*     */ import net.minecraft.nbt.Tag;
/*     */ import net.minecraft.util.Tuple;
/*     */ import net.minecraft.world.damagesource.DamageSource;
/*     */ import net.minecraft.world.entity.LivingEntity;
/*     */ import net.minecraft.world.entity.ai.attributes.AttributeModifier;
/*     */ import net.minecraft.world.item.ItemStack;
/*     */ import net.minecraft.world.level.storage.loot.LootContext;
/*     */ import top.theillusivec4.curios.api.type.inventory.ICurioStacksHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface ICuriosItemHandler
/*     */ {
/*     */   Map<String, ICurioStacksHandler> getCurios();
/*     */   
/*     */   void setCurios(Map<String, ICurioStacksHandler> paramMap);
/*     */   
/*     */   int getSlots();
/*     */   
/*     */   default int getVisibleSlots() {
/*  70 */     return getSlots();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void reset();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Optional<ICurioStacksHandler> getStacksHandler(String paramString);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   LivingEntity getWearer();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void loseInvalidStack(ItemStack paramItemStack);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void handleInvalidStacks();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int getFortuneLevel(@Nullable LootContext paramLootContext);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int getLootingLevel(DamageSource paramDamageSource, LivingEntity paramLivingEntity, int paramInt);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ListTag saveInventory(boolean paramBoolean);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void loadInventory(ListTag paramListTag);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Set<ICurioStacksHandler> getUpdatingInventories();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void addTransientSlotModifiers(Multimap<String, AttributeModifier> paramMultimap);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void addPermanentSlotModifiers(Multimap<String, AttributeModifier> paramMultimap);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void removeSlotModifiers(Multimap<String, AttributeModifier> paramMultimap);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void clearSlotModifiers();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Multimap<String, AttributeModifier> getModifiers();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Tag writeTag();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void readTag(Tag paramTag);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void clearCachedSlotModifiers();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   default Set<String> getLockedSlots() {
/* 201 */     return new HashSet<>();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   default void unlockSlotType(String identifier, int amount, boolean visible, boolean cosmetic) {
/* 210 */     growSlotType(identifier, amount);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   default void lockSlotType(String identifier) {
/* 219 */     shrinkSlotType(identifier, 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   default void processSlots() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   default int getFortuneBonus() {
/* 235 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   default int getLootingBonus() {
/* 243 */     return 0;
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   default void setEnchantmentBonuses(Tuple<Integer, Integer> fortuneAndLooting) {}
/*     */   
/*     */   @Deprecated
/*     */   void growSlotType(String paramString, int paramInt);
/*     */   
/*     */   @Deprecated
/*     */   void shrinkSlotType(String paramString, int paramInt);
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\curios-309927-4590652.jar!\top\theillusivec4\curios\api\type\capability\ICuriosItemHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */