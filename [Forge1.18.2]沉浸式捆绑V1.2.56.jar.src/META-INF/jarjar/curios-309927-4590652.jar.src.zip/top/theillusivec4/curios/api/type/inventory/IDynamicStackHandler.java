package top.theillusivec4.curios.api.type.inventory;

import javax.annotation.Nonnull;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.items.IItemHandlerModifiable;

public interface IDynamicStackHandler extends IItemHandlerModifiable {
  void setStackInSlot(int paramInt, @Nonnull ItemStack paramItemStack);
  
  @Nonnull
  ItemStack getStackInSlot(int paramInt);
  
  void setPreviousStackInSlot(int paramInt, @Nonnull ItemStack paramItemStack);
  
  ItemStack getPreviousStackInSlot(int paramInt);
  
  int getSlots();
  
  void grow(int paramInt);
  
  void shrink(int paramInt);
  
  CompoundTag serializeNBT();
  
  void deserializeNBT(CompoundTag paramCompoundTag);
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\curios-309927-4590652.jar!\top\theillusivec4\curios\api\type\inventory\IDynamicStackHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */