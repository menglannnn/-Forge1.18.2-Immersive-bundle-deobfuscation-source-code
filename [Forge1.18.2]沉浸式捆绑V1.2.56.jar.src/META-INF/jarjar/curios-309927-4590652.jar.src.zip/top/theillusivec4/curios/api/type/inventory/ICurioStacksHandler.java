package top.theillusivec4.curios.api.type.inventory;

import java.util.Collection;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import net.minecraft.core.NonNullList;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;

public interface ICurioStacksHandler {
  IDynamicStackHandler getStacks();
  
  IDynamicStackHandler getCosmeticStacks();
  
  NonNullList<Boolean> getRenders();
  
  int getSlots();
  
  boolean isVisible();
  
  boolean hasCosmetic();
  
  CompoundTag serializeNBT();
  
  void deserializeNBT(CompoundTag paramCompoundTag);
  
  String getIdentifier();
  
  Map<UUID, AttributeModifier> getModifiers();
  
  Set<AttributeModifier> getPermanentModifiers();
  
  Set<AttributeModifier> getCachedModifiers();
  
  Collection<AttributeModifier> getModifiersByOperation(AttributeModifier.Operation paramOperation);
  
  void addTransientModifier(AttributeModifier paramAttributeModifier);
  
  void addPermanentModifier(AttributeModifier paramAttributeModifier);
  
  void removeModifier(UUID paramUUID);
  
  void clearModifiers();
  
  void clearCachedModifiers();
  
  void copyModifiers(ICurioStacksHandler paramICurioStacksHandler);
  
  void update();
  
  CompoundTag getSyncTag();
  
  void applySyncTag(CompoundTag paramCompoundTag);
  
  @Deprecated
  int getSizeShift();
  
  @Deprecated
  void grow(int paramInt);
  
  @Deprecated
  void shrink(int paramInt);
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\curios-309927-4590652.jar!\top\theillusivec4\curios\api\type\inventory\ICurioStacksHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */