package top.theillusivec4.curios.api.type.util;

import com.google.common.collect.Multimap;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.function.Consumer;
import java.util.function.Predicate;
import javax.annotation.Nonnull;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.common.util.LazyOptional;
import net.minecraftforge.items.IItemHandlerModifiable;
import org.apache.commons.lang3.tuple.ImmutableTriple;
import org.apache.logging.log4j.util.TriConsumer;
import top.theillusivec4.curios.api.SlotContext;
import top.theillusivec4.curios.api.SlotResult;
import top.theillusivec4.curios.api.type.capability.ICurio;
import top.theillusivec4.curios.api.type.capability.ICuriosItemHandler;

public interface ICuriosHelper {
  LazyOptional<ICurio> getCurio(ItemStack paramItemStack);
  
  LazyOptional<ICuriosItemHandler> getCuriosHandler(LivingEntity paramLivingEntity);
  
  Set<String> getCurioTags(Item paramItem);
  
  LazyOptional<IItemHandlerModifiable> getEquippedCurios(LivingEntity paramLivingEntity);
  
  void setEquippedCurio(@Nonnull LivingEntity paramLivingEntity, String paramString, int paramInt, ItemStack paramItemStack);
  
  Optional<SlotResult> findFirstCurio(@Nonnull LivingEntity paramLivingEntity, Item paramItem);
  
  Optional<SlotResult> findFirstCurio(@Nonnull LivingEntity paramLivingEntity, Predicate<ItemStack> paramPredicate);
  
  List<SlotResult> findCurios(@Nonnull LivingEntity paramLivingEntity, Item paramItem);
  
  List<SlotResult> findCurios(@Nonnull LivingEntity paramLivingEntity, Predicate<ItemStack> paramPredicate);
  
  List<SlotResult> findCurios(@Nonnull LivingEntity paramLivingEntity, String... paramVarArgs);
  
  Optional<SlotResult> findCurio(@Nonnull LivingEntity paramLivingEntity, String paramString, int paramInt);
  
  Multimap<Attribute, AttributeModifier> getAttributeModifiers(SlotContext paramSlotContext, UUID paramUUID, ItemStack paramItemStack);
  
  void addSlotModifier(Multimap<Attribute, AttributeModifier> paramMultimap, String paramString, UUID paramUUID, double paramDouble, AttributeModifier.Operation paramOperation);
  
  void addSlotModifier(ItemStack paramItemStack, String paramString1, String paramString2, UUID paramUUID, double paramDouble, AttributeModifier.Operation paramOperation, String paramString3);
  
  void addModifier(ItemStack paramItemStack, Attribute paramAttribute, String paramString1, UUID paramUUID, double paramDouble, AttributeModifier.Operation paramOperation, String paramString2);
  
  boolean isStackValid(SlotContext paramSlotContext, ItemStack paramItemStack);
  
  void onBrokenCurio(SlotContext paramSlotContext);
  
  void setBrokenCurioConsumer(Consumer<SlotContext> paramConsumer);
  
  @Nonnull
  @Deprecated
  Optional<ImmutableTriple<String, Integer, ItemStack>> findEquippedCurio(Item paramItem, @Nonnull LivingEntity paramLivingEntity);
  
  @Nonnull
  @Deprecated
  Optional<ImmutableTriple<String, Integer, ItemStack>> findEquippedCurio(Predicate<ItemStack> paramPredicate, @Nonnull LivingEntity paramLivingEntity);
  
  @Deprecated
  void onBrokenCurio(String paramString, int paramInt, LivingEntity paramLivingEntity);
  
  @Deprecated
  void setBrokenCurioConsumer(TriConsumer<String, Integer, LivingEntity> paramTriConsumer);
  
  @Deprecated
  Multimap<Attribute, AttributeModifier> getAttributeModifiers(String paramString, ItemStack paramItemStack);
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\curios-309927-4590652.jar!\top\theillusivec4\curios\api\typ\\util\ICuriosHelper.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */