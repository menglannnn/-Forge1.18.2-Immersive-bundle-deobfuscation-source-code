/*    */ package top.theillusivec4.curios.api.event;
/*    */ 
/*    */ import net.minecraft.world.item.ItemStack;
/*    */ import net.minecraftforge.event.entity.living.LivingEvent;
/*    */ import net.minecraftforge.eventbus.api.Event.HasResult;
/*    */ import top.theillusivec4.curios.api.SlotContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @HasResult
/*    */ public class CurioUnequipEvent
/*    */   extends LivingEvent
/*    */ {
/*    */   private final SlotContext slotContext;
/*    */   private final ItemStack stack;
/*    */   
/*    */   public CurioUnequipEvent(ItemStack stack, SlotContext slotContext) {
/* 28 */     super(slotContext.entity());
/* 29 */     this.slotContext = slotContext;
/* 30 */     this.stack = stack;
/*    */   }
/*    */   
/*    */   public SlotContext getSlotContext() {
/* 34 */     return this.slotContext;
/*    */   }
/*    */   
/*    */   public ItemStack getStack() {
/* 38 */     return this.stack;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\curios-309927-4590652.jar!\top\theillusivec4\curios\api\event\CurioUnequipEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */