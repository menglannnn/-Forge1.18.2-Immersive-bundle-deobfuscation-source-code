/*    */ package top.theillusivec4.curios.api.client;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import java.util.Optional;
/*    */ import java.util.concurrent.ConcurrentHashMap;
/*    */ import java.util.function.Supplier;
/*    */ import net.minecraft.world.item.Item;
/*    */ 
/*    */ public class CuriosRendererRegistry
/*    */ {
/* 12 */   private static final Map<Item, Supplier<ICurioRenderer>> RENDERER_REGISTRY = new ConcurrentHashMap<>();
/*    */   
/* 14 */   private static final Map<Item, ICurioRenderer> RENDERERS = new HashMap<>();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void register(Item item, Supplier<ICurioRenderer> renderer) {
/* 25 */     RENDERER_REGISTRY.put(item, renderer);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static Optional<ICurioRenderer> getRenderer(Item item) {
/* 35 */     return Optional.ofNullable(RENDERERS.get(item));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void load() {
/* 45 */     for (Map.Entry<Item, Supplier<ICurioRenderer>> entry : RENDERER_REGISTRY.entrySet())
/* 46 */       RENDERERS.put(entry.getKey(), ((Supplier<ICurioRenderer>)entry.getValue()).get()); 
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\curios-309927-4590652.jar!\top\theillusivec4\curios\api\client\CuriosRendererRegistry.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */