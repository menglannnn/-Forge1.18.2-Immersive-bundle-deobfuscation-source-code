/*   */ package top.theillusivec4.curios.api;
/*   */ public final class SlotResult extends Record { private final SlotContext slotContext;
/*   */   private final ItemStack stack;
/*   */   
/* 5 */   public SlotResult(SlotContext slotContext, ItemStack stack) { this.slotContext = slotContext; this.stack = stack; } public final String toString() { // Byte code:
/*   */     //   0: aload_0
/*   */     //   1: <illegal opcode> toString : (Ltop/theillusivec4/curios/api/SlotResult;)Ljava/lang/String;
/*   */     //   6: areturn
/*   */     // Line number table:
/*   */     //   Java source line number -> byte code offset
/*   */     //   #5	-> 0
/*   */     // Local variable table:
/*   */     //   start	length	slot	name	descriptor
/* 5 */     //   0	7	0	this	Ltop/theillusivec4/curios/api/SlotResult; } public SlotContext slotContext() { return this.slotContext; } public final int hashCode() { // Byte code:
/*   */     //   0: aload_0
/*   */     //   1: <illegal opcode> hashCode : (Ltop/theillusivec4/curios/api/SlotResult;)I
/*   */     //   6: ireturn
/*   */     // Line number table:
/*   */     //   Java source line number -> byte code offset
/*   */     //   #5	-> 0
/*   */     // Local variable table:
/*   */     //   start	length	slot	name	descriptor
/*   */     //   0	7	0	this	Ltop/theillusivec4/curios/api/SlotResult; } public final boolean equals(Object o) { // Byte code:
/*   */     //   0: aload_0
/*   */     //   1: aload_1
/*   */     //   2: <illegal opcode> equals : (Ltop/theillusivec4/curios/api/SlotResult;Ljava/lang/Object;)Z
/*   */     //   7: ireturn
/*   */     // Line number table:
/*   */     //   Java source line number -> byte code offset
/*   */     //   #5	-> 0
/*   */     // Local variable table:
/*   */     //   start	length	slot	name	descriptor
/*   */     //   0	8	0	this	Ltop/theillusivec4/curios/api/SlotResult;
/* 5 */     //   0	8	1	o	Ljava/lang/Object; } public ItemStack stack() { return this.stack; }
/*   */    }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\curios-309927-4590652.jar!\top\theillusivec4\curios\api\SlotResult.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */