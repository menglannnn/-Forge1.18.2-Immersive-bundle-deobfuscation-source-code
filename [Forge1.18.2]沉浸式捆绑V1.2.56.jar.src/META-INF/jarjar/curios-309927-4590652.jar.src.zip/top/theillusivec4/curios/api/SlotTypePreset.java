/*    */ package top.theillusivec4.curios.api;
/*    */ 
/*    */ import java.util.Optional;
/*    */ import net.minecraft.resources.ResourceLocation;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum SlotTypePreset
/*    */ {
/* 31 */   HEAD("head", 40), NECKLACE("necklace", 60), BACK("back", 80), BODY("body", 100), BRACELET("bracelet", 120),
/* 32 */   HANDS("hands", 140), RING("ring", 160), BELT("belt", 180), CHARM("charm", 200),
/* 33 */   CURIO("curio", 20);
/*    */   
/*    */   final String id;
/*    */   final int priority;
/*    */   
/*    */   SlotTypePreset(String id, int priority) {
/* 39 */     this.id = id;
/* 40 */     this.priority = priority;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static Optional<SlotTypePreset> findPreset(String id) {
/*    */     try {
/* 52 */       return Optional.of(valueOf(id.toUpperCase()));
/* 53 */     } catch (IllegalArgumentException e) {
/* 54 */       return Optional.empty();
/*    */     } 
/*    */   }
/*    */   
/*    */   public String getIdentifier() {
/* 59 */     return this.id;
/*    */   }
/*    */   
/*    */   public SlotTypeMessage.Builder getMessageBuilder() {
/* 63 */     return (new SlotTypeMessage.Builder(this.id)).priority(this.priority).icon(new ResourceLocation("curios", "item/empty_" + 
/* 64 */           getIdentifier() + "_slot"));
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\curios-309927-4590652.jar!\top\theillusivec4\curios\api\SlotTypePreset.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */