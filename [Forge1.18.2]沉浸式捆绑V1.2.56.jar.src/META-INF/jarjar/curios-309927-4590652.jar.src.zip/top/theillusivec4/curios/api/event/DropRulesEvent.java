/*     */ package top.theillusivec4.curios.api.event;
/*     */ 
/*     */ import com.google.common.collect.ImmutableList;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.function.Predicate;
/*     */ import net.minecraft.util.Tuple;
/*     */ import net.minecraft.world.damagesource.DamageSource;
/*     */ import net.minecraft.world.entity.LivingEntity;
/*     */ import net.minecraft.world.item.ItemStack;
/*     */ import net.minecraftforge.event.entity.living.LivingEvent;
/*     */ import top.theillusivec4.curios.api.type.capability.ICurio;
/*     */ import top.theillusivec4.curios.api.type.capability.ICuriosItemHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DropRulesEvent
/*     */   extends LivingEvent
/*     */ {
/*     */   private final DamageSource source;
/*     */   private final int lootingLevel;
/*     */   private final boolean recentlyHit;
/*     */   private final ICuriosItemHandler curioHandler;
/*  59 */   private final List<Tuple<Predicate<ItemStack>, ICurio.DropRule>> overrides = new ArrayList<>();
/*     */ 
/*     */ 
/*     */   
/*     */   public DropRulesEvent(LivingEntity entity, ICuriosItemHandler handler, DamageSource source, int lootingLevel, boolean recentlyHit) {
/*  64 */     super(entity);
/*  65 */     this.source = source;
/*  66 */     this.lootingLevel = lootingLevel;
/*  67 */     this.recentlyHit = recentlyHit;
/*  68 */     this.curioHandler = handler;
/*     */   }
/*     */   
/*     */   public DamageSource getSource() {
/*  72 */     return this.source;
/*     */   }
/*     */   
/*     */   public int getLootingLevel() {
/*  76 */     return this.lootingLevel;
/*     */   }
/*     */   
/*     */   public boolean isRecentlyHit() {
/*  80 */     return this.recentlyHit;
/*     */   }
/*     */   
/*     */   public ICuriosItemHandler getCurioHandler() {
/*  84 */     return this.curioHandler;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addOverride(Predicate<ItemStack> predicate, ICurio.DropRule dropRule) {
/*  97 */     this.overrides.add(new Tuple(predicate, dropRule));
/*     */   }
/*     */   
/*     */   public ImmutableList<Tuple<Predicate<ItemStack>, ICurio.DropRule>> getOverrides() {
/* 101 */     return ImmutableList.copyOf(this.overrides);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\curios-309927-4590652.jar!\top\theillusivec4\curios\api\event\DropRulesEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */