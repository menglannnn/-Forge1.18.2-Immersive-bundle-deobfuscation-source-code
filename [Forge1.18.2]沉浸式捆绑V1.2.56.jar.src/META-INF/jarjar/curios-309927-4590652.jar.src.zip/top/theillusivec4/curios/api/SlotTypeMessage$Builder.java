/*     */ package top.theillusivec4.curios.api;
/*     */ 
/*     */ import net.minecraft.resources.ResourceLocation;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Builder
/*     */ {
/*     */   private final String identifier;
/*     */   private Integer priority;
/*  81 */   private int size = 1;
/*     */   private boolean visible = true;
/*     */   private boolean cosmetic = false;
/*  84 */   private ResourceLocation icon = null;
/*     */   
/*     */   public Builder(String identifier) {
/*  87 */     this.identifier = identifier;
/*     */   }
/*     */   
/*     */   public Builder icon(ResourceLocation icon) {
/*  91 */     this.icon = icon;
/*  92 */     return this;
/*     */   }
/*     */   
/*     */   public Builder priority(int priority) {
/*  96 */     this.priority = Integer.valueOf(priority);
/*  97 */     return this;
/*     */   }
/*     */   
/*     */   public Builder size(int size) {
/* 101 */     this.size = size;
/* 102 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public Builder lock() {
/* 110 */     this.size = 0;
/* 111 */     return this;
/*     */   }
/*     */   
/*     */   public Builder hide() {
/* 115 */     this.visible = false;
/* 116 */     return this;
/*     */   }
/*     */   
/*     */   public Builder cosmetic() {
/* 120 */     this.cosmetic = true;
/* 121 */     return this;
/*     */   }
/*     */   
/*     */   public SlotTypeMessage build() {
/* 125 */     return new SlotTypeMessage(this);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\curios-309927-4590652.jar!\top\theillusivec4\curios\api\SlotTypeMessage$Builder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */