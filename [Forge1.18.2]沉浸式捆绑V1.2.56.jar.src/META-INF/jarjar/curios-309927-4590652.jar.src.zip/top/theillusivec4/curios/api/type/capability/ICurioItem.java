/*     */ package top.theillusivec4.curios.api.type.capability;
/*     */ 
/*     */ import com.google.common.collect.Multimap;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.UUID;
/*     */ import javax.annotation.Nonnull;
/*     */ import net.minecraft.nbt.CompoundTag;
/*     */ import net.minecraft.network.chat.Component;
/*     */ import net.minecraft.sounds.SoundEvents;
/*     */ import net.minecraft.world.damagesource.DamageSource;
/*     */ import net.minecraft.world.entity.LivingEntity;
/*     */ import net.minecraft.world.entity.ai.attributes.Attribute;
/*     */ import net.minecraft.world.entity.ai.attributes.AttributeModifier;
/*     */ import net.minecraft.world.entity.monster.EnderMan;
/*     */ import net.minecraft.world.entity.player.Player;
/*     */ import net.minecraft.world.item.ItemStack;
/*     */ import net.minecraft.world.level.storage.loot.LootContext;
/*     */ import top.theillusivec4.curios.api.SlotContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface ICurioItem
/*     */ {
/*     */   public static final ICurio defaultInstance = () -> ItemStack.f_41583_;
/*     */   
/*     */   default boolean hasCurioCapability(ItemStack stack) {
/*  67 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default void curioTick(SlotContext slotContext, ItemStack stack) {
/*  77 */     curioTick(slotContext.identifier(), slotContext.index(), slotContext.entity(), stack);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default void onEquip(SlotContext slotContext, ItemStack prevStack, ItemStack stack) {
/*  88 */     onEquip(slotContext.identifier(), slotContext.index(), slotContext.entity(), stack);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default void onUnequip(SlotContext slotContext, ItemStack newStack, ItemStack stack) {
/*  99 */     onUnequip(slotContext.identifier(), slotContext.index(), slotContext.entity(), stack);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default boolean canEquip(SlotContext slotContext, ItemStack stack) {
/* 110 */     return canEquip(slotContext.identifier(), slotContext.entity(), stack);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default boolean canUnequip(SlotContext slotContext, ItemStack stack) {
/* 121 */     return canUnequip(slotContext.identifier(), slotContext.entity(), stack);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default List<Component> getSlotsTooltip(List<Component> tooltips, ItemStack stack) {
/* 136 */     return getTagsTooltip(tooltips, stack);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Multimap<Attribute, AttributeModifier> getAttributeModifiers(SlotContext slotContext, UUID uuid, ItemStack stack) {
/* 152 */     return getAttributeModifiers(slotContext.identifier(), stack);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default void onEquipFromUse(SlotContext slotContext, ItemStack stack) {
/* 167 */     playRightClickEquipSound(slotContext.entity(), stack);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nonnull
/*     */   default ICurio.SoundInfo getEquipSound(SlotContext slotContext, ItemStack stack) {
/* 179 */     return new ICurio.SoundInfo(SoundEvents.f_11675_, 1.0F, 1.0F);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default boolean canEquipFromUse(SlotContext slotContext, ItemStack stack) {
/* 191 */     return canRightClickEquip(stack);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default void curioBreak(SlotContext slotContext, ItemStack stack) {
/* 202 */     curioBreak(stack, slotContext.entity());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default boolean canSync(SlotContext slotContext, ItemStack stack) {
/* 215 */     return canSync(slotContext.identifier(), slotContext.index(), slotContext.entity(), stack);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nonnull
/*     */   default CompoundTag writeSyncData(SlotContext slotContext, ItemStack stack) {
/* 228 */     return writeSyncData(stack);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default void readSyncData(SlotContext slotContext, CompoundTag compound, ItemStack stack) {
/* 240 */     readSyncData(compound, stack);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nonnull
/*     */   default ICurio.DropRule getDropRule(SlotContext slotContext, DamageSource source, int lootingLevel, boolean recentlyHit, ItemStack stack) {
/* 257 */     return getDropRule(slotContext.entity(), stack);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default List<Component> getAttributesTooltip(List<Component> tooltips, ItemStack stack) {
/* 271 */     return showAttributesTooltip("", stack) ? tooltips : new ArrayList<>();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default int getFortuneLevel(SlotContext slotContext, LootContext lootContext, ItemStack stack) {
/* 284 */     return getFortuneBonus(slotContext.identifier(), slotContext.entity(), stack, slotContext
/* 285 */         .index());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default int getLootingLevel(SlotContext slotContext, DamageSource source, LivingEntity target, int baseLooting, ItemStack stack) {
/* 301 */     return getLootingBonus(slotContext.identifier(), slotContext.entity(), stack, slotContext
/* 302 */         .index());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default boolean makesPiglinsNeutral(SlotContext slotContext, ItemStack stack) {
/* 313 */     return stack.makesPiglinsNeutral(slotContext.entity());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default boolean canWalkOnPowderedSnow(SlotContext slotContext, ItemStack stack) {
/* 324 */     return stack.canWalkOnPowderedSnow(slotContext.entity());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default boolean isEnderMask(SlotContext slotContext, EnderMan enderMan, ItemStack stack) {
/* 337 */     LivingEntity livingEntity = slotContext.entity(); if (livingEntity instanceof Player) { Player player = (Player)livingEntity;
/* 338 */       return stack.isEnderMask(player, enderMan); }
/*     */     
/* 340 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   default void curioTick(String identifier, int index, LivingEntity livingEntity, ItemStack stack) {
/* 351 */     defaultInstance.curioTick(identifier, index, livingEntity);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   default void curioAnimate(String identifier, int index, LivingEntity livingEntity, ItemStack stack) {
/* 360 */     defaultInstance.curioAnimate(identifier, index, livingEntity);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   default void onEquip(String identifier, int index, LivingEntity livingEntity, ItemStack stack) {
/* 368 */     defaultInstance.onEquip(identifier, index, livingEntity);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   default void onUnequip(String identifier, int index, LivingEntity livingEntity, ItemStack stack) {
/* 376 */     defaultInstance.onUnequip(identifier, index, livingEntity);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   default boolean canEquip(String identifier, LivingEntity livingEntity, ItemStack stack) {
/* 384 */     return defaultInstance.canEquip(identifier, livingEntity);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   default boolean canUnequip(String identifier, LivingEntity livingEntity, ItemStack stack) {
/* 392 */     return defaultInstance.canUnequip(identifier, livingEntity);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   default List<Component> getTagsTooltip(List<Component> tagTooltips, ItemStack stack) {
/* 400 */     return defaultInstance.getTagsTooltip(tagTooltips);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   default void playRightClickEquipSound(LivingEntity livingEntity, ItemStack stack) {
/* 413 */     ICurio.SoundInfo soundInfo = getEquipSound(new SlotContext("", livingEntity, 0, false, true), stack);
/* 414 */     livingEntity.f_19853_.m_5594_(null, livingEntity.m_142538_(), soundInfo.getSoundEvent(), livingEntity
/* 415 */         .m_5720_(), soundInfo.getVolume(), soundInfo.getPitch());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   default boolean canRightClickEquip(ItemStack stack) {
/* 424 */     return defaultInstance.canRightClickEquip();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   default Multimap<Attribute, AttributeModifier> getAttributeModifiers(String identifier, ItemStack stack) {
/* 434 */     return defaultInstance.getAttributeModifiers(identifier);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   default void curioBreak(ItemStack stack, LivingEntity livingEntity) {
/* 442 */     defaultInstance.curioBreak(stack, livingEntity);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   default boolean canSync(String identifier, int index, LivingEntity livingEntity, ItemStack stack) {
/* 451 */     return defaultInstance.canSync(identifier, index, livingEntity);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nonnull
/*     */   @Deprecated
/*     */   default CompoundTag writeSyncData(ItemStack stack) {
/* 460 */     return defaultInstance.writeSyncData();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   default void readSyncData(CompoundTag compound, ItemStack stack) {
/* 468 */     defaultInstance.readSyncData(compound);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nonnull
/*     */   @Deprecated
/*     */   default ICurio.DropRule getDropRule(LivingEntity livingEntity, ItemStack stack) {
/* 477 */     return defaultInstance.getDropRule(livingEntity);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   default boolean showAttributesTooltip(String identifier, ItemStack stack) {
/* 485 */     return defaultInstance.showAttributesTooltip(identifier);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   default int getFortuneBonus(String identifier, LivingEntity livingEntity, ItemStack curio, int index) {
/* 494 */     return defaultInstance.getFortuneBonus(identifier, livingEntity, curio, index);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   default int getLootingBonus(String identifier, LivingEntity livingEntity, ItemStack curio, int index) {
/* 503 */     return defaultInstance.getLootingBonus(identifier, livingEntity, curio, index);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\curios-309927-4590652.jar!\top\theillusivec4\curios\api\type\capability\ICurioItem.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */