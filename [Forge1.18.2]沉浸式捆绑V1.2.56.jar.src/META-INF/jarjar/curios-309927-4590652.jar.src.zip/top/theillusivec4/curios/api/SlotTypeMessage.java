/*     */ package top.theillusivec4.curios.api;
/*     */ 
/*     */ import net.minecraft.resources.ResourceLocation;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SlotTypeMessage
/*     */ {
/*     */   public static final String REGISTER_TYPE = "register_type";
/*     */   public static final String MODIFY_TYPE = "modify_type";
/*     */   private final String identifier;
/*     */   private final Integer priority;
/*     */   private final int size;
/*     */   private final boolean visible;
/*     */   private final boolean cosmetic;
/*     */   private final ResourceLocation icon;
/*     */   
/*     */   private SlotTypeMessage(Builder builder) {
/*  37 */     this.identifier = builder.identifier;
/*  38 */     this.priority = builder.priority;
/*  39 */     this.size = builder.size;
/*  40 */     this.visible = builder.visible;
/*  41 */     this.cosmetic = builder.cosmetic;
/*  42 */     this.icon = builder.icon;
/*     */   }
/*     */   
/*     */   public String getIdentifier() {
/*  46 */     return this.identifier;
/*     */   }
/*     */   
/*     */   public ResourceLocation getIcon() {
/*  50 */     return this.icon;
/*     */   }
/*     */   
/*     */   public Integer getPriority() {
/*  54 */     return this.priority;
/*     */   }
/*     */   
/*     */   public int getSize() {
/*  58 */     return this.size;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public boolean isLocked() {
/*  66 */     return (getSize() == 0);
/*     */   }
/*     */   
/*     */   public boolean isVisible() {
/*  70 */     return this.visible;
/*     */   }
/*     */   
/*     */   public boolean hasCosmetic() {
/*  74 */     return this.cosmetic;
/*     */   }
/*     */   
/*     */   public static class Builder
/*     */   {
/*     */     private final String identifier;
/*     */     private Integer priority;
/*  81 */     private int size = 1;
/*     */     private boolean visible = true;
/*     */     private boolean cosmetic = false;
/*  84 */     private ResourceLocation icon = null;
/*     */     
/*     */     public Builder(String identifier) {
/*  87 */       this.identifier = identifier;
/*     */     }
/*     */     
/*     */     public Builder icon(ResourceLocation icon) {
/*  91 */       this.icon = icon;
/*  92 */       return this;
/*     */     }
/*     */     
/*     */     public Builder priority(int priority) {
/*  96 */       this.priority = Integer.valueOf(priority);
/*  97 */       return this;
/*     */     }
/*     */     
/*     */     public Builder size(int size) {
/* 101 */       this.size = size;
/* 102 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Deprecated
/*     */     public Builder lock() {
/* 110 */       this.size = 0;
/* 111 */       return this;
/*     */     }
/*     */     
/*     */     public Builder hide() {
/* 115 */       this.visible = false;
/* 116 */       return this;
/*     */     }
/*     */     
/*     */     public Builder cosmetic() {
/* 120 */       this.cosmetic = true;
/* 121 */       return this;
/*     */     }
/*     */     
/*     */     public SlotTypeMessage build() {
/* 125 */       return new SlotTypeMessage(this);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\curios-309927-4590652.jar!\top\theillusivec4\curios\api\SlotTypeMessage.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */