package top.theillusivec4.curios.api;

import net.minecraftforge.common.capabilities.CapabilityToken;
import top.theillusivec4.curios.api.type.capability.ICuriosItemHandler;

class null extends CapabilityToken<ICuriosItemHandler> {}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\curios-309927-4590652.jar!\top\theillusivec4\curios\api\CuriosCapability$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */