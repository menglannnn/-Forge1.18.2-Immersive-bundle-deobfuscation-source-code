/*     */ package discord4j.core.object;
/*     */ 
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.GatewayDiscordClient;
/*     */ import discord4j.core.object.entity.Guild;
/*     */ import discord4j.core.object.entity.User;
/*     */ import discord4j.core.object.entity.channel.CategorizableChannel;
/*     */ import discord4j.core.retriever.EntityRetrievalStrategy;
/*     */ import discord4j.discordjson.json.GuildFields;
/*     */ import discord4j.discordjson.json.InviteData;
/*     */ import discord4j.discordjson.json.UserData;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import java.util.OptionalInt;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Invite
/*     */   implements DiscordObject
/*     */ {
/*     */   private final GatewayDiscordClient gateway;
/*     */   private final InviteData data;
/*     */   
/*     */   public Invite(GatewayDiscordClient gateway, InviteData data) {
/*  55 */     this.gateway = Objects.<GatewayDiscordClient>requireNonNull(gateway);
/*  56 */     this.data = Objects.<InviteData>requireNonNull(data);
/*     */   }
/*     */ 
/*     */   
/*     */   public final GatewayDiscordClient getClient() {
/*  61 */     return this.gateway;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getCode() {
/*  70 */     return this.data.code();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Optional<Snowflake> getGuildId() {
/*  79 */     return this.data.guild().toOptional()
/*  80 */       .map(GuildFields::id)
/*  81 */       .map(Snowflake::of);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Mono<Guild> getGuild() {
/*  91 */     Objects.requireNonNull(this.gateway); return getGuildId().<Mono<Guild>>map(this.gateway::getGuildById).orElse(Mono.empty());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Mono<Guild> getGuild(EntityRetrievalStrategy retrievalStrategy) {
/* 102 */     return getGuildId()
/* 103 */       .<Mono<Guild>>map(id -> this.gateway.withRetrievalStrategy(retrievalStrategy).getGuildById(id))
/* 104 */       .orElse(Mono.empty());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Snowflake getChannelId() {
/* 113 */     return Snowflake.of(this.data.channel().id());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Mono<CategorizableChannel> getChannel() {
/* 123 */     return this.gateway.getChannelById(getChannelId()).cast(CategorizableChannel.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Mono<CategorizableChannel> getChannel(EntityRetrievalStrategy retrievalStrategy) {
/* 134 */     return this.gateway.withRetrievalStrategy(retrievalStrategy)
/* 135 */       .getChannelById(getChannelId())
/* 136 */       .cast(CategorizableChannel.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Optional<Snowflake> getInviterId() {
/* 145 */     return this.data.inviter().toOptional()
/* 146 */       .map(UserData::id)
/* 147 */       .map(Snowflake::of);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Optional<User> getInviter() {
/* 156 */     return this.data.inviter().toOptional()
/* 157 */       .map(data -> new User(this.gateway, data));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Optional<Snowflake> getTargetUserId() {
/* 166 */     return this.data.targetUser().toOptional()
/* 167 */       .map(UserData::id)
/* 168 */       .map(Snowflake::of);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Optional<User> getTargetUser() {
/* 177 */     return this.data.targetUser().toOptional()
/* 178 */       .map(data -> new User(this.gateway, data));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public final Optional<Type> getTargetUserType() {
/* 189 */     return getTargetType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Optional<Type> getTargetType() {
/* 198 */     return this.data.targetType().toOptional()
/* 199 */       .map(Type::of);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final OptionalInt getApproximatePresenceCount() {
/* 210 */     return this.data.approximatePresenceCount().toOptional()
/* 211 */       .map(OptionalInt::of)
/* 212 */       .orElse(OptionalInt.empty());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final OptionalInt getApproximateMemberCount() {
/* 223 */     return this.data.approximateMemberCount().toOptional()
/* 224 */       .map(OptionalInt::of)
/* 225 */       .orElse(OptionalInt.empty());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Mono<Void> delete() {
/* 235 */     return delete(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Mono<Void> delete(@Nullable String reason) {
/* 246 */     return this.gateway.getRestClient().getInviteService()
/* 247 */       .deleteInvite(getCode(), reason)
/* 248 */       .then();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   InviteData getData() {
/* 257 */     return this.data;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public enum Type
/*     */   {
/* 264 */     UNKNOWN(-1),
/*     */ 
/*     */     
/* 267 */     STREAM(1),
/*     */ 
/*     */     
/* 270 */     EMBEDDED_APPLICATION(2);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final int value;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Type(int value) {
/* 281 */       this.value = value;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int getValue() {
/* 290 */       return this.value;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Type of(int value) {
/* 301 */       switch (value) { case 1:
/* 302 */           return STREAM;
/* 303 */         case 2: return EMBEDDED_APPLICATION; }
/* 304 */        return UNKNOWN;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 312 */     return "Invite{data=" + this.data + '}';
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\object\Invite.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */