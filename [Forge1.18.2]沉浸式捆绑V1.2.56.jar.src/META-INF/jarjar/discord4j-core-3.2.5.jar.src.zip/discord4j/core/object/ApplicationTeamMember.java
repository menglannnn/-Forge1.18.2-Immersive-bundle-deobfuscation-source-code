/*     */ package discord4j.core.object;
/*     */ 
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.GatewayDiscordClient;
/*     */ import discord4j.core.object.entity.User;
/*     */ import discord4j.core.retriever.EntityRetrievalStrategy;
/*     */ import discord4j.discordjson.json.ApplicationTeamMemberData;
/*     */ import java.util.Objects;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ApplicationTeamMember
/*     */   implements DiscordObject
/*     */ {
/*     */   private final GatewayDiscordClient gateway;
/*     */   private final ApplicationTeamMemberData data;
/*     */   
/*     */   public ApplicationTeamMember(GatewayDiscordClient gateway, ApplicationTeamMemberData data) {
/*  48 */     this.gateway = Objects.<GatewayDiscordClient>requireNonNull(gateway);
/*  49 */     this.data = Objects.<ApplicationTeamMemberData>requireNonNull(data);
/*     */   }
/*     */ 
/*     */   
/*     */   public GatewayDiscordClient getClient() {
/*  54 */     return this.gateway;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ApplicationTeamMemberData getData() {
/*  63 */     return this.data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MembershipState getMembershipState() {
/*  72 */     return MembershipState.of(this.data.membershipState());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Snowflake getTeamId() {
/*  81 */     return Snowflake.of(this.data.teamId().asLong());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Snowflake getUserId() {
/*  90 */     return Snowflake.of(this.data.user().id().asLong());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<User> getUser() {
/* 100 */     return this.gateway.getUserById(getUserId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<User> getUser(EntityRetrievalStrategy retrievalStrategy) {
/* 111 */     return this.gateway.withRetrievalStrategy(retrievalStrategy).getUserById(getUserId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum MembershipState
/*     */   {
/* 122 */     UNKNOWN(-1),
/*     */     
/* 124 */     INVITED(1),
/*     */     
/* 126 */     ACCEPTED(2);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final int value;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     MembershipState(int value) {
/* 137 */       this.value = value;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int getValue() {
/* 146 */       return this.value;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static MembershipState of(int value) {
/* 157 */       switch (value) { case 1:
/* 158 */           return INVITED;
/* 159 */         case 2: return ACCEPTED; }
/* 160 */        return UNKNOWN;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 167 */     return "ApplicationTeamMember{data=" + this.data + '}';
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\object\ApplicationTeamMember.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */