/*     */ package discord4j.core.object.automod;
/*     */ 
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.GatewayDiscordClient;
/*     */ import discord4j.core.object.DiscordObject;
/*     */ import discord4j.discordjson.json.AutoModActionData;
/*     */ import discord4j.discordjson.json.AutoModActionMetaData;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AutoModRuleAction
/*     */   implements DiscordObject
/*     */ {
/*     */   private final GatewayDiscordClient gateway;
/*     */   private final AutoModActionData data;
/*     */   
/*     */   public AutoModRuleAction(GatewayDiscordClient gateway, AutoModActionData data) {
/*  30 */     this.gateway = Objects.<GatewayDiscordClient>requireNonNull(gateway);
/*  31 */     this.data = Objects.<AutoModActionData>requireNonNull(data);
/*     */   }
/*     */   
/*     */   public AutoModActionData getData() {
/*  35 */     return this.data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Type getType() {
/*  44 */     return Type.of(this.data.type());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<AutoModRuleActionMetaData> getMetadata() {
/*  53 */     return this.data.metadata().toOptional().map(data -> new AutoModRuleActionMetaData(this.gateway, data));
/*     */   }
/*     */ 
/*     */   
/*     */   public GatewayDiscordClient getClient() {
/*  58 */     return this.gateway;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class AutoModRuleActionMetaData
/*     */     implements DiscordObject
/*     */   {
/*     */     private final GatewayDiscordClient gateway;
/*     */ 
/*     */ 
/*     */     
/*     */     private final AutoModActionMetaData data;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public AutoModRuleActionMetaData(GatewayDiscordClient gateway, AutoModActionMetaData data) {
/*  78 */       this.gateway = Objects.<GatewayDiscordClient>requireNonNull(gateway);
/*  79 */       this.data = Objects.<AutoModActionMetaData>requireNonNull(data);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Optional<Snowflake> getChannelId() {
/*  90 */       return this.data.channelId().toOptional().map(Snowflake::of);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Optional<Integer> getDurationTimeout() {
/* 101 */       return this.data.duration().toOptional();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Optional<String> getCustomMessage() {
/* 112 */       return this.data.customMessage().toOptional();
/*     */     }
/*     */ 
/*     */     
/*     */     public GatewayDiscordClient getClient() {
/* 117 */       return this.gateway;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum Type
/*     */   {
/* 128 */     UNKNOWN(-1),
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 133 */     BLOCK_MESSAGE(1),
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 138 */     SEND_ALERT_MESSAGE(2),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 146 */     TIMEOUT(3);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final int value;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Type(int value) {
/* 159 */       this.value = value;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int getValue() {
/* 168 */       return this.value;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Type of(int value) {
/* 179 */       for (Type type : values()) {
/* 180 */         if (type.getValue() == value) {
/* 181 */           return type;
/*     */         }
/*     */       } 
/* 184 */       return UNKNOWN;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\object\automod\AutoModRuleAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */