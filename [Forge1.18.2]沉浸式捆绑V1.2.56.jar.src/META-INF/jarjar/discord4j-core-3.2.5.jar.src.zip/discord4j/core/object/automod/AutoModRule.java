/*     */ package discord4j.core.object.automod;
/*     */ 
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.GatewayDiscordClient;
/*     */ import discord4j.core.object.entity.Entity;
/*     */ import discord4j.core.object.entity.User;
/*     */ import discord4j.core.spec.AutoModRuleEditMono;
/*     */ import discord4j.core.spec.AutoModRuleEditSpec;
/*     */ import discord4j.discordjson.json.AutoModActionData;
/*     */ import discord4j.discordjson.json.AutoModRuleData;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.stream.Collectors;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AutoModRule
/*     */   implements Entity
/*     */ {
/*     */   private final GatewayDiscordClient gateway;
/*     */   private final AutoModRuleData data;
/*     */   
/*     */   public AutoModRule(GatewayDiscordClient gateway, AutoModRuleData data) {
/*  35 */     this.gateway = Objects.<GatewayDiscordClient>requireNonNull(gateway);
/*  36 */     this.data = Objects.<AutoModRuleData>requireNonNull(data);
/*     */   }
/*     */   
/*     */   public AutoModRuleData getData() {
/*  40 */     return this.data;
/*     */   }
/*     */ 
/*     */   
/*     */   public GatewayDiscordClient getClient() {
/*  45 */     return this.gateway;
/*     */   }
/*     */ 
/*     */   
/*     */   public Snowflake getId() {
/*  50 */     return Snowflake.of(this.data.id());
/*     */   }
/*     */   
/*     */   public Snowflake getGuildId() {
/*  54 */     return Snowflake.of(this.data.guildId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Snowflake getCreatorId() {
/*  63 */     return Snowflake.of(this.data.creatorId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<User> getCreatorUser() {
/*  73 */     return getClient().getUserById(getCreatorId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEnabled() {
/*  82 */     return this.data.enabled();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/*  91 */     return this.data.name();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TriggerType getTriggerType() {
/* 100 */     return TriggerType.of(this.data.triggerType());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AutoModRuleTriggerMetaData getTriggerMetaData() {
/* 109 */     return new AutoModRuleTriggerMetaData(this.gateway, this.data.triggerMetadata());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<AutoModRuleAction> getActions() {
/* 118 */     return (List<AutoModRuleAction>)this.data.actions().stream()
/* 119 */       .map(data -> new AutoModRuleAction(this.gateway, data))
/* 120 */       .collect(Collectors.toList());
/*     */   }
/*     */   
/*     */   public EventType getEventType() {
/* 124 */     return EventType.of(this.data.eventType());
/*     */   }
/*     */   
/*     */   public List<Snowflake> getExemptRolesIds() {
/* 128 */     return (List<Snowflake>)this.data.exemptRoles().stream()
/* 129 */       .map(Snowflake::of)
/* 130 */       .collect(Collectors.toList());
/*     */   }
/*     */   
/*     */   public List<Snowflake> getExemptChannelsIds() {
/* 134 */     return (List<Snowflake>)this.data.exemptChannels().stream()
/* 135 */       .map(Snowflake::of)
/* 136 */       .collect(Collectors.toList());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AutoModRuleEditMono edit(String name, EventType eventType, boolean enabled) {
/* 150 */     return AutoModRuleEditMono.of(name, eventType.value, enabled, this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<AutoModRule> edit(AutoModRuleEditSpec spec) {
/* 161 */     Objects.requireNonNull(spec);
/* 162 */     return Mono.defer(() -> this.gateway.getRestClient().getAutoModService().modifyAutoModRule(getGuildId().asLong(), getId().asLong(), spec.asRequest(), spec.reason()))
/*     */ 
/*     */ 
/*     */       
/* 166 */       .map(data -> new AutoModRule(this.gateway, data));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Void> delete() {
/* 176 */     return delete(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Void> delete(@Nullable String reason) {
/* 187 */     return this.gateway.getRestClient().getAutoModService()
/* 188 */       .deleteAutoModRule(getGuildId().asLong(), getId().asLong(), reason);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum TriggerType
/*     */   {
/* 199 */     UNKNOWN(-1),
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 204 */     KEYWORD(1),
/*     */     
/* 206 */     HARMFUL_LINK(2),
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 211 */     SPAM(3),
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 216 */     KEYWORD_PRESET(4),
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 221 */     MENTION_SPAM(5);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final int value;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     TriggerType(int value) {
/* 234 */       this.value = value;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int getValue() {
/* 243 */       return this.value;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static TriggerType of(int value) {
/* 254 */       for (TriggerType type : values()) {
/* 255 */         if (type.getValue() == value) {
/* 256 */           return type;
/*     */         }
/*     */       } 
/* 259 */       return UNKNOWN;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum EventType
/*     */   {
/* 270 */     UNKNOWN(-1),
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 275 */     MESSAGE_SEND(1);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final int value;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     EventType(int value) {
/* 288 */       this.value = value;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int getValue() {
/* 297 */       return this.value;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static EventType of(int value) {
/* 308 */       switch (value) { case 1:
/* 309 */           return MESSAGE_SEND; }
/* 310 */        return UNKNOWN;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\object\automod\AutoModRule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */