/*     */ package discord4j.core.object.automod;
/*     */ 
/*     */ import discord4j.core.GatewayDiscordClient;
/*     */ import discord4j.discordjson.json.AutoModTriggerMetaData;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.EnumSet;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import java.util.regex.Pattern;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.stream.Stream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AutoModRuleTriggerMetaData
/*     */ {
/*     */   private final GatewayDiscordClient gateway;
/*     */   private final AutoModTriggerMetaData data;
/*     */   
/*     */   public AutoModRuleTriggerMetaData(GatewayDiscordClient gateway, AutoModTriggerMetaData data) {
/*  33 */     this.gateway = Objects.<GatewayDiscordClient>requireNonNull(gateway);
/*  34 */     this.data = Objects.<AutoModTriggerMetaData>requireNonNull(data);
/*     */   }
/*     */   
/*     */   public GatewayDiscordClient getClient() {
/*  38 */     return this.gateway;
/*     */   }
/*     */   
/*     */   public AutoModTriggerMetaData getData() {
/*  42 */     return this.data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<String> getKeywordFilter() {
/*  51 */     return this.data.keywordFilter().toOptional()
/*  52 */       .orElse(Collections.emptyList());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<String> getAllowedFilter() {
/*  61 */     return this.data.allowList().toOptional()
/*  62 */       .orElse(Collections.emptyList());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Pattern> getRegexPatterns() {
/*  71 */     return this.data.regexPatterns().toOptional()
/*  72 */       .map(listRegexPatterns -> (List)listRegexPatterns.stream().map(Pattern::compile).collect(Collectors.toList()))
/*  73 */       .orElse(Collections.emptyList());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<Integer> getMentionLimit() {
/*  82 */     return this.data.mentionTotalLimit().toOptional();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isMentionRaidProtectionEnabled() {
/*  91 */     return ((Boolean)this.data.mentionRaidProtectionEnabled().toOptional().orElse(Boolean.valueOf(false))).booleanValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EnumSet<Preset> getPresets() {
/* 100 */     EnumSet<Preset> presets = EnumSet.noneOf(Preset.class);
/* 101 */     if (this.data.presets().isAbsent()) {
/* 102 */       return presets;
/*     */     }
/* 104 */     presets.addAll((Collection<? extends Preset>)((Stream)this.data.presets().toOptional().map(presetValues -> presetValues.stream().map(Preset::of)).orElse(Stream.empty())).collect(Collectors.toList()));
/* 105 */     return presets;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum Preset
/*     */   {
/* 115 */     UNKNOWN(-1),
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 120 */     PROFANITY(1),
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 125 */     SEXUAL_CONTENT(2),
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 130 */     SLURS(3);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final int value;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Preset(int value) {
/* 143 */       this.value = value;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int getValue() {
/* 152 */       return this.value;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Preset of(int value) {
/* 163 */       for (Preset preset : values()) {
/* 164 */         if (preset.getValue() == value) {
/* 165 */           return preset;
/*     */         }
/*     */       } 
/* 168 */       return UNKNOWN;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\object\automod\AutoModRuleTriggerMetaData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */