/*    */ package discord4j.core.object;
/*    */ 
/*    */ import discord4j.core.GatewayDiscordClient;
/*    */ import discord4j.discordjson.json.InviteData;
/*    */ import java.time.Instant;
/*    */ import java.time.format.DateTimeFormatter;
/*    */ import java.time.temporal.ChronoUnit;
/*    */ import java.util.Optional;
/*    */ import java.util.function.Supplier;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ExtendedInvite
/*    */   extends Invite
/*    */ {
/*    */   public ExtendedInvite(GatewayDiscordClient gateway, InviteData data) {
/* 43 */     super(gateway, data);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getUses() {
/* 52 */     return ((Integer)getData().uses().toOptional()
/* 53 */       .orElseThrow(IllegalStateException::new)).intValue();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getMaxUses() {
/* 62 */     return ((Integer)getData().maxUses().toOptional()
/* 63 */       .orElseThrow(IllegalStateException::new)).intValue();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Optional<Instant> getExpiration() {
/* 72 */     int maxAge = ((Integer)getData().maxAge().toOptional().orElseThrow(IllegalStateException::new)).intValue();
/* 73 */     return (maxAge > 0) ? Optional.<Instant>of(getCreation().plus(maxAge, ChronoUnit.SECONDS)) : Optional.<Instant>empty();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isTemporary() {
/* 82 */     return ((Boolean)getData().temporary().toOptional()
/* 83 */       .orElseThrow(IllegalStateException::new)).booleanValue();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Instant getCreation() {
/* 92 */     String createdAt = (String)getData().createdAt().toOptional().orElseThrow(IllegalStateException::new);
/* 93 */     return DateTimeFormatter.ISO_OFFSET_DATE_TIME.<Instant>parse(createdAt, Instant::from);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 98 */     return "ExtendedInvite{} " + super.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\object\ExtendedInvite.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */