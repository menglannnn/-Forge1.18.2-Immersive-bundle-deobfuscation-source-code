/*    */ package discord4j.core.object;
/*    */ 
/*    */ import discord4j.core.GatewayDiscordClient;
/*    */ import discord4j.discordjson.json.GuildScheduledEventEntityMetadataData;
/*    */ import java.util.Objects;
/*    */ import java.util.Optional;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ScheduledEventEntityMetadata
/*    */   implements DiscordObject
/*    */ {
/*    */   private final GatewayDiscordClient gateway;
/*    */   private final GuildScheduledEventEntityMetadataData data;
/*    */   
/*    */   public ScheduledEventEntityMetadata(GatewayDiscordClient gateway, GuildScheduledEventEntityMetadataData data) {
/* 41 */     this.gateway = Objects.<GatewayDiscordClient>requireNonNull(gateway);
/* 42 */     this.data = Objects.<GuildScheduledEventEntityMetadataData>requireNonNull(data);
/*    */   }
/*    */ 
/*    */   
/*    */   public GatewayDiscordClient getClient() {
/* 47 */     return this.gateway;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public GuildScheduledEventEntityMetadataData getData() {
/* 56 */     return this.data;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Optional<String> getLocation() {
/* 65 */     return this.data.location().toOptional();
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 70 */     return "ScheduledEventEntityMetadata{data=" + this.data + '}';
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\object\ScheduledEventEntityMetadata.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */