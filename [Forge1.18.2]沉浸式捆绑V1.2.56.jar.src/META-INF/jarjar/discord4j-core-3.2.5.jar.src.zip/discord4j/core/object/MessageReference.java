/*    */ package discord4j.core.object;
/*    */ 
/*    */ import discord4j.common.annotations.Experimental;
/*    */ import discord4j.common.util.Snowflake;
/*    */ import discord4j.core.GatewayDiscordClient;
/*    */ import discord4j.discordjson.Id;
/*    */ import discord4j.discordjson.json.MessageReferenceData;
/*    */ import java.util.Objects;
/*    */ import java.util.Optional;
/*    */ import java.util.function.Supplier;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Experimental
/*    */ public class MessageReference
/*    */   implements DiscordObject
/*    */ {
/*    */   private final GatewayDiscordClient gateway;
/*    */   private final MessageReferenceData data;
/*    */   
/*    */   public MessageReference(GatewayDiscordClient gateway, MessageReferenceData data) {
/* 50 */     this.gateway = Objects.<GatewayDiscordClient>requireNonNull(gateway);
/* 51 */     this.data = Objects.<MessageReferenceData>requireNonNull(data);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public MessageReferenceData getData() {
/* 60 */     return this.data;
/*    */   }
/*    */   
/*    */   public Snowflake getChannelId() {
/* 64 */     return Snowflake.of((Id)this.data.channelId().toOptional().orElseThrow(IllegalStateException::new));
/*    */   }
/*    */   
/*    */   public Optional<Snowflake> getGuildId() {
/* 68 */     return this.data.guildId().toOptional()
/* 69 */       .map(Snowflake::of);
/*    */   }
/*    */   
/*    */   public Optional<Snowflake> getMessageId() {
/* 73 */     return this.data.messageId().toOptional()
/* 74 */       .map(Snowflake::of);
/*    */   }
/*    */ 
/*    */   
/*    */   public GatewayDiscordClient getClient() {
/* 79 */     return this.gateway;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 84 */     return "MessageReference{data=" + this.data + '}';
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\object\MessageReference.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */