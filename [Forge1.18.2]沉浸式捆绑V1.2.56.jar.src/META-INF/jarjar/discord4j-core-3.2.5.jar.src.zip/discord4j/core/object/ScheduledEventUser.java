/*    */ package discord4j.core.object;
/*    */ 
/*    */ import discord4j.common.util.Snowflake;
/*    */ import discord4j.core.GatewayDiscordClient;
/*    */ import discord4j.core.object.entity.PartialMember;
/*    */ import discord4j.core.object.entity.User;
/*    */ import discord4j.discordjson.json.GuildScheduledEventUserData;
/*    */ import discord4j.discordjson.json.PartialMemberData;
/*    */ import java.util.Objects;
/*    */ import java.util.Optional;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ScheduledEventUser
/*    */   implements DiscordObject
/*    */ {
/*    */   private final GatewayDiscordClient gateway;
/*    */   private final GuildScheduledEventUserData data;
/*    */   private final Snowflake guildId;
/*    */   
/*    */   public ScheduledEventUser(GatewayDiscordClient gateway, GuildScheduledEventUserData data, Snowflake guildId) {
/* 48 */     this.gateway = Objects.<GatewayDiscordClient>requireNonNull(gateway);
/* 49 */     this.data = Objects.<GuildScheduledEventUserData>requireNonNull(data);
/* 50 */     this.guildId = Objects.<Snowflake>requireNonNull(guildId);
/*    */   }
/*    */ 
/*    */   
/*    */   public GatewayDiscordClient getClient() {
/* 55 */     return this.gateway;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Snowflake getEventId() {
/* 64 */     return Snowflake.of(this.data.guildScheduledEventId());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public User getUser() {
/* 73 */     return new User(this.gateway, this.data.user());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Optional<PartialMember> getMember() {
/* 82 */     return this.data.member().toOptional()
/* 83 */       .map(memberData -> new PartialMember(this.gateway, this.data.user(), memberData, this.guildId.asLong()));
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 88 */     return "ScheduledEventUser{data=" + this.data + '}';
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\object\ScheduledEventUser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */