/*    */ package discord4j.core.object.presence;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum Status
/*    */ {
/* 26 */   UNKNOWN("UNKNOWN"),
/* 27 */   ONLINE("online"),
/* 28 */   DO_NOT_DISTURB("dnd"),
/* 29 */   IDLE("idle"),
/* 30 */   INVISIBLE("invisible"),
/* 31 */   OFFLINE("offline");
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private final String value;
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   Status(String value) {
/* 42 */     this.value = value;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getValue() {
/* 51 */     return this.value;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static Status of(String value) {
/* 62 */     switch (value) { case "idle":
/* 63 */         return IDLE;
/* 64 */       case "dnd": return DO_NOT_DISTURB;
/* 65 */       case "online": return ONLINE;
/* 66 */       case "invisible": return INVISIBLE;
/* 67 */       case "offline": return OFFLINE; }
/* 68 */      return UNKNOWN;
/*    */   }
/*    */   
/*    */   public enum Platform
/*    */   {
/* 73 */     DESKTOP,
/* 74 */     MOBILE,
/* 75 */     WEB;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\object\presence\Status.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */