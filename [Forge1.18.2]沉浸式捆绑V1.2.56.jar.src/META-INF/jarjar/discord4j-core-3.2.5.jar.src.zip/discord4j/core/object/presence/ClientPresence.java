/*     */ package discord4j.core.object.presence;
/*     */ 
/*     */ import discord4j.discordjson.json.ActivityUpdateRequest;
/*     */ import discord4j.discordjson.json.gateway.StatusUpdate;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Optional;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClientPresence
/*     */ {
/*     */   private final StatusUpdate statusUpdate;
/*     */   
/*     */   public static ClientPresence online() {
/*  48 */     return of(Status.ONLINE, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ClientPresence online(ClientActivity activity) {
/*  58 */     return of(Status.ONLINE, activity);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ClientPresence doNotDisturb() {
/*  67 */     return of(Status.DO_NOT_DISTURB, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ClientPresence doNotDisturb(ClientActivity activity) {
/*  77 */     return of(Status.DO_NOT_DISTURB, activity);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ClientPresence idle() {
/*  86 */     return of(Status.IDLE, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ClientPresence idle(ClientActivity activity) {
/*  96 */     return of(Status.IDLE, activity);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ClientPresence invisible() {
/* 105 */     return of(Status.INVISIBLE, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ClientPresence of(Status status, @Nullable ClientActivity activity) {
/* 119 */     List<ActivityUpdateRequest> activities = Optional.<ClientActivity>ofNullable(activity).map(ClientActivity::getActivityUpdateRequest).map(Collections::singletonList).orElse(Collections.emptyList());
/*     */     
/* 121 */     return new ClientPresence((StatusUpdate)StatusUpdate.builder()
/* 122 */         .status(status.getValue())
/* 123 */         .activities(activities)
/* 124 */         .afk(false)
/* 125 */         .since(0L)
/* 126 */         .build());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private ClientPresence(StatusUpdate statusUpdate) {
/* 132 */     this.statusUpdate = statusUpdate;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StatusUpdate getStatusUpdate() {
/* 141 */     return this.statusUpdate;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\object\presence\ClientPresence.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */