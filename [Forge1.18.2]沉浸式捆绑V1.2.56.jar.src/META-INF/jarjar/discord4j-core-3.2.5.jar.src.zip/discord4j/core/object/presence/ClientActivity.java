/*     */ package discord4j.core.object.presence;
/*     */ 
/*     */ import discord4j.discordjson.json.ActivityUpdateRequest;
/*     */ import java.util.Optional;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClientActivity
/*     */ {
/*     */   private final ActivityUpdateRequest activityUpdateRequest;
/*     */   
/*     */   public static ClientActivity playing(String name) {
/*  40 */     return of(Activity.Type.PLAYING, name, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ClientActivity streaming(String name, String url) {
/*  51 */     return of(Activity.Type.STREAMING, name, url);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ClientActivity listening(String name) {
/*  61 */     return of(Activity.Type.LISTENING, name, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ClientActivity watching(String name) {
/*  71 */     return of(Activity.Type.WATCHING, name, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ClientActivity competing(String name) {
/*  81 */     return of(Activity.Type.COMPETING, name, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ClientActivity of(Activity.Type type, String name, @Nullable String url) {
/*  93 */     return new ClientActivity((ActivityUpdateRequest)ActivityUpdateRequest.builder()
/*  94 */         .type(type.getValue())
/*  95 */         .name(name)
/*  96 */         .url(Optional.ofNullable(url))
/*  97 */         .build());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private ClientActivity(ActivityUpdateRequest activityUpdateRequest) {
/* 103 */     this.activityUpdateRequest = activityUpdateRequest;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ActivityUpdateRequest getActivityUpdateRequest() {
/* 112 */     return this.activityUpdateRequest;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\object\presence\ClientActivity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */