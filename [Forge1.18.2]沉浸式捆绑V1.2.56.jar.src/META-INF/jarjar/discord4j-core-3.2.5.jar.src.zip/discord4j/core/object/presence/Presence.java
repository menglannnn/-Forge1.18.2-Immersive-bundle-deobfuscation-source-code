/*    */ package discord4j.core.object.presence;
/*    */ 
/*    */ import discord4j.discordjson.json.PresenceData;
/*    */ import java.util.List;
/*    */ import java.util.Optional;
/*    */ import java.util.function.Function;
/*    */ import java.util.stream.Collectors;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Presence
/*    */ {
/*    */   private final PresenceData data;
/*    */   
/*    */   public Presence(PresenceData data) {
/* 40 */     this.data = data;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Status getStatus() {
/* 49 */     return Status.of(this.data.status());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Optional<Status> getStatus(Status.Platform platform) {
/* 59 */     switch (platform) { case DESKTOP:
/* 60 */         return this.data.clientStatus().desktop().toOptional().map(Status::of);
/* 61 */       case MOBILE: return this.data.clientStatus().mobile().toOptional().map(Status::of);
/* 62 */       case WEB: return this.data.clientStatus().web().toOptional().map(Status::of); }
/*    */     
/* 64 */     throw new IllegalArgumentException("Unhandled platform " + platform);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Optional<Activity> getActivity() {
/* 74 */     return this.data.activities().stream().map(Activity::new).findFirst();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public List<Activity> getActivities() {
/* 83 */     return (List<Activity>)this.data.activities().stream().map(Activity::new).collect(Collectors.toList());
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 88 */     return "Presence{data=" + this.data + '}';
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\object\presence\Presence.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */