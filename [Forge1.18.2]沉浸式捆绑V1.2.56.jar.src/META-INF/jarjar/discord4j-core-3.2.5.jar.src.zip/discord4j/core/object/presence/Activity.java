/*     */ package discord4j.core.object.presence;
/*     */ 
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.object.reaction.ReactionEmoji;
/*     */ import discord4j.discordjson.Id;
/*     */ import discord4j.discordjson.json.ActivityAssetsData;
/*     */ import discord4j.discordjson.json.ActivityData;
/*     */ import discord4j.discordjson.json.ActivityEmojiData;
/*     */ import discord4j.discordjson.json.ActivityPartyData;
/*     */ import discord4j.discordjson.json.ActivitySecretsData;
/*     */ import discord4j.discordjson.json.ActivityTimestampsData;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.time.Instant;
/*     */ import java.util.Arrays;
/*     */ import java.util.EnumSet;
/*     */ import java.util.List;
/*     */ import java.util.Optional;
/*     */ import java.util.OptionalLong;
/*     */ import java.util.stream.Collectors;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Activity
/*     */ {
/*     */   private final ActivityData data;
/*     */   
/*     */   Activity(ActivityData data) {
/*  39 */     this.data = data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ActivityData getData() {
/*  48 */     return this.data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Type getType() {
/*  57 */     return Type.of(this.data.type());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/*  66 */     return this.data.name();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<String> getStreamingUrl() {
/*  75 */     return Possible.flatOpt(this.data.url());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Instant getCreatedAt() {
/*  84 */     return Instant.ofEpochMilli(this.data.createdAt());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<Instant> getStart() {
/*  93 */     return this.data.timestamps().toOptional()
/*  94 */       .flatMap(timestamps -> timestamps.start().toOptional())
/*  95 */       .map(Instant::ofEpochMilli);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<Instant> getEnd() {
/* 104 */     return this.data.timestamps().toOptional()
/* 105 */       .flatMap(timestamps -> timestamps.end().toOptional())
/* 106 */       .map(Instant::ofEpochMilli);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<Snowflake> getApplicationId() {
/* 115 */     return this.data.applicationId().toOptional()
/* 116 */       .map(Snowflake::of);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<String> getDetails() {
/* 125 */     return Possible.flatOpt(this.data.details());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<String> getState() {
/* 134 */     return Possible.flatOpt(this.data.state());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<String> getPartyId() {
/* 143 */     return this.data.party().toOptional()
/* 144 */       .flatMap(party -> party.id().toOptional());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OptionalLong getCurrentPartySize() {
/* 153 */     return this.data.party().toOptional()
/* 154 */       .flatMap(party -> party.size().toOptional())
/* 155 */       .map(size -> (Long)size.get(0))
/* 156 */       .map(OptionalLong::of)
/* 157 */       .orElseGet(OptionalLong::empty);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OptionalLong getMaxPartySize() {
/* 166 */     return this.data.party().toOptional()
/* 167 */       .flatMap(party -> party.size().toOptional())
/* 168 */       .map(size -> (Long)size.get(1))
/* 169 */       .map(OptionalLong::of)
/* 170 */       .orElseGet(OptionalLong::empty);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<String> getLargeImageId() {
/* 179 */     return this.data.assets().toOptional()
/* 180 */       .flatMap(assets -> assets.largeImage().toOptional());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<String> getLargeText() {
/* 189 */     return this.data.assets().toOptional()
/* 190 */       .flatMap(assets -> assets.largeText().toOptional());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<String> getSmallImageId() {
/* 199 */     return this.data.assets().toOptional()
/* 200 */       .flatMap(assets -> assets.smallImage().toOptional());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<String> getSmallText() {
/* 209 */     return this.data.assets().toOptional()
/* 210 */       .flatMap(assets -> assets.smallText().toOptional());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<String> getJoinSecret() {
/* 219 */     return this.data.secrets().toOptional()
/* 220 */       .flatMap(secrets -> secrets.join().toOptional());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<String> getSpectateSecret() {
/* 229 */     return this.data.secrets().toOptional()
/* 230 */       .flatMap(secrets -> secrets.spectate().toOptional());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<String> getMatchSecret() {
/* 239 */     return this.data.secrets().toOptional()
/* 240 */       .flatMap(secrets -> secrets.match().toOptional());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<ReactionEmoji> getEmoji() {
/* 249 */     return Possible.flatOpt(this.data.emoji())
/* 250 */       .map(emoji -> {
/*     */           String sid = emoji.id().toOptional().map(Id::asString).orElse(null);
/*     */           Long id = (sid == null) ? null : Long.valueOf(Snowflake.asLong(sid));
/*     */           return ReactionEmoji.of(id, emoji.name(), ((Boolean)emoji.animated().toOptional().orElse(Boolean.valueOf(false))).booleanValue());
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isInstance() {
/* 265 */     return ((Boolean)this.data.instance().toOptional().orElse(Boolean.valueOf(false))).booleanValue();
/*     */   }
/*     */   
/*     */   public EnumSet<Flag> getFlags() {
/* 269 */     return this.data.flags().toOptional()
/* 270 */       .map(flags -> (EnumSet)Arrays.<Flag>stream(Flag.values()).filter(()).collect(Collectors.toCollection(())))
/*     */ 
/*     */       
/* 273 */       .orElse(EnumSet.noneOf(Flag.class));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public enum Type
/*     */   {
/* 280 */     UNKNOWN(-1),
/*     */ 
/*     */     
/* 283 */     PLAYING(0),
/*     */ 
/*     */     
/* 286 */     STREAMING(1),
/*     */ 
/*     */     
/* 289 */     LISTENING(2),
/*     */ 
/*     */     
/* 292 */     WATCHING(3),
/*     */ 
/*     */     
/* 295 */     CUSTOM(4),
/*     */ 
/*     */     
/* 298 */     COMPETING(5);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final int value;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Type(int value) {
/* 309 */       this.value = value;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int getValue() {
/* 318 */       return this.value;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Type of(int value) {
/* 329 */       switch (value) { case 0:
/* 330 */           return PLAYING;
/* 331 */         case 1: return STREAMING;
/* 332 */         case 2: return LISTENING;
/* 333 */         case 3: return WATCHING;
/* 334 */         case 4: return CUSTOM;
/* 335 */         case 5: return COMPETING; }
/* 336 */        return UNKNOWN;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public enum Flag
/*     */   {
/* 343 */     UNKNOWN(0),
/*     */     
/* 345 */     INSTANCE(1),
/* 346 */     JOIN(2),
/* 347 */     SPECTATE(4),
/* 348 */     JOIN_REQUEST(8),
/* 349 */     SYNC(16),
/* 350 */     PLAY(32),
/* 351 */     PARTY_PRIVACY_FRIENDS(64),
/* 352 */     PARTY_PRIVACY_VOICE_CHANNEL(128),
/* 353 */     EMBEDDED(256);
/*     */     
/*     */     private final int value;
/*     */     
/*     */     Flag(int value) {
/* 358 */       this.value = value;
/*     */     }
/*     */     
/*     */     public int getValue() {
/* 362 */       return this.value;
/*     */     }
/*     */     
/*     */     public static Flag of(int value) {
/* 366 */       switch (value) { case 1:
/* 367 */           return INSTANCE;
/* 368 */         case 2: return JOIN;
/* 369 */         case 4: return SPECTATE;
/* 370 */         case 8: return JOIN_REQUEST;
/* 371 */         case 16: return SYNC;
/* 372 */         case 32: return PLAY;
/* 373 */         case 64: return PARTY_PRIVACY_FRIENDS;
/* 374 */         case 128: return PARTY_PRIVACY_VOICE_CHANNEL;
/* 375 */         case 256: return EMBEDDED; }
/* 376 */        return UNKNOWN;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 383 */     return "Activity{data=" + this.data + '}';
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\object\presence\Activity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */