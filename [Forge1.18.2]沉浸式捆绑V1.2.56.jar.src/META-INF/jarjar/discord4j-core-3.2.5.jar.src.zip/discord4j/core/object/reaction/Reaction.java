/*    */ package discord4j.core.object.reaction;
/*    */ 
/*    */ import discord4j.core.GatewayDiscordClient;
/*    */ import discord4j.core.object.DiscordObject;
/*    */ import discord4j.discordjson.json.ReactionData;
/*    */ import java.util.Objects;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Reaction
/*    */   implements DiscordObject
/*    */ {
/*    */   private final GatewayDiscordClient gateway;
/*    */   private final ReactionData data;
/*    */   
/*    */   public Reaction(GatewayDiscordClient gateway, ReactionData data) {
/* 45 */     this.gateway = Objects.<GatewayDiscordClient>requireNonNull(gateway);
/* 46 */     this.data = Objects.<ReactionData>requireNonNull(data);
/*    */   }
/*    */ 
/*    */   
/*    */   public GatewayDiscordClient getClient() {
/* 51 */     return this.gateway;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ReactionData getData() {
/* 60 */     return this.data;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getCount() {
/* 69 */     return this.data.count();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean selfReacted() {
/* 78 */     return this.data.me();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ReactionEmoji getEmoji() {
/* 87 */     return ReactionEmoji.of(this.data);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 92 */     return "Reaction{data=" + this.data + '}';
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\object\reaction\Reaction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */