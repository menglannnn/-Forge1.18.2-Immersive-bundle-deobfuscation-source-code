/*     */ package discord4j.core.object.reaction;
/*     */ 
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.object.entity.GuildEmoji;
/*     */ import discord4j.discordjson.json.EmojiData;
/*     */ import discord4j.discordjson.json.ReactionData;
/*     */ import java.util.Arrays;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import java.util.function.Supplier;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ReactionEmoji
/*     */ {
/*     */   public static Custom custom(GuildEmoji emoji) {
/*  42 */     return new Custom(emoji.getId().asLong(), emoji.getName(), emoji.isAnimated());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Custom custom(Snowflake id, String name, boolean isAnimated) {
/*  54 */     return new Custom(id.asLong(), name, isAnimated);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Unicode unicode(String raw) {
/*  75 */     return new Unicode(raw);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Unicode codepoints(String... codepoints) {
/*  96 */     String combined = ((StringBuilder)Arrays.<String>stream(codepoints).map(c -> Integer.valueOf(Integer.parseInt(c.substring(2), 16))).reduce(new StringBuilder(), StringBuilder::appendCodePoint, StringBuilder::append)).toString();
/*     */     
/*  98 */     return unicode(combined);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ReactionEmoji of(@Nullable Long id, String name, boolean isAnimated) {
/* 110 */     return (id == null) ? unicode(name) : custom(Snowflake.of(id.longValue()), name, isAnimated);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ReactionEmoji of(ReactionData data) {
/* 120 */     return of(data.emoji());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ReactionEmoji of(EmojiData data) {
/* 130 */     if (data.id().isPresent()) {
/* 131 */       return custom(Snowflake.of(data.id().get()), (String)data
/* 132 */           .name().orElseThrow(IllegalArgumentException::new), ((Boolean)data
/* 133 */           .animated().toOptional().orElse(Boolean.valueOf(false))).booleanValue());
/*     */     }
/* 135 */     return unicode((String)data.name().orElseThrow(IllegalArgumentException::new));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<Custom> asCustomEmoji() {
/* 144 */     return (this instanceof Custom) ? Optional.<Custom>of((Custom)this) : Optional.<Custom>empty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<Unicode> asUnicodeEmoji() {
/* 153 */     return (this instanceof Unicode) ? Optional.<Unicode>of((Unicode)this) : Optional.<Unicode>empty();
/*     */   }
/*     */ 
/*     */   
/*     */   public abstract EmojiData asEmojiData();
/*     */ 
/*     */   
/*     */   public static final class Custom
/*     */     extends ReactionEmoji
/*     */   {
/*     */     private final long id;
/*     */     
/*     */     private final String name;
/*     */     
/*     */     private final boolean isAnimated;
/*     */     
/*     */     private Custom(long id, String name, boolean isAnimated) {
/* 170 */       this.id = id;
/* 171 */       this.name = name;
/* 172 */       this.isAnimated = isAnimated;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Snowflake getId() {
/* 181 */       return Snowflake.of(this.id);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getName() {
/* 190 */       return this.name;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isAnimated() {
/* 199 */       return this.isAnimated;
/*     */     }
/*     */ 
/*     */     
/*     */     public EmojiData asEmojiData() {
/* 204 */       return (EmojiData)EmojiData.builder()
/* 205 */         .id(this.id)
/* 206 */         .name(this.name)
/* 207 */         .animated(Boolean.valueOf(this.isAnimated))
/* 208 */         .build();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String asFormat() {
/* 217 */       return '<' + (isAnimated() ? "a" : "") + ':' + getName() + ':' + getId().asString() + '>';
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 222 */       return "ReactionEmoji.Custom{id=" + this.id + ", name='" + this.name + '\'' + ", isAnimated=" + this.isAnimated + "} " + super
/*     */ 
/*     */ 
/*     */         
/* 226 */         .toString();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(@Nullable Object o) {
/* 231 */       if (this == o) {
/* 232 */         return true;
/*     */       }
/* 234 */       if (o == null || getClass() != o.getClass()) {
/* 235 */         return false;
/*     */       }
/* 237 */       Custom custom = (Custom)o;
/* 238 */       return (this.id == custom.id);
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 243 */       return Objects.hash(new Object[] { Long.valueOf(this.id) });
/*     */     }
/*     */   }
/*     */   
/*     */   public static final class Unicode
/*     */     extends ReactionEmoji {
/*     */     private final String raw;
/*     */     
/*     */     private Unicode(String raw) {
/* 252 */       this.raw = raw;
/*     */     }
/*     */     
/*     */     public String getRaw() {
/* 256 */       return this.raw;
/*     */     }
/*     */ 
/*     */     
/*     */     public EmojiData asEmojiData() {
/* 261 */       return (EmojiData)EmojiData.builder()
/* 262 */         .name(this.raw)
/* 263 */         .build();
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 268 */       return "ReactionEmoji.Unicode{raw='" + this.raw + '\'' + "} " + super
/*     */         
/* 270 */         .toString();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(@Nullable Object o) {
/* 275 */       if (this == o) {
/* 276 */         return true;
/*     */       }
/* 278 */       if (o == null || getClass() != o.getClass()) {
/* 279 */         return false;
/*     */       }
/* 281 */       Unicode unicode = (Unicode)o;
/* 282 */       return Objects.equals(this.raw, unicode.raw);
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 287 */       return this.raw.hashCode();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\object\reaction\ReactionEmoji.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */