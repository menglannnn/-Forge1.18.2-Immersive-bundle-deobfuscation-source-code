/*    */ package discord4j.core.object.audit;
/*    */ 
/*    */ import java.util.Optional;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AuditLogChange<T>
/*    */ {
/*    */   private final T oldValue;
/*    */   private final T currentValue;
/*    */   
/*    */   public AuditLogChange(@Nullable T oldValue, @Nullable T currentValue) {
/* 29 */     this.oldValue = oldValue;
/* 30 */     this.currentValue = currentValue;
/*    */   }
/*    */   
/*    */   public Optional<T> getOldValue() {
/* 34 */     return Optional.ofNullable(this.oldValue);
/*    */   }
/*    */   
/*    */   public Optional<T> getCurrentValue() {
/* 38 */     return Optional.ofNullable(this.currentValue);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 43 */     return "AuditLogChange{oldValue=" + this.oldValue + ", currentValue=" + this.currentValue + '}';
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\object\audit\AuditLogChange.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */