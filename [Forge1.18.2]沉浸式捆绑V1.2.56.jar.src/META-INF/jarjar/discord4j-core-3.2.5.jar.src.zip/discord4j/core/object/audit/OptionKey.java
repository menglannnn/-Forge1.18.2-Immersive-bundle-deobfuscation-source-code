/*    */ package discord4j.core.object.audit;
/*    */ 
/*    */ import discord4j.common.util.Snowflake;
/*    */ import java.util.function.Function;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OptionKey<T>
/*    */ {
/* 33 */   public static final OptionKey<Integer> DELETE_MEMBER_DAYS = optionKey("delete_member_days", Integer::parseInt);
/*    */   
/* 35 */   public static final OptionKey<Integer> MEMBERS_REMOVED = optionKey("members_removed", Integer::parseInt);
/*    */   
/* 37 */   public static final OptionKey<Snowflake> CHANNEL_ID = optionKey("channel_id", Snowflake::of);
/*    */   
/* 39 */   public static final OptionKey<Snowflake> MESSAGE_ID = optionKey("message_id", Snowflake::of);
/*    */   
/* 41 */   public static final OptionKey<Integer> COUNT = optionKey("count", Integer::parseInt);
/*    */   
/* 43 */   public static final OptionKey<Snowflake> ID = optionKey("id", Snowflake::of);
/*    */   
/* 45 */   public static final OptionKey<String> TYPE = optionKey("type", Function.identity());
/*    */   
/* 47 */   public static final OptionKey<String> ROLE_NAME = optionKey("role_name", Function.identity());
/*    */   
/*    */   private static <T> OptionKey<T> optionKey(String field, Function<String, T> parser) {
/* 50 */     return new OptionKey<>(field, parser);
/*    */   }
/*    */   
/*    */   private final String field;
/*    */   private final Function<String, T> parser;
/*    */   
/*    */   private OptionKey(String field, Function<String, T> parser) {
/* 57 */     this.field = field;
/* 58 */     this.parser = parser;
/*    */   }
/*    */   
/*    */   public String getField() {
/* 62 */     return this.field;
/*    */   }
/*    */   
/*    */   public T parseValue(String value) {
/* 66 */     return this.parser.apply(value);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 71 */     return "OptionKey{field='" + this.field + '\'' + '}';
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\object\audit\OptionKey.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */