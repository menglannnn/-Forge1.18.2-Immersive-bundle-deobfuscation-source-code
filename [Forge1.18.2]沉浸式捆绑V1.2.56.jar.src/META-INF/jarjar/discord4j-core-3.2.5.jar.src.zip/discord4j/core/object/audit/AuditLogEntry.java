/*     */ package discord4j.core.object.audit;
/*     */ 
/*     */ import com.fasterxml.jackson.databind.JsonNode;
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.GatewayDiscordClient;
/*     */ import discord4j.core.object.entity.Entity;
/*     */ import discord4j.core.object.entity.User;
/*     */ import discord4j.core.util.AuditLogUtil;
/*     */ import discord4j.discordjson.json.AuditLogChangeData;
/*     */ import discord4j.discordjson.json.AuditLogEntryData;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.Optional;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AuditLogEntry
/*     */   implements Entity
/*     */ {
/*     */   public static final int MAX_REASON_LENGTH = 512;
/*     */   private final GatewayDiscordClient gateway;
/*     */   private final AuditLogPart auditLogPart;
/*     */   private final AuditLogEntryData data;
/*     */   
/*     */   AuditLogEntry(GatewayDiscordClient gateway, AuditLogPart auditLogPart, AuditLogEntryData data) {
/*  62 */     this.gateway = gateway;
/*  63 */     this.auditLogPart = auditLogPart;
/*  64 */     this.data = data;
/*     */   }
/*     */   
/*     */   public AuditLogEntry(GatewayDiscordClient gateway, AuditLogEntryData data) {
/*  68 */     this.gateway = gateway;
/*  69 */     this.auditLogPart = null;
/*  70 */     this.data = data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AuditLogEntryData getData() {
/*  79 */     return this.data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<Snowflake> getTargetId() {
/*  88 */     return this.data.targetId()
/*  89 */       .filter(it -> !it.equals("0"))
/*  90 */       .map(Snowflake::of);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<Snowflake> getResponsibleUserId() {
/*  99 */     return this.data.userId().map(Snowflake::of);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<User> getResponsibleUser() {
/* 110 */     if (this.auditLogPart == null) {
/* 111 */       throw new NoSuchElementException("User is not available for audit log entries created by gateway events");
/*     */     }
/* 113 */     return getResponsibleUserId()
/* 114 */       .map(id -> (User)this.auditLogPart.getUserById(id).<Throwable>orElseThrow(()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<String> getReason() {
/* 124 */     return this.data.reason().toOptional();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ActionType getActionType() {
/* 133 */     return ActionType.of(this.data.actionType());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> Optional<AuditLogChange<T>> getChange(ChangeKey<T> changeKey) {
/* 144 */     return this.data.changes().toOptional()
/* 145 */       .map(list -> (Map)list.stream().collect(AuditLogUtil.changeCollector()))
/* 146 */       .flatMap(map -> Optional.ofNullable((AuditLogChangeData)map.get(changeKey.getName())))
/* 147 */       .map(changeData -> {
/*     */           T oldValue = changeData.oldValue().toOptional().map(()).orElse(null);
/*     */           T newValue = changeData.newValue().toOptional().map(()).orElse(null);
/*     */           return new AuditLogChange<>(oldValue, newValue);
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> Optional<T> getOption(OptionKey<T> optionKey) {
/* 169 */     return this.data.options().toOptional()
/* 170 */       .map(AuditLogUtil::createOptionMap)
/* 171 */       .map(map -> optionKey.parseValue((String)map.get(optionKey.getField())));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public AuditLogPart getParent() {
/* 182 */     return this.auditLogPart;
/*     */   }
/*     */ 
/*     */   
/*     */   public Snowflake getId() {
/* 187 */     return Snowflake.of(this.data.id());
/*     */   }
/*     */ 
/*     */   
/*     */   public GatewayDiscordClient getClient() {
/* 192 */     return this.gateway;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 197 */     return "AuditLogEntry{data=" + this.data + '}';
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\object\audit\AuditLogEntry.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */