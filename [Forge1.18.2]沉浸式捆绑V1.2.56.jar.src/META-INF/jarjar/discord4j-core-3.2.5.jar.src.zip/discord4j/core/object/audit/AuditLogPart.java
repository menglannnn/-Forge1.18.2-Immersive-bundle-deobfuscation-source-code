/*     */ package discord4j.core.object.audit;
/*     */ 
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.GatewayDiscordClient;
/*     */ import discord4j.core.object.automod.AutoModRule;
/*     */ import discord4j.core.object.entity.User;
/*     */ import discord4j.core.object.entity.Webhook;
/*     */ import discord4j.discordjson.json.AuditLogData;
/*     */ import discord4j.discordjson.json.AuditLogEntryData;
/*     */ import discord4j.discordjson.json.AutoModRuleData;
/*     */ import discord4j.discordjson.json.UserData;
/*     */ import discord4j.discordjson.json.WebhookData;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Optional;
/*     */ import java.util.Set;
/*     */ import java.util.stream.Collectors;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AuditLogPart
/*     */ {
/*     */   private final long guildId;
/*     */   private final List<AutoModRule> autoModRules;
/*     */   private final Set<Webhook> webhooks;
/*     */   private final Set<User> users;
/*     */   private final List<AuditLogEntry> entries;
/*     */   
/*     */   public AuditLogPart(long guildId, GatewayDiscordClient gateway, AuditLogData data) {
/*  46 */     this.guildId = guildId;
/*     */     
/*  48 */     this
/*     */       
/*  50 */       .autoModRules = (List<AutoModRule>)data.autoModerationRules().stream().map(autoModRuleData -> new AutoModRule(gateway, autoModRuleData)).collect(Collectors.toList());
/*     */     
/*  52 */     this
/*     */       
/*  54 */       .webhooks = (Set<Webhook>)data.webhooks().stream().map(webhookData -> new Webhook(gateway, webhookData)).collect(Collectors.toSet());
/*     */     
/*  56 */     this
/*     */       
/*  58 */       .users = (Set<User>)data.users().stream().map(userData -> new User(gateway, userData)).collect(Collectors.toSet());
/*     */     
/*  60 */     this
/*     */       
/*  62 */       .entries = (List<AuditLogEntry>)data.auditLogEntries().stream().map(auditLogEntryData -> new AuditLogEntry(gateway, this, auditLogEntryData)).collect(Collectors.toList());
/*     */   }
/*     */   
/*     */   private AuditLogPart(long guildId, List<AutoModRule> autoModRules, Set<Webhook> webhooks, Set<User> users, List<AuditLogEntry> entries) {
/*  66 */     this.guildId = guildId;
/*  67 */     this.autoModRules = autoModRules;
/*  68 */     this.webhooks = webhooks;
/*  69 */     this.users = users;
/*  70 */     this.entries = entries;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<AutoModRule> getAutoModRules() {
/*  79 */     return this.autoModRules;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<Webhook> getWebhooks() {
/*  88 */     return this.webhooks;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<User> getUsers() {
/*  97 */     return this.users;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<AuditLogEntry> getEntries() {
/* 106 */     return this.entries;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<Webhook> getWebhookById(Snowflake webhookId) {
/* 116 */     return this.webhooks.stream()
/* 117 */       .filter(webhook -> webhook.getId().equals(webhookId))
/* 118 */       .findFirst();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<User> getUserById(Snowflake userId) {
/* 128 */     return this.users.stream()
/* 129 */       .filter(user -> user.getId().equals(userId))
/* 130 */       .findFirst();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Snowflake getGuildId() {
/* 139 */     return Snowflake.of(this.guildId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AuditLogPart combine(AuditLogPart other) {
/* 149 */     if (other.guildId != this.guildId) {
/* 150 */       throw new IllegalArgumentException("Cannot combine audit log parts from two different guilds.");
/*     */     }
/*     */     
/* 153 */     Set<Webhook> combinedWebhooks = new HashSet<>(this.webhooks.size() + other.webhooks.size());
/* 154 */     combinedWebhooks.addAll(this.webhooks);
/* 155 */     combinedWebhooks.addAll(other.webhooks);
/*     */     
/* 157 */     Set<User> combinedUsers = new HashSet<>(this.users.size() + other.users.size());
/* 158 */     combinedUsers.addAll(this.users);
/* 159 */     combinedUsers.addAll(other.users);
/*     */     
/* 161 */     List<AuditLogEntry> combinedEntries = new ArrayList<>(this.entries.size() + other.entries.size());
/* 162 */     combinedEntries.addAll(this.entries);
/* 163 */     combinedEntries.addAll(other.entries);
/*     */     
/* 165 */     List<AutoModRule> combinedAutoModRules = new ArrayList<>(this.autoModRules.size() + other.autoModRules.size());
/* 166 */     combinedAutoModRules.addAll(this.autoModRules);
/* 167 */     combinedAutoModRules.addAll(other.autoModRules);
/*     */     
/* 169 */     return new AuditLogPart(this.guildId, combinedAutoModRules, combinedWebhooks, combinedUsers, combinedEntries);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\object\audit\AuditLogPart.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */