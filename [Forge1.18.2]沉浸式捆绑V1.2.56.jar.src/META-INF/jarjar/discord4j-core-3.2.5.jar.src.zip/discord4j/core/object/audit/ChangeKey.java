/*     */ package discord4j.core.object.audit;
/*     */ 
/*     */ import com.fasterxml.jackson.databind.JsonNode;
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.object.ExtendedPermissionOverwrite;
/*     */ import discord4j.core.object.entity.Guild;
/*     */ import discord4j.core.object.entity.Sticker;
/*     */ import discord4j.core.object.entity.channel.Channel;
/*     */ import discord4j.rest.util.Color;
/*     */ import discord4j.rest.util.PermissionSet;
/*     */ import java.time.Instant;
/*     */ import java.util.Set;
/*     */ import java.util.function.BiFunction;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ChangeKey<T>
/*     */ {
/*  44 */   public static final ChangeKey<String> NAME = changeKey("name", AuditLogChangeParser.STRING_PARSER);
/*     */   
/*  46 */   public static final ChangeKey<String> DESCRIPTION = changeKey("description", AuditLogChangeParser.STRING_PARSER);
/*     */   
/*  48 */   public static final ChangeKey<String> ICON = changeKey("icon_hash", AuditLogChangeParser.STRING_PARSER);
/*     */   
/*  50 */   public static final ChangeKey<String> SPLASH = changeKey("splash_hash", AuditLogChangeParser.STRING_PARSER);
/*     */   
/*  52 */   public static final ChangeKey<String> DISCOVERY_SPLASH = changeKey("discovery_splash_hash", AuditLogChangeParser.STRING_PARSER);
/*     */   
/*  54 */   public static final ChangeKey<String> BANNER = changeKey("banner_hash", AuditLogChangeParser.STRING_PARSER);
/*     */   
/*  56 */   public static final ChangeKey<Snowflake> OWNER = changeKey("owner_id", AuditLogChangeParser.SNOWFLAKE_PARSER);
/*     */   
/*  58 */   public static final ChangeKey<String> REGION = changeKey("region", AuditLogChangeParser.STRING_PARSER);
/*     */   
/*  60 */   public static final ChangeKey<String> PREFERRED_LOCALE = changeKey("preferred_locale", AuditLogChangeParser.STRING_PARSER);
/*     */   
/*  62 */   public static final ChangeKey<Snowflake> AFK_CHANNEL = changeKey("afk_channel_id", AuditLogChangeParser.SNOWFLAKE_PARSER);
/*     */   
/*  64 */   public static final ChangeKey<Integer> AFK_TIMEOUT = changeKey("afk_timeout", AuditLogChangeParser.INTEGER_PARSER);
/*     */   
/*  66 */   public static final ChangeKey<Snowflake> RULES_CHANNEL = changeKey("rules_channel_id", AuditLogChangeParser.SNOWFLAKE_PARSER);
/*     */   
/*  68 */   public static final ChangeKey<Snowflake> PUBLIC_UPDATES_CHANNEL = changeKey("public_updates_channel_id", AuditLogChangeParser.SNOWFLAKE_PARSER);
/*     */   
/*  70 */   public static final ChangeKey<Guild.MfaLevel> MFA_LEVEL = changeKey("mfa_level", AuditLogChangeParser.INTEGER_PARSER.andThen(Guild.MfaLevel::of));
/*     */   
/*  72 */   public static final ChangeKey<Guild.VerificationLevel> VERIFICATION_LEVEL = changeKey("verification_level", AuditLogChangeParser.INTEGER_PARSER.andThen(Guild.VerificationLevel::of));
/*     */   
/*  74 */   public static final ChangeKey<Guild.ContentFilterLevel> CONTENT_FILTER_LEVEL = changeKey("explicit_content_filter", AuditLogChangeParser.INTEGER_PARSER.andThen(Guild.ContentFilterLevel::of));
/*     */   
/*  76 */   public static final ChangeKey<Guild.NotificationLevel> NOTIFICATION_LEVEL = changeKey("default_message_notifications", AuditLogChangeParser.INTEGER_PARSER.andThen(Guild.NotificationLevel::of));
/*     */   
/*  78 */   public static final ChangeKey<String> VANITY_URL = changeKey("vanity_url_code", AuditLogChangeParser.STRING_PARSER);
/*     */   
/*  80 */   public static final ChangeKey<Set<AuditLogRole>> ROLES_ADD = changeKey("$add", AuditLogChangeParser.AUDIT_LOG_ROLES_PARSER);
/*     */   
/*  82 */   public static final ChangeKey<Set<AuditLogRole>> ROLES_REMOVE = changeKey("$remove", AuditLogChangeParser.AUDIT_LOG_ROLES_PARSER);
/*     */   
/*  84 */   public static final ChangeKey<Integer> PRUNE_DAYS = changeKey("prune_delete_days", AuditLogChangeParser.INTEGER_PARSER);
/*     */   
/*  86 */   public static final ChangeKey<Boolean> WIDGET_ENABLED = changeKey("widget_enabled", AuditLogChangeParser.BOOLEAN_PARSER);
/*     */   
/*  88 */   public static final ChangeKey<Snowflake> WIDGET_CHANNEL = changeKey("widget_channel_id", AuditLogChangeParser.SNOWFLAKE_PARSER);
/*     */   
/*  90 */   public static final ChangeKey<Snowflake> SYSTEM_CHANNEL = changeKey("system_channel_id", AuditLogChangeParser.SNOWFLAKE_PARSER);
/*     */   
/*  92 */   public static final ChangeKey<Integer> POSITION = changeKey("position", AuditLogChangeParser.INTEGER_PARSER);
/*     */   
/*  94 */   public static final ChangeKey<String> TOPIC = changeKey("topic", AuditLogChangeParser.STRING_PARSER);
/*     */   
/*  96 */   public static final ChangeKey<Integer> BITRATE = changeKey("bitrate", AuditLogChangeParser.INTEGER_PARSER);
/*     */   
/*  98 */   public static final ChangeKey<Set<ExtendedPermissionOverwrite>> OVERWRITES = changeKey("permission_overwrites", AuditLogChangeParser.OVERWRITES_PARSER);
/*     */   
/* 100 */   public static final ChangeKey<Boolean> NSFW = changeKey("nsfw", AuditLogChangeParser.BOOLEAN_PARSER);
/*     */   
/* 102 */   public static final ChangeKey<Snowflake> APPLICATION_ID = changeKey("application_id", AuditLogChangeParser.SNOWFLAKE_PARSER);
/*     */   
/* 104 */   public static final ChangeKey<Integer> RATE_LIMIT_PER_USER = changeKey("rate_limit_per_user", AuditLogChangeParser.INTEGER_PARSER);
/*     */   
/* 106 */   public static final ChangeKey<PermissionSet> PERMISSIONS = changeKey("permissions", AuditLogChangeParser.PERMISSION_SET_PARSER);
/*     */   
/* 108 */   public static final ChangeKey<Color> COLOR = changeKey("color", AuditLogChangeParser.INTEGER_PARSER.andThen(Color::of));
/*     */   
/* 110 */   public static final ChangeKey<Boolean> HOIST = changeKey("hoist", AuditLogChangeParser.BOOLEAN_PARSER);
/*     */   
/* 112 */   public static final ChangeKey<Boolean> MENTIONABLE = changeKey("mentionable", AuditLogChangeParser.BOOLEAN_PARSER);
/*     */   
/* 114 */   public static final ChangeKey<PermissionSet> ALLOW = changeKey("allow", AuditLogChangeParser.PERMISSION_SET_PARSER);
/*     */   
/* 116 */   public static final ChangeKey<PermissionSet> DENY = changeKey("deny", AuditLogChangeParser.PERMISSION_SET_PARSER);
/*     */   
/* 118 */   public static final ChangeKey<String> INVITE_CODE = changeKey("code", AuditLogChangeParser.STRING_PARSER);
/*     */   
/* 120 */   public static final ChangeKey<Snowflake> INVITE_CHANNEL_ID = changeKey("channel_id", AuditLogChangeParser.SNOWFLAKE_PARSER);
/*     */   
/* 122 */   public static final ChangeKey<Snowflake> INVITER_ID = changeKey("inviter_id", AuditLogChangeParser.SNOWFLAKE_PARSER);
/*     */   
/* 124 */   public static final ChangeKey<Integer> INVITE_MAX_USES = changeKey("max_uses", AuditLogChangeParser.INTEGER_PARSER);
/*     */   
/* 126 */   public static final ChangeKey<Integer> INVITE_USES = changeKey("uses", AuditLogChangeParser.INTEGER_PARSER);
/*     */   
/* 128 */   public static final ChangeKey<Integer> INVITE_MAX_AGE = changeKey("max_age", AuditLogChangeParser.INTEGER_PARSER);
/*     */   
/* 130 */   public static final ChangeKey<Boolean> INVITE_TEMPORARY = changeKey("temporary", AuditLogChangeParser.BOOLEAN_PARSER);
/*     */   
/* 132 */   public static final ChangeKey<Boolean> USER_DEAFENED = changeKey("deaf", AuditLogChangeParser.BOOLEAN_PARSER);
/*     */   
/* 134 */   public static final ChangeKey<Boolean> USER_MUTED = changeKey("mute", AuditLogChangeParser.BOOLEAN_PARSER);
/*     */   
/* 136 */   public static final ChangeKey<String> USER_NICK = changeKey("nick", AuditLogChangeParser.STRING_PARSER);
/*     */   
/* 138 */   public static final ChangeKey<String> USER_AVATAR = changeKey("avatar_hash", AuditLogChangeParser.STRING_PARSER);
/*     */   
/* 140 */   public static final ChangeKey<Snowflake> ID = changeKey("id", AuditLogChangeParser.SNOWFLAKE_PARSER);
/*     */   
/* 142 */   public static final ChangeKey<Channel.Type> CHANNEL_TYPE = changeKey("type", AuditLogChangeParser.INTEGER_PARSER
/* 143 */       .andThen(Channel.Type::of));
/*     */   
/* 145 */   public static final ChangeKey<Boolean> ENABLE_EMOTICONS = changeKey("enable_emoticons", AuditLogChangeParser.BOOLEAN_PARSER);
/*     */   
/* 147 */   public static final ChangeKey<Integer> EXPIRE_BEHAVIOR = changeKey("expire_behavior", AuditLogChangeParser.INTEGER_PARSER);
/*     */   
/* 149 */   public static final ChangeKey<Integer> EXPIRE_GRACE_PERIOD = changeKey("expire_grace_period", AuditLogChangeParser.INTEGER_PARSER);
/*     */   
/* 151 */   public static final ChangeKey<Integer> USER_LIMIT = changeKey("user_limit", AuditLogChangeParser.INTEGER_PARSER);
/*     */   
/* 153 */   public static final ChangeKey<Instant> COMMUNICATION_DISABLED_UNTIL = changeKey("communication_disabled_until", AuditLogChangeParser.INSTANT_PARSER);
/*     */   
/* 155 */   public static final ChangeKey<String> ROLE_ICON = changeKey("unicode_emoji", AuditLogChangeParser.STRING_PARSER);
/*     */   
/* 157 */   public static final ChangeKey<String> STICKER_TAGS = changeKey("tags", AuditLogChangeParser.STRING_PARSER);
/*     */   
/* 159 */   public static final ChangeKey<Sticker.Format> STICKER_FORMAT_TYPE = changeKey("format_type", AuditLogChangeParser.INTEGER_PARSER.andThen(Sticker.Format::of));
/*     */   
/* 161 */   public static final ChangeKey<Snowflake> STICKER_GUILD_ID = changeKey("guild_id", AuditLogChangeParser.SNOWFLAKE_PARSER);
/*     */   
/* 163 */   public static final ChangeKey<Boolean> STICKER_AVAILABLE = changeKey("available", AuditLogChangeParser.BOOLEAN_PARSER);
/*     */   
/* 165 */   public static final ChangeKey<Boolean> THREAD_ARCHIVED = changeKey("archived", AuditLogChangeParser.BOOLEAN_PARSER);
/*     */   
/* 167 */   public static final ChangeKey<Integer> THREAD_AUTO_ARCHIVE_DURATION = changeKey("auto_archive_duration", AuditLogChangeParser.INTEGER_PARSER);
/*     */   
/* 169 */   public static final ChangeKey<Boolean> THREAD_LOCKED = changeKey("locked", AuditLogChangeParser.BOOLEAN_PARSER);
/*     */   
/* 171 */   public static final ChangeKey<Integer> ENTITY_TYPE = changeKey("entity_type", AuditLogChangeParser.INTEGER_PARSER);
/*     */   
/* 173 */   public static final ChangeKey<String> LOCATION = changeKey("location", AuditLogChangeParser.STRING_PARSER);
/*     */   
/* 175 */   public static final ChangeKey<Integer> STATUS = changeKey("status", AuditLogChangeParser.INTEGER_PARSER);
/*     */   private final String name;
/*     */   
/*     */   private static <T> ChangeKey<T> changeKey(String name, BiFunction<AuditLogEntry, JsonNode, T> parser) {
/* 179 */     return new ChangeKey<>(name, parser);
/*     */   }
/*     */ 
/*     */   
/*     */   private final BiFunction<AuditLogEntry, JsonNode, T> parser;
/*     */ 
/*     */   
/*     */   private ChangeKey(String name, BiFunction<AuditLogEntry, JsonNode, T> parser) {
/* 187 */     this.name = name;
/* 188 */     this.parser = parser;
/*     */   }
/*     */   
/*     */   public T parseValue(AuditLogEntry entry, JsonNode value) {
/* 192 */     return this.parser.apply(entry, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 201 */     return this.name;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 206 */     return "ChangeKey{name='" + this.name + '\'' + '}';
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\object\audit\ChangeKey.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */