/*     */ package discord4j.core.object.audit;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum ActionType
/*     */ {
/*  26 */   UNKNOWN(-1),
/*  27 */   GUILD_UPDATE(1),
/*  28 */   CHANNEL_CREATE(10),
/*  29 */   CHANNEL_UPDATE(11),
/*  30 */   CHANNEL_DELETE(12),
/*  31 */   CHANNEL_OVERWRITE_CREATE(13),
/*  32 */   CHANNEL_OVERWRITE_UPDATE(14),
/*  33 */   CHANNEL_OVERWRITE_DELETE(15),
/*  34 */   MEMBER_KICK(20),
/*  35 */   MEMBER_PRUNE(21),
/*  36 */   MEMBER_BAN_ADD(22),
/*  37 */   MEMBER_BAN_REMOVE(23),
/*  38 */   MEMBER_UPDATE(24),
/*  39 */   MEMBER_ROLE_UPDATE(25),
/*  40 */   MEMBER_MOVE(26),
/*  41 */   MEMBER_DISCONNECT(27),
/*  42 */   BOT_ADD(28),
/*  43 */   ROLE_CREATE(30),
/*  44 */   ROLE_UPDATE(31),
/*  45 */   ROLE_DELETE(32),
/*  46 */   INVITE_CREATE(40),
/*  47 */   INVITE_UPDATE(41),
/*  48 */   INVITE_DELETE(42),
/*  49 */   WEBHOOK_CREATE(50),
/*  50 */   WEBHOOK_UPDATE(51),
/*  51 */   WEBHOOK_DELETE(52),
/*  52 */   EMOJI_CREATE(60),
/*  53 */   EMOJI_UPDATE(61),
/*  54 */   EMOJI_DELETE(62),
/*  55 */   MESSAGE_DELETE(72),
/*  56 */   MESSAGE_BULK_DELETE(73),
/*  57 */   MESSAGE_PIN(74),
/*  58 */   MESSAGE_UNPIN(75),
/*  59 */   INTEGRATION_CREATE(80),
/*  60 */   INTEGRATION_UPDATE(81),
/*  61 */   INTEGRATION_DELETE(82),
/*  62 */   GUILD_SCHEDULED_EVENT_CREATE(100),
/*  63 */   GUILD_SCHEDULED_EVENT_UPDATE(101),
/*  64 */   GUILD_SCHEDULED_EVENT_DELETE(102),
/*  65 */   AUTO_MODERATION_RULE_CREATE(140),
/*  66 */   AUTO_MODERATION_RULE_UPDATE(141),
/*  67 */   AUTO_MODERATION_RULE_DELETE(142),
/*  68 */   AUTO_MODERATION_BLOCK_MESSAGE(143),
/*  69 */   AUTO_MODERATION_FLAG_TO_CHANNEL(144),
/*  70 */   AUTO_MODERATION_USER_COMMUNICATION_DISABLED(145);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final int value;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ActionType of(int value) {
/*  81 */     switch (value) { case 1:
/*  82 */         return GUILD_UPDATE;
/*  83 */       case 10: return CHANNEL_CREATE;
/*  84 */       case 11: return CHANNEL_UPDATE;
/*  85 */       case 12: return CHANNEL_DELETE;
/*  86 */       case 13: return CHANNEL_OVERWRITE_CREATE;
/*  87 */       case 14: return CHANNEL_OVERWRITE_UPDATE;
/*  88 */       case 15: return CHANNEL_OVERWRITE_DELETE;
/*  89 */       case 20: return MEMBER_KICK;
/*  90 */       case 21: return MEMBER_PRUNE;
/*  91 */       case 22: return MEMBER_BAN_ADD;
/*  92 */       case 23: return MEMBER_BAN_REMOVE;
/*  93 */       case 24: return MEMBER_UPDATE;
/*  94 */       case 25: return MEMBER_ROLE_UPDATE;
/*  95 */       case 26: return MEMBER_MOVE;
/*  96 */       case 27: return MEMBER_DISCONNECT;
/*  97 */       case 28: return BOT_ADD;
/*  98 */       case 30: return ROLE_CREATE;
/*  99 */       case 31: return ROLE_UPDATE;
/* 100 */       case 32: return ROLE_DELETE;
/* 101 */       case 40: return INVITE_CREATE;
/* 102 */       case 41: return INVITE_UPDATE;
/* 103 */       case 42: return INVITE_DELETE;
/* 104 */       case 50: return WEBHOOK_CREATE;
/* 105 */       case 51: return WEBHOOK_UPDATE;
/* 106 */       case 52: return WEBHOOK_DELETE;
/* 107 */       case 60: return EMOJI_CREATE;
/* 108 */       case 61: return EMOJI_UPDATE;
/* 109 */       case 62: return EMOJI_DELETE;
/* 110 */       case 72: return MESSAGE_DELETE;
/* 111 */       case 73: return MESSAGE_BULK_DELETE;
/* 112 */       case 74: return MESSAGE_PIN;
/* 113 */       case 75: return MESSAGE_UNPIN;
/* 114 */       case 80: return INTEGRATION_CREATE;
/* 115 */       case 81: return INTEGRATION_UPDATE;
/* 116 */       case 82: return INTEGRATION_DELETE;
/* 117 */       case 100: return GUILD_SCHEDULED_EVENT_CREATE;
/* 118 */       case 101: return GUILD_SCHEDULED_EVENT_UPDATE;
/* 119 */       case 102: return GUILD_SCHEDULED_EVENT_DELETE;
/* 120 */       case 140: return AUTO_MODERATION_RULE_CREATE;
/* 121 */       case 141: return AUTO_MODERATION_RULE_UPDATE;
/* 122 */       case 142: return AUTO_MODERATION_RULE_DELETE;
/* 123 */       case 143: return AUTO_MODERATION_BLOCK_MESSAGE;
/* 124 */       case 144: return AUTO_MODERATION_FLAG_TO_CHANNEL;
/* 125 */       case 145: return AUTO_MODERATION_USER_COMMUNICATION_DISABLED; }
/* 126 */      return UNKNOWN;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ActionType(int value) {
/* 139 */     this.value = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getValue() {
/* 148 */     return this.value;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\object\audit\ActionType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */