/*    */ package discord4j.core.object.audit;
/*    */ 
/*    */ import discord4j.common.util.Snowflake;
/*    */ import discord4j.discordjson.json.AuditLogPartialRoleData;
/*    */ import java.util.Objects;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class AuditLogRole
/*    */ {
/*    */   private final AuditLogPartialRoleData data;
/*    */   
/*    */   public AuditLogRole(AuditLogPartialRoleData data) {
/* 33 */     this.data = data;
/*    */   }
/*    */   
/*    */   public Snowflake getId() {
/* 37 */     return Snowflake.of(this.data.id());
/*    */   }
/*    */   
/*    */   public String getName() {
/* 41 */     return this.data.name();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object o) {
/* 46 */     if (this == o) {
/* 47 */       return true;
/*    */     }
/* 49 */     if (o == null || getClass() != o.getClass()) {
/* 50 */       return false;
/*    */     }
/* 52 */     AuditLogRole that = (AuditLogRole)o;
/* 53 */     return Objects.equals(this.data, that.data);
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 58 */     return Objects.hash(new Object[] { this.data });
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 63 */     return "AuditLogRole{data=" + this.data + '}';
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\object\audit\AuditLogRole.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */