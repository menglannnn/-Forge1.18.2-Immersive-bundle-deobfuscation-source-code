/*    */ package discord4j.core.object.audit;
/*    */ 
/*    */ import com.fasterxml.jackson.databind.JsonNode;
/*    */ import com.fasterxml.jackson.databind.ObjectMapper;
/*    */ import discord4j.common.util.Snowflake;
/*    */ import discord4j.core.GatewayDiscordClient;
/*    */ import discord4j.core.object.ExtendedPermissionOverwrite;
/*    */ import discord4j.discordjson.json.AuditLogPartialRoleData;
/*    */ import discord4j.discordjson.json.OverwriteData;
/*    */ import discord4j.rest.util.PermissionSet;
/*    */ import java.io.IOException;
/*    */ import java.time.Instant;
/*    */ import java.time.format.DateTimeFormatter;
/*    */ import java.util.List;
/*    */ import java.util.NoSuchElementException;
/*    */ import java.util.Set;
/*    */ import java.util.function.BiFunction;
/*    */ import java.util.function.Function;
/*    */ import java.util.stream.Collectors;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ interface AuditLogChangeParser<T>
/*    */   extends BiFunction<AuditLogEntry, JsonNode, T>
/*    */ {
/*    */   public static final AuditLogChangeParser<String> STRING_PARSER;
/*    */   public static final AuditLogChangeParser<Integer> INTEGER_PARSER;
/*    */   public static final AuditLogChangeParser<Boolean> BOOLEAN_PARSER;
/*    */   public static final AuditLogChangeParser<Snowflake> SNOWFLAKE_PARSER;
/*    */   public static final AuditLogChangeParser<PermissionSet> PERMISSION_SET_PARSER;
/*    */   public static final AuditLogChangeParser<Instant> INSTANT_PARSER;
/*    */   public static final AuditLogChangeParser<Set<AuditLogRole>> AUDIT_LOG_ROLES_PARSER;
/*    */   public static final AuditLogChangeParser<Set<ExtendedPermissionOverwrite>> OVERWRITES_PARSER;
/*    */   
/*    */   static {
/* 45 */     STRING_PARSER = ((entry, node) -> node.asText());
/*    */     
/* 47 */     INTEGER_PARSER = ((entry, node) -> Integer.valueOf(node.asInt()));
/*    */     
/* 49 */     BOOLEAN_PARSER = ((entry, node) -> Boolean.valueOf(node.asBoolean()));
/*    */     
/* 51 */     SNOWFLAKE_PARSER = ((entry, node) -> Snowflake.of(node.asText()));
/*    */     
/* 53 */     PERMISSION_SET_PARSER = ((entry, node) -> PermissionSet.of(node.asText()));
/*    */     
/* 55 */     INSTANT_PARSER = ((entry, node) -> (Instant)DateTimeFormatter.ISO_OFFSET_DATE_TIME.<Instant>parse(node.asText(), Instant::from));
/*    */     
/* 57 */     AUDIT_LOG_ROLES_PARSER = ((entry, node) -> {
/*    */         try {
/*    */           ObjectMapper mapper = entry.getClient().getCoreResources().getJacksonResources().getObjectMapper();
/*    */ 
/*    */           
/*    */           List<AuditLogPartialRoleData> roles = (List<AuditLogPartialRoleData>)mapper.readerForListOf(AuditLogPartialRoleData.class).readValue(node);
/*    */           
/*    */           return (Set)roles.stream().map(AuditLogRole::new).collect(Collectors.toSet());
/* 65 */         } catch (IOException e) {
/*    */           throw new RuntimeException("Could not parse audit log roles");
/*    */         } 
/*    */       });
/*    */     
/* 70 */     OVERWRITES_PARSER = ((entry, node) -> {
/*    */         try {
/*    */           GatewayDiscordClient client = entry.getClient();
/*    */ 
/*    */           
/*    */           ObjectMapper mapper = client.getCoreResources().getJacksonResources().getObjectMapper();
/*    */           
/*    */           List<OverwriteData> overwrites = (List<OverwriteData>)mapper.readerForListOf(OverwriteData.class).readValue(node);
/*    */           
/*    */           long guildId = entry.getParent().getGuildId().asLong();
/*    */           
/*    */           long channelId = ((Snowflake)entry.getTargetId().<Throwable>orElseThrow(())).asLong();
/*    */           
/*    */           return (Set)overwrites.stream().map(()).collect(Collectors.toSet());
/* 84 */         } catch (IOException e) {
/*    */           throw new RuntimeException("Could not parse audit log overwrite data");
/*    */         } 
/*    */       });
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\object\audit\AuditLogChangeParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */