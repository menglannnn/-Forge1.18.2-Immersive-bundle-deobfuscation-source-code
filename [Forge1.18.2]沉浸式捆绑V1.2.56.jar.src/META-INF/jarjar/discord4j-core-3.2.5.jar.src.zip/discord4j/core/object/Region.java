/*     */ package discord4j.core.object;
/*     */ 
/*     */ import discord4j.core.GatewayDiscordClient;
/*     */ import discord4j.discordjson.json.RegionData;
/*     */ import java.util.Objects;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Region
/*     */   implements DiscordObject
/*     */ {
/*     */   private final GatewayDiscordClient gateway;
/*     */   private final RegionData data;
/*     */   
/*     */   public Region(GatewayDiscordClient gateway, RegionData data) {
/*  45 */     this.gateway = Objects.<GatewayDiscordClient>requireNonNull(gateway);
/*  46 */     this.data = Objects.<RegionData>requireNonNull(data);
/*     */   }
/*     */ 
/*     */   
/*     */   public GatewayDiscordClient getClient() {
/*  51 */     return this.gateway;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RegionData getData() {
/*  60 */     return this.data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getId() {
/*  69 */     return this.data.id();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/*  78 */     return this.data.name();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isVip() {
/*  88 */     return ((Boolean)this.data.vip().toOptional().orElse(Boolean.valueOf(false))).booleanValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isOptimal() {
/*  97 */     return this.data.optimal();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDeprecated() {
/* 106 */     return this.data.deprecated();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isCustom() {
/* 115 */     return this.data.custom();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 120 */     return "Region{data=" + this.data + '}';
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum Id
/*     */   {
/* 128 */     UNKNOWN(null),
/*     */     
/* 130 */     AUTOMATIC(null),
/*     */     
/* 132 */     US_WEST("us-west"),
/*     */     
/* 134 */     US_EAST("us-east"),
/*     */     
/* 136 */     US_CENTRAL("us-central"),
/*     */     
/* 138 */     US_SOUTH("us-south"),
/*     */     
/* 140 */     SINGAPORE("singapore"),
/*     */     
/* 142 */     SOUTHAFRICA("southafrica"),
/*     */     
/* 144 */     SYDNEY("sydney"),
/*     */     
/* 146 */     EUROPE("europe"),
/*     */     
/* 148 */     BRAZIL("brazil"),
/*     */     
/* 150 */     HONGKONG("hongkong"),
/*     */     
/* 152 */     RUSSIA("russia"),
/*     */     
/* 154 */     JAPAN("japan"),
/*     */     
/* 156 */     INDIA("india");
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final String value;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Id(String value) {
/* 167 */       this.value = value;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public String getValue() {
/* 177 */       return this.value;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Id of(@Nullable String value) {
/* 188 */       if (value == null) {
/* 189 */         return AUTOMATIC;
/*     */       }
/*     */       
/* 192 */       switch (value) { case "us-west":
/* 193 */           return US_WEST;
/* 194 */         case "us-east": return US_EAST;
/* 195 */         case "us-central": return US_CENTRAL;
/* 196 */         case "us-south": return US_SOUTH;
/* 197 */         case "singapore": return SINGAPORE;
/* 198 */         case "southafrica": return SOUTHAFRICA;
/* 199 */         case "sydney": return SYDNEY;
/* 200 */         case "europe": return EUROPE;
/* 201 */         case "brazil": return BRAZIL;
/* 202 */         case "hongkong": return HONGKONG;
/* 203 */         case "russia": return RUSSIA;
/* 204 */         case "japan": return JAPAN;
/* 205 */         case "india": return INDIA; }
/* 206 */        return UNKNOWN;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\object\Region.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */