/*    */ package discord4j.core.object;
/*    */ 
/*    */ import discord4j.common.util.Snowflake;
/*    */ import discord4j.core.GatewayDiscordClient;
/*    */ import discord4j.discordjson.json.RoleTagsData;
/*    */ import java.util.Objects;
/*    */ import java.util.Optional;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RoleTags
/*    */   implements DiscordObject
/*    */ {
/*    */   private final GatewayDiscordClient gateway;
/*    */   private final RoleTagsData data;
/*    */   
/*    */   public RoleTags(GatewayDiscordClient gateway, RoleTagsData data) {
/* 44 */     this.gateway = Objects.<GatewayDiscordClient>requireNonNull(gateway);
/* 45 */     this.data = Objects.<RoleTagsData>requireNonNull(data);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public RoleTagsData getData() {
/* 54 */     return this.data;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Optional<Snowflake> getBotId() {
/* 63 */     return this.data.botId().toOptional().map(Snowflake::of);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Optional<Snowflake> getIntegrationId() {
/* 72 */     return this.data.integrationId().toOptional().map(Snowflake::of);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isPremiumSubscriberRole() {
/* 81 */     return !this.data.premiumSubscriber().isAbsent();
/*    */   }
/*    */ 
/*    */   
/*    */   public GatewayDiscordClient getClient() {
/* 86 */     return this.gateway;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 91 */     return "RoleTags{data=" + this.data + '}';
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\object\RoleTags.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */