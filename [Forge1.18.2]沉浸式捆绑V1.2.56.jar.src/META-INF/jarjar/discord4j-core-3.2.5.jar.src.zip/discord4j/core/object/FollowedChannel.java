/*     */ package discord4j.core.object;
/*     */ 
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.GatewayDiscordClient;
/*     */ import discord4j.core.object.entity.Webhook;
/*     */ import discord4j.core.object.entity.channel.NewsChannel;
/*     */ import discord4j.core.retriever.EntityRetrievalStrategy;
/*     */ import discord4j.discordjson.json.FollowedChannelData;
/*     */ import java.util.Objects;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FollowedChannel
/*     */   implements DiscordObject
/*     */ {
/*     */   private final GatewayDiscordClient gateway;
/*     */   private final FollowedChannelData data;
/*     */   
/*     */   public FollowedChannel(GatewayDiscordClient gateway, FollowedChannelData data) {
/*  45 */     this.gateway = Objects.<GatewayDiscordClient>requireNonNull(gateway);
/*  46 */     this.data = Objects.<FollowedChannelData>requireNonNull(data);
/*     */   }
/*     */ 
/*     */   
/*     */   public final GatewayDiscordClient getClient() {
/*  51 */     return this.gateway;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FollowedChannelData getData() {
/*  60 */     return this.data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Snowflake getNewsChannelId() {
/*  69 */     return Snowflake.of(this.data.channelId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<NewsChannel> getNewsChannel() {
/*  79 */     return this.gateway.getChannelById(Snowflake.of(this.data.channelId()))
/*  80 */       .cast(NewsChannel.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<NewsChannel> getNewsChannel(EntityRetrievalStrategy retrievalStrategy) {
/*  91 */     return this.gateway.withRetrievalStrategy(retrievalStrategy)
/*  92 */       .getChannelById(Snowflake.of(this.data.channelId()))
/*  93 */       .cast(NewsChannel.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Snowflake getWebhookId() {
/* 102 */     return Snowflake.of(this.data.webhookId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Webhook> getWebhook() {
/* 116 */     return this.gateway.getWebhookById(Snowflake.of(this.data.webhookId()));
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\object\FollowedChannel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */