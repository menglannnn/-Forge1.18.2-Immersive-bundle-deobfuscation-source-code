/*     */ package discord4j.core.object;
/*     */ 
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.GatewayDiscordClient;
/*     */ import discord4j.core.object.entity.Guild;
/*     */ import discord4j.core.object.entity.Role;
/*     */ import discord4j.core.object.entity.User;
/*     */ import discord4j.core.object.entity.channel.GuildChannel;
/*     */ import discord4j.core.retriever.EntityRetrievalStrategy;
/*     */ import discord4j.discordjson.json.OverwriteData;
/*     */ import java.util.Objects;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ExtendedPermissionOverwrite
/*     */   extends PermissionOverwrite
/*     */   implements DiscordObject
/*     */ {
/*     */   private final GatewayDiscordClient gateway;
/*     */   private final long guildId;
/*     */   private final long channelId;
/*     */   
/*     */   public ExtendedPermissionOverwrite(GatewayDiscordClient gateway, OverwriteData data, long guildId, long channelId) {
/*  58 */     super(data.allow(), data.deny(), Snowflake.asLong(data.id()), PermissionOverwrite.Type.of(data.type()));
/*  59 */     this.gateway = Objects.<GatewayDiscordClient>requireNonNull(gateway);
/*  60 */     this.guildId = guildId;
/*  61 */     this.channelId = channelId;
/*     */   }
/*     */ 
/*     */   
/*     */   public GatewayDiscordClient getClient() {
/*  66 */     return this.gateway;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Role> getRole() {
/*  76 */     return Mono.justOrEmpty(getRoleId()).flatMap(id -> this.gateway.getRoleById(getGuildId(), id));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Role> getRole(EntityRetrievalStrategy retrievalStrategy) {
/*  87 */     return Mono.justOrEmpty(getRoleId())
/*  88 */       .flatMap(id -> this.gateway.withRetrievalStrategy(retrievalStrategy).getRoleById(getGuildId(), id));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<User> getUser() {
/*  99 */     Objects.requireNonNull(this.gateway); return Mono.justOrEmpty(getMemberId()).flatMap(this.gateway::getUserById);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<User> getUser(EntityRetrievalStrategy retrievalStrategy) {
/* 110 */     return Mono.justOrEmpty(getMemberId())
/* 111 */       .flatMap(id -> this.gateway.withRetrievalStrategy(retrievalStrategy).getUserById(id));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Snowflake getGuildId() {
/* 120 */     return Snowflake.of(this.guildId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Guild> getGuild() {
/* 130 */     return this.gateway.getGuildById(getGuildId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Guild> getGuild(EntityRetrievalStrategy retrievalStrategy) {
/* 141 */     return this.gateway.withRetrievalStrategy(retrievalStrategy).getGuildById(getGuildId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Snowflake getChannelId() {
/* 150 */     return Snowflake.of(this.channelId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<GuildChannel> getChannel() {
/* 160 */     return this.gateway.getChannelById(getChannelId()).cast(GuildChannel.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<GuildChannel> getChannel(EntityRetrievalStrategy retrievalStrategy) {
/* 171 */     return this.gateway.withRetrievalStrategy(retrievalStrategy)
/* 172 */       .getChannelById(getChannelId())
/* 173 */       .cast(GuildChannel.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Void> delete() {
/* 183 */     return delete((String)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Void> delete(@Nullable String reason) {
/* 194 */     return this.gateway.getRestClient().getChannelService()
/* 195 */       .deleteChannelPermission(this.channelId, getTargetId().asLong(), reason);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\object\ExtendedPermissionOverwrite.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */