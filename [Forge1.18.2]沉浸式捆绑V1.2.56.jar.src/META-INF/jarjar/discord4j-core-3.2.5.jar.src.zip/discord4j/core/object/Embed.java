/*     */ package discord4j.core.object;
/*     */ 
/*     */ import discord4j.core.GatewayDiscordClient;
/*     */ import discord4j.discordjson.json.EmbedAuthorData;
/*     */ import discord4j.discordjson.json.EmbedData;
/*     */ import discord4j.discordjson.json.EmbedFieldData;
/*     */ import discord4j.discordjson.json.EmbedFooterData;
/*     */ import discord4j.discordjson.json.EmbedImageData;
/*     */ import discord4j.discordjson.json.EmbedProviderData;
/*     */ import discord4j.discordjson.json.EmbedThumbnailData;
/*     */ import discord4j.discordjson.json.EmbedVideoData;
/*     */ import discord4j.rest.util.Color;
/*     */ import java.time.Instant;
/*     */ import java.time.format.DateTimeFormatter;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import java.util.function.Supplier;
/*     */ import java.util.stream.Collectors;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Embed
/*     */   implements DiscordObject
/*     */ {
/*     */   public static final int MAX_TITLE_LENGTH = 256;
/*     */   public static final int MAX_DESCRIPTION_LENGTH = 4096;
/*     */   public static final int MAX_FIELDS = 25;
/*     */   @Deprecated
/*     */   public static final int MAX_CHARACTER_LENGTH = 6000;
/*     */   private final GatewayDiscordClient gateway;
/*     */   private final EmbedData data;
/*     */   
/*     */   public Embed(GatewayDiscordClient gateway, EmbedData data) {
/*  71 */     this.gateway = Objects.<GatewayDiscordClient>requireNonNull(gateway);
/*  72 */     this.data = Objects.<EmbedData>requireNonNull(data);
/*     */   }
/*     */ 
/*     */   
/*     */   public GatewayDiscordClient getClient() {
/*  77 */     return this.gateway;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EmbedData getData() {
/*  86 */     return this.data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<String> getTitle() {
/*  95 */     return this.data.title().toOptional();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Type getType() {
/* 104 */     return (Type)this.data.type().toOptional()
/* 105 */       .map(Type::of)
/* 106 */       .orElseThrow(IllegalStateException::new);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<String> getDescription() {
/* 115 */     return this.data.description().toOptional();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<String> getUrl() {
/* 124 */     return this.data.url().toOptional();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<Instant> getTimestamp() {
/* 133 */     return this.data.timestamp().toOptional()
/* 134 */       .map(timestamp -> (Instant)DateTimeFormatter.ISO_OFFSET_DATE_TIME.<Instant>parse(timestamp, Instant::from));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<Color> getColor() {
/* 143 */     return this.data.color().toOptional().map(Color::of);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<Footer> getFooter() {
/* 152 */     return this.data.footer().toOptional().map(x$0 -> new Footer(x$0));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<Image> getImage() {
/* 161 */     return this.data.image().toOptional().map(x$0 -> new Image(x$0));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<Thumbnail> getThumbnail() {
/* 170 */     return this.data.thumbnail().toOptional().map(x$0 -> new Thumbnail(x$0));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<Video> getVideo() {
/* 179 */     return this.data.video().toOptional().map(x$0 -> new Video(x$0));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<Provider> getProvider() {
/* 188 */     return this.data.provider().toOptional().map(x$0 -> new Provider(x$0));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<Author> getAuthor() {
/* 197 */     return this.data.author().toOptional().map(x$0 -> new Author(x$0));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Field> getFields() {
/* 206 */     return this.data.fields().toOptional()
/* 207 */       .map(fields -> (List)fields.stream().map(()).collect(Collectors.toList()))
/* 208 */       .orElse(Collections.emptyList());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public enum Type
/*     */   {
/* 215 */     UNKNOWN("UNKNOWN"),
/*     */ 
/*     */     
/* 218 */     IMAGE("image"),
/*     */ 
/*     */     
/* 221 */     LINK("link"),
/*     */ 
/*     */     
/* 224 */     RICH("rich"),
/*     */ 
/*     */     
/* 227 */     VIDEO("video"),
/*     */ 
/*     */     
/* 230 */     GIFV("gifv"),
/*     */ 
/*     */     
/* 233 */     ARTICLE("article");
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final String value;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Type(String value) {
/* 244 */       this.value = value;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getValue() {
/* 253 */       return this.value;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Type of(String value) {
/* 264 */       switch (value) { case "image":
/* 265 */           return IMAGE;
/* 266 */         case "link": return LINK;
/* 267 */         case "rich": return RICH;
/* 268 */         case "video": return VIDEO;
/* 269 */         case "gifv": return GIFV;
/* 270 */         case "article": return ARTICLE; }
/* 271 */        return UNKNOWN;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final class Footer
/*     */   {
/*     */     public static final int MAX_TEXT_LENGTH = 2048;
/*     */ 
/*     */ 
/*     */     
/*     */     private final EmbedFooterData data;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private Footer(EmbedFooterData data) {
/* 291 */       this.data = Objects.<EmbedFooterData>requireNonNull(data);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Embed getEmbed() {
/* 300 */       return Embed.this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public EmbedFooterData getData() {
/* 309 */       return this.data;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getText() {
/* 318 */       return this.data.text();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Optional<String> getIconUrl() {
/* 327 */       return this.data.iconUrl().toOptional();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Optional<String> getProxyIconUrl() {
/* 336 */       return this.data.proxyIconUrl().toOptional();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final class Image
/*     */   {
/*     */     private final EmbedImageData data;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private Image(EmbedImageData data) {
/* 352 */       this.data = Objects.<EmbedImageData>requireNonNull(data);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Embed getEmbed() {
/* 361 */       return Embed.this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public EmbedImageData getData() {
/* 370 */       return this.data;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getUrl() {
/* 379 */       return (String)this.data.url().toOptional()
/* 380 */         .orElseThrow(IllegalStateException::new);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getProxyUrl() {
/* 389 */       return (String)this.data.proxyUrl().toOptional()
/* 390 */         .orElseThrow(IllegalStateException::new);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int getHeight() {
/* 399 */       return ((Integer)this.data.height().toOptional()
/* 400 */         .orElseThrow(IllegalStateException::new)).intValue();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int getWidth() {
/* 409 */       return ((Integer)this.data.width().toOptional()
/* 410 */         .orElseThrow(IllegalStateException::new)).intValue();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final class Thumbnail
/*     */   {
/*     */     private final EmbedThumbnailData data;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private Thumbnail(EmbedThumbnailData data) {
/* 426 */       this.data = Objects.<EmbedThumbnailData>requireNonNull(data);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Embed getEmbed() {
/* 435 */       return Embed.this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public EmbedThumbnailData getData() {
/* 444 */       return this.data;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getUrl() {
/* 453 */       return (String)this.data.url().toOptional()
/* 454 */         .orElseThrow(IllegalStateException::new);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getProxyUrl() {
/* 463 */       return (String)this.data.proxyUrl().toOptional()
/* 464 */         .orElseThrow(IllegalStateException::new);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int getHeight() {
/* 473 */       return ((Integer)this.data.height().toOptional()
/* 474 */         .orElseThrow(IllegalStateException::new)).intValue();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int getWidth() {
/* 483 */       return ((Integer)this.data.width().toOptional()
/* 484 */         .orElseThrow(IllegalStateException::new)).intValue();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final class Video
/*     */   {
/*     */     private final EmbedVideoData data;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private Video(EmbedVideoData data) {
/* 500 */       this.data = Objects.<EmbedVideoData>requireNonNull(data);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Embed getEmbed() {
/* 509 */       return Embed.this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public EmbedVideoData getData() {
/* 518 */       return this.data;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getUrl() {
/* 527 */       return (String)this.data.url().toOptional()
/* 528 */         .orElseThrow(IllegalStateException::new);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public String getProxyUrl() {
/* 538 */       return this.data.proxyUrl().toOptional().orElse(null);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int getHeight() {
/* 547 */       return ((Integer)this.data.height().toOptional()
/* 548 */         .orElseThrow(IllegalStateException::new)).intValue();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int getWidth() {
/* 557 */       return ((Integer)this.data.width().toOptional()
/* 558 */         .orElseThrow(IllegalStateException::new)).intValue();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final class Provider
/*     */   {
/*     */     private final EmbedProviderData data;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private Provider(EmbedProviderData data) {
/* 574 */       this.data = Objects.<EmbedProviderData>requireNonNull(data);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Embed getEmbed() {
/* 583 */       return Embed.this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public EmbedProviderData getData() {
/* 592 */       return this.data;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Optional<String> getName() {
/* 601 */       return this.data.name().toOptional();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Optional<String> getUrl() {
/* 610 */       return this.data.url().toOptional();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final class Author
/*     */   {
/*     */     public static final int MAX_NAME_LENGTH = 256;
/*     */ 
/*     */ 
/*     */     
/*     */     private final EmbedAuthorData data;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private Author(EmbedAuthorData data) {
/* 629 */       this.data = Objects.<EmbedAuthorData>requireNonNull(data);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Embed getEmbed() {
/* 638 */       return Embed.this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public EmbedAuthorData getData() {
/* 647 */       return this.data;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Optional<String> getName() {
/* 656 */       return this.data.name().toOptional();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Optional<String> getUrl() {
/* 665 */       return this.data.url().toOptional();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Optional<String> getIconUrl() {
/* 674 */       return this.data.iconUrl().toOptional();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Optional<String> getProxyIconUrl() {
/* 683 */       return this.data.proxyIconUrl().toOptional();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final class Field
/*     */   {
/*     */     public static final int MAX_NAME_LENGTH = 256;
/*     */ 
/*     */ 
/*     */     
/*     */     public static final int MAX_VALUE_LENGTH = 1024;
/*     */ 
/*     */ 
/*     */     
/*     */     private final EmbedFieldData data;
/*     */ 
/*     */ 
/*     */     
/*     */     private Field(EmbedFieldData data) {
/* 705 */       this.data = Objects.<EmbedFieldData>requireNonNull(data);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Embed getEmbed() {
/* 714 */       return Embed.this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public EmbedFieldData getData() {
/* 723 */       return this.data;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getName() {
/* 732 */       return this.data.name();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getValue() {
/* 741 */       return this.data.value();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isInline() {
/* 750 */       return ((Boolean)this.data.inline().toOptional()
/* 751 */         .orElseThrow(IllegalStateException::new)).booleanValue();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 757 */     return "Embed{data=" + this.data + '}';
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\object\Embed.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */