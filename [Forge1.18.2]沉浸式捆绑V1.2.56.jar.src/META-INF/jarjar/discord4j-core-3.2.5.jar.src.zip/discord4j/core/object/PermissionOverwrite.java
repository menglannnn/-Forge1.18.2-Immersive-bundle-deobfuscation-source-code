/*     */ package discord4j.core.object;
/*     */ 
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.discordjson.json.OverwriteData;
/*     */ import discord4j.rest.util.PermissionSet;
/*     */ import java.util.Optional;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PermissionOverwrite
/*     */ {
/*     */   private final long allowed;
/*     */   private final long denied;
/*     */   private final long targetId;
/*     */   private final Type type;
/*     */   
/*     */   public static PermissionOverwrite forMember(Snowflake memberId, PermissionSet allowed, PermissionSet denied) {
/*  38 */     return new PermissionOverwrite(allowed.getRawValue(), denied.getRawValue(), memberId.asLong(), Type.MEMBER);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static PermissionOverwrite forRole(Snowflake roleId, PermissionSet allowed, PermissionSet denied) {
/*  50 */     return new PermissionOverwrite(allowed.getRawValue(), denied.getRawValue(), roleId.asLong(), Type.ROLE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   PermissionOverwrite(long allowed, long denied, long targetId, Type type) {
/*  59 */     this.allowed = allowed;
/*  60 */     this.denied = denied;
/*  61 */     this.targetId = targetId;
/*  62 */     this.type = type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OverwriteData getData() {
/*  71 */     return (OverwriteData)OverwriteData.builder()
/*  72 */       .id(this.targetId)
/*  73 */       .type(this.type.getValue())
/*  74 */       .allow(this.allowed)
/*  75 */       .deny(this.denied)
/*  76 */       .build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PermissionSet getAllowed() {
/*  84 */     return PermissionSet.of(this.allowed);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PermissionSet getDenied() {
/*  92 */     return PermissionSet.of(this.denied);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Snowflake getTargetId() {
/* 103 */     return Snowflake.of(this.targetId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<Snowflake> getRoleId() {
/* 111 */     return (this.type == Type.ROLE) ? Optional.<Snowflake>of(getTargetId()) : Optional.<Snowflake>empty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<Snowflake> getMemberId() {
/* 119 */     return (this.type == Type.MEMBER) ? Optional.<Snowflake>of(getTargetId()) : Optional.<Snowflake>empty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Type getType() {
/* 127 */     return this.type;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public enum Type
/*     */   {
/* 134 */     UNKNOWN(-1),
/*     */ 
/*     */     
/* 137 */     ROLE(0),
/*     */ 
/*     */     
/* 140 */     MEMBER(1);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final int value;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Type(int value) {
/* 151 */       this.value = value;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int getValue() {
/* 160 */       return this.value;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Type of(int value) {
/* 171 */       switch (value) { case 0:
/* 172 */           return ROLE;
/* 173 */         case 1: return MEMBER; }
/* 174 */        return UNKNOWN;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 181 */     return "PermissionOverwrite{allowed=" + this.allowed + ", denied=" + this.denied + ", targetId=" + this.targetId + ", type=" + this.type + '}';
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\object\PermissionOverwrite.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */