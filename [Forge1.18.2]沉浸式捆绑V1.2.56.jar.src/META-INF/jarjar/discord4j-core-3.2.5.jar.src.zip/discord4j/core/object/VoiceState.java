/*     */ package discord4j.core.object;
/*     */ 
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.GatewayDiscordClient;
/*     */ import discord4j.core.object.entity.Guild;
/*     */ import discord4j.core.object.entity.Member;
/*     */ import discord4j.core.object.entity.User;
/*     */ import discord4j.core.object.entity.channel.VoiceChannel;
/*     */ import discord4j.core.retriever.EntityRetrievalStrategy;
/*     */ import discord4j.discordjson.Id;
/*     */ import discord4j.discordjson.json.VoiceStateData;
/*     */ import java.time.Instant;
/*     */ import java.time.format.DateTimeFormatter;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import java.util.function.Supplier;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class VoiceState
/*     */   implements DiscordObject
/*     */ {
/*     */   private final GatewayDiscordClient gateway;
/*     */   private final VoiceStateData data;
/*     */   
/*     */   public VoiceState(GatewayDiscordClient gateway, VoiceStateData data) {
/*  54 */     this.gateway = Objects.<GatewayDiscordClient>requireNonNull(gateway);
/*  55 */     this.data = Objects.<VoiceStateData>requireNonNull(data);
/*     */   }
/*     */ 
/*     */   
/*     */   public GatewayDiscordClient getClient() {
/*  60 */     return this.gateway;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public VoiceStateData getData() {
/*  69 */     return this.data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Snowflake getGuildId() {
/*  81 */     return Snowflake.of((Id)this.data.guildId().toOptional().orElseThrow(IllegalStateException::new));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Guild> getGuild() {
/*  91 */     return this.gateway.getGuildById(getGuildId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Guild> getGuild(EntityRetrievalStrategy retrievalStrategy) {
/* 102 */     return this.gateway.withRetrievalStrategy(retrievalStrategy).getGuildById(getGuildId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<Snowflake> getChannelId() {
/* 111 */     return this.data.channelId().map(Snowflake::of);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<VoiceChannel> getChannel() {
/* 121 */     Objects.requireNonNull(this.gateway); return Mono.justOrEmpty(getChannelId()).flatMap(this.gateway::getChannelById).cast(VoiceChannel.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<VoiceChannel> getChannel(EntityRetrievalStrategy retrievalStrategy) {
/* 132 */     return Mono.justOrEmpty(getChannelId())
/* 133 */       .flatMap(id -> this.gateway.withRetrievalStrategy(retrievalStrategy).getChannelById(id))
/* 134 */       .cast(VoiceChannel.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Snowflake getUserId() {
/* 143 */     return Snowflake.of(this.data.userId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<User> getUser() {
/* 153 */     return this.gateway.getUserById(getUserId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<User> getUser(EntityRetrievalStrategy retrievalStrategy) {
/* 164 */     return this.gateway.withRetrievalStrategy(retrievalStrategy).getUserById(getUserId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Member> getMember() {
/* 174 */     return this.gateway.getMemberById(getGuildId(), getUserId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Member> getMember(EntityRetrievalStrategy retrievalStrategy) {
/* 185 */     return this.gateway.withRetrievalStrategy(retrievalStrategy).getMemberById(getGuildId(), getUserId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSessionId() {
/* 194 */     return this.data.sessionId();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDeaf() {
/* 203 */     return this.data.deaf();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isMuted() {
/* 212 */     return this.data.mute();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSelfDeaf() {
/* 221 */     return this.data.selfDeaf();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSelfMuted() {
/* 230 */     return this.data.selfMute();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSelfStreaming() {
/* 239 */     return ((Boolean)this.data.selfStream().toOptional().orElse(Boolean.valueOf(false))).booleanValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSelfVideoEnabled() {
/* 248 */     return this.data.selfVideo();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSuppressed() {
/* 257 */     return this.data.suppress();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<Instant> getRequestedToSpeakAt() {
/* 266 */     return this.data.requestToSpeakTimestamp()
/* 267 */       .map(timestamp -> (Instant)DateTimeFormatter.ISO_OFFSET_DATE_TIME.<Instant>parse(timestamp, Instant::from));
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 272 */     return "VoiceState{data=" + this.data + '}';
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\object\VoiceState.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */