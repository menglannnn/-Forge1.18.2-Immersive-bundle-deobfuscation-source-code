/*     */ package discord4j.core.object.entity.channel;
/*     */ 
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.GatewayDiscordClient;
/*     */ import discord4j.core.object.ExtendedInvite;
/*     */ import discord4j.core.object.ExtendedPermissionOverwrite;
/*     */ import discord4j.core.object.PermissionOverwrite;
/*     */ import discord4j.core.object.entity.Guild;
/*     */ import discord4j.core.object.entity.Member;
/*     */ import discord4j.core.object.entity.Message;
/*     */ import discord4j.core.object.entity.Webhook;
/*     */ import discord4j.core.retriever.EntityRetrievalStrategy;
/*     */ import discord4j.core.spec.InviteCreateSpec;
/*     */ import discord4j.core.spec.MessageCreateSpec;
/*     */ import discord4j.core.spec.WebhookCreateSpec;
/*     */ import discord4j.core.spec.legacy.LegacyInviteCreateSpec;
/*     */ import discord4j.core.spec.legacy.LegacyMessageCreateSpec;
/*     */ import discord4j.core.spec.legacy.LegacyWebhookCreateSpec;
/*     */ import discord4j.discordjson.json.BulkDeleteRequest;
/*     */ import discord4j.discordjson.json.ChannelData;
/*     */ import discord4j.discordjson.json.WebhookData;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import discord4j.rest.util.Permission;
/*     */ import discord4j.rest.util.PermissionSet;
/*     */ import java.time.Duration;
/*     */ import java.time.Instant;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import java.util.Set;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.stream.Collectors;
/*     */ import org.reactivestreams.Publisher;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class BaseGuildMessageChannel
/*     */   extends BaseChannel
/*     */   implements GuildMessageChannel
/*     */ {
/*     */   private final BaseGuildChannel guildChannel;
/*     */   private final BaseMessageChannel messageChannel;
/*     */   private final BaseCategorizableChannel categorizableChannel;
/*     */   
/*     */   BaseGuildMessageChannel(GatewayDiscordClient gateway, ChannelData data) {
/*  70 */     super(gateway, data);
/*  71 */     this.guildChannel = new BaseGuildChannel(gateway, data);
/*  72 */     this.messageChannel = new BaseMessageChannel(gateway, data);
/*  73 */     this.categorizableChannel = new BaseCategorizableChannel(gateway, data);
/*     */   }
/*     */ 
/*     */   
/*     */   public Snowflake getGuildId() {
/*  78 */     return this.guildChannel.getGuildId();
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Guild> getGuild() {
/*  83 */     return this.guildChannel.getGuild();
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Guild> getGuild(EntityRetrievalStrategy retrievalStrategy) {
/*  88 */     return this.guildChannel.getGuild(retrievalStrategy);
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<ExtendedPermissionOverwrite> getPermissionOverwrites() {
/*  93 */     return this.guildChannel.getPermissionOverwrites();
/*     */   }
/*     */ 
/*     */   
/*     */   public Optional<ExtendedPermissionOverwrite> getOverwriteForMember(Snowflake memberId) {
/*  98 */     return this.guildChannel.getOverwriteForMember(memberId);
/*     */   }
/*     */ 
/*     */   
/*     */   public Optional<ExtendedPermissionOverwrite> getOverwriteForRole(Snowflake roleId) {
/* 103 */     return this.guildChannel.getOverwriteForRole(roleId);
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<PermissionSet> getEffectivePermissions(Snowflake memberId) {
/* 108 */     return this.guildChannel.getEffectivePermissions(memberId);
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<PermissionSet> getEffectivePermissions(Member member) {
/* 113 */     return this.guildChannel.getEffectivePermissions(member);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getName() {
/* 118 */     return this.guildChannel.getName();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getRawPosition() {
/* 123 */     return this.guildChannel.getRawPosition();
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Integer> getPosition() {
/* 128 */     return this.guildChannel.getPosition();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Void> addMemberOverwrite(Snowflake memberId, PermissionOverwrite overwrite, @Nullable String reason) {
/* 134 */     return this.guildChannel.addMemberOverwrite(memberId, overwrite, reason);
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> addRoleOverwrite(Snowflake roleId, PermissionOverwrite overwrite, @Nullable String reason) {
/* 139 */     return this.guildChannel.addRoleOverwrite(roleId, overwrite, reason);
/*     */   }
/*     */ 
/*     */   
/*     */   public Optional<Snowflake> getLastMessageId() {
/* 144 */     return this.messageChannel.getLastMessageId();
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Message> getLastMessage() {
/* 149 */     return this.messageChannel.getLastMessage();
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Message> getLastMessage(EntityRetrievalStrategy retrievalStrategy) {
/* 154 */     return this.messageChannel.getLastMessage(retrievalStrategy);
/*     */   }
/*     */ 
/*     */   
/*     */   public Optional<Instant> getLastPinTimestamp() {
/* 159 */     return this.messageChannel.getLastPinTimestamp();
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Message> createMessage(Consumer<? super LegacyMessageCreateSpec> spec) {
/* 164 */     return this.messageChannel.createMessage(spec);
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Message> createMessage(MessageCreateSpec spec) {
/* 169 */     return this.messageChannel.createMessage(spec);
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> type() {
/* 174 */     return this.messageChannel.type();
/*     */   }
/*     */ 
/*     */   
/*     */   public Flux<Long> typeUntil(Publisher<?> until) {
/* 179 */     return this.messageChannel.typeUntil(until);
/*     */   }
/*     */ 
/*     */   
/*     */   public Flux<Message> getMessagesBefore(Snowflake messageId) {
/* 184 */     return this.messageChannel.getMessagesBefore(messageId);
/*     */   }
/*     */ 
/*     */   
/*     */   public Flux<Message> getMessagesAfter(Snowflake messageId) {
/* 189 */     return this.messageChannel.getMessagesAfter(messageId);
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Message> getMessageById(Snowflake id) {
/* 194 */     return this.messageChannel.getMessageById(id);
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Message> getMessageById(Snowflake id, EntityRetrievalStrategy retrievalStrategy) {
/* 199 */     return this.messageChannel.getMessageById(id, retrievalStrategy);
/*     */   }
/*     */ 
/*     */   
/*     */   public Flux<Message> getPinnedMessages() {
/* 204 */     return this.messageChannel.getPinnedMessages();
/*     */   }
/*     */ 
/*     */   
/*     */   public Optional<Snowflake> getCategoryId() {
/* 209 */     return this.categorizableChannel.getCategoryId();
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Category> getCategory() {
/* 214 */     return this.categorizableChannel.getCategory();
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Category> getCategory(EntityRetrievalStrategy retrievalStrategy) {
/* 219 */     return this.categorizableChannel.getCategory(retrievalStrategy);
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<ExtendedInvite> createInvite(Consumer<? super LegacyInviteCreateSpec> spec) {
/* 224 */     return this.categorizableChannel.createInvite(spec);
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<ExtendedInvite> createInvite(InviteCreateSpec spec) {
/* 229 */     return this.categorizableChannel.createInvite(spec);
/*     */   }
/*     */ 
/*     */   
/*     */   public Flux<ExtendedInvite> getInvites() {
/* 234 */     return this.categorizableChannel.getInvites();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<String> getTopic() {
/* 244 */     return Possible.flatOpt(getData().topic());
/*     */   }
/*     */ 
/*     */   
/*     */   public Flux<Snowflake> bulkDelete(Publisher<Snowflake> messageIds) {
/* 249 */     return getRestChannel().bulkDelete(messageIds);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Flux<Message> bulkDeleteMessages(Publisher<Message> messages) {
/* 257 */     Instant timeLimit = Instant.now().minus(Duration.ofDays(14L));
/*     */     
/* 259 */     return Flux.from(messages)
/* 260 */       .distinct(Message::getId)
/* 261 */       .buffer(100)
/* 262 */       .flatMap(allMessages -> {
/*     */           List<Message> eligibleMessages = new ArrayList<>(0);
/*     */           Collection<Message> ineligibleMessages = new ArrayList<>(0);
/*     */           for (Message message : allMessages) {
/*     */             if (message.getId().getTimestamp().isBefore(timeLimit)) {
/*     */               ineligibleMessages.add(message);
/*     */               continue;
/*     */             } 
/*     */             eligibleMessages.add(message);
/*     */           } 
/*     */           if (eligibleMessages.size() == 1) {
/*     */             ineligibleMessages.add(eligibleMessages.get(0));
/*     */             eligibleMessages.clear();
/*     */           } 
/*     */           Collection<String> eligibleIds = (Collection<String>)eligibleMessages.stream().map(Message::getId).map(Snowflake::asString).collect(Collectors.toList());
/*     */           return (Publisher)Mono.just(eligibleIds).filter(()).flatMap(()).thenMany((Publisher)Flux.fromIterable(ineligibleMessages));
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Webhook> createWebhook(Consumer<? super LegacyWebhookCreateSpec> spec) {
/* 296 */     return Mono.defer(() -> {
/*     */           LegacyWebhookCreateSpec mutatedSpec = new LegacyWebhookCreateSpec();
/*     */ 
/*     */           
/*     */           spec.accept(mutatedSpec);
/*     */           
/*     */           return getClient().getRestClient().getWebhookService().createWebhook(getId().asLong(), mutatedSpec.asRequest(), mutatedSpec.getReason());
/* 303 */         }).map(data -> new Webhook(getClient(), data));
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Webhook> createWebhook(WebhookCreateSpec spec) {
/* 308 */     Objects.requireNonNull(spec);
/* 309 */     return Mono.defer(() -> getClient().getRestClient().getWebhookService().createWebhook(getId().asLong(), spec.asRequest(), spec.reason()))
/*     */ 
/*     */       
/* 312 */       .map(data -> new Webhook(getClient(), data));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Flux<Webhook> getWebhooks() {
/* 323 */     return getClient().getRestClient().getWebhookService()
/* 324 */       .getChannelWebhooks(getId().asLong())
/* 325 */       .map(data -> new Webhook(getClient(), data));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Flux<Member> getMembers() {
/* 336 */     return getGuild()
/* 337 */       .flatMapMany(Guild::getMembers)
/* 338 */       .filterWhen(member -> getEffectivePermissions(member.getId()).map(()));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 344 */     return "GuildMessageChannel{guildChannel=" + this.guildChannel + ", messageChannel=" + this.messageChannel + "} " + super
/*     */ 
/*     */       
/* 347 */       .toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\object\entity\channel\BaseGuildMessageChannel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */