/*     */ package discord4j.core.object.entity.channel;
/*     */ 
/*     */ import discord4j.common.store.action.read.ReadActions;
/*     */ import discord4j.common.store.api.StoreAction;
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.GatewayDiscordClient;
/*     */ import discord4j.core.object.PermissionOverwrite;
/*     */ import discord4j.core.object.Region;
/*     */ import discord4j.core.object.VoiceState;
/*     */ import discord4j.core.object.entity.Guild;
/*     */ import discord4j.core.object.entity.Member;
/*     */ import discord4j.core.object.entity.Message;
/*     */ import discord4j.core.retriever.EntityRetrievalStrategy;
/*     */ import discord4j.core.spec.InviteCreateSpec;
/*     */ import discord4j.core.spec.MessageCreateSpec;
/*     */ import discord4j.core.spec.VoiceChannelEditMono;
/*     */ import discord4j.core.spec.VoiceChannelEditSpec;
/*     */ import discord4j.core.spec.VoiceChannelJoinMono;
/*     */ import discord4j.core.spec.VoiceChannelJoinSpec;
/*     */ import discord4j.core.spec.WebhookCreateSpec;
/*     */ import discord4j.core.spec.legacy.LegacyInviteCreateSpec;
/*     */ import discord4j.core.spec.legacy.LegacyMessageCreateSpec;
/*     */ import discord4j.core.spec.legacy.LegacyVoiceChannelEditSpec;
/*     */ import discord4j.core.spec.legacy.LegacyVoiceChannelJoinSpec;
/*     */ import discord4j.core.spec.legacy.LegacyWebhookCreateSpec;
/*     */ import discord4j.core.util.EntityUtil;
/*     */ import discord4j.discordjson.json.ChannelData;
/*     */ import discord4j.discordjson.json.VoiceStateData;
/*     */ import discord4j.discordjson.json.gateway.VoiceStateUpdate;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import discord4j.gateway.GatewayClientGroup;
/*     */ import discord4j.gateway.json.ShardGatewayPayload;
/*     */ import discord4j.rest.entity.RestChannel;
/*     */ import discord4j.voice.VoiceConnection;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Supplier;
/*     */ import org.reactivestreams.Publisher;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class VoiceChannel
/*     */   extends BaseTopLevelGuildMessageChannel
/*     */ {
/*     */   public VoiceChannel(GatewayDiscordClient gateway, ChannelData data) {
/*  55 */     super(gateway, data);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getBitrate() {
/*  64 */     return ((Integer)getData().bitrate().toOptional().orElseThrow(IllegalStateException::new)).intValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getUserLimit() {
/*  73 */     return ((Integer)getData().userLimit().toOptional().orElseThrow(IllegalStateException::new)).intValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Region.Id getRtcRegion() {
/*  82 */     return Possible.flatOpt(getData().rtcRegion()).map(Region.Id::of).orElse(Region.Id.AUTOMATIC);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mode getVideoQualityMode() {
/*  91 */     return getData().videoQualityMode().toOptional().map(Mode::of).orElse(Mode.AUTO);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public Mono<VoiceChannel> edit(Consumer<? super LegacyVoiceChannelEditSpec> spec) {
/* 105 */     return Mono.defer(() -> {
/*     */           LegacyVoiceChannelEditSpec mutatedSpec = new LegacyVoiceChannelEditSpec();
/*     */ 
/*     */           
/*     */           spec.accept(mutatedSpec);
/*     */           
/*     */           return getClient().getRestClient().getChannelService().modifyChannel(getId().asLong(), mutatedSpec.asRequest(), mutatedSpec.getReason());
/* 112 */         }).map(data -> EntityUtil.getChannel(getClient(), data))
/* 113 */       .cast(VoiceChannel.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public VoiceChannelEditMono edit() {
/* 124 */     return VoiceChannelEditMono.of(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<VoiceChannel> edit(VoiceChannelEditSpec spec) {
/* 135 */     Objects.requireNonNull(spec);
/* 136 */     return Mono.defer(() -> getClient().getRestClient().getChannelService().modifyChannel(getId().asLong(), spec.asRequest(), spec.reason()))
/*     */ 
/*     */       
/* 139 */       .map(data -> EntityUtil.getChannel(getClient(), data))
/* 140 */       .cast(VoiceChannel.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Flux<VoiceState> getVoiceStates() {
/* 150 */     return Flux.from(getClient().getGatewayResources().getStore()
/* 151 */         .execute((StoreAction)ReadActions.getVoiceStatesInChannel(getGuildId().asLong(), getId().asLong())))
/* 152 */       .map(data -> new VoiceState(getClient(), data));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public Mono<VoiceConnection> join(Consumer<? super LegacyVoiceChannelJoinSpec> spec) {
/* 170 */     return Mono.defer(() -> {
/*     */           LegacyVoiceChannelJoinSpec mutatedSpec = new LegacyVoiceChannelJoinSpec(getClient(), this);
/*     */           spec.accept(mutatedSpec);
/*     */           return mutatedSpec.asRequest();
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public VoiceChannelJoinMono join() {
/* 191 */     return VoiceChannelJoinMono.of(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<VoiceConnection> join(VoiceChannelJoinSpec spec) {
/* 206 */     Objects.requireNonNull(spec);
/* 207 */     return Mono.defer(() -> (Mono)spec.asRequest().apply(this));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Void> sendConnectVoiceState(boolean selfMute, boolean selfDeaf) {
/* 220 */     GatewayClientGroup clientGroup = getClient().getGatewayClientGroup();
/* 221 */     int shardId = clientGroup.computeShardIndex(getGuildId());
/* 222 */     return clientGroup.unicast(ShardGatewayPayload.voiceStateUpdate(
/* 223 */           (VoiceStateUpdate)VoiceStateUpdate.builder()
/* 224 */           .guildId(getGuildId().asString())
/* 225 */           .channelId(getId().asString())
/* 226 */           .selfMute(selfMute)
/* 227 */           .selfDeaf(selfDeaf)
/* 228 */           .build(), shardId));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Void> sendDisconnectVoiceState() {
/* 240 */     GatewayClientGroup clientGroup = getClient().getGatewayClientGroup();
/* 241 */     int shardId = clientGroup.computeShardIndex(getGuildId());
/* 242 */     return clientGroup.unicast(ShardGatewayPayload.voiceStateUpdate(
/* 243 */           (VoiceStateUpdate)VoiceStateUpdate.builder()
/* 244 */           .guildId(getGuildId().asString())
/* 245 */           .selfMute(false)
/* 246 */           .selfDeaf(false)
/* 247 */           .build(), shardId));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Boolean> isMemberConnected(Snowflake memberId) {
/* 262 */     Objects.requireNonNull(memberId); return getVoiceStates().map(VoiceState::getUserId).any(memberId::equals);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<VoiceConnection> getVoiceConnection() {
/* 273 */     return getGuild()
/* 274 */       .flatMap(Guild::getVoiceConnection)
/* 275 */       .filterWhen(voiceConnection -> voiceConnection.getChannelId().map(()));
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 280 */     return "VoiceChannel{} " + super.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public enum Mode
/*     */   {
/* 287 */     UNKNOWN(-1),
/*     */ 
/*     */     
/* 290 */     AUTO(1),
/*     */ 
/*     */     
/* 293 */     FULL(2);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final int value;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Mode(int value) {
/* 304 */       this.value = value;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int getValue() {
/* 313 */       return this.value;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Mode of(int value) {
/* 324 */       switch (value) { case 1:
/* 325 */           return AUTO;
/* 326 */         case 2: return FULL; }
/* 327 */        return UNKNOWN;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\object\entity\channel\VoiceChannel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */