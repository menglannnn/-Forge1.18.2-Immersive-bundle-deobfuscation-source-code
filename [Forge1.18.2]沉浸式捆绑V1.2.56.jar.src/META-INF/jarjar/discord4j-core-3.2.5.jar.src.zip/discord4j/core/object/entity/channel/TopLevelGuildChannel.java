/*    */ package discord4j.core.object.entity.channel;
/*    */ 
/*    */ import discord4j.common.util.Snowflake;
/*    */ import discord4j.core.object.ExtendedPermissionOverwrite;
/*    */ import discord4j.core.object.PermissionOverwrite;
/*    */ import java.util.Optional;
/*    */ import java.util.Set;
/*    */ import reactor.core.publisher.Mono;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface TopLevelGuildChannel
/*    */   extends GuildChannel
/*    */ {
/*    */   Set<ExtendedPermissionOverwrite> getPermissionOverwrites();
/*    */   
/*    */   Optional<ExtendedPermissionOverwrite> getOverwriteForMember(Snowflake paramSnowflake);
/*    */   
/*    */   Optional<ExtendedPermissionOverwrite> getOverwriteForRole(Snowflake paramSnowflake);
/*    */   
/*    */   default Mono<Void> addMemberOverwrite(Snowflake memberId, PermissionOverwrite overwrite) {
/* 42 */     return addMemberOverwrite(memberId, overwrite, null);
/*    */   }
/*    */ 
/*    */   
/*    */   Mono<Void> addMemberOverwrite(Snowflake paramSnowflake, PermissionOverwrite paramPermissionOverwrite, @Nullable String paramString);
/*    */ 
/*    */   
/*    */   default Mono<Void> addRoleOverwrite(Snowflake roleId, PermissionOverwrite overwrite) {
/* 50 */     return addRoleOverwrite(roleId, overwrite, null);
/*    */   }
/*    */   
/*    */   Mono<Void> addRoleOverwrite(Snowflake paramSnowflake, PermissionOverwrite paramPermissionOverwrite, @Nullable String paramString);
/*    */   
/*    */   int getRawPosition();
/*    */   
/*    */   Mono<Integer> getPosition();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\object\entity\channel\TopLevelGuildChannel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */