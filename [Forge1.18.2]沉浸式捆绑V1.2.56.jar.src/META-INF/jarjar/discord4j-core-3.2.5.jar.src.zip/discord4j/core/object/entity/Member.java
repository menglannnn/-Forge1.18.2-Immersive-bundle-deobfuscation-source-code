/*    */ package discord4j.core.object.entity;
/*    */ 
/*    */ import discord4j.common.util.Snowflake;
/*    */ import discord4j.core.GatewayDiscordClient;
/*    */ import discord4j.discordjson.json.MemberData;
/*    */ import discord4j.discordjson.json.PartialMemberData;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Member
/*    */   extends PartialMember
/*    */ {
/*    */   public Member(GatewayDiscordClient gateway, MemberData data, long guildId) {
/* 39 */     super(gateway, data.user(), (PartialMemberData)data, guildId);
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<Member> asMember(Snowflake guildId) {
/* 44 */     return Mono.just(this)
/* 45 */       .filter(member -> member.getGuildId().equals(guildId))
/* 46 */       .switchIfEmpty(super.asMember(guildId));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public MemberData getMemberData() {
/* 56 */     return (MemberData)super.getMemberData();
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<Member> asFullMember() {
/* 61 */     return Mono.just(this);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isPending() {
/* 70 */     return ((Boolean)getMemberData().pending().toOptional().orElse(Boolean.valueOf(false))).booleanValue();
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 75 */     return "Member{} " + super.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\object\entity\Member.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */