/*     */ package discord4j.core.object.entity.channel;
/*     */ 
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.GatewayDiscordClient;
/*     */ import discord4j.core.util.EntityUtil;
/*     */ import discord4j.discordjson.json.ChannelData;
/*     */ import discord4j.rest.entity.RestChannel;
/*     */ import java.util.Objects;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class BaseChannel
/*     */   implements Channel
/*     */ {
/*     */   private final ChannelData data;
/*     */   private final GatewayDiscordClient gateway;
/*     */   private final RestChannel rest;
/*     */   
/*     */   BaseChannel(GatewayDiscordClient gateway, ChannelData data) {
/*  48 */     this.gateway = Objects.<GatewayDiscordClient>requireNonNull(gateway);
/*  49 */     this.data = Objects.<ChannelData>requireNonNull(data);
/*  50 */     this.rest = RestChannel.create(gateway.getRestClient(), Snowflake.of(data.id()));
/*     */   }
/*     */ 
/*     */   
/*     */   public final GatewayDiscordClient getClient() {
/*  55 */     return this.gateway;
/*     */   }
/*     */ 
/*     */   
/*     */   public final Snowflake getId() {
/*  60 */     return Snowflake.of(this.data.id());
/*     */   }
/*     */ 
/*     */   
/*     */   public RestChannel getRestChannel() {
/*  65 */     return this.rest;
/*     */   }
/*     */ 
/*     */   
/*     */   public final Channel.Type getType() {
/*  70 */     return Channel.Type.of(this.data.type());
/*     */   }
/*     */ 
/*     */   
/*     */   public final Mono<Void> delete(@Nullable String reason) {
/*  75 */     return this.rest.delete(reason);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ChannelData getData() {
/*  84 */     return this.data;
/*     */   }
/*     */ 
/*     */   
/*     */   public final boolean equals(@Nullable Object obj) {
/*  89 */     if (this == obj) {
/*  90 */       return true;
/*     */     }
/*  92 */     if (obj == null || !BaseChannel.class.isAssignableFrom(obj.getClass())) {
/*  93 */       return false;
/*     */     }
/*  95 */     BaseChannel that = (BaseChannel)obj;
/*  96 */     return getId().equals(that.getId());
/*     */   }
/*     */ 
/*     */   
/*     */   public final int hashCode() {
/* 101 */     return EntityUtil.hashCode(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 106 */     return "BaseChannel{data=" + this.data + '}';
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\object\entity\channel\BaseChannel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */