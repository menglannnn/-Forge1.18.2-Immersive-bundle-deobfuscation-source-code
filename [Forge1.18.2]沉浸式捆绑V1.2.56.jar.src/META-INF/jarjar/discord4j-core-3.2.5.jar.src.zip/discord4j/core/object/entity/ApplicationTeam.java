/*     */ package discord4j.core.object.entity;
/*     */ 
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.GatewayDiscordClient;
/*     */ import discord4j.core.object.ApplicationTeamMember;
/*     */ import discord4j.core.retriever.EntityRetrievalStrategy;
/*     */ import discord4j.discordjson.json.ApplicationTeamData;
/*     */ import discord4j.discordjson.json.ApplicationTeamMemberData;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.stream.Collectors;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ApplicationTeam
/*     */   implements Entity
/*     */ {
/*     */   private final GatewayDiscordClient gateway;
/*     */   private final ApplicationTeamData data;
/*     */   
/*     */   public ApplicationTeam(GatewayDiscordClient gateway, ApplicationTeamData data) {
/*  48 */     this.gateway = Objects.<GatewayDiscordClient>requireNonNull(gateway);
/*  49 */     this.data = Objects.<ApplicationTeamData>requireNonNull(data);
/*     */   }
/*     */ 
/*     */   
/*     */   public GatewayDiscordClient getClient() {
/*  54 */     return this.gateway;
/*     */   }
/*     */ 
/*     */   
/*     */   public Snowflake getId() {
/*  59 */     return Snowflake.of(this.data.id());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<ApplicationTeamMember> getMembers() {
/*  68 */     return (List<ApplicationTeamMember>)this.data.members().stream()
/*  69 */       .map(data -> new ApplicationTeamMember(this.gateway, data))
/*  70 */       .collect(Collectors.toList());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/*  79 */     return this.data.name();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Snowflake getOwnerId() {
/*  88 */     return Snowflake.of(this.data.ownerUserId().asLong());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<User> getOwner() {
/*  98 */     return this.gateway.getUserById(getOwnerId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<User> getOwner(EntityRetrievalStrategy retrievalStrategy) {
/* 109 */     return this.gateway.withRetrievalStrategy(retrievalStrategy).getUserById(getOwnerId());
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 114 */     return "ApplicationTeam{data=" + this.data + '}';
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\object\entity\ApplicationTeam.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */