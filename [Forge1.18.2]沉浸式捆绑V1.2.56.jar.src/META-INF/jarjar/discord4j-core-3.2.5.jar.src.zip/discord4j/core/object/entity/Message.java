/*      */ package discord4j.core.object.entity;
/*      */ 
/*      */ import discord4j.common.annotations.Experimental;
/*      */ import discord4j.common.util.Snowflake;
/*      */ import discord4j.core.GatewayDiscordClient;
/*      */ import discord4j.core.object.Embed;
/*      */ import discord4j.core.object.MessageInteraction;
/*      */ import discord4j.core.object.MessageReference;
/*      */ import discord4j.core.object.component.LayoutComponent;
/*      */ import discord4j.core.object.component.MessageComponent;
/*      */ import discord4j.core.object.entity.channel.GuildChannel;
/*      */ import discord4j.core.object.entity.channel.MessageChannel;
/*      */ import discord4j.core.object.reaction.Reaction;
/*      */ import discord4j.core.object.reaction.ReactionEmoji;
/*      */ import discord4j.core.retriever.EntityRetrievalStrategy;
/*      */ import discord4j.core.spec.MessageEditMono;
/*      */ import discord4j.core.spec.MessageEditSpec;
/*      */ import discord4j.core.spec.legacy.LegacyMessageEditSpec;
/*      */ import discord4j.core.util.EntityUtil;
/*      */ import discord4j.discordjson.Id;
/*      */ import discord4j.discordjson.json.AttachmentData;
/*      */ import discord4j.discordjson.json.EmbedData;
/*      */ import discord4j.discordjson.json.MessageData;
/*      */ import discord4j.discordjson.json.MessageInteractionData;
/*      */ import discord4j.discordjson.json.MessageReferenceData;
/*      */ import discord4j.discordjson.json.PartialMemberData;
/*      */ import discord4j.discordjson.json.PartialStickerData;
/*      */ import discord4j.discordjson.json.ReactionData;
/*      */ import discord4j.discordjson.json.StickerData;
/*      */ import discord4j.discordjson.json.SuppressEmbedsRequest;
/*      */ import discord4j.discordjson.json.UserData;
/*      */ import discord4j.discordjson.json.UserWithMemberData;
/*      */ import discord4j.discordjson.possible.Possible;
/*      */ import discord4j.rest.entity.RestChannel;
/*      */ import discord4j.rest.entity.RestMessage;
/*      */ import discord4j.rest.util.AllowedMentions;
/*      */ import discord4j.rest.util.MultipartRequest;
/*      */ import discord4j.rest.util.PaginationUtil;
/*      */ import java.time.Instant;
/*      */ import java.time.format.DateTimeFormatter;
/*      */ import java.util.Collections;
/*      */ import java.util.EnumSet;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Objects;
/*      */ import java.util.Optional;
/*      */ import java.util.function.Consumer;
/*      */ import java.util.function.Function;
/*      */ import java.util.stream.Collectors;
/*      */ import org.reactivestreams.Publisher;
/*      */ import reactor.core.publisher.Flux;
/*      */ import reactor.core.publisher.Mono;
/*      */ import reactor.util.annotation.Nullable;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class Message
/*      */   implements Entity
/*      */ {
/*      */   public static final int MAX_CONTENT_LENGTH = 2000;
/*      */   public static final int MAX_TOTAL_EMBEDS_CHARACTER_LENGTH = 6000;
/*      */   private final GatewayDiscordClient gateway;
/*      */   private final MessageData data;
/*      */   private final RestMessage rest;
/*      */   
/*      */   public Message(GatewayDiscordClient gateway, MessageData data) {
/*   95 */     this.gateway = Objects.<GatewayDiscordClient>requireNonNull(gateway);
/*   96 */     this.data = Objects.<MessageData>requireNonNull(data);
/*   97 */     this.rest = RestMessage.create(gateway.getRestClient(), Snowflake.of(data.channelId()), 
/*   98 */         Snowflake.of(data.id()));
/*      */   }
/*      */ 
/*      */   
/*      */   public GatewayDiscordClient getClient() {
/*  103 */     return this.gateway;
/*      */   }
/*      */ 
/*      */   
/*      */   public Snowflake getId() {
/*  108 */     return Snowflake.of(this.data.id());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MessageData getData() {
/*  117 */     return this.data;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public RestMessage getRestMessage() {
/*  124 */     return this.rest;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public RestChannel getRestChannel() {
/*  131 */     return RestChannel.create(this.gateway.getRestClient(), Snowflake.of(this.data.channelId()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Snowflake getChannelId() {
/*  140 */     return Snowflake.of(this.data.channelId());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<MessageChannel> getChannel() {
/*  150 */     return this.gateway.getChannelById(getChannelId()).cast(MessageChannel.class);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<MessageChannel> getChannel(EntityRetrievalStrategy retrievalStrategy) {
/*  161 */     return this.gateway.withRetrievalStrategy(retrievalStrategy).getChannelById(getChannelId()).cast(MessageChannel.class);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Optional<Snowflake> getWebhookId() {
/*  170 */     return this.data.webhookId().toOptional().map(Snowflake::of);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Optional<User> getAuthor() {
/*  179 */     return (this.data.webhookId().isAbsent() || !this.data.interaction().isAbsent()) ? 
/*  180 */       Optional.<User>of(new User(this.gateway, this.data.author())) : Optional.<User>empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<Member> getAuthorAsMember() {
/*  191 */     return Mono.justOrEmpty(getAuthor())
/*  192 */       .flatMap(author -> {
/*      */           Objects.requireNonNull(author);
/*      */           return getGuild().map(Guild::getId).flatMap(author::asMember);
/*      */         });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Experimental
/*      */   public UserData getUserData() {
/*  204 */     return this.data.author();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getContent() {
/*  213 */     return this.data.content();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Instant getTimestamp() {
/*  222 */     return DateTimeFormatter.ISO_OFFSET_DATE_TIME.<Instant>parse(this.data.timestamp(), Instant::from);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Optional<Instant> getEditedTimestamp() {
/*  231 */     return this.data.editedTimestamp()
/*  232 */       .map(timestamp -> (Instant)DateTimeFormatter.ISO_OFFSET_DATE_TIME.<Instant>parse(timestamp, Instant::from));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isTts() {
/*  241 */     return this.data.tts();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean mentionsEveryone() {
/*  250 */     return this.data.mentionEveryone();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<Snowflake> getUserMentionIds() {
/*  261 */     return (List<Snowflake>)this.data.mentions().stream()
/*  262 */       .map(UserData::id)
/*  263 */       .map(Snowflake::of)
/*  264 */       .collect(Collectors.toList());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<PartialMember> getMemberMentions() {
/*  275 */     if (this.data.guildId().isAbsent()) {
/*  276 */       return Collections.emptyList();
/*      */     }
/*  278 */     long guildId = ((Id)this.data.guildId().get()).asLong();
/*  279 */     return (List<PartialMember>)this.data.mentions().stream()
/*  280 */       .map(data -> new PartialMember(this.gateway, (UserData)data, (PartialMemberData)data.member().get(), guildId))
/*  281 */       .collect(Collectors.toList());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<User> getUserMentions() {
/*  292 */     return (List<User>)this.data.mentions().stream()
/*  293 */       .map(data -> new User(this.gateway, (UserData)data))
/*  294 */       .collect(Collectors.toList());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<Snowflake> getRoleMentionIds() {
/*  305 */     return (List<Snowflake>)this.data.mentionRoles().stream()
/*  306 */       .map(Snowflake::of)
/*  307 */       .collect(Collectors.toList());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Flux<Role> getRoleMentions() {
/*  317 */     return Flux.fromIterable(getRoleMentionIds())
/*  318 */       .flatMap(roleId -> getGuild().map(Guild::getId).flatMap(()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Flux<Role> getRoleMentions(EntityRetrievalStrategy retrievalStrategy) {
/*  331 */     return Flux.fromIterable(getRoleMentionIds())
/*  332 */       .flatMap(roleId -> getGuild().map(Guild::getId).flatMap(()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<Attachment> getAttachments() {
/*  344 */     return (List<Attachment>)this.data.attachments().stream()
/*  345 */       .map(data -> new Attachment(this.gateway, data))
/*  346 */       .collect(Collectors.toList());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<Embed> getEmbeds() {
/*  355 */     return (List<Embed>)this.data.embeds().stream()
/*  356 */       .map(data -> new Embed(this.gateway, data))
/*  357 */       .collect(Collectors.toList());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<Reaction> getReactions() {
/*  366 */     return this.data.reactions().toOptional()
/*  367 */       .map(reactions -> (List)reactions.stream().map(()).collect(Collectors.toList()))
/*      */ 
/*      */       
/*  370 */       .orElse(Collections.emptyList());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Flux<User> getReactors(ReactionEmoji emoji) {
/*  382 */     Function<Map<String, Object>, Flux<UserData>> makeRequest = params -> this.gateway.getRestClient().getChannelService().getReactions(getChannelId().asLong(), getId().asLong(), EntityUtil.getEmojiString(emoji), params);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  388 */     return PaginationUtil.paginateAfter(makeRequest, data -> Snowflake.asLong(data.id()), 0L, 100)
/*  389 */       .map(data -> new User(this.gateway, data));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isPinned() {
/*  398 */     return this.data.pinned();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<Webhook> getWebhook() {
/*  408 */     Objects.requireNonNull(this.gateway); return Mono.justOrEmpty(getWebhookId()).flatMap(this.gateway::getWebhookById);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Optional<MessageReference> getMessageReference() {
/*  417 */     return this.data.messageReference().toOptional()
/*  418 */       .map(data -> new MessageReference(this.gateway, data));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public EnumSet<Flag> getFlags() {
/*  427 */     return this.data.flags().toOptional()
/*  428 */       .map(Flag::of)
/*  429 */       .orElse(EnumSet.noneOf(Flag.class));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Optional<Snowflake> getGuildId() {
/*  439 */     return this.data.guildId().toOptional().map(Snowflake::of);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<Guild> getGuild() {
/*  449 */     return getChannel().ofType(GuildChannel.class).flatMap(GuildChannel::getGuild);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<Guild> getGuild(EntityRetrievalStrategy retrievalStrategy) {
/*  460 */     return getChannel(retrievalStrategy).ofType(GuildChannel.class)
/*  461 */       .flatMap(guildChannel -> guildChannel.getGuild(retrievalStrategy));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Type getType() {
/*  470 */     return Type.of(this.data.type());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Experimental
/*      */   public List<PartialSticker> getStickersItems() {
/*  480 */     return this.data.stickerItems().toOptional()
/*  481 */       .map(partialStickers -> (List)partialStickers.stream().map(()).collect(Collectors.toList()))
/*      */ 
/*      */       
/*  484 */       .orElse(Collections.emptyList());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public List<Sticker> getStickers() {
/*  494 */     return (List<Sticker>)((List)this.data.stickers().toOptional()
/*  495 */       .orElse(Collections.emptyList()))
/*  496 */       .stream()
/*  497 */       .map(data -> new Sticker(this.gateway, data))
/*  498 */       .collect(Collectors.toList());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Optional<Message> getReferencedMessage() {
/*  507 */     return Possible.flatOpt(this.data.referencedMessage())
/*  508 */       .map(data -> new Message(this.gateway, data));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Optional<MessageInteraction> getInteraction() {
/*  517 */     return this.data.interaction().toOptional()
/*  518 */       .map(data -> new MessageInteraction(this.gateway, data));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<LayoutComponent> getComponents() {
/*  527 */     return this.data.components().toOptional()
/*  528 */       .map(components -> (List)components.stream().map(MessageComponent::fromData).filter(()).map(()).collect(Collectors.toList()))
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  534 */       .orElse(Collections.emptyList());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public Mono<Message> edit(Consumer<? super LegacyMessageEditSpec> spec) {
/*  548 */     return Mono.defer(() -> {
/*      */           LegacyMessageEditSpec mutatedSpec = new LegacyMessageEditSpec();
/*      */ 
/*      */           
/*      */           Objects.requireNonNull(mutatedSpec);
/*      */           
/*      */           getClient().getRestClient().getRestResources().getAllowedMentions().ifPresent(mutatedSpec::setAllowedMentions);
/*      */           
/*      */           spec.accept(mutatedSpec);
/*      */           
/*      */           return this.gateway.getRestClient().getChannelService().editMessage(getChannelId().asLong(), getId().asLong(), MultipartRequest.ofRequest(mutatedSpec.asRequest()));
/*  559 */         }).map(data -> new Message(this.gateway, data));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<Message> edit(MessageEditSpec spec) {
/*  573 */     Objects.requireNonNull(spec);
/*  574 */     return Mono.defer(() -> {
/*      */           Objects.requireNonNull(spec);
/*      */ 
/*      */ 
/*      */           
/*      */           MessageEditSpec actualSpec = getClient().getRestClient().getRestResources().getAllowedMentions().filter(()).map(spec::withAllowedMentionsOrNull).orElse(spec);
/*      */ 
/*      */ 
/*      */           
/*      */           return this.gateway.getRestClient().getChannelService().editMessage(getChannelId().asLong(), getId().asLong(), actualSpec.asRequest());
/*  584 */         }).map(data -> new Message(this.gateway, data));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MessageEditMono edit() {
/*  631 */     return MessageEditMono.of(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<Void> delete() {
/*  641 */     return delete(null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<Void> delete(@Nullable String reason) {
/*  652 */     return this.gateway.getRestClient().getChannelService()
/*  653 */       .deleteMessage(getChannelId().asLong(), getId().asLong(), reason);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public Mono<Void> suppressEmbeds(boolean suppress) {
/*  669 */     return this.gateway.getRestClient().getChannelService()
/*  670 */       .suppressEmbeds(getChannelId().asLong(), getId().asLong(), 
/*  671 */         (SuppressEmbedsRequest)SuppressEmbedsRequest.builder().suppress(suppress).build());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<Void> addReaction(ReactionEmoji emoji) {
/*  682 */     return this.gateway.getRestClient().getChannelService()
/*  683 */       .createReaction(getChannelId().asLong(), getId().asLong(), EntityUtil.getEmojiString(emoji));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<Void> removeReaction(ReactionEmoji emoji, Snowflake userId) {
/*  695 */     return this.gateway.getRestClient().getChannelService()
/*  696 */       .deleteReaction(getChannelId().asLong(), getId().asLong(), EntityUtil.getEmojiString(emoji), userId
/*  697 */         .asLong());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<Void> removeReactions(ReactionEmoji emoji) {
/*  708 */     return this.gateway.getRestClient().getChannelService()
/*  709 */       .deleteReactions(getChannelId().asLong(), getId().asLong(), EntityUtil.getEmojiString(emoji));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<Void> removeSelfReaction(ReactionEmoji emoji) {
/*  720 */     return this.gateway.getRestClient().getChannelService()
/*  721 */       .deleteOwnReaction(getChannelId().asLong(), getId().asLong(), EntityUtil.getEmojiString(emoji));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<Void> removeAllReactions() {
/*  731 */     return this.gateway.getRestClient().getChannelService()
/*  732 */       .deleteAllReactions(getChannelId().asLong(), getId().asLong());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<Void> pin() {
/*  742 */     return this.gateway.getRestClient().getChannelService()
/*  743 */       .addPinnedMessage(getChannelId().asLong(), getId().asLong());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<Void> unpin() {
/*  753 */     return this.gateway.getRestClient().getChannelService()
/*  754 */       .deletePinnedMessage(getChannelId().asLong(), getId().asLong());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<Message> publish() {
/*  766 */     return this.gateway.getRestClient().getChannelService()
/*  767 */       .publishMessage(getChannelId().asLong(), getId().asLong())
/*  768 */       .map(data -> new Message(this.gateway, data));
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean equals(@Nullable Object obj) {
/*  773 */     return EntityUtil.equals(this, obj);
/*      */   }
/*      */ 
/*      */   
/*      */   public int hashCode() {
/*  778 */     return EntityUtil.hashCode(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public enum Flag
/*      */   {
/*  787 */     CROSSPOSTED(0),
/*      */ 
/*      */     
/*  790 */     IS_CROSSPOST(1),
/*      */ 
/*      */     
/*  793 */     SUPPRESS_EMBEDS(2),
/*      */ 
/*      */     
/*  796 */     SOURCE_MESSAGE_DELETED(3),
/*      */ 
/*      */     
/*  799 */     URGENT(4),
/*      */ 
/*      */     
/*  802 */     HAS_THREAD(5),
/*      */ 
/*      */     
/*  805 */     EPHEMERAL(6),
/*      */ 
/*      */     
/*  808 */     LOADING(7),
/*      */ 
/*      */     
/*  811 */     FAILED_TO_MENTION_SOME_ROLES_IN_THREAD(8),
/*      */ 
/*      */     
/*  814 */     SUPPRESS_NOTIFICATIONS(12),
/*      */ 
/*      */     
/*  817 */     IS_VOICE_MESSAGE(13);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final int value;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final int flag;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     Flag(int value) {
/*  833 */       this.value = value;
/*  834 */       this.flag = 1 << value;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int getValue() {
/*  843 */       return this.value;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int getFlag() {
/*  852 */       return this.flag;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static EnumSet<Flag> of(int value) {
/*  863 */       EnumSet<Flag> messageFlags = EnumSet.noneOf(Flag.class);
/*  864 */       for (Flag flag : values()) {
/*  865 */         long flagValue = flag.getFlag();
/*  866 */         if ((flagValue & value) == flagValue) {
/*  867 */           messageFlags.add(flag);
/*      */         }
/*      */       } 
/*  870 */       return messageFlags;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public enum Type
/*      */   {
/*  882 */     UNKNOWN(-1),
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  887 */     DEFAULT(0),
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  892 */     RECIPIENT_ADD(1),
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  897 */     RECIPIENT_REMOVE(2),
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  902 */     CALL(3),
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  907 */     CHANNEL_NAME_CHANGE(4),
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  912 */     CHANNEL_ICON_CHANGE(5),
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  917 */     CHANNEL_PINNED_MESSAGE(6),
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  922 */     GUILD_MEMBER_JOIN(7),
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  927 */     USER_PREMIUM_GUILD_SUBSCRIPTION(8),
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  932 */     USER_PREMIUM_GUILD_SUBSCRIPTION_TIER_1(9),
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  937 */     USER_PREMIUM_GUILD_SUBSCRIPTION_TIER_2(10),
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  942 */     USER_PREMIUM_GUILD_SUBSCRIPTION_TIER_3(11),
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  948 */     CHANNEL_FOLLOW_ADD(12),
/*      */ 
/*      */     
/*  951 */     GUILD_DISCOVERY_DISQUALIFIED(14),
/*      */ 
/*      */     
/*  954 */     GUILD_DISCOVERY_REQUALIFIED(15),
/*      */ 
/*      */     
/*  957 */     GUILD_DISCOVERY_GRACE_PERIOD_INITIAL_WARNING(16),
/*      */ 
/*      */     
/*  960 */     GUILD_DISCOVERY_GRACE_PERIOD_FINAL_WARNING(17),
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  965 */     THREAD_CREATED(18),
/*      */ 
/*      */     
/*  968 */     REPLY(19),
/*      */ 
/*      */     
/*  971 */     APPLICATION_COMMAND(20),
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  978 */     THREAD_STARTER_MESSAGE(21),
/*      */ 
/*      */     
/*  981 */     GUILD_INVITE_REMINDER(22),
/*      */     
/*  983 */     CONTEXT_MENU_COMMAND(23),
/*      */     
/*  985 */     AUTO_MODERATION_ACTION(24),
/*      */     
/*  987 */     ROLE_SUBSCRIPTION_PURCHASE(25),
/*      */     
/*  989 */     INTERACTION_PREMIUM_UPSELL(26),
/*      */     
/*  991 */     STAGE_START(27),
/*      */     
/*  993 */     STAGE_END(28),
/*      */     
/*  995 */     STAGE_SPEAKER(29),
/*      */     
/*  997 */     STAGE_TOPIC(31),
/*      */     
/*  999 */     GUILD_APPLICATION_PREMIUM_SUBSCRIPTION(32);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final int value;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     Type(int value) {
/* 1012 */       this.value = value;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int getValue() {
/* 1021 */       return this.value;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static Type of(int value) {
/* 1032 */       switch (value) { case 0:
/* 1033 */           return DEFAULT;
/* 1034 */         case 1: return RECIPIENT_ADD;
/* 1035 */         case 2: return RECIPIENT_REMOVE;
/* 1036 */         case 3: return CALL;
/* 1037 */         case 4: return CHANNEL_NAME_CHANGE;
/* 1038 */         case 5: return CHANNEL_ICON_CHANGE;
/* 1039 */         case 6: return CHANNEL_PINNED_MESSAGE;
/* 1040 */         case 7: return GUILD_MEMBER_JOIN;
/* 1041 */         case 8: return USER_PREMIUM_GUILD_SUBSCRIPTION;
/* 1042 */         case 9: return USER_PREMIUM_GUILD_SUBSCRIPTION_TIER_1;
/* 1043 */         case 10: return USER_PREMIUM_GUILD_SUBSCRIPTION_TIER_2;
/* 1044 */         case 11: return USER_PREMIUM_GUILD_SUBSCRIPTION_TIER_3;
/* 1045 */         case 12: return CHANNEL_FOLLOW_ADD;
/* 1046 */         case 14: return GUILD_DISCOVERY_DISQUALIFIED;
/* 1047 */         case 15: return GUILD_DISCOVERY_REQUALIFIED;
/* 1048 */         case 16: return GUILD_DISCOVERY_GRACE_PERIOD_INITIAL_WARNING;
/* 1049 */         case 17: return GUILD_DISCOVERY_GRACE_PERIOD_FINAL_WARNING;
/* 1050 */         case 18: return THREAD_CREATED;
/* 1051 */         case 19: return REPLY;
/* 1052 */         case 20: return APPLICATION_COMMAND;
/* 1053 */         case 21: return THREAD_STARTER_MESSAGE;
/* 1054 */         case 22: return GUILD_INVITE_REMINDER;
/* 1055 */         case 23: return CONTEXT_MENU_COMMAND;
/* 1056 */         case 24: return AUTO_MODERATION_ACTION;
/* 1057 */         case 25: return ROLE_SUBSCRIPTION_PURCHASE;
/* 1058 */         case 26: return INTERACTION_PREMIUM_UPSELL;
/* 1059 */         case 27: return STAGE_START;
/* 1060 */         case 28: return STAGE_END;
/* 1061 */         case 29: return STAGE_SPEAKER;
/* 1062 */         case 31: return STAGE_TOPIC;
/* 1063 */         case 32: return GUILD_APPLICATION_PREMIUM_SUBSCRIPTION; }
/* 1064 */        return UNKNOWN;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/* 1071 */     return "Message{data=" + this.data + '}';
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\object\entity\Message.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */