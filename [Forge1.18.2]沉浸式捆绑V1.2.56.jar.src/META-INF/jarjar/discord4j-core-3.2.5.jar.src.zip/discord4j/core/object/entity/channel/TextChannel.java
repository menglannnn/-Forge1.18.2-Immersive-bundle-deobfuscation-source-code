/*     */ package discord4j.core.object.entity.channel;
/*     */ 
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.GatewayDiscordClient;
/*     */ import discord4j.core.object.PermissionOverwrite;
/*     */ import discord4j.core.object.entity.Member;
/*     */ import discord4j.core.object.entity.Message;
/*     */ import discord4j.core.retriever.EntityRetrievalStrategy;
/*     */ import discord4j.core.spec.InviteCreateSpec;
/*     */ import discord4j.core.spec.MessageCreateSpec;
/*     */ import discord4j.core.spec.TextChannelEditMono;
/*     */ import discord4j.core.spec.TextChannelEditSpec;
/*     */ import discord4j.core.spec.WebhookCreateSpec;
/*     */ import discord4j.core.spec.legacy.LegacyInviteCreateSpec;
/*     */ import discord4j.core.spec.legacy.LegacyMessageCreateSpec;
/*     */ import discord4j.core.spec.legacy.LegacyTextChannelEditSpec;
/*     */ import discord4j.core.spec.legacy.LegacyWebhookCreateSpec;
/*     */ import discord4j.core.util.EntityUtil;
/*     */ import discord4j.discordjson.json.ChannelData;
/*     */ import discord4j.rest.entity.RestChannel;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Supplier;
/*     */ import org.reactivestreams.Publisher;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class TextChannel
/*     */   extends BaseTopLevelGuildMessageChannel
/*     */ {
/*     */   public TextChannel(GatewayDiscordClient gateway, ChannelData data) {
/*  42 */     super(gateway, data);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getRateLimitPerUser() {
/*  53 */     return ((Integer)getData().rateLimitPerUser().toOptional()
/*  54 */       .orElseThrow(IllegalStateException::new)).intValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isNsfw() {
/*  63 */     return ((Boolean)getData().nsfw().toOptional().orElse(Boolean.valueOf(false))).booleanValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public Mono<TextChannel> edit(Consumer<? super LegacyTextChannelEditSpec> spec) {
/*  77 */     return Mono.defer(() -> {
/*     */           LegacyTextChannelEditSpec mutatedSpec = new LegacyTextChannelEditSpec();
/*     */ 
/*     */           
/*     */           spec.accept(mutatedSpec);
/*     */           
/*     */           return getClient().getRestClient().getChannelService().modifyChannel(getId().asLong(), mutatedSpec.asRequest(), mutatedSpec.getReason());
/*  84 */         }).map(bean -> EntityUtil.getChannel(getClient(), bean))
/*  85 */       .cast(TextChannel.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TextChannelEditMono edit() {
/*  96 */     return TextChannelEditMono.of(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<TextChannel> edit(TextChannelEditSpec spec) {
/* 107 */     Objects.requireNonNull(spec);
/* 108 */     return Mono.defer(() -> getClient().getRestClient().getChannelService().modifyChannel(getId().asLong(), spec.asRequest(), spec.reason()))
/*     */ 
/*     */       
/* 111 */       .map(bean -> EntityUtil.getChannel(getClient(), bean))
/* 112 */       .cast(TextChannel.class);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 117 */     return "TextChannel{} " + super.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\object\entity\channel\TextChannel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */