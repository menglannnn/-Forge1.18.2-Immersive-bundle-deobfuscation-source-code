/*     */ package discord4j.core.object.entity;
/*     */ 
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.GatewayDiscordClient;
/*     */ import discord4j.core.retriever.EntityRetrievalStrategy;
/*     */ import discord4j.core.spec.GuildStickerEditMono;
/*     */ import discord4j.core.spec.GuildStickerEditSpec;
/*     */ import discord4j.discordjson.Id;
/*     */ import discord4j.discordjson.json.StickerData;
/*     */ import java.util.Objects;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ public final class GuildSticker
/*     */   extends Sticker {
/*     */   private final long guildId;
/*     */   
/*     */   public GuildSticker(GatewayDiscordClient gateway, StickerData data) {
/*  19 */     super(gateway, data);
/*  20 */     this.guildId = ((Id)data.guildId().toOptional().get()).asLong();
/*     */   }
/*     */   
/*     */   public GuildSticker(GatewayDiscordClient gateway, StickerData data, long guildId) {
/*  24 */     super(gateway, data);
/*  25 */     this.guildId = guildId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Snowflake getGuildId() {
/*  34 */     return Snowflake.of(this.guildId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Guild> getGuild() {
/*  44 */     return getClient().getGuildById(getGuildId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Guild> getGuild(EntityRetrievalStrategy retrievalStrategy) {
/*  55 */     return getClient().withRetrievalStrategy(retrievalStrategy).getGuildById(getGuildId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GuildStickerEditMono edit() {
/*  66 */     return GuildStickerEditMono.of(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<GuildSticker> edit(GuildStickerEditSpec spec) {
/*  77 */     Objects.requireNonNull(spec);
/*  78 */     return Mono.defer(() -> this.gateway.getRestClient().getStickerService().modifyGuildSticker(getGuildId().asLong(), getId().asLong(), spec.asRequest(), spec.reason()))
/*     */ 
/*     */ 
/*     */       
/*  82 */       .map(data -> new GuildSticker(this.gateway, data, getGuildId().asLong()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Void> delete() {
/*  92 */     return delete((String)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Void> delete(@Nullable String reason) {
/* 103 */     return this.gateway.getRestClient().getStickerService()
/* 104 */       .deleteGuildSticker(getGuildId().asLong(), getId().asLong(), reason);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\object\entity\GuildSticker.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */