/*     */ package discord4j.core.object.entity;
/*     */ 
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.GatewayDiscordClient;
/*     */ import discord4j.discordjson.json.PartialStickerData;
/*     */ import discord4j.discordjson.json.StickerData;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Optional;
/*     */ import java.util.function.Supplier;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Sticker
/*     */   extends PartialSticker
/*     */ {
/*     */   public Sticker(GatewayDiscordClient gateway, StickerData data) {
/*  29 */     super(gateway, (PartialStickerData)data);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StickerData getData() {
/*  38 */     return (StickerData)getStickerData();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<Snowflake> getPackId() {
/*  47 */     return getData().packId().toOptional().map(Snowflake::of);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<String> getDescription() {
/*  56 */     return getData().description();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<String> getTags() {
/*  65 */     return getData().tags().toOptional()
/*  66 */       .map(tags -> tags.split(", "))
/*  67 */       .map(Arrays::asList)
/*  68 */       .orElse(Collections.emptyList());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAvailable() {
/*  77 */     return ((Boolean)getData().available().toOptional()
/*  78 */       .orElseThrow(IllegalStateException::new)).booleanValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Type getType() {
/*  87 */     return Type.of(getData().type());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum Format
/*     */   {
/* 101 */     UNKNOWN(0),
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 106 */     PNG(1),
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 111 */     APNG(2),
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 116 */     LOTTIE(3);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final int value;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Format(int value) {
/* 127 */       this.value = value;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int getValue() {
/* 136 */       return this.value;
/*     */     }
/*     */     
/*     */     public static Format of(int value) {
/* 140 */       switch (value) {
/*     */         case 1:
/* 142 */           return PNG;
/*     */         case 2:
/* 144 */           return APNG;
/*     */         case 3:
/* 146 */           return LOTTIE;
/*     */       } 
/* 148 */       return UNKNOWN;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum Type
/*     */   {
/* 163 */     UNKNOWN(0),
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 168 */     STANDARD(1),
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 173 */     GUILD(2);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final int value;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Type(int value) {
/* 184 */       this.value = value;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int getValue() {
/* 193 */       return this.value;
/*     */     }
/*     */     
/*     */     public static Type of(int value) {
/* 197 */       switch (value) {
/*     */         case 1:
/* 199 */           return STANDARD;
/*     */         case 2:
/* 201 */           return GUILD;
/*     */       } 
/* 203 */       return UNKNOWN;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\object\entity\Sticker.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */