/*     */ package discord4j.core.object.entity.channel;
/*     */ 
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.GatewayDiscordClient;
/*     */ import discord4j.core.object.entity.Message;
/*     */ import discord4j.core.retriever.EntityRetrievalStrategy;
/*     */ import discord4j.core.spec.MessageCreateSpec;
/*     */ import discord4j.core.spec.legacy.LegacyMessageCreateSpec;
/*     */ import discord4j.discordjson.json.ChannelData;
/*     */ import discord4j.discordjson.json.MessageData;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import discord4j.rest.util.AllowedMentions;
/*     */ import discord4j.rest.util.PaginationUtil;
/*     */ import java.time.Duration;
/*     */ import java.time.Instant;
/*     */ import java.time.format.DateTimeFormatter;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Function;
/*     */ import org.reactivestreams.Publisher;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.core.scheduler.Scheduler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class BaseMessageChannel
/*     */   extends BaseChannel
/*     */   implements MessageChannel
/*     */ {
/*     */   BaseMessageChannel(GatewayDiscordClient gateway, ChannelData data) {
/*  53 */     super(gateway, data);
/*     */   }
/*     */ 
/*     */   
/*     */   public final Optional<Snowflake> getLastMessageId() {
/*  58 */     return Possible.flatOpt(getData().lastMessageId()).map(Snowflake::of);
/*     */   }
/*     */ 
/*     */   
/*     */   public final Mono<Message> getLastMessage() {
/*  63 */     return Mono.justOrEmpty(getLastMessageId()).flatMap(id -> getClient().getMessageById(getId(), id));
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Message> getLastMessage(EntityRetrievalStrategy retrievalStrategy) {
/*  68 */     return Mono.justOrEmpty(getLastMessageId())
/*  69 */       .flatMap(id -> getClient().withRetrievalStrategy(retrievalStrategy).getMessageById(getId(), id));
/*     */   }
/*     */ 
/*     */   
/*     */   public final Optional<Instant> getLastPinTimestamp() {
/*  74 */     return Possible.flatOpt(getData().lastPinTimestamp())
/*  75 */       .map(timestamp -> (Instant)DateTimeFormatter.ISO_OFFSET_DATE_TIME.<Instant>parse(timestamp, Instant::from));
/*     */   }
/*     */ 
/*     */   
/*     */   public final Mono<Message> createMessage(Consumer<? super LegacyMessageCreateSpec> spec) {
/*  80 */     return Mono.defer(() -> {
/*     */           LegacyMessageCreateSpec mutatedSpec = new LegacyMessageCreateSpec();
/*     */           
/*     */           Objects.requireNonNull(mutatedSpec);
/*     */           
/*     */           getClient().getRestClient().getRestResources().getAllowedMentions().ifPresent(mutatedSpec::setAllowedMentions);
/*     */           
/*     */           spec.accept(mutatedSpec);
/*     */           return getRestChannel().createMessage(mutatedSpec.asRequest());
/*  89 */         }).map(data -> new Message(getClient(), data));
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Message> createMessage(MessageCreateSpec spec) {
/*  94 */     Objects.requireNonNull(spec);
/*  95 */     return Mono.defer(() -> {
/*     */           Objects.requireNonNull(spec);
/*     */ 
/*     */ 
/*     */           
/*     */           MessageCreateSpec actualSpec = getClient().getRestClient().getRestResources().getAllowedMentions().filter(()).map(spec::withAllowedMentions).orElse(spec);
/*     */ 
/*     */ 
/*     */           
/*     */           return getRestChannel().createMessage(actualSpec.asRequest());
/* 105 */         }).map(data -> new Message(getClient(), data));
/*     */   }
/*     */ 
/*     */   
/*     */   public final Mono<Void> type() {
/* 110 */     return getClient().getRestClient().getChannelService()
/* 111 */       .triggerTypingIndicator(getId().asLong())
/* 112 */       .then();
/*     */   }
/*     */ 
/*     */   
/*     */   public final Flux<Long> typeUntil(Publisher<?> until) {
/* 117 */     Scheduler delayScheduler = getClient().getCoreResources().getReactorResources().getTimerTaskScheduler();
/*     */ 
/*     */ 
/*     */     
/* 121 */     Flux<Long> repeatUntilOther = Flux.interval(Duration.ofSeconds(8L), delayScheduler).flatMap(tick -> type().thenReturn(Long.valueOf(tick.longValue() + 1L))).takeUntilOther(until);
/*     */ 
/*     */ 
/*     */     
/* 125 */     return type()
/* 126 */       .thenReturn(Long.valueOf(0L))
/* 127 */       .concatWith((Publisher)repeatUntilOther);
/*     */   }
/*     */ 
/*     */   
/*     */   public final Flux<Message> getMessagesBefore(Snowflake messageId) {
/* 132 */     Function<Map<String, Object>, Flux<MessageData>> doRequest = params -> getClient().getRestClient().getChannelService().getMessages(getId().asLong(), params);
/*     */ 
/*     */ 
/*     */     
/* 136 */     return PaginationUtil.paginateBefore(doRequest, data -> Snowflake.asLong(data.id()), messageId.asLong(), 100)
/* 137 */       .map(data -> new Message(getClient(), data));
/*     */   }
/*     */ 
/*     */   
/*     */   public final Flux<Message> getMessagesAfter(Snowflake messageId) {
/* 142 */     Function<Map<String, Object>, Flux<MessageData>> doRequest = params -> getClient().getRestClient().getChannelService().getMessages(getId().asLong(), params);
/*     */ 
/*     */ 
/*     */     
/* 146 */     return PaginationUtil.paginateAfter(doRequest, data -> Snowflake.asLong(data.id()), messageId.asLong(), 100)
/* 147 */       .map(data -> new Message(getClient(), data));
/*     */   }
/*     */ 
/*     */   
/*     */   public final Mono<Message> getMessageById(Snowflake id) {
/* 152 */     return getClient().getMessageById(getId(), id);
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Message> getMessageById(Snowflake id, EntityRetrievalStrategy retrievalStrategy) {
/* 157 */     return getClient().withRetrievalStrategy(retrievalStrategy).getMessageById(getId(), id);
/*     */   }
/*     */ 
/*     */   
/*     */   public final Flux<Message> getPinnedMessages() {
/* 162 */     return getClient().getRestClient().getChannelService()
/* 163 */       .getPinnedMessages(getId().asLong())
/* 164 */       .map(data -> new Message(getClient(), data));
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 169 */     return "BaseMessageChannel{} " + super.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\object\entity\channel\BaseMessageChannel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */