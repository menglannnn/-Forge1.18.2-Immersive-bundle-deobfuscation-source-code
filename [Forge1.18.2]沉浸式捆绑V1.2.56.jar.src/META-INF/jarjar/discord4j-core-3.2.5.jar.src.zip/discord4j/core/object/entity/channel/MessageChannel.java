/*     */ package discord4j.core.object.entity.channel;
/*     */ 
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.object.entity.Message;
/*     */ import discord4j.core.retriever.EntityRetrievalStrategy;
/*     */ import discord4j.core.spec.EmbedCreateSpec;
/*     */ import discord4j.core.spec.MessageCreateMono;
/*     */ import discord4j.core.spec.MessageCreateSpec;
/*     */ import discord4j.core.spec.legacy.LegacyEmbedCreateSpec;
/*     */ import discord4j.core.spec.legacy.LegacyMessageCreateSpec;
/*     */ import java.time.Instant;
/*     */ import java.util.Optional;
/*     */ import java.util.function.Consumer;
/*     */ import org.reactivestreams.Publisher;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface MessageChannel
/*     */   extends Channel
/*     */ {
/*     */   default MessageCreateMono createMessage(String message) {
/* 104 */     return MessageCreateMono.of(this).withContent(message);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MessageCreateMono createMessage(EmbedCreateSpec... embeds) {
/* 117 */     return MessageCreateMono.of(this).withEmbeds(embeds);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   default Mono<Message> createEmbed(Consumer<? super LegacyEmbedCreateSpec> spec) {
/* 130 */     return createMessage(messageSpec -> messageSpec.setEmbed(spec));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   default MessageCreateMono createEmbed(EmbedCreateSpec embed) {
/* 145 */     return MessageCreateMono.of(this).withEmbeds(new EmbedCreateSpec[] { embed });
/*     */   }
/*     */   
/*     */   Optional<Snowflake> getLastMessageId();
/*     */   
/*     */   Mono<Message> getLastMessage();
/*     */   
/*     */   Mono<Message> getLastMessage(EntityRetrievalStrategy paramEntityRetrievalStrategy);
/*     */   
/*     */   Optional<Instant> getLastPinTimestamp();
/*     */   
/*     */   @Deprecated
/*     */   Mono<Message> createMessage(Consumer<? super LegacyMessageCreateSpec> paramConsumer);
/*     */   
/*     */   Mono<Message> createMessage(MessageCreateSpec paramMessageCreateSpec);
/*     */   
/*     */   Mono<Void> type();
/*     */   
/*     */   Flux<Long> typeUntil(Publisher<?> paramPublisher);
/*     */   
/*     */   Flux<Message> getMessagesBefore(Snowflake paramSnowflake);
/*     */   
/*     */   Flux<Message> getMessagesAfter(Snowflake paramSnowflake);
/*     */   
/*     */   Mono<Message> getMessageById(Snowflake paramSnowflake);
/*     */   
/*     */   Mono<Message> getMessageById(Snowflake paramSnowflake, EntityRetrievalStrategy paramEntityRetrievalStrategy);
/*     */   
/*     */   Flux<Message> getPinnedMessages();
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\object\entity\channel\MessageChannel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */