/*     */ package discord4j.core.object.entity;
/*     */ 
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.GatewayDiscordClient;
/*     */ import discord4j.core.object.RoleTags;
/*     */ import discord4j.core.retriever.EntityRetrievalStrategy;
/*     */ import discord4j.core.spec.RoleEditMono;
/*     */ import discord4j.core.spec.RoleEditSpec;
/*     */ import discord4j.core.spec.legacy.LegacyRoleEditSpec;
/*     */ import discord4j.core.util.EntityUtil;
/*     */ import discord4j.core.util.ImageUtil;
/*     */ import discord4j.core.util.OrderUtil;
/*     */ import discord4j.discordjson.json.RoleData;
/*     */ import discord4j.discordjson.json.RoleTagsData;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import discord4j.rest.RestClient;
/*     */ import discord4j.rest.entity.RestRole;
/*     */ import discord4j.rest.util.Color;
/*     */ import discord4j.rest.util.Image;
/*     */ import discord4j.rest.util.PermissionSet;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import java.util.function.Consumer;
/*     */ import org.reactivestreams.Publisher;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Role
/*     */   implements Entity
/*     */ {
/*  51 */   public static final Color DEFAULT_COLOR = Color.of(0);
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String ICON_IMAGE_PATH = "role-icons/%s/%s";
/*     */ 
/*     */ 
/*     */   
/*     */   private final GatewayDiscordClient gateway;
/*     */ 
/*     */ 
/*     */   
/*     */   private final RoleData data;
/*     */ 
/*     */ 
/*     */   
/*     */   private final RestRole rest;
/*     */ 
/*     */ 
/*     */   
/*     */   private final long guildId;
/*     */ 
/*     */ 
/*     */   
/*     */   public Role(GatewayDiscordClient gateway, RoleData data, long guildId) {
/*  76 */     this.gateway = Objects.<GatewayDiscordClient>requireNonNull(gateway);
/*  77 */     this.data = Objects.<RoleData>requireNonNull(data);
/*  78 */     this.rest = RestRole.create((RestClient)gateway.rest(), Snowflake.of(guildId), Snowflake.of(data.id()));
/*  79 */     this.guildId = guildId;
/*     */   }
/*     */ 
/*     */   
/*     */   public GatewayDiscordClient getClient() {
/*  84 */     return this.gateway;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RoleData getData() {
/*  93 */     return this.data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getRawPosition() {
/* 102 */     return this.data.position();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Integer> getPosition() {
/* 132 */     return getGuild()
/* 133 */       .flatMapMany(Guild::getRoles)
/* 134 */       .transform(OrderUtil::orderRoles)
/* 135 */       .collectList()
/* 136 */       .map(roles -> Integer.valueOf(roles.indexOf(this)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Integer> getPosition(EntityRetrievalStrategy retrievalStrategy) {
/* 168 */     return getGuild(retrievalStrategy)
/* 169 */       .flatMapMany(guild -> guild.getRoles(retrievalStrategy))
/* 170 */       .transform(OrderUtil::orderRoles)
/* 171 */       .collectList()
/* 172 */       .map(roles -> Integer.valueOf(roles.indexOf(this)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<String> getIconUrl(Image.Format format) {
/* 182 */     return Possible.flatOpt(this.data.icon())
/* 183 */       .map(icon -> ImageUtil.getUrl(String.format("role-icons/%s/%s", new Object[] { getId().asString(), icon }), format));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<String> getUnicodeEmoji() {
/* 192 */     return Possible.flatOpt(this.data.unicodeEmoji());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 201 */     return this.data.name();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Color getColor() {
/* 210 */     return Color.of(this.data.color());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isHoisted() {
/* 219 */     return this.data.hoist();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PermissionSet getPermissions() {
/* 228 */     return PermissionSet.of(this.data.permissions());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isManaged() {
/* 237 */     return this.data.managed();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isMentionable() {
/* 246 */     return this.data.mentionable();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEveryone() {
/* 255 */     return getId().equals(getGuildId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Snowflake getGuildId() {
/* 264 */     return Snowflake.of(this.guildId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Guild> getGuild() {
/* 274 */     return this.gateway.getGuildById(getGuildId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Guild> getGuild(EntityRetrievalStrategy retrievalStrategy) {
/* 285 */     return this.gateway.withRetrievalStrategy(retrievalStrategy).getGuildById(getGuildId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getMention() {
/* 295 */     if (isEveryone()) {
/* 296 */       return "@everyone";
/*     */     }
/* 298 */     return "<@&" + getId().asString() + ">";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<RoleTags> getTags() {
/* 307 */     return this.data.tags().toOptional().map(data -> new RoleTags(this.gateway, data));
/*     */   }
/*     */ 
/*     */   
/*     */   public Snowflake getId() {
/* 312 */     return Snowflake.of(this.data.id());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public Mono<Role> edit(Consumer<? super LegacyRoleEditSpec> spec) {
/* 325 */     return Mono.defer(() -> {
/*     */           LegacyRoleEditSpec mutatedSpec = new LegacyRoleEditSpec();
/*     */           spec.accept(mutatedSpec);
/*     */           return this.rest.edit(mutatedSpec.asRequest(), mutatedSpec.getReason()).map(());
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RoleEditMono edit() {
/* 342 */     return RoleEditMono.of(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Role> edit(RoleEditSpec spec) {
/* 353 */     Objects.requireNonNull(spec);
/* 354 */     return Mono.defer(() -> this.rest.edit(spec.asRequest(), spec.reason()).map(()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Void> delete() {
/* 365 */     return delete(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Void> delete(@Nullable String reason) {
/* 376 */     return this.rest.delete(reason);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Flux<Role> changePosition(int position) {
/* 387 */     return this.rest.changePosition(position)
/* 388 */       .map(data -> new Role(this.gateway, data, getGuildId().asLong()));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(@Nullable Object obj) {
/* 393 */     return EntityUtil.equals(this, obj);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 398 */     return EntityUtil.hashCode(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 403 */     return "Role{data=" + this.data + ", guildId=" + this.guildId + '}';
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\object\entity\Role.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */