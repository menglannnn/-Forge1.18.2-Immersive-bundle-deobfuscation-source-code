/*     */ package discord4j.core.object.entity;
/*     */ 
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.GatewayDiscordClient;
/*     */ import discord4j.core.object.ScheduledEventEntityMetadata;
/*     */ import discord4j.core.object.ScheduledEventUser;
/*     */ import discord4j.core.object.entity.channel.GuildChannel;
/*     */ import discord4j.core.spec.ScheduledEventEditMono;
/*     */ import discord4j.core.spec.ScheduledEventEditSpec;
/*     */ import discord4j.discordjson.json.GuildScheduledEventData;
/*     */ import discord4j.discordjson.json.GuildScheduledEventEntityMetadataData;
/*     */ import discord4j.discordjson.json.GuildScheduledEventUserData;
/*     */ import java.time.Instant;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ScheduledEvent
/*     */   implements Entity
/*     */ {
/*     */   private final GatewayDiscordClient gateway;
/*     */   private final GuildScheduledEventData data;
/*     */   
/*     */   public ScheduledEvent(GatewayDiscordClient gateway, GuildScheduledEventData data) {
/*  62 */     this.gateway = Objects.<GatewayDiscordClient>requireNonNull(gateway);
/*  63 */     this.data = Objects.<GuildScheduledEventData>requireNonNull(data);
/*     */   }
/*     */ 
/*     */   
/*     */   public GatewayDiscordClient getClient() {
/*  68 */     return this.gateway;
/*     */   }
/*     */ 
/*     */   
/*     */   public Snowflake getId() {
/*  73 */     return Snowflake.of(this.data.id());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GuildScheduledEventData getData() {
/*  82 */     return this.data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Snowflake getGuildId() {
/*  91 */     return Snowflake.of(this.data.guildId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<Snowflake> getCreatorId() {
/* 100 */     return this.data.creatorId().map(Snowflake::of);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Member> getCreator() {
/* 111 */     return Mono.justOrEmpty(getCreatorId()).flatMap(id -> this.gateway.getMemberById(getGuildId(), id));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<Snowflake> getChannelId() {
/* 120 */     return this.data.channelId().map(Snowflake::of);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<GuildChannel> getChannel() {
/* 134 */     Objects.requireNonNull(this.gateway); return Mono.justOrEmpty(getChannelId()).flatMap(this.gateway::getChannelById)
/* 135 */       .ofType(GuildChannel.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Instant getStartTime() {
/* 144 */     return this.data.scheduledStartTime();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<Instant> getEndTime() {
/* 155 */     return this.data.scheduledEndTime();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PrivacyLevel getPrivacyLevel() {
/* 164 */     return PrivacyLevel.of(this.data.privacyLevel());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Status getStatus() {
/* 173 */     return Status.of(this.data.status());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EntityType getEntityType() {
/* 182 */     return EntityType.of(this.data.entityType());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<Snowflake> getEntityId() {
/* 194 */     return getData().entityId().map(Snowflake::of);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<ScheduledEventEntityMetadata> getEntityMetadata() {
/* 205 */     return this.data.entityMetadata().map(data -> new ScheduledEventEntityMetadata(this.gateway, data));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<String> getLocation() {
/* 216 */     return getEntityMetadata().flatMap(ScheduledEventEntityMetadata::getLocation);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<Integer> getSubscribedUserCount() {
/* 225 */     return this.data.userCount().toOptional();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Flux<ScheduledEventUser> getSubscribedUsers(boolean withMemberData) {
/* 236 */     Map<String, Object> queryParams = new HashMap<>();
/* 237 */     queryParams.put("with_member", Boolean.valueOf(withMemberData));
/*     */     
/* 239 */     return this.gateway.getRestClient().getGuildService().getScheduledEventUsers(getGuildId().asLong(), getId().asLong(), queryParams)
/* 240 */       .map(data -> new ScheduledEventUser(this.gateway, data, getGuildId()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Flux<ScheduledEventUser> getSubscribedUsersBefore(Snowflake userId, boolean withMemberData) {
/* 252 */     return this.gateway.getRestClient().getScheduledEventById(getGuildId(), getId())
/* 253 */       .getSubscribedUsersBefore(userId, Boolean.valueOf(withMemberData))
/* 254 */       .map(data -> new ScheduledEventUser(this.gateway, data, getGuildId()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Flux<ScheduledEventUser> getSubscribedUsersAfter(Snowflake userId, boolean withMemberData) {
/* 266 */     return this.gateway.getRestClient().getScheduledEventById(getGuildId(), getId())
/* 267 */       .getSubscribedUsersAfter(userId, Boolean.valueOf(withMemberData))
/* 268 */       .map(data -> new ScheduledEventUser(this.gateway, data, getGuildId()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ScheduledEventEditMono edit() {
/* 278 */     return ScheduledEventEditMono.of(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<ScheduledEvent> edit(ScheduledEventEditSpec spec) {
/* 289 */     Objects.requireNonNull(spec);
/* 290 */     return Mono.defer(() -> this.gateway.getRestClient().getScheduledEventById(getGuildId(), getId()).edit(spec.asRequest(), spec.reason()).map(()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Void> delete(@Nullable String reason) {
/* 301 */     return this.gateway.getRestClient().getScheduledEventById(getGuildId(), getId())
/* 302 */       .delete(reason);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Void> delete() {
/* 311 */     return delete(null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public enum PrivacyLevel
/*     */   {
/* 318 */     UNKNOWN(-1),
/* 319 */     GUILD_ONLY(2);
/*     */     
/*     */     private final int value;
/*     */     
/*     */     PrivacyLevel(int value) {
/* 324 */       this.value = value;
/*     */     }
/*     */     
/*     */     public int getValue() {
/* 328 */       return this.value;
/*     */     }
/*     */     
/*     */     public static PrivacyLevel of(int value) {
/* 332 */       switch (value) {
/*     */         case 2:
/* 334 */           return GUILD_ONLY;
/*     */       } 
/* 336 */       return UNKNOWN;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum EntityType
/*     */   {
/* 345 */     UNKNOWN(-1),
/* 346 */     STAGE_INSTANCE(1),
/* 347 */     VOICE(2),
/* 348 */     EXTERNAL(3);
/*     */     
/*     */     private final int value;
/*     */     
/*     */     EntityType(int value) {
/* 353 */       this.value = value;
/*     */     }
/*     */     
/*     */     public int getValue() {
/* 357 */       return this.value;
/*     */     }
/*     */     
/*     */     public static EntityType of(int value) {
/* 361 */       switch (value) {
/*     */         case 1:
/* 363 */           return STAGE_INSTANCE;
/*     */         case 2:
/* 365 */           return VOICE;
/*     */         case 3:
/* 367 */           return EXTERNAL;
/*     */       } 
/* 369 */       return UNKNOWN;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum Status
/*     */   {
/* 378 */     UNKNOWN(-1),
/* 379 */     SCHEDULED(1),
/* 380 */     ACTIVE(2),
/* 381 */     COMPLETED(3),
/* 382 */     CANCELED(4);
/*     */     
/*     */     private final int value;
/*     */     
/*     */     Status(int value) {
/* 387 */       this.value = value;
/*     */     }
/*     */     
/*     */     public int getValue() {
/* 391 */       return this.value;
/*     */     }
/*     */     
/*     */     public static Status of(int value) {
/* 395 */       switch (value) {
/*     */         case 1:
/* 397 */           return SCHEDULED;
/*     */         case 2:
/* 399 */           return ACTIVE;
/*     */         case 3:
/* 401 */           return COMPLETED;
/*     */         case 4:
/* 403 */           return CANCELED;
/*     */       } 
/* 405 */       return UNKNOWN;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\object\entity\ScheduledEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */