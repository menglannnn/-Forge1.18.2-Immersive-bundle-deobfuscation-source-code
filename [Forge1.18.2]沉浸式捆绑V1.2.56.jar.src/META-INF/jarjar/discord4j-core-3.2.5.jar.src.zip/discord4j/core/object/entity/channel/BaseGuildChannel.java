/*     */ package discord4j.core.object.entity.channel;
/*     */ 
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.GatewayDiscordClient;
/*     */ import discord4j.core.object.ExtendedPermissionOverwrite;
/*     */ import discord4j.core.object.PermissionOverwrite;
/*     */ import discord4j.core.object.entity.Guild;
/*     */ import discord4j.core.object.entity.Member;
/*     */ import discord4j.core.retriever.EntityRetrievalStrategy;
/*     */ import discord4j.core.util.OrderUtil;
/*     */ import discord4j.core.util.PermissionUtil;
/*     */ import discord4j.discordjson.json.ChannelData;
/*     */ import discord4j.discordjson.json.ImmutablePermissionsEditRequest;
/*     */ import discord4j.discordjson.json.OverwriteData;
/*     */ import discord4j.discordjson.json.PermissionsEditRequest;
/*     */ import discord4j.rest.util.PermissionSet;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import java.util.Set;
/*     */ import java.util.function.Supplier;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.stream.Stream;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class BaseGuildChannel
/*     */   extends BaseChannel
/*     */   implements GuildChannel
/*     */ {
/*     */   BaseGuildChannel(GatewayDiscordClient gateway, ChannelData data) {
/*  51 */     super(gateway, data);
/*     */   }
/*     */ 
/*     */   
/*     */   public final Snowflake getGuildId() {
/*  56 */     return (Snowflake)getData().guildId().toOptional()
/*  57 */       .map(Snowflake::of)
/*  58 */       .orElseThrow(IllegalStateException::new);
/*     */   }
/*     */ 
/*     */   
/*     */   public final Mono<Guild> getGuild() {
/*  63 */     return getClient().getGuildById(getGuildId());
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Guild> getGuild(EntityRetrievalStrategy retrievalStrategy) {
/*  68 */     return getClient().withRetrievalStrategy(retrievalStrategy).getGuildById(getGuildId());
/*     */   }
/*     */ 
/*     */   
/*     */   public final Set<ExtendedPermissionOverwrite> getPermissionOverwrites() {
/*  73 */     return getData().permissionOverwrites().toOptional()
/*  74 */       .map(permissionOverwrites -> {
/*     */           long guildId = getGuildId().asLong();
/*     */ 
/*     */           
/*     */           long channelId = getId().asLong();
/*     */           
/*     */           return (Set)permissionOverwrites.stream().map(()).collect(Collectors.toSet());
/*  81 */         }).orElse(Collections.emptySet());
/*     */   }
/*     */ 
/*     */   
/*     */   public Optional<ExtendedPermissionOverwrite> getOverwriteForMember(Snowflake memberId) {
/*  86 */     return getPermissionOverwrites().stream()
/*  87 */       .filter(overwrite -> { Objects.requireNonNull(memberId); return ((Boolean)overwrite.getMemberId().map(memberId::equals).orElse(Boolean.valueOf(false))).booleanValue();
/*  88 */         }).findFirst();
/*     */   }
/*     */ 
/*     */   
/*     */   public Optional<ExtendedPermissionOverwrite> getOverwriteForRole(Snowflake roleId) {
/*  93 */     return getPermissionOverwrites().stream()
/*  94 */       .filter(overwrite -> { Objects.requireNonNull(roleId); return ((Boolean)overwrite.getRoleId().map(roleId::equals).orElse(Boolean.valueOf(false))).booleanValue();
/*  95 */         }).findFirst();
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<PermissionSet> getEffectivePermissions(Snowflake memberId) {
/* 100 */     return getClient().getMemberById(getGuildId(), memberId)
/* 101 */       .flatMap(this::getEffectivePermissions);
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<PermissionSet> getEffectivePermissions(Member member) {
/* 106 */     return member.getBasePermissions().map(basePerms -> {
/*     */           PermissionOverwrite everyoneOverwrite = (PermissionOverwrite)getOverwriteForRole(getGuildId()).orElse(null);
/*     */           List<PermissionOverwrite> roleOverwrites = (List<PermissionOverwrite>)member.getRoleIds().stream().map(this::getOverwriteForRole).flatMap(()).collect(Collectors.toList());
/*     */           PermissionOverwrite memberOverwrite = (PermissionOverwrite)getOverwriteForMember(member.getId()).orElse(null);
/*     */           return PermissionUtil.computePermissions(basePerms, everyoneOverwrite, roleOverwrites, memberOverwrite);
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getName() {
/* 121 */     return (String)getData().name().toOptional()
/* 122 */       .orElseThrow(IllegalStateException::new);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getRawPosition() {
/* 127 */     return ((Integer)getData().position().toOptional()
/* 128 */       .orElseThrow(IllegalStateException::new)).intValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public final Mono<Integer> getPosition() {
/* 133 */     return getGuild()
/* 134 */       .flatMapMany(Guild::getChannels)
/* 135 */       .transform(OrderUtil::orderGuildChannels)
/* 136 */       .collectList()
/* 137 */       .map(channels -> Integer.valueOf(channels.indexOf(this)));
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> addMemberOverwrite(Snowflake memberId, PermissionOverwrite overwrite, @Nullable String reason) {
/* 142 */     PermissionSet allow = overwrite.getAllowed();
/* 143 */     PermissionSet deny = overwrite.getDenied();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 148 */     ImmutablePermissionsEditRequest immutablePermissionsEditRequest = PermissionsEditRequest.builder().allow(allow.getRawValue()).deny(deny.getRawValue()).type(PermissionOverwrite.Type.MEMBER.getValue()).build();
/*     */     
/* 150 */     return getClient().getRestClient().getChannelService()
/* 151 */       .editChannelPermissions(getId().asLong(), memberId.asLong(), (PermissionsEditRequest)immutablePermissionsEditRequest, reason);
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> addRoleOverwrite(Snowflake roleId, PermissionOverwrite overwrite, @Nullable String reason) {
/* 156 */     PermissionSet allow = overwrite.getAllowed();
/* 157 */     PermissionSet deny = overwrite.getDenied();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 162 */     ImmutablePermissionsEditRequest immutablePermissionsEditRequest = PermissionsEditRequest.builder().allow(allow.getRawValue()).deny(deny.getRawValue()).type(PermissionOverwrite.Type.ROLE.getValue()).build();
/*     */     
/* 164 */     return getClient().getRestClient().getChannelService()
/* 165 */       .editChannelPermissions(getId().asLong(), roleId.asLong(), (PermissionsEditRequest)immutablePermissionsEditRequest, reason);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 170 */     return "BaseGuildChannel{} " + super.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\object\entity\channel\BaseGuildChannel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */