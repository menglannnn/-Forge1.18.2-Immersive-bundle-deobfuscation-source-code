/*    */ package discord4j.core.object.entity.channel;
/*    */ 
/*    */ import discord4j.common.util.Snowflake;
/*    */ import discord4j.core.GatewayDiscordClient;
/*    */ import discord4j.core.object.ExtendedInvite;
/*    */ import discord4j.core.retriever.EntityRetrievalStrategy;
/*    */ import discord4j.core.spec.InviteCreateSpec;
/*    */ import discord4j.core.spec.legacy.LegacyInviteCreateSpec;
/*    */ import discord4j.discordjson.json.ChannelData;
/*    */ import discord4j.discordjson.json.InviteData;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import java.util.Objects;
/*    */ import java.util.Optional;
/*    */ import java.util.function.Consumer;
/*    */ import java.util.function.Supplier;
/*    */ import reactor.core.publisher.Flux;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class BaseCategorizableChannel
/*    */   extends BaseGuildChannel
/*    */   implements CategorizableChannel
/*    */ {
/*    */   BaseCategorizableChannel(GatewayDiscordClient gateway, ChannelData data) {
/* 37 */     super(gateway, data);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getRateLimitPerUser() {
/* 48 */     return ((Integer)getData().rateLimitPerUser().toOptional()
/* 49 */       .orElseThrow(IllegalStateException::new)).intValue();
/*    */   }
/*    */ 
/*    */   
/*    */   public Optional<Snowflake> getCategoryId() {
/* 54 */     return Possible.flatOpt(getData().parentId())
/* 55 */       .map(Snowflake::of);
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<Category> getCategory() {
/* 60 */     Objects.requireNonNull(getClient()); return Mono.justOrEmpty(getCategoryId()).flatMap(getClient()::getChannelById).cast(Category.class);
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<Category> getCategory(EntityRetrievalStrategy retrievalStrategy) {
/* 65 */     return Mono.justOrEmpty(getCategoryId())
/* 66 */       .flatMap(id -> getClient().withRetrievalStrategy(retrievalStrategy).getChannelById(id))
/* 67 */       .cast(Category.class);
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<ExtendedInvite> createInvite(Consumer<? super LegacyInviteCreateSpec> spec) {
/* 72 */     return Mono.defer(() -> {
/*    */           LegacyInviteCreateSpec mutatedSpec = new LegacyInviteCreateSpec();
/*    */ 
/*    */           
/*    */           spec.accept(mutatedSpec);
/*    */           
/*    */           return getClient().getRestClient().getChannelService().createChannelInvite(getId().asLong(), mutatedSpec.asRequest(), mutatedSpec.getReason());
/* 79 */         }).map(data -> new ExtendedInvite(getClient(), data));
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<ExtendedInvite> createInvite(InviteCreateSpec spec) {
/* 84 */     Objects.requireNonNull(spec);
/* 85 */     return Mono.defer(() -> getClient().getRestClient().getChannelService().createChannelInvite(getId().asLong(), spec.asRequest(), spec.reason()))
/*    */ 
/*    */       
/* 88 */       .map(data -> new ExtendedInvite(getClient(), data));
/*    */   }
/*    */ 
/*    */   
/*    */   public Flux<ExtendedInvite> getInvites() {
/* 93 */     return getClient().getRestClient().getChannelService()
/* 94 */       .getChannelInvites(getId().asLong())
/* 95 */       .map(data -> new ExtendedInvite(getClient(), data));
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\object\entity\channel\BaseCategorizableChannel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */