/*     */ package discord4j.core.object.entity;
/*     */ 
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.GatewayDiscordClient;
/*     */ import discord4j.core.retriever.EntityRetrievalStrategy;
/*     */ import discord4j.core.util.EntityUtil;
/*     */ import discord4j.core.util.ImageUtil;
/*     */ import discord4j.discordjson.json.ApplicationInfoData;
/*     */ import discord4j.discordjson.json.ApplicationTeamData;
/*     */ import discord4j.rest.util.Image;
/*     */ import java.util.EnumSet;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ApplicationInfo
/*     */   implements Entity
/*     */ {
/*     */   private static final String ICON_IMAGE_PATH = "app-icons/%s/%s";
/*     */   private final GatewayDiscordClient gateway;
/*     */   private final ApplicationInfoData data;
/*     */   
/*     */   public ApplicationInfo(GatewayDiscordClient gateway, ApplicationInfoData data) {
/*  54 */     this.gateway = Objects.<GatewayDiscordClient>requireNonNull(gateway);
/*  55 */     this.data = Objects.<ApplicationInfoData>requireNonNull(data);
/*     */   }
/*     */ 
/*     */   
/*     */   public GatewayDiscordClient getClient() {
/*  60 */     return this.gateway;
/*     */   }
/*     */ 
/*     */   
/*     */   public Snowflake getId() {
/*  65 */     return Snowflake.of(this.data.id());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ApplicationInfoData getData() {
/*  74 */     return this.data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/*  83 */     return this.data.name();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<String> getIconUrl(Image.Format format) {
/*  93 */     return this.data.icon()
/*  94 */       .map(icon -> ImageUtil.getUrl(String.format("app-icons/%s/%s", new Object[] { getId().asString(), icon }), format));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Image> getIcon(Image.Format format) {
/* 105 */     return Mono.justOrEmpty(getIconUrl(format)).flatMap(Image::ofUrl);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDescription() {
/* 114 */     return this.data.description();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isPublic() {
/* 123 */     return this.data.botPublic();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean requireCodeGrant() {
/* 133 */     return this.data.botRequireCodeGrant();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<String> getTermsOfServiceUrl() {
/* 142 */     return this.data.termsOfServiceUrl().toOptional();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<String> getPrivacyPolicyUrl() {
/* 151 */     return this.data.privacyPolicyUrl().toOptional();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Snowflake getOwnerId() {
/* 160 */     return Snowflake.of(this.data.owner().id());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<User> getOwner() {
/* 170 */     return this.gateway.getUserById(getOwnerId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<User> getOwner(EntityRetrievalStrategy retrievalStrategy) {
/* 181 */     return this.gateway.withRetrievalStrategy(retrievalStrategy).getUserById(getOwnerId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<ApplicationTeam> getTeam() {
/* 190 */     return this.data.team().map(data -> new ApplicationTeam(this.gateway, data));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EnumSet<Flag> getFlags() {
/* 199 */     int publicFlags = ((Integer)this.data.flags().toOptional().orElse(Integer.valueOf(0))).intValue();
/* 200 */     if (publicFlags != 0) {
/* 201 */       return Flag.of(publicFlags);
/*     */     }
/* 203 */     return EnumSet.noneOf(Flag.class);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(@Nullable Object obj) {
/* 208 */     return EntityUtil.equals(this, obj);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 213 */     return EntityUtil.hashCode(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum Flag
/*     */   {
/* 223 */     APPLICATION_AUTO_MODERATION_RULE_CREATE_BADGE(6),
/* 224 */     GATEWAY_PRESENCE(12),
/* 225 */     GATEWAY_PRESENCE_LIMITED(13),
/* 226 */     GATEWAY_GUILD_MEMBERS(14),
/* 227 */     GATEWAY_GUILD_MEMBERS_LIMITED(15),
/* 228 */     VERIFICATION_PENDING_GUILD_LIMIT(16),
/* 229 */     EMBEDDED(17),
/* 230 */     GATEWAY_MESSAGE_CONTENT(18),
/* 231 */     GATEWAY_MESSAGE_CONTENT_LIMITED(19),
/* 232 */     APPLICATION_COMMAND_BADGE(23);
/*     */ 
/*     */ 
/*     */     
/*     */     private final int value;
/*     */ 
/*     */     
/*     */     private final int flag;
/*     */ 
/*     */ 
/*     */     
/*     */     Flag(int value) {
/* 244 */       this.value = value;
/* 245 */       this.flag = 1 << value;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int getValue() {
/* 254 */       return this.value;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int getFlag() {
/* 263 */       return this.flag;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static EnumSet<Flag> of(int value) {
/* 274 */       EnumSet<Flag> flagSet = EnumSet.noneOf(Flag.class);
/* 275 */       for (Flag flag : values()) {
/* 276 */         long flagValue = flag.getFlag();
/* 277 */         if ((flagValue & value) == flagValue) {
/* 278 */           flagSet.add(flag);
/*     */         }
/*     */       } 
/* 281 */       return flagSet;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 287 */     return "ApplicationInfo{data=" + this.data + '}';
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\object\entity\ApplicationInfo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */