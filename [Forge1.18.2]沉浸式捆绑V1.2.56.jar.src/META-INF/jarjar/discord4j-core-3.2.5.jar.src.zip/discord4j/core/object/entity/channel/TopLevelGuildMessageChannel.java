/*    */ package discord4j.core.object.entity.channel;
/*    */ 
/*    */ import discord4j.core.object.entity.Webhook;
/*    */ import discord4j.core.spec.WebhookCreateMono;
/*    */ import discord4j.core.spec.WebhookCreateSpec;
/*    */ import discord4j.core.spec.legacy.LegacyWebhookCreateSpec;
/*    */ import java.util.Optional;
/*    */ import java.util.function.Consumer;
/*    */ import reactor.core.publisher.Flux;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface TopLevelGuildMessageChannel
/*    */   extends CategorizableChannel, GuildMessageChannel
/*    */ {
/*    */   Optional<String> getTopic();
/*    */   
/*    */   Mono<Webhook> createWebhook(Consumer<? super LegacyWebhookCreateSpec> paramConsumer);
/*    */   
/*    */   default WebhookCreateMono createWebhook(String name) {
/* 40 */     return super.createWebhook(name);
/*    */   }
/*    */   
/*    */   Mono<Webhook> createWebhook(WebhookCreateSpec paramWebhookCreateSpec);
/*    */   
/*    */   Flux<Webhook> getWebhooks();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\object\entity\channel\TopLevelGuildMessageChannel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */