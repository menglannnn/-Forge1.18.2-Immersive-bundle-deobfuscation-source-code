/*     */ package discord4j.core.object.entity;
/*     */ 
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.GatewayDiscordClient;
/*     */ import discord4j.core.retriever.EntityRetrievalStrategy;
/*     */ import discord4j.core.spec.GuildEmojiEditMono;
/*     */ import discord4j.core.spec.GuildEmojiEditSpec;
/*     */ import discord4j.core.spec.legacy.LegacyGuildEmojiEditSpec;
/*     */ import discord4j.core.util.EntityUtil;
/*     */ import discord4j.core.util.ImageUtil;
/*     */ import discord4j.discordjson.json.EmojiData;
/*     */ import discord4j.discordjson.json.UserData;
/*     */ import discord4j.rest.util.Image;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Supplier;
/*     */ import java.util.stream.Collectors;
/*     */ import org.reactivestreams.Publisher;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class GuildEmoji
/*     */   implements Entity
/*     */ {
/*     */   private static final String EMOJI_IMAGE_PATH = "emojis/%s";
/*     */   private final GatewayDiscordClient gateway;
/*     */   private final EmojiData data;
/*     */   private final long guildId;
/*     */   
/*     */   public GuildEmoji(GatewayDiscordClient gateway, EmojiData data, long guildId) {
/*  70 */     this.gateway = Objects.<GatewayDiscordClient>requireNonNull(gateway);
/*  71 */     this.data = Objects.<EmojiData>requireNonNull(data);
/*  72 */     this.guildId = guildId;
/*     */   }
/*     */ 
/*     */   
/*     */   public GatewayDiscordClient getClient() {
/*  77 */     return this.gateway;
/*     */   }
/*     */ 
/*     */   
/*     */   public Snowflake getId() {
/*  82 */     return (Snowflake)this.data.id()
/*  83 */       .map(Snowflake::of)
/*  84 */       .orElseThrow(IllegalStateException::new);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EmojiData getData() {
/*  93 */     return this.data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 102 */     return (String)this.data.name()
/* 103 */       .orElseThrow(IllegalStateException::new);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<Snowflake> getRoleIds() {
/* 112 */     return (Set<Snowflake>)this.data.roles().toOptional()
/* 113 */       .map(roles -> (Set)roles.stream().map(Snowflake::of).collect(Collectors.toSet()))
/*     */ 
/*     */       
/* 116 */       .orElseThrow(IllegalStateException::new);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Flux<Role> getRoles() {
/* 129 */     return Flux.fromIterable(getRoleIds()).flatMap(id -> this.gateway.getRoleById(getGuildId(), id));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Flux<Role> getRoles(EntityRetrievalStrategy retrievalStrategy) {
/* 143 */     return Flux.fromIterable(getRoleIds())
/* 144 */       .flatMap(id -> this.gateway.withRetrievalStrategy(retrievalStrategy).getRoleById(getGuildId(), id));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<User> getUser() {
/* 155 */     UserData user = (UserData)this.data.user().toOptional().orElseThrow(IllegalStateException::new);
/*     */     
/* 157 */     return this.gateway.getRestClient().getEmojiService()
/* 158 */       .getGuildEmoji(getGuildId().asLong(), getId().asLong())
/* 159 */       .map(data -> new User(this.gateway, user));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean requiresColons() {
/* 168 */     return ((Boolean)this.data.requireColons().toOptional()
/* 169 */       .orElseThrow(IllegalStateException::new)).booleanValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isManaged() {
/* 178 */     return ((Boolean)this.data.managed().toOptional()
/* 179 */       .orElseThrow(IllegalStateException::new)).booleanValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAnimated() {
/* 188 */     return ((Boolean)this.data.animated().toOptional()
/* 189 */       .orElseThrow(IllegalStateException::new)).booleanValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAvailable() {
/* 198 */     return ((Boolean)this.data.available().toOptional()
/* 199 */       .orElseThrow(IllegalStateException::new)).booleanValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Snowflake getGuildId() {
/* 208 */     return Snowflake.of(this.guildId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Guild> getGuild() {
/* 218 */     return this.gateway.getGuildById(getGuildId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Guild> getGuild(EntityRetrievalStrategy retrievalStrategy) {
/* 229 */     return this.gateway.withRetrievalStrategy(retrievalStrategy).getGuildById(getGuildId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public Mono<GuildEmoji> edit(Consumer<? super LegacyGuildEmojiEditSpec> spec) {
/* 243 */     return Mono.defer(() -> {
/*     */           LegacyGuildEmojiEditSpec mutatedSpec = new LegacyGuildEmojiEditSpec();
/*     */ 
/*     */           
/*     */           spec.accept(mutatedSpec);
/*     */ 
/*     */           
/*     */           return this.gateway.getRestClient().getEmojiService().modifyGuildEmoji(getGuildId().asLong(), getId().asLong(), mutatedSpec.asRequest(), mutatedSpec.getReason());
/* 251 */         }).map(data -> new GuildEmoji(this.gateway, data, getGuildId().asLong()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GuildEmojiEditMono edit() {
/* 262 */     return GuildEmojiEditMono.of(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<GuildEmoji> edit(GuildEmojiEditSpec spec) {
/* 273 */     Objects.requireNonNull(spec);
/* 274 */     return Mono.defer(() -> this.gateway.getRestClient().getEmojiService().modifyGuildEmoji(getGuildId().asLong(), getId().asLong(), spec.asRequest(), spec.reason()))
/*     */ 
/*     */ 
/*     */       
/* 278 */       .map(data -> new GuildEmoji(this.gateway, data, getGuildId().asLong()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Void> delete() {
/* 288 */     return delete(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Void> delete(@Nullable String reason) {
/* 299 */     return this.gateway.getRestClient().getEmojiService()
/* 300 */       .deleteGuildEmoji(getGuildId().asLong(), getId().asLong(), reason);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getImageUrl() {
/* 309 */     String path = String.format("emojis/%s", new Object[] { getId().asString() });
/* 310 */     return isAnimated() ? ImageUtil.getUrl(path, Image.Format.GIF) : ImageUtil.getUrl(path, Image.Format.PNG);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Image> getImage() {
/* 320 */     return Image.ofUrl(getImageUrl());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String asFormat() {
/* 329 */     return '<' + (isAnimated() ? "a" : "") + ':' + getName() + ':' + getId().asString() + '>';
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(@Nullable Object obj) {
/* 334 */     return EntityUtil.equals(this, obj);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 339 */     return EntityUtil.hashCode(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 344 */     return "GuildEmoji{data=" + this.data + ", guildId=" + this.guildId + '}';
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\object\entity\GuildEmoji.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */