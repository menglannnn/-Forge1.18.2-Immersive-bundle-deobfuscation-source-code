/*     */ package discord4j.core.object.entity;
/*     */ 
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.GatewayDiscordClient;
/*     */ import discord4j.core.object.entity.channel.Channel;
/*     */ import discord4j.core.object.entity.channel.PrivateChannel;
/*     */ import discord4j.core.retriever.EntityRetrievalStrategy;
/*     */ import discord4j.core.util.EntityUtil;
/*     */ import discord4j.core.util.ImageUtil;
/*     */ import discord4j.discordjson.json.ChannelData;
/*     */ import discord4j.discordjson.json.DMCreateRequest;
/*     */ import discord4j.discordjson.json.UserData;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import discord4j.rest.util.Color;
/*     */ import discord4j.rest.util.Image;
/*     */ import java.util.EnumSet;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class User
/*     */   implements Entity
/*     */ {
/*     */   private static final String DEFAULT_IMAGE_PATH = "embed/avatars/%d";
/*     */   private static final String AVATAR_IMAGE_PATH = "avatars/%s/%s";
/*     */   private static final String BANNER_IMAGE_PATH = "banners/%s/%s";
/*     */   private final GatewayDiscordClient gateway;
/*     */   private final UserData data;
/*     */   
/*     */   public User(GatewayDiscordClient gateway, UserData data) {
/*  69 */     this.gateway = Objects.<GatewayDiscordClient>requireNonNull(gateway);
/*  70 */     this.data = Objects.<UserData>requireNonNull(data);
/*     */   }
/*     */ 
/*     */   
/*     */   public final GatewayDiscordClient getClient() {
/*  75 */     return this.gateway;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UserData getUserData() {
/*  84 */     return this.data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Optional<String> getGlobalName() {
/*  94 */     return this.data.globalName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getUsername() {
/* 104 */     return this.data.username();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @Nullable
/*     */   public final String getDiscriminator() {
/* 120 */     return this.data.discriminator();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isMigrated() {
/* 129 */     return (getDiscriminator() == null || getDiscriminator().equals("0"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getTag() {
/* 138 */     if (isMigrated()) {
/* 139 */       return getUsername();
/*     */     }
/*     */     
/* 142 */     return getUsername() + "#" + getDiscriminator();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean hasAnimatedAvatar() {
/* 151 */     String avatar = this.data.avatar().orElse(null);
/* 152 */     return (avatar != null && avatar.startsWith("a_"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Optional<String> getAvatarUrl(Image.Format format) {
/* 162 */     return this.data.avatar().map(avatar -> ImageUtil.getUrl(String.format("avatars/%s/%s", new Object[] { getId().asString(), avatar }), format));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getAvatarUrl() {
/* 172 */     boolean animated = hasAnimatedAvatar();
/* 173 */     return getAvatarUrl(animated ? Image.Format.GIF : Image.Format.PNG).orElse(getDefaultAvatarUrl());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Image> getAvatar(Image.Format format) {
/* 183 */     return Mono.justOrEmpty(getAvatarUrl(format)).flatMap(Image::ofUrl);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Mono<Image> getAvatar() {
/* 193 */     return Image.ofUrl(getAvatarUrl());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getDefaultAvatarUrl() {
/* 202 */     if (isMigrated()) {
/* 203 */       return ImageUtil.getUrl(String.format("embed/avatars/%d", new Object[] { Long.valueOf((getId().asLong() >> 22L) % 6L) }), Image.Format.PNG);
/*     */     }
/*     */     
/* 206 */     return ImageUtil.getUrl(String.format("embed/avatars/%d", new Object[] { Integer.valueOf(Integer.parseInt(getDiscriminator()) % 5) }), Image.Format.PNG);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean hasAnimatedBanner() {
/* 215 */     String banner = Possible.flatOpt(this.data.banner()).orElse(null);
/* 216 */     return (banner != null && banner.startsWith("a_"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Optional<String> getBannerUrl(Image.Format format) {
/* 226 */     return Possible.flatOpt(this.data.banner()).map(banner -> ImageUtil.getUrl(String.format("banners/%s/%s", new Object[] { getId().asString(), banner }), format));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Optional<String> getBannerUrl() {
/* 236 */     boolean animated = hasAnimatedBanner();
/* 237 */     return getBannerUrl(animated ? Image.Format.GIF : Image.Format.PNG);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Image> getBanner(Image.Format format) {
/* 247 */     return Mono.justOrEmpty(getBannerUrl(format)).flatMap(Image::ofUrl);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Mono<Image> getBanner() {
/* 257 */     return Mono.justOrEmpty(getBannerUrl()).flatMap(Image::ofUrl);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Optional<Color> getAccentColor() {
/* 266 */     return Possible.flatOpt(this.data.accentColor())
/* 267 */       .map(Color::of);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isBot() {
/* 276 */     return ((Boolean)this.data.bot().toOptional().orElse(Boolean.valueOf(false))).booleanValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getMention() {
/* 286 */     return "<@" + getId().asString() + ">";
/*     */   }
/*     */ 
/*     */   
/*     */   public final Snowflake getId() {
/* 291 */     return Snowflake.of(this.data.id());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Member> asMember(Snowflake guildId) {
/* 302 */     return this.gateway.getMemberById(guildId, getId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Member> asMember(Snowflake guildId, EntityRetrievalStrategy retrievalStrategy) {
/* 314 */     return this.gateway.withRetrievalStrategy(retrievalStrategy).getMemberById(guildId, getId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Mono<PrivateChannel> getPrivateChannel() {
/* 324 */     return this.gateway.getRestClient().getUserService()
/* 325 */       .createDM((DMCreateRequest)DMCreateRequest.builder().recipientId(Snowflake.asString(getId().asLong())).build())
/* 326 */       .map(data -> EntityUtil.getChannel(this.gateway, data))
/* 327 */       .cast(PrivateChannel.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EnumSet<Flag> getPublicFlags() {
/* 336 */     long publicFlags = ((Long)this.data.publicFlags().toOptional().orElse(Long.valueOf(0L))).longValue();
/* 337 */     if (publicFlags != 0L) {
/* 338 */       return Flag.of(publicFlags);
/*     */     }
/* 340 */     return EnumSet.noneOf(Flag.class);
/*     */   }
/*     */ 
/*     */   
/*     */   public final boolean equals(@Nullable Object obj) {
/* 345 */     return EntityUtil.equals(this, obj);
/*     */   }
/*     */ 
/*     */   
/*     */   public final int hashCode() {
/* 350 */     return EntityUtil.hashCode(this);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public enum Flag
/*     */   {
/* 357 */     DISCORD_EMPLOYEE(0),
/*     */     
/* 359 */     DISCORD_PARTNER(1),
/*     */     
/* 361 */     HYPESQUAD_EVENTS(2),
/*     */     
/* 363 */     BUG_HUNTER_LEVEL_1(3),
/*     */     
/* 365 */     HOUSE_BRAVERY(6),
/*     */     
/* 367 */     HOUSE_BRILLIANCE(7),
/*     */     
/* 369 */     HOUSE_BALANCE(8),
/*     */     
/* 371 */     EARLY_SUPPORTER(9),
/*     */     
/* 373 */     TEAM_USER(10),
/*     */     
/* 375 */     SYSTEM(12),
/*     */     
/* 377 */     BUG_HUNTER_LEVEL_2(14),
/*     */     
/* 379 */     VERIFIED_BOT(16),
/*     */     
/* 381 */     VERIFIED_BOT_DEVELOPER(17),
/*     */     
/* 383 */     DISCORD_CERTIFIED_MODERATOR(18),
/*     */     
/* 385 */     BOT_HTTP_INTERACTIONS(19),
/*     */     
/* 387 */     ACTIVE_DEVELOPER(22);
/*     */ 
/*     */ 
/*     */     
/*     */     private final int value;
/*     */ 
/*     */     
/*     */     private final int flag;
/*     */ 
/*     */ 
/*     */     
/*     */     Flag(int value) {
/* 399 */       this.value = value;
/* 400 */       this.flag = 1 << value;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int getValue() {
/* 409 */       return this.value;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int getFlag() {
/* 418 */       return this.flag;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static EnumSet<Flag> of(long value) {
/* 429 */       EnumSet<Flag> userFlags = EnumSet.noneOf(Flag.class);
/* 430 */       for (Flag flag : values()) {
/* 431 */         long flagValue = flag.getFlag();
/* 432 */         if ((flagValue & value) == flagValue) {
/* 433 */           userFlags.add(flag);
/*     */         }
/*     */       } 
/* 436 */       return userFlags;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 442 */     return "User{data=" + this.data + '}';
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\object\entity\User.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */