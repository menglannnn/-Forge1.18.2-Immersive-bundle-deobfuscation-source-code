/*     */ package discord4j.core.object.entity;
/*     */ 
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.GatewayDiscordClient;
/*     */ import discord4j.core.util.ImageUtil;
/*     */ import discord4j.discordjson.json.IntegrationApplicationData;
/*     */ import discord4j.discordjson.json.UserData;
/*     */ import discord4j.rest.util.Image;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IntegrationApplication
/*     */   implements Entity
/*     */ {
/*     */   private static final String ICON_IMAGE_PATH = "app-icons/%s/%s";
/*     */   private final GatewayDiscordClient gateway;
/*     */   private final IntegrationApplicationData data;
/*     */   
/*     */   public IntegrationApplication(GatewayDiscordClient gateway, IntegrationApplicationData data) {
/*  52 */     this.gateway = Objects.<GatewayDiscordClient>requireNonNull(gateway);
/*  53 */     this.data = Objects.<IntegrationApplicationData>requireNonNull(data);
/*     */   }
/*     */ 
/*     */   
/*     */   public GatewayDiscordClient getClient() {
/*  58 */     return this.gateway;
/*     */   }
/*     */ 
/*     */   
/*     */   public Snowflake getId() {
/*  63 */     return Snowflake.of(this.data.id());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IntegrationApplicationData getData() {
/*  72 */     return this.data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/*  81 */     return this.data.name();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<String> getIconUrl(Image.Format format) {
/*  91 */     return this.data.icon()
/*  92 */       .map(icon -> ImageUtil.getUrl(String.format("app-icons/%s/%s", new Object[] { getId().asString(), icon }), format));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDescription() {
/* 101 */     return this.data.description();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSummary() {
/* 110 */     return this.data.summary();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<User> getBot() {
/* 119 */     return this.data.bot().toOptional()
/* 120 */       .map(data -> new User(this.gateway, data));
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\object\entity\IntegrationApplication.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */