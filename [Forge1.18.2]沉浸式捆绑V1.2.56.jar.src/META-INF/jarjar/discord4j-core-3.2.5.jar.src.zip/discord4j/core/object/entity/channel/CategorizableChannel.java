/*    */ package discord4j.core.object.entity.channel;
/*    */ 
/*    */ import discord4j.common.util.Snowflake;
/*    */ import discord4j.core.object.ExtendedInvite;
/*    */ import discord4j.core.retriever.EntityRetrievalStrategy;
/*    */ import discord4j.core.spec.InviteCreateMono;
/*    */ import discord4j.core.spec.InviteCreateSpec;
/*    */ import discord4j.core.spec.legacy.LegacyInviteCreateSpec;
/*    */ import java.util.Optional;
/*    */ import java.util.function.Consumer;
/*    */ import reactor.core.publisher.Flux;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface CategorizableChannel
/*    */   extends TopLevelGuildChannel
/*    */ {
/*    */   Optional<Snowflake> getCategoryId();
/*    */   
/*    */   Mono<Category> getCategory();
/*    */   
/*    */   Mono<Category> getCategory(EntityRetrievalStrategy paramEntityRetrievalStrategy);
/*    */   
/*    */   @Deprecated
/*    */   Mono<ExtendedInvite> createInvite(Consumer<? super LegacyInviteCreateSpec> paramConsumer);
/*    */   
/*    */   default InviteCreateMono createInvite() {
/* 78 */     return InviteCreateMono.of(this);
/*    */   }
/*    */   
/*    */   Mono<ExtendedInvite> createInvite(InviteCreateSpec paramInviteCreateSpec);
/*    */   
/*    */   Flux<ExtendedInvite> getInvites();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\object\entity\channel\CategorizableChannel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */