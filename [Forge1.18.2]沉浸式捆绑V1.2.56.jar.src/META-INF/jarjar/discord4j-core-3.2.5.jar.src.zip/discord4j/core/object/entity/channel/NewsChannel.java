/*     */ package discord4j.core.object.entity.channel;
/*     */ 
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.GatewayDiscordClient;
/*     */ import discord4j.core.object.FollowedChannel;
/*     */ import discord4j.core.object.PermissionOverwrite;
/*     */ import discord4j.core.object.entity.Member;
/*     */ import discord4j.core.object.entity.Message;
/*     */ import discord4j.core.retriever.EntityRetrievalStrategy;
/*     */ import discord4j.core.spec.InviteCreateSpec;
/*     */ import discord4j.core.spec.MessageCreateSpec;
/*     */ import discord4j.core.spec.NewsChannelEditMono;
/*     */ import discord4j.core.spec.NewsChannelEditSpec;
/*     */ import discord4j.core.spec.WebhookCreateSpec;
/*     */ import discord4j.core.spec.legacy.LegacyInviteCreateSpec;
/*     */ import discord4j.core.spec.legacy.LegacyMessageCreateSpec;
/*     */ import discord4j.core.spec.legacy.LegacyNewsChannelEditSpec;
/*     */ import discord4j.core.spec.legacy.LegacyWebhookCreateSpec;
/*     */ import discord4j.core.util.EntityUtil;
/*     */ import discord4j.discordjson.json.ChannelData;
/*     */ import discord4j.discordjson.json.FollowedChannelData;
/*     */ import discord4j.discordjson.json.NewsChannelFollowRequest;
/*     */ import discord4j.rest.entity.RestChannel;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import java.util.function.Consumer;
/*     */ import org.reactivestreams.Publisher;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class NewsChannel
/*     */   extends BaseTopLevelGuildMessageChannel
/*     */ {
/*     */   public NewsChannel(GatewayDiscordClient gateway, ChannelData data) {
/*  43 */     super(gateway, data);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public Mono<NewsChannel> edit(Consumer<? super LegacyNewsChannelEditSpec> spec) {
/*  57 */     return Mono.defer(() -> {
/*     */           LegacyNewsChannelEditSpec mutatedSpec = new LegacyNewsChannelEditSpec();
/*     */ 
/*     */           
/*     */           spec.accept(mutatedSpec);
/*     */           
/*     */           return getClient().getRestClient().getChannelService().modifyChannel(getId().asLong(), mutatedSpec.asRequest(), mutatedSpec.getReason());
/*  64 */         }).map(data -> EntityUtil.getChannel(getClient(), data))
/*  65 */       .cast(NewsChannel.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NewsChannelEditMono edit() {
/*  76 */     return NewsChannelEditMono.of(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<NewsChannel> edit(NewsChannelEditSpec spec) {
/*  87 */     Objects.requireNonNull(spec);
/*  88 */     return Mono.defer(() -> getClient().getRestClient().getChannelService().modifyChannel(getId().asLong(), spec.asRequest(), spec.reason()))
/*     */ 
/*     */       
/*  91 */       .map(data -> EntityUtil.getChannel(getClient(), data))
/*  92 */       .cast(NewsChannel.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<FollowedChannel> follow(Snowflake targetChannelId) {
/* 104 */     return getClient().getRestClient().getChannelService()
/* 105 */       .followNewsChannel(getId().asLong(), (NewsChannelFollowRequest)NewsChannelFollowRequest.builder()
/* 106 */         .webhookChannelId(targetChannelId.asString())
/* 107 */         .build())
/* 108 */       .map(data -> new FollowedChannel(getClient(), data));
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 113 */     return "NewsChannel{} " + super.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\object\entity\channel\NewsChannel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */