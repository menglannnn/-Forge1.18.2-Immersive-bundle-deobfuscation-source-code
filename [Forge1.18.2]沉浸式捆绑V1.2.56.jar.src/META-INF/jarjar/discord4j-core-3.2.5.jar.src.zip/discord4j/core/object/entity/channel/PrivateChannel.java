/*    */ package discord4j.core.object.entity.channel;
/*    */ 
/*    */ import discord4j.common.util.Snowflake;
/*    */ import discord4j.core.GatewayDiscordClient;
/*    */ import discord4j.core.object.entity.User;
/*    */ import discord4j.core.retriever.EntityRetrievalStrategy;
/*    */ import discord4j.core.spec.MessageCreateSpec;
/*    */ import discord4j.discordjson.json.ChannelData;
/*    */ import discord4j.discordjson.json.UserData;
/*    */ import discord4j.rest.entity.RestChannel;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import java.util.Set;
/*    */ import java.util.stream.Collectors;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class PrivateChannel
/*    */   extends BaseMessageChannel
/*    */ {
/*    */   public PrivateChannel(GatewayDiscordClient gateway, ChannelData data) {
/* 39 */     super(gateway, data);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Set<Snowflake> getRecipientIds() {
/* 48 */     return getData().recipients().toOptional()
/* 49 */       .map(recipients -> (Set)recipients.stream().map(UserData::id).map(Snowflake::of).collect(Collectors.toSet()))
/*    */ 
/*    */ 
/*    */       
/* 53 */       .orElse(Collections.emptySet());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Set<User> getRecipients() {
/* 62 */     return getData().recipients().toOptional()
/* 63 */       .map(recipients -> (Set)recipients.stream().map(()).collect(Collectors.toSet()))
/*    */ 
/*    */       
/* 66 */       .orElse(Collections.emptySet());
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 71 */     return "PrivateChannel{} " + super.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\object\entity\channel\PrivateChannel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */