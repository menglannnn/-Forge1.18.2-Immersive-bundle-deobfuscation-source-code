/*     */ package discord4j.core.object.entity;
/*     */ 
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.GatewayDiscordClient;
/*     */ import discord4j.core.object.entity.channel.GuildMessageChannel;
/*     */ import discord4j.core.retriever.EntityRetrievalStrategy;
/*     */ import discord4j.core.spec.WebhookEditMono;
/*     */ import discord4j.core.spec.WebhookEditSpec;
/*     */ import discord4j.core.spec.WebhookEditWithTokenMono;
/*     */ import discord4j.core.spec.WebhookEditWithTokenSpec;
/*     */ import discord4j.core.spec.WebhookExecuteMono;
/*     */ import discord4j.core.spec.WebhookExecuteSpec;
/*     */ import discord4j.core.spec.WebhookMessageEditMono;
/*     */ import discord4j.core.spec.WebhookMessageEditSpec;
/*     */ import discord4j.core.spec.legacy.LegacyWebhookEditSpec;
/*     */ import discord4j.core.spec.legacy.LegacyWebhookEditWithTokenSpec;
/*     */ import discord4j.core.spec.legacy.LegacyWebhookExecuteSpec;
/*     */ import discord4j.core.util.EntityUtil;
/*     */ import discord4j.discordjson.Id;
/*     */ import discord4j.discordjson.json.MessageData;
/*     */ import discord4j.discordjson.json.UserData;
/*     */ import discord4j.discordjson.json.WebhookData;
/*     */ import discord4j.discordjson.json.WebhookPartialChannelData;
/*     */ import discord4j.discordjson.json.WebhookPartialGuildData;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import java.util.function.Consumer;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Webhook
/*     */   implements Entity
/*     */ {
/*     */   private final GatewayDiscordClient gateway;
/*     */   private final WebhookData data;
/*     */   
/*     */   public Webhook(GatewayDiscordClient gateway, WebhookData data) {
/*  62 */     this.gateway = Objects.<GatewayDiscordClient>requireNonNull(gateway);
/*  63 */     this.data = Objects.<WebhookData>requireNonNull(data);
/*     */   }
/*     */ 
/*     */   
/*     */   public GatewayDiscordClient getClient() {
/*  68 */     return this.gateway;
/*     */   }
/*     */ 
/*     */   
/*     */   public Snowflake getId() {
/*  73 */     return Snowflake.of(this.data.id());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebhookData getData() {
/*  82 */     return this.data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Type getType() {
/*  91 */     return Type.of(this.data.type());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Snowflake getGuildId() {
/* 100 */     return Snowflake.of(((Optional<Id>)this.data.guildId().get()).get());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Guild> getGuild() {
/* 110 */     return this.gateway.getGuildById(getGuildId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Guild> getGuild(EntityRetrievalStrategy retrievalStrategy) {
/* 121 */     return this.gateway.withRetrievalStrategy(retrievalStrategy).getGuildById(getGuildId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Snowflake getChannelId() {
/* 130 */     return Snowflake.of(this.data.channelId().get());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<GuildMessageChannel> getChannel() {
/* 140 */     return this.gateway.getChannelById(getChannelId()).cast(GuildMessageChannel.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<GuildMessageChannel> getChannel(EntityRetrievalStrategy retrievalStrategy) {
/* 151 */     return this.gateway.withRetrievalStrategy(retrievalStrategy)
/* 152 */       .getChannelById(getChannelId())
/* 153 */       .cast(GuildMessageChannel.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<User> getCreator() {
/* 163 */     return this.data.user().toOptional().map(userData -> new User(this.gateway, userData));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<String> getName() {
/* 172 */     return this.data.name();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<String> getAvatar() {
/* 181 */     return this.data.avatar();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<String> getToken() {
/* 190 */     return this.data.token().toOptional();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<Snowflake> getApplicationId() {
/* 199 */     return this.data.applicationId().map(Snowflake::of);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<Snowflake> getSourceGuildId() {
/* 210 */     return this.data.sourceGuild().toOptional().map(WebhookPartialGuildData::id).map(Snowflake::of);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<String> getSourceGuildName() {
/* 221 */     return this.data.sourceGuild().toOptional().map(WebhookPartialGuildData::name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<Snowflake> getSourceChannelId() {
/* 231 */     return this.data.sourceChannel().toOptional().map(WebhookPartialChannelData::id).map(Snowflake::of);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<String> getSourceChannelName() {
/* 242 */     return this.data.sourceChannel().toOptional().map(WebhookPartialChannelData::name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Void> delete() {
/* 252 */     return delete(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Void> delete(@Nullable String reason) {
/* 263 */     return this.gateway.getRestClient().getWebhookService()
/* 264 */       .deleteWebhook(getId().asLong(), reason);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Void> deleteWithToken() {
/* 274 */     return Mono.defer(() -> {
/*     */           if (!getToken().isPresent()) {
/*     */             throw new IllegalStateException("Missing token");
/*     */           }
/*     */           return this.gateway.getRestClient().getWebhookService().deleteWebhookWithToken(getId().asLong(), getToken().get());
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public Mono<Webhook> edit(Consumer<? super LegacyWebhookEditSpec> spec) {
/* 294 */     return Mono.defer(() -> {
/*     */           LegacyWebhookEditSpec mutatedSpec = new LegacyWebhookEditSpec();
/*     */ 
/*     */           
/*     */           spec.accept(mutatedSpec);
/*     */           
/*     */           return this.gateway.getRestClient().getWebhookService().modifyWebhook(getId().asLong(), mutatedSpec.asRequest(), mutatedSpec.getReason());
/* 301 */         }).map(data -> new Webhook(this.gateway, data));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebhookEditMono edit() {
/* 312 */     return WebhookEditMono.of(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Webhook> edit(WebhookEditSpec spec) {
/* 323 */     Objects.requireNonNull(spec);
/* 324 */     return Mono.defer(() -> this.gateway.getRestClient().getWebhookService().modifyWebhook(getId().asLong(), spec.asRequest(), spec.reason()))
/*     */ 
/*     */       
/* 327 */       .map(data -> new Webhook(this.gateway, data));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public Mono<Webhook> editWithToken(Consumer<? super LegacyWebhookEditWithTokenSpec> spec) {
/* 341 */     return Mono.defer(() -> {
/*     */           if (!getToken().isPresent()) {
/*     */             throw new IllegalStateException("Can't edit webhook.");
/*     */           }
/*     */           
/*     */           LegacyWebhookEditWithTokenSpec mutatedSpec = new LegacyWebhookEditWithTokenSpec();
/*     */           
/*     */           spec.accept(mutatedSpec);
/*     */           
/*     */           return this.gateway.getRestClient().getWebhookService().modifyWebhookWithToken(getId().asLong(), getToken().get(), mutatedSpec.asRequest());
/* 351 */         }).map(data -> new Webhook(this.gateway, data));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebhookEditWithTokenMono editWithToken() {
/* 362 */     return WebhookEditWithTokenMono.of(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Webhook> editWithToken(WebhookEditWithTokenSpec spec) {
/* 373 */     Objects.requireNonNull(spec);
/* 374 */     return Mono.defer(() -> this.gateway.getRestClient().getWebhookService().modifyWebhookWithToken(getId().asLong(), getToken().<Throwable>orElseThrow(()), spec.asRequest()))
/*     */ 
/*     */       
/* 377 */       .map(data -> new Webhook(this.gateway, data));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public Mono<Void> execute(Consumer<? super LegacyWebhookExecuteSpec> spec) {
/* 391 */     return execute(false, spec).then();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebhookExecuteMono execute() {
/* 404 */     return WebhookExecuteMono.of(false, this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Void> execute(WebhookExecuteSpec spec) {
/* 415 */     return execute(false, spec).then();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public Mono<Message> execute(boolean wait, Consumer<? super LegacyWebhookExecuteSpec> spec) {
/* 430 */     return Mono.defer(() -> {
/*     */           if (!getToken().isPresent()) {
/*     */             throw new IllegalArgumentException("Can't execute webhook.");
/*     */           }
/*     */           LegacyWebhookExecuteSpec mutatedSpec = new LegacyWebhookExecuteSpec();
/*     */           spec.accept(mutatedSpec);
/*     */           return this.gateway.getRestClient().getWebhookService().executeWebhook(getId().asLong(), getToken().get(), wait, mutatedSpec.asRequest()).map(());
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Message> execute(boolean wait, WebhookExecuteSpec spec) {
/* 454 */     Objects.requireNonNull(spec);
/* 455 */     return Mono.defer(() -> {
/*     */           if (!getToken().isPresent()) {
/*     */             throw new IllegalArgumentException("Can't execute webhook.");
/*     */           }
/*     */           return this.gateway.getRestClient().getWebhookService().executeWebhook(getId().asLong(), getToken().get(), wait, spec.asRequest()).map(());
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public Mono<Message> executeAndWait(Consumer<? super LegacyWebhookExecuteSpec> spec) {
/* 477 */     return execute(true, spec);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Message> executeAndWait(WebhookExecuteSpec spec) {
/* 488 */     return execute(true, spec);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Message> getMessage(Snowflake messageId) {
/* 499 */     Objects.requireNonNull(messageId);
/* 500 */     return Mono.defer(() -> {
/*     */           if (!getToken().isPresent()) {
/*     */             throw new IllegalArgumentException("Can't get message with this webhook.");
/*     */           }
/*     */           return this.gateway.getRestClient().getWebhookService().getWebhookMessage(getId().asLong(), getToken().get(), messageId.asString()).map(());
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebhookMessageEditMono editMessage(Snowflake messageId) {
/* 522 */     return WebhookMessageEditMono.of(messageId, this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Message> editMessage(Snowflake messageId, WebhookMessageEditSpec spec) {
/* 534 */     Objects.requireNonNull(messageId);
/* 535 */     Objects.requireNonNull(spec);
/* 536 */     return Mono.defer(() -> {
/*     */           if (!getToken().isPresent()) {
/*     */             throw new IllegalArgumentException("Can't edit message with this webhook.");
/*     */           }
/*     */           return this.gateway.getRestClient().getWebhookService().modifyWebhookMessage(getId().asLong(), getToken().get(), messageId.asString(), spec.asRequest()).map(());
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Void> deleteMessage(Snowflake messageId) {
/* 556 */     Objects.requireNonNull(messageId);
/* 557 */     return Mono.defer(() -> {
/*     */           if (!getToken().isPresent()) {
/*     */             throw new IllegalArgumentException("Can't delete message with this webhook.");
/*     */           }
/*     */           return this.gateway.getRestClient().getWebhookService().deleteWebhookMessage(getId().asLong(), getToken().get(), messageId.asString());
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(@Nullable Object obj) {
/* 570 */     return EntityUtil.equals(this, obj);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 575 */     return EntityUtil.hashCode(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 580 */     return "Webhook{data=" + this.data + '}';
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum Type
/*     */   {
/* 592 */     UNKNOWN(-1),
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 597 */     INCOMING(1),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 603 */     CHANNEL_FOLLOWER(2);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final int value;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Type(int value) {
/* 616 */       this.value = value;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Type of(int value) {
/* 627 */       switch (value) {
/*     */         case 1:
/* 629 */           return INCOMING;
/*     */         case 2:
/* 631 */           return CHANNEL_FOLLOWER;
/*     */       } 
/* 633 */       return UNKNOWN;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int getValue() {
/* 643 */       return this.value;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\object\entity\Webhook.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */