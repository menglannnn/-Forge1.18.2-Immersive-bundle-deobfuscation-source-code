/*     */ package discord4j.core.object.entity;
/*     */ 
/*     */ import discord4j.common.store.action.read.ReadActions;
/*     */ import discord4j.common.store.api.StoreAction;
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.GatewayDiscordClient;
/*     */ import discord4j.core.object.VoiceState;
/*     */ import discord4j.core.object.presence.Presence;
/*     */ import discord4j.core.retriever.EntityRetrievalStrategy;
/*     */ import discord4j.core.spec.BanQuerySpec;
/*     */ import discord4j.core.spec.GuildMemberEditMono;
/*     */ import discord4j.core.spec.GuildMemberEditSpec;
/*     */ import discord4j.core.spec.MemberBanQueryMono;
/*     */ import discord4j.core.spec.legacy.LegacyBanQuerySpec;
/*     */ import discord4j.core.spec.legacy.LegacyGuildMemberEditSpec;
/*     */ import discord4j.core.util.ImageUtil;
/*     */ import discord4j.core.util.OrderUtil;
/*     */ import discord4j.core.util.PermissionUtil;
/*     */ import discord4j.discordjson.json.MemberData;
/*     */ import discord4j.discordjson.json.PartialMemberData;
/*     */ import discord4j.discordjson.json.UserData;
/*     */ import discord4j.discordjson.json.VoiceStateData;
/*     */ import discord4j.discordjson.json.gateway.GuildMembersChunk;
/*     */ import discord4j.discordjson.json.gateway.ImmutableRequestGuildMembers;
/*     */ import discord4j.discordjson.json.gateway.RequestGuildMembers;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import discord4j.rest.util.Color;
/*     */ import discord4j.rest.util.Image;
/*     */ import discord4j.rest.util.PermissionSet;
/*     */ import java.time.Instant;
/*     */ import java.time.format.DateTimeFormatter;
/*     */ import java.util.EnumSet;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import java.util.Set;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Predicate;
/*     */ import java.util.stream.Collectors;
/*     */ import org.reactivestreams.Publisher;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.math.MathFlux;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PartialMember
/*     */   extends User
/*     */ {
/*     */   private static final String AVATAR_IMAGE_PATH = "guilds/%s/users/%s/avatars/%s";
/*     */   private final PartialMemberData data;
/*     */   private final long guildId;
/*     */   
/*     */   public PartialMember(GatewayDiscordClient gateway, UserData userData, PartialMemberData memberData, long guildId) {
/*  79 */     super(gateway, userData);
/*  80 */     this.data = Objects.<PartialMemberData>requireNonNull(memberData);
/*  81 */     this.guildId = guildId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PartialMemberData getMemberData() {
/*  90 */     return this.data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Member> asFullMember() {
/* 100 */     return asMember(getGuildId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<Snowflake> getRoleIds() {
/* 109 */     return (Set<Snowflake>)this.data.roles().stream()
/* 110 */       .map(Snowflake::of)
/* 111 */       .collect(Collectors.toSet());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Flux<Role> getRoles() {
/* 124 */     return Flux.fromIterable(getRoleIds())
/* 125 */       .flatMap(id -> getClient().getRoleById(getGuildId(), id));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Flux<Role> getRoles(EntityRetrievalStrategy retrievalStrategy) {
/* 139 */     return Flux.fromIterable(getRoleIds())
/* 140 */       .flatMap(id -> getClient().withRetrievalStrategy(retrievalStrategy).getRoleById(getGuildId(), id));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Role> getHighestRole() {
/* 153 */     return MathFlux.max((Publisher)Flux.fromIterable(getRoleIds()).flatMap(id -> getClient().getRoleById(getGuildId(), id)), OrderUtil.ROLE_ORDER);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Role> getHighestRole(EntityRetrievalStrategy retrievalStrategy) {
/* 168 */     return MathFlux.max((Publisher)Flux.fromIterable(getRoleIds())
/* 169 */         .flatMap(id -> getClient().withRetrievalStrategy(retrievalStrategy).getRoleById(getGuildId(), id)), OrderUtil.ROLE_ORDER);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<Instant> getJoinTime() {
/* 180 */     return this.data.joinedAt().map(it -> (Instant)DateTimeFormatter.ISO_OFFSET_DATE_TIME.<Instant>parse(it, Instant::from));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<Instant> getPremiumTime() {
/* 189 */     return Possible.flatOpt(this.data.premiumSince())
/* 190 */       .map(timestamp -> (Instant)DateTimeFormatter.ISO_OFFSET_DATE_TIME.<Instant>parse(timestamp, Instant::from));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<Instant> getCommunicationDisabledUntil() {
/* 199 */     return Possible.flatOpt(this.data.communicationDisabledUntil())
/* 200 */       .map(timestamp -> (Instant)DateTimeFormatter.ISO_OFFSET_DATE_TIME.<Instant>parse(timestamp, Instant::from));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Snowflake getGuildId() {
/* 209 */     return Snowflake.of(this.guildId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Guild> getGuild() {
/* 219 */     return getClient().getGuildById(getGuildId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Guild> getGuild(EntityRetrievalStrategy retrievalStrategy) {
/* 230 */     return getClient().withRetrievalStrategy(retrievalStrategy).getGuildById(getGuildId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDisplayName() {
/* 239 */     return getNickname().orElse(getUsername());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<String> getNickname() {
/* 248 */     return Possible.flatOpt(this.data.nick());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getNicknameMention() {
/* 258 */     return "<@!" + getId().asString() + ">";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean hasAnimatedGuildAvatar() {
/* 267 */     String avatar = this.data.avatar().orElse(null);
/* 268 */     return (avatar != null && avatar.startsWith("a_"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Optional<String> getGuildAvatarUrl(Image.Format format) {
/* 278 */     return this.data.avatar().map(avatar -> ImageUtil.getUrl(String.format("guilds/%s/users/%s/avatars/%s", new Object[] { Long.valueOf(this.guildId), getId().asString(), avatar }), format));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getEffectiveAvatarUrl() {
/* 289 */     boolean animated = hasAnimatedGuildAvatar();
/* 290 */     return getGuildAvatarUrl(animated ? Image.Format.GIF : Image.Format.PNG).orElse(getAvatarUrl());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Image> getGuildAvatar(Image.Format format) {
/* 303 */     return Mono.justOrEmpty(getGuildAvatarUrl(format)).flatMap(Image::ofUrl);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Mono<Image> getEffectiveAvatar() {
/* 313 */     return Image.ofUrl(getEffectiveAvatarUrl());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<VoiceState> getVoiceState() {
/* 323 */     return Mono.from(getClient().getGatewayResources().getStore()
/* 324 */         .execute((StoreAction)ReadActions.getVoiceStateById(getGuildId().asLong(), getId().asLong())))
/* 325 */       .map(bean -> new VoiceState(getClient(), bean));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Presence> getPresence() {
/* 338 */     if (getClient().getSelfId().equals(getId())) {
/* 339 */       return Mono.defer(() -> {
/*     */             ImmutableRequestGuildMembers request = RequestGuildMembers.builder().guildId(getGuildId().asString()).addUserId(getId().asString()).presences(Boolean.valueOf(true)).limit(1).build();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/*     */             return getClient().requestMemberChunks((RequestGuildMembers)request).singleOrEmpty().flatMap(()).onErrorResume(IllegalArgumentException.class, ());
/*     */           });
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 358 */     return Mono.from(getClient().getGatewayResources().getStore()
/* 359 */         .execute((StoreAction)ReadActions.getPresenceById(getGuildId().asLong(), getId().asLong())))
/* 360 */       .map(Presence::new);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Void> kick() {
/* 370 */     return kick((String)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Void> kick(@Nullable String reason) {
/* 381 */     return getClient().getRestClient().getGuildService()
/* 382 */       .removeGuildMember(getGuildId().asLong(), getId().asLong(), reason);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Void> addRole(Snowflake roleId) {
/* 393 */     return addRole(roleId, (String)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Void> addRole(Snowflake roleId, @Nullable String reason) {
/* 405 */     return getClient().getRestClient().getGuildService()
/* 406 */       .addGuildMemberRole(this.guildId, getId().asLong(), roleId.asLong(), reason);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Void> removeRole(Snowflake roleId) {
/* 417 */     return removeRole(roleId, (String)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Void> removeRole(Snowflake roleId, @Nullable String reason) {
/* 429 */     return getClient().getRestClient().getGuildService()
/* 430 */       .removeGuildMemberRole(this.guildId, getId().asLong(), roleId.asLong(), reason);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<PermissionSet> getBasePermissions() {
/* 439 */     Mono<Boolean> getIsOwner = getGuild().map(guild -> Boolean.valueOf(guild.getOwnerId().equals(getId())));
/* 440 */     Mono<PermissionSet> getEveryonePerms = getGuild().flatMap(Guild::getEveryoneRole).map(Role::getPermissions);
/* 441 */     Mono<List<PermissionSet>> getRolePerms = getRoles().map(Role::getPermissions).collectList();
/*     */     
/* 443 */     return getIsOwner.filter(Predicate.isEqual(Boolean.TRUE))
/* 444 */       .flatMap(ignored -> Mono.just(PermissionSet.all()))
/* 445 */       .switchIfEmpty(Mono.zip(getEveryonePerms, getRolePerms, PermissionUtil::computeBasePermissions));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Boolean> isHigher(Member otherMember) {
/* 459 */     if (!getGuildId().equals(otherMember.getGuildId())) {
/* 460 */       return Mono.error(new IllegalArgumentException("The provided member is in a different guild."));
/*     */     }
/*     */ 
/*     */     
/* 464 */     if (equals(otherMember)) {
/* 465 */       return Mono.just(Boolean.valueOf(false));
/*     */     }
/*     */     
/* 468 */     return getGuild().map(Guild::getOwnerId)
/* 469 */       .flatMap(ownerId -> ownerId.equals(getId()) ? Mono.just(Boolean.valueOf(true)) : (ownerId.equals(otherMember.getId()) ? Mono.just(Boolean.valueOf(false)) : hasHigherRoles(otherMember.getRoleIds())));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Boolean> isHigher(Snowflake id) {
/* 494 */     return getClient().getMemberById(getGuildId(), id).flatMap(this::isHigher);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Boolean> hasHigherRoles(Set<Snowflake> otherRoles) {
/* 509 */     return getGuild()
/* 510 */       .flatMapMany(Guild::getRoles)
/* 511 */       .transform(OrderUtil::orderRoles)
/* 512 */       .collectList()
/* 513 */       .map(guildRoles -> {
/*     */           Set<Snowflake> thisRoleIds = getRoleIds();
/*     */           Objects.requireNonNull(guildRoles);
/*     */           int thisHighestRolePos = ((Integer)guildRoles.stream().filter(()).max(OrderUtil.ROLE_ORDER).map(guildRoles::indexOf).orElse(Integer.valueOf(0))).intValue();
/*     */           Objects.requireNonNull(guildRoles);
/*     */           int otherHighestPos = ((Integer)guildRoles.stream().filter(()).max(OrderUtil.ROLE_ORDER).map(guildRoles::indexOf).orElse(Integer.valueOf(0))).intValue();
/*     */           return Boolean.valueOf((thisHighestRolePos > otherHighestPos));
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Color> getColor() {
/* 543 */     Flux<Role> rolesWithColor = getRoles().filter(it -> !it.getColor().equals(Role.DEFAULT_COLOR));
/*     */     
/* 545 */     return MathFlux.max((Publisher)rolesWithColor, OrderUtil.ROLE_ORDER)
/* 546 */       .map(Role::getColor)
/* 547 */       .defaultIfEmpty(Role.DEFAULT_COLOR);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EnumSet<Flag> getFlags() {
/* 556 */     long memberFlags = this.data.flags();
/* 557 */     if (memberFlags != 0L) {
/* 558 */       return Flag.of(memberFlags);
/*     */     }
/* 560 */     return EnumSet.noneOf(Flag.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public Mono<Void> ban(Consumer<? super LegacyBanQuerySpec> spec) {
/* 573 */     return Mono.defer(() -> {
/*     */           LegacyBanQuerySpec mutatedSpec = new LegacyBanQuerySpec();
/*     */           spec.accept(mutatedSpec);
/*     */           return getClient().getRestClient().getGuildService().createGuildBan(getGuildId().asLong(), getId().asLong(), mutatedSpec.asRequest(), mutatedSpec.getReason());
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MemberBanQueryMono ban() {
/* 591 */     return MemberBanQueryMono.of(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Void> ban(BanQuerySpec spec) {
/* 602 */     Objects.requireNonNull(spec);
/* 603 */     return Mono.defer(() -> getClient().getRestClient().getGuildService().createGuildBan(getGuildId().asLong(), getId().asLong(), spec.asRequest(), spec.reason()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Void> unban() {
/* 615 */     return unban((String)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Void> unban(@Nullable String reason) {
/* 626 */     return getClient().getRestClient().getGuildService()
/* 627 */       .removeGuildBan(getGuildId().asLong(), getId().asLong(), reason);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public Mono<Member> edit(Consumer<? super LegacyGuildMemberEditSpec> spec) {
/* 641 */     return Mono.defer(() -> {
/*     */           LegacyGuildMemberEditSpec mutatedSpec = new LegacyGuildMemberEditSpec();
/*     */           spec.accept(mutatedSpec);
/*     */           return getClient().getRestClient().getGuildService().modifyGuildMember(getGuildId().asLong(), getId().asLong(), mutatedSpec.asRequest(), mutatedSpec.getReason()).map(());
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GuildMemberEditMono edit() {
/* 660 */     return GuildMemberEditMono.of(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Member> edit(GuildMemberEditSpec spec) {
/* 671 */     Objects.requireNonNull(spec);
/* 672 */     return Mono.defer(() -> getClient().getRestClient().getGuildService().modifyGuildMember(getGuildId().asLong(), getId().asLong(), spec.asRequest(), spec.reason()).map(()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 680 */     return "PartialMember{data=" + this.data + ", guildId=" + this.guildId + "} " + super
/*     */ 
/*     */       
/* 683 */       .toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum Flag
/*     */   {
/* 693 */     DID_REJOIN(0),
/*     */ 
/*     */ 
/*     */     
/* 697 */     COMPLETED_ONBOARDING(1),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 703 */     BYPASSES_VERIFICATION(2),
/*     */ 
/*     */ 
/*     */     
/* 707 */     STARTED_ONBOARDING(3);
/*     */ 
/*     */ 
/*     */     
/*     */     private final int value;
/*     */ 
/*     */     
/*     */     private final int flag;
/*     */ 
/*     */ 
/*     */     
/*     */     Flag(int value) {
/* 719 */       this.value = value;
/* 720 */       this.flag = 1 << value;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int getValue() {
/* 729 */       return this.value;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int getFlag() {
/* 738 */       return this.flag;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static EnumSet<Flag> of(long value) {
/* 749 */       EnumSet<Flag> memberFlags = EnumSet.noneOf(Flag.class);
/* 750 */       for (Flag flag : values()) {
/* 751 */         long flagValue = flag.getFlag();
/* 752 */         if ((flagValue & value) == flagValue) {
/* 753 */           memberFlags.add(flag);
/*     */         }
/*     */       } 
/* 756 */       return memberFlags;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\object\entity\PartialMember.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */