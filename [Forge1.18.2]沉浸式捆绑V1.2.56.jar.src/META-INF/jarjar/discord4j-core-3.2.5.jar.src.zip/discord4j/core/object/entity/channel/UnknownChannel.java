/*    */ package discord4j.core.object.entity.channel;
/*    */ 
/*    */ import discord4j.core.GatewayDiscordClient;
/*    */ import discord4j.discordjson.json.ChannelData;
/*    */ import discord4j.rest.entity.RestChannel;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UnknownChannel
/*    */   extends BaseChannel
/*    */ {
/*    */   public UnknownChannel(GatewayDiscordClient gateway, ChannelData data) {
/* 36 */     super(gateway, data);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 41 */     return "UnknownChannel{data=" + 
/* 42 */       getData() + '}';
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\object\entity\channel\UnknownChannel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */