/*     */ package discord4j.core.object.entity.channel;
/*     */ 
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.object.ExtendedPermissionOverwrite;
/*     */ import discord4j.core.object.PermissionOverwrite;
/*     */ import discord4j.core.object.entity.Guild;
/*     */ import discord4j.core.object.entity.Member;
/*     */ import discord4j.core.retriever.EntityRetrievalStrategy;
/*     */ import discord4j.rest.util.PermissionSet;
/*     */ import java.util.Optional;
/*     */ import java.util.Set;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface GuildChannel
/*     */   extends Channel
/*     */ {
/*     */   Snowflake getGuildId();
/*     */   
/*     */   Mono<Guild> getGuild();
/*     */   
/*     */   Mono<Guild> getGuild(EntityRetrievalStrategy paramEntityRetrievalStrategy);
/*     */   
/*     */   @Deprecated
/*     */   Set<ExtendedPermissionOverwrite> getPermissionOverwrites();
/*     */   
/*     */   @Deprecated
/*     */   Optional<ExtendedPermissionOverwrite> getOverwriteForMember(Snowflake paramSnowflake);
/*     */   
/*     */   @Deprecated
/*     */   Optional<ExtendedPermissionOverwrite> getOverwriteForRole(Snowflake paramSnowflake);
/*     */   
/*     */   Mono<PermissionSet> getEffectivePermissions(Snowflake paramSnowflake);
/*     */   
/*     */   Mono<PermissionSet> getEffectivePermissions(Member paramMember);
/*     */   
/*     */   String getName();
/*     */   
/*     */   @Deprecated
/*     */   int getRawPosition();
/*     */   
/*     */   @Deprecated
/*     */   Mono<Integer> getPosition();
/*     */   
/*     */   @Deprecated
/*     */   default Mono<Void> addMemberOverwrite(Snowflake memberId, PermissionOverwrite overwrite) {
/* 170 */     return addMemberOverwrite(memberId, overwrite, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   Mono<Void> addMemberOverwrite(Snowflake paramSnowflake, PermissionOverwrite paramPermissionOverwrite, @Nullable String paramString);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   default Mono<Void> addRoleOverwrite(Snowflake roleId, PermissionOverwrite overwrite) {
/* 201 */     return addRoleOverwrite(roleId, overwrite, null);
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   Mono<Void> addRoleOverwrite(Snowflake paramSnowflake, PermissionOverwrite paramPermissionOverwrite, @Nullable String paramString);
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\object\entity\channel\GuildChannel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */