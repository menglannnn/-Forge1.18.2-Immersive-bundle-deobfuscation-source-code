/*      */ package discord4j.core.object.entity;
/*      */ import discord4j.common.util.Snowflake;
/*      */ import discord4j.core.GatewayDiscordClient;
/*      */ import discord4j.core.object.Ban;
/*      */ import discord4j.core.object.ExtendedInvite;
/*      */ import discord4j.core.object.GuildTemplate;
/*      */ import discord4j.core.object.Region;
/*      */ import discord4j.core.object.VoiceState;
/*      */ import discord4j.core.object.audit.AuditLogPart;
/*      */ import discord4j.core.object.automod.AutoModRule;
/*      */ import discord4j.core.object.entity.channel.Category;
/*      */ import discord4j.core.object.entity.channel.Channel;
/*      */ import discord4j.core.object.entity.channel.GuildChannel;
/*      */ import discord4j.core.object.entity.channel.NewsChannel;
/*      */ import discord4j.core.object.entity.channel.TextChannel;
/*      */ import discord4j.core.object.entity.channel.VoiceChannel;
/*      */ import discord4j.core.retriever.EntityRetrievalStrategy;
/*      */ import discord4j.core.spec.AuditLogQuerySpec;
/*      */ import discord4j.core.spec.AutoModRuleCreateSpec;
/*      */ import discord4j.core.spec.BanQuerySpec;
/*      */ import discord4j.core.spec.CategoryCreateSpec;
/*      */ import discord4j.core.spec.GuildEditSpec;
/*      */ import discord4j.core.spec.GuildEmojiCreateSpec;
/*      */ import discord4j.core.spec.GuildPruneCountSpec;
/*      */ import discord4j.core.spec.GuildPruneSpec;
/*      */ import discord4j.core.spec.GuildStickerCreateSpec;
/*      */ import discord4j.core.spec.GuildTemplateCreateSpec;
/*      */ import discord4j.core.spec.NewsChannelCreateSpec;
/*      */ import discord4j.core.spec.RoleCreateSpec;
/*      */ import discord4j.core.spec.TextChannelCreateSpec;
/*      */ import discord4j.core.spec.VoiceChannelCreateSpec;
/*      */ import discord4j.core.spec.legacy.LegacyAuditLogQuerySpec;
/*      */ import discord4j.core.spec.legacy.LegacyBanQuerySpec;
/*      */ import discord4j.core.spec.legacy.LegacyCategoryCreateSpec;
/*      */ import discord4j.core.spec.legacy.LegacyGuildEditSpec;
/*      */ import discord4j.core.spec.legacy.LegacyGuildEmojiCreateSpec;
/*      */ import discord4j.core.spec.legacy.LegacyGuildPruneCountSpec;
/*      */ import discord4j.core.spec.legacy.LegacyGuildPruneSpec;
/*      */ import discord4j.core.spec.legacy.LegacyGuildTemplateCreateSpec;
/*      */ import discord4j.core.spec.legacy.LegacyNewsChannelCreateSpec;
/*      */ import discord4j.core.spec.legacy.LegacyRoleCreateSpec;
/*      */ import discord4j.core.spec.legacy.LegacyTextChannelCreateSpec;
/*      */ import discord4j.core.spec.legacy.LegacyVoiceChannelCreateSpec;
/*      */ import discord4j.core.util.EntityUtil;
/*      */ import discord4j.core.util.ImageUtil;
/*      */ import discord4j.discordjson.json.AuditLogData;
/*      */ import discord4j.discordjson.json.AuditLogEntryData;
/*      */ import discord4j.discordjson.json.AutoModRuleData;
/*      */ import discord4j.discordjson.json.BanData;
/*      */ import discord4j.discordjson.json.ChannelData;
/*      */ import discord4j.discordjson.json.EmojiData;
/*      */ import discord4j.discordjson.json.GuildData;
/*      */ import discord4j.discordjson.json.GuildScheduledEventData;
/*      */ import discord4j.discordjson.json.GuildUpdateData;
/*      */ import discord4j.discordjson.json.GuildUpdateFields;
/*      */ import discord4j.discordjson.json.MemberData;
/*      */ import discord4j.discordjson.json.PruneData;
/*      */ import discord4j.discordjson.json.RegionData;
/*      */ import discord4j.discordjson.json.RoleData;
/*      */ import discord4j.discordjson.json.TemplateData;
/*      */ import discord4j.discordjson.json.VoiceStateData;
/*      */ import discord4j.discordjson.possible.Possible;
/*      */ import discord4j.rest.util.Image;
/*      */ import java.util.EnumSet;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Objects;
/*      */ import java.util.Optional;
/*      */ import java.util.OptionalInt;
/*      */ import java.util.Set;
/*      */ import java.util.function.Consumer;
/*      */ import java.util.function.Function;
/*      */ import java.util.function.ToLongFunction;
/*      */ import java.util.stream.Collectors;
/*      */ import reactor.core.publisher.Flux;
/*      */ import reactor.core.publisher.Mono;
/*      */ import reactor.core.publisher.SynchronousSink;
/*      */ import reactor.util.annotation.Nullable;
/*      */ 
/*      */ public final class Guild implements Entity {
/*      */   private static final int DEFAULT_MAX_PRESENCES = 25000;
/*      */   private static final String ICON_IMAGE_PATH = "icons/%s/%s";
/*      */   private static final String SPLASH_IMAGE_PATH = "splashes/%s/%s";
/*      */   
/*      */   public Guild(GatewayDiscordClient gateway, GuildData data) {
/*   86 */     this.gateway = Objects.<GatewayDiscordClient>requireNonNull(gateway);
/*   87 */     this.data = Objects.<GuildData>requireNonNull(data);
/*      */   }
/*      */   private static final String DISCOVERY_SPLASH_IMAGE_PATH = "discovery-splashes/%s/%s"; private static final String BANNER_IMAGE_PATH = "banners/%s/%s"; private final GatewayDiscordClient gateway; private final GuildData data;
/*      */   
/*      */   public GatewayDiscordClient getClient() {
/*   92 */     return this.gateway;
/*      */   }
/*      */ 
/*      */   
/*      */   public Snowflake getId() {
/*   97 */     return Snowflake.of(this.data.id());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public GuildData getData() {
/*  106 */     return this.data;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getName() {
/*  115 */     return this.data.name();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Optional<String> getIconUrl(Image.Format format) {
/*  125 */     return this.data.icon()
/*  126 */       .map(icon -> ImageUtil.getUrl(String.format("icons/%s/%s", new Object[] { getId().asString(), icon }), format));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<Image> getIcon(Image.Format format) {
/*  137 */     return Mono.justOrEmpty(getIconUrl(format)).flatMap(Image::ofUrl);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Optional<String> getSplashUrl(Image.Format format) {
/*  147 */     return this.data.splash()
/*  148 */       .map(splash -> ImageUtil.getUrl(String.format("splashes/%s/%s", new Object[] { getId().asString(), splash }), format));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<Image> getSplash(Image.Format format) {
/*  159 */     return Mono.justOrEmpty(getSplashUrl(format)).flatMap(Image::ofUrl);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Optional<String> getDiscoverySplashUrl(Image.Format format) {
/*  169 */     return this.data.discoverySplash()
/*  170 */       .map(splash -> ImageUtil.getUrl(String.format("discovery-splashes/%s/%s", new Object[] { getId().asString(), splash }), format));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<Image> getDiscoverySplash(Image.Format format) {
/*  182 */     return Mono.justOrEmpty(getDiscoverySplashUrl(format)).flatMap(Image::ofUrl);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Optional<String> getBannerUrl(Image.Format format) {
/*  192 */     return this.data.banner()
/*  193 */       .map(splash -> ImageUtil.getUrl(String.format("banners/%s/%s", new Object[] { getId().asString(), splash }), format));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<Image> getBanner(Image.Format format) {
/*  204 */     return Mono.justOrEmpty(getBannerUrl(format)).flatMap(Image::ofUrl);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Snowflake getOwnerId() {
/*  213 */     return Snowflake.of(this.data.ownerId());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<Member> getOwner() {
/*  223 */     return this.gateway.getMemberById(getId(), getOwnerId());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public Region.Id getRegionId() {
/*  234 */     return Region.Id.of(Possible.flatOpt(this.data.region()).orElse(null));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public Mono<Region> getRegion() {
/*  246 */     return getRegions().filter(response -> response.getId().equals(getRegionId().getValue())).single();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Flux<Region> getRegions() {
/*  256 */     return this.gateway.getRestClient().getGuildService()
/*  257 */       .getGuildVoiceRegions(getId().asLong())
/*  258 */       .map(data -> new Region(this.gateway, data));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Optional<Snowflake> getAfkChannelId() {
/*  267 */     return this.data.afkChannelId().map(Snowflake::of);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<VoiceChannel> getAfkChannel() {
/*  277 */     Objects.requireNonNull(this.gateway); return Mono.justOrEmpty(getAfkChannelId()).flatMap(this.gateway::getChannelById).cast(VoiceChannel.class);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<VoiceChannel> getAfkChannel(EntityRetrievalStrategy retrievalStrategy) {
/*  288 */     return Mono.justOrEmpty(getAfkChannelId())
/*  289 */       .flatMap(id -> this.gateway.withRetrievalStrategy(retrievalStrategy).getChannelById(id))
/*  290 */       .cast(VoiceChannel.class);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getAfkTimeout() {
/*  299 */     return this.data.afkTimeout();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public PremiumTier getPremiumTier() {
/*  308 */     return PremiumTier.of(this.data.premiumTier());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public OptionalInt getPremiumSubscriptionCount() {
/*  317 */     return this.data.premiumSubscriptionCount().toOptional()
/*  318 */       .map(OptionalInt::of)
/*  319 */       .orElse(OptionalInt.empty());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Locale getPreferredLocale() {
/*  330 */     return (new Locale.Builder()).setLanguageTag(this.data.preferredLocale()).build();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public VerificationLevel getVerificationLevel() {
/*  339 */     return VerificationLevel.of(this.data.verificationLevel());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public NotificationLevel getNotificationLevel() {
/*  348 */     return NotificationLevel.of(this.data.defaultMessageNotifications());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ContentFilterLevel getContentFilterLevel() {
/*  357 */     return ContentFilterLevel.of(this.data.explicitContentFilter());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Set<Snowflake> getRoleIds() {
/*  366 */     return (Set<Snowflake>)this.data.roles().stream().map(Snowflake::of).collect(Collectors.toSet());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Flux<Role> getRoles() {
/*  379 */     return this.gateway.getGuildRoles(getId());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Flux<Role> getRoles(EntityRetrievalStrategy retrievalStrategy) {
/*  393 */     return this.gateway.withRetrievalStrategy(retrievalStrategy).getGuildRoles(getId());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<Role> getRoleById(Snowflake id) {
/*  404 */     return this.gateway.getRoleById(getId(), id);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<Role> getRoleById(Snowflake id, EntityRetrievalStrategy retrievalStrategy) {
/*  416 */     return this.gateway.withRetrievalStrategy(retrievalStrategy).getRoleById(getId(), id);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<Role> getEveryoneRole() {
/*  426 */     return this.gateway.getRoleById(getId(), getId());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<Role> getEveryoneRole(EntityRetrievalStrategy retrievalStrategy) {
/*  437 */     return this.gateway.withRetrievalStrategy(retrievalStrategy).getRoleById(getId(), getId());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Set<Snowflake> getStickerIds() {
/*  446 */     return this.data.stickers().toOptional().map(ids -> (Set)ids.stream().map(Snowflake::of).collect(Collectors.toSet())).orElse(Collections.emptySet());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Flux<GuildSticker> getStickers() {
/*  456 */     return this.gateway.getGuildStickers(getId());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Set<Snowflake> getEmojiIds() {
/*  465 */     return (Set<Snowflake>)this.data.emojis().stream().map(Snowflake::of).collect(Collectors.toSet());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Flux<GuildSticker> getStickers(EntityRetrievalStrategy retrievalStrategy) {
/*  476 */     return this.gateway.withRetrievalStrategy(retrievalStrategy).getGuildStickers(getId());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<GuildSticker> getGuildStickerById(Snowflake id) {
/*  487 */     return this.gateway.getGuildStickerById(getId(), id);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<GuildSticker> getGuildStickerById(Snowflake id, EntityRetrievalStrategy retrievalStrategy) {
/*  499 */     return this.gateway.withRetrievalStrategy(retrievalStrategy).getGuildStickerById(getId(), id);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Flux<GuildEmoji> getEmojis() {
/*  509 */     return this.gateway.getGuildEmojis(getId());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Flux<GuildEmoji> getEmojis(EntityRetrievalStrategy retrievalStrategy) {
/*  520 */     return this.gateway.withRetrievalStrategy(retrievalStrategy).getGuildEmojis(getId());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<GuildEmoji> getGuildEmojiById(Snowflake id) {
/*  531 */     return this.gateway.getGuildEmojiById(getId(), id);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<GuildEmoji> getGuildEmojiById(Snowflake id, EntityRetrievalStrategy retrievalStrategy) {
/*  543 */     return this.gateway.withRetrievalStrategy(retrievalStrategy).getGuildEmojiById(getId(), id);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Set<String> getFeatures() {
/*  555 */     return new HashSet<>(this.data.features());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MfaLevel getMfaLevel() {
/*  564 */     return MfaLevel.of(this.data.mfaLevel());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Optional<Snowflake> getApplicationId() {
/*  573 */     return this.data.applicationId().map(Snowflake::of);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isWidgetEnabled() {
/*  582 */     return ((Boolean)this.data.widgetEnabled().toOptional().orElse(Boolean.valueOf(false))).booleanValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Optional<Snowflake> getWidgetChannelId() {
/*  591 */     return Possible.flatOpt(this.data.widgetChannelId()).map(Snowflake::of);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<GuildChannel> getWidgetChannel() {
/*  601 */     Objects.requireNonNull(this.gateway); return Mono.justOrEmpty(getWidgetChannelId()).flatMap(this.gateway::getChannelById).cast(GuildChannel.class);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<GuildChannel> getWidgetChannel(EntityRetrievalStrategy retrievalStrategy) {
/*  612 */     return Mono.justOrEmpty(getWidgetChannelId())
/*  613 */       .flatMap(id -> this.gateway.withRetrievalStrategy(retrievalStrategy).getChannelById(id))
/*  614 */       .cast(GuildChannel.class);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Optional<Snowflake> getSystemChannelId() {
/*  624 */     return this.data.systemChannelId().map(Snowflake::of);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<TextChannel> getSystemChannel() {
/*  634 */     Objects.requireNonNull(this.gateway); return Mono.justOrEmpty(getSystemChannelId()).flatMap(this.gateway::getChannelById).cast(TextChannel.class);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<TextChannel> getSystemChannel(EntityRetrievalStrategy retrievalStrategy) {
/*  646 */     return Mono.justOrEmpty(getSystemChannelId())
/*  647 */       .flatMap(id -> this.gateway.withRetrievalStrategy(retrievalStrategy).getChannelById(id))
/*  648 */       .cast(TextChannel.class);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public EnumSet<SystemChannelFlag> getSystemChannelFlags() {
/*  657 */     return SystemChannelFlag.of(this.data.systemChannelFlags().orElse(0));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Optional<Snowflake> getRulesChannelId() {
/*  666 */     return this.data.rulesChannelId().map(Snowflake::of);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<TextChannel> getRulesChannel() {
/*  677 */     Objects.requireNonNull(this.gateway); return Mono.justOrEmpty(getRulesChannelId()).flatMap(this.gateway::getChannelById).cast(TextChannel.class);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<TextChannel> getRulesChannel(EntityRetrievalStrategy retrievalStrategy) {
/*  690 */     return Mono.justOrEmpty(getRulesChannelId())
/*  691 */       .flatMap(id -> this.gateway.withRetrievalStrategy(retrievalStrategy).getChannelById(id))
/*  692 */       .cast(TextChannel.class);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Optional<Snowflake> getPublicUpdatesChannelId() {
/*  703 */     return this.data.publicUpdatesChannelId().map(Snowflake::of);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<TextChannel> getPublicUpdatesChannel() {
/*  715 */     Objects.requireNonNull(this.gateway); return Mono.justOrEmpty(getPublicUpdatesChannelId()).flatMap(this.gateway::getChannelById).cast(TextChannel.class);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<TextChannel> getPublicUpdatesChannel(EntityRetrievalStrategy retrievalStrategy) {
/*  729 */     return Mono.justOrEmpty(getPublicUpdatesChannelId())
/*  730 */       .flatMap(id -> this.gateway.withRetrievalStrategy(retrievalStrategy).getChannelById(id))
/*  731 */       .cast(TextChannel.class);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Optional<Snowflake> getSafetyAlertsChannelId() {
/*  742 */     return this.data.safetyAlertsChannelId().map(Snowflake::of);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Optional<Integer> getMaxVideoChannelUsers() {
/*  751 */     return this.data.maxVideoChannelUsers().toOptional();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Instant getJoinTime() {
/*  761 */     return DateTimeFormatter.ISO_OFFSET_DATE_TIME.<Instant>parse(this.data.joinedAt(), Instant::from);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isLarge() {
/*  771 */     return this.data.large();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isUnavailable() {
/*  780 */     return ((Boolean)this.data.unavailable().toOptional().orElse(Boolean.valueOf(false))).booleanValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public boolean isEmbedEnabled() {
/*  791 */     return isWidgetEnabled();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getMemberCount() {
/*  802 */     return this.data.memberCount();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public boolean isNsfw() {
/*  813 */     return ((Boolean)this.data.nsfw().toOptional().orElse(Boolean.valueOf(false))).booleanValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public NsfwLevel getNsfwLevel() {
/*  822 */     return NsfwLevel.of(this.data.nsfwLevel());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Flux<VoiceState> getVoiceStates() {
/*  832 */     return Flux.from(this.gateway.getGatewayResources().getStore()
/*  833 */         .execute((StoreAction)ReadActions.getVoiceStatesInGuild(getId().asLong())))
/*  834 */       .map(data -> new VoiceState(this.gateway, data));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Flux<Member> getMembers() {
/*  844 */     return this.gateway.getGuildMembers(getId());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Flux<Member> getMembers(EntityRetrievalStrategy retrievalStrategy) {
/*  855 */     return this.gateway.withRetrievalStrategy(retrievalStrategy).getGuildMembers(getId());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Flux<Member> requestMembers() {
/*  865 */     return this.gateway.requestMembers(getId());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Flux<Member> requestMembers(Set<Snowflake> userIds) {
/*  878 */     return this.gateway.requestMembers(getId(), userIds);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Flux<Member> searchMembers(String username, int limit) {
/*  890 */     Map<String, Object> queryParams = new HashMap<>(2);
/*  891 */     queryParams.put("query", username);
/*  892 */     queryParams.put("limit", Integer.valueOf(limit));
/*  893 */     return this.gateway.getRestClient().getGuildService()
/*  894 */       .searchGuildMembers(this.data.id().asLong(), queryParams)
/*  895 */       .map(memberData -> new Member(this.gateway, memberData, this.data.id().asLong()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<Member> getMemberById(Snowflake id) {
/*  906 */     return this.gateway.getMemberById(getId(), id);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<Member> getMemberById(Snowflake id, EntityRetrievalStrategy retrievalStrategy) {
/*  918 */     return this.gateway.withRetrievalStrategy(retrievalStrategy).getMemberById(getId(), id);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<Member> getSelfMember() {
/*  928 */     return getMemberById(this.gateway.getSelfId());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Flux<GuildChannel> getChannels() {
/*  943 */     return this.gateway.getGuildChannels(getId());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Flux<GuildChannel> getChannels(EntityRetrievalStrategy retrievalStrategy) {
/*  959 */     return this.gateway.withRetrievalStrategy(retrievalStrategy).getGuildChannels(getId());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<GuildChannel> getChannelById(Snowflake id) {
/*  970 */     return this.gateway.getChannelById(id)
/*  971 */       .cast(GuildChannel.class)
/*  972 */       .filter(channel -> channel.getGuildId().equals(getId()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<GuildChannel> getChannelById(Snowflake id, EntityRetrievalStrategy retrievalStrategy) {
/*  984 */     return this.gateway.withRetrievalStrategy(retrievalStrategy).getChannelById(id)
/*  985 */       .cast(GuildChannel.class)
/*  986 */       .filter(channel -> channel.getGuildId().equals(getId()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Flux<Presence> getPresences() {
/*  996 */     return Flux.from(this.gateway.getGatewayResources().getStore()
/*  997 */         .execute((StoreAction)ReadActions.getPresencesInGuild(getId().asLong())))
/*  998 */       .map(Presence::new);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Optional<String> getVanityUrlCode() {
/* 1007 */     return this.data.vanityUrlCode();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Optional<String> getDescription() {
/* 1016 */     return this.data.description();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getMaxPresences() {
/* 1025 */     return ((Integer)Possible.flatOpt(this.data.maxPresences()).orElse(Integer.valueOf(25000))).intValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public OptionalInt getMaxMembers() {
/* 1034 */     return this.data.maxMembers().toOptional()
/* 1035 */       .map(OptionalInt::of)
/* 1036 */       .orElseGet(OptionalInt::empty);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public Mono<Guild> edit(Consumer<? super LegacyGuildEditSpec> spec) {
/* 1049 */     return Mono.defer(() -> {
/*      */           LegacyGuildEditSpec mutatedSpec = new LegacyGuildEditSpec();
/*      */ 
/*      */           
/*      */           spec.accept(mutatedSpec);
/*      */           
/*      */           return this.gateway.getRestClient().getGuildService().modifyGuild(getId().asLong(), mutatedSpec.asRequest(), mutatedSpec.getReason());
/* 1056 */         }).map(data -> new Guild(this.gateway, (GuildData)GuildData.builder().from(this.data).from((GuildUpdateFields)data).build()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public GuildEditMono edit() {
/* 1070 */     return GuildEditMono.of(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<Guild> edit(GuildEditSpec spec) {
/* 1081 */     Objects.requireNonNull(spec);
/* 1082 */     return Mono.defer(() -> this.gateway.getRestClient().getGuildService().modifyGuild(getId().asLong(), spec.asRequest(), spec.reason()))
/*      */ 
/*      */       
/* 1085 */       .map(data -> new Guild(this.gateway, (GuildData)GuildData.builder().from(this.data).from((GuildUpdateFields)data).build()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public Mono<GuildEmoji> createEmoji(Consumer<? super LegacyGuildEmojiCreateSpec> spec) {
/* 1102 */     return Mono.defer(() -> {
/*      */           LegacyGuildEmojiCreateSpec mutatedSpec = new LegacyGuildEmojiCreateSpec();
/*      */ 
/*      */           
/*      */           spec.accept(mutatedSpec);
/*      */           
/*      */           return this.gateway.getRestClient().getEmojiService().createGuildEmoji(getId().asLong(), mutatedSpec.asRequest(), mutatedSpec.getReason());
/* 1109 */         }).map(data -> new GuildEmoji(this.gateway, data, getId().asLong()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public GuildEmojiCreateMono createEmoji(String name, Image image) {
/* 1122 */     return GuildEmojiCreateMono.of(name, image, this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<GuildEmoji> createEmoji(GuildEmojiCreateSpec spec) {
/* 1133 */     Objects.requireNonNull(spec);
/* 1134 */     return Mono.defer(() -> this.gateway.getRestClient().getEmojiService().createGuildEmoji(getId().asLong(), spec.asRequest(), spec.reason()))
/*      */ 
/*      */       
/* 1137 */       .map(data -> new GuildEmoji(this.gateway, data, getId().asLong()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<GuildSticker> createSticker(GuildStickerCreateSpec spec) {
/* 1148 */     Objects.requireNonNull(spec);
/* 1149 */     return Mono.defer(() -> this.gateway.getRestClient().getStickerService().createGuildSticker(getId().asLong(), spec.asRequest(), spec.reason()))
/*      */ 
/*      */       
/* 1152 */       .map(data -> new GuildSticker(this.gateway, data, getId().asLong()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public Mono<GuildTemplate> createTemplate(Consumer<? super LegacyGuildTemplateCreateSpec> spec) {
/* 1166 */     return Mono.defer(() -> {
/*      */           LegacyGuildTemplateCreateSpec mutatedSpec = new LegacyGuildTemplateCreateSpec();
/*      */ 
/*      */           
/*      */           spec.accept(mutatedSpec);
/*      */           
/*      */           return this.gateway.getRestClient().getTemplateService().createTemplate(getId().asLong(), mutatedSpec.asRequest());
/* 1173 */         }).map(data -> new GuildTemplate(this.gateway, data));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public GuildTemplateCreateMono createTemplate(String name) {
/* 1185 */     return GuildTemplateCreateMono.of(name, this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<GuildTemplate> createTemplate(GuildTemplateCreateSpec spec) {
/* 1196 */     Objects.requireNonNull(spec);
/* 1197 */     return Mono.defer(() -> this.gateway.getRestClient().getTemplateService().createTemplate(getId().asLong(), spec.asRequest()))
/*      */       
/* 1199 */       .map(data -> new GuildTemplate(this.gateway, data));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public Mono<Role> createRole(Consumer<? super LegacyRoleCreateSpec> spec) {
/* 1213 */     return Mono.defer(() -> {
/*      */           LegacyRoleCreateSpec mutatedSpec = new LegacyRoleCreateSpec();
/*      */ 
/*      */           
/*      */           spec.accept(mutatedSpec);
/*      */           
/*      */           return this.gateway.getRestClient().getGuildService().createGuildRole(getId().asLong(), mutatedSpec.asRequest(), mutatedSpec.getReason());
/* 1220 */         }).map(data -> new Role(this.gateway, data, getId().asLong()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public RoleCreateMono createRole() {
/* 1231 */     return RoleCreateMono.of(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<Role> createRole(RoleCreateSpec spec) {
/* 1242 */     Objects.requireNonNull(spec);
/* 1243 */     return Mono.defer(() -> this.gateway.getRestClient().getGuildService().createGuildRole(getId().asLong(), spec.asRequest(), spec.reason()))
/*      */ 
/*      */       
/* 1246 */       .map(data -> new Role(this.gateway, data, getId().asLong()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public Mono<NewsChannel> createNewsChannel(Consumer<? super LegacyNewsChannelCreateSpec> spec) {
/* 1260 */     return Mono.defer(() -> {
/*      */           LegacyNewsChannelCreateSpec mutatedSpec = new LegacyNewsChannelCreateSpec();
/*      */ 
/*      */           
/*      */           spec.accept(mutatedSpec);
/*      */           
/*      */           return this.gateway.getRestClient().getGuildService().createGuildChannel(getId().asLong(), mutatedSpec.asRequest(), mutatedSpec.getReason());
/* 1267 */         }).map(data -> EntityUtil.getChannel(this.gateway, data))
/* 1268 */       .cast(NewsChannel.class);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public NewsChannelCreateMono createNewsChannel(String name) {
/* 1280 */     return NewsChannelCreateMono.of(name, this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<NewsChannel> createNewsChannel(NewsChannelCreateSpec spec) {
/* 1291 */     Objects.requireNonNull(spec);
/* 1292 */     return Mono.defer(() -> this.gateway.getRestClient().getGuildService().createGuildChannel(getId().asLong(), spec.asRequest(), spec.reason()))
/*      */ 
/*      */       
/* 1295 */       .map(data -> EntityUtil.getChannel(this.gateway, data))
/* 1296 */       .cast(NewsChannel.class);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public Mono<Category> createCategory(Consumer<? super LegacyCategoryCreateSpec> spec) {
/* 1310 */     return Mono.defer(() -> {
/*      */           LegacyCategoryCreateSpec mutatedSpec = new LegacyCategoryCreateSpec();
/*      */ 
/*      */           
/*      */           spec.accept(mutatedSpec);
/*      */           
/*      */           return this.gateway.getRestClient().getGuildService().createGuildChannel(getId().asLong(), mutatedSpec.asRequest(), mutatedSpec.getReason());
/* 1317 */         }).map(data -> EntityUtil.getChannel(this.gateway, data))
/* 1318 */       .cast(Category.class);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CategoryCreateMono createCategory(String name) {
/* 1330 */     return CategoryCreateMono.of(name, this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<Category> createCategory(CategoryCreateSpec spec) {
/* 1341 */     Objects.requireNonNull(spec);
/* 1342 */     return Mono.defer(() -> this.gateway.getRestClient().getGuildService().createGuildChannel(getId().asLong(), spec.asRequest(), spec.reason()))
/*      */ 
/*      */       
/* 1345 */       .map(data -> EntityUtil.getChannel(this.gateway, data))
/* 1346 */       .cast(Category.class);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public Mono<TextChannel> createTextChannel(Consumer<? super LegacyTextChannelCreateSpec> spec) {
/* 1360 */     return Mono.defer(() -> {
/*      */           LegacyTextChannelCreateSpec mutatedSpec = new LegacyTextChannelCreateSpec();
/*      */ 
/*      */           
/*      */           spec.accept(mutatedSpec);
/*      */           
/*      */           return this.gateway.getRestClient().getGuildService().createGuildChannel(getId().asLong(), mutatedSpec.asRequest(), mutatedSpec.getReason());
/* 1367 */         }).map(data -> EntityUtil.getChannel(this.gateway, data))
/* 1368 */       .cast(TextChannel.class);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TextChannelCreateMono createTextChannel(String name) {
/* 1380 */     return TextChannelCreateMono.of(name, this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<TextChannel> createTextChannel(TextChannelCreateSpec spec) {
/* 1391 */     Objects.requireNonNull(spec);
/* 1392 */     return Mono.defer(() -> this.gateway.getRestClient().getGuildService().createGuildChannel(getId().asLong(), spec.asRequest(), spec.reason()))
/*      */ 
/*      */       
/* 1395 */       .map(data -> EntityUtil.getChannel(this.gateway, data))
/* 1396 */       .cast(TextChannel.class);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public Mono<VoiceChannel> createVoiceChannel(Consumer<? super LegacyVoiceChannelCreateSpec> spec) {
/* 1410 */     return Mono.defer(() -> {
/*      */           LegacyVoiceChannelCreateSpec mutatedSpec = new LegacyVoiceChannelCreateSpec();
/*      */ 
/*      */           
/*      */           spec.accept(mutatedSpec);
/*      */           
/*      */           return this.gateway.getRestClient().getGuildService().createGuildChannel(getId().asLong(), mutatedSpec.asRequest(), mutatedSpec.getReason());
/* 1417 */         }).map(data -> EntityUtil.getChannel(this.gateway, data))
/* 1418 */       .cast(VoiceChannel.class);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public VoiceChannelCreateMono createVoiceChannel(String name) {
/* 1430 */     return VoiceChannelCreateMono.of(name, this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<VoiceChannel> createVoiceChannel(VoiceChannelCreateSpec spec) {
/* 1441 */     Objects.requireNonNull(spec);
/* 1442 */     return Mono.defer(() -> this.gateway.getRestClient().getGuildService().createGuildChannel(getId().asLong(), spec.asRequest(), spec.reason()))
/*      */ 
/*      */       
/* 1445 */       .map(data -> EntityUtil.getChannel(this.gateway, data))
/* 1446 */       .cast(VoiceChannel.class);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AutoModRuleCreateMono createAutoModRule(String name, AutoModRule.EventType eventType, AutoModRule.TriggerType triggerType) {
/* 1460 */     return AutoModRuleCreateMono.of(name, eventType.getValue(), triggerType.getValue(), this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<AutoModRule> createAutoModRule(AutoModRuleCreateSpec spec) {
/* 1471 */     Objects.requireNonNull(spec);
/* 1472 */     return Mono.defer(() -> this.gateway.getRestClient().getAutoModService().createAutoModRule(getId().asLong(), spec.asRequest(), spec.reason()))
/*      */ 
/*      */       
/* 1475 */       .map(data -> new AutoModRule(this.gateway, data));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<Void> delete() {
/* 1485 */     return this.gateway.getRestClient().getGuildService()
/* 1486 */       .deleteGuild(getId().asLong());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<Void> kick(Snowflake userId) {
/* 1497 */     return kick(userId, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<Void> kick(Snowflake userId, @Nullable String reason) {
/* 1509 */     return this.gateway.getRestClient().getGuildService()
/* 1510 */       .removeGuildMember(getId().asLong(), userId.asLong(), reason);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Flux<Ban> getBans() {
/* 1520 */     return this.gateway.getRestClient().getGuildService()
/* 1521 */       .getGuildBans(getId().asLong())
/* 1522 */       .map(data -> new Ban(this.gateway, data));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<Ban> getBan(Snowflake userId) {
/* 1533 */     return this.gateway.getRestClient().getGuildService()
/* 1534 */       .getGuildBan(getId().asLong(), userId.asLong())
/* 1535 */       .map(data -> new Ban(this.gateway, data));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public Mono<Void> ban(Snowflake userId, Consumer<? super LegacyBanQuerySpec> spec) {
/* 1550 */     return Mono.defer(() -> {
/*      */           LegacyBanQuerySpec mutatedSpec = new LegacyBanQuerySpec();
/*      */           spec.accept(mutatedSpec);
/*      */           return this.gateway.getRestClient().getGuildService().createGuildBan(getId().asLong(), userId.asLong(), mutatedSpec.asRequest(), mutatedSpec.getReason());
/*      */         });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public GuildBanQueryMono ban(Snowflake userId) {
/* 1569 */     return GuildBanQueryMono.of(userId, this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<Void> ban(Snowflake userId, BanQuerySpec spec) {
/* 1581 */     Objects.requireNonNull(spec);
/* 1582 */     return Mono.defer(() -> this.gateway.getRestClient().getGuildService().createGuildBan(getId().asLong(), userId.asLong(), spec.asRequest(), spec.reason()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<Void> unban(Snowflake userId) {
/* 1595 */     return unban(userId, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<Void> unban(Snowflake userId, @Nullable String reason) {
/* 1607 */     return this.gateway.getRestClient().getGuildService()
/* 1608 */       .removeGuildBan(getId().asLong(), userId.asLong(), reason);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public Mono<Integer> getPruneCount(Consumer<? super LegacyGuildPruneCountSpec> spec) {
/* 1624 */     return Mono.defer(() -> {
/*      */           LegacyGuildPruneCountSpec mutatedSpec = new LegacyGuildPruneCountSpec();
/*      */           spec.accept(mutatedSpec);
/*      */           return this.gateway.getRestClient().getGuildService().getGuildPruneCount(getId().asLong(), mutatedSpec.asRequest()).flatMap(());
/*      */         });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public GuildPruneCountMono getPruneCount(int days) {
/* 1645 */     return GuildPruneCountMono.of(Integer.valueOf(days), this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<Integer> getPruneCount(GuildPruneCountSpec spec) {
/* 1658 */     Objects.requireNonNull(spec);
/* 1659 */     return Mono.defer(() -> this.gateway.getRestClient().getGuildService().getGuildPruneCount(getId().asLong(), spec.asRequest()).flatMap(()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public Mono<Integer> prune(Consumer<? super LegacyGuildPruneSpec> spec) {
/* 1679 */     return Mono.defer(() -> {
/*      */           LegacyGuildPruneSpec mutatedSpec = new LegacyGuildPruneSpec();
/*      */           spec.accept(mutatedSpec);
/*      */           return this.gateway.getRestClient().getGuildService().beginGuildPrune(getId().asLong(), mutatedSpec.asRequest(), mutatedSpec.getReason()).flatMap(());
/*      */         });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public GuildPruneMono prune(int days) {
/* 1700 */     return GuildPruneMono.of(Integer.valueOf(days), this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<Integer> prune(GuildPruneSpec spec) {
/* 1714 */     Objects.requireNonNull(spec);
/* 1715 */     return Mono.defer(() -> this.gateway.getRestClient().getGuildService().beginGuildPrune(getId().asLong(), spec.asRequest(), spec.reason()).flatMap(()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<Void> leave() {
/* 1728 */     return this.gateway.getRestClient().getUserService()
/* 1729 */       .leaveGuild(getId().asLong());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public Flux<AuditLogPart> getAuditLog(Consumer<? super LegacyAuditLogQuerySpec> spec) {
/* 1752 */     Function<Map<String, Object>, Flux<AuditLogData>> makeRequest = params -> {
/*      */         LegacyAuditLogQuerySpec mutatedSpec = new LegacyAuditLogQuerySpec();
/*      */         
/*      */         spec.accept(mutatedSpec);
/*      */         
/*      */         params.putAll(mutatedSpec.asRequest());
/*      */         return this.gateway.getRestClient().getAuditLogService().getAuditLog(getId().asLong(), params).flux();
/*      */       };
/* 1760 */     ToLongFunction<AuditLogData> getLastEntryId = response -> {
/*      */         List<AuditLogEntryData> entries = response.auditLogEntries();
/*      */         
/*      */         return entries.isEmpty() ? Long.MAX_VALUE : Snowflake.asLong(((AuditLogEntryData)entries.get(entries.size() - 1)).id());
/*      */       };
/* 1765 */     return PaginationUtil.paginateBefore(makeRequest, getLastEntryId, Long.MAX_VALUE, 100)
/* 1766 */       .map(data -> new AuditLogPart(getId().asLong(), this.gateway, data));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AuditLogQueryFlux getAuditLog() {
/* 1787 */     return AuditLogQueryFlux.of(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Flux<AuditLogPart> getAuditLog(AuditLogQuerySpec spec) {
/* 1807 */     Objects.requireNonNull(spec);
/* 1808 */     Function<Map<String, Object>, Flux<AuditLogData>> makeRequest = params -> {
/*      */         params.putAll(spec.asRequest());
/*      */ 
/*      */         
/*      */         return this.gateway.getRestClient().getAuditLogService().getAuditLog(getId().asLong(), params).flux();
/*      */       };
/*      */     
/* 1815 */     ToLongFunction<AuditLogData> getLastEntryId = response -> {
/*      */         List<AuditLogEntryData> entries = response.auditLogEntries();
/*      */         
/*      */         return entries.isEmpty() ? Long.MAX_VALUE : Snowflake.asLong(((AuditLogEntryData)entries.get(entries.size() - 1)).id());
/*      */       };
/*      */     
/* 1821 */     return PaginationUtil.paginateBefore(makeRequest, getLastEntryId, Long.MAX_VALUE, 100)
/* 1822 */       .map(data -> new AuditLogPart(getId().asLong(), this.gateway, data));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Flux<Webhook> getWebhooks() {
/* 1832 */     return this.gateway.getRestClient().getWebhookService()
/* 1833 */       .getGuildWebhooks(getId().asLong())
/* 1834 */       .map(data -> new Webhook(this.gateway, data));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Flux<ExtendedInvite> getInvites() {
/* 1844 */     return this.gateway.getRestClient().getGuildService()
/* 1845 */       .getGuildInvites(getId().asLong())
/* 1846 */       .map(data -> new ExtendedInvite(this.gateway, data));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Flux<GuildTemplate> getTemplates() {
/* 1856 */     return this.gateway.getRestClient().getTemplateService()
/* 1857 */       .getTemplates(getId().asLong())
/* 1858 */       .map(data -> new GuildTemplate(this.gateway, data));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<String> changeSelfNickname(@Nullable String nickname) {
/* 1870 */     return this.gateway.getRestClient().getGuildService()
/* 1871 */       .modifyCurrentMember(getId().asLong(), (CurrentMemberModifyData)CurrentMemberModifyData.builder()
/* 1872 */         .nick(Optional.ofNullable(nickname))
/* 1873 */         .build())
/* 1874 */       .handle((data, sink) -> {
/*      */           String nick = Possible.flatOpt(data.nick()).orElse(null);
/*      */           if (nick != null) {
/*      */             sink.next(nick);
/*      */           } else {
/*      */             sink.complete();
/*      */           } 
/*      */         });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<VoiceConnection> getVoiceConnection() {
/* 1890 */     return this.gateway.getVoiceConnectionRegistry().getVoiceConnection(getId());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Flux<AutoModRule> getAutoModRules() {
/* 1900 */     return this.gateway.getRestClient().getAutoModService()
/* 1901 */       .getAutoModRules(getId().asLong())
/* 1902 */       .map(data -> new AutoModRule(this.gateway, data));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<AutoModRule> getAutoModRule(Snowflake autoModRuleId) {
/* 1911 */     return this.gateway.getRestClient().getAutoModService()
/* 1912 */       .getAutoModRule(getId().asLong(), autoModRuleId.asLong())
/* 1913 */       .map(data -> new AutoModRule(this.gateway, data));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<ScheduledEvent> getScheduledEventById(Snowflake eventId, boolean withUserCount) {
/* 1924 */     return this.gateway.getRestClient().getScheduledEventById(getId(), eventId).getData(Boolean.valueOf(withUserCount))
/* 1925 */       .map(data -> new ScheduledEvent(this.gateway, data));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Flux<ScheduledEvent> getScheduledEvents(boolean withUserCount) {
/* 1935 */     Map<String, Object> queryParams = new HashMap<>();
/* 1936 */     queryParams.put("with_user_count", Boolean.valueOf(withUserCount));
/*      */     
/* 1938 */     return this.gateway.getRestClient().getGuildService().getScheduledEvents(getId().asLong(), queryParams)
/* 1939 */       .map(data -> new ScheduledEvent(this.gateway, data));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<ScheduledEvent> createScheduledEvent(ScheduledEventCreateSpec spec) {
/* 1950 */     return this.gateway.getRestClient().getGuildService().createScheduledEvent(getId().asLong(), spec.asRequest())
/* 1951 */       .map(data -> new ScheduledEvent(this.gateway, data));
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean equals(@Nullable Object obj) {
/* 1956 */     return EntityUtil.equals(this, obj);
/*      */   }
/*      */ 
/*      */   
/*      */   public int hashCode() {
/* 1961 */     return EntityUtil.hashCode(this);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public enum ContentFilterLevel
/*      */   {
/* 1968 */     UNKNOWN(-1),
/*      */ 
/*      */     
/* 1971 */     DISABLED(0),
/*      */ 
/*      */     
/* 1974 */     MEMBERS_WITHOUT_ROLES(1),
/*      */ 
/*      */     
/* 1977 */     ALL_MEMBERS(2);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final int value;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     ContentFilterLevel(int value) {
/* 1988 */       this.value = value;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int getValue() {
/* 1997 */       return this.value;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static ContentFilterLevel of(int value) {
/* 2008 */       switch (value) { case 0:
/* 2009 */           return DISABLED;
/* 2010 */         case 1: return MEMBERS_WITHOUT_ROLES;
/* 2011 */         case 2: return ALL_MEMBERS; }
/* 2012 */        return UNKNOWN;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public enum MfaLevel
/*      */   {
/* 2024 */     UNKNOWN(-1),
/*      */ 
/*      */     
/* 2027 */     NONE(0),
/*      */ 
/*      */     
/* 2030 */     ELEVATED(1);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final int value;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     MfaLevel(int value) {
/* 2041 */       this.value = value;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int getValue() {
/* 2050 */       return this.value;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static MfaLevel of(int value) {
/* 2061 */       switch (value) { case 0:
/* 2062 */           return NONE;
/* 2063 */         case 1: return ELEVATED; }
/* 2064 */        return UNKNOWN;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public enum NotificationLevel
/*      */   {
/* 2076 */     UNKNOWN(-1),
/*      */ 
/*      */     
/* 2079 */     ALL_MESSAGES(0),
/*      */ 
/*      */     
/* 2082 */     ONLY_MENTIONS(1);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final int value;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     NotificationLevel(int value) {
/* 2093 */       this.value = value;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int getValue() {
/* 2102 */       return this.value;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static NotificationLevel of(int value) {
/* 2113 */       switch (value) { case 0:
/* 2114 */           return ALL_MESSAGES;
/* 2115 */         case 1: return ONLY_MENTIONS; }
/* 2116 */        return UNKNOWN;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public enum PremiumTier
/*      */   {
/* 2131 */     UNKNOWN(-1),
/*      */ 
/*      */     
/* 2134 */     NONE(0),
/*      */ 
/*      */     
/* 2137 */     TIER_1(1),
/*      */ 
/*      */     
/* 2140 */     TIER_2(2),
/*      */ 
/*      */     
/* 2143 */     TIER_3(3);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final int value;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     PremiumTier(int value) {
/* 2154 */       this.value = value;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int getValue() {
/* 2163 */       return this.value;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static PremiumTier of(int value) {
/* 2175 */       switch (value) { case 0:
/* 2176 */           return NONE;
/* 2177 */         case 1: return TIER_1;
/* 2178 */         case 2: return TIER_2;
/* 2179 */         case 3: return TIER_3; }
/* 2180 */        return UNKNOWN;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public enum VerificationLevel
/*      */   {
/* 2192 */     UNKNOWN(-1),
/*      */ 
/*      */     
/* 2195 */     NONE(0),
/*      */ 
/*      */     
/* 2198 */     LOW(1),
/*      */ 
/*      */     
/* 2201 */     MEDIUM(2),
/*      */ 
/*      */     
/* 2204 */     HIGH(3),
/*      */ 
/*      */     
/* 2207 */     VERY_HIGH(4);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final int value;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     VerificationLevel(int value) {
/* 2218 */       this.value = value;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int getValue() {
/* 2227 */       return this.value;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static VerificationLevel of(int value) {
/* 2238 */       switch (value) { case 0:
/* 2239 */           return NONE;
/* 2240 */         case 1: return LOW;
/* 2241 */         case 2: return MEDIUM;
/* 2242 */         case 3: return HIGH;
/* 2243 */         case 4: return VERY_HIGH; }
/* 2244 */        return UNKNOWN;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public enum SystemChannelFlag
/*      */   {
/* 2253 */     SUPPRESS_JOIN_NOTIFICATIONS(0),
/*      */ 
/*      */     
/* 2256 */     SUPPRESS_PREMIUM_SUBSCRIPTIONS(1),
/*      */ 
/*      */     
/* 2259 */     SUPPRESS_GUILD_REMINDER_NOTIFICATIONS(2),
/*      */ 
/*      */     
/* 2262 */     SUPPRESS_JOIN_NOTIFICATION_REPLIES(3),
/*      */ 
/*      */     
/* 2265 */     SUPPRESS_ROLE_SUBSCRIPTION_PURCHASE_NOTIFICATIONS(4),
/*      */ 
/*      */     
/* 2268 */     SUPPRESS_ROLE_SUBSCRIPTION_PURCHASE_NOTIFICATION_REPLIES(5);
/*      */ 
/*      */ 
/*      */     
/*      */     private final int value;
/*      */ 
/*      */     
/*      */     private final int flag;
/*      */ 
/*      */ 
/*      */     
/*      */     SystemChannelFlag(int value) {
/* 2280 */       this.value = value;
/* 2281 */       this.flag = 1 << value;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int getValue() {
/* 2290 */       return this.value;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int getFlag() {
/* 2299 */       return this.flag;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static EnumSet<SystemChannelFlag> of(int value) {
/* 2310 */       EnumSet<SystemChannelFlag> flags = EnumSet.noneOf(SystemChannelFlag.class);
/* 2311 */       for (SystemChannelFlag flag : values()) {
/* 2312 */         long flagValue = flag.getFlag();
/* 2313 */         if ((flagValue & value) == flagValue) {
/* 2314 */           flags.add(flag);
/*      */         }
/*      */       } 
/* 2317 */       return flags;
/*      */     }
/*      */   }
/*      */   
/*      */   public enum NsfwLevel
/*      */   {
/* 2323 */     UNKNOWN(-1),
/*      */     
/* 2325 */     DEFAULT(0),
/*      */     
/* 2327 */     EXPLICIT(1),
/*      */     
/* 2329 */     SAFE(2),
/*      */     
/* 2331 */     AGE_RESTRICTED(3);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final int value;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     NsfwLevel(int value) {
/* 2342 */       this.value = value;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int getValue() {
/* 2351 */       return this.value;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static NsfwLevel of(int value) {
/* 2362 */       switch (value) { case 0:
/* 2363 */           return DEFAULT;
/* 2364 */         case 1: return EXPLICIT;
/* 2365 */         case 2: return SAFE;
/* 2366 */         case 3: return AGE_RESTRICTED; }
/* 2367 */        return UNKNOWN;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/* 2374 */     return "Guild{data=" + this.data + '}';
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\object\entity\Guild.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */