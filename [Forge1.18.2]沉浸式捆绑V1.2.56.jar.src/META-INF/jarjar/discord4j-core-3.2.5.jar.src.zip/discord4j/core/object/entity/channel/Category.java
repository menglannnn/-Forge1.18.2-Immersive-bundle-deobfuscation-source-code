/*     */ package discord4j.core.object.entity.channel;
/*     */ 
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.GatewayDiscordClient;
/*     */ import discord4j.core.object.PermissionOverwrite;
/*     */ import discord4j.core.object.entity.Guild;
/*     */ import discord4j.core.object.entity.Member;
/*     */ import discord4j.core.retriever.EntityRetrievalStrategy;
/*     */ import discord4j.core.spec.CategoryEditMono;
/*     */ import discord4j.core.spec.CategoryEditSpec;
/*     */ import discord4j.core.spec.legacy.LegacyCategoryEditSpec;
/*     */ import discord4j.core.util.EntityUtil;
/*     */ import discord4j.discordjson.json.ChannelData;
/*     */ import discord4j.rest.entity.RestChannel;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import java.util.function.Consumer;
/*     */ import org.reactivestreams.Publisher;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Category
/*     */   extends BaseGuildChannel
/*     */ {
/*     */   public Category(GatewayDiscordClient gateway, ChannelData data) {
/*  43 */     super(gateway, data);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Flux<CategorizableChannel> getChannels() {
/*  53 */     return getGuild().flatMapMany(Guild::getChannels)
/*  54 */       .ofType(CategorizableChannel.class)
/*  55 */       .filter(channel -> {
/*     */           Objects.requireNonNull(getId());
/*     */           return ((Boolean)channel.getCategoryId().<Boolean>map(getId()::equals).orElse(Boolean.valueOf(false))).booleanValue();
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Flux<CategorizableChannel> getChannels(EntityRetrievalStrategy retrievalStrategy) {
/*  66 */     return getGuild(retrievalStrategy)
/*  67 */       .flatMapMany(guild -> guild.getChannels(retrievalStrategy))
/*  68 */       .ofType(CategorizableChannel.class)
/*  69 */       .filter(channel -> {
/*     */           Objects.requireNonNull(getId());
/*     */           return ((Boolean)channel.getCategoryId().<Boolean>map(getId()::equals).orElse(Boolean.valueOf(false))).booleanValue();
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public Mono<Category> edit(Consumer<? super LegacyCategoryEditSpec> spec) {
/*  83 */     return Mono.defer(() -> {
/*     */           LegacyCategoryEditSpec mutatedSpec = new LegacyCategoryEditSpec();
/*     */ 
/*     */           
/*     */           spec.accept(mutatedSpec);
/*     */           
/*     */           return getClient().getRestClient().getChannelService().modifyChannel(getId().asLong(), mutatedSpec.asRequest(), mutatedSpec.getReason());
/*  90 */         }).map(data -> EntityUtil.getChannel(getClient(), data))
/*  91 */       .cast(Category.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CategoryEditMono edit() {
/* 102 */     return CategoryEditMono.of(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Category> edit(CategoryEditSpec spec) {
/* 113 */     Objects.requireNonNull(spec);
/* 114 */     return Mono.defer(() -> getClient().getRestClient().getChannelService().modifyChannel(getId().asLong(), spec.asRequest(), spec.reason()))
/*     */ 
/*     */       
/* 117 */       .map(data -> EntityUtil.getChannel(getClient(), data))
/* 118 */       .cast(Category.class);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 123 */     return "Category{} " + super.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\object\entity\channel\Category.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */