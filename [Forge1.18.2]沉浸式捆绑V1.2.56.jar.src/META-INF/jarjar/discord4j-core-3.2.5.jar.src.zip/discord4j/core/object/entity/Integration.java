/*     */ package discord4j.core.object.entity;
/*     */ 
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.GatewayDiscordClient;
/*     */ import discord4j.core.object.IntegrationAccount;
/*     */ import discord4j.core.retriever.EntityRetrievalStrategy;
/*     */ import discord4j.core.util.EntityUtil;
/*     */ import discord4j.discordjson.json.IntegrationApplicationData;
/*     */ import discord4j.discordjson.json.IntegrationData;
/*     */ import discord4j.discordjson.json.UserData;
/*     */ import java.time.Instant;
/*     */ import java.time.format.DateTimeFormatter;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Integration
/*     */   implements Entity
/*     */ {
/*     */   private final GatewayDiscordClient gateway;
/*     */   private final IntegrationData data;
/*     */   private final long guildId;
/*     */   
/*     */   public Integration(GatewayDiscordClient gateway, IntegrationData data, long guildId) {
/*  57 */     this.gateway = Objects.<GatewayDiscordClient>requireNonNull(gateway);
/*  58 */     this.data = Objects.<IntegrationData>requireNonNull(data);
/*  59 */     this.guildId = guildId;
/*     */   }
/*     */ 
/*     */   
/*     */   public GatewayDiscordClient getClient() {
/*  64 */     return this.gateway;
/*     */   }
/*     */ 
/*     */   
/*     */   public Snowflake getId() {
/*  69 */     return Snowflake.of(this.data.id());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Snowflake getGuildId() {
/*  78 */     return Snowflake.of(this.guildId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IntegrationData getData() {
/*  87 */     return this.data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/*  96 */     return this.data.name();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getType() {
/* 105 */     return this.data.type();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEnabled() {
/* 114 */     return ((Boolean)this.data.enabled().toOptional().orElse(Boolean.valueOf(true))).booleanValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSyncing() {
/* 123 */     return ((Boolean)this.data.syncing().toOptional().orElse(Boolean.valueOf(false))).booleanValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<Snowflake> getSubscriberRoleId() {
/* 132 */     return this.data.roleId().toOptional().map(Snowflake::of);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Role> getSubscriberRole() {
/* 142 */     return Mono.justOrEmpty(getSubscriberRoleId())
/* 143 */       .flatMap(id -> this.gateway.getRoleById(getGuildId(), id));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Role> getSubscriberRole(EntityRetrievalStrategy retrievalStrategy) {
/* 154 */     return Mono.justOrEmpty(getSubscriberRoleId())
/* 155 */       .flatMap(id -> this.gateway.withRetrievalStrategy(retrievalStrategy).getRoleById(getGuildId(), id));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEnableEmoticons() {
/* 164 */     return ((Boolean)this.data.enableEmoticons().toOptional().orElse(Boolean.valueOf(false))).booleanValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<ExpireBehavior> getExpireBehavior() {
/* 173 */     return this.data.expireBehavior().toOptional().map(ExpireBehavior::of);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<Integer> getExpireGracePeriod() {
/* 182 */     return this.data.expireGracePeriod().toOptional();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<User> getUser() {
/* 191 */     return this.data.user().toOptional().map(data -> new User(this.gateway, data));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IntegrationAccount getAccount() {
/* 200 */     return new IntegrationAccount(this.gateway, this.data.account());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<Instant> getSyncedAt() {
/* 209 */     return this.data.syncedAt().toOptional()
/* 210 */       .map(timestamp -> (Instant)DateTimeFormatter.ISO_OFFSET_DATE_TIME.<Instant>parse(timestamp, Instant::from));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<Integer> getSubscriberCount() {
/* 219 */     return this.data.subscriberCount().toOptional();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isRevoked() {
/* 228 */     return ((Boolean)this.data.revoked().toOptional().orElse(Boolean.valueOf(false))).booleanValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<IntegrationApplication> getApplication() {
/* 237 */     return this.data.application().toOptional()
/* 238 */       .map(data -> new IntegrationApplication(this.gateway, data));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(@Nullable Object obj) {
/* 243 */     return EntityUtil.equals(this, obj);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 248 */     return EntityUtil.hashCode(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 253 */     return "Integration{data=" + this.data + '}';
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum ExpireBehavior
/*     */   {
/* 262 */     UNKNOWN(-1),
/*     */ 
/*     */     
/* 265 */     REMOVE_ROLE(0),
/*     */ 
/*     */     
/* 268 */     KICK(1);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final int value;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     ExpireBehavior(int value) {
/* 279 */       this.value = value;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int getValue() {
/* 288 */       return this.value;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static ExpireBehavior of(int value) {
/* 299 */       switch (value) { case 0:
/* 300 */           return REMOVE_ROLE;
/* 301 */         case 1: return KICK; }
/* 302 */        return UNKNOWN;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\object\entity\Integration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */