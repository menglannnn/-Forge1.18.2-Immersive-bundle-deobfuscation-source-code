/*     */ package discord4j.core.object.entity;
/*     */ 
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.GatewayDiscordClient;
/*     */ import discord4j.core.util.EntityUtil;
/*     */ import discord4j.discordjson.json.AttachmentData;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import java.util.OptionalInt;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Attachment
/*     */   implements Entity
/*     */ {
/*     */   public static final String SPOILER_PREFIX = "SPOILER_";
/*     */   private final GatewayDiscordClient gateway;
/*     */   private final AttachmentData data;
/*     */   
/*     */   public Attachment(GatewayDiscordClient gateway, AttachmentData data) {
/*  55 */     this.gateway = Objects.<GatewayDiscordClient>requireNonNull(gateway);
/*  56 */     this.data = Objects.<AttachmentData>requireNonNull(data);
/*     */   }
/*     */ 
/*     */   
/*     */   public GatewayDiscordClient getClient() {
/*  61 */     return this.gateway;
/*     */   }
/*     */ 
/*     */   
/*     */   public Snowflake getId() {
/*  66 */     return Snowflake.of(this.data.id());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AttachmentData getData() {
/*  75 */     return this.data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFilename() {
/*  84 */     return this.data.filename();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSize() {
/*  93 */     return this.data.size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getUrl() {
/* 102 */     return this.data.url();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getProxyUrl() {
/* 111 */     return this.data.proxyUrl();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OptionalInt getHeight() {
/* 120 */     return Possible.flatOpt(this.data.height())
/* 121 */       .map(OptionalInt::of)
/* 122 */       .orElse(OptionalInt.empty());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OptionalInt getWidth() {
/* 131 */     return Possible.flatOpt(this.data.width())
/* 132 */       .map(OptionalInt::of)
/* 133 */       .orElse(OptionalInt.empty());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSpoiler() {
/* 142 */     return getFilename().startsWith("SPOILER_");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<String> getContentType() {
/* 151 */     return this.data.contentType().toOptional();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(@Nullable Object obj) {
/* 156 */     return EntityUtil.equals(this, obj);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 161 */     return EntityUtil.hashCode(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 166 */     return "Attachment{data=" + this.data + '}';
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\object\entity\Attachment.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */