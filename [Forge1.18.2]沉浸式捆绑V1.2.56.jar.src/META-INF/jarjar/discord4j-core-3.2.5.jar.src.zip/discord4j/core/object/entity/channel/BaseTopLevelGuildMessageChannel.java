/*     */ package discord4j.core.object.entity.channel;
/*     */ 
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.GatewayDiscordClient;
/*     */ import discord4j.core.object.entity.Member;
/*     */ import discord4j.core.object.entity.Message;
/*     */ import discord4j.core.object.entity.Webhook;
/*     */ import discord4j.core.retriever.EntityRetrievalStrategy;
/*     */ import discord4j.core.spec.MessageCreateSpec;
/*     */ import discord4j.core.spec.WebhookCreateSpec;
/*     */ import discord4j.core.spec.legacy.LegacyMessageCreateSpec;
/*     */ import discord4j.core.spec.legacy.LegacyWebhookCreateSpec;
/*     */ import discord4j.discordjson.json.ChannelData;
/*     */ import java.time.Instant;
/*     */ import java.util.Optional;
/*     */ import java.util.function.Consumer;
/*     */ import org.reactivestreams.Publisher;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class BaseTopLevelGuildMessageChannel
/*     */   extends BaseCategorizableChannel
/*     */   implements TopLevelGuildMessageChannel
/*     */ {
/*     */   private final BaseGuildMessageChannel guildMessageChannel;
/*     */   
/*     */   BaseTopLevelGuildMessageChannel(GatewayDiscordClient gateway, ChannelData data) {
/*  43 */     super(gateway, data);
/*  44 */     this.guildMessageChannel = new BaseGuildMessageChannel(gateway, data);
/*     */   }
/*     */ 
/*     */   
/*     */   public Flux<Snowflake> bulkDelete(Publisher<Snowflake> messageIds) {
/*  49 */     return this.guildMessageChannel.bulkDelete(messageIds);
/*     */   }
/*     */ 
/*     */   
/*     */   public Flux<Message> bulkDeleteMessages(Publisher<Message> messages) {
/*  54 */     return this.guildMessageChannel.bulkDeleteMessages(messages);
/*     */   }
/*     */ 
/*     */   
/*     */   public Flux<Member> getMembers() {
/*  59 */     return this.guildMessageChannel.getMembers();
/*     */   }
/*     */ 
/*     */   
/*     */   public Optional<Snowflake> getLastMessageId() {
/*  64 */     return this.guildMessageChannel.getLastMessageId();
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Message> getLastMessage() {
/*  69 */     return this.guildMessageChannel.getLastMessage();
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Message> getLastMessage(EntityRetrievalStrategy retrievalStrategy) {
/*  74 */     return this.guildMessageChannel.getLastMessage(retrievalStrategy);
/*     */   }
/*     */ 
/*     */   
/*     */   public Optional<Instant> getLastPinTimestamp() {
/*  79 */     return this.guildMessageChannel.getLastPinTimestamp();
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Message> createMessage(Consumer<? super LegacyMessageCreateSpec> spec) {
/*  84 */     return this.guildMessageChannel.createMessage(spec);
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Message> createMessage(MessageCreateSpec spec) {
/*  89 */     return this.guildMessageChannel.createMessage(spec);
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> type() {
/*  94 */     return this.guildMessageChannel.type();
/*     */   }
/*     */ 
/*     */   
/*     */   public Flux<Long> typeUntil(Publisher<?> until) {
/*  99 */     return this.guildMessageChannel.typeUntil(until);
/*     */   }
/*     */ 
/*     */   
/*     */   public Flux<Message> getMessagesBefore(Snowflake messageId) {
/* 104 */     return this.guildMessageChannel.getMessagesBefore(messageId);
/*     */   }
/*     */ 
/*     */   
/*     */   public Flux<Message> getMessagesAfter(Snowflake messageId) {
/* 109 */     return this.guildMessageChannel.getMessagesAfter(messageId);
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Message> getMessageById(Snowflake id) {
/* 114 */     return this.guildMessageChannel.getMessageById(id);
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Message> getMessageById(Snowflake id, EntityRetrievalStrategy retrievalStrategy) {
/* 119 */     return this.guildMessageChannel.getMessageById(id, retrievalStrategy);
/*     */   }
/*     */ 
/*     */   
/*     */   public Flux<Message> getPinnedMessages() {
/* 124 */     return this.guildMessageChannel.getPinnedMessages();
/*     */   }
/*     */ 
/*     */   
/*     */   public Optional<String> getTopic() {
/* 129 */     return this.guildMessageChannel.getTopic();
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Webhook> createWebhook(Consumer<? super LegacyWebhookCreateSpec> spec) {
/* 134 */     return this.guildMessageChannel.createWebhook(spec);
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Webhook> createWebhook(WebhookCreateSpec spec) {
/* 139 */     return this.guildMessageChannel.createWebhook(spec);
/*     */   }
/*     */ 
/*     */   
/*     */   public Flux<Webhook> getWebhooks() {
/* 144 */     return this.guildMessageChannel.getWebhooks();
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\object\entity\channel\BaseTopLevelGuildMessageChannel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */