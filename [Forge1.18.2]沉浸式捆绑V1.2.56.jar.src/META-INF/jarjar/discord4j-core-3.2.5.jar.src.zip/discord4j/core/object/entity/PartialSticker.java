/*    */ package discord4j.core.object.entity;
/*    */ 
/*    */ import discord4j.common.util.Snowflake;
/*    */ import discord4j.core.GatewayDiscordClient;
/*    */ import discord4j.core.util.ImageUtil;
/*    */ import discord4j.discordjson.json.PartialStickerData;
/*    */ import discord4j.rest.util.Image;
/*    */ import java.util.Objects;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PartialSticker
/*    */   implements Entity
/*    */ {
/*    */   private static final String STICKER_IMAGE_PATH = "stickers/%s";
/*    */   protected final GatewayDiscordClient gateway;
/*    */   private final PartialStickerData data;
/*    */   
/*    */   public PartialSticker(GatewayDiscordClient gateway, PartialStickerData data) {
/* 29 */     this.gateway = Objects.<GatewayDiscordClient>requireNonNull(gateway);
/* 30 */     this.data = Objects.<PartialStickerData>requireNonNull(data);
/*    */   }
/*    */ 
/*    */   
/*    */   public GatewayDiscordClient getClient() {
/* 35 */     return this.gateway;
/*    */   }
/*    */ 
/*    */   
/*    */   public Snowflake getId() {
/* 40 */     return Snowflake.of(this.data.id());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getName() {
/* 49 */     return this.data.name();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Sticker.Format getFormatType() {
/* 58 */     return Sticker.Format.of(this.data.formatType());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getImageUrl() {
/* 67 */     String path = String.format("stickers/%s", new Object[] { getId().asString() });
/* 68 */     return getFormatType().equals(Sticker.Format.LOTTIE) ? ImageUtil.getUrl(path, Image.Format.LOTTIE) : ImageUtil.getUrl(path, Image.Format.PNG);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public PartialStickerData getStickerData() {
/* 77 */     return this.data;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\object\entity\PartialSticker.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */