/*     */ package discord4j.core.object.entity.channel;
/*     */ 
/*     */ import discord4j.core.object.entity.Entity;
/*     */ import discord4j.rest.entity.RestChannel;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface Channel
/*     */   extends Entity
/*     */ {
/*     */   Type getType();
/*     */   
/*     */   default Mono<Void> delete() {
/*  45 */     return delete(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Mono<Void> delete(@Nullable String paramString);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default String getMention() {
/*  63 */     return "<#" + getId().asString() + '>';
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   RestChannel getRestChannel();
/*     */ 
/*     */ 
/*     */   
/*     */   public enum Type
/*     */   {
/*  75 */     UNKNOWN(-1),
/*     */ 
/*     */     
/*  78 */     GUILD_TEXT(0),
/*     */ 
/*     */     
/*  81 */     DM(1),
/*     */ 
/*     */     
/*  84 */     GUILD_VOICE(2),
/*     */ 
/*     */     
/*  87 */     GROUP_DM(3),
/*     */ 
/*     */     
/*  90 */     GUILD_CATEGORY(4),
/*     */ 
/*     */     
/*  93 */     GUILD_NEWS(5),
/*     */ 
/*     */     
/*  96 */     GUILD_STORE(6),
/*     */ 
/*     */     
/*  99 */     GUILD_STAGE_VOICE(13);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final int value;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Type(int value) {
/* 110 */       this.value = value;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int getValue() {
/* 119 */       return this.value;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Type of(int value) {
/* 130 */       switch (value) { case 0:
/* 131 */           return GUILD_TEXT;
/* 132 */         case 1: return DM;
/* 133 */         case 2: return GUILD_VOICE;
/* 134 */         case 3: return GROUP_DM;
/* 135 */         case 4: return GUILD_CATEGORY;
/* 136 */         case 5: return GUILD_NEWS;
/* 137 */         case 6: return GUILD_STORE;
/* 138 */         case 13: return GUILD_STAGE_VOICE; }
/* 139 */        return UNKNOWN;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\object\entity\channel\Channel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */