/*    */ package discord4j.core.object.entity.channel;
/*    */ 
/*    */ import discord4j.common.util.Snowflake;
/*    */ import discord4j.core.GatewayDiscordClient;
/*    */ import discord4j.core.object.PermissionOverwrite;
/*    */ import discord4j.core.object.entity.Member;
/*    */ import discord4j.core.retriever.EntityRetrievalStrategy;
/*    */ import discord4j.core.spec.InviteCreateSpec;
/*    */ import discord4j.core.spec.StoreChannelEditMono;
/*    */ import discord4j.core.spec.StoreChannelEditSpec;
/*    */ import discord4j.core.spec.legacy.LegacyInviteCreateSpec;
/*    */ import discord4j.core.spec.legacy.LegacyStoreChannelEditSpec;
/*    */ import discord4j.core.util.EntityUtil;
/*    */ import discord4j.discordjson.json.ChannelData;
/*    */ import discord4j.rest.entity.RestChannel;
/*    */ import java.util.Objects;
/*    */ import java.util.Optional;
/*    */ import java.util.function.Consumer;
/*    */ import reactor.core.publisher.Flux;
/*    */ import reactor.core.publisher.Mono;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class StoreChannel
/*    */   extends BaseCategorizableChannel
/*    */ {
/*    */   public StoreChannel(GatewayDiscordClient gateway, ChannelData data) {
/* 40 */     super(gateway, data);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Deprecated
/*    */   public Mono<StoreChannel> edit(Consumer<? super LegacyStoreChannelEditSpec> spec) {
/* 54 */     return Mono.defer(() -> {
/*    */           LegacyStoreChannelEditSpec mutatedSpec = new LegacyStoreChannelEditSpec();
/*    */ 
/*    */           
/*    */           spec.accept(mutatedSpec);
/*    */           
/*    */           return getClient().getRestClient().getChannelService().modifyChannel(getId().asLong(), mutatedSpec.asRequest(), mutatedSpec.getReason());
/* 61 */         }).map(data -> EntityUtil.getChannel(getClient(), data))
/* 62 */       .cast(StoreChannel.class);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public StoreChannelEditMono edit() {
/* 73 */     return StoreChannelEditMono.of(this);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Mono<StoreChannel> edit(StoreChannelEditSpec spec) {
/* 84 */     Objects.requireNonNull(spec);
/* 85 */     return Mono.defer(() -> getClient().getRestClient().getChannelService().modifyChannel(getId().asLong(), spec.asRequest(), spec.reason()))
/*    */ 
/*    */       
/* 88 */       .map(data -> EntityUtil.getChannel(getClient(), data))
/* 89 */       .cast(StoreChannel.class);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 94 */     return "StoreChannel{} " + super.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\object\entity\channel\StoreChannel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */