/*    */ package discord4j.core.object;
/*    */ 
/*    */ import discord4j.common.util.Snowflake;
/*    */ import discord4j.core.GatewayDiscordClient;
/*    */ import discord4j.core.object.command.ApplicationCommandOption;
/*    */ import discord4j.core.object.entity.User;
/*    */ import discord4j.discordjson.json.MessageInteractionData;
/*    */ import java.util.Objects;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MessageInteraction
/*    */   implements DiscordObject
/*    */ {
/*    */   private final GatewayDiscordClient gateway;
/*    */   private final MessageInteractionData data;
/*    */   
/*    */   public MessageInteraction(GatewayDiscordClient gateway, MessageInteractionData data) {
/* 49 */     this.gateway = Objects.<GatewayDiscordClient>requireNonNull(gateway);
/* 50 */     this.data = Objects.<MessageInteractionData>requireNonNull(data);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Snowflake getId() {
/* 59 */     return Snowflake.of(this.data.id());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ApplicationCommandOption.Type getType() {
/* 68 */     return ApplicationCommandOption.Type.of(this.data.type());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getName() {
/* 77 */     return this.data.name();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public User getUser() {
/* 86 */     return new User(this.gateway, this.data.user());
/*    */   }
/*    */ 
/*    */   
/*    */   public final GatewayDiscordClient getClient() {
/* 91 */     return this.gateway;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\object\MessageInteraction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */