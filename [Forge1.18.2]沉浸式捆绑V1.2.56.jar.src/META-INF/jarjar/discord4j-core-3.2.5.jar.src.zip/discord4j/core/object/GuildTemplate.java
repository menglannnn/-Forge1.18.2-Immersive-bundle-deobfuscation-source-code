/*     */ package discord4j.core.object;
/*     */ 
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.GatewayDiscordClient;
/*     */ import discord4j.core.object.entity.Guild;
/*     */ import discord4j.core.object.entity.User;
/*     */ import discord4j.core.spec.GuildCreateFromTemplateMono;
/*     */ import discord4j.core.spec.GuildCreateFromTemplateSpec;
/*     */ import discord4j.core.spec.GuildTemplateEditMono;
/*     */ import discord4j.core.spec.GuildTemplateEditSpec;
/*     */ import discord4j.core.spec.legacy.LegacyGuildCreateFromTemplateSpec;
/*     */ import discord4j.core.spec.legacy.LegacyGuildTemplateEditSpec;
/*     */ import discord4j.discordjson.json.GuildData;
/*     */ import discord4j.discordjson.json.SerializedSourceGuildData;
/*     */ import discord4j.discordjson.json.TemplateData;
/*     */ import java.time.Instant;
/*     */ import java.time.format.DateTimeFormatter;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import java.util.function.Consumer;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class GuildTemplate
/*     */   implements DiscordObject
/*     */ {
/*     */   private final GatewayDiscordClient gateway;
/*     */   private final TemplateData data;
/*     */   private final long guildId;
/*     */   
/*     */   public GuildTemplate(GatewayDiscordClient gateway, TemplateData data) {
/*  62 */     this.gateway = Objects.<GatewayDiscordClient>requireNonNull(gateway);
/*  63 */     this.data = Objects.<TemplateData>requireNonNull(data);
/*  64 */     this.guildId = Snowflake.asLong(data.sourceGuildId());
/*     */   }
/*     */ 
/*     */   
/*     */   public GatewayDiscordClient getClient() {
/*  69 */     return this.gateway;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TemplateData getData() {
/*  78 */     return this.data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCode() {
/*  87 */     return this.data.code();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Snowflake getGuildId() {
/*  96 */     return Snowflake.of(this.guildId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 105 */     return this.data.name();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<String> getDescription() {
/* 114 */     return this.data.description();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getUsageCount() {
/* 123 */     return this.data.usageCount();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Snowflake getCreatorId() {
/* 132 */     return Snowflake.of(this.data.creatorId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public User getCreator() {
/* 141 */     return new User(this.gateway, this.data.creator());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Instant getCreatedAt() {
/* 150 */     return DateTimeFormatter.ISO_OFFSET_DATE_TIME.<Instant>parse(this.data.createdAt(), Instant::from);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Instant getUpdatedAt() {
/* 159 */     return DateTimeFormatter.ISO_OFFSET_DATE_TIME.<Instant>parse(this.data.updatedAt(), Instant::from);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SerializedSourceGuildData getSourceGuild() {
/* 168 */     return this.data.serializedSourceGuild();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public Mono<Guild> createGuild(Consumer<? super LegacyGuildCreateFromTemplateSpec> spec) {
/* 183 */     return Mono.defer(() -> {
/*     */           LegacyGuildCreateFromTemplateSpec mutatedSpec = new LegacyGuildCreateFromTemplateSpec();
/*     */ 
/*     */           
/*     */           spec.accept(mutatedSpec);
/*     */           
/*     */           return this.gateway.getRestClient().getTemplateService().createGuild(getCode(), mutatedSpec.asRequest());
/* 190 */         }).map(data -> new Guild(this.gateway, data));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GuildCreateFromTemplateMono createGuild(String name) {
/* 202 */     return GuildCreateFromTemplateMono.of(name, this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Guild> createGuild(GuildCreateFromTemplateSpec spec) {
/* 213 */     Objects.requireNonNull(spec);
/* 214 */     return Mono.defer(() -> this.gateway.getRestClient().getTemplateService().createGuild(getCode(), spec.asRequest()))
/* 215 */       .map(data -> new Guild(this.gateway, data));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<GuildTemplate> sync() {
/* 225 */     return this.gateway.getRestClient().getTemplateService()
/* 226 */       .syncTemplate(this.guildId, getCode())
/* 227 */       .map(data -> new GuildTemplate(this.gateway, data));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public Mono<GuildTemplate> edit(Consumer<? super LegacyGuildTemplateEditSpec> spec) {
/* 241 */     return Mono.defer(() -> {
/*     */           LegacyGuildTemplateEditSpec mutatedSpec = new LegacyGuildTemplateEditSpec();
/*     */ 
/*     */           
/*     */           spec.accept(mutatedSpec);
/*     */           
/*     */           return this.gateway.getRestClient().getTemplateService().modifyTemplate(this.guildId, getCode(), mutatedSpec.asRequest());
/* 248 */         }).map(data -> new GuildTemplate(this.gateway, data));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GuildTemplateEditMono edit() {
/* 259 */     return GuildTemplateEditMono.of(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<GuildTemplate> edit(GuildTemplateEditSpec spec) {
/* 270 */     Objects.requireNonNull(spec);
/* 271 */     return Mono.defer(() -> this.gateway.getRestClient().getTemplateService().modifyTemplate(this.guildId, getCode(), spec.asRequest()))
/*     */       
/* 273 */       .map(data -> new GuildTemplate(this.gateway, data));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<GuildTemplate> delete() {
/* 283 */     return this.gateway.getRestClient().getTemplateService()
/* 284 */       .deleteTemplate(this.guildId, getCode())
/* 285 */       .map(data -> new GuildTemplate(this.gateway, data));
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\object\GuildTemplate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */