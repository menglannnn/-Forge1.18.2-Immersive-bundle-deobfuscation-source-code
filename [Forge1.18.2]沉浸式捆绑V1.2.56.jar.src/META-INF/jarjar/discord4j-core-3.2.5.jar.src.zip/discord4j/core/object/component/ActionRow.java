/*    */ package discord4j.core.object.component;
/*    */ 
/*    */ import discord4j.discordjson.json.ComponentData;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ import java.util.Objects;
/*    */ import java.util.stream.Collectors;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ActionRow
/*    */   extends LayoutComponent
/*    */ {
/*    */   public static ActionRow of(ActionComponent... components) {
/* 40 */     return of(Arrays.asList(components));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static ActionRow of(List<? extends ActionComponent> components) {
/* 50 */     return new ActionRow((ComponentData)ComponentData.builder()
/* 51 */         .type(MessageComponent.Type.ACTION_ROW.getValue())
/* 52 */         .components((List)components.stream().map(MessageComponent::getData).collect(Collectors.toList()))
/* 53 */         .build());
/*    */   }
/*    */   
/*    */   ActionRow(ComponentData data) {
/* 57 */     super(data);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ActionRow withAddedComponent(ActionComponent component) {
/* 67 */     List<MessageComponent> components = new ArrayList<>(getChildren());
/* 68 */     components.add(component);
/* 69 */     return new ActionRow((ComponentData)ComponentData.builder()
/* 70 */         .type(MessageComponent.Type.ACTION_ROW.getValue())
/* 71 */         .components((List)components.stream().map(MessageComponent::getData).collect(Collectors.toList()))
/* 72 */         .build());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ActionRow withRemovedComponent(String customId) {
/* 88 */     List<MessageComponent> components = (List<MessageComponent>)getChildren().stream().filter(it -> { Objects.requireNonNull(customId); return !it.getData().customId().toOptional().filter(customId::equals).isPresent(); }).collect(Collectors.toList());
/* 89 */     return new ActionRow((ComponentData)ComponentData.builder()
/* 90 */         .type(MessageComponent.Type.ACTION_ROW.getValue())
/* 91 */         .components((List)components.stream().map(MessageComponent::getData).collect(Collectors.toList()))
/* 92 */         .build());
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\object\component\ActionRow.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */