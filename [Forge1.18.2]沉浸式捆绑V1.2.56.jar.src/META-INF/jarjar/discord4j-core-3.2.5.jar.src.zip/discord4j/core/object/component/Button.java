/*     */ package discord4j.core.object.component;
/*     */ 
/*     */ import discord4j.core.object.reaction.ReactionEmoji;
/*     */ import discord4j.discordjson.json.ComponentData;
/*     */ import discord4j.discordjson.json.ImmutableComponentData;
/*     */ import java.util.Optional;
/*     */ import java.util.function.Supplier;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Button
/*     */   extends ActionComponent
/*     */ {
/*     */   public static Button primary(String customId, String label) {
/*  41 */     return of(Style.PRIMARY, customId, null, label, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Button primary(String customId, ReactionEmoji emoji) {
/*  52 */     return of(Style.PRIMARY, customId, emoji, null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Button primary(String customId, ReactionEmoji emoji, String label) {
/*  64 */     return of(Style.PRIMARY, customId, emoji, label, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Button secondary(String customId, String label) {
/*  75 */     return of(Style.SECONDARY, customId, null, label, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Button secondary(String customId, ReactionEmoji emoji) {
/*  86 */     return of(Style.SECONDARY, customId, emoji, null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Button secondary(String customId, ReactionEmoji emoji, String label) {
/*  98 */     return of(Style.SECONDARY, customId, emoji, label, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Button success(String customId, String label) {
/* 109 */     return of(Style.SUCCESS, customId, null, label, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Button success(String customId, ReactionEmoji emoji) {
/* 120 */     return of(Style.SUCCESS, customId, emoji, null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Button success(String customId, ReactionEmoji emoji, String label) {
/* 132 */     return of(Style.SUCCESS, customId, emoji, label, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Button danger(String customId, String label) {
/* 143 */     return of(Style.DANGER, customId, null, label, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Button danger(String customId, ReactionEmoji emoji) {
/* 154 */     return of(Style.DANGER, customId, emoji, null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Button danger(String customId, ReactionEmoji emoji, String label) {
/* 166 */     return of(Style.DANGER, customId, emoji, label, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Button link(String url, String label) {
/* 177 */     return of(Style.LINK, null, null, label, url);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Button link(String url, ReactionEmoji emoji) {
/* 188 */     return of(Style.LINK, null, emoji, null, url);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Button link(String url, ReactionEmoji emoji, String label) {
/* 200 */     return of(Style.LINK, null, emoji, label, url);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static Button of(Style style, @Nullable String customId, @Nullable ReactionEmoji emoji, @Nullable String label, @Nullable String url) {
/* 206 */     ImmutableComponentData.Builder builder = ComponentData.builder().type(MessageComponent.Type.BUTTON.getValue()).style(Integer.valueOf(style.getValue()));
/*     */     
/* 208 */     if (customId != null) {
/* 209 */       builder.customId(customId);
/*     */     }
/* 211 */     if (emoji != null) {
/* 212 */       builder.emoji(emoji.asEmojiData());
/*     */     }
/* 214 */     if (label != null) {
/* 215 */       builder.label(label);
/*     */     }
/* 217 */     if (url != null) {
/* 218 */       builder.url(url);
/*     */     }
/* 220 */     return new Button((ComponentData)builder.build());
/*     */   }
/*     */   
/*     */   Button(ComponentData data) {
/* 224 */     super(data);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Style getStyle() {
/* 233 */     return (Style)getData().style().toOptional()
/* 234 */       .map(Style::of)
/* 235 */       .orElseThrow(IllegalStateException::new);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<String> getLabel() {
/* 244 */     return getData().label().toOptional();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<ReactionEmoji> getEmoji() {
/* 253 */     return getData().emoji().toOptional()
/* 254 */       .map(ReactionEmoji::of);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<String> getCustomId() {
/* 263 */     return getData().customId().toOptional();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<String> getUrl() {
/* 272 */     return getData().url().toOptional();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDisabled() {
/* 281 */     return ((Boolean)getData().disabled().toOptional().orElse(Boolean.valueOf(false))).booleanValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Button disabled() {
/* 290 */     return disabled(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Button disabled(boolean value) {
/* 300 */     return new Button((ComponentData)ComponentData.builder().from(getData()).disabled(Boolean.valueOf(value)).build());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum Style
/*     */   {
/* 309 */     UNKNOWN(-1),
/* 310 */     PRIMARY(1),
/* 311 */     SECONDARY(2),
/* 312 */     SUCCESS(3),
/* 313 */     DANGER(4),
/* 314 */     LINK(5);
/*     */     
/*     */     private final int value;
/*     */     
/*     */     Style(int value) {
/* 319 */       this.value = value;
/*     */     }
/*     */     
/*     */     public int getValue() {
/* 323 */       return this.value;
/*     */     }
/*     */     
/*     */     public static Style of(int value) {
/* 327 */       switch (value) { case 1:
/* 328 */           return PRIMARY;
/* 329 */         case 2: return SECONDARY;
/* 330 */         case 3: return SUCCESS;
/* 331 */         case 4: return DANGER;
/* 332 */         case 5: return LINK; }
/* 333 */        return UNKNOWN;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\object\component\Button.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */