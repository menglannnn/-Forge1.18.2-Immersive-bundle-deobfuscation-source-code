/*     */ package discord4j.core.object.component;
/*     */ 
/*     */ import discord4j.discordjson.json.ComponentData;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MessageComponent
/*     */ {
/*     */   private final ComponentData data;
/*     */   
/*     */   public static MessageComponent fromData(ComponentData data) {
/*  37 */     switch (Type.of(data.type())) { case ACTION_ROW:
/*  38 */         return new ActionRow(data);
/*  39 */       case BUTTON: return new Button(data);
/*     */       case SELECT_MENU_ROLE: case SELECT_MENU_CHANNEL:
/*     */       case SELECT_MENU_MENTIONABLE:
/*     */       case SELECT_MENU_USER:
/*     */       case SELECT_MENU:
/*  44 */         return new SelectMenu(data);
/*  45 */       case TEXT_INPUT: return new TextInput(data); }
/*  46 */      return new MessageComponent(data);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MessageComponent(ComponentData data) {
/*  53 */     this.data = data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ComponentData getData() {
/*  62 */     return this.data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Type getType() {
/*  71 */     return Type.of(this.data.type());
/*     */   }
/*     */   
/*     */   public enum Type {
/*  75 */     UNKNOWN(-1),
/*  76 */     ACTION_ROW(1),
/*  77 */     BUTTON(2),
/*  78 */     SELECT_MENU(3),
/*  79 */     TEXT_INPUT(4),
/*  80 */     SELECT_MENU_USER(5),
/*  81 */     SELECT_MENU_ROLE(6),
/*  82 */     SELECT_MENU_MENTIONABLE(7),
/*  83 */     SELECT_MENU_CHANNEL(8);
/*     */     
/*     */     private final int value;
/*     */     
/*     */     Type(int value) {
/*  88 */       this.value = value;
/*     */     }
/*     */     
/*     */     public int getValue() {
/*  92 */       return this.value;
/*     */     }
/*     */     
/*     */     public static Type of(int value) {
/*  96 */       switch (value) { case 1:
/*  97 */           return ACTION_ROW;
/*  98 */         case 2: return BUTTON;
/*  99 */         case 3: return SELECT_MENU;
/* 100 */         case 4: return TEXT_INPUT;
/* 101 */         case 5: return SELECT_MENU_USER;
/* 102 */         case 6: return SELECT_MENU_ROLE;
/* 103 */         case 7: return SELECT_MENU_MENTIONABLE;
/* 104 */         case 8: return SELECT_MENU_CHANNEL; }
/* 105 */        return UNKNOWN;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\object\component\MessageComponent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */