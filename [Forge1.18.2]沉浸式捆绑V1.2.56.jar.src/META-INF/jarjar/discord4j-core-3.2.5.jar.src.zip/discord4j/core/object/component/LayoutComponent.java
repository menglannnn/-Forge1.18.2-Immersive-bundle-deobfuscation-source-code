/*    */ package discord4j.core.object.component;
/*    */ 
/*    */ import discord4j.common.annotations.Experimental;
/*    */ import discord4j.discordjson.json.ComponentData;
/*    */ import java.util.List;
/*    */ import java.util.function.Supplier;
/*    */ import java.util.stream.Collectors;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Experimental
/*    */ public abstract class LayoutComponent
/*    */   extends MessageComponent
/*    */ {
/*    */   LayoutComponent(ComponentData data) {
/* 33 */     super(data);
/*    */   }
/*    */   
/*    */   public List<MessageComponent> getChildren() {
/* 37 */     return (List<MessageComponent>)getData().components().toOptional()
/* 38 */       .map(components -> (List)components.stream().map(MessageComponent::fromData).collect(Collectors.toList()))
/*    */ 
/*    */       
/* 41 */       .orElseThrow(IllegalStateException::new);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\object\component\LayoutComponent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */