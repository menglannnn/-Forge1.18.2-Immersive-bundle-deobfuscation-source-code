/*     */ package discord4j.core.object.component;
/*     */ 
/*     */ import discord4j.core.object.entity.channel.Channel;
/*     */ import discord4j.core.object.reaction.ReactionEmoji;
/*     */ import discord4j.discordjson.json.ComponentData;
/*     */ import discord4j.discordjson.json.ImmutableComponentData;
/*     */ import discord4j.discordjson.json.SelectOptionData;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.EnumSet;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import java.util.Set;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Supplier;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.stream.StreamSupport;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SelectMenu
/*     */   extends ActionComponent
/*     */ {
/*     */   public static SelectMenu of(String customId, Option... options) {
/*  45 */     return of(MessageComponent.Type.SELECT_MENU, customId, Arrays.asList(options), (List<Channel.Type>)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static SelectMenu of(String customId, List<Option> options) {
/*  56 */     Objects.requireNonNull(options);
/*  57 */     return of(MessageComponent.Type.SELECT_MENU, customId, options, (List<Channel.Type>)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static SelectMenu ofRole(String customId) {
/*  67 */     return of(MessageComponent.Type.SELECT_MENU_ROLE, customId, (List<Option>)null, (List<Channel.Type>)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static SelectMenu ofUser(String customId) {
/*  77 */     return of(MessageComponent.Type.SELECT_MENU_USER, customId, (List<Option>)null, (List<Channel.Type>)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static SelectMenu ofMentionable(String customId) {
/*  87 */     return of(MessageComponent.Type.SELECT_MENU_MENTIONABLE, customId, (List<Option>)null, (List<Channel.Type>)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static SelectMenu ofChannel(String customId, Channel.Type... channelTypes) {
/*  98 */     return of(MessageComponent.Type.SELECT_MENU_CHANNEL, customId, (List<Option>)null, Arrays.asList(channelTypes));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static SelectMenu ofChannel(String customId, List<Channel.Type> channelTypes) {
/* 109 */     return of(MessageComponent.Type.SELECT_MENU_CHANNEL, customId, (List<Option>)null, channelTypes);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static SelectMenu of(MessageComponent.Type type, String customId, @Nullable List<Option> options, @Nullable List<Channel.Type> channelTypes) {
/* 115 */     ImmutableComponentData.Builder builder = ComponentData.builder().type(type.getValue()).customId(customId);
/*     */     
/* 117 */     if (options != null) {
/* 118 */       builder.options((List)options.stream().map(opt -> opt.data).collect(Collectors.toList()));
/*     */     }
/*     */     
/* 121 */     if (channelTypes != null) {
/* 122 */       builder.channelTypes((List)channelTypes.stream()
/* 123 */           .map(Channel.Type::getValue)
/* 124 */           .collect(Collectors.toList()));
/*     */     }
/*     */     
/* 127 */     return new SelectMenu((ComponentData)builder.build());
/*     */   }
/*     */   
/*     */   SelectMenu(ComponentData data) {
/* 131 */     super(data);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCustomId() {
/* 140 */     return (String)getData().customId().toOptional().orElseThrow(IllegalStateException::new);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<List<String>> getValues() {
/* 149 */     return getData().values().toOptional();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<Channel.Type> getAllowedChannelTypes() {
/* 159 */     return (Set<Channel.Type>)((List)getData().channelTypes().toOptional()
/* 160 */       .orElse(Collections.emptyList()))
/* 161 */       .stream()
/* 162 */       .map(Channel.Type::of)
/* 163 */       .collect(Collectors.toCollection(() -> EnumSet.noneOf(Channel.Type.class)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<String> getPlaceholder() {
/* 172 */     return getData().placeholder().toOptional();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMinValues() {
/* 181 */     return ((Integer)getData().minValues().toOptional().orElse(Integer.valueOf(1))).intValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMaxValues() {
/* 190 */     return ((Integer)getData().maxValues().toOptional().orElse(Integer.valueOf(1))).intValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Option> getOptions() {
/* 200 */     return (List<Option>)((List)getData().options().toOptional()
/* 201 */       .orElse(Collections.emptyList())).stream()
/* 202 */       .map(Option::new)
/* 203 */       .collect(Collectors.toList());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDisabled() {
/* 212 */     return ((Boolean)getData().disabled().toOptional().orElse(Boolean.valueOf(false))).booleanValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SelectMenu disabled() {
/* 221 */     return disabled(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SelectMenu disabled(boolean value) {
/* 232 */     return new SelectMenu((ComponentData)ComponentData.builder().from(getData()).disabled(Boolean.valueOf(value)).build());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SelectMenu withPlaceholder(String placeholder) {
/* 242 */     return new SelectMenu((ComponentData)ComponentData.builder().from(getData()).placeholder(placeholder).build());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SelectMenu withMinValues(int minValues) {
/* 252 */     return new SelectMenu((ComponentData)ComponentData.builder().from(getData()).minValues(Integer.valueOf(minValues)).build());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SelectMenu withMaxValues(int maxValues) {
/* 262 */     return new SelectMenu((ComponentData)ComponentData.builder().from(getData()).maxValues(Integer.valueOf(maxValues)).build());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SelectMenu withAllowedChannelTypes(Iterable<Channel.Type> types) {
/* 272 */     if (getType() != MessageComponent.Type.SELECT_MENU_CHANNEL) {
/* 273 */       throw new IllegalArgumentException("Select menu with type " + getType() + " can't have channel types restriction");
/*     */     }
/*     */     
/* 276 */     return new SelectMenu((ComponentData)ComponentData.builder().from(getData())
/* 277 */         .channelTypes((List)StreamSupport.stream(types.spliterator(), false)
/* 278 */           .map(Channel.Type::getValue)
/* 279 */           .collect(Collectors.toList()))
/* 280 */         .build());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SelectMenu withAllowedChannelTypes(Channel.Type... types) {
/* 290 */     if (getType() != MessageComponent.Type.SELECT_MENU_CHANNEL) {
/* 291 */       throw new IllegalArgumentException("Select menu with type " + getType() + " can't have channel types restriction");
/*     */     }
/*     */     
/* 294 */     return new SelectMenu((ComponentData)ComponentData.builder().from(getData())
/* 295 */         .channelTypes((List)Arrays.<Channel.Type>stream(types)
/* 296 */           .map(Channel.Type::getValue)
/* 297 */           .collect(Collectors.toList()))
/* 298 */         .build());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Option
/*     */   {
/*     */     private final SelectOptionData data;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Option of(String label, String value) {
/* 314 */       return of(label, value, false);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Option ofDefault(String label, String value) {
/* 327 */       return of(label, value, true);
/*     */     }
/*     */     
/*     */     private static Option of(String label, String value, boolean isDefault) {
/* 331 */       return new Option((SelectOptionData)SelectOptionData.builder()
/* 332 */           .label(label)
/* 333 */           .value(value)
/* 334 */           .isDefault(Boolean.valueOf(isDefault))
/* 335 */           .build());
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     Option(SelectOptionData data) {
/* 341 */       this.data = data;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getLabel() {
/* 350 */       return this.data.label();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getValue() {
/* 359 */       return this.data.value();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Optional<String> getDescription() {
/* 368 */       return this.data.description().toOptional();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Optional<ReactionEmoji> getEmoji() {
/* 377 */       return this.data.emoji().toOptional()
/* 378 */         .map(ReactionEmoji::of);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isDefault() {
/* 387 */       return ((Boolean)this.data.isDefault().toOptional().orElse(Boolean.valueOf(false))).booleanValue();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Option withDescription(String description) {
/* 397 */       return new Option((SelectOptionData)SelectOptionData.builder().from(this.data).description(description).build());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Option withEmoji(ReactionEmoji emoji) {
/* 407 */       return new Option((SelectOptionData)SelectOptionData.builder().from(this.data).emoji(emoji.asEmojiData()).build());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Option withDefault(boolean isDefault) {
/* 417 */       return new Option((SelectOptionData)SelectOptionData.builder().from(this.data).isDefault(Boolean.valueOf(isDefault)).build());
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\object\component\SelectMenu.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */