/*     */ package discord4j.core.object.component;
/*     */ 
/*     */ import discord4j.discordjson.json.ComponentData;
/*     */ import discord4j.discordjson.json.ImmutableComponentData;
/*     */ import java.util.Optional;
/*     */ import java.util.function.Supplier;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TextInput
/*     */   extends ActionComponent
/*     */ {
/*     */   public static TextInput small(String customId) {
/*  40 */     return of(Style.SHORT, customId, null, null, null, null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static TextInput small(String customId, String label) {
/*  51 */     return of(Style.SHORT, customId, label, null, null, null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static TextInput small(String customId, String label, String placeholder) {
/*  63 */     return of(Style.SHORT, customId, label, null, null, null, placeholder);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static TextInput small(String customId, String label, int minLength, int maxLength) {
/*  76 */     return of(Style.SHORT, customId, label, Integer.valueOf(minLength), Integer.valueOf(maxLength), null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static TextInput paragraph(String customId) {
/*  86 */     return of(Style.PARAGRAPH, customId, null, null, null, null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static TextInput paragraph(String customId, String label) {
/*  97 */     return of(Style.PARAGRAPH, customId, label, null, null, null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static TextInput paragraph(String customId, String label, String placeholder) {
/* 109 */     return of(Style.PARAGRAPH, customId, label, null, null, null, placeholder);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static TextInput paragraph(String customId, String label, int minLength, int maxLength) {
/* 122 */     return of(Style.PARAGRAPH, customId, label, Integer.valueOf(minLength), Integer.valueOf(maxLength), null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static TextInput of(Style style, String customId, @Nullable String label, @Nullable Integer minLength, @Nullable Integer maxLength, @Nullable String value, @Nullable String placeholder) {
/* 130 */     ImmutableComponentData.Builder builder = ComponentData.builder().type(MessageComponent.Type.TEXT_INPUT.getValue()).style(Integer.valueOf(style.getValue())).customId(customId);
/*     */     
/* 132 */     if (label != null) {
/* 133 */       builder.label(label);
/*     */     }
/*     */     
/* 136 */     if (minLength != null) {
/* 137 */       builder.minLength(minLength);
/*     */     }
/*     */     
/* 140 */     if (maxLength != null) {
/* 141 */       builder.maxLength(maxLength);
/*     */     }
/*     */     
/* 144 */     if (value != null) {
/* 145 */       builder.value(value);
/*     */     }
/*     */     
/* 148 */     if (placeholder != null) {
/* 149 */       builder.placeholder(placeholder);
/*     */     }
/*     */     
/* 152 */     return new TextInput((ComponentData)builder.build());
/*     */   }
/*     */   
/*     */   TextInput(ComponentData data) {
/* 156 */     super(data);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Style getStyle() {
/* 165 */     return (Style)getData().style().toOptional()
/* 166 */       .map(Style::of)
/* 167 */       .orElseThrow(IllegalStateException::new);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCustomId() {
/* 176 */     return (String)getData().customId().toOptional()
/* 177 */       .orElseThrow(IllegalStateException::new);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<String> getLabel() {
/* 186 */     return getData().label().toOptional();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMinLength() {
/* 195 */     return ((Integer)getData().minLength().toOptional().orElse(Integer.valueOf(0))).intValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMaxLength() {
/* 204 */     return ((Integer)getData().maxLength().toOptional().orElse(Integer.valueOf(4000))).intValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isRequired() {
/* 213 */     return ((Boolean)getData().required().toOptional().orElse(Boolean.valueOf(true))).booleanValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<String> getValue() {
/* 222 */     return getData().value().toOptional();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<String> getPlaceholder() {
/* 231 */     return getData().placeholder().toOptional();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TextInput required() {
/* 240 */     return required(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TextInput required(boolean value) {
/* 251 */     return new TextInput((ComponentData)ComponentData.builder().from(getData()).required(Boolean.valueOf(value)).build());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TextInput prefilled(String value) {
/* 261 */     return new TextInput((ComponentData)ComponentData.builder().from(getData()).value(value).build());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TextInput placeholder(String value) {
/* 271 */     return new TextInput((ComponentData)ComponentData.builder().from(getData()).placeholder(value).build());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum Style
/*     */   {
/* 280 */     UNKNOWN(-1),
/* 281 */     SHORT(1),
/* 282 */     PARAGRAPH(2);
/*     */     
/*     */     private final int value;
/*     */     
/*     */     Style(int value) {
/* 287 */       this.value = value;
/*     */     }
/*     */     
/*     */     public int getValue() {
/* 291 */       return this.value;
/*     */     }
/*     */     
/*     */     public static Style of(int value) {
/* 295 */       switch (value) { case 1:
/* 296 */           return SHORT;
/* 297 */         case 2: return PARAGRAPH; }
/* 298 */        return UNKNOWN;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\object\component\TextInput.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */