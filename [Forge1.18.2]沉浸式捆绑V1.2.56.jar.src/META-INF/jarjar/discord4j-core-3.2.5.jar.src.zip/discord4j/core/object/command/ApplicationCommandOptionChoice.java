/*     */ package discord4j.core.object.command;
/*     */ 
/*     */ import discord4j.common.annotations.Experimental;
/*     */ import discord4j.core.GatewayDiscordClient;
/*     */ import discord4j.core.object.DiscordObject;
/*     */ import discord4j.discordjson.json.ApplicationCommandOptionChoiceData;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.Collections;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.stream.Collectors;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Experimental
/*     */ public class ApplicationCommandOptionChoice
/*     */   implements DiscordObject
/*     */ {
/*     */   public static final int MAX_NAME_LENGTH = 100;
/*     */   public static final int MAX_VALUE_LENGTH = 100;
/*     */   private final GatewayDiscordClient gateway;
/*     */   private final ApplicationCommandOptionChoiceData data;
/*     */   
/*     */   public ApplicationCommandOptionChoice(GatewayDiscordClient gateway, ApplicationCommandOptionChoiceData data) {
/*  61 */     this.gateway = Objects.<GatewayDiscordClient>requireNonNull(gateway);
/*  62 */     this.data = Objects.<ApplicationCommandOptionChoiceData>requireNonNull(data);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/*  71 */     return this.data.name();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<Locale, String> getLocalizedNames() {
/*  80 */     return (Map<Locale, String>)((Map)Possible.flatOpt(this.data.nameLocalizations())
/*  81 */       .orElse(Collections.emptyMap()))
/*  82 */       .entrySet().stream()
/*  83 */       .collect(Collectors.toMap(entry -> (new Locale.Builder()).setLanguageTag((String)entry.getKey()).build(), Map.Entry::getValue));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getValue() {
/*  93 */     return this.data.value();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String asString() {
/* 102 */     return String.valueOf(this.data.value());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long asLong() {
/*     */     try {
/* 112 */       return Long.parseLong(asString());
/* 113 */     } catch (NumberFormatException e) {
/* 114 */       throw new IllegalArgumentException("Choice value cannot be converted to long", e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double asDouble() {
/*     */     try {
/* 125 */       return Double.parseDouble(asString());
/* 126 */     } catch (NumberFormatException e) {
/* 127 */       throw new IllegalArgumentException("Choice value cannot be converted to double", e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public GatewayDiscordClient getClient() {
/* 133 */     return this.gateway;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\object\command\ApplicationCommandOptionChoice.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */