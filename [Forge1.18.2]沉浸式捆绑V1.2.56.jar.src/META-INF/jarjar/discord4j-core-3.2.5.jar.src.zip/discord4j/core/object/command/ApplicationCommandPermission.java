/*     */ package discord4j.core.object.command;
/*     */ 
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.GatewayDiscordClient;
/*     */ import discord4j.core.object.DiscordObject;
/*     */ import discord4j.discordjson.json.ApplicationCommandPermissionsData;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ApplicationCommandPermission
/*     */   implements DiscordObject
/*     */ {
/*     */   private final GatewayDiscordClient gateway;
/*     */   private final long guildId;
/*     */   private final ApplicationCommandPermissionsData data;
/*     */   
/*     */   public ApplicationCommandPermission(GatewayDiscordClient gateway, Snowflake guildId, ApplicationCommandPermissionsData data) {
/*  53 */     this.gateway = gateway;
/*  54 */     this.guildId = guildId.asLong();
/*  55 */     this.data = data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Snowflake getId() {
/*  65 */     return Snowflake.of(this.data.id());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean appliesToEveryone() {
/*  74 */     return (this.guildId == this.data.id().asLong());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean appliesToAllChannels() {
/*  83 */     return (this.guildId - 1L == this.data.id().asLong());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Type getType() {
/*  92 */     return Type.of(this.data.type());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAllowed() {
/* 102 */     return this.data.permission();
/*     */   }
/*     */ 
/*     */   
/*     */   public GatewayDiscordClient getClient() {
/* 107 */     return this.gateway;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum Type
/*     */   {
/* 118 */     UNKNOWN(-1),
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 123 */     ROLE(1),
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 128 */     USER(2),
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 133 */     CHANNEL(3);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final int value;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Type(int value) {
/* 146 */       this.value = value;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int getValue() {
/* 155 */       return this.value;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Type of(int value) {
/* 166 */       switch (value) { case 1:
/* 167 */           return ROLE;
/* 168 */         case 2: return USER;
/* 169 */         case 3: return CHANNEL; }
/* 170 */        return UNKNOWN;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 177 */     return "ApplicationCommandPermission{data=" + this.data + '}';
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\object\command\ApplicationCommandPermission.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */