/*     */ package discord4j.core.object.command;
/*     */ 
/*     */ import discord4j.common.annotations.Experimental;
/*     */ import discord4j.core.GatewayDiscordClient;
/*     */ import discord4j.core.object.DiscordObject;
/*     */ import discord4j.discordjson.json.ApplicationCommandInteractionOptionData;
/*     */ import discord4j.discordjson.json.ApplicationCommandInteractionResolvedData;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import java.util.stream.Collectors;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Experimental
/*     */ public class ApplicationCommandInteractionOption
/*     */   implements DiscordObject
/*     */ {
/*     */   private final GatewayDiscordClient gateway;
/*     */   private final ApplicationCommandInteractionOptionData data;
/*     */   @Nullable
/*     */   private final Long guildId;
/*     */   @Nullable
/*     */   private final ApplicationCommandInteractionResolvedData resolved;
/*     */   
/*     */   public ApplicationCommandInteractionOption(GatewayDiscordClient gateway, ApplicationCommandInteractionOptionData data, @Nullable Long guildId, @Nullable ApplicationCommandInteractionResolvedData resolved) {
/*  66 */     this.gateway = Objects.<GatewayDiscordClient>requireNonNull(gateway);
/*  67 */     this.data = Objects.<ApplicationCommandInteractionOptionData>requireNonNull(data);
/*  68 */     this.guildId = guildId;
/*  69 */     this.resolved = resolved;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/*  78 */     return this.data.name();
/*     */   }
/*     */ 
/*     */   
/*     */   public Optional<ApplicationCommandInteractionOptionValue> getValue() {
/*  83 */     return this.data.value().toOptional()
/*  84 */       .map(value -> new ApplicationCommandInteractionOptionValue(this.gateway, this.guildId, this.data.type(), value, this.resolved));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ApplicationCommandOption.Type getType() {
/*  93 */     return ApplicationCommandOption.Type.of(this.data.type());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<ApplicationCommandInteractionOption> getOptions() {
/* 102 */     return (List<ApplicationCommandInteractionOption>)((List)this.data.options().toOptional().orElse(Collections.emptyList())).stream()
/* 103 */       .map(data -> new ApplicationCommandInteractionOption(this.gateway, data, this.guildId, this.resolved))
/* 104 */       .collect(Collectors.toList());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<ApplicationCommandInteractionOption> getOption(String name) {
/* 114 */     return ((List)this.data.options().toOptional().orElse(Collections.emptyList())).stream()
/* 115 */       .filter(data -> data.name().equals(name))
/* 116 */       .findFirst()
/* 117 */       .map(data -> new ApplicationCommandInteractionOption(this.gateway, data, this.guildId, this.resolved));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isFocused() {
/* 127 */     return ((Boolean)this.data.focused().toOptional().orElse(Boolean.valueOf(false))).booleanValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public GatewayDiscordClient getClient() {
/* 132 */     return this.gateway;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\object\command\ApplicationCommandInteractionOption.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */