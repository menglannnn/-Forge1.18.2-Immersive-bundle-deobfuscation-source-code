/*     */ package discord4j.core.object.command;
/*     */ 
/*     */ import discord4j.common.annotations.Experimental;
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.GatewayDiscordClient;
/*     */ import discord4j.core.object.DiscordObject;
/*     */ import discord4j.core.object.component.MessageComponent;
/*     */ import discord4j.discordjson.json.ApplicationCommandInteractionData;
/*     */ import discord4j.discordjson.json.ApplicationCommandInteractionOptionData;
/*     */ import discord4j.discordjson.json.ApplicationCommandInteractionResolvedData;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import java.util.stream.Collectors;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Experimental
/*     */ public class ApplicationCommandInteraction
/*     */   implements DiscordObject
/*     */ {
/*     */   private final GatewayDiscordClient gateway;
/*     */   private final ApplicationCommandInteractionData data;
/*     */   @Nullable
/*     */   private final Long guildId;
/*     */   
/*     */   public ApplicationCommandInteraction(GatewayDiscordClient gateway, ApplicationCommandInteractionData data, @Nullable Long guildId) {
/*  65 */     this.gateway = Objects.<GatewayDiscordClient>requireNonNull(gateway);
/*  66 */     this.data = Objects.<ApplicationCommandInteractionData>requireNonNull(data);
/*  67 */     this.guildId = guildId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<Snowflake> getId() {
/*  76 */     return this.data.id().toOptional().map(Snowflake::of);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<String> getName() {
/*  85 */     return this.data.name().toOptional();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<ApplicationCommand.Type> getApplicationCommandType() {
/*  94 */     return this.data.type().toOptional().map(ApplicationCommand.Type::of);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<String> getCustomId() {
/* 103 */     return this.data.customId().toOptional();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<MessageComponent.Type> getComponentType() {
/* 112 */     return this.data.componentType().toOptional().map(MessageComponent.Type::of);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<ApplicationCommandInteractionOption> getOptions() {
/* 121 */     return (List<ApplicationCommandInteractionOption>)((List)this.data.options().toOptional().orElse(Collections.emptyList())).stream()
/* 122 */       .map(data -> new ApplicationCommandInteractionOption(this.gateway, data, this.guildId, this.data.resolved().toOptional().orElse(null)))
/*     */       
/* 124 */       .collect(Collectors.toList());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<ApplicationCommandInteractionOption> getOption(String name) {
/* 134 */     return ((List)this.data.options().toOptional().orElse(Collections.emptyList())).stream()
/* 135 */       .filter(option -> option.name().equals(name))
/* 136 */       .findFirst()
/* 137 */       .map(data -> new ApplicationCommandInteractionOption(this.gateway, data, this.guildId, this.data.resolved().toOptional().orElse(null)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<List<String>> getValues() {
/* 147 */     return this.data.values().toOptional();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<ApplicationCommandInteractionResolved> getResolved() {
/* 156 */     return this.data.resolved().toOptional()
/* 157 */       .map(data -> new ApplicationCommandInteractionResolved(this.gateway, data, this.guildId));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<Snowflake> getTargetId() {
/* 166 */     return this.data.targetId().toOptional()
/* 167 */       .map(Snowflake::of);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<MessageComponent> getComponents() {
/* 176 */     return (List<MessageComponent>)((List)this.data.components().toOptional().orElse(Collections.emptyList())).stream()
/* 177 */       .map(MessageComponent::fromData)
/* 178 */       .collect(Collectors.toList());
/*     */   }
/*     */ 
/*     */   
/*     */   public GatewayDiscordClient getClient() {
/* 183 */     return this.gateway;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 188 */     return "ApplicationCommandInteraction{data=" + this.data + ", guildId=" + this.guildId + '}';
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\object\command\ApplicationCommandInteraction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */