/*     */ package discord4j.core.object.command;
/*     */ 
/*     */ import discord4j.common.annotations.Experimental;
/*     */ import discord4j.core.GatewayDiscordClient;
/*     */ import discord4j.core.object.DiscordObject;
/*     */ import discord4j.core.object.entity.channel.Channel;
/*     */ import discord4j.discordjson.json.ApplicationCommandOptionChoiceData;
/*     */ import discord4j.discordjson.json.ApplicationCommandOptionData;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import java.util.stream.Collectors;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Experimental
/*     */ public class ApplicationCommandOption
/*     */   implements DiscordObject
/*     */ {
/*     */   public static final int MAX_NAME_LENGTH = 32;
/*     */   public static final int MAX_DESCRIPTION_LENGTH = 100;
/*     */   private final GatewayDiscordClient gateway;
/*     */   private final ApplicationCommandOptionData data;
/*     */   
/*     */   public ApplicationCommandOption(GatewayDiscordClient gateway, ApplicationCommandOptionData data) {
/*  57 */     this.gateway = Objects.<GatewayDiscordClient>requireNonNull(gateway);
/*  58 */     this.data = Objects.<ApplicationCommandOptionData>requireNonNull(data);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Type getType() {
/*  67 */     return Type.of(this.data.type());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/*  76 */     return this.data.name();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<Locale, String> getLocalizedNames() {
/*  85 */     return (Map<Locale, String>)((Map)Possible.flatOpt(this.data.nameLocalizations())
/*  86 */       .orElse(Collections.emptyMap()))
/*  87 */       .entrySet().stream()
/*  88 */       .collect(Collectors.toMap(entry -> (new Locale.Builder()).setLanguageTag((String)entry.getKey()).build(), Map.Entry::getValue));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDescription() {
/*  98 */     return this.data.description();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<Locale, String> getLocalizedDescriptions() {
/* 107 */     return (Map<Locale, String>)((Map)Possible.flatOpt(this.data.descriptionLocalizations())
/* 108 */       .orElse(Collections.emptyMap()))
/* 109 */       .entrySet().stream()
/* 110 */       .collect(Collectors.toMap(entry -> (new Locale.Builder()).setLanguageTag((String)entry.getKey()).build(), Map.Entry::getValue));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isRequired() {
/* 120 */     return ((Boolean)this.data.required().toOptional().orElse(Boolean.valueOf(false))).booleanValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<ApplicationCommandOptionChoice> getChoices() {
/* 129 */     return (List<ApplicationCommandOptionChoice>)((List)this.data.choices().toOptional().orElse(Collections.emptyList()))
/* 130 */       .stream()
/* 131 */       .map(data -> new ApplicationCommandOptionChoice(this.gateway, data))
/* 132 */       .collect(Collectors.toList());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<ApplicationCommandOptionChoice> getChoice(String name) {
/* 142 */     return ((List)this.data.choices().toOptional().orElse(Collections.emptyList())).stream()
/* 143 */       .filter(choice -> choice.name().equals(name))
/* 144 */       .findFirst()
/* 145 */       .map(data -> new ApplicationCommandOptionChoice(this.gateway, data));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<ApplicationCommandOption> getOptions() {
/* 154 */     return (List<ApplicationCommandOption>)((List)this.data.options().toOptional().orElse(Collections.emptyList()))
/* 155 */       .stream()
/* 156 */       .map(data -> new ApplicationCommandOption(this.gateway, data))
/* 157 */       .collect(Collectors.toList());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<ApplicationCommandOption> getOption(String name) {
/* 169 */     return ((List)this.data.options().toOptional().orElse(Collections.emptyList())).stream()
/* 170 */       .filter(option -> option.name().equals(name))
/* 171 */       .findFirst()
/* 172 */       .map(data -> new ApplicationCommandOption(this.gateway, data));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Channel.Type> getAllowedChannelTypes() {
/* 182 */     return (List<Channel.Type>)((List)this.data.channelTypes().toOptional()
/* 183 */       .orElse(Collections.emptyList()))
/* 184 */       .stream()
/* 185 */       .map(Channel.Type::of)
/* 186 */       .collect(Collectors.toList());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasAutocompleteEnabled() {
/* 196 */     return ((Boolean)this.data.autocomplete().toOptional().orElse(Boolean.valueOf(false))).booleanValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<Double> getMinimumValue() {
/* 206 */     return this.data.minValue().toOptional();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<Double> getMaximumValue() {
/* 216 */     return this.data.maxValue().toOptional();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<Integer> getMinimumLength() {
/* 226 */     return this.data.minLength().toOptional();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<Integer> getMaximumLength() {
/* 236 */     return this.data.maxLength().toOptional();
/*     */   }
/*     */ 
/*     */   
/*     */   public GatewayDiscordClient getClient() {
/* 241 */     return this.gateway;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum Type
/*     */   {
/* 249 */     UNKNOWN(-1),
/* 250 */     SUB_COMMAND(1),
/* 251 */     SUB_COMMAND_GROUP(2),
/* 252 */     STRING(3),
/* 253 */     INTEGER(4),
/* 254 */     BOOLEAN(5),
/* 255 */     USER(6),
/* 256 */     CHANNEL(7),
/* 257 */     ROLE(8),
/* 258 */     MENTIONABLE(9),
/* 259 */     NUMBER(10),
/* 260 */     ATTACHMENT(11);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final int value;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Type(int value) {
/* 273 */       this.value = value;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int getValue() {
/* 282 */       return this.value;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Type of(int value) {
/* 294 */       switch (value) { case 1:
/* 295 */           return SUB_COMMAND;
/* 296 */         case 2: return SUB_COMMAND_GROUP;
/* 297 */         case 3: return STRING;
/* 298 */         case 4: return INTEGER;
/* 299 */         case 5: return BOOLEAN;
/* 300 */         case 6: return USER;
/* 301 */         case 7: return CHANNEL;
/* 302 */         case 8: return ROLE;
/* 303 */         case 9: return MENTIONABLE;
/* 304 */         case 10: return NUMBER;
/* 305 */         case 11: return ATTACHMENT; }
/* 306 */        return UNKNOWN;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\object\command\ApplicationCommandOption.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */