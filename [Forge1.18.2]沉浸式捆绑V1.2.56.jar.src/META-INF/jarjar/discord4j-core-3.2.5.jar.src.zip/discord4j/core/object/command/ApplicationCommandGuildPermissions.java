/*     */ package discord4j.core.object.command;
/*     */ 
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.GatewayDiscordClient;
/*     */ import discord4j.core.object.DiscordObject;
/*     */ import discord4j.discordjson.json.ApplicationCommandPermissionsData;
/*     */ import discord4j.discordjson.json.GuildApplicationCommandPermissionsData;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.stream.Collectors;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ApplicationCommandGuildPermissions
/*     */   implements DiscordObject
/*     */ {
/*     */   public static final int MAX_PERMISSION_ENTRIES = 100;
/*     */   private final GatewayDiscordClient gateway;
/*     */   private final GuildApplicationCommandPermissionsData data;
/*     */   
/*     */   public ApplicationCommandGuildPermissions(GatewayDiscordClient gateway, GuildApplicationCommandPermissionsData data) {
/*  63 */     this.gateway = Objects.<GatewayDiscordClient>requireNonNull(gateway);
/*  64 */     this.data = Objects.<GuildApplicationCommandPermissionsData>requireNonNull(data);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Snowflake getId() {
/*  73 */     return Snowflake.of(this.data.id());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Snowflake getGuildId() {
/*  83 */     return Snowflake.of(this.data.guildId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Snowflake getApplicationId() {
/*  92 */     return Snowflake.of(this.data.applicationId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<ApplicationCommandPermission> getPermissions() {
/* 101 */     return (List<ApplicationCommandPermission>)this.data.permissions()
/* 102 */       .stream()
/* 103 */       .map(data -> new ApplicationCommandPermission(this.gateway, getGuildId(), data))
/* 104 */       .collect(Collectors.toList());
/*     */   }
/*     */ 
/*     */   
/*     */   public GatewayDiscordClient getClient() {
/* 109 */     return this.gateway;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 114 */     return "ApplicationCommandGuildPermissions{data=" + this.data + '}';
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\object\command\ApplicationCommandGuildPermissions.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */