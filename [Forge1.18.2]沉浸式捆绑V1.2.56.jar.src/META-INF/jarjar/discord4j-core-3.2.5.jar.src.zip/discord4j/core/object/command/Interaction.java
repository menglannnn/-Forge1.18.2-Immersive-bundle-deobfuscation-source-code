/*     */ package discord4j.core.object.command;
/*     */ 
/*     */ import discord4j.common.annotations.Experimental;
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.GatewayDiscordClient;
/*     */ import discord4j.core.object.DiscordObject;
/*     */ import discord4j.core.object.entity.Guild;
/*     */ import discord4j.core.object.entity.Member;
/*     */ import discord4j.core.object.entity.Message;
/*     */ import discord4j.core.object.entity.User;
/*     */ import discord4j.core.object.entity.channel.MessageChannel;
/*     */ import discord4j.discordjson.Id;
/*     */ import discord4j.discordjson.json.ApplicationCommandInteractionData;
/*     */ import discord4j.discordjson.json.InteractionData;
/*     */ import discord4j.discordjson.json.MemberData;
/*     */ import discord4j.discordjson.json.MessageData;
/*     */ import discord4j.discordjson.json.UserData;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Experimental
/*     */ public class Interaction
/*     */   implements DiscordObject
/*     */ {
/*     */   private final GatewayDiscordClient gateway;
/*     */   private final InteractionData data;
/*     */   
/*     */   public Interaction(GatewayDiscordClient gateway, InteractionData data) {
/*  57 */     this.gateway = Objects.<GatewayDiscordClient>requireNonNull(gateway);
/*  58 */     this.data = Objects.<InteractionData>requireNonNull(data);
/*     */   }
/*     */   
/*     */   public InteractionData getData() {
/*  62 */     return this.data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Snowflake getId() {
/*  71 */     return Snowflake.of(this.data.id());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Snowflake getApplicationId() {
/*  80 */     return Snowflake.of(this.data.applicationId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Type getType() {
/*  89 */     return Type.of(this.data.type());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<ApplicationCommandInteraction> getCommandInteraction() {
/*  98 */     return this.data.data().toOptional().map(data -> new ApplicationCommandInteraction(getClient(), data, getGuildId().<Long>map(Snowflake::asLong).orElse(null)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<Snowflake> getGuildId() {
/* 108 */     return this.data.guildId().toOptional().map(Snowflake::of);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Guild> getGuild() {
/* 117 */     Objects.requireNonNull(this.gateway); return Mono.justOrEmpty(getGuildId()).flatMap(this.gateway::getGuildById);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Snowflake getChannelId() {
/* 126 */     return Snowflake.of((Id)this.data.channelId().get());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<MessageChannel> getChannel() {
/* 135 */     return this.gateway.getChannelById(getChannelId()).cast(MessageChannel.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<Member> getMember() {
/* 144 */     return this.data.member().toOptional()
/* 145 */       .map(data -> new Member(this.gateway, data, ((Snowflake)getGuildId().get()).asLong()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public User getUser() {
/* 154 */     UserData userData = this.data.member().isAbsent() ? (UserData)this.data.user().get() : ((MemberData)this.data.member().get()).user();
/* 155 */     return new User(getClient(), userData);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getToken() {
/* 164 */     return this.data.token();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<Message> getMessage() {
/* 173 */     return this.data.message().toOptional()
/* 174 */       .map(data -> new Message(this.gateway, data));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<Snowflake> getMessageId() {
/* 183 */     return this.data.message().toOptional()
/* 184 */       .map(data -> Snowflake.of(data.id()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getUserLocale() {
/* 196 */     return this.data.locale().toOptional().orElse("en-US");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<String> getGuildLocale() {
/* 209 */     return this.data.guildLocale().toOptional();
/*     */   }
/*     */ 
/*     */   
/*     */   public GatewayDiscordClient getClient() {
/* 214 */     return this.gateway;
/*     */   }
/*     */ 
/*     */   
/*     */   public enum Type
/*     */   {
/* 220 */     UNKNOWN(-1),
/* 221 */     PING(1),
/* 222 */     APPLICATION_COMMAND(2),
/* 223 */     MESSAGE_COMPONENT(3),
/* 224 */     APPLICATION_COMMAND_AUTOCOMPLETE(4),
/* 225 */     MODAL_SUBMIT(5);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final int value;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Type(int value) {
/* 236 */       this.value = value;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int getValue() {
/* 245 */       return this.value;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Type of(int value) {
/* 256 */       switch (value) { case 1:
/* 257 */           return PING;
/* 258 */         case 2: return APPLICATION_COMMAND;
/* 259 */         case 3: return MESSAGE_COMPONENT;
/* 260 */         case 4: return APPLICATION_COMMAND_AUTOCOMPLETE;
/* 261 */         case 5: return MODAL_SUBMIT; }
/* 262 */        return UNKNOWN;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\object\command\Interaction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */