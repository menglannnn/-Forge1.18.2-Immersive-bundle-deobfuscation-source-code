/*     */ package discord4j.core.object.command;
/*     */ 
/*     */ import discord4j.common.annotations.Experimental;
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.GatewayDiscordClient;
/*     */ import discord4j.core.object.DiscordObject;
/*     */ import discord4j.core.object.entity.Attachment;
/*     */ import discord4j.core.object.entity.Message;
/*     */ import discord4j.core.object.entity.Role;
/*     */ import discord4j.core.object.entity.User;
/*     */ import discord4j.discordjson.json.ApplicationCommandInteractionResolvedData;
/*     */ import discord4j.discordjson.json.AttachmentData;
/*     */ import discord4j.discordjson.json.MessageData;
/*     */ import discord4j.discordjson.json.ResolvedChannelData;
/*     */ import discord4j.discordjson.json.ResolvedMemberData;
/*     */ import discord4j.discordjson.json.RoleData;
/*     */ import discord4j.discordjson.json.UserData;
/*     */ import java.util.Collections;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import java.util.function.Supplier;
/*     */ import java.util.stream.Collectors;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.function.Tuple2;
/*     */ import reactor.util.function.Tuples;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Experimental
/*     */ public class ApplicationCommandInteractionResolved
/*     */   implements DiscordObject
/*     */ {
/*     */   private final GatewayDiscordClient gateway;
/*     */   private final ApplicationCommandInteractionResolvedData data;
/*     */   @Nullable
/*     */   private final Long guildId;
/*     */   
/*     */   public ApplicationCommandInteractionResolved(GatewayDiscordClient gateway, ApplicationCommandInteractionResolvedData data, @Nullable Long guildId) {
/*  61 */     this.gateway = Objects.<GatewayDiscordClient>requireNonNull(gateway);
/*  62 */     this.data = Objects.<ApplicationCommandInteractionResolvedData>requireNonNull(data);
/*  63 */     this.guildId = guildId;
/*     */   }
/*     */ 
/*     */   
/*     */   public GatewayDiscordClient getClient() {
/*  68 */     return this.gateway;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ApplicationCommandInteractionResolvedData getData() {
/*  77 */     return this.data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<ResolvedChannel> getChannel(Snowflake channelId) {
/*  87 */     return this.data.channels().toOptional()
/*  88 */       .map(channels -> (ResolvedChannelData)channels.get(channelId.asString()))
/*  89 */       .map(data -> new ResolvedChannel(this.gateway, data));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<Snowflake, ResolvedChannel> getChannels() {
/*  98 */     return this.data.channels().toOptional()
/*  99 */       .map(map -> (Map)map.entrySet().stream().map(()).collect(Collectors.toMap(Tuple2::getT1, Tuple2::getT2)))
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 104 */       .orElseGet(Collections::emptyMap);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<User> getUser(Snowflake userId) {
/* 115 */     return this.data.users().toOptional()
/* 116 */       .map(users -> (UserData)users.get(userId.asString()))
/* 117 */       .map(data -> new User(this.gateway, data));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<Snowflake, User> getUsers() {
/* 126 */     return this.data.users().toOptional()
/* 127 */       .map(map -> (Map)map.entrySet().stream().map(()).collect(Collectors.toMap(Tuple2::getT1, Tuple2::getT2)))
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 132 */       .orElseGet(Collections::emptyMap);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<ResolvedMember> getMember(Snowflake memberId) {
/* 142 */     return this.data.members().toOptional()
/* 143 */       .map(members -> (ResolvedMemberData)members.get(memberId.asString()))
/* 144 */       .map(memberData -> new ResolvedMember(this.gateway, memberData, (UserData)getUser(memberId).map(User::getUserData).orElseThrow(IllegalStateException::new), ((Long)Objects.<Long>requireNonNull(this.guildId)).longValue()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<Snowflake, ResolvedMember> getMembers() {
/* 155 */     return this.data.members().toOptional()
/* 156 */       .map(map -> (Map)map.entrySet().stream().map(()).collect(Collectors.toMap(Tuple2::getT1, Tuple2::getT2)))
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 164 */       .orElseGet(Collections::emptyMap);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<Role> getRole(Snowflake roleId) {
/* 174 */     return this.data.roles().toOptional()
/* 175 */       .map(roles -> (RoleData)roles.get(roleId.asString()))
/* 176 */       .map(data -> new Role(this.gateway, data, ((Long)Objects.<Long>requireNonNull(this.guildId)).longValue()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<Snowflake, Role> getRoles() {
/* 185 */     return this.data.roles().toOptional()
/* 186 */       .map(map -> (Map)map.entrySet().stream().map(()).collect(Collectors.toMap(Tuple2::getT1, Tuple2::getT2)))
/*     */ 
/*     */ 
/*     */       
/* 190 */       .orElseGet(Collections::emptyMap);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<Message> getMessage(Snowflake messageId) {
/* 200 */     return this.data.messages().toOptional()
/* 201 */       .map(messages -> (MessageData)messages.get(messageId.asString()))
/* 202 */       .map(data -> new Message(this.gateway, data));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<Snowflake, Message> getMessages() {
/* 211 */     return this.data.messages().toOptional()
/* 212 */       .map(map -> (Map)map.entrySet().stream().map(()).collect(Collectors.toMap(Tuple2::getT1, Tuple2::getT2)))
/*     */ 
/*     */ 
/*     */       
/* 216 */       .orElseGet(Collections::emptyMap);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<Attachment> getAttachment(Snowflake attachmentId) {
/* 226 */     return this.data.attachments().toOptional()
/* 227 */       .map(attachments -> (AttachmentData)attachments.get(attachmentId.asString()))
/* 228 */       .map(data -> new Attachment(this.gateway, data));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<Snowflake, Attachment> getAttachments() {
/* 237 */     return this.data.attachments().toOptional()
/* 238 */       .map(map -> (Map)map.entrySet().stream().map(()).collect(Collectors.toMap(Tuple2::getT1, Tuple2::getT2)))
/*     */ 
/*     */ 
/*     */       
/* 242 */       .orElseGet(Collections::emptyMap);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 247 */     return "ApplicationCommandInteractionResolved{data=" + this.data + ", guildId=" + this.guildId + '}';
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\object\command\ApplicationCommandInteractionResolved.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */