/*     */ package discord4j.core.object.command;
/*     */ 
/*     */ import discord4j.common.annotations.Experimental;
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.GatewayDiscordClient;
/*     */ import discord4j.core.object.DiscordObject;
/*     */ import discord4j.discordjson.json.ApplicationCommandData;
/*     */ import discord4j.discordjson.json.ApplicationCommandOptionData;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import discord4j.rest.util.PermissionSet;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import java.util.stream.Collectors;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Experimental
/*     */ public class ApplicationCommand
/*     */   implements DiscordObject
/*     */ {
/*     */   public static final int MAX_NAME_LENGTH = 32;
/*     */   public static final int MAX_DESCRIPTION_LENGTH = 100;
/*     */   private final GatewayDiscordClient gateway;
/*     */   private final ApplicationCommandData data;
/*     */   
/*     */   public ApplicationCommand(GatewayDiscordClient gateway, ApplicationCommandData data) {
/*  58 */     this.gateway = Objects.<GatewayDiscordClient>requireNonNull(gateway);
/*  59 */     this.data = Objects.<ApplicationCommandData>requireNonNull(data);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Snowflake getId() {
/*  68 */     return Snowflake.of(this.data.id());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Snowflake getVersion() {
/*  77 */     return Snowflake.of(this.data.version());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<Snowflake> getGuildId() {
/*  86 */     return this.data.guildId().toOptional().map(Snowflake::of);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Type getType() {
/*  96 */     return this.data.type().toOptional()
/*  97 */       .map(Type::of)
/*  98 */       .orElse(Type.CHAT_INPUT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Snowflake getApplicationId() {
/* 107 */     return Snowflake.of(this.data.applicationId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 116 */     return this.data.name();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<Locale, String> getLocalizedNames() {
/* 125 */     return (Map<Locale, String>)((Map)Possible.flatOpt(this.data.nameLocalizations())
/* 126 */       .orElse(Collections.emptyMap()))
/* 127 */       .entrySet().stream()
/* 128 */       .collect(Collectors.toMap(entry -> (new Locale.Builder()).setLanguageTag((String)entry.getKey()).build(), Map.Entry::getValue));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDescription() {
/* 138 */     return this.data.description();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<Locale, String> getLocalizedDescriptions() {
/* 147 */     return (Map<Locale, String>)((Map)Possible.flatOpt(this.data.descriptionLocalizations())
/* 148 */       .orElse(Collections.emptyMap()))
/* 149 */       .entrySet().stream()
/* 150 */       .collect(Collectors.toMap(entry -> (new Locale.Builder()).setLanguageTag((String)entry.getKey()).build(), Map.Entry::getValue));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PermissionSet getDefaultMemberPermissions() {
/* 160 */     return this.data.defaultMemberPermissions().map(Long::parseLong).map(PermissionSet::of).orElse(PermissionSet.none());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<ApplicationCommandOption> getOptions() {
/* 169 */     return (List<ApplicationCommandOption>)((List)this.data.options().toOptional().orElse(Collections.emptyList())).stream()
/* 170 */       .map(data -> new ApplicationCommandOption(this.gateway, data))
/* 171 */       .collect(Collectors.toList());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<ApplicationCommandOption> getOption(String name) {
/* 181 */     return ((List)this.data.options().toOptional().orElse(Collections.emptyList())).stream()
/* 182 */       .filter(option -> option.name().equals(name))
/* 183 */       .findFirst()
/* 184 */       .map(data -> new ApplicationCommandOption(this.gateway, data));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAvailableInDM() {
/* 193 */     return ((Boolean)this.data.dmPermission().toOptional().orElse(Boolean.valueOf(!getGuildId().isPresent()))).booleanValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public GatewayDiscordClient getClient() {
/* 198 */     return this.gateway;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum Type
/*     */   {
/* 206 */     UNKNOWN(-1),
/* 207 */     CHAT_INPUT(1),
/* 208 */     USER(2),
/* 209 */     MESSAGE(3);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final int value;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Type(int value) {
/* 222 */       this.value = value;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int getValue() {
/* 231 */       return this.value;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Type of(int value) {
/* 243 */       switch (value) { case 1:
/* 244 */           return CHAT_INPUT;
/* 245 */         case 2: return USER;
/* 246 */         case 3: return MESSAGE; }
/* 247 */        return UNKNOWN;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\object\command\ApplicationCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */