/*     */ package discord4j.core.object.command;
/*     */ 
/*     */ import discord4j.common.annotations.Experimental;
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.GatewayDiscordClient;
/*     */ import discord4j.core.object.DiscordObject;
/*     */ import discord4j.core.object.entity.Member;
/*     */ import discord4j.core.retriever.EntityRetrievalStrategy;
/*     */ import discord4j.discordjson.json.ResolvedMemberData;
/*     */ import discord4j.discordjson.json.UserData;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import discord4j.rest.util.PermissionSet;
/*     */ import java.time.Instant;
/*     */ import java.time.format.DateTimeFormatter;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import java.util.Set;
/*     */ import java.util.function.Supplier;
/*     */ import java.util.stream.Collectors;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Experimental
/*     */ public class ResolvedMember
/*     */   implements DiscordObject
/*     */ {
/*     */   private final GatewayDiscordClient gateway;
/*     */   private final ResolvedMemberData data;
/*     */   private final UserData user;
/*     */   private final long guildId;
/*     */   
/*     */   public ResolvedMember(GatewayDiscordClient gateway, ResolvedMemberData data, UserData user, long guildId) {
/*  72 */     this.gateway = Objects.<GatewayDiscordClient>requireNonNull(gateway);
/*  73 */     this.data = Objects.<ResolvedMemberData>requireNonNull(data);
/*  74 */     this.user = Objects.<UserData>requireNonNull(user);
/*  75 */     this.guildId = guildId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResolvedMemberData getData() {
/*  84 */     return this.data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Snowflake getId() {
/*  93 */     return Snowflake.of(this.user.id());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Snowflake getGuildId() {
/* 102 */     return Snowflake.of(this.guildId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<Snowflake> getRoleIds() {
/* 111 */     return (Set<Snowflake>)this.data.roles().stream()
/* 112 */       .map(Snowflake::of)
/* 113 */       .collect(Collectors.toSet());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Instant getJoinTime() {
/* 122 */     return DateTimeFormatter.ISO_OFFSET_DATE_TIME.<Instant>parse(this.data.joinedAt(), Instant::from);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<Instant> getPremiumTime() {
/* 131 */     return Possible.flatOpt(this.data.premiumSince())
/* 132 */       .map(timestamp -> (Instant)DateTimeFormatter.ISO_OFFSET_DATE_TIME.<Instant>parse(timestamp, Instant::from));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDisplayName() {
/* 141 */     return getNickname().orElse(this.user.username());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<String> getNickname() {
/* 150 */     return Possible.flatOpt(this.data.nick());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getNicknameMention() {
/* 160 */     return "<@!" + getId().asString() + ">";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PermissionSet getEffectivePermissions() {
/* 169 */     return PermissionSet.of((String)this.data.permissions().toOptional().orElseThrow(IllegalStateException::new));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Member> asFullMember() {
/* 179 */     return this.gateway.getMemberById(getGuildId(), getId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Member> asFullMember(EntityRetrievalStrategy retrievalStrategy) {
/* 190 */     return this.gateway.withRetrievalStrategy(retrievalStrategy).getMemberById(getGuildId(), getId());
/*     */   }
/*     */ 
/*     */   
/*     */   public GatewayDiscordClient getClient() {
/* 195 */     return this.gateway;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 200 */     return "ResolvedMember{data=" + this.data + ", user=" + this.user + ", guildId=" + this.guildId + '}';
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\object\command\ResolvedMember.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */