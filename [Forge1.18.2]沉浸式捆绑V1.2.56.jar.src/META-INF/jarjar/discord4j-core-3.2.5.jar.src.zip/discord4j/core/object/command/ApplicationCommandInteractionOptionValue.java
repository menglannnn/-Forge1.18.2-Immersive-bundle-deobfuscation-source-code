/*     */ package discord4j.core.object.command;
/*     */ 
/*     */ import discord4j.common.annotations.Experimental;
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.GatewayDiscordClient;
/*     */ import discord4j.core.object.DiscordObject;
/*     */ import discord4j.core.object.entity.Attachment;
/*     */ import discord4j.core.object.entity.Role;
/*     */ import discord4j.core.object.entity.User;
/*     */ import discord4j.core.object.entity.channel.Channel;
/*     */ import discord4j.discordjson.json.ApplicationCommandInteractionResolvedData;
/*     */ import discord4j.discordjson.json.AttachmentData;
/*     */ import java.util.Arrays;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.function.Function;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Experimental
/*     */ public class ApplicationCommandInteractionOptionValue
/*     */   implements DiscordObject
/*     */ {
/*     */   private final GatewayDiscordClient gateway;
/*     */   @Nullable
/*     */   private final Long guildId;
/*     */   private final int type;
/*     */   private final String value;
/*     */   @Nullable
/*     */   private final ApplicationCommandInteractionResolvedData resolved;
/*     */   
/*     */   public ApplicationCommandInteractionOptionValue(GatewayDiscordClient gateway, @Nullable Long guildId, int type, String value, @Nullable ApplicationCommandInteractionResolvedData resolved) {
/*  52 */     this.gateway = gateway;
/*  53 */     this.guildId = guildId;
/*  54 */     this.value = value;
/*  55 */     this.type = type;
/*  56 */     this.resolved = resolved;
/*     */   }
/*     */   
/*     */   public String getRaw() {
/*  60 */     return this.value;
/*     */   }
/*     */   
/*     */   public String asString() {
/*  64 */     return getValueAs("string", Function.identity(), new ApplicationCommandOption.Type[] { ApplicationCommandOption.Type.STRING });
/*     */   }
/*     */   
/*     */   public boolean asBoolean() {
/*  68 */     return ((Boolean)getValueAs("boolean", Boolean::parseBoolean, new ApplicationCommandOption.Type[] { ApplicationCommandOption.Type.BOOLEAN })).booleanValue();
/*     */   }
/*     */   
/*     */   public long asLong() {
/*  72 */     return ((Long)getValueAs("long", Long::parseLong, new ApplicationCommandOption.Type[] { ApplicationCommandOption.Type.INTEGER })).longValue();
/*     */   }
/*     */   
/*     */   public double asDouble() {
/*  76 */     return ((Double)getValueAs("double", Double::parseDouble, new ApplicationCommandOption.Type[] { ApplicationCommandOption.Type.NUMBER })).doubleValue();
/*     */   }
/*     */   
/*     */   public Snowflake asSnowflake() {
/*  80 */     return getValueAs("snowflake", Snowflake::of, new ApplicationCommandOption.Type[] { ApplicationCommandOption.Type.USER, ApplicationCommandOption.Type.ROLE, ApplicationCommandOption.Type.CHANNEL, ApplicationCommandOption.Type.MENTIONABLE });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<User> asUser() {
/*  88 */     return getValueAs("user", value -> getClient().getUserById(Snowflake.of(value)), new ApplicationCommandOption.Type[] { ApplicationCommandOption.Type.USER });
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Role> asRole() {
/*  94 */     return getValueAs("role", value -> getClient().getRoleById(Snowflake.of(((Long)Objects.<Long>requireNonNull(this.guildId)).longValue()), Snowflake.of(value)), new ApplicationCommandOption.Type[] { ApplicationCommandOption.Type.ROLE });
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Channel> asChannel() {
/* 100 */     return getValueAs("channel", value -> getClient().getChannelById(Snowflake.of(value)), new ApplicationCommandOption.Type[] { ApplicationCommandOption.Type.CHANNEL });
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Attachment asAttachment() {
/* 106 */     return getValueAs("attachment", value -> new Attachment(getClient(), (AttachmentData)((Map)((ApplicationCommandInteractionResolvedData)Objects.<ApplicationCommandInteractionResolvedData>requireNonNull(this.resolved)).attachments().get()).get(value)), new ApplicationCommandOption.Type[] { ApplicationCommandOption.Type.ATTACHMENT });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private <T> T getValueAs(String parsedTypeName, Function<String, T> parser, ApplicationCommandOption.Type... allowedTypes) {
/* 114 */     if (!Arrays.<ApplicationCommandOption.Type>asList(allowedTypes).contains(ApplicationCommandOption.Type.of(this.type))) {
/* 115 */       throw new IllegalArgumentException("Option value cannot be converted as " + parsedTypeName);
/*     */     }
/*     */     
/* 118 */     return parser.apply(this.value);
/*     */   }
/*     */ 
/*     */   
/*     */   public GatewayDiscordClient getClient() {
/* 123 */     return this.gateway;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\object\command\ApplicationCommandInteractionOptionValue.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */