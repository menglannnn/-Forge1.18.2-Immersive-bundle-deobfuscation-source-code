/*    */ package discord4j.core.object;
/*    */ 
/*    */ import discord4j.core.GatewayDiscordClient;
/*    */ import discord4j.discordjson.json.IntegrationAccountData;
/*    */ import java.util.Objects;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IntegrationAccount
/*    */   implements DiscordObject
/*    */ {
/*    */   private final GatewayDiscordClient gateway;
/*    */   private final IntegrationAccountData data;
/*    */   
/*    */   public IntegrationAccount(GatewayDiscordClient gateway, IntegrationAccountData data) {
/* 44 */     this.gateway = Objects.<GatewayDiscordClient>requireNonNull(gateway);
/* 45 */     this.data = Objects.<IntegrationAccountData>requireNonNull(data);
/*    */   }
/*    */ 
/*    */   
/*    */   public GatewayDiscordClient getClient() {
/* 50 */     return this.gateway;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public IntegrationAccountData getData() {
/* 59 */     return this.data;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getId() {
/* 68 */     return this.data.id();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getName() {
/* 77 */     return this.data.name();
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\object\IntegrationAccount.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */