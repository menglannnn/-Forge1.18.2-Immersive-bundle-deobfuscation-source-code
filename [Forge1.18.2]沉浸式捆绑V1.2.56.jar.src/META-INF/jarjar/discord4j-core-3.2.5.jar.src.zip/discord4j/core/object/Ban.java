/*    */ package discord4j.core.object;
/*    */ 
/*    */ import discord4j.core.GatewayDiscordClient;
/*    */ import discord4j.core.object.entity.User;
/*    */ import discord4j.discordjson.json.BanData;
/*    */ import java.util.Objects;
/*    */ import java.util.Optional;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Ban
/*    */   implements DiscordObject
/*    */ {
/*    */   private final GatewayDiscordClient gateway;
/*    */   private final BanData data;
/*    */   
/*    */   public Ban(GatewayDiscordClient gateway, BanData data) {
/* 46 */     this.gateway = Objects.<GatewayDiscordClient>requireNonNull(gateway);
/* 47 */     this.data = Objects.<BanData>requireNonNull(data);
/*    */   }
/*    */ 
/*    */   
/*    */   public GatewayDiscordClient getClient() {
/* 52 */     return this.gateway;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public BanData getData() {
/* 61 */     return this.data;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Optional<String> getReason() {
/* 70 */     return this.data.reason();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public User getUser() {
/* 79 */     return new User(this.gateway, this.data.user());
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 84 */     return "Ban{data=" + this.data + '}';
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\object\Ban.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */