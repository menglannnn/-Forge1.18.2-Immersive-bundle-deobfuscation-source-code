/*    */ package discord4j.core;
/*    */ 
/*    */ import discord4j.common.JacksonResources;
/*    */ import discord4j.common.ReactorResources;
/*    */ import discord4j.rest.RestResources;
/*    */ import discord4j.rest.request.Router;
/*    */ import discord4j.rest.util.AllowedMentions;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CoreResources
/*    */   extends RestResources
/*    */ {
/*    */   public CoreResources(String token, ReactorResources reactorResources, JacksonResources jacksonResources, Router router, @Nullable AllowedMentions allowedMentions) {
/* 44 */     super(token, reactorResources, jacksonResources, router, allowedMentions);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\CoreResources.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */