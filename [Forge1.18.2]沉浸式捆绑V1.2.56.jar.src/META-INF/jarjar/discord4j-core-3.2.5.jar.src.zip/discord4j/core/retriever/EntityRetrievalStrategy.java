/*    */ package discord4j.core.retriever;
/*    */ 
/*    */ import discord4j.core.GatewayDiscordClient;
/*    */ import java.util.function.Function;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @FunctionalInterface
/*    */ public interface EntityRetrievalStrategy
/*    */   extends Function<GatewayDiscordClient, EntityRetriever>
/*    */ {
/* 49 */   public static final EntityRetrievalStrategy STORE = StoreEntityRetriever::new;
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 54 */   public static final EntityRetrievalStrategy REST = RestEntityRetriever::new;
/*    */   
/*    */   public static final EntityRetrievalStrategy STORE_FALLBACK_REST;
/*    */   
/*    */   static {
/* 59 */     STORE_FALLBACK_REST = (gateway -> new FallbackEntityRetriever(new StoreEntityRetriever(gateway), new RestEntityRetriever(gateway)));
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\retriever\EntityRetrievalStrategy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */