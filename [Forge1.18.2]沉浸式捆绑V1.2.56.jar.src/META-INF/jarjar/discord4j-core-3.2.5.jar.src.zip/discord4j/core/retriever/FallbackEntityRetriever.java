/*     */ package discord4j.core.retriever;
/*     */ 
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.object.ScheduledEventUser;
/*     */ import discord4j.core.object.automod.AutoModRule;
/*     */ import discord4j.core.object.entity.Guild;
/*     */ import discord4j.core.object.entity.GuildEmoji;
/*     */ import discord4j.core.object.entity.GuildSticker;
/*     */ import discord4j.core.object.entity.Member;
/*     */ import discord4j.core.object.entity.Message;
/*     */ import discord4j.core.object.entity.Role;
/*     */ import discord4j.core.object.entity.ScheduledEvent;
/*     */ import discord4j.core.object.entity.User;
/*     */ import discord4j.core.object.entity.channel.Channel;
/*     */ import discord4j.core.object.entity.channel.GuildChannel;
/*     */ import org.reactivestreams.Publisher;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FallbackEntityRetriever
/*     */   implements EntityRetriever
/*     */ {
/*     */   private final EntityRetriever first;
/*     */   private final EntityRetriever fallback;
/*     */   
/*     */   public FallbackEntityRetriever(EntityRetriever first, EntityRetriever fallback) {
/*  34 */     this.first = first;
/*  35 */     this.fallback = fallback;
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Channel> getChannelById(Snowflake channelId) {
/*  40 */     return this.first.getChannelById(channelId).switchIfEmpty(this.fallback.getChannelById(channelId));
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Guild> getGuildById(Snowflake guildId) {
/*  45 */     return this.first.getGuildById(guildId).switchIfEmpty(this.fallback.getGuildById(guildId));
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<GuildSticker> getGuildStickerById(Snowflake guildId, Snowflake stickerId) {
/*  50 */     return this.first.getGuildStickerById(guildId, stickerId).switchIfEmpty(this.fallback.getGuildStickerById(guildId, stickerId));
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<GuildEmoji> getGuildEmojiById(Snowflake guildId, Snowflake emojiId) {
/*  55 */     return this.first.getGuildEmojiById(guildId, emojiId).switchIfEmpty(this.fallback.getGuildEmojiById(guildId, emojiId));
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Member> getMemberById(Snowflake guildId, Snowflake userId) {
/*  60 */     return this.first.getMemberById(guildId, userId).switchIfEmpty(this.fallback.getMemberById(guildId, userId));
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Message> getMessageById(Snowflake channelId, Snowflake messageId) {
/*  65 */     return this.first.getMessageById(channelId, messageId).switchIfEmpty(this.fallback.getMessageById(channelId, messageId));
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Role> getRoleById(Snowflake guildId, Snowflake roleId) {
/*  70 */     return this.first.getRoleById(guildId, roleId).switchIfEmpty(this.fallback.getRoleById(guildId, roleId));
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<User> getUserById(Snowflake userId) {
/*  75 */     return this.first.getUserById(userId).switchIfEmpty(this.fallback.getUserById(userId));
/*     */   }
/*     */ 
/*     */   
/*     */   public Flux<Guild> getGuilds() {
/*  80 */     return this.first.getGuilds().switchIfEmpty((Publisher)this.fallback.getGuilds());
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<User> getSelf() {
/*  85 */     return this.first.getSelf().switchIfEmpty(this.fallback.getSelf());
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Member> getSelfMember(Snowflake guildId) {
/*  90 */     return this.first.getSelfMember(guildId).switchIfEmpty(this.fallback.getSelfMember(guildId));
/*     */   }
/*     */ 
/*     */   
/*     */   public Flux<Member> getGuildMembers(Snowflake guildId) {
/*  95 */     return this.first.getGuildMembers(guildId).switchIfEmpty((Publisher)this.fallback.getGuildMembers(guildId));
/*     */   }
/*     */ 
/*     */   
/*     */   public Flux<GuildChannel> getGuildChannels(Snowflake guildId) {
/* 100 */     return this.first.getGuildChannels(guildId).switchIfEmpty((Publisher)this.fallback.getGuildChannels(guildId));
/*     */   }
/*     */ 
/*     */   
/*     */   public Flux<Role> getGuildRoles(Snowflake guildId) {
/* 105 */     return this.first.getGuildRoles(guildId).switchIfEmpty((Publisher)this.fallback.getGuildRoles(guildId));
/*     */   }
/*     */ 
/*     */   
/*     */   public Flux<GuildEmoji> getGuildEmojis(Snowflake guildId) {
/* 110 */     return this.first.getGuildEmojis(guildId).switchIfEmpty((Publisher)this.fallback.getGuildEmojis(guildId));
/*     */   }
/*     */ 
/*     */   
/*     */   public Flux<GuildSticker> getGuildStickers(Snowflake guildId) {
/* 115 */     return this.first.getGuildStickers(guildId).switchIfEmpty((Publisher)this.fallback.getGuildStickers(guildId));
/*     */   }
/*     */ 
/*     */   
/*     */   public Flux<AutoModRule> getGuildAutoModRules(Snowflake guildId) {
/* 120 */     return this.first.getGuildAutoModRules(guildId).switchIfEmpty((Publisher)this.fallback.getGuildAutoModRules(guildId));
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<ScheduledEvent> getScheduledEventById(Snowflake guildId, Snowflake eventId) {
/* 125 */     return this.first.getScheduledEventById(guildId, eventId).switchIfEmpty(this.fallback.getScheduledEventById(guildId, eventId));
/*     */   }
/*     */ 
/*     */   
/*     */   public Flux<ScheduledEvent> getScheduledEvents(Snowflake guildId) {
/* 130 */     return this.first.getScheduledEvents(guildId).switchIfEmpty((Publisher)this.fallback.getScheduledEvents(guildId));
/*     */   }
/*     */ 
/*     */   
/*     */   public Flux<ScheduledEventUser> getScheduledEventUsers(Snowflake guildId, Snowflake eventId) {
/* 135 */     return this.first.getScheduledEventUsers(guildId, eventId).switchIfEmpty((Publisher)this.fallback.getScheduledEventUsers(guildId, eventId));
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\retriever\FallbackEntityRetriever.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */