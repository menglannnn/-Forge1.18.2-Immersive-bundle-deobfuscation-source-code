package discord4j.core.retriever;

import discord4j.common.util.Snowflake;
import discord4j.core.object.ScheduledEventUser;
import discord4j.core.object.automod.AutoModRule;
import discord4j.core.object.entity.Guild;
import discord4j.core.object.entity.GuildEmoji;
import discord4j.core.object.entity.GuildSticker;
import discord4j.core.object.entity.Member;
import discord4j.core.object.entity.Message;
import discord4j.core.object.entity.Role;
import discord4j.core.object.entity.ScheduledEvent;
import discord4j.core.object.entity.User;
import discord4j.core.object.entity.channel.Channel;
import discord4j.core.object.entity.channel.GuildChannel;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public interface EntityRetriever {
  Mono<Channel> getChannelById(Snowflake paramSnowflake);
  
  Mono<Guild> getGuildById(Snowflake paramSnowflake);
  
  Mono<GuildSticker> getGuildStickerById(Snowflake paramSnowflake1, Snowflake paramSnowflake2);
  
  Mono<GuildEmoji> getGuildEmojiById(Snowflake paramSnowflake1, Snowflake paramSnowflake2);
  
  Mono<Member> getMemberById(Snowflake paramSnowflake1, Snowflake paramSnowflake2);
  
  Mono<Message> getMessageById(Snowflake paramSnowflake1, Snowflake paramSnowflake2);
  
  Mono<Role> getRoleById(Snowflake paramSnowflake1, Snowflake paramSnowflake2);
  
  Mono<User> getUserById(Snowflake paramSnowflake);
  
  Flux<Guild> getGuilds();
  
  Mono<User> getSelf();
  
  Mono<Member> getSelfMember(Snowflake paramSnowflake);
  
  Flux<Member> getGuildMembers(Snowflake paramSnowflake);
  
  Flux<GuildChannel> getGuildChannels(Snowflake paramSnowflake);
  
  Flux<Role> getGuildRoles(Snowflake paramSnowflake);
  
  Flux<GuildEmoji> getGuildEmojis(Snowflake paramSnowflake);
  
  Flux<GuildSticker> getGuildStickers(Snowflake paramSnowflake);
  
  Flux<AutoModRule> getGuildAutoModRules(Snowflake paramSnowflake);
  
  Mono<ScheduledEvent> getScheduledEventById(Snowflake paramSnowflake1, Snowflake paramSnowflake2);
  
  Flux<ScheduledEvent> getScheduledEvents(Snowflake paramSnowflake);
  
  Flux<ScheduledEventUser> getScheduledEventUsers(Snowflake paramSnowflake1, Snowflake paramSnowflake2);
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\retriever\EntityRetriever.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */