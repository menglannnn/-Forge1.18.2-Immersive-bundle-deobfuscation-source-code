/*     */ package discord4j.core.retriever;
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.GatewayDiscordClient;
/*     */ import discord4j.core.object.ScheduledEventUser;
/*     */ import discord4j.core.object.automod.AutoModRule;
/*     */ import discord4j.core.object.entity.Guild;
/*     */ import discord4j.core.object.entity.GuildEmoji;
/*     */ import discord4j.core.object.entity.GuildSticker;
/*     */ import discord4j.core.object.entity.Member;
/*     */ import discord4j.core.object.entity.Message;
/*     */ import discord4j.core.object.entity.Role;
/*     */ import discord4j.core.object.entity.ScheduledEvent;
/*     */ import discord4j.core.object.entity.User;
/*     */ import discord4j.core.object.entity.channel.Channel;
/*     */ import discord4j.core.object.entity.channel.GuildChannel;
/*     */ import discord4j.core.util.EntityUtil;
/*     */ import discord4j.discordjson.Id;
/*     */ import discord4j.discordjson.json.AutoModRuleData;
/*     */ import discord4j.discordjson.json.ChannelData;
/*     */ import discord4j.discordjson.json.EmojiData;
/*     */ import discord4j.discordjson.json.GuildData;
/*     */ import discord4j.discordjson.json.GuildScheduledEventData;
/*     */ import discord4j.discordjson.json.GuildScheduledEventUserData;
/*     */ import discord4j.discordjson.json.GuildUpdateData;
/*     */ import discord4j.discordjson.json.MemberData;
/*     */ import discord4j.discordjson.json.MessageData;
/*     */ import discord4j.discordjson.json.RoleData;
/*     */ import discord4j.discordjson.json.StickerData;
/*     */ import discord4j.discordjson.json.UserData;
/*     */ import discord4j.discordjson.json.UserGuildData;
/*     */ import discord4j.rest.RestClient;
/*     */ import discord4j.rest.util.PaginationUtil;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.function.Function;
/*     */ import java.util.stream.Collectors;
/*     */ import org.reactivestreams.Publisher;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ public class RestEntityRetriever implements EntityRetriever {
/*     */   private final GatewayDiscordClient gateway;
/*     */   
/*     */   public RestEntityRetriever(GatewayDiscordClient gateway) {
/*  46 */     this.gateway = gateway;
/*  47 */     this.rest = (RestClient)gateway.rest();
/*     */   }
/*     */   private final RestClient rest;
/*     */   
/*     */   public Mono<Channel> getChannelById(Snowflake channelId) {
/*  52 */     return this.rest.getChannelService()
/*  53 */       .getChannel(channelId.asLong())
/*  54 */       .map(data -> EntityUtil.getChannel(this.gateway, data));
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Guild> getGuildById(Snowflake guildId) {
/*  59 */     return this.rest.getGuildService()
/*  60 */       .getGuild(guildId.asLong())
/*  61 */       .map(this::toGuildData)
/*  62 */       .map(data -> new Guild(this.gateway, data));
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<GuildSticker> getGuildStickerById(Snowflake guildId, Snowflake stickerId) {
/*  67 */     return this.rest.getStickerService()
/*  68 */       .getGuildSticker(guildId.asLong(), stickerId.asLong())
/*  69 */       .map(data -> new GuildSticker(this.gateway, data, guildId.asLong()));
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<GuildEmoji> getGuildEmojiById(Snowflake guildId, Snowflake emojiId) {
/*  74 */     return this.rest.getEmojiService()
/*  75 */       .getGuildEmoji(guildId.asLong(), emojiId.asLong())
/*  76 */       .map(data -> new GuildEmoji(this.gateway, data, guildId.asLong()));
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Member> getMemberById(Snowflake guildId, Snowflake userId) {
/*  81 */     return this.rest.getGuildService()
/*  82 */       .getGuildMember(guildId.asLong(), userId.asLong())
/*  83 */       .map(data -> new Member(this.gateway, data, guildId.asLong()));
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Message> getMessageById(Snowflake channelId, Snowflake messageId) {
/*  88 */     return this.rest.getChannelService()
/*  89 */       .getMessage(channelId.asLong(), messageId.asLong())
/*  90 */       .map(data -> new Message(this.gateway, data));
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Role> getRoleById(Snowflake guildId, Snowflake roleId) {
/*  95 */     return this.rest.getGuildService()
/*  96 */       .getGuildRoles(guildId.asLong())
/*  97 */       .filter(response -> response.id().asString().equals(roleId.asString()))
/*  98 */       .singleOrEmpty()
/*  99 */       .map(data -> new Role(this.gateway, data, guildId.asLong()));
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<User> getUserById(Snowflake userId) {
/* 104 */     return this.rest.getUserService()
/* 105 */       .getUser(userId.asLong())
/* 106 */       .map(data -> new User(this.gateway, data));
/*     */   }
/*     */ 
/*     */   
/*     */   public Flux<Guild> getGuilds() {
/* 111 */     Function<Map<String, Object>, Flux<UserGuildData>> makeRequest = params -> this.rest.getUserService().getCurrentUserGuilds(params);
/*     */     
/* 113 */     return PaginationUtil.paginateAfter(makeRequest, data -> Snowflake.asLong(data.id()), 0L, 100)
/* 114 */       .map(GuildFields::id)
/* 115 */       .flatMap(id -> this.rest.getGuildService().getGuild(Snowflake.asLong(id)))
/* 116 */       .map(this::toGuildData)
/* 117 */       .map(data -> new Guild(this.gateway, data));
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<User> getSelf() {
/* 122 */     return this.rest.getUserService().getCurrentUser().map(data -> new User(this.gateway, data));
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Member> getSelfMember(Snowflake guildId) {
/* 127 */     return this.rest.getSelfMember(guildId).map(data -> new Member(this.gateway, data, guildId.asLong()));
/*     */   }
/*     */ 
/*     */   
/*     */   public Flux<Member> getGuildMembers(Snowflake guildId) {
/* 132 */     Function<Map<String, Object>, Flux<MemberData>> doRequest = params -> this.rest.getGuildService().getGuildMembers(guildId.asLong(), params);
/*     */ 
/*     */     
/* 135 */     return PaginationUtil.paginateAfter(doRequest, data -> Snowflake.asLong(data.user().id()), 0L, 100)
/* 136 */       .map(data -> new Member(this.gateway, data, guildId.asLong()));
/*     */   }
/*     */ 
/*     */   
/*     */   public Flux<GuildChannel> getGuildChannels(Snowflake guildId) {
/* 141 */     return this.rest.getGuildService()
/* 142 */       .getGuildChannels(guildId.asLong())
/* 143 */       .map(data -> EntityUtil.getChannel(this.gateway, data))
/* 144 */       .ofType(GuildChannel.class);
/*     */   }
/*     */ 
/*     */   
/*     */   public Flux<Role> getGuildRoles(Snowflake guildId) {
/* 149 */     return this.rest.getGuildService()
/* 150 */       .getGuildRoles(guildId.asLong())
/* 151 */       .map(data -> new Role(this.gateway, data, guildId.asLong()));
/*     */   }
/*     */ 
/*     */   
/*     */   public Flux<GuildEmoji> getGuildEmojis(Snowflake guildId) {
/* 156 */     return this.rest.getEmojiService()
/* 157 */       .getGuildEmojis(guildId.asLong())
/* 158 */       .map(data -> new GuildEmoji(this.gateway, data, guildId.asLong()));
/*     */   }
/*     */ 
/*     */   
/*     */   public Flux<GuildSticker> getGuildStickers(Snowflake guildId) {
/* 163 */     return this.rest.getStickerService()
/* 164 */       .getGuildStickers(guildId.asLong())
/* 165 */       .map(data -> new GuildSticker(this.gateway, data, guildId.asLong()));
/*     */   }
/*     */ 
/*     */   
/*     */   public Flux<AutoModRule> getGuildAutoModRules(Snowflake guildId) {
/* 170 */     return this.rest.getAutoModService()
/* 171 */       .getAutoModRules(guildId.asLong())
/* 172 */       .map(data -> new AutoModRule(this.gateway, data));
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<ScheduledEvent> getScheduledEventById(Snowflake guildId, Snowflake eventId) {
/* 177 */     Map<String, Object> queryParams = new HashMap<>();
/* 178 */     queryParams.put("with_user_count", Boolean.valueOf(true));
/*     */     
/* 180 */     return this.rest.getGuildService()
/* 181 */       .getScheduledEvent(guildId.asLong(), eventId.asLong(), queryParams)
/* 182 */       .map(data -> new ScheduledEvent(this.gateway, data));
/*     */   }
/*     */ 
/*     */   
/*     */   public Flux<ScheduledEvent> getScheduledEvents(Snowflake guildId) {
/* 187 */     Map<String, Object> queryParams = new HashMap<>();
/* 188 */     queryParams.put("with_user_count", Boolean.valueOf(true));
/*     */     
/* 190 */     return this.rest.getGuildService()
/* 191 */       .getScheduledEvents(guildId.asLong(), queryParams)
/* 192 */       .map(data -> new ScheduledEvent(this.gateway, data));
/*     */   }
/*     */ 
/*     */   
/*     */   public Flux<ScheduledEventUser> getScheduledEventUsers(Snowflake guildId, Snowflake eventId) {
/* 197 */     Function<Map<String, Object>, Flux<GuildScheduledEventUserData>> doRequest = params -> {
/*     */         params.put("with_member", Boolean.valueOf(true));
/*     */         
/*     */         return this.rest.getGuildService().getScheduledEventUsers(guildId.asLong(), eventId.asLong(), params);
/*     */       };
/* 202 */     return PaginationUtil.paginateAfter(doRequest, data -> Snowflake.asLong(data.user().id()), 0L, 100)
/* 203 */       .map(data -> new ScheduledEventUser(this.gateway, data, guildId));
/*     */   }
/*     */ 
/*     */   
/*     */   private GuildData toGuildData(GuildUpdateData guild) {
/* 208 */     return (GuildData)GuildData.builder()
/* 209 */       .from((GuildUpdateFields)guild)
/* 210 */       .roles((List)guild.roles().stream()
/* 211 */         .map(RoleDataFields::id)
/* 212 */         .collect(Collectors.toList()))
/* 213 */       .emojis((List)guild.emojis().stream()
/* 214 */         .map(EmojiData::id)
/* 215 */         .filter(Optional::isPresent)
/* 216 */         .map(Optional::get)
/* 217 */         .collect(Collectors.toList()))
/* 218 */       .channels(Collections.emptyList())
/* 219 */       .members(Collections.emptyList())
/* 220 */       .joinedAt("")
/* 221 */       .large(false)
/* 222 */       .memberCount(0)
/* 223 */       .build();
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\retriever\RestEntityRetriever.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */