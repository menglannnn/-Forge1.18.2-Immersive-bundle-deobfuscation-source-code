/*     */ package discord4j.core.retriever;
/*     */ 
/*     */ import discord4j.common.store.Store;
/*     */ import discord4j.common.store.action.read.ReadActions;
/*     */ import discord4j.common.store.api.StoreAction;
/*     */ import discord4j.common.store.api.object.ExactResultNotAvailableException;
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.GatewayDiscordClient;
/*     */ import discord4j.core.object.ScheduledEventUser;
/*     */ import discord4j.core.object.automod.AutoModRule;
/*     */ import discord4j.core.object.entity.Guild;
/*     */ import discord4j.core.object.entity.GuildEmoji;
/*     */ import discord4j.core.object.entity.GuildSticker;
/*     */ import discord4j.core.object.entity.Member;
/*     */ import discord4j.core.object.entity.Message;
/*     */ import discord4j.core.object.entity.Role;
/*     */ import discord4j.core.object.entity.ScheduledEvent;
/*     */ import discord4j.core.object.entity.User;
/*     */ import discord4j.core.object.entity.channel.Channel;
/*     */ import discord4j.core.object.entity.channel.GuildChannel;
/*     */ import discord4j.core.util.EntityUtil;
/*     */ import discord4j.discordjson.Id;
/*     */ import discord4j.discordjson.json.AutoModRuleData;
/*     */ import discord4j.discordjson.json.ChannelData;
/*     */ import discord4j.discordjson.json.EmojiData;
/*     */ import discord4j.discordjson.json.GuildData;
/*     */ import discord4j.discordjson.json.GuildScheduledEventData;
/*     */ import discord4j.discordjson.json.GuildScheduledEventUserData;
/*     */ import discord4j.discordjson.json.MemberData;
/*     */ import discord4j.discordjson.json.MessageData;
/*     */ import discord4j.discordjson.json.RoleData;
/*     */ import discord4j.discordjson.json.StickerData;
/*     */ import discord4j.discordjson.json.UserData;
/*     */ import java.util.Collections;
/*     */ import org.reactivestreams.Publisher;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ public class StoreEntityRetriever implements EntityRetriever {
/*     */   private final GatewayDiscordClient gateway;
/*     */   
/*     */   public StoreEntityRetriever(GatewayDiscordClient gateway) {
/*  43 */     this.gateway = gateway;
/*  44 */     this.store = gateway.getGatewayResources().getStore();
/*     */   }
/*     */   private final Store store;
/*     */   
/*     */   public Mono<Channel> getChannelById(Snowflake channelId) {
/*  49 */     return Mono.from(this.store.execute((StoreAction)ReadActions.getChannelById(channelId.asLong())))
/*  50 */       .map(data -> EntityUtil.getChannel(this.gateway, data));
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Guild> getGuildById(Snowflake guildId) {
/*  55 */     return Mono.from(this.store.execute((StoreAction)ReadActions.getGuildById(guildId.asLong())))
/*  56 */       .map(data -> new Guild(this.gateway, data));
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<GuildSticker> getGuildStickerById(Snowflake guildId, Snowflake stickerId) {
/*  61 */     return Mono.from(this.store.execute((StoreAction)ReadActions.getStickerById(guildId.asLong(), stickerId.asLong())))
/*  62 */       .map(data -> new GuildSticker(this.gateway, data, guildId.asLong()));
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<GuildEmoji> getGuildEmojiById(Snowflake guildId, Snowflake emojiId) {
/*  67 */     return Mono.from(this.store.execute((StoreAction)ReadActions.getEmojiById(guildId.asLong(), emojiId.asLong())))
/*  68 */       .map(data -> new GuildEmoji(this.gateway, data, guildId.asLong()));
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Member> getMemberById(Snowflake guildId, Snowflake userId) {
/*  73 */     return Mono.from(this.store.execute((StoreAction)ReadActions.getMemberById(guildId.asLong(), userId.asLong())))
/*  74 */       .map(data -> new Member(this.gateway, data, guildId.asLong()))
/*  75 */       .onErrorResume(ExactResultNotAvailableException.class, ignored -> this.gateway.requestMembers(guildId, Collections.singleton(userId)).filter(()).next());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Message> getMessageById(Snowflake channelId, Snowflake messageId) {
/*  83 */     return Mono.from(this.store.execute((StoreAction)ReadActions.getMessageById(channelId.asLong(), messageId.asLong())))
/*  84 */       .map(data -> new Message(this.gateway, data));
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Role> getRoleById(Snowflake guildId, Snowflake roleId) {
/*  89 */     return Mono.from(this.store.execute((StoreAction)ReadActions.getRoleById(guildId.asLong(), roleId.asLong())))
/*  90 */       .map(data -> new Role(this.gateway, data, guildId.asLong()));
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<User> getUserById(Snowflake userId) {
/*  95 */     return Mono.from(this.store.execute((StoreAction)ReadActions.getUserById(userId.asLong())))
/*  96 */       .map(data -> new User(this.gateway, data));
/*     */   }
/*     */ 
/*     */   
/*     */   public Flux<Guild> getGuilds() {
/* 101 */     return Flux.from(this.store.execute((StoreAction)ReadActions.getGuilds()))
/* 102 */       .map(data -> new Guild(this.gateway, data));
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<User> getSelf() {
/* 107 */     return getUserById(this.gateway.getSelfId());
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Member> getSelfMember(Snowflake guildId) {
/* 112 */     return getMemberById(guildId, this.gateway.getSelfId());
/*     */   }
/*     */ 
/*     */   
/*     */   public Flux<Member> getGuildMembers(Snowflake guildId) {
/* 117 */     return Flux.from(this.store.execute((StoreAction)ReadActions.getExactMembersInGuild(guildId.asLong())))
/* 118 */       .map(data -> new Member(this.gateway, data, guildId.asLong()))
/* 119 */       .onErrorResume(ExactResultNotAvailableException.class, e -> this.gateway.requestMembers(guildId));
/*     */   }
/*     */ 
/*     */   
/*     */   public Flux<GuildChannel> getGuildChannels(Snowflake guildId) {
/* 124 */     return Flux.from(this.store.execute((StoreAction)ReadActions.getChannelsInGuild(guildId.asLong())))
/* 125 */       .map(channelData -> EntityUtil.getChannel(this.gateway, channelData))
/* 126 */       .ofType(GuildChannel.class);
/*     */   }
/*     */ 
/*     */   
/*     */   public Flux<Role> getGuildRoles(Snowflake guildId) {
/* 131 */     return Flux.from(this.store.execute((StoreAction)ReadActions.getRolesInGuild(guildId.asLong())))
/* 132 */       .map(roleData -> new Role(this.gateway, roleData, guildId.asLong()));
/*     */   }
/*     */ 
/*     */   
/*     */   public Flux<GuildEmoji> getGuildEmojis(Snowflake guildId) {
/* 137 */     return Flux.from(this.store.execute((StoreAction)ReadActions.getEmojisInGuild(guildId.asLong())))
/* 138 */       .map(emojiData -> new GuildEmoji(this.gateway, emojiData, guildId.asLong()));
/*     */   }
/*     */ 
/*     */   
/*     */   public Flux<GuildSticker> getGuildStickers(Snowflake guildId) {
/* 143 */     return Flux.from(this.store.execute((StoreAction)ReadActions.getStickersInGuild(guildId.asLong())))
/* 144 */       .map(data -> new GuildSticker(this.gateway, data, guildId.asLong()));
/*     */   }
/*     */ 
/*     */   
/*     */   public Flux<AutoModRule> getGuildAutoModRules(Snowflake guildId) {
/* 149 */     return Flux.from(this.store.execute((StoreAction)ReadActions.getAutoModRulesInGuild(guildId.asLong())))
/* 150 */       .map(data -> new AutoModRule(this.gateway, data));
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<ScheduledEvent> getScheduledEventById(Snowflake guildId, Snowflake eventId) {
/* 155 */     return Mono.from(this.store.execute((StoreAction)ReadActions.getScheduledEventById(guildId.asLong(), eventId.asLong())))
/* 156 */       .map(data -> new ScheduledEvent(this.gateway, data));
/*     */   }
/*     */ 
/*     */   
/*     */   public Flux<ScheduledEvent> getScheduledEvents(Snowflake guildId) {
/* 161 */     return Flux.from(this.store.execute((StoreAction)ReadActions.getScheduledEventsInGuild(guildId.asLong())))
/* 162 */       .map(data -> new ScheduledEvent(this.gateway, data));
/*     */   }
/*     */ 
/*     */   
/*     */   public Flux<ScheduledEventUser> getScheduledEventUsers(Snowflake guildId, Snowflake eventId) {
/* 167 */     return Flux.from(this.store.execute((StoreAction)ReadActions.getScheduledEventsUsers(guildId.asLong(), eventId.asLong())))
/* 168 */       .flatMap(id -> Mono.from(this.store.execute((StoreAction)ReadActions.getUserById(id.asLong()))))
/* 169 */       .map(userData -> new ScheduledEventUser(this.gateway, (GuildScheduledEventUserData)GuildScheduledEventUserData.builder().user(userData).guildScheduledEventId(eventId.asLong()).build(), guildId));
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\retriever\StoreEntityRetriever.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */