/*    */ package discord4j.core;
/*    */ 
/*    */ import discord4j.common.GitProperties;
/*    */ import discord4j.rest.RestClientBuilder;
/*    */ import discord4j.rest.request.Router;
/*    */ import discord4j.rest.request.RouterOptions;
/*    */ import java.util.Properties;
/*    */ import java.util.function.Function;
/*    */ import reactor.util.Logger;
/*    */ import reactor.util.Loggers;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class DiscordClientBuilder<C, O extends RouterOptions>
/*    */   extends RestClientBuilder<C, O>
/*    */ {
/* 35 */   private static final Logger log = Loggers.getLogger(DiscordClientBuilder.class);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static DiscordClientBuilder<DiscordClient, RouterOptions> create(String token) {
/* 43 */     Function<RestClientBuilder.Config, DiscordClient> clientFactory = config -> {
/*    */         CoreResources coreResources = new CoreResources(config.getToken(), config.getReactorResources(), config.getJacksonResources(), config.getRouter(), config.getAllowedMentions().orElse(null));
/*    */         
/*    */         Properties properties = GitProperties.getProperties();
/*    */         String url = properties.getProperty("application.url", "https://discord4j.com");
/*    */         String name = properties.getProperty("application.name", "Discord4J");
/*    */         String version = properties.getProperty("git.build.version", "3.2");
/*    */         String gitDescribe = properties.getProperty("git.commit.id.describe", version);
/*    */         log.info("{} {} ({})", new Object[] { name, gitDescribe, url });
/*    */         return new DiscordClient(coreResources);
/*    */       };
/* 54 */     return new DiscordClientBuilder<>(token, clientFactory, Function.identity());
/*    */   }
/*    */   
/*    */   DiscordClientBuilder(String token, Function<RestClientBuilder.Config, C> allocator, Function<RouterOptions, O> optionsModifier) {
/* 58 */     super(token, allocator, optionsModifier);
/*    */   }
/*    */ 
/*    */   
/*    */   DiscordClientBuilder(DiscordClientBuilder<?, ?> source, Function<RestClientBuilder.Config, C> allocator, Function<RouterOptions, O> optionsModifier) {
/* 63 */     super(source, allocator, optionsModifier);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public C build() {
/* 73 */     return build(discord4j.rest.request.DefaultRouter::new);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public C build(Function<O, Router> routerFactory) {
/* 85 */     return (C)super.build(routerFactory);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\DiscordClientBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */