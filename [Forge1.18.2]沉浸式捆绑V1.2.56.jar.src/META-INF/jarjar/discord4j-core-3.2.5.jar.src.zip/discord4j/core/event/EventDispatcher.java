/*     */ package discord4j.core.event;
/*     */ 
/*     */ import discord4j.common.LogUtil;
/*     */ import discord4j.core.event.domain.Event;
/*     */ import java.time.Duration;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Supplier;
/*     */ import org.reactivestreams.Publisher;
/*     */ import reactor.core.publisher.EmitterProcessor;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.FluxProcessor;
/*     */ import reactor.core.publisher.FluxSink;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.core.publisher.Sinks;
/*     */ import reactor.core.scheduler.Scheduler;
/*     */ import reactor.scheduler.forkjoin.ForkJoinPoolScheduler;
/*     */ import reactor.util.Logger;
/*     */ import reactor.util.Loggers;
/*     */ import reactor.util.context.Context;
/*     */ import reactor.util.context.ContextView;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface EventDispatcher
/*     */ {
/*  58 */   public static final Logger log = Loggers.getLogger(EventDispatcher.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final Supplier<Scheduler> DEFAULT_EVENT_SCHEDULER = () -> ForkJoinPoolScheduler.create("d4j-events");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default <E extends Event, T> Flux<T> on(Class<E> eventClass, Function<E, Publisher<T>> mapper) {
/* 124 */     return on(eventClass)
/* 125 */       .flatMap(event -> Flux.defer(()).contextWrite(()).onErrorResume(()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Flux<Event> on(ReactiveEventAdapter adapter) {
/* 171 */     return on(Event.class)
/* 172 */       .flatMap(event -> Flux.defer(()).contextWrite(()).onErrorResume(()).then(Mono.just(event)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Builder builder() {
/* 205 */     return new DefaultEventDispatcher.Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static EventDispatcher buffering() {
/* 216 */     return builder().build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static EventDispatcher withEarliestEvents(int bufferSize) {
/* 228 */     return builder()
/* 229 */       .eventSink(spec -> spec.multicast().onBackpressureBuffer(bufferSize, false))
/* 230 */       .build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static EventDispatcher withLatestEvents(int bufferSize) {
/* 244 */     return builder()
/* 245 */       .eventProcessor((FluxProcessor<Event, Event>)EmitterProcessor.create(bufferSize, false))
/* 246 */       .overflowStrategy(FluxSink.OverflowStrategy.LATEST)
/* 247 */       .build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static EventDispatcher replaying() {
/* 264 */     return ReplayingEventDispatcher.create();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static EventDispatcher replayingWithTimeout(Duration maxAge) {
/* 277 */     return builder()
/* 278 */       .eventSink(spec -> spec.replay().limit(maxAge))
/* 279 */       .build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static EventDispatcher replayingWithSize(int historySize) {
/* 291 */     return builder()
/* 292 */       .eventSink(spec -> spec.replay().limit(historySize))
/* 293 */       .build();
/*     */   }
/*     */   
/*     */   <E extends Event> Flux<E> on(Class<E> paramClass);
/*     */   
/*     */   void publish(Event paramEvent);
/*     */   
/*     */   void shutdown();
/*     */   
/*     */   public static interface Builder {
/*     */     SinksEventDispatcher.Builder eventSink(Function<Sinks.ManySpec, Sinks.Many<Event>> param1Function);
/*     */     
/*     */     @Deprecated
/*     */     DefaultEventDispatcher.Builder eventProcessor(FluxProcessor<Event, Event> param1FluxProcessor);
/*     */     
/*     */     @Deprecated
/*     */     DefaultEventDispatcher.Builder overflowStrategy(FluxSink.OverflowStrategy param1OverflowStrategy);
/*     */     
/*     */     DefaultEventDispatcher.Builder eventScheduler(Scheduler param1Scheduler);
/*     */     
/*     */     EventDispatcher build();
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\event\EventDispatcher.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */