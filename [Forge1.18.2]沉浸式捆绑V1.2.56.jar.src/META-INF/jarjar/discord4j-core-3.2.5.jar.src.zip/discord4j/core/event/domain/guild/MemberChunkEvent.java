/*     */ package discord4j.core.event.domain.guild;
/*     */ 
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.GatewayDiscordClient;
/*     */ import discord4j.core.object.entity.Guild;
/*     */ import discord4j.core.object.entity.Member;
/*     */ import discord4j.gateway.ShardInfo;
/*     */ import java.util.List;
/*     */ import java.util.Optional;
/*     */ import java.util.Set;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MemberChunkEvent
/*     */   extends GuildEvent
/*     */ {
/*     */   private final long guildId;
/*     */   private final Set<Member> members;
/*     */   private final int chunkIndex;
/*     */   private final int chunkCount;
/*     */   private final List<Snowflake> notFound;
/*     */   @Nullable
/*     */   private final String nonce;
/*     */   
/*     */   public MemberChunkEvent(GatewayDiscordClient gateway, ShardInfo shardInfo, long guildId, Set<Member> members, int chunkIndex, int chunkCount, List<Snowflake> notFound, @Nullable String nonce) {
/*  58 */     super(gateway, shardInfo);
/*  59 */     this.guildId = guildId;
/*  60 */     this.members = members;
/*  61 */     this.chunkIndex = chunkIndex;
/*  62 */     this.chunkCount = chunkCount;
/*  63 */     this.notFound = notFound;
/*  64 */     this.nonce = nonce;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Snowflake getGuildId() {
/*  73 */     return Snowflake.of(this.guildId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Guild> getGuild() {
/*  83 */     return getClient().getGuildById(getGuildId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<Member> getMembers() {
/*  93 */     return this.members;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getChunkIndex() {
/* 102 */     return this.chunkIndex;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getChunkCount() {
/* 111 */     return this.chunkCount;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Snowflake> getNotFound() {
/* 120 */     return this.notFound;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<String> getNonce() {
/* 129 */     return Optional.ofNullable(this.nonce);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 134 */     return "MemberChunkEvent{guildId=" + this.guildId + ", members=" + this.members + ", chunkIndex=" + this.chunkIndex + ", chunkCount=" + this.chunkCount + ", notFound=" + this.notFound + ", nonce='" + this.nonce + '\'' + '}';
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\event\domain\guild\MemberChunkEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */