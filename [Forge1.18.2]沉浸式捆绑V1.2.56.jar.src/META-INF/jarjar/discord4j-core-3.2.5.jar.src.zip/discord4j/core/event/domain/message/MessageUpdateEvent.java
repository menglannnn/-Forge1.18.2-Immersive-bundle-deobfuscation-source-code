/*     */ package discord4j.core.event.domain.message;
/*     */ 
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.GatewayDiscordClient;
/*     */ import discord4j.core.object.Embed;
/*     */ import discord4j.core.object.entity.Guild;
/*     */ import discord4j.core.object.entity.Message;
/*     */ import discord4j.core.object.entity.channel.MessageChannel;
/*     */ import discord4j.gateway.ShardInfo;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MessageUpdateEvent
/*     */   extends MessageEvent
/*     */ {
/*     */   private final long messageId;
/*     */   private final long channelId;
/*     */   @Nullable
/*     */   private final Long guildId;
/*     */   @Nullable
/*     */   private final Message old;
/*     */   private final boolean contentChanged;
/*     */   @Nullable
/*     */   private final String currentContent;
/*     */   private final boolean embedsChanged;
/*     */   private final List<Embed> currentEmbeds;
/*     */   
/*     */   public MessageUpdateEvent(GatewayDiscordClient gateway, ShardInfo shardInfo, long messageId, long channelId, @Nullable Long guildId, @Nullable Message old, boolean contentChanged, @Nullable String currentContent, boolean embedsChanged, List<Embed> currentEmbeds) {
/*  62 */     super(gateway, shardInfo);
/*  63 */     this.messageId = messageId;
/*  64 */     this.channelId = channelId;
/*  65 */     this.guildId = guildId;
/*  66 */     this.old = old;
/*  67 */     this.contentChanged = contentChanged;
/*  68 */     this.currentContent = currentContent;
/*  69 */     this.embedsChanged = embedsChanged;
/*  70 */     this.currentEmbeds = currentEmbeds;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Snowflake getMessageId() {
/*  79 */     return Snowflake.of(this.messageId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Message> getMessage() {
/*  89 */     return getClient().getMessageById(getChannelId(), getMessageId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Snowflake getChannelId() {
/*  98 */     return Snowflake.of(this.channelId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<MessageChannel> getChannel() {
/* 108 */     return getClient().getChannelById(getChannelId()).cast(MessageChannel.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<Snowflake> getGuildId() {
/* 117 */     return Optional.<Long>ofNullable(this.guildId).map(Snowflake::of);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Guild> getGuild() {
/* 127 */     Objects.requireNonNull(getClient()); return Mono.justOrEmpty(getGuildId()).flatMap(getClient()::getGuildById);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<Message> getOld() {
/* 137 */     return Optional.ofNullable(this.old);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isContentChanged() {
/* 146 */     return this.contentChanged;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<String> getCurrentContent() {
/* 155 */     return Optional.ofNullable(this.currentContent);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEmbedsChanged() {
/* 164 */     return this.embedsChanged;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Embed> getCurrentEmbeds() {
/* 173 */     return this.currentEmbeds;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 178 */     return "MessageUpdateEvent{messageId=" + this.messageId + ", channelId=" + this.channelId + ", guildId=" + this.guildId + ", old=" + this.old + ", contentChanged=" + this.contentChanged + ", currentContent='" + this.currentContent + '\'' + ", embedsChanged=" + this.embedsChanged + ", currentEmbeds=" + this.currentEmbeds + '}';
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\event\domain\message\MessageUpdateEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */