/*    */ package discord4j.core.event.domain;
/*    */ 
/*    */ import discord4j.common.util.Snowflake;
/*    */ import discord4j.core.GatewayDiscordClient;
/*    */ import discord4j.core.object.entity.Guild;
/*    */ import discord4j.core.object.entity.channel.TextChannel;
/*    */ import discord4j.gateway.ShardInfo;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WebhooksUpdateEvent
/*    */   extends Event
/*    */ {
/*    */   private final long guildId;
/*    */   private final long channelId;
/*    */   
/*    */   public WebhooksUpdateEvent(GatewayDiscordClient gateway, ShardInfo shardInfo, long guildId, long channelId) {
/* 41 */     super(gateway, shardInfo);
/* 42 */     this.guildId = guildId;
/* 43 */     this.channelId = channelId;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Snowflake getGuildId() {
/* 52 */     return Snowflake.of(this.guildId);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Mono<Guild> getGuild() {
/* 62 */     return getClient().getGuildById(getGuildId());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Snowflake getChannelId() {
/* 71 */     return Snowflake.of(this.channelId);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Mono<TextChannel> getChannel() {
/* 81 */     return getClient().getChannelById(getChannelId()).cast(TextChannel.class);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 86 */     return "WebhooksUpdateEvent{guildId=" + this.guildId + ", channelId=" + this.channelId + '}';
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\event\domain\WebhooksUpdateEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */