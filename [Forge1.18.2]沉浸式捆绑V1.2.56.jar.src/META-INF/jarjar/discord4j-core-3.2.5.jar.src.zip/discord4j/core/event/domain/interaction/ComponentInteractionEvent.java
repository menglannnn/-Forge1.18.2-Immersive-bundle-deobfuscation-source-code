/*     */ package discord4j.core.event.domain.interaction;
/*     */ 
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.GatewayDiscordClient;
/*     */ import discord4j.core.object.command.ApplicationCommandInteraction;
/*     */ import discord4j.core.object.command.Interaction;
/*     */ import discord4j.core.object.entity.Message;
/*     */ import discord4j.core.spec.InteractionApplicationCommandCallbackEditMono;
/*     */ import discord4j.core.spec.InteractionApplicationCommandCallbackSpec;
/*     */ import discord4j.core.spec.InteractionCallbackSpec;
/*     */ import discord4j.core.spec.InteractionCallbackSpecDeferEditMono;
/*     */ import discord4j.core.spec.legacy.LegacyInteractionApplicationCommandCallbackSpec;
/*     */ import discord4j.discordjson.json.ImmutableInteractionApplicationCommandCallbackData;
/*     */ import discord4j.discordjson.json.InteractionApplicationCommandCallbackData;
/*     */ import discord4j.gateway.ShardInfo;
/*     */ import discord4j.rest.util.AllowedMentions;
/*     */ import discord4j.rest.util.InteractionResponseType;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Supplier;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ComponentInteractionEvent
/*     */   extends DeferrableInteractionEvent
/*     */ {
/*     */   public ComponentInteractionEvent(GatewayDiscordClient gateway, ShardInfo shardInfo, Interaction interaction) {
/*  60 */     super(gateway, shardInfo, interaction);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCustomId() {
/*  70 */     return (String)getInteraction().getCommandInteraction()
/*  71 */       .flatMap(ApplicationCommandInteraction::getCustomId)
/*     */ 
/*     */ 
/*     */       
/*  75 */       .orElseThrow(IllegalStateException::new);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<Message> getMessage() {
/*  86 */     return getInteraction().getMessage();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Snowflake getMessageId() {
/*  95 */     return (Snowflake)getInteraction().getMessageId()
/*  96 */       .orElseThrow(IllegalStateException::new);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InteractionCallbackSpecDeferEditMono deferEdit() {
/* 114 */     return InteractionCallbackSpecDeferEditMono.of(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Void> deferEdit(InteractionCallbackSpec spec) {
/* 132 */     Objects.requireNonNull(spec);
/* 133 */     return Mono.defer(() -> createInteractionResponse(InteractionResponseType.DEFERRED_UPDATE_MESSAGE, spec.asRequest()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public Mono<Void> edit(Consumer<? super LegacyInteractionApplicationCommandCallbackSpec> spec) {
/* 149 */     return Mono.defer(() -> {
/*     */           LegacyInteractionApplicationCommandCallbackSpec mutatedSpec = new LegacyInteractionApplicationCommandCallbackSpec();
/*     */           Objects.requireNonNull(mutatedSpec);
/*     */           getClient().getRestClient().getRestResources().getAllowedMentions().ifPresent(mutatedSpec::setAllowedMentions);
/*     */           spec.accept(mutatedSpec);
/*     */           return createInteractionResponse(InteractionResponseType.UPDATE_MESSAGE, mutatedSpec.asRequest());
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InteractionApplicationCommandCallbackEditMono edit() {
/* 179 */     return InteractionApplicationCommandCallbackEditMono.of(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InteractionApplicationCommandCallbackEditMono edit(String content) {
/* 197 */     return edit().withContent(content);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Void> edit(InteractionApplicationCommandCallbackSpec spec) {
/* 213 */     Objects.requireNonNull(spec);
/* 214 */     return Mono.defer(() -> {
/*     */           Objects.requireNonNull(spec);
/*     */           InteractionApplicationCommandCallbackSpec actualSpec = getClient().getRestClient().getRestResources().getAllowedMentions().filter(()).map(spec::withAllowedMentions).orElse(spec);
/*     */           return createInteractionResponse(InteractionResponseType.UPDATE_MESSAGE, actualSpec.asRequest());
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Void> acknowledge() {
/* 238 */     return createInteractionResponse(InteractionResponseType.DEFERRED_UPDATE_MESSAGE, (InteractionApplicationCommandCallbackData)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Void> acknowledgeEphemeral() {
/* 253 */     ImmutableInteractionApplicationCommandCallbackData immutableInteractionApplicationCommandCallbackData = InteractionApplicationCommandCallbackData.builder().flags(Integer.valueOf(Message.Flag.EPHEMERAL.getFlag())).build();
/*     */     
/* 255 */     return createInteractionResponse(InteractionResponseType.DEFERRED_UPDATE_MESSAGE, (InteractionApplicationCommandCallbackData)immutableInteractionApplicationCommandCallbackData);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\event\domain\interaction\ComponentInteractionEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */