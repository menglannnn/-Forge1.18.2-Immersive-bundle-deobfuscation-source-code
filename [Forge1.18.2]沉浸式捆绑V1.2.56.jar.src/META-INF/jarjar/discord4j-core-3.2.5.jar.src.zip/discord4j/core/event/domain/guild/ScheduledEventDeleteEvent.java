/*    */ package discord4j.core.event.domain.guild;
/*    */ 
/*    */ import discord4j.common.util.Snowflake;
/*    */ import discord4j.core.GatewayDiscordClient;
/*    */ import discord4j.core.object.entity.Guild;
/*    */ import discord4j.core.object.entity.ScheduledEvent;
/*    */ import discord4j.gateway.ShardInfo;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ScheduledEventDeleteEvent
/*    */   extends GuildEvent
/*    */ {
/*    */   private final ScheduledEvent scheduledEvent;
/*    */   
/*    */   public ScheduledEventDeleteEvent(GatewayDiscordClient gateway, ShardInfo shardInfo, ScheduledEvent scheduledEvent) {
/* 39 */     super(gateway, shardInfo);
/* 40 */     this.scheduledEvent = scheduledEvent;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ScheduledEvent getScheduledEvent() {
/* 49 */     return this.scheduledEvent;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Snowflake getGuildId() {
/* 58 */     return this.scheduledEvent.getGuildId();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Mono<Guild> getGuild() {
/* 68 */     return getClient().getGuildById(getGuildId());
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 73 */     return "ScheduledEventDeleteEvent{scheduledEvent=" + this.scheduledEvent + "}";
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\event\domain\guild\ScheduledEventDeleteEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */