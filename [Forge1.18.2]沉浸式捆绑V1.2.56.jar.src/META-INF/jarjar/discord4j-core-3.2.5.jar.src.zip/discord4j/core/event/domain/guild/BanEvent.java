/*    */ package discord4j.core.event.domain.guild;
/*    */ 
/*    */ import discord4j.common.util.Snowflake;
/*    */ import discord4j.core.GatewayDiscordClient;
/*    */ import discord4j.core.object.entity.Guild;
/*    */ import discord4j.core.object.entity.User;
/*    */ import discord4j.gateway.ShardInfo;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BanEvent
/*    */   extends GuildEvent
/*    */ {
/*    */   private final User user;
/*    */   private final long guildId;
/*    */   
/*    */   public BanEvent(GatewayDiscordClient gateway, ShardInfo shardInfo, User user, long guildId) {
/* 39 */     super(gateway, shardInfo);
/* 40 */     this.user = user;
/* 41 */     this.guildId = guildId;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public User getUser() {
/* 50 */     return this.user;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Snowflake getGuildId() {
/* 59 */     return Snowflake.of(this.guildId);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Mono<Guild> getGuild() {
/* 69 */     return getClient().getGuildById(getGuildId());
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 74 */     return "BanEvent{user=" + this.user + ", guildId=" + this.guildId + '}';
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\event\domain\guild\BanEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */