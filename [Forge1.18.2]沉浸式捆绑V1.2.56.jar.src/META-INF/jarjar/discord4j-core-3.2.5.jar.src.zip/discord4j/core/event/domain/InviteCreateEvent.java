/*     */ package discord4j.core.event.domain;
/*     */ 
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.GatewayDiscordClient;
/*     */ import discord4j.core.object.Invite;
/*     */ import discord4j.core.object.entity.Guild;
/*     */ import discord4j.core.object.entity.User;
/*     */ import discord4j.gateway.ShardInfo;
/*     */ import java.time.Instant;
/*     */ import java.time.temporal.ChronoUnit;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InviteCreateEvent
/*     */   extends Event
/*     */ {
/*     */   @Nullable
/*     */   private final Long guildId;
/*     */   private final long channelId;
/*     */   private final String code;
/*     */   @Nullable
/*     */   private final User inviter;
/*     */   private final Instant createdAt;
/*     */   private final int uses;
/*     */   private final int maxUses;
/*     */   private final int maxAge;
/*     */   private final boolean temporary;
/*     */   
/*     */   public InviteCreateEvent(GatewayDiscordClient client, ShardInfo shardInfo, Long guildId, long channelId, String code, @Nullable User inviter, Instant createdAt, int uses, int maxUses, int maxAge, boolean temporary) {
/*  56 */     super(client, shardInfo);
/*  57 */     this.guildId = guildId;
/*  58 */     this.channelId = channelId;
/*  59 */     this.code = code;
/*  60 */     this.inviter = inviter;
/*  61 */     this.createdAt = createdAt;
/*  62 */     this.uses = uses;
/*  63 */     this.maxAge = maxAge;
/*  64 */     this.maxUses = maxUses;
/*  65 */     this.temporary = temporary;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<Snowflake> getGuildId() {
/*  74 */     return Optional.<Long>ofNullable(this.guildId).map(Snowflake::of);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Guild> getGuild() {
/*  84 */     Objects.requireNonNull(getClient()); return Mono.justOrEmpty(getGuildId()).flatMap(getClient()::getGuildById);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Snowflake getChannelId() {
/*  93 */     return Snowflake.of(this.channelId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCode() {
/* 102 */     return this.code;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<User> getInviter() {
/* 111 */     return Optional.ofNullable(this.inviter);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getUses() {
/* 120 */     return this.uses;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMaxUses() {
/* 129 */     return this.maxUses;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMaxAge() {
/* 138 */     return this.maxAge;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isTemporary() {
/* 147 */     return this.temporary;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Instant getCreation() {
/* 156 */     return this.createdAt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<Instant> getExpiration() {
/* 165 */     return (this.maxAge > 0) ? Optional.<Instant>of(getCreation().plus(this.maxAge, ChronoUnit.SECONDS)) : Optional.<Instant>empty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Invite> getInvite() {
/* 175 */     return getClient().getInvite(this.code);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 180 */     return "InviteCreateEvent{code='" + this.code + '\'' + ", guildId=" + this.guildId + ", channelId=" + this.channelId + ", inviter=" + this.inviter + ", uses=" + this.uses + ", maxUses=" + this.maxUses + ", maxAge=" + this.maxAge + ", temporary=" + this.temporary + ", createdAt='" + this.createdAt + '\'' + '}';
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\event\domain\InviteCreateEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */