/*     */ package discord4j.core.event.domain.lifecycle;
/*     */ 
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.GatewayDiscordClient;
/*     */ import discord4j.core.object.entity.User;
/*     */ import discord4j.discordjson.json.gateway.Ready;
/*     */ import discord4j.gateway.ShardInfo;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReadyEvent
/*     */   extends GatewayLifecycleEvent
/*     */ {
/*     */   private final Ready data;
/*     */   private final User self;
/*     */   private final Set<Guild> guilds;
/*     */   
/*     */   public ReadyEvent(GatewayDiscordClient gateway, ShardInfo shardInfo, Ready data, User self, Set<Guild> guilds) {
/*  44 */     super(gateway, shardInfo);
/*  45 */     this.data = data;
/*  46 */     this.self = self;
/*  47 */     this.guilds = guilds;
/*     */   }
/*     */   
/*     */   public Ready getData() {
/*  51 */     return this.data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getGatewayVersion() {
/*  60 */     return this.data.v();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public User getSelf() {
/*  69 */     return this.self;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<Guild> getGuilds() {
/*  81 */     return this.guilds;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSessionId() {
/*  90 */     return this.data.sessionId();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<String> getTrace() {
/*  99 */     return this.data.trace();
/*     */   }
/*     */ 
/*     */   
/*     */   public static class Guild
/*     */   {
/*     */     private final long id;
/*     */     
/*     */     private final boolean available;
/*     */ 
/*     */     
/*     */     public Guild(long id, boolean available) {
/* 111 */       this.id = id;
/* 112 */       this.available = available;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Snowflake getId() {
/* 121 */       return Snowflake.of(this.id);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isAvailable() {
/* 131 */       return this.available;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(@Nullable Object o) {
/* 136 */       if (this == o) {
/* 137 */         return true;
/*     */       }
/* 139 */       if (o == null || getClass() != o.getClass()) {
/* 140 */         return false;
/*     */       }
/* 142 */       Guild guild = (Guild)o;
/* 143 */       return (this.id == guild.id && this.available == guild.available);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 149 */       return Objects.hash(new Object[] { Long.valueOf(this.id), Boolean.valueOf(this.available) });
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 154 */       return "Guild{id=" + this.id + ", available=" + this.available + '}';
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 163 */     return "ReadyEvent{data=" + this.data + ", self=" + this.self + ", guilds=" + this.guilds + '}';
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\event\domain\lifecycle\ReadyEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */