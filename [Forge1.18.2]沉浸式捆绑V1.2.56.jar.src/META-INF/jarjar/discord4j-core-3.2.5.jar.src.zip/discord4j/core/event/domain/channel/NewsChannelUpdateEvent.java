/*    */ package discord4j.core.event.domain.channel;
/*    */ 
/*    */ import discord4j.core.GatewayDiscordClient;
/*    */ import discord4j.core.object.entity.channel.GuildMessageChannel;
/*    */ import discord4j.core.object.entity.channel.NewsChannel;
/*    */ import discord4j.core.object.entity.channel.TextChannel;
/*    */ import discord4j.gateway.ShardInfo;
/*    */ import java.util.Optional;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NewsChannelUpdateEvent
/*    */   extends ChannelEvent
/*    */ {
/*    */   private final GuildMessageChannel current;
/*    */   private final NewsChannel old;
/*    */   
/*    */   public NewsChannelUpdateEvent(GatewayDiscordClient gateway, ShardInfo shardInfo, GuildMessageChannel current, @Nullable NewsChannel old) {
/* 45 */     super(gateway, shardInfo);
/* 46 */     this.current = current;
/* 47 */     this.old = old;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public GuildMessageChannel getCurrent() {
/* 57 */     return this.current;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Optional<NewsChannel> getNewsChannel() {
/* 67 */     return (this.current instanceof NewsChannel) ? Optional.<NewsChannel>of((NewsChannel)this.current) : Optional.<NewsChannel>empty();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Optional<TextChannel> getTextChannel() {
/* 77 */     return (this.current instanceof TextChannel) ? Optional.<TextChannel>of((TextChannel)this.current) : Optional.<TextChannel>empty();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Optional<NewsChannel> getOld() {
/* 87 */     return Optional.ofNullable(this.old);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 92 */     return "NewsChannelUpdateEvent{current=" + this.current + ", old=" + this.old + '}';
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\event\domain\channel\NewsChannelUpdateEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */