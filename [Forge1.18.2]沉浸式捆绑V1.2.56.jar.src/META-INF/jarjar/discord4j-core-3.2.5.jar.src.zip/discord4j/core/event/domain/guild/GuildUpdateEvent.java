/*    */ package discord4j.core.event.domain.guild;
/*    */ 
/*    */ import discord4j.core.GatewayDiscordClient;
/*    */ import discord4j.core.object.entity.Guild;
/*    */ import discord4j.gateway.ShardInfo;
/*    */ import java.util.Optional;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GuildUpdateEvent
/*    */   extends GuildEvent
/*    */ {
/*    */   private final Guild current;
/*    */   private final Guild old;
/*    */   
/*    */   public GuildUpdateEvent(GatewayDiscordClient gateway, ShardInfo shardInfo, Guild current, @Nullable Guild old) {
/* 41 */     super(gateway, shardInfo);
/* 42 */     this.current = current;
/* 43 */     this.old = old;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Guild getCurrent() {
/* 52 */     return this.current;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Optional<Guild> getOld() {
/* 62 */     return Optional.ofNullable(this.old);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 67 */     return "GuildUpdateEvent{current=" + this.current + ", old=" + this.old + '}';
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\event\domain\guild\GuildUpdateEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */