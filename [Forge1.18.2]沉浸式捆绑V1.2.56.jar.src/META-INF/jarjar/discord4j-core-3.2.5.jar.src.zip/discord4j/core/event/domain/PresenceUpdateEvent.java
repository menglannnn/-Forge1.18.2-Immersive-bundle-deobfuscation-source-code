/*     */ package discord4j.core.event.domain;
/*     */ 
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.GatewayDiscordClient;
/*     */ import discord4j.core.object.entity.Guild;
/*     */ import discord4j.core.object.entity.Member;
/*     */ import discord4j.core.object.entity.User;
/*     */ import discord4j.core.object.presence.Presence;
/*     */ import discord4j.discordjson.json.PartialUserData;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import discord4j.gateway.ShardInfo;
/*     */ import java.util.Optional;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PresenceUpdateEvent
/*     */   extends Event
/*     */ {
/*     */   private final long guildId;
/*     */   private final User oldUser;
/*     */   private final PartialUserData user;
/*     */   private final Presence current;
/*     */   private final Presence old;
/*     */   
/*     */   public PresenceUpdateEvent(GatewayDiscordClient gateway, ShardInfo shardInfo, long guildId, @Nullable User oldUser, PartialUserData user, Presence current, @Nullable Presence old) {
/*  52 */     super(gateway, shardInfo);
/*  53 */     this.guildId = guildId;
/*  54 */     this.oldUser = oldUser;
/*  55 */     this.user = user;
/*  56 */     this.current = current;
/*  57 */     this.old = old;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Snowflake getGuildId() {
/*  66 */     return Snowflake.of(this.guildId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Guild> getGuild() {
/*  75 */     return getClient().getGuildById(getGuildId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<User> getOldUser() {
/*  85 */     return Optional.ofNullable(this.oldUser);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<String> getNewGlobalName() {
/*  95 */     return Possible.flatOpt(this.user.globalName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<String> getNewUsername() {
/* 105 */     return this.user.username().toOptional();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public Optional<String> getNewDiscriminator() {
/* 117 */     return this.user.discriminator().toOptional();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<String> getNewAvatar() {
/* 127 */     return Possible.flatOpt(this.user.avatar());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Snowflake getUserId() {
/* 136 */     return Snowflake.of(this.user.id());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<User> getUser() {
/* 146 */     return getClient().getUserById(getUserId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Member> getMember() {
/* 156 */     return getClient().getMemberById(getGuildId(), getUserId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Presence getCurrent() {
/* 165 */     return this.current;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<Presence> getOld() {
/* 175 */     return Optional.ofNullable(this.old);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 180 */     return "PresenceUpdateEvent{guildId=" + this.guildId + ", oldUser=" + this.oldUser + ", user=" + this.user + ", current=" + this.current + ", old=" + this.old + '}';
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\event\domain\PresenceUpdateEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */