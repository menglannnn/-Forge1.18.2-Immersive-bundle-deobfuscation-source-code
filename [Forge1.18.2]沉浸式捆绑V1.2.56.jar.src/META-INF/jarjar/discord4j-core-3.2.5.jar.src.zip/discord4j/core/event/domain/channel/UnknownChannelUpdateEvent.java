/*    */ package discord4j.core.event.domain.channel;
/*    */ 
/*    */ import discord4j.core.GatewayDiscordClient;
/*    */ import discord4j.core.object.entity.channel.UnknownChannel;
/*    */ import discord4j.gateway.ShardInfo;
/*    */ import java.util.Optional;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UnknownChannelUpdateEvent
/*    */   extends ChannelEvent
/*    */ {
/*    */   private final UnknownChannel current;
/*    */   private final UnknownChannel old;
/*    */   
/*    */   public UnknownChannelUpdateEvent(GatewayDiscordClient gateway, ShardInfo shardInfo, UnknownChannel current, @Nullable UnknownChannel old) {
/* 41 */     super(gateway, shardInfo);
/* 42 */     this.current = current;
/* 43 */     this.old = old;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public UnknownChannel getCurrent() {
/* 52 */     return this.current;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Optional<UnknownChannel> getOld() {
/* 62 */     return Optional.ofNullable(this.old);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 67 */     return "UnknownChannelUpdateEvent{current=" + this.current + ", old=" + this.old + '}';
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\event\domain\channel\UnknownChannelUpdateEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */