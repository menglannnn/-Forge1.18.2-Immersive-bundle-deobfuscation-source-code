/*    */ package discord4j.core.event.domain.role;
/*    */ 
/*    */ import discord4j.common.util.Snowflake;
/*    */ import discord4j.core.GatewayDiscordClient;
/*    */ import discord4j.core.object.entity.Guild;
/*    */ import discord4j.core.object.entity.Role;
/*    */ import discord4j.gateway.ShardInfo;
/*    */ import java.util.Optional;
/*    */ import reactor.core.publisher.Mono;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RoleDeleteEvent
/*    */   extends RoleEvent
/*    */ {
/*    */   private final long guildId;
/*    */   private final long roleId;
/*    */   @Nullable
/*    */   private final Role role;
/*    */   
/*    */   public RoleDeleteEvent(GatewayDiscordClient gateway, ShardInfo shardInfo, long guildId, long roleId, @Nullable Role role) {
/* 46 */     super(gateway, shardInfo);
/* 47 */     this.guildId = guildId;
/* 48 */     this.roleId = roleId;
/* 49 */     this.role = role;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Snowflake getGuildId() {
/* 58 */     return Snowflake.of(this.guildId);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Mono<Guild> getGuild() {
/* 69 */     return getClient().getGuildById(getGuildId());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Snowflake getRoleId() {
/* 79 */     return Snowflake.of(this.roleId);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Optional<Role> getRole() {
/* 89 */     return Optional.ofNullable(this.role);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 94 */     return "RoleDeleteEvent{guildId=" + this.guildId + ", roleId=" + this.roleId + ", role=" + this.role + '}';
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\event\domain\role\RoleDeleteEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */