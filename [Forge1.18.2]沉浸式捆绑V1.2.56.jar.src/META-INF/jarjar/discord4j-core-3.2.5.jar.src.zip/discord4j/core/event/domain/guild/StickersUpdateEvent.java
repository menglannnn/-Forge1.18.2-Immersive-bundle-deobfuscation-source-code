/*    */ package discord4j.core.event.domain.guild;
/*    */ 
/*    */ import discord4j.common.util.Snowflake;
/*    */ import discord4j.core.GatewayDiscordClient;
/*    */ import discord4j.core.object.entity.Guild;
/*    */ import discord4j.core.object.entity.GuildSticker;
/*    */ import discord4j.gateway.ShardInfo;
/*    */ import java.util.Optional;
/*    */ import java.util.Set;
/*    */ import reactor.core.publisher.Mono;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StickersUpdateEvent
/*    */   extends GuildEvent
/*    */ {
/*    */   private final long guildId;
/*    */   private final Set<GuildSticker> stickers;
/*    */   @Nullable
/*    */   private final Set<GuildSticker> old;
/*    */   
/*    */   public StickersUpdateEvent(GatewayDiscordClient gateway, ShardInfo shardInfo, long guildId, Set<GuildSticker> stickers, Set<GuildSticker> old) {
/* 46 */     super(gateway, shardInfo);
/* 47 */     this.guildId = guildId;
/* 48 */     this.stickers = stickers;
/* 49 */     this.old = old;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Snowflake getGuildId() {
/* 58 */     return Snowflake.of(this.guildId);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Mono<Guild> getGuild() {
/* 68 */     return getClient().getGuildById(getGuildId());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Set<GuildSticker> getStickers() {
/* 77 */     return this.stickers;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Optional<Set<GuildSticker>> getOld() {
/* 87 */     return Optional.ofNullable(this.old);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 92 */     return "StickersUpdateEvent{guildId=" + this.guildId + ", stickers=" + this.stickers + ", old=" + this.old + '}';
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\event\domain\guild\StickersUpdateEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */