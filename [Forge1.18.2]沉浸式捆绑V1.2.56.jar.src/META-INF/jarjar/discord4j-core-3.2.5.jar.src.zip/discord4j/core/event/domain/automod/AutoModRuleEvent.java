/*    */ package discord4j.core.event.domain.automod;
/*    */ 
/*    */ import discord4j.common.util.Snowflake;
/*    */ import discord4j.core.GatewayDiscordClient;
/*    */ import discord4j.core.event.domain.Event;
/*    */ import discord4j.core.object.automod.AutoModRule;
/*    */ import discord4j.core.object.entity.Guild;
/*    */ import discord4j.gateway.ShardInfo;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AutoModRuleEvent
/*    */   extends Event
/*    */ {
/*    */   private final AutoModRule autoModRule;
/*    */   
/*    */   protected AutoModRuleEvent(GatewayDiscordClient gateway, ShardInfo shardInfo, AutoModRule autoModRule) {
/* 19 */     super(gateway, shardInfo);
/* 20 */     this.autoModRule = autoModRule;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Snowflake getGuildId() {
/* 29 */     return this.autoModRule.getGuildId();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Mono<Guild> getGuild() {
/* 39 */     return getClient().getGuildById(getGuildId());
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\event\domain\automod\AutoModRuleEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */