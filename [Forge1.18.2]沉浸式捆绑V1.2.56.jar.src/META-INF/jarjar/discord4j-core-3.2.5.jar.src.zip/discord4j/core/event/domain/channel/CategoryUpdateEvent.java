/*    */ package discord4j.core.event.domain.channel;
/*    */ 
/*    */ import discord4j.core.GatewayDiscordClient;
/*    */ import discord4j.core.object.entity.channel.Category;
/*    */ import discord4j.gateway.ShardInfo;
/*    */ import java.util.Optional;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CategoryUpdateEvent
/*    */   extends ChannelEvent
/*    */ {
/*    */   private final Category current;
/*    */   private final Category old;
/*    */   
/*    */   public CategoryUpdateEvent(GatewayDiscordClient gateway, ShardInfo shardInfo, Category current, @Nullable Category old) {
/* 41 */     super(gateway, shardInfo);
/* 42 */     this.current = current;
/* 43 */     this.old = old;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Category getCurrent() {
/* 52 */     return this.current;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Optional<Category> getOld() {
/* 62 */     return Optional.ofNullable(this.old);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 67 */     return "CategoryUpdateEvent{current=" + this.current + ", old=" + this.old + '}';
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\event\domain\channel\CategoryUpdateEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */