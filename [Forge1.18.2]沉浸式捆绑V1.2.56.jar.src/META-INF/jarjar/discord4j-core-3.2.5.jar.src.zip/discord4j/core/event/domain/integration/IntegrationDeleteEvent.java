/*    */ package discord4j.core.event.domain.integration;
/*    */ 
/*    */ import discord4j.common.util.Snowflake;
/*    */ import discord4j.core.GatewayDiscordClient;
/*    */ import discord4j.core.event.domain.Event;
/*    */ import discord4j.gateway.ShardInfo;
/*    */ import java.util.Optional;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IntegrationDeleteEvent
/*    */   extends Event
/*    */ {
/*    */   private final long id;
/*    */   private final long guildId;
/*    */   @Nullable
/*    */   private final Long applicationId;
/*    */   
/*    */   public IntegrationDeleteEvent(GatewayDiscordClient gateway, ShardInfo shardInfo, long id, long guildId, @Nullable Long applicationId) {
/* 43 */     super(gateway, shardInfo);
/* 44 */     this.id = id;
/* 45 */     this.guildId = guildId;
/* 46 */     this.applicationId = applicationId;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Snowflake getId() {
/* 55 */     return Snowflake.of(this.id);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Snowflake getGuildId() {
/* 64 */     return Snowflake.of(this.guildId);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Optional<Snowflake> getApplicationId() {
/* 73 */     return Optional.<Long>ofNullable(this.applicationId).map(Snowflake::of);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\event\domain\integration\IntegrationDeleteEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */