/*    */ package discord4j.core.event.domain.guild;
/*    */ 
/*    */ import discord4j.common.util.Snowflake;
/*    */ import discord4j.core.GatewayDiscordClient;
/*    */ import discord4j.core.object.entity.Guild;
/*    */ import discord4j.gateway.ShardInfo;
/*    */ import java.util.Optional;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GuildDeleteEvent
/*    */   extends GuildEvent
/*    */ {
/*    */   private final long guildId;
/*    */   private final Guild guild;
/*    */   private final boolean unavailable;
/*    */   
/*    */   public GuildDeleteEvent(GatewayDiscordClient gateway, ShardInfo shardInfo, long guildId, @Nullable Guild guild, boolean unavailable) {
/* 45 */     super(gateway, shardInfo);
/* 46 */     this.guildId = guildId;
/* 47 */     this.guild = guild;
/* 48 */     this.unavailable = unavailable;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Snowflake getGuildId() {
/* 57 */     return Snowflake.of(this.guildId);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Optional<Guild> getGuild() {
/* 66 */     return Optional.ofNullable(this.guild);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isUnavailable() {
/* 75 */     return this.unavailable;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 80 */     return "GuildDeleteEvent{guildId=" + this.guildId + ", guild=" + this.guild + ", unavailable=" + this.unavailable + '}';
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\event\domain\guild\GuildDeleteEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */