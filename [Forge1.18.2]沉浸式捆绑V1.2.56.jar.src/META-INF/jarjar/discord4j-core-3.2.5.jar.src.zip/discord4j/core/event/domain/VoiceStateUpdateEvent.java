/*    */ package discord4j.core.event.domain;
/*    */ 
/*    */ import discord4j.common.util.Snowflake;
/*    */ import discord4j.core.GatewayDiscordClient;
/*    */ import discord4j.core.object.VoiceState;
/*    */ import discord4j.gateway.ShardInfo;
/*    */ import java.util.Objects;
/*    */ import java.util.Optional;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class VoiceStateUpdateEvent
/*    */   extends Event
/*    */ {
/*    */   private final VoiceState current;
/*    */   private final VoiceState old;
/*    */   
/*    */   public VoiceStateUpdateEvent(GatewayDiscordClient gateway, ShardInfo shardInfo, VoiceState current, @Nullable VoiceState old) {
/* 43 */     super(gateway, shardInfo);
/* 44 */     this.current = current;
/* 45 */     this.old = old;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public VoiceState getCurrent() {
/* 54 */     return this.current;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Optional<VoiceState> getOld() {
/* 64 */     return Optional.ofNullable(this.old);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isJoinEvent() {
/* 73 */     return (this.current.getChannelId().isPresent() && this.old == null);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isLeaveEvent() {
/* 82 */     return (!this.current.getChannelId().isPresent() && this.old != null);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isMoveEvent() {
/* 91 */     if (this.old == null) {
/* 92 */       return false;
/*    */     }
/* 94 */     return !((Boolean)this.current.getChannelId().flatMap(current -> { Objects.requireNonNull(current); return this.old.getChannelId().map(current::equals); }).orElse(Boolean.valueOf(true))).booleanValue();
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 99 */     return "VoiceStateUpdateEvent{current=" + this.current + ", old=" + this.old + '}';
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\event\domain\VoiceStateUpdateEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */