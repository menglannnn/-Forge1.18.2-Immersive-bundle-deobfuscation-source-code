/*    */ package discord4j.core.event.domain;
/*    */ 
/*    */ import discord4j.common.util.Snowflake;
/*    */ import discord4j.core.GatewayDiscordClient;
/*    */ import discord4j.core.event.domain.guild.GuildEvent;
/*    */ import discord4j.core.object.audit.AuditLogEntry;
/*    */ import discord4j.core.object.entity.Guild;
/*    */ import discord4j.gateway.ShardInfo;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AuditLogEntryCreateEvent
/*    */   extends GuildEvent
/*    */ {
/*    */   private final long guildId;
/*    */   private final AuditLogEntry auditLogEntry;
/*    */   
/*    */   public AuditLogEntryCreateEvent(GatewayDiscordClient gateway, ShardInfo shardInfo, long guildId, AuditLogEntry auditLogEntry) {
/* 24 */     super(gateway, shardInfo);
/* 25 */     this.guildId = guildId;
/* 26 */     this.auditLogEntry = auditLogEntry;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Snowflake getGuildId() {
/* 35 */     return Snowflake.of(this.guildId);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Mono<Guild> getGuild() {
/* 45 */     return getClient().getGuildById(getGuildId());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public AuditLogEntry getAuditLogEntry() {
/* 55 */     return this.auditLogEntry;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 60 */     return "AuditLogEntryCreateEvent{guildId=" + this.guildId + ", auditLogEntry=" + this.auditLogEntry + '}';
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\event\domain\AuditLogEntryCreateEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */