/*     */ package discord4j.core.event.domain.interaction;
/*     */ 
/*     */ import discord4j.common.annotations.Experimental;
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.GatewayDiscordClient;
/*     */ import discord4j.core.event.domain.Event;
/*     */ import discord4j.core.object.command.Interaction;
/*     */ import discord4j.core.object.entity.Message;
/*     */ import discord4j.discordjson.json.FollowupMessageRequest;
/*     */ import discord4j.discordjson.json.ImmutableFollowupMessageRequest;
/*     */ import discord4j.discordjson.json.ImmutableInteractionResponseData;
/*     */ import discord4j.discordjson.json.InteractionApplicationCommandCallbackData;
/*     */ import discord4j.discordjson.json.InteractionData;
/*     */ import discord4j.discordjson.json.InteractionResponseData;
/*     */ import discord4j.discordjson.json.MessageData;
/*     */ import discord4j.discordjson.json.WebhookExecuteRequest;
/*     */ import discord4j.discordjson.json.WebhookMessageEditRequest;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import discord4j.gateway.ShardInfo;
/*     */ import discord4j.rest.RestClient;
/*     */ import discord4j.rest.interaction.InteractionResponse;
/*     */ import discord4j.rest.util.InteractionResponseType;
/*     */ import discord4j.rest.util.MultipartRequest;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Experimental
/*     */ public class InteractionCreateEvent
/*     */   extends Event
/*     */ {
/*     */   private final Interaction interaction;
/*     */   
/*     */   public InteractionCreateEvent(GatewayDiscordClient gateway, ShardInfo shardInfo, Interaction interaction) {
/*  63 */     super(gateway, shardInfo);
/*  64 */     this.interaction = interaction;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Interaction getInteraction() {
/*  73 */     return this.interaction;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected Mono<Void> createInteractionResponse(InteractionResponseType responseType, @Nullable InteractionApplicationCommandCallbackData data) {
/*  82 */     ImmutableInteractionResponseData immutableInteractionResponseData = InteractionResponseData.builder().type(responseType.getValue()).data((data == null) ? Possible.absent() : Possible.of(data)).build();
/*     */     
/*  84 */     long id = this.interaction.getId().asLong();
/*  85 */     String token = this.interaction.getToken();
/*     */     
/*  87 */     return getClient().rest().getInteractionService()
/*  88 */       .createInteractionResponse(id, token, (InteractionResponseData)immutableInteractionResponseData);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Mono<Void> createInteractionResponse(InteractionResponseType responseType, MultipartRequest<InteractionApplicationCommandCallbackData> data) {
/*  96 */     ImmutableInteractionResponseData immutableInteractionResponseData = InteractionResponseData.builder().type(responseType.getValue()).data(Possible.of(data.getJsonPayload())).build();
/*     */     
/*  98 */     long id = this.interaction.getId().asLong();
/*  99 */     String token = this.interaction.getToken();
/*     */     
/* 101 */     return getClient().rest().getInteractionService()
/* 102 */       .createInteractionResponse(id, token, data.withRequest(immutableInteractionResponseData));
/*     */   }
/*     */   
/*     */   static class EventInteractionResponse
/*     */     implements InteractionResponse {
/*     */     private final RestClient restClient;
/*     */     private final InteractionData interactionData;
/*     */     private final long applicationId;
/*     */     
/*     */     EventInteractionResponse(RestClient restClient, InteractionData interactionData) {
/* 112 */       this.restClient = restClient;
/* 113 */       this.interactionData = interactionData;
/* 114 */       this.applicationId = Snowflake.asLong(interactionData.applicationId());
/*     */     }
/*     */ 
/*     */     
/*     */     public Mono<MessageData> getInitialResponse() {
/* 119 */       return this.restClient.getWebhookService()
/* 120 */         .getWebhookMessage(this.applicationId, this.interactionData.token(), "@original");
/*     */     }
/*     */ 
/*     */     
/*     */     public Mono<MessageData> editInitialResponse(WebhookMessageEditRequest request) {
/* 125 */       return this.restClient.getWebhookService()
/* 126 */         .modifyWebhookMessage(this.applicationId, this.interactionData.token(), "@original", request);
/*     */     }
/*     */ 
/*     */     
/*     */     public Mono<MessageData> editInitialResponse(MultipartRequest<WebhookMessageEditRequest> request) {
/* 131 */       return this.restClient.getWebhookService()
/* 132 */         .modifyWebhookMessage(this.applicationId, this.interactionData.token(), "@original", request);
/*     */     }
/*     */ 
/*     */     
/*     */     public Mono<Void> deleteInitialResponse() {
/* 137 */       return this.restClient.getWebhookService()
/* 138 */         .deleteWebhookMessage(this.applicationId, this.interactionData.token(), "@original");
/*     */     }
/*     */ 
/*     */     
/*     */     public Mono<MessageData> createFollowupMessage(String content) {
/* 143 */       ImmutableFollowupMessageRequest immutableFollowupMessageRequest = FollowupMessageRequest.builder().content(content).build();
/* 144 */       return this.restClient.getWebhookService()
/* 145 */         .executeWebhook(this.applicationId, this.interactionData.token(), true, MultipartRequest.ofRequest(immutableFollowupMessageRequest));
/*     */     }
/*     */ 
/*     */     
/*     */     public Mono<MessageData> createFollowupMessage(MultipartRequest<? extends WebhookExecuteRequest> request) {
/* 150 */       return this.restClient.getWebhookService()
/* 151 */         .executeWebhook(this.applicationId, this.interactionData.token(), true, request);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Mono<MessageData> createFollowupMessageEphemeral(String content) {
/* 159 */       ImmutableFollowupMessageRequest immutableFollowupMessageRequest = FollowupMessageRequest.builder().content(content).flags(Integer.valueOf(Message.Flag.EPHEMERAL.getFlag())).build();
/* 160 */       return this.restClient.getWebhookService()
/* 161 */         .executeWebhook(this.applicationId, this.interactionData.token(), true, MultipartRequest.ofRequest(immutableFollowupMessageRequest));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Mono<MessageData> createFollowupMessageEphemeral(MultipartRequest<WebhookExecuteRequest> request) {
/* 169 */       ImmutableFollowupMessageRequest immutableFollowupMessageRequest = FollowupMessageRequest.builder().from((WebhookExecuteRequest)request.getJsonPayload()).flags(Integer.valueOf(Message.Flag.EPHEMERAL.getFlag())).build();
/* 170 */       return this.restClient.getWebhookService()
/* 171 */         .executeWebhook(this.applicationId, this.interactionData.token(), true, MultipartRequest.ofRequest(immutableFollowupMessageRequest));
/*     */     }
/*     */ 
/*     */     
/*     */     public Mono<MessageData> editFollowupMessage(long messageId, WebhookMessageEditRequest request, boolean wait) {
/* 176 */       return this.restClient.getWebhookService()
/* 177 */         .modifyWebhookMessage(this.applicationId, this.interactionData.token(), String.valueOf(messageId), request);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Mono<MessageData> editFollowupMessage(long messageId, MultipartRequest<WebhookMessageEditRequest> request) {
/* 183 */       return this.restClient.getWebhookService()
/* 184 */         .modifyWebhookMessage(this.applicationId, this.interactionData.token(), String.valueOf(messageId), request);
/*     */     }
/*     */ 
/*     */     
/*     */     public Mono<Void> deleteFollowupMessage(long messageId) {
/* 189 */       return this.restClient.getWebhookService()
/* 190 */         .deleteWebhookMessage(this.applicationId, this.interactionData.token(), String.valueOf(messageId));
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\event\domain\interaction\InteractionCreateEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */