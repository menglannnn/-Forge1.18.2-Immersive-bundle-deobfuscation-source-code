/*     */ package discord4j.core.event.domain.automod;
/*     */ 
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.GatewayDiscordClient;
/*     */ import discord4j.core.event.domain.Event;
/*     */ import discord4j.core.object.automod.AutoModRule;
/*     */ import discord4j.core.object.automod.AutoModRuleAction;
/*     */ import discord4j.core.object.entity.Guild;
/*     */ import discord4j.core.object.entity.Member;
/*     */ import discord4j.core.object.entity.Message;
/*     */ import discord4j.core.object.entity.User;
/*     */ import discord4j.core.object.entity.channel.MessageChannel;
/*     */ import discord4j.discordjson.json.gateway.AutoModActionExecution;
/*     */ import discord4j.gateway.ShardInfo;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AutoModActionExecutedEvent
/*     */   extends Event
/*     */ {
/*     */   private final AutoModActionExecution data;
/*     */   private final AutoModRuleAction autoModRuleAction;
/*     */   
/*     */   public AutoModActionExecutedEvent(GatewayDiscordClient gateway, ShardInfo shardInfo, AutoModActionExecution autoModActionExecution) {
/*  32 */     super(gateway, shardInfo);
/*  33 */     this.data = autoModActionExecution;
/*  34 */     this.autoModRuleAction = new AutoModRuleAction(gateway, autoModActionExecution.action());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AutoModActionExecution getData() {
/*  43 */     return this.data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Snowflake getGuildId() {
/*  52 */     return Snowflake.of(this.data.guildId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Guild> getGuild() {
/*  62 */     return getClient().getGuildById(getGuildId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AutoModRuleAction getAction() {
/*  71 */     return this.autoModRuleAction;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Snowflake getAutoModRuleId() {
/*  80 */     return Snowflake.of(this.data.ruleId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<AutoModRule> getAutoModRule() {
/*  90 */     return getGuild().flatMap(guild -> guild.getAutoModRule(getAutoModRuleId()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AutoModRule.TriggerType getTriggerType() {
/*  99 */     return AutoModRule.TriggerType.of(this.data.ruleTriggerType());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Snowflake getUserId() {
/* 108 */     return Snowflake.of(this.data.userId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<User> getUser() {
/* 118 */     return getClient().getUserById(getUserId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Member> getMember() {
/* 128 */     return getClient().getMemberById(getGuildId(), getUserId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<Snowflake> getChannelId() {
/* 138 */     return this.data.channelId().toOptional().map(Snowflake::of);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<MessageChannel> getChannel() {
/* 149 */     Objects.requireNonNull(getClient()); return Mono.justOrEmpty(getChannelId()).flatMap(getClient()::getChannelById).cast(MessageChannel.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<Snowflake> getMessageId() {
/* 159 */     return this.data.messageId().toOptional().map(Snowflake::of);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Message> getMessage() {
/* 169 */     if (!getChannelId().isPresent() || !getMessageId().isPresent()) {
/* 170 */       return Mono.empty();
/*     */     }
/* 172 */     return getClient().getMessageById(getChannelId().get(), getMessageId().get());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<Snowflake> getSystemMessageId() {
/* 182 */     return this.data.alertSystemMessageId().toOptional().map(Snowflake::of);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getContent() {
/* 191 */     return this.data.content();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<String> getMatchedKeyword() {
/* 200 */     return this.data.matchedKeyword();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<String> getMatchedContent() {
/* 209 */     return this.data.matchedContent();
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\event\domain\automod\AutoModActionExecutedEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */