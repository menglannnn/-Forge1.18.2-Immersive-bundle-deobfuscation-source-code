/*     */ package discord4j.core.event.domain.interaction;
/*     */ 
/*     */ import discord4j.common.annotations.Experimental;
/*     */ import discord4j.core.GatewayDiscordClient;
/*     */ import discord4j.core.object.command.ApplicationCommandInteraction;
/*     */ import discord4j.core.object.command.Interaction;
/*     */ import discord4j.core.object.component.ActionRow;
/*     */ import discord4j.core.object.component.MessageComponent;
/*     */ import discord4j.core.spec.InteractionPresentModalSpec;
/*     */ import discord4j.gateway.ShardInfo;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.function.Supplier;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.stream.Stream;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Experimental
/*     */ public class ModalSubmitInteractionEvent
/*     */   extends ComponentInteractionEvent
/*     */ {
/*     */   public ModalSubmitInteractionEvent(GatewayDiscordClient gateway, ShardInfo shardInfo, Interaction interaction) {
/*  72 */     super(gateway, shardInfo, interaction);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCustomId() {
/*  85 */     return (String)getInteraction().getCommandInteraction()
/*  86 */       .flatMap(ApplicationCommandInteraction::getCustomId)
/*  87 */       .orElseThrow(IllegalStateException::new);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<MessageComponent> getComponents() {
/*  96 */     return getInteraction().getCommandInteraction()
/*  97 */       .map(ApplicationCommandInteraction::getComponents)
/*  98 */       .orElse(Collections.emptyList());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T extends MessageComponent> List<T> getComponents(Class<T> componentType) {
/* 108 */     return (List<T>)getComponents()
/* 109 */       .stream()
/* 110 */       .flatMap(it -> {
/*     */           if (it instanceof ActionRow) {
/*     */             ActionRow row = (ActionRow)it;
/*     */             
/*     */             return row.getChildren().stream();
/*     */           } 
/*     */           return Stream.empty();
/* 117 */         }).flatMap(it -> componentType.isAssignableFrom(it.getClass()) ? Stream.of(componentType.cast(it)) : Stream.empty())
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 123 */       .collect(Collectors.toList());
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> presentModal(InteractionPresentModalSpec spec) {
/* 128 */     return Mono.error(new UnsupportedOperationException("Modal submit interactions cannot present other modals"));
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\event\domain\interaction\ModalSubmitInteractionEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */