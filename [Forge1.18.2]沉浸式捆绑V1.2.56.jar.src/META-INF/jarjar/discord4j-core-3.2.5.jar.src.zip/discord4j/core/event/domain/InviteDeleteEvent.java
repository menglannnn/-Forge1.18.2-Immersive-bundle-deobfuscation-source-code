/*    */ package discord4j.core.event.domain;
/*    */ 
/*    */ import discord4j.common.util.Snowflake;
/*    */ import discord4j.core.GatewayDiscordClient;
/*    */ import discord4j.core.object.entity.Guild;
/*    */ import discord4j.gateway.ShardInfo;
/*    */ import java.util.Objects;
/*    */ import java.util.Optional;
/*    */ import reactor.core.publisher.Mono;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InviteDeleteEvent
/*    */   extends Event
/*    */ {
/*    */   @Nullable
/*    */   private final Long guildId;
/*    */   private final long channelId;
/*    */   private final String code;
/*    */   
/*    */   public InviteDeleteEvent(GatewayDiscordClient client, ShardInfo shardInfo, Long guildId, long channelId, String code) {
/* 44 */     super(client, shardInfo);
/* 45 */     this.guildId = guildId;
/* 46 */     this.channelId = channelId;
/* 47 */     this.code = code;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Optional<Snowflake> getGuildId() {
/* 56 */     return Optional.<Long>ofNullable(this.guildId).map(Snowflake::of);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Mono<Guild> getGuild() {
/* 66 */     Objects.requireNonNull(getClient()); return Mono.justOrEmpty(getGuildId()).flatMap(getClient()::getGuildById);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Snowflake getChannelId() {
/* 75 */     return Snowflake.of(this.channelId);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final String getCode() {
/* 84 */     return this.code;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 89 */     return "InviteDeleteEvent{guildId=" + this.guildId + ", channelId=" + this.channelId + ", code=" + this.code + '}';
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\event\domain\InviteDeleteEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */