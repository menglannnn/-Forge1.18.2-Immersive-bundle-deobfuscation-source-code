/*     */ package discord4j.core.event.domain.message;
/*     */ 
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.GatewayDiscordClient;
/*     */ import discord4j.core.object.entity.Guild;
/*     */ import discord4j.core.object.entity.Member;
/*     */ import discord4j.core.object.entity.Message;
/*     */ import discord4j.core.object.entity.User;
/*     */ import discord4j.core.object.entity.channel.MessageChannel;
/*     */ import discord4j.core.object.reaction.ReactionEmoji;
/*     */ import discord4j.gateway.ShardInfo;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReactionAddEvent
/*     */   extends MessageEvent
/*     */ {
/*     */   private final long userId;
/*     */   private final long channelId;
/*     */   private final long messageId;
/*     */   @Nullable
/*     */   private final Long guildId;
/*     */   private final ReactionEmoji emoji;
/*     */   @Nullable
/*     */   private final Member member;
/*     */   
/*     */   public ReactionAddEvent(GatewayDiscordClient gateway, ShardInfo shardInfo, long userId, long channelId, long messageId, @Nullable Long guildId, ReactionEmoji emoji, @Nullable Member member) {
/*  55 */     super(gateway, shardInfo);
/*  56 */     this.userId = userId;
/*  57 */     this.channelId = channelId;
/*  58 */     this.messageId = messageId;
/*  59 */     this.guildId = guildId;
/*  60 */     this.emoji = emoji;
/*  61 */     this.member = member;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Snowflake getUserId() {
/*  70 */     return Snowflake.of(this.userId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<User> getUser() {
/*  80 */     return getClient().getUserById(getUserId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Snowflake getChannelId() {
/*  89 */     return Snowflake.of(this.channelId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<MessageChannel> getChannel() {
/*  99 */     return getClient().getChannelById(getChannelId()).cast(MessageChannel.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Snowflake getMessageId() {
/* 108 */     return Snowflake.of(this.messageId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Message> getMessage() {
/* 118 */     return getClient().getMessageById(getChannelId(), getMessageId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<Snowflake> getGuildId() {
/* 128 */     return Optional.<Long>ofNullable(this.guildId).map(Snowflake::of);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Guild> getGuild() {
/* 139 */     Objects.requireNonNull(getClient()); return Mono.justOrEmpty(getGuildId()).flatMap(getClient()::getGuildById);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReactionEmoji getEmoji() {
/* 148 */     return this.emoji;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<Member> getMember() {
/* 158 */     return Optional.ofNullable(this.member);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 163 */     return "ReactionAddEvent{userId=" + this.userId + ", channelId=" + this.channelId + ", messageId=" + this.messageId + ", guildId=" + this.guildId + ", emoji=" + this.emoji + ", member=" + this.member + '}';
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\event\domain\message\ReactionAddEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */