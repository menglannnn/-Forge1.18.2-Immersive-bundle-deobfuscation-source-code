/*     */ package discord4j.core.event.domain.message;
/*     */ 
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.GatewayDiscordClient;
/*     */ import discord4j.core.object.entity.Guild;
/*     */ import discord4j.core.object.entity.Message;
/*     */ import discord4j.core.object.entity.channel.MessageChannel;
/*     */ import discord4j.core.object.reaction.ReactionEmoji;
/*     */ import discord4j.gateway.ShardInfo;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReactionRemoveEmojiEvent
/*     */   extends MessageEvent
/*     */ {
/*     */   private final long channelId;
/*     */   private final long messageId;
/*     */   @Nullable
/*     */   private final Long guildId;
/*     */   private final ReactionEmoji emoji;
/*     */   
/*     */   public ReactionRemoveEmojiEvent(GatewayDiscordClient gateway, ShardInfo shardInfo, long channelId, long messageId, @Nullable Long guildId, ReactionEmoji emoji) {
/*  51 */     super(gateway, shardInfo);
/*  52 */     this.channelId = channelId;
/*  53 */     this.messageId = messageId;
/*  54 */     this.guildId = guildId;
/*  55 */     this.emoji = emoji;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Snowflake getChannelId() {
/*  66 */     return Snowflake.of(this.channelId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<MessageChannel> getChannel() {
/*  76 */     return getClient().getChannelById(getChannelId()).cast(MessageChannel.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Snowflake getMessageId() {
/*  85 */     return Snowflake.of(this.messageId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Message> getMessage() {
/*  95 */     return getClient().getMessageById(getChannelId(), getMessageId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<Snowflake> getGuildId() {
/* 105 */     return Optional.<Long>ofNullable(this.guildId).map(Snowflake::of);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Guild> getGuild() {
/* 116 */     Objects.requireNonNull(getClient()); return Mono.justOrEmpty(getGuildId()).flatMap(getClient()::getGuildById);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReactionEmoji getEmoji() {
/* 125 */     return this.emoji;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 130 */     return "ReactionRemoveEvent{channelId=" + this.channelId + ", messageId=" + this.messageId + ", guildId=" + this.guildId + ", emoji=" + this.emoji + '}';
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\event\domain\message\ReactionRemoveEmojiEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */