/*    */ package discord4j.core.event.domain.lifecycle;
/*    */ 
/*    */ import discord4j.core.GatewayDiscordClient;
/*    */ import discord4j.gateway.ShardInfo;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ResumeEvent
/*    */   extends GatewayLifecycleEvent
/*    */ {
/*    */   private final List<String> trace;
/*    */   
/*    */   public ResumeEvent(GatewayDiscordClient gateway, ShardInfo shardInfo, List<String> trace) {
/* 36 */     super(gateway, shardInfo);
/* 37 */     this.trace = trace;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public List<String> getTrace() {
/* 46 */     return this.trace;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 51 */     return "ResumeEvent{trace=" + this.trace + "} " + super
/*    */       
/* 53 */       .toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\event\domain\lifecycle\ResumeEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */