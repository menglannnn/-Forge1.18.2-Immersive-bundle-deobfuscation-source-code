/*    */ package discord4j.core.event.domain.message;
/*    */ 
/*    */ import discord4j.common.util.Snowflake;
/*    */ import discord4j.core.GatewayDiscordClient;
/*    */ import discord4j.core.object.entity.Guild;
/*    */ import discord4j.core.object.entity.Member;
/*    */ import discord4j.core.object.entity.Message;
/*    */ import discord4j.gateway.ShardInfo;
/*    */ import java.util.Objects;
/*    */ import java.util.Optional;
/*    */ import reactor.core.publisher.Mono;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MessageCreateEvent
/*    */   extends MessageEvent
/*    */ {
/*    */   private final Message message;
/*    */   @Nullable
/*    */   private final Long guildId;
/*    */   @Nullable
/*    */   private final Member member;
/*    */   
/*    */   public MessageCreateEvent(GatewayDiscordClient gateway, ShardInfo shardInfo, Message message, @Nullable Long guildId, @Nullable Member member) {
/* 48 */     super(gateway, shardInfo);
/* 49 */     this.message = message;
/* 50 */     this.guildId = guildId;
/* 51 */     this.member = member;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Message getMessage() {
/* 60 */     return this.message;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Optional<Snowflake> getGuildId() {
/* 70 */     return Optional.<Long>ofNullable(this.guildId).map(Snowflake::of);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Mono<Guild> getGuild() {
/* 81 */     Objects.requireNonNull(getClient()); return Mono.justOrEmpty(getGuildId()).flatMap(getClient()::getGuildById);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Optional<Member> getMember() {
/* 91 */     return Optional.ofNullable(this.member);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 96 */     return "MessageCreateEvent{message=" + this.message + ", guildId=" + this.guildId + ", member=" + this.member + '}';
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\event\domain\message\MessageCreateEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */