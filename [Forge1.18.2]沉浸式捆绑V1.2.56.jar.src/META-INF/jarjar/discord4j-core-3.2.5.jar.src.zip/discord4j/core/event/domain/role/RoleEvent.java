/*    */ package discord4j.core.event.domain.role;
/*    */ 
/*    */ import discord4j.core.GatewayDiscordClient;
/*    */ import discord4j.core.event.domain.Event;
/*    */ import discord4j.gateway.ShardInfo;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class RoleEvent
/*    */   extends Event
/*    */ {
/*    */   public RoleEvent(GatewayDiscordClient gateway, ShardInfo shardInfo) {
/* 30 */     super(gateway, shardInfo);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\event\domain\role\RoleEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */