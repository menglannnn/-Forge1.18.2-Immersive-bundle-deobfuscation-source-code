/*    */ package discord4j.core.event.domain.channel;
/*    */ 
/*    */ import discord4j.core.GatewayDiscordClient;
/*    */ import discord4j.core.object.entity.channel.NewsChannel;
/*    */ import discord4j.gateway.ShardInfo;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NewsChannelCreateEvent
/*    */   extends ChannelEvent
/*    */ {
/*    */   private final NewsChannel channel;
/*    */   
/*    */   public NewsChannelCreateEvent(GatewayDiscordClient gateway, ShardInfo shardInfo, NewsChannel channel) {
/* 35 */     super(gateway, shardInfo);
/* 36 */     this.channel = channel;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public NewsChannel getChannel() {
/* 45 */     return this.channel;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 50 */     return "NewsChannelCreateEvent{channel=" + this.channel + '}';
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\event\domain\channel\NewsChannelCreateEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */