/*    */ package discord4j.core.event.domain.guild;
/*    */ 
/*    */ import discord4j.core.GatewayDiscordClient;
/*    */ import discord4j.core.object.entity.Guild;
/*    */ import discord4j.gateway.ShardInfo;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GuildCreateEvent
/*    */   extends GuildEvent
/*    */ {
/*    */   private final Guild guild;
/*    */   
/*    */   public GuildCreateEvent(GatewayDiscordClient gateway, ShardInfo shardInfo, Guild guild) {
/* 42 */     super(gateway, shardInfo);
/* 43 */     this.guild = guild;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Guild getGuild() {
/* 52 */     return this.guild;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 57 */     return "GuildCreateEvent{guild=" + this.guild + '}';
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\event\domain\guild\GuildCreateEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */