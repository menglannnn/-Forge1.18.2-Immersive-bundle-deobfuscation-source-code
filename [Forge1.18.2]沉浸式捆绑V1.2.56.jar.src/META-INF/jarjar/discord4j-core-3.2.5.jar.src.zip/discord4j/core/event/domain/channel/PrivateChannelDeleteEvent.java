/*    */ package discord4j.core.event.domain.channel;
/*    */ 
/*    */ import discord4j.core.GatewayDiscordClient;
/*    */ import discord4j.core.object.entity.channel.PrivateChannel;
/*    */ import discord4j.gateway.ShardInfo;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PrivateChannelDeleteEvent
/*    */   extends ChannelEvent
/*    */ {
/*    */   private final PrivateChannel channel;
/*    */   
/*    */   public PrivateChannelDeleteEvent(GatewayDiscordClient gateway, ShardInfo shardInfo, PrivateChannel channel) {
/* 35 */     super(gateway, shardInfo);
/* 36 */     this.channel = channel;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public PrivateChannel getChannel() {
/* 45 */     return this.channel;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 50 */     return "PrivateChannelDeleteEvent{channel=" + this.channel + '}';
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\event\domain\channel\PrivateChannelDeleteEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */