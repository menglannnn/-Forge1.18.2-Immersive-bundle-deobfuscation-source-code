/*    */ package discord4j.core.event.domain.command;
/*    */ 
/*    */ import discord4j.common.util.Snowflake;
/*    */ import discord4j.core.GatewayDiscordClient;
/*    */ import discord4j.core.object.command.ApplicationCommandGuildPermissions;
/*    */ import discord4j.core.object.command.ApplicationCommandPermission;
/*    */ import discord4j.core.object.entity.Guild;
/*    */ import discord4j.gateway.ShardInfo;
/*    */ import java.util.List;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ApplicationCommandPermissionUpdateEvent
/*    */   extends ApplicationCommandEvent
/*    */ {
/*    */   private final ApplicationCommandGuildPermissions permissions;
/*    */   
/*    */   public ApplicationCommandPermissionUpdateEvent(GatewayDiscordClient gateway, ShardInfo shardInfo, ApplicationCommandGuildPermissions permissions) {
/* 45 */     super(gateway, shardInfo);
/* 46 */     this.permissions = permissions;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Snowflake getId() {
/* 55 */     return this.permissions.getId();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Snowflake getGuildId() {
/* 64 */     return this.permissions.getGuildId();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Mono<Guild> getGuild() {
/* 75 */     return getClient().getGuildById(this.permissions.getGuildId());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Snowflake getApplicationId() {
/* 84 */     return this.permissions.getApplicationId();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public List<ApplicationCommandPermission> getPermissions() {
/* 93 */     return this.permissions.getPermissions();
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\event\domain\command\ApplicationCommandPermissionUpdateEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */