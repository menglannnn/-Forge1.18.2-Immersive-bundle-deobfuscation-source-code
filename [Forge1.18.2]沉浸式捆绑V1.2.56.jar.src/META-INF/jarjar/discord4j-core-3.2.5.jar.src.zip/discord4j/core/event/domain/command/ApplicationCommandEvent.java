/*    */ package discord4j.core.event.domain.command;
/*    */ 
/*    */ import discord4j.core.GatewayDiscordClient;
/*    */ import discord4j.core.event.domain.Event;
/*    */ import discord4j.gateway.ShardInfo;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ApplicationCommandEvent
/*    */   extends Event
/*    */ {
/*    */   public ApplicationCommandEvent(GatewayDiscordClient gateway, ShardInfo shardInfo) {
/* 30 */     super(gateway, shardInfo);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\event\domain\command\ApplicationCommandEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */