/*    */ package discord4j.core.event.domain.channel;
/*    */ 
/*    */ import discord4j.core.GatewayDiscordClient;
/*    */ import discord4j.core.object.entity.channel.StoreChannel;
/*    */ import discord4j.gateway.ShardInfo;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StoreChannelDeleteEvent
/*    */   extends ChannelEvent
/*    */ {
/*    */   private final StoreChannel channel;
/*    */   
/*    */   public StoreChannelDeleteEvent(GatewayDiscordClient gateway, ShardInfo shardInfo, StoreChannel channel) {
/* 35 */     super(gateway, shardInfo);
/* 36 */     this.channel = channel;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public StoreChannel getChannel() {
/* 45 */     return this.channel;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 50 */     return "StoreChannelDeleteEvent{channel=" + this.channel + '}';
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\event\domain\channel\StoreChannelDeleteEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */