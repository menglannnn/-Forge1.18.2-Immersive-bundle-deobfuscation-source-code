/*     */ package discord4j.core.event.domain.message;
/*     */ 
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.GatewayDiscordClient;
/*     */ import discord4j.core.object.entity.Guild;
/*     */ import discord4j.core.object.entity.Message;
/*     */ import discord4j.core.object.entity.channel.TextChannel;
/*     */ import discord4j.gateway.ShardInfo;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.stream.Collectors;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MessageBulkDeleteEvent
/*     */   extends MessageEvent
/*     */ {
/*     */   private final List<Long> messageIds;
/*     */   private final long channelId;
/*     */   private final long guildId;
/*     */   private final Set<Message> messages;
/*     */   
/*     */   public MessageBulkDeleteEvent(GatewayDiscordClient gateway, ShardInfo shardInfo, List<Long> messageIds, long channelId, long guildId, Set<Message> messages) {
/*  50 */     super(gateway, shardInfo);
/*  51 */     this.messageIds = messageIds;
/*  52 */     this.channelId = channelId;
/*  53 */     this.guildId = guildId;
/*  54 */     this.messages = messages;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<Snowflake> getMessageIds() {
/*  63 */     return (Set<Snowflake>)this.messageIds.stream()
/*  64 */       .map(Snowflake::of)
/*  65 */       .collect(Collectors.toSet());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<Message> getMessages() {
/*  74 */     return this.messages;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Snowflake getChannelId() {
/*  83 */     return Snowflake.of(this.channelId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<TextChannel> getChannel() {
/*  94 */     return getClient().getChannelById(getChannelId()).cast(TextChannel.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Snowflake getGuildId() {
/* 103 */     return Snowflake.of(this.guildId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Guild> getGuild() {
/* 113 */     return getClient().getGuildById(getGuildId());
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 118 */     return "MessageBulkDeleteEvent{messageIds=" + this.messageIds + ", channelId=" + this.channelId + ", guildId=" + this.guildId + ", messages=" + this.messages + '}';
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\event\domain\message\MessageBulkDeleteEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */