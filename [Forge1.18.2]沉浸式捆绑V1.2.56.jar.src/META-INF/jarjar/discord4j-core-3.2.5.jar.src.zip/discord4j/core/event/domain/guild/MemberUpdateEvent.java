/*     */ package discord4j.core.event.domain.guild;
/*     */ 
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.GatewayDiscordClient;
/*     */ import discord4j.core.object.entity.Guild;
/*     */ import discord4j.core.object.entity.Member;
/*     */ import discord4j.core.object.entity.Role;
/*     */ import discord4j.core.util.ImageUtil;
/*     */ import discord4j.gateway.ShardInfo;
/*     */ import discord4j.rest.util.Image;
/*     */ import java.time.Instant;
/*     */ import java.time.format.DateTimeFormatter;
/*     */ import java.util.Optional;
/*     */ import java.util.Set;
/*     */ import java.util.stream.Collectors;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MemberUpdateEvent
/*     */   extends GuildEvent
/*     */ {
/*     */   private static final String AVATAR_IMAGE_PATH = "guilds/%s/users/%s/avatars/%s";
/*     */   private final long guildId;
/*     */   private final long memberId;
/*     */   @Nullable
/*     */   private final Member old;
/*     */   private final Set<Long> currentRoleIds;
/*     */   @Nullable
/*     */   private final String currentNickname;
/*     */   @Nullable
/*     */   private final String currentAvatar;
/*     */   @Nullable
/*     */   private final String currentJoinedAt;
/*     */   @Nullable
/*     */   private final String currentPremiumSince;
/*     */   @Nullable
/*     */   private final Boolean currentPending;
/*     */   @Nullable
/*     */   private final String communicationDisabledUntil;
/*     */   
/*     */   public MemberUpdateEvent(GatewayDiscordClient gateway, ShardInfo shardInfo, long guildId, long memberId, @Nullable Member old, Set<Long> currentRoleIds, @Nullable String currentNickname, @Nullable String currentAvatar, @Nullable String currentJoinedAt, @Nullable String currentPremiumSince, @Nullable Boolean currentPending, @Nullable String communicationDisabledUntil) {
/*  73 */     super(gateway, shardInfo);
/*     */     
/*  75 */     this.guildId = guildId;
/*  76 */     this.memberId = memberId;
/*  77 */     this.old = old;
/*  78 */     this.currentRoleIds = currentRoleIds;
/*  79 */     this.currentNickname = currentNickname;
/*  80 */     this.currentAvatar = currentAvatar;
/*  81 */     this.currentJoinedAt = currentJoinedAt;
/*  82 */     this.currentPremiumSince = currentPremiumSince;
/*  83 */     this.currentPending = currentPending;
/*  84 */     this.communicationDisabledUntil = communicationDisabledUntil;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Snowflake getGuildId() {
/*  93 */     return Snowflake.of(this.guildId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Guild> getGuild() {
/* 103 */     return getClient().getGuildById(getGuildId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Snowflake getMemberId() {
/* 112 */     return Snowflake.of(this.memberId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Member> getMember() {
/* 122 */     return getClient().getMemberById(getGuildId(), getMemberId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<Member> getOld() {
/* 132 */     return Optional.ofNullable(this.old);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<Snowflake> getCurrentRoleIds() {
/* 141 */     return (Set<Snowflake>)this.currentRoleIds.stream()
/* 142 */       .map(Snowflake::of)
/* 143 */       .collect(Collectors.toSet());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Flux<Role> getCurrentRoles() {
/* 152 */     return getClient().getGuildRoles(getGuildId())
/* 153 */       .filter(role -> this.currentRoleIds.contains(Long.valueOf(role.getId().asLong())));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<String> getCurrentNickname() {
/* 162 */     return Optional.ofNullable(this.currentNickname);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<String> getCurrentGuildAvatarUrl(Image.Format format) {
/* 172 */     return Optional.<String>ofNullable(this.currentAvatar)
/* 173 */       .map(avatar -> ImageUtil.getUrl(String.format("guilds/%s/users/%s/avatars/%s", new Object[] { Long.valueOf(this.guildId), Snowflake.asString(this.memberId), avatar }), format));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Image> getCurrentGuildAvatar(Image.Format format) {
/* 186 */     return Mono.justOrEmpty(getCurrentGuildAvatarUrl(format)).flatMap(Image::ofUrl);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<Instant> getJoinTime() {
/* 196 */     return Optional.<String>ofNullable(this.currentJoinedAt)
/* 197 */       .map(it -> (Instant)DateTimeFormatter.ISO_OFFSET_DATE_TIME.<Instant>parse(it, Instant::from));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<Instant> getCurrentPremiumSince() {
/* 206 */     return Optional.<String>ofNullable(this.currentPremiumSince)
/* 207 */       .map(timestamp -> (Instant)DateTimeFormatter.ISO_OFFSET_DATE_TIME.<Instant>parse(timestamp, Instant::from));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isCurrentPending() {
/* 216 */     return ((Boolean)Optional.<Boolean>ofNullable(this.currentPending).orElse(Boolean.valueOf(false))).booleanValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<Instant> getCommunicationDisabledUntil() {
/* 225 */     return Optional.<String>ofNullable(this.communicationDisabledUntil)
/* 226 */       .map(timestamp -> (Instant)DateTimeFormatter.ISO_OFFSET_DATE_TIME.<Instant>parse(timestamp, Instant::from));
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 231 */     return "MemberUpdateEvent{guildId=" + this.guildId + ", memberId=" + this.memberId + ", old=" + this.old + ", currentRoleIds=" + this.currentRoleIds + ", currentNickname='" + this.currentNickname + '\'' + ", currentAvatar='" + this.currentAvatar + '\'' + ", currentJoinedAt='" + this.currentJoinedAt + '\'' + ", currentPremiumSince='" + this.currentPremiumSince + '\'' + ", currentPending=" + this.currentPending + ", communicationDisabledUntil='" + this.communicationDisabledUntil + '\'' + '}';
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\event\domain\guild\MemberUpdateEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */