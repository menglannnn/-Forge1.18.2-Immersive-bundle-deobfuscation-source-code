/*     */ package discord4j.core.event.domain.channel;
/*     */ 
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.GatewayDiscordClient;
/*     */ import discord4j.core.object.entity.Member;
/*     */ import discord4j.core.object.entity.User;
/*     */ import discord4j.core.object.entity.channel.MessageChannel;
/*     */ import discord4j.gateway.ShardInfo;
/*     */ import java.time.Instant;
/*     */ import java.util.Optional;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TypingStartEvent
/*     */   extends ChannelEvent
/*     */ {
/*     */   private final long channelId;
/*     */   @Nullable
/*     */   private final Long guildId;
/*     */   private final long userId;
/*     */   private final Instant startTime;
/*     */   @Nullable
/*     */   private final Member member;
/*     */   
/*     */   public TypingStartEvent(GatewayDiscordClient gateway, ShardInfo shardInfo, long channelId, @Nullable Long guildId, long userId, Instant startTime, @Nullable Member member) {
/*  51 */     super(gateway, shardInfo);
/*  52 */     this.channelId = channelId;
/*  53 */     this.guildId = guildId;
/*  54 */     this.userId = userId;
/*  55 */     this.startTime = startTime;
/*  56 */     this.member = member;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Snowflake getChannelId() {
/*  65 */     return Snowflake.of(this.channelId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<Snowflake> getGuildId() {
/*  74 */     return Optional.<Long>ofNullable(this.guildId).map(Snowflake::of);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<MessageChannel> getChannel() {
/*  84 */     return getClient().getChannelById(getChannelId()).cast(MessageChannel.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Snowflake getUserId() {
/*  93 */     return Snowflake.of(this.userId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<User> getUser() {
/* 103 */     return getClient().getUserById(getUserId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Instant getStartTime() {
/* 112 */     return this.startTime;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<Member> getMember() {
/* 121 */     return Optional.ofNullable(this.member);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 126 */     return "TypingStartEvent{channelId=" + this.channelId + ", guildId=" + this.guildId + ", userId=" + this.userId + ", startTime=" + this.startTime + ", member=" + this.member + '}';
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\event\domain\channel\TypingStartEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */