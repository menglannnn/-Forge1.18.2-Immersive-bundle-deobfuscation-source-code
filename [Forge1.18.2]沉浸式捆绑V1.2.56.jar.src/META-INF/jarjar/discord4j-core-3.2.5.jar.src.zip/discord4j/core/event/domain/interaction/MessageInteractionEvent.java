/*     */ package discord4j.core.event.domain.interaction;
/*     */ 
/*     */ import discord4j.common.annotations.Experimental;
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.GatewayDiscordClient;
/*     */ import discord4j.core.object.command.ApplicationCommandInteraction;
/*     */ import discord4j.core.object.command.ApplicationCommandInteractionResolved;
/*     */ import discord4j.core.object.command.Interaction;
/*     */ import discord4j.core.object.entity.Message;
/*     */ import discord4j.core.retriever.EntityRetrievalStrategy;
/*     */ import discord4j.gateway.ShardInfo;
/*     */ import java.util.Optional;
/*     */ import java.util.function.Supplier;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Experimental
/*     */ public class MessageInteractionEvent
/*     */   extends ApplicationCommandInteractionEvent
/*     */ {
/*     */   public MessageInteractionEvent(GatewayDiscordClient gateway, ShardInfo shardInfo, Interaction interaction) {
/*  53 */     super(gateway, shardInfo, interaction);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Message getResolvedMessage() {
/*  66 */     return (Message)getInteraction().getCommandInteraction()
/*  67 */       .flatMap(ApplicationCommandInteraction::getResolved)
/*  68 */       .flatMap(it -> it.getMessage(getTargetId()))
/*  69 */       .orElseThrow(IllegalStateException::new);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Snowflake getTargetId() {
/*  78 */     return (Snowflake)getInteraction().getCommandInteraction()
/*  79 */       .flatMap(ApplicationCommandInteraction::getTargetId)
/*  80 */       .orElseThrow(IllegalStateException::new);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Message> getTargetMessage() {
/*  90 */     return getClient().getMessageById(getInteraction().getChannelId(), getTargetId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Message> getTargetMessage(EntityRetrievalStrategy retrievalStrategy) {
/* 101 */     return getClient().withRetrievalStrategy(retrievalStrategy)
/* 102 */       .getMessageById(getInteraction().getChannelId(), getTargetId());
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\event\domain\interaction\MessageInteractionEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */