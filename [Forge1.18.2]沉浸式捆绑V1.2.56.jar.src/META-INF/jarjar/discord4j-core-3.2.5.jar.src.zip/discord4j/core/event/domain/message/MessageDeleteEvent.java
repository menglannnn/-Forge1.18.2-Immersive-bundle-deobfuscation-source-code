/*     */ package discord4j.core.event.domain.message;
/*     */ 
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.GatewayDiscordClient;
/*     */ import discord4j.core.object.entity.Guild;
/*     */ import discord4j.core.object.entity.Message;
/*     */ import discord4j.core.object.entity.channel.MessageChannel;
/*     */ import discord4j.gateway.ShardInfo;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MessageDeleteEvent
/*     */   extends MessageEvent
/*     */ {
/*     */   private final long messageId;
/*     */   private final long channelId;
/*     */   @Nullable
/*     */   private final Long guildId;
/*     */   @Nullable
/*     */   private final Message message;
/*     */   
/*     */   public MessageDeleteEvent(GatewayDiscordClient gateway, ShardInfo shardInfo, long messageId, long channelId, @Nullable Long guildId, @Nullable Message message) {
/*  49 */     super(gateway, shardInfo);
/*  50 */     this.messageId = messageId;
/*  51 */     this.channelId = channelId;
/*  52 */     this.guildId = guildId;
/*  53 */     this.message = message;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Snowflake getMessageId() {
/*  62 */     return Snowflake.of(this.messageId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<Message> getMessage() {
/*  72 */     return Optional.ofNullable(this.message);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Snowflake getChannelId() {
/*  81 */     return Snowflake.of(this.channelId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<MessageChannel> getChannel() {
/*  91 */     return getClient().getChannelById(getChannelId()).cast(MessageChannel.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<Snowflake> getGuildId() {
/* 102 */     return Optional.<Long>ofNullable(this.guildId).map(Snowflake::of);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Guild> getGuild() {
/* 114 */     Objects.requireNonNull(getClient()); return Mono.justOrEmpty(getGuildId()).flatMap(getClient()::getGuildById);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 119 */     return "MessageDeleteEvent{messageId=" + this.messageId + ", channelId=" + this.channelId + ", message=" + this.message + '}';
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\event\domain\message\MessageDeleteEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */