/*    */ package discord4j.core.event.domain.automod;
/*    */ 
/*    */ import discord4j.core.GatewayDiscordClient;
/*    */ import discord4j.core.object.automod.AutoModRule;
/*    */ import discord4j.gateway.ShardInfo;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AutoModRuleCreateEvent
/*    */   extends AutoModRuleEvent
/*    */ {
/*    */   public AutoModRuleCreateEvent(GatewayDiscordClient gateway, ShardInfo shardInfo, AutoModRule autoModRule) {
/* 17 */     super(gateway, shardInfo, autoModRule);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\event\domain\automod\AutoModRuleCreateEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */