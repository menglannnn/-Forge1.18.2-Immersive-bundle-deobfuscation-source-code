/*    */ package discord4j.core.event.domain.channel;
/*    */ 
/*    */ import discord4j.core.GatewayDiscordClient;
/*    */ import discord4j.core.object.entity.channel.Category;
/*    */ import discord4j.gateway.ShardInfo;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CategoryDeleteEvent
/*    */   extends ChannelEvent
/*    */ {
/*    */   private final Category category;
/*    */   
/*    */   public CategoryDeleteEvent(GatewayDiscordClient gateway, ShardInfo shardInfo, Category category) {
/* 35 */     super(gateway, shardInfo);
/* 36 */     this.category = category;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Category getCategory() {
/* 45 */     return this.category;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 50 */     return "CategoryDeleteEvent{category=" + this.category + '}';
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\event\domain\channel\CategoryDeleteEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */