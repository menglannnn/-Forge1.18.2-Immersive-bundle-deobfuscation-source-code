/*    */ package discord4j.core.event.domain.lifecycle;
/*    */ 
/*    */ import discord4j.core.GatewayDiscordClient;
/*    */ import discord4j.gateway.ShardInfo;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ReconnectEvent
/*    */   extends GatewayLifecycleEvent
/*    */ {
/*    */   private final long currentAttempt;
/*    */   
/*    */   public ReconnectEvent(GatewayDiscordClient gateway, ShardInfo shardInfo, long currentAttempt) {
/* 33 */     super(gateway, shardInfo);
/* 34 */     this.currentAttempt = currentAttempt;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public long getCurrentAttempt() {
/* 43 */     return this.currentAttempt;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 48 */     return "Gateway successfully reconnected";
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\event\domain\lifecycle\ReconnectEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */