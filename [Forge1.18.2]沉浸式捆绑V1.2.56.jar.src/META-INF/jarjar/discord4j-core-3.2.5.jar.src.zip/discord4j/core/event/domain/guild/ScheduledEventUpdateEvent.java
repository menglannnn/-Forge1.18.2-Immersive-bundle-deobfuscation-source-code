/*    */ package discord4j.core.event.domain.guild;
/*    */ 
/*    */ import discord4j.common.util.Snowflake;
/*    */ import discord4j.core.GatewayDiscordClient;
/*    */ import discord4j.core.object.entity.Guild;
/*    */ import discord4j.core.object.entity.ScheduledEvent;
/*    */ import discord4j.gateway.ShardInfo;
/*    */ import java.util.Optional;
/*    */ import reactor.core.publisher.Mono;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ScheduledEventUpdateEvent
/*    */   extends GuildEvent
/*    */ {
/*    */   private final ScheduledEvent current;
/*    */   @Nullable
/*    */   private final ScheduledEvent old;
/*    */   
/*    */   public ScheduledEventUpdateEvent(GatewayDiscordClient gateway, ShardInfo shardInfo, ScheduledEvent current, @Nullable ScheduledEvent old) {
/* 38 */     super(gateway, shardInfo);
/* 39 */     this.current = current;
/* 40 */     this.old = old;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ScheduledEvent getCurrent() {
/* 49 */     return this.current;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Optional<ScheduledEvent> getOld() {
/* 59 */     return Optional.ofNullable(this.old);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Snowflake getGuildId() {
/* 68 */     return this.current.getGuildId();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Mono<Guild> getGuild() {
/* 78 */     return getClient().getGuildById(getGuildId());
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 83 */     return "ScheduledEventUpdateEvent{current=" + this.current + ", old=" + this.old + "}";
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\event\domain\guild\ScheduledEventUpdateEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */