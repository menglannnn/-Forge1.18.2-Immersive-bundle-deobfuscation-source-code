/*    */ package discord4j.core.event.domain.interaction;
/*    */ 
/*    */ import discord4j.common.annotations.Experimental;
/*    */ import discord4j.core.GatewayDiscordClient;
/*    */ import discord4j.core.object.command.ApplicationCommandInteraction;
/*    */ import discord4j.core.object.command.ApplicationCommandInteractionOption;
/*    */ import discord4j.core.object.command.Interaction;
/*    */ import discord4j.gateway.ShardInfo;
/*    */ import java.util.List;
/*    */ import java.util.Optional;
/*    */ import java.util.function.Supplier;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Experimental
/*    */ public class ChatInputInteractionEvent
/*    */   extends ApplicationCommandInteractionEvent
/*    */ {
/*    */   public ChatInputInteractionEvent(GatewayDiscordClient gateway, ShardInfo shardInfo, Interaction interaction) {
/* 51 */     super(gateway, shardInfo, interaction);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public List<ApplicationCommandInteractionOption> getOptions() {
/* 64 */     return ((ApplicationCommandInteraction)getInteraction().getCommandInteraction()
/* 65 */       .orElseThrow(IllegalStateException::new))
/* 66 */       .getOptions();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Optional<ApplicationCommandInteractionOption> getOption(String name) {
/* 76 */     return ((ApplicationCommandInteraction)getInteraction().getCommandInteraction()
/* 77 */       .orElseThrow(IllegalStateException::new))
/* 78 */       .getOption(name);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\event\domain\interaction\ChatInputInteractionEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */