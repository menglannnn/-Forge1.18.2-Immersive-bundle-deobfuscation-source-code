/*    */ package discord4j.core.event.domain.lifecycle;
/*    */ 
/*    */ import discord4j.common.close.CloseStatus;
/*    */ import discord4j.core.GatewayDiscordClient;
/*    */ import discord4j.gateway.ShardInfo;
/*    */ import java.util.Optional;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DisconnectEvent
/*    */   extends GatewayLifecycleEvent
/*    */ {
/*    */   private final CloseStatus status;
/*    */   @Nullable
/*    */   private final Throwable cause;
/*    */   
/*    */   public DisconnectEvent(GatewayDiscordClient gateway, ShardInfo shardInfo, CloseStatus status, @Nullable Throwable cause) {
/* 38 */     super(gateway, shardInfo);
/* 39 */     this.status = status;
/* 40 */     this.cause = cause;
/*    */   }
/*    */   
/*    */   public CloseStatus getStatus() {
/* 44 */     return this.status;
/*    */   }
/*    */   
/*    */   public Optional<Throwable> getCause() {
/* 48 */     return Optional.ofNullable(this.cause);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 53 */     return "Gateway connection terminated";
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\event\domain\lifecycle\DisconnectEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */