/*     */ package discord4j.core.event.domain.guild;
/*     */ 
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.GatewayDiscordClient;
/*     */ import discord4j.core.object.entity.Guild;
/*     */ import discord4j.core.object.entity.Member;
/*     */ import discord4j.core.object.entity.ScheduledEvent;
/*     */ import discord4j.core.object.entity.User;
/*     */ import discord4j.gateway.ShardInfo;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ScheduledEventUserRemoveEvent
/*     */   extends GuildEvent
/*     */ {
/*     */   private final long guildId;
/*     */   private final long scheduledEventId;
/*     */   private final long userId;
/*     */   
/*     */   public ScheduledEventUserRemoveEvent(GatewayDiscordClient gateway, ShardInfo shardInfo, long guildId, long scheduledEventId, long userId) {
/*  44 */     super(gateway, shardInfo);
/*  45 */     this.guildId = guildId;
/*  46 */     this.scheduledEventId = scheduledEventId;
/*  47 */     this.userId = userId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Snowflake getGuildId() {
/*  56 */     return Snowflake.of(this.guildId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Guild> getGuild() {
/*  66 */     return getClient().getGuildById(getGuildId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Snowflake getScheduledEventId() {
/*  75 */     return Snowflake.of(this.scheduledEventId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<ScheduledEvent> getScheduledEvent() {
/*  85 */     return getClient().getScheduledEventById(getGuildId(), getScheduledEventId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Snowflake getUserId() {
/*  94 */     return Snowflake.of(this.userId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<User> getUser() {
/* 104 */     return getClient().getUserById(getUserId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Member> getMember() {
/* 114 */     return getClient().getMemberById(getGuildId(), getUserId());
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 119 */     return "ScheduledEventUserRemoveEvent{guildId=" + this.guildId + ", scheduledEventId=" + this.scheduledEventId + ", userId=" + this.userId + "}";
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\event\domain\guild\ScheduledEventUserRemoveEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */