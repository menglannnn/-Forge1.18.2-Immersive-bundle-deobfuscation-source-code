/*    */ package discord4j.core.event.domain.guild;
/*    */ 
/*    */ import discord4j.common.util.Snowflake;
/*    */ import discord4j.core.GatewayDiscordClient;
/*    */ import discord4j.core.object.entity.Guild;
/*    */ import discord4j.core.object.entity.Member;
/*    */ import discord4j.core.object.entity.User;
/*    */ import discord4j.gateway.ShardInfo;
/*    */ import java.util.Optional;
/*    */ import reactor.core.publisher.Mono;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MemberLeaveEvent
/*    */   extends GuildEvent
/*    */ {
/*    */   private final User user;
/*    */   private final long guildId;
/*    */   @Nullable
/*    */   private final Member member;
/*    */   
/*    */   public MemberLeaveEvent(GatewayDiscordClient gateway, ShardInfo shardInfo, User user, long guildId, @Nullable Member member) {
/* 48 */     super(gateway, shardInfo);
/* 49 */     this.user = user;
/* 50 */     this.guildId = guildId;
/* 51 */     this.member = member;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public User getUser() {
/* 60 */     return this.user;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Snowflake getGuildId() {
/* 69 */     return Snowflake.of(this.guildId);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Mono<Guild> getGuild() {
/* 79 */     return getClient().getGuildById(getGuildId());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Optional<Member> getMember() {
/* 88 */     return Optional.ofNullable(this.member);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 93 */     return "MemberLeaveEvent{user=" + this.user + ", guildId=" + this.guildId + '}';
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\event\domain\guild\MemberLeaveEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */