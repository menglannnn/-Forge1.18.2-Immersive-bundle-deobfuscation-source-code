/*    */ package discord4j.core.event.domain.interaction;
/*    */ 
/*    */ import discord4j.common.annotations.Experimental;
/*    */ import discord4j.common.util.Snowflake;
/*    */ import discord4j.core.GatewayDiscordClient;
/*    */ import discord4j.core.object.command.ApplicationCommand;
/*    */ import discord4j.core.object.command.ApplicationCommandInteraction;
/*    */ import discord4j.core.object.command.Interaction;
/*    */ import discord4j.gateway.ShardInfo;
/*    */ import java.util.function.Supplier;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Experimental
/*    */ public class ApplicationCommandInteractionEvent
/*    */   extends DeferrableInteractionEvent
/*    */ {
/*    */   public ApplicationCommandInteractionEvent(GatewayDiscordClient gateway, ShardInfo shardInfo, Interaction interaction) {
/* 51 */     super(gateway, shardInfo, interaction);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Snowflake getCommandId() {
/* 64 */     return (Snowflake)getInteraction().getCommandInteraction()
/* 65 */       .flatMap(ApplicationCommandInteraction::getId)
/* 66 */       .orElseThrow(IllegalStateException::new);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getCommandName() {
/* 75 */     return (String)getInteraction().getCommandInteraction()
/* 76 */       .flatMap(ApplicationCommandInteraction::getName)
/* 77 */       .orElseThrow(IllegalStateException::new);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ApplicationCommand.Type getCommandType() {
/* 86 */     return (ApplicationCommand.Type)getInteraction().getCommandInteraction()
/* 87 */       .flatMap(ApplicationCommandInteraction::getApplicationCommandType)
/* 88 */       .orElseThrow(IllegalStateException::new);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\event\domain\interaction\ApplicationCommandInteractionEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */