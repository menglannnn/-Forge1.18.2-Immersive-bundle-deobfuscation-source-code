/*    */ package discord4j.core.event.domain.lifecycle;
/*    */ 
/*    */ import discord4j.core.GatewayDiscordClient;
/*    */ import discord4j.gateway.ShardInfo;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ReconnectFailEvent
/*    */   extends GatewayLifecycleEvent
/*    */ {
/*    */   private final long currentAttempt;
/*    */   
/*    */   public ReconnectFailEvent(GatewayDiscordClient gateway, ShardInfo shardInfo, long currentAttempt) {
/* 34 */     super(gateway, shardInfo);
/* 35 */     this.currentAttempt = currentAttempt;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public long getCurrentAttempt() {
/* 44 */     return this.currentAttempt;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 49 */     return "Gateway reconnect attempt failed";
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\event\domain\lifecycle\ReconnectFailEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */