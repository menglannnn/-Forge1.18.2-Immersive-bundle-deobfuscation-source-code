/*    */ package discord4j.core.event.domain;
/*    */ 
/*    */ import discord4j.common.util.Snowflake;
/*    */ import discord4j.core.GatewayDiscordClient;
/*    */ import discord4j.core.object.entity.Guild;
/*    */ import discord4j.gateway.ShardInfo;
/*    */ import reactor.core.publisher.Mono;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class VoiceServerUpdateEvent
/*    */   extends Event
/*    */ {
/*    */   private final String token;
/*    */   private final long guildId;
/*    */   @Nullable
/*    */   private final String endpoint;
/*    */   
/*    */   public VoiceServerUpdateEvent(GatewayDiscordClient gateway, ShardInfo shardInfo, String token, long guildId, @Nullable String endpoint) {
/* 42 */     super(gateway, shardInfo);
/* 43 */     this.token = token;
/* 44 */     this.guildId = guildId;
/* 45 */     this.endpoint = endpoint;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getToken() {
/* 54 */     return this.token;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Snowflake getGuildId() {
/* 63 */     return Snowflake.of(this.guildId);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Mono<Guild> getGuild() {
/* 74 */     return getClient().getGuildById(getGuildId());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public String getEndpoint() {
/* 84 */     return this.endpoint;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 89 */     return "VoiceServerUpdateEvent{token='" + this.token + '\'' + ", guildId=" + this.guildId + ", endpoint='" + this.endpoint + '\'' + '}';
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\event\domain\VoiceServerUpdateEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */