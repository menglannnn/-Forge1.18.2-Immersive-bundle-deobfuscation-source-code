/*     */ package discord4j.core.event.domain.interaction;
/*     */ 
/*     */ import discord4j.common.annotations.Experimental;
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.GatewayDiscordClient;
/*     */ import discord4j.core.object.command.ApplicationCommand;
/*     */ import discord4j.core.object.command.ApplicationCommandInteraction;
/*     */ import discord4j.core.object.command.ApplicationCommandInteractionOption;
/*     */ import discord4j.core.object.command.Interaction;
/*     */ import discord4j.discordjson.json.ApplicationCommandOptionChoiceData;
/*     */ import discord4j.discordjson.json.ImmutableInteractionApplicationCommandCallbackData;
/*     */ import discord4j.discordjson.json.InteractionApplicationCommandCallbackData;
/*     */ import discord4j.gateway.ShardInfo;
/*     */ import discord4j.rest.util.InteractionResponseType;
/*     */ import java.util.List;
/*     */ import java.util.Optional;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Supplier;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Experimental
/*     */ public class ChatInputAutoCompleteEvent
/*     */   extends AutoCompleteInteractionEvent
/*     */ {
/*     */   public ChatInputAutoCompleteEvent(GatewayDiscordClient gateway, ShardInfo shardInfo, Interaction interaction) {
/*  53 */     super(gateway, shardInfo, interaction);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Void> respondWithSuggestions(Iterable<ApplicationCommandOptionChoiceData> choices) {
/*  66 */     ImmutableInteractionApplicationCommandCallbackData immutableInteractionApplicationCommandCallbackData = InteractionApplicationCommandCallbackData.builder().choices(choices).build();
/*     */     
/*  68 */     return createInteractionResponse(InteractionResponseType.APPLICATION_COMMAND_AUTOCOMPLETE_RESULT, (InteractionApplicationCommandCallbackData)immutableInteractionApplicationCommandCallbackData);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Snowflake getCommandId() {
/*  81 */     return (Snowflake)getInteraction().getCommandInteraction()
/*  82 */       .flatMap(ApplicationCommandInteraction::getId)
/*  83 */       .orElseThrow(IllegalStateException::new);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCommandName() {
/*  92 */     return (String)getInteraction().getCommandInteraction()
/*  93 */       .flatMap(ApplicationCommandInteraction::getName)
/*  94 */       .orElseThrow(IllegalStateException::new);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ApplicationCommand.Type getCommandType() {
/* 103 */     return (ApplicationCommand.Type)getInteraction().getCommandInteraction()
/* 104 */       .flatMap(ApplicationCommandInteraction::getApplicationCommandType)
/* 105 */       .orElseThrow(IllegalStateException::new);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<ApplicationCommandInteractionOption> getOptions() {
/* 114 */     return ((ApplicationCommandInteraction)getInteraction().getCommandInteraction()
/* 115 */       .orElseThrow(IllegalStateException::new))
/* 116 */       .getOptions();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<ApplicationCommandInteractionOption> getOption(String name) {
/* 126 */     return ((ApplicationCommandInteraction)getInteraction().getCommandInteraction()
/* 127 */       .orElseThrow(IllegalStateException::new))
/* 128 */       .getOption(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ApplicationCommandInteractionOption getFocusedOption() {
/* 137 */     return (ApplicationCommandInteractionOption)getOptions().stream()
/* 138 */       .map(this::getFocusedOption)
/* 139 */       .filter(Optional::isPresent)
/* 140 */       .findFirst()
/* 141 */       .flatMap(Function.identity())
/* 142 */       .orElseThrow(() -> new IllegalStateException("No focused option found"));
/*     */   }
/*     */   
/*     */   private Optional<ApplicationCommandInteractionOption> getFocusedOption(ApplicationCommandInteractionOption opt) {
/* 146 */     if (opt.isFocused()) {
/* 147 */       return Optional.of(opt);
/*     */     }
/*     */     
/* 150 */     return opt.getOptions()
/* 151 */       .stream()
/* 152 */       .map(this::getFocusedOption)
/* 153 */       .filter(Optional::isPresent)
/* 154 */       .findFirst()
/* 155 */       .flatMap(Function.identity());
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\event\domain\interaction\ChatInputAutoCompleteEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */