/*    */ package discord4j.core.event.domain.interaction;
/*    */ 
/*    */ import discord4j.common.annotations.Experimental;
/*    */ import discord4j.core.GatewayDiscordClient;
/*    */ import discord4j.core.object.command.ApplicationCommandInteraction;
/*    */ import discord4j.core.object.command.Interaction;
/*    */ import discord4j.gateway.ShardInfo;
/*    */ import java.util.List;
/*    */ import java.util.function.Supplier;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Experimental
/*    */ public class SelectMenuInteractionEvent
/*    */   extends ComponentInteractionEvent
/*    */ {
/*    */   public SelectMenuInteractionEvent(GatewayDiscordClient gateway, ShardInfo shardInfo, Interaction interaction) {
/* 53 */     super(gateway, shardInfo, interaction);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public List<String> getValues() {
/* 64 */     return (List<String>)getInteraction().getCommandInteraction()
/* 65 */       .flatMap(ApplicationCommandInteraction::getValues)
/* 66 */       .orElseThrow(IllegalStateException::new);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\event\domain\interaction\SelectMenuInteractionEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */