/*     */ package discord4j.core.event.domain.interaction;
/*     */ 
/*     */ import discord4j.common.annotations.Experimental;
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.GatewayDiscordClient;
/*     */ import discord4j.core.object.command.Interaction;
/*     */ import discord4j.core.object.component.LayoutComponent;
/*     */ import discord4j.core.object.entity.Message;
/*     */ import discord4j.core.spec.InteractionApplicationCommandCallbackReplyMono;
/*     */ import discord4j.core.spec.InteractionApplicationCommandCallbackSpec;
/*     */ import discord4j.core.spec.InteractionCallbackSpec;
/*     */ import discord4j.core.spec.InteractionCallbackSpecDeferReplyMono;
/*     */ import discord4j.core.spec.InteractionFollowupCreateMono;
/*     */ import discord4j.core.spec.InteractionFollowupCreateSpec;
/*     */ import discord4j.core.spec.InteractionFollowupEditMono;
/*     */ import discord4j.core.spec.InteractionPresentModalMono;
/*     */ import discord4j.core.spec.InteractionPresentModalSpec;
/*     */ import discord4j.core.spec.InteractionReplyEditMono;
/*     */ import discord4j.core.spec.InteractionReplyEditSpec;
/*     */ import discord4j.core.spec.legacy.LegacyInteractionApplicationCommandCallbackSpec;
/*     */ import discord4j.discordjson.json.ImmutableInteractionApplicationCommandCallbackData;
/*     */ import discord4j.discordjson.json.InteractionApplicationCommandCallbackData;
/*     */ import discord4j.discordjson.json.MessageData;
/*     */ import discord4j.gateway.ShardInfo;
/*     */ import discord4j.rest.RestClient;
/*     */ import discord4j.rest.interaction.InteractionResponse;
/*     */ import discord4j.rest.util.AllowedMentions;
/*     */ import discord4j.rest.util.InteractionResponseType;
/*     */ import java.util.Collection;
/*     */ import java.util.Objects;
/*     */ import java.util.function.Consumer;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Experimental
/*     */ public class DeferrableInteractionEvent
/*     */   extends InteractionCreateEvent
/*     */ {
/*     */   private final InteractionCreateEvent.EventInteractionResponse response;
/*     */   
/*     */   public DeferrableInteractionEvent(GatewayDiscordClient gateway, ShardInfo shardInfo, Interaction interaction) {
/*  75 */     super(gateway, shardInfo, interaction);
/*  76 */     this.response = new InteractionCreateEvent.EventInteractionResponse((RestClient)getClient().rest(), interaction.getData());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public Mono<Void> acknowledge() {
/*  91 */     return createInteractionResponse(InteractionResponseType.DEFERRED_CHANNEL_MESSAGE_WITH_SOURCE, (InteractionApplicationCommandCallbackData)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InteractionCallbackSpecDeferReplyMono deferReply() {
/* 109 */     return InteractionCallbackSpecDeferReplyMono.of(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Void> deferReply(InteractionCallbackSpec spec) {
/* 127 */     Objects.requireNonNull(spec);
/* 128 */     return Mono.defer(() -> createInteractionResponse(InteractionResponseType.DEFERRED_CHANNEL_MESSAGE_WITH_SOURCE, spec.asRequest()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public Mono<Void> acknowledgeEphemeral() {
/* 144 */     ImmutableInteractionApplicationCommandCallbackData immutableInteractionApplicationCommandCallbackData = InteractionApplicationCommandCallbackData.builder().flags(Integer.valueOf(Message.Flag.EPHEMERAL.getFlag())).build();
/*     */     
/* 146 */     return createInteractionResponse(InteractionResponseType.DEFERRED_CHANNEL_MESSAGE_WITH_SOURCE, (InteractionApplicationCommandCallbackData)immutableInteractionApplicationCommandCallbackData);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public Mono<Void> reply(Consumer<? super LegacyInteractionApplicationCommandCallbackSpec> spec) {
/* 161 */     return Mono.defer(() -> {
/*     */           LegacyInteractionApplicationCommandCallbackSpec mutatedSpec = new LegacyInteractionApplicationCommandCallbackSpec();
/*     */           Objects.requireNonNull(mutatedSpec);
/*     */           getClient().getRestClient().getRestResources().getAllowedMentions().ifPresent(mutatedSpec::setAllowedMentions);
/*     */           spec.accept(mutatedSpec);
/*     */           return createInteractionResponse(InteractionResponseType.CHANNEL_MESSAGE_WITH_SOURCE, mutatedSpec.asRequest());
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InteractionApplicationCommandCallbackReplyMono reply() {
/* 196 */     return InteractionApplicationCommandCallbackReplyMono.of(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InteractionApplicationCommandCallbackReplyMono reply(String content) {
/* 219 */     return reply().withContent(content);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Void> reply(InteractionApplicationCommandCallbackSpec spec) {
/* 239 */     Objects.requireNonNull(spec);
/* 240 */     return Mono.defer(() -> {
/*     */           Objects.requireNonNull(spec);
/*     */           InteractionApplicationCommandCallbackSpec actualSpec = getClient().getRestClient().getRestResources().getAllowedMentions().filter(()).map(spec::withAllowedMentions).orElse(spec);
/*     */           return createInteractionResponse(InteractionResponseType.CHANNEL_MESSAGE_WITH_SOURCE, actualSpec.asRequest());
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InteractionPresentModalMono presentModal() {
/* 264 */     return InteractionPresentModalMono.of(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Void> presentModal(String title, String customId, Collection<LayoutComponent> components) {
/* 278 */     return (Mono<Void>)presentModal().withTitle(title).withCustomId(customId).withComponents(components);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Void> presentModal(InteractionPresentModalSpec spec) {
/* 290 */     Objects.requireNonNull(spec);
/* 291 */     return Mono.defer(() -> createInteractionResponse(InteractionResponseType.MODAL, spec.asRequest()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InteractionReplyEditMono editReply(String content) {
/* 307 */     return editReply().withContentOrNull(content);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InteractionReplyEditMono editReply() {
/* 359 */     return InteractionReplyEditMono.of(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Message> editReply(InteractionReplyEditSpec spec) {
/* 381 */     Objects.requireNonNull(spec);
/* 382 */     return Mono.defer(() -> {
/*     */           Objects.requireNonNull(spec);
/*     */ 
/*     */           
/*     */           InteractionReplyEditSpec actualSpec = getClient().getRestClient().getRestResources().getAllowedMentions().filter(()).map(spec::withAllowedMentionsOrNull).orElse(spec);
/*     */ 
/*     */           
/*     */           return getInteractionResponse().editInitialResponse(actualSpec.asRequest());
/* 390 */         }).map(data -> new Message(getClient(), data));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Message> getReply() {
/* 400 */     return getInteractionResponse().getInitialResponse().map(data -> new Message(getClient(), data));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Void> deleteReply() {
/* 410 */     return getInteractionResponse().deleteInitialResponse();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InteractionFollowupCreateMono createFollowup() {
/* 421 */     return InteractionFollowupCreateMono.of(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InteractionFollowupCreateMono createFollowup(String content) {
/* 432 */     return createFollowup().withContent(content);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Message> createFollowup(InteractionFollowupCreateSpec spec) {
/* 443 */     Objects.requireNonNull(spec);
/* 444 */     return Mono.defer(() -> {
/*     */           Objects.requireNonNull(spec);
/*     */ 
/*     */           
/*     */           InteractionFollowupCreateSpec actualSpec = getClient().getRestClient().getRestResources().getAllowedMentions().filter(()).map(spec::withAllowedMentions).orElse(spec);
/*     */ 
/*     */           
/*     */           return getInteractionResponse().createFollowupMessage(actualSpec.asRequest());
/* 452 */         }).map(data -> new Message(getClient(), data));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InteractionFollowupEditMono editFollowup(Snowflake messageId) {
/* 464 */     return InteractionFollowupEditMono.of(messageId, this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Message> editFollowup(Snowflake messageId, InteractionReplyEditSpec spec) {
/* 476 */     Objects.requireNonNull(spec);
/* 477 */     return Mono.defer(() -> {
/*     */           Objects.requireNonNull(spec);
/*     */ 
/*     */           
/*     */           InteractionReplyEditSpec actualSpec = getClient().getRestClient().getRestResources().getAllowedMentions().filter(()).map(spec::withAllowedMentionsOrNull).orElse(spec);
/*     */ 
/*     */           
/*     */           return getInteractionResponse().editFollowupMessage(messageId.asLong(), actualSpec.asRequest());
/* 485 */         }).map(data -> new Message(getClient(), data));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Void> deleteFollowup(Snowflake messageId) {
/* 496 */     return getInteractionResponse().deleteFollowupMessage(messageId.asLong());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InteractionResponse getInteractionResponse() {
/* 511 */     return this.response;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\event\domain\interaction\DeferrableInteractionEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */