/*      */ package discord4j.core.event;
/*      */ import discord4j.core.event.domain.AuditLogEntryCreateEvent;
/*      */ import discord4j.core.event.domain.Event;
/*      */ import discord4j.core.event.domain.InviteDeleteEvent;
/*      */ import discord4j.core.event.domain.PresenceUpdateEvent;
/*      */ import discord4j.core.event.domain.UserUpdateEvent;
/*      */ import discord4j.core.event.domain.VoiceServerUpdateEvent;
/*      */ import discord4j.core.event.domain.VoiceStateUpdateEvent;
/*      */ import discord4j.core.event.domain.automod.AutoModRuleDeleteEvent;
/*      */ import discord4j.core.event.domain.automod.AutoModRuleUpdateEvent;
/*      */ import discord4j.core.event.domain.channel.CategoryCreateEvent;
/*      */ import discord4j.core.event.domain.channel.CategoryUpdateEvent;
/*      */ import discord4j.core.event.domain.channel.NewsChannelDeleteEvent;
/*      */ import discord4j.core.event.domain.channel.NewsChannelUpdateEvent;
/*      */ import discord4j.core.event.domain.channel.PinsUpdateEvent;
/*      */ import discord4j.core.event.domain.channel.StoreChannelDeleteEvent;
/*      */ import discord4j.core.event.domain.channel.TextChannelCreateEvent;
/*      */ import discord4j.core.event.domain.channel.TextChannelUpdateEvent;
/*      */ import discord4j.core.event.domain.channel.TypingStartEvent;
/*      */ import discord4j.core.event.domain.channel.UnknownChannelCreateEvent;
/*      */ import discord4j.core.event.domain.channel.UnknownChannelDeleteEvent;
/*      */ import discord4j.core.event.domain.channel.UnknownChannelUpdateEvent;
/*      */ import discord4j.core.event.domain.channel.VoiceChannelCreateEvent;
/*      */ import discord4j.core.event.domain.command.ApplicationCommandCreateEvent;
/*      */ import discord4j.core.event.domain.command.ApplicationCommandUpdateEvent;
/*      */ import discord4j.core.event.domain.guild.GuildDeleteEvent;
/*      */ import discord4j.core.event.domain.guild.GuildUpdateEvent;
/*      */ import discord4j.core.event.domain.guild.IntegrationsUpdateEvent;
/*      */ import discord4j.core.event.domain.guild.MemberChunkEvent;
/*      */ import discord4j.core.event.domain.guild.MemberJoinEvent;
/*      */ import discord4j.core.event.domain.guild.MemberLeaveEvent;
/*      */ import discord4j.core.event.domain.guild.ScheduledEventDeleteEvent;
/*      */ import discord4j.core.event.domain.guild.ScheduledEventUserAddEvent;
/*      */ import discord4j.core.event.domain.guild.StickersUpdateEvent;
/*      */ import discord4j.core.event.domain.guild.UnbanEvent;
/*      */ import discord4j.core.event.domain.integration.IntegrationCreateEvent;
/*      */ import discord4j.core.event.domain.integration.IntegrationDeleteEvent;
/*      */ import discord4j.core.event.domain.integration.IntegrationUpdateEvent;
/*      */ import discord4j.core.event.domain.interaction.ApplicationCommandInteractionEvent;
/*      */ import discord4j.core.event.domain.interaction.ButtonInteractionEvent;
/*      */ import discord4j.core.event.domain.interaction.ChatInputAutoCompleteEvent;
/*      */ import discord4j.core.event.domain.interaction.ChatInputInteractionEvent;
/*      */ import discord4j.core.event.domain.interaction.InteractionCreateEvent;
/*      */ import discord4j.core.event.domain.interaction.MessageInteractionEvent;
/*      */ import discord4j.core.event.domain.interaction.ModalSubmitInteractionEvent;
/*      */ import discord4j.core.event.domain.interaction.SelectMenuInteractionEvent;
/*      */ import discord4j.core.event.domain.lifecycle.ReadyEvent;
/*      */ import discord4j.core.event.domain.lifecycle.ReconnectStartEvent;
/*      */ import discord4j.core.event.domain.lifecycle.ResumeEvent;
/*      */ import discord4j.core.event.domain.lifecycle.SessionInvalidatedEvent;
/*      */ import discord4j.core.event.domain.message.MessageBulkDeleteEvent;
/*      */ import discord4j.core.event.domain.message.MessageCreateEvent;
/*      */ import discord4j.core.event.domain.message.MessageDeleteEvent;
/*      */ import discord4j.core.event.domain.message.ReactionAddEvent;
/*      */ import discord4j.core.event.domain.message.ReactionRemoveEmojiEvent;
/*      */ import discord4j.core.event.domain.message.ReactionRemoveEvent;
/*      */ import discord4j.core.event.domain.role.RoleDeleteEvent;
/*      */ import java.util.List;
/*      */ import org.reactivestreams.Publisher;
/*      */ import reactor.core.publisher.Mono;
/*      */ 
/*      */ public abstract class ReactiveEventAdapter {
/*      */   public Publisher<?> onReady(ReadyEvent event) {
/*   64 */     return (Publisher<?>)Mono.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Publisher<?> onResume(ResumeEvent event) {
/*   75 */     return (Publisher<?>)Mono.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Publisher<?> onMessageCreate(MessageCreateEvent event) {
/*   88 */     return (Publisher<?>)Mono.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Publisher<?> onMessageDelete(MessageDeleteEvent event) {
/*   99 */     return (Publisher<?>)Mono.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Publisher<?> onMessageUpdate(MessageUpdateEvent event) {
/*  112 */     return (Publisher<?>)Mono.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Publisher<?> onMessageBulkDelete(MessageBulkDeleteEvent event) {
/*  123 */     return (Publisher<?>)Mono.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Publisher<?> onReactionAdd(ReactionAddEvent event) {
/*  134 */     return (Publisher<?>)Mono.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Publisher<?> onReactionRemove(ReactionRemoveEvent event) {
/*  146 */     return (Publisher<?>)Mono.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Publisher<?> onReactionRemoveEmoji(ReactionRemoveEmojiEvent event) {
/*  158 */     return (Publisher<?>)Mono.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Publisher<?> onReactionRemoveAll(ReactionRemoveAllEvent event) {
/*  170 */     return (Publisher<?>)Mono.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Publisher<?> onApplicationCommandCreate(ApplicationCommandCreateEvent event) {
/*  184 */     return (Publisher<?>)Mono.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Publisher<?> onApplicationCommandUpdate(ApplicationCommandUpdateEvent event) {
/*  196 */     return (Publisher<?>)Mono.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Publisher<?> onApplicationCommandDelete(ApplicationCommandDeleteEvent event) {
/*  208 */     return (Publisher<?>)Mono.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Publisher<?> onGuildCreate(GuildCreateEvent event) {
/*  222 */     return (Publisher<?>)Mono.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Publisher<?> onGuildDelete(GuildDeleteEvent event) {
/*  233 */     return (Publisher<?>)Mono.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Publisher<?> onGuildUpdate(GuildUpdateEvent event) {
/*  244 */     return (Publisher<?>)Mono.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Publisher<?> onMemberJoin(MemberJoinEvent event) {
/*  255 */     return (Publisher<?>)Mono.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Publisher<?> onMemberLeave(MemberLeaveEvent event) {
/*  266 */     return (Publisher<?>)Mono.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Publisher<?> onMemberUpdate(MemberUpdateEvent event) {
/*  277 */     return (Publisher<?>)Mono.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Publisher<?> onMemberChunk(MemberChunkEvent event) {
/*  288 */     return (Publisher<?>)Mono.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Publisher<?> onEmojisUpdate(EmojisUpdateEvent event) {
/*  299 */     return (Publisher<?>)Mono.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Publisher<?> onStickersUpdate(StickersUpdateEvent event) {
/*  310 */     return (Publisher<?>)Mono.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Publisher<?> onAuditLogEntryCreate(AuditLogEntryCreateEvent event) {
/*  321 */     return (Publisher<?>)Mono.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Publisher<?> onBan(BanEvent event) {
/*  332 */     return (Publisher<?>)Mono.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Publisher<?> onUnban(UnbanEvent event) {
/*  343 */     return (Publisher<?>)Mono.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Publisher<?> onIntegrationsUpdate(IntegrationsUpdateEvent event) {
/*  354 */     return (Publisher<?>)Mono.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Publisher<?> onWebhooksUpdate(WebhooksUpdateEvent event) {
/*  366 */     return (Publisher<?>)Mono.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Publisher<?> onTextChannelCreate(TextChannelCreateEvent event) {
/*  379 */     return (Publisher<?>)Mono.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Publisher<?> onTextChannelDelete(TextChannelDeleteEvent event) {
/*  390 */     return (Publisher<?>)Mono.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Publisher<?> onTextChannelUpdate(TextChannelUpdateEvent event) {
/*  401 */     return (Publisher<?>)Mono.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Publisher<?> onVoiceChannelCreate(VoiceChannelCreateEvent event) {
/*  412 */     return (Publisher<?>)Mono.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Publisher<?> onVoiceChannelDelete(VoiceChannelDeleteEvent event) {
/*  423 */     return (Publisher<?>)Mono.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Publisher<?> onVoiceChannelUpdate(VoiceChannelUpdateEvent event) {
/*  434 */     return (Publisher<?>)Mono.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Publisher<?> onCategoryCreate(CategoryCreateEvent event) {
/*  445 */     return (Publisher<?>)Mono.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Publisher<?> onCategoryDelete(CategoryDeleteEvent event) {
/*  456 */     return (Publisher<?>)Mono.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Publisher<?> onCategoryUpdate(CategoryUpdateEvent event) {
/*  467 */     return (Publisher<?>)Mono.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Publisher<?> onNewsChannelCreate(NewsChannelCreateEvent event) {
/*  478 */     return (Publisher<?>)Mono.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Publisher<?> onNewsChannelDelete(NewsChannelDeleteEvent event) {
/*  489 */     return (Publisher<?>)Mono.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Publisher<?> onNewsChannelUpdate(NewsChannelUpdateEvent event) {
/*  500 */     return (Publisher<?>)Mono.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Publisher<?> onStoreChannelCreate(StoreChannelCreateEvent event) {
/*  511 */     return (Publisher<?>)Mono.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Publisher<?> onStoreChannelDelete(StoreChannelDeleteEvent event) {
/*  522 */     return (Publisher<?>)Mono.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Publisher<?> onStoreChannelUpdate(StoreChannelUpdateEvent event) {
/*  533 */     return (Publisher<?>)Mono.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Publisher<?> onUnknownChannelCreate(UnknownChannelCreateEvent event) {
/*  545 */     return (Publisher<?>)Mono.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Publisher<?> onUnknownChannelDelete(UnknownChannelDeleteEvent event) {
/*  557 */     return (Publisher<?>)Mono.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Publisher<?> onUnknownChannelUpdate(UnknownChannelUpdateEvent event) {
/*  569 */     return (Publisher<?>)Mono.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Publisher<?> onTypingStart(TypingStartEvent event) {
/*  580 */     return (Publisher<?>)Mono.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Publisher<?> onPinsUpdate(PinsUpdateEvent event) {
/*  591 */     return (Publisher<?>)Mono.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Publisher<?> onRoleCreate(RoleCreateEvent event) {
/*  604 */     return (Publisher<?>)Mono.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Publisher<?> onRoleDelete(RoleDeleteEvent event) {
/*  615 */     return (Publisher<?>)Mono.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Publisher<?> onRoleUpdate(RoleUpdateEvent event) {
/*  626 */     return (Publisher<?>)Mono.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Publisher<?> onInviteCreate(InviteCreateEvent event) {
/*  639 */     return (Publisher<?>)Mono.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Publisher<?> onInviteDelete(InviteDeleteEvent event) {
/*  650 */     return (Publisher<?>)Mono.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Publisher<?> onUserUpdate(UserUpdateEvent event) {
/*  663 */     return (Publisher<?>)Mono.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Publisher<?> onPresenceUpdate(PresenceUpdateEvent event) {
/*  674 */     return (Publisher<?>)Mono.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Publisher<?> onVoiceStateUpdate(VoiceStateUpdateEvent event) {
/*  687 */     return (Publisher<?>)Mono.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Publisher<?> onVoiceServerUpdate(VoiceServerUpdateEvent event) {
/*  698 */     return (Publisher<?>)Mono.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Publisher<?> onConnect(ConnectEvent event) {
/*  711 */     return (Publisher<?>)Mono.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Publisher<?> onReconnect(ReconnectEvent event) {
/*  722 */     return (Publisher<?>)Mono.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Publisher<?> onDisconnect(DisconnectEvent event) {
/*  733 */     return (Publisher<?>)Mono.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Publisher<?> onReconnectStart(ReconnectStartEvent event) {
/*  744 */     return (Publisher<?>)Mono.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Publisher<?> onReconnectFail(ReconnectFailEvent event) {
/*  755 */     return (Publisher<?>)Mono.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Publisher<?> onSessionInvalidated(SessionInvalidatedEvent event) {
/*  766 */     return (Publisher<?>)Mono.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Publisher<?> onInteractionCreate(InteractionCreateEvent event) {
/*  779 */     return (Publisher<?>)Mono.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Publisher<?> onDeferrableInteraction(DeferrableInteractionEvent event) {
/*  790 */     return (Publisher<?>)Mono.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Publisher<?> onApplicationCommandInteraction(ApplicationCommandInteractionEvent event) {
/*  801 */     return (Publisher<?>)Mono.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Publisher<?> onChatInputInteraction(ChatInputInteractionEvent event) {
/*  812 */     return (Publisher<?>)Mono.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Publisher<?> onMessageInteraction(MessageInteractionEvent event) {
/*  823 */     return (Publisher<?>)Mono.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Publisher<?> onUserInteraction(UserInteractionEvent event) {
/*  834 */     return (Publisher<?>)Mono.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Publisher<?> onComponentInteraction(ComponentInteractionEvent event) {
/*  845 */     return (Publisher<?>)Mono.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Publisher<?> onButtonInteraction(ButtonInteractionEvent event) {
/*  856 */     return (Publisher<?>)Mono.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Publisher<?> onSelectMenuInteraction(SelectMenuInteractionEvent event) {
/*  867 */     return (Publisher<?>)Mono.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Publisher<?> onAutoCompleteInteraction(AutoCompleteInteractionEvent event) {
/*  878 */     return (Publisher<?>)Mono.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Publisher<?> onChatInputAutoCompleteInteraction(ChatInputAutoCompleteEvent event) {
/*  889 */     return (Publisher<?>)Mono.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Publisher<?> onModalSubmitInteraction(ModalSubmitInteractionEvent event) {
/*  900 */     return (Publisher<?>)Mono.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Publisher<?> onIntegrationCreate(IntegrationCreateEvent event) {
/*  913 */     return (Publisher<?>)Mono.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Publisher<?> onIntegrationUpdate(IntegrationUpdateEvent event) {
/*  924 */     return (Publisher<?>)Mono.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Publisher<?> onIntegrationDelete(IntegrationDeleteEvent event) {
/*  935 */     return (Publisher<?>)Mono.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Publisher<?> onAutoModRuleCreate(AutoModRuleCreateEvent event) {
/*  948 */     return (Publisher<?>)Mono.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Publisher<?> onAutoModRuleUpdate(AutoModRuleUpdateEvent event) {
/*  959 */     return (Publisher<?>)Mono.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Publisher<?> onAutoModRuleDelete(AutoModRuleDeleteEvent event) {
/*  970 */     return (Publisher<?>)Mono.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Publisher<?> onAutoModActionExecution(AutoModActionExecutedEvent event) {
/*  981 */     return (Publisher<?>)Mono.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Publisher<?> onScheduledEventCreate(ScheduledEventCreateEvent event) {
/*  994 */     return (Publisher<?>)Mono.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Publisher<?> onScheduledEventUpdate(ScheduledEventUpdateEvent event) {
/* 1005 */     return (Publisher<?>)Mono.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Publisher<?> onScheduledEventDelete(ScheduledEventDeleteEvent event) {
/* 1016 */     return (Publisher<?>)Mono.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Publisher<?> onScheduledEventUserAdd(ScheduledEventUserAddEvent event) {
/* 1027 */     return (Publisher<?>)Mono.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Publisher<?> onScheduledEventUserRemove(ScheduledEventUserRemoveEvent event) {
/* 1038 */     return (Publisher<?>)Mono.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ReactiveEventAdapter from(ReactiveEventAdapter... adapters) {
/* 1050 */     return new CompositeReactiveEventAdapter(adapters);
/*      */   }
/*      */ 
/*      */   
/*      */   public Publisher<?> hookOnEvent(Event event) {
/* 1055 */     List<Publisher<?>> compatibleHooks = new ArrayList<>();
/* 1056 */     if (event instanceof ReadyEvent) compatibleHooks.add(onReady((ReadyEvent)event)); 
/* 1057 */     if (event instanceof ResumeEvent) compatibleHooks.add(onResume((ResumeEvent)event)); 
/* 1058 */     if (event instanceof MessageCreateEvent) compatibleHooks.add(onMessageCreate((MessageCreateEvent)event)); 
/* 1059 */     if (event instanceof MessageDeleteEvent) compatibleHooks.add(onMessageDelete((MessageDeleteEvent)event)); 
/* 1060 */     if (event instanceof MessageUpdateEvent) compatibleHooks.add(onMessageUpdate((MessageUpdateEvent)event)); 
/* 1061 */     if (event instanceof MessageBulkDeleteEvent) compatibleHooks.add(onMessageBulkDelete((MessageBulkDeleteEvent)event)); 
/* 1062 */     if (event instanceof ReactionAddEvent) compatibleHooks.add(onReactionAdd((ReactionAddEvent)event)); 
/* 1063 */     if (event instanceof ReactionRemoveEvent) compatibleHooks.add(onReactionRemove((ReactionRemoveEvent)event)); 
/* 1064 */     if (event instanceof ReactionRemoveEmojiEvent) compatibleHooks.add(onReactionRemoveEmoji((ReactionRemoveEmojiEvent)event)); 
/* 1065 */     if (event instanceof ReactionRemoveAllEvent) compatibleHooks.add(onReactionRemoveAll((ReactionRemoveAllEvent)event)); 
/* 1066 */     if (event instanceof GuildCreateEvent) compatibleHooks.add(onGuildCreate((GuildCreateEvent)event)); 
/* 1067 */     if (event instanceof GuildDeleteEvent) compatibleHooks.add(onGuildDelete((GuildDeleteEvent)event)); 
/* 1068 */     if (event instanceof GuildUpdateEvent) compatibleHooks.add(onGuildUpdate((GuildUpdateEvent)event)); 
/* 1069 */     if (event instanceof MemberJoinEvent) compatibleHooks.add(onMemberJoin((MemberJoinEvent)event)); 
/* 1070 */     if (event instanceof MemberLeaveEvent) compatibleHooks.add(onMemberLeave((MemberLeaveEvent)event)); 
/* 1071 */     if (event instanceof MemberUpdateEvent) compatibleHooks.add(onMemberUpdate((MemberUpdateEvent)event)); 
/* 1072 */     if (event instanceof MemberChunkEvent) compatibleHooks.add(onMemberChunk((MemberChunkEvent)event)); 
/* 1073 */     if (event instanceof EmojisUpdateEvent) compatibleHooks.add(onEmojisUpdate((EmojisUpdateEvent)event)); 
/* 1074 */     if (event instanceof StickersUpdateEvent) compatibleHooks.add(onStickersUpdate((StickersUpdateEvent)event)); 
/* 1075 */     if (event instanceof AuditLogEntryCreateEvent) compatibleHooks.add(onAuditLogEntryCreate((AuditLogEntryCreateEvent)event)); 
/* 1076 */     if (event instanceof BanEvent) compatibleHooks.add(onBan((BanEvent)event)); 
/* 1077 */     if (event instanceof UnbanEvent) compatibleHooks.add(onUnban((UnbanEvent)event)); 
/* 1078 */     if (event instanceof IntegrationsUpdateEvent) compatibleHooks.add(onIntegrationsUpdate((IntegrationsUpdateEvent)event)); 
/* 1079 */     if (event instanceof WebhooksUpdateEvent) compatibleHooks.add(onWebhooksUpdate((WebhooksUpdateEvent)event)); 
/* 1080 */     if (event instanceof TextChannelCreateEvent) compatibleHooks.add(onTextChannelCreate((TextChannelCreateEvent)event)); 
/* 1081 */     if (event instanceof TextChannelDeleteEvent) compatibleHooks.add(onTextChannelDelete((TextChannelDeleteEvent)event)); 
/* 1082 */     if (event instanceof TextChannelUpdateEvent) compatibleHooks.add(onTextChannelUpdate((TextChannelUpdateEvent)event)); 
/* 1083 */     if (event instanceof VoiceChannelCreateEvent) compatibleHooks.add(onVoiceChannelCreate((VoiceChannelCreateEvent)event)); 
/* 1084 */     if (event instanceof VoiceChannelDeleteEvent) compatibleHooks.add(onVoiceChannelDelete((VoiceChannelDeleteEvent)event)); 
/* 1085 */     if (event instanceof VoiceChannelUpdateEvent) compatibleHooks.add(onVoiceChannelUpdate((VoiceChannelUpdateEvent)event)); 
/* 1086 */     if (event instanceof CategoryCreateEvent) compatibleHooks.add(onCategoryCreate((CategoryCreateEvent)event)); 
/* 1087 */     if (event instanceof CategoryDeleteEvent) compatibleHooks.add(onCategoryDelete((CategoryDeleteEvent)event)); 
/* 1088 */     if (event instanceof CategoryUpdateEvent) compatibleHooks.add(onCategoryUpdate((CategoryUpdateEvent)event)); 
/* 1089 */     if (event instanceof NewsChannelCreateEvent) compatibleHooks.add(onNewsChannelCreate((NewsChannelCreateEvent)event)); 
/* 1090 */     if (event instanceof NewsChannelDeleteEvent) compatibleHooks.add(onNewsChannelDelete((NewsChannelDeleteEvent)event)); 
/* 1091 */     if (event instanceof NewsChannelUpdateEvent) compatibleHooks.add(onNewsChannelUpdate((NewsChannelUpdateEvent)event)); 
/* 1092 */     if (event instanceof StoreChannelCreateEvent) compatibleHooks.add(onStoreChannelCreate((StoreChannelCreateEvent)event)); 
/* 1093 */     if (event instanceof StoreChannelDeleteEvent) compatibleHooks.add(onStoreChannelDelete((StoreChannelDeleteEvent)event)); 
/* 1094 */     if (event instanceof StoreChannelUpdateEvent) compatibleHooks.add(onStoreChannelUpdate((StoreChannelUpdateEvent)event)); 
/* 1095 */     if (event instanceof UnknownChannelCreateEvent) compatibleHooks.add(onUnknownChannelCreate((UnknownChannelCreateEvent)event)); 
/* 1096 */     if (event instanceof UnknownChannelDeleteEvent) compatibleHooks.add(onUnknownChannelDelete((UnknownChannelDeleteEvent)event)); 
/* 1097 */     if (event instanceof UnknownChannelUpdateEvent) compatibleHooks.add(onUnknownChannelUpdate((UnknownChannelUpdateEvent)event)); 
/* 1098 */     if (event instanceof TypingStartEvent) compatibleHooks.add(onTypingStart((TypingStartEvent)event)); 
/* 1099 */     if (event instanceof PinsUpdateEvent) compatibleHooks.add(onPinsUpdate((PinsUpdateEvent)event)); 
/* 1100 */     if (event instanceof RoleCreateEvent) compatibleHooks.add(onRoleCreate((RoleCreateEvent)event)); 
/* 1101 */     if (event instanceof RoleDeleteEvent) compatibleHooks.add(onRoleDelete((RoleDeleteEvent)event)); 
/* 1102 */     if (event instanceof RoleUpdateEvent) compatibleHooks.add(onRoleUpdate((RoleUpdateEvent)event)); 
/* 1103 */     if (event instanceof InviteCreateEvent) compatibleHooks.add(onInviteCreate((InviteCreateEvent)event)); 
/* 1104 */     if (event instanceof InviteDeleteEvent) compatibleHooks.add(onInviteDelete((InviteDeleteEvent)event)); 
/* 1105 */     if (event instanceof UserUpdateEvent) compatibleHooks.add(onUserUpdate((UserUpdateEvent)event)); 
/* 1106 */     if (event instanceof PresenceUpdateEvent) compatibleHooks.add(onPresenceUpdate((PresenceUpdateEvent)event)); 
/* 1107 */     if (event instanceof VoiceStateUpdateEvent) compatibleHooks.add(onVoiceStateUpdate((VoiceStateUpdateEvent)event)); 
/* 1108 */     if (event instanceof VoiceServerUpdateEvent) compatibleHooks.add(onVoiceServerUpdate((VoiceServerUpdateEvent)event)); 
/* 1109 */     if (event instanceof ConnectEvent) compatibleHooks.add(onConnect((ConnectEvent)event)); 
/* 1110 */     if (event instanceof ReconnectEvent) compatibleHooks.add(onReconnect((ReconnectEvent)event)); 
/* 1111 */     if (event instanceof DisconnectEvent) compatibleHooks.add(onDisconnect((DisconnectEvent)event)); 
/* 1112 */     if (event instanceof ReconnectStartEvent) compatibleHooks.add(onReconnectStart((ReconnectStartEvent)event)); 
/* 1113 */     if (event instanceof ReconnectFailEvent) compatibleHooks.add(onReconnectFail((ReconnectFailEvent)event)); 
/* 1114 */     if (event instanceof SessionInvalidatedEvent) compatibleHooks.add(onSessionInvalidated((SessionInvalidatedEvent)event)); 
/* 1115 */     if (event instanceof ApplicationCommandInteractionEvent) compatibleHooks.add(onApplicationCommandInteraction((ApplicationCommandInteractionEvent)event)); 
/* 1116 */     if (event instanceof ChatInputInteractionEvent) compatibleHooks.add(onChatInputInteraction((ChatInputInteractionEvent)event)); 
/* 1117 */     if (event instanceof MessageInteractionEvent) compatibleHooks.add(onMessageInteraction((MessageInteractionEvent)event)); 
/* 1118 */     if (event instanceof UserInteractionEvent) compatibleHooks.add(onUserInteraction((UserInteractionEvent)event)); 
/* 1119 */     if (event instanceof ButtonInteractionEvent) compatibleHooks.add(onButtonInteraction((ButtonInteractionEvent)event)); 
/* 1120 */     if (event instanceof SelectMenuInteractionEvent) compatibleHooks.add(onSelectMenuInteraction((SelectMenuInteractionEvent)event)); 
/* 1121 */     if (event instanceof ComponentInteractionEvent) compatibleHooks.add(onComponentInteraction((ComponentInteractionEvent)event)); 
/* 1122 */     if (event instanceof AutoCompleteInteractionEvent) compatibleHooks.add(onAutoCompleteInteraction((AutoCompleteInteractionEvent)event)); 
/* 1123 */     if (event instanceof ChatInputAutoCompleteEvent) compatibleHooks.add(onChatInputAutoCompleteInteraction((ChatInputAutoCompleteEvent)event)); 
/* 1124 */     if (event instanceof ModalSubmitInteractionEvent) compatibleHooks.add(onModalSubmitInteraction((ModalSubmitInteractionEvent)event)); 
/* 1125 */     if (event instanceof DeferrableInteractionEvent) compatibleHooks.add(onDeferrableInteraction((DeferrableInteractionEvent)event)); 
/* 1126 */     if (event instanceof InteractionCreateEvent) compatibleHooks.add(onInteractionCreate((InteractionCreateEvent)event)); 
/* 1127 */     if (event instanceof ApplicationCommandCreateEvent) compatibleHooks.add(onApplicationCommandCreate((ApplicationCommandCreateEvent)event)); 
/* 1128 */     if (event instanceof ApplicationCommandUpdateEvent) compatibleHooks.add(onApplicationCommandUpdate((ApplicationCommandUpdateEvent)event)); 
/* 1129 */     if (event instanceof ApplicationCommandDeleteEvent) compatibleHooks.add(onApplicationCommandDelete((ApplicationCommandDeleteEvent)event)); 
/* 1130 */     if (event instanceof IntegrationCreateEvent) compatibleHooks.add(onIntegrationCreate((IntegrationCreateEvent)event)); 
/* 1131 */     if (event instanceof IntegrationUpdateEvent) compatibleHooks.add(onIntegrationUpdate((IntegrationUpdateEvent)event)); 
/* 1132 */     if (event instanceof IntegrationDeleteEvent) compatibleHooks.add(onIntegrationDelete((IntegrationDeleteEvent)event)); 
/* 1133 */     if (event instanceof AutoModRuleCreateEvent) compatibleHooks.add(onAutoModRuleCreate((AutoModRuleCreateEvent)event)); 
/* 1134 */     if (event instanceof AutoModRuleUpdateEvent) compatibleHooks.add(onAutoModRuleUpdate((AutoModRuleUpdateEvent)event)); 
/* 1135 */     if (event instanceof AutoModRuleDeleteEvent) compatibleHooks.add(onAutoModRuleDelete((AutoModRuleDeleteEvent)event)); 
/* 1136 */     if (event instanceof AutoModActionExecutedEvent) compatibleHooks.add(onAutoModActionExecution((AutoModActionExecutedEvent)event)); 
/* 1137 */     if (event instanceof ScheduledEventCreateEvent) compatibleHooks.add(onScheduledEventCreate((ScheduledEventCreateEvent)event)); 
/* 1138 */     if (event instanceof ScheduledEventUpdateEvent) compatibleHooks.add(onScheduledEventUpdate((ScheduledEventUpdateEvent)event)); 
/* 1139 */     if (event instanceof ScheduledEventDeleteEvent) compatibleHooks.add(onScheduledEventDelete((ScheduledEventDeleteEvent)event)); 
/* 1140 */     if (event instanceof ScheduledEventUserAddEvent) compatibleHooks.add(onScheduledEventUserAdd((ScheduledEventUserAddEvent)event)); 
/* 1141 */     if (event instanceof ScheduledEventUserRemoveEvent) compatibleHooks.add(onScheduledEventUserRemove((ScheduledEventUserRemoveEvent)event));
/*      */     
/* 1143 */     return (Publisher<?>)Mono.whenDelayError(compatibleHooks);
/*      */   }
/*      */   
/*      */   private static class CompositeReactiveEventAdapter
/*      */     extends ReactiveEventAdapter {
/*      */     private final ReactiveEventAdapter[] adapters;
/*      */     
/*      */     public CompositeReactiveEventAdapter(ReactiveEventAdapter... adapters) {
/* 1151 */       this.adapters = adapters;
/*      */     }
/*      */ 
/*      */     
/*      */     public Publisher<?> hookOnEvent(Event event) {
/* 1156 */       return (Publisher<?>)Flux.fromArray((Object[])this.adapters).flatMap(it -> it.hookOnEvent(event));
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\event\ReactiveEventAdapter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */