/*     */ package discord4j.core.event;
/*     */ 
/*     */ import discord4j.common.LogUtil;
/*     */ import discord4j.core.event.domain.Event;
/*     */ import java.time.Duration;
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.atomic.AtomicReference;
/*     */ import java.util.function.Predicate;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.publisher.EmitterProcessor;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.FluxProcessor;
/*     */ import reactor.core.publisher.FluxSink;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.core.publisher.ReplayProcessor;
/*     */ import reactor.core.publisher.SignalType;
/*     */ import reactor.core.publisher.SynchronousSink;
/*     */ import reactor.core.scheduler.Scheduler;
/*     */ import reactor.core.scheduler.Schedulers;
/*     */ import reactor.util.Logger;
/*     */ import reactor.util.Loggers;
/*     */ import reactor.util.concurrent.Queues;
/*     */ import reactor.util.context.ContextView;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReplayingEventDispatcher
/*     */   implements EventDispatcher
/*     */ {
/*  57 */   private static final Logger log = Loggers.getLogger(ReplayingEventDispatcher.class);
/*     */   
/*     */   private final FluxProcessor<Event, Event> eventProcessor;
/*     */   
/*     */   private final FluxSink<Event> sink;
/*     */   private final Scheduler eventScheduler;
/*     */   private final ReplayProcessor<Event> replayEventProcessor;
/*     */   private final FluxSink<Event> replaySink;
/*     */   private final Predicate<Event> replayEventFilter;
/*     */   private final Scheduler timedTaskScheduler;
/*     */   private final Publisher<?> stopReplayingTrigger;
/*  68 */   private final AtomicReference<State> state = new AtomicReference<>(State.REPLAY);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReplayingEventDispatcher(FluxProcessor<Event, Event> eventProcessor, FluxSink.OverflowStrategy overflowStrategy, Scheduler eventScheduler, ReplayProcessor<Event> replayEventProcessor, FluxSink.OverflowStrategy replayEventOverflowStrategy, Predicate<Event> replayEventFilter, Scheduler timedTaskScheduler, Publisher<?> stopReplayingTrigger) {
/*  96 */     this.eventProcessor = eventProcessor;
/*  97 */     this.sink = eventProcessor.sink(overflowStrategy);
/*  98 */     this.eventScheduler = eventScheduler;
/*  99 */     this.replayEventProcessor = replayEventProcessor;
/* 100 */     this.replaySink = replayEventProcessor.sink(replayEventOverflowStrategy);
/* 101 */     this.replayEventFilter = replayEventFilter;
/* 102 */     this.timedTaskScheduler = timedTaskScheduler;
/* 103 */     this.stopReplayingTrigger = stopReplayingTrigger;
/*     */   }
/*     */ 
/*     */   
/*     */   public <E extends Event> Flux<E> on(Class<E> eventClass) {
/* 108 */     AtomicReference<Subscription> subscription = new AtomicReference<>();
/* 109 */     return this.eventProcessor.publishOn(this.eventScheduler)
/* 110 */       .startWith((Publisher)this.replayEventProcessor.timeout(Duration.ofMillis(1L), (Publisher)Mono.empty(), this.timedTaskScheduler))
/* 111 */       .ofType(eventClass)
/* 112 */       .handle((event, sink) -> {
/*     */           if (log.isTraceEnabled()) {
/*     */             log.trace(LogUtil.format((ContextView)sink.currentContext().put("discord4j.shard", Integer.valueOf(event.getShardInfo().getIndex())), "{}"), new Object[] { event.toString() });
/*     */           }
/*     */ 
/*     */           
/*     */           sink.next(event);
/* 119 */         }).doOnSubscribe(sub -> {
/*     */           subscription.set(sub);
/*     */ 
/*     */           
/*     */           if (log.isDebugEnabled()) {
/*     */             log.debug("Subscription {} to {} created", new Object[] { Integer.toHexString(sub.hashCode()), eventClass.getSimpleName() });
/*     */           }
/* 126 */         }).doFinally(signal -> {
/*     */           if (log.isDebugEnabled()) {
/*     */             log.debug("Subscription {} to {} disposed due to {}", new Object[] { Integer.toHexString(((Subscription)subscription.get()).hashCode()), eventClass.getSimpleName(), signal });
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void publish(Event event) {
/* 136 */     if (this.state.get() != State.EMIT && this.replayEventFilter.test(event)) {
/* 137 */       this.replaySink.next(event);
/*     */     }
/* 139 */     if (this.eventProcessor.hasDownstreams()) {
/* 140 */       if (this.state.compareAndSet(State.REPLAY, State.REPLAY_EMIT)) {
/* 141 */         Flux.from(this.stopReplayingTrigger).doFinally(__ -> this.state.set(State.EMIT)).subscribe();
/*     */       }
/* 143 */       this.sink.next(event);
/* 144 */     } else if (this.state.compareAndSet(State.EMIT, State.REPLAY) && this.replayEventFilter.test(event)) {
/* 145 */       log.warn("All subscribers have disconnected from this dispatcher");
/* 146 */       this.replaySink.next(event);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void shutdown() {
/* 152 */     this.replaySink.complete();
/* 153 */     this.sink.complete();
/*     */   }
/*     */   
/*     */   private enum State {
/* 157 */     REPLAY, REPLAY_EMIT, EMIT;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static EventDispatcher create() {
/* 166 */     return builder().build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 175 */     return new Builder();
/*     */   }
/*     */   
/*     */   public static class Builder extends DefaultEventDispatcher.Builder {
/*     */     protected Predicate<Event> replayEventFilter;
/*     */     protected Scheduler timedTaskScheduler;
/*     */     
/*     */     protected Builder() {
/* 183 */       this.replayEventFilter = (event -> 
/* 184 */         (event instanceof discord4j.core.event.domain.lifecycle.GatewayLifecycleEvent || event instanceof discord4j.core.event.domain.guild.GuildCreateEvent));
/* 185 */       this.timedTaskScheduler = Schedulers.parallel();
/*     */       
/* 187 */       this.replayEventOverflowStrategy = FluxSink.OverflowStrategy.DROP;
/*     */     }
/*     */     
/*     */     protected ReplayProcessor<Event> replayEventProcessor;
/*     */     protected FluxSink.OverflowStrategy replayEventOverflowStrategy;
/*     */     protected Publisher<?> stopReplayingTrigger;
/*     */     
/*     */     public Builder eventProcessor(FluxProcessor<Event, Event> eventProcessor) {
/* 195 */       this.eventProcessor = Objects.<FluxProcessor<Event, Event>>requireNonNull(eventProcessor);
/* 196 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder overflowStrategy(FluxSink.OverflowStrategy overflowStrategy) {
/* 201 */       this.overflowStrategy = Objects.<FluxSink.OverflowStrategy>requireNonNull(overflowStrategy);
/* 202 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder eventScheduler(Scheduler eventScheduler) {
/* 207 */       this.eventScheduler = Objects.<Scheduler>requireNonNull(eventScheduler);
/* 208 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder replayEventProcessor(ReplayProcessor<Event> replayEventProcessor) {
/* 219 */       this.replayEventProcessor = Objects.<ReplayProcessor<Event>>requireNonNull(replayEventProcessor);
/* 220 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder replayEventOverflowStrategy(FluxSink.OverflowStrategy replayEventOverflowStrategy) {
/* 230 */       this.replayEventOverflowStrategy = Objects.<FluxSink.OverflowStrategy>requireNonNull(replayEventOverflowStrategy);
/* 231 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder replayEventFilter(Predicate<Event> replayEventFilter) {
/* 241 */       this.replayEventFilter = Objects.<Predicate<Event>>requireNonNull(replayEventFilter);
/* 242 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder timedTaskScheduler(Scheduler timedTaskScheduler) {
/* 252 */       this.timedTaskScheduler = Objects.<Scheduler>requireNonNull(timedTaskScheduler);
/* 253 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder stopReplayingTrigger(Publisher<?> stopReplayingTrigger) {
/* 266 */       this.stopReplayingTrigger = Objects.<Publisher>requireNonNull(stopReplayingTrigger);
/* 267 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public EventDispatcher build() {
/* 272 */       if (this.eventProcessor == null) {
/* 273 */         this.eventProcessor = (FluxProcessor<Event, Event>)EmitterProcessor.create(Queues.SMALL_BUFFER_SIZE, false);
/*     */       }
/* 275 */       if (this.eventScheduler == null) {
/* 276 */         this.eventScheduler = EventDispatcher.DEFAULT_EVENT_SCHEDULER.get();
/*     */       }
/* 278 */       if (this.timedTaskScheduler == null) {
/* 279 */         this.timedTaskScheduler = Schedulers.parallel();
/*     */       }
/* 281 */       if (this.replayEventProcessor == null) {
/* 282 */         this.replayEventProcessor = ReplayProcessor.createTimeout(Duration.ofMinutes(2L), this.timedTaskScheduler);
/*     */       }
/* 284 */       if (this.stopReplayingTrigger == null) {
/* 285 */         this.stopReplayingTrigger = (Publisher<?>)Mono.delay(Duration.ofSeconds(5L), this.timedTaskScheduler);
/*     */       }
/* 287 */       return new ReplayingEventDispatcher(this.eventProcessor, this.overflowStrategy, this.eventScheduler, this.replayEventProcessor, this.replayEventOverflowStrategy, this.replayEventFilter, this.timedTaskScheduler, this.stopReplayingTrigger);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\event\ReplayingEventDispatcher.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */