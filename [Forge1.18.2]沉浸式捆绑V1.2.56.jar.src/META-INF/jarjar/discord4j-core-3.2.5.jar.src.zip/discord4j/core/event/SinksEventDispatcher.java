/*     */ package discord4j.core.event;
/*     */ 
/*     */ import discord4j.common.LogUtil;
/*     */ import discord4j.common.annotations.Experimental;
/*     */ import discord4j.common.sinks.EmissionStrategy;
/*     */ import discord4j.core.event.domain.Event;
/*     */ import java.time.Duration;
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.atomic.AtomicReference;
/*     */ import java.util.function.Function;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.SignalType;
/*     */ import reactor.core.publisher.Sinks;
/*     */ import reactor.core.publisher.SynchronousSink;
/*     */ import reactor.core.scheduler.Scheduler;
/*     */ import reactor.util.Logger;
/*     */ import reactor.util.Loggers;
/*     */ import reactor.util.concurrent.Queues;
/*     */ import reactor.util.context.ContextView;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Experimental
/*     */ public class SinksEventDispatcher
/*     */   implements EventDispatcher
/*     */ {
/*  47 */   private static final Logger log = Loggers.getLogger(SinksEventDispatcher.class);
/*     */ 
/*     */ 
/*     */   
/*     */   private final Sinks.Many<Event> events;
/*     */ 
/*     */ 
/*     */   
/*     */   private final EmissionStrategy emissionStrategy;
/*     */ 
/*     */   
/*     */   private final Scheduler eventScheduler;
/*     */ 
/*     */ 
/*     */   
/*     */   public SinksEventDispatcher(Function<Sinks.ManySpec, Sinks.Many<Event>> eventSinkFactory, EmissionStrategy emissionStrategy, Scheduler eventScheduler) {
/*  63 */     this.events = eventSinkFactory.apply(Sinks.many());
/*  64 */     this.emissionStrategy = emissionStrategy;
/*  65 */     this.eventScheduler = eventScheduler;
/*     */   }
/*     */ 
/*     */   
/*     */   public <E extends Event> Flux<E> on(Class<E> eventClass) {
/*  70 */     AtomicReference<Subscription> subscription = new AtomicReference<>();
/*  71 */     return this.events.asFlux()
/*  72 */       .publishOn(this.eventScheduler)
/*  73 */       .ofType(eventClass)
/*  74 */       .handle((event, sink) -> {
/*     */           if (log.isTraceEnabled()) {
/*     */             log.trace(LogUtil.format((ContextView)sink.currentContext().put("discord4j.shard", Integer.valueOf(event.getShardInfo().getIndex())), "{}"), new Object[] { event.toString() });
/*     */           }
/*     */ 
/*     */           
/*     */           sink.next(event);
/*  81 */         }).doOnSubscribe(sub -> {
/*     */           subscription.set(sub);
/*     */ 
/*     */           
/*     */           if (log.isDebugEnabled()) {
/*     */             log.debug("Subscription {} to {} created", new Object[] { Integer.toHexString(sub.hashCode()), eventClass.getSimpleName() });
/*     */           }
/*  88 */         }).doFinally(signal -> {
/*     */           if (log.isDebugEnabled()) {
/*     */             log.debug("Subscription {} to {} disposed due to {}", new Object[] { Integer.toHexString(((Subscription)subscription.get()).hashCode()), eventClass.getSimpleName(), signal });
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void publish(Event event) {
/*  98 */     this.emissionStrategy.emitNext(this.events, event);
/*     */   }
/*     */ 
/*     */   
/*     */   public void shutdown() {
/* 103 */     this.emissionStrategy.emitComplete(this.events);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Builder
/*     */   {
/*     */     protected Function<Sinks.ManySpec, Sinks.Many<Event>> eventSinkFactory;
/*     */ 
/*     */ 
/*     */     
/*     */     protected EmissionStrategy emissionStrategy;
/*     */ 
/*     */ 
/*     */     
/*     */     protected Scheduler eventScheduler;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder eventSink(Function<Sinks.ManySpec, Sinks.Many<Event>> eventSinkFactory) {
/* 126 */       this.eventSinkFactory = Objects.<Function<Sinks.ManySpec, Sinks.Many<Event>>>requireNonNull(eventSinkFactory);
/* 127 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder emissionStrategy(EmissionStrategy emissionStrategy) {
/* 139 */       this.emissionStrategy = Objects.<EmissionStrategy>requireNonNull(emissionStrategy);
/* 140 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder eventScheduler(Scheduler eventScheduler) {
/* 151 */       this.eventScheduler = Objects.<Scheduler>requireNonNull(eventScheduler);
/* 152 */       return this;
/*     */     }
/*     */     
/*     */     public EventDispatcher build() {
/* 156 */       if (this.eventSinkFactory == null) {
/* 157 */         this.eventSinkFactory = (spec -> spec.multicast().onBackpressureBuffer(Queues.SMALL_BUFFER_SIZE, false));
/*     */       }
/* 159 */       if (this.emissionStrategy == null) {
/* 160 */         this.emissionStrategy = (EmissionStrategy)EmissionStrategy.timeoutDrop(Duration.ofSeconds(10L));
/*     */       }
/* 162 */       if (this.eventScheduler == null) {
/* 163 */         this.eventScheduler = EventDispatcher.DEFAULT_EVENT_SCHEDULER.get();
/*     */       }
/* 165 */       return new SinksEventDispatcher(this.eventSinkFactory, this.emissionStrategy, this.eventScheduler);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\event\SinksEventDispatcher.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */