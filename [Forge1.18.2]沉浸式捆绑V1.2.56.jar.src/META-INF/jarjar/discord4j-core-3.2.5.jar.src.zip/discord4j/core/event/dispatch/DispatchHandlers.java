/*     */ package discord4j.core.event.dispatch;
/*     */ import discord4j.common.store.api.object.PresenceAndUserData;
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.GatewayDiscordClient;
/*     */ import discord4j.core.event.domain.AuditLogEntryCreateEvent;
/*     */ import discord4j.core.event.domain.Event;
/*     */ import discord4j.core.event.domain.InviteCreateEvent;
/*     */ import discord4j.core.event.domain.InviteDeleteEvent;
/*     */ import discord4j.core.event.domain.PresenceUpdateEvent;
/*     */ import discord4j.core.event.domain.UserUpdateEvent;
/*     */ import discord4j.core.event.domain.VoiceStateUpdateEvent;
/*     */ import discord4j.core.event.domain.automod.AutoModActionExecutedEvent;
/*     */ import discord4j.core.event.domain.automod.AutoModRuleCreateEvent;
/*     */ import discord4j.core.event.domain.automod.AutoModRuleDeleteEvent;
/*     */ import discord4j.core.event.domain.automod.AutoModRuleUpdateEvent;
/*     */ import discord4j.core.event.domain.channel.TypingStartEvent;
/*     */ import discord4j.core.event.domain.integration.IntegrationCreateEvent;
/*     */ import discord4j.core.event.domain.integration.IntegrationDeleteEvent;
/*     */ import discord4j.core.event.domain.integration.IntegrationUpdateEvent;
/*     */ import discord4j.core.event.domain.interaction.InteractionCreateEvent;
/*     */ import discord4j.core.event.domain.interaction.SelectMenuInteractionEvent;
/*     */ import discord4j.core.object.VoiceState;
/*     */ import discord4j.core.object.audit.AuditLogEntry;
/*     */ import discord4j.core.object.automod.AutoModRule;
/*     */ import discord4j.core.object.command.ApplicationCommand;
/*     */ import discord4j.core.object.command.ApplicationCommandInteraction;
/*     */ import discord4j.core.object.command.Interaction;
/*     */ import discord4j.core.object.component.MessageComponent;
/*     */ import discord4j.core.object.entity.Integration;
/*     */ import discord4j.core.object.entity.Member;
/*     */ import discord4j.core.object.entity.User;
/*     */ import discord4j.core.object.presence.Presence;
/*     */ import discord4j.discordjson.json.MemberData;
/*     */ import discord4j.discordjson.json.PartialUserData;
/*     */ import discord4j.discordjson.json.PresenceData;
/*     */ import discord4j.discordjson.json.UserData;
/*     */ import discord4j.discordjson.json.VoiceStateData;
/*     */ import discord4j.discordjson.json.gateway.AuditLogEntryCreate;
/*     */ import discord4j.discordjson.json.gateway.AutoModActionExecution;
/*     */ import discord4j.discordjson.json.gateway.AutoModRuleCreate;
/*     */ import discord4j.discordjson.json.gateway.AutoModRuleDelete;
/*     */ import discord4j.discordjson.json.gateway.AutoModRuleUpdate;
/*     */ import discord4j.discordjson.json.gateway.GuildMemberRemove;
/*     */ import discord4j.discordjson.json.gateway.GuildScheduledEventUserAdd;
/*     */ import discord4j.discordjson.json.gateway.IntegrationCreate;
/*     */ import discord4j.discordjson.json.gateway.IntegrationDelete;
/*     */ import discord4j.discordjson.json.gateway.IntegrationUpdate;
/*     */ import discord4j.discordjson.json.gateway.InteractionCreate;
/*     */ import discord4j.discordjson.json.gateway.InviteCreate;
/*     */ import discord4j.discordjson.json.gateway.InviteDelete;
/*     */ import discord4j.discordjson.json.gateway.PresenceUpdate;
/*     */ import discord4j.discordjson.json.gateway.TypingStart;
/*     */ import discord4j.discordjson.json.gateway.UserUpdate;
/*     */ import discord4j.discordjson.json.gateway.VoiceServerUpdate;
/*     */ import discord4j.discordjson.json.gateway.VoiceStateUpdateDispatch;
/*     */ import discord4j.discordjson.json.gateway.WebhooksUpdate;
/*     */ import java.time.Instant;
/*     */ import java.util.Map;
/*     */ import java.util.function.Supplier;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ public class DispatchHandlers implements DispatchEventMapper {
/*  63 */   private static final Map<Class<?>, DispatchHandler<?, ?, ?>> handlerMap = new HashMap<>();
/*     */   
/*     */   static {
/*  66 */     addHandler(ChannelCreate.class, ChannelDispatchHandlers::channelCreate);
/*  67 */     addHandler(ChannelDelete.class, ChannelDispatchHandlers::channelDelete);
/*  68 */     addHandler(ChannelPinsUpdate.class, ChannelDispatchHandlers::channelPinsUpdate);
/*  69 */     addHandler(ChannelUpdate.class, ChannelDispatchHandlers::channelUpdate);
/*  70 */     addHandler(AuditLogEntryCreate.class, DispatchHandlers::auditLogEntryCreate);
/*  71 */     addHandler(GuildBanAdd.class, GuildDispatchHandlers::guildBanAdd);
/*  72 */     addHandler(GuildBanRemove.class, GuildDispatchHandlers::guildBanRemove);
/*  73 */     addHandler(GuildCreate.class, GuildDispatchHandlers::guildCreate);
/*  74 */     addHandler(GuildDelete.class, GuildDispatchHandlers::guildDelete);
/*  75 */     addHandler(GuildEmojisUpdate.class, GuildDispatchHandlers::guildEmojisUpdate);
/*  76 */     addHandler(GuildIntegrationsUpdate.class, GuildDispatchHandlers::guildIntegrationsUpdate);
/*  77 */     addHandler(GuildMemberAdd.class, GuildDispatchHandlers::guildMemberAdd);
/*  78 */     addHandler(GuildMemberRemove.class, GuildDispatchHandlers::guildMemberRemove);
/*  79 */     addHandler(GuildMembersChunk.class, GuildDispatchHandlers::guildMembersChunk);
/*  80 */     addHandler(GuildMemberUpdate.class, GuildDispatchHandlers::guildMemberUpdate);
/*  81 */     addHandler(GuildRoleCreate.class, GuildDispatchHandlers::guildRoleCreate);
/*  82 */     addHandler(GuildRoleDelete.class, GuildDispatchHandlers::guildRoleDelete);
/*  83 */     addHandler(GuildRoleUpdate.class, GuildDispatchHandlers::guildRoleUpdate);
/*  84 */     addHandler(GuildScheduledEventCreate.class, GuildDispatchHandlers::scheduledEventCreate);
/*  85 */     addHandler(GuildScheduledEventUpdate.class, GuildDispatchHandlers::scheduledEventUpdate);
/*  86 */     addHandler(GuildScheduledEventDelete.class, GuildDispatchHandlers::scheduledEventDelete);
/*  87 */     addHandler(GuildScheduledEventUserAdd.class, GuildDispatchHandlers::scheduledEventUserAdd);
/*  88 */     addHandler(GuildScheduledEventUserRemove.class, GuildDispatchHandlers::scheduledEventUserRemove);
/*  89 */     addHandler(GuildUpdate.class, GuildDispatchHandlers::guildUpdate);
/*  90 */     addHandler(MessageCreate.class, MessageDispatchHandlers::messageCreate);
/*  91 */     addHandler(MessageDelete.class, MessageDispatchHandlers::messageDelete);
/*  92 */     addHandler(MessageDeleteBulk.class, MessageDispatchHandlers::messageDeleteBulk);
/*  93 */     addHandler(MessageReactionAdd.class, MessageDispatchHandlers::messageReactionAdd);
/*  94 */     addHandler(MessageReactionRemove.class, MessageDispatchHandlers::messageReactionRemove);
/*  95 */     addHandler(MessageReactionRemoveEmoji.class, MessageDispatchHandlers::messageReactionRemoveEmoji);
/*  96 */     addHandler(MessageReactionRemoveAll.class, MessageDispatchHandlers::messageReactionRemoveAll);
/*  97 */     addHandler(MessageUpdate.class, MessageDispatchHandlers::messageUpdate);
/*  98 */     addHandler(PresenceUpdate.class, DispatchHandlers::presenceUpdate);
/*  99 */     addHandler(Ready.class, LifecycleDispatchHandlers::ready);
/* 100 */     addHandler(Resumed.class, LifecycleDispatchHandlers::resumed);
/* 101 */     addHandler(TypingStart.class, DispatchHandlers::typingStart);
/* 102 */     addHandler(UserUpdate.class, DispatchHandlers::userUpdate);
/* 103 */     addHandler(VoiceServerUpdate.class, DispatchHandlers::voiceServerUpdate);
/* 104 */     addHandler(VoiceStateUpdateDispatch.class, DispatchHandlers::voiceStateUpdateDispatch);
/* 105 */     addHandler(WebhooksUpdate.class, DispatchHandlers::webhooksUpdate);
/* 106 */     addHandler(InviteCreate.class, DispatchHandlers::inviteCreate);
/* 107 */     addHandler(InviteDelete.class, DispatchHandlers::inviteDelete);
/* 108 */     addHandler(InteractionCreate.class, DispatchHandlers::interactionCreate);
/* 109 */     addHandler(ApplicationCommandCreate.class, ApplicationCommandDispatchHandlers::applicationCommandCreate);
/* 110 */     addHandler(ApplicationCommandUpdate.class, ApplicationCommandDispatchHandlers::applicationCommandUpdate);
/* 111 */     addHandler(ApplicationCommandDelete.class, ApplicationCommandDispatchHandlers::applicationCommandDelete);
/* 112 */     addHandler(ApplicationCommandPermissionUpdate.class, ApplicationCommandDispatchHandlers::applicationCommandPermissionUpdate);
/* 113 */     addHandler(IntegrationCreate.class, DispatchHandlers::integrationCreate);
/* 114 */     addHandler(IntegrationUpdate.class, DispatchHandlers::integrationUpdate);
/* 115 */     addHandler(IntegrationDelete.class, DispatchHandlers::integrationDelete);
/* 116 */     addHandler(AutoModRuleCreate.class, DispatchHandlers::autoModRuleCreate);
/* 117 */     addHandler(AutoModRuleUpdate.class, DispatchHandlers::autoModRuleUpdate);
/* 118 */     addHandler(AutoModRuleDelete.class, DispatchHandlers::autoModRuleDelete);
/* 119 */     addHandler(AutoModActionExecution.class, DispatchHandlers::autoModActionExecute);
/*     */     
/* 121 */     addHandler(GatewayStateChange.class, LifecycleDispatchHandlers::gatewayStateChanged);
/*     */     
/* 123 */     addHandler(UnavailableGuildCreate.class, context -> Mono.empty());
/*     */   }
/*     */ 
/*     */   
/*     */   private static <D, S, E extends Event> void addHandler(Class<D> dispatchType, DispatchHandler<D, S, E> dispatchHandler) {
/* 128 */     handlerMap.put(dispatchType, dispatchHandler);
/*     */   }
/*     */   
/* 131 */   private static final Logger log = Loggers.getLogger(DispatchHandlers.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <D, S, E extends Event> Mono<E> handle(DispatchContext<D, S> context) {
/* 149 */     DispatchHandler<D, S, E> handler = handlerMap.entrySet().stream().filter(entry -> ((Class)entry.getKey()).isAssignableFrom(context.getDispatch().getClass())).map(Map.Entry::getValue).findFirst().orElse(null);
/* 150 */     if (handler == null) {
/* 151 */       log.warn("Handler not found from: {}", new Object[] { context.getDispatch().getClass() });
/* 152 */       return Mono.empty();
/*     */     } 
/* 154 */     return Mono.defer(() -> handler.handle(context))
/* 155 */       .checkpoint("Dispatch handled for " + context.getDispatch().getClass());
/*     */   }
/*     */   
/*     */   private static Mono<PresenceUpdateEvent> presenceUpdate(DispatchContext<PresenceUpdate, PresenceAndUserData> context) {
/* 159 */     GatewayDiscordClient gateway = context.getGateway();
/*     */     
/* 161 */     long guildId = Snowflake.asLong(((PresenceUpdate)context.getDispatch()).guildId());
/* 162 */     PartialUserData userData = ((PresenceUpdate)context.getDispatch()).user();
/* 163 */     PresenceData presenceData = createPresence(context.getDispatch());
/* 164 */     Presence current = new Presence(presenceData);
/*     */ 
/*     */ 
/*     */     
/* 168 */     Presence oldPresence = context.getOldState().flatMap(PresenceAndUserData::getPresenceData).map(Presence::new).orElse(null);
/*     */ 
/*     */ 
/*     */     
/* 172 */     User oldUser = context.getOldState().flatMap(PresenceAndUserData::getUserData).map(old -> new User(gateway, old)).orElse(null);
/*     */     
/* 174 */     return Mono.just(new PresenceUpdateEvent(gateway, context.getShardInfo(), guildId, oldUser, userData, current, oldPresence));
/*     */   }
/*     */   
/*     */   private static PresenceData createPresence(PresenceUpdate update) {
/* 178 */     return (PresenceData)PresenceData.builder()
/* 179 */       .user(update.user())
/* 180 */       .status(update.status())
/* 181 */       .activities(update.activities())
/* 182 */       .clientStatus(update.clientStatus())
/* 183 */       .build();
/*     */   }
/*     */   
/*     */   private static Mono<TypingStartEvent> typingStart(DispatchContext<TypingStart, Void> context) {
/* 187 */     long channelId = Snowflake.asLong(((TypingStart)context.getDispatch()).channelId());
/* 188 */     Long guildId = ((TypingStart)context.getDispatch()).guildId().toOptional().map(Snowflake::asLong).orElse(null);
/* 189 */     long userId = Snowflake.asLong(((TypingStart)context.getDispatch()).userId());
/* 190 */     Instant startTime = Instant.ofEpochSecond(((TypingStart)context.getDispatch()).timestamp());
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 195 */     Member member = ((TypingStart)context.getDispatch()).member().toOptional().filter(__ -> (guildId != null)).map(memberData -> new Member(context.getGateway(), memberData, guildId.longValue())).orElse(null);
/*     */     
/* 197 */     return Mono.just(new TypingStartEvent(context.getGateway(), context.getShardInfo(), channelId, guildId, userId, startTime, member));
/*     */   }
/*     */ 
/*     */   
/*     */   private static Mono<UserUpdateEvent> userUpdate(DispatchContext<UserUpdate, UserData> context) {
/* 202 */     GatewayDiscordClient gateway = context.getGateway();
/* 203 */     UserData userData = ((UserUpdate)context.getDispatch()).user();
/* 204 */     User current = new User(gateway, userData);
/*     */     
/* 206 */     return Mono.just(new UserUpdateEvent(gateway, context.getShardInfo(), current, context.getOldState()
/* 207 */           .map(old -> new User(gateway, old)).orElse(null)));
/*     */   }
/*     */   
/*     */   private static Mono<Event> voiceServerUpdate(DispatchContext<VoiceServerUpdate, Void> context) {
/* 211 */     String token = ((VoiceServerUpdate)context.getDispatch()).token();
/* 212 */     long guildId = Snowflake.asLong(((VoiceServerUpdate)context.getDispatch()).guildId());
/* 213 */     String endpoint = ((VoiceServerUpdate)context.getDispatch()).endpoint();
/*     */     
/* 215 */     return Mono.just(new VoiceServerUpdateEvent(context.getGateway(), context.getShardInfo(), token, guildId, endpoint));
/*     */   }
/*     */ 
/*     */   
/*     */   private static Mono<VoiceStateUpdateEvent> voiceStateUpdateDispatch(DispatchContext<VoiceStateUpdateDispatch, VoiceStateData> context) {
/* 220 */     GatewayDiscordClient gateway = context.getGateway();
/* 221 */     VoiceStateData voiceStateData = ((VoiceStateUpdateDispatch)context.getDispatch()).voiceState();
/*     */     
/* 223 */     VoiceState current = new VoiceState(gateway, voiceStateData);
/*     */     
/* 225 */     return Mono.just(new VoiceStateUpdateEvent(gateway, context.getShardInfo(), current, context.getOldState()
/* 226 */           .map(old -> new VoiceState(gateway, old)).orElse(null)));
/*     */   }
/*     */   
/*     */   private static Mono<Event> webhooksUpdate(DispatchContext<WebhooksUpdate, Void> context) {
/* 230 */     long guildId = Snowflake.asLong(((WebhooksUpdate)context.getDispatch()).guildId());
/* 231 */     long channelId = Snowflake.asLong(((WebhooksUpdate)context.getDispatch()).channelId());
/*     */     
/* 233 */     return Mono.just(new WebhooksUpdateEvent(context.getGateway(), context.getShardInfo(), guildId, channelId));
/*     */   }
/*     */   
/*     */   private static Mono<AuditLogEntryCreateEvent> auditLogEntryCreate(DispatchContext<AuditLogEntryCreate, Void> context) {
/* 237 */     long guildId = Snowflake.asLong(((AuditLogEntryCreate)context.getDispatch()).guildId());
/* 238 */     AuditLogEntry auditLogEntry = new AuditLogEntry(context.getGateway(), (AuditLogEntryData)context.getDispatch());
/*     */     
/* 240 */     return Mono.just(new AuditLogEntryCreateEvent(context.getGateway(), context.getShardInfo(), guildId, auditLogEntry));
/*     */   }
/*     */   
/*     */   private static Mono<InviteCreateEvent> inviteCreate(DispatchContext<InviteCreate, Void> context) {
/* 244 */     long guildId = Snowflake.asLong(((InviteCreate)context.getDispatch()).guildId());
/* 245 */     long channelId = Snowflake.asLong(((InviteCreate)context.getDispatch()).channelId());
/* 246 */     String code = ((InviteCreate)context.getDispatch()).code();
/*     */     
/* 248 */     Instant createdAt = DateTimeFormatter.ISO_OFFSET_DATE_TIME.<Instant>parse(((InviteCreate)context.getDispatch()).createdAt(), Instant::from);
/* 249 */     int uses = ((InviteCreate)context.getDispatch()).uses();
/* 250 */     int maxUses = ((InviteCreate)context.getDispatch()).maxUses();
/* 251 */     int maxAge = ((InviteCreate)context.getDispatch()).maxAge();
/* 252 */     boolean temporary = ((InviteCreate)context.getDispatch()).temporary();
/*     */ 
/*     */ 
/*     */     
/* 256 */     User current = ((InviteCreate)context.getDispatch()).inviter().toOptional().map(userData -> new User(context.getGateway(), userData)).orElse(null);
/*     */     
/* 258 */     return Mono.just(new InviteCreateEvent(context.getGateway(), context.getShardInfo(), Long.valueOf(guildId), channelId, code, current, createdAt, uses, maxUses, maxAge, temporary));
/*     */   }
/*     */ 
/*     */   
/*     */   private static Mono<InviteDeleteEvent> inviteDelete(DispatchContext<InviteDelete, Void> context) {
/* 263 */     long guildId = Snowflake.asLong(((InviteDelete)context.getDispatch()).guildId());
/* 264 */     long channelId = Snowflake.asLong(((InviteDelete)context.getDispatch()).channelId());
/* 265 */     String code = ((InviteDelete)context.getDispatch()).code();
/*     */     
/* 267 */     return Mono.just(new InviteDeleteEvent(context.getGateway(), context.getShardInfo(), Long.valueOf(guildId), channelId, code));
/*     */   } private static Mono<InteractionCreateEvent> interactionCreate(DispatchContext<InteractionCreate, Void> context) {
/*     */     ApplicationCommand.Type commandType;
/*     */     MessageComponent.Type componentType;
/* 271 */     GatewayDiscordClient gateway = context.getGateway();
/* 272 */     Interaction interaction = new Interaction(gateway, ((InteractionCreate)context.getDispatch()).interaction());
/*     */     
/* 274 */     switch (interaction.getType()) {
/*     */ 
/*     */       
/*     */       case APPLICATION_COMMAND:
/* 278 */         commandType = (ApplicationCommand.Type)interaction.getCommandInteraction().flatMap(ApplicationCommandInteraction::getApplicationCommandType).orElseThrow(IllegalStateException::new);
/*     */         
/* 280 */         switch (commandType) {
/*     */           case APPLICATION_COMMAND:
/* 282 */             return Mono.just(new ChatInputInteractionEvent(gateway, context.getShardInfo(), interaction));
/*     */           case MESSAGE_COMPONENT:
/* 284 */             return Mono.just(new MessageInteractionEvent(gateway, context.getShardInfo(), interaction));
/*     */           case APPLICATION_COMMAND_AUTOCOMPLETE:
/* 286 */             return Mono.just(new UserInteractionEvent(gateway, context.getShardInfo(), interaction));
/*     */         } 
/* 288 */         return Mono.just(new ApplicationCommandInteractionEvent(gateway, context
/* 289 */               .getShardInfo(), interaction));
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case MESSAGE_COMPONENT:
/* 295 */         componentType = (MessageComponent.Type)interaction.getCommandInteraction().flatMap(ApplicationCommandInteraction::getComponentType).orElseThrow(IllegalStateException::new);
/*     */         
/* 297 */         switch (componentType) {
/*     */           case APPLICATION_COMMAND:
/* 299 */             return Mono.just(new ButtonInteractionEvent(gateway, context.getShardInfo(), interaction));
/*     */           case MESSAGE_COMPONENT:
/*     */           case APPLICATION_COMMAND_AUTOCOMPLETE:
/*     */           case MODAL_SUBMIT:
/*     */           case null:
/*     */           case null:
/* 305 */             return Mono.just(new SelectMenuInteractionEvent(gateway, context.getShardInfo(), interaction));
/*     */         } 
/* 307 */         return Mono.just(new ComponentInteractionEvent(gateway, context.getShardInfo(), interaction));
/*     */ 
/*     */       
/*     */       case APPLICATION_COMMAND_AUTOCOMPLETE:
/* 311 */         return Mono.just(new ChatInputAutoCompleteEvent(gateway, context.getShardInfo(), interaction));
/*     */       case MODAL_SUBMIT:
/* 313 */         return Mono.just(new ModalSubmitInteractionEvent(gateway, context.getShardInfo(), interaction));
/*     */     } 
/* 315 */     return Mono.just(new InteractionCreateEvent(gateway, context.getShardInfo(), interaction));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static Mono<IntegrationDeleteEvent> integrationDelete(DispatchContext<IntegrationDelete, Void> context) {
/* 321 */     long guildId = Snowflake.asLong(((IntegrationDelete)context.getDispatch()).guildId());
/* 322 */     long id = Snowflake.asLong(((IntegrationDelete)context.getDispatch()).id());
/* 323 */     Long applicationId = ((IntegrationDelete)context.getDispatch()).applicationId().toOptional().map(Snowflake::asLong).orElse(null);
/*     */     
/* 325 */     return Mono.just(new IntegrationDeleteEvent(context.getGateway(), context.getShardInfo(), id, guildId, applicationId));
/*     */   }
/*     */ 
/*     */   
/*     */   private static Mono<IntegrationUpdateEvent> integrationUpdate(DispatchContext<IntegrationUpdate, Void> context) {
/* 330 */     long guildId = Snowflake.asLong(((IntegrationUpdate)context.getDispatch()).guildId());
/* 331 */     Integration integration = new Integration(context.getGateway(), ((IntegrationUpdate)context.getDispatch()).integration(), guildId);
/*     */     
/* 333 */     return Mono.just(new IntegrationUpdateEvent(context.getGateway(), context.getShardInfo(), guildId, integration));
/*     */   }
/*     */ 
/*     */   
/*     */   private static Mono<IntegrationCreateEvent> integrationCreate(DispatchContext<IntegrationCreate, Void> context) {
/* 338 */     long guildId = Snowflake.asLong(((IntegrationCreate)context.getDispatch()).guildId());
/* 339 */     Integration integration = new Integration(context.getGateway(), ((IntegrationCreate)context.getDispatch()).integration(), guildId);
/*     */     
/* 341 */     return Mono.just(new IntegrationCreateEvent(context.getGateway(), context.getShardInfo(), guildId, integration));
/*     */   }
/*     */   
/*     */   private static Mono<AutoModRuleCreateEvent> autoModRuleCreate(DispatchContext<AutoModRuleCreate, Void> context) {
/* 345 */     AutoModRule autoModRule = new AutoModRule(context.getGateway(), ((AutoModRuleCreate)context.getDispatch()).automodrule());
/*     */     
/* 347 */     return Mono.just(new AutoModRuleCreateEvent(context.getGateway(), context.getShardInfo(), autoModRule));
/*     */   }
/*     */   
/*     */   private static Mono<AutoModRuleUpdateEvent> autoModRuleUpdate(DispatchContext<AutoModRuleUpdate, Void> context) {
/* 351 */     AutoModRule autoModRule = new AutoModRule(context.getGateway(), ((AutoModRuleUpdate)context.getDispatch()).automodrule());
/*     */     
/* 353 */     return Mono.just(new AutoModRuleUpdateEvent(context.getGateway(), context.getShardInfo(), autoModRule));
/*     */   }
/*     */   
/*     */   private static Mono<AutoModRuleDeleteEvent> autoModRuleDelete(DispatchContext<AutoModRuleDelete, Void> context) {
/* 357 */     AutoModRule autoModRule = new AutoModRule(context.getGateway(), ((AutoModRuleDelete)context.getDispatch()).automodrule());
/*     */     
/* 359 */     return Mono.just(new AutoModRuleDeleteEvent(context.getGateway(), context.getShardInfo(), autoModRule));
/*     */   }
/*     */   
/*     */   private static Mono<AutoModActionExecutedEvent> autoModActionExecute(DispatchContext<AutoModActionExecution, Void> context) {
/* 363 */     return Mono.just(new AutoModActionExecutedEvent(context.getGateway(), context.getShardInfo(), context.getDispatch()));
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\event\dispatch\DispatchHandlers.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */