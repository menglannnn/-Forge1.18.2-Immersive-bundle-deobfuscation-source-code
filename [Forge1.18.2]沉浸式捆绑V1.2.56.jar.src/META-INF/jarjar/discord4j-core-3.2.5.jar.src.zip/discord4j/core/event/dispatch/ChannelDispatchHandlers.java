/*     */ package discord4j.core.event.dispatch;
/*     */ import discord4j.core.GatewayDiscordClient;
/*     */ import discord4j.core.event.domain.Event;
/*     */ import discord4j.core.event.domain.channel.CategoryCreateEvent;
/*     */ import discord4j.core.event.domain.channel.CategoryUpdateEvent;
/*     */ import discord4j.core.event.domain.channel.ChannelEvent;
/*     */ import discord4j.core.event.domain.channel.NewsChannelUpdateEvent;
/*     */ import discord4j.core.event.domain.channel.PinsUpdateEvent;
/*     */ import discord4j.core.event.domain.channel.PrivateChannelDeleteEvent;
/*     */ import discord4j.core.event.domain.channel.StoreChannelCreateEvent;
/*     */ import discord4j.core.event.domain.channel.StoreChannelDeleteEvent;
/*     */ import discord4j.core.event.domain.channel.TextChannelCreateEvent;
/*     */ import discord4j.core.event.domain.channel.TextChannelDeleteEvent;
/*     */ import discord4j.core.event.domain.channel.TextChannelUpdateEvent;
/*     */ import discord4j.core.event.domain.channel.UnknownChannelCreateEvent;
/*     */ import discord4j.core.event.domain.channel.UnknownChannelDeleteEvent;
/*     */ import discord4j.core.event.domain.channel.UnknownChannelUpdateEvent;
/*     */ import discord4j.core.event.domain.channel.VoiceChannelCreateEvent;
/*     */ import discord4j.core.event.domain.channel.VoiceChannelDeleteEvent;
/*     */ import discord4j.core.object.entity.channel.Category;
/*     */ import discord4j.core.object.entity.channel.Channel;
/*     */ import discord4j.core.object.entity.channel.GuildMessageChannel;
/*     */ import discord4j.core.object.entity.channel.NewsChannel;
/*     */ import discord4j.core.object.entity.channel.PrivateChannel;
/*     */ import discord4j.core.object.entity.channel.StoreChannel;
/*     */ import discord4j.core.object.entity.channel.TextChannel;
/*     */ import discord4j.core.object.entity.channel.UnknownChannel;
/*     */ import discord4j.core.object.entity.channel.VoiceChannel;
/*     */ import discord4j.discordjson.json.ChannelData;
/*     */ import discord4j.discordjson.json.gateway.ChannelCreate;
/*     */ import discord4j.discordjson.json.gateway.ChannelDelete;
/*     */ import discord4j.discordjson.json.gateway.ChannelPinsUpdate;
/*     */ import discord4j.discordjson.json.gateway.ChannelUpdate;
/*     */ import java.time.Instant;
/*     */ import java.time.format.DateTimeFormatter;
/*     */ import java.util.Optional;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ class ChannelDispatchHandlers {
/*  40 */   private static final Logger log = Loggers.getLogger(ChannelDispatchHandlers.class);
/*     */   
/*     */   static Mono<? extends Event> channelCreate(DispatchContext<ChannelCreate, Void> context) {
/*  43 */     Channel.Type type = Channel.Type.of(((ChannelCreate)context.getDispatch()).channel().type());
/*     */     
/*  45 */     GatewayDiscordClient gateway = context.getGateway();
/*  46 */     ChannelData channel = ((ChannelCreate)context.getDispatch()).channel();
/*     */     
/*  48 */     return Mono.fromCallable(() -> {
/*     */           switch (type) {
/*     */             case GUILD_TEXT:
/*     */               return (ChannelEvent)new TextChannelCreateEvent(gateway, context.getShardInfo(), new TextChannel(gateway, channel));
/*     */             case GUILD_VOICE:
/*     */             case GUILD_STAGE_VOICE:
/*     */               return (ChannelEvent)new VoiceChannelCreateEvent(gateway, context.getShardInfo(), new VoiceChannel(gateway, channel));
/*     */             case GROUP_DM:
/*     */               throw new UnsupportedOperationException("Received channel_create for group on a bot account!");
/*     */             case GUILD_CATEGORY:
/*     */               return (ChannelEvent)new CategoryCreateEvent(gateway, context.getShardInfo(), new Category(gateway, channel));
/*     */             case GUILD_NEWS:
/*     */               return (ChannelEvent)new NewsChannelCreateEvent(gateway, context.getShardInfo(), new NewsChannel(gateway, channel));
/*     */             case GUILD_STORE:
/*     */               return (ChannelEvent)new StoreChannelCreateEvent(gateway, context.getShardInfo(), new StoreChannel(gateway, channel));
/*     */           } 
/*     */           log.info("Received unknown channel create: {}", new Object[] { channel });
/*     */           return (ChannelEvent)new UnknownChannelCreateEvent(gateway, context.getShardInfo(), new UnknownChannel(gateway, channel));
/*     */         });
/*  67 */   } static Mono<? extends Event> channelDelete(DispatchContext<ChannelDelete, ChannelData> context) { Channel.Type type = Channel.Type.of(((ChannelDelete)context.getDispatch()).channel().type());
/*  68 */     GatewayDiscordClient gateway = context.getGateway();
/*  69 */     ChannelData channel = ((ChannelDelete)context.getDispatch()).channel();
/*     */     
/*  71 */     return Mono.fromCallable(() -> {
/*     */           switch (type) {
/*     */             case GUILD_TEXT:
/*     */               return (ChannelEvent)new TextChannelDeleteEvent(gateway, context.getShardInfo(), new TextChannel(gateway, channel));
/*     */             case DM:
/*     */               return (ChannelEvent)new PrivateChannelDeleteEvent(gateway, context.getShardInfo(), new PrivateChannel(gateway, channel));
/*     */             case GUILD_VOICE:
/*     */             case GUILD_STAGE_VOICE:
/*     */               return (ChannelEvent)new VoiceChannelDeleteEvent(gateway, context.getShardInfo(), new VoiceChannel(gateway, channel));
/*     */             case GROUP_DM:
/*     */               throw new UnsupportedOperationException("Received channel_delete for a group on a bot account!");
/*     */             case GUILD_CATEGORY:
/*     */               return (ChannelEvent)new CategoryDeleteEvent(gateway, context.getShardInfo(), new Category(gateway, channel));
/*     */             case GUILD_NEWS:
/*     */               return (ChannelEvent)new NewsChannelDeleteEvent(gateway, context.getShardInfo(), new NewsChannel(gateway, channel));
/*     */             case GUILD_STORE:
/*     */               return (ChannelEvent)new StoreChannelDeleteEvent(gateway, context.getShardInfo(), new StoreChannel(gateway, channel));
/*     */           } 
/*     */           log.info("Received unknown channel delete: {}", new Object[] { channel });
/*     */           return (ChannelEvent)new UnknownChannelDeleteEvent(gateway, context.getShardInfo(), new UnknownChannel(gateway, channel));
/*  91 */         }); } static Mono<PinsUpdateEvent> channelPinsUpdate(DispatchContext<ChannelPinsUpdate, Void> context) { long channelId = Snowflake.asLong(((ChannelPinsUpdate)context.getDispatch()).channelId());
/*     */ 
/*     */ 
/*     */     
/*  95 */     Long guildId = ((ChannelPinsUpdate)context.getDispatch()).guildId().toOptional().map(Snowflake::asLong).orElse(null);
/*     */ 
/*     */ 
/*     */     
/*  99 */     Instant timestamp = Possible.flatOpt(((ChannelPinsUpdate)context.getDispatch()).lastPinTimestamp()).map(text -> (Instant)DateTimeFormatter.ISO_OFFSET_DATE_TIME.<Instant>parse(text, Instant::from)).orElse(null);
/*     */     
/* 101 */     return Mono.just(new PinsUpdateEvent(context.getGateway(), context.getShardInfo(), channelId, guildId, timestamp)); }
/*     */ 
/*     */   
/*     */   static Mono<? extends Event> channelUpdate(DispatchContext<ChannelUpdate, ChannelData> context) {
/* 105 */     Channel.Type type = Channel.Type.of(((ChannelUpdate)context.getDispatch()).channel().type());
/* 106 */     GatewayDiscordClient gateway = context.getGateway();
/* 107 */     ChannelData channel = ((ChannelUpdate)context.getDispatch()).channel();
/* 108 */     Optional<ChannelData> oldData = context.getOldState();
/*     */     
/* 110 */     return Mono.fromCallable(() -> {
/*     */           switch (type) {
/*     */             case GUILD_TEXT:
/*     */               return (ChannelEvent)new TextChannelUpdateEvent(gateway, context.getShardInfo(), getConvertibleChannel(gateway, channel), oldData.map(()).orElse(null));
/*     */             case DM:
/*     */               throw new UnsupportedOperationException("Received channel_update for a DM on a bot account!");
/*     */             case GUILD_VOICE:
/*     */             case GUILD_STAGE_VOICE:
/*     */               return (ChannelEvent)new VoiceChannelUpdateEvent(gateway, context.getShardInfo(), new VoiceChannel(gateway, channel), oldData.map(()).orElse(null));
/*     */             case GROUP_DM:
/*     */               throw new UnsupportedOperationException("Received channel_update for a group on a bot account!");
/*     */             case GUILD_CATEGORY:
/*     */               return (ChannelEvent)new CategoryUpdateEvent(gateway, context.getShardInfo(), new Category(gateway, channel), oldData.map(()).orElse(null));
/*     */             case GUILD_NEWS:
/*     */               return (ChannelEvent)new NewsChannelUpdateEvent(gateway, context.getShardInfo(), getConvertibleChannel(gateway, channel), oldData.map(()).orElse(null));
/*     */             case GUILD_STORE:
/*     */               return (ChannelEvent)new StoreChannelUpdateEvent(gateway, context.getShardInfo(), new StoreChannel(gateway, channel), oldData.map(()).orElse(null));
/*     */           } 
/*     */           log.info("Received unknown channel update: {}", new Object[] { channel });
/*     */           return (ChannelEvent)new UnknownChannelUpdateEvent(gateway, context.getShardInfo(), new UnknownChannel(gateway, channel), oldData.map(()).orElse(null));
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static GuildMessageChannel getConvertibleChannel(GatewayDiscordClient gateway, ChannelData channel) {
/* 143 */     switch (Channel.Type.of(channel.type())) { case GUILD_NEWS:
/* 144 */         return (GuildMessageChannel)new NewsChannel(gateway, channel);
/* 145 */       case GUILD_TEXT: return (GuildMessageChannel)new TextChannel(gateway, channel); }
/* 146 */      throw new IllegalArgumentException("Unhandled channel type " + channel.type());
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\event\dispatch\ChannelDispatchHandlers.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */