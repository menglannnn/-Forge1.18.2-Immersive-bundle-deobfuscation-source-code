/*    */ package discord4j.core.event.dispatch;
/*    */ 
/*    */ import discord4j.common.annotations.Experimental;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @FunctionalInterface
/*    */ @Experimental
/*    */ public interface DispatchEventMapper
/*    */ {
/*    */   <D, S, E extends discord4j.core.event.domain.Event> Mono<E> handle(DispatchContext<D, S> paramDispatchContext);
/*    */   
/*    */   static DispatchEventMapper emitEvents() {
/* 50 */     return new DispatchHandlers();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static DispatchEventMapper discardEvents() {
/* 60 */     final DispatchHandlers handlers = new DispatchHandlers();
/* 61 */     return new DispatchEventMapper()
/*    */       {
/*    */         public <D, S, E extends discord4j.core.event.domain.Event> Mono<E> handle(DispatchContext<D, S> context)
/*    */         {
/* 65 */           return handlers.<D, S, E>handle(context).then(Mono.empty());
/*    */         }
/*    */       };
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static DispatchEventMapper noOp() {
/* 76 */     return new DispatchEventMapper()
/*    */       {
/*    */         public <D, S, E extends discord4j.core.event.domain.Event> Mono<E> handle(DispatchContext<D, S> context) {
/* 79 */           return Mono.empty();
/*    */         }
/*    */       };
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\event\dispatch\DispatchEventMapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */