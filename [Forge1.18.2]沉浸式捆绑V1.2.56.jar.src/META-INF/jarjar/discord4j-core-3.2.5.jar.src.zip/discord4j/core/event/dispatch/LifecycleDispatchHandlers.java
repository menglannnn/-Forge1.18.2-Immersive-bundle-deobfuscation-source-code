/*    */ package discord4j.core.event.dispatch;
/*    */ 
/*    */ import discord4j.common.util.Snowflake;
/*    */ import discord4j.core.GatewayDiscordClient;
/*    */ import discord4j.core.event.domain.lifecycle.ConnectEvent;
/*    */ import discord4j.core.event.domain.lifecycle.DisconnectEvent;
/*    */ import discord4j.core.event.domain.lifecycle.GatewayLifecycleEvent;
/*    */ import discord4j.core.event.domain.lifecycle.ReadyEvent;
/*    */ import discord4j.core.event.domain.lifecycle.ReconnectEvent;
/*    */ import discord4j.core.event.domain.lifecycle.ReconnectFailEvent;
/*    */ import discord4j.core.event.domain.lifecycle.ReconnectStartEvent;
/*    */ import discord4j.core.event.domain.lifecycle.ResumeEvent;
/*    */ import discord4j.core.event.domain.lifecycle.SessionInvalidatedEvent;
/*    */ import discord4j.core.object.entity.User;
/*    */ import discord4j.discordjson.json.UnavailableGuildData;
/*    */ import discord4j.discordjson.json.UserData;
/*    */ import discord4j.discordjson.json.gateway.Ready;
/*    */ import discord4j.discordjson.json.gateway.Resumed;
/*    */ import discord4j.gateway.retry.ClosingStateChange;
/*    */ import discord4j.gateway.retry.GatewayStateChange;
/*    */ import java.util.Set;
/*    */ import java.util.stream.Collectors;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class LifecycleDispatchHandlers
/*    */ {
/*    */   static Mono<ReadyEvent> ready(DispatchContext<Ready, Void> context) {
/* 36 */     GatewayDiscordClient gateway = context.getGateway();
/* 37 */     Ready dispatch = context.getDispatch();
/* 38 */     UserData userData = dispatch.user();
/*    */     
/* 40 */     User self = new User(gateway, userData);
/*    */ 
/*    */ 
/*    */     
/* 44 */     Set<ReadyEvent.Guild> guilds = (Set<ReadyEvent.Guild>)dispatch.guilds().stream().map(g -> new ReadyEvent.Guild(Snowflake.asLong(g.id()), !((Boolean)g.unavailable().get()).booleanValue())).collect(Collectors.toSet());
/*    */     
/* 46 */     return Mono.just(new ReadyEvent(gateway, context.getShardInfo(), dispatch, self, guilds));
/*    */   }
/*    */   
/*    */   static Mono<ResumeEvent> resumed(DispatchContext<Resumed, Void> context) {
/* 50 */     return Mono.just(new ResumeEvent(context.getGateway(), context.getShardInfo(), ((Resumed)context
/* 51 */           .getDispatch()).trace()));
/*    */   }
/*    */   static Mono<? extends GatewayLifecycleEvent> gatewayStateChanged(DispatchContext<GatewayStateChange, Void> context) {
/*    */     ClosingStateChange c;
/* 55 */     GatewayDiscordClient gateway = context.getGateway();
/* 56 */     GatewayStateChange dispatch = context.getDispatch();
/* 57 */     switch (dispatch.getState()) {
/*    */       case CONNECTED:
/* 59 */         return Mono.just(new ConnectEvent(gateway, context.getShardInfo()));
/*    */       case RETRY_STARTED:
/*    */       case RETRY_RESUME_STARTED:
/* 62 */         return Mono.just(new ReconnectStartEvent(gateway, context.getShardInfo()));
/*    */       case RETRY_FAILED:
/* 64 */         return Mono.just(new ReconnectFailEvent(gateway, context.getShardInfo(), dispatch.getCurrentAttempt()));
/*    */       case RETRY_SUCCEEDED:
/* 66 */         return Mono.just(new ReconnectEvent(gateway, context.getShardInfo(), dispatch.getCurrentAttempt()));
/*    */       case DISCONNECTED:
/*    */       case DISCONNECTED_RESUME:
/* 69 */         c = (ClosingStateChange)context.getDispatch();
/* 70 */         return Mono.just(new DisconnectEvent(gateway, context.getShardInfo(), c.getStatus(), c.getBehavior().getCause()));
/*    */       case SESSION_INVALIDATED:
/* 72 */         return Mono.just(new SessionInvalidatedEvent(gateway, context.getShardInfo()));
/*    */     } 
/* 74 */     return Mono.empty();
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\event\dispatch\LifecycleDispatchHandlers.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */