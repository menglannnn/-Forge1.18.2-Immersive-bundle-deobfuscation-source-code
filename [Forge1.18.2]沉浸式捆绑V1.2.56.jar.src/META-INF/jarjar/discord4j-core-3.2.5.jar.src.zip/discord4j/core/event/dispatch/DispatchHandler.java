package discord4j.core.event.dispatch;

import reactor.core.publisher.Mono;

@FunctionalInterface
public interface DispatchHandler<D, S, E extends discord4j.core.event.domain.Event> {
  Mono<E> handle(DispatchContext<D, S> paramDispatchContext);
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\event\dispatch\DispatchHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */