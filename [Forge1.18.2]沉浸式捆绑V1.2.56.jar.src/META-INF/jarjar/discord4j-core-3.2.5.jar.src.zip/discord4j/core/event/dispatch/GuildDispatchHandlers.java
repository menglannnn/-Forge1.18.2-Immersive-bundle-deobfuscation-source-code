/*     */ package discord4j.core.event.dispatch;
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.GatewayDiscordClient;
/*     */ import discord4j.core.object.entity.Guild;
/*     */ import discord4j.core.object.entity.GuildEmoji;
/*     */ import discord4j.core.object.entity.GuildSticker;
/*     */ import discord4j.core.object.entity.Member;
/*     */ import discord4j.core.object.entity.Role;
/*     */ import discord4j.core.object.entity.ScheduledEvent;
/*     */ import discord4j.core.object.entity.User;
/*     */ import discord4j.discordjson.json.EmojiData;
/*     */ import discord4j.discordjson.json.GuildCreateData;
/*     */ import discord4j.discordjson.json.GuildData;
/*     */ import discord4j.discordjson.json.GuildScheduledEventData;
/*     */ import discord4j.discordjson.json.ImmutableGuildCreateData;
/*     */ import discord4j.discordjson.json.ImmutableGuildData;
/*     */ import discord4j.discordjson.json.MemberData;
/*     */ import discord4j.discordjson.json.RoleData;
/*     */ import discord4j.discordjson.json.StickerData;
/*     */ import discord4j.discordjson.json.gateway.GuildBanAdd;
/*     */ import discord4j.discordjson.json.gateway.GuildBanRemove;
/*     */ import discord4j.discordjson.json.gateway.GuildCreate;
/*     */ import discord4j.discordjson.json.gateway.GuildDelete;
/*     */ import discord4j.discordjson.json.gateway.GuildEmojisUpdate;
/*     */ import discord4j.discordjson.json.gateway.GuildIntegrationsUpdate;
/*     */ import discord4j.discordjson.json.gateway.GuildMemberAdd;
/*     */ import discord4j.discordjson.json.gateway.GuildMemberRemove;
/*     */ import discord4j.discordjson.json.gateway.GuildMemberUpdate;
/*     */ import discord4j.discordjson.json.gateway.GuildMembersChunk;
/*     */ import discord4j.discordjson.json.gateway.GuildRoleCreate;
/*     */ import discord4j.discordjson.json.gateway.GuildRoleDelete;
/*     */ import discord4j.discordjson.json.gateway.GuildRoleUpdate;
/*     */ import discord4j.discordjson.json.gateway.GuildScheduledEventCreate;
/*     */ import discord4j.discordjson.json.gateway.GuildScheduledEventDelete;
/*     */ import discord4j.discordjson.json.gateway.GuildScheduledEventUpdate;
/*     */ import discord4j.discordjson.json.gateway.GuildScheduledEventUserAdd;
/*     */ import discord4j.discordjson.json.gateway.GuildScheduledEventUserRemove;
/*     */ import discord4j.discordjson.json.gateway.GuildStickersUpdate;
/*     */ import discord4j.discordjson.json.gateway.GuildUpdate;
/*     */ import java.util.List;
/*     */ import java.util.Optional;
/*     */ import java.util.Set;
/*     */ import java.util.stream.Collectors;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.core.publisher.MonoSink;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ class GuildDispatchHandlers {
/*  49 */   private static final Logger log = Loggers.getLogger(GuildDispatchHandlers.class);
/*     */   
/*     */   static Mono<BanEvent> guildBanAdd(DispatchContext<GuildBanAdd, Void> context) {
/*  52 */     User user = new User(context.getGateway(), ((GuildBanAdd)context.getDispatch()).user());
/*  53 */     long guildId = Snowflake.asLong(((GuildBanAdd)context.getDispatch()).guildId());
/*     */     
/*  55 */     return Mono.just(new BanEvent(context.getGateway(), context.getShardInfo(), user, guildId));
/*     */   }
/*     */   
/*     */   static Mono<UnbanEvent> guildBanRemove(DispatchContext<GuildBanRemove, Void> context) {
/*  59 */     User user = new User(context.getGateway(), ((GuildBanRemove)context.getDispatch()).user());
/*  60 */     long guildId = Snowflake.asLong(((GuildBanRemove)context.getDispatch()).guildId());
/*     */     
/*  62 */     return Mono.just(new UnbanEvent(context.getGateway(), context.getShardInfo(), user, guildId));
/*     */   } static Mono<GuildCreateEvent> guildCreate(DispatchContext<GuildCreate, Void> context) {
/*     */     GuildCreateData createData;
/*     */     ImmutableGuildData immutableGuildData;
/*  66 */     GatewayDiscordClient gateway = context.getGateway();
/*     */ 
/*     */     
/*  69 */     if (((GuildCreate)context.getDispatch()).guild().large()) {
/*     */ 
/*     */ 
/*     */       
/*  73 */       ImmutableGuildCreateData immutableGuildCreateData = GuildCreateData.builder().from(((GuildCreate)context.getDispatch()).guild()).members(Collections.emptyList()).build();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  79 */       immutableGuildData = GuildData.builder().from((GuildCreateFields)immutableGuildCreateData).roles((List)immutableGuildCreateData.roles().stream().map(RoleDataFields::id).collect(Collectors.toList())).emojis((List)immutableGuildCreateData.emojis().stream().map(EmojiData::id).filter(Optional::isPresent).map(Optional::get).collect(Collectors.toList())).channels((List)immutableGuildCreateData.channels().stream().map(ChannelData::id).collect(Collectors.toList())).build();
/*     */     } else {
/*  81 */       createData = ((GuildCreate)context.getDispatch()).guild();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  88 */       immutableGuildData = GuildData.builder().from((GuildCreateFields)createData).roles((List)createData.roles().stream().map(RoleDataFields::id).collect(Collectors.toList())).emojis((List)createData.emojis().stream().map(EmojiData::id).filter(Optional::isPresent).map(Optional::get).collect(Collectors.toList())).members((List)createData.members().stream().map(data -> data.user().id()).distinct().collect(Collectors.toList())).channels((List)createData.channels().stream().map(ChannelData::id).collect(Collectors.toList())).build();
/*     */     } 
/*     */     
/*  91 */     Mono<Void> asyncMemberChunk = Mono.create(sink -> sink.onRequest(()));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 107 */     return asyncMemberChunk
/* 108 */       .thenReturn(new GuildCreateEvent(gateway, context.getShardInfo(), new Guild(gateway, (GuildData)immutableGuildData)));
/*     */   }
/*     */   
/*     */   static Mono<GuildDeleteEvent> guildDelete(DispatchContext<GuildDelete, GuildData> context) {
/* 112 */     GatewayDiscordClient gateway = context.getGateway();
/*     */     
/* 114 */     long guildId = Snowflake.asLong(((GuildDelete)context.getDispatch()).guild().id());
/*     */     
/* 116 */     boolean unavailable = ((Boolean)((GuildDelete)context.getDispatch()).guild().unavailable().toOptional().orElse(Boolean.valueOf(false))).booleanValue();
/* 117 */     Guild guild = context.getOldState().map(data -> new Guild(gateway, data)).orElse(null);
/*     */     
/* 119 */     return Mono.just(new GuildDeleteEvent(gateway, context.getShardInfo(), guildId, guild, unavailable));
/*     */   }
/*     */   
/*     */   static Mono<StickersUpdateEvent> guildStickersUpdate(DispatchContext<GuildStickersUpdate, Set<StickerData>> context) {
/* 123 */     GatewayDiscordClient gateway = context.getGateway();
/* 124 */     long guildId = Snowflake.asLong(((GuildStickersUpdate)context.getDispatch()).guildId());
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 129 */     Set<GuildSticker> stickers = (Set<GuildSticker>)((GuildStickersUpdate)context.getDispatch()).stickers().stream().map(sticker -> new GuildSticker(gateway, sticker, guildId)).collect(Collectors.toSet());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 135 */     Set<GuildSticker> oldStickers = context.getOldState().map(oldState -> (Set)oldState.stream().map(()).collect(Collectors.toSet())).orElse(Collections.emptySet());
/*     */     
/* 137 */     return Mono.just(new StickersUpdateEvent(gateway, context.getShardInfo(), guildId, stickers, oldStickers));
/*     */   }
/*     */   
/*     */   static Mono<EmojisUpdateEvent> guildEmojisUpdate(DispatchContext<GuildEmojisUpdate, Set<EmojiData>> context) {
/* 141 */     GatewayDiscordClient gateway = context.getGateway();
/* 142 */     long guildId = Snowflake.asLong(((GuildEmojisUpdate)context.getDispatch()).guildId());
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 147 */     Set<GuildEmoji> emojis = (Set<GuildEmoji>)((GuildEmojisUpdate)context.getDispatch()).emojis().stream().map(emoji -> new GuildEmoji(gateway, emoji, guildId)).collect(Collectors.toSet());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 153 */     Set<GuildEmoji> oldEmojis = context.getOldState().map(oldState -> (Set)oldState.stream().map(()).collect(Collectors.toSet())).orElse(Collections.emptySet());
/*     */     
/* 155 */     return Mono.just(new EmojisUpdateEvent(gateway, context.getShardInfo(), guildId, emojis, oldEmojis));
/*     */   }
/*     */   
/*     */   static Mono<IntegrationsUpdateEvent> guildIntegrationsUpdate(DispatchContext<GuildIntegrationsUpdate, Void> context) {
/* 159 */     return Mono.just(new IntegrationsUpdateEvent(context.getGateway(), context.getShardInfo(), 
/* 160 */           Snowflake.asLong(((GuildIntegrationsUpdate)context.getDispatch()).guildId())));
/*     */   }
/*     */   
/*     */   static Mono<MemberJoinEvent> guildMemberAdd(DispatchContext<GuildMemberAdd, Void> context) {
/* 164 */     GatewayDiscordClient gateway = context.getGateway();
/* 165 */     long guildId = Snowflake.asLong(((GuildMemberAdd)context.getDispatch()).guildId());
/* 166 */     MemberData member = ((GuildMemberAdd)context.getDispatch()).member();
/*     */     
/* 168 */     return Mono.just(new MemberJoinEvent(gateway, context.getShardInfo(), new Member(gateway, member, guildId), guildId));
/*     */   }
/*     */ 
/*     */   
/*     */   static Mono<MemberLeaveEvent> guildMemberRemove(DispatchContext<GuildMemberRemove, MemberData> context) {
/* 173 */     GatewayDiscordClient gateway = context.getGateway();
/* 174 */     long guildId = Snowflake.asLong(((GuildMemberRemove)context.getDispatch()).guildId());
/* 175 */     UserData userData = ((GuildMemberRemove)context.getDispatch()).user();
/*     */     
/* 177 */     User user = new User(gateway, userData);
/* 178 */     Member oldMember = context.getOldState().map(data -> new Member(gateway, data, guildId)).orElse(null);
/*     */     
/* 180 */     return Mono.just(new MemberLeaveEvent(gateway, context.getShardInfo(), user, guildId, oldMember));
/*     */   }
/*     */   
/*     */   static Mono<MemberChunkEvent> guildMembersChunk(DispatchContext<GuildMembersChunk, Void> context) {
/* 184 */     GatewayDiscordClient gateway = context.getGateway();
/* 185 */     long guildId = Snowflake.asLong(((GuildMembersChunk)context.getDispatch()).guildId());
/* 186 */     List<MemberData> members = ((GuildMembersChunk)context.getDispatch()).members();
/* 187 */     int chunkIndex = ((GuildMembersChunk)context.getDispatch()).chunkIndex();
/* 188 */     int chunkCount = ((GuildMembersChunk)context.getDispatch()).chunkCount();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 194 */     List<Snowflake> notFound = (List<Snowflake>)((List)((GuildMembersChunk)context.getDispatch()).notFound().toOptional().orElse(Collections.emptyList())).stream().map(Snowflake::of).collect(Collectors.toList());
/* 195 */     String nonce = ((GuildMembersChunk)context.getDispatch()).nonce().toOptional().orElse(null);
/*     */     
/* 197 */     return Mono.just(new MemberChunkEvent(gateway, context.getShardInfo(), guildId, (Set)members
/* 198 */           .stream()
/* 199 */           .map(member -> new Member(gateway, member, guildId))
/* 200 */           .collect(Collectors.toSet()), chunkIndex, chunkCount, notFound, nonce));
/*     */   }
/*     */ 
/*     */   
/*     */   static Mono<MemberUpdateEvent> guildMemberUpdate(DispatchContext<GuildMemberUpdate, MemberData> context) {
/* 205 */     GatewayDiscordClient gateway = context.getGateway();
/*     */     
/* 207 */     long guildId = Snowflake.asLong(((GuildMemberUpdate)context.getDispatch()).guildId());
/* 208 */     long memberId = Snowflake.asLong(((GuildMemberUpdate)context.getDispatch()).user().id());
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 213 */     Set<Long> currentRoleIds = (Set<Long>)((GuildMemberUpdate)context.getDispatch()).roles().stream().map(Snowflake::asLong).collect(Collectors.toSet());
/* 214 */     String currentNick = Possible.flatOpt(((GuildMemberUpdate)context.getDispatch()).nick()).orElse(null);
/* 215 */     String currentAvatar = ((GuildMemberUpdate)context.getDispatch()).avatar().orElse(null);
/* 216 */     String currentJoinedAt = ((GuildMemberUpdate)context.getDispatch()).joinedAt().orElse(null);
/* 217 */     String currentPremiumSince = Possible.flatOpt(((GuildMemberUpdate)context.getDispatch()).premiumSince()).orElse(null);
/* 218 */     Boolean currentPending = ((GuildMemberUpdate)context.getDispatch()).pending().toOptional().orElse(null);
/* 219 */     String communicationDisabledUntil = Possible.flatOpt(((GuildMemberUpdate)context.getDispatch()).communicationDisabledUntil()).orElse(null);
/*     */ 
/*     */     
/* 222 */     Member oldMember = context.getOldState().map(data -> new Member(gateway, data, guildId)).orElse(null);
/*     */     
/* 224 */     return Mono.just(new MemberUpdateEvent(gateway, context.getShardInfo(), guildId, memberId, oldMember, currentRoleIds, currentNick, currentAvatar, currentJoinedAt, currentPremiumSince, currentPending, communicationDisabledUntil));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static Mono<RoleCreateEvent> guildRoleCreate(DispatchContext<GuildRoleCreate, Void> context) {
/* 230 */     GatewayDiscordClient gateway = context.getGateway();
/* 231 */     long guildId = Snowflake.asLong(((GuildRoleCreate)context.getDispatch()).guildId());
/* 232 */     RoleData role = ((GuildRoleCreate)context.getDispatch()).role();
/*     */     
/* 234 */     return Mono.just(new RoleCreateEvent(gateway, context.getShardInfo(), guildId, new Role(gateway, role, guildId)));
/*     */   }
/*     */ 
/*     */   
/*     */   static Mono<RoleDeleteEvent> guildRoleDelete(DispatchContext<GuildRoleDelete, RoleData> context) {
/* 239 */     GatewayDiscordClient gateway = context.getGateway();
/* 240 */     long guildId = Snowflake.asLong(((GuildRoleDelete)context.getDispatch()).guildId());
/* 241 */     long roleId = Snowflake.asLong(((GuildRoleDelete)context.getDispatch()).roleId());
/*     */ 
/*     */ 
/*     */     
/* 245 */     Role oldRole = context.getOldState().map(data -> new Role(gateway, data, guildId)).orElse(null);
/*     */     
/* 247 */     return Mono.just(new RoleDeleteEvent(gateway, context.getShardInfo(), guildId, roleId, oldRole));
/*     */   }
/*     */   
/*     */   static Mono<RoleUpdateEvent> guildRoleUpdate(DispatchContext<GuildRoleUpdate, RoleData> context) {
/* 251 */     GatewayDiscordClient gateway = context.getGateway();
/* 252 */     long guildId = Snowflake.asLong(((GuildRoleUpdate)context.getDispatch()).guildId());
/* 253 */     RoleData role = ((GuildRoleUpdate)context.getDispatch()).role();
/* 254 */     Role current = new Role(gateway, role, guildId);
/*     */ 
/*     */ 
/*     */     
/* 258 */     Role oldRole = context.getOldState().map(data -> new Role(gateway, data, guildId)).orElse(null);
/*     */     
/* 260 */     return Mono.just(new RoleUpdateEvent(gateway, context.getShardInfo(), current, oldRole));
/*     */   }
/*     */   
/*     */   static Mono<ScheduledEventCreateEvent> scheduledEventCreate(DispatchContext<GuildScheduledEventCreate, Void> context) {
/* 264 */     GatewayDiscordClient gateway = context.getGateway();
/* 265 */     GuildScheduledEventData payload = ((GuildScheduledEventCreate)context.getDispatch()).scheduledEvent();
/* 266 */     ScheduledEvent scheduledEvent = new ScheduledEvent(gateway, payload);
/* 267 */     return Mono.just(new ScheduledEventCreateEvent(gateway, context.getShardInfo(), scheduledEvent));
/*     */   }
/*     */   
/*     */   static Mono<ScheduledEventUpdateEvent> scheduledEventUpdate(DispatchContext<GuildScheduledEventUpdate, GuildScheduledEventData> context) {
/* 271 */     GatewayDiscordClient gateway = context.getGateway();
/* 272 */     GuildScheduledEventData payload = ((GuildScheduledEventUpdate)context.getDispatch()).scheduledEvent();
/* 273 */     ScheduledEvent scheduledEvent = new ScheduledEvent(gateway, payload);
/*     */ 
/*     */     
/* 276 */     ScheduledEvent oldScheduledEvent = context.getOldState().map(data -> new ScheduledEvent(gateway, data)).orElse(null);
/* 277 */     return Mono.just(new ScheduledEventUpdateEvent(gateway, context.getShardInfo(), scheduledEvent, oldScheduledEvent));
/*     */   }
/*     */   
/*     */   static Mono<ScheduledEventDeleteEvent> scheduledEventDelete(DispatchContext<GuildScheduledEventDelete, GuildScheduledEventData> context) {
/* 281 */     GatewayDiscordClient gateway = context.getGateway();
/* 282 */     GuildScheduledEventData payload = ((GuildScheduledEventDelete)context.getDispatch()).scheduledEvent();
/* 283 */     ScheduledEvent scheduledEvent = new ScheduledEvent(gateway, payload);
/* 284 */     return Mono.just(new ScheduledEventDeleteEvent(gateway, context.getShardInfo(), scheduledEvent));
/*     */   }
/*     */   
/*     */   static Mono<ScheduledEventUserAddEvent> scheduledEventUserAdd(DispatchContext<GuildScheduledEventUserAdd, Void> context) {
/* 288 */     GatewayDiscordClient gateway = context.getGateway();
/* 289 */     GuildScheduledEventUserAdd dispatch = context.getDispatch();
/* 290 */     return Mono.just(new ScheduledEventUserAddEvent(gateway, context.getShardInfo(), 
/* 291 */           Snowflake.asLong(dispatch.guildId()), 
/* 292 */           Snowflake.asLong(dispatch.scheduledEventId()), 
/* 293 */           Snowflake.asLong(dispatch.userId())));
/*     */   }
/*     */   
/*     */   static Mono<ScheduledEventUserRemoveEvent> scheduledEventUserRemove(DispatchContext<GuildScheduledEventUserRemove, Void> context) {
/* 297 */     GatewayDiscordClient gateway = context.getGateway();
/* 298 */     GuildScheduledEventUserRemove dispatch = context.getDispatch();
/* 299 */     return Mono.just(new ScheduledEventUserRemoveEvent(gateway, context.getShardInfo(), 
/* 300 */           Snowflake.asLong(dispatch.guildId()), 
/* 301 */           Snowflake.asLong(dispatch.scheduledEventId()), 
/* 302 */           Snowflake.asLong(dispatch.userId())));
/*     */   }
/*     */   
/*     */   static Mono<GuildUpdateEvent> guildUpdate(DispatchContext<GuildUpdate, GuildData> context) {
/* 306 */     GatewayDiscordClient gateway = context.getGateway();
/*     */ 
/*     */ 
/*     */     
/* 310 */     Guild oldGuild = context.getOldState().map(data -> new Guild(gateway, data)).orElse(null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 328 */     Guild newGuild = new Guild(gateway, (GuildData)GuildData.builder().from(context.getOldState().orElseGet(() -> GuildData.builder().joinedAt(DateTimeFormatter.ISO_OFFSET_DATE_TIME.format(ZonedDateTime.now())).large(false).memberCount(((Integer)((GuildUpdate)context.getDispatch()).guild().approximateMemberCount().toOptional().orElse(Integer.valueOf(1))).intValue()).build())).from((GuildUpdateFields)((GuildUpdate)context.getDispatch()).guild()).roles((List)((GuildUpdate)context.getDispatch()).guild().roles().stream().map(RoleDataFields::id).collect(Collectors.toList())).emojis((List)((GuildUpdate)context.getDispatch()).guild().emojis().stream().map(EmojiData::id).filter(Optional::isPresent).map(Optional::get).collect(Collectors.toList())).build());
/*     */     
/* 330 */     return Mono.just(new GuildUpdateEvent(gateway, context.getShardInfo(), newGuild, oldGuild));
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\event\dispatch\GuildDispatchHandlers.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */