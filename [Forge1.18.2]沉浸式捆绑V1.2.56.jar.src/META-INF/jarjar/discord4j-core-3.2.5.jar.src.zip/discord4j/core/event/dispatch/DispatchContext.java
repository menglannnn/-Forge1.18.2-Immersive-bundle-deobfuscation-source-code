/*    */ package discord4j.core.event.dispatch;
/*    */ 
/*    */ import discord4j.core.GatewayDiscordClient;
/*    */ import discord4j.gateway.ShardInfo;
/*    */ import discord4j.gateway.state.StatefulDispatch;
/*    */ import java.util.Optional;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DispatchContext<D, S>
/*    */ {
/*    */   private final StatefulDispatch<D, S> statefulDispatch;
/*    */   private final GatewayDiscordClient gateway;
/*    */   
/*    */   public static <D, S> DispatchContext<D, S> of(StatefulDispatch<D, S> statefulDispatch, GatewayDiscordClient gateway) {
/* 40 */     return new DispatchContext<>(statefulDispatch, gateway);
/*    */   }
/*    */   
/*    */   private DispatchContext(StatefulDispatch<D, S> statefulDispatch, GatewayDiscordClient gateway) {
/* 44 */     this.statefulDispatch = statefulDispatch;
/* 45 */     this.gateway = gateway;
/*    */   }
/*    */   
/*    */   public GatewayDiscordClient getGateway() {
/* 49 */     return this.gateway;
/*    */   }
/*    */   
/*    */   public D getDispatch() {
/* 53 */     return (D)this.statefulDispatch.getDispatch();
/*    */   }
/*    */   
/*    */   public ShardInfo getShardInfo() {
/* 57 */     return this.statefulDispatch.getShardInfo();
/*    */   }
/*    */   
/*    */   public Optional<S> getOldState() {
/* 61 */     return this.statefulDispatch.getOldState();
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\event\dispatch\DispatchContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */