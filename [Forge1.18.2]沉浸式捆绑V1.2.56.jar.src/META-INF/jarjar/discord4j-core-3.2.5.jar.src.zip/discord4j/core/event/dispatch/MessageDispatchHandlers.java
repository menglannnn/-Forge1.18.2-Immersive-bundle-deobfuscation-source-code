/*     */ package discord4j.core.event.dispatch;
/*     */ 
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.GatewayDiscordClient;
/*     */ import discord4j.core.event.domain.message.MessageBulkDeleteEvent;
/*     */ import discord4j.core.event.domain.message.MessageCreateEvent;
/*     */ import discord4j.core.event.domain.message.MessageDeleteEvent;
/*     */ import discord4j.core.event.domain.message.MessageUpdateEvent;
/*     */ import discord4j.core.event.domain.message.ReactionAddEvent;
/*     */ import discord4j.core.event.domain.message.ReactionRemoveAllEvent;
/*     */ import discord4j.core.event.domain.message.ReactionRemoveEmojiEvent;
/*     */ import discord4j.core.event.domain.message.ReactionRemoveEvent;
/*     */ import discord4j.core.object.Embed;
/*     */ import discord4j.core.object.entity.Member;
/*     */ import discord4j.core.object.entity.Message;
/*     */ import discord4j.core.object.reaction.ReactionEmoji;
/*     */ import discord4j.discordjson.Id;
/*     */ import discord4j.discordjson.json.EmbedData;
/*     */ import discord4j.discordjson.json.MemberData;
/*     */ import discord4j.discordjson.json.MessageData;
/*     */ import discord4j.discordjson.json.PartialMemberData;
/*     */ import discord4j.discordjson.json.PartialMessageData;
/*     */ import discord4j.discordjson.json.gateway.MessageCreate;
/*     */ import discord4j.discordjson.json.gateway.MessageDelete;
/*     */ import discord4j.discordjson.json.gateway.MessageDeleteBulk;
/*     */ import discord4j.discordjson.json.gateway.MessageReactionAdd;
/*     */ import discord4j.discordjson.json.gateway.MessageReactionRemove;
/*     */ import discord4j.discordjson.json.gateway.MessageReactionRemoveAll;
/*     */ import discord4j.discordjson.json.gateway.MessageReactionRemoveEmoji;
/*     */ import discord4j.discordjson.json.gateway.MessageUpdate;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Optional;
/*     */ import java.util.Set;
/*     */ import java.util.stream.Collectors;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ class MessageDispatchHandlers
/*     */ {
/*     */   static Mono<MessageCreateEvent> messageCreate(DispatchContext<MessageCreate, Void> context) {
/*  41 */     GatewayDiscordClient gateway = context.getGateway();
/*  42 */     MessageData message = ((MessageCreate)context.getDispatch()).message();
/*     */ 
/*     */ 
/*     */     
/*  46 */     Optional<Member> maybeMember = ((MessageCreate)context.getDispatch()).message().guildId().toOptional().map(Snowflake::asLong).flatMap(guildId -> message.member().toOptional().map(()));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  61 */     return Mono.just(new MessageCreateEvent(gateway, context.getShardInfo(), new Message(gateway, message), ((MessageCreate)context
/*  62 */           .getDispatch()).message().guildId().toOptional()
/*  63 */           .map(Snowflake::asLong)
/*  64 */           .orElse(null), maybeMember
/*  65 */           .orElse(null)));
/*     */   }
/*     */   
/*     */   static Mono<MessageDeleteEvent> messageDelete(DispatchContext<MessageDelete, MessageData> context) {
/*  69 */     GatewayDiscordClient gateway = context.getGateway();
/*  70 */     long messageId = Snowflake.asLong(((MessageDelete)context.getDispatch()).id());
/*  71 */     long channelId = Snowflake.asLong(((MessageDelete)context.getDispatch()).channelId());
/*     */ 
/*     */ 
/*     */     
/*  75 */     Long guildId = ((MessageDelete)context.getDispatch()).guildId().toOptional().map(Snowflake::asLong).orElse(null);
/*     */ 
/*     */ 
/*     */     
/*  79 */     Message oldMessage = context.getOldState().map(data -> new Message(gateway, data)).orElse(null);
/*     */     
/*  81 */     return Mono.just(new MessageDeleteEvent(gateway, context.getShardInfo(), messageId, channelId, guildId, oldMessage));
/*     */   }
/*     */ 
/*     */   
/*     */   static Mono<MessageBulkDeleteEvent> messageDeleteBulk(DispatchContext<MessageDeleteBulk, Set<MessageData>> context) {
/*  86 */     GatewayDiscordClient gateway = context.getGateway();
/*     */ 
/*     */     
/*  89 */     List<Long> messageIds = (List<Long>)((MessageDeleteBulk)context.getDispatch()).ids().stream().map(Snowflake::asLong).collect(Collectors.toList());
/*  90 */     long channelId = Snowflake.asLong(((MessageDeleteBulk)context.getDispatch()).channelId());
/*  91 */     long guildId = Snowflake.asLong((Id)((MessageDeleteBulk)context.getDispatch()).guildId().get());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  97 */     Set<Message> deletedMessages = context.getOldState().map(oldState -> (Set)oldState.stream().map(()).collect(Collectors.toSet())).orElse(Collections.emptySet());
/*     */     
/*  99 */     return Mono.just(new MessageBulkDeleteEvent(gateway, context.getShardInfo(), messageIds, channelId, guildId, deletedMessages));
/*     */   }
/*     */ 
/*     */   
/*     */   static Mono<ReactionAddEvent> messageReactionAdd(DispatchContext<MessageReactionAdd, Void> context) {
/* 104 */     GatewayDiscordClient gateway = context.getGateway();
/* 105 */     long userId = Snowflake.asLong(((MessageReactionAdd)context.getDispatch()).userId());
/* 106 */     long channelId = Snowflake.asLong(((MessageReactionAdd)context.getDispatch()).channelId());
/* 107 */     long messageId = Snowflake.asLong(((MessageReactionAdd)context.getDispatch()).messageId());
/*     */ 
/*     */ 
/*     */     
/* 111 */     Long guildId = ((MessageReactionAdd)context.getDispatch()).guildId().toOptional().map(Snowflake::asLong).orElse(null);
/*     */     
/* 113 */     MemberData memberData = ((MessageReactionAdd)context.getDispatch()).member().toOptional().orElse(null);
/*     */ 
/*     */ 
/*     */     
/* 117 */     Long emojiId = ((MessageReactionAdd)context.getDispatch()).emoji().id().map(Snowflake::asLong).orElse(null);
/*     */     
/* 119 */     String emojiName = ((MessageReactionAdd)context.getDispatch()).emoji().name().orElse(null);
/*     */ 
/*     */     
/* 122 */     boolean emojiAnimated = ((Boolean)((MessageReactionAdd)context.getDispatch()).emoji().animated().toOptional().orElse(Boolean.valueOf(false))).booleanValue();
/* 123 */     ReactionEmoji emoji = ReactionEmoji.of(emojiId, emojiName, emojiAnimated);
/*     */     
/* 125 */     Member member = (memberData != null) ? new Member(gateway, memberData, guildId.longValue()) : null;
/*     */     
/* 127 */     return Mono.just(new ReactionAddEvent(gateway, context.getShardInfo(), userId, channelId, messageId, guildId, emoji, member));
/*     */   }
/*     */ 
/*     */   
/*     */   static Mono<ReactionRemoveEvent> messageReactionRemove(DispatchContext<MessageReactionRemove, Void> context) {
/* 132 */     GatewayDiscordClient gateway = context.getGateway();
/* 133 */     long userId = Snowflake.asLong(((MessageReactionRemove)context.getDispatch()).userId());
/* 134 */     long channelId = Snowflake.asLong(((MessageReactionRemove)context.getDispatch()).channelId());
/* 135 */     long messageId = Snowflake.asLong(((MessageReactionRemove)context.getDispatch()).messageId());
/*     */ 
/*     */ 
/*     */     
/* 139 */     Long guildId = ((MessageReactionRemove)context.getDispatch()).guildId().toOptional().map(Snowflake::asLong).orElse(null);
/*     */ 
/*     */ 
/*     */     
/* 143 */     Long emojiId = ((MessageReactionRemove)context.getDispatch()).emoji().id().map(Snowflake::asLong).orElse(null);
/*     */     
/* 145 */     String emojiName = ((MessageReactionRemove)context.getDispatch()).emoji().name().orElse(null);
/*     */ 
/*     */     
/* 148 */     boolean emojiAnimated = ((Boolean)((MessageReactionRemove)context.getDispatch()).emoji().animated().toOptional().orElse(Boolean.valueOf(false))).booleanValue();
/* 149 */     ReactionEmoji emoji = ReactionEmoji.of(emojiId, emojiName, emojiAnimated);
/* 150 */     return Mono.just(new ReactionRemoveEvent(gateway, context.getShardInfo(), userId, channelId, messageId, guildId, emoji));
/*     */   }
/*     */ 
/*     */   
/*     */   static Mono<ReactionRemoveEmojiEvent> messageReactionRemoveEmoji(DispatchContext<MessageReactionRemoveEmoji, Void> context) {
/* 155 */     GatewayDiscordClient gateway = context.getGateway();
/* 156 */     long channelId = Snowflake.asLong(((MessageReactionRemoveEmoji)context.getDispatch()).channelId());
/* 157 */     long messageId = Snowflake.asLong(((MessageReactionRemoveEmoji)context.getDispatch()).messageId());
/*     */ 
/*     */ 
/*     */     
/* 161 */     Long guildId = ((MessageReactionRemoveEmoji)context.getDispatch()).guildId().toOptional().map(Snowflake::asLong).orElse(null);
/*     */ 
/*     */ 
/*     */     
/* 165 */     Long emojiId = ((MessageReactionRemoveEmoji)context.getDispatch()).emoji().id().map(Snowflake::asLong).orElse(null);
/*     */     
/* 167 */     String emojiName = ((MessageReactionRemoveEmoji)context.getDispatch()).emoji().name().orElse(null);
/*     */ 
/*     */     
/* 170 */     boolean emojiAnimated = ((Boolean)((MessageReactionRemoveEmoji)context.getDispatch()).emoji().animated().toOptional().orElse(Boolean.valueOf(false))).booleanValue();
/* 171 */     ReactionEmoji emoji = ReactionEmoji.of(emojiId, emojiName, emojiAnimated);
/* 172 */     return Mono.just(new ReactionRemoveEmojiEvent(gateway, context.getShardInfo(), channelId, messageId, guildId, emoji));
/*     */   }
/*     */ 
/*     */   
/*     */   static Mono<ReactionRemoveAllEvent> messageReactionRemoveAll(DispatchContext<MessageReactionRemoveAll, Void> context) {
/* 177 */     GatewayDiscordClient gateway = context.getGateway();
/* 178 */     long channelId = Snowflake.asLong(((MessageReactionRemoveAll)context.getDispatch()).channelId());
/* 179 */     long messageId = Snowflake.asLong(((MessageReactionRemoveAll)context.getDispatch()).messageId());
/*     */ 
/*     */ 
/*     */     
/* 183 */     Long guildId = ((MessageReactionRemoveAll)context.getDispatch()).guildId().toOptional().map(Snowflake::asLong).orElse(null);
/*     */     
/* 185 */     return Mono.just(new ReactionRemoveAllEvent(gateway, context.getShardInfo(), channelId, messageId, guildId));
/*     */   }
/*     */ 
/*     */   
/*     */   static Mono<MessageUpdateEvent> messageUpdate(DispatchContext<MessageUpdate, MessageData> context) {
/* 190 */     GatewayDiscordClient gateway = context.getGateway();
/* 191 */     PartialMessageData messageData = ((MessageUpdate)context.getDispatch()).message();
/*     */     
/* 193 */     long channelId = Snowflake.asLong(messageData.channelId());
/* 194 */     long messageId = Snowflake.asLong(messageData.id());
/*     */ 
/*     */ 
/*     */     
/* 198 */     Long guildId = messageData.guildId().toOptional().map(Snowflake::asLong).orElse(null);
/*     */     
/* 200 */     String currentContent = messageData.content().toOptional().orElse(null);
/*     */ 
/*     */ 
/*     */     
/* 204 */     List<Embed> embedList = (List<Embed>)messageData.embeds().stream().map(embedData -> new Embed(gateway, embedData)).collect(Collectors.toList());
/*     */ 
/*     */ 
/*     */     
/* 208 */     Message oldMessage = context.getOldState().map(data -> new Message(gateway, data)).orElse(null);
/*     */     
/* 210 */     return Mono.just(new MessageUpdateEvent(gateway, context.getShardInfo(), messageId, channelId, guildId, oldMessage, 
/* 211 */           !messageData.content().isAbsent(), currentContent, 
/* 212 */           !messageData.embeds().isEmpty(), embedList));
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\event\dispatch\MessageDispatchHandlers.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */