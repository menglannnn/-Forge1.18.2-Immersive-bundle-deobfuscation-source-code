/*    */ package discord4j.core.event.dispatch;
/*    */ 
/*    */ import discord4j.common.util.Snowflake;
/*    */ import discord4j.core.GatewayDiscordClient;
/*    */ import discord4j.core.event.domain.command.ApplicationCommandCreateEvent;
/*    */ import discord4j.core.event.domain.command.ApplicationCommandDeleteEvent;
/*    */ import discord4j.core.event.domain.command.ApplicationCommandPermissionUpdateEvent;
/*    */ import discord4j.core.event.domain.command.ApplicationCommandUpdateEvent;
/*    */ import discord4j.core.object.command.ApplicationCommand;
/*    */ import discord4j.core.object.command.ApplicationCommandGuildPermissions;
/*    */ import discord4j.discordjson.json.ApplicationCommandData;
/*    */ import discord4j.discordjson.json.GuildApplicationCommandPermissionsData;
/*    */ import discord4j.discordjson.json.gateway.ApplicationCommandCreate;
/*    */ import discord4j.discordjson.json.gateway.ApplicationCommandDelete;
/*    */ import discord4j.discordjson.json.gateway.ApplicationCommandPermissionUpdate;
/*    */ import discord4j.discordjson.json.gateway.ApplicationCommandUpdate;
/*    */ import discord4j.gateway.ShardInfo;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ApplicationCommandDispatchHandlers
/*    */ {
/*    */   static Mono<ApplicationCommandCreateEvent> applicationCommandCreate(DispatchContext<ApplicationCommandCreate, Void> context) {
/* 40 */     GatewayDiscordClient gateway = context.getGateway();
/* 41 */     ShardInfo shardInfo = context.getShardInfo();
/* 42 */     Long guildId = Long.valueOf(Snowflake.asLong(((ApplicationCommandCreate)context.getDispatch()).guildId()));
/* 43 */     ApplicationCommandData command = ((ApplicationCommandCreate)context.getDispatch()).command();
/*    */     
/* 45 */     return Mono.just(new ApplicationCommandCreateEvent(gateway, shardInfo, new ApplicationCommand(gateway, command), guildId));
/*    */   }
/*    */ 
/*    */   
/*    */   static Mono<ApplicationCommandUpdateEvent> applicationCommandUpdate(DispatchContext<ApplicationCommandUpdate, Void> context) {
/* 50 */     GatewayDiscordClient gateway = context.getGateway();
/* 51 */     ShardInfo shardInfo = context.getShardInfo();
/* 52 */     Long guildId = Long.valueOf(Snowflake.asLong(((ApplicationCommandUpdate)context.getDispatch()).guildId()));
/* 53 */     ApplicationCommandData command = ((ApplicationCommandUpdate)context.getDispatch()).command();
/*    */     
/* 55 */     return Mono.just(new ApplicationCommandUpdateEvent(gateway, shardInfo, new ApplicationCommand(gateway, command), guildId));
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   static Mono<ApplicationCommandDeleteEvent> applicationCommandDelete(DispatchContext<ApplicationCommandDelete, Void> context) {
/* 61 */     GatewayDiscordClient gateway = context.getGateway();
/* 62 */     ShardInfo shardInfo = context.getShardInfo();
/* 63 */     Long guildId = Long.valueOf(Snowflake.asLong(((ApplicationCommandDelete)context.getDispatch()).guildId()));
/* 64 */     ApplicationCommandData command = ((ApplicationCommandDelete)context.getDispatch()).command();
/*    */     
/* 66 */     return Mono.just(new ApplicationCommandDeleteEvent(gateway, shardInfo, new ApplicationCommand(gateway, command), guildId));
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   static Mono<ApplicationCommandPermissionUpdateEvent> applicationCommandPermissionUpdate(DispatchContext<ApplicationCommandPermissionUpdate, Void> context) {
/* 72 */     GatewayDiscordClient gateway = context.getGateway();
/* 73 */     ShardInfo shardInfo = context.getShardInfo();
/* 74 */     GuildApplicationCommandPermissionsData data = ((ApplicationCommandPermissionUpdate)context.getDispatch()).data();
/*    */     
/* 76 */     return Mono.just(new ApplicationCommandPermissionUpdateEvent(gateway, shardInfo, new ApplicationCommandGuildPermissions(gateway, data)));
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\event\dispatch\ApplicationCommandDispatchHandlers.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */