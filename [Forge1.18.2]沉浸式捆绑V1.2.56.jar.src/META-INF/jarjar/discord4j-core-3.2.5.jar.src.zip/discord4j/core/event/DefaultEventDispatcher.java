/*     */ package discord4j.core.event;
/*     */ 
/*     */ import discord4j.common.LogUtil;
/*     */ import discord4j.core.event.domain.Event;
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.atomic.AtomicReference;
/*     */ import java.util.function.Function;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.publisher.EmitterProcessor;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.FluxProcessor;
/*     */ import reactor.core.publisher.FluxSink;
/*     */ import reactor.core.publisher.SignalType;
/*     */ import reactor.core.publisher.Sinks;
/*     */ import reactor.core.publisher.SynchronousSink;
/*     */ import reactor.core.scheduler.Scheduler;
/*     */ import reactor.util.Logger;
/*     */ import reactor.util.Loggers;
/*     */ import reactor.util.concurrent.Queues;
/*     */ import reactor.util.context.ContextView;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultEventDispatcher
/*     */   implements EventDispatcher
/*     */ {
/*  44 */   private static final Logger log = Loggers.getLogger(DefaultEventDispatcher.class);
/*     */ 
/*     */ 
/*     */   
/*     */   private final FluxProcessor<Event, Event> eventProcessor;
/*     */ 
/*     */ 
/*     */   
/*     */   private final FluxSink<Event> sink;
/*     */ 
/*     */ 
/*     */   
/*     */   private final Scheduler eventScheduler;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DefaultEventDispatcher(FluxProcessor<Event, Event> eventProcessor, FluxSink.OverflowStrategy overflowStrategy, Scheduler eventScheduler) {
/*  62 */     this.eventProcessor = eventProcessor;
/*  63 */     this.sink = eventProcessor.sink(overflowStrategy);
/*  64 */     this.eventScheduler = eventScheduler;
/*     */   }
/*     */ 
/*     */   
/*     */   public <E extends Event> Flux<E> on(Class<E> eventClass) {
/*  69 */     AtomicReference<Subscription> subscription = new AtomicReference<>();
/*  70 */     return this.eventProcessor.publishOn(this.eventScheduler)
/*  71 */       .ofType(eventClass)
/*  72 */       .handle((event, sink) -> {
/*     */           if (log.isTraceEnabled()) {
/*     */             log.trace(LogUtil.format((ContextView)sink.currentContext().put("discord4j.shard", Integer.valueOf(event.getShardInfo().getIndex())), "{}"), new Object[] { event.toString() });
/*     */           }
/*     */ 
/*     */           
/*     */           sink.next(event);
/*  79 */         }).doOnSubscribe(sub -> {
/*     */           subscription.set(sub);
/*     */ 
/*     */           
/*     */           if (log.isDebugEnabled()) {
/*     */             log.debug("Subscription {} to {} created", new Object[] { Integer.toHexString(sub.hashCode()), eventClass.getSimpleName() });
/*     */           }
/*  86 */         }).doFinally(signal -> {
/*     */           if (log.isDebugEnabled()) {
/*     */             log.debug("Subscription {} to {} disposed due to {}", new Object[] { Integer.toHexString(((Subscription)subscription.get()).hashCode()), eventClass.getSimpleName(), signal });
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void publish(Event event) {
/*  96 */     this.sink.next(event);
/*     */   }
/*     */ 
/*     */   
/*     */   public void shutdown() {
/* 101 */     this.sink.complete();
/*     */   }
/*     */ 
/*     */   
/*     */   public static class Builder
/*     */     implements EventDispatcher.Builder
/*     */   {
/*     */     protected FluxProcessor<Event, Event> eventProcessor;
/*     */     
/* 110 */     protected FluxSink.OverflowStrategy overflowStrategy = FluxSink.OverflowStrategy.BUFFER;
/*     */ 
/*     */ 
/*     */     
/*     */     protected Scheduler eventScheduler;
/*     */ 
/*     */ 
/*     */     
/*     */     public SinksEventDispatcher.Builder eventSink(Function<Sinks.ManySpec, Sinks.Many<Event>> eventSinkFactory) {
/* 119 */       SinksEventDispatcher.Builder builder = (new SinksEventDispatcher.Builder()).eventSink(Objects.<Function<Sinks.ManySpec, Sinks.Many<Event>>>requireNonNull(eventSinkFactory));
/* 120 */       if (this.eventScheduler != null) {
/* 121 */         builder.eventScheduler(this.eventScheduler);
/*     */       }
/* 123 */       return builder;
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder eventProcessor(FluxProcessor<Event, Event> eventProcessor) {
/* 128 */       this.eventProcessor = Objects.<FluxProcessor<Event, Event>>requireNonNull(eventProcessor);
/* 129 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder overflowStrategy(FluxSink.OverflowStrategy overflowStrategy) {
/* 134 */       this.overflowStrategy = Objects.<FluxSink.OverflowStrategy>requireNonNull(overflowStrategy);
/* 135 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder eventScheduler(Scheduler eventScheduler) {
/* 140 */       this.eventScheduler = Objects.<Scheduler>requireNonNull(eventScheduler);
/* 141 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public EventDispatcher build() {
/* 146 */       if (this.eventProcessor == null) {
/* 147 */         this.eventProcessor = (FluxProcessor<Event, Event>)EmitterProcessor.create(Queues.SMALL_BUFFER_SIZE, false);
/*     */       }
/* 149 */       if (this.eventScheduler == null) {
/* 150 */         this.eventScheduler = EventDispatcher.DEFAULT_EVENT_SCHEDULER.get();
/*     */       }
/* 152 */       return new DefaultEventDispatcher(this.eventProcessor, this.overflowStrategy, this.eventScheduler);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\event\DefaultEventDispatcher.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */