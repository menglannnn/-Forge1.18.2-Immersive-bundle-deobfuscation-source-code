package discord4j.core.spec;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import org.immutables.value.Value;
import org.immutables.value.Value.Style;

@Target({ElementType.PACKAGE})
@Retention(RetentionPolicy.CLASS)
@Style(typeAbstract = {"*Generator"}, typeImmutable = "*", visibility = Value.Style.ImplementationVisibility.PUBLIC, deepImmutablesDetection = true, allMandatoryParameters = true, depluralize = true, instance = "create")
public @interface SpecStyle {}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\SpecStyle.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */