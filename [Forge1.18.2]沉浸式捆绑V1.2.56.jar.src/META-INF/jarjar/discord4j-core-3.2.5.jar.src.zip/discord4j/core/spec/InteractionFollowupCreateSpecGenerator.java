/*    */ package discord4j.core.spec;
/*    */ 
/*    */ import discord4j.core.object.component.LayoutComponent;
/*    */ import discord4j.core.object.component.MessageComponent;
/*    */ import discord4j.core.object.entity.Message;
/*    */ import discord4j.discordjson.json.FollowupMessageRequest;
/*    */ import discord4j.discordjson.json.ImmutableFollowupMessageRequest;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import discord4j.rest.util.AllowedMentions;
/*    */ import discord4j.rest.util.MultipartRequest;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import java.util.stream.Collectors;
/*    */ import java.util.stream.Stream;
/*    */ import org.immutables.value.Value.Default;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Immutable(singleton = true)
/*    */ interface InteractionFollowupCreateSpecGenerator
/*    */   extends Spec<MultipartRequest<FollowupMessageRequest>>
/*    */ {
/*    */   @Default
/*    */   default boolean tts() {
/* 49 */     return false;
/*    */   }
/*    */   
/*    */   @Default
/*    */   default List<MessageCreateFields.File> files() {
/* 54 */     return Collections.emptyList();
/*    */   }
/*    */   
/*    */   @Default
/*    */   default List<MessageCreateFields.FileSpoiler> fileSpoilers() {
/* 59 */     return Collections.emptyList();
/*    */   }
/*    */   
/*    */   @Default
/*    */   default List<EmbedCreateSpec> embeds() {
/* 64 */     return Collections.emptyList();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   default MultipartRequest<FollowupMessageRequest> asRequest() {
/* 86 */     ImmutableFollowupMessageRequest immutableFollowupMessageRequest = FollowupMessageRequest.builder().content(content()).username(username()).avatarUrl(avatarUrl()).tts(Boolean.valueOf(tts())).embeds((List)embeds().stream().map(EmbedCreateSpecGenerator::asRequest).collect(Collectors.toList())).allowedMentions(InternalSpecUtils.mapPossible(allowedMentions(), AllowedMentions::toData)).components(InternalSpecUtils.mapPossible(components(), components -> (List)components.stream().map(MessageComponent::getData).collect(Collectors.toList()))).flags(InternalSpecUtils.mapPossible(ephemeral(), eph -> Integer.valueOf(eph.booleanValue() ? Message.Flag.EPHEMERAL.getFlag() : 0))).build();
/* 87 */     return MultipartRequest.ofRequestAndFiles(immutableFollowupMessageRequest, (List)Stream.concat(files().stream(), fileSpoilers().stream())
/* 88 */         .map(MessageCreateFields.File::asRequest)
/* 89 */         .collect(Collectors.toList()));
/*    */   }
/*    */   
/*    */   Possible<String> content();
/*    */   
/*    */   Possible<String> username();
/*    */   
/*    */   Possible<String> avatarUrl();
/*    */   
/*    */   Possible<AllowedMentions> allowedMentions();
/*    */   
/*    */   Possible<List<LayoutComponent>> components();
/*    */   
/*    */   Possible<Boolean> ephemeral();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\InteractionFollowupCreateSpecGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */