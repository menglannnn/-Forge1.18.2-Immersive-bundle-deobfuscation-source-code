/*     */ package discord4j.core.spec;
/*     */ 
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.object.audit.ActionType;
/*     */ import discord4j.core.object.audit.AuditLogPart;
/*     */ import discord4j.core.object.entity.Guild;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ @Generated(from = "AuditLogQueryFluxGenerator", generator = "Immutables")
/*     */ public final class AuditLogQueryFlux
/*     */   extends AuditLogQueryFluxGenerator
/*     */ {
/*     */   @Nullable
/*     */   private final Snowflake userId;
/*     */   @Nullable
/*     */   private final ActionType actionType;
/*     */   @Nullable
/*     */   private final Snowflake before;
/*     */   @Nullable
/*     */   private final Integer limit;
/*     */   private final Guild guild;
/*     */   
/*     */   private AuditLogQueryFlux(Guild guild) {
/*  28 */     this.guild = Objects.<Guild>requireNonNull(guild, "guild");
/*  29 */     this.userId = null;
/*  30 */     this.actionType = null;
/*  31 */     this.before = null;
/*  32 */     this.limit = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private AuditLogQueryFlux(@Nullable Snowflake userId, @Nullable ActionType actionType, @Nullable Snowflake before, @Nullable Integer limit, Guild guild) {
/*  41 */     this.userId = userId;
/*  42 */     this.actionType = actionType;
/*  43 */     this.before = before;
/*  44 */     this.limit = limit;
/*  45 */     this.guild = guild;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Snowflake userId() {
/*  53 */     return this.userId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public ActionType actionType() {
/*  61 */     return this.actionType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Snowflake before() {
/*  69 */     return this.before;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Integer limit() {
/*  77 */     return this.limit;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Guild guild() {
/*  85 */     return this.guild;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final AuditLogQueryFlux withUserId(@Nullable Snowflake value) {
/*  95 */     if (this.userId == value) return this; 
/*  96 */     return new AuditLogQueryFlux(value, this.actionType, this.before, this.limit, this.guild);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final AuditLogQueryFlux withActionType(@Nullable ActionType value) {
/* 106 */     if (this.actionType == value) return this; 
/* 107 */     return new AuditLogQueryFlux(this.userId, value, this.before, this.limit, this.guild);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final AuditLogQueryFlux withBefore(@Nullable Snowflake value) {
/* 117 */     if (this.before == value) return this; 
/* 118 */     return new AuditLogQueryFlux(this.userId, this.actionType, value, this.limit, this.guild);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final AuditLogQueryFlux withLimit(@Nullable Integer value) {
/* 128 */     if (Objects.equals(this.limit, value)) return this; 
/* 129 */     return new AuditLogQueryFlux(this.userId, this.actionType, this.before, value, this.guild);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final AuditLogQueryFlux withGuild(Guild value) {
/* 139 */     if (this.guild == value) return this; 
/* 140 */     Guild newValue = Objects.<Guild>requireNonNull(value, "guild");
/* 141 */     return new AuditLogQueryFlux(this.userId, this.actionType, this.before, this.limit, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 150 */     if (this == another) return true; 
/* 151 */     return (another instanceof AuditLogQueryFlux && 
/* 152 */       equalTo(0, (AuditLogQueryFlux)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, AuditLogQueryFlux another) {
/* 156 */     return (Objects.equals(this.userId, another.userId) && 
/* 157 */       Objects.equals(this.actionType, another.actionType) && 
/* 158 */       Objects.equals(this.before, another.before) && 
/* 159 */       Objects.equals(this.limit, another.limit) && this.guild
/* 160 */       .equals(another.guild));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 169 */     int h = 5381;
/* 170 */     h += (h << 5) + Objects.hashCode(this.userId);
/* 171 */     h += (h << 5) + Objects.hashCode(this.actionType);
/* 172 */     h += (h << 5) + Objects.hashCode(this.before);
/* 173 */     h += (h << 5) + Objects.hashCode(this.limit);
/* 174 */     h += (h << 5) + this.guild.hashCode();
/* 175 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 184 */     return "AuditLogQueryFlux{userId=" + this.userId + ", actionType=" + this.actionType + ", before=" + this.before + ", limit=" + this.limit + ", guild=" + this.guild + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AuditLogQueryFlux of(Guild guild) {
/* 199 */     return new AuditLogQueryFlux(guild);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static AuditLogQueryFlux copyOf(AuditLogQueryFluxGenerator instance) {
/* 210 */     if (instance instanceof AuditLogQueryFlux) {
/* 211 */       return (AuditLogQueryFlux)instance;
/*     */     }
/* 213 */     return of(instance.guild())
/* 214 */       .withUserId(instance.userId())
/* 215 */       .withActionType(instance.actionType())
/* 216 */       .withBefore(instance.before())
/* 217 */       .withLimit(instance.limit());
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\AuditLogQueryFlux.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */