/*    */ package discord4j.core.spec;
/*    */ 
/*    */ import discord4j.discordjson.json.TemplateCreateRequest;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import java.util.Optional;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Immutable
/*    */ interface GuildTemplateCreateSpecGenerator
/*    */   extends Spec<TemplateCreateRequest>
/*    */ {
/*    */   default TemplateCreateRequest asRequest() {
/* 39 */     return (TemplateCreateRequest)TemplateCreateRequest.builder()
/* 40 */       .name(name())
/* 41 */       .description(description())
/* 42 */       .build();
/*    */   }
/*    */   
/*    */   Possible<Optional<String>> description();
/*    */   
/*    */   String name();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\GuildTemplateCreateSpecGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */