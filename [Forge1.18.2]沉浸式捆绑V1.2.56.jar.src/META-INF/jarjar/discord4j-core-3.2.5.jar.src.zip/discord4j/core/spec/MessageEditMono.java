/*     */ package discord4j.core.spec;
/*     */ 
/*     */ import discord4j.core.object.component.LayoutComponent;
/*     */ import discord4j.core.object.entity.Attachment;
/*     */ import discord4j.core.object.entity.Message;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import discord4j.rest.util.AllowedMentions;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.stream.StreamSupport;
/*     */ import org.immutables.value.Generated;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "MessageEditMonoGenerator", generator = "Immutables")
/*     */ public final class MessageEditMono
/*     */   extends MessageEditMonoGenerator
/*     */ {
/*     */   private final String content_value;
/*     */   private final boolean content_absent;
/*     */   private final List<EmbedCreateSpec> embeds_value;
/*     */   private final boolean embeds_absent;
/*     */   private final List<MessageCreateFields.File> files;
/*     */   private final List<MessageCreateFields.FileSpoiler> fileSpoilers;
/*     */   private final AllowedMentions allowedMentions_value;
/*     */   private final boolean allowedMentions_absent;
/*     */   private final List<Message.Flag> flags_value;
/*     */   private final boolean flags_absent;
/*     */   private final List<LayoutComponent> components_value;
/*     */   private final boolean components_absent;
/*     */   private final List<Attachment> attachments_value;
/*     */   private final boolean attachments_absent;
/*     */   private final Message message;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   private volatile transient InitShim initShim;
/*     */   
/*     */   private MessageEditMono(Message message) {
/* 109 */     this.initShim = new InitShim(); this.message = Objects.<Message>requireNonNull(message, "message"); Possible<Optional<String>> content$impl = Possible.absent(); Possible<Optional<List<EmbedCreateSpec>>> embeds$impl = Possible.absent(); Possible<Optional<AllowedMentions>> allowedMentions$impl = Possible.absent(); Possible<Optional<List<Message.Flag>>> flags$impl = Possible.absent(); Possible<Optional<List<LayoutComponent>>> components$impl = Possible.absent(); Possible<Optional<List<Attachment>>> attachments$impl = Possible.absent(); this.content_value = Possible.flatOpt(content$impl).orElse(null); this.content_absent = content$impl.isAbsent(); this.embeds_value = Possible.flatOpt(embeds$impl).orElse(null); this.embeds_absent = embeds$impl.isAbsent(); this.allowedMentions_value = Possible.flatOpt(allowedMentions$impl).orElse(null); this.allowedMentions_absent = allowedMentions$impl.isAbsent(); this.flags_value = Possible.flatOpt(flags$impl).orElse(null); this.flags_absent = flags$impl.isAbsent(); this.components_value = Possible.flatOpt(components$impl).orElse(null); this.components_absent = components$impl.isAbsent(); this.attachments_value = Possible.flatOpt(attachments$impl).orElse(null); this.attachments_absent = attachments$impl.isAbsent(); this.files = this.initShim.files(); this.fileSpoilers = this.initShim.fileSpoilers(); this.initShim = null; } private MessageEditMono(Possible<Optional<String>> content, Possible<Optional<List<EmbedCreateSpec>>> embeds, List<MessageCreateFields.File> files, List<MessageCreateFields.FileSpoiler> fileSpoilers, Possible<Optional<AllowedMentions>> allowedMentions, Possible<Optional<List<Message.Flag>>> flags, Possible<Optional<List<LayoutComponent>>> components, Possible<Optional<List<Attachment>>> attachments, Message message) { this.initShim = new InitShim(); Possible<Optional<String>> content$impl = content; Possible<Optional<List<EmbedCreateSpec>>> embeds$impl = embeds; this.initShim.files(files); this.initShim.fileSpoilers(fileSpoilers); Possible<Optional<AllowedMentions>> allowedMentions$impl = allowedMentions; Possible<Optional<List<Message.Flag>>> flags$impl = flags; Possible<Optional<List<LayoutComponent>>> components$impl = components; Possible<Optional<List<Attachment>>> attachments$impl = attachments; this.message = message; this.content_value = Possible.flatOpt(content$impl).orElse(null); this.content_absent = content$impl.isAbsent(); this.embeds_value = Possible.flatOpt(embeds$impl).orElse(null); this.embeds_absent = embeds$impl.isAbsent(); this.allowedMentions_value = Possible.flatOpt(allowedMentions$impl).orElse(null); this.allowedMentions_absent = allowedMentions$impl.isAbsent(); this.flags_value = Possible.flatOpt(flags$impl).orElse(null); this.flags_absent = flags$impl.isAbsent(); this.components_value = Possible.flatOpt(components$impl).orElse(null); this.components_absent = components$impl.isAbsent();
/*     */     this.attachments_value = Possible.flatOpt(attachments$impl).orElse(null);
/*     */     this.attachments_absent = attachments$impl.isAbsent();
/*     */     this.files = this.initShim.files();
/*     */     this.fileSpoilers = this.initShim.fileSpoilers();
/* 114 */     this.initShim = null; } @Generated(from = "MessageEditMonoGenerator", generator = "Immutables") private final class InitShim { private byte filesBuildStage = 0;
/*     */     private List<MessageCreateFields.File> files;
/*     */     
/*     */     List<MessageCreateFields.File> files() {
/* 118 */       if (this.filesBuildStage == -1) throw new IllegalStateException(formatInitCycleMessage()); 
/* 119 */       if (this.filesBuildStage == 0) {
/* 120 */         this.filesBuildStage = -1;
/* 121 */         this.files = (List)MessageEditMono.createUnmodifiableList(false, MessageEditMono.createSafeList((Iterable)MessageEditMono.this.files(), true, false));
/* 122 */         this.filesBuildStage = 1;
/*     */       } 
/* 124 */       return this.files;
/*     */     }
/*     */     
/*     */     void files(List<MessageCreateFields.File> files) {
/* 128 */       this.files = files;
/* 129 */       this.filesBuildStage = 1;
/*     */     }
/*     */     
/* 132 */     private byte fileSpoilersBuildStage = 0;
/*     */     private List<MessageCreateFields.FileSpoiler> fileSpoilers;
/*     */     
/*     */     List<MessageCreateFields.FileSpoiler> fileSpoilers() {
/* 136 */       if (this.fileSpoilersBuildStage == -1) throw new IllegalStateException(formatInitCycleMessage()); 
/* 137 */       if (this.fileSpoilersBuildStage == 0) {
/* 138 */         this.fileSpoilersBuildStage = -1;
/* 139 */         this.fileSpoilers = (List)MessageEditMono.createUnmodifiableList(false, MessageEditMono.createSafeList((Iterable)MessageEditMono.this.fileSpoilers(), true, false));
/* 140 */         this.fileSpoilersBuildStage = 1;
/*     */       } 
/* 142 */       return this.fileSpoilers;
/*     */     }
/*     */     
/*     */     void fileSpoilers(List<MessageCreateFields.FileSpoiler> fileSpoilers) {
/* 146 */       this.fileSpoilers = fileSpoilers;
/* 147 */       this.fileSpoilersBuildStage = 1;
/*     */     }
/*     */     
/*     */     private String formatInitCycleMessage() {
/* 151 */       List<String> attributes = new ArrayList<>();
/* 152 */       if (this.filesBuildStage == -1) attributes.add("files"); 
/* 153 */       if (this.fileSpoilersBuildStage == -1) attributes.add("fileSpoilers"); 
/* 154 */       return "Cannot build MessageEditMono, attribute initializers form cycle " + attributes;
/*     */     }
/*     */ 
/*     */     
/*     */     private InitShim() {} }
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Optional<String>> content() {
/* 163 */     return this.content_absent ? Possible.absent() : 
/* 164 */       Possible.of(Optional.ofNullable(this.content_value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Optional<List<EmbedCreateSpec>>> embeds() {
/* 172 */     return this.embeds_absent ? Possible.absent() : 
/* 173 */       Possible.of(Optional.ofNullable(this.embeds_value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<MessageCreateFields.File> files() {
/* 181 */     InitShim shim = this.initShim;
/* 182 */     return (shim != null) ? 
/* 183 */       shim.files() : 
/* 184 */       this.files;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<MessageCreateFields.FileSpoiler> fileSpoilers() {
/* 192 */     InitShim shim = this.initShim;
/* 193 */     return (shim != null) ? 
/* 194 */       shim.fileSpoilers() : 
/* 195 */       this.fileSpoilers;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Optional<AllowedMentions>> allowedMentions() {
/* 203 */     return this.allowedMentions_absent ? Possible.absent() : 
/* 204 */       Possible.of(Optional.ofNullable(this.allowedMentions_value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Optional<List<Message.Flag>>> flags() {
/* 212 */     return this.flags_absent ? Possible.absent() : 
/* 213 */       Possible.of(Optional.ofNullable(this.flags_value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Optional<List<LayoutComponent>>> components() {
/* 221 */     return this.components_absent ? Possible.absent() : 
/* 222 */       Possible.of(Optional.ofNullable(this.components_value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Optional<List<Attachment>>> attachments() {
/* 230 */     return this.attachments_absent ? Possible.absent() : 
/* 231 */       Possible.of(Optional.ofNullable(this.attachments_value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Message message() {
/* 239 */     return this.message;
/*     */   }
/*     */   
/*     */   public MessageEditMono withContent(Possible<Optional<String>> value) {
/* 243 */     Possible<Optional<String>> newValue = Objects.<Possible<Optional<String>>>requireNonNull(value);
/* 244 */     return new MessageEditMono(newValue, 
/*     */         
/* 246 */         embeds(), this.files, this.fileSpoilers, 
/*     */ 
/*     */         
/* 249 */         allowedMentions(), 
/* 250 */         flags(), 
/* 251 */         components(), 
/* 252 */         attachments(), this.message);
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public MessageEditMono withContent(@Nullable String value) {
/* 258 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/* 259 */     return new MessageEditMono(newValue, 
/*     */         
/* 261 */         embeds(), this.files, this.fileSpoilers, 
/*     */ 
/*     */         
/* 264 */         allowedMentions(), 
/* 265 */         flags(), 
/* 266 */         components(), 
/* 267 */         attachments(), this.message);
/*     */   }
/*     */ 
/*     */   
/*     */   public MessageEditMono withContentOrNull(@Nullable String value) {
/* 272 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/* 273 */     return new MessageEditMono(newValue, 
/*     */         
/* 275 */         embeds(), this.files, this.fileSpoilers, 
/*     */ 
/*     */         
/* 278 */         allowedMentions(), 
/* 279 */         flags(), 
/* 280 */         components(), 
/* 281 */         attachments(), this.message);
/*     */   }
/*     */ 
/*     */   
/*     */   public MessageEditMono withEmbeds(Possible<Optional<List<EmbedCreateSpec>>> possible) {
/* 286 */     Possible<Optional<List<EmbedCreateSpec>>> newValue = Objects.<Possible<Optional<List<EmbedCreateSpec>>>>requireNonNull(possible);
/* 287 */     return new MessageEditMono(
/* 288 */         content(), newValue, this.files, this.fileSpoilers, 
/*     */ 
/*     */ 
/*     */         
/* 292 */         allowedMentions(), 
/* 293 */         flags(), 
/* 294 */         components(), 
/* 295 */         attachments(), this.message);
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public MessageEditMono withEmbeds(@Nullable Iterable<EmbedCreateSpec> elements) {
/* 301 */     Possible<Optional<List<EmbedCreateSpec>>> newValue = Possible.of(Optional.<Iterable<EmbedCreateSpec>>ofNullable(elements)
/* 302 */         .map(els -> (List)StreamSupport.stream(els.spliterator(), false).collect(Collectors.toList())));
/* 303 */     return new MessageEditMono(
/* 304 */         content(), newValue, this.files, this.fileSpoilers, 
/*     */ 
/*     */ 
/*     */         
/* 308 */         allowedMentions(), 
/* 309 */         flags(), 
/* 310 */         components(), 
/* 311 */         attachments(), this.message);
/*     */   }
/*     */ 
/*     */   
/*     */   public MessageEditMono withEmbedsOrNull(@Nullable Iterable<EmbedCreateSpec> elements) {
/* 316 */     Possible<Optional<List<EmbedCreateSpec>>> newValue = Possible.of(Optional.<Iterable<EmbedCreateSpec>>ofNullable(elements)
/* 317 */         .map(els -> (List)StreamSupport.stream(els.spliterator(), false).collect(Collectors.toList())));
/* 318 */     return new MessageEditMono(
/* 319 */         content(), newValue, this.files, this.fileSpoilers, 
/*     */ 
/*     */ 
/*     */         
/* 323 */         allowedMentions(), 
/* 324 */         flags(), 
/* 325 */         components(), 
/* 326 */         attachments(), this.message);
/*     */   }
/*     */ 
/*     */   
/*     */   @SafeVarargs
/*     */   public final MessageEditMono withEmbeds(EmbedCreateSpec... elements) {
/* 332 */     Possible<Optional<List<EmbedCreateSpec>>> newValue = Possible.of(Optional.of(Arrays.asList(elements)));
/* 333 */     return new MessageEditMono(
/* 334 */         content(), newValue, this.files, this.fileSpoilers, 
/*     */ 
/*     */ 
/*     */         
/* 338 */         allowedMentions(), 
/* 339 */         flags(), 
/* 340 */         components(), 
/* 341 */         attachments(), this.message);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final MessageEditMono withFiles(MessageCreateFields.File... elements) {
/* 351 */     List<MessageCreateFields.File> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/* 352 */     return new MessageEditMono(
/* 353 */         content(), 
/* 354 */         embeds(), newValue, this.fileSpoilers, 
/*     */ 
/*     */         
/* 357 */         allowedMentions(), 
/* 358 */         flags(), 
/* 359 */         components(), 
/* 360 */         attachments(), this.message);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final MessageEditMono withFiles(Iterable<? extends MessageCreateFields.File> elements) {
/* 371 */     if (this.files == elements) return this; 
/* 372 */     List<MessageCreateFields.File> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/* 373 */     return new MessageEditMono(
/* 374 */         content(), 
/* 375 */         embeds(), newValue, this.fileSpoilers, 
/*     */ 
/*     */         
/* 378 */         allowedMentions(), 
/* 379 */         flags(), 
/* 380 */         components(), 
/* 381 */         attachments(), this.message);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final MessageEditMono withFileSpoilers(MessageCreateFields.FileSpoiler... elements) {
/* 391 */     List<MessageCreateFields.FileSpoiler> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/* 392 */     return new MessageEditMono(
/* 393 */         content(), 
/* 394 */         embeds(), this.files, newValue, 
/*     */ 
/*     */         
/* 397 */         allowedMentions(), 
/* 398 */         flags(), 
/* 399 */         components(), 
/* 400 */         attachments(), this.message);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final MessageEditMono withFileSpoilers(Iterable<? extends MessageCreateFields.FileSpoiler> elements) {
/* 411 */     if (this.fileSpoilers == elements) return this; 
/* 412 */     List<MessageCreateFields.FileSpoiler> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/* 413 */     return new MessageEditMono(
/* 414 */         content(), 
/* 415 */         embeds(), this.files, newValue, 
/*     */ 
/*     */         
/* 418 */         allowedMentions(), 
/* 419 */         flags(), 
/* 420 */         components(), 
/* 421 */         attachments(), this.message);
/*     */   }
/*     */ 
/*     */   
/*     */   public MessageEditMono withAllowedMentions(Possible<Optional<AllowedMentions>> value) {
/* 426 */     Possible<Optional<AllowedMentions>> newValue = Objects.<Possible<Optional<AllowedMentions>>>requireNonNull(value);
/* 427 */     return new MessageEditMono(
/* 428 */         content(), 
/* 429 */         embeds(), this.files, this.fileSpoilers, newValue, 
/*     */ 
/*     */ 
/*     */         
/* 433 */         flags(), 
/* 434 */         components(), 
/* 435 */         attachments(), this.message);
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public MessageEditMono withAllowedMentions(@Nullable AllowedMentions value) {
/* 441 */     Possible<Optional<AllowedMentions>> newValue = Possible.of(Optional.ofNullable(value));
/* 442 */     return new MessageEditMono(
/* 443 */         content(), 
/* 444 */         embeds(), this.files, this.fileSpoilers, newValue, 
/*     */ 
/*     */ 
/*     */         
/* 448 */         flags(), 
/* 449 */         components(), 
/* 450 */         attachments(), this.message);
/*     */   }
/*     */ 
/*     */   
/*     */   public MessageEditMono withAllowedMentionsOrNull(@Nullable AllowedMentions value) {
/* 455 */     Possible<Optional<AllowedMentions>> newValue = Possible.of(Optional.ofNullable(value));
/* 456 */     return new MessageEditMono(
/* 457 */         content(), 
/* 458 */         embeds(), this.files, this.fileSpoilers, newValue, 
/*     */ 
/*     */ 
/*     */         
/* 462 */         flags(), 
/* 463 */         components(), 
/* 464 */         attachments(), this.message);
/*     */   }
/*     */ 
/*     */   
/*     */   public MessageEditMono withFlags(Possible<Optional<List<Message.Flag>>> possible) {
/* 469 */     Possible<Optional<List<Message.Flag>>> newValue = Objects.<Possible<Optional<List<Message.Flag>>>>requireNonNull(possible);
/* 470 */     return new MessageEditMono(
/* 471 */         content(), 
/* 472 */         embeds(), this.files, this.fileSpoilers, 
/*     */ 
/*     */         
/* 475 */         allowedMentions(), newValue, 
/*     */         
/* 477 */         components(), 
/* 478 */         attachments(), this.message);
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public MessageEditMono withFlags(@Nullable Iterable<Message.Flag> elements) {
/* 484 */     Possible<Optional<List<Message.Flag>>> newValue = Possible.of(Optional.<Iterable<Message.Flag>>ofNullable(elements)
/* 485 */         .map(els -> (List)StreamSupport.stream(els.spliterator(), false).collect(Collectors.toList())));
/* 486 */     return new MessageEditMono(
/* 487 */         content(), 
/* 488 */         embeds(), this.files, this.fileSpoilers, 
/*     */ 
/*     */         
/* 491 */         allowedMentions(), newValue, 
/*     */         
/* 493 */         components(), 
/* 494 */         attachments(), this.message);
/*     */   }
/*     */ 
/*     */   
/*     */   public MessageEditMono withFlagsOrNull(@Nullable Iterable<Message.Flag> elements) {
/* 499 */     Possible<Optional<List<Message.Flag>>> newValue = Possible.of(Optional.<Iterable<Message.Flag>>ofNullable(elements)
/* 500 */         .map(els -> (List)StreamSupport.stream(els.spliterator(), false).collect(Collectors.toList())));
/* 501 */     return new MessageEditMono(
/* 502 */         content(), 
/* 503 */         embeds(), this.files, this.fileSpoilers, 
/*     */ 
/*     */         
/* 506 */         allowedMentions(), newValue, 
/*     */         
/* 508 */         components(), 
/* 509 */         attachments(), this.message);
/*     */   }
/*     */ 
/*     */   
/*     */   @SafeVarargs
/*     */   public final MessageEditMono withFlags(Message.Flag... elements) {
/* 515 */     Possible<Optional<List<Message.Flag>>> newValue = Possible.of(Optional.of(Arrays.asList(elements)));
/* 516 */     return new MessageEditMono(
/* 517 */         content(), 
/* 518 */         embeds(), this.files, this.fileSpoilers, 
/*     */ 
/*     */         
/* 521 */         allowedMentions(), newValue, 
/*     */         
/* 523 */         components(), 
/* 524 */         attachments(), this.message);
/*     */   }
/*     */ 
/*     */   
/*     */   public MessageEditMono withComponents(Possible<Optional<List<LayoutComponent>>> possible) {
/* 529 */     Possible<Optional<List<LayoutComponent>>> newValue = Objects.<Possible<Optional<List<LayoutComponent>>>>requireNonNull(possible);
/* 530 */     return new MessageEditMono(
/* 531 */         content(), 
/* 532 */         embeds(), this.files, this.fileSpoilers, 
/*     */ 
/*     */         
/* 535 */         allowedMentions(), 
/* 536 */         flags(), newValue, 
/*     */         
/* 538 */         attachments(), this.message);
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public MessageEditMono withComponents(@Nullable Iterable<LayoutComponent> elements) {
/* 544 */     Possible<Optional<List<LayoutComponent>>> newValue = Possible.of(Optional.<Iterable<LayoutComponent>>ofNullable(elements)
/* 545 */         .map(els -> (List)StreamSupport.stream(els.spliterator(), false).collect(Collectors.toList())));
/* 546 */     return new MessageEditMono(
/* 547 */         content(), 
/* 548 */         embeds(), this.files, this.fileSpoilers, 
/*     */ 
/*     */         
/* 551 */         allowedMentions(), 
/* 552 */         flags(), newValue, 
/*     */         
/* 554 */         attachments(), this.message);
/*     */   }
/*     */ 
/*     */   
/*     */   public MessageEditMono withComponentsOrNull(@Nullable Iterable<LayoutComponent> elements) {
/* 559 */     Possible<Optional<List<LayoutComponent>>> newValue = Possible.of(Optional.<Iterable<LayoutComponent>>ofNullable(elements)
/* 560 */         .map(els -> (List)StreamSupport.stream(els.spliterator(), false).collect(Collectors.toList())));
/* 561 */     return new MessageEditMono(
/* 562 */         content(), 
/* 563 */         embeds(), this.files, this.fileSpoilers, 
/*     */ 
/*     */         
/* 566 */         allowedMentions(), 
/* 567 */         flags(), newValue, 
/*     */         
/* 569 */         attachments(), this.message);
/*     */   }
/*     */ 
/*     */   
/*     */   @SafeVarargs
/*     */   public final MessageEditMono withComponents(LayoutComponent... elements) {
/* 575 */     Possible<Optional<List<LayoutComponent>>> newValue = Possible.of(Optional.of(Arrays.asList(elements)));
/* 576 */     return new MessageEditMono(
/* 577 */         content(), 
/* 578 */         embeds(), this.files, this.fileSpoilers, 
/*     */ 
/*     */         
/* 581 */         allowedMentions(), 
/* 582 */         flags(), newValue, 
/*     */         
/* 584 */         attachments(), this.message);
/*     */   }
/*     */ 
/*     */   
/*     */   public MessageEditMono withAttachments(Possible<Optional<List<Attachment>>> possible) {
/* 589 */     Possible<Optional<List<Attachment>>> newValue = Objects.<Possible<Optional<List<Attachment>>>>requireNonNull(possible);
/* 590 */     return new MessageEditMono(
/* 591 */         content(), 
/* 592 */         embeds(), this.files, this.fileSpoilers, 
/*     */ 
/*     */         
/* 595 */         allowedMentions(), 
/* 596 */         flags(), 
/* 597 */         components(), newValue, this.message);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public MessageEditMono withAttachments(@Nullable Iterable<Attachment> elements) {
/* 604 */     Possible<Optional<List<Attachment>>> newValue = Possible.of(Optional.<Iterable<Attachment>>ofNullable(elements)
/* 605 */         .map(els -> (List)StreamSupport.stream(els.spliterator(), false).collect(Collectors.toList())));
/* 606 */     return new MessageEditMono(
/* 607 */         content(), 
/* 608 */         embeds(), this.files, this.fileSpoilers, 
/*     */ 
/*     */         
/* 611 */         allowedMentions(), 
/* 612 */         flags(), 
/* 613 */         components(), newValue, this.message);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public MessageEditMono withAttachmentsOrNull(@Nullable Iterable<Attachment> elements) {
/* 619 */     Possible<Optional<List<Attachment>>> newValue = Possible.of(Optional.<Iterable<Attachment>>ofNullable(elements)
/* 620 */         .map(els -> (List)StreamSupport.stream(els.spliterator(), false).collect(Collectors.toList())));
/* 621 */     return new MessageEditMono(
/* 622 */         content(), 
/* 623 */         embeds(), this.files, this.fileSpoilers, 
/*     */ 
/*     */         
/* 626 */         allowedMentions(), 
/* 627 */         flags(), 
/* 628 */         components(), newValue, this.message);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SafeVarargs
/*     */   public final MessageEditMono withAttachments(Attachment... elements) {
/* 635 */     Possible<Optional<List<Attachment>>> newValue = Possible.of(Optional.of(Arrays.asList(elements)));
/* 636 */     return new MessageEditMono(
/* 637 */         content(), 
/* 638 */         embeds(), this.files, this.fileSpoilers, 
/*     */ 
/*     */         
/* 641 */         allowedMentions(), 
/* 642 */         flags(), 
/* 643 */         components(), newValue, this.message);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final MessageEditMono withMessage(Message value) {
/* 655 */     if (this.message == value) return this; 
/* 656 */     Message newValue = Objects.<Message>requireNonNull(value, "message");
/* 657 */     return new MessageEditMono(
/* 658 */         content(), 
/* 659 */         embeds(), this.files, this.fileSpoilers, 
/*     */ 
/*     */         
/* 662 */         allowedMentions(), 
/* 663 */         flags(), 
/* 664 */         components(), 
/* 665 */         attachments(), newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 675 */     if (this == another) return true; 
/* 676 */     return (another instanceof MessageEditMono && 
/* 677 */       equalTo(0, (MessageEditMono)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, MessageEditMono another) {
/* 681 */     return (content().equals(another.content()) && 
/* 682 */       Objects.equals(this.embeds_value, another.embeds_value) && this.files
/* 683 */       .equals(another.files) && this.fileSpoilers
/* 684 */       .equals(another.fileSpoilers) && 
/* 685 */       allowedMentions().equals(another.allowedMentions()) && 
/* 686 */       Objects.equals(this.flags_value, another.flags_value) && 
/* 687 */       Objects.equals(this.components_value, another.components_value) && 
/* 688 */       Objects.equals(this.attachments_value, another.attachments_value) && this.message
/* 689 */       .equals(another.message));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 698 */     int h = 5381;
/* 699 */     h += (h << 5) + content().hashCode();
/* 700 */     h += (h << 5) + Objects.hashCode(this.embeds_value);
/* 701 */     h += (h << 5) + this.files.hashCode();
/* 702 */     h += (h << 5) + this.fileSpoilers.hashCode();
/* 703 */     h += (h << 5) + allowedMentions().hashCode();
/* 704 */     h += (h << 5) + Objects.hashCode(this.flags_value);
/* 705 */     h += (h << 5) + Objects.hashCode(this.components_value);
/* 706 */     h += (h << 5) + Objects.hashCode(this.attachments_value);
/* 707 */     h += (h << 5) + this.message.hashCode();
/* 708 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 717 */     return "MessageEditMono{content=" + 
/* 718 */       content().toString() + ", embeds=" + 
/* 719 */       Objects.toString(this.embeds_value) + ", files=" + this.files + ", fileSpoilers=" + this.fileSpoilers + ", allowedMentions=" + 
/*     */ 
/*     */       
/* 722 */       allowedMentions().toString() + ", flags=" + 
/* 723 */       Objects.toString(this.flags_value) + ", components=" + 
/* 724 */       Objects.toString(this.components_value) + ", attachments=" + 
/* 725 */       Objects.toString(this.attachments_value) + ", message=" + this.message + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MessageEditMono of(Message message) {
/* 736 */     return new MessageEditMono(message);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static MessageEditMono copyOf(MessageEditMonoGenerator instance) {
/* 747 */     if (instance instanceof MessageEditMono) {
/* 748 */       return (MessageEditMono)instance;
/*     */     }
/* 750 */     return of(instance.message())
/* 751 */       .withContent(instance.content())
/* 752 */       .withEmbeds(instance.embeds())
/* 753 */       .withFiles(instance.files())
/* 754 */       .withFileSpoilers(instance.fileSpoilers())
/* 755 */       .withAllowedMentions(instance.allowedMentions())
/* 756 */       .withFlags(instance.flags())
/* 757 */       .withComponents(instance.components())
/* 758 */       .withAttachments(instance.attachments());
/*     */   }
/*     */   
/*     */   public boolean isContentPresent() {
/* 762 */     return !this.content_absent;
/*     */   }
/*     */   
/*     */   public String contentOrElse(String defaultValue) {
/* 766 */     return !this.content_absent ? this.content_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isEmbedsPresent() {
/* 770 */     return !this.embeds_absent;
/*     */   }
/*     */   
/*     */   public List<EmbedCreateSpec> embedsOrElse(List<EmbedCreateSpec> defaultValue) {
/* 774 */     return !this.embeds_absent ? this.embeds_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isAllowedMentionsPresent() {
/* 778 */     return !this.allowedMentions_absent;
/*     */   }
/*     */   
/*     */   public AllowedMentions allowedMentionsOrElse(AllowedMentions defaultValue) {
/* 782 */     return !this.allowedMentions_absent ? this.allowedMentions_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isFlagsPresent() {
/* 786 */     return !this.flags_absent;
/*     */   }
/*     */   
/*     */   public List<Message.Flag> flagsOrElse(List<Message.Flag> defaultValue) {
/* 790 */     return !this.flags_absent ? this.flags_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isComponentsPresent() {
/* 794 */     return !this.components_absent;
/*     */   }
/*     */   
/*     */   public List<LayoutComponent> componentsOrElse(List<LayoutComponent> defaultValue) {
/* 798 */     return !this.components_absent ? this.components_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isAttachmentsPresent() {
/* 802 */     return !this.attachments_absent;
/*     */   }
/*     */   
/*     */   public List<Attachment> attachmentsOrElse(List<Attachment> defaultValue) {
/* 806 */     return !this.attachments_absent ? this.attachments_value : defaultValue;
/*     */   }
/*     */   
/*     */   private static <T> List<T> createSafeList(Iterable<? extends T> iterable, boolean checkNulls, boolean skipNulls) {
/*     */     ArrayList<T> list;
/* 811 */     if (iterable instanceof Collection) {
/* 812 */       int size = ((Collection)iterable).size();
/* 813 */       if (size == 0) return Collections.emptyList(); 
/* 814 */       list = new ArrayList<>();
/*     */     } else {
/* 816 */       list = new ArrayList<>();
/*     */     } 
/* 818 */     for (T element : iterable) {
/* 819 */       if (skipNulls && element == null)
/* 820 */         continue;  if (checkNulls) Objects.requireNonNull(element, "element"); 
/* 821 */       list.add(element);
/*     */     } 
/* 823 */     return list;
/*     */   }
/*     */   
/*     */   private static <T> List<T> createUnmodifiableList(boolean clone, List<T> list) {
/* 827 */     switch (list.size()) { case 0:
/* 828 */         return Collections.emptyList();
/* 829 */       case 1: return Collections.singletonList(list.get(0)); }
/*     */     
/* 831 */     if (clone) {
/* 832 */       return Collections.unmodifiableList(new ArrayList<>(list));
/*     */     }
/* 834 */     if (list instanceof ArrayList) {
/* 835 */       ((ArrayList)list).trimToSize();
/*     */     }
/* 837 */     return Collections.unmodifiableList(list);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\MessageEditMono.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */