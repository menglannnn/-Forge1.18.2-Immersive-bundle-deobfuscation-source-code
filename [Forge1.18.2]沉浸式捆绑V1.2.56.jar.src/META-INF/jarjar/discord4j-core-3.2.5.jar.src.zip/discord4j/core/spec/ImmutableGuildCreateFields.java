/*     */ package discord4j.core.spec;
/*     */ 
/*     */ import com.google.errorprone.annotations.CanIgnoreReturnValue;
/*     */ import discord4j.core.object.entity.channel.Channel;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "GuildCreateFields", generator = "Immutables")
/*     */ final class ImmutableGuildCreateFields
/*     */ {
/*     */   @Generated(from = "GuildCreateFields.PartialChannel", generator = "Immutables")
/*     */   static final class PartialChannel
/*     */     implements GuildCreateFields.PartialChannel
/*     */   {
/*     */     private final String name;
/*     */     private final Channel.Type type;
/*     */     
/*     */     private PartialChannel(String name, Channel.Type type) {
/*  36 */       this.name = Objects.<String>requireNonNull(name, "name");
/*  37 */       this.type = Objects.<Channel.Type>requireNonNull(type, "type");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private PartialChannel(PartialChannel original, String name, Channel.Type type) {
/*  44 */       this.name = name;
/*  45 */       this.type = type;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String name() {
/*  53 */       return this.name;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Channel.Type type() {
/*  61 */       return this.type;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final PartialChannel withName(String value) {
/*  71 */       String newValue = Objects.<String>requireNonNull(value, "name");
/*  72 */       if (this.name.equals(newValue)) return this; 
/*  73 */       return new PartialChannel(this, newValue, this.type);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final PartialChannel withType(Channel.Type value) {
/*  83 */       Channel.Type newValue = Objects.<Channel.Type>requireNonNull(value, "type");
/*  84 */       if (this.type == newValue) return this; 
/*  85 */       return new PartialChannel(this, this.name, newValue);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean equals(Object another) {
/*  94 */       if (this == another) return true; 
/*  95 */       return (another instanceof PartialChannel && 
/*  96 */         equalTo(0, (PartialChannel)another));
/*     */     }
/*     */     
/*     */     private boolean equalTo(int synthetic, PartialChannel another) {
/* 100 */       return (this.name.equals(another.name) && this.type
/* 101 */         .equals(another.type));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 110 */       int h = 5381;
/* 111 */       h += (h << 5) + this.name.hashCode();
/* 112 */       h += (h << 5) + this.type.hashCode();
/* 113 */       return h;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String toString() {
/* 122 */       return "PartialChannel{name=" + this.name + ", type=" + this.type + "}";
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static PartialChannel of(String name, Channel.Type type) {
/* 135 */       return new PartialChannel(name, type);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static PartialChannel copyOf(GuildCreateFields.PartialChannel instance) {
/* 146 */       if (instance instanceof PartialChannel) {
/* 147 */         return (PartialChannel)instance;
/*     */       }
/* 149 */       return builder()
/* 150 */         .from(instance)
/* 151 */         .build();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Builder builder() {
/* 165 */       return new Builder();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     @Generated(from = "GuildCreateFields.PartialChannel", generator = "Immutables")
/*     */     public static final class Builder
/*     */     {
/*     */       private static final long INIT_BIT_NAME = 1L;
/*     */ 
/*     */       
/*     */       private static final long INIT_BIT_TYPE = 2L;
/*     */ 
/*     */       
/* 179 */       private long initBits = 3L;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       private String name;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       private Channel.Type type;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @CanIgnoreReturnValue
/*     */       public final Builder from(GuildCreateFields.PartialChannel instance) {
/* 196 */         Objects.requireNonNull(instance, "instance");
/* 197 */         name(instance.name());
/* 198 */         type(instance.type());
/* 199 */         return this;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @CanIgnoreReturnValue
/*     */       public final Builder name(String name) {
/* 209 */         this.name = Objects.<String>requireNonNull(name, "name");
/* 210 */         this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 211 */         return this;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @CanIgnoreReturnValue
/*     */       public final Builder type(Channel.Type type) {
/* 221 */         this.type = Objects.<Channel.Type>requireNonNull(type, "type");
/* 222 */         this.initBits &= 0xFFFFFFFFFFFFFFFDL;
/* 223 */         return this;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public ImmutableGuildCreateFields.PartialChannel build() {
/* 232 */         if (this.initBits != 0L) {
/* 233 */           throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */         }
/* 235 */         return new ImmutableGuildCreateFields.PartialChannel(null, this.name, this.type);
/*     */       }
/*     */       
/*     */       private String formatRequiredAttributesMessage() {
/* 239 */         List<String> attributes = new ArrayList<>();
/* 240 */         if ((this.initBits & 0x1L) != 0L) attributes.add("name"); 
/* 241 */         if ((this.initBits & 0x2L) != 0L) attributes.add("type"); 
/* 242 */         return "Cannot build PartialChannel, some of required attributes are not set " + attributes;
/*     */       }
/*     */       
/*     */       private Builder() {}
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\ImmutableGuildCreateFields.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */