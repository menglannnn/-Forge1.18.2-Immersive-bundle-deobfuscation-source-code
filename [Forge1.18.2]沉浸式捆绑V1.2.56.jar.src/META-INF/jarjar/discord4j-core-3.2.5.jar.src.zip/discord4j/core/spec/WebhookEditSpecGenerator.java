/*    */ package discord4j.core.spec;
/*    */ 
/*    */ import discord4j.common.util.Snowflake;
/*    */ import discord4j.discordjson.json.WebhookModifyRequest;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import discord4j.rest.util.Image;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Immutable(singleton = true)
/*    */ interface WebhookEditSpecGenerator
/*    */   extends AuditSpec<WebhookModifyRequest>
/*    */ {
/*    */   default WebhookModifyRequest asRequest() {
/* 42 */     return (WebhookModifyRequest)WebhookModifyRequest.builder()
/* 43 */       .name(name())
/* 44 */       .avatar(InternalSpecUtils.mapPossible(avatar(), Image::getDataUri))
/* 45 */       .channelId(InternalSpecUtils.mapPossible(channelId(), Snowflake::asString))
/* 46 */       .build();
/*    */   }
/*    */   
/*    */   Possible<Snowflake> channelId();
/*    */   
/*    */   Possible<Image> avatar();
/*    */   
/*    */   Possible<String> name();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\WebhookEditSpecGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */