/*    */ package discord4j.core.spec;
/*    */ 
/*    */ import discord4j.common.util.Snowflake;
/*    */ import discord4j.core.object.PermissionOverwrite;
/*    */ import discord4j.discordjson.json.ChannelModifyRequest;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import java.util.List;
/*    */ import java.util.Optional;
/*    */ import java.util.stream.Collectors;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Immutable(singleton = true)
/*    */ interface TextChannelEditSpecGenerator
/*    */   extends AuditSpec<ChannelModifyRequest>
/*    */ {
/*    */   default ChannelModifyRequest asRequest() {
/* 54 */     return (ChannelModifyRequest)ChannelModifyRequest.builder()
/* 55 */       .name(name())
/* 56 */       .position(position())
/* 57 */       .topic(topic())
/* 58 */       .rateLimitPerUser(rateLimitPerUser())
/* 59 */       .nsfw(nsfw())
/* 60 */       .permissionOverwrites(InternalSpecUtils.mapPossible(permissionOverwrites(), po -> (List)po.stream().map(PermissionOverwrite::getData).collect(Collectors.toList())))
/*    */ 
/*    */       
/* 63 */       .parentId(InternalSpecUtils.mapPossibleOptional(parentId(), Snowflake::asString))
/* 64 */       .build();
/*    */   }
/*    */   
/*    */   Possible<String> name();
/*    */   
/*    */   Possible<Integer> position();
/*    */   
/*    */   Possible<String> topic();
/*    */   
/*    */   Possible<Integer> rateLimitPerUser();
/*    */   
/*    */   Possible<Boolean> nsfw();
/*    */   
/*    */   Possible<List<PermissionOverwrite>> permissionOverwrites();
/*    */   
/*    */   Possible<Optional<Snowflake>> parentId();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\TextChannelEditSpecGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */