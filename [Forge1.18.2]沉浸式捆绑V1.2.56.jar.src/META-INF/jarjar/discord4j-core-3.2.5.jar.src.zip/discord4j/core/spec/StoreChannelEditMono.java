/*     */ package discord4j.core.spec;
/*     */ 
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.object.PermissionOverwrite;
/*     */ import discord4j.core.object.entity.channel.StoreChannel;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.stream.StreamSupport;
/*     */ import org.immutables.value.Generated;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "StoreChannelEditMonoGenerator", generator = "Immutables")
/*     */ public final class StoreChannelEditMono
/*     */   extends StoreChannelEditMonoGenerator
/*     */ {
/*     */   @Nullable
/*     */   private final String reason;
/*     */   private final String name_value;
/*     */   private final boolean name_absent;
/*     */   private final Integer position_value;
/*     */   private final boolean position_absent;
/*     */   private final List<PermissionOverwrite> permissionOverwrites_value;
/*     */   private final boolean permissionOverwrites_absent;
/*     */   private final Snowflake parentId_value;
/*     */   private final boolean parentId_absent;
/*     */   private final StoreChannel channel;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   private volatile transient InitShim initShim;
/*     */   
/*     */   private StoreChannelEditMono(StoreChannel channel) {
/*  84 */     this.initShim = new InitShim(); this.channel = Objects.<StoreChannel>requireNonNull(channel, "channel"); this.reason = null; Possible<String> name$impl = Possible.absent(); Possible<Integer> position$impl = Possible.absent(); Possible<List<PermissionOverwrite>> permissionOverwrites$impl = Possible.absent(); Possible<Optional<Snowflake>> parentId$impl = Possible.absent(); this.name_value = name$impl.toOptional().orElse(null); this.name_absent = name$impl.isAbsent(); this.position_value = position$impl.toOptional().orElse(null); this.position_absent = position$impl.isAbsent(); this.permissionOverwrites_value = permissionOverwrites$impl.toOptional().orElse(null); this.permissionOverwrites_absent = permissionOverwrites$impl.isAbsent(); this.parentId_value = Possible.flatOpt(parentId$impl).orElse(null); this.parentId_absent = parentId$impl.isAbsent(); this.initShim = null; } private StoreChannelEditMono(@Nullable String reason, Possible<String> name, Possible<Integer> position, Possible<List<PermissionOverwrite>> permissionOverwrites, Possible<Optional<Snowflake>> parentId, StoreChannel channel) { this.initShim = new InitShim(); this.reason = reason; Possible<String> name$impl = name; Possible<Integer> position$impl = position; Possible<List<PermissionOverwrite>> permissionOverwrites$impl = permissionOverwrites; Possible<Optional<Snowflake>> parentId$impl = parentId; this.channel = channel; this.name_value = name$impl.toOptional().orElse(null); this.name_absent = name$impl.isAbsent(); this.position_value = position$impl.toOptional().orElse(null);
/*     */     this.position_absent = position$impl.isAbsent();
/*     */     this.permissionOverwrites_value = permissionOverwrites$impl.toOptional().orElse(null);
/*     */     this.permissionOverwrites_absent = permissionOverwrites$impl.isAbsent();
/*     */     this.parentId_value = Possible.flatOpt(parentId$impl).orElse(null);
/*     */     this.parentId_absent = parentId$impl.isAbsent();
/*  90 */     this.initShim = null; } @Generated(from = "StoreChannelEditMonoGenerator", generator = "Immutables") private final class InitShim { private InitShim() {} private String formatInitCycleMessage() { List<String> attributes = new ArrayList<>();
/*  91 */       return "Cannot build StoreChannelEditMono, attribute initializers form cycle " + attributes; }
/*     */      }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String reason() {
/* 101 */     return this.reason;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<String> name() {
/* 109 */     return this.name_absent ? Possible.absent() : Possible.of(this.name_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Integer> position() {
/* 117 */     return this.position_absent ? Possible.absent() : Possible.of(this.position_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<List<PermissionOverwrite>> permissionOverwrites() {
/* 125 */     return this.permissionOverwrites_absent ? Possible.absent() : 
/* 126 */       Possible.of(this.permissionOverwrites_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Optional<Snowflake>> parentId() {
/* 134 */     return this.parentId_absent ? Possible.absent() : 
/* 135 */       Possible.of(Optional.ofNullable(this.parentId_value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StoreChannel channel() {
/* 143 */     return this.channel;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final StoreChannelEditMono withReason(@Nullable String value) {
/* 153 */     if (Objects.equals(this.reason, value)) return this; 
/* 154 */     return new StoreChannelEditMono(value, name(), position(), permissionOverwrites(), parentId(), this.channel);
/*     */   }
/*     */   
/*     */   public StoreChannelEditMono withName(Possible<String> value) {
/* 158 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/* 159 */     return new StoreChannelEditMono(this.reason, newValue, 
/*     */ 
/*     */         
/* 162 */         position(), 
/* 163 */         permissionOverwrites(), 
/* 164 */         parentId(), this.channel);
/*     */   }
/*     */ 
/*     */   
/*     */   public StoreChannelEditMono withName(String value) {
/* 169 */     Possible<String> newValue = Possible.of(value);
/* 170 */     return new StoreChannelEditMono(this.reason, newValue, 
/*     */ 
/*     */         
/* 173 */         position(), 
/* 174 */         permissionOverwrites(), 
/* 175 */         parentId(), this.channel);
/*     */   }
/*     */ 
/*     */   
/*     */   public StoreChannelEditMono withPosition(Possible<Integer> value) {
/* 180 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/* 181 */     return new StoreChannelEditMono(this.reason, name(), newValue, permissionOverwrites(), parentId(), this.channel);
/*     */   }
/*     */   
/*     */   public StoreChannelEditMono withPosition(Integer value) {
/* 185 */     Possible<Integer> newValue = Possible.of(value);
/* 186 */     return new StoreChannelEditMono(this.reason, name(), newValue, permissionOverwrites(), parentId(), this.channel);
/*     */   }
/*     */   
/*     */   public StoreChannelEditMono withPermissionOverwrites(Possible<List<PermissionOverwrite>> possible) {
/* 190 */     Possible<List<PermissionOverwrite>> newValue = Objects.<Possible<List<PermissionOverwrite>>>requireNonNull(possible);
/* 191 */     return new StoreChannelEditMono(this.reason, name(), position(), newValue, parentId(), this.channel);
/*     */   }
/*     */   
/*     */   public StoreChannelEditMono withPermissionOverwrites(Iterable<PermissionOverwrite> elements) {
/* 195 */     Possible<List<PermissionOverwrite>> newValue = Possible.of(
/* 196 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/* 197 */     return new StoreChannelEditMono(this.reason, name(), position(), newValue, parentId(), this.channel);
/*     */   }
/*     */   
/*     */   @SafeVarargs
/*     */   public final StoreChannelEditMono withPermissionOverwrites(PermissionOverwrite... elements) {
/* 202 */     Possible<List<PermissionOverwrite>> newValue = Possible.of(Arrays.asList(elements));
/* 203 */     return new StoreChannelEditMono(this.reason, name(), position(), newValue, parentId(), this.channel);
/*     */   }
/*     */   
/*     */   public StoreChannelEditMono withParentId(Possible<Optional<Snowflake>> value) {
/* 207 */     Possible<Optional<Snowflake>> newValue = Objects.<Possible<Optional<Snowflake>>>requireNonNull(value);
/* 208 */     return new StoreChannelEditMono(this.reason, name(), position(), permissionOverwrites(), newValue, this.channel);
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public StoreChannelEditMono withParentId(@Nullable Snowflake value) {
/* 213 */     Possible<Optional<Snowflake>> newValue = Possible.of(Optional.ofNullable(value));
/* 214 */     return new StoreChannelEditMono(this.reason, name(), position(), permissionOverwrites(), newValue, this.channel);
/*     */   }
/*     */   
/*     */   public StoreChannelEditMono withParentIdOrNull(@Nullable Snowflake value) {
/* 218 */     Possible<Optional<Snowflake>> newValue = Possible.of(Optional.ofNullable(value));
/* 219 */     return new StoreChannelEditMono(this.reason, name(), position(), permissionOverwrites(), newValue, this.channel);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final StoreChannelEditMono withChannel(StoreChannel value) {
/* 229 */     if (this.channel == value) return this; 
/* 230 */     StoreChannel newValue = Objects.<StoreChannel>requireNonNull(value, "channel");
/* 231 */     return new StoreChannelEditMono(this.reason, 
/*     */         
/* 233 */         name(), 
/* 234 */         position(), 
/* 235 */         permissionOverwrites(), 
/* 236 */         parentId(), newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 246 */     if (this == another) return true; 
/* 247 */     return (another instanceof StoreChannelEditMono && 
/* 248 */       equalTo(0, (StoreChannelEditMono)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, StoreChannelEditMono another) {
/* 252 */     return (Objects.equals(this.reason, another.reason) && 
/* 253 */       name().equals(another.name()) && 
/* 254 */       position().equals(another.position()) && 
/* 255 */       Objects.equals(this.permissionOverwrites_value, another.permissionOverwrites_value) && 
/* 256 */       parentId().equals(another.parentId()) && this.channel
/* 257 */       .equals(another.channel));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 266 */     int h = 5381;
/* 267 */     h += (h << 5) + Objects.hashCode(this.reason);
/* 268 */     h += (h << 5) + name().hashCode();
/* 269 */     h += (h << 5) + position().hashCode();
/* 270 */     h += (h << 5) + Objects.hashCode(this.permissionOverwrites_value);
/* 271 */     h += (h << 5) + parentId().hashCode();
/* 272 */     h += (h << 5) + this.channel.hashCode();
/* 273 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 282 */     return "StoreChannelEditMono{reason=" + this.reason + ", name=" + 
/*     */       
/* 284 */       name().toString() + ", position=" + 
/* 285 */       position().toString() + ", permissionOverwrites=" + 
/* 286 */       Objects.toString(this.permissionOverwrites_value) + ", parentId=" + 
/* 287 */       parentId().toString() + ", channel=" + this.channel + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static StoreChannelEditMono of(StoreChannel channel) {
/* 298 */     return new StoreChannelEditMono(channel);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static StoreChannelEditMono copyOf(StoreChannelEditMonoGenerator instance) {
/* 309 */     if (instance instanceof StoreChannelEditMono) {
/* 310 */       return (StoreChannelEditMono)instance;
/*     */     }
/* 312 */     return of(instance.channel())
/* 313 */       .withReason(instance.reason())
/* 314 */       .withName(instance.name())
/* 315 */       .withPosition(instance.position())
/* 316 */       .withPermissionOverwrites(instance.permissionOverwrites())
/* 317 */       .withParentId(instance.parentId());
/*     */   }
/*     */   
/*     */   public boolean isNamePresent() {
/* 321 */     return !this.name_absent;
/*     */   }
/*     */   
/*     */   public String nameOrElse(String defaultValue) {
/* 325 */     return !this.name_absent ? this.name_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isPositionPresent() {
/* 329 */     return !this.position_absent;
/*     */   }
/*     */   
/*     */   public Integer positionOrElse(Integer defaultValue) {
/* 333 */     return !this.position_absent ? this.position_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isPermissionOverwritesPresent() {
/* 337 */     return !this.permissionOverwrites_absent;
/*     */   }
/*     */   
/*     */   public List<PermissionOverwrite> permissionOverwritesOrElse(List<PermissionOverwrite> defaultValue) {
/* 341 */     return !this.permissionOverwrites_absent ? this.permissionOverwrites_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isParentIdPresent() {
/* 345 */     return !this.parentId_absent;
/*     */   }
/*     */   
/*     */   public Snowflake parentIdOrElse(Snowflake defaultValue) {
/* 349 */     return !this.parentId_absent ? this.parentId_value : defaultValue;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\StoreChannelEditMono.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */