/*    */ package discord4j.core.spec;
/*    */ 
/*    */ import discord4j.core.object.entity.channel.Channel;
/*    */ import discord4j.discordjson.json.PartialChannelCreateRequest;
/*    */ import org.immutables.value.Value.Enclosing;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @InlineFieldStyle
/*    */ @Enclosing
/*    */ public final class GuildCreateFields
/*    */ {
/*    */   private GuildCreateFields() {
/* 29 */     throw new AssertionError();
/*    */   }
/*    */   
/*    */   @Immutable
/*    */   public static interface PartialChannel
/*    */     extends Spec<PartialChannelCreateRequest> {
/*    */     static PartialChannel of(String name, Channel.Type type) {
/* 36 */       return ImmutableGuildCreateFields.PartialChannel.of(name, type);
/*    */     }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/*    */     default PartialChannelCreateRequest asRequest() {
/* 45 */       return (PartialChannelCreateRequest)PartialChannelCreateRequest.builder()
/* 46 */         .name(name())
/* 47 */         .type(type().getValue())
/* 48 */         .build();
/*    */     }
/*    */     
/*    */     String name();
/*    */     
/*    */     Channel.Type type();
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\GuildCreateFields.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */