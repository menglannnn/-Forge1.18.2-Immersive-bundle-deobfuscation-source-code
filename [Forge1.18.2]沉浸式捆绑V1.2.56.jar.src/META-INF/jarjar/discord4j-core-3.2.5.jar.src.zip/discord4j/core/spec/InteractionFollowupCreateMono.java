/*     */ package discord4j.core.spec;
/*     */ 
/*     */ import discord4j.core.event.domain.interaction.DeferrableInteractionEvent;
/*     */ import discord4j.core.object.component.LayoutComponent;
/*     */ import discord4j.core.object.entity.Message;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import discord4j.rest.util.AllowedMentions;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.stream.StreamSupport;
/*     */ import org.immutables.value.Generated;
/*     */ import reactor.core.CoreSubscriber;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "InteractionFollowupCreateMonoGenerator", generator = "Immutables")
/*     */ public final class InteractionFollowupCreateMono
/*     */   extends InteractionFollowupCreateMonoGenerator
/*     */ {
/*     */   private final String content_value;
/*     */   private final boolean content_absent;
/*     */   private final String username_value;
/*     */   private final boolean username_absent;
/*     */   private final String avatarUrl_value;
/*     */   private final boolean avatarUrl_absent;
/*     */   private final boolean tts;
/*     */   private final List<MessageCreateFields.File> files;
/*     */   private final List<MessageCreateFields.FileSpoiler> fileSpoilers;
/*     */   private final List<EmbedCreateSpec> embeds;
/*     */   private final AllowedMentions allowedMentions_value;
/*     */   private final boolean allowedMentions_absent;
/*     */   private final List<LayoutComponent> components_value;
/*     */   private final boolean components_absent;
/*     */   private final Boolean ephemeral_value;
/*     */   private final boolean ephemeral_absent;
/*     */   private final DeferrableInteractionEvent event;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   private volatile transient InitShim initShim;
/*     */   
/*     */   private InteractionFollowupCreateMono(DeferrableInteractionEvent event) {
/* 119 */     this.initShim = new InitShim(); this.event = Objects.<DeferrableInteractionEvent>requireNonNull(event, "event"); Possible<String> content$impl = Possible.absent(); Possible<String> username$impl = Possible.absent(); Possible<String> avatarUrl$impl = Possible.absent(); Possible<AllowedMentions> allowedMentions$impl = Possible.absent(); Possible<List<LayoutComponent>> components$impl = Possible.absent(); Possible<Boolean> ephemeral$impl = Possible.absent(); this.content_value = content$impl.toOptional().orElse(null); this.content_absent = content$impl.isAbsent(); this.username_value = username$impl.toOptional().orElse(null); this.username_absent = username$impl.isAbsent(); this.avatarUrl_value = avatarUrl$impl.toOptional().orElse(null); this.avatarUrl_absent = avatarUrl$impl.isAbsent(); this.allowedMentions_value = allowedMentions$impl.toOptional().orElse(null); this.allowedMentions_absent = allowedMentions$impl.isAbsent(); this.components_value = components$impl.toOptional().orElse(null); this.components_absent = components$impl.isAbsent(); this.ephemeral_value = ephemeral$impl.toOptional().orElse(null); this.ephemeral_absent = ephemeral$impl.isAbsent(); this.tts = this.initShim.tts(); this.files = this.initShim.files(); this.fileSpoilers = this.initShim.fileSpoilers(); this.embeds = this.initShim.embeds(); this.initShim = null; } private InteractionFollowupCreateMono(Possible<String> content, Possible<String> username, Possible<String> avatarUrl, boolean tts, List<MessageCreateFields.File> files, List<MessageCreateFields.FileSpoiler> fileSpoilers, List<EmbedCreateSpec> embeds, Possible<AllowedMentions> allowedMentions, Possible<List<LayoutComponent>> components, Possible<Boolean> ephemeral, DeferrableInteractionEvent event) { this.initShim = new InitShim(); Possible<String> content$impl = content; Possible<String> username$impl = username; Possible<String> avatarUrl$impl = avatarUrl; this.initShim.tts(tts); this.initShim.files(files); this.initShim.fileSpoilers(fileSpoilers); this.initShim.embeds(embeds); Possible<AllowedMentions> allowedMentions$impl = allowedMentions; Possible<List<LayoutComponent>> components$impl = components; Possible<Boolean> ephemeral$impl = ephemeral; this.event = event; this.content_value = content$impl.toOptional().orElse(null); this.content_absent = content$impl.isAbsent(); this.username_value = username$impl.toOptional().orElse(null); this.username_absent = username$impl.isAbsent(); this.avatarUrl_value = avatarUrl$impl.toOptional().orElse(null); this.avatarUrl_absent = avatarUrl$impl.isAbsent(); this.allowedMentions_value = allowedMentions$impl.toOptional().orElse(null); this.allowedMentions_absent = allowedMentions$impl.isAbsent(); this.components_value = components$impl.toOptional().orElse(null); this.components_absent = components$impl.isAbsent(); this.ephemeral_value = ephemeral$impl.toOptional().orElse(null); this.ephemeral_absent = ephemeral$impl.isAbsent();
/*     */     this.tts = this.initShim.tts();
/*     */     this.files = this.initShim.files();
/*     */     this.fileSpoilers = this.initShim.fileSpoilers();
/*     */     this.embeds = this.initShim.embeds();
/* 124 */     this.initShim = null; } @Generated(from = "InteractionFollowupCreateMonoGenerator", generator = "Immutables") private final class InitShim { private byte ttsBuildStage = 0;
/*     */     private boolean tts;
/*     */     
/*     */     boolean tts() {
/* 128 */       if (this.ttsBuildStage == -1) throw new IllegalStateException(formatInitCycleMessage()); 
/* 129 */       if (this.ttsBuildStage == 0) {
/* 130 */         this.ttsBuildStage = -1;
/* 131 */         this.tts = InteractionFollowupCreateMono.this.tts();
/* 132 */         this.ttsBuildStage = 1;
/*     */       } 
/* 134 */       return this.tts;
/*     */     }
/*     */     
/*     */     void tts(boolean tts) {
/* 138 */       this.tts = tts;
/* 139 */       this.ttsBuildStage = 1;
/*     */     }
/*     */     
/* 142 */     private byte filesBuildStage = 0;
/*     */     private List<MessageCreateFields.File> files;
/*     */     
/*     */     List<MessageCreateFields.File> files() {
/* 146 */       if (this.filesBuildStage == -1) throw new IllegalStateException(formatInitCycleMessage()); 
/* 147 */       if (this.filesBuildStage == 0) {
/* 148 */         this.filesBuildStage = -1;
/* 149 */         this.files = (List)InteractionFollowupCreateMono.createUnmodifiableList(false, InteractionFollowupCreateMono.createSafeList((Iterable)InteractionFollowupCreateMono.this.files(), true, false));
/* 150 */         this.filesBuildStage = 1;
/*     */       } 
/* 152 */       return this.files;
/*     */     }
/*     */     
/*     */     void files(List<MessageCreateFields.File> files) {
/* 156 */       this.files = files;
/* 157 */       this.filesBuildStage = 1;
/*     */     }
/*     */     
/* 160 */     private byte fileSpoilersBuildStage = 0;
/*     */     private List<MessageCreateFields.FileSpoiler> fileSpoilers;
/*     */     
/*     */     List<MessageCreateFields.FileSpoiler> fileSpoilers() {
/* 164 */       if (this.fileSpoilersBuildStage == -1) throw new IllegalStateException(formatInitCycleMessage()); 
/* 165 */       if (this.fileSpoilersBuildStage == 0) {
/* 166 */         this.fileSpoilersBuildStage = -1;
/* 167 */         this.fileSpoilers = (List)InteractionFollowupCreateMono.createUnmodifiableList(false, InteractionFollowupCreateMono.createSafeList((Iterable)InteractionFollowupCreateMono.this.fileSpoilers(), true, false));
/* 168 */         this.fileSpoilersBuildStage = 1;
/*     */       } 
/* 170 */       return this.fileSpoilers;
/*     */     }
/*     */     
/*     */     void fileSpoilers(List<MessageCreateFields.FileSpoiler> fileSpoilers) {
/* 174 */       this.fileSpoilers = fileSpoilers;
/* 175 */       this.fileSpoilersBuildStage = 1;
/*     */     }
/*     */     
/* 178 */     private byte embedsBuildStage = 0;
/*     */     private List<EmbedCreateSpec> embeds;
/*     */     
/*     */     List<EmbedCreateSpec> embeds() {
/* 182 */       if (this.embedsBuildStage == -1) throw new IllegalStateException(formatInitCycleMessage()); 
/* 183 */       if (this.embedsBuildStage == 0) {
/* 184 */         this.embedsBuildStage = -1;
/* 185 */         this.embeds = (List)InteractionFollowupCreateMono.createUnmodifiableList(false, InteractionFollowupCreateMono.createSafeList((Iterable)InteractionFollowupCreateMono.this.embeds(), true, false));
/* 186 */         this.embedsBuildStage = 1;
/*     */       } 
/* 188 */       return this.embeds;
/*     */     }
/*     */     
/*     */     void embeds(List<EmbedCreateSpec> embeds) {
/* 192 */       this.embeds = embeds;
/* 193 */       this.embedsBuildStage = 1;
/*     */     }
/*     */     
/*     */     private String formatInitCycleMessage() {
/* 197 */       List<String> attributes = new ArrayList<>();
/* 198 */       if (this.ttsBuildStage == -1) attributes.add("tts"); 
/* 199 */       if (this.filesBuildStage == -1) attributes.add("files"); 
/* 200 */       if (this.fileSpoilersBuildStage == -1) attributes.add("fileSpoilers"); 
/* 201 */       if (this.embedsBuildStage == -1) attributes.add("embeds"); 
/* 202 */       return "Cannot build InteractionFollowupCreateMono, attribute initializers form cycle " + attributes;
/*     */     }
/*     */ 
/*     */     
/*     */     private InitShim() {} }
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<String> content() {
/* 211 */     return this.content_absent ? Possible.absent() : Possible.of(this.content_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<String> username() {
/* 219 */     return this.username_absent ? Possible.absent() : Possible.of(this.username_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<String> avatarUrl() {
/* 227 */     return this.avatarUrl_absent ? Possible.absent() : Possible.of(this.avatarUrl_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean tts() {
/* 235 */     InitShim shim = this.initShim;
/* 236 */     return (shim != null) ? 
/* 237 */       shim.tts() : 
/* 238 */       this.tts;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<MessageCreateFields.File> files() {
/* 246 */     InitShim shim = this.initShim;
/* 247 */     return (shim != null) ? 
/* 248 */       shim.files() : 
/* 249 */       this.files;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<MessageCreateFields.FileSpoiler> fileSpoilers() {
/* 257 */     InitShim shim = this.initShim;
/* 258 */     return (shim != null) ? 
/* 259 */       shim.fileSpoilers() : 
/* 260 */       this.fileSpoilers;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<EmbedCreateSpec> embeds() {
/* 268 */     InitShim shim = this.initShim;
/* 269 */     return (shim != null) ? 
/* 270 */       shim.embeds() : 
/* 271 */       this.embeds;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<AllowedMentions> allowedMentions() {
/* 279 */     return this.allowedMentions_absent ? Possible.absent() : Possible.of(this.allowedMentions_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<List<LayoutComponent>> components() {
/* 287 */     return this.components_absent ? Possible.absent() : 
/* 288 */       Possible.of(this.components_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Boolean> ephemeral() {
/* 296 */     return this.ephemeral_absent ? Possible.absent() : Possible.of(this.ephemeral_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DeferrableInteractionEvent event() {
/* 304 */     return this.event;
/*     */   }
/*     */   
/*     */   public InteractionFollowupCreateMono withContent(Possible<String> value) {
/* 308 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/* 309 */     return new InteractionFollowupCreateMono(newValue, 
/*     */         
/* 311 */         username(), 
/* 312 */         avatarUrl(), this.tts, this.files, this.fileSpoilers, this.embeds, 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 317 */         allowedMentions(), 
/* 318 */         components(), 
/* 319 */         ephemeral(), this.event);
/*     */   }
/*     */ 
/*     */   
/*     */   public InteractionFollowupCreateMono withContent(String value) {
/* 324 */     Possible<String> newValue = Possible.of(value);
/* 325 */     return new InteractionFollowupCreateMono(newValue, 
/*     */         
/* 327 */         username(), 
/* 328 */         avatarUrl(), this.tts, this.files, this.fileSpoilers, this.embeds, 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 333 */         allowedMentions(), 
/* 334 */         components(), 
/* 335 */         ephemeral(), this.event);
/*     */   }
/*     */ 
/*     */   
/*     */   public InteractionFollowupCreateMono withUsername(Possible<String> value) {
/* 340 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/* 341 */     return new InteractionFollowupCreateMono(
/* 342 */         content(), newValue, 
/*     */         
/* 344 */         avatarUrl(), this.tts, this.files, this.fileSpoilers, this.embeds, 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 349 */         allowedMentions(), 
/* 350 */         components(), 
/* 351 */         ephemeral(), this.event);
/*     */   }
/*     */ 
/*     */   
/*     */   public InteractionFollowupCreateMono withUsername(String value) {
/* 356 */     Possible<String> newValue = Possible.of(value);
/* 357 */     return new InteractionFollowupCreateMono(
/* 358 */         content(), newValue, 
/*     */         
/* 360 */         avatarUrl(), this.tts, this.files, this.fileSpoilers, this.embeds, 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 365 */         allowedMentions(), 
/* 366 */         components(), 
/* 367 */         ephemeral(), this.event);
/*     */   }
/*     */ 
/*     */   
/*     */   public InteractionFollowupCreateMono withAvatarUrl(Possible<String> value) {
/* 372 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/* 373 */     return new InteractionFollowupCreateMono(
/* 374 */         content(), 
/* 375 */         username(), newValue, this.tts, this.files, this.fileSpoilers, this.embeds, 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 381 */         allowedMentions(), 
/* 382 */         components(), 
/* 383 */         ephemeral(), this.event);
/*     */   }
/*     */ 
/*     */   
/*     */   public InteractionFollowupCreateMono withAvatarUrl(String value) {
/* 388 */     Possible<String> newValue = Possible.of(value);
/* 389 */     return new InteractionFollowupCreateMono(
/* 390 */         content(), 
/* 391 */         username(), newValue, this.tts, this.files, this.fileSpoilers, this.embeds, 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 397 */         allowedMentions(), 
/* 398 */         components(), 
/* 399 */         ephemeral(), this.event);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final InteractionFollowupCreateMono withTts(boolean value) {
/* 410 */     if (this.tts == value) return this; 
/* 411 */     return new InteractionFollowupCreateMono(
/* 412 */         content(), 
/* 413 */         username(), 
/* 414 */         avatarUrl(), value, this.files, this.fileSpoilers, this.embeds, 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 419 */         allowedMentions(), 
/* 420 */         components(), 
/* 421 */         ephemeral(), this.event);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final InteractionFollowupCreateMono withFiles(MessageCreateFields.File... elements) {
/* 431 */     List<MessageCreateFields.File> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/* 432 */     return new InteractionFollowupCreateMono(
/* 433 */         content(), 
/* 434 */         username(), 
/* 435 */         avatarUrl(), this.tts, newValue, this.fileSpoilers, this.embeds, 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 440 */         allowedMentions(), 
/* 441 */         components(), 
/* 442 */         ephemeral(), this.event);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final InteractionFollowupCreateMono withFiles(Iterable<? extends MessageCreateFields.File> elements) {
/* 453 */     if (this.files == elements) return this; 
/* 454 */     List<MessageCreateFields.File> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/* 455 */     return new InteractionFollowupCreateMono(
/* 456 */         content(), 
/* 457 */         username(), 
/* 458 */         avatarUrl(), this.tts, newValue, this.fileSpoilers, this.embeds, 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 463 */         allowedMentions(), 
/* 464 */         components(), 
/* 465 */         ephemeral(), this.event);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final InteractionFollowupCreateMono withFileSpoilers(MessageCreateFields.FileSpoiler... elements) {
/* 475 */     List<MessageCreateFields.FileSpoiler> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/* 476 */     return new InteractionFollowupCreateMono(
/* 477 */         content(), 
/* 478 */         username(), 
/* 479 */         avatarUrl(), this.tts, this.files, newValue, this.embeds, 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 484 */         allowedMentions(), 
/* 485 */         components(), 
/* 486 */         ephemeral(), this.event);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final InteractionFollowupCreateMono withFileSpoilers(Iterable<? extends MessageCreateFields.FileSpoiler> elements) {
/* 497 */     if (this.fileSpoilers == elements) return this; 
/* 498 */     List<MessageCreateFields.FileSpoiler> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/* 499 */     return new InteractionFollowupCreateMono(
/* 500 */         content(), 
/* 501 */         username(), 
/* 502 */         avatarUrl(), this.tts, this.files, newValue, this.embeds, 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 507 */         allowedMentions(), 
/* 508 */         components(), 
/* 509 */         ephemeral(), this.event);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final InteractionFollowupCreateMono withEmbeds(EmbedCreateSpec... elements) {
/* 519 */     List<EmbedCreateSpec> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/* 520 */     return new InteractionFollowupCreateMono(
/* 521 */         content(), 
/* 522 */         username(), 
/* 523 */         avatarUrl(), this.tts, this.files, this.fileSpoilers, newValue, 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 528 */         allowedMentions(), 
/* 529 */         components(), 
/* 530 */         ephemeral(), this.event);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final InteractionFollowupCreateMono withEmbeds(Iterable<? extends EmbedCreateSpec> elements) {
/* 541 */     if (this.embeds == elements) return this; 
/* 542 */     List<EmbedCreateSpec> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/* 543 */     return new InteractionFollowupCreateMono(
/* 544 */         content(), 
/* 545 */         username(), 
/* 546 */         avatarUrl(), this.tts, this.files, this.fileSpoilers, newValue, 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 551 */         allowedMentions(), 
/* 552 */         components(), 
/* 553 */         ephemeral(), this.event);
/*     */   }
/*     */ 
/*     */   
/*     */   public InteractionFollowupCreateMono withAllowedMentions(Possible<AllowedMentions> value) {
/* 558 */     Possible<AllowedMentions> newValue = Objects.<Possible<AllowedMentions>>requireNonNull(value);
/* 559 */     return new InteractionFollowupCreateMono(
/* 560 */         content(), 
/* 561 */         username(), 
/* 562 */         avatarUrl(), this.tts, this.files, this.fileSpoilers, this.embeds, newValue, 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 568 */         components(), 
/* 569 */         ephemeral(), this.event);
/*     */   }
/*     */ 
/*     */   
/*     */   public InteractionFollowupCreateMono withAllowedMentions(AllowedMentions value) {
/* 574 */     Possible<AllowedMentions> newValue = Possible.of(value);
/* 575 */     return new InteractionFollowupCreateMono(
/* 576 */         content(), 
/* 577 */         username(), 
/* 578 */         avatarUrl(), this.tts, this.files, this.fileSpoilers, this.embeds, newValue, 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 584 */         components(), 
/* 585 */         ephemeral(), this.event);
/*     */   }
/*     */ 
/*     */   
/*     */   public InteractionFollowupCreateMono withComponents(Possible<List<LayoutComponent>> possible) {
/* 590 */     Possible<List<LayoutComponent>> newValue = Objects.<Possible<List<LayoutComponent>>>requireNonNull(possible);
/* 591 */     return new InteractionFollowupCreateMono(
/* 592 */         content(), 
/* 593 */         username(), 
/* 594 */         avatarUrl(), this.tts, this.files, this.fileSpoilers, this.embeds, 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 599 */         allowedMentions(), newValue, 
/*     */         
/* 601 */         ephemeral(), this.event);
/*     */   }
/*     */ 
/*     */   
/*     */   public InteractionFollowupCreateMono withComponents(Iterable<LayoutComponent> elements) {
/* 606 */     Possible<List<LayoutComponent>> newValue = Possible.of(
/* 607 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/* 608 */     return new InteractionFollowupCreateMono(
/* 609 */         content(), 
/* 610 */         username(), 
/* 611 */         avatarUrl(), this.tts, this.files, this.fileSpoilers, this.embeds, 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 616 */         allowedMentions(), newValue, 
/*     */         
/* 618 */         ephemeral(), this.event);
/*     */   }
/*     */ 
/*     */   
/*     */   @SafeVarargs
/*     */   public final InteractionFollowupCreateMono withComponents(LayoutComponent... elements) {
/* 624 */     Possible<List<LayoutComponent>> newValue = Possible.of(Arrays.asList(elements));
/* 625 */     return new InteractionFollowupCreateMono(
/* 626 */         content(), 
/* 627 */         username(), 
/* 628 */         avatarUrl(), this.tts, this.files, this.fileSpoilers, this.embeds, 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 633 */         allowedMentions(), newValue, 
/*     */         
/* 635 */         ephemeral(), this.event);
/*     */   }
/*     */ 
/*     */   
/*     */   public InteractionFollowupCreateMono withEphemeral(Possible<Boolean> value) {
/* 640 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/* 641 */     return new InteractionFollowupCreateMono(
/* 642 */         content(), 
/* 643 */         username(), 
/* 644 */         avatarUrl(), this.tts, this.files, this.fileSpoilers, this.embeds, 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 649 */         allowedMentions(), 
/* 650 */         components(), newValue, this.event);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public InteractionFollowupCreateMono withEphemeral(Boolean value) {
/* 656 */     Possible<Boolean> newValue = Possible.of(value);
/* 657 */     return new InteractionFollowupCreateMono(
/* 658 */         content(), 
/* 659 */         username(), 
/* 660 */         avatarUrl(), this.tts, this.files, this.fileSpoilers, this.embeds, 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 665 */         allowedMentions(), 
/* 666 */         components(), newValue, this.event);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final InteractionFollowupCreateMono withEvent(DeferrableInteractionEvent value) {
/* 678 */     if (this.event == value) return this; 
/* 679 */     DeferrableInteractionEvent newValue = Objects.<DeferrableInteractionEvent>requireNonNull(value, "event");
/* 680 */     return new InteractionFollowupCreateMono(
/* 681 */         content(), 
/* 682 */         username(), 
/* 683 */         avatarUrl(), this.tts, this.files, this.fileSpoilers, this.embeds, 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 688 */         allowedMentions(), 
/* 689 */         components(), 
/* 690 */         ephemeral(), newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 700 */     if (this == another) return true; 
/* 701 */     return (another instanceof InteractionFollowupCreateMono && 
/* 702 */       equalTo(0, (InteractionFollowupCreateMono)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, InteractionFollowupCreateMono another) {
/* 706 */     return (content().equals(another.content()) && 
/* 707 */       username().equals(another.username()) && 
/* 708 */       avatarUrl().equals(another.avatarUrl()) && this.tts == another.tts && this.files
/*     */       
/* 710 */       .equals(another.files) && this.fileSpoilers
/* 711 */       .equals(another.fileSpoilers) && this.embeds
/* 712 */       .equals(another.embeds) && 
/* 713 */       allowedMentions().equals(another.allowedMentions()) && 
/* 714 */       Objects.equals(this.components_value, another.components_value) && 
/* 715 */       ephemeral().equals(another.ephemeral()) && this.event
/* 716 */       .equals(another.event));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 725 */     int h = 5381;
/* 726 */     h += (h << 5) + content().hashCode();
/* 727 */     h += (h << 5) + username().hashCode();
/* 728 */     h += (h << 5) + avatarUrl().hashCode();
/* 729 */     h += (h << 5) + Boolean.hashCode(this.tts);
/* 730 */     h += (h << 5) + this.files.hashCode();
/* 731 */     h += (h << 5) + this.fileSpoilers.hashCode();
/* 732 */     h += (h << 5) + this.embeds.hashCode();
/* 733 */     h += (h << 5) + allowedMentions().hashCode();
/* 734 */     h += (h << 5) + Objects.hashCode(this.components_value);
/* 735 */     h += (h << 5) + ephemeral().hashCode();
/* 736 */     h += (h << 5) + this.event.hashCode();
/* 737 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 746 */     return "InteractionFollowupCreateMono{content=" + 
/* 747 */       content().toString() + ", username=" + 
/* 748 */       username().toString() + ", avatarUrl=" + 
/* 749 */       avatarUrl().toString() + ", tts=" + this.tts + ", files=" + this.files + ", fileSpoilers=" + this.fileSpoilers + ", embeds=" + this.embeds + ", allowedMentions=" + 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 754 */       allowedMentions().toString() + ", components=" + 
/* 755 */       Objects.toString(this.components_value) + ", ephemeral=" + 
/* 756 */       ephemeral().toString() + ", event=" + this.event + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static InteractionFollowupCreateMono of(DeferrableInteractionEvent event) {
/* 767 */     return new InteractionFollowupCreateMono(event);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static InteractionFollowupCreateMono copyOf(InteractionFollowupCreateMonoGenerator instance) {
/* 778 */     if (instance instanceof InteractionFollowupCreateMono) {
/* 779 */       return (InteractionFollowupCreateMono)instance;
/*     */     }
/* 781 */     return of(instance.event())
/* 782 */       .withContent(instance.content())
/* 783 */       .withUsername(instance.username())
/* 784 */       .withAvatarUrl(instance.avatarUrl())
/* 785 */       .withTts(instance.tts())
/* 786 */       .withFiles(instance.files())
/* 787 */       .withFileSpoilers(instance.fileSpoilers())
/* 788 */       .withEmbeds(instance.embeds())
/* 789 */       .withAllowedMentions(instance.allowedMentions())
/* 790 */       .withComponents(instance.components())
/* 791 */       .withEphemeral(instance.ephemeral());
/*     */   }
/*     */   
/*     */   public boolean isContentPresent() {
/* 795 */     return !this.content_absent;
/*     */   }
/*     */   
/*     */   public String contentOrElse(String defaultValue) {
/* 799 */     return !this.content_absent ? this.content_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isUsernamePresent() {
/* 803 */     return !this.username_absent;
/*     */   }
/*     */   
/*     */   public String usernameOrElse(String defaultValue) {
/* 807 */     return !this.username_absent ? this.username_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isAvatarUrlPresent() {
/* 811 */     return !this.avatarUrl_absent;
/*     */   }
/*     */   
/*     */   public String avatarUrlOrElse(String defaultValue) {
/* 815 */     return !this.avatarUrl_absent ? this.avatarUrl_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isAllowedMentionsPresent() {
/* 819 */     return !this.allowedMentions_absent;
/*     */   }
/*     */   
/*     */   public AllowedMentions allowedMentionsOrElse(AllowedMentions defaultValue) {
/* 823 */     return !this.allowedMentions_absent ? this.allowedMentions_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isComponentsPresent() {
/* 827 */     return !this.components_absent;
/*     */   }
/*     */   
/*     */   public List<LayoutComponent> componentsOrElse(List<LayoutComponent> defaultValue) {
/* 831 */     return !this.components_absent ? this.components_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isEphemeralPresent() {
/* 835 */     return !this.ephemeral_absent;
/*     */   }
/*     */   
/*     */   public Boolean ephemeralOrElse(Boolean defaultValue) {
/* 839 */     return !this.ephemeral_absent ? this.ephemeral_value : defaultValue;
/*     */   }
/*     */   
/*     */   private static <T> List<T> createSafeList(Iterable<? extends T> iterable, boolean checkNulls, boolean skipNulls) {
/*     */     ArrayList<T> list;
/* 844 */     if (iterable instanceof Collection) {
/* 845 */       int size = ((Collection)iterable).size();
/* 846 */       if (size == 0) return Collections.emptyList(); 
/* 847 */       list = new ArrayList<>();
/*     */     } else {
/* 849 */       list = new ArrayList<>();
/*     */     } 
/* 851 */     for (T element : iterable) {
/* 852 */       if (skipNulls && element == null)
/* 853 */         continue;  if (checkNulls) Objects.requireNonNull(element, "element"); 
/* 854 */       list.add(element);
/*     */     } 
/* 856 */     return list;
/*     */   }
/*     */   
/*     */   private static <T> List<T> createUnmodifiableList(boolean clone, List<T> list) {
/* 860 */     switch (list.size()) { case 0:
/* 861 */         return Collections.emptyList();
/* 862 */       case 1: return Collections.singletonList(list.get(0)); }
/*     */     
/* 864 */     if (clone) {
/* 865 */       return Collections.unmodifiableList(new ArrayList<>(list));
/*     */     }
/* 867 */     if (list instanceof ArrayList) {
/* 868 */       ((ArrayList)list).trimToSize();
/*     */     }
/* 870 */     return Collections.unmodifiableList(list);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\InteractionFollowupCreateMono.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */