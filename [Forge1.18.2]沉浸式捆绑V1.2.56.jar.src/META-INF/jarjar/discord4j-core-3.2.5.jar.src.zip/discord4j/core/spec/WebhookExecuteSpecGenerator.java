/*    */ package discord4j.core.spec;
/*    */ 
/*    */ import discord4j.core.object.component.LayoutComponent;
/*    */ import discord4j.core.object.component.MessageComponent;
/*    */ import discord4j.discordjson.json.ImmutableWebhookExecuteRequest;
/*    */ import discord4j.discordjson.json.WebhookExecuteRequest;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import discord4j.rest.util.AllowedMentions;
/*    */ import discord4j.rest.util.MultipartRequest;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import java.util.stream.Collectors;
/*    */ import java.util.stream.Stream;
/*    */ import org.immutables.value.Value.Default;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Immutable(singleton = true)
/*    */ interface WebhookExecuteSpecGenerator
/*    */   extends Spec<MultipartRequest<WebhookExecuteRequest>>
/*    */ {
/*    */   @Default
/*    */   default boolean tts() {
/* 49 */     return false;
/*    */   }
/*    */   
/*    */   @Default
/*    */   default List<MessageCreateFields.File> files() {
/* 54 */     return Collections.emptyList();
/*    */   }
/*    */   
/*    */   @Default
/*    */   default List<MessageCreateFields.FileSpoiler> fileSpoilers() {
/* 59 */     return Collections.emptyList();
/*    */   }
/*    */   
/*    */   @Default
/*    */   default List<EmbedCreateSpec> embeds() {
/* 64 */     return Collections.emptyList();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   default MultipartRequest<WebhookExecuteRequest> asRequest() {
/* 83 */     ImmutableWebhookExecuteRequest immutableWebhookExecuteRequest = WebhookExecuteRequest.builder().content(content()).username(username()).avatarUrl(avatarUrl()).tts(Boolean.valueOf(tts())).embeds((List)embeds().stream().map(EmbedCreateSpecGenerator::asRequest).collect(Collectors.toList())).allowedMentions(InternalSpecUtils.mapPossible(allowedMentions(), AllowedMentions::toData)).components(InternalSpecUtils.mapPossible(components(), components -> (List)components.stream().map(MessageComponent::getData).collect(Collectors.toList()))).build();
/* 84 */     return MultipartRequest.ofRequestAndFiles(immutableWebhookExecuteRequest, (List)Stream.concat(files().stream(), fileSpoilers().stream())
/* 85 */         .map(MessageCreateFields.File::asRequest)
/* 86 */         .collect(Collectors.toList()));
/*    */   }
/*    */   
/*    */   Possible<String> content();
/*    */   
/*    */   Possible<String> username();
/*    */   
/*    */   Possible<String> avatarUrl();
/*    */   
/*    */   Possible<AllowedMentions> allowedMentions();
/*    */   
/*    */   Possible<List<LayoutComponent>> components();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\WebhookExecuteSpecGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */