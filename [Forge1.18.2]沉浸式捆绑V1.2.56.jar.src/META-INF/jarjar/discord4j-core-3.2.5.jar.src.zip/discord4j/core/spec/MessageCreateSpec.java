/*      */ package discord4j.core.spec;
/*      */ 
/*      */ import com.google.errorprone.annotations.CanIgnoreReturnValue;
/*      */ import discord4j.common.util.Snowflake;
/*      */ import discord4j.core.object.component.LayoutComponent;
/*      */ import discord4j.discordjson.possible.Possible;
/*      */ import discord4j.rest.util.AllowedMentions;
/*      */ import java.io.InputStream;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.List;
/*      */ import java.util.Objects;
/*      */ import java.util.stream.Collectors;
/*      */ import java.util.stream.StreamSupport;
/*      */ import org.immutables.value.Generated;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ @Generated(from = "MessageCreateSpecGenerator", generator = "Immutables")
/*      */ public final class MessageCreateSpec
/*      */   implements MessageCreateSpecGenerator
/*      */ {
/*      */   private final String content_value;
/*      */   private final boolean content_absent;
/*      */   private final String nonce_value;
/*      */   private final boolean nonce_absent;
/*      */   private final Boolean tts_value;
/*      */   private final boolean tts_absent;
/*      */   private final List<EmbedCreateSpec> embeds_value;
/*      */   private final boolean embeds_absent;
/*      */   private final List<MessageCreateFields.File> files;
/*      */   private final List<MessageCreateFields.FileSpoiler> fileSpoilers;
/*      */   private final AllowedMentions allowedMentions_value;
/*      */   private final boolean allowedMentions_absent;
/*      */   private final Snowflake messageReference_value;
/*      */   private final boolean messageReference_absent;
/*      */   private final List<LayoutComponent> components_value;
/*      */   private final boolean components_absent;
/*      */   private static final byte STAGE_INITIALIZING = -1;
/*      */   private static final byte STAGE_UNINITIALIZED = 0;
/*      */   private static final byte STAGE_INITIALIZED = 1;
/*      */   
/*      */   private MessageCreateSpec() {
/*   50 */     Possible<String> content$impl = Possible.absent();
/*   51 */     Possible<String> nonce$impl = Possible.absent();
/*   52 */     Possible<Boolean> tts$impl = Possible.absent();
/*   53 */     Possible<List<EmbedCreateSpec>> embeds$impl = Possible.absent();
/*   54 */     Possible<AllowedMentions> allowedMentions$impl = Possible.absent();
/*   55 */     Possible<Snowflake> messageReference$impl = Possible.absent();
/*   56 */     Possible<List<LayoutComponent>> components$impl = Possible.absent();
/*   57 */     this.content_value = content$impl.toOptional().orElse(null);
/*   58 */     this.content_absent = content$impl.isAbsent();
/*   59 */     this.nonce_value = nonce$impl.toOptional().orElse(null);
/*   60 */     this.nonce_absent = nonce$impl.isAbsent();
/*   61 */     this.tts_value = tts$impl.toOptional().orElse(null);
/*   62 */     this.tts_absent = tts$impl.isAbsent();
/*   63 */     this.embeds_value = embeds$impl.toOptional().orElse(null);
/*   64 */     this.embeds_absent = embeds$impl.isAbsent();
/*   65 */     this.allowedMentions_value = allowedMentions$impl.toOptional().orElse(null);
/*   66 */     this.allowedMentions_absent = allowedMentions$impl.isAbsent();
/*   67 */     this.messageReference_value = messageReference$impl.toOptional().orElse(null);
/*   68 */     this.messageReference_absent = messageReference$impl.isAbsent();
/*   69 */     this.components_value = components$impl.toOptional().orElse(null);
/*   70 */     this.components_absent = components$impl.isAbsent();
/*   71 */     this.files = this.initShim.files();
/*   72 */     this.fileSpoilers = this.initShim.fileSpoilers();
/*   73 */     this.initShim = null;
/*      */   }
/*      */   
/*      */   private MessageCreateSpec(Builder builder) {
/*   77 */     Possible<String> content$impl = builder.content_build();
/*   78 */     Possible<String> nonce$impl = builder.nonce_build();
/*   79 */     Possible<Boolean> tts$impl = builder.tts_build();
/*   80 */     Possible<List<EmbedCreateSpec>> embeds$impl = builder.embeds_build();
/*   81 */     Possible<AllowedMentions> allowedMentions$impl = builder.allowedMentions_build();
/*   82 */     Possible<Snowflake> messageReference$impl = builder.messageReference_build();
/*   83 */     Possible<List<LayoutComponent>> components$impl = builder.components_build();
/*   84 */     if (builder.filesIsSet()) {
/*   85 */       this.initShim.files(createUnmodifiableList(true, builder.files));
/*      */     }
/*   87 */     if (builder.fileSpoilersIsSet()) {
/*   88 */       this.initShim.fileSpoilers(createUnmodifiableList(true, builder.fileSpoilers));
/*      */     }
/*   90 */     this.content_value = content$impl.toOptional().orElse(null);
/*   91 */     this.content_absent = content$impl.isAbsent();
/*   92 */     this.nonce_value = nonce$impl.toOptional().orElse(null);
/*   93 */     this.nonce_absent = nonce$impl.isAbsent();
/*   94 */     this.tts_value = tts$impl.toOptional().orElse(null);
/*   95 */     this.tts_absent = tts$impl.isAbsent();
/*   96 */     this.embeds_value = embeds$impl.toOptional().orElse(null);
/*   97 */     this.embeds_absent = embeds$impl.isAbsent();
/*   98 */     this.allowedMentions_value = allowedMentions$impl.toOptional().orElse(null);
/*   99 */     this.allowedMentions_absent = allowedMentions$impl.isAbsent();
/*  100 */     this.messageReference_value = messageReference$impl.toOptional().orElse(null);
/*  101 */     this.messageReference_absent = messageReference$impl.isAbsent();
/*  102 */     this.components_value = components$impl.toOptional().orElse(null);
/*  103 */     this.components_absent = components$impl.isAbsent();
/*  104 */     this.files = this.initShim.files();
/*  105 */     this.fileSpoilers = this.initShim.fileSpoilers();
/*  106 */     this.initShim = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private MessageCreateSpec(Possible<String> content, Possible<String> nonce, Possible<Boolean> tts, Possible<List<EmbedCreateSpec>> embeds, List<MessageCreateFields.File> files, List<MessageCreateFields.FileSpoiler> fileSpoilers, Possible<AllowedMentions> allowedMentions, Possible<Snowflake> messageReference, Possible<List<LayoutComponent>> components) {
/*  119 */     Possible<String> content$impl = content;
/*  120 */     Possible<String> nonce$impl = nonce;
/*  121 */     Possible<Boolean> tts$impl = tts;
/*  122 */     Possible<List<EmbedCreateSpec>> embeds$impl = embeds;
/*  123 */     this.initShim.files(files);
/*  124 */     this.initShim.fileSpoilers(fileSpoilers);
/*  125 */     Possible<AllowedMentions> allowedMentions$impl = allowedMentions;
/*  126 */     Possible<Snowflake> messageReference$impl = messageReference;
/*  127 */     Possible<List<LayoutComponent>> components$impl = components;
/*  128 */     this.content_value = content$impl.toOptional().orElse(null);
/*  129 */     this.content_absent = content$impl.isAbsent();
/*  130 */     this.nonce_value = nonce$impl.toOptional().orElse(null);
/*  131 */     this.nonce_absent = nonce$impl.isAbsent();
/*  132 */     this.tts_value = tts$impl.toOptional().orElse(null);
/*  133 */     this.tts_absent = tts$impl.isAbsent();
/*  134 */     this.embeds_value = embeds$impl.toOptional().orElse(null);
/*  135 */     this.embeds_absent = embeds$impl.isAbsent();
/*  136 */     this.allowedMentions_value = allowedMentions$impl.toOptional().orElse(null);
/*  137 */     this.allowedMentions_absent = allowedMentions$impl.isAbsent();
/*  138 */     this.messageReference_value = messageReference$impl.toOptional().orElse(null);
/*  139 */     this.messageReference_absent = messageReference$impl.isAbsent();
/*  140 */     this.components_value = components$impl.toOptional().orElse(null);
/*  141 */     this.components_absent = components$impl.isAbsent();
/*  142 */     this.files = this.initShim.files();
/*  143 */     this.fileSpoilers = this.initShim.fileSpoilers();
/*  144 */     this.initShim = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  150 */   private volatile transient InitShim initShim = new InitShim();
/*      */   
/*      */   @Generated(from = "MessageCreateSpecGenerator", generator = "Immutables")
/*      */   private final class InitShim
/*      */   {
/*  155 */     private byte filesBuildStage = 0;
/*      */     private List<MessageCreateFields.File> files;
/*      */     
/*      */     List<MessageCreateFields.File> files() {
/*  159 */       if (this.filesBuildStage == -1) throw new IllegalStateException(formatInitCycleMessage()); 
/*  160 */       if (this.filesBuildStage == 0) {
/*  161 */         this.filesBuildStage = -1;
/*  162 */         this.files = (List)MessageCreateSpec.createUnmodifiableList(false, MessageCreateSpec.createSafeList((Iterable)MessageCreateSpec.this.filesInitialize(), true, false));
/*  163 */         this.filesBuildStage = 1;
/*      */       } 
/*  165 */       return this.files;
/*      */     }
/*      */     
/*      */     void files(List<MessageCreateFields.File> files) {
/*  169 */       this.files = files;
/*  170 */       this.filesBuildStage = 1;
/*      */     }
/*      */     
/*  173 */     private byte fileSpoilersBuildStage = 0;
/*      */     private List<MessageCreateFields.FileSpoiler> fileSpoilers;
/*      */     
/*      */     List<MessageCreateFields.FileSpoiler> fileSpoilers() {
/*  177 */       if (this.fileSpoilersBuildStage == -1) throw new IllegalStateException(formatInitCycleMessage()); 
/*  178 */       if (this.fileSpoilersBuildStage == 0) {
/*  179 */         this.fileSpoilersBuildStage = -1;
/*  180 */         this.fileSpoilers = (List)MessageCreateSpec.createUnmodifiableList(false, MessageCreateSpec.createSafeList((Iterable)MessageCreateSpec.this.fileSpoilersInitialize(), true, false));
/*  181 */         this.fileSpoilersBuildStage = 1;
/*      */       } 
/*  183 */       return this.fileSpoilers;
/*      */     }
/*      */     
/*      */     void fileSpoilers(List<MessageCreateFields.FileSpoiler> fileSpoilers) {
/*  187 */       this.fileSpoilers = fileSpoilers;
/*  188 */       this.fileSpoilersBuildStage = 1;
/*      */     }
/*      */     private InitShim() {}
/*      */     private String formatInitCycleMessage() {
/*  192 */       List<String> attributes = new ArrayList<>();
/*  193 */       if (this.filesBuildStage == -1) attributes.add("files"); 
/*  194 */       if (this.fileSpoilersBuildStage == -1) attributes.add("fileSpoilers"); 
/*  195 */       return "Cannot build MessageCreateSpec, attribute initializers form cycle " + attributes;
/*      */     }
/*      */   }
/*      */   
/*      */   private List<MessageCreateFields.File> filesInitialize() {
/*  200 */     return super.files();
/*      */   }
/*      */   
/*      */   private List<MessageCreateFields.FileSpoiler> fileSpoilersInitialize() {
/*  204 */     return super.fileSpoilers();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Possible<String> content() {
/*  212 */     return this.content_absent ? Possible.absent() : Possible.of(this.content_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Possible<String> nonce() {
/*  220 */     return this.nonce_absent ? Possible.absent() : Possible.of(this.nonce_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Possible<Boolean> tts() {
/*  228 */     return this.tts_absent ? Possible.absent() : Possible.of(this.tts_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Possible<List<EmbedCreateSpec>> embeds() {
/*  236 */     return this.embeds_absent ? Possible.absent() : 
/*  237 */       Possible.of(this.embeds_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<MessageCreateFields.File> files() {
/*  245 */     InitShim shim = this.initShim;
/*  246 */     return (shim != null) ? 
/*  247 */       shim.files() : 
/*  248 */       this.files;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<MessageCreateFields.FileSpoiler> fileSpoilers() {
/*  256 */     InitShim shim = this.initShim;
/*  257 */     return (shim != null) ? 
/*  258 */       shim.fileSpoilers() : 
/*  259 */       this.fileSpoilers;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Possible<AllowedMentions> allowedMentions() {
/*  267 */     return this.allowedMentions_absent ? Possible.absent() : Possible.of(this.allowedMentions_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Possible<Snowflake> messageReference() {
/*  275 */     return this.messageReference_absent ? Possible.absent() : Possible.of(this.messageReference_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Possible<List<LayoutComponent>> components() {
/*  283 */     return this.components_absent ? Possible.absent() : 
/*  284 */       Possible.of(this.components_value);
/*      */   }
/*      */   
/*      */   public MessageCreateSpec withContent(Possible<String> value) {
/*  288 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/*  289 */     return validate(new MessageCreateSpec(newValue, 
/*      */           
/*  291 */           nonce(), 
/*  292 */           tts(), 
/*  293 */           embeds(), this.files, this.fileSpoilers, 
/*      */ 
/*      */           
/*  296 */           allowedMentions(), 
/*  297 */           messageReference(), 
/*  298 */           components()));
/*      */   }
/*      */   
/*      */   public MessageCreateSpec withContent(String value) {
/*  302 */     Possible<String> newValue = Possible.of(value);
/*  303 */     return validate(new MessageCreateSpec(newValue, 
/*      */           
/*  305 */           nonce(), 
/*  306 */           tts(), 
/*  307 */           embeds(), this.files, this.fileSpoilers, 
/*      */ 
/*      */           
/*  310 */           allowedMentions(), 
/*  311 */           messageReference(), 
/*  312 */           components()));
/*      */   }
/*      */   
/*      */   public MessageCreateSpec withNonce(Possible<String> value) {
/*  316 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/*  317 */     return validate(new MessageCreateSpec(
/*  318 */           content(), newValue, 
/*      */           
/*  320 */           tts(), 
/*  321 */           embeds(), this.files, this.fileSpoilers, 
/*      */ 
/*      */           
/*  324 */           allowedMentions(), 
/*  325 */           messageReference(), 
/*  326 */           components()));
/*      */   }
/*      */   
/*      */   public MessageCreateSpec withNonce(String value) {
/*  330 */     Possible<String> newValue = Possible.of(value);
/*  331 */     return validate(new MessageCreateSpec(
/*  332 */           content(), newValue, 
/*      */           
/*  334 */           tts(), 
/*  335 */           embeds(), this.files, this.fileSpoilers, 
/*      */ 
/*      */           
/*  338 */           allowedMentions(), 
/*  339 */           messageReference(), 
/*  340 */           components()));
/*      */   }
/*      */   
/*      */   public MessageCreateSpec withTts(Possible<Boolean> value) {
/*  344 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/*  345 */     return validate(new MessageCreateSpec(
/*  346 */           content(), 
/*  347 */           nonce(), newValue, 
/*      */           
/*  349 */           embeds(), this.files, this.fileSpoilers, 
/*      */ 
/*      */           
/*  352 */           allowedMentions(), 
/*  353 */           messageReference(), 
/*  354 */           components()));
/*      */   }
/*      */   
/*      */   public MessageCreateSpec withTts(Boolean value) {
/*  358 */     Possible<Boolean> newValue = Possible.of(value);
/*  359 */     return validate(new MessageCreateSpec(
/*  360 */           content(), 
/*  361 */           nonce(), newValue, 
/*      */           
/*  363 */           embeds(), this.files, this.fileSpoilers, 
/*      */ 
/*      */           
/*  366 */           allowedMentions(), 
/*  367 */           messageReference(), 
/*  368 */           components()));
/*      */   }
/*      */   
/*      */   public MessageCreateSpec withEmbeds(Possible<List<EmbedCreateSpec>> possible) {
/*  372 */     Possible<List<EmbedCreateSpec>> newValue = Objects.<Possible<List<EmbedCreateSpec>>>requireNonNull(possible);
/*  373 */     return validate(new MessageCreateSpec(
/*  374 */           content(), 
/*  375 */           nonce(), 
/*  376 */           tts(), newValue, this.files, this.fileSpoilers, 
/*      */ 
/*      */ 
/*      */           
/*  380 */           allowedMentions(), 
/*  381 */           messageReference(), 
/*  382 */           components()));
/*      */   }
/*      */   
/*      */   public MessageCreateSpec withEmbeds(Iterable<EmbedCreateSpec> elements) {
/*  386 */     Possible<List<EmbedCreateSpec>> newValue = Possible.of(
/*  387 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/*  388 */     return validate(new MessageCreateSpec(
/*  389 */           content(), 
/*  390 */           nonce(), 
/*  391 */           tts(), newValue, this.files, this.fileSpoilers, 
/*      */ 
/*      */ 
/*      */           
/*  395 */           allowedMentions(), 
/*  396 */           messageReference(), 
/*  397 */           components()));
/*      */   }
/*      */   
/*      */   @SafeVarargs
/*      */   public final MessageCreateSpec withEmbeds(EmbedCreateSpec... elements) {
/*  402 */     Possible<List<EmbedCreateSpec>> newValue = Possible.of(Arrays.asList(elements));
/*  403 */     return validate(new MessageCreateSpec(
/*  404 */           content(), 
/*  405 */           nonce(), 
/*  406 */           tts(), newValue, this.files, this.fileSpoilers, 
/*      */ 
/*      */ 
/*      */           
/*  410 */           allowedMentions(), 
/*  411 */           messageReference(), 
/*  412 */           components()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final MessageCreateSpec withFiles(MessageCreateFields.File... elements) {
/*  421 */     List<MessageCreateFields.File> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/*  422 */     return validate(new MessageCreateSpec(
/*  423 */           content(), 
/*  424 */           nonce(), 
/*  425 */           tts(), 
/*  426 */           embeds(), newValue, this.fileSpoilers, 
/*      */ 
/*      */           
/*  429 */           allowedMentions(), 
/*  430 */           messageReference(), 
/*  431 */           components()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final MessageCreateSpec withFiles(Iterable<? extends MessageCreateFields.File> elements) {
/*  441 */     if (this.files == elements) return this; 
/*  442 */     List<MessageCreateFields.File> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/*  443 */     return validate(new MessageCreateSpec(
/*  444 */           content(), 
/*  445 */           nonce(), 
/*  446 */           tts(), 
/*  447 */           embeds(), newValue, this.fileSpoilers, 
/*      */ 
/*      */           
/*  450 */           allowedMentions(), 
/*  451 */           messageReference(), 
/*  452 */           components()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final MessageCreateSpec withFileSpoilers(MessageCreateFields.FileSpoiler... elements) {
/*  461 */     List<MessageCreateFields.FileSpoiler> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/*  462 */     return validate(new MessageCreateSpec(
/*  463 */           content(), 
/*  464 */           nonce(), 
/*  465 */           tts(), 
/*  466 */           embeds(), this.files, newValue, 
/*      */ 
/*      */           
/*  469 */           allowedMentions(), 
/*  470 */           messageReference(), 
/*  471 */           components()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final MessageCreateSpec withFileSpoilers(Iterable<? extends MessageCreateFields.FileSpoiler> elements) {
/*  481 */     if (this.fileSpoilers == elements) return this; 
/*  482 */     List<MessageCreateFields.FileSpoiler> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/*  483 */     return validate(new MessageCreateSpec(
/*  484 */           content(), 
/*  485 */           nonce(), 
/*  486 */           tts(), 
/*  487 */           embeds(), this.files, newValue, 
/*      */ 
/*      */           
/*  490 */           allowedMentions(), 
/*  491 */           messageReference(), 
/*  492 */           components()));
/*      */   }
/*      */   
/*      */   public MessageCreateSpec withAllowedMentions(Possible<AllowedMentions> value) {
/*  496 */     Possible<AllowedMentions> newValue = Objects.<Possible<AllowedMentions>>requireNonNull(value);
/*  497 */     return validate(new MessageCreateSpec(
/*  498 */           content(), 
/*  499 */           nonce(), 
/*  500 */           tts(), 
/*  501 */           embeds(), this.files, this.fileSpoilers, newValue, 
/*      */ 
/*      */ 
/*      */           
/*  505 */           messageReference(), 
/*  506 */           components()));
/*      */   }
/*      */   
/*      */   public MessageCreateSpec withAllowedMentions(AllowedMentions value) {
/*  510 */     Possible<AllowedMentions> newValue = Possible.of(value);
/*  511 */     return validate(new MessageCreateSpec(
/*  512 */           content(), 
/*  513 */           nonce(), 
/*  514 */           tts(), 
/*  515 */           embeds(), this.files, this.fileSpoilers, newValue, 
/*      */ 
/*      */ 
/*      */           
/*  519 */           messageReference(), 
/*  520 */           components()));
/*      */   }
/*      */   
/*      */   public MessageCreateSpec withMessageReference(Possible<Snowflake> value) {
/*  524 */     Possible<Snowflake> newValue = Objects.<Possible<Snowflake>>requireNonNull(value);
/*  525 */     return validate(new MessageCreateSpec(
/*  526 */           content(), 
/*  527 */           nonce(), 
/*  528 */           tts(), 
/*  529 */           embeds(), this.files, this.fileSpoilers, 
/*      */ 
/*      */           
/*  532 */           allowedMentions(), newValue, 
/*      */           
/*  534 */           components()));
/*      */   }
/*      */   
/*      */   public MessageCreateSpec withMessageReference(Snowflake value) {
/*  538 */     Possible<Snowflake> newValue = Possible.of(value);
/*  539 */     return validate(new MessageCreateSpec(
/*  540 */           content(), 
/*  541 */           nonce(), 
/*  542 */           tts(), 
/*  543 */           embeds(), this.files, this.fileSpoilers, 
/*      */ 
/*      */           
/*  546 */           allowedMentions(), newValue, 
/*      */           
/*  548 */           components()));
/*      */   }
/*      */   
/*      */   public MessageCreateSpec withComponents(Possible<List<LayoutComponent>> possible) {
/*  552 */     Possible<List<LayoutComponent>> newValue = Objects.<Possible<List<LayoutComponent>>>requireNonNull(possible);
/*  553 */     return validate(new MessageCreateSpec(
/*  554 */           content(), 
/*  555 */           nonce(), 
/*  556 */           tts(), 
/*  557 */           embeds(), this.files, this.fileSpoilers, 
/*      */ 
/*      */           
/*  560 */           allowedMentions(), 
/*  561 */           messageReference(), newValue));
/*      */   }
/*      */ 
/*      */   
/*      */   public MessageCreateSpec withComponents(Iterable<LayoutComponent> elements) {
/*  566 */     Possible<List<LayoutComponent>> newValue = Possible.of(
/*  567 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/*  568 */     return validate(new MessageCreateSpec(
/*  569 */           content(), 
/*  570 */           nonce(), 
/*  571 */           tts(), 
/*  572 */           embeds(), this.files, this.fileSpoilers, 
/*      */ 
/*      */           
/*  575 */           allowedMentions(), 
/*  576 */           messageReference(), newValue));
/*      */   }
/*      */ 
/*      */   
/*      */   @SafeVarargs
/*      */   public final MessageCreateSpec withComponents(LayoutComponent... elements) {
/*  582 */     Possible<List<LayoutComponent>> newValue = Possible.of(Arrays.asList(elements));
/*  583 */     return validate(new MessageCreateSpec(
/*  584 */           content(), 
/*  585 */           nonce(), 
/*  586 */           tts(), 
/*  587 */           embeds(), this.files, this.fileSpoilers, 
/*      */ 
/*      */           
/*  590 */           allowedMentions(), 
/*  591 */           messageReference(), newValue));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean equals(Object another) {
/*  601 */     if (this == another) return true; 
/*  602 */     return (another instanceof MessageCreateSpec && 
/*  603 */       equalTo(0, (MessageCreateSpec)another));
/*      */   }
/*      */   
/*      */   private boolean equalTo(int synthetic, MessageCreateSpec another) {
/*  607 */     return (content().equals(another.content()) && 
/*  608 */       nonce().equals(another.nonce()) && 
/*  609 */       tts().equals(another.tts()) && 
/*  610 */       Objects.equals(this.embeds_value, another.embeds_value) && this.files
/*  611 */       .equals(another.files) && this.fileSpoilers
/*  612 */       .equals(another.fileSpoilers) && 
/*  613 */       allowedMentions().equals(another.allowedMentions()) && 
/*  614 */       messageReference().equals(another.messageReference()) && 
/*  615 */       Objects.equals(this.components_value, another.components_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int hashCode() {
/*  624 */     int h = 5381;
/*  625 */     h += (h << 5) + content().hashCode();
/*  626 */     h += (h << 5) + nonce().hashCode();
/*  627 */     h += (h << 5) + tts().hashCode();
/*  628 */     h += (h << 5) + Objects.hashCode(this.embeds_value);
/*  629 */     h += (h << 5) + this.files.hashCode();
/*  630 */     h += (h << 5) + this.fileSpoilers.hashCode();
/*  631 */     h += (h << 5) + allowedMentions().hashCode();
/*  632 */     h += (h << 5) + messageReference().hashCode();
/*  633 */     h += (h << 5) + Objects.hashCode(this.components_value);
/*  634 */     return h;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/*  643 */     return "MessageCreateSpec{content=" + 
/*  644 */       content().toString() + ", nonce=" + 
/*  645 */       nonce().toString() + ", tts=" + 
/*  646 */       tts().toString() + ", embeds=" + 
/*  647 */       Objects.toString(this.embeds_value) + ", files=" + this.files + ", fileSpoilers=" + this.fileSpoilers + ", allowedMentions=" + 
/*      */ 
/*      */       
/*  650 */       allowedMentions().toString() + ", messageReference=" + 
/*  651 */       messageReference().toString() + ", components=" + 
/*  652 */       Objects.toString(this.components_value) + "}";
/*      */   }
/*      */ 
/*      */   
/*  656 */   private static final MessageCreateSpec INSTANCE = validate(new MessageCreateSpec());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static MessageCreateSpec create() {
/*  663 */     return INSTANCE;
/*      */   }
/*      */   
/*      */   private static MessageCreateSpec validate(MessageCreateSpec instance) {
/*  667 */     return (INSTANCE != null && INSTANCE.equalTo(0, instance)) ? INSTANCE : instance;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static MessageCreateSpec copyOf(MessageCreateSpecGenerator instance) {
/*  678 */     if (instance instanceof MessageCreateSpec) {
/*  679 */       return (MessageCreateSpec)instance;
/*      */     }
/*  681 */     return builder()
/*  682 */       .from(instance)
/*  683 */       .build();
/*      */   }
/*      */   
/*      */   public boolean isContentPresent() {
/*  687 */     return !this.content_absent;
/*      */   }
/*      */   
/*      */   public String contentOrElse(String defaultValue) {
/*  691 */     return !this.content_absent ? this.content_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isNoncePresent() {
/*  695 */     return !this.nonce_absent;
/*      */   }
/*      */   
/*      */   public String nonceOrElse(String defaultValue) {
/*  699 */     return !this.nonce_absent ? this.nonce_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isTtsPresent() {
/*  703 */     return !this.tts_absent;
/*      */   }
/*      */   
/*      */   public Boolean ttsOrElse(Boolean defaultValue) {
/*  707 */     return !this.tts_absent ? this.tts_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isEmbedsPresent() {
/*  711 */     return !this.embeds_absent;
/*      */   }
/*      */   
/*      */   public List<EmbedCreateSpec> embedsOrElse(List<EmbedCreateSpec> defaultValue) {
/*  715 */     return !this.embeds_absent ? this.embeds_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isAllowedMentionsPresent() {
/*  719 */     return !this.allowedMentions_absent;
/*      */   }
/*      */   
/*      */   public AllowedMentions allowedMentionsOrElse(AllowedMentions defaultValue) {
/*  723 */     return !this.allowedMentions_absent ? this.allowedMentions_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isMessageReferencePresent() {
/*  727 */     return !this.messageReference_absent;
/*      */   }
/*      */   
/*      */   public Snowflake messageReferenceOrElse(Snowflake defaultValue) {
/*  731 */     return !this.messageReference_absent ? this.messageReference_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isComponentsPresent() {
/*  735 */     return !this.components_absent;
/*      */   }
/*      */   
/*      */   public List<LayoutComponent> componentsOrElse(List<LayoutComponent> defaultValue) {
/*  739 */     return !this.components_absent ? this.components_value : defaultValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Builder builder() {
/*  760 */     return new Builder();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   @Generated(from = "MessageCreateSpecGenerator", generator = "Immutables")
/*      */   public static final class Builder
/*      */   {
/*      */     private static final long OPT_BIT_FILES = 1L;
/*      */ 
/*      */     
/*      */     private static final long OPT_BIT_FILE_SPOILERS = 2L;
/*      */ 
/*      */     
/*      */     private long optBits;
/*      */     
/*  776 */     private Possible<String> content_possible = Possible.absent();
/*  777 */     private Possible<String> nonce_possible = Possible.absent();
/*  778 */     private Possible<Boolean> tts_possible = Possible.absent();
/*  779 */     private List<EmbedCreateSpec> embeds_list = null;
/*  780 */     private Possible<AllowedMentions> allowedMentions_possible = Possible.absent();
/*  781 */     private Possible<Snowflake> messageReference_possible = Possible.absent();
/*  782 */     private List<LayoutComponent> components_list = null;
/*  783 */     private List<MessageCreateFields.File> files = new ArrayList<>();
/*  784 */     private List<MessageCreateFields.FileSpoiler> fileSpoilers = new ArrayList<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder from(MessageCreateSpec instance) {
/*  798 */       return from(instance);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     final Builder from(MessageCreateSpecGenerator instance) {
/*  808 */       Objects.requireNonNull(instance, "instance");
/*  809 */       content(instance.content());
/*  810 */       nonce(instance.nonce());
/*  811 */       tts(instance.tts());
/*  812 */       embeds(instance.embeds());
/*  813 */       addAllFiles(instance.files());
/*  814 */       addAllFileSpoilers(instance.fileSpoilers());
/*  815 */       allowedMentions(instance.allowedMentions());
/*  816 */       messageReference(instance.messageReference());
/*  817 */       components(instance.components());
/*  818 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder content(Possible<String> value) {
/*  823 */       this.content_possible = value;
/*  824 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder content(String value) {
/*  829 */       this.content_possible = Possible.of(value);
/*  830 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder nonce(Possible<String> value) {
/*  835 */       this.nonce_possible = value;
/*  836 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder nonce(String value) {
/*  841 */       this.nonce_possible = Possible.of(value);
/*  842 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder tts(Possible<Boolean> value) {
/*  847 */       this.tts_possible = value;
/*  848 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder tts(Boolean value) {
/*  853 */       this.tts_possible = Possible.of(value);
/*  854 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder addEmbed(EmbedCreateSpec element) {
/*  859 */       embeds_getOrCreate().add(element);
/*  860 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder addAllEmbeds(List<EmbedCreateSpec> elements) {
/*  865 */       embeds_getOrCreate().addAll(elements);
/*  866 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder embeds(Possible<List<EmbedCreateSpec>> elements) {
/*  871 */       this.embeds_list = null;
/*  872 */       elements.toOptional().ifPresent(e -> embeds_getOrCreate().addAll(e));
/*  873 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder embeds(List<EmbedCreateSpec> elements) {
/*  878 */       this.embeds_list = new ArrayList<>(elements);
/*  879 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder embeds(Iterable<EmbedCreateSpec> elements) {
/*  884 */       this.embeds_list = (List<EmbedCreateSpec>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/*  885 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public final Builder addFile(MessageCreateFields.File element) {
/*  895 */       element = ImmutableMessageCreateFields.File.copyOf(element);
/*  896 */       this.files.add(Objects.<MessageCreateFields.File>requireNonNull(element, "files element"));
/*  897 */       this.optBits |= 0x1L;
/*  898 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addFile(String name, InputStream inputStream) {
/*  908 */       return addFile(ImmutableMessageCreateFields.File.of(name, inputStream));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public final Builder addFiles(MessageCreateFields.File... elements) {
/*  918 */       for (MessageCreateFields.File element : elements) {
/*  919 */         element = ImmutableMessageCreateFields.File.copyOf(element);
/*  920 */         this.files.add(Objects.<MessageCreateFields.File>requireNonNull(element, "files element"));
/*      */       } 
/*  922 */       this.optBits |= 0x1L;
/*  923 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public final Builder files(Iterable<? extends MessageCreateFields.File> elements) {
/*  934 */       this.files.clear();
/*  935 */       return addAllFiles(elements);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public final Builder addAllFiles(Iterable<? extends MessageCreateFields.File> elements) {
/*  945 */       for (MessageCreateFields.File element : elements) {
/*  946 */         element = ImmutableMessageCreateFields.File.copyOf(element);
/*  947 */         this.files.add(Objects.<MessageCreateFields.File>requireNonNull(element, "files element"));
/*      */       } 
/*  949 */       this.optBits |= 0x1L;
/*  950 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public final Builder addFileSpoiler(MessageCreateFields.FileSpoiler element) {
/*  960 */       element = ImmutableMessageCreateFields.FileSpoiler.copyOf(element);
/*  961 */       this.fileSpoilers.add(Objects.<MessageCreateFields.FileSpoiler>requireNonNull(element, "fileSpoilers element"));
/*  962 */       this.optBits |= 0x2L;
/*  963 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addFileSpoiler(String name, InputStream inputStream) {
/*  973 */       return addFileSpoiler(ImmutableMessageCreateFields.FileSpoiler.of(name, inputStream));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public final Builder addFileSpoilers(MessageCreateFields.FileSpoiler... elements) {
/*  983 */       for (MessageCreateFields.FileSpoiler element : elements) {
/*  984 */         element = ImmutableMessageCreateFields.FileSpoiler.copyOf(element);
/*  985 */         this.fileSpoilers.add(Objects.<MessageCreateFields.FileSpoiler>requireNonNull(element, "fileSpoilers element"));
/*      */       } 
/*  987 */       this.optBits |= 0x2L;
/*  988 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public final Builder fileSpoilers(Iterable<? extends MessageCreateFields.FileSpoiler> elements) {
/*  999 */       this.fileSpoilers.clear();
/* 1000 */       return addAllFileSpoilers(elements);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public final Builder addAllFileSpoilers(Iterable<? extends MessageCreateFields.FileSpoiler> elements) {
/* 1010 */       for (MessageCreateFields.FileSpoiler element : elements) {
/* 1011 */         element = ImmutableMessageCreateFields.FileSpoiler.copyOf(element);
/* 1012 */         this.fileSpoilers.add(Objects.<MessageCreateFields.FileSpoiler>requireNonNull(element, "fileSpoilers element"));
/*      */       } 
/* 1014 */       this.optBits |= 0x2L;
/* 1015 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder allowedMentions(Possible<AllowedMentions> value) {
/* 1020 */       this.allowedMentions_possible = value;
/* 1021 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder allowedMentions(AllowedMentions value) {
/* 1026 */       this.allowedMentions_possible = Possible.of(value);
/* 1027 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder messageReference(Possible<Snowflake> value) {
/* 1032 */       this.messageReference_possible = value;
/* 1033 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder messageReference(Snowflake value) {
/* 1038 */       this.messageReference_possible = Possible.of(value);
/* 1039 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder addComponent(LayoutComponent element) {
/* 1044 */       components_getOrCreate().add(element);
/* 1045 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder addAllComponents(List<LayoutComponent> elements) {
/* 1050 */       components_getOrCreate().addAll(elements);
/* 1051 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder components(Possible<List<LayoutComponent>> elements) {
/* 1056 */       this.components_list = null;
/* 1057 */       elements.toOptional().ifPresent(e -> components_getOrCreate().addAll(e));
/* 1058 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder components(List<LayoutComponent> elements) {
/* 1063 */       this.components_list = new ArrayList<>(elements);
/* 1064 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder components(Iterable<LayoutComponent> elements) {
/* 1069 */       this.components_list = (List<LayoutComponent>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/* 1070 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public MessageCreateSpec build() {
/* 1079 */       return MessageCreateSpec.validate(new MessageCreateSpec(this));
/*      */     }
/*      */     
/*      */     private boolean filesIsSet() {
/* 1083 */       return ((this.optBits & 0x1L) != 0L);
/*      */     }
/*      */     
/*      */     private boolean fileSpoilersIsSet() {
/* 1087 */       return ((this.optBits & 0x2L) != 0L);
/*      */     }
/*      */     
/*      */     private Possible<String> content_build() {
/* 1091 */       return this.content_possible;
/*      */     }
/*      */     
/*      */     private Possible<String> nonce_build() {
/* 1095 */       return this.nonce_possible;
/*      */     }
/*      */     
/*      */     private Possible<Boolean> tts_build() {
/* 1099 */       return this.tts_possible;
/*      */     }
/*      */     
/*      */     private Possible<List<EmbedCreateSpec>> embeds_build() {
/* 1103 */       return (this.embeds_list == null) ? Possible.absent() : 
/* 1104 */         Possible.of(this.embeds_list);
/*      */     }
/*      */     
/*      */     private List<EmbedCreateSpec> embeds_getOrCreate() {
/* 1108 */       if (this.embeds_list == null) {
/* 1109 */         this.embeds_list = new ArrayList<>();
/*      */       }
/* 1111 */       return this.embeds_list;
/*      */     }
/*      */     
/*      */     private Possible<AllowedMentions> allowedMentions_build() {
/* 1115 */       return this.allowedMentions_possible;
/*      */     }
/*      */     
/*      */     private Possible<Snowflake> messageReference_build() {
/* 1119 */       return this.messageReference_possible;
/*      */     }
/*      */     
/*      */     private Possible<List<LayoutComponent>> components_build() {
/* 1123 */       return (this.components_list == null) ? Possible.absent() : 
/* 1124 */         Possible.of(this.components_list);
/*      */     }
/*      */     
/*      */     private List<LayoutComponent> components_getOrCreate() {
/* 1128 */       if (this.components_list == null) {
/* 1129 */         this.components_list = new ArrayList<>();
/*      */       }
/* 1131 */       return this.components_list;
/*      */     }
/*      */     private Builder() {} }
/*      */   
/*      */   private static <T> List<T> createSafeList(Iterable<? extends T> iterable, boolean checkNulls, boolean skipNulls) {
/*      */     ArrayList<T> list;
/* 1137 */     if (iterable instanceof Collection) {
/* 1138 */       int size = ((Collection)iterable).size();
/* 1139 */       if (size == 0) return Collections.emptyList(); 
/* 1140 */       list = new ArrayList<>();
/*      */     } else {
/* 1142 */       list = new ArrayList<>();
/*      */     } 
/* 1144 */     for (T element : iterable) {
/* 1145 */       if (skipNulls && element == null)
/* 1146 */         continue;  if (checkNulls) Objects.requireNonNull(element, "element"); 
/* 1147 */       list.add(element);
/*      */     } 
/* 1149 */     return list;
/*      */   }
/*      */   
/*      */   private static <T> List<T> createUnmodifiableList(boolean clone, List<T> list) {
/* 1153 */     switch (list.size()) { case 0:
/* 1154 */         return Collections.emptyList();
/* 1155 */       case 1: return Collections.singletonList(list.get(0)); }
/*      */     
/* 1157 */     if (clone) {
/* 1158 */       return Collections.unmodifiableList(new ArrayList<>(list));
/*      */     }
/* 1160 */     if (list instanceof ArrayList) {
/* 1161 */       ((ArrayList)list).trimToSize();
/*      */     }
/* 1163 */     return Collections.unmodifiableList(list);
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\MessageCreateSpec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */