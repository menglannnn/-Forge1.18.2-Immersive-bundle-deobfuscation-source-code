/*     */ package discord4j.core.spec;
/*     */ 
/*     */ import discord4j.discordjson.json.EmbedAuthorData;
/*     */ import discord4j.discordjson.json.EmbedFieldData;
/*     */ import discord4j.discordjson.json.EmbedFooterData;
/*     */ import org.immutables.value.Value.Enclosing;
/*     */ import org.immutables.value.Value.Immutable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @InlineFieldStyle
/*     */ @Enclosing
/*     */ public final class EmbedCreateFields
/*     */ {
/*     */   private EmbedCreateFields() {
/*  33 */     throw new AssertionError();
/*     */   }
/*     */   
/*     */   @Immutable
/*     */   public static interface Footer
/*     */     extends Spec<EmbedFooterData> {
/*     */     static Footer of(String text, @Nullable String iconUrl) {
/*  40 */       return ImmutableEmbedCreateFields.Footer.of(text, iconUrl);
/*     */     }
/*     */ 
/*     */     
/*     */     String text();
/*     */     
/*     */     @Nullable
/*     */     String iconUrl();
/*     */     
/*     */     default EmbedFooterData asRequest() {
/*  50 */       return (EmbedFooterData)EmbedFooterData.builder()
/*  51 */         .text(text())
/*  52 */         .iconUrl(InternalSpecUtils.toPossible(iconUrl()))
/*  53 */         .build();
/*     */     }
/*     */   }
/*     */   
/*     */   @Immutable
/*     */   public static interface Author
/*     */     extends Spec<EmbedAuthorData> {
/*     */     static Author of(String name, @Nullable String url, @Nullable String iconUrl) {
/*  61 */       return ImmutableEmbedCreateFields.Author.of(name, url, iconUrl);
/*     */     }
/*     */ 
/*     */     
/*     */     String name();
/*     */     
/*     */     @Nullable
/*     */     String url();
/*     */     
/*     */     @Nullable
/*     */     String iconUrl();
/*     */     
/*     */     default EmbedAuthorData asRequest() {
/*  74 */       return (EmbedAuthorData)EmbedAuthorData.builder()
/*  75 */         .name(name())
/*  76 */         .url(InternalSpecUtils.toPossible(url()))
/*  77 */         .iconUrl(InternalSpecUtils.toPossible(iconUrl()))
/*  78 */         .build();
/*     */     }
/*     */   }
/*     */   
/*     */   @Immutable
/*     */   public static interface Field
/*     */     extends Spec<EmbedFieldData> {
/*     */     static Field of(String name, String value, boolean inline) {
/*  86 */       return ImmutableEmbedCreateFields.Field.of(name, value, inline);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     default EmbedFieldData asRequest() {
/*  97 */       return (EmbedFieldData)EmbedFieldData.builder()
/*  98 */         .name(name())
/*  99 */         .value(value())
/* 100 */         .inline(Boolean.valueOf(inline()))
/* 101 */         .build();
/*     */     }
/*     */     
/*     */     String name();
/*     */     
/*     */     String value();
/*     */     
/*     */     boolean inline();
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\EmbedCreateFields.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */