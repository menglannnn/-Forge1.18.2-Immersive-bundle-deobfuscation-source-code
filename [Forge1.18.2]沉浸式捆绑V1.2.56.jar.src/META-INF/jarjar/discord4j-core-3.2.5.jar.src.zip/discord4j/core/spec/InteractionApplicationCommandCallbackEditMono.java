/*     */ package discord4j.core.spec;
/*     */ 
/*     */ import discord4j.core.event.domain.interaction.ComponentInteractionEvent;
/*     */ import discord4j.core.object.component.LayoutComponent;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import discord4j.rest.util.AllowedMentions;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.stream.StreamSupport;
/*     */ import org.immutables.value.Generated;
/*     */ import reactor.core.CoreSubscriber;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "InteractionApplicationCommandCallbackEditMonoGenerator", generator = "Immutables")
/*     */ public final class InteractionApplicationCommandCallbackEditMono
/*     */   extends InteractionApplicationCommandCallbackEditMonoGenerator
/*     */ {
/*     */   private final String content_value;
/*     */   private final boolean content_absent;
/*     */   private final Boolean tts_value;
/*     */   private final boolean tts_absent;
/*     */   private final Boolean ephemeral_value;
/*     */   private final boolean ephemeral_absent;
/*     */   private final List<EmbedCreateSpec> embeds_value;
/*     */   private final boolean embeds_absent;
/*     */   private final List<MessageCreateFields.File> files;
/*     */   private final List<MessageCreateFields.FileSpoiler> fileSpoilers;
/*     */   private final AllowedMentions allowedMentions_value;
/*     */   private final boolean allowedMentions_absent;
/*     */   private final List<LayoutComponent> components_value;
/*     */   private final boolean components_absent;
/*     */   private final ComponentInteractionEvent event;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   private volatile transient InitShim initShim;
/*     */   
/*     */   private InteractionApplicationCommandCallbackEditMono(ComponentInteractionEvent event) {
/* 109 */     this.initShim = new InitShim(); this.event = Objects.<ComponentInteractionEvent>requireNonNull(event, "event"); Possible<String> content$impl = Possible.absent(); Possible<Boolean> tts$impl = Possible.absent(); Possible<Boolean> ephemeral$impl = Possible.absent(); Possible<List<EmbedCreateSpec>> embeds$impl = Possible.absent(); Possible<AllowedMentions> allowedMentions$impl = Possible.absent(); Possible<List<LayoutComponent>> components$impl = Possible.absent(); this.content_value = content$impl.toOptional().orElse(null); this.content_absent = content$impl.isAbsent(); this.tts_value = tts$impl.toOptional().orElse(null); this.tts_absent = tts$impl.isAbsent(); this.ephemeral_value = ephemeral$impl.toOptional().orElse(null); this.ephemeral_absent = ephemeral$impl.isAbsent(); this.embeds_value = embeds$impl.toOptional().orElse(null); this.embeds_absent = embeds$impl.isAbsent(); this.allowedMentions_value = allowedMentions$impl.toOptional().orElse(null); this.allowedMentions_absent = allowedMentions$impl.isAbsent(); this.components_value = components$impl.toOptional().orElse(null); this.components_absent = components$impl.isAbsent(); this.files = this.initShim.files(); this.fileSpoilers = this.initShim.fileSpoilers(); this.initShim = null; } private InteractionApplicationCommandCallbackEditMono(Possible<String> content, Possible<Boolean> tts, Possible<Boolean> ephemeral, Possible<List<EmbedCreateSpec>> embeds, List<MessageCreateFields.File> files, List<MessageCreateFields.FileSpoiler> fileSpoilers, Possible<AllowedMentions> allowedMentions, Possible<List<LayoutComponent>> components, ComponentInteractionEvent event) { this.initShim = new InitShim(); Possible<String> content$impl = content; Possible<Boolean> tts$impl = tts; Possible<Boolean> ephemeral$impl = ephemeral; Possible<List<EmbedCreateSpec>> embeds$impl = embeds; this.initShim.files(files); this.initShim.fileSpoilers(fileSpoilers); Possible<AllowedMentions> allowedMentions$impl = allowedMentions; Possible<List<LayoutComponent>> components$impl = components; this.event = event; this.content_value = content$impl.toOptional().orElse(null); this.content_absent = content$impl.isAbsent(); this.tts_value = tts$impl.toOptional().orElse(null); this.tts_absent = tts$impl.isAbsent(); this.ephemeral_value = ephemeral$impl.toOptional().orElse(null); this.ephemeral_absent = ephemeral$impl.isAbsent(); this.embeds_value = embeds$impl.toOptional().orElse(null); this.embeds_absent = embeds$impl.isAbsent(); this.allowedMentions_value = allowedMentions$impl.toOptional().orElse(null); this.allowedMentions_absent = allowedMentions$impl.isAbsent();
/*     */     this.components_value = components$impl.toOptional().orElse(null);
/*     */     this.components_absent = components$impl.isAbsent();
/*     */     this.files = this.initShim.files();
/*     */     this.fileSpoilers = this.initShim.fileSpoilers();
/* 114 */     this.initShim = null; } @Generated(from = "InteractionApplicationCommandCallbackEditMonoGenerator", generator = "Immutables") private final class InitShim { private byte filesBuildStage = 0;
/*     */     private List<MessageCreateFields.File> files;
/*     */     
/*     */     List<MessageCreateFields.File> files() {
/* 118 */       if (this.filesBuildStage == -1) throw new IllegalStateException(formatInitCycleMessage()); 
/* 119 */       if (this.filesBuildStage == 0) {
/* 120 */         this.filesBuildStage = -1;
/* 121 */         this.files = (List)InteractionApplicationCommandCallbackEditMono.createUnmodifiableList(false, InteractionApplicationCommandCallbackEditMono.createSafeList((Iterable)InteractionApplicationCommandCallbackEditMono.this.files(), true, false));
/* 122 */         this.filesBuildStage = 1;
/*     */       } 
/* 124 */       return this.files;
/*     */     }
/*     */     
/*     */     void files(List<MessageCreateFields.File> files) {
/* 128 */       this.files = files;
/* 129 */       this.filesBuildStage = 1;
/*     */     }
/*     */     
/* 132 */     private byte fileSpoilersBuildStage = 0;
/*     */     private List<MessageCreateFields.FileSpoiler> fileSpoilers;
/*     */     
/*     */     List<MessageCreateFields.FileSpoiler> fileSpoilers() {
/* 136 */       if (this.fileSpoilersBuildStage == -1) throw new IllegalStateException(formatInitCycleMessage()); 
/* 137 */       if (this.fileSpoilersBuildStage == 0) {
/* 138 */         this.fileSpoilersBuildStage = -1;
/* 139 */         this.fileSpoilers = (List)InteractionApplicationCommandCallbackEditMono.createUnmodifiableList(false, InteractionApplicationCommandCallbackEditMono.createSafeList((Iterable)InteractionApplicationCommandCallbackEditMono.this.fileSpoilers(), true, false));
/* 140 */         this.fileSpoilersBuildStage = 1;
/*     */       } 
/* 142 */       return this.fileSpoilers;
/*     */     }
/*     */     
/*     */     void fileSpoilers(List<MessageCreateFields.FileSpoiler> fileSpoilers) {
/* 146 */       this.fileSpoilers = fileSpoilers;
/* 147 */       this.fileSpoilersBuildStage = 1;
/*     */     }
/*     */     
/*     */     private String formatInitCycleMessage() {
/* 151 */       List<String> attributes = new ArrayList<>();
/* 152 */       if (this.filesBuildStage == -1) attributes.add("files"); 
/* 153 */       if (this.fileSpoilersBuildStage == -1) attributes.add("fileSpoilers"); 
/* 154 */       return "Cannot build InteractionApplicationCommandCallbackEditMono, attribute initializers form cycle " + attributes;
/*     */     }
/*     */ 
/*     */     
/*     */     private InitShim() {} }
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<String> content() {
/* 163 */     return this.content_absent ? Possible.absent() : Possible.of(this.content_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Boolean> tts() {
/* 171 */     return this.tts_absent ? Possible.absent() : Possible.of(this.tts_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Boolean> ephemeral() {
/* 179 */     return this.ephemeral_absent ? Possible.absent() : Possible.of(this.ephemeral_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<List<EmbedCreateSpec>> embeds() {
/* 187 */     return this.embeds_absent ? Possible.absent() : 
/* 188 */       Possible.of(this.embeds_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<MessageCreateFields.File> files() {
/* 196 */     InitShim shim = this.initShim;
/* 197 */     return (shim != null) ? 
/* 198 */       shim.files() : 
/* 199 */       this.files;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<MessageCreateFields.FileSpoiler> fileSpoilers() {
/* 207 */     InitShim shim = this.initShim;
/* 208 */     return (shim != null) ? 
/* 209 */       shim.fileSpoilers() : 
/* 210 */       this.fileSpoilers;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<AllowedMentions> allowedMentions() {
/* 218 */     return this.allowedMentions_absent ? Possible.absent() : Possible.of(this.allowedMentions_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<List<LayoutComponent>> components() {
/* 226 */     return this.components_absent ? Possible.absent() : 
/* 227 */       Possible.of(this.components_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ComponentInteractionEvent event() {
/* 235 */     return this.event;
/*     */   }
/*     */   
/*     */   public InteractionApplicationCommandCallbackEditMono withContent(Possible<String> value) {
/* 239 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/* 240 */     return new InteractionApplicationCommandCallbackEditMono(newValue, 
/*     */         
/* 242 */         tts(), 
/* 243 */         ephemeral(), 
/* 244 */         embeds(), this.files, this.fileSpoilers, 
/*     */ 
/*     */         
/* 247 */         allowedMentions(), 
/* 248 */         components(), this.event);
/*     */   }
/*     */ 
/*     */   
/*     */   public InteractionApplicationCommandCallbackEditMono withContent(String value) {
/* 253 */     Possible<String> newValue = Possible.of(value);
/* 254 */     return new InteractionApplicationCommandCallbackEditMono(newValue, 
/*     */         
/* 256 */         tts(), 
/* 257 */         ephemeral(), 
/* 258 */         embeds(), this.files, this.fileSpoilers, 
/*     */ 
/*     */         
/* 261 */         allowedMentions(), 
/* 262 */         components(), this.event);
/*     */   }
/*     */ 
/*     */   
/*     */   public InteractionApplicationCommandCallbackEditMono withTts(Possible<Boolean> value) {
/* 267 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/* 268 */     return new InteractionApplicationCommandCallbackEditMono(
/* 269 */         content(), newValue, 
/*     */         
/* 271 */         ephemeral(), 
/* 272 */         embeds(), this.files, this.fileSpoilers, 
/*     */ 
/*     */         
/* 275 */         allowedMentions(), 
/* 276 */         components(), this.event);
/*     */   }
/*     */ 
/*     */   
/*     */   public InteractionApplicationCommandCallbackEditMono withTts(Boolean value) {
/* 281 */     Possible<Boolean> newValue = Possible.of(value);
/* 282 */     return new InteractionApplicationCommandCallbackEditMono(
/* 283 */         content(), newValue, 
/*     */         
/* 285 */         ephemeral(), 
/* 286 */         embeds(), this.files, this.fileSpoilers, 
/*     */ 
/*     */         
/* 289 */         allowedMentions(), 
/* 290 */         components(), this.event);
/*     */   }
/*     */ 
/*     */   
/*     */   public InteractionApplicationCommandCallbackEditMono withEphemeral(Possible<Boolean> value) {
/* 295 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/* 296 */     return new InteractionApplicationCommandCallbackEditMono(
/* 297 */         content(), 
/* 298 */         tts(), newValue, 
/*     */         
/* 300 */         embeds(), this.files, this.fileSpoilers, 
/*     */ 
/*     */         
/* 303 */         allowedMentions(), 
/* 304 */         components(), this.event);
/*     */   }
/*     */ 
/*     */   
/*     */   public InteractionApplicationCommandCallbackEditMono withEphemeral(Boolean value) {
/* 309 */     Possible<Boolean> newValue = Possible.of(value);
/* 310 */     return new InteractionApplicationCommandCallbackEditMono(
/* 311 */         content(), 
/* 312 */         tts(), newValue, 
/*     */         
/* 314 */         embeds(), this.files, this.fileSpoilers, 
/*     */ 
/*     */         
/* 317 */         allowedMentions(), 
/* 318 */         components(), this.event);
/*     */   }
/*     */ 
/*     */   
/*     */   public InteractionApplicationCommandCallbackEditMono withEmbeds(Possible<List<EmbedCreateSpec>> possible) {
/* 323 */     Possible<List<EmbedCreateSpec>> newValue = Objects.<Possible<List<EmbedCreateSpec>>>requireNonNull(possible);
/* 324 */     return new InteractionApplicationCommandCallbackEditMono(
/* 325 */         content(), 
/* 326 */         tts(), 
/* 327 */         ephemeral(), newValue, this.files, this.fileSpoilers, 
/*     */ 
/*     */ 
/*     */         
/* 331 */         allowedMentions(), 
/* 332 */         components(), this.event);
/*     */   }
/*     */ 
/*     */   
/*     */   public InteractionApplicationCommandCallbackEditMono withEmbeds(Iterable<EmbedCreateSpec> elements) {
/* 337 */     Possible<List<EmbedCreateSpec>> newValue = Possible.of(
/* 338 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/* 339 */     return new InteractionApplicationCommandCallbackEditMono(
/* 340 */         content(), 
/* 341 */         tts(), 
/* 342 */         ephemeral(), newValue, this.files, this.fileSpoilers, 
/*     */ 
/*     */ 
/*     */         
/* 346 */         allowedMentions(), 
/* 347 */         components(), this.event);
/*     */   }
/*     */ 
/*     */   
/*     */   @SafeVarargs
/*     */   public final InteractionApplicationCommandCallbackEditMono withEmbeds(EmbedCreateSpec... elements) {
/* 353 */     Possible<List<EmbedCreateSpec>> newValue = Possible.of(Arrays.asList(elements));
/* 354 */     return new InteractionApplicationCommandCallbackEditMono(
/* 355 */         content(), 
/* 356 */         tts(), 
/* 357 */         ephemeral(), newValue, this.files, this.fileSpoilers, 
/*     */ 
/*     */ 
/*     */         
/* 361 */         allowedMentions(), 
/* 362 */         components(), this.event);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final InteractionApplicationCommandCallbackEditMono withFiles(MessageCreateFields.File... elements) {
/* 372 */     List<MessageCreateFields.File> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/* 373 */     return new InteractionApplicationCommandCallbackEditMono(
/* 374 */         content(), 
/* 375 */         tts(), 
/* 376 */         ephemeral(), 
/* 377 */         embeds(), newValue, this.fileSpoilers, 
/*     */ 
/*     */         
/* 380 */         allowedMentions(), 
/* 381 */         components(), this.event);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final InteractionApplicationCommandCallbackEditMono withFiles(Iterable<? extends MessageCreateFields.File> elements) {
/* 392 */     if (this.files == elements) return this; 
/* 393 */     List<MessageCreateFields.File> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/* 394 */     return new InteractionApplicationCommandCallbackEditMono(
/* 395 */         content(), 
/* 396 */         tts(), 
/* 397 */         ephemeral(), 
/* 398 */         embeds(), newValue, this.fileSpoilers, 
/*     */ 
/*     */         
/* 401 */         allowedMentions(), 
/* 402 */         components(), this.event);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final InteractionApplicationCommandCallbackEditMono withFileSpoilers(MessageCreateFields.FileSpoiler... elements) {
/* 412 */     List<MessageCreateFields.FileSpoiler> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/* 413 */     return new InteractionApplicationCommandCallbackEditMono(
/* 414 */         content(), 
/* 415 */         tts(), 
/* 416 */         ephemeral(), 
/* 417 */         embeds(), this.files, newValue, 
/*     */ 
/*     */         
/* 420 */         allowedMentions(), 
/* 421 */         components(), this.event);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final InteractionApplicationCommandCallbackEditMono withFileSpoilers(Iterable<? extends MessageCreateFields.FileSpoiler> elements) {
/* 432 */     if (this.fileSpoilers == elements) return this; 
/* 433 */     List<MessageCreateFields.FileSpoiler> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/* 434 */     return new InteractionApplicationCommandCallbackEditMono(
/* 435 */         content(), 
/* 436 */         tts(), 
/* 437 */         ephemeral(), 
/* 438 */         embeds(), this.files, newValue, 
/*     */ 
/*     */         
/* 441 */         allowedMentions(), 
/* 442 */         components(), this.event);
/*     */   }
/*     */ 
/*     */   
/*     */   public InteractionApplicationCommandCallbackEditMono withAllowedMentions(Possible<AllowedMentions> value) {
/* 447 */     Possible<AllowedMentions> newValue = Objects.<Possible<AllowedMentions>>requireNonNull(value);
/* 448 */     return new InteractionApplicationCommandCallbackEditMono(
/* 449 */         content(), 
/* 450 */         tts(), 
/* 451 */         ephemeral(), 
/* 452 */         embeds(), this.files, this.fileSpoilers, newValue, 
/*     */ 
/*     */ 
/*     */         
/* 456 */         components(), this.event);
/*     */   }
/*     */ 
/*     */   
/*     */   public InteractionApplicationCommandCallbackEditMono withAllowedMentions(AllowedMentions value) {
/* 461 */     Possible<AllowedMentions> newValue = Possible.of(value);
/* 462 */     return new InteractionApplicationCommandCallbackEditMono(
/* 463 */         content(), 
/* 464 */         tts(), 
/* 465 */         ephemeral(), 
/* 466 */         embeds(), this.files, this.fileSpoilers, newValue, 
/*     */ 
/*     */ 
/*     */         
/* 470 */         components(), this.event);
/*     */   }
/*     */ 
/*     */   
/*     */   public InteractionApplicationCommandCallbackEditMono withComponents(Possible<List<LayoutComponent>> possible) {
/* 475 */     Possible<List<LayoutComponent>> newValue = Objects.<Possible<List<LayoutComponent>>>requireNonNull(possible);
/* 476 */     return new InteractionApplicationCommandCallbackEditMono(
/* 477 */         content(), 
/* 478 */         tts(), 
/* 479 */         ephemeral(), 
/* 480 */         embeds(), this.files, this.fileSpoilers, 
/*     */ 
/*     */         
/* 483 */         allowedMentions(), newValue, this.event);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public InteractionApplicationCommandCallbackEditMono withComponents(Iterable<LayoutComponent> elements) {
/* 489 */     Possible<List<LayoutComponent>> newValue = Possible.of(
/* 490 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/* 491 */     return new InteractionApplicationCommandCallbackEditMono(
/* 492 */         content(), 
/* 493 */         tts(), 
/* 494 */         ephemeral(), 
/* 495 */         embeds(), this.files, this.fileSpoilers, 
/*     */ 
/*     */         
/* 498 */         allowedMentions(), newValue, this.event);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SafeVarargs
/*     */   public final InteractionApplicationCommandCallbackEditMono withComponents(LayoutComponent... elements) {
/* 505 */     Possible<List<LayoutComponent>> newValue = Possible.of(Arrays.asList(elements));
/* 506 */     return new InteractionApplicationCommandCallbackEditMono(
/* 507 */         content(), 
/* 508 */         tts(), 
/* 509 */         ephemeral(), 
/* 510 */         embeds(), this.files, this.fileSpoilers, 
/*     */ 
/*     */         
/* 513 */         allowedMentions(), newValue, this.event);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final InteractionApplicationCommandCallbackEditMono withEvent(ComponentInteractionEvent value) {
/* 525 */     if (this.event == value) return this; 
/* 526 */     ComponentInteractionEvent newValue = Objects.<ComponentInteractionEvent>requireNonNull(value, "event");
/* 527 */     return new InteractionApplicationCommandCallbackEditMono(
/* 528 */         content(), 
/* 529 */         tts(), 
/* 530 */         ephemeral(), 
/* 531 */         embeds(), this.files, this.fileSpoilers, 
/*     */ 
/*     */         
/* 534 */         allowedMentions(), 
/* 535 */         components(), newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 545 */     if (this == another) return true; 
/* 546 */     return (another instanceof InteractionApplicationCommandCallbackEditMono && 
/* 547 */       equalTo(0, (InteractionApplicationCommandCallbackEditMono)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, InteractionApplicationCommandCallbackEditMono another) {
/* 551 */     return (content().equals(another.content()) && 
/* 552 */       tts().equals(another.tts()) && 
/* 553 */       ephemeral().equals(another.ephemeral()) && 
/* 554 */       Objects.equals(this.embeds_value, another.embeds_value) && this.files
/* 555 */       .equals(another.files) && this.fileSpoilers
/* 556 */       .equals(another.fileSpoilers) && 
/* 557 */       allowedMentions().equals(another.allowedMentions()) && 
/* 558 */       Objects.equals(this.components_value, another.components_value) && this.event
/* 559 */       .equals(another.event));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 568 */     int h = 5381;
/* 569 */     h += (h << 5) + content().hashCode();
/* 570 */     h += (h << 5) + tts().hashCode();
/* 571 */     h += (h << 5) + ephemeral().hashCode();
/* 572 */     h += (h << 5) + Objects.hashCode(this.embeds_value);
/* 573 */     h += (h << 5) + this.files.hashCode();
/* 574 */     h += (h << 5) + this.fileSpoilers.hashCode();
/* 575 */     h += (h << 5) + allowedMentions().hashCode();
/* 576 */     h += (h << 5) + Objects.hashCode(this.components_value);
/* 577 */     h += (h << 5) + this.event.hashCode();
/* 578 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 587 */     return "InteractionApplicationCommandCallbackEditMono{content=" + 
/* 588 */       content().toString() + ", tts=" + 
/* 589 */       tts().toString() + ", ephemeral=" + 
/* 590 */       ephemeral().toString() + ", embeds=" + 
/* 591 */       Objects.toString(this.embeds_value) + ", files=" + this.files + ", fileSpoilers=" + this.fileSpoilers + ", allowedMentions=" + 
/*     */ 
/*     */       
/* 594 */       allowedMentions().toString() + ", components=" + 
/* 595 */       Objects.toString(this.components_value) + ", event=" + this.event + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static InteractionApplicationCommandCallbackEditMono of(ComponentInteractionEvent event) {
/* 606 */     return new InteractionApplicationCommandCallbackEditMono(event);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static InteractionApplicationCommandCallbackEditMono copyOf(InteractionApplicationCommandCallbackEditMonoGenerator instance) {
/* 617 */     if (instance instanceof InteractionApplicationCommandCallbackEditMono) {
/* 618 */       return (InteractionApplicationCommandCallbackEditMono)instance;
/*     */     }
/* 620 */     return of(instance.event())
/* 621 */       .withContent(instance.content())
/* 622 */       .withTts(instance.tts())
/* 623 */       .withEphemeral(instance.ephemeral())
/* 624 */       .withEmbeds(instance.embeds())
/* 625 */       .withFiles(instance.files())
/* 626 */       .withFileSpoilers(instance.fileSpoilers())
/* 627 */       .withAllowedMentions(instance.allowedMentions())
/* 628 */       .withComponents(instance.components());
/*     */   }
/*     */   
/*     */   public boolean isContentPresent() {
/* 632 */     return !this.content_absent;
/*     */   }
/*     */   
/*     */   public String contentOrElse(String defaultValue) {
/* 636 */     return !this.content_absent ? this.content_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isTtsPresent() {
/* 640 */     return !this.tts_absent;
/*     */   }
/*     */   
/*     */   public Boolean ttsOrElse(Boolean defaultValue) {
/* 644 */     return !this.tts_absent ? this.tts_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isEphemeralPresent() {
/* 648 */     return !this.ephemeral_absent;
/*     */   }
/*     */   
/*     */   public Boolean ephemeralOrElse(Boolean defaultValue) {
/* 652 */     return !this.ephemeral_absent ? this.ephemeral_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isEmbedsPresent() {
/* 656 */     return !this.embeds_absent;
/*     */   }
/*     */   
/*     */   public List<EmbedCreateSpec> embedsOrElse(List<EmbedCreateSpec> defaultValue) {
/* 660 */     return !this.embeds_absent ? this.embeds_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isAllowedMentionsPresent() {
/* 664 */     return !this.allowedMentions_absent;
/*     */   }
/*     */   
/*     */   public AllowedMentions allowedMentionsOrElse(AllowedMentions defaultValue) {
/* 668 */     return !this.allowedMentions_absent ? this.allowedMentions_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isComponentsPresent() {
/* 672 */     return !this.components_absent;
/*     */   }
/*     */   
/*     */   public List<LayoutComponent> componentsOrElse(List<LayoutComponent> defaultValue) {
/* 676 */     return !this.components_absent ? this.components_value : defaultValue;
/*     */   }
/*     */   
/*     */   private static <T> List<T> createSafeList(Iterable<? extends T> iterable, boolean checkNulls, boolean skipNulls) {
/*     */     ArrayList<T> list;
/* 681 */     if (iterable instanceof Collection) {
/* 682 */       int size = ((Collection)iterable).size();
/* 683 */       if (size == 0) return Collections.emptyList(); 
/* 684 */       list = new ArrayList<>();
/*     */     } else {
/* 686 */       list = new ArrayList<>();
/*     */     } 
/* 688 */     for (T element : iterable) {
/* 689 */       if (skipNulls && element == null)
/* 690 */         continue;  if (checkNulls) Objects.requireNonNull(element, "element"); 
/* 691 */       list.add(element);
/*     */     } 
/* 693 */     return list;
/*     */   }
/*     */   
/*     */   private static <T> List<T> createUnmodifiableList(boolean clone, List<T> list) {
/* 697 */     switch (list.size()) { case 0:
/* 698 */         return Collections.emptyList();
/* 699 */       case 1: return Collections.singletonList(list.get(0)); }
/*     */     
/* 701 */     if (clone) {
/* 702 */       return Collections.unmodifiableList(new ArrayList<>(list));
/*     */     }
/* 704 */     if (list instanceof ArrayList) {
/* 705 */       ((ArrayList)list).trimToSize();
/*     */     }
/* 707 */     return Collections.unmodifiableList(list);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\InteractionApplicationCommandCallbackEditMono.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */