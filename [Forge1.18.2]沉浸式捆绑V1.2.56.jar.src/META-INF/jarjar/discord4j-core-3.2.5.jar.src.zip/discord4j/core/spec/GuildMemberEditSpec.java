/*     */ package discord4j.core.spec;
/*     */ 
/*     */ import com.google.errorprone.annotations.CanIgnoreReturnValue;
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.time.Instant;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.stream.StreamSupport;
/*     */ import org.immutables.value.Generated;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "GuildMemberEditSpecGenerator", generator = "Immutables")
/*     */ public final class GuildMemberEditSpec
/*     */   implements GuildMemberEditSpecGenerator
/*     */ {
/*     */   @Nullable
/*     */   private final String reason;
/*     */   private final Snowflake newVoiceChannel_value;
/*     */   private final boolean newVoiceChannel_absent;
/*     */   private final Boolean mute_value;
/*     */   private final boolean mute_absent;
/*     */   private final Boolean deafen_value;
/*     */   private final boolean deafen_absent;
/*     */   private final String nickname_value;
/*     */   private final boolean nickname_absent;
/*     */   private final List<Snowflake> roles_value;
/*     */   private final boolean roles_absent;
/*     */   private final Instant communicationDisabledUntil_value;
/*     */   private final boolean communicationDisabledUntil_absent;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   
/*     */   private GuildMemberEditSpec() {
/*  45 */     this.reason = null;
/*  46 */     Possible<Optional<Snowflake>> newVoiceChannel$impl = Possible.absent();
/*  47 */     Possible<Boolean> mute$impl = Possible.absent();
/*  48 */     Possible<Boolean> deafen$impl = Possible.absent();
/*  49 */     Possible<Optional<String>> nickname$impl = Possible.absent();
/*  50 */     Possible<List<Snowflake>> roles$impl = Possible.absent();
/*  51 */     Possible<Optional<Instant>> communicationDisabledUntil$impl = Possible.absent();
/*  52 */     this.newVoiceChannel_value = Possible.flatOpt(newVoiceChannel$impl).orElse(null);
/*  53 */     this.newVoiceChannel_absent = newVoiceChannel$impl.isAbsent();
/*  54 */     this.mute_value = mute$impl.toOptional().orElse(null);
/*  55 */     this.mute_absent = mute$impl.isAbsent();
/*  56 */     this.deafen_value = deafen$impl.toOptional().orElse(null);
/*  57 */     this.deafen_absent = deafen$impl.isAbsent();
/*  58 */     this.nickname_value = Possible.flatOpt(nickname$impl).orElse(null);
/*  59 */     this.nickname_absent = nickname$impl.isAbsent();
/*  60 */     this.roles_value = roles$impl.toOptional().orElse(null);
/*  61 */     this.roles_absent = roles$impl.isAbsent();
/*  62 */     this.communicationDisabledUntil_value = Possible.flatOpt(communicationDisabledUntil$impl).orElse(null);
/*  63 */     this.communicationDisabledUntil_absent = communicationDisabledUntil$impl.isAbsent();
/*  64 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private GuildMemberEditSpec(@Nullable String reason, Possible<Optional<Snowflake>> newVoiceChannel, Possible<Boolean> mute, Possible<Boolean> deafen, Possible<Optional<String>> nickname, Possible<List<Snowflake>> roles, Possible<Optional<Instant>> communicationDisabledUntil) {
/*  75 */     this.reason = reason;
/*  76 */     Possible<Optional<Snowflake>> newVoiceChannel$impl = newVoiceChannel;
/*  77 */     Possible<Boolean> mute$impl = mute;
/*  78 */     Possible<Boolean> deafen$impl = deafen;
/*  79 */     Possible<Optional<String>> nickname$impl = nickname;
/*  80 */     Possible<List<Snowflake>> roles$impl = roles;
/*  81 */     Possible<Optional<Instant>> communicationDisabledUntil$impl = communicationDisabledUntil;
/*  82 */     this.newVoiceChannel_value = Possible.flatOpt(newVoiceChannel$impl).orElse(null);
/*  83 */     this.newVoiceChannel_absent = newVoiceChannel$impl.isAbsent();
/*  84 */     this.mute_value = mute$impl.toOptional().orElse(null);
/*  85 */     this.mute_absent = mute$impl.isAbsent();
/*  86 */     this.deafen_value = deafen$impl.toOptional().orElse(null);
/*  87 */     this.deafen_absent = deafen$impl.isAbsent();
/*  88 */     this.nickname_value = Possible.flatOpt(nickname$impl).orElse(null);
/*  89 */     this.nickname_absent = nickname$impl.isAbsent();
/*  90 */     this.roles_value = roles$impl.toOptional().orElse(null);
/*  91 */     this.roles_absent = roles$impl.isAbsent();
/*  92 */     this.communicationDisabledUntil_value = Possible.flatOpt(communicationDisabledUntil$impl).orElse(null);
/*  93 */     this.communicationDisabledUntil_absent = communicationDisabledUntil$impl.isAbsent();
/*  94 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 100 */   private volatile transient InitShim initShim = new InitShim();
/*     */   
/*     */   @Generated(from = "GuildMemberEditSpecGenerator", generator = "Immutables")
/*     */   private final class InitShim
/*     */   {
/*     */     private String formatInitCycleMessage() {
/* 106 */       List<String> attributes = new ArrayList<>();
/* 107 */       return "Cannot build GuildMemberEditSpec, attribute initializers form cycle " + attributes;
/*     */     }
/*     */ 
/*     */     
/*     */     private InitShim() {}
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String reason() {
/* 117 */     return this.reason;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Optional<Snowflake>> newVoiceChannel() {
/* 125 */     return this.newVoiceChannel_absent ? Possible.absent() : 
/* 126 */       Possible.of(Optional.ofNullable(this.newVoiceChannel_value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Boolean> mute() {
/* 134 */     return this.mute_absent ? Possible.absent() : Possible.of(this.mute_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Boolean> deafen() {
/* 142 */     return this.deafen_absent ? Possible.absent() : Possible.of(this.deafen_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Optional<String>> nickname() {
/* 150 */     return this.nickname_absent ? Possible.absent() : 
/* 151 */       Possible.of(Optional.ofNullable(this.nickname_value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<List<Snowflake>> roles() {
/* 159 */     return this.roles_absent ? Possible.absent() : 
/* 160 */       Possible.of(this.roles_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Optional<Instant>> communicationDisabledUntil() {
/* 168 */     return this.communicationDisabledUntil_absent ? Possible.absent() : 
/* 169 */       Possible.of(Optional.ofNullable(this.communicationDisabledUntil_value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final GuildMemberEditSpec withReason(@Nullable String value) {
/* 179 */     if (Objects.equals(this.reason, value)) return this; 
/* 180 */     return validate(new GuildMemberEditSpec(value, 
/*     */           
/* 182 */           newVoiceChannel(), 
/* 183 */           mute(), 
/* 184 */           deafen(), 
/* 185 */           nickname(), 
/* 186 */           roles(), 
/* 187 */           communicationDisabledUntil()));
/*     */   }
/*     */   
/*     */   public GuildMemberEditSpec withNewVoiceChannel(Possible<Optional<Snowflake>> value) {
/* 191 */     Possible<Optional<Snowflake>> newValue = Objects.<Possible<Optional<Snowflake>>>requireNonNull(value);
/* 192 */     return validate(new GuildMemberEditSpec(this.reason, newValue, 
/*     */ 
/*     */           
/* 195 */           mute(), 
/* 196 */           deafen(), 
/* 197 */           nickname(), 
/* 198 */           roles(), 
/* 199 */           communicationDisabledUntil()));
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public GuildMemberEditSpec withNewVoiceChannel(@Nullable Snowflake value) {
/* 204 */     Possible<Optional<Snowflake>> newValue = Possible.of(Optional.ofNullable(value));
/* 205 */     return validate(new GuildMemberEditSpec(this.reason, newValue, 
/*     */ 
/*     */           
/* 208 */           mute(), 
/* 209 */           deafen(), 
/* 210 */           nickname(), 
/* 211 */           roles(), 
/* 212 */           communicationDisabledUntil()));
/*     */   }
/*     */   
/*     */   public GuildMemberEditSpec withNewVoiceChannelOrNull(@Nullable Snowflake value) {
/* 216 */     Possible<Optional<Snowflake>> newValue = Possible.of(Optional.ofNullable(value));
/* 217 */     return validate(new GuildMemberEditSpec(this.reason, newValue, 
/*     */ 
/*     */           
/* 220 */           mute(), 
/* 221 */           deafen(), 
/* 222 */           nickname(), 
/* 223 */           roles(), 
/* 224 */           communicationDisabledUntil()));
/*     */   }
/*     */   
/*     */   public GuildMemberEditSpec withMute(Possible<Boolean> value) {
/* 228 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/* 229 */     return validate(new GuildMemberEditSpec(this.reason, 
/*     */           
/* 231 */           newVoiceChannel(), newValue, 
/*     */           
/* 233 */           deafen(), 
/* 234 */           nickname(), 
/* 235 */           roles(), 
/* 236 */           communicationDisabledUntil()));
/*     */   }
/*     */   
/*     */   public GuildMemberEditSpec withMute(Boolean value) {
/* 240 */     Possible<Boolean> newValue = Possible.of(value);
/* 241 */     return validate(new GuildMemberEditSpec(this.reason, 
/*     */           
/* 243 */           newVoiceChannel(), newValue, 
/*     */           
/* 245 */           deafen(), 
/* 246 */           nickname(), 
/* 247 */           roles(), 
/* 248 */           communicationDisabledUntil()));
/*     */   }
/*     */   
/*     */   public GuildMemberEditSpec withDeafen(Possible<Boolean> value) {
/* 252 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/* 253 */     return validate(new GuildMemberEditSpec(this.reason, 
/*     */           
/* 255 */           newVoiceChannel(), 
/* 256 */           mute(), newValue, 
/*     */           
/* 258 */           nickname(), 
/* 259 */           roles(), 
/* 260 */           communicationDisabledUntil()));
/*     */   }
/*     */   
/*     */   public GuildMemberEditSpec withDeafen(Boolean value) {
/* 264 */     Possible<Boolean> newValue = Possible.of(value);
/* 265 */     return validate(new GuildMemberEditSpec(this.reason, 
/*     */           
/* 267 */           newVoiceChannel(), 
/* 268 */           mute(), newValue, 
/*     */           
/* 270 */           nickname(), 
/* 271 */           roles(), 
/* 272 */           communicationDisabledUntil()));
/*     */   }
/*     */   
/*     */   public GuildMemberEditSpec withNickname(Possible<Optional<String>> value) {
/* 276 */     Possible<Optional<String>> newValue = Objects.<Possible<Optional<String>>>requireNonNull(value);
/* 277 */     return validate(new GuildMemberEditSpec(this.reason, 
/*     */           
/* 279 */           newVoiceChannel(), 
/* 280 */           mute(), 
/* 281 */           deafen(), newValue, 
/*     */           
/* 283 */           roles(), 
/* 284 */           communicationDisabledUntil()));
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public GuildMemberEditSpec withNickname(@Nullable String value) {
/* 289 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/* 290 */     return validate(new GuildMemberEditSpec(this.reason, 
/*     */           
/* 292 */           newVoiceChannel(), 
/* 293 */           mute(), 
/* 294 */           deafen(), newValue, 
/*     */           
/* 296 */           roles(), 
/* 297 */           communicationDisabledUntil()));
/*     */   }
/*     */   
/*     */   public GuildMemberEditSpec withNicknameOrNull(@Nullable String value) {
/* 301 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/* 302 */     return validate(new GuildMemberEditSpec(this.reason, 
/*     */           
/* 304 */           newVoiceChannel(), 
/* 305 */           mute(), 
/* 306 */           deafen(), newValue, 
/*     */           
/* 308 */           roles(), 
/* 309 */           communicationDisabledUntil()));
/*     */   }
/*     */   
/*     */   public GuildMemberEditSpec withRoles(Possible<List<Snowflake>> possible) {
/* 313 */     Possible<List<Snowflake>> newValue = Objects.<Possible<List<Snowflake>>>requireNonNull(possible);
/* 314 */     return validate(new GuildMemberEditSpec(this.reason, 
/*     */           
/* 316 */           newVoiceChannel(), 
/* 317 */           mute(), 
/* 318 */           deafen(), 
/* 319 */           nickname(), newValue, 
/*     */           
/* 321 */           communicationDisabledUntil()));
/*     */   }
/*     */   
/*     */   public GuildMemberEditSpec withRoles(Iterable<Snowflake> elements) {
/* 325 */     Possible<List<Snowflake>> newValue = Possible.of(
/* 326 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/* 327 */     return validate(new GuildMemberEditSpec(this.reason, 
/*     */           
/* 329 */           newVoiceChannel(), 
/* 330 */           mute(), 
/* 331 */           deafen(), 
/* 332 */           nickname(), newValue, 
/*     */           
/* 334 */           communicationDisabledUntil()));
/*     */   }
/*     */   
/*     */   @SafeVarargs
/*     */   public final GuildMemberEditSpec withRoles(Snowflake... elements) {
/* 339 */     Possible<List<Snowflake>> newValue = Possible.of(Arrays.asList(elements));
/* 340 */     return validate(new GuildMemberEditSpec(this.reason, 
/*     */           
/* 342 */           newVoiceChannel(), 
/* 343 */           mute(), 
/* 344 */           deafen(), 
/* 345 */           nickname(), newValue, 
/*     */           
/* 347 */           communicationDisabledUntil()));
/*     */   }
/*     */   
/*     */   public GuildMemberEditSpec withCommunicationDisabledUntil(Possible<Optional<Instant>> value) {
/* 351 */     Possible<Optional<Instant>> newValue = Objects.<Possible<Optional<Instant>>>requireNonNull(value);
/* 352 */     return validate(new GuildMemberEditSpec(this.reason, 
/*     */           
/* 354 */           newVoiceChannel(), 
/* 355 */           mute(), 
/* 356 */           deafen(), 
/* 357 */           nickname(), 
/* 358 */           roles(), newValue));
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public GuildMemberEditSpec withCommunicationDisabledUntil(@Nullable Instant value) {
/* 364 */     Possible<Optional<Instant>> newValue = Possible.of(Optional.ofNullable(value));
/* 365 */     return validate(new GuildMemberEditSpec(this.reason, 
/*     */           
/* 367 */           newVoiceChannel(), 
/* 368 */           mute(), 
/* 369 */           deafen(), 
/* 370 */           nickname(), 
/* 371 */           roles(), newValue));
/*     */   }
/*     */ 
/*     */   
/*     */   public GuildMemberEditSpec withCommunicationDisabledUntilOrNull(@Nullable Instant value) {
/* 376 */     Possible<Optional<Instant>> newValue = Possible.of(Optional.ofNullable(value));
/* 377 */     return validate(new GuildMemberEditSpec(this.reason, 
/*     */           
/* 379 */           newVoiceChannel(), 
/* 380 */           mute(), 
/* 381 */           deafen(), 
/* 382 */           nickname(), 
/* 383 */           roles(), newValue));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 393 */     if (this == another) return true; 
/* 394 */     return (another instanceof GuildMemberEditSpec && 
/* 395 */       equalTo(0, (GuildMemberEditSpec)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, GuildMemberEditSpec another) {
/* 399 */     return (Objects.equals(this.reason, another.reason) && 
/* 400 */       newVoiceChannel().equals(another.newVoiceChannel()) && 
/* 401 */       mute().equals(another.mute()) && 
/* 402 */       deafen().equals(another.deafen()) && 
/* 403 */       nickname().equals(another.nickname()) && 
/* 404 */       Objects.equals(this.roles_value, another.roles_value) && 
/* 405 */       communicationDisabledUntil().equals(another.communicationDisabledUntil()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 414 */     int h = 5381;
/* 415 */     h += (h << 5) + Objects.hashCode(this.reason);
/* 416 */     h += (h << 5) + newVoiceChannel().hashCode();
/* 417 */     h += (h << 5) + mute().hashCode();
/* 418 */     h += (h << 5) + deafen().hashCode();
/* 419 */     h += (h << 5) + nickname().hashCode();
/* 420 */     h += (h << 5) + Objects.hashCode(this.roles_value);
/* 421 */     h += (h << 5) + communicationDisabledUntil().hashCode();
/* 422 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 431 */     return "GuildMemberEditSpec{reason=" + this.reason + ", newVoiceChannel=" + 
/*     */       
/* 433 */       newVoiceChannel().toString() + ", mute=" + 
/* 434 */       mute().toString() + ", deafen=" + 
/* 435 */       deafen().toString() + ", nickname=" + 
/* 436 */       nickname().toString() + ", roles=" + 
/* 437 */       Objects.toString(this.roles_value) + ", communicationDisabledUntil=" + 
/* 438 */       communicationDisabledUntil().toString() + "}";
/*     */   }
/*     */ 
/*     */   
/* 442 */   private static final GuildMemberEditSpec INSTANCE = validate(new GuildMemberEditSpec());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static GuildMemberEditSpec create() {
/* 449 */     return INSTANCE;
/*     */   }
/*     */   
/*     */   private static GuildMemberEditSpec validate(GuildMemberEditSpec instance) {
/* 453 */     return (INSTANCE != null && INSTANCE.equalTo(0, instance)) ? INSTANCE : instance;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static GuildMemberEditSpec copyOf(GuildMemberEditSpecGenerator instance) {
/* 464 */     if (instance instanceof GuildMemberEditSpec) {
/* 465 */       return (GuildMemberEditSpec)instance;
/*     */     }
/* 467 */     return builder()
/* 468 */       .from(instance)
/* 469 */       .build();
/*     */   }
/*     */   
/*     */   public boolean isNewVoiceChannelPresent() {
/* 473 */     return !this.newVoiceChannel_absent;
/*     */   }
/*     */   
/*     */   public Snowflake newVoiceChannelOrElse(Snowflake defaultValue) {
/* 477 */     return !this.newVoiceChannel_absent ? this.newVoiceChannel_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isMutePresent() {
/* 481 */     return !this.mute_absent;
/*     */   }
/*     */   
/*     */   public Boolean muteOrElse(Boolean defaultValue) {
/* 485 */     return !this.mute_absent ? this.mute_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isDeafenPresent() {
/* 489 */     return !this.deafen_absent;
/*     */   }
/*     */   
/*     */   public Boolean deafenOrElse(Boolean defaultValue) {
/* 493 */     return !this.deafen_absent ? this.deafen_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isNicknamePresent() {
/* 497 */     return !this.nickname_absent;
/*     */   }
/*     */   
/*     */   public String nicknameOrElse(String defaultValue) {
/* 501 */     return !this.nickname_absent ? this.nickname_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isRolesPresent() {
/* 505 */     return !this.roles_absent;
/*     */   }
/*     */   
/*     */   public List<Snowflake> rolesOrElse(List<Snowflake> defaultValue) {
/* 509 */     return !this.roles_absent ? this.roles_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isCommunicationDisabledUntilPresent() {
/* 513 */     return !this.communicationDisabledUntil_absent;
/*     */   }
/*     */   
/*     */   public Instant communicationDisabledUntilOrElse(Instant defaultValue) {
/* 517 */     return !this.communicationDisabledUntil_absent ? this.communicationDisabledUntil_value : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 536 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "GuildMemberEditSpecGenerator", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/* 548 */     private Possible<Optional<Snowflake>> newVoiceChannel_possible = Possible.absent();
/* 549 */     private Possible<Boolean> mute_possible = Possible.absent();
/* 550 */     private Possible<Boolean> deafen_possible = Possible.absent();
/* 551 */     private Possible<Optional<String>> nickname_possible = Possible.absent();
/* 552 */     private List<Snowflake> roles_list = null;
/* 553 */     private Possible<Optional<Instant>> communicationDisabledUntil_possible = Possible.absent();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private String reason;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(GuildMemberEditSpec instance) {
/* 567 */       return from(instance);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     final Builder from(GuildMemberEditSpecGenerator instance) {
/* 577 */       Objects.requireNonNull(instance, "instance");
/* 578 */       String reasonValue = instance.reason();
/* 579 */       if (reasonValue != null) {
/* 580 */         reason(reasonValue);
/*     */       }
/* 582 */       newVoiceChannel(instance.newVoiceChannel());
/* 583 */       mute(instance.mute());
/* 584 */       deafen(instance.deafen());
/* 585 */       nickname(instance.nickname());
/* 586 */       roles(instance.roles());
/* 587 */       communicationDisabledUntil(instance.communicationDisabledUntil());
/* 588 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder reason(@Nullable String reason) {
/* 598 */       this.reason = reason;
/* 599 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder newVoiceChannel(Possible<Optional<Snowflake>> value) {
/* 604 */       this.newVoiceChannel_possible = value;
/* 605 */       return this;
/*     */     }
/*     */     
/*     */     @Deprecated
/*     */     @CanIgnoreReturnValue
/*     */     public Builder newVoiceChannel(@Nullable Snowflake value) {
/* 611 */       this.newVoiceChannel_possible = Possible.of(Optional.ofNullable(value));
/* 612 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder newVoiceChannelOrNull(@Nullable Snowflake value) {
/* 617 */       this.newVoiceChannel_possible = Possible.of(Optional.ofNullable(value));
/* 618 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder mute(Possible<Boolean> value) {
/* 623 */       this.mute_possible = value;
/* 624 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder mute(Boolean value) {
/* 629 */       this.mute_possible = Possible.of(value);
/* 630 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder deafen(Possible<Boolean> value) {
/* 635 */       this.deafen_possible = value;
/* 636 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder deafen(Boolean value) {
/* 641 */       this.deafen_possible = Possible.of(value);
/* 642 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder nickname(Possible<Optional<String>> value) {
/* 647 */       this.nickname_possible = value;
/* 648 */       return this;
/*     */     }
/*     */     
/*     */     @Deprecated
/*     */     @CanIgnoreReturnValue
/*     */     public Builder nickname(@Nullable String value) {
/* 654 */       this.nickname_possible = Possible.of(Optional.ofNullable(value));
/* 655 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder nicknameOrNull(@Nullable String value) {
/* 660 */       this.nickname_possible = Possible.of(Optional.ofNullable(value));
/* 661 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder addRole(Snowflake element) {
/* 666 */       roles_getOrCreate().add(element);
/* 667 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder addAllRoles(List<Snowflake> elements) {
/* 672 */       roles_getOrCreate().addAll(elements);
/* 673 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder roles(Possible<List<Snowflake>> elements) {
/* 678 */       this.roles_list = null;
/* 679 */       elements.toOptional().ifPresent(e -> roles_getOrCreate().addAll(e));
/* 680 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder roles(List<Snowflake> elements) {
/* 685 */       this.roles_list = new ArrayList<>(elements);
/* 686 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder roles(Iterable<Snowflake> elements) {
/* 691 */       this.roles_list = (List<Snowflake>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/* 692 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder communicationDisabledUntil(Possible<Optional<Instant>> value) {
/* 697 */       this.communicationDisabledUntil_possible = value;
/* 698 */       return this;
/*     */     }
/*     */     
/*     */     @Deprecated
/*     */     @CanIgnoreReturnValue
/*     */     public Builder communicationDisabledUntil(@Nullable Instant value) {
/* 704 */       this.communicationDisabledUntil_possible = Possible.of(Optional.ofNullable(value));
/* 705 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder communicationDisabledUntilOrNull(@Nullable Instant value) {
/* 710 */       this.communicationDisabledUntil_possible = Possible.of(Optional.ofNullable(value));
/* 711 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public GuildMemberEditSpec build() {
/* 720 */       return GuildMemberEditSpec.validate(new GuildMemberEditSpec(this.reason, 
/*     */             
/* 722 */             newVoiceChannel_build(), 
/* 723 */             mute_build(), 
/* 724 */             deafen_build(), 
/* 725 */             nickname_build(), 
/* 726 */             roles_build(), 
/* 727 */             communicationDisabledUntil_build()));
/*     */     }
/*     */     
/*     */     private Possible<Optional<Snowflake>> newVoiceChannel_build() {
/* 731 */       return this.newVoiceChannel_possible;
/*     */     }
/*     */     
/*     */     private Possible<Boolean> mute_build() {
/* 735 */       return this.mute_possible;
/*     */     }
/*     */     
/*     */     private Possible<Boolean> deafen_build() {
/* 739 */       return this.deafen_possible;
/*     */     }
/*     */     
/*     */     private Possible<Optional<String>> nickname_build() {
/* 743 */       return this.nickname_possible;
/*     */     }
/*     */     
/*     */     private Possible<List<Snowflake>> roles_build() {
/* 747 */       return (this.roles_list == null) ? Possible.absent() : 
/* 748 */         Possible.of(this.roles_list);
/*     */     }
/*     */     
/*     */     private List<Snowflake> roles_getOrCreate() {
/* 752 */       if (this.roles_list == null) {
/* 753 */         this.roles_list = new ArrayList<>();
/*     */       }
/* 755 */       return this.roles_list;
/*     */     }
/*     */     
/*     */     private Possible<Optional<Instant>> communicationDisabledUntil_build() {
/* 759 */       return this.communicationDisabledUntil_possible;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\GuildMemberEditSpec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */