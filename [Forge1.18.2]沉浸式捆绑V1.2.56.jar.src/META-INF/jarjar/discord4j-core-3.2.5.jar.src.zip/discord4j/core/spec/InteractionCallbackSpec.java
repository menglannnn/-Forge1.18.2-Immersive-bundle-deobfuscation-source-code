/*     */ package discord4j.core.spec;
/*     */ 
/*     */ import com.google.errorprone.annotations.CanIgnoreReturnValue;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "InteractionCallbackSpecGenerator", generator = "Immutables")
/*     */ public final class InteractionCallbackSpec
/*     */   implements InteractionCallbackSpecGenerator
/*     */ {
/*     */   private final Boolean ephemeral_value;
/*     */   private final boolean ephemeral_absent;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   
/*     */   private InteractionCallbackSpec() {
/*  27 */     Possible<Boolean> ephemeral$impl = Possible.absent();
/*  28 */     this.ephemeral_value = ephemeral$impl.toOptional().orElse(null);
/*  29 */     this.ephemeral_absent = ephemeral$impl.isAbsent();
/*  30 */     this.initShim = null;
/*     */   }
/*     */   
/*     */   private InteractionCallbackSpec(Possible<Boolean> ephemeral) {
/*  34 */     Possible<Boolean> ephemeral$impl = ephemeral;
/*  35 */     this.ephemeral_value = ephemeral$impl.toOptional().orElse(null);
/*  36 */     this.ephemeral_absent = ephemeral$impl.isAbsent();
/*  37 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  43 */   private volatile transient InitShim initShim = new InitShim();
/*     */   
/*     */   @Generated(from = "InteractionCallbackSpecGenerator", generator = "Immutables")
/*     */   private final class InitShim
/*     */   {
/*     */     private String formatInitCycleMessage() {
/*  49 */       List<String> attributes = new ArrayList<>();
/*  50 */       return "Cannot build InteractionCallbackSpec, attribute initializers form cycle " + attributes;
/*     */     }
/*     */ 
/*     */     
/*     */     private InitShim() {}
/*     */   }
/*     */ 
/*     */   
/*     */   public Possible<Boolean> ephemeral() {
/*  59 */     return this.ephemeral_absent ? Possible.absent() : Possible.of(this.ephemeral_value);
/*     */   }
/*     */   
/*     */   public InteractionCallbackSpec withEphemeral(Possible<Boolean> value) {
/*  63 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/*  64 */     return validate(new InteractionCallbackSpec(newValue));
/*     */   }
/*     */   
/*     */   public InteractionCallbackSpec withEphemeral(Boolean value) {
/*  68 */     Possible<Boolean> newValue = Possible.of(value);
/*  69 */     return validate(new InteractionCallbackSpec(newValue));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/*  78 */     if (this == another) return true; 
/*  79 */     return (another instanceof InteractionCallbackSpec && 
/*  80 */       equalTo(0, (InteractionCallbackSpec)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, InteractionCallbackSpec another) {
/*  84 */     return ephemeral().equals(another.ephemeral());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  93 */     int h = 5381;
/*  94 */     h += (h << 5) + ephemeral().hashCode();
/*  95 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 104 */     return "InteractionCallbackSpec{ephemeral=" + 
/* 105 */       ephemeral().toString() + "}";
/*     */   }
/*     */ 
/*     */   
/* 109 */   private static final InteractionCallbackSpec INSTANCE = validate(new InteractionCallbackSpec());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static InteractionCallbackSpec create() {
/* 116 */     return INSTANCE;
/*     */   }
/*     */   
/*     */   private static InteractionCallbackSpec validate(InteractionCallbackSpec instance) {
/* 120 */     return (INSTANCE != null && INSTANCE.equalTo(0, instance)) ? INSTANCE : instance;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static InteractionCallbackSpec copyOf(InteractionCallbackSpecGenerator instance) {
/* 131 */     if (instance instanceof InteractionCallbackSpec) {
/* 132 */       return (InteractionCallbackSpec)instance;
/*     */     }
/* 134 */     return builder()
/* 135 */       .from(instance)
/* 136 */       .build();
/*     */   }
/*     */   
/*     */   public boolean isEphemeralPresent() {
/* 140 */     return !this.ephemeral_absent;
/*     */   }
/*     */   
/*     */   public Boolean ephemeralOrElse(Boolean defaultValue) {
/* 144 */     return !this.ephemeral_absent ? this.ephemeral_value : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 157 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "InteractionCallbackSpecGenerator", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/* 169 */     private Possible<Boolean> ephemeral_possible = Possible.absent();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(InteractionCallbackSpec instance) {
/* 182 */       return from(instance);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     final Builder from(InteractionCallbackSpecGenerator instance) {
/* 192 */       Objects.requireNonNull(instance, "instance");
/* 193 */       ephemeral(instance.ephemeral());
/* 194 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder ephemeral(Possible<Boolean> value) {
/* 199 */       this.ephemeral_possible = value;
/* 200 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder ephemeral(Boolean value) {
/* 205 */       this.ephemeral_possible = Possible.of(value);
/* 206 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public InteractionCallbackSpec build() {
/* 215 */       return InteractionCallbackSpec.validate(new InteractionCallbackSpec(ephemeral_build()));
/*     */     }
/*     */     
/*     */     private Possible<Boolean> ephemeral_build() {
/* 219 */       return this.ephemeral_possible;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\InteractionCallbackSpec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */