/*     */ package discord4j.core.spec;
/*     */ 
/*     */ import com.google.errorprone.annotations.CanIgnoreReturnValue;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import discord4j.rest.util.Image;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import org.immutables.value.Generated;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "WebhookCreateSpecGenerator", generator = "Immutables")
/*     */ public final class WebhookCreateSpec
/*     */   implements WebhookCreateSpecGenerator
/*     */ {
/*     */   @Nullable
/*     */   private final String reason;
/*     */   private final String name;
/*     */   private final Image avatar_value;
/*     */   private final boolean avatar_absent;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   private volatile transient InitShim initShim;
/*     */   
/*     */   private WebhookCreateSpec(String name) {
/*  55 */     this.initShim = new InitShim(); this.name = Objects.<String>requireNonNull(name, "name"); this.reason = null; Possible<Optional<Image>> avatar$impl = Possible.absent(); this.avatar_value = Possible.flatOpt(avatar$impl).orElse(null); this.avatar_absent = avatar$impl.isAbsent(); this.initShim = null; } private WebhookCreateSpec(@Nullable String reason, String name, Possible<Optional<Image>> avatar) { this.initShim = new InitShim();
/*     */     this.reason = reason;
/*     */     this.name = name;
/*     */     Possible<Optional<Image>> avatar$impl = avatar;
/*     */     this.avatar_value = Possible.flatOpt(avatar$impl).orElse(null);
/*     */     this.avatar_absent = avatar$impl.isAbsent();
/*  61 */     this.initShim = null; } @Generated(from = "WebhookCreateSpecGenerator", generator = "Immutables") private final class InitShim { private InitShim() {} private String formatInitCycleMessage() { List<String> attributes = new ArrayList<>();
/*  62 */       return "Cannot build WebhookCreateSpec, attribute initializers form cycle " + attributes; }
/*     */      }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String reason() {
/*  72 */     return this.reason;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String name() {
/*  80 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Optional<Image>> avatar() {
/*  88 */     return this.avatar_absent ? Possible.absent() : 
/*  89 */       Possible.of(Optional.ofNullable(this.avatar_value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final WebhookCreateSpec withReason(@Nullable String value) {
/*  99 */     if (Objects.equals(this.reason, value)) return this; 
/* 100 */     return new WebhookCreateSpec(value, this.name, avatar());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final WebhookCreateSpec withName(String value) {
/* 110 */     String newValue = Objects.<String>requireNonNull(value, "name");
/* 111 */     if (this.name.equals(newValue)) return this; 
/* 112 */     return new WebhookCreateSpec(this.reason, newValue, avatar());
/*     */   }
/*     */   
/*     */   public WebhookCreateSpec withAvatar(Possible<Optional<Image>> value) {
/* 116 */     Possible<Optional<Image>> newValue = Objects.<Possible<Optional<Image>>>requireNonNull(value);
/* 117 */     return new WebhookCreateSpec(this.reason, this.name, newValue);
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public WebhookCreateSpec withAvatar(@Nullable Image value) {
/* 122 */     Possible<Optional<Image>> newValue = Possible.of(Optional.ofNullable(value));
/* 123 */     return new WebhookCreateSpec(this.reason, this.name, newValue);
/*     */   }
/*     */   
/*     */   public WebhookCreateSpec withAvatarOrNull(@Nullable Image value) {
/* 127 */     Possible<Optional<Image>> newValue = Possible.of(Optional.ofNullable(value));
/* 128 */     return new WebhookCreateSpec(this.reason, this.name, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 137 */     if (this == another) return true; 
/* 138 */     return (another instanceof WebhookCreateSpec && 
/* 139 */       equalTo(0, (WebhookCreateSpec)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, WebhookCreateSpec another) {
/* 143 */     return (Objects.equals(this.reason, another.reason) && this.name
/* 144 */       .equals(another.name) && 
/* 145 */       avatar().equals(another.avatar()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 154 */     int h = 5381;
/* 155 */     h += (h << 5) + Objects.hashCode(this.reason);
/* 156 */     h += (h << 5) + this.name.hashCode();
/* 157 */     h += (h << 5) + avatar().hashCode();
/* 158 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 167 */     return "WebhookCreateSpec{reason=" + this.reason + ", name=" + this.name + ", avatar=" + 
/*     */ 
/*     */       
/* 170 */       avatar().toString() + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static WebhookCreateSpec of(String name) {
/* 180 */     return new WebhookCreateSpec(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static WebhookCreateSpec copyOf(WebhookCreateSpecGenerator instance) {
/* 191 */     if (instance instanceof WebhookCreateSpec) {
/* 192 */       return (WebhookCreateSpec)instance;
/*     */     }
/* 194 */     return builder()
/* 195 */       .from(instance)
/* 196 */       .build();
/*     */   }
/*     */   
/*     */   public boolean isAvatarPresent() {
/* 200 */     return !this.avatar_absent;
/*     */   }
/*     */   
/*     */   public Image avatarOrElse(Image defaultValue) {
/* 204 */     return !this.avatar_absent ? this.avatar_value : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 219 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "WebhookCreateSpecGenerator", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_NAME = 1L;
/*     */ 
/*     */ 
/*     */     
/* 232 */     private long initBits = 1L;
/*     */     
/* 234 */     private Possible<Optional<Image>> avatar_possible = Possible.absent();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private String reason;
/*     */ 
/*     */ 
/*     */     
/*     */     private String name;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(WebhookCreateSpec instance) {
/* 249 */       return from(instance);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     final Builder from(WebhookCreateSpecGenerator instance) {
/* 259 */       Objects.requireNonNull(instance, "instance");
/* 260 */       String reasonValue = instance.reason();
/* 261 */       if (reasonValue != null) {
/* 262 */         reason(reasonValue);
/*     */       }
/* 264 */       name(instance.name());
/* 265 */       avatar(instance.avatar());
/* 266 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder reason(@Nullable String reason) {
/* 276 */       this.reason = reason;
/* 277 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder name(String name) {
/* 287 */       this.name = Objects.<String>requireNonNull(name, "name");
/* 288 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 289 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder avatar(Possible<Optional<Image>> value) {
/* 294 */       this.avatar_possible = value;
/* 295 */       return this;
/*     */     }
/*     */     
/*     */     @Deprecated
/*     */     @CanIgnoreReturnValue
/*     */     public Builder avatar(@Nullable Image value) {
/* 301 */       this.avatar_possible = Possible.of(Optional.ofNullable(value));
/* 302 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder avatarOrNull(@Nullable Image value) {
/* 307 */       this.avatar_possible = Possible.of(Optional.ofNullable(value));
/* 308 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public WebhookCreateSpec build() {
/* 317 */       if (this.initBits != 0L) {
/* 318 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 320 */       return new WebhookCreateSpec(this.reason, this.name, avatar_build());
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 324 */       List<String> attributes = new ArrayList<>();
/* 325 */       if ((this.initBits & 0x1L) != 0L) attributes.add("name"); 
/* 326 */       return "Cannot build WebhookCreateSpec, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Possible<Optional<Image>> avatar_build() {
/* 330 */       return this.avatar_possible;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\WebhookCreateSpec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */