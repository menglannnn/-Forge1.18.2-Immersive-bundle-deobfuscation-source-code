/*    */ package discord4j.core.spec;
/*    */ 
/*    */ import discord4j.core.object.component.LayoutComponent;
/*    */ import discord4j.core.object.component.MessageComponent;
/*    */ import discord4j.core.object.entity.Attachment;
/*    */ import discord4j.core.object.entity.Message;
/*    */ import discord4j.discordjson.json.ImmutableMessageEditRequest;
/*    */ import discord4j.discordjson.json.MessageEditRequest;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import discord4j.rest.util.AllowedMentions;
/*    */ import discord4j.rest.util.MultipartRequest;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import java.util.Optional;
/*    */ import java.util.stream.Collectors;
/*    */ import java.util.stream.Stream;
/*    */ import org.immutables.value.Value.Default;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Immutable(singleton = true)
/*    */ interface MessageEditSpecGenerator
/*    */   extends Spec<MultipartRequest<MessageEditRequest>>
/*    */ {
/*    */   @Default
/*    */   default List<MessageCreateFields.File> files() {
/* 48 */     return Collections.emptyList();
/*    */   }
/*    */   
/*    */   @Default
/*    */   default List<MessageCreateFields.FileSpoiler> fileSpoilers() {
/* 53 */     return Collections.emptyList();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   default MultipartRequest<MessageEditRequest> asRequest() {
/* 82 */     ImmutableMessageEditRequest immutableMessageEditRequest = MessageEditRequest.builder().content(content()).embeds(InternalSpecUtils.mapPossibleOptional(embeds(), embeds -> (List)embeds.stream().map(EmbedCreateSpecGenerator::asRequest).collect(Collectors.toList()))).allowedMentions(InternalSpecUtils.mapPossibleOptional(allowedMentions(), AllowedMentions::toData)).flags(InternalSpecUtils.mapPossibleOptional(flags(), f -> Integer.valueOf(f.stream().mapToInt(Message.Flag::getFlag).reduce(0, ())))).components(InternalSpecUtils.mapPossibleOptional(components(), components -> (List)components.stream().map(MessageComponent::getData).collect(Collectors.toList()))).attachments(InternalSpecUtils.mapPossibleOptional(attachments(), attachments -> (List)attachments.stream().map(Attachment::getData).collect(Collectors.toList()))).build();
/* 83 */     return MultipartRequest.ofRequestAndFiles(immutableMessageEditRequest, (List)Stream.concat(files().stream(), fileSpoilers().stream())
/* 84 */         .map(MessageCreateFields.File::asRequest)
/* 85 */         .collect(Collectors.toList()));
/*    */   }
/*    */   
/*    */   Possible<Optional<String>> content();
/*    */   
/*    */   Possible<Optional<List<EmbedCreateSpec>>> embeds();
/*    */   
/*    */   Possible<Optional<AllowedMentions>> allowedMentions();
/*    */   
/*    */   Possible<Optional<List<Message.Flag>>> flags();
/*    */   
/*    */   Possible<Optional<List<LayoutComponent>>> components();
/*    */   
/*    */   Possible<Optional<List<Attachment>>> attachments();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\MessageEditSpecGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */