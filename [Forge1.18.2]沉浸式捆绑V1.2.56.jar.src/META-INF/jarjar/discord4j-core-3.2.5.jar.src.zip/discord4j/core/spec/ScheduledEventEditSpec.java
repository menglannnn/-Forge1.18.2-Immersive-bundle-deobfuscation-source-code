/*     */ package discord4j.core.spec;
/*     */ 
/*     */ import com.google.errorprone.annotations.CanIgnoreReturnValue;
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.object.entity.ScheduledEvent;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.time.Instant;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import org.immutables.value.Generated;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "ScheduledEventEditSpecGenerator", generator = "Immutables")
/*     */ public final class ScheduledEventEditSpec
/*     */   implements ScheduledEventEditSpecGenerator
/*     */ {
/*     */   @Nullable
/*     */   private final String reason;
/*     */   private final Snowflake channelId_value;
/*     */   private final boolean channelId_absent;
/*     */   private final ScheduledEventEntityMetadataSpec entityMetadata_value;
/*     */   private final boolean entityMetadata_absent;
/*     */   private final String name_value;
/*     */   private final boolean name_absent;
/*     */   private final ScheduledEvent.PrivacyLevel privacyLevel_value;
/*     */   private final boolean privacyLevel_absent;
/*     */   private final Instant scheduledStartTime_value;
/*     */   private final boolean scheduledStartTime_absent;
/*     */   private final Instant scheduledEndTime_value;
/*     */   private final boolean scheduledEndTime_absent;
/*     */   private final String description_value;
/*     */   private final boolean description_absent;
/*     */   private final ScheduledEvent.EntityType entityType_value;
/*     */   private final boolean entityType_absent;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   private volatile transient InitShim initShim;
/*     */   
/*     */   private ScheduledEventEditSpec(@Nullable String reason, Possible<Optional<Snowflake>> channelId, Possible<ScheduledEventEntityMetadataSpec> entityMetadata, Possible<String> name, Possible<ScheduledEvent.PrivacyLevel> privacyLevel, Possible<Instant> scheduledStartTime, Possible<Instant> scheduledEndTime, Possible<String> description, Possible<ScheduledEvent.EntityType> entityType) {
/*  85 */     this.initShim = new InitShim(); this.reason = reason; Possible<Optional<Snowflake>> channelId$impl = channelId; Possible<ScheduledEventEntityMetadataSpec> entityMetadata$impl = entityMetadata; Possible<String> name$impl = name; Possible<ScheduledEvent.PrivacyLevel> privacyLevel$impl = privacyLevel; Possible<Instant> scheduledStartTime$impl = scheduledStartTime; Possible<Instant> scheduledEndTime$impl = scheduledEndTime; Possible<String> description$impl = description; Possible<ScheduledEvent.EntityType> entityType$impl = entityType; this.channelId_value = Possible.flatOpt(channelId$impl).orElse(null); this.channelId_absent = channelId$impl.isAbsent(); this.entityMetadata_value = entityMetadata$impl.toOptional().orElse(null); this.entityMetadata_absent = entityMetadata$impl.isAbsent(); this.name_value = name$impl.toOptional().orElse(null); this.name_absent = name$impl.isAbsent(); this.privacyLevel_value = privacyLevel$impl.toOptional().orElse(null); this.privacyLevel_absent = privacyLevel$impl.isAbsent(); this.scheduledStartTime_value = scheduledStartTime$impl.toOptional().orElse(null); this.scheduledStartTime_absent = scheduledStartTime$impl.isAbsent(); this.scheduledEndTime_value = scheduledEndTime$impl.toOptional().orElse(null);
/*     */     this.scheduledEndTime_absent = scheduledEndTime$impl.isAbsent();
/*     */     this.description_value = description$impl.toOptional().orElse(null);
/*     */     this.description_absent = description$impl.isAbsent();
/*     */     this.entityType_value = entityType$impl.toOptional().orElse(null);
/*     */     this.entityType_absent = entityType$impl.isAbsent();
/*  91 */     this.initShim = null; } @Generated(from = "ScheduledEventEditSpecGenerator", generator = "Immutables") private final class InitShim { private String formatInitCycleMessage() { List<String> attributes = new ArrayList<>();
/*  92 */       return "Cannot build ScheduledEventEditSpec, attribute initializers form cycle " + attributes; }
/*     */ 
/*     */ 
/*     */     
/*     */     private InitShim() {} }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String reason() {
/* 102 */     return this.reason;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Optional<Snowflake>> channelId() {
/* 110 */     return this.channelId_absent ? Possible.absent() : 
/* 111 */       Possible.of(Optional.ofNullable(this.channelId_value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<ScheduledEventEntityMetadataSpec> entityMetadata() {
/* 119 */     return this.entityMetadata_absent ? Possible.absent() : Possible.of(this.entityMetadata_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<String> name() {
/* 127 */     return this.name_absent ? Possible.absent() : Possible.of(this.name_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<ScheduledEvent.PrivacyLevel> privacyLevel() {
/* 135 */     return this.privacyLevel_absent ? Possible.absent() : Possible.of(this.privacyLevel_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Instant> scheduledStartTime() {
/* 143 */     return this.scheduledStartTime_absent ? Possible.absent() : Possible.of(this.scheduledStartTime_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Instant> scheduledEndTime() {
/* 151 */     return this.scheduledEndTime_absent ? Possible.absent() : Possible.of(this.scheduledEndTime_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<String> description() {
/* 159 */     return this.description_absent ? Possible.absent() : Possible.of(this.description_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<ScheduledEvent.EntityType> entityType() {
/* 167 */     return this.entityType_absent ? Possible.absent() : Possible.of(this.entityType_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ScheduledEventEditSpec withReason(@Nullable String value) {
/* 177 */     if (Objects.equals(this.reason, value)) return this; 
/* 178 */     return new ScheduledEventEditSpec(value, 
/*     */         
/* 180 */         channelId(), 
/* 181 */         entityMetadata(), 
/* 182 */         name(), 
/* 183 */         privacyLevel(), 
/* 184 */         scheduledStartTime(), 
/* 185 */         scheduledEndTime(), 
/* 186 */         description(), 
/* 187 */         entityType());
/*     */   }
/*     */   
/*     */   public ScheduledEventEditSpec withChannelId(Possible<Optional<Snowflake>> value) {
/* 191 */     Possible<Optional<Snowflake>> newValue = Objects.<Possible<Optional<Snowflake>>>requireNonNull(value);
/* 192 */     return new ScheduledEventEditSpec(this.reason, newValue, 
/*     */ 
/*     */         
/* 195 */         entityMetadata(), 
/* 196 */         name(), 
/* 197 */         privacyLevel(), 
/* 198 */         scheduledStartTime(), 
/* 199 */         scheduledEndTime(), 
/* 200 */         description(), 
/* 201 */         entityType());
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public ScheduledEventEditSpec withChannelId(@Nullable Snowflake value) {
/* 206 */     Possible<Optional<Snowflake>> newValue = Possible.of(Optional.ofNullable(value));
/* 207 */     return new ScheduledEventEditSpec(this.reason, newValue, 
/*     */ 
/*     */         
/* 210 */         entityMetadata(), 
/* 211 */         name(), 
/* 212 */         privacyLevel(), 
/* 213 */         scheduledStartTime(), 
/* 214 */         scheduledEndTime(), 
/* 215 */         description(), 
/* 216 */         entityType());
/*     */   }
/*     */   
/*     */   public ScheduledEventEditSpec withChannelIdOrNull(@Nullable Snowflake value) {
/* 220 */     Possible<Optional<Snowflake>> newValue = Possible.of(Optional.ofNullable(value));
/* 221 */     return new ScheduledEventEditSpec(this.reason, newValue, 
/*     */ 
/*     */         
/* 224 */         entityMetadata(), 
/* 225 */         name(), 
/* 226 */         privacyLevel(), 
/* 227 */         scheduledStartTime(), 
/* 228 */         scheduledEndTime(), 
/* 229 */         description(), 
/* 230 */         entityType());
/*     */   }
/*     */   
/*     */   public ScheduledEventEditSpec withEntityMetadata(Possible<ScheduledEventEntityMetadataSpec> value) {
/* 234 */     Possible<ScheduledEventEntityMetadataSpec> newValue = Objects.<Possible<ScheduledEventEntityMetadataSpec>>requireNonNull(value);
/* 235 */     return new ScheduledEventEditSpec(this.reason, 
/*     */         
/* 237 */         channelId(), newValue, 
/*     */         
/* 239 */         name(), 
/* 240 */         privacyLevel(), 
/* 241 */         scheduledStartTime(), 
/* 242 */         scheduledEndTime(), 
/* 243 */         description(), 
/* 244 */         entityType());
/*     */   }
/*     */   
/*     */   public ScheduledEventEditSpec withEntityMetadata(ScheduledEventEntityMetadataSpec value) {
/* 248 */     Possible<ScheduledEventEntityMetadataSpec> newValue = Possible.of(value);
/* 249 */     return new ScheduledEventEditSpec(this.reason, 
/*     */         
/* 251 */         channelId(), newValue, 
/*     */         
/* 253 */         name(), 
/* 254 */         privacyLevel(), 
/* 255 */         scheduledStartTime(), 
/* 256 */         scheduledEndTime(), 
/* 257 */         description(), 
/* 258 */         entityType());
/*     */   }
/*     */   
/*     */   public ScheduledEventEditSpec withName(Possible<String> value) {
/* 262 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/* 263 */     return new ScheduledEventEditSpec(this.reason, 
/*     */         
/* 265 */         channelId(), 
/* 266 */         entityMetadata(), newValue, 
/*     */         
/* 268 */         privacyLevel(), 
/* 269 */         scheduledStartTime(), 
/* 270 */         scheduledEndTime(), 
/* 271 */         description(), 
/* 272 */         entityType());
/*     */   }
/*     */   
/*     */   public ScheduledEventEditSpec withName(String value) {
/* 276 */     Possible<String> newValue = Possible.of(value);
/* 277 */     return new ScheduledEventEditSpec(this.reason, 
/*     */         
/* 279 */         channelId(), 
/* 280 */         entityMetadata(), newValue, 
/*     */         
/* 282 */         privacyLevel(), 
/* 283 */         scheduledStartTime(), 
/* 284 */         scheduledEndTime(), 
/* 285 */         description(), 
/* 286 */         entityType());
/*     */   }
/*     */   
/*     */   public ScheduledEventEditSpec withPrivacyLevel(Possible<ScheduledEvent.PrivacyLevel> value) {
/* 290 */     Possible<ScheduledEvent.PrivacyLevel> newValue = Objects.<Possible<ScheduledEvent.PrivacyLevel>>requireNonNull(value);
/* 291 */     return new ScheduledEventEditSpec(this.reason, 
/*     */         
/* 293 */         channelId(), 
/* 294 */         entityMetadata(), 
/* 295 */         name(), newValue, 
/*     */         
/* 297 */         scheduledStartTime(), 
/* 298 */         scheduledEndTime(), 
/* 299 */         description(), 
/* 300 */         entityType());
/*     */   }
/*     */   
/*     */   public ScheduledEventEditSpec withPrivacyLevel(ScheduledEvent.PrivacyLevel value) {
/* 304 */     Possible<ScheduledEvent.PrivacyLevel> newValue = Possible.of(value);
/* 305 */     return new ScheduledEventEditSpec(this.reason, 
/*     */         
/* 307 */         channelId(), 
/* 308 */         entityMetadata(), 
/* 309 */         name(), newValue, 
/*     */         
/* 311 */         scheduledStartTime(), 
/* 312 */         scheduledEndTime(), 
/* 313 */         description(), 
/* 314 */         entityType());
/*     */   }
/*     */   
/*     */   public ScheduledEventEditSpec withScheduledStartTime(Possible<Instant> value) {
/* 318 */     Possible<Instant> newValue = Objects.<Possible<Instant>>requireNonNull(value);
/* 319 */     return new ScheduledEventEditSpec(this.reason, 
/*     */         
/* 321 */         channelId(), 
/* 322 */         entityMetadata(), 
/* 323 */         name(), 
/* 324 */         privacyLevel(), newValue, 
/*     */         
/* 326 */         scheduledEndTime(), 
/* 327 */         description(), 
/* 328 */         entityType());
/*     */   }
/*     */   
/*     */   public ScheduledEventEditSpec withScheduledStartTime(Instant value) {
/* 332 */     Possible<Instant> newValue = Possible.of(value);
/* 333 */     return new ScheduledEventEditSpec(this.reason, 
/*     */         
/* 335 */         channelId(), 
/* 336 */         entityMetadata(), 
/* 337 */         name(), 
/* 338 */         privacyLevel(), newValue, 
/*     */         
/* 340 */         scheduledEndTime(), 
/* 341 */         description(), 
/* 342 */         entityType());
/*     */   }
/*     */   
/*     */   public ScheduledEventEditSpec withScheduledEndTime(Possible<Instant> value) {
/* 346 */     Possible<Instant> newValue = Objects.<Possible<Instant>>requireNonNull(value);
/* 347 */     return new ScheduledEventEditSpec(this.reason, 
/*     */         
/* 349 */         channelId(), 
/* 350 */         entityMetadata(), 
/* 351 */         name(), 
/* 352 */         privacyLevel(), 
/* 353 */         scheduledStartTime(), newValue, 
/*     */         
/* 355 */         description(), 
/* 356 */         entityType());
/*     */   }
/*     */   
/*     */   public ScheduledEventEditSpec withScheduledEndTime(Instant value) {
/* 360 */     Possible<Instant> newValue = Possible.of(value);
/* 361 */     return new ScheduledEventEditSpec(this.reason, 
/*     */         
/* 363 */         channelId(), 
/* 364 */         entityMetadata(), 
/* 365 */         name(), 
/* 366 */         privacyLevel(), 
/* 367 */         scheduledStartTime(), newValue, 
/*     */         
/* 369 */         description(), 
/* 370 */         entityType());
/*     */   }
/*     */   
/*     */   public ScheduledEventEditSpec withDescription(Possible<String> value) {
/* 374 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/* 375 */     return new ScheduledEventEditSpec(this.reason, 
/*     */         
/* 377 */         channelId(), 
/* 378 */         entityMetadata(), 
/* 379 */         name(), 
/* 380 */         privacyLevel(), 
/* 381 */         scheduledStartTime(), 
/* 382 */         scheduledEndTime(), newValue, 
/*     */         
/* 384 */         entityType());
/*     */   }
/*     */   
/*     */   public ScheduledEventEditSpec withDescription(String value) {
/* 388 */     Possible<String> newValue = Possible.of(value);
/* 389 */     return new ScheduledEventEditSpec(this.reason, 
/*     */         
/* 391 */         channelId(), 
/* 392 */         entityMetadata(), 
/* 393 */         name(), 
/* 394 */         privacyLevel(), 
/* 395 */         scheduledStartTime(), 
/* 396 */         scheduledEndTime(), newValue, 
/*     */         
/* 398 */         entityType());
/*     */   }
/*     */   
/*     */   public ScheduledEventEditSpec withEntityType(Possible<ScheduledEvent.EntityType> value) {
/* 402 */     Possible<ScheduledEvent.EntityType> newValue = Objects.<Possible<ScheduledEvent.EntityType>>requireNonNull(value);
/* 403 */     return new ScheduledEventEditSpec(this.reason, 
/*     */         
/* 405 */         channelId(), 
/* 406 */         entityMetadata(), 
/* 407 */         name(), 
/* 408 */         privacyLevel(), 
/* 409 */         scheduledStartTime(), 
/* 410 */         scheduledEndTime(), 
/* 411 */         description(), newValue);
/*     */   }
/*     */ 
/*     */   
/*     */   public ScheduledEventEditSpec withEntityType(ScheduledEvent.EntityType value) {
/* 416 */     Possible<ScheduledEvent.EntityType> newValue = Possible.of(value);
/* 417 */     return new ScheduledEventEditSpec(this.reason, 
/*     */         
/* 419 */         channelId(), 
/* 420 */         entityMetadata(), 
/* 421 */         name(), 
/* 422 */         privacyLevel(), 
/* 423 */         scheduledStartTime(), 
/* 424 */         scheduledEndTime(), 
/* 425 */         description(), newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 435 */     if (this == another) return true; 
/* 436 */     return (another instanceof ScheduledEventEditSpec && 
/* 437 */       equalTo(0, (ScheduledEventEditSpec)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ScheduledEventEditSpec another) {
/* 441 */     return (Objects.equals(this.reason, another.reason) && 
/* 442 */       channelId().equals(another.channelId()) && 
/* 443 */       entityMetadata().equals(another.entityMetadata()) && 
/* 444 */       name().equals(another.name()) && 
/* 445 */       privacyLevel().equals(another.privacyLevel()) && 
/* 446 */       scheduledStartTime().equals(another.scheduledStartTime()) && 
/* 447 */       scheduledEndTime().equals(another.scheduledEndTime()) && 
/* 448 */       description().equals(another.description()) && 
/* 449 */       entityType().equals(another.entityType()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 458 */     int h = 5381;
/* 459 */     h += (h << 5) + Objects.hashCode(this.reason);
/* 460 */     h += (h << 5) + channelId().hashCode();
/* 461 */     h += (h << 5) + entityMetadata().hashCode();
/* 462 */     h += (h << 5) + name().hashCode();
/* 463 */     h += (h << 5) + privacyLevel().hashCode();
/* 464 */     h += (h << 5) + scheduledStartTime().hashCode();
/* 465 */     h += (h << 5) + scheduledEndTime().hashCode();
/* 466 */     h += (h << 5) + description().hashCode();
/* 467 */     h += (h << 5) + entityType().hashCode();
/* 468 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 477 */     return "ScheduledEventEditSpec{reason=" + this.reason + ", channelId=" + 
/*     */       
/* 479 */       channelId().toString() + ", entityMetadata=" + 
/* 480 */       entityMetadata().toString() + ", name=" + 
/* 481 */       name().toString() + ", privacyLevel=" + 
/* 482 */       privacyLevel().toString() + ", scheduledStartTime=" + 
/* 483 */       scheduledStartTime().toString() + ", scheduledEndTime=" + 
/* 484 */       scheduledEndTime().toString() + ", description=" + 
/* 485 */       description().toString() + ", entityType=" + 
/* 486 */       entityType().toString() + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ScheduledEventEditSpec copyOf(ScheduledEventEditSpecGenerator instance) {
/* 498 */     if (instance instanceof ScheduledEventEditSpec) {
/* 499 */       return (ScheduledEventEditSpec)instance;
/*     */     }
/* 501 */     return builder()
/* 502 */       .from(instance)
/* 503 */       .build();
/*     */   }
/*     */   
/*     */   public boolean isChannelIdPresent() {
/* 507 */     return !this.channelId_absent;
/*     */   }
/*     */   
/*     */   public Snowflake channelIdOrElse(Snowflake defaultValue) {
/* 511 */     return !this.channelId_absent ? this.channelId_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isEntityMetadataPresent() {
/* 515 */     return !this.entityMetadata_absent;
/*     */   }
/*     */   
/*     */   public ScheduledEventEntityMetadataSpec entityMetadataOrElse(ScheduledEventEntityMetadataSpec defaultValue) {
/* 519 */     return !this.entityMetadata_absent ? this.entityMetadata_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isNamePresent() {
/* 523 */     return !this.name_absent;
/*     */   }
/*     */   
/*     */   public String nameOrElse(String defaultValue) {
/* 527 */     return !this.name_absent ? this.name_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isPrivacyLevelPresent() {
/* 531 */     return !this.privacyLevel_absent;
/*     */   }
/*     */   
/*     */   public ScheduledEvent.PrivacyLevel privacyLevelOrElse(ScheduledEvent.PrivacyLevel defaultValue) {
/* 535 */     return !this.privacyLevel_absent ? this.privacyLevel_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isScheduledStartTimePresent() {
/* 539 */     return !this.scheduledStartTime_absent;
/*     */   }
/*     */   
/*     */   public Instant scheduledStartTimeOrElse(Instant defaultValue) {
/* 543 */     return !this.scheduledStartTime_absent ? this.scheduledStartTime_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isScheduledEndTimePresent() {
/* 547 */     return !this.scheduledEndTime_absent;
/*     */   }
/*     */   
/*     */   public Instant scheduledEndTimeOrElse(Instant defaultValue) {
/* 551 */     return !this.scheduledEndTime_absent ? this.scheduledEndTime_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isDescriptionPresent() {
/* 555 */     return !this.description_absent;
/*     */   }
/*     */   
/*     */   public String descriptionOrElse(String defaultValue) {
/* 559 */     return !this.description_absent ? this.description_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isEntityTypePresent() {
/* 563 */     return !this.entityType_absent;
/*     */   }
/*     */   
/*     */   public ScheduledEvent.EntityType entityTypeOrElse(ScheduledEvent.EntityType defaultValue) {
/* 567 */     return !this.entityType_absent ? this.entityType_value : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 588 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "ScheduledEventEditSpecGenerator", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/* 600 */     private Possible<Optional<Snowflake>> channelId_possible = Possible.absent();
/* 601 */     private Possible<ScheduledEventEntityMetadataSpec> entityMetadata_possible = Possible.absent();
/* 602 */     private Possible<String> name_possible = Possible.absent();
/* 603 */     private Possible<ScheduledEvent.PrivacyLevel> privacyLevel_possible = Possible.absent();
/* 604 */     private Possible<Instant> scheduledStartTime_possible = Possible.absent();
/* 605 */     private Possible<Instant> scheduledEndTime_possible = Possible.absent();
/* 606 */     private Possible<String> description_possible = Possible.absent();
/* 607 */     private Possible<ScheduledEvent.EntityType> entityType_possible = Possible.absent();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private String reason;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder from(ScheduledEventEditSpecGenerator instance) {
/* 622 */       Objects.requireNonNull(instance, "instance");
/* 623 */       String reasonValue = instance.reason();
/* 624 */       if (reasonValue != null) {
/* 625 */         reason(reasonValue);
/*     */       }
/* 627 */       channelId(instance.channelId());
/* 628 */       entityMetadata(instance.entityMetadata());
/* 629 */       name(instance.name());
/* 630 */       privacyLevel(instance.privacyLevel());
/* 631 */       scheduledStartTime(instance.scheduledStartTime());
/* 632 */       scheduledEndTime(instance.scheduledEndTime());
/* 633 */       description(instance.description());
/* 634 */       entityType(instance.entityType());
/* 635 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder reason(@Nullable String reason) {
/* 645 */       this.reason = reason;
/* 646 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder channelId(Possible<Optional<Snowflake>> value) {
/* 651 */       this.channelId_possible = value;
/* 652 */       return this;
/*     */     }
/*     */     
/*     */     @Deprecated
/*     */     @CanIgnoreReturnValue
/*     */     public Builder channelId(@Nullable Snowflake value) {
/* 658 */       this.channelId_possible = Possible.of(Optional.ofNullable(value));
/* 659 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder channelIdOrNull(@Nullable Snowflake value) {
/* 664 */       this.channelId_possible = Possible.of(Optional.ofNullable(value));
/* 665 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder entityMetadata(Possible<ScheduledEventEntityMetadataSpec> value) {
/* 670 */       this.entityMetadata_possible = value;
/* 671 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder entityMetadata(ScheduledEventEntityMetadataSpec value) {
/* 676 */       this.entityMetadata_possible = Possible.of(value);
/* 677 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder name(Possible<String> value) {
/* 682 */       this.name_possible = value;
/* 683 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder name(String value) {
/* 688 */       this.name_possible = Possible.of(value);
/* 689 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder privacyLevel(Possible<ScheduledEvent.PrivacyLevel> value) {
/* 694 */       this.privacyLevel_possible = value;
/* 695 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder privacyLevel(ScheduledEvent.PrivacyLevel value) {
/* 700 */       this.privacyLevel_possible = Possible.of(value);
/* 701 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder scheduledStartTime(Possible<Instant> value) {
/* 706 */       this.scheduledStartTime_possible = value;
/* 707 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder scheduledStartTime(Instant value) {
/* 712 */       this.scheduledStartTime_possible = Possible.of(value);
/* 713 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder scheduledEndTime(Possible<Instant> value) {
/* 718 */       this.scheduledEndTime_possible = value;
/* 719 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder scheduledEndTime(Instant value) {
/* 724 */       this.scheduledEndTime_possible = Possible.of(value);
/* 725 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder description(Possible<String> value) {
/* 730 */       this.description_possible = value;
/* 731 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder description(String value) {
/* 736 */       this.description_possible = Possible.of(value);
/* 737 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder entityType(Possible<ScheduledEvent.EntityType> value) {
/* 742 */       this.entityType_possible = value;
/* 743 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder entityType(ScheduledEvent.EntityType value) {
/* 748 */       this.entityType_possible = Possible.of(value);
/* 749 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ScheduledEventEditSpec build() {
/* 758 */       return new ScheduledEventEditSpec(this.reason, 
/*     */           
/* 760 */           channelId_build(), 
/* 761 */           entityMetadata_build(), 
/* 762 */           name_build(), 
/* 763 */           privacyLevel_build(), 
/* 764 */           scheduledStartTime_build(), 
/* 765 */           scheduledEndTime_build(), 
/* 766 */           description_build(), 
/* 767 */           entityType_build());
/*     */     }
/*     */     
/*     */     private Possible<Optional<Snowflake>> channelId_build() {
/* 771 */       return this.channelId_possible;
/*     */     }
/*     */     
/*     */     private Possible<ScheduledEventEntityMetadataSpec> entityMetadata_build() {
/* 775 */       return this.entityMetadata_possible;
/*     */     }
/*     */     
/*     */     private Possible<String> name_build() {
/* 779 */       return this.name_possible;
/*     */     }
/*     */     
/*     */     private Possible<ScheduledEvent.PrivacyLevel> privacyLevel_build() {
/* 783 */       return this.privacyLevel_possible;
/*     */     }
/*     */     
/*     */     private Possible<Instant> scheduledStartTime_build() {
/* 787 */       return this.scheduledStartTime_possible;
/*     */     }
/*     */     
/*     */     private Possible<Instant> scheduledEndTime_build() {
/* 791 */       return this.scheduledEndTime_possible;
/*     */     }
/*     */     
/*     */     private Possible<String> description_build() {
/* 795 */       return this.description_possible;
/*     */     }
/*     */     
/*     */     private Possible<ScheduledEvent.EntityType> entityType_build() {
/* 799 */       return this.entityType_possible;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\ScheduledEventEditSpec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */