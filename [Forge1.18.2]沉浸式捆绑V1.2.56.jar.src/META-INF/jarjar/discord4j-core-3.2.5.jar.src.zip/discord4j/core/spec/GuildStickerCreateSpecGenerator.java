/*    */ package discord4j.core.spec;
/*    */ 
/*    */ import discord4j.discordjson.json.GuildStickerCreateRequest;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Immutable
/*    */ interface GuildStickerCreateSpecGenerator
/*    */   extends AuditSpec<GuildStickerCreateRequest>
/*    */ {
/*    */   default GuildStickerCreateRequest asRequest() {
/* 40 */     return (GuildStickerCreateRequest)GuildStickerCreateRequest.builder()
/* 41 */       .name(name())
/* 42 */       .description(description())
/* 43 */       .tags(tags())
/* 44 */       .file(file())
/* 45 */       .build();
/*    */   }
/*    */   
/*    */   String file();
/*    */   
/*    */   String tags();
/*    */   
/*    */   String description();
/*    */   
/*    */   String name();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\GuildStickerCreateSpecGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */