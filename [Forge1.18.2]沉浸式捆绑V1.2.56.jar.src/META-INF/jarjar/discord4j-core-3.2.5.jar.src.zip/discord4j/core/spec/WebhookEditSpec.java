/*     */ package discord4j.core.spec;
/*     */ 
/*     */ import com.google.errorprone.annotations.CanIgnoreReturnValue;
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import discord4j.rest.util.Image;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "WebhookEditSpecGenerator", generator = "Immutables")
/*     */ public final class WebhookEditSpec
/*     */   implements WebhookEditSpecGenerator
/*     */ {
/*     */   @Nullable
/*     */   private final String reason;
/*     */   private final String name_value;
/*     */   private final boolean name_absent;
/*     */   private final Image avatar_value;
/*     */   private final boolean avatar_absent;
/*     */   private final Snowflake channelId_value;
/*     */   private final boolean channelId_absent;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   
/*     */   private WebhookEditSpec() {
/*  35 */     this.reason = null;
/*  36 */     Possible<String> name$impl = Possible.absent();
/*  37 */     Possible<Image> avatar$impl = Possible.absent();
/*  38 */     Possible<Snowflake> channelId$impl = Possible.absent();
/*  39 */     this.name_value = name$impl.toOptional().orElse(null);
/*  40 */     this.name_absent = name$impl.isAbsent();
/*  41 */     this.avatar_value = avatar$impl.toOptional().orElse(null);
/*  42 */     this.avatar_absent = avatar$impl.isAbsent();
/*  43 */     this.channelId_value = channelId$impl.toOptional().orElse(null);
/*  44 */     this.channelId_absent = channelId$impl.isAbsent();
/*  45 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private WebhookEditSpec(@Nullable String reason, Possible<String> name, Possible<Image> avatar, Possible<Snowflake> channelId) {
/*  53 */     this.reason = reason;
/*  54 */     Possible<String> name$impl = name;
/*  55 */     Possible<Image> avatar$impl = avatar;
/*  56 */     Possible<Snowflake> channelId$impl = channelId;
/*  57 */     this.name_value = name$impl.toOptional().orElse(null);
/*  58 */     this.name_absent = name$impl.isAbsent();
/*  59 */     this.avatar_value = avatar$impl.toOptional().orElse(null);
/*  60 */     this.avatar_absent = avatar$impl.isAbsent();
/*  61 */     this.channelId_value = channelId$impl.toOptional().orElse(null);
/*  62 */     this.channelId_absent = channelId$impl.isAbsent();
/*  63 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  69 */   private volatile transient InitShim initShim = new InitShim();
/*     */   
/*     */   @Generated(from = "WebhookEditSpecGenerator", generator = "Immutables")
/*     */   private final class InitShim
/*     */   {
/*     */     private String formatInitCycleMessage() {
/*  75 */       List<String> attributes = new ArrayList<>();
/*  76 */       return "Cannot build WebhookEditSpec, attribute initializers form cycle " + attributes;
/*     */     }
/*     */ 
/*     */     
/*     */     private InitShim() {}
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String reason() {
/*  86 */     return this.reason;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<String> name() {
/*  94 */     return this.name_absent ? Possible.absent() : Possible.of(this.name_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Image> avatar() {
/* 102 */     return this.avatar_absent ? Possible.absent() : Possible.of(this.avatar_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Snowflake> channelId() {
/* 110 */     return this.channelId_absent ? Possible.absent() : Possible.of(this.channelId_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final WebhookEditSpec withReason(@Nullable String value) {
/* 120 */     if (Objects.equals(this.reason, value)) return this; 
/* 121 */     return validate(new WebhookEditSpec(value, name(), avatar(), channelId()));
/*     */   }
/*     */   
/*     */   public WebhookEditSpec withName(Possible<String> value) {
/* 125 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/* 126 */     return validate(new WebhookEditSpec(this.reason, newValue, avatar(), channelId()));
/*     */   }
/*     */   
/*     */   public WebhookEditSpec withName(String value) {
/* 130 */     Possible<String> newValue = Possible.of(value);
/* 131 */     return validate(new WebhookEditSpec(this.reason, newValue, avatar(), channelId()));
/*     */   }
/*     */   
/*     */   public WebhookEditSpec withAvatar(Possible<Image> value) {
/* 135 */     Possible<Image> newValue = Objects.<Possible<Image>>requireNonNull(value);
/* 136 */     return validate(new WebhookEditSpec(this.reason, name(), newValue, channelId()));
/*     */   }
/*     */   
/*     */   public WebhookEditSpec withAvatar(Image value) {
/* 140 */     Possible<Image> newValue = Possible.of(value);
/* 141 */     return validate(new WebhookEditSpec(this.reason, name(), newValue, channelId()));
/*     */   }
/*     */   
/*     */   public WebhookEditSpec withChannelId(Possible<Snowflake> value) {
/* 145 */     Possible<Snowflake> newValue = Objects.<Possible<Snowflake>>requireNonNull(value);
/* 146 */     return validate(new WebhookEditSpec(this.reason, name(), avatar(), newValue));
/*     */   }
/*     */   
/*     */   public WebhookEditSpec withChannelId(Snowflake value) {
/* 150 */     Possible<Snowflake> newValue = Possible.of(value);
/* 151 */     return validate(new WebhookEditSpec(this.reason, name(), avatar(), newValue));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 160 */     if (this == another) return true; 
/* 161 */     return (another instanceof WebhookEditSpec && 
/* 162 */       equalTo(0, (WebhookEditSpec)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, WebhookEditSpec another) {
/* 166 */     return (Objects.equals(this.reason, another.reason) && 
/* 167 */       name().equals(another.name()) && 
/* 168 */       avatar().equals(another.avatar()) && 
/* 169 */       channelId().equals(another.channelId()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 178 */     int h = 5381;
/* 179 */     h += (h << 5) + Objects.hashCode(this.reason);
/* 180 */     h += (h << 5) + name().hashCode();
/* 181 */     h += (h << 5) + avatar().hashCode();
/* 182 */     h += (h << 5) + channelId().hashCode();
/* 183 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 192 */     return "WebhookEditSpec{reason=" + this.reason + ", name=" + 
/*     */       
/* 194 */       name().toString() + ", avatar=" + 
/* 195 */       avatar().toString() + ", channelId=" + 
/* 196 */       channelId().toString() + "}";
/*     */   }
/*     */ 
/*     */   
/* 200 */   private static final WebhookEditSpec INSTANCE = validate(new WebhookEditSpec());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static WebhookEditSpec create() {
/* 207 */     return INSTANCE;
/*     */   }
/*     */   
/*     */   private static WebhookEditSpec validate(WebhookEditSpec instance) {
/* 211 */     return (INSTANCE != null && INSTANCE.equalTo(0, instance)) ? INSTANCE : instance;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static WebhookEditSpec copyOf(WebhookEditSpecGenerator instance) {
/* 222 */     if (instance instanceof WebhookEditSpec) {
/* 223 */       return (WebhookEditSpec)instance;
/*     */     }
/* 225 */     return builder()
/* 226 */       .from(instance)
/* 227 */       .build();
/*     */   }
/*     */   
/*     */   public boolean isNamePresent() {
/* 231 */     return !this.name_absent;
/*     */   }
/*     */   
/*     */   public String nameOrElse(String defaultValue) {
/* 235 */     return !this.name_absent ? this.name_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isAvatarPresent() {
/* 239 */     return !this.avatar_absent;
/*     */   }
/*     */   
/*     */   public Image avatarOrElse(Image defaultValue) {
/* 243 */     return !this.avatar_absent ? this.avatar_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isChannelIdPresent() {
/* 247 */     return !this.channelId_absent;
/*     */   }
/*     */   
/*     */   public Snowflake channelIdOrElse(Snowflake defaultValue) {
/* 251 */     return !this.channelId_absent ? this.channelId_value : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 267 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "WebhookEditSpecGenerator", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/* 279 */     private Possible<String> name_possible = Possible.absent();
/* 280 */     private Possible<Image> avatar_possible = Possible.absent();
/* 281 */     private Possible<Snowflake> channelId_possible = Possible.absent();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private String reason;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(WebhookEditSpec instance) {
/* 295 */       return from(instance);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     final Builder from(WebhookEditSpecGenerator instance) {
/* 305 */       Objects.requireNonNull(instance, "instance");
/* 306 */       String reasonValue = instance.reason();
/* 307 */       if (reasonValue != null) {
/* 308 */         reason(reasonValue);
/*     */       }
/* 310 */       name(instance.name());
/* 311 */       avatar(instance.avatar());
/* 312 */       channelId(instance.channelId());
/* 313 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder reason(@Nullable String reason) {
/* 323 */       this.reason = reason;
/* 324 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder name(Possible<String> value) {
/* 329 */       this.name_possible = value;
/* 330 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder name(String value) {
/* 335 */       this.name_possible = Possible.of(value);
/* 336 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder avatar(Possible<Image> value) {
/* 341 */       this.avatar_possible = value;
/* 342 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder avatar(Image value) {
/* 347 */       this.avatar_possible = Possible.of(value);
/* 348 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder channelId(Possible<Snowflake> value) {
/* 353 */       this.channelId_possible = value;
/* 354 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder channelId(Snowflake value) {
/* 359 */       this.channelId_possible = Possible.of(value);
/* 360 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public WebhookEditSpec build() {
/* 369 */       return WebhookEditSpec.validate(new WebhookEditSpec(this.reason, name_build(), avatar_build(), channelId_build()));
/*     */     }
/*     */     
/*     */     private Possible<String> name_build() {
/* 373 */       return this.name_possible;
/*     */     }
/*     */     
/*     */     private Possible<Image> avatar_build() {
/* 377 */       return this.avatar_possible;
/*     */     }
/*     */     
/*     */     private Possible<Snowflake> channelId_build() {
/* 381 */       return this.channelId_possible;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\WebhookEditSpec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */