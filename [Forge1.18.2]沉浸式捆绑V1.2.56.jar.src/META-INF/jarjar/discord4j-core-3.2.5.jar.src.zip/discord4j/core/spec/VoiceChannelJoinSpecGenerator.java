/*     */ package discord4j.core.spec;
/*     */ 
/*     */ import discord4j.common.LogUtil;
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.GatewayDiscordClient;
/*     */ import discord4j.core.event.domain.VoiceServerUpdateEvent;
/*     */ import discord4j.core.event.domain.VoiceStateUpdateEvent;
/*     */ import discord4j.core.object.VoiceState;
/*     */ import discord4j.core.object.entity.PartialMember;
/*     */ import discord4j.core.object.entity.channel.VoiceChannel;
/*     */ import discord4j.discordjson.json.gateway.VoiceStateUpdate;
/*     */ import discord4j.gateway.GatewayClientGroup;
/*     */ import discord4j.gateway.intent.Intent;
/*     */ import discord4j.gateway.json.ShardGatewayPayload;
/*     */ import discord4j.voice.AudioProvider;
/*     */ import discord4j.voice.AudioReceiver;
/*     */ import discord4j.voice.LocalVoiceReceiveTaskFactory;
/*     */ import discord4j.voice.LocalVoiceSendTaskFactory;
/*     */ import discord4j.voice.VoiceChannelRetrieveTask;
/*     */ import discord4j.voice.VoiceConnection;
/*     */ import discord4j.voice.VoiceDisconnectTask;
/*     */ import discord4j.voice.VoiceGatewayOptions;
/*     */ import discord4j.voice.VoiceReceiveTaskFactory;
/*     */ import discord4j.voice.VoiceSendTaskFactory;
/*     */ import discord4j.voice.VoiceServerOptions;
/*     */ import discord4j.voice.VoiceServerUpdateTask;
/*     */ import discord4j.voice.VoiceStateUpdateTask;
/*     */ import java.time.Duration;
/*     */ import java.util.concurrent.TimeoutException;
/*     */ import java.util.function.Function;
/*     */ import org.immutables.value.Value.Default;
/*     */ import org.immutables.value.Value.Immutable;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.core.publisher.Signal;
/*     */ import reactor.core.publisher.SignalType;
/*     */ import reactor.function.TupleUtils;
/*     */ import reactor.util.Logger;
/*     */ import reactor.util.Loggers;
/*     */ import reactor.util.context.Context;
/*     */ import reactor.util.retry.RetrySpec;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Immutable(singleton = true)
/*     */ interface VoiceChannelJoinSpecGenerator
/*     */   extends Spec<Function<VoiceChannel, Mono<VoiceConnection>>>
/*     */ {
/*     */   public static final int DEFAULT_TIMEOUT = 10;
/*     */   public static final int DEFAULT_DISCOVERY_TIMEOUT = 5;
/*     */   
/*     */   static Flux<VoiceStateUpdateEvent> onVoiceStateUpdates(GatewayDiscordClient gateway, Snowflake guildId) {
/*  61 */     return gateway.getEventDispatcher()
/*  62 */       .on(VoiceStateUpdateEvent.class)
/*  63 */       .filter(vsu -> {
/*     */           Snowflake vsuUser = vsu.getCurrent().getUserId();
/*     */           
/*     */           Snowflake vsuGuild = vsu.getCurrent().getGuildId();
/*  67 */           return (vsuUser.equals(gateway.getSelfId()) && vsuGuild.equals(guildId));
/*     */         });
/*     */   }
/*     */   
/*     */   static Mono<VoiceServerUpdateEvent> onVoiceServerUpdate(GatewayDiscordClient gateway, Snowflake guildId) {
/*  72 */     return gateway.getEventDispatcher()
/*  73 */       .on(VoiceServerUpdateEvent.class)
/*  74 */       .filter(vsu -> (vsu.getGuildId().equals(guildId) && vsu.getEndpoint() != null))
/*  75 */       .next();
/*     */   }
/*     */   
/*     */   @Default
/*     */   default Duration timeout() {
/*  80 */     return Duration.ofSeconds(10L);
/*     */   }
/*     */   
/*     */   @Default
/*     */   default AudioProvider provider() {
/*  85 */     return AudioProvider.NO_OP;
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   @Default
/*     */   default AudioReceiver receiver() {
/*  91 */     return AudioReceiver.NO_OP;
/*     */   }
/*     */   
/*     */   @Default
/*     */   default VoiceSendTaskFactory sendTaskFactory() {
/*  96 */     return (VoiceSendTaskFactory)new LocalVoiceSendTaskFactory();
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   @Default
/*     */   default VoiceReceiveTaskFactory receiveTaskFactory() {
/* 102 */     return (VoiceReceiveTaskFactory)new LocalVoiceReceiveTaskFactory();
/*     */   }
/*     */   
/*     */   @Default
/*     */   default boolean selfDeaf() {
/* 107 */     return false;
/*     */   }
/*     */   
/*     */   @Default
/*     */   default boolean selfMute() {
/* 112 */     return false;
/*     */   }
/*     */   
/*     */   @Default
/*     */   default Duration ipDiscoveryTimeout() {
/* 117 */     return Duration.ofSeconds(5L);
/*     */   }
/*     */   
/*     */   @Default
/*     */   default RetrySpec ipDiscoveryRetrySpec() {
/* 122 */     return RetrySpec.maxInARow(1L);
/*     */   }
/*     */ 
/*     */   
/*     */   default Function<VoiceChannel, Mono<VoiceConnection>> asRequest() {
/* 127 */     return voiceChannel -> {
/*     */         Logger log = Loggers.getLogger(VoiceChannelJoinSpec.class);
/*     */         GatewayDiscordClient gateway = voiceChannel.getClient();
/*     */         if (!gateway.getGatewayResources().getIntents().contains(Intent.GUILD_VOICE_STATES))
/*     */           return Mono.error(new IllegalArgumentException("GUILD_VOICE_STATES intent is required to establish a voice connection")); 
/*     */         Snowflake guildId = voiceChannel.getGuildId();
/*     */         Snowflake channelId = voiceChannel.getId();
/*     */         GatewayClientGroup clientGroup = voiceChannel.getClient().getGatewayClientGroup();
/*     */         int shardId = clientGroup.computeShardIndex(guildId);
/*     */         Mono<Void> sendVoiceStateUpdate = clientGroup.unicast(ShardGatewayPayload.voiceStateUpdate((VoiceStateUpdate)VoiceStateUpdate.builder().guildId(guildId.asString()).channelId(channelId.asString()).selfMute(selfMute()).selfDeaf(selfDeaf()).build(), shardId));
/*     */         Mono<VoiceStateUpdateEvent> waitForVoiceStateUpdate = onVoiceStateUpdates(gateway, guildId).next();
/*     */         Mono<VoiceServerUpdateEvent> waitForVoiceServerUpdate = onVoiceServerUpdate(gateway, guildId);
/*     */         VoiceDisconnectTask disconnectTask = ();
/*     */         VoiceServerUpdateTask serverUpdateTask = ();
/*     */         VoiceStateUpdateTask stateUpdateTask = ();
/*     */         VoiceChannelRetrieveTask channelRetrieveTask = ();
/*     */         Mono<VoiceConnection> newConnection = sendVoiceStateUpdate.then(Mono.zip(waitForVoiceStateUpdate, waitForVoiceServerUpdate)).flatMap(TupleUtils.function(())).timeout(timeout()).doFinally(()).onErrorResume(TimeoutException.class, ());
/*     */         return gateway.getVoiceConnectionRegistry().getVoiceConnection(guildId).flatMap(()).switchIfEmpty(newConnection);
/*     */       };
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\VoiceChannelJoinSpecGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */