/*    */ package discord4j.core.spec;
/*    */ 
/*    */ import discord4j.core.object.component.LayoutComponent;
/*    */ import discord4j.core.object.component.MessageComponent;
/*    */ import discord4j.core.object.entity.Attachment;
/*    */ import discord4j.discordjson.json.ImmutableWebhookMessageEditRequest;
/*    */ import discord4j.discordjson.json.WebhookMessageEditRequest;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import discord4j.rest.util.AllowedMentions;
/*    */ import discord4j.rest.util.MultipartRequest;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import java.util.Optional;
/*    */ import java.util.stream.Collectors;
/*    */ import java.util.stream.Stream;
/*    */ import org.immutables.value.Value.Default;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Immutable(singleton = true)
/*    */ interface InteractionReplyEditSpecGenerator
/*    */   extends Spec<MultipartRequest<WebhookMessageEditRequest>>
/*    */ {
/*    */   @Default
/*    */   default List<MessageCreateFields.File> files() {
/* 51 */     return Collections.emptyList();
/*    */   }
/*    */   
/*    */   @Default
/*    */   default List<MessageCreateFields.FileSpoiler> fileSpoilers() {
/* 56 */     return Collections.emptyList();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   default MultipartRequest<WebhookMessageEditRequest> asRequest() {
/* 82 */     ImmutableWebhookMessageEditRequest immutableWebhookMessageEditRequest = WebhookMessageEditRequest.builder().content(content()).embeds(InternalSpecUtils.mapPossibleOptional(embeds(), embeds -> (List)embeds.stream().map(EmbedCreateSpecGenerator::asRequest).collect(Collectors.toList()))).allowedMentions(InternalSpecUtils.mapPossibleOptional(allowedMentions(), AllowedMentions::toData)).components(InternalSpecUtils.mapPossible(components(), components -> (List)components.map(()).orElse(Collections.emptyList()))).attachments(InternalSpecUtils.mapPossibleOptional(attachments(), attachments -> (List)attachments.stream().map(Attachment::getData).collect(Collectors.toList()))).build();
/* 83 */     return MultipartRequest.ofRequestAndFiles(immutableWebhookMessageEditRequest, (List)Stream.concat(files().stream(), fileSpoilers().stream())
/* 84 */         .map(MessageCreateFields.File::asRequest)
/* 85 */         .collect(Collectors.toList()));
/*    */   }
/*    */   
/*    */   Possible<Optional<String>> content();
/*    */   
/*    */   Possible<Optional<List<EmbedCreateSpec>>> embeds();
/*    */   
/*    */   Possible<Optional<AllowedMentions>> allowedMentions();
/*    */   
/*    */   Possible<Optional<List<LayoutComponent>>> components();
/*    */   
/*    */   Possible<Optional<List<Attachment>>> attachments();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\InteractionReplyEditSpecGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */