/*     */ package discord4j.core.spec;
/*     */ 
/*     */ import com.google.errorprone.annotations.CanIgnoreReturnValue;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import org.immutables.value.Generated;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "GuildTemplateEditSpecGenerator", generator = "Immutables")
/*     */ public final class GuildTemplateEditSpec
/*     */   implements GuildTemplateEditSpecGenerator
/*     */ {
/*     */   private final String name_value;
/*     */   private final boolean name_absent;
/*     */   private final String description_value;
/*     */   private final boolean description_absent;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   
/*     */   private GuildTemplateEditSpec() {
/*  31 */     Possible<String> name$impl = Possible.absent();
/*  32 */     Possible<Optional<String>> description$impl = Possible.absent();
/*  33 */     this.name_value = name$impl.toOptional().orElse(null);
/*  34 */     this.name_absent = name$impl.isAbsent();
/*  35 */     this.description_value = Possible.flatOpt(description$impl).orElse(null);
/*  36 */     this.description_absent = description$impl.isAbsent();
/*  37 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private GuildTemplateEditSpec(Possible<String> name, Possible<Optional<String>> description) {
/*  43 */     Possible<String> name$impl = name;
/*  44 */     Possible<Optional<String>> description$impl = description;
/*  45 */     this.name_value = name$impl.toOptional().orElse(null);
/*  46 */     this.name_absent = name$impl.isAbsent();
/*  47 */     this.description_value = Possible.flatOpt(description$impl).orElse(null);
/*  48 */     this.description_absent = description$impl.isAbsent();
/*  49 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  55 */   private volatile transient InitShim initShim = new InitShim();
/*     */   
/*     */   @Generated(from = "GuildTemplateEditSpecGenerator", generator = "Immutables")
/*     */   private final class InitShim
/*     */   {
/*     */     private String formatInitCycleMessage() {
/*  61 */       List<String> attributes = new ArrayList<>();
/*  62 */       return "Cannot build GuildTemplateEditSpec, attribute initializers form cycle " + attributes;
/*     */     }
/*     */ 
/*     */     
/*     */     private InitShim() {}
/*     */   }
/*     */ 
/*     */   
/*     */   public Possible<String> name() {
/*  71 */     return this.name_absent ? Possible.absent() : Possible.of(this.name_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Optional<String>> description() {
/*  79 */     return this.description_absent ? Possible.absent() : 
/*  80 */       Possible.of(Optional.ofNullable(this.description_value));
/*     */   }
/*     */   
/*     */   public GuildTemplateEditSpec withName(Possible<String> value) {
/*  84 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/*  85 */     return validate(new GuildTemplateEditSpec(newValue, description()));
/*     */   }
/*     */   
/*     */   public GuildTemplateEditSpec withName(String value) {
/*  89 */     Possible<String> newValue = Possible.of(value);
/*  90 */     return validate(new GuildTemplateEditSpec(newValue, description()));
/*     */   }
/*     */   
/*     */   public GuildTemplateEditSpec withDescription(Possible<Optional<String>> value) {
/*  94 */     Possible<Optional<String>> newValue = Objects.<Possible<Optional<String>>>requireNonNull(value);
/*  95 */     return validate(new GuildTemplateEditSpec(name(), newValue));
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public GuildTemplateEditSpec withDescription(@Nullable String value) {
/* 100 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/* 101 */     return validate(new GuildTemplateEditSpec(name(), newValue));
/*     */   }
/*     */   
/*     */   public GuildTemplateEditSpec withDescriptionOrNull(@Nullable String value) {
/* 105 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/* 106 */     return validate(new GuildTemplateEditSpec(name(), newValue));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 115 */     if (this == another) return true; 
/* 116 */     return (another instanceof GuildTemplateEditSpec && 
/* 117 */       equalTo(0, (GuildTemplateEditSpec)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, GuildTemplateEditSpec another) {
/* 121 */     return (name().equals(another.name()) && 
/* 122 */       description().equals(another.description()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 131 */     int h = 5381;
/* 132 */     h += (h << 5) + name().hashCode();
/* 133 */     h += (h << 5) + description().hashCode();
/* 134 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 143 */     return "GuildTemplateEditSpec{name=" + 
/* 144 */       name().toString() + ", description=" + 
/* 145 */       description().toString() + "}";
/*     */   }
/*     */ 
/*     */   
/* 149 */   private static final GuildTemplateEditSpec INSTANCE = validate(new GuildTemplateEditSpec());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static GuildTemplateEditSpec create() {
/* 156 */     return INSTANCE;
/*     */   }
/*     */   
/*     */   private static GuildTemplateEditSpec validate(GuildTemplateEditSpec instance) {
/* 160 */     return (INSTANCE != null && INSTANCE.equalTo(0, instance)) ? INSTANCE : instance;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static GuildTemplateEditSpec copyOf(GuildTemplateEditSpecGenerator instance) {
/* 171 */     if (instance instanceof GuildTemplateEditSpec) {
/* 172 */       return (GuildTemplateEditSpec)instance;
/*     */     }
/* 174 */     return builder()
/* 175 */       .from(instance)
/* 176 */       .build();
/*     */   }
/*     */   
/*     */   public boolean isNamePresent() {
/* 180 */     return !this.name_absent;
/*     */   }
/*     */   
/*     */   public String nameOrElse(String defaultValue) {
/* 184 */     return !this.name_absent ? this.name_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isDescriptionPresent() {
/* 188 */     return !this.description_absent;
/*     */   }
/*     */   
/*     */   public String descriptionOrElse(String defaultValue) {
/* 192 */     return !this.description_absent ? this.description_value : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 206 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "GuildTemplateEditSpecGenerator", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/* 218 */     private Possible<String> name_possible = Possible.absent();
/* 219 */     private Possible<Optional<String>> description_possible = Possible.absent();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(GuildTemplateEditSpec instance) {
/* 232 */       return from(instance);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     final Builder from(GuildTemplateEditSpecGenerator instance) {
/* 242 */       Objects.requireNonNull(instance, "instance");
/* 243 */       name(instance.name());
/* 244 */       description(instance.description());
/* 245 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder name(Possible<String> value) {
/* 250 */       this.name_possible = value;
/* 251 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder name(String value) {
/* 256 */       this.name_possible = Possible.of(value);
/* 257 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder description(Possible<Optional<String>> value) {
/* 262 */       this.description_possible = value;
/* 263 */       return this;
/*     */     }
/*     */     
/*     */     @Deprecated
/*     */     @CanIgnoreReturnValue
/*     */     public Builder description(@Nullable String value) {
/* 269 */       this.description_possible = Possible.of(Optional.ofNullable(value));
/* 270 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder descriptionOrNull(@Nullable String value) {
/* 275 */       this.description_possible = Possible.of(Optional.ofNullable(value));
/* 276 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public GuildTemplateEditSpec build() {
/* 285 */       return GuildTemplateEditSpec.validate(new GuildTemplateEditSpec(name_build(), description_build()));
/*     */     }
/*     */     
/*     */     private Possible<String> name_build() {
/* 289 */       return this.name_possible;
/*     */     }
/*     */     
/*     */     private Possible<Optional<String>> description_build() {
/* 293 */       return this.description_possible;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\GuildTemplateEditSpec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */