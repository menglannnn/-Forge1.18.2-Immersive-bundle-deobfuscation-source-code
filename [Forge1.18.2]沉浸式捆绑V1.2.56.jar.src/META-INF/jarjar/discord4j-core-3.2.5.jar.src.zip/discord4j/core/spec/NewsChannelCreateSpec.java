/*     */ package discord4j.core.spec;
/*     */ 
/*     */ import com.google.errorprone.annotations.CanIgnoreReturnValue;
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.object.PermissionOverwrite;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.stream.StreamSupport;
/*     */ import org.immutables.value.Generated;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "NewsChannelCreateSpecGenerator", generator = "Immutables")
/*     */ public final class NewsChannelCreateSpec
/*     */   implements NewsChannelCreateSpecGenerator
/*     */ {
/*     */   @Nullable
/*     */   private final String reason;
/*     */   private final String name;
/*     */   private final String topic_value;
/*     */   private final boolean topic_absent;
/*     */   private final Integer position_value;
/*     */   private final boolean position_absent;
/*     */   private final Integer rateLimitPerUser_value;
/*     */   private final boolean rateLimitPerUser_absent;
/*     */   private final List<PermissionOverwrite> permissionOverwrites_value;
/*     */   private final boolean permissionOverwrites_absent;
/*     */   private final Snowflake parentId_value;
/*     */   private final boolean parentId_absent;
/*     */   private final Boolean nsfw_value;
/*     */   private final boolean nsfw_absent;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   private volatile transient InitShim initShim;
/*     */   
/*     */   private NewsChannelCreateSpec(String name) {
/* 103 */     this.initShim = new InitShim(); this.name = Objects.<String>requireNonNull(name, "name"); this.reason = null; Possible<String> topic$impl = Possible.absent(); Possible<Integer> position$impl = Possible.absent(); Possible<Integer> rateLimitPerUser$impl = Possible.absent(); Possible<List<PermissionOverwrite>> permissionOverwrites$impl = Possible.absent(); Possible<Snowflake> parentId$impl = Possible.absent(); Possible<Boolean> nsfw$impl = Possible.absent(); this.topic_value = topic$impl.toOptional().orElse(null); this.topic_absent = topic$impl.isAbsent(); this.position_value = position$impl.toOptional().orElse(null); this.position_absent = position$impl.isAbsent(); this.rateLimitPerUser_value = rateLimitPerUser$impl.toOptional().orElse(null); this.rateLimitPerUser_absent = rateLimitPerUser$impl.isAbsent(); this.permissionOverwrites_value = permissionOverwrites$impl.toOptional().orElse(null); this.permissionOverwrites_absent = permissionOverwrites$impl.isAbsent(); this.parentId_value = parentId$impl.toOptional().orElse(null); this.parentId_absent = parentId$impl.isAbsent(); this.nsfw_value = nsfw$impl.toOptional().orElse(null); this.nsfw_absent = nsfw$impl.isAbsent(); this.initShim = null; } private NewsChannelCreateSpec(@Nullable String reason, String name, Possible<String> topic, Possible<Integer> position, Possible<Integer> rateLimitPerUser, Possible<List<PermissionOverwrite>> permissionOverwrites, Possible<Snowflake> parentId, Possible<Boolean> nsfw) { this.initShim = new InitShim(); this.reason = reason; this.name = name; Possible<String> topic$impl = topic; Possible<Integer> position$impl = position; Possible<Integer> rateLimitPerUser$impl = rateLimitPerUser; Possible<List<PermissionOverwrite>> permissionOverwrites$impl = permissionOverwrites; Possible<Snowflake> parentId$impl = parentId; Possible<Boolean> nsfw$impl = nsfw; this.topic_value = topic$impl.toOptional().orElse(null); this.topic_absent = topic$impl.isAbsent(); this.position_value = position$impl.toOptional().orElse(null); this.position_absent = position$impl.isAbsent(); this.rateLimitPerUser_value = rateLimitPerUser$impl.toOptional().orElse(null); this.rateLimitPerUser_absent = rateLimitPerUser$impl.isAbsent(); this.permissionOverwrites_value = permissionOverwrites$impl.toOptional().orElse(null);
/*     */     this.permissionOverwrites_absent = permissionOverwrites$impl.isAbsent();
/*     */     this.parentId_value = parentId$impl.toOptional().orElse(null);
/*     */     this.parentId_absent = parentId$impl.isAbsent();
/*     */     this.nsfw_value = nsfw$impl.toOptional().orElse(null);
/*     */     this.nsfw_absent = nsfw$impl.isAbsent();
/* 109 */     this.initShim = null; } @Generated(from = "NewsChannelCreateSpecGenerator", generator = "Immutables") private final class InitShim { private InitShim() {} private String formatInitCycleMessage() { List<String> attributes = new ArrayList<>();
/* 110 */       return "Cannot build NewsChannelCreateSpec, attribute initializers form cycle " + attributes; }
/*     */      }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String reason() {
/* 120 */     return this.reason;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String name() {
/* 128 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<String> topic() {
/* 136 */     return this.topic_absent ? Possible.absent() : Possible.of(this.topic_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Integer> position() {
/* 144 */     return this.position_absent ? Possible.absent() : Possible.of(this.position_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Integer> rateLimitPerUser() {
/* 152 */     return this.rateLimitPerUser_absent ? Possible.absent() : Possible.of(this.rateLimitPerUser_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<List<PermissionOverwrite>> permissionOverwrites() {
/* 160 */     return this.permissionOverwrites_absent ? Possible.absent() : 
/* 161 */       Possible.of(this.permissionOverwrites_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Snowflake> parentId() {
/* 169 */     return this.parentId_absent ? Possible.absent() : Possible.of(this.parentId_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Boolean> nsfw() {
/* 177 */     return this.nsfw_absent ? Possible.absent() : Possible.of(this.nsfw_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final NewsChannelCreateSpec withReason(@Nullable String value) {
/* 187 */     if (Objects.equals(this.reason, value)) return this; 
/* 188 */     return new NewsChannelCreateSpec(value, this.name, 
/*     */ 
/*     */         
/* 191 */         topic(), 
/* 192 */         position(), 
/* 193 */         rateLimitPerUser(), 
/* 194 */         permissionOverwrites(), 
/* 195 */         parentId(), 
/* 196 */         nsfw());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final NewsChannelCreateSpec withName(String value) {
/* 206 */     String newValue = Objects.<String>requireNonNull(value, "name");
/* 207 */     if (this.name.equals(newValue)) return this; 
/* 208 */     return new NewsChannelCreateSpec(this.reason, newValue, 
/*     */ 
/*     */         
/* 211 */         topic(), 
/* 212 */         position(), 
/* 213 */         rateLimitPerUser(), 
/* 214 */         permissionOverwrites(), 
/* 215 */         parentId(), 
/* 216 */         nsfw());
/*     */   }
/*     */   
/*     */   public NewsChannelCreateSpec withTopic(Possible<String> value) {
/* 220 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/* 221 */     return new NewsChannelCreateSpec(this.reason, this.name, newValue, 
/*     */ 
/*     */ 
/*     */         
/* 225 */         position(), 
/* 226 */         rateLimitPerUser(), 
/* 227 */         permissionOverwrites(), 
/* 228 */         parentId(), 
/* 229 */         nsfw());
/*     */   }
/*     */   
/*     */   public NewsChannelCreateSpec withTopic(String value) {
/* 233 */     Possible<String> newValue = Possible.of(value);
/* 234 */     return new NewsChannelCreateSpec(this.reason, this.name, newValue, 
/*     */ 
/*     */ 
/*     */         
/* 238 */         position(), 
/* 239 */         rateLimitPerUser(), 
/* 240 */         permissionOverwrites(), 
/* 241 */         parentId(), 
/* 242 */         nsfw());
/*     */   }
/*     */   
/*     */   public NewsChannelCreateSpec withPosition(Possible<Integer> value) {
/* 246 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/* 247 */     return new NewsChannelCreateSpec(this.reason, this.name, 
/*     */ 
/*     */         
/* 250 */         topic(), newValue, 
/*     */         
/* 252 */         rateLimitPerUser(), 
/* 253 */         permissionOverwrites(), 
/* 254 */         parentId(), 
/* 255 */         nsfw());
/*     */   }
/*     */   
/*     */   public NewsChannelCreateSpec withPosition(Integer value) {
/* 259 */     Possible<Integer> newValue = Possible.of(value);
/* 260 */     return new NewsChannelCreateSpec(this.reason, this.name, 
/*     */ 
/*     */         
/* 263 */         topic(), newValue, 
/*     */         
/* 265 */         rateLimitPerUser(), 
/* 266 */         permissionOverwrites(), 
/* 267 */         parentId(), 
/* 268 */         nsfw());
/*     */   }
/*     */   
/*     */   public NewsChannelCreateSpec withRateLimitPerUser(Possible<Integer> value) {
/* 272 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/* 273 */     return new NewsChannelCreateSpec(this.reason, this.name, 
/*     */ 
/*     */         
/* 276 */         topic(), 
/* 277 */         position(), newValue, 
/*     */         
/* 279 */         permissionOverwrites(), 
/* 280 */         parentId(), 
/* 281 */         nsfw());
/*     */   }
/*     */   
/*     */   public NewsChannelCreateSpec withRateLimitPerUser(Integer value) {
/* 285 */     Possible<Integer> newValue = Possible.of(value);
/* 286 */     return new NewsChannelCreateSpec(this.reason, this.name, 
/*     */ 
/*     */         
/* 289 */         topic(), 
/* 290 */         position(), newValue, 
/*     */         
/* 292 */         permissionOverwrites(), 
/* 293 */         parentId(), 
/* 294 */         nsfw());
/*     */   }
/*     */   
/*     */   public NewsChannelCreateSpec withPermissionOverwrites(Possible<List<PermissionOverwrite>> possible) {
/* 298 */     Possible<List<PermissionOverwrite>> newValue = Objects.<Possible<List<PermissionOverwrite>>>requireNonNull(possible);
/* 299 */     return new NewsChannelCreateSpec(this.reason, this.name, 
/*     */ 
/*     */         
/* 302 */         topic(), 
/* 303 */         position(), 
/* 304 */         rateLimitPerUser(), newValue, 
/*     */         
/* 306 */         parentId(), 
/* 307 */         nsfw());
/*     */   }
/*     */   
/*     */   public NewsChannelCreateSpec withPermissionOverwrites(Iterable<PermissionOverwrite> elements) {
/* 311 */     Possible<List<PermissionOverwrite>> newValue = Possible.of(
/* 312 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/* 313 */     return new NewsChannelCreateSpec(this.reason, this.name, 
/*     */ 
/*     */         
/* 316 */         topic(), 
/* 317 */         position(), 
/* 318 */         rateLimitPerUser(), newValue, 
/*     */         
/* 320 */         parentId(), 
/* 321 */         nsfw());
/*     */   }
/*     */   
/*     */   @SafeVarargs
/*     */   public final NewsChannelCreateSpec withPermissionOverwrites(PermissionOverwrite... elements) {
/* 326 */     Possible<List<PermissionOverwrite>> newValue = Possible.of(Arrays.asList(elements));
/* 327 */     return new NewsChannelCreateSpec(this.reason, this.name, 
/*     */ 
/*     */         
/* 330 */         topic(), 
/* 331 */         position(), 
/* 332 */         rateLimitPerUser(), newValue, 
/*     */         
/* 334 */         parentId(), 
/* 335 */         nsfw());
/*     */   }
/*     */   
/*     */   public NewsChannelCreateSpec withParentId(Possible<Snowflake> value) {
/* 339 */     Possible<Snowflake> newValue = Objects.<Possible<Snowflake>>requireNonNull(value);
/* 340 */     return new NewsChannelCreateSpec(this.reason, this.name, 
/*     */ 
/*     */         
/* 343 */         topic(), 
/* 344 */         position(), 
/* 345 */         rateLimitPerUser(), 
/* 346 */         permissionOverwrites(), newValue, 
/*     */         
/* 348 */         nsfw());
/*     */   }
/*     */   
/*     */   public NewsChannelCreateSpec withParentId(Snowflake value) {
/* 352 */     Possible<Snowflake> newValue = Possible.of(value);
/* 353 */     return new NewsChannelCreateSpec(this.reason, this.name, 
/*     */ 
/*     */         
/* 356 */         topic(), 
/* 357 */         position(), 
/* 358 */         rateLimitPerUser(), 
/* 359 */         permissionOverwrites(), newValue, 
/*     */         
/* 361 */         nsfw());
/*     */   }
/*     */   
/*     */   public NewsChannelCreateSpec withNsfw(Possible<Boolean> value) {
/* 365 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/* 366 */     return new NewsChannelCreateSpec(this.reason, this.name, 
/*     */ 
/*     */         
/* 369 */         topic(), 
/* 370 */         position(), 
/* 371 */         rateLimitPerUser(), 
/* 372 */         permissionOverwrites(), 
/* 373 */         parentId(), newValue);
/*     */   }
/*     */ 
/*     */   
/*     */   public NewsChannelCreateSpec withNsfw(Boolean value) {
/* 378 */     Possible<Boolean> newValue = Possible.of(value);
/* 379 */     return new NewsChannelCreateSpec(this.reason, this.name, 
/*     */ 
/*     */         
/* 382 */         topic(), 
/* 383 */         position(), 
/* 384 */         rateLimitPerUser(), 
/* 385 */         permissionOverwrites(), 
/* 386 */         parentId(), newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 396 */     if (this == another) return true; 
/* 397 */     return (another instanceof NewsChannelCreateSpec && 
/* 398 */       equalTo(0, (NewsChannelCreateSpec)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, NewsChannelCreateSpec another) {
/* 402 */     return (Objects.equals(this.reason, another.reason) && this.name
/* 403 */       .equals(another.name) && 
/* 404 */       topic().equals(another.topic()) && 
/* 405 */       position().equals(another.position()) && 
/* 406 */       rateLimitPerUser().equals(another.rateLimitPerUser()) && 
/* 407 */       Objects.equals(this.permissionOverwrites_value, another.permissionOverwrites_value) && 
/* 408 */       parentId().equals(another.parentId()) && 
/* 409 */       nsfw().equals(another.nsfw()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 418 */     int h = 5381;
/* 419 */     h += (h << 5) + Objects.hashCode(this.reason);
/* 420 */     h += (h << 5) + this.name.hashCode();
/* 421 */     h += (h << 5) + topic().hashCode();
/* 422 */     h += (h << 5) + position().hashCode();
/* 423 */     h += (h << 5) + rateLimitPerUser().hashCode();
/* 424 */     h += (h << 5) + Objects.hashCode(this.permissionOverwrites_value);
/* 425 */     h += (h << 5) + parentId().hashCode();
/* 426 */     h += (h << 5) + nsfw().hashCode();
/* 427 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 436 */     return "NewsChannelCreateSpec{reason=" + this.reason + ", name=" + this.name + ", topic=" + 
/*     */ 
/*     */       
/* 439 */       topic().toString() + ", position=" + 
/* 440 */       position().toString() + ", rateLimitPerUser=" + 
/* 441 */       rateLimitPerUser().toString() + ", permissionOverwrites=" + 
/* 442 */       Objects.toString(this.permissionOverwrites_value) + ", parentId=" + 
/* 443 */       parentId().toString() + ", nsfw=" + 
/* 444 */       nsfw().toString() + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static NewsChannelCreateSpec of(String name) {
/* 454 */     return new NewsChannelCreateSpec(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static NewsChannelCreateSpec copyOf(NewsChannelCreateSpecGenerator instance) {
/* 465 */     if (instance instanceof NewsChannelCreateSpec) {
/* 466 */       return (NewsChannelCreateSpec)instance;
/*     */     }
/* 468 */     return builder()
/* 469 */       .from(instance)
/* 470 */       .build();
/*     */   }
/*     */   
/*     */   public boolean isTopicPresent() {
/* 474 */     return !this.topic_absent;
/*     */   }
/*     */   
/*     */   public String topicOrElse(String defaultValue) {
/* 478 */     return !this.topic_absent ? this.topic_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isPositionPresent() {
/* 482 */     return !this.position_absent;
/*     */   }
/*     */   
/*     */   public Integer positionOrElse(Integer defaultValue) {
/* 486 */     return !this.position_absent ? this.position_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isRateLimitPerUserPresent() {
/* 490 */     return !this.rateLimitPerUser_absent;
/*     */   }
/*     */   
/*     */   public Integer rateLimitPerUserOrElse(Integer defaultValue) {
/* 494 */     return !this.rateLimitPerUser_absent ? this.rateLimitPerUser_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isPermissionOverwritesPresent() {
/* 498 */     return !this.permissionOverwrites_absent;
/*     */   }
/*     */   
/*     */   public List<PermissionOverwrite> permissionOverwritesOrElse(List<PermissionOverwrite> defaultValue) {
/* 502 */     return !this.permissionOverwrites_absent ? this.permissionOverwrites_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isParentIdPresent() {
/* 506 */     return !this.parentId_absent;
/*     */   }
/*     */   
/*     */   public Snowflake parentIdOrElse(Snowflake defaultValue) {
/* 510 */     return !this.parentId_absent ? this.parentId_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isNsfwPresent() {
/* 514 */     return !this.nsfw_absent;
/*     */   }
/*     */   
/*     */   public Boolean nsfwOrElse(Boolean defaultValue) {
/* 518 */     return !this.nsfw_absent ? this.nsfw_value : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 538 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "NewsChannelCreateSpecGenerator", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_NAME = 1L;
/*     */ 
/*     */ 
/*     */     
/* 551 */     private long initBits = 1L;
/*     */     
/* 553 */     private Possible<String> topic_possible = Possible.absent();
/* 554 */     private Possible<Integer> position_possible = Possible.absent();
/* 555 */     private Possible<Integer> rateLimitPerUser_possible = Possible.absent();
/* 556 */     private List<PermissionOverwrite> permissionOverwrites_list = null;
/* 557 */     private Possible<Snowflake> parentId_possible = Possible.absent();
/* 558 */     private Possible<Boolean> nsfw_possible = Possible.absent();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private String reason;
/*     */ 
/*     */ 
/*     */     
/*     */     private String name;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(NewsChannelCreateSpec instance) {
/* 573 */       return from(instance);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     final Builder from(NewsChannelCreateSpecGenerator instance) {
/* 583 */       Objects.requireNonNull(instance, "instance");
/* 584 */       String reasonValue = instance.reason();
/* 585 */       if (reasonValue != null) {
/* 586 */         reason(reasonValue);
/*     */       }
/* 588 */       name(instance.name());
/* 589 */       topic(instance.topic());
/* 590 */       position(instance.position());
/* 591 */       rateLimitPerUser(instance.rateLimitPerUser());
/* 592 */       permissionOverwrites(instance.permissionOverwrites());
/* 593 */       parentId(instance.parentId());
/* 594 */       nsfw(instance.nsfw());
/* 595 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder reason(@Nullable String reason) {
/* 605 */       this.reason = reason;
/* 606 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder name(String name) {
/* 616 */       this.name = Objects.<String>requireNonNull(name, "name");
/* 617 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 618 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder topic(Possible<String> value) {
/* 623 */       this.topic_possible = value;
/* 624 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder topic(String value) {
/* 629 */       this.topic_possible = Possible.of(value);
/* 630 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder position(Possible<Integer> value) {
/* 635 */       this.position_possible = value;
/* 636 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder position(Integer value) {
/* 641 */       this.position_possible = Possible.of(value);
/* 642 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder rateLimitPerUser(Possible<Integer> value) {
/* 647 */       this.rateLimitPerUser_possible = value;
/* 648 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder rateLimitPerUser(Integer value) {
/* 653 */       this.rateLimitPerUser_possible = Possible.of(value);
/* 654 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder addPermissionOverwrite(PermissionOverwrite element) {
/* 659 */       permissionOverwrites_getOrCreate().add(element);
/* 660 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder addAllPermissionOverwrites(List<PermissionOverwrite> elements) {
/* 665 */       permissionOverwrites_getOrCreate().addAll(elements);
/* 666 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder permissionOverwrites(Possible<List<PermissionOverwrite>> elements) {
/* 671 */       this.permissionOverwrites_list = null;
/* 672 */       elements.toOptional().ifPresent(e -> permissionOverwrites_getOrCreate().addAll(e));
/* 673 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder permissionOverwrites(List<PermissionOverwrite> elements) {
/* 678 */       this.permissionOverwrites_list = new ArrayList<>(elements);
/* 679 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder permissionOverwrites(Iterable<PermissionOverwrite> elements) {
/* 684 */       this.permissionOverwrites_list = (List<PermissionOverwrite>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/* 685 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder parentId(Possible<Snowflake> value) {
/* 690 */       this.parentId_possible = value;
/* 691 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder parentId(Snowflake value) {
/* 696 */       this.parentId_possible = Possible.of(value);
/* 697 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder nsfw(Possible<Boolean> value) {
/* 702 */       this.nsfw_possible = value;
/* 703 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder nsfw(Boolean value) {
/* 708 */       this.nsfw_possible = Possible.of(value);
/* 709 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public NewsChannelCreateSpec build() {
/* 718 */       if (this.initBits != 0L) {
/* 719 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 721 */       return new NewsChannelCreateSpec(this.reason, this.name, 
/*     */ 
/*     */           
/* 724 */           topic_build(), 
/* 725 */           position_build(), 
/* 726 */           rateLimitPerUser_build(), 
/* 727 */           permissionOverwrites_build(), 
/* 728 */           parentId_build(), 
/* 729 */           nsfw_build());
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 733 */       List<String> attributes = new ArrayList<>();
/* 734 */       if ((this.initBits & 0x1L) != 0L) attributes.add("name"); 
/* 735 */       return "Cannot build NewsChannelCreateSpec, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Possible<String> topic_build() {
/* 739 */       return this.topic_possible;
/*     */     }
/*     */     
/*     */     private Possible<Integer> position_build() {
/* 743 */       return this.position_possible;
/*     */     }
/*     */     
/*     */     private Possible<Integer> rateLimitPerUser_build() {
/* 747 */       return this.rateLimitPerUser_possible;
/*     */     }
/*     */     
/*     */     private Possible<List<PermissionOverwrite>> permissionOverwrites_build() {
/* 751 */       return (this.permissionOverwrites_list == null) ? Possible.absent() : 
/* 752 */         Possible.of(this.permissionOverwrites_list);
/*     */     }
/*     */     
/*     */     private List<PermissionOverwrite> permissionOverwrites_getOrCreate() {
/* 756 */       if (this.permissionOverwrites_list == null) {
/* 757 */         this.permissionOverwrites_list = new ArrayList<>();
/*     */       }
/* 759 */       return this.permissionOverwrites_list;
/*     */     }
/*     */     
/*     */     private Possible<Snowflake> parentId_build() {
/* 763 */       return this.parentId_possible;
/*     */     }
/*     */     
/*     */     private Possible<Boolean> nsfw_build() {
/* 767 */       return this.nsfw_possible;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\NewsChannelCreateSpec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */