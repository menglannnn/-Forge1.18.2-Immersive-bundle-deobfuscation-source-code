/*    */ package discord4j.core.spec;
/*    */ 
/*    */ import discord4j.discordjson.json.UserModifyRequest;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import discord4j.rest.util.Image;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Immutable(singleton = true)
/*    */ interface UserEditSpecGenerator
/*    */   extends Spec<UserModifyRequest>
/*    */ {
/*    */   default UserModifyRequest asRequest() {
/* 40 */     return (UserModifyRequest)UserModifyRequest.builder()
/* 41 */       .username(username())
/* 42 */       .avatar(InternalSpecUtils.mapPossible(avatar(), Image::getDataUri))
/* 43 */       .build();
/*    */   }
/*    */   
/*    */   Possible<Image> avatar();
/*    */   
/*    */   Possible<String> username();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\UserEditSpecGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */