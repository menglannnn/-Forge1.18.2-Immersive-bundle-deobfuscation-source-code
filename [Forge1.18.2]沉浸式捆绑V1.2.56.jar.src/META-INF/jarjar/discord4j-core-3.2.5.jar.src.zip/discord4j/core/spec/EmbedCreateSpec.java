/*      */ package discord4j.core.spec;
/*      */ 
/*      */ import com.google.errorprone.annotations.CanIgnoreReturnValue;
/*      */ import discord4j.discordjson.possible.Possible;
/*      */ import discord4j.rest.util.Color;
/*      */ import java.time.Instant;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.List;
/*      */ import java.util.Objects;
/*      */ import org.immutables.value.Generated;
/*      */ import reactor.util.annotation.Nullable;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ @Generated(from = "EmbedCreateSpecGenerator", generator = "Immutables")
/*      */ public final class EmbedCreateSpec
/*      */   implements EmbedCreateSpecGenerator
/*      */ {
/*      */   private final String title_value;
/*      */   private final boolean title_absent;
/*      */   private final String description_value;
/*      */   private final boolean description_absent;
/*      */   private final String url_value;
/*      */   private final boolean url_absent;
/*      */   private final Instant timestamp_value;
/*      */   private final boolean timestamp_absent;
/*      */   private final Color color_value;
/*      */   private final boolean color_absent;
/*      */   @Nullable
/*      */   private final ImmutableEmbedCreateFields.Footer footer;
/*      */   private final String image_value;
/*      */   private final boolean image_absent;
/*      */   private final String thumbnail_value;
/*      */   private final boolean thumbnail_absent;
/*      */   @Nullable
/*      */   private final ImmutableEmbedCreateFields.Author author;
/*      */   private final List<EmbedCreateFields.Field> fields;
/*      */   private static final byte STAGE_INITIALIZING = -1;
/*      */   private static final byte STAGE_UNINITIALIZED = 0;
/*      */   private static final byte STAGE_INITIALIZED = 1;
/*      */   
/*      */   private EmbedCreateSpec() {
/*   48 */     Possible<String> title$impl = Possible.absent();
/*   49 */     Possible<String> description$impl = Possible.absent();
/*   50 */     Possible<String> url$impl = Possible.absent();
/*   51 */     Possible<Instant> timestamp$impl = Possible.absent();
/*   52 */     Possible<Color> color$impl = Possible.absent();
/*   53 */     this.footer = null;
/*   54 */     Possible<String> image$impl = Possible.absent();
/*   55 */     Possible<String> thumbnail$impl = Possible.absent();
/*   56 */     this.author = null;
/*   57 */     this.title_value = title$impl.toOptional().orElse(null);
/*   58 */     this.title_absent = title$impl.isAbsent();
/*   59 */     this.description_value = description$impl.toOptional().orElse(null);
/*   60 */     this.description_absent = description$impl.isAbsent();
/*   61 */     this.url_value = url$impl.toOptional().orElse(null);
/*   62 */     this.url_absent = url$impl.isAbsent();
/*   63 */     this.timestamp_value = timestamp$impl.toOptional().orElse(null);
/*   64 */     this.timestamp_absent = timestamp$impl.isAbsent();
/*   65 */     this.color_value = color$impl.toOptional().orElse(null);
/*   66 */     this.color_absent = color$impl.isAbsent();
/*   67 */     this.image_value = image$impl.toOptional().orElse(null);
/*   68 */     this.image_absent = image$impl.isAbsent();
/*   69 */     this.thumbnail_value = thumbnail$impl.toOptional().orElse(null);
/*   70 */     this.thumbnail_absent = thumbnail$impl.isAbsent();
/*   71 */     this.fields = this.initShim.fields();
/*   72 */     this.initShim = null;
/*      */   }
/*      */   
/*      */   private EmbedCreateSpec(Builder builder) {
/*   76 */     Possible<String> title$impl = builder.title_build();
/*   77 */     Possible<String> description$impl = builder.description_build();
/*   78 */     Possible<String> url$impl = builder.url_build();
/*   79 */     Possible<Instant> timestamp$impl = builder.timestamp_build();
/*   80 */     Possible<Color> color$impl = builder.color_build();
/*   81 */     this.footer = (builder.footer == null) ? null : ImmutableEmbedCreateFields.Footer.copyOf(builder.footer);
/*   82 */     Possible<String> image$impl = builder.image_build();
/*   83 */     Possible<String> thumbnail$impl = builder.thumbnail_build();
/*   84 */     this.author = (builder.author == null) ? null : ImmutableEmbedCreateFields.Author.copyOf(builder.author);
/*   85 */     if (builder.fieldsIsSet()) {
/*   86 */       this.initShim.fields(createUnmodifiableList(true, builder.fields));
/*      */     }
/*   88 */     this.title_value = title$impl.toOptional().orElse(null);
/*   89 */     this.title_absent = title$impl.isAbsent();
/*   90 */     this.description_value = description$impl.toOptional().orElse(null);
/*   91 */     this.description_absent = description$impl.isAbsent();
/*   92 */     this.url_value = url$impl.toOptional().orElse(null);
/*   93 */     this.url_absent = url$impl.isAbsent();
/*   94 */     this.timestamp_value = timestamp$impl.toOptional().orElse(null);
/*   95 */     this.timestamp_absent = timestamp$impl.isAbsent();
/*   96 */     this.color_value = color$impl.toOptional().orElse(null);
/*   97 */     this.color_absent = color$impl.isAbsent();
/*   98 */     this.image_value = image$impl.toOptional().orElse(null);
/*   99 */     this.image_absent = image$impl.isAbsent();
/*  100 */     this.thumbnail_value = thumbnail$impl.toOptional().orElse(null);
/*  101 */     this.thumbnail_absent = thumbnail$impl.isAbsent();
/*  102 */     this.fields = this.initShim.fields();
/*  103 */     this.initShim = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private EmbedCreateSpec(Possible<String> title, Possible<String> description, Possible<String> url, Possible<Instant> timestamp, Possible<Color> color, @Nullable ImmutableEmbedCreateFields.Footer footer, Possible<String> image, Possible<String> thumbnail, @Nullable ImmutableEmbedCreateFields.Author author, List<EmbedCreateFields.Field> fields) {
/*  117 */     Possible<String> title$impl = title;
/*  118 */     Possible<String> description$impl = description;
/*  119 */     Possible<String> url$impl = url;
/*  120 */     Possible<Instant> timestamp$impl = timestamp;
/*  121 */     Possible<Color> color$impl = color;
/*  122 */     this.footer = footer;
/*  123 */     Possible<String> image$impl = image;
/*  124 */     Possible<String> thumbnail$impl = thumbnail;
/*  125 */     this.author = author;
/*  126 */     this.initShim.fields(fields);
/*  127 */     this.title_value = title$impl.toOptional().orElse(null);
/*  128 */     this.title_absent = title$impl.isAbsent();
/*  129 */     this.description_value = description$impl.toOptional().orElse(null);
/*  130 */     this.description_absent = description$impl.isAbsent();
/*  131 */     this.url_value = url$impl.toOptional().orElse(null);
/*  132 */     this.url_absent = url$impl.isAbsent();
/*  133 */     this.timestamp_value = timestamp$impl.toOptional().orElse(null);
/*  134 */     this.timestamp_absent = timestamp$impl.isAbsent();
/*  135 */     this.color_value = color$impl.toOptional().orElse(null);
/*  136 */     this.color_absent = color$impl.isAbsent();
/*  137 */     this.image_value = image$impl.toOptional().orElse(null);
/*  138 */     this.image_absent = image$impl.isAbsent();
/*  139 */     this.thumbnail_value = thumbnail$impl.toOptional().orElse(null);
/*  140 */     this.thumbnail_absent = thumbnail$impl.isAbsent();
/*  141 */     this.fields = this.initShim.fields();
/*  142 */     this.initShim = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  148 */   private volatile transient InitShim initShim = new InitShim();
/*      */   
/*      */   @Generated(from = "EmbedCreateSpecGenerator", generator = "Immutables")
/*      */   private final class InitShim
/*      */   {
/*  153 */     private byte fieldsBuildStage = 0;
/*      */     private List<EmbedCreateFields.Field> fields;
/*      */     
/*      */     List<EmbedCreateFields.Field> fields() {
/*  157 */       if (this.fieldsBuildStage == -1) throw new IllegalStateException(formatInitCycleMessage()); 
/*  158 */       if (this.fieldsBuildStage == 0) {
/*  159 */         this.fieldsBuildStage = -1;
/*  160 */         this.fields = (List)EmbedCreateSpec.createUnmodifiableList(false, EmbedCreateSpec.createSafeList((Iterable)EmbedCreateSpec.this.fieldsInitialize(), true, false));
/*  161 */         this.fieldsBuildStage = 1;
/*      */       } 
/*  163 */       return this.fields;
/*      */     }
/*      */     
/*      */     void fields(List<EmbedCreateFields.Field> fields) {
/*  167 */       this.fields = fields;
/*  168 */       this.fieldsBuildStage = 1;
/*      */     }
/*      */     private InitShim() {}
/*      */     private String formatInitCycleMessage() {
/*  172 */       List<String> attributes = new ArrayList<>();
/*  173 */       if (this.fieldsBuildStage == -1) attributes.add("fields"); 
/*  174 */       return "Cannot build EmbedCreateSpec, attribute initializers form cycle " + attributes;
/*      */     }
/*      */   }
/*      */   
/*      */   private List<EmbedCreateFields.Field> fieldsInitialize() {
/*  179 */     return super.fields();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Possible<String> title() {
/*  187 */     return this.title_absent ? Possible.absent() : Possible.of(this.title_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Possible<String> description() {
/*  195 */     return this.description_absent ? Possible.absent() : Possible.of(this.description_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Possible<String> url() {
/*  203 */     return this.url_absent ? Possible.absent() : Possible.of(this.url_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Possible<Instant> timestamp() {
/*  211 */     return this.timestamp_absent ? Possible.absent() : Possible.of(this.timestamp_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Possible<Color> color() {
/*  219 */     return this.color_absent ? Possible.absent() : Possible.of(this.color_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public ImmutableEmbedCreateFields.Footer footer() {
/*  227 */     return this.footer;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Possible<String> image() {
/*  235 */     return this.image_absent ? Possible.absent() : Possible.of(this.image_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Possible<String> thumbnail() {
/*  243 */     return this.thumbnail_absent ? Possible.absent() : Possible.of(this.thumbnail_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public ImmutableEmbedCreateFields.Author author() {
/*  251 */     return this.author;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<EmbedCreateFields.Field> fields() {
/*  259 */     InitShim shim = this.initShim;
/*  260 */     return (shim != null) ? 
/*  261 */       shim.fields() : 
/*  262 */       this.fields;
/*      */   }
/*      */   
/*      */   public EmbedCreateSpec withTitle(Possible<String> value) {
/*  266 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/*  267 */     return validate(new EmbedCreateSpec(newValue, 
/*      */           
/*  269 */           description(), 
/*  270 */           url(), 
/*  271 */           timestamp(), 
/*  272 */           color(), this.footer, 
/*      */           
/*  274 */           image(), 
/*  275 */           thumbnail(), this.author, this.fields));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public EmbedCreateSpec withTitle(String value) {
/*  281 */     Possible<String> newValue = Possible.of(value);
/*  282 */     return validate(new EmbedCreateSpec(newValue, 
/*      */           
/*  284 */           description(), 
/*  285 */           url(), 
/*  286 */           timestamp(), 
/*  287 */           color(), this.footer, 
/*      */           
/*  289 */           image(), 
/*  290 */           thumbnail(), this.author, this.fields));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public EmbedCreateSpec withDescription(Possible<String> value) {
/*  296 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/*  297 */     return validate(new EmbedCreateSpec(
/*  298 */           title(), newValue, 
/*      */           
/*  300 */           url(), 
/*  301 */           timestamp(), 
/*  302 */           color(), this.footer, 
/*      */           
/*  304 */           image(), 
/*  305 */           thumbnail(), this.author, this.fields));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public EmbedCreateSpec withDescription(String value) {
/*  311 */     Possible<String> newValue = Possible.of(value);
/*  312 */     return validate(new EmbedCreateSpec(
/*  313 */           title(), newValue, 
/*      */           
/*  315 */           url(), 
/*  316 */           timestamp(), 
/*  317 */           color(), this.footer, 
/*      */           
/*  319 */           image(), 
/*  320 */           thumbnail(), this.author, this.fields));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public EmbedCreateSpec withUrl(Possible<String> value) {
/*  326 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/*  327 */     return validate(new EmbedCreateSpec(
/*  328 */           title(), 
/*  329 */           description(), newValue, 
/*      */           
/*  331 */           timestamp(), 
/*  332 */           color(), this.footer, 
/*      */           
/*  334 */           image(), 
/*  335 */           thumbnail(), this.author, this.fields));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public EmbedCreateSpec withUrl(String value) {
/*  341 */     Possible<String> newValue = Possible.of(value);
/*  342 */     return validate(new EmbedCreateSpec(
/*  343 */           title(), 
/*  344 */           description(), newValue, 
/*      */           
/*  346 */           timestamp(), 
/*  347 */           color(), this.footer, 
/*      */           
/*  349 */           image(), 
/*  350 */           thumbnail(), this.author, this.fields));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public EmbedCreateSpec withTimestamp(Possible<Instant> value) {
/*  356 */     Possible<Instant> newValue = Objects.<Possible<Instant>>requireNonNull(value);
/*  357 */     return validate(new EmbedCreateSpec(
/*  358 */           title(), 
/*  359 */           description(), 
/*  360 */           url(), newValue, 
/*      */           
/*  362 */           color(), this.footer, 
/*      */           
/*  364 */           image(), 
/*  365 */           thumbnail(), this.author, this.fields));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public EmbedCreateSpec withTimestamp(Instant value) {
/*  371 */     Possible<Instant> newValue = Possible.of(value);
/*  372 */     return validate(new EmbedCreateSpec(
/*  373 */           title(), 
/*  374 */           description(), 
/*  375 */           url(), newValue, 
/*      */           
/*  377 */           color(), this.footer, 
/*      */           
/*  379 */           image(), 
/*  380 */           thumbnail(), this.author, this.fields));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public EmbedCreateSpec withColor(Possible<Color> value) {
/*  386 */     Possible<Color> newValue = Objects.<Possible<Color>>requireNonNull(value);
/*  387 */     return validate(new EmbedCreateSpec(
/*  388 */           title(), 
/*  389 */           description(), 
/*  390 */           url(), 
/*  391 */           timestamp(), newValue, this.footer, 
/*      */ 
/*      */           
/*  394 */           image(), 
/*  395 */           thumbnail(), this.author, this.fields));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public EmbedCreateSpec withColor(Color value) {
/*  401 */     Possible<Color> newValue = Possible.of(value);
/*  402 */     return validate(new EmbedCreateSpec(
/*  403 */           title(), 
/*  404 */           description(), 
/*  405 */           url(), 
/*  406 */           timestamp(), newValue, this.footer, 
/*      */ 
/*      */           
/*  409 */           image(), 
/*  410 */           thumbnail(), this.author, this.fields));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final EmbedCreateSpec withFooter(@Nullable EmbedCreateFields.Footer value) {
/*  422 */     if (this.footer == value) return this; 
/*  423 */     ImmutableEmbedCreateFields.Footer newValue = (value == null) ? null : ImmutableEmbedCreateFields.Footer.copyOf(value);
/*  424 */     return validate(new EmbedCreateSpec(
/*  425 */           title(), 
/*  426 */           description(), 
/*  427 */           url(), 
/*  428 */           timestamp(), 
/*  429 */           color(), newValue, 
/*      */           
/*  431 */           image(), 
/*  432 */           thumbnail(), this.author, this.fields));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public EmbedCreateSpec withImage(Possible<String> value) {
/*  438 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/*  439 */     return validate(new EmbedCreateSpec(
/*  440 */           title(), 
/*  441 */           description(), 
/*  442 */           url(), 
/*  443 */           timestamp(), 
/*  444 */           color(), this.footer, newValue, 
/*      */ 
/*      */           
/*  447 */           thumbnail(), this.author, this.fields));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public EmbedCreateSpec withImage(String value) {
/*  453 */     Possible<String> newValue = Possible.of(value);
/*  454 */     return validate(new EmbedCreateSpec(
/*  455 */           title(), 
/*  456 */           description(), 
/*  457 */           url(), 
/*  458 */           timestamp(), 
/*  459 */           color(), this.footer, newValue, 
/*      */ 
/*      */           
/*  462 */           thumbnail(), this.author, this.fields));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public EmbedCreateSpec withThumbnail(Possible<String> value) {
/*  468 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/*  469 */     return validate(new EmbedCreateSpec(
/*  470 */           title(), 
/*  471 */           description(), 
/*  472 */           url(), 
/*  473 */           timestamp(), 
/*  474 */           color(), this.footer, 
/*      */           
/*  476 */           image(), newValue, this.author, this.fields));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public EmbedCreateSpec withThumbnail(String value) {
/*  483 */     Possible<String> newValue = Possible.of(value);
/*  484 */     return validate(new EmbedCreateSpec(
/*  485 */           title(), 
/*  486 */           description(), 
/*  487 */           url(), 
/*  488 */           timestamp(), 
/*  489 */           color(), this.footer, 
/*      */           
/*  491 */           image(), newValue, this.author, this.fields));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final EmbedCreateSpec withAuthor(@Nullable EmbedCreateFields.Author value) {
/*  504 */     if (this.author == value) return this; 
/*  505 */     ImmutableEmbedCreateFields.Author newValue = (value == null) ? null : ImmutableEmbedCreateFields.Author.copyOf(value);
/*  506 */     return validate(new EmbedCreateSpec(
/*  507 */           title(), 
/*  508 */           description(), 
/*  509 */           url(), 
/*  510 */           timestamp(), 
/*  511 */           color(), this.footer, 
/*      */           
/*  513 */           image(), 
/*  514 */           thumbnail(), newValue, this.fields));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final EmbedCreateSpec withFields(EmbedCreateFields.Field... elements) {
/*  525 */     List<EmbedCreateFields.Field> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/*  526 */     return validate(new EmbedCreateSpec(
/*  527 */           title(), 
/*  528 */           description(), 
/*  529 */           url(), 
/*  530 */           timestamp(), 
/*  531 */           color(), this.footer, 
/*      */           
/*  533 */           image(), 
/*  534 */           thumbnail(), this.author, newValue));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final EmbedCreateSpec withFields(Iterable<? extends EmbedCreateFields.Field> elements) {
/*  546 */     if (this.fields == elements) return this; 
/*  547 */     List<EmbedCreateFields.Field> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/*  548 */     return validate(new EmbedCreateSpec(
/*  549 */           title(), 
/*  550 */           description(), 
/*  551 */           url(), 
/*  552 */           timestamp(), 
/*  553 */           color(), this.footer, 
/*      */           
/*  555 */           image(), 
/*  556 */           thumbnail(), this.author, newValue));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean equals(Object another) {
/*  567 */     if (this == another) return true; 
/*  568 */     return (another instanceof EmbedCreateSpec && 
/*  569 */       equalTo(0, (EmbedCreateSpec)another));
/*      */   }
/*      */   
/*      */   private boolean equalTo(int synthetic, EmbedCreateSpec another) {
/*  573 */     return (title().equals(another.title()) && 
/*  574 */       description().equals(another.description()) && 
/*  575 */       url().equals(another.url()) && 
/*  576 */       timestamp().equals(another.timestamp()) && 
/*  577 */       color().equals(another.color()) && 
/*  578 */       Objects.equals(this.footer, another.footer) && 
/*  579 */       image().equals(another.image()) && 
/*  580 */       thumbnail().equals(another.thumbnail()) && 
/*  581 */       Objects.equals(this.author, another.author) && this.fields
/*  582 */       .equals(another.fields));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int hashCode() {
/*  591 */     int h = 5381;
/*  592 */     h += (h << 5) + title().hashCode();
/*  593 */     h += (h << 5) + description().hashCode();
/*  594 */     h += (h << 5) + url().hashCode();
/*  595 */     h += (h << 5) + timestamp().hashCode();
/*  596 */     h += (h << 5) + color().hashCode();
/*  597 */     h += (h << 5) + Objects.hashCode(this.footer);
/*  598 */     h += (h << 5) + image().hashCode();
/*  599 */     h += (h << 5) + thumbnail().hashCode();
/*  600 */     h += (h << 5) + Objects.hashCode(this.author);
/*  601 */     h += (h << 5) + this.fields.hashCode();
/*  602 */     return h;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/*  611 */     return "EmbedCreateSpec{title=" + 
/*  612 */       title().toString() + ", description=" + 
/*  613 */       description().toString() + ", url=" + 
/*  614 */       url().toString() + ", timestamp=" + 
/*  615 */       timestamp().toString() + ", color=" + 
/*  616 */       color().toString() + ", footer=" + this.footer + ", image=" + 
/*      */       
/*  618 */       image().toString() + ", thumbnail=" + 
/*  619 */       thumbnail().toString() + ", author=" + this.author + ", fields=" + this.fields + "}";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  625 */   private static final EmbedCreateSpec INSTANCE = validate(new EmbedCreateSpec());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static EmbedCreateSpec create() {
/*  632 */     return INSTANCE;
/*      */   }
/*      */   
/*      */   private static EmbedCreateSpec validate(EmbedCreateSpec instance) {
/*  636 */     return (INSTANCE != null && INSTANCE.equalTo(0, instance)) ? INSTANCE : instance;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static EmbedCreateSpec copyOf(EmbedCreateSpecGenerator instance) {
/*  647 */     if (instance instanceof EmbedCreateSpec) {
/*  648 */       return (EmbedCreateSpec)instance;
/*      */     }
/*  650 */     return builder()
/*  651 */       .from(instance)
/*  652 */       .build();
/*      */   }
/*      */   
/*      */   public boolean isTitlePresent() {
/*  656 */     return !this.title_absent;
/*      */   }
/*      */   
/*      */   public String titleOrElse(String defaultValue) {
/*  660 */     return !this.title_absent ? this.title_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isDescriptionPresent() {
/*  664 */     return !this.description_absent;
/*      */   }
/*      */   
/*      */   public String descriptionOrElse(String defaultValue) {
/*  668 */     return !this.description_absent ? this.description_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isUrlPresent() {
/*  672 */     return !this.url_absent;
/*      */   }
/*      */   
/*      */   public String urlOrElse(String defaultValue) {
/*  676 */     return !this.url_absent ? this.url_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isTimestampPresent() {
/*  680 */     return !this.timestamp_absent;
/*      */   }
/*      */   
/*      */   public Instant timestampOrElse(Instant defaultValue) {
/*  684 */     return !this.timestamp_absent ? this.timestamp_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isColorPresent() {
/*  688 */     return !this.color_absent;
/*      */   }
/*      */   
/*      */   public Color colorOrElse(Color defaultValue) {
/*  692 */     return !this.color_absent ? this.color_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isImagePresent() {
/*  696 */     return !this.image_absent;
/*      */   }
/*      */   
/*      */   public String imageOrElse(String defaultValue) {
/*  700 */     return !this.image_absent ? this.image_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isThumbnailPresent() {
/*  704 */     return !this.thumbnail_absent;
/*      */   }
/*      */   
/*      */   public String thumbnailOrElse(String defaultValue) {
/*  708 */     return !this.thumbnail_absent ? this.thumbnail_value : defaultValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Builder builder() {
/*  730 */     return new Builder();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Generated(from = "EmbedCreateSpecGenerator", generator = "Immutables")
/*      */   public static final class Builder
/*      */   {
/*      */     private static final long OPT_BIT_FIELDS = 1L;
/*      */ 
/*      */     
/*      */     private long optBits;
/*      */ 
/*      */     
/*  745 */     private Possible<String> title_possible = Possible.absent();
/*  746 */     private Possible<String> description_possible = Possible.absent();
/*  747 */     private Possible<String> url_possible = Possible.absent();
/*  748 */     private Possible<Instant> timestamp_possible = Possible.absent();
/*  749 */     private Possible<Color> color_possible = Possible.absent();
/*  750 */     private Possible<String> image_possible = Possible.absent();
/*  751 */     private Possible<String> thumbnail_possible = Possible.absent();
/*      */     private EmbedCreateFields.Footer footer;
/*      */     private EmbedCreateFields.Author author;
/*  754 */     private List<EmbedCreateFields.Field> fields = new ArrayList<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder from(EmbedCreateSpec instance) {
/*  768 */       return from(instance);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     final Builder from(EmbedCreateSpecGenerator instance) {
/*  778 */       Objects.requireNonNull(instance, "instance");
/*  779 */       title(instance.title());
/*  780 */       description(instance.description());
/*  781 */       url(instance.url());
/*  782 */       timestamp(instance.timestamp());
/*  783 */       color(instance.color());
/*  784 */       EmbedCreateFields.Footer footerValue = instance.footer();
/*  785 */       if (footerValue != null) {
/*  786 */         footer(footerValue);
/*      */       }
/*  788 */       image(instance.image());
/*  789 */       thumbnail(instance.thumbnail());
/*  790 */       EmbedCreateFields.Author authorValue = instance.author();
/*  791 */       if (authorValue != null) {
/*  792 */         author(authorValue);
/*      */       }
/*  794 */       addAllFields(instance.fields());
/*  795 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder title(Possible<String> value) {
/*  800 */       this.title_possible = value;
/*  801 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder title(String value) {
/*  806 */       this.title_possible = Possible.of(value);
/*  807 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder description(Possible<String> value) {
/*  812 */       this.description_possible = value;
/*  813 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder description(String value) {
/*  818 */       this.description_possible = Possible.of(value);
/*  819 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder url(Possible<String> value) {
/*  824 */       this.url_possible = value;
/*  825 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder url(String value) {
/*  830 */       this.url_possible = Possible.of(value);
/*  831 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder timestamp(Possible<Instant> value) {
/*  836 */       this.timestamp_possible = value;
/*  837 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder timestamp(Instant value) {
/*  842 */       this.timestamp_possible = Possible.of(value);
/*  843 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder color(Possible<Color> value) {
/*  848 */       this.color_possible = value;
/*  849 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder color(Color value) {
/*  854 */       this.color_possible = Possible.of(value);
/*  855 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public final Builder footer(String text, @Nullable String iconUrl) {
/*  866 */       return footer(ImmutableEmbedCreateFields.Footer.of(text, iconUrl));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public final Builder footer(@Nullable EmbedCreateFields.Footer footer) {
/*  876 */       this.footer = (footer == null) ? null : ImmutableEmbedCreateFields.Footer.copyOf(footer);
/*  877 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder image(Possible<String> value) {
/*  882 */       this.image_possible = value;
/*  883 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder image(String value) {
/*  888 */       this.image_possible = Possible.of(value);
/*  889 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder thumbnail(Possible<String> value) {
/*  894 */       this.thumbnail_possible = value;
/*  895 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder thumbnail(String value) {
/*  900 */       this.thumbnail_possible = Possible.of(value);
/*  901 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public final Builder author(String name, @Nullable String url, @Nullable String iconUrl) {
/*  913 */       return author(ImmutableEmbedCreateFields.Author.of(name, url, iconUrl));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public final Builder author(@Nullable EmbedCreateFields.Author author) {
/*  923 */       this.author = (author == null) ? null : ImmutableEmbedCreateFields.Author.copyOf(author);
/*  924 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public final Builder addField(EmbedCreateFields.Field element) {
/*  934 */       element = ImmutableEmbedCreateFields.Field.copyOf(element);
/*  935 */       this.fields.add(Objects.<EmbedCreateFields.Field>requireNonNull(element, "fields element"));
/*  936 */       this.optBits |= 0x1L;
/*  937 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addField(String name, String value, boolean inline) {
/*  948 */       return addField(ImmutableEmbedCreateFields.Field.of(name, value, inline));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public final Builder addFields(EmbedCreateFields.Field... elements) {
/*  958 */       for (EmbedCreateFields.Field element : elements) {
/*  959 */         element = ImmutableEmbedCreateFields.Field.copyOf(element);
/*  960 */         this.fields.add(Objects.<EmbedCreateFields.Field>requireNonNull(element, "fields element"));
/*      */       } 
/*  962 */       this.optBits |= 0x1L;
/*  963 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public final Builder fields(Iterable<? extends EmbedCreateFields.Field> elements) {
/*  974 */       this.fields.clear();
/*  975 */       return addAllFields(elements);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public final Builder addAllFields(Iterable<? extends EmbedCreateFields.Field> elements) {
/*  985 */       for (EmbedCreateFields.Field element : elements) {
/*  986 */         element = ImmutableEmbedCreateFields.Field.copyOf(element);
/*  987 */         this.fields.add(Objects.<EmbedCreateFields.Field>requireNonNull(element, "fields element"));
/*      */       } 
/*  989 */       this.optBits |= 0x1L;
/*  990 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public EmbedCreateSpec build() {
/*  999 */       return EmbedCreateSpec.validate(new EmbedCreateSpec(this));
/*      */     }
/*      */     
/*      */     private boolean fieldsIsSet() {
/* 1003 */       return ((this.optBits & 0x1L) != 0L);
/*      */     }
/*      */     
/*      */     private Possible<String> title_build() {
/* 1007 */       return this.title_possible;
/*      */     }
/*      */     
/*      */     private Possible<String> description_build() {
/* 1011 */       return this.description_possible;
/*      */     }
/*      */     
/*      */     private Possible<String> url_build() {
/* 1015 */       return this.url_possible;
/*      */     }
/*      */     
/*      */     private Possible<Instant> timestamp_build() {
/* 1019 */       return this.timestamp_possible;
/*      */     }
/*      */     
/*      */     private Possible<Color> color_build() {
/* 1023 */       return this.color_possible;
/*      */     }
/*      */     
/*      */     private Possible<String> image_build() {
/* 1027 */       return this.image_possible;
/*      */     }
/*      */     
/*      */     private Possible<String> thumbnail_build() {
/* 1031 */       return this.thumbnail_possible;
/*      */     }
/*      */     private Builder() {} }
/*      */   
/*      */   private static <T> List<T> createSafeList(Iterable<? extends T> iterable, boolean checkNulls, boolean skipNulls) {
/*      */     ArrayList<T> list;
/* 1037 */     if (iterable instanceof Collection) {
/* 1038 */       int size = ((Collection)iterable).size();
/* 1039 */       if (size == 0) return Collections.emptyList(); 
/* 1040 */       list = new ArrayList<>();
/*      */     } else {
/* 1042 */       list = new ArrayList<>();
/*      */     } 
/* 1044 */     for (T element : iterable) {
/* 1045 */       if (skipNulls && element == null)
/* 1046 */         continue;  if (checkNulls) Objects.requireNonNull(element, "element"); 
/* 1047 */       list.add(element);
/*      */     } 
/* 1049 */     return list;
/*      */   }
/*      */   
/*      */   private static <T> List<T> createUnmodifiableList(boolean clone, List<T> list) {
/* 1053 */     switch (list.size()) { case 0:
/* 1054 */         return Collections.emptyList();
/* 1055 */       case 1: return Collections.singletonList(list.get(0)); }
/*      */     
/* 1057 */     if (clone) {
/* 1058 */       return Collections.unmodifiableList(new ArrayList<>(list));
/*      */     }
/* 1060 */     if (list instanceof ArrayList) {
/* 1061 */       ((ArrayList)list).trimToSize();
/*      */     }
/* 1063 */     return Collections.unmodifiableList(list);
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\EmbedCreateSpec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */