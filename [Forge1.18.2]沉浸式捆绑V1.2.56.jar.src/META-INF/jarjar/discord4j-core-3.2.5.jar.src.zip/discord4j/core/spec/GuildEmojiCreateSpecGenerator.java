/*    */ package discord4j.core.spec;
/*    */ 
/*    */ import discord4j.common.util.Snowflake;
/*    */ import discord4j.discordjson.json.GuildEmojiCreateRequest;
/*    */ import discord4j.rest.util.Image;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import java.util.stream.Collectors;
/*    */ import org.immutables.value.Value.Default;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Immutable
/*    */ interface GuildEmojiCreateSpecGenerator
/*    */   extends AuditSpec<GuildEmojiCreateRequest>
/*    */ {
/*    */   @Default
/*    */   default List<Snowflake> roles() {
/* 42 */     return Collections.emptyList();
/*    */   }
/*    */ 
/*    */   
/*    */   default GuildEmojiCreateRequest asRequest() {
/* 47 */     return (GuildEmojiCreateRequest)GuildEmojiCreateRequest.builder()
/* 48 */       .name(name())
/* 49 */       .image(image().getDataUri())
/* 50 */       .roles((Iterable)roles().stream().map(Snowflake::asString).collect(Collectors.toList()))
/* 51 */       .build();
/*    */   }
/*    */   
/*    */   String name();
/*    */   
/*    */   Image image();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\GuildEmojiCreateSpecGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */