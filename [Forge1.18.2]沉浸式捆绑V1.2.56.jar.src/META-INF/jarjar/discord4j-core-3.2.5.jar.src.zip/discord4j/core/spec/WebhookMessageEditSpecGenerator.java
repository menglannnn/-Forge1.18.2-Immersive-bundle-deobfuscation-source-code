/*    */ package discord4j.core.spec;
/*    */ 
/*    */ import discord4j.core.object.component.LayoutComponent;
/*    */ import discord4j.core.object.component.MessageComponent;
/*    */ import discord4j.discordjson.json.ImmutableWebhookMessageEditRequest;
/*    */ import discord4j.discordjson.json.WebhookMessageEditRequest;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import discord4j.rest.util.AllowedMentions;
/*    */ import discord4j.rest.util.MultipartRequest;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import java.util.Optional;
/*    */ import java.util.stream.Collectors;
/*    */ import java.util.stream.Stream;
/*    */ import org.immutables.value.Value.Default;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Immutable(singleton = true)
/*    */ public interface WebhookMessageEditSpecGenerator
/*    */   extends Spec<MultipartRequest<WebhookMessageEditRequest>>
/*    */ {
/*    */   @Default
/*    */   default List<MessageCreateFields.File> files() {
/* 48 */     return Collections.emptyList();
/*    */   }
/*    */   
/*    */   @Default
/*    */   default List<MessageCreateFields.FileSpoiler> fileSpoilers() {
/* 53 */     return Collections.emptyList();
/*    */   }
/*    */   
/*    */   @Default
/*    */   default List<EmbedCreateSpec> embeds() {
/* 58 */     return Collections.emptyList();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   default MultipartRequest<WebhookMessageEditRequest> asRequest() {
/* 74 */     ImmutableWebhookMessageEditRequest immutableWebhookMessageEditRequest = WebhookMessageEditRequest.builder().content(content()).embeds((List)embeds().stream().map(EmbedCreateSpecGenerator::asRequest).collect(Collectors.toList())).allowedMentions(InternalSpecUtils.mapPossibleOptional(allowedMentions(), AllowedMentions::toData)).components(InternalSpecUtils.mapPossible(components(), components -> (List)components.stream().map(MessageComponent::getData).collect(Collectors.toList()))).build();
/* 75 */     return MultipartRequest.ofRequestAndFiles(immutableWebhookMessageEditRequest, (List)Stream.concat(files().stream(), fileSpoilers().stream())
/* 76 */         .map(MessageCreateFields.File::asRequest)
/* 77 */         .collect(Collectors.toList()));
/*    */   }
/*    */   
/*    */   Possible<Optional<String>> content();
/*    */   
/*    */   Possible<Optional<AllowedMentions>> allowedMentions();
/*    */   
/*    */   Possible<List<LayoutComponent>> components();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\WebhookMessageEditSpecGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */