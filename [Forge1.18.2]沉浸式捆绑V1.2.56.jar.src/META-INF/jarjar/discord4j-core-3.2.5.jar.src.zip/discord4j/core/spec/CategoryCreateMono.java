/*     */ package discord4j.core.spec;
/*     */ 
/*     */ import discord4j.core.object.PermissionOverwrite;
/*     */ import discord4j.core.object.entity.Guild;
/*     */ import discord4j.core.object.entity.channel.Category;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.stream.StreamSupport;
/*     */ import org.immutables.value.Generated;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "CategoryCreateMonoGenerator", generator = "Immutables")
/*     */ public final class CategoryCreateMono
/*     */   extends CategoryCreateMonoGenerator
/*     */ {
/*     */   @Nullable
/*     */   private final String reason;
/*     */   private final String name;
/*     */   private final Integer position_value;
/*     */   private final boolean position_absent;
/*     */   private final List<PermissionOverwrite> permissionOverwrites_value;
/*     */   private final boolean permissionOverwrites_absent;
/*     */   private final Guild guild;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   private volatile transient InitShim initShim;
/*     */   
/*     */   private CategoryCreateMono(String name, Guild guild) {
/*  68 */     this.initShim = new InitShim(); this.name = Objects.<String>requireNonNull(name, "name"); this.guild = Objects.<Guild>requireNonNull(guild, "guild"); this.reason = null; Possible<Integer> position$impl = Possible.absent(); Possible<List<PermissionOverwrite>> permissionOverwrites$impl = Possible.absent(); this.position_value = position$impl.toOptional().orElse(null); this.position_absent = position$impl.isAbsent(); this.permissionOverwrites_value = permissionOverwrites$impl.toOptional().orElse(null); this.permissionOverwrites_absent = permissionOverwrites$impl.isAbsent(); this.initShim = null; } private CategoryCreateMono(@Nullable String reason, String name, Possible<Integer> position, Possible<List<PermissionOverwrite>> permissionOverwrites, Guild guild) { this.initShim = new InitShim(); this.reason = reason; this.name = name; Possible<Integer> position$impl = position; Possible<List<PermissionOverwrite>> permissionOverwrites$impl = permissionOverwrites;
/*     */     this.guild = guild;
/*     */     this.position_value = position$impl.toOptional().orElse(null);
/*     */     this.position_absent = position$impl.isAbsent();
/*     */     this.permissionOverwrites_value = permissionOverwrites$impl.toOptional().orElse(null);
/*     */     this.permissionOverwrites_absent = permissionOverwrites$impl.isAbsent();
/*  74 */     this.initShim = null; } @Generated(from = "CategoryCreateMonoGenerator", generator = "Immutables") private final class InitShim { private InitShim() {} private String formatInitCycleMessage() { List<String> attributes = new ArrayList<>();
/*  75 */       return "Cannot build CategoryCreateMono, attribute initializers form cycle " + attributes; }
/*     */      }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String reason() {
/*  85 */     return this.reason;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String name() {
/*  93 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Integer> position() {
/* 101 */     return this.position_absent ? Possible.absent() : Possible.of(this.position_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<List<PermissionOverwrite>> permissionOverwrites() {
/* 109 */     return this.permissionOverwrites_absent ? Possible.absent() : 
/* 110 */       Possible.of(this.permissionOverwrites_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Guild guild() {
/* 118 */     return this.guild;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final CategoryCreateMono withReason(@Nullable String value) {
/* 128 */     if (Objects.equals(this.reason, value)) return this; 
/* 129 */     return new CategoryCreateMono(value, this.name, position(), permissionOverwrites(), this.guild);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final CategoryCreateMono withName(String value) {
/* 139 */     String newValue = Objects.<String>requireNonNull(value, "name");
/* 140 */     if (this.name.equals(newValue)) return this; 
/* 141 */     return new CategoryCreateMono(this.reason, newValue, position(), permissionOverwrites(), this.guild);
/*     */   }
/*     */   
/*     */   public CategoryCreateMono withPosition(Possible<Integer> value) {
/* 145 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/* 146 */     return new CategoryCreateMono(this.reason, this.name, newValue, permissionOverwrites(), this.guild);
/*     */   }
/*     */   
/*     */   public CategoryCreateMono withPosition(Integer value) {
/* 150 */     Possible<Integer> newValue = Possible.of(value);
/* 151 */     return new CategoryCreateMono(this.reason, this.name, newValue, permissionOverwrites(), this.guild);
/*     */   }
/*     */   
/*     */   public CategoryCreateMono withPermissionOverwrites(Possible<List<PermissionOverwrite>> possible) {
/* 155 */     Possible<List<PermissionOverwrite>> newValue = Objects.<Possible<List<PermissionOverwrite>>>requireNonNull(possible);
/* 156 */     return new CategoryCreateMono(this.reason, this.name, position(), newValue, this.guild);
/*     */   }
/*     */   
/*     */   public CategoryCreateMono withPermissionOverwrites(Iterable<PermissionOverwrite> elements) {
/* 160 */     Possible<List<PermissionOverwrite>> newValue = Possible.of(
/* 161 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/* 162 */     return new CategoryCreateMono(this.reason, this.name, position(), newValue, this.guild);
/*     */   }
/*     */   
/*     */   @SafeVarargs
/*     */   public final CategoryCreateMono withPermissionOverwrites(PermissionOverwrite... elements) {
/* 167 */     Possible<List<PermissionOverwrite>> newValue = Possible.of(Arrays.asList(elements));
/* 168 */     return new CategoryCreateMono(this.reason, this.name, position(), newValue, this.guild);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final CategoryCreateMono withGuild(Guild value) {
/* 178 */     if (this.guild == value) return this; 
/* 179 */     Guild newValue = Objects.<Guild>requireNonNull(value, "guild");
/* 180 */     return new CategoryCreateMono(this.reason, this.name, position(), permissionOverwrites(), newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 189 */     if (this == another) return true; 
/* 190 */     return (another instanceof CategoryCreateMono && 
/* 191 */       equalTo(0, (CategoryCreateMono)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, CategoryCreateMono another) {
/* 195 */     return (Objects.equals(this.reason, another.reason) && this.name
/* 196 */       .equals(another.name) && 
/* 197 */       position().equals(another.position()) && 
/* 198 */       Objects.equals(this.permissionOverwrites_value, another.permissionOverwrites_value) && this.guild
/* 199 */       .equals(another.guild));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 208 */     int h = 5381;
/* 209 */     h += (h << 5) + Objects.hashCode(this.reason);
/* 210 */     h += (h << 5) + this.name.hashCode();
/* 211 */     h += (h << 5) + position().hashCode();
/* 212 */     h += (h << 5) + Objects.hashCode(this.permissionOverwrites_value);
/* 213 */     h += (h << 5) + this.guild.hashCode();
/* 214 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 223 */     return "CategoryCreateMono{reason=" + this.reason + ", name=" + this.name + ", position=" + 
/*     */ 
/*     */       
/* 226 */       position().toString() + ", permissionOverwrites=" + 
/* 227 */       Objects.toString(this.permissionOverwrites_value) + ", guild=" + this.guild + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CategoryCreateMono of(String name, Guild guild) {
/* 239 */     return new CategoryCreateMono(name, guild);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static CategoryCreateMono copyOf(CategoryCreateMonoGenerator instance) {
/* 250 */     if (instance instanceof CategoryCreateMono) {
/* 251 */       return (CategoryCreateMono)instance;
/*     */     }
/* 253 */     return of(instance.name(), instance.guild())
/* 254 */       .withReason(instance.reason())
/* 255 */       .withPosition(instance.position())
/* 256 */       .withPermissionOverwrites(instance.permissionOverwrites());
/*     */   }
/*     */   
/*     */   public boolean isPositionPresent() {
/* 260 */     return !this.position_absent;
/*     */   }
/*     */   
/*     */   public Integer positionOrElse(Integer defaultValue) {
/* 264 */     return !this.position_absent ? this.position_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isPermissionOverwritesPresent() {
/* 268 */     return !this.permissionOverwrites_absent;
/*     */   }
/*     */   
/*     */   public List<PermissionOverwrite> permissionOverwritesOrElse(List<PermissionOverwrite> defaultValue) {
/* 272 */     return !this.permissionOverwrites_absent ? this.permissionOverwrites_value : defaultValue;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\CategoryCreateMono.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */