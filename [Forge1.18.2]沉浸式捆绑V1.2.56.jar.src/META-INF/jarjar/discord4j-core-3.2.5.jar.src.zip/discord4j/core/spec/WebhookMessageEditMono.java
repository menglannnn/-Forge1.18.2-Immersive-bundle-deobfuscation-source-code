/*     */ package discord4j.core.spec;
/*     */ 
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.object.component.LayoutComponent;
/*     */ import discord4j.core.object.entity.Message;
/*     */ import discord4j.core.object.entity.Webhook;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import discord4j.rest.util.AllowedMentions;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.stream.StreamSupport;
/*     */ import org.immutables.value.Generated;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "WebhookMessageEditMonoGenerator", generator = "Immutables")
/*     */ public final class WebhookMessageEditMono
/*     */   extends WebhookMessageEditMonoGenerator
/*     */ {
/*     */   private final String content_value;
/*     */   private final boolean content_absent;
/*     */   private final List<MessageCreateFields.File> files;
/*     */   private final List<MessageCreateFields.FileSpoiler> fileSpoilers;
/*     */   private final List<EmbedCreateSpec> embeds;
/*     */   private final AllowedMentions allowedMentions_value;
/*     */   private final boolean allowedMentions_absent;
/*     */   private final List<LayoutComponent> components_value;
/*     */   private final boolean components_absent;
/*     */   private final Snowflake messageId;
/*     */   private final Webhook webhook;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   private volatile transient InitShim initShim;
/*     */   
/*     */   private WebhookMessageEditMono(Snowflake messageId, Webhook webhook) {
/*  93 */     this.initShim = new InitShim(); this.messageId = Objects.<Snowflake>requireNonNull(messageId, "messageId"); this.webhook = Objects.<Webhook>requireNonNull(webhook, "webhook"); Possible<Optional<String>> content$impl = Possible.absent(); Possible<Optional<AllowedMentions>> allowedMentions$impl = Possible.absent(); Possible<List<LayoutComponent>> components$impl = Possible.absent(); this.content_value = Possible.flatOpt(content$impl).orElse(null); this.content_absent = content$impl.isAbsent(); this.allowedMentions_value = Possible.flatOpt(allowedMentions$impl).orElse(null); this.allowedMentions_absent = allowedMentions$impl.isAbsent(); this.components_value = components$impl.toOptional().orElse(null); this.components_absent = components$impl.isAbsent(); this.files = this.initShim.files(); this.fileSpoilers = this.initShim.fileSpoilers(); this.embeds = this.initShim.embeds(); this.initShim = null; } private WebhookMessageEditMono(Possible<Optional<String>> content, List<MessageCreateFields.File> files, List<MessageCreateFields.FileSpoiler> fileSpoilers, List<EmbedCreateSpec> embeds, Possible<Optional<AllowedMentions>> allowedMentions, Possible<List<LayoutComponent>> components, Snowflake messageId, Webhook webhook) { this.initShim = new InitShim(); Possible<Optional<String>> content$impl = content; this.initShim.files(files); this.initShim.fileSpoilers(fileSpoilers); this.initShim.embeds(embeds); Possible<Optional<AllowedMentions>> allowedMentions$impl = allowedMentions; Possible<List<LayoutComponent>> components$impl = components; this.messageId = messageId; this.webhook = webhook; this.content_value = Possible.flatOpt(content$impl).orElse(null); this.content_absent = content$impl.isAbsent(); this.allowedMentions_value = Possible.flatOpt(allowedMentions$impl).orElse(null); this.allowedMentions_absent = allowedMentions$impl.isAbsent(); this.components_value = components$impl.toOptional().orElse(null);
/*     */     this.components_absent = components$impl.isAbsent();
/*     */     this.files = this.initShim.files();
/*     */     this.fileSpoilers = this.initShim.fileSpoilers();
/*     */     this.embeds = this.initShim.embeds();
/*  98 */     this.initShim = null; } @Generated(from = "WebhookMessageEditMonoGenerator", generator = "Immutables") private final class InitShim { private byte filesBuildStage = 0;
/*     */     private List<MessageCreateFields.File> files;
/*     */     
/*     */     List<MessageCreateFields.File> files() {
/* 102 */       if (this.filesBuildStage == -1) throw new IllegalStateException(formatInitCycleMessage()); 
/* 103 */       if (this.filesBuildStage == 0) {
/* 104 */         this.filesBuildStage = -1;
/* 105 */         this.files = (List)WebhookMessageEditMono.createUnmodifiableList(false, WebhookMessageEditMono.createSafeList((Iterable)WebhookMessageEditMono.this.files(), true, false));
/* 106 */         this.filesBuildStage = 1;
/*     */       } 
/* 108 */       return this.files;
/*     */     }
/*     */     
/*     */     void files(List<MessageCreateFields.File> files) {
/* 112 */       this.files = files;
/* 113 */       this.filesBuildStage = 1;
/*     */     }
/*     */     
/* 116 */     private byte fileSpoilersBuildStage = 0;
/*     */     private List<MessageCreateFields.FileSpoiler> fileSpoilers;
/*     */     
/*     */     List<MessageCreateFields.FileSpoiler> fileSpoilers() {
/* 120 */       if (this.fileSpoilersBuildStage == -1) throw new IllegalStateException(formatInitCycleMessage()); 
/* 121 */       if (this.fileSpoilersBuildStage == 0) {
/* 122 */         this.fileSpoilersBuildStage = -1;
/* 123 */         this.fileSpoilers = (List)WebhookMessageEditMono.createUnmodifiableList(false, WebhookMessageEditMono.createSafeList((Iterable)WebhookMessageEditMono.this.fileSpoilers(), true, false));
/* 124 */         this.fileSpoilersBuildStage = 1;
/*     */       } 
/* 126 */       return this.fileSpoilers;
/*     */     }
/*     */     
/*     */     void fileSpoilers(List<MessageCreateFields.FileSpoiler> fileSpoilers) {
/* 130 */       this.fileSpoilers = fileSpoilers;
/* 131 */       this.fileSpoilersBuildStage = 1;
/*     */     }
/*     */     
/* 134 */     private byte embedsBuildStage = 0;
/*     */     private List<EmbedCreateSpec> embeds;
/*     */     
/*     */     List<EmbedCreateSpec> embeds() {
/* 138 */       if (this.embedsBuildStage == -1) throw new IllegalStateException(formatInitCycleMessage()); 
/* 139 */       if (this.embedsBuildStage == 0) {
/* 140 */         this.embedsBuildStage = -1;
/* 141 */         this.embeds = (List)WebhookMessageEditMono.createUnmodifiableList(false, WebhookMessageEditMono.createSafeList((Iterable)WebhookMessageEditMono.this.embeds(), true, false));
/* 142 */         this.embedsBuildStage = 1;
/*     */       } 
/* 144 */       return this.embeds;
/*     */     }
/*     */     
/*     */     void embeds(List<EmbedCreateSpec> embeds) {
/* 148 */       this.embeds = embeds;
/* 149 */       this.embedsBuildStage = 1;
/*     */     }
/*     */     
/*     */     private String formatInitCycleMessage() {
/* 153 */       List<String> attributes = new ArrayList<>();
/* 154 */       if (this.filesBuildStage == -1) attributes.add("files"); 
/* 155 */       if (this.fileSpoilersBuildStage == -1) attributes.add("fileSpoilers"); 
/* 156 */       if (this.embedsBuildStage == -1) attributes.add("embeds"); 
/* 157 */       return "Cannot build WebhookMessageEditMono, attribute initializers form cycle " + attributes;
/*     */     }
/*     */ 
/*     */     
/*     */     private InitShim() {} }
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Optional<String>> content() {
/* 166 */     return this.content_absent ? Possible.absent() : 
/* 167 */       Possible.of(Optional.ofNullable(this.content_value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<MessageCreateFields.File> files() {
/* 175 */     InitShim shim = this.initShim;
/* 176 */     return (shim != null) ? 
/* 177 */       shim.files() : 
/* 178 */       this.files;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<MessageCreateFields.FileSpoiler> fileSpoilers() {
/* 186 */     InitShim shim = this.initShim;
/* 187 */     return (shim != null) ? 
/* 188 */       shim.fileSpoilers() : 
/* 189 */       this.fileSpoilers;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<EmbedCreateSpec> embeds() {
/* 197 */     InitShim shim = this.initShim;
/* 198 */     return (shim != null) ? 
/* 199 */       shim.embeds() : 
/* 200 */       this.embeds;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Optional<AllowedMentions>> allowedMentions() {
/* 208 */     return this.allowedMentions_absent ? Possible.absent() : 
/* 209 */       Possible.of(Optional.ofNullable(this.allowedMentions_value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<List<LayoutComponent>> components() {
/* 217 */     return this.components_absent ? Possible.absent() : 
/* 218 */       Possible.of(this.components_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Snowflake messageId() {
/* 226 */     return this.messageId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Webhook webhook() {
/* 234 */     return this.webhook;
/*     */   }
/*     */   
/*     */   public WebhookMessageEditMono withContent(Possible<Optional<String>> value) {
/* 238 */     Possible<Optional<String>> newValue = Objects.<Possible<Optional<String>>>requireNonNull(value);
/* 239 */     return new WebhookMessageEditMono(newValue, this.files, this.fileSpoilers, this.embeds, 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 244 */         allowedMentions(), 
/* 245 */         components(), this.messageId, this.webhook);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public WebhookMessageEditMono withContent(@Nullable String value) {
/* 252 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/* 253 */     return new WebhookMessageEditMono(newValue, this.files, this.fileSpoilers, this.embeds, 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 258 */         allowedMentions(), 
/* 259 */         components(), this.messageId, this.webhook);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public WebhookMessageEditMono withContentOrNull(@Nullable String value) {
/* 265 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/* 266 */     return new WebhookMessageEditMono(newValue, this.files, this.fileSpoilers, this.embeds, 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 271 */         allowedMentions(), 
/* 272 */         components(), this.messageId, this.webhook);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final WebhookMessageEditMono withFiles(MessageCreateFields.File... elements) {
/* 283 */     List<MessageCreateFields.File> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/* 284 */     return new WebhookMessageEditMono(
/* 285 */         content(), newValue, this.fileSpoilers, this.embeds, 
/*     */ 
/*     */ 
/*     */         
/* 289 */         allowedMentions(), 
/* 290 */         components(), this.messageId, this.webhook);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final WebhookMessageEditMono withFiles(Iterable<? extends MessageCreateFields.File> elements) {
/* 302 */     if (this.files == elements) return this; 
/* 303 */     List<MessageCreateFields.File> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/* 304 */     return new WebhookMessageEditMono(
/* 305 */         content(), newValue, this.fileSpoilers, this.embeds, 
/*     */ 
/*     */ 
/*     */         
/* 309 */         allowedMentions(), 
/* 310 */         components(), this.messageId, this.webhook);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final WebhookMessageEditMono withFileSpoilers(MessageCreateFields.FileSpoiler... elements) {
/* 321 */     List<MessageCreateFields.FileSpoiler> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/* 322 */     return new WebhookMessageEditMono(
/* 323 */         content(), this.files, newValue, this.embeds, 
/*     */ 
/*     */ 
/*     */         
/* 327 */         allowedMentions(), 
/* 328 */         components(), this.messageId, this.webhook);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final WebhookMessageEditMono withFileSpoilers(Iterable<? extends MessageCreateFields.FileSpoiler> elements) {
/* 340 */     if (this.fileSpoilers == elements) return this; 
/* 341 */     List<MessageCreateFields.FileSpoiler> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/* 342 */     return new WebhookMessageEditMono(
/* 343 */         content(), this.files, newValue, this.embeds, 
/*     */ 
/*     */ 
/*     */         
/* 347 */         allowedMentions(), 
/* 348 */         components(), this.messageId, this.webhook);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final WebhookMessageEditMono withEmbeds(EmbedCreateSpec... elements) {
/* 359 */     List<EmbedCreateSpec> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/* 360 */     return new WebhookMessageEditMono(
/* 361 */         content(), this.files, this.fileSpoilers, newValue, 
/*     */ 
/*     */ 
/*     */         
/* 365 */         allowedMentions(), 
/* 366 */         components(), this.messageId, this.webhook);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final WebhookMessageEditMono withEmbeds(Iterable<? extends EmbedCreateSpec> elements) {
/* 378 */     if (this.embeds == elements) return this; 
/* 379 */     List<EmbedCreateSpec> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/* 380 */     return new WebhookMessageEditMono(
/* 381 */         content(), this.files, this.fileSpoilers, newValue, 
/*     */ 
/*     */ 
/*     */         
/* 385 */         allowedMentions(), 
/* 386 */         components(), this.messageId, this.webhook);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public WebhookMessageEditMono withAllowedMentions(Possible<Optional<AllowedMentions>> value) {
/* 392 */     Possible<Optional<AllowedMentions>> newValue = Objects.<Possible<Optional<AllowedMentions>>>requireNonNull(value);
/* 393 */     return new WebhookMessageEditMono(
/* 394 */         content(), this.files, this.fileSpoilers, this.embeds, newValue, 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 399 */         components(), this.messageId, this.webhook);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public WebhookMessageEditMono withAllowedMentions(@Nullable AllowedMentions value) {
/* 406 */     Possible<Optional<AllowedMentions>> newValue = Possible.of(Optional.ofNullable(value));
/* 407 */     return new WebhookMessageEditMono(
/* 408 */         content(), this.files, this.fileSpoilers, this.embeds, newValue, 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 413 */         components(), this.messageId, this.webhook);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public WebhookMessageEditMono withAllowedMentionsOrNull(@Nullable AllowedMentions value) {
/* 419 */     Possible<Optional<AllowedMentions>> newValue = Possible.of(Optional.ofNullable(value));
/* 420 */     return new WebhookMessageEditMono(
/* 421 */         content(), this.files, this.fileSpoilers, this.embeds, newValue, 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 426 */         components(), this.messageId, this.webhook);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public WebhookMessageEditMono withComponents(Possible<List<LayoutComponent>> possible) {
/* 432 */     Possible<List<LayoutComponent>> newValue = Objects.<Possible<List<LayoutComponent>>>requireNonNull(possible);
/* 433 */     return new WebhookMessageEditMono(
/* 434 */         content(), this.files, this.fileSpoilers, this.embeds, 
/*     */ 
/*     */ 
/*     */         
/* 438 */         allowedMentions(), newValue, this.messageId, this.webhook);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebhookMessageEditMono withComponents(Iterable<LayoutComponent> elements) {
/* 445 */     Possible<List<LayoutComponent>> newValue = Possible.of(
/* 446 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/* 447 */     return new WebhookMessageEditMono(
/* 448 */         content(), this.files, this.fileSpoilers, this.embeds, 
/*     */ 
/*     */ 
/*     */         
/* 452 */         allowedMentions(), newValue, this.messageId, this.webhook);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SafeVarargs
/*     */   public final WebhookMessageEditMono withComponents(LayoutComponent... elements) {
/* 460 */     Possible<List<LayoutComponent>> newValue = Possible.of(Arrays.asList(elements));
/* 461 */     return new WebhookMessageEditMono(
/* 462 */         content(), this.files, this.fileSpoilers, this.embeds, 
/*     */ 
/*     */ 
/*     */         
/* 466 */         allowedMentions(), newValue, this.messageId, this.webhook);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final WebhookMessageEditMono withMessageId(Snowflake value) {
/* 479 */     if (this.messageId == value) return this; 
/* 480 */     Snowflake newValue = Objects.<Snowflake>requireNonNull(value, "messageId");
/* 481 */     return new WebhookMessageEditMono(
/* 482 */         content(), this.files, this.fileSpoilers, this.embeds, 
/*     */ 
/*     */ 
/*     */         
/* 486 */         allowedMentions(), 
/* 487 */         components(), newValue, this.webhook);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final WebhookMessageEditMono withWebhook(Webhook value) {
/* 499 */     if (this.webhook == value) return this; 
/* 500 */     Webhook newValue = Objects.<Webhook>requireNonNull(value, "webhook");
/* 501 */     return new WebhookMessageEditMono(
/* 502 */         content(), this.files, this.fileSpoilers, this.embeds, 
/*     */ 
/*     */ 
/*     */         
/* 506 */         allowedMentions(), 
/* 507 */         components(), this.messageId, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 518 */     if (this == another) return true; 
/* 519 */     return (another instanceof WebhookMessageEditMono && 
/* 520 */       equalTo(0, (WebhookMessageEditMono)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, WebhookMessageEditMono another) {
/* 524 */     return (content().equals(another.content()) && this.files
/* 525 */       .equals(another.files) && this.fileSpoilers
/* 526 */       .equals(another.fileSpoilers) && this.embeds
/* 527 */       .equals(another.embeds) && 
/* 528 */       allowedMentions().equals(another.allowedMentions()) && 
/* 529 */       Objects.equals(this.components_value, another.components_value) && this.messageId
/* 530 */       .equals(another.messageId) && this.webhook
/* 531 */       .equals(another.webhook));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 540 */     int h = 5381;
/* 541 */     h += (h << 5) + content().hashCode();
/* 542 */     h += (h << 5) + this.files.hashCode();
/* 543 */     h += (h << 5) + this.fileSpoilers.hashCode();
/* 544 */     h += (h << 5) + this.embeds.hashCode();
/* 545 */     h += (h << 5) + allowedMentions().hashCode();
/* 546 */     h += (h << 5) + Objects.hashCode(this.components_value);
/* 547 */     h += (h << 5) + this.messageId.hashCode();
/* 548 */     h += (h << 5) + this.webhook.hashCode();
/* 549 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 558 */     return "WebhookMessageEditMono{content=" + 
/* 559 */       content().toString() + ", files=" + this.files + ", fileSpoilers=" + this.fileSpoilers + ", embeds=" + this.embeds + ", allowedMentions=" + 
/*     */ 
/*     */ 
/*     */       
/* 563 */       allowedMentions().toString() + ", components=" + 
/* 564 */       Objects.toString(this.components_value) + ", messageId=" + this.messageId + ", webhook=" + this.webhook + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static WebhookMessageEditMono of(Snowflake messageId, Webhook webhook) {
/* 577 */     return new WebhookMessageEditMono(messageId, webhook);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static WebhookMessageEditMono copyOf(WebhookMessageEditMonoGenerator instance) {
/* 588 */     if (instance instanceof WebhookMessageEditMono) {
/* 589 */       return (WebhookMessageEditMono)instance;
/*     */     }
/* 591 */     return of(instance.messageId(), instance.webhook())
/* 592 */       .withContent(instance.content())
/* 593 */       .withFiles(instance.files())
/* 594 */       .withFileSpoilers(instance.fileSpoilers())
/* 595 */       .withEmbeds(instance.embeds())
/* 596 */       .withAllowedMentions(instance.allowedMentions())
/* 597 */       .withComponents(instance.components());
/*     */   }
/*     */   
/*     */   public boolean isContentPresent() {
/* 601 */     return !this.content_absent;
/*     */   }
/*     */   
/*     */   public String contentOrElse(String defaultValue) {
/* 605 */     return !this.content_absent ? this.content_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isAllowedMentionsPresent() {
/* 609 */     return !this.allowedMentions_absent;
/*     */   }
/*     */   
/*     */   public AllowedMentions allowedMentionsOrElse(AllowedMentions defaultValue) {
/* 613 */     return !this.allowedMentions_absent ? this.allowedMentions_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isComponentsPresent() {
/* 617 */     return !this.components_absent;
/*     */   }
/*     */   
/*     */   public List<LayoutComponent> componentsOrElse(List<LayoutComponent> defaultValue) {
/* 621 */     return !this.components_absent ? this.components_value : defaultValue;
/*     */   }
/*     */   
/*     */   private static <T> List<T> createSafeList(Iterable<? extends T> iterable, boolean checkNulls, boolean skipNulls) {
/*     */     ArrayList<T> list;
/* 626 */     if (iterable instanceof Collection) {
/* 627 */       int size = ((Collection)iterable).size();
/* 628 */       if (size == 0) return Collections.emptyList(); 
/* 629 */       list = new ArrayList<>();
/*     */     } else {
/* 631 */       list = new ArrayList<>();
/*     */     } 
/* 633 */     for (T element : iterable) {
/* 634 */       if (skipNulls && element == null)
/* 635 */         continue;  if (checkNulls) Objects.requireNonNull(element, "element"); 
/* 636 */       list.add(element);
/*     */     } 
/* 638 */     return list;
/*     */   }
/*     */   
/*     */   private static <T> List<T> createUnmodifiableList(boolean clone, List<T> list) {
/* 642 */     switch (list.size()) { case 0:
/* 643 */         return Collections.emptyList();
/* 644 */       case 1: return Collections.singletonList(list.get(0)); }
/*     */     
/* 646 */     if (clone) {
/* 647 */       return Collections.unmodifiableList(new ArrayList<>(list));
/*     */     }
/* 649 */     if (list instanceof ArrayList) {
/* 650 */       ((ArrayList)list).trimToSize();
/*     */     }
/* 652 */     return Collections.unmodifiableList(list);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\WebhookMessageEditMono.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */