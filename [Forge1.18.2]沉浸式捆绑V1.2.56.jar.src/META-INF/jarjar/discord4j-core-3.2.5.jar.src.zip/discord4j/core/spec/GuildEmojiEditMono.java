/*     */ package discord4j.core.spec;
/*     */ 
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.object.entity.GuildEmoji;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.stream.StreamSupport;
/*     */ import org.immutables.value.Generated;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "GuildEmojiEditMonoGenerator", generator = "Immutables")
/*     */ public final class GuildEmojiEditMono
/*     */   extends GuildEmojiEditMonoGenerator
/*     */ {
/*     */   @Nullable
/*     */   private final String reason;
/*     */   private final String name_value;
/*     */   private final boolean name_absent;
/*     */   private final List<Snowflake> roles_value;
/*     */   private final boolean roles_absent;
/*     */   private final GuildEmoji guildEmoji;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   private volatile transient InitShim initShim;
/*     */   
/*     */   private GuildEmojiEditMono(GuildEmoji guildEmoji) {
/*  64 */     this.initShim = new InitShim(); this.guildEmoji = Objects.<GuildEmoji>requireNonNull(guildEmoji, "guildEmoji"); this.reason = null; Possible<String> name$impl = Possible.absent(); Possible<List<Snowflake>> roles$impl = Possible.absent(); this.name_value = name$impl.toOptional().orElse(null); this.name_absent = name$impl.isAbsent(); this.roles_value = roles$impl.toOptional().orElse(null); this.roles_absent = roles$impl.isAbsent(); this.initShim = null; } private GuildEmojiEditMono(@Nullable String reason, Possible<String> name, Possible<List<Snowflake>> roles, GuildEmoji guildEmoji) { this.initShim = new InitShim(); this.reason = reason; Possible<String> name$impl = name; Possible<List<Snowflake>> roles$impl = roles;
/*     */     this.guildEmoji = guildEmoji;
/*     */     this.name_value = name$impl.toOptional().orElse(null);
/*     */     this.name_absent = name$impl.isAbsent();
/*     */     this.roles_value = roles$impl.toOptional().orElse(null);
/*     */     this.roles_absent = roles$impl.isAbsent();
/*  70 */     this.initShim = null; } @Generated(from = "GuildEmojiEditMonoGenerator", generator = "Immutables") private final class InitShim { private InitShim() {} private String formatInitCycleMessage() { List<String> attributes = new ArrayList<>();
/*  71 */       return "Cannot build GuildEmojiEditMono, attribute initializers form cycle " + attributes; }
/*     */      }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String reason() {
/*  81 */     return this.reason;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<String> name() {
/*  89 */     return this.name_absent ? Possible.absent() : Possible.of(this.name_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<List<Snowflake>> roles() {
/*  97 */     return this.roles_absent ? Possible.absent() : 
/*  98 */       Possible.of(this.roles_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GuildEmoji guildEmoji() {
/* 106 */     return this.guildEmoji;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final GuildEmojiEditMono withReason(@Nullable String value) {
/* 116 */     if (Objects.equals(this.reason, value)) return this; 
/* 117 */     return new GuildEmojiEditMono(value, name(), roles(), this.guildEmoji);
/*     */   }
/*     */   
/*     */   public GuildEmojiEditMono withName(Possible<String> value) {
/* 121 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/* 122 */     return new GuildEmojiEditMono(this.reason, newValue, roles(), this.guildEmoji);
/*     */   }
/*     */   
/*     */   public GuildEmojiEditMono withName(String value) {
/* 126 */     Possible<String> newValue = Possible.of(value);
/* 127 */     return new GuildEmojiEditMono(this.reason, newValue, roles(), this.guildEmoji);
/*     */   }
/*     */   
/*     */   public GuildEmojiEditMono withRoles(Possible<List<Snowflake>> possible) {
/* 131 */     Possible<List<Snowflake>> newValue = Objects.<Possible<List<Snowflake>>>requireNonNull(possible);
/* 132 */     return new GuildEmojiEditMono(this.reason, name(), newValue, this.guildEmoji);
/*     */   }
/*     */   
/*     */   public GuildEmojiEditMono withRoles(Iterable<Snowflake> elements) {
/* 136 */     Possible<List<Snowflake>> newValue = Possible.of(
/* 137 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/* 138 */     return new GuildEmojiEditMono(this.reason, name(), newValue, this.guildEmoji);
/*     */   }
/*     */   
/*     */   @SafeVarargs
/*     */   public final GuildEmojiEditMono withRoles(Snowflake... elements) {
/* 143 */     Possible<List<Snowflake>> newValue = Possible.of(Arrays.asList(elements));
/* 144 */     return new GuildEmojiEditMono(this.reason, name(), newValue, this.guildEmoji);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final GuildEmojiEditMono withGuildEmoji(GuildEmoji value) {
/* 154 */     if (this.guildEmoji == value) return this; 
/* 155 */     GuildEmoji newValue = Objects.<GuildEmoji>requireNonNull(value, "guildEmoji");
/* 156 */     return new GuildEmojiEditMono(this.reason, name(), roles(), newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 165 */     if (this == another) return true; 
/* 166 */     return (another instanceof GuildEmojiEditMono && 
/* 167 */       equalTo(0, (GuildEmojiEditMono)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, GuildEmojiEditMono another) {
/* 171 */     return (Objects.equals(this.reason, another.reason) && 
/* 172 */       name().equals(another.name()) && 
/* 173 */       Objects.equals(this.roles_value, another.roles_value) && this.guildEmoji
/* 174 */       .equals(another.guildEmoji));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 183 */     int h = 5381;
/* 184 */     h += (h << 5) + Objects.hashCode(this.reason);
/* 185 */     h += (h << 5) + name().hashCode();
/* 186 */     h += (h << 5) + Objects.hashCode(this.roles_value);
/* 187 */     h += (h << 5) + this.guildEmoji.hashCode();
/* 188 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 197 */     return "GuildEmojiEditMono{reason=" + this.reason + ", name=" + 
/*     */       
/* 199 */       name().toString() + ", roles=" + 
/* 200 */       Objects.toString(this.roles_value) + ", guildEmoji=" + this.guildEmoji + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static GuildEmojiEditMono of(GuildEmoji guildEmoji) {
/* 211 */     return new GuildEmojiEditMono(guildEmoji);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static GuildEmojiEditMono copyOf(GuildEmojiEditMonoGenerator instance) {
/* 222 */     if (instance instanceof GuildEmojiEditMono) {
/* 223 */       return (GuildEmojiEditMono)instance;
/*     */     }
/* 225 */     return of(instance.guildEmoji())
/* 226 */       .withReason(instance.reason())
/* 227 */       .withName(instance.name())
/* 228 */       .withRoles(instance.roles());
/*     */   }
/*     */   
/*     */   public boolean isNamePresent() {
/* 232 */     return !this.name_absent;
/*     */   }
/*     */   
/*     */   public String nameOrElse(String defaultValue) {
/* 236 */     return !this.name_absent ? this.name_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isRolesPresent() {
/* 240 */     return !this.roles_absent;
/*     */   }
/*     */   
/*     */   public List<Snowflake> rolesOrElse(List<Snowflake> defaultValue) {
/* 244 */     return !this.roles_absent ? this.roles_value : defaultValue;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\GuildEmojiEditMono.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */