/*    */ package discord4j.core.spec;
/*    */ 
/*    */ import discord4j.core.object.audit.AuditLogPart;
/*    */ import discord4j.core.object.entity.Guild;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ import reactor.core.CoreSubscriber;
/*    */ import reactor.core.publisher.Flux;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Immutable(builder = false)
/*    */ abstract class AuditLogQueryFluxGenerator
/*    */   extends Flux<AuditLogPart>
/*    */   implements AuditLogQuerySpecGenerator
/*    */ {
/*    */   abstract Guild guild();
/*    */   
/*    */   public void subscribe(CoreSubscriber<? super AuditLogPart> actual) {
/* 70 */     guild().getAuditLog(AuditLogQuerySpec.copyOf(this)).subscribe(actual);
/*    */   }
/*    */   
/*    */   public abstract String toString();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\AuditLogQueryFluxGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */