/*     */ package discord4j.core.spec;
/*     */ 
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.object.automod.AutoModRule;
/*     */ import discord4j.discordjson.json.AutoModActionData;
/*     */ import discord4j.discordjson.json.AutoModTriggerMetaData;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "AutoModRuleEditMonoGenerator", generator = "Immutables")
/*     */ public final class AutoModRuleEditMono
/*     */   extends AutoModRuleEditMonoGenerator
/*     */ {
/*     */   @Nullable
/*     */   private final String reason;
/*     */   private final String name;
/*     */   private final int eventType;
/*     */   private final AutoModTriggerMetaData triggerMetaData_value;
/*     */   private final boolean triggerMetaData_absent;
/*     */   private final List<AutoModActionData> actions;
/*     */   private final boolean enabled;
/*     */   private final List<Snowflake> exemptRoles;
/*     */   private final List<Snowflake> exemptChannels;
/*     */   private final AutoModRule autoModRule;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   private volatile transient InitShim initShim;
/*     */   
/*     */   private AutoModRuleEditMono(String name, int eventType, boolean enabled, AutoModRule autoModRule) {
/*  88 */     this.initShim = new InitShim(); this.name = Objects.<String>requireNonNull(name, "name"); this.eventType = eventType; this.enabled = enabled; this.autoModRule = Objects.<AutoModRule>requireNonNull(autoModRule, "autoModRule"); this.reason = null; Possible<AutoModTriggerMetaData> triggerMetaData$impl = Possible.absent(); this.triggerMetaData_value = triggerMetaData$impl.toOptional().orElse(null); this.triggerMetaData_absent = triggerMetaData$impl.isAbsent(); this.actions = this.initShim.actions(); this.exemptRoles = this.initShim.exemptRoles(); this.exemptChannels = this.initShim.exemptChannels(); this.initShim = null; } private AutoModRuleEditMono(@Nullable String reason, String name, int eventType, Possible<AutoModTriggerMetaData> triggerMetaData, List<AutoModActionData> actions, boolean enabled, List<Snowflake> exemptRoles, List<Snowflake> exemptChannels, AutoModRule autoModRule) { this.initShim = new InitShim(); this.reason = reason; this.name = name; this.eventType = eventType; Possible<AutoModTriggerMetaData> triggerMetaData$impl = triggerMetaData; this.initShim.actions(actions); this.enabled = enabled; this.initShim.exemptRoles(exemptRoles); this.initShim.exemptChannels(exemptChannels); this.autoModRule = autoModRule; this.triggerMetaData_value = triggerMetaData$impl.toOptional().orElse(null);
/*     */     this.triggerMetaData_absent = triggerMetaData$impl.isAbsent();
/*     */     this.actions = this.initShim.actions();
/*     */     this.exemptRoles = this.initShim.exemptRoles();
/*     */     this.exemptChannels = this.initShim.exemptChannels();
/*  93 */     this.initShim = null; } @Generated(from = "AutoModRuleEditMonoGenerator", generator = "Immutables") private final class InitShim { private byte actionsBuildStage = 0;
/*     */     private List<AutoModActionData> actions;
/*     */     
/*     */     List<AutoModActionData> actions() {
/*  97 */       if (this.actionsBuildStage == -1) throw new IllegalStateException(formatInitCycleMessage()); 
/*  98 */       if (this.actionsBuildStage == 0) {
/*  99 */         this.actionsBuildStage = -1;
/* 100 */         this.actions = (List)AutoModRuleEditMono.createUnmodifiableList(false, AutoModRuleEditMono.createSafeList((Iterable)AutoModRuleEditMono.this.actions(), true, false));
/* 101 */         this.actionsBuildStage = 1;
/*     */       } 
/* 103 */       return this.actions;
/*     */     }
/*     */     
/*     */     void actions(List<AutoModActionData> actions) {
/* 107 */       this.actions = actions;
/* 108 */       this.actionsBuildStage = 1;
/*     */     }
/*     */     
/* 111 */     private byte exemptRolesBuildStage = 0;
/*     */     private List<Snowflake> exemptRoles;
/*     */     
/*     */     List<Snowflake> exemptRoles() {
/* 115 */       if (this.exemptRolesBuildStage == -1) throw new IllegalStateException(formatInitCycleMessage()); 
/* 116 */       if (this.exemptRolesBuildStage == 0) {
/* 117 */         this.exemptRolesBuildStage = -1;
/* 118 */         this.exemptRoles = (List)AutoModRuleEditMono.createUnmodifiableList(false, AutoModRuleEditMono.createSafeList((Iterable)AutoModRuleEditMono.this.exemptRoles(), true, false));
/* 119 */         this.exemptRolesBuildStage = 1;
/*     */       } 
/* 121 */       return this.exemptRoles;
/*     */     }
/*     */     
/*     */     void exemptRoles(List<Snowflake> exemptRoles) {
/* 125 */       this.exemptRoles = exemptRoles;
/* 126 */       this.exemptRolesBuildStage = 1;
/*     */     }
/*     */     
/* 129 */     private byte exemptChannelsBuildStage = 0;
/*     */     private List<Snowflake> exemptChannels;
/*     */     
/*     */     List<Snowflake> exemptChannels() {
/* 133 */       if (this.exemptChannelsBuildStage == -1) throw new IllegalStateException(formatInitCycleMessage()); 
/* 134 */       if (this.exemptChannelsBuildStage == 0) {
/* 135 */         this.exemptChannelsBuildStage = -1;
/* 136 */         this.exemptChannels = (List)AutoModRuleEditMono.createUnmodifiableList(false, AutoModRuleEditMono.createSafeList((Iterable)AutoModRuleEditMono.this.exemptChannels(), true, false));
/* 137 */         this.exemptChannelsBuildStage = 1;
/*     */       } 
/* 139 */       return this.exemptChannels;
/*     */     }
/*     */     
/*     */     void exemptChannels(List<Snowflake> exemptChannels) {
/* 143 */       this.exemptChannels = exemptChannels;
/* 144 */       this.exemptChannelsBuildStage = 1;
/*     */     }
/*     */     
/*     */     private String formatInitCycleMessage() {
/* 148 */       List<String> attributes = new ArrayList<>();
/* 149 */       if (this.actionsBuildStage == -1) attributes.add("actions"); 
/* 150 */       if (this.exemptRolesBuildStage == -1) attributes.add("exemptRoles"); 
/* 151 */       if (this.exemptChannelsBuildStage == -1) attributes.add("exemptChannels"); 
/* 152 */       return "Cannot build AutoModRuleEditMono, attribute initializers form cycle " + attributes;
/*     */     }
/*     */ 
/*     */     
/*     */     private InitShim() {} }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String reason() {
/* 162 */     return this.reason;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String name() {
/* 170 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int eventType() {
/* 178 */     return this.eventType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<AutoModTriggerMetaData> triggerMetaData() {
/* 186 */     return this.triggerMetaData_absent ? Possible.absent() : Possible.of(this.triggerMetaData_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<AutoModActionData> actions() {
/* 194 */     InitShim shim = this.initShim;
/* 195 */     return (shim != null) ? 
/* 196 */       shim.actions() : 
/* 197 */       this.actions;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean enabled() {
/* 205 */     return this.enabled;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Snowflake> exemptRoles() {
/* 213 */     InitShim shim = this.initShim;
/* 214 */     return (shim != null) ? 
/* 215 */       shim.exemptRoles() : 
/* 216 */       this.exemptRoles;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Snowflake> exemptChannels() {
/* 224 */     InitShim shim = this.initShim;
/* 225 */     return (shim != null) ? 
/* 226 */       shim.exemptChannels() : 
/* 227 */       this.exemptChannels;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AutoModRule autoModRule() {
/* 235 */     return this.autoModRule;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final AutoModRuleEditMono withReason(@Nullable String value) {
/* 245 */     if (Objects.equals(this.reason, value)) return this; 
/* 246 */     return new AutoModRuleEditMono(value, this.name, this.eventType, 
/*     */ 
/*     */ 
/*     */         
/* 250 */         triggerMetaData(), this.actions, this.enabled, this.exemptRoles, this.exemptChannels, this.autoModRule);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final AutoModRuleEditMono withName(String value) {
/* 265 */     String newValue = Objects.<String>requireNonNull(value, "name");
/* 266 */     if (this.name.equals(newValue)) return this; 
/* 267 */     return new AutoModRuleEditMono(this.reason, newValue, this.eventType, 
/*     */ 
/*     */ 
/*     */         
/* 271 */         triggerMetaData(), this.actions, this.enabled, this.exemptRoles, this.exemptChannels, this.autoModRule);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final AutoModRuleEditMono withEventType(int value) {
/* 286 */     if (this.eventType == value) return this; 
/* 287 */     return new AutoModRuleEditMono(this.reason, this.name, value, 
/*     */ 
/*     */ 
/*     */         
/* 291 */         triggerMetaData(), this.actions, this.enabled, this.exemptRoles, this.exemptChannels, this.autoModRule);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AutoModRuleEditMono withTriggerMetaData(Possible<AutoModTriggerMetaData> value) {
/* 300 */     Possible<AutoModTriggerMetaData> newValue = Objects.<Possible<AutoModTriggerMetaData>>requireNonNull(value);
/* 301 */     return new AutoModRuleEditMono(this.reason, this.name, this.eventType, newValue, this.actions, this.enabled, this.exemptRoles, this.exemptChannels, this.autoModRule);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AutoModRuleEditMono withTriggerMetaData(AutoModTriggerMetaData value) {
/* 314 */     Possible<AutoModTriggerMetaData> newValue = Possible.of(value);
/* 315 */     return new AutoModRuleEditMono(this.reason, this.name, this.eventType, newValue, this.actions, this.enabled, this.exemptRoles, this.exemptChannels, this.autoModRule);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final AutoModRuleEditMono withActions(AutoModActionData... elements) {
/* 333 */     List<AutoModActionData> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/* 334 */     return new AutoModRuleEditMono(this.reason, this.name, this.eventType, 
/*     */ 
/*     */ 
/*     */         
/* 338 */         triggerMetaData(), newValue, this.enabled, this.exemptRoles, this.exemptChannels, this.autoModRule);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final AutoModRuleEditMono withActions(Iterable<? extends AutoModActionData> elements) {
/* 353 */     if (this.actions == elements) return this; 
/* 354 */     List<AutoModActionData> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/* 355 */     return new AutoModRuleEditMono(this.reason, this.name, this.eventType, 
/*     */ 
/*     */ 
/*     */         
/* 359 */         triggerMetaData(), newValue, this.enabled, this.exemptRoles, this.exemptChannels, this.autoModRule);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final AutoModRuleEditMono withEnabled(boolean value) {
/* 374 */     if (this.enabled == value) return this; 
/* 375 */     return new AutoModRuleEditMono(this.reason, this.name, this.eventType, 
/*     */ 
/*     */ 
/*     */         
/* 379 */         triggerMetaData(), this.actions, value, this.exemptRoles, this.exemptChannels, this.autoModRule);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final AutoModRuleEditMono withExemptRoles(Snowflake... elements) {
/* 393 */     List<Snowflake> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/* 394 */     return new AutoModRuleEditMono(this.reason, this.name, this.eventType, 
/*     */ 
/*     */ 
/*     */         
/* 398 */         triggerMetaData(), this.actions, this.enabled, newValue, this.exemptChannels, this.autoModRule);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final AutoModRuleEditMono withExemptRoles(Iterable<? extends Snowflake> elements) {
/* 413 */     if (this.exemptRoles == elements) return this; 
/* 414 */     List<Snowflake> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/* 415 */     return new AutoModRuleEditMono(this.reason, this.name, this.eventType, 
/*     */ 
/*     */ 
/*     */         
/* 419 */         triggerMetaData(), this.actions, this.enabled, newValue, this.exemptChannels, this.autoModRule);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final AutoModRuleEditMono withExemptChannels(Snowflake... elements) {
/* 433 */     List<Snowflake> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/* 434 */     return new AutoModRuleEditMono(this.reason, this.name, this.eventType, 
/*     */ 
/*     */ 
/*     */         
/* 438 */         triggerMetaData(), this.actions, this.enabled, this.exemptRoles, newValue, this.autoModRule);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final AutoModRuleEditMono withExemptChannels(Iterable<? extends Snowflake> elements) {
/* 453 */     if (this.exemptChannels == elements) return this; 
/* 454 */     List<Snowflake> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/* 455 */     return new AutoModRuleEditMono(this.reason, this.name, this.eventType, 
/*     */ 
/*     */ 
/*     */         
/* 459 */         triggerMetaData(), this.actions, this.enabled, this.exemptRoles, newValue, this.autoModRule);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final AutoModRuleEditMono withAutoModRule(AutoModRule value) {
/* 474 */     if (this.autoModRule == value) return this; 
/* 475 */     AutoModRule newValue = Objects.<AutoModRule>requireNonNull(value, "autoModRule");
/* 476 */     return new AutoModRuleEditMono(this.reason, this.name, this.eventType, 
/*     */ 
/*     */ 
/*     */         
/* 480 */         triggerMetaData(), this.actions, this.enabled, this.exemptRoles, this.exemptChannels, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 494 */     if (this == another) return true; 
/* 495 */     return (another instanceof AutoModRuleEditMono && 
/* 496 */       equalTo(0, (AutoModRuleEditMono)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, AutoModRuleEditMono another) {
/* 500 */     return (Objects.equals(this.reason, another.reason) && this.name
/* 501 */       .equals(another.name) && this.eventType == another.eventType && 
/*     */       
/* 503 */       triggerMetaData().equals(another.triggerMetaData()) && this.actions
/* 504 */       .equals(another.actions) && this.enabled == another.enabled && this.exemptRoles
/*     */       
/* 506 */       .equals(another.exemptRoles) && this.exemptChannels
/* 507 */       .equals(another.exemptChannels) && this.autoModRule
/* 508 */       .equals(another.autoModRule));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 517 */     int h = 5381;
/* 518 */     h += (h << 5) + Objects.hashCode(this.reason);
/* 519 */     h += (h << 5) + this.name.hashCode();
/* 520 */     h += (h << 5) + this.eventType;
/* 521 */     h += (h << 5) + triggerMetaData().hashCode();
/* 522 */     h += (h << 5) + this.actions.hashCode();
/* 523 */     h += (h << 5) + Boolean.hashCode(this.enabled);
/* 524 */     h += (h << 5) + this.exemptRoles.hashCode();
/* 525 */     h += (h << 5) + this.exemptChannels.hashCode();
/* 526 */     h += (h << 5) + this.autoModRule.hashCode();
/* 527 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 536 */     return "AutoModRuleEditMono{reason=" + this.reason + ", name=" + this.name + ", eventType=" + this.eventType + ", triggerMetaData=" + 
/*     */ 
/*     */ 
/*     */       
/* 540 */       triggerMetaData().toString() + ", actions=" + this.actions + ", enabled=" + this.enabled + ", exemptRoles=" + this.exemptRoles + ", exemptChannels=" + this.exemptChannels + ", autoModRule=" + this.autoModRule + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AutoModRuleEditMono of(String name, int eventType, boolean enabled, AutoModRule autoModRule) {
/* 558 */     return new AutoModRuleEditMono(name, eventType, enabled, autoModRule);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static AutoModRuleEditMono copyOf(AutoModRuleEditMonoGenerator instance) {
/* 569 */     if (instance instanceof AutoModRuleEditMono) {
/* 570 */       return (AutoModRuleEditMono)instance;
/*     */     }
/* 572 */     return of(instance.name(), instance.eventType(), instance.enabled(), instance.autoModRule())
/* 573 */       .withReason(instance.reason())
/* 574 */       .withTriggerMetaData(instance.triggerMetaData())
/* 575 */       .withActions(instance.actions())
/* 576 */       .withExemptRoles(instance.exemptRoles())
/* 577 */       .withExemptChannels(instance.exemptChannels());
/*     */   }
/*     */   
/*     */   public boolean isTriggerMetaDataPresent() {
/* 581 */     return !this.triggerMetaData_absent;
/*     */   }
/*     */   
/*     */   public AutoModTriggerMetaData triggerMetaDataOrElse(AutoModTriggerMetaData defaultValue) {
/* 585 */     return !this.triggerMetaData_absent ? this.triggerMetaData_value : defaultValue;
/*     */   }
/*     */   
/*     */   private static <T> List<T> createSafeList(Iterable<? extends T> iterable, boolean checkNulls, boolean skipNulls) {
/*     */     ArrayList<T> list;
/* 590 */     if (iterable instanceof Collection) {
/* 591 */       int size = ((Collection)iterable).size();
/* 592 */       if (size == 0) return Collections.emptyList(); 
/* 593 */       list = new ArrayList<>();
/*     */     } else {
/* 595 */       list = new ArrayList<>();
/*     */     } 
/* 597 */     for (T element : iterable) {
/* 598 */       if (skipNulls && element == null)
/* 599 */         continue;  if (checkNulls) Objects.requireNonNull(element, "element"); 
/* 600 */       list.add(element);
/*     */     } 
/* 602 */     return list;
/*     */   }
/*     */   
/*     */   private static <T> List<T> createUnmodifiableList(boolean clone, List<T> list) {
/* 606 */     switch (list.size()) { case 0:
/* 607 */         return Collections.emptyList();
/* 608 */       case 1: return Collections.singletonList(list.get(0)); }
/*     */     
/* 610 */     if (clone) {
/* 611 */       return Collections.unmodifiableList(new ArrayList<>(list));
/*     */     }
/* 613 */     if (list instanceof ArrayList) {
/* 614 */       ((ArrayList)list).trimToSize();
/*     */     }
/* 616 */     return Collections.unmodifiableList(list);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\AutoModRuleEditMono.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */