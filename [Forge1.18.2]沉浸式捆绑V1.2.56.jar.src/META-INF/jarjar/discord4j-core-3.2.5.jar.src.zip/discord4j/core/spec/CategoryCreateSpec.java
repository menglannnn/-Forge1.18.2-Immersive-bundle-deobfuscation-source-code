/*     */ package discord4j.core.spec;
/*     */ 
/*     */ import com.google.errorprone.annotations.CanIgnoreReturnValue;
/*     */ import discord4j.core.object.PermissionOverwrite;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.stream.StreamSupport;
/*     */ import org.immutables.value.Generated;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "CategoryCreateSpecGenerator", generator = "Immutables")
/*     */ public final class CategoryCreateSpec
/*     */   implements CategoryCreateSpecGenerator
/*     */ {
/*     */   @Nullable
/*     */   private final String reason;
/*     */   private final String name;
/*     */   private final Integer position_value;
/*     */   private final boolean position_absent;
/*     */   private final List<PermissionOverwrite> permissionOverwrites_value;
/*     */   private final boolean permissionOverwrites_absent;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   private volatile transient InitShim initShim;
/*     */   
/*     */   private CategoryCreateSpec(String name) {
/*  66 */     this.initShim = new InitShim(); this.name = Objects.<String>requireNonNull(name, "name"); this.reason = null; Possible<Integer> position$impl = Possible.absent(); Possible<List<PermissionOverwrite>> permissionOverwrites$impl = Possible.absent(); this.position_value = position$impl.toOptional().orElse(null); this.position_absent = position$impl.isAbsent(); this.permissionOverwrites_value = permissionOverwrites$impl.toOptional().orElse(null); this.permissionOverwrites_absent = permissionOverwrites$impl.isAbsent(); this.initShim = null; } private CategoryCreateSpec(@Nullable String reason, String name, Possible<Integer> position, Possible<List<PermissionOverwrite>> permissionOverwrites) { this.initShim = new InitShim(); this.reason = reason; this.name = name; Possible<Integer> position$impl = position;
/*     */     Possible<List<PermissionOverwrite>> permissionOverwrites$impl = permissionOverwrites;
/*     */     this.position_value = position$impl.toOptional().orElse(null);
/*     */     this.position_absent = position$impl.isAbsent();
/*     */     this.permissionOverwrites_value = permissionOverwrites$impl.toOptional().orElse(null);
/*     */     this.permissionOverwrites_absent = permissionOverwrites$impl.isAbsent();
/*  72 */     this.initShim = null; } @Generated(from = "CategoryCreateSpecGenerator", generator = "Immutables") private final class InitShim { private InitShim() {} private String formatInitCycleMessage() { List<String> attributes = new ArrayList<>();
/*  73 */       return "Cannot build CategoryCreateSpec, attribute initializers form cycle " + attributes; }
/*     */      }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String reason() {
/*  83 */     return this.reason;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String name() {
/*  91 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Integer> position() {
/*  99 */     return this.position_absent ? Possible.absent() : Possible.of(this.position_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<List<PermissionOverwrite>> permissionOverwrites() {
/* 107 */     return this.permissionOverwrites_absent ? Possible.absent() : 
/* 108 */       Possible.of(this.permissionOverwrites_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final CategoryCreateSpec withReason(@Nullable String value) {
/* 118 */     if (Objects.equals(this.reason, value)) return this; 
/* 119 */     return new CategoryCreateSpec(value, this.name, position(), permissionOverwrites());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final CategoryCreateSpec withName(String value) {
/* 129 */     String newValue = Objects.<String>requireNonNull(value, "name");
/* 130 */     if (this.name.equals(newValue)) return this; 
/* 131 */     return new CategoryCreateSpec(this.reason, newValue, position(), permissionOverwrites());
/*     */   }
/*     */   
/*     */   public CategoryCreateSpec withPosition(Possible<Integer> value) {
/* 135 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/* 136 */     return new CategoryCreateSpec(this.reason, this.name, newValue, permissionOverwrites());
/*     */   }
/*     */   
/*     */   public CategoryCreateSpec withPosition(Integer value) {
/* 140 */     Possible<Integer> newValue = Possible.of(value);
/* 141 */     return new CategoryCreateSpec(this.reason, this.name, newValue, permissionOverwrites());
/*     */   }
/*     */   
/*     */   public CategoryCreateSpec withPermissionOverwrites(Possible<List<PermissionOverwrite>> possible) {
/* 145 */     Possible<List<PermissionOverwrite>> newValue = Objects.<Possible<List<PermissionOverwrite>>>requireNonNull(possible);
/* 146 */     return new CategoryCreateSpec(this.reason, this.name, position(), newValue);
/*     */   }
/*     */   
/*     */   public CategoryCreateSpec withPermissionOverwrites(Iterable<PermissionOverwrite> elements) {
/* 150 */     Possible<List<PermissionOverwrite>> newValue = Possible.of(
/* 151 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/* 152 */     return new CategoryCreateSpec(this.reason, this.name, position(), newValue);
/*     */   }
/*     */   
/*     */   @SafeVarargs
/*     */   public final CategoryCreateSpec withPermissionOverwrites(PermissionOverwrite... elements) {
/* 157 */     Possible<List<PermissionOverwrite>> newValue = Possible.of(Arrays.asList(elements));
/* 158 */     return new CategoryCreateSpec(this.reason, this.name, position(), newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 167 */     if (this == another) return true; 
/* 168 */     return (another instanceof CategoryCreateSpec && 
/* 169 */       equalTo(0, (CategoryCreateSpec)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, CategoryCreateSpec another) {
/* 173 */     return (Objects.equals(this.reason, another.reason) && this.name
/* 174 */       .equals(another.name) && 
/* 175 */       position().equals(another.position()) && 
/* 176 */       Objects.equals(this.permissionOverwrites_value, another.permissionOverwrites_value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 185 */     int h = 5381;
/* 186 */     h += (h << 5) + Objects.hashCode(this.reason);
/* 187 */     h += (h << 5) + this.name.hashCode();
/* 188 */     h += (h << 5) + position().hashCode();
/* 189 */     h += (h << 5) + Objects.hashCode(this.permissionOverwrites_value);
/* 190 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 199 */     return "CategoryCreateSpec{reason=" + this.reason + ", name=" + this.name + ", position=" + 
/*     */ 
/*     */       
/* 202 */       position().toString() + ", permissionOverwrites=" + 
/* 203 */       Objects.toString(this.permissionOverwrites_value) + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CategoryCreateSpec of(String name) {
/* 213 */     return new CategoryCreateSpec(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static CategoryCreateSpec copyOf(CategoryCreateSpecGenerator instance) {
/* 224 */     if (instance instanceof CategoryCreateSpec) {
/* 225 */       return (CategoryCreateSpec)instance;
/*     */     }
/* 227 */     return builder()
/* 228 */       .from(instance)
/* 229 */       .build();
/*     */   }
/*     */   
/*     */   public boolean isPositionPresent() {
/* 233 */     return !this.position_absent;
/*     */   }
/*     */   
/*     */   public Integer positionOrElse(Integer defaultValue) {
/* 237 */     return !this.position_absent ? this.position_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isPermissionOverwritesPresent() {
/* 241 */     return !this.permissionOverwrites_absent;
/*     */   }
/*     */   
/*     */   public List<PermissionOverwrite> permissionOverwritesOrElse(List<PermissionOverwrite> defaultValue) {
/* 245 */     return !this.permissionOverwrites_absent ? this.permissionOverwrites_value : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 261 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "CategoryCreateSpecGenerator", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_NAME = 1L;
/*     */ 
/*     */ 
/*     */     
/* 274 */     private long initBits = 1L;
/*     */     
/* 276 */     private Possible<Integer> position_possible = Possible.absent();
/* 277 */     private List<PermissionOverwrite> permissionOverwrites_list = null;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private String reason;
/*     */ 
/*     */ 
/*     */     
/*     */     private String name;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(CategoryCreateSpec instance) {
/* 292 */       return from(instance);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     final Builder from(CategoryCreateSpecGenerator instance) {
/* 302 */       Objects.requireNonNull(instance, "instance");
/* 303 */       String reasonValue = instance.reason();
/* 304 */       if (reasonValue != null) {
/* 305 */         reason(reasonValue);
/*     */       }
/* 307 */       name(instance.name());
/* 308 */       position(instance.position());
/* 309 */       permissionOverwrites(instance.permissionOverwrites());
/* 310 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder reason(@Nullable String reason) {
/* 320 */       this.reason = reason;
/* 321 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder name(String name) {
/* 331 */       this.name = Objects.<String>requireNonNull(name, "name");
/* 332 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 333 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder position(Possible<Integer> value) {
/* 338 */       this.position_possible = value;
/* 339 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder position(Integer value) {
/* 344 */       this.position_possible = Possible.of(value);
/* 345 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder addPermissionOverwrite(PermissionOverwrite element) {
/* 350 */       permissionOverwrites_getOrCreate().add(element);
/* 351 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder addAllPermissionOverwrites(List<PermissionOverwrite> elements) {
/* 356 */       permissionOverwrites_getOrCreate().addAll(elements);
/* 357 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder permissionOverwrites(Possible<List<PermissionOverwrite>> elements) {
/* 362 */       this.permissionOverwrites_list = null;
/* 363 */       elements.toOptional().ifPresent(e -> permissionOverwrites_getOrCreate().addAll(e));
/* 364 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder permissionOverwrites(List<PermissionOverwrite> elements) {
/* 369 */       this.permissionOverwrites_list = new ArrayList<>(elements);
/* 370 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder permissionOverwrites(Iterable<PermissionOverwrite> elements) {
/* 375 */       this.permissionOverwrites_list = (List<PermissionOverwrite>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/* 376 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public CategoryCreateSpec build() {
/* 385 */       if (this.initBits != 0L) {
/* 386 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 388 */       return new CategoryCreateSpec(this.reason, this.name, position_build(), permissionOverwrites_build());
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 392 */       List<String> attributes = new ArrayList<>();
/* 393 */       if ((this.initBits & 0x1L) != 0L) attributes.add("name"); 
/* 394 */       return "Cannot build CategoryCreateSpec, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Possible<Integer> position_build() {
/* 398 */       return this.position_possible;
/*     */     }
/*     */     
/*     */     private Possible<List<PermissionOverwrite>> permissionOverwrites_build() {
/* 402 */       return (this.permissionOverwrites_list == null) ? Possible.absent() : 
/* 403 */         Possible.of(this.permissionOverwrites_list);
/*     */     }
/*     */     
/*     */     private List<PermissionOverwrite> permissionOverwrites_getOrCreate() {
/* 407 */       if (this.permissionOverwrites_list == null) {
/* 408 */         this.permissionOverwrites_list = new ArrayList<>();
/*     */       }
/* 410 */       return this.permissionOverwrites_list;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\CategoryCreateSpec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */