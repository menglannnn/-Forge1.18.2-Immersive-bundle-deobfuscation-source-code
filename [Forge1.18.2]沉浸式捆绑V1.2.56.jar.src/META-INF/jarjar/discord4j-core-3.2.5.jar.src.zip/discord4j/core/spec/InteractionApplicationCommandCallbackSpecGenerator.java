/*    */ package discord4j.core.spec;
/*    */ 
/*    */ import discord4j.core.object.component.LayoutComponent;
/*    */ import discord4j.core.object.component.MessageComponent;
/*    */ import discord4j.core.object.entity.Message;
/*    */ import discord4j.discordjson.json.ImmutableInteractionApplicationCommandCallbackData;
/*    */ import discord4j.discordjson.json.InteractionApplicationCommandCallbackData;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import discord4j.rest.util.AllowedMentions;
/*    */ import discord4j.rest.util.MultipartRequest;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import java.util.stream.Collectors;
/*    */ import java.util.stream.Stream;
/*    */ import org.immutables.value.Value.Default;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Immutable(singleton = true)
/*    */ interface InteractionApplicationCommandCallbackSpecGenerator
/*    */   extends Spec<MultipartRequest<InteractionApplicationCommandCallbackData>>
/*    */ {
/*    */   @Default
/*    */   default List<MessageCreateFields.File> files() {
/* 52 */     return Collections.emptyList();
/*    */   }
/*    */   
/*    */   @Default
/*    */   default List<MessageCreateFields.FileSpoiler> fileSpoilers() {
/* 57 */     return Collections.emptyList();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   default MultipartRequest<InteractionApplicationCommandCallbackData> asRequest() {
/* 77 */     ImmutableInteractionApplicationCommandCallbackData immutableInteractionApplicationCommandCallbackData = InteractionApplicationCommandCallbackData.builder().content(content()).tts(tts()).flags(InternalSpecUtils.mapPossible(ephemeral(), eph -> Integer.valueOf(eph.booleanValue() ? Message.Flag.EPHEMERAL.getFlag() : 0))).embeds(InternalSpecUtils.mapPossible(embeds(), embeds -> (List)embeds.stream().map(EmbedCreateSpecGenerator::asRequest).collect(Collectors.toList()))).components(InternalSpecUtils.mapPossible(components(), components -> (List)components.stream().map(MessageComponent::getData).collect(Collectors.toList()))).allowedMentions(InternalSpecUtils.mapPossible(allowedMentions(), AllowedMentions::toData)).build();
/* 78 */     return MultipartRequest.ofRequestAndFiles(immutableInteractionApplicationCommandCallbackData, (List)Stream.concat(files().stream(), fileSpoilers().stream())
/* 79 */         .map(MessageCreateFields.File::asRequest)
/* 80 */         .collect(Collectors.toList()));
/*    */   }
/*    */   
/*    */   Possible<String> content();
/*    */   
/*    */   Possible<Boolean> tts();
/*    */   
/*    */   Possible<Boolean> ephemeral();
/*    */   
/*    */   Possible<List<EmbedCreateSpec>> embeds();
/*    */   
/*    */   Possible<AllowedMentions> allowedMentions();
/*    */   
/*    */   Possible<List<LayoutComponent>> components();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\InteractionApplicationCommandCallbackSpecGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */