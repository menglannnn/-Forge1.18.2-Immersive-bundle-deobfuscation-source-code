/*     */ package discord4j.core.spec;
/*     */ 
/*     */ import discord4j.core.object.GuildTemplate;
/*     */ import discord4j.core.object.entity.Guild;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import discord4j.rest.util.Image;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ import reactor.core.CoreSubscriber;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "GuildCreateFromTemplateMonoGenerator", generator = "Immutables")
/*     */ public final class GuildCreateFromTemplateMono
/*     */   extends GuildCreateFromTemplateMonoGenerator
/*     */ {
/*     */   private final String name;
/*     */   private final Image icon_value;
/*     */   private final boolean icon_absent;
/*     */   private final GuildTemplate guildTemplate;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   private volatile transient InitShim initShim;
/*     */   
/*     */   private GuildCreateFromTemplateMono(String name, GuildTemplate guildTemplate) {
/*  52 */     this.initShim = new InitShim(); this.name = Objects.<String>requireNonNull(name, "name"); this.guildTemplate = Objects.<GuildTemplate>requireNonNull(guildTemplate, "guildTemplate"); Possible<Image> icon$impl = Possible.absent(); this.icon_value = icon$impl.toOptional().orElse(null); this.icon_absent = icon$impl.isAbsent(); this.initShim = null; } private GuildCreateFromTemplateMono(String name, Possible<Image> icon, GuildTemplate guildTemplate) { this.initShim = new InitShim();
/*     */     this.name = name;
/*     */     Possible<Image> icon$impl = icon;
/*     */     this.guildTemplate = guildTemplate;
/*     */     this.icon_value = icon$impl.toOptional().orElse(null);
/*     */     this.icon_absent = icon$impl.isAbsent();
/*  58 */     this.initShim = null; } @Generated(from = "GuildCreateFromTemplateMonoGenerator", generator = "Immutables") private final class InitShim { private InitShim() {} private String formatInitCycleMessage() { List<String> attributes = new ArrayList<>();
/*  59 */       return "Cannot build GuildCreateFromTemplateMono, attribute initializers form cycle " + attributes; }
/*     */      }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String name() {
/*  68 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Image> icon() {
/*  76 */     return this.icon_absent ? Possible.absent() : Possible.of(this.icon_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GuildTemplate guildTemplate() {
/*  84 */     return this.guildTemplate;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final GuildCreateFromTemplateMono withName(String value) {
/*  94 */     String newValue = Objects.<String>requireNonNull(value, "name");
/*  95 */     if (this.name.equals(newValue)) return this; 
/*  96 */     return new GuildCreateFromTemplateMono(newValue, icon(), this.guildTemplate);
/*     */   }
/*     */   
/*     */   public GuildCreateFromTemplateMono withIcon(Possible<Image> value) {
/* 100 */     Possible<Image> newValue = Objects.<Possible<Image>>requireNonNull(value);
/* 101 */     return new GuildCreateFromTemplateMono(this.name, newValue, this.guildTemplate);
/*     */   }
/*     */   
/*     */   public GuildCreateFromTemplateMono withIcon(Image value) {
/* 105 */     Possible<Image> newValue = Possible.of(value);
/* 106 */     return new GuildCreateFromTemplateMono(this.name, newValue, this.guildTemplate);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final GuildCreateFromTemplateMono withGuildTemplate(GuildTemplate value) {
/* 116 */     if (this.guildTemplate == value) return this; 
/* 117 */     GuildTemplate newValue = Objects.<GuildTemplate>requireNonNull(value, "guildTemplate");
/* 118 */     return new GuildCreateFromTemplateMono(this.name, icon(), newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 127 */     if (this == another) return true; 
/* 128 */     return (another instanceof GuildCreateFromTemplateMono && 
/* 129 */       equalTo(0, (GuildCreateFromTemplateMono)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, GuildCreateFromTemplateMono another) {
/* 133 */     return (this.name.equals(another.name) && 
/* 134 */       icon().equals(another.icon()) && this.guildTemplate
/* 135 */       .equals(another.guildTemplate));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 144 */     int h = 5381;
/* 145 */     h += (h << 5) + this.name.hashCode();
/* 146 */     h += (h << 5) + icon().hashCode();
/* 147 */     h += (h << 5) + this.guildTemplate.hashCode();
/* 148 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 157 */     return "GuildCreateFromTemplateMono{name=" + this.name + ", icon=" + 
/*     */       
/* 159 */       icon().toString() + ", guildTemplate=" + this.guildTemplate + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static GuildCreateFromTemplateMono of(String name, GuildTemplate guildTemplate) {
/* 171 */     return new GuildCreateFromTemplateMono(name, guildTemplate);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static GuildCreateFromTemplateMono copyOf(GuildCreateFromTemplateMonoGenerator instance) {
/* 182 */     if (instance instanceof GuildCreateFromTemplateMono) {
/* 183 */       return (GuildCreateFromTemplateMono)instance;
/*     */     }
/* 185 */     return of(instance.name(), instance.guildTemplate())
/* 186 */       .withIcon(instance.icon());
/*     */   }
/*     */   
/*     */   public boolean isIconPresent() {
/* 190 */     return !this.icon_absent;
/*     */   }
/*     */   
/*     */   public Image iconOrElse(Image defaultValue) {
/* 194 */     return !this.icon_absent ? this.icon_value : defaultValue;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\GuildCreateFromTemplateMono.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */