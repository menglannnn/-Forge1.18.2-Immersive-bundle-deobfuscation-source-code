/*    */ package discord4j.core.spec;
/*    */ 
/*    */ import discord4j.common.util.Snowflake;
/*    */ import discord4j.core.object.entity.ScheduledEvent;
/*    */ import discord4j.discordjson.Id;
/*    */ import discord4j.discordjson.json.GuildScheduledEventCreateRequest;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import java.time.Instant;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Immutable
/*    */ public interface ScheduledEventCreateSpecGenerator
/*    */   extends AuditSpec<GuildScheduledEventCreateRequest>
/*    */ {
/*    */   default GuildScheduledEventCreateRequest asRequest() {
/* 41 */     return (GuildScheduledEventCreateRequest)GuildScheduledEventCreateRequest.builder()
/* 42 */       .channelId(InternalSpecUtils.mapPossible(channelId(), snowflake -> Id.of(snowflake.asLong())))
/* 43 */       .entityMetadata(InternalSpecUtils.mapPossible(entityMetadata(), ScheduledEventEntityMetadataSpecGenerator::asRequest))
/* 44 */       .name(name())
/* 45 */       .privacyLevel(privacyLevel().getValue())
/* 46 */       .scheduledStartTime(scheduledStartTime())
/* 47 */       .scheduledEndTime(scheduledEndTime())
/* 48 */       .description(description())
/* 49 */       .entityType(entityType().getValue())
/* 50 */       .build();
/*    */   }
/*    */   
/*    */   Possible<Snowflake> channelId();
/*    */   
/*    */   Possible<ScheduledEventEntityMetadataSpec> entityMetadata();
/*    */   
/*    */   String name();
/*    */   
/*    */   ScheduledEvent.PrivacyLevel privacyLevel();
/*    */   
/*    */   Instant scheduledStartTime();
/*    */   
/*    */   Possible<Instant> scheduledEndTime();
/*    */   
/*    */   Possible<String> description();
/*    */   
/*    */   ScheduledEvent.EntityType entityType();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\ScheduledEventCreateSpecGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */