/*     */ package discord4j.core.spec;
/*     */ 
/*     */ import discord4j.core.object.entity.Webhook;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import discord4j.rest.util.Image;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "WebhookEditWithTokenMonoGenerator", generator = "Immutables")
/*     */ public final class WebhookEditWithTokenMono
/*     */   extends WebhookEditWithTokenMonoGenerator
/*     */ {
/*     */   @Nullable
/*     */   private final String reason;
/*     */   private final String name_value;
/*     */   private final boolean name_absent;
/*     */   private final Image avatar_value;
/*     */   private final boolean avatar_absent;
/*     */   private final Webhook webhook;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   private volatile transient InitShim initShim;
/*     */   
/*     */   private WebhookEditWithTokenMono(Webhook webhook) {
/*  61 */     this.initShim = new InitShim(); this.webhook = Objects.<Webhook>requireNonNull(webhook, "webhook"); this.reason = null; Possible<String> name$impl = Possible.absent(); Possible<Image> avatar$impl = Possible.absent(); this.name_value = name$impl.toOptional().orElse(null); this.name_absent = name$impl.isAbsent(); this.avatar_value = avatar$impl.toOptional().orElse(null); this.avatar_absent = avatar$impl.isAbsent(); this.initShim = null; } private WebhookEditWithTokenMono(@Nullable String reason, Possible<String> name, Possible<Image> avatar, Webhook webhook) { this.initShim = new InitShim(); this.reason = reason; Possible<String> name$impl = name; Possible<Image> avatar$impl = avatar;
/*     */     this.webhook = webhook;
/*     */     this.name_value = name$impl.toOptional().orElse(null);
/*     */     this.name_absent = name$impl.isAbsent();
/*     */     this.avatar_value = avatar$impl.toOptional().orElse(null);
/*     */     this.avatar_absent = avatar$impl.isAbsent();
/*  67 */     this.initShim = null; } @Generated(from = "WebhookEditWithTokenMonoGenerator", generator = "Immutables") private final class InitShim { private InitShim() {} private String formatInitCycleMessage() { List<String> attributes = new ArrayList<>();
/*  68 */       return "Cannot build WebhookEditWithTokenMono, attribute initializers form cycle " + attributes; }
/*     */      }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String reason() {
/*  78 */     return this.reason;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<String> name() {
/*  86 */     return this.name_absent ? Possible.absent() : Possible.of(this.name_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Image> avatar() {
/*  94 */     return this.avatar_absent ? Possible.absent() : Possible.of(this.avatar_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Webhook webhook() {
/* 102 */     return this.webhook;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final WebhookEditWithTokenMono withReason(@Nullable String value) {
/* 112 */     if (Objects.equals(this.reason, value)) return this; 
/* 113 */     return new WebhookEditWithTokenMono(value, name(), avatar(), this.webhook);
/*     */   }
/*     */   
/*     */   public WebhookEditWithTokenMono withName(Possible<String> value) {
/* 117 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/* 118 */     return new WebhookEditWithTokenMono(this.reason, newValue, avatar(), this.webhook);
/*     */   }
/*     */   
/*     */   public WebhookEditWithTokenMono withName(String value) {
/* 122 */     Possible<String> newValue = Possible.of(value);
/* 123 */     return new WebhookEditWithTokenMono(this.reason, newValue, avatar(), this.webhook);
/*     */   }
/*     */   
/*     */   public WebhookEditWithTokenMono withAvatar(Possible<Image> value) {
/* 127 */     Possible<Image> newValue = Objects.<Possible<Image>>requireNonNull(value);
/* 128 */     return new WebhookEditWithTokenMono(this.reason, name(), newValue, this.webhook);
/*     */   }
/*     */   
/*     */   public WebhookEditWithTokenMono withAvatar(Image value) {
/* 132 */     Possible<Image> newValue = Possible.of(value);
/* 133 */     return new WebhookEditWithTokenMono(this.reason, name(), newValue, this.webhook);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final WebhookEditWithTokenMono withWebhook(Webhook value) {
/* 143 */     if (this.webhook == value) return this; 
/* 144 */     Webhook newValue = Objects.<Webhook>requireNonNull(value, "webhook");
/* 145 */     return new WebhookEditWithTokenMono(this.reason, name(), avatar(), newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 154 */     if (this == another) return true; 
/* 155 */     return (another instanceof WebhookEditWithTokenMono && 
/* 156 */       equalTo(0, (WebhookEditWithTokenMono)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, WebhookEditWithTokenMono another) {
/* 160 */     return (Objects.equals(this.reason, another.reason) && 
/* 161 */       name().equals(another.name()) && 
/* 162 */       avatar().equals(another.avatar()) && this.webhook
/* 163 */       .equals(another.webhook));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 172 */     int h = 5381;
/* 173 */     h += (h << 5) + Objects.hashCode(this.reason);
/* 174 */     h += (h << 5) + name().hashCode();
/* 175 */     h += (h << 5) + avatar().hashCode();
/* 176 */     h += (h << 5) + this.webhook.hashCode();
/* 177 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 186 */     return "WebhookEditWithTokenMono{reason=" + this.reason + ", name=" + 
/*     */       
/* 188 */       name().toString() + ", avatar=" + 
/* 189 */       avatar().toString() + ", webhook=" + this.webhook + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static WebhookEditWithTokenMono of(Webhook webhook) {
/* 200 */     return new WebhookEditWithTokenMono(webhook);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static WebhookEditWithTokenMono copyOf(WebhookEditWithTokenMonoGenerator instance) {
/* 211 */     if (instance instanceof WebhookEditWithTokenMono) {
/* 212 */       return (WebhookEditWithTokenMono)instance;
/*     */     }
/* 214 */     return of(instance.webhook())
/* 215 */       .withReason(instance.reason())
/* 216 */       .withName(instance.name())
/* 217 */       .withAvatar(instance.avatar());
/*     */   }
/*     */   
/*     */   public boolean isNamePresent() {
/* 221 */     return !this.name_absent;
/*     */   }
/*     */   
/*     */   public String nameOrElse(String defaultValue) {
/* 225 */     return !this.name_absent ? this.name_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isAvatarPresent() {
/* 229 */     return !this.avatar_absent;
/*     */   }
/*     */   
/*     */   public Image avatarOrElse(Image defaultValue) {
/* 233 */     return !this.avatar_absent ? this.avatar_value : defaultValue;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\WebhookEditWithTokenMono.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */