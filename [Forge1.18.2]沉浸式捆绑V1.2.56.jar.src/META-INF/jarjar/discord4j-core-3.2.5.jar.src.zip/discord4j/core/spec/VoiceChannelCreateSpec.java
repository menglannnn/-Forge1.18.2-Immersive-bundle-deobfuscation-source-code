/*     */ package discord4j.core.spec;
/*     */ 
/*     */ import com.google.errorprone.annotations.CanIgnoreReturnValue;
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.object.PermissionOverwrite;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.stream.StreamSupport;
/*     */ import org.immutables.value.Generated;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "VoiceChannelCreateSpecGenerator", generator = "Immutables")
/*     */ public final class VoiceChannelCreateSpec
/*     */   implements VoiceChannelCreateSpecGenerator
/*     */ {
/*     */   @Nullable
/*     */   private final String reason;
/*     */   private final String name;
/*     */   private final Integer bitrate_value;
/*     */   private final boolean bitrate_absent;
/*     */   private final Integer userLimit_value;
/*     */   private final boolean userLimit_absent;
/*     */   private final Integer position_value;
/*     */   private final boolean position_absent;
/*     */   private final Integer rateLimitPerUser_value;
/*     */   private final boolean rateLimitPerUser_absent;
/*     */   private final List<PermissionOverwrite> permissionOverwrites_value;
/*     */   private final boolean permissionOverwrites_absent;
/*     */   private final Snowflake parentId_value;
/*     */   private final boolean parentId_absent;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   private volatile transient InitShim initShim;
/*     */   
/*     */   private VoiceChannelCreateSpec(String name) {
/* 103 */     this.initShim = new InitShim(); this.name = Objects.<String>requireNonNull(name, "name"); this.reason = null; Possible<Integer> bitrate$impl = Possible.absent(); Possible<Integer> userLimit$impl = Possible.absent(); Possible<Integer> position$impl = Possible.absent(); Possible<Integer> rateLimitPerUser$impl = Possible.absent(); Possible<List<PermissionOverwrite>> permissionOverwrites$impl = Possible.absent(); Possible<Snowflake> parentId$impl = Possible.absent(); this.bitrate_value = bitrate$impl.toOptional().orElse(null); this.bitrate_absent = bitrate$impl.isAbsent(); this.userLimit_value = userLimit$impl.toOptional().orElse(null); this.userLimit_absent = userLimit$impl.isAbsent(); this.position_value = position$impl.toOptional().orElse(null); this.position_absent = position$impl.isAbsent(); this.rateLimitPerUser_value = rateLimitPerUser$impl.toOptional().orElse(null); this.rateLimitPerUser_absent = rateLimitPerUser$impl.isAbsent(); this.permissionOverwrites_value = permissionOverwrites$impl.toOptional().orElse(null); this.permissionOverwrites_absent = permissionOverwrites$impl.isAbsent(); this.parentId_value = parentId$impl.toOptional().orElse(null); this.parentId_absent = parentId$impl.isAbsent(); this.initShim = null; } private VoiceChannelCreateSpec(@Nullable String reason, String name, Possible<Integer> bitrate, Possible<Integer> userLimit, Possible<Integer> position, Possible<Integer> rateLimitPerUser, Possible<List<PermissionOverwrite>> permissionOverwrites, Possible<Snowflake> parentId) { this.initShim = new InitShim(); this.reason = reason; this.name = name; Possible<Integer> bitrate$impl = bitrate; Possible<Integer> userLimit$impl = userLimit; Possible<Integer> position$impl = position; Possible<Integer> rateLimitPerUser$impl = rateLimitPerUser; Possible<List<PermissionOverwrite>> permissionOverwrites$impl = permissionOverwrites; Possible<Snowflake> parentId$impl = parentId; this.bitrate_value = bitrate$impl.toOptional().orElse(null); this.bitrate_absent = bitrate$impl.isAbsent(); this.userLimit_value = userLimit$impl.toOptional().orElse(null); this.userLimit_absent = userLimit$impl.isAbsent(); this.position_value = position$impl.toOptional().orElse(null); this.position_absent = position$impl.isAbsent(); this.rateLimitPerUser_value = rateLimitPerUser$impl.toOptional().orElse(null);
/*     */     this.rateLimitPerUser_absent = rateLimitPerUser$impl.isAbsent();
/*     */     this.permissionOverwrites_value = permissionOverwrites$impl.toOptional().orElse(null);
/*     */     this.permissionOverwrites_absent = permissionOverwrites$impl.isAbsent();
/*     */     this.parentId_value = parentId$impl.toOptional().orElse(null);
/*     */     this.parentId_absent = parentId$impl.isAbsent();
/* 109 */     this.initShim = null; } @Generated(from = "VoiceChannelCreateSpecGenerator", generator = "Immutables") private final class InitShim { private InitShim() {} private String formatInitCycleMessage() { List<String> attributes = new ArrayList<>();
/* 110 */       return "Cannot build VoiceChannelCreateSpec, attribute initializers form cycle " + attributes; }
/*     */      }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String reason() {
/* 120 */     return this.reason;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String name() {
/* 128 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Integer> bitrate() {
/* 136 */     return this.bitrate_absent ? Possible.absent() : Possible.of(this.bitrate_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Integer> userLimit() {
/* 144 */     return this.userLimit_absent ? Possible.absent() : Possible.of(this.userLimit_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Integer> position() {
/* 152 */     return this.position_absent ? Possible.absent() : Possible.of(this.position_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Integer> rateLimitPerUser() {
/* 160 */     return this.rateLimitPerUser_absent ? Possible.absent() : Possible.of(this.rateLimitPerUser_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<List<PermissionOverwrite>> permissionOverwrites() {
/* 168 */     return this.permissionOverwrites_absent ? Possible.absent() : 
/* 169 */       Possible.of(this.permissionOverwrites_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Snowflake> parentId() {
/* 177 */     return this.parentId_absent ? Possible.absent() : Possible.of(this.parentId_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final VoiceChannelCreateSpec withReason(@Nullable String value) {
/* 187 */     if (Objects.equals(this.reason, value)) return this; 
/* 188 */     return new VoiceChannelCreateSpec(value, this.name, 
/*     */ 
/*     */         
/* 191 */         bitrate(), 
/* 192 */         userLimit(), 
/* 193 */         position(), 
/* 194 */         rateLimitPerUser(), 
/* 195 */         permissionOverwrites(), 
/* 196 */         parentId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final VoiceChannelCreateSpec withName(String value) {
/* 206 */     String newValue = Objects.<String>requireNonNull(value, "name");
/* 207 */     if (this.name.equals(newValue)) return this; 
/* 208 */     return new VoiceChannelCreateSpec(this.reason, newValue, 
/*     */ 
/*     */         
/* 211 */         bitrate(), 
/* 212 */         userLimit(), 
/* 213 */         position(), 
/* 214 */         rateLimitPerUser(), 
/* 215 */         permissionOverwrites(), 
/* 216 */         parentId());
/*     */   }
/*     */   
/*     */   public VoiceChannelCreateSpec withBitrate(Possible<Integer> value) {
/* 220 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/* 221 */     return new VoiceChannelCreateSpec(this.reason, this.name, newValue, 
/*     */ 
/*     */ 
/*     */         
/* 225 */         userLimit(), 
/* 226 */         position(), 
/* 227 */         rateLimitPerUser(), 
/* 228 */         permissionOverwrites(), 
/* 229 */         parentId());
/*     */   }
/*     */   
/*     */   public VoiceChannelCreateSpec withBitrate(Integer value) {
/* 233 */     Possible<Integer> newValue = Possible.of(value);
/* 234 */     return new VoiceChannelCreateSpec(this.reason, this.name, newValue, 
/*     */ 
/*     */ 
/*     */         
/* 238 */         userLimit(), 
/* 239 */         position(), 
/* 240 */         rateLimitPerUser(), 
/* 241 */         permissionOverwrites(), 
/* 242 */         parentId());
/*     */   }
/*     */   
/*     */   public VoiceChannelCreateSpec withUserLimit(Possible<Integer> value) {
/* 246 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/* 247 */     return new VoiceChannelCreateSpec(this.reason, this.name, 
/*     */ 
/*     */         
/* 250 */         bitrate(), newValue, 
/*     */         
/* 252 */         position(), 
/* 253 */         rateLimitPerUser(), 
/* 254 */         permissionOverwrites(), 
/* 255 */         parentId());
/*     */   }
/*     */   
/*     */   public VoiceChannelCreateSpec withUserLimit(Integer value) {
/* 259 */     Possible<Integer> newValue = Possible.of(value);
/* 260 */     return new VoiceChannelCreateSpec(this.reason, this.name, 
/*     */ 
/*     */         
/* 263 */         bitrate(), newValue, 
/*     */         
/* 265 */         position(), 
/* 266 */         rateLimitPerUser(), 
/* 267 */         permissionOverwrites(), 
/* 268 */         parentId());
/*     */   }
/*     */   
/*     */   public VoiceChannelCreateSpec withPosition(Possible<Integer> value) {
/* 272 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/* 273 */     return new VoiceChannelCreateSpec(this.reason, this.name, 
/*     */ 
/*     */         
/* 276 */         bitrate(), 
/* 277 */         userLimit(), newValue, 
/*     */         
/* 279 */         rateLimitPerUser(), 
/* 280 */         permissionOverwrites(), 
/* 281 */         parentId());
/*     */   }
/*     */   
/*     */   public VoiceChannelCreateSpec withPosition(Integer value) {
/* 285 */     Possible<Integer> newValue = Possible.of(value);
/* 286 */     return new VoiceChannelCreateSpec(this.reason, this.name, 
/*     */ 
/*     */         
/* 289 */         bitrate(), 
/* 290 */         userLimit(), newValue, 
/*     */         
/* 292 */         rateLimitPerUser(), 
/* 293 */         permissionOverwrites(), 
/* 294 */         parentId());
/*     */   }
/*     */   
/*     */   public VoiceChannelCreateSpec withRateLimitPerUser(Possible<Integer> value) {
/* 298 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/* 299 */     return new VoiceChannelCreateSpec(this.reason, this.name, 
/*     */ 
/*     */         
/* 302 */         bitrate(), 
/* 303 */         userLimit(), 
/* 304 */         position(), newValue, 
/*     */         
/* 306 */         permissionOverwrites(), 
/* 307 */         parentId());
/*     */   }
/*     */   
/*     */   public VoiceChannelCreateSpec withRateLimitPerUser(Integer value) {
/* 311 */     Possible<Integer> newValue = Possible.of(value);
/* 312 */     return new VoiceChannelCreateSpec(this.reason, this.name, 
/*     */ 
/*     */         
/* 315 */         bitrate(), 
/* 316 */         userLimit(), 
/* 317 */         position(), newValue, 
/*     */         
/* 319 */         permissionOverwrites(), 
/* 320 */         parentId());
/*     */   }
/*     */   
/*     */   public VoiceChannelCreateSpec withPermissionOverwrites(Possible<List<PermissionOverwrite>> possible) {
/* 324 */     Possible<List<PermissionOverwrite>> newValue = Objects.<Possible<List<PermissionOverwrite>>>requireNonNull(possible);
/* 325 */     return new VoiceChannelCreateSpec(this.reason, this.name, 
/*     */ 
/*     */         
/* 328 */         bitrate(), 
/* 329 */         userLimit(), 
/* 330 */         position(), 
/* 331 */         rateLimitPerUser(), newValue, 
/*     */         
/* 333 */         parentId());
/*     */   }
/*     */   
/*     */   public VoiceChannelCreateSpec withPermissionOverwrites(Iterable<PermissionOverwrite> elements) {
/* 337 */     Possible<List<PermissionOverwrite>> newValue = Possible.of(
/* 338 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/* 339 */     return new VoiceChannelCreateSpec(this.reason, this.name, 
/*     */ 
/*     */         
/* 342 */         bitrate(), 
/* 343 */         userLimit(), 
/* 344 */         position(), 
/* 345 */         rateLimitPerUser(), newValue, 
/*     */         
/* 347 */         parentId());
/*     */   }
/*     */   
/*     */   @SafeVarargs
/*     */   public final VoiceChannelCreateSpec withPermissionOverwrites(PermissionOverwrite... elements) {
/* 352 */     Possible<List<PermissionOverwrite>> newValue = Possible.of(Arrays.asList(elements));
/* 353 */     return new VoiceChannelCreateSpec(this.reason, this.name, 
/*     */ 
/*     */         
/* 356 */         bitrate(), 
/* 357 */         userLimit(), 
/* 358 */         position(), 
/* 359 */         rateLimitPerUser(), newValue, 
/*     */         
/* 361 */         parentId());
/*     */   }
/*     */   
/*     */   public VoiceChannelCreateSpec withParentId(Possible<Snowflake> value) {
/* 365 */     Possible<Snowflake> newValue = Objects.<Possible<Snowflake>>requireNonNull(value);
/* 366 */     return new VoiceChannelCreateSpec(this.reason, this.name, 
/*     */ 
/*     */         
/* 369 */         bitrate(), 
/* 370 */         userLimit(), 
/* 371 */         position(), 
/* 372 */         rateLimitPerUser(), 
/* 373 */         permissionOverwrites(), newValue);
/*     */   }
/*     */ 
/*     */   
/*     */   public VoiceChannelCreateSpec withParentId(Snowflake value) {
/* 378 */     Possible<Snowflake> newValue = Possible.of(value);
/* 379 */     return new VoiceChannelCreateSpec(this.reason, this.name, 
/*     */ 
/*     */         
/* 382 */         bitrate(), 
/* 383 */         userLimit(), 
/* 384 */         position(), 
/* 385 */         rateLimitPerUser(), 
/* 386 */         permissionOverwrites(), newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 396 */     if (this == another) return true; 
/* 397 */     return (another instanceof VoiceChannelCreateSpec && 
/* 398 */       equalTo(0, (VoiceChannelCreateSpec)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, VoiceChannelCreateSpec another) {
/* 402 */     return (Objects.equals(this.reason, another.reason) && this.name
/* 403 */       .equals(another.name) && 
/* 404 */       bitrate().equals(another.bitrate()) && 
/* 405 */       userLimit().equals(another.userLimit()) && 
/* 406 */       position().equals(another.position()) && 
/* 407 */       rateLimitPerUser().equals(another.rateLimitPerUser()) && 
/* 408 */       Objects.equals(this.permissionOverwrites_value, another.permissionOverwrites_value) && 
/* 409 */       parentId().equals(another.parentId()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 418 */     int h = 5381;
/* 419 */     h += (h << 5) + Objects.hashCode(this.reason);
/* 420 */     h += (h << 5) + this.name.hashCode();
/* 421 */     h += (h << 5) + bitrate().hashCode();
/* 422 */     h += (h << 5) + userLimit().hashCode();
/* 423 */     h += (h << 5) + position().hashCode();
/* 424 */     h += (h << 5) + rateLimitPerUser().hashCode();
/* 425 */     h += (h << 5) + Objects.hashCode(this.permissionOverwrites_value);
/* 426 */     h += (h << 5) + parentId().hashCode();
/* 427 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 436 */     return "VoiceChannelCreateSpec{reason=" + this.reason + ", name=" + this.name + ", bitrate=" + 
/*     */ 
/*     */       
/* 439 */       bitrate().toString() + ", userLimit=" + 
/* 440 */       userLimit().toString() + ", position=" + 
/* 441 */       position().toString() + ", rateLimitPerUser=" + 
/* 442 */       rateLimitPerUser().toString() + ", permissionOverwrites=" + 
/* 443 */       Objects.toString(this.permissionOverwrites_value) + ", parentId=" + 
/* 444 */       parentId().toString() + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static VoiceChannelCreateSpec of(String name) {
/* 454 */     return new VoiceChannelCreateSpec(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static VoiceChannelCreateSpec copyOf(VoiceChannelCreateSpecGenerator instance) {
/* 465 */     if (instance instanceof VoiceChannelCreateSpec) {
/* 466 */       return (VoiceChannelCreateSpec)instance;
/*     */     }
/* 468 */     return builder()
/* 469 */       .from(instance)
/* 470 */       .build();
/*     */   }
/*     */   
/*     */   public boolean isBitratePresent() {
/* 474 */     return !this.bitrate_absent;
/*     */   }
/*     */   
/*     */   public Integer bitrateOrElse(Integer defaultValue) {
/* 478 */     return !this.bitrate_absent ? this.bitrate_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isUserLimitPresent() {
/* 482 */     return !this.userLimit_absent;
/*     */   }
/*     */   
/*     */   public Integer userLimitOrElse(Integer defaultValue) {
/* 486 */     return !this.userLimit_absent ? this.userLimit_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isPositionPresent() {
/* 490 */     return !this.position_absent;
/*     */   }
/*     */   
/*     */   public Integer positionOrElse(Integer defaultValue) {
/* 494 */     return !this.position_absent ? this.position_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isRateLimitPerUserPresent() {
/* 498 */     return !this.rateLimitPerUser_absent;
/*     */   }
/*     */   
/*     */   public Integer rateLimitPerUserOrElse(Integer defaultValue) {
/* 502 */     return !this.rateLimitPerUser_absent ? this.rateLimitPerUser_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isPermissionOverwritesPresent() {
/* 506 */     return !this.permissionOverwrites_absent;
/*     */   }
/*     */   
/*     */   public List<PermissionOverwrite> permissionOverwritesOrElse(List<PermissionOverwrite> defaultValue) {
/* 510 */     return !this.permissionOverwrites_absent ? this.permissionOverwrites_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isParentIdPresent() {
/* 514 */     return !this.parentId_absent;
/*     */   }
/*     */   
/*     */   public Snowflake parentIdOrElse(Snowflake defaultValue) {
/* 518 */     return !this.parentId_absent ? this.parentId_value : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 538 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "VoiceChannelCreateSpecGenerator", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_NAME = 1L;
/*     */ 
/*     */ 
/*     */     
/* 551 */     private long initBits = 1L;
/*     */     
/* 553 */     private Possible<Integer> bitrate_possible = Possible.absent();
/* 554 */     private Possible<Integer> userLimit_possible = Possible.absent();
/* 555 */     private Possible<Integer> position_possible = Possible.absent();
/* 556 */     private Possible<Integer> rateLimitPerUser_possible = Possible.absent();
/* 557 */     private List<PermissionOverwrite> permissionOverwrites_list = null;
/* 558 */     private Possible<Snowflake> parentId_possible = Possible.absent();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private String reason;
/*     */ 
/*     */ 
/*     */     
/*     */     private String name;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(VoiceChannelCreateSpec instance) {
/* 573 */       return from(instance);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     final Builder from(VoiceChannelCreateSpecGenerator instance) {
/* 583 */       Objects.requireNonNull(instance, "instance");
/* 584 */       String reasonValue = instance.reason();
/* 585 */       if (reasonValue != null) {
/* 586 */         reason(reasonValue);
/*     */       }
/* 588 */       name(instance.name());
/* 589 */       bitrate(instance.bitrate());
/* 590 */       userLimit(instance.userLimit());
/* 591 */       position(instance.position());
/* 592 */       rateLimitPerUser(instance.rateLimitPerUser());
/* 593 */       permissionOverwrites(instance.permissionOverwrites());
/* 594 */       parentId(instance.parentId());
/* 595 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder reason(@Nullable String reason) {
/* 605 */       this.reason = reason;
/* 606 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder name(String name) {
/* 616 */       this.name = Objects.<String>requireNonNull(name, "name");
/* 617 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 618 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder bitrate(Possible<Integer> value) {
/* 623 */       this.bitrate_possible = value;
/* 624 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder bitrate(Integer value) {
/* 629 */       this.bitrate_possible = Possible.of(value);
/* 630 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder userLimit(Possible<Integer> value) {
/* 635 */       this.userLimit_possible = value;
/* 636 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder userLimit(Integer value) {
/* 641 */       this.userLimit_possible = Possible.of(value);
/* 642 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder position(Possible<Integer> value) {
/* 647 */       this.position_possible = value;
/* 648 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder position(Integer value) {
/* 653 */       this.position_possible = Possible.of(value);
/* 654 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder rateLimitPerUser(Possible<Integer> value) {
/* 659 */       this.rateLimitPerUser_possible = value;
/* 660 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder rateLimitPerUser(Integer value) {
/* 665 */       this.rateLimitPerUser_possible = Possible.of(value);
/* 666 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder addPermissionOverwrite(PermissionOverwrite element) {
/* 671 */       permissionOverwrites_getOrCreate().add(element);
/* 672 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder addAllPermissionOverwrites(List<PermissionOverwrite> elements) {
/* 677 */       permissionOverwrites_getOrCreate().addAll(elements);
/* 678 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder permissionOverwrites(Possible<List<PermissionOverwrite>> elements) {
/* 683 */       this.permissionOverwrites_list = null;
/* 684 */       elements.toOptional().ifPresent(e -> permissionOverwrites_getOrCreate().addAll(e));
/* 685 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder permissionOverwrites(List<PermissionOverwrite> elements) {
/* 690 */       this.permissionOverwrites_list = new ArrayList<>(elements);
/* 691 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder permissionOverwrites(Iterable<PermissionOverwrite> elements) {
/* 696 */       this.permissionOverwrites_list = (List<PermissionOverwrite>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/* 697 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder parentId(Possible<Snowflake> value) {
/* 702 */       this.parentId_possible = value;
/* 703 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder parentId(Snowflake value) {
/* 708 */       this.parentId_possible = Possible.of(value);
/* 709 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public VoiceChannelCreateSpec build() {
/* 718 */       if (this.initBits != 0L) {
/* 719 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 721 */       return new VoiceChannelCreateSpec(this.reason, this.name, 
/*     */ 
/*     */           
/* 724 */           bitrate_build(), 
/* 725 */           userLimit_build(), 
/* 726 */           position_build(), 
/* 727 */           rateLimitPerUser_build(), 
/* 728 */           permissionOverwrites_build(), 
/* 729 */           parentId_build());
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 733 */       List<String> attributes = new ArrayList<>();
/* 734 */       if ((this.initBits & 0x1L) != 0L) attributes.add("name"); 
/* 735 */       return "Cannot build VoiceChannelCreateSpec, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Possible<Integer> bitrate_build() {
/* 739 */       return this.bitrate_possible;
/*     */     }
/*     */     
/*     */     private Possible<Integer> userLimit_build() {
/* 743 */       return this.userLimit_possible;
/*     */     }
/*     */     
/*     */     private Possible<Integer> position_build() {
/* 747 */       return this.position_possible;
/*     */     }
/*     */     
/*     */     private Possible<Integer> rateLimitPerUser_build() {
/* 751 */       return this.rateLimitPerUser_possible;
/*     */     }
/*     */     
/*     */     private Possible<List<PermissionOverwrite>> permissionOverwrites_build() {
/* 755 */       return (this.permissionOverwrites_list == null) ? Possible.absent() : 
/* 756 */         Possible.of(this.permissionOverwrites_list);
/*     */     }
/*     */     
/*     */     private List<PermissionOverwrite> permissionOverwrites_getOrCreate() {
/* 760 */       if (this.permissionOverwrites_list == null) {
/* 761 */         this.permissionOverwrites_list = new ArrayList<>();
/*     */       }
/* 763 */       return this.permissionOverwrites_list;
/*     */     }
/*     */     
/*     */     private Possible<Snowflake> parentId_build() {
/* 767 */       return this.parentId_possible;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\VoiceChannelCreateSpec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */