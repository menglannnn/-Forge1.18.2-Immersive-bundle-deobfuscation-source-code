/*    */ package discord4j.core.spec;
/*    */ 
/*    */ import discord4j.core.object.ExtendedInvite;
/*    */ import discord4j.core.object.entity.channel.CategorizableChannel;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ import reactor.core.CoreSubscriber;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Immutable(builder = false)
/*    */ abstract class InviteCreateMonoGenerator
/*    */   extends Mono<ExtendedInvite>
/*    */   implements InviteCreateSpecGenerator
/*    */ {
/*    */   abstract CategorizableChannel channel();
/*    */   
/*    */   public void subscribe(CoreSubscriber<? super ExtendedInvite> actual) {
/* 71 */     channel().createInvite(InviteCreateSpec.copyOf(this)).subscribe(actual);
/*    */   }
/*    */   
/*    */   public abstract String toString();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\InviteCreateMonoGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */