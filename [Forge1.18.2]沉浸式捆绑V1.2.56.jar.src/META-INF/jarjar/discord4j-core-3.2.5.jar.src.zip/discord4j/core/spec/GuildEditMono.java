/*      */ package discord4j.core.spec;
/*      */ 
/*      */ import discord4j.common.util.Snowflake;
/*      */ import discord4j.core.object.Region;
/*      */ import discord4j.core.object.entity.Guild;
/*      */ import discord4j.discordjson.possible.Possible;
/*      */ import discord4j.rest.util.Image;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.Objects;
/*      */ import java.util.Optional;
/*      */ import java.util.stream.Collectors;
/*      */ import java.util.stream.StreamSupport;
/*      */ import org.immutables.value.Generated;
/*      */ import reactor.core.CoreSubscriber;
/*      */ import reactor.util.annotation.Nullable;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ @Generated(from = "GuildEditMonoGenerator", generator = "Immutables")
/*      */ public final class GuildEditMono
/*      */   extends GuildEditMonoGenerator
/*      */ {
/*      */   @Nullable
/*      */   private final String reason;
/*      */   private final String name_value;
/*      */   private final boolean name_absent;
/*      */   private final Region region_value;
/*      */   private final boolean region_absent;
/*      */   private final Guild.VerificationLevel verificationLevel_value;
/*      */   private final boolean verificationLevel_absent;
/*      */   private final Guild.NotificationLevel defaultMessageNotificationsLevel_value;
/*      */   private final boolean defaultMessageNotificationsLevel_absent;
/*      */   private final Guild.ContentFilterLevel explicitContentFilter_value;
/*      */   private final boolean explicitContentFilter_absent;
/*      */   private final Snowflake afkChannelId_value;
/*      */   private final boolean afkChannelId_absent;
/*      */   private final Integer afkTimeout_value;
/*      */   private final boolean afkTimeout_absent;
/*      */   private final Image icon_value;
/*      */   private final boolean icon_absent;
/*      */   private final Snowflake ownerId_value;
/*      */   private final boolean ownerId_absent;
/*      */   private final Image splash_value;
/*      */   private final boolean splash_absent;
/*      */   private final Image discoverySplash_value;
/*      */   private final boolean discoverySplash_absent;
/*      */   private final Image banner_value;
/*      */   private final boolean banner_absent;
/*      */   private final Snowflake systemChannelId_value;
/*      */   private final boolean systemChannelId_absent;
/*      */   private final Guild.SystemChannelFlag systemChannelFlags_value;
/*      */   private final boolean systemChannelFlags_absent;
/*      */   private final Snowflake rulesChannelId_value;
/*      */   private final boolean rulesChannelId_absent;
/*      */   private final Snowflake publicUpdatesChannelId_value;
/*      */   private final boolean publicUpdatesChannelId_absent;
/*      */   private final Locale preferredLocale_value;
/*      */   private final boolean preferredLocale_absent;
/*      */   private final List<String> features_value;
/*      */   private final boolean features_absent;
/*      */   private final String description_value;
/*      */   private final boolean description_absent;
/*      */   private final Snowflake safetyAlertsChannelId_value;
/*      */   private final boolean safetyAlertsChannelId_absent;
/*      */   private final Guild guild;
/*      */   private static final byte STAGE_INITIALIZING = -1;
/*      */   private static final byte STAGE_UNINITIALIZED = 0;
/*      */   private static final byte STAGE_INITIALIZED = 1;
/*      */   private volatile transient InitShim initShim;
/*      */   
/*      */   private GuildEditMono(Guild guild) {
/*  230 */     this.initShim = new InitShim(); this.guild = Objects.<Guild>requireNonNull(guild, "guild"); this.reason = null; Possible<String> name$impl = Possible.absent(); Possible<Optional<Region>> region$impl = Possible.absent(); Possible<Optional<Guild.VerificationLevel>> verificationLevel$impl = Possible.absent(); Possible<Optional<Guild.NotificationLevel>> defaultMessageNotificationsLevel$impl = Possible.absent(); Possible<Optional<Guild.ContentFilterLevel>> explicitContentFilter$impl = Possible.absent(); Possible<Optional<Snowflake>> afkChannelId$impl = Possible.absent(); Possible<Integer> afkTimeout$impl = Possible.absent(); Possible<Optional<Image>> icon$impl = Possible.absent(); Possible<Snowflake> ownerId$impl = Possible.absent(); Possible<Optional<Image>> splash$impl = Possible.absent(); Possible<Optional<Image>> discoverySplash$impl = Possible.absent(); Possible<Optional<Image>> banner$impl = Possible.absent(); Possible<Optional<Snowflake>> systemChannelId$impl = Possible.absent(); Possible<Guild.SystemChannelFlag> systemChannelFlags$impl = Possible.absent(); Possible<Optional<Snowflake>> rulesChannelId$impl = Possible.absent(); Possible<Optional<Snowflake>> publicUpdatesChannelId$impl = Possible.absent(); Possible<Optional<Locale>> preferredLocale$impl = Possible.absent(); Possible<List<String>> features$impl = Possible.absent(); Possible<Optional<String>> description$impl = Possible.absent(); Possible<Optional<Snowflake>> safetyAlertsChannelId$impl = Possible.absent(); this.name_value = name$impl.toOptional().orElse(null); this.name_absent = name$impl.isAbsent(); this.region_value = Possible.flatOpt(region$impl).orElse(null); this.region_absent = region$impl.isAbsent(); this.verificationLevel_value = Possible.flatOpt(verificationLevel$impl).orElse(null); this.verificationLevel_absent = verificationLevel$impl.isAbsent(); this.defaultMessageNotificationsLevel_value = Possible.flatOpt(defaultMessageNotificationsLevel$impl).orElse(null); this.defaultMessageNotificationsLevel_absent = defaultMessageNotificationsLevel$impl.isAbsent(); this.explicitContentFilter_value = Possible.flatOpt(explicitContentFilter$impl).orElse(null); this.explicitContentFilter_absent = explicitContentFilter$impl.isAbsent(); this.afkChannelId_value = Possible.flatOpt(afkChannelId$impl).orElse(null); this.afkChannelId_absent = afkChannelId$impl.isAbsent(); this.afkTimeout_value = afkTimeout$impl.toOptional().orElse(null); this.afkTimeout_absent = afkTimeout$impl.isAbsent(); this.icon_value = Possible.flatOpt(icon$impl).orElse(null); this.icon_absent = icon$impl.isAbsent(); this.ownerId_value = ownerId$impl.toOptional().orElse(null); this.ownerId_absent = ownerId$impl.isAbsent(); this.splash_value = Possible.flatOpt(splash$impl).orElse(null); this.splash_absent = splash$impl.isAbsent(); this.discoverySplash_value = Possible.flatOpt(discoverySplash$impl).orElse(null); this.discoverySplash_absent = discoverySplash$impl.isAbsent(); this.banner_value = Possible.flatOpt(banner$impl).orElse(null); this.banner_absent = banner$impl.isAbsent(); this.systemChannelId_value = Possible.flatOpt(systemChannelId$impl).orElse(null); this.systemChannelId_absent = systemChannelId$impl.isAbsent(); this.systemChannelFlags_value = systemChannelFlags$impl.toOptional().orElse(null); this.systemChannelFlags_absent = systemChannelFlags$impl.isAbsent(); this.rulesChannelId_value = Possible.flatOpt(rulesChannelId$impl).orElse(null); this.rulesChannelId_absent = rulesChannelId$impl.isAbsent(); this.publicUpdatesChannelId_value = Possible.flatOpt(publicUpdatesChannelId$impl).orElse(null); this.publicUpdatesChannelId_absent = publicUpdatesChannelId$impl.isAbsent(); this.preferredLocale_value = Possible.flatOpt(preferredLocale$impl).orElse(null); this.preferredLocale_absent = preferredLocale$impl.isAbsent(); this.features_value = features$impl.toOptional().orElse(null); this.features_absent = features$impl.isAbsent(); this.description_value = Possible.flatOpt(description$impl).orElse(null); this.description_absent = description$impl.isAbsent(); this.safetyAlertsChannelId_value = Possible.flatOpt(safetyAlertsChannelId$impl).orElse(null); this.safetyAlertsChannelId_absent = safetyAlertsChannelId$impl.isAbsent(); this.initShim = null; } private GuildEditMono(@Nullable String reason, Possible<String> name, Possible<Optional<Region>> region, Possible<Optional<Guild.VerificationLevel>> verificationLevel, Possible<Optional<Guild.NotificationLevel>> defaultMessageNotificationsLevel, Possible<Optional<Guild.ContentFilterLevel>> explicitContentFilter, Possible<Optional<Snowflake>> afkChannelId, Possible<Integer> afkTimeout, Possible<Optional<Image>> icon, Possible<Snowflake> ownerId, Possible<Optional<Image>> splash, Possible<Optional<Image>> discoverySplash, Possible<Optional<Image>> banner, Possible<Optional<Snowflake>> systemChannelId, Possible<Guild.SystemChannelFlag> systemChannelFlags, Possible<Optional<Snowflake>> rulesChannelId, Possible<Optional<Snowflake>> publicUpdatesChannelId, Possible<Optional<Locale>> preferredLocale, Possible<List<String>> features, Possible<Optional<String>> description, Possible<Optional<Snowflake>> safetyAlertsChannelId, Guild guild) { this.initShim = new InitShim(); this.reason = reason; Possible<String> name$impl = name; Possible<Optional<Region>> region$impl = region; Possible<Optional<Guild.VerificationLevel>> verificationLevel$impl = verificationLevel; Possible<Optional<Guild.NotificationLevel>> defaultMessageNotificationsLevel$impl = defaultMessageNotificationsLevel; Possible<Optional<Guild.ContentFilterLevel>> explicitContentFilter$impl = explicitContentFilter; Possible<Optional<Snowflake>> afkChannelId$impl = afkChannelId; Possible<Integer> afkTimeout$impl = afkTimeout; Possible<Optional<Image>> icon$impl = icon; Possible<Snowflake> ownerId$impl = ownerId; Possible<Optional<Image>> splash$impl = splash; Possible<Optional<Image>> discoverySplash$impl = discoverySplash; Possible<Optional<Image>> banner$impl = banner; Possible<Optional<Snowflake>> systemChannelId$impl = systemChannelId; Possible<Guild.SystemChannelFlag> systemChannelFlags$impl = systemChannelFlags; Possible<Optional<Snowflake>> rulesChannelId$impl = rulesChannelId; Possible<Optional<Snowflake>> publicUpdatesChannelId$impl = publicUpdatesChannelId; Possible<Optional<Locale>> preferredLocale$impl = preferredLocale; Possible<List<String>> features$impl = features; Possible<Optional<String>> description$impl = description; Possible<Optional<Snowflake>> safetyAlertsChannelId$impl = safetyAlertsChannelId; this.guild = guild; this.name_value = name$impl.toOptional().orElse(null); this.name_absent = name$impl.isAbsent(); this.region_value = Possible.flatOpt(region$impl).orElse(null); this.region_absent = region$impl.isAbsent(); this.verificationLevel_value = Possible.flatOpt(verificationLevel$impl).orElse(null); this.verificationLevel_absent = verificationLevel$impl.isAbsent(); this.defaultMessageNotificationsLevel_value = Possible.flatOpt(defaultMessageNotificationsLevel$impl).orElse(null); this.defaultMessageNotificationsLevel_absent = defaultMessageNotificationsLevel$impl.isAbsent(); this.explicitContentFilter_value = Possible.flatOpt(explicitContentFilter$impl).orElse(null); this.explicitContentFilter_absent = explicitContentFilter$impl.isAbsent(); this.afkChannelId_value = Possible.flatOpt(afkChannelId$impl).orElse(null); this.afkChannelId_absent = afkChannelId$impl.isAbsent(); this.afkTimeout_value = afkTimeout$impl.toOptional().orElse(null); this.afkTimeout_absent = afkTimeout$impl.isAbsent(); this.icon_value = Possible.flatOpt(icon$impl).orElse(null); this.icon_absent = icon$impl.isAbsent(); this.ownerId_value = ownerId$impl.toOptional().orElse(null); this.ownerId_absent = ownerId$impl.isAbsent(); this.splash_value = Possible.flatOpt(splash$impl).orElse(null); this.splash_absent = splash$impl.isAbsent(); this.discoverySplash_value = Possible.flatOpt(discoverySplash$impl).orElse(null); this.discoverySplash_absent = discoverySplash$impl.isAbsent(); this.banner_value = Possible.flatOpt(banner$impl).orElse(null); this.banner_absent = banner$impl.isAbsent(); this.systemChannelId_value = Possible.flatOpt(systemChannelId$impl).orElse(null); this.systemChannelId_absent = systemChannelId$impl.isAbsent(); this.systemChannelFlags_value = systemChannelFlags$impl.toOptional().orElse(null); this.systemChannelFlags_absent = systemChannelFlags$impl.isAbsent(); this.rulesChannelId_value = Possible.flatOpt(rulesChannelId$impl).orElse(null); this.rulesChannelId_absent = rulesChannelId$impl.isAbsent(); this.publicUpdatesChannelId_value = Possible.flatOpt(publicUpdatesChannelId$impl).orElse(null); this.publicUpdatesChannelId_absent = publicUpdatesChannelId$impl.isAbsent(); this.preferredLocale_value = Possible.flatOpt(preferredLocale$impl).orElse(null); this.preferredLocale_absent = preferredLocale$impl.isAbsent(); this.features_value = features$impl.toOptional().orElse(null);
/*      */     this.features_absent = features$impl.isAbsent();
/*      */     this.description_value = Possible.flatOpt(description$impl).orElse(null);
/*      */     this.description_absent = description$impl.isAbsent();
/*      */     this.safetyAlertsChannelId_value = Possible.flatOpt(safetyAlertsChannelId$impl).orElse(null);
/*      */     this.safetyAlertsChannelId_absent = safetyAlertsChannelId$impl.isAbsent();
/*  236 */     this.initShim = null; } @Generated(from = "GuildEditMonoGenerator", generator = "Immutables") private final class InitShim { private InitShim() {} private String formatInitCycleMessage() { List<String> attributes = new ArrayList<>();
/*  237 */       return "Cannot build GuildEditMono, attribute initializers form cycle " + attributes; }
/*      */      }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public String reason() {
/*  247 */     return this.reason;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Possible<String> name() {
/*  255 */     return this.name_absent ? Possible.absent() : Possible.of(this.name_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Possible<Optional<Region>> region() {
/*  263 */     return this.region_absent ? Possible.absent() : 
/*  264 */       Possible.of(Optional.ofNullable(this.region_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Possible<Optional<Guild.VerificationLevel>> verificationLevel() {
/*  272 */     return this.verificationLevel_absent ? Possible.absent() : 
/*  273 */       Possible.of(Optional.ofNullable(this.verificationLevel_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Possible<Optional<Guild.NotificationLevel>> defaultMessageNotificationsLevel() {
/*  281 */     return this.defaultMessageNotificationsLevel_absent ? Possible.absent() : 
/*  282 */       Possible.of(Optional.ofNullable(this.defaultMessageNotificationsLevel_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Possible<Optional<Guild.ContentFilterLevel>> explicitContentFilter() {
/*  290 */     return this.explicitContentFilter_absent ? Possible.absent() : 
/*  291 */       Possible.of(Optional.ofNullable(this.explicitContentFilter_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Possible<Optional<Snowflake>> afkChannelId() {
/*  299 */     return this.afkChannelId_absent ? Possible.absent() : 
/*  300 */       Possible.of(Optional.ofNullable(this.afkChannelId_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Possible<Integer> afkTimeout() {
/*  308 */     return this.afkTimeout_absent ? Possible.absent() : Possible.of(this.afkTimeout_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Possible<Optional<Image>> icon() {
/*  316 */     return this.icon_absent ? Possible.absent() : 
/*  317 */       Possible.of(Optional.ofNullable(this.icon_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Possible<Snowflake> ownerId() {
/*  325 */     return this.ownerId_absent ? Possible.absent() : Possible.of(this.ownerId_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Possible<Optional<Image>> splash() {
/*  333 */     return this.splash_absent ? Possible.absent() : 
/*  334 */       Possible.of(Optional.ofNullable(this.splash_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Possible<Optional<Image>> discoverySplash() {
/*  342 */     return this.discoverySplash_absent ? Possible.absent() : 
/*  343 */       Possible.of(Optional.ofNullable(this.discoverySplash_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Possible<Optional<Image>> banner() {
/*  351 */     return this.banner_absent ? Possible.absent() : 
/*  352 */       Possible.of(Optional.ofNullable(this.banner_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Possible<Optional<Snowflake>> systemChannelId() {
/*  360 */     return this.systemChannelId_absent ? Possible.absent() : 
/*  361 */       Possible.of(Optional.ofNullable(this.systemChannelId_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Possible<Guild.SystemChannelFlag> systemChannelFlags() {
/*  369 */     return this.systemChannelFlags_absent ? Possible.absent() : Possible.of(this.systemChannelFlags_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Possible<Optional<Snowflake>> rulesChannelId() {
/*  377 */     return this.rulesChannelId_absent ? Possible.absent() : 
/*  378 */       Possible.of(Optional.ofNullable(this.rulesChannelId_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Possible<Optional<Snowflake>> publicUpdatesChannelId() {
/*  386 */     return this.publicUpdatesChannelId_absent ? Possible.absent() : 
/*  387 */       Possible.of(Optional.ofNullable(this.publicUpdatesChannelId_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Possible<Optional<Locale>> preferredLocale() {
/*  395 */     return this.preferredLocale_absent ? Possible.absent() : 
/*  396 */       Possible.of(Optional.ofNullable(this.preferredLocale_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Possible<List<String>> features() {
/*  404 */     return this.features_absent ? Possible.absent() : 
/*  405 */       Possible.of(this.features_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Possible<Optional<String>> description() {
/*  413 */     return this.description_absent ? Possible.absent() : 
/*  414 */       Possible.of(Optional.ofNullable(this.description_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Possible<Optional<Snowflake>> safetyAlertsChannelId() {
/*  422 */     return this.safetyAlertsChannelId_absent ? Possible.absent() : 
/*  423 */       Possible.of(Optional.ofNullable(this.safetyAlertsChannelId_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Guild guild() {
/*  431 */     return this.guild;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final GuildEditMono withReason(@Nullable String value) {
/*  441 */     if (Objects.equals(this.reason, value)) return this; 
/*  442 */     return new GuildEditMono(value, 
/*      */         
/*  444 */         name(), 
/*  445 */         region(), 
/*  446 */         verificationLevel(), 
/*  447 */         defaultMessageNotificationsLevel(), 
/*  448 */         explicitContentFilter(), 
/*  449 */         afkChannelId(), 
/*  450 */         afkTimeout(), 
/*  451 */         icon(), 
/*  452 */         ownerId(), 
/*  453 */         splash(), 
/*  454 */         discoverySplash(), 
/*  455 */         banner(), 
/*  456 */         systemChannelId(), 
/*  457 */         systemChannelFlags(), 
/*  458 */         rulesChannelId(), 
/*  459 */         publicUpdatesChannelId(), 
/*  460 */         preferredLocale(), 
/*  461 */         features(), 
/*  462 */         description(), 
/*  463 */         safetyAlertsChannelId(), this.guild);
/*      */   }
/*      */ 
/*      */   
/*      */   public GuildEditMono withName(Possible<String> value) {
/*  468 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/*  469 */     return new GuildEditMono(this.reason, newValue, 
/*      */ 
/*      */         
/*  472 */         region(), 
/*  473 */         verificationLevel(), 
/*  474 */         defaultMessageNotificationsLevel(), 
/*  475 */         explicitContentFilter(), 
/*  476 */         afkChannelId(), 
/*  477 */         afkTimeout(), 
/*  478 */         icon(), 
/*  479 */         ownerId(), 
/*  480 */         splash(), 
/*  481 */         discoverySplash(), 
/*  482 */         banner(), 
/*  483 */         systemChannelId(), 
/*  484 */         systemChannelFlags(), 
/*  485 */         rulesChannelId(), 
/*  486 */         publicUpdatesChannelId(), 
/*  487 */         preferredLocale(), 
/*  488 */         features(), 
/*  489 */         description(), 
/*  490 */         safetyAlertsChannelId(), this.guild);
/*      */   }
/*      */ 
/*      */   
/*      */   public GuildEditMono withName(String value) {
/*  495 */     Possible<String> newValue = Possible.of(value);
/*  496 */     return new GuildEditMono(this.reason, newValue, 
/*      */ 
/*      */         
/*  499 */         region(), 
/*  500 */         verificationLevel(), 
/*  501 */         defaultMessageNotificationsLevel(), 
/*  502 */         explicitContentFilter(), 
/*  503 */         afkChannelId(), 
/*  504 */         afkTimeout(), 
/*  505 */         icon(), 
/*  506 */         ownerId(), 
/*  507 */         splash(), 
/*  508 */         discoverySplash(), 
/*  509 */         banner(), 
/*  510 */         systemChannelId(), 
/*  511 */         systemChannelFlags(), 
/*  512 */         rulesChannelId(), 
/*  513 */         publicUpdatesChannelId(), 
/*  514 */         preferredLocale(), 
/*  515 */         features(), 
/*  516 */         description(), 
/*  517 */         safetyAlertsChannelId(), this.guild);
/*      */   }
/*      */ 
/*      */   
/*      */   public GuildEditMono withRegion(Possible<Optional<Region>> value) {
/*  522 */     Possible<Optional<Region>> newValue = Objects.<Possible<Optional<Region>>>requireNonNull(value);
/*  523 */     return new GuildEditMono(this.reason, 
/*      */         
/*  525 */         name(), newValue, 
/*      */         
/*  527 */         verificationLevel(), 
/*  528 */         defaultMessageNotificationsLevel(), 
/*  529 */         explicitContentFilter(), 
/*  530 */         afkChannelId(), 
/*  531 */         afkTimeout(), 
/*  532 */         icon(), 
/*  533 */         ownerId(), 
/*  534 */         splash(), 
/*  535 */         discoverySplash(), 
/*  536 */         banner(), 
/*  537 */         systemChannelId(), 
/*  538 */         systemChannelFlags(), 
/*  539 */         rulesChannelId(), 
/*  540 */         publicUpdatesChannelId(), 
/*  541 */         preferredLocale(), 
/*  542 */         features(), 
/*  543 */         description(), 
/*  544 */         safetyAlertsChannelId(), this.guild);
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public GuildEditMono withRegion(@Nullable Region value) {
/*  550 */     Possible<Optional<Region>> newValue = Possible.of(Optional.ofNullable(value));
/*  551 */     return new GuildEditMono(this.reason, 
/*      */         
/*  553 */         name(), newValue, 
/*      */         
/*  555 */         verificationLevel(), 
/*  556 */         defaultMessageNotificationsLevel(), 
/*  557 */         explicitContentFilter(), 
/*  558 */         afkChannelId(), 
/*  559 */         afkTimeout(), 
/*  560 */         icon(), 
/*  561 */         ownerId(), 
/*  562 */         splash(), 
/*  563 */         discoverySplash(), 
/*  564 */         banner(), 
/*  565 */         systemChannelId(), 
/*  566 */         systemChannelFlags(), 
/*  567 */         rulesChannelId(), 
/*  568 */         publicUpdatesChannelId(), 
/*  569 */         preferredLocale(), 
/*  570 */         features(), 
/*  571 */         description(), 
/*  572 */         safetyAlertsChannelId(), this.guild);
/*      */   }
/*      */ 
/*      */   
/*      */   public GuildEditMono withRegionOrNull(@Nullable Region value) {
/*  577 */     Possible<Optional<Region>> newValue = Possible.of(Optional.ofNullable(value));
/*  578 */     return new GuildEditMono(this.reason, 
/*      */         
/*  580 */         name(), newValue, 
/*      */         
/*  582 */         verificationLevel(), 
/*  583 */         defaultMessageNotificationsLevel(), 
/*  584 */         explicitContentFilter(), 
/*  585 */         afkChannelId(), 
/*  586 */         afkTimeout(), 
/*  587 */         icon(), 
/*  588 */         ownerId(), 
/*  589 */         splash(), 
/*  590 */         discoverySplash(), 
/*  591 */         banner(), 
/*  592 */         systemChannelId(), 
/*  593 */         systemChannelFlags(), 
/*  594 */         rulesChannelId(), 
/*  595 */         publicUpdatesChannelId(), 
/*  596 */         preferredLocale(), 
/*  597 */         features(), 
/*  598 */         description(), 
/*  599 */         safetyAlertsChannelId(), this.guild);
/*      */   }
/*      */ 
/*      */   
/*      */   public GuildEditMono withVerificationLevel(Possible<Optional<Guild.VerificationLevel>> value) {
/*  604 */     Possible<Optional<Guild.VerificationLevel>> newValue = Objects.<Possible<Optional<Guild.VerificationLevel>>>requireNonNull(value);
/*  605 */     return new GuildEditMono(this.reason, 
/*      */         
/*  607 */         name(), 
/*  608 */         region(), newValue, 
/*      */         
/*  610 */         defaultMessageNotificationsLevel(), 
/*  611 */         explicitContentFilter(), 
/*  612 */         afkChannelId(), 
/*  613 */         afkTimeout(), 
/*  614 */         icon(), 
/*  615 */         ownerId(), 
/*  616 */         splash(), 
/*  617 */         discoverySplash(), 
/*  618 */         banner(), 
/*  619 */         systemChannelId(), 
/*  620 */         systemChannelFlags(), 
/*  621 */         rulesChannelId(), 
/*  622 */         publicUpdatesChannelId(), 
/*  623 */         preferredLocale(), 
/*  624 */         features(), 
/*  625 */         description(), 
/*  626 */         safetyAlertsChannelId(), this.guild);
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public GuildEditMono withVerificationLevel(@Nullable Guild.VerificationLevel value) {
/*  632 */     Possible<Optional<Guild.VerificationLevel>> newValue = Possible.of(Optional.ofNullable(value));
/*  633 */     return new GuildEditMono(this.reason, 
/*      */         
/*  635 */         name(), 
/*  636 */         region(), newValue, 
/*      */         
/*  638 */         defaultMessageNotificationsLevel(), 
/*  639 */         explicitContentFilter(), 
/*  640 */         afkChannelId(), 
/*  641 */         afkTimeout(), 
/*  642 */         icon(), 
/*  643 */         ownerId(), 
/*  644 */         splash(), 
/*  645 */         discoverySplash(), 
/*  646 */         banner(), 
/*  647 */         systemChannelId(), 
/*  648 */         systemChannelFlags(), 
/*  649 */         rulesChannelId(), 
/*  650 */         publicUpdatesChannelId(), 
/*  651 */         preferredLocale(), 
/*  652 */         features(), 
/*  653 */         description(), 
/*  654 */         safetyAlertsChannelId(), this.guild);
/*      */   }
/*      */ 
/*      */   
/*      */   public GuildEditMono withVerificationLevelOrNull(@Nullable Guild.VerificationLevel value) {
/*  659 */     Possible<Optional<Guild.VerificationLevel>> newValue = Possible.of(Optional.ofNullable(value));
/*  660 */     return new GuildEditMono(this.reason, 
/*      */         
/*  662 */         name(), 
/*  663 */         region(), newValue, 
/*      */         
/*  665 */         defaultMessageNotificationsLevel(), 
/*  666 */         explicitContentFilter(), 
/*  667 */         afkChannelId(), 
/*  668 */         afkTimeout(), 
/*  669 */         icon(), 
/*  670 */         ownerId(), 
/*  671 */         splash(), 
/*  672 */         discoverySplash(), 
/*  673 */         banner(), 
/*  674 */         systemChannelId(), 
/*  675 */         systemChannelFlags(), 
/*  676 */         rulesChannelId(), 
/*  677 */         publicUpdatesChannelId(), 
/*  678 */         preferredLocale(), 
/*  679 */         features(), 
/*  680 */         description(), 
/*  681 */         safetyAlertsChannelId(), this.guild);
/*      */   }
/*      */ 
/*      */   
/*      */   public GuildEditMono withDefaultMessageNotificationsLevel(Possible<Optional<Guild.NotificationLevel>> value) {
/*  686 */     Possible<Optional<Guild.NotificationLevel>> newValue = Objects.<Possible<Optional<Guild.NotificationLevel>>>requireNonNull(value);
/*  687 */     return new GuildEditMono(this.reason, 
/*      */         
/*  689 */         name(), 
/*  690 */         region(), 
/*  691 */         verificationLevel(), newValue, 
/*      */         
/*  693 */         explicitContentFilter(), 
/*  694 */         afkChannelId(), 
/*  695 */         afkTimeout(), 
/*  696 */         icon(), 
/*  697 */         ownerId(), 
/*  698 */         splash(), 
/*  699 */         discoverySplash(), 
/*  700 */         banner(), 
/*  701 */         systemChannelId(), 
/*  702 */         systemChannelFlags(), 
/*  703 */         rulesChannelId(), 
/*  704 */         publicUpdatesChannelId(), 
/*  705 */         preferredLocale(), 
/*  706 */         features(), 
/*  707 */         description(), 
/*  708 */         safetyAlertsChannelId(), this.guild);
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public GuildEditMono withDefaultMessageNotificationsLevel(@Nullable Guild.NotificationLevel value) {
/*  714 */     Possible<Optional<Guild.NotificationLevel>> newValue = Possible.of(Optional.ofNullable(value));
/*  715 */     return new GuildEditMono(this.reason, 
/*      */         
/*  717 */         name(), 
/*  718 */         region(), 
/*  719 */         verificationLevel(), newValue, 
/*      */         
/*  721 */         explicitContentFilter(), 
/*  722 */         afkChannelId(), 
/*  723 */         afkTimeout(), 
/*  724 */         icon(), 
/*  725 */         ownerId(), 
/*  726 */         splash(), 
/*  727 */         discoverySplash(), 
/*  728 */         banner(), 
/*  729 */         systemChannelId(), 
/*  730 */         systemChannelFlags(), 
/*  731 */         rulesChannelId(), 
/*  732 */         publicUpdatesChannelId(), 
/*  733 */         preferredLocale(), 
/*  734 */         features(), 
/*  735 */         description(), 
/*  736 */         safetyAlertsChannelId(), this.guild);
/*      */   }
/*      */ 
/*      */   
/*      */   public GuildEditMono withDefaultMessageNotificationsLevelOrNull(@Nullable Guild.NotificationLevel value) {
/*  741 */     Possible<Optional<Guild.NotificationLevel>> newValue = Possible.of(Optional.ofNullable(value));
/*  742 */     return new GuildEditMono(this.reason, 
/*      */         
/*  744 */         name(), 
/*  745 */         region(), 
/*  746 */         verificationLevel(), newValue, 
/*      */         
/*  748 */         explicitContentFilter(), 
/*  749 */         afkChannelId(), 
/*  750 */         afkTimeout(), 
/*  751 */         icon(), 
/*  752 */         ownerId(), 
/*  753 */         splash(), 
/*  754 */         discoverySplash(), 
/*  755 */         banner(), 
/*  756 */         systemChannelId(), 
/*  757 */         systemChannelFlags(), 
/*  758 */         rulesChannelId(), 
/*  759 */         publicUpdatesChannelId(), 
/*  760 */         preferredLocale(), 
/*  761 */         features(), 
/*  762 */         description(), 
/*  763 */         safetyAlertsChannelId(), this.guild);
/*      */   }
/*      */ 
/*      */   
/*      */   public GuildEditMono withExplicitContentFilter(Possible<Optional<Guild.ContentFilterLevel>> value) {
/*  768 */     Possible<Optional<Guild.ContentFilterLevel>> newValue = Objects.<Possible<Optional<Guild.ContentFilterLevel>>>requireNonNull(value);
/*  769 */     return new GuildEditMono(this.reason, 
/*      */         
/*  771 */         name(), 
/*  772 */         region(), 
/*  773 */         verificationLevel(), 
/*  774 */         defaultMessageNotificationsLevel(), newValue, 
/*      */         
/*  776 */         afkChannelId(), 
/*  777 */         afkTimeout(), 
/*  778 */         icon(), 
/*  779 */         ownerId(), 
/*  780 */         splash(), 
/*  781 */         discoverySplash(), 
/*  782 */         banner(), 
/*  783 */         systemChannelId(), 
/*  784 */         systemChannelFlags(), 
/*  785 */         rulesChannelId(), 
/*  786 */         publicUpdatesChannelId(), 
/*  787 */         preferredLocale(), 
/*  788 */         features(), 
/*  789 */         description(), 
/*  790 */         safetyAlertsChannelId(), this.guild);
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public GuildEditMono withExplicitContentFilter(@Nullable Guild.ContentFilterLevel value) {
/*  796 */     Possible<Optional<Guild.ContentFilterLevel>> newValue = Possible.of(Optional.ofNullable(value));
/*  797 */     return new GuildEditMono(this.reason, 
/*      */         
/*  799 */         name(), 
/*  800 */         region(), 
/*  801 */         verificationLevel(), 
/*  802 */         defaultMessageNotificationsLevel(), newValue, 
/*      */         
/*  804 */         afkChannelId(), 
/*  805 */         afkTimeout(), 
/*  806 */         icon(), 
/*  807 */         ownerId(), 
/*  808 */         splash(), 
/*  809 */         discoverySplash(), 
/*  810 */         banner(), 
/*  811 */         systemChannelId(), 
/*  812 */         systemChannelFlags(), 
/*  813 */         rulesChannelId(), 
/*  814 */         publicUpdatesChannelId(), 
/*  815 */         preferredLocale(), 
/*  816 */         features(), 
/*  817 */         description(), 
/*  818 */         safetyAlertsChannelId(), this.guild);
/*      */   }
/*      */ 
/*      */   
/*      */   public GuildEditMono withExplicitContentFilterOrNull(@Nullable Guild.ContentFilterLevel value) {
/*  823 */     Possible<Optional<Guild.ContentFilterLevel>> newValue = Possible.of(Optional.ofNullable(value));
/*  824 */     return new GuildEditMono(this.reason, 
/*      */         
/*  826 */         name(), 
/*  827 */         region(), 
/*  828 */         verificationLevel(), 
/*  829 */         defaultMessageNotificationsLevel(), newValue, 
/*      */         
/*  831 */         afkChannelId(), 
/*  832 */         afkTimeout(), 
/*  833 */         icon(), 
/*  834 */         ownerId(), 
/*  835 */         splash(), 
/*  836 */         discoverySplash(), 
/*  837 */         banner(), 
/*  838 */         systemChannelId(), 
/*  839 */         systemChannelFlags(), 
/*  840 */         rulesChannelId(), 
/*  841 */         publicUpdatesChannelId(), 
/*  842 */         preferredLocale(), 
/*  843 */         features(), 
/*  844 */         description(), 
/*  845 */         safetyAlertsChannelId(), this.guild);
/*      */   }
/*      */ 
/*      */   
/*      */   public GuildEditMono withAfkChannelId(Possible<Optional<Snowflake>> value) {
/*  850 */     Possible<Optional<Snowflake>> newValue = Objects.<Possible<Optional<Snowflake>>>requireNonNull(value);
/*  851 */     return new GuildEditMono(this.reason, 
/*      */         
/*  853 */         name(), 
/*  854 */         region(), 
/*  855 */         verificationLevel(), 
/*  856 */         defaultMessageNotificationsLevel(), 
/*  857 */         explicitContentFilter(), newValue, 
/*      */         
/*  859 */         afkTimeout(), 
/*  860 */         icon(), 
/*  861 */         ownerId(), 
/*  862 */         splash(), 
/*  863 */         discoverySplash(), 
/*  864 */         banner(), 
/*  865 */         systemChannelId(), 
/*  866 */         systemChannelFlags(), 
/*  867 */         rulesChannelId(), 
/*  868 */         publicUpdatesChannelId(), 
/*  869 */         preferredLocale(), 
/*  870 */         features(), 
/*  871 */         description(), 
/*  872 */         safetyAlertsChannelId(), this.guild);
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public GuildEditMono withAfkChannelId(@Nullable Snowflake value) {
/*  878 */     Possible<Optional<Snowflake>> newValue = Possible.of(Optional.ofNullable(value));
/*  879 */     return new GuildEditMono(this.reason, 
/*      */         
/*  881 */         name(), 
/*  882 */         region(), 
/*  883 */         verificationLevel(), 
/*  884 */         defaultMessageNotificationsLevel(), 
/*  885 */         explicitContentFilter(), newValue, 
/*      */         
/*  887 */         afkTimeout(), 
/*  888 */         icon(), 
/*  889 */         ownerId(), 
/*  890 */         splash(), 
/*  891 */         discoverySplash(), 
/*  892 */         banner(), 
/*  893 */         systemChannelId(), 
/*  894 */         systemChannelFlags(), 
/*  895 */         rulesChannelId(), 
/*  896 */         publicUpdatesChannelId(), 
/*  897 */         preferredLocale(), 
/*  898 */         features(), 
/*  899 */         description(), 
/*  900 */         safetyAlertsChannelId(), this.guild);
/*      */   }
/*      */ 
/*      */   
/*      */   public GuildEditMono withAfkChannelIdOrNull(@Nullable Snowflake value) {
/*  905 */     Possible<Optional<Snowflake>> newValue = Possible.of(Optional.ofNullable(value));
/*  906 */     return new GuildEditMono(this.reason, 
/*      */         
/*  908 */         name(), 
/*  909 */         region(), 
/*  910 */         verificationLevel(), 
/*  911 */         defaultMessageNotificationsLevel(), 
/*  912 */         explicitContentFilter(), newValue, 
/*      */         
/*  914 */         afkTimeout(), 
/*  915 */         icon(), 
/*  916 */         ownerId(), 
/*  917 */         splash(), 
/*  918 */         discoverySplash(), 
/*  919 */         banner(), 
/*  920 */         systemChannelId(), 
/*  921 */         systemChannelFlags(), 
/*  922 */         rulesChannelId(), 
/*  923 */         publicUpdatesChannelId(), 
/*  924 */         preferredLocale(), 
/*  925 */         features(), 
/*  926 */         description(), 
/*  927 */         safetyAlertsChannelId(), this.guild);
/*      */   }
/*      */ 
/*      */   
/*      */   public GuildEditMono withAfkTimeout(Possible<Integer> value) {
/*  932 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/*  933 */     return new GuildEditMono(this.reason, 
/*      */         
/*  935 */         name(), 
/*  936 */         region(), 
/*  937 */         verificationLevel(), 
/*  938 */         defaultMessageNotificationsLevel(), 
/*  939 */         explicitContentFilter(), 
/*  940 */         afkChannelId(), newValue, 
/*      */         
/*  942 */         icon(), 
/*  943 */         ownerId(), 
/*  944 */         splash(), 
/*  945 */         discoverySplash(), 
/*  946 */         banner(), 
/*  947 */         systemChannelId(), 
/*  948 */         systemChannelFlags(), 
/*  949 */         rulesChannelId(), 
/*  950 */         publicUpdatesChannelId(), 
/*  951 */         preferredLocale(), 
/*  952 */         features(), 
/*  953 */         description(), 
/*  954 */         safetyAlertsChannelId(), this.guild);
/*      */   }
/*      */ 
/*      */   
/*      */   public GuildEditMono withAfkTimeout(Integer value) {
/*  959 */     Possible<Integer> newValue = Possible.of(value);
/*  960 */     return new GuildEditMono(this.reason, 
/*      */         
/*  962 */         name(), 
/*  963 */         region(), 
/*  964 */         verificationLevel(), 
/*  965 */         defaultMessageNotificationsLevel(), 
/*  966 */         explicitContentFilter(), 
/*  967 */         afkChannelId(), newValue, 
/*      */         
/*  969 */         icon(), 
/*  970 */         ownerId(), 
/*  971 */         splash(), 
/*  972 */         discoverySplash(), 
/*  973 */         banner(), 
/*  974 */         systemChannelId(), 
/*  975 */         systemChannelFlags(), 
/*  976 */         rulesChannelId(), 
/*  977 */         publicUpdatesChannelId(), 
/*  978 */         preferredLocale(), 
/*  979 */         features(), 
/*  980 */         description(), 
/*  981 */         safetyAlertsChannelId(), this.guild);
/*      */   }
/*      */ 
/*      */   
/*      */   public GuildEditMono withIcon(Possible<Optional<Image>> value) {
/*  986 */     Possible<Optional<Image>> newValue = Objects.<Possible<Optional<Image>>>requireNonNull(value);
/*  987 */     return new GuildEditMono(this.reason, 
/*      */         
/*  989 */         name(), 
/*  990 */         region(), 
/*  991 */         verificationLevel(), 
/*  992 */         defaultMessageNotificationsLevel(), 
/*  993 */         explicitContentFilter(), 
/*  994 */         afkChannelId(), 
/*  995 */         afkTimeout(), newValue, 
/*      */         
/*  997 */         ownerId(), 
/*  998 */         splash(), 
/*  999 */         discoverySplash(), 
/* 1000 */         banner(), 
/* 1001 */         systemChannelId(), 
/* 1002 */         systemChannelFlags(), 
/* 1003 */         rulesChannelId(), 
/* 1004 */         publicUpdatesChannelId(), 
/* 1005 */         preferredLocale(), 
/* 1006 */         features(), 
/* 1007 */         description(), 
/* 1008 */         safetyAlertsChannelId(), this.guild);
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public GuildEditMono withIcon(@Nullable Image value) {
/* 1014 */     Possible<Optional<Image>> newValue = Possible.of(Optional.ofNullable(value));
/* 1015 */     return new GuildEditMono(this.reason, 
/*      */         
/* 1017 */         name(), 
/* 1018 */         region(), 
/* 1019 */         verificationLevel(), 
/* 1020 */         defaultMessageNotificationsLevel(), 
/* 1021 */         explicitContentFilter(), 
/* 1022 */         afkChannelId(), 
/* 1023 */         afkTimeout(), newValue, 
/*      */         
/* 1025 */         ownerId(), 
/* 1026 */         splash(), 
/* 1027 */         discoverySplash(), 
/* 1028 */         banner(), 
/* 1029 */         systemChannelId(), 
/* 1030 */         systemChannelFlags(), 
/* 1031 */         rulesChannelId(), 
/* 1032 */         publicUpdatesChannelId(), 
/* 1033 */         preferredLocale(), 
/* 1034 */         features(), 
/* 1035 */         description(), 
/* 1036 */         safetyAlertsChannelId(), this.guild);
/*      */   }
/*      */ 
/*      */   
/*      */   public GuildEditMono withIconOrNull(@Nullable Image value) {
/* 1041 */     Possible<Optional<Image>> newValue = Possible.of(Optional.ofNullable(value));
/* 1042 */     return new GuildEditMono(this.reason, 
/*      */         
/* 1044 */         name(), 
/* 1045 */         region(), 
/* 1046 */         verificationLevel(), 
/* 1047 */         defaultMessageNotificationsLevel(), 
/* 1048 */         explicitContentFilter(), 
/* 1049 */         afkChannelId(), 
/* 1050 */         afkTimeout(), newValue, 
/*      */         
/* 1052 */         ownerId(), 
/* 1053 */         splash(), 
/* 1054 */         discoverySplash(), 
/* 1055 */         banner(), 
/* 1056 */         systemChannelId(), 
/* 1057 */         systemChannelFlags(), 
/* 1058 */         rulesChannelId(), 
/* 1059 */         publicUpdatesChannelId(), 
/* 1060 */         preferredLocale(), 
/* 1061 */         features(), 
/* 1062 */         description(), 
/* 1063 */         safetyAlertsChannelId(), this.guild);
/*      */   }
/*      */ 
/*      */   
/*      */   public GuildEditMono withOwnerId(Possible<Snowflake> value) {
/* 1068 */     Possible<Snowflake> newValue = Objects.<Possible<Snowflake>>requireNonNull(value);
/* 1069 */     return new GuildEditMono(this.reason, 
/*      */         
/* 1071 */         name(), 
/* 1072 */         region(), 
/* 1073 */         verificationLevel(), 
/* 1074 */         defaultMessageNotificationsLevel(), 
/* 1075 */         explicitContentFilter(), 
/* 1076 */         afkChannelId(), 
/* 1077 */         afkTimeout(), 
/* 1078 */         icon(), newValue, 
/*      */         
/* 1080 */         splash(), 
/* 1081 */         discoverySplash(), 
/* 1082 */         banner(), 
/* 1083 */         systemChannelId(), 
/* 1084 */         systemChannelFlags(), 
/* 1085 */         rulesChannelId(), 
/* 1086 */         publicUpdatesChannelId(), 
/* 1087 */         preferredLocale(), 
/* 1088 */         features(), 
/* 1089 */         description(), 
/* 1090 */         safetyAlertsChannelId(), this.guild);
/*      */   }
/*      */ 
/*      */   
/*      */   public GuildEditMono withOwnerId(Snowflake value) {
/* 1095 */     Possible<Snowflake> newValue = Possible.of(value);
/* 1096 */     return new GuildEditMono(this.reason, 
/*      */         
/* 1098 */         name(), 
/* 1099 */         region(), 
/* 1100 */         verificationLevel(), 
/* 1101 */         defaultMessageNotificationsLevel(), 
/* 1102 */         explicitContentFilter(), 
/* 1103 */         afkChannelId(), 
/* 1104 */         afkTimeout(), 
/* 1105 */         icon(), newValue, 
/*      */         
/* 1107 */         splash(), 
/* 1108 */         discoverySplash(), 
/* 1109 */         banner(), 
/* 1110 */         systemChannelId(), 
/* 1111 */         systemChannelFlags(), 
/* 1112 */         rulesChannelId(), 
/* 1113 */         publicUpdatesChannelId(), 
/* 1114 */         preferredLocale(), 
/* 1115 */         features(), 
/* 1116 */         description(), 
/* 1117 */         safetyAlertsChannelId(), this.guild);
/*      */   }
/*      */ 
/*      */   
/*      */   public GuildEditMono withSplash(Possible<Optional<Image>> value) {
/* 1122 */     Possible<Optional<Image>> newValue = Objects.<Possible<Optional<Image>>>requireNonNull(value);
/* 1123 */     return new GuildEditMono(this.reason, 
/*      */         
/* 1125 */         name(), 
/* 1126 */         region(), 
/* 1127 */         verificationLevel(), 
/* 1128 */         defaultMessageNotificationsLevel(), 
/* 1129 */         explicitContentFilter(), 
/* 1130 */         afkChannelId(), 
/* 1131 */         afkTimeout(), 
/* 1132 */         icon(), 
/* 1133 */         ownerId(), newValue, 
/*      */         
/* 1135 */         discoverySplash(), 
/* 1136 */         banner(), 
/* 1137 */         systemChannelId(), 
/* 1138 */         systemChannelFlags(), 
/* 1139 */         rulesChannelId(), 
/* 1140 */         publicUpdatesChannelId(), 
/* 1141 */         preferredLocale(), 
/* 1142 */         features(), 
/* 1143 */         description(), 
/* 1144 */         safetyAlertsChannelId(), this.guild);
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public GuildEditMono withSplash(@Nullable Image value) {
/* 1150 */     Possible<Optional<Image>> newValue = Possible.of(Optional.ofNullable(value));
/* 1151 */     return new GuildEditMono(this.reason, 
/*      */         
/* 1153 */         name(), 
/* 1154 */         region(), 
/* 1155 */         verificationLevel(), 
/* 1156 */         defaultMessageNotificationsLevel(), 
/* 1157 */         explicitContentFilter(), 
/* 1158 */         afkChannelId(), 
/* 1159 */         afkTimeout(), 
/* 1160 */         icon(), 
/* 1161 */         ownerId(), newValue, 
/*      */         
/* 1163 */         discoverySplash(), 
/* 1164 */         banner(), 
/* 1165 */         systemChannelId(), 
/* 1166 */         systemChannelFlags(), 
/* 1167 */         rulesChannelId(), 
/* 1168 */         publicUpdatesChannelId(), 
/* 1169 */         preferredLocale(), 
/* 1170 */         features(), 
/* 1171 */         description(), 
/* 1172 */         safetyAlertsChannelId(), this.guild);
/*      */   }
/*      */ 
/*      */   
/*      */   public GuildEditMono withSplashOrNull(@Nullable Image value) {
/* 1177 */     Possible<Optional<Image>> newValue = Possible.of(Optional.ofNullable(value));
/* 1178 */     return new GuildEditMono(this.reason, 
/*      */         
/* 1180 */         name(), 
/* 1181 */         region(), 
/* 1182 */         verificationLevel(), 
/* 1183 */         defaultMessageNotificationsLevel(), 
/* 1184 */         explicitContentFilter(), 
/* 1185 */         afkChannelId(), 
/* 1186 */         afkTimeout(), 
/* 1187 */         icon(), 
/* 1188 */         ownerId(), newValue, 
/*      */         
/* 1190 */         discoverySplash(), 
/* 1191 */         banner(), 
/* 1192 */         systemChannelId(), 
/* 1193 */         systemChannelFlags(), 
/* 1194 */         rulesChannelId(), 
/* 1195 */         publicUpdatesChannelId(), 
/* 1196 */         preferredLocale(), 
/* 1197 */         features(), 
/* 1198 */         description(), 
/* 1199 */         safetyAlertsChannelId(), this.guild);
/*      */   }
/*      */ 
/*      */   
/*      */   public GuildEditMono withDiscoverySplash(Possible<Optional<Image>> value) {
/* 1204 */     Possible<Optional<Image>> newValue = Objects.<Possible<Optional<Image>>>requireNonNull(value);
/* 1205 */     return new GuildEditMono(this.reason, 
/*      */         
/* 1207 */         name(), 
/* 1208 */         region(), 
/* 1209 */         verificationLevel(), 
/* 1210 */         defaultMessageNotificationsLevel(), 
/* 1211 */         explicitContentFilter(), 
/* 1212 */         afkChannelId(), 
/* 1213 */         afkTimeout(), 
/* 1214 */         icon(), 
/* 1215 */         ownerId(), 
/* 1216 */         splash(), newValue, 
/*      */         
/* 1218 */         banner(), 
/* 1219 */         systemChannelId(), 
/* 1220 */         systemChannelFlags(), 
/* 1221 */         rulesChannelId(), 
/* 1222 */         publicUpdatesChannelId(), 
/* 1223 */         preferredLocale(), 
/* 1224 */         features(), 
/* 1225 */         description(), 
/* 1226 */         safetyAlertsChannelId(), this.guild);
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public GuildEditMono withDiscoverySplash(@Nullable Image value) {
/* 1232 */     Possible<Optional<Image>> newValue = Possible.of(Optional.ofNullable(value));
/* 1233 */     return new GuildEditMono(this.reason, 
/*      */         
/* 1235 */         name(), 
/* 1236 */         region(), 
/* 1237 */         verificationLevel(), 
/* 1238 */         defaultMessageNotificationsLevel(), 
/* 1239 */         explicitContentFilter(), 
/* 1240 */         afkChannelId(), 
/* 1241 */         afkTimeout(), 
/* 1242 */         icon(), 
/* 1243 */         ownerId(), 
/* 1244 */         splash(), newValue, 
/*      */         
/* 1246 */         banner(), 
/* 1247 */         systemChannelId(), 
/* 1248 */         systemChannelFlags(), 
/* 1249 */         rulesChannelId(), 
/* 1250 */         publicUpdatesChannelId(), 
/* 1251 */         preferredLocale(), 
/* 1252 */         features(), 
/* 1253 */         description(), 
/* 1254 */         safetyAlertsChannelId(), this.guild);
/*      */   }
/*      */ 
/*      */   
/*      */   public GuildEditMono withDiscoverySplashOrNull(@Nullable Image value) {
/* 1259 */     Possible<Optional<Image>> newValue = Possible.of(Optional.ofNullable(value));
/* 1260 */     return new GuildEditMono(this.reason, 
/*      */         
/* 1262 */         name(), 
/* 1263 */         region(), 
/* 1264 */         verificationLevel(), 
/* 1265 */         defaultMessageNotificationsLevel(), 
/* 1266 */         explicitContentFilter(), 
/* 1267 */         afkChannelId(), 
/* 1268 */         afkTimeout(), 
/* 1269 */         icon(), 
/* 1270 */         ownerId(), 
/* 1271 */         splash(), newValue, 
/*      */         
/* 1273 */         banner(), 
/* 1274 */         systemChannelId(), 
/* 1275 */         systemChannelFlags(), 
/* 1276 */         rulesChannelId(), 
/* 1277 */         publicUpdatesChannelId(), 
/* 1278 */         preferredLocale(), 
/* 1279 */         features(), 
/* 1280 */         description(), 
/* 1281 */         safetyAlertsChannelId(), this.guild);
/*      */   }
/*      */ 
/*      */   
/*      */   public GuildEditMono withBanner(Possible<Optional<Image>> value) {
/* 1286 */     Possible<Optional<Image>> newValue = Objects.<Possible<Optional<Image>>>requireNonNull(value);
/* 1287 */     return new GuildEditMono(this.reason, 
/*      */         
/* 1289 */         name(), 
/* 1290 */         region(), 
/* 1291 */         verificationLevel(), 
/* 1292 */         defaultMessageNotificationsLevel(), 
/* 1293 */         explicitContentFilter(), 
/* 1294 */         afkChannelId(), 
/* 1295 */         afkTimeout(), 
/* 1296 */         icon(), 
/* 1297 */         ownerId(), 
/* 1298 */         splash(), 
/* 1299 */         discoverySplash(), newValue, 
/*      */         
/* 1301 */         systemChannelId(), 
/* 1302 */         systemChannelFlags(), 
/* 1303 */         rulesChannelId(), 
/* 1304 */         publicUpdatesChannelId(), 
/* 1305 */         preferredLocale(), 
/* 1306 */         features(), 
/* 1307 */         description(), 
/* 1308 */         safetyAlertsChannelId(), this.guild);
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public GuildEditMono withBanner(@Nullable Image value) {
/* 1314 */     Possible<Optional<Image>> newValue = Possible.of(Optional.ofNullable(value));
/* 1315 */     return new GuildEditMono(this.reason, 
/*      */         
/* 1317 */         name(), 
/* 1318 */         region(), 
/* 1319 */         verificationLevel(), 
/* 1320 */         defaultMessageNotificationsLevel(), 
/* 1321 */         explicitContentFilter(), 
/* 1322 */         afkChannelId(), 
/* 1323 */         afkTimeout(), 
/* 1324 */         icon(), 
/* 1325 */         ownerId(), 
/* 1326 */         splash(), 
/* 1327 */         discoverySplash(), newValue, 
/*      */         
/* 1329 */         systemChannelId(), 
/* 1330 */         systemChannelFlags(), 
/* 1331 */         rulesChannelId(), 
/* 1332 */         publicUpdatesChannelId(), 
/* 1333 */         preferredLocale(), 
/* 1334 */         features(), 
/* 1335 */         description(), 
/* 1336 */         safetyAlertsChannelId(), this.guild);
/*      */   }
/*      */ 
/*      */   
/*      */   public GuildEditMono withBannerOrNull(@Nullable Image value) {
/* 1341 */     Possible<Optional<Image>> newValue = Possible.of(Optional.ofNullable(value));
/* 1342 */     return new GuildEditMono(this.reason, 
/*      */         
/* 1344 */         name(), 
/* 1345 */         region(), 
/* 1346 */         verificationLevel(), 
/* 1347 */         defaultMessageNotificationsLevel(), 
/* 1348 */         explicitContentFilter(), 
/* 1349 */         afkChannelId(), 
/* 1350 */         afkTimeout(), 
/* 1351 */         icon(), 
/* 1352 */         ownerId(), 
/* 1353 */         splash(), 
/* 1354 */         discoverySplash(), newValue, 
/*      */         
/* 1356 */         systemChannelId(), 
/* 1357 */         systemChannelFlags(), 
/* 1358 */         rulesChannelId(), 
/* 1359 */         publicUpdatesChannelId(), 
/* 1360 */         preferredLocale(), 
/* 1361 */         features(), 
/* 1362 */         description(), 
/* 1363 */         safetyAlertsChannelId(), this.guild);
/*      */   }
/*      */ 
/*      */   
/*      */   public GuildEditMono withSystemChannelId(Possible<Optional<Snowflake>> value) {
/* 1368 */     Possible<Optional<Snowflake>> newValue = Objects.<Possible<Optional<Snowflake>>>requireNonNull(value);
/* 1369 */     return new GuildEditMono(this.reason, 
/*      */         
/* 1371 */         name(), 
/* 1372 */         region(), 
/* 1373 */         verificationLevel(), 
/* 1374 */         defaultMessageNotificationsLevel(), 
/* 1375 */         explicitContentFilter(), 
/* 1376 */         afkChannelId(), 
/* 1377 */         afkTimeout(), 
/* 1378 */         icon(), 
/* 1379 */         ownerId(), 
/* 1380 */         splash(), 
/* 1381 */         discoverySplash(), 
/* 1382 */         banner(), newValue, 
/*      */         
/* 1384 */         systemChannelFlags(), 
/* 1385 */         rulesChannelId(), 
/* 1386 */         publicUpdatesChannelId(), 
/* 1387 */         preferredLocale(), 
/* 1388 */         features(), 
/* 1389 */         description(), 
/* 1390 */         safetyAlertsChannelId(), this.guild);
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public GuildEditMono withSystemChannelId(@Nullable Snowflake value) {
/* 1396 */     Possible<Optional<Snowflake>> newValue = Possible.of(Optional.ofNullable(value));
/* 1397 */     return new GuildEditMono(this.reason, 
/*      */         
/* 1399 */         name(), 
/* 1400 */         region(), 
/* 1401 */         verificationLevel(), 
/* 1402 */         defaultMessageNotificationsLevel(), 
/* 1403 */         explicitContentFilter(), 
/* 1404 */         afkChannelId(), 
/* 1405 */         afkTimeout(), 
/* 1406 */         icon(), 
/* 1407 */         ownerId(), 
/* 1408 */         splash(), 
/* 1409 */         discoverySplash(), 
/* 1410 */         banner(), newValue, 
/*      */         
/* 1412 */         systemChannelFlags(), 
/* 1413 */         rulesChannelId(), 
/* 1414 */         publicUpdatesChannelId(), 
/* 1415 */         preferredLocale(), 
/* 1416 */         features(), 
/* 1417 */         description(), 
/* 1418 */         safetyAlertsChannelId(), this.guild);
/*      */   }
/*      */ 
/*      */   
/*      */   public GuildEditMono withSystemChannelIdOrNull(@Nullable Snowflake value) {
/* 1423 */     Possible<Optional<Snowflake>> newValue = Possible.of(Optional.ofNullable(value));
/* 1424 */     return new GuildEditMono(this.reason, 
/*      */         
/* 1426 */         name(), 
/* 1427 */         region(), 
/* 1428 */         verificationLevel(), 
/* 1429 */         defaultMessageNotificationsLevel(), 
/* 1430 */         explicitContentFilter(), 
/* 1431 */         afkChannelId(), 
/* 1432 */         afkTimeout(), 
/* 1433 */         icon(), 
/* 1434 */         ownerId(), 
/* 1435 */         splash(), 
/* 1436 */         discoverySplash(), 
/* 1437 */         banner(), newValue, 
/*      */         
/* 1439 */         systemChannelFlags(), 
/* 1440 */         rulesChannelId(), 
/* 1441 */         publicUpdatesChannelId(), 
/* 1442 */         preferredLocale(), 
/* 1443 */         features(), 
/* 1444 */         description(), 
/* 1445 */         safetyAlertsChannelId(), this.guild);
/*      */   }
/*      */ 
/*      */   
/*      */   public GuildEditMono withSystemChannelFlags(Possible<Guild.SystemChannelFlag> value) {
/* 1450 */     Possible<Guild.SystemChannelFlag> newValue = Objects.<Possible<Guild.SystemChannelFlag>>requireNonNull(value);
/* 1451 */     return new GuildEditMono(this.reason, 
/*      */         
/* 1453 */         name(), 
/* 1454 */         region(), 
/* 1455 */         verificationLevel(), 
/* 1456 */         defaultMessageNotificationsLevel(), 
/* 1457 */         explicitContentFilter(), 
/* 1458 */         afkChannelId(), 
/* 1459 */         afkTimeout(), 
/* 1460 */         icon(), 
/* 1461 */         ownerId(), 
/* 1462 */         splash(), 
/* 1463 */         discoverySplash(), 
/* 1464 */         banner(), 
/* 1465 */         systemChannelId(), newValue, 
/*      */         
/* 1467 */         rulesChannelId(), 
/* 1468 */         publicUpdatesChannelId(), 
/* 1469 */         preferredLocale(), 
/* 1470 */         features(), 
/* 1471 */         description(), 
/* 1472 */         safetyAlertsChannelId(), this.guild);
/*      */   }
/*      */ 
/*      */   
/*      */   public GuildEditMono withSystemChannelFlags(Guild.SystemChannelFlag value) {
/* 1477 */     Possible<Guild.SystemChannelFlag> newValue = Possible.of(value);
/* 1478 */     return new GuildEditMono(this.reason, 
/*      */         
/* 1480 */         name(), 
/* 1481 */         region(), 
/* 1482 */         verificationLevel(), 
/* 1483 */         defaultMessageNotificationsLevel(), 
/* 1484 */         explicitContentFilter(), 
/* 1485 */         afkChannelId(), 
/* 1486 */         afkTimeout(), 
/* 1487 */         icon(), 
/* 1488 */         ownerId(), 
/* 1489 */         splash(), 
/* 1490 */         discoverySplash(), 
/* 1491 */         banner(), 
/* 1492 */         systemChannelId(), newValue, 
/*      */         
/* 1494 */         rulesChannelId(), 
/* 1495 */         publicUpdatesChannelId(), 
/* 1496 */         preferredLocale(), 
/* 1497 */         features(), 
/* 1498 */         description(), 
/* 1499 */         safetyAlertsChannelId(), this.guild);
/*      */   }
/*      */ 
/*      */   
/*      */   public GuildEditMono withRulesChannelId(Possible<Optional<Snowflake>> value) {
/* 1504 */     Possible<Optional<Snowflake>> newValue = Objects.<Possible<Optional<Snowflake>>>requireNonNull(value);
/* 1505 */     return new GuildEditMono(this.reason, 
/*      */         
/* 1507 */         name(), 
/* 1508 */         region(), 
/* 1509 */         verificationLevel(), 
/* 1510 */         defaultMessageNotificationsLevel(), 
/* 1511 */         explicitContentFilter(), 
/* 1512 */         afkChannelId(), 
/* 1513 */         afkTimeout(), 
/* 1514 */         icon(), 
/* 1515 */         ownerId(), 
/* 1516 */         splash(), 
/* 1517 */         discoverySplash(), 
/* 1518 */         banner(), 
/* 1519 */         systemChannelId(), 
/* 1520 */         systemChannelFlags(), newValue, 
/*      */         
/* 1522 */         publicUpdatesChannelId(), 
/* 1523 */         preferredLocale(), 
/* 1524 */         features(), 
/* 1525 */         description(), 
/* 1526 */         safetyAlertsChannelId(), this.guild);
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public GuildEditMono withRulesChannelId(@Nullable Snowflake value) {
/* 1532 */     Possible<Optional<Snowflake>> newValue = Possible.of(Optional.ofNullable(value));
/* 1533 */     return new GuildEditMono(this.reason, 
/*      */         
/* 1535 */         name(), 
/* 1536 */         region(), 
/* 1537 */         verificationLevel(), 
/* 1538 */         defaultMessageNotificationsLevel(), 
/* 1539 */         explicitContentFilter(), 
/* 1540 */         afkChannelId(), 
/* 1541 */         afkTimeout(), 
/* 1542 */         icon(), 
/* 1543 */         ownerId(), 
/* 1544 */         splash(), 
/* 1545 */         discoverySplash(), 
/* 1546 */         banner(), 
/* 1547 */         systemChannelId(), 
/* 1548 */         systemChannelFlags(), newValue, 
/*      */         
/* 1550 */         publicUpdatesChannelId(), 
/* 1551 */         preferredLocale(), 
/* 1552 */         features(), 
/* 1553 */         description(), 
/* 1554 */         safetyAlertsChannelId(), this.guild);
/*      */   }
/*      */ 
/*      */   
/*      */   public GuildEditMono withRulesChannelIdOrNull(@Nullable Snowflake value) {
/* 1559 */     Possible<Optional<Snowflake>> newValue = Possible.of(Optional.ofNullable(value));
/* 1560 */     return new GuildEditMono(this.reason, 
/*      */         
/* 1562 */         name(), 
/* 1563 */         region(), 
/* 1564 */         verificationLevel(), 
/* 1565 */         defaultMessageNotificationsLevel(), 
/* 1566 */         explicitContentFilter(), 
/* 1567 */         afkChannelId(), 
/* 1568 */         afkTimeout(), 
/* 1569 */         icon(), 
/* 1570 */         ownerId(), 
/* 1571 */         splash(), 
/* 1572 */         discoverySplash(), 
/* 1573 */         banner(), 
/* 1574 */         systemChannelId(), 
/* 1575 */         systemChannelFlags(), newValue, 
/*      */         
/* 1577 */         publicUpdatesChannelId(), 
/* 1578 */         preferredLocale(), 
/* 1579 */         features(), 
/* 1580 */         description(), 
/* 1581 */         safetyAlertsChannelId(), this.guild);
/*      */   }
/*      */ 
/*      */   
/*      */   public GuildEditMono withPublicUpdatesChannelId(Possible<Optional<Snowflake>> value) {
/* 1586 */     Possible<Optional<Snowflake>> newValue = Objects.<Possible<Optional<Snowflake>>>requireNonNull(value);
/* 1587 */     return new GuildEditMono(this.reason, 
/*      */         
/* 1589 */         name(), 
/* 1590 */         region(), 
/* 1591 */         verificationLevel(), 
/* 1592 */         defaultMessageNotificationsLevel(), 
/* 1593 */         explicitContentFilter(), 
/* 1594 */         afkChannelId(), 
/* 1595 */         afkTimeout(), 
/* 1596 */         icon(), 
/* 1597 */         ownerId(), 
/* 1598 */         splash(), 
/* 1599 */         discoverySplash(), 
/* 1600 */         banner(), 
/* 1601 */         systemChannelId(), 
/* 1602 */         systemChannelFlags(), 
/* 1603 */         rulesChannelId(), newValue, 
/*      */         
/* 1605 */         preferredLocale(), 
/* 1606 */         features(), 
/* 1607 */         description(), 
/* 1608 */         safetyAlertsChannelId(), this.guild);
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public GuildEditMono withPublicUpdatesChannelId(@Nullable Snowflake value) {
/* 1614 */     Possible<Optional<Snowflake>> newValue = Possible.of(Optional.ofNullable(value));
/* 1615 */     return new GuildEditMono(this.reason, 
/*      */         
/* 1617 */         name(), 
/* 1618 */         region(), 
/* 1619 */         verificationLevel(), 
/* 1620 */         defaultMessageNotificationsLevel(), 
/* 1621 */         explicitContentFilter(), 
/* 1622 */         afkChannelId(), 
/* 1623 */         afkTimeout(), 
/* 1624 */         icon(), 
/* 1625 */         ownerId(), 
/* 1626 */         splash(), 
/* 1627 */         discoverySplash(), 
/* 1628 */         banner(), 
/* 1629 */         systemChannelId(), 
/* 1630 */         systemChannelFlags(), 
/* 1631 */         rulesChannelId(), newValue, 
/*      */         
/* 1633 */         preferredLocale(), 
/* 1634 */         features(), 
/* 1635 */         description(), 
/* 1636 */         safetyAlertsChannelId(), this.guild);
/*      */   }
/*      */ 
/*      */   
/*      */   public GuildEditMono withPublicUpdatesChannelIdOrNull(@Nullable Snowflake value) {
/* 1641 */     Possible<Optional<Snowflake>> newValue = Possible.of(Optional.ofNullable(value));
/* 1642 */     return new GuildEditMono(this.reason, 
/*      */         
/* 1644 */         name(), 
/* 1645 */         region(), 
/* 1646 */         verificationLevel(), 
/* 1647 */         defaultMessageNotificationsLevel(), 
/* 1648 */         explicitContentFilter(), 
/* 1649 */         afkChannelId(), 
/* 1650 */         afkTimeout(), 
/* 1651 */         icon(), 
/* 1652 */         ownerId(), 
/* 1653 */         splash(), 
/* 1654 */         discoverySplash(), 
/* 1655 */         banner(), 
/* 1656 */         systemChannelId(), 
/* 1657 */         systemChannelFlags(), 
/* 1658 */         rulesChannelId(), newValue, 
/*      */         
/* 1660 */         preferredLocale(), 
/* 1661 */         features(), 
/* 1662 */         description(), 
/* 1663 */         safetyAlertsChannelId(), this.guild);
/*      */   }
/*      */ 
/*      */   
/*      */   public GuildEditMono withPreferredLocale(Possible<Optional<Locale>> value) {
/* 1668 */     Possible<Optional<Locale>> newValue = Objects.<Possible<Optional<Locale>>>requireNonNull(value);
/* 1669 */     return new GuildEditMono(this.reason, 
/*      */         
/* 1671 */         name(), 
/* 1672 */         region(), 
/* 1673 */         verificationLevel(), 
/* 1674 */         defaultMessageNotificationsLevel(), 
/* 1675 */         explicitContentFilter(), 
/* 1676 */         afkChannelId(), 
/* 1677 */         afkTimeout(), 
/* 1678 */         icon(), 
/* 1679 */         ownerId(), 
/* 1680 */         splash(), 
/* 1681 */         discoverySplash(), 
/* 1682 */         banner(), 
/* 1683 */         systemChannelId(), 
/* 1684 */         systemChannelFlags(), 
/* 1685 */         rulesChannelId(), 
/* 1686 */         publicUpdatesChannelId(), newValue, 
/*      */         
/* 1688 */         features(), 
/* 1689 */         description(), 
/* 1690 */         safetyAlertsChannelId(), this.guild);
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public GuildEditMono withPreferredLocale(@Nullable Locale value) {
/* 1696 */     Possible<Optional<Locale>> newValue = Possible.of(Optional.ofNullable(value));
/* 1697 */     return new GuildEditMono(this.reason, 
/*      */         
/* 1699 */         name(), 
/* 1700 */         region(), 
/* 1701 */         verificationLevel(), 
/* 1702 */         defaultMessageNotificationsLevel(), 
/* 1703 */         explicitContentFilter(), 
/* 1704 */         afkChannelId(), 
/* 1705 */         afkTimeout(), 
/* 1706 */         icon(), 
/* 1707 */         ownerId(), 
/* 1708 */         splash(), 
/* 1709 */         discoverySplash(), 
/* 1710 */         banner(), 
/* 1711 */         systemChannelId(), 
/* 1712 */         systemChannelFlags(), 
/* 1713 */         rulesChannelId(), 
/* 1714 */         publicUpdatesChannelId(), newValue, 
/*      */         
/* 1716 */         features(), 
/* 1717 */         description(), 
/* 1718 */         safetyAlertsChannelId(), this.guild);
/*      */   }
/*      */ 
/*      */   
/*      */   public GuildEditMono withPreferredLocaleOrNull(@Nullable Locale value) {
/* 1723 */     Possible<Optional<Locale>> newValue = Possible.of(Optional.ofNullable(value));
/* 1724 */     return new GuildEditMono(this.reason, 
/*      */         
/* 1726 */         name(), 
/* 1727 */         region(), 
/* 1728 */         verificationLevel(), 
/* 1729 */         defaultMessageNotificationsLevel(), 
/* 1730 */         explicitContentFilter(), 
/* 1731 */         afkChannelId(), 
/* 1732 */         afkTimeout(), 
/* 1733 */         icon(), 
/* 1734 */         ownerId(), 
/* 1735 */         splash(), 
/* 1736 */         discoverySplash(), 
/* 1737 */         banner(), 
/* 1738 */         systemChannelId(), 
/* 1739 */         systemChannelFlags(), 
/* 1740 */         rulesChannelId(), 
/* 1741 */         publicUpdatesChannelId(), newValue, 
/*      */         
/* 1743 */         features(), 
/* 1744 */         description(), 
/* 1745 */         safetyAlertsChannelId(), this.guild);
/*      */   }
/*      */ 
/*      */   
/*      */   public GuildEditMono withFeatures(Possible<List<String>> possible) {
/* 1750 */     Possible<List<String>> newValue = Objects.<Possible<List<String>>>requireNonNull(possible);
/* 1751 */     return new GuildEditMono(this.reason, 
/*      */         
/* 1753 */         name(), 
/* 1754 */         region(), 
/* 1755 */         verificationLevel(), 
/* 1756 */         defaultMessageNotificationsLevel(), 
/* 1757 */         explicitContentFilter(), 
/* 1758 */         afkChannelId(), 
/* 1759 */         afkTimeout(), 
/* 1760 */         icon(), 
/* 1761 */         ownerId(), 
/* 1762 */         splash(), 
/* 1763 */         discoverySplash(), 
/* 1764 */         banner(), 
/* 1765 */         systemChannelId(), 
/* 1766 */         systemChannelFlags(), 
/* 1767 */         rulesChannelId(), 
/* 1768 */         publicUpdatesChannelId(), 
/* 1769 */         preferredLocale(), newValue, 
/*      */         
/* 1771 */         description(), 
/* 1772 */         safetyAlertsChannelId(), this.guild);
/*      */   }
/*      */ 
/*      */   
/*      */   public GuildEditMono withFeatures(Iterable<String> elements) {
/* 1777 */     Possible<List<String>> newValue = Possible.of(
/* 1778 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/* 1779 */     return new GuildEditMono(this.reason, 
/*      */         
/* 1781 */         name(), 
/* 1782 */         region(), 
/* 1783 */         verificationLevel(), 
/* 1784 */         defaultMessageNotificationsLevel(), 
/* 1785 */         explicitContentFilter(), 
/* 1786 */         afkChannelId(), 
/* 1787 */         afkTimeout(), 
/* 1788 */         icon(), 
/* 1789 */         ownerId(), 
/* 1790 */         splash(), 
/* 1791 */         discoverySplash(), 
/* 1792 */         banner(), 
/* 1793 */         systemChannelId(), 
/* 1794 */         systemChannelFlags(), 
/* 1795 */         rulesChannelId(), 
/* 1796 */         publicUpdatesChannelId(), 
/* 1797 */         preferredLocale(), newValue, 
/*      */         
/* 1799 */         description(), 
/* 1800 */         safetyAlertsChannelId(), this.guild);
/*      */   }
/*      */ 
/*      */   
/*      */   @SafeVarargs
/*      */   public final GuildEditMono withFeatures(String... elements) {
/* 1806 */     Possible<List<String>> newValue = Possible.of(Arrays.asList(elements));
/* 1807 */     return new GuildEditMono(this.reason, 
/*      */         
/* 1809 */         name(), 
/* 1810 */         region(), 
/* 1811 */         verificationLevel(), 
/* 1812 */         defaultMessageNotificationsLevel(), 
/* 1813 */         explicitContentFilter(), 
/* 1814 */         afkChannelId(), 
/* 1815 */         afkTimeout(), 
/* 1816 */         icon(), 
/* 1817 */         ownerId(), 
/* 1818 */         splash(), 
/* 1819 */         discoverySplash(), 
/* 1820 */         banner(), 
/* 1821 */         systemChannelId(), 
/* 1822 */         systemChannelFlags(), 
/* 1823 */         rulesChannelId(), 
/* 1824 */         publicUpdatesChannelId(), 
/* 1825 */         preferredLocale(), newValue, 
/*      */         
/* 1827 */         description(), 
/* 1828 */         safetyAlertsChannelId(), this.guild);
/*      */   }
/*      */ 
/*      */   
/*      */   public GuildEditMono withDescription(Possible<Optional<String>> value) {
/* 1833 */     Possible<Optional<String>> newValue = Objects.<Possible<Optional<String>>>requireNonNull(value);
/* 1834 */     return new GuildEditMono(this.reason, 
/*      */         
/* 1836 */         name(), 
/* 1837 */         region(), 
/* 1838 */         verificationLevel(), 
/* 1839 */         defaultMessageNotificationsLevel(), 
/* 1840 */         explicitContentFilter(), 
/* 1841 */         afkChannelId(), 
/* 1842 */         afkTimeout(), 
/* 1843 */         icon(), 
/* 1844 */         ownerId(), 
/* 1845 */         splash(), 
/* 1846 */         discoverySplash(), 
/* 1847 */         banner(), 
/* 1848 */         systemChannelId(), 
/* 1849 */         systemChannelFlags(), 
/* 1850 */         rulesChannelId(), 
/* 1851 */         publicUpdatesChannelId(), 
/* 1852 */         preferredLocale(), 
/* 1853 */         features(), newValue, 
/*      */         
/* 1855 */         safetyAlertsChannelId(), this.guild);
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public GuildEditMono withDescription(@Nullable String value) {
/* 1861 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/* 1862 */     return new GuildEditMono(this.reason, 
/*      */         
/* 1864 */         name(), 
/* 1865 */         region(), 
/* 1866 */         verificationLevel(), 
/* 1867 */         defaultMessageNotificationsLevel(), 
/* 1868 */         explicitContentFilter(), 
/* 1869 */         afkChannelId(), 
/* 1870 */         afkTimeout(), 
/* 1871 */         icon(), 
/* 1872 */         ownerId(), 
/* 1873 */         splash(), 
/* 1874 */         discoverySplash(), 
/* 1875 */         banner(), 
/* 1876 */         systemChannelId(), 
/* 1877 */         systemChannelFlags(), 
/* 1878 */         rulesChannelId(), 
/* 1879 */         publicUpdatesChannelId(), 
/* 1880 */         preferredLocale(), 
/* 1881 */         features(), newValue, 
/*      */         
/* 1883 */         safetyAlertsChannelId(), this.guild);
/*      */   }
/*      */ 
/*      */   
/*      */   public GuildEditMono withDescriptionOrNull(@Nullable String value) {
/* 1888 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/* 1889 */     return new GuildEditMono(this.reason, 
/*      */         
/* 1891 */         name(), 
/* 1892 */         region(), 
/* 1893 */         verificationLevel(), 
/* 1894 */         defaultMessageNotificationsLevel(), 
/* 1895 */         explicitContentFilter(), 
/* 1896 */         afkChannelId(), 
/* 1897 */         afkTimeout(), 
/* 1898 */         icon(), 
/* 1899 */         ownerId(), 
/* 1900 */         splash(), 
/* 1901 */         discoverySplash(), 
/* 1902 */         banner(), 
/* 1903 */         systemChannelId(), 
/* 1904 */         systemChannelFlags(), 
/* 1905 */         rulesChannelId(), 
/* 1906 */         publicUpdatesChannelId(), 
/* 1907 */         preferredLocale(), 
/* 1908 */         features(), newValue, 
/*      */         
/* 1910 */         safetyAlertsChannelId(), this.guild);
/*      */   }
/*      */ 
/*      */   
/*      */   public GuildEditMono withSafetyAlertsChannelId(Possible<Optional<Snowflake>> value) {
/* 1915 */     Possible<Optional<Snowflake>> newValue = Objects.<Possible<Optional<Snowflake>>>requireNonNull(value);
/* 1916 */     return new GuildEditMono(this.reason, 
/*      */         
/* 1918 */         name(), 
/* 1919 */         region(), 
/* 1920 */         verificationLevel(), 
/* 1921 */         defaultMessageNotificationsLevel(), 
/* 1922 */         explicitContentFilter(), 
/* 1923 */         afkChannelId(), 
/* 1924 */         afkTimeout(), 
/* 1925 */         icon(), 
/* 1926 */         ownerId(), 
/* 1927 */         splash(), 
/* 1928 */         discoverySplash(), 
/* 1929 */         banner(), 
/* 1930 */         systemChannelId(), 
/* 1931 */         systemChannelFlags(), 
/* 1932 */         rulesChannelId(), 
/* 1933 */         publicUpdatesChannelId(), 
/* 1934 */         preferredLocale(), 
/* 1935 */         features(), 
/* 1936 */         description(), newValue, this.guild);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public GuildEditMono withSafetyAlertsChannelId(@Nullable Snowflake value) {
/* 1943 */     Possible<Optional<Snowflake>> newValue = Possible.of(Optional.ofNullable(value));
/* 1944 */     return new GuildEditMono(this.reason, 
/*      */         
/* 1946 */         name(), 
/* 1947 */         region(), 
/* 1948 */         verificationLevel(), 
/* 1949 */         defaultMessageNotificationsLevel(), 
/* 1950 */         explicitContentFilter(), 
/* 1951 */         afkChannelId(), 
/* 1952 */         afkTimeout(), 
/* 1953 */         icon(), 
/* 1954 */         ownerId(), 
/* 1955 */         splash(), 
/* 1956 */         discoverySplash(), 
/* 1957 */         banner(), 
/* 1958 */         systemChannelId(), 
/* 1959 */         systemChannelFlags(), 
/* 1960 */         rulesChannelId(), 
/* 1961 */         publicUpdatesChannelId(), 
/* 1962 */         preferredLocale(), 
/* 1963 */         features(), 
/* 1964 */         description(), newValue, this.guild);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public GuildEditMono withSafetyAlertsChannelIdOrNull(@Nullable Snowflake value) {
/* 1970 */     Possible<Optional<Snowflake>> newValue = Possible.of(Optional.ofNullable(value));
/* 1971 */     return new GuildEditMono(this.reason, 
/*      */         
/* 1973 */         name(), 
/* 1974 */         region(), 
/* 1975 */         verificationLevel(), 
/* 1976 */         defaultMessageNotificationsLevel(), 
/* 1977 */         explicitContentFilter(), 
/* 1978 */         afkChannelId(), 
/* 1979 */         afkTimeout(), 
/* 1980 */         icon(), 
/* 1981 */         ownerId(), 
/* 1982 */         splash(), 
/* 1983 */         discoverySplash(), 
/* 1984 */         banner(), 
/* 1985 */         systemChannelId(), 
/* 1986 */         systemChannelFlags(), 
/* 1987 */         rulesChannelId(), 
/* 1988 */         publicUpdatesChannelId(), 
/* 1989 */         preferredLocale(), 
/* 1990 */         features(), 
/* 1991 */         description(), newValue, this.guild);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final GuildEditMono withGuild(Guild value) {
/* 2003 */     if (this.guild == value) return this; 
/* 2004 */     Guild newValue = Objects.<Guild>requireNonNull(value, "guild");
/* 2005 */     return new GuildEditMono(this.reason, 
/*      */         
/* 2007 */         name(), 
/* 2008 */         region(), 
/* 2009 */         verificationLevel(), 
/* 2010 */         defaultMessageNotificationsLevel(), 
/* 2011 */         explicitContentFilter(), 
/* 2012 */         afkChannelId(), 
/* 2013 */         afkTimeout(), 
/* 2014 */         icon(), 
/* 2015 */         ownerId(), 
/* 2016 */         splash(), 
/* 2017 */         discoverySplash(), 
/* 2018 */         banner(), 
/* 2019 */         systemChannelId(), 
/* 2020 */         systemChannelFlags(), 
/* 2021 */         rulesChannelId(), 
/* 2022 */         publicUpdatesChannelId(), 
/* 2023 */         preferredLocale(), 
/* 2024 */         features(), 
/* 2025 */         description(), 
/* 2026 */         safetyAlertsChannelId(), newValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean equals(Object another) {
/* 2036 */     if (this == another) return true; 
/* 2037 */     return (another instanceof GuildEditMono && 
/* 2038 */       equalTo(0, (GuildEditMono)another));
/*      */   }
/*      */   
/*      */   private boolean equalTo(int synthetic, GuildEditMono another) {
/* 2042 */     return (Objects.equals(this.reason, another.reason) && 
/* 2043 */       name().equals(another.name()) && 
/* 2044 */       region().equals(another.region()) && 
/* 2045 */       verificationLevel().equals(another.verificationLevel()) && 
/* 2046 */       defaultMessageNotificationsLevel().equals(another.defaultMessageNotificationsLevel()) && 
/* 2047 */       explicitContentFilter().equals(another.explicitContentFilter()) && 
/* 2048 */       afkChannelId().equals(another.afkChannelId()) && 
/* 2049 */       afkTimeout().equals(another.afkTimeout()) && 
/* 2050 */       icon().equals(another.icon()) && 
/* 2051 */       ownerId().equals(another.ownerId()) && 
/* 2052 */       splash().equals(another.splash()) && 
/* 2053 */       discoverySplash().equals(another.discoverySplash()) && 
/* 2054 */       banner().equals(another.banner()) && 
/* 2055 */       systemChannelId().equals(another.systemChannelId()) && 
/* 2056 */       systemChannelFlags().equals(another.systemChannelFlags()) && 
/* 2057 */       rulesChannelId().equals(another.rulesChannelId()) && 
/* 2058 */       publicUpdatesChannelId().equals(another.publicUpdatesChannelId()) && 
/* 2059 */       preferredLocale().equals(another.preferredLocale()) && 
/* 2060 */       Objects.equals(this.features_value, another.features_value) && 
/* 2061 */       description().equals(another.description()) && 
/* 2062 */       safetyAlertsChannelId().equals(another.safetyAlertsChannelId()) && this.guild
/* 2063 */       .equals(another.guild));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int hashCode() {
/* 2072 */     int h = 5381;
/* 2073 */     h += (h << 5) + Objects.hashCode(this.reason);
/* 2074 */     h += (h << 5) + name().hashCode();
/* 2075 */     h += (h << 5) + region().hashCode();
/* 2076 */     h += (h << 5) + verificationLevel().hashCode();
/* 2077 */     h += (h << 5) + defaultMessageNotificationsLevel().hashCode();
/* 2078 */     h += (h << 5) + explicitContentFilter().hashCode();
/* 2079 */     h += (h << 5) + afkChannelId().hashCode();
/* 2080 */     h += (h << 5) + afkTimeout().hashCode();
/* 2081 */     h += (h << 5) + icon().hashCode();
/* 2082 */     h += (h << 5) + ownerId().hashCode();
/* 2083 */     h += (h << 5) + splash().hashCode();
/* 2084 */     h += (h << 5) + discoverySplash().hashCode();
/* 2085 */     h += (h << 5) + banner().hashCode();
/* 2086 */     h += (h << 5) + systemChannelId().hashCode();
/* 2087 */     h += (h << 5) + systemChannelFlags().hashCode();
/* 2088 */     h += (h << 5) + rulesChannelId().hashCode();
/* 2089 */     h += (h << 5) + publicUpdatesChannelId().hashCode();
/* 2090 */     h += (h << 5) + preferredLocale().hashCode();
/* 2091 */     h += (h << 5) + Objects.hashCode(this.features_value);
/* 2092 */     h += (h << 5) + description().hashCode();
/* 2093 */     h += (h << 5) + safetyAlertsChannelId().hashCode();
/* 2094 */     h += (h << 5) + this.guild.hashCode();
/* 2095 */     return h;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/* 2104 */     return "GuildEditMono{reason=" + this.reason + ", name=" + 
/*      */       
/* 2106 */       name().toString() + ", region=" + 
/* 2107 */       region().toString() + ", verificationLevel=" + 
/* 2108 */       verificationLevel().toString() + ", defaultMessageNotificationsLevel=" + 
/* 2109 */       defaultMessageNotificationsLevel().toString() + ", explicitContentFilter=" + 
/* 2110 */       explicitContentFilter().toString() + ", afkChannelId=" + 
/* 2111 */       afkChannelId().toString() + ", afkTimeout=" + 
/* 2112 */       afkTimeout().toString() + ", icon=" + 
/* 2113 */       icon().toString() + ", ownerId=" + 
/* 2114 */       ownerId().toString() + ", splash=" + 
/* 2115 */       splash().toString() + ", discoverySplash=" + 
/* 2116 */       discoverySplash().toString() + ", banner=" + 
/* 2117 */       banner().toString() + ", systemChannelId=" + 
/* 2118 */       systemChannelId().toString() + ", systemChannelFlags=" + 
/* 2119 */       systemChannelFlags().toString() + ", rulesChannelId=" + 
/* 2120 */       rulesChannelId().toString() + ", publicUpdatesChannelId=" + 
/* 2121 */       publicUpdatesChannelId().toString() + ", preferredLocale=" + 
/* 2122 */       preferredLocale().toString() + ", features=" + 
/* 2123 */       Objects.toString(this.features_value) + ", description=" + 
/* 2124 */       description().toString() + ", safetyAlertsChannelId=" + 
/* 2125 */       safetyAlertsChannelId().toString() + ", guild=" + this.guild + "}";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static GuildEditMono of(Guild guild) {
/* 2136 */     return new GuildEditMono(guild);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static GuildEditMono copyOf(GuildEditMonoGenerator instance) {
/* 2147 */     if (instance instanceof GuildEditMono) {
/* 2148 */       return (GuildEditMono)instance;
/*      */     }
/* 2150 */     return of(instance.guild())
/* 2151 */       .withReason(instance.reason())
/* 2152 */       .withName(instance.name())
/* 2153 */       .withRegion(instance.region())
/* 2154 */       .withVerificationLevel(instance.verificationLevel())
/* 2155 */       .withDefaultMessageNotificationsLevel(instance.defaultMessageNotificationsLevel())
/* 2156 */       .withExplicitContentFilter(instance.explicitContentFilter())
/* 2157 */       .withAfkChannelId(instance.afkChannelId())
/* 2158 */       .withAfkTimeout(instance.afkTimeout())
/* 2159 */       .withIcon(instance.icon())
/* 2160 */       .withOwnerId(instance.ownerId())
/* 2161 */       .withSplash(instance.splash())
/* 2162 */       .withDiscoverySplash(instance.discoverySplash())
/* 2163 */       .withBanner(instance.banner())
/* 2164 */       .withSystemChannelId(instance.systemChannelId())
/* 2165 */       .withSystemChannelFlags(instance.systemChannelFlags())
/* 2166 */       .withRulesChannelId(instance.rulesChannelId())
/* 2167 */       .withPublicUpdatesChannelId(instance.publicUpdatesChannelId())
/* 2168 */       .withPreferredLocale(instance.preferredLocale())
/* 2169 */       .withFeatures(instance.features())
/* 2170 */       .withDescription(instance.description())
/* 2171 */       .withSafetyAlertsChannelId(instance.safetyAlertsChannelId());
/*      */   }
/*      */   
/*      */   public boolean isNamePresent() {
/* 2175 */     return !this.name_absent;
/*      */   }
/*      */   
/*      */   public String nameOrElse(String defaultValue) {
/* 2179 */     return !this.name_absent ? this.name_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isRegionPresent() {
/* 2183 */     return !this.region_absent;
/*      */   }
/*      */   
/*      */   public Region regionOrElse(Region defaultValue) {
/* 2187 */     return !this.region_absent ? this.region_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isVerificationLevelPresent() {
/* 2191 */     return !this.verificationLevel_absent;
/*      */   }
/*      */   
/*      */   public Guild.VerificationLevel verificationLevelOrElse(Guild.VerificationLevel defaultValue) {
/* 2195 */     return !this.verificationLevel_absent ? this.verificationLevel_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isDefaultMessageNotificationsLevelPresent() {
/* 2199 */     return !this.defaultMessageNotificationsLevel_absent;
/*      */   }
/*      */   
/*      */   public Guild.NotificationLevel defaultMessageNotificationsLevelOrElse(Guild.NotificationLevel defaultValue) {
/* 2203 */     return !this.defaultMessageNotificationsLevel_absent ? this.defaultMessageNotificationsLevel_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isExplicitContentFilterPresent() {
/* 2207 */     return !this.explicitContentFilter_absent;
/*      */   }
/*      */   
/*      */   public Guild.ContentFilterLevel explicitContentFilterOrElse(Guild.ContentFilterLevel defaultValue) {
/* 2211 */     return !this.explicitContentFilter_absent ? this.explicitContentFilter_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isAfkChannelIdPresent() {
/* 2215 */     return !this.afkChannelId_absent;
/*      */   }
/*      */   
/*      */   public Snowflake afkChannelIdOrElse(Snowflake defaultValue) {
/* 2219 */     return !this.afkChannelId_absent ? this.afkChannelId_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isAfkTimeoutPresent() {
/* 2223 */     return !this.afkTimeout_absent;
/*      */   }
/*      */   
/*      */   public Integer afkTimeoutOrElse(Integer defaultValue) {
/* 2227 */     return !this.afkTimeout_absent ? this.afkTimeout_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isIconPresent() {
/* 2231 */     return !this.icon_absent;
/*      */   }
/*      */   
/*      */   public Image iconOrElse(Image defaultValue) {
/* 2235 */     return !this.icon_absent ? this.icon_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isOwnerIdPresent() {
/* 2239 */     return !this.ownerId_absent;
/*      */   }
/*      */   
/*      */   public Snowflake ownerIdOrElse(Snowflake defaultValue) {
/* 2243 */     return !this.ownerId_absent ? this.ownerId_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isSplashPresent() {
/* 2247 */     return !this.splash_absent;
/*      */   }
/*      */   
/*      */   public Image splashOrElse(Image defaultValue) {
/* 2251 */     return !this.splash_absent ? this.splash_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isDiscoverySplashPresent() {
/* 2255 */     return !this.discoverySplash_absent;
/*      */   }
/*      */   
/*      */   public Image discoverySplashOrElse(Image defaultValue) {
/* 2259 */     return !this.discoverySplash_absent ? this.discoverySplash_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isBannerPresent() {
/* 2263 */     return !this.banner_absent;
/*      */   }
/*      */   
/*      */   public Image bannerOrElse(Image defaultValue) {
/* 2267 */     return !this.banner_absent ? this.banner_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isSystemChannelIdPresent() {
/* 2271 */     return !this.systemChannelId_absent;
/*      */   }
/*      */   
/*      */   public Snowflake systemChannelIdOrElse(Snowflake defaultValue) {
/* 2275 */     return !this.systemChannelId_absent ? this.systemChannelId_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isSystemChannelFlagsPresent() {
/* 2279 */     return !this.systemChannelFlags_absent;
/*      */   }
/*      */   
/*      */   public Guild.SystemChannelFlag systemChannelFlagsOrElse(Guild.SystemChannelFlag defaultValue) {
/* 2283 */     return !this.systemChannelFlags_absent ? this.systemChannelFlags_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isRulesChannelIdPresent() {
/* 2287 */     return !this.rulesChannelId_absent;
/*      */   }
/*      */   
/*      */   public Snowflake rulesChannelIdOrElse(Snowflake defaultValue) {
/* 2291 */     return !this.rulesChannelId_absent ? this.rulesChannelId_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isPublicUpdatesChannelIdPresent() {
/* 2295 */     return !this.publicUpdatesChannelId_absent;
/*      */   }
/*      */   
/*      */   public Snowflake publicUpdatesChannelIdOrElse(Snowflake defaultValue) {
/* 2299 */     return !this.publicUpdatesChannelId_absent ? this.publicUpdatesChannelId_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isPreferredLocalePresent() {
/* 2303 */     return !this.preferredLocale_absent;
/*      */   }
/*      */   
/*      */   public Locale preferredLocaleOrElse(Locale defaultValue) {
/* 2307 */     return !this.preferredLocale_absent ? this.preferredLocale_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isFeaturesPresent() {
/* 2311 */     return !this.features_absent;
/*      */   }
/*      */   
/*      */   public List<String> featuresOrElse(List<String> defaultValue) {
/* 2315 */     return !this.features_absent ? this.features_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isDescriptionPresent() {
/* 2319 */     return !this.description_absent;
/*      */   }
/*      */   
/*      */   public String descriptionOrElse(String defaultValue) {
/* 2323 */     return !this.description_absent ? this.description_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isSafetyAlertsChannelIdPresent() {
/* 2327 */     return !this.safetyAlertsChannelId_absent;
/*      */   }
/*      */   
/*      */   public Snowflake safetyAlertsChannelIdOrElse(Snowflake defaultValue) {
/* 2331 */     return !this.safetyAlertsChannelId_absent ? this.safetyAlertsChannelId_value : defaultValue;
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\GuildEditMono.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */