/*     */ package discord4j.core.spec;
/*     */ 
/*     */ import discord4j.core.object.entity.Guild;
/*     */ import discord4j.core.object.entity.Role;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import discord4j.rest.util.Color;
/*     */ import discord4j.rest.util.PermissionSet;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import org.immutables.value.Generated;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "RoleCreateMonoGenerator", generator = "Immutables")
/*     */ public final class RoleCreateMono
/*     */   extends RoleCreateMonoGenerator
/*     */ {
/*     */   @Nullable
/*     */   private final String reason;
/*     */   private final String name_value;
/*     */   private final boolean name_absent;
/*     */   private final PermissionSet permissions_value;
/*     */   private final boolean permissions_absent;
/*     */   private final Color color_value;
/*     */   private final boolean color_absent;
/*     */   private final Boolean hoist_value;
/*     */   private final boolean hoist_absent;
/*     */   private final Boolean mentionable_value;
/*     */   private final boolean mentionable_absent;
/*     */   private final String icon_value;
/*     */   private final boolean icon_absent;
/*     */   private final String unicodeEmoji_value;
/*     */   private final boolean unicodeEmoji_absent;
/*     */   private final Guild guild;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   private volatile transient InitShim initShim;
/*     */   
/*     */   private RoleCreateMono(Guild guild) {
/* 108 */     this.initShim = new InitShim(); this.guild = Objects.<Guild>requireNonNull(guild, "guild"); this.reason = null; Possible<String> name$impl = Possible.absent(); Possible<PermissionSet> permissions$impl = Possible.absent(); Possible<Color> color$impl = Possible.absent(); Possible<Boolean> hoist$impl = Possible.absent(); Possible<Boolean> mentionable$impl = Possible.absent(); Possible<Optional<String>> icon$impl = Possible.absent(); Possible<Optional<String>> unicodeEmoji$impl = Possible.absent(); this.name_value = name$impl.toOptional().orElse(null); this.name_absent = name$impl.isAbsent(); this.permissions_value = permissions$impl.toOptional().orElse(null); this.permissions_absent = permissions$impl.isAbsent(); this.color_value = color$impl.toOptional().orElse(null); this.color_absent = color$impl.isAbsent(); this.hoist_value = hoist$impl.toOptional().orElse(null); this.hoist_absent = hoist$impl.isAbsent(); this.mentionable_value = mentionable$impl.toOptional().orElse(null); this.mentionable_absent = mentionable$impl.isAbsent(); this.icon_value = Possible.flatOpt(icon$impl).orElse(null); this.icon_absent = icon$impl.isAbsent(); this.unicodeEmoji_value = Possible.flatOpt(unicodeEmoji$impl).orElse(null); this.unicodeEmoji_absent = unicodeEmoji$impl.isAbsent(); this.initShim = null; } private RoleCreateMono(@Nullable String reason, Possible<String> name, Possible<PermissionSet> permissions, Possible<Color> color, Possible<Boolean> hoist, Possible<Boolean> mentionable, Possible<Optional<String>> icon, Possible<Optional<String>> unicodeEmoji, Guild guild) { this.initShim = new InitShim(); this.reason = reason; Possible<String> name$impl = name; Possible<PermissionSet> permissions$impl = permissions; Possible<Color> color$impl = color; Possible<Boolean> hoist$impl = hoist; Possible<Boolean> mentionable$impl = mentionable; Possible<Optional<String>> icon$impl = icon; Possible<Optional<String>> unicodeEmoji$impl = unicodeEmoji; this.guild = guild; this.name_value = name$impl.toOptional().orElse(null); this.name_absent = name$impl.isAbsent(); this.permissions_value = permissions$impl.toOptional().orElse(null); this.permissions_absent = permissions$impl.isAbsent(); this.color_value = color$impl.toOptional().orElse(null); this.color_absent = color$impl.isAbsent(); this.hoist_value = hoist$impl.toOptional().orElse(null); this.hoist_absent = hoist$impl.isAbsent(); this.mentionable_value = mentionable$impl.toOptional().orElse(null);
/*     */     this.mentionable_absent = mentionable$impl.isAbsent();
/*     */     this.icon_value = Possible.flatOpt(icon$impl).orElse(null);
/*     */     this.icon_absent = icon$impl.isAbsent();
/*     */     this.unicodeEmoji_value = Possible.flatOpt(unicodeEmoji$impl).orElse(null);
/*     */     this.unicodeEmoji_absent = unicodeEmoji$impl.isAbsent();
/* 114 */     this.initShim = null; } @Generated(from = "RoleCreateMonoGenerator", generator = "Immutables") private final class InitShim { private InitShim() {} private String formatInitCycleMessage() { List<String> attributes = new ArrayList<>();
/* 115 */       return "Cannot build RoleCreateMono, attribute initializers form cycle " + attributes; }
/*     */      }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String reason() {
/* 125 */     return this.reason;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<String> name() {
/* 133 */     return this.name_absent ? Possible.absent() : Possible.of(this.name_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<PermissionSet> permissions() {
/* 141 */     return this.permissions_absent ? Possible.absent() : Possible.of(this.permissions_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Color> color() {
/* 149 */     return this.color_absent ? Possible.absent() : Possible.of(this.color_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Boolean> hoist() {
/* 157 */     return this.hoist_absent ? Possible.absent() : Possible.of(this.hoist_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Boolean> mentionable() {
/* 165 */     return this.mentionable_absent ? Possible.absent() : Possible.of(this.mentionable_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Optional<String>> icon() {
/* 173 */     return this.icon_absent ? Possible.absent() : 
/* 174 */       Possible.of(Optional.ofNullable(this.icon_value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Optional<String>> unicodeEmoji() {
/* 182 */     return this.unicodeEmoji_absent ? Possible.absent() : 
/* 183 */       Possible.of(Optional.ofNullable(this.unicodeEmoji_value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Guild guild() {
/* 191 */     return this.guild;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final RoleCreateMono withReason(@Nullable String value) {
/* 201 */     if (Objects.equals(this.reason, value)) return this; 
/* 202 */     return new RoleCreateMono(value, 
/*     */         
/* 204 */         name(), 
/* 205 */         permissions(), 
/* 206 */         color(), 
/* 207 */         hoist(), 
/* 208 */         mentionable(), 
/* 209 */         icon(), 
/* 210 */         unicodeEmoji(), this.guild);
/*     */   }
/*     */ 
/*     */   
/*     */   public RoleCreateMono withName(Possible<String> value) {
/* 215 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/* 216 */     return new RoleCreateMono(this.reason, newValue, 
/*     */ 
/*     */         
/* 219 */         permissions(), 
/* 220 */         color(), 
/* 221 */         hoist(), 
/* 222 */         mentionable(), 
/* 223 */         icon(), 
/* 224 */         unicodeEmoji(), this.guild);
/*     */   }
/*     */ 
/*     */   
/*     */   public RoleCreateMono withName(String value) {
/* 229 */     Possible<String> newValue = Possible.of(value);
/* 230 */     return new RoleCreateMono(this.reason, newValue, 
/*     */ 
/*     */         
/* 233 */         permissions(), 
/* 234 */         color(), 
/* 235 */         hoist(), 
/* 236 */         mentionable(), 
/* 237 */         icon(), 
/* 238 */         unicodeEmoji(), this.guild);
/*     */   }
/*     */ 
/*     */   
/*     */   public RoleCreateMono withPermissions(Possible<PermissionSet> value) {
/* 243 */     Possible<PermissionSet> newValue = Objects.<Possible<PermissionSet>>requireNonNull(value);
/* 244 */     return new RoleCreateMono(this.reason, 
/*     */         
/* 246 */         name(), newValue, 
/*     */         
/* 248 */         color(), 
/* 249 */         hoist(), 
/* 250 */         mentionable(), 
/* 251 */         icon(), 
/* 252 */         unicodeEmoji(), this.guild);
/*     */   }
/*     */ 
/*     */   
/*     */   public RoleCreateMono withPermissions(PermissionSet value) {
/* 257 */     Possible<PermissionSet> newValue = Possible.of(value);
/* 258 */     return new RoleCreateMono(this.reason, 
/*     */         
/* 260 */         name(), newValue, 
/*     */         
/* 262 */         color(), 
/* 263 */         hoist(), 
/* 264 */         mentionable(), 
/* 265 */         icon(), 
/* 266 */         unicodeEmoji(), this.guild);
/*     */   }
/*     */ 
/*     */   
/*     */   public RoleCreateMono withColor(Possible<Color> value) {
/* 271 */     Possible<Color> newValue = Objects.<Possible<Color>>requireNonNull(value);
/* 272 */     return new RoleCreateMono(this.reason, 
/*     */         
/* 274 */         name(), 
/* 275 */         permissions(), newValue, 
/*     */         
/* 277 */         hoist(), 
/* 278 */         mentionable(), 
/* 279 */         icon(), 
/* 280 */         unicodeEmoji(), this.guild);
/*     */   }
/*     */ 
/*     */   
/*     */   public RoleCreateMono withColor(Color value) {
/* 285 */     Possible<Color> newValue = Possible.of(value);
/* 286 */     return new RoleCreateMono(this.reason, 
/*     */         
/* 288 */         name(), 
/* 289 */         permissions(), newValue, 
/*     */         
/* 291 */         hoist(), 
/* 292 */         mentionable(), 
/* 293 */         icon(), 
/* 294 */         unicodeEmoji(), this.guild);
/*     */   }
/*     */ 
/*     */   
/*     */   public RoleCreateMono withHoist(Possible<Boolean> value) {
/* 299 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/* 300 */     return new RoleCreateMono(this.reason, 
/*     */         
/* 302 */         name(), 
/* 303 */         permissions(), 
/* 304 */         color(), newValue, 
/*     */         
/* 306 */         mentionable(), 
/* 307 */         icon(), 
/* 308 */         unicodeEmoji(), this.guild);
/*     */   }
/*     */ 
/*     */   
/*     */   public RoleCreateMono withHoist(Boolean value) {
/* 313 */     Possible<Boolean> newValue = Possible.of(value);
/* 314 */     return new RoleCreateMono(this.reason, 
/*     */         
/* 316 */         name(), 
/* 317 */         permissions(), 
/* 318 */         color(), newValue, 
/*     */         
/* 320 */         mentionable(), 
/* 321 */         icon(), 
/* 322 */         unicodeEmoji(), this.guild);
/*     */   }
/*     */ 
/*     */   
/*     */   public RoleCreateMono withMentionable(Possible<Boolean> value) {
/* 327 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/* 328 */     return new RoleCreateMono(this.reason, 
/*     */         
/* 330 */         name(), 
/* 331 */         permissions(), 
/* 332 */         color(), 
/* 333 */         hoist(), newValue, 
/*     */         
/* 335 */         icon(), 
/* 336 */         unicodeEmoji(), this.guild);
/*     */   }
/*     */ 
/*     */   
/*     */   public RoleCreateMono withMentionable(Boolean value) {
/* 341 */     Possible<Boolean> newValue = Possible.of(value);
/* 342 */     return new RoleCreateMono(this.reason, 
/*     */         
/* 344 */         name(), 
/* 345 */         permissions(), 
/* 346 */         color(), 
/* 347 */         hoist(), newValue, 
/*     */         
/* 349 */         icon(), 
/* 350 */         unicodeEmoji(), this.guild);
/*     */   }
/*     */ 
/*     */   
/*     */   public RoleCreateMono withIcon(Possible<Optional<String>> value) {
/* 355 */     Possible<Optional<String>> newValue = Objects.<Possible<Optional<String>>>requireNonNull(value);
/* 356 */     return new RoleCreateMono(this.reason, 
/*     */         
/* 358 */         name(), 
/* 359 */         permissions(), 
/* 360 */         color(), 
/* 361 */         hoist(), 
/* 362 */         mentionable(), newValue, 
/*     */         
/* 364 */         unicodeEmoji(), this.guild);
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public RoleCreateMono withIcon(@Nullable String value) {
/* 370 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/* 371 */     return new RoleCreateMono(this.reason, 
/*     */         
/* 373 */         name(), 
/* 374 */         permissions(), 
/* 375 */         color(), 
/* 376 */         hoist(), 
/* 377 */         mentionable(), newValue, 
/*     */         
/* 379 */         unicodeEmoji(), this.guild);
/*     */   }
/*     */ 
/*     */   
/*     */   public RoleCreateMono withIconOrNull(@Nullable String value) {
/* 384 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/* 385 */     return new RoleCreateMono(this.reason, 
/*     */         
/* 387 */         name(), 
/* 388 */         permissions(), 
/* 389 */         color(), 
/* 390 */         hoist(), 
/* 391 */         mentionable(), newValue, 
/*     */         
/* 393 */         unicodeEmoji(), this.guild);
/*     */   }
/*     */ 
/*     */   
/*     */   public RoleCreateMono withUnicodeEmoji(Possible<Optional<String>> value) {
/* 398 */     Possible<Optional<String>> newValue = Objects.<Possible<Optional<String>>>requireNonNull(value);
/* 399 */     return new RoleCreateMono(this.reason, 
/*     */         
/* 401 */         name(), 
/* 402 */         permissions(), 
/* 403 */         color(), 
/* 404 */         hoist(), 
/* 405 */         mentionable(), 
/* 406 */         icon(), newValue, this.guild);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public RoleCreateMono withUnicodeEmoji(@Nullable String value) {
/* 413 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/* 414 */     return new RoleCreateMono(this.reason, 
/*     */         
/* 416 */         name(), 
/* 417 */         permissions(), 
/* 418 */         color(), 
/* 419 */         hoist(), 
/* 420 */         mentionable(), 
/* 421 */         icon(), newValue, this.guild);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public RoleCreateMono withUnicodeEmojiOrNull(@Nullable String value) {
/* 427 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/* 428 */     return new RoleCreateMono(this.reason, 
/*     */         
/* 430 */         name(), 
/* 431 */         permissions(), 
/* 432 */         color(), 
/* 433 */         hoist(), 
/* 434 */         mentionable(), 
/* 435 */         icon(), newValue, this.guild);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final RoleCreateMono withGuild(Guild value) {
/* 447 */     if (this.guild == value) return this; 
/* 448 */     Guild newValue = Objects.<Guild>requireNonNull(value, "guild");
/* 449 */     return new RoleCreateMono(this.reason, 
/*     */         
/* 451 */         name(), 
/* 452 */         permissions(), 
/* 453 */         color(), 
/* 454 */         hoist(), 
/* 455 */         mentionable(), 
/* 456 */         icon(), 
/* 457 */         unicodeEmoji(), newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 467 */     if (this == another) return true; 
/* 468 */     return (another instanceof RoleCreateMono && 
/* 469 */       equalTo(0, (RoleCreateMono)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, RoleCreateMono another) {
/* 473 */     return (Objects.equals(this.reason, another.reason) && 
/* 474 */       name().equals(another.name()) && 
/* 475 */       permissions().equals(another.permissions()) && 
/* 476 */       color().equals(another.color()) && 
/* 477 */       hoist().equals(another.hoist()) && 
/* 478 */       mentionable().equals(another.mentionable()) && 
/* 479 */       icon().equals(another.icon()) && 
/* 480 */       unicodeEmoji().equals(another.unicodeEmoji()) && this.guild
/* 481 */       .equals(another.guild));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 490 */     int h = 5381;
/* 491 */     h += (h << 5) + Objects.hashCode(this.reason);
/* 492 */     h += (h << 5) + name().hashCode();
/* 493 */     h += (h << 5) + permissions().hashCode();
/* 494 */     h += (h << 5) + color().hashCode();
/* 495 */     h += (h << 5) + hoist().hashCode();
/* 496 */     h += (h << 5) + mentionable().hashCode();
/* 497 */     h += (h << 5) + icon().hashCode();
/* 498 */     h += (h << 5) + unicodeEmoji().hashCode();
/* 499 */     h += (h << 5) + this.guild.hashCode();
/* 500 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 509 */     return "RoleCreateMono{reason=" + this.reason + ", name=" + 
/*     */       
/* 511 */       name().toString() + ", permissions=" + 
/* 512 */       permissions().toString() + ", color=" + 
/* 513 */       color().toString() + ", hoist=" + 
/* 514 */       hoist().toString() + ", mentionable=" + 
/* 515 */       mentionable().toString() + ", icon=" + 
/* 516 */       icon().toString() + ", unicodeEmoji=" + 
/* 517 */       unicodeEmoji().toString() + ", guild=" + this.guild + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static RoleCreateMono of(Guild guild) {
/* 528 */     return new RoleCreateMono(guild);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static RoleCreateMono copyOf(RoleCreateMonoGenerator instance) {
/* 539 */     if (instance instanceof RoleCreateMono) {
/* 540 */       return (RoleCreateMono)instance;
/*     */     }
/* 542 */     return of(instance.guild())
/* 543 */       .withReason(instance.reason())
/* 544 */       .withName(instance.name())
/* 545 */       .withPermissions(instance.permissions())
/* 546 */       .withColor(instance.color())
/* 547 */       .withHoist(instance.hoist())
/* 548 */       .withMentionable(instance.mentionable())
/* 549 */       .withIcon(instance.icon())
/* 550 */       .withUnicodeEmoji(instance.unicodeEmoji());
/*     */   }
/*     */   
/*     */   public boolean isNamePresent() {
/* 554 */     return !this.name_absent;
/*     */   }
/*     */   
/*     */   public String nameOrElse(String defaultValue) {
/* 558 */     return !this.name_absent ? this.name_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isPermissionsPresent() {
/* 562 */     return !this.permissions_absent;
/*     */   }
/*     */   
/*     */   public PermissionSet permissionsOrElse(PermissionSet defaultValue) {
/* 566 */     return !this.permissions_absent ? this.permissions_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isColorPresent() {
/* 570 */     return !this.color_absent;
/*     */   }
/*     */   
/*     */   public Color colorOrElse(Color defaultValue) {
/* 574 */     return !this.color_absent ? this.color_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isHoistPresent() {
/* 578 */     return !this.hoist_absent;
/*     */   }
/*     */   
/*     */   public Boolean hoistOrElse(Boolean defaultValue) {
/* 582 */     return !this.hoist_absent ? this.hoist_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isMentionablePresent() {
/* 586 */     return !this.mentionable_absent;
/*     */   }
/*     */   
/*     */   public Boolean mentionableOrElse(Boolean defaultValue) {
/* 590 */     return !this.mentionable_absent ? this.mentionable_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isIconPresent() {
/* 594 */     return !this.icon_absent;
/*     */   }
/*     */   
/*     */   public String iconOrElse(String defaultValue) {
/* 598 */     return !this.icon_absent ? this.icon_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isUnicodeEmojiPresent() {
/* 602 */     return !this.unicodeEmoji_absent;
/*     */   }
/*     */   
/*     */   public String unicodeEmojiOrElse(String defaultValue) {
/* 606 */     return !this.unicodeEmoji_absent ? this.unicodeEmoji_value : defaultValue;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\RoleCreateMono.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */