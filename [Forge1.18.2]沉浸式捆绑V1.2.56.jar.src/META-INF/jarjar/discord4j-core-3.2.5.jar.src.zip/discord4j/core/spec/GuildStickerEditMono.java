/*     */ package discord4j.core.spec;
/*     */ 
/*     */ import discord4j.core.object.entity.GuildSticker;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "GuildStickerEditMonoGenerator", generator = "Immutables")
/*     */ public final class GuildStickerEditMono
/*     */   extends GuildStickerEditMonoGenerator
/*     */ {
/*     */   @Nullable
/*     */   private final String reason;
/*     */   private final String name_value;
/*     */   private final boolean name_absent;
/*     */   private final String description_value;
/*     */   private final boolean description_absent;
/*     */   private final String tags_value;
/*     */   private final boolean tags_absent;
/*     */   private final GuildSticker sticker;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   private volatile transient InitShim initShim;
/*     */   
/*     */   private GuildStickerEditMono(GuildSticker sticker) {
/*  69 */     this.initShim = new InitShim(); this.sticker = Objects.<GuildSticker>requireNonNull(sticker, "sticker"); this.reason = null; Possible<String> name$impl = Possible.absent(); Possible<String> description$impl = Possible.absent(); Possible<String> tags$impl = Possible.absent(); this.name_value = name$impl.toOptional().orElse(null); this.name_absent = name$impl.isAbsent(); this.description_value = description$impl.toOptional().orElse(null); this.description_absent = description$impl.isAbsent(); this.tags_value = tags$impl.toOptional().orElse(null); this.tags_absent = tags$impl.isAbsent(); this.initShim = null; } private GuildStickerEditMono(@Nullable String reason, Possible<String> name, Possible<String> description, Possible<String> tags, GuildSticker sticker) { this.initShim = new InitShim(); this.reason = reason; Possible<String> name$impl = name; Possible<String> description$impl = description; Possible<String> tags$impl = tags; this.sticker = sticker; this.name_value = name$impl.toOptional().orElse(null);
/*     */     this.name_absent = name$impl.isAbsent();
/*     */     this.description_value = description$impl.toOptional().orElse(null);
/*     */     this.description_absent = description$impl.isAbsent();
/*     */     this.tags_value = tags$impl.toOptional().orElse(null);
/*     */     this.tags_absent = tags$impl.isAbsent();
/*  75 */     this.initShim = null; } @Generated(from = "GuildStickerEditMonoGenerator", generator = "Immutables") private final class InitShim { private InitShim() {} private String formatInitCycleMessage() { List<String> attributes = new ArrayList<>();
/*  76 */       return "Cannot build GuildStickerEditMono, attribute initializers form cycle " + attributes; }
/*     */      }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String reason() {
/*  86 */     return this.reason;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<String> name() {
/*  94 */     return this.name_absent ? Possible.absent() : Possible.of(this.name_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<String> description() {
/* 102 */     return this.description_absent ? Possible.absent() : Possible.of(this.description_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<String> tags() {
/* 110 */     return this.tags_absent ? Possible.absent() : Possible.of(this.tags_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GuildSticker sticker() {
/* 118 */     return this.sticker;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final GuildStickerEditMono withReason(@Nullable String value) {
/* 128 */     if (Objects.equals(this.reason, value)) return this; 
/* 129 */     return new GuildStickerEditMono(value, name(), description(), tags(), this.sticker);
/*     */   }
/*     */   
/*     */   public GuildStickerEditMono withName(Possible<String> value) {
/* 133 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/* 134 */     return new GuildStickerEditMono(this.reason, newValue, description(), tags(), this.sticker);
/*     */   }
/*     */   
/*     */   public GuildStickerEditMono withName(String value) {
/* 138 */     Possible<String> newValue = Possible.of(value);
/* 139 */     return new GuildStickerEditMono(this.reason, newValue, description(), tags(), this.sticker);
/*     */   }
/*     */   
/*     */   public GuildStickerEditMono withDescription(Possible<String> value) {
/* 143 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/* 144 */     return new GuildStickerEditMono(this.reason, name(), newValue, tags(), this.sticker);
/*     */   }
/*     */   
/*     */   public GuildStickerEditMono withDescription(String value) {
/* 148 */     Possible<String> newValue = Possible.of(value);
/* 149 */     return new GuildStickerEditMono(this.reason, name(), newValue, tags(), this.sticker);
/*     */   }
/*     */   
/*     */   public GuildStickerEditMono withTags(Possible<String> value) {
/* 153 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/* 154 */     return new GuildStickerEditMono(this.reason, name(), description(), newValue, this.sticker);
/*     */   }
/*     */   
/*     */   public GuildStickerEditMono withTags(String value) {
/* 158 */     Possible<String> newValue = Possible.of(value);
/* 159 */     return new GuildStickerEditMono(this.reason, name(), description(), newValue, this.sticker);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final GuildStickerEditMono withSticker(GuildSticker value) {
/* 169 */     if (this.sticker == value) return this; 
/* 170 */     GuildSticker newValue = Objects.<GuildSticker>requireNonNull(value, "sticker");
/* 171 */     return new GuildStickerEditMono(this.reason, name(), description(), tags(), newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 180 */     if (this == another) return true; 
/* 181 */     return (another instanceof GuildStickerEditMono && 
/* 182 */       equalTo(0, (GuildStickerEditMono)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, GuildStickerEditMono another) {
/* 186 */     return (Objects.equals(this.reason, another.reason) && 
/* 187 */       name().equals(another.name()) && 
/* 188 */       description().equals(another.description()) && 
/* 189 */       tags().equals(another.tags()) && this.sticker
/* 190 */       .equals(another.sticker));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 199 */     int h = 5381;
/* 200 */     h += (h << 5) + Objects.hashCode(this.reason);
/* 201 */     h += (h << 5) + name().hashCode();
/* 202 */     h += (h << 5) + description().hashCode();
/* 203 */     h += (h << 5) + tags().hashCode();
/* 204 */     h += (h << 5) + this.sticker.hashCode();
/* 205 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 214 */     return "GuildStickerEditMono{reason=" + this.reason + ", name=" + 
/*     */       
/* 216 */       name().toString() + ", description=" + 
/* 217 */       description().toString() + ", tags=" + 
/* 218 */       tags().toString() + ", sticker=" + this.sticker + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static GuildStickerEditMono of(GuildSticker sticker) {
/* 229 */     return new GuildStickerEditMono(sticker);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static GuildStickerEditMono copyOf(GuildStickerEditMonoGenerator instance) {
/* 240 */     if (instance instanceof GuildStickerEditMono) {
/* 241 */       return (GuildStickerEditMono)instance;
/*     */     }
/* 243 */     return of(instance.sticker())
/* 244 */       .withReason(instance.reason())
/* 245 */       .withName(instance.name())
/* 246 */       .withDescription(instance.description())
/* 247 */       .withTags(instance.tags());
/*     */   }
/*     */   
/*     */   public boolean isNamePresent() {
/* 251 */     return !this.name_absent;
/*     */   }
/*     */   
/*     */   public String nameOrElse(String defaultValue) {
/* 255 */     return !this.name_absent ? this.name_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isDescriptionPresent() {
/* 259 */     return !this.description_absent;
/*     */   }
/*     */   
/*     */   public String descriptionOrElse(String defaultValue) {
/* 263 */     return !this.description_absent ? this.description_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isTagsPresent() {
/* 267 */     return !this.tags_absent;
/*     */   }
/*     */   
/*     */   public String tagsOrElse(String defaultValue) {
/* 271 */     return !this.tags_absent ? this.tags_value : defaultValue;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\GuildStickerEditMono.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */