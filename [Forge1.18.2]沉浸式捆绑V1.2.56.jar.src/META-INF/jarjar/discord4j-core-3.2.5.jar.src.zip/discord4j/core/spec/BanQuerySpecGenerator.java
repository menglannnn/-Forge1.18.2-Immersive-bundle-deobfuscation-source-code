/*    */ package discord4j.core.spec;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Immutable(singleton = true)
/*    */ interface BanQuerySpecGenerator
/*    */   extends AuditSpec<Map<String, Object>>
/*    */ {
/*    */   default Map<String, Object> asRequest() {
/* 45 */     Map<String, Object> request = new HashMap<>(2);
/* 46 */     InternalSpecUtils.putIfNotNull(request, "delete_message_seconds", deleteMessageSeconds());
/* 47 */     InternalSpecUtils.putIfNotNull(request, "delete_message_days", deleteMessageDays());
/* 48 */     InternalSpecUtils.putIfNotNull(request, "reason", reason());
/* 49 */     return request;
/*    */   }
/*    */   
/*    */   @Deprecated
/*    */   @Nullable
/*    */   Integer deleteMessageDays();
/*    */   
/*    */   @Nullable
/*    */   Integer deleteMessageSeconds();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\BanQuerySpecGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */