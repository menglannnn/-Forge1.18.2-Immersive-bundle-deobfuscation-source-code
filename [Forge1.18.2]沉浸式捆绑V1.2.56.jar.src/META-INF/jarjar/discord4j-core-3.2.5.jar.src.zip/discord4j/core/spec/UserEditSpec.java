/*     */ package discord4j.core.spec;
/*     */ 
/*     */ import com.google.errorprone.annotations.CanIgnoreReturnValue;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import discord4j.rest.util.Image;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "UserEditSpecGenerator", generator = "Immutables")
/*     */ public final class UserEditSpec
/*     */   implements UserEditSpecGenerator
/*     */ {
/*     */   private final String username_value;
/*     */   private final boolean username_absent;
/*     */   private final Image avatar_value;
/*     */   private final boolean avatar_absent;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   
/*     */   private UserEditSpec() {
/*  30 */     Possible<String> username$impl = Possible.absent();
/*  31 */     Possible<Image> avatar$impl = Possible.absent();
/*  32 */     this.username_value = username$impl.toOptional().orElse(null);
/*  33 */     this.username_absent = username$impl.isAbsent();
/*  34 */     this.avatar_value = avatar$impl.toOptional().orElse(null);
/*  35 */     this.avatar_absent = avatar$impl.isAbsent();
/*  36 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private UserEditSpec(Possible<String> username, Possible<Image> avatar) {
/*  42 */     Possible<String> username$impl = username;
/*  43 */     Possible<Image> avatar$impl = avatar;
/*  44 */     this.username_value = username$impl.toOptional().orElse(null);
/*  45 */     this.username_absent = username$impl.isAbsent();
/*  46 */     this.avatar_value = avatar$impl.toOptional().orElse(null);
/*  47 */     this.avatar_absent = avatar$impl.isAbsent();
/*  48 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  54 */   private volatile transient InitShim initShim = new InitShim();
/*     */   
/*     */   @Generated(from = "UserEditSpecGenerator", generator = "Immutables")
/*     */   private final class InitShim
/*     */   {
/*     */     private String formatInitCycleMessage() {
/*  60 */       List<String> attributes = new ArrayList<>();
/*  61 */       return "Cannot build UserEditSpec, attribute initializers form cycle " + attributes;
/*     */     }
/*     */ 
/*     */     
/*     */     private InitShim() {}
/*     */   }
/*     */ 
/*     */   
/*     */   public Possible<String> username() {
/*  70 */     return this.username_absent ? Possible.absent() : Possible.of(this.username_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Image> avatar() {
/*  78 */     return this.avatar_absent ? Possible.absent() : Possible.of(this.avatar_value);
/*     */   }
/*     */   
/*     */   public UserEditSpec withUsername(Possible<String> value) {
/*  82 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/*  83 */     return validate(new UserEditSpec(newValue, avatar()));
/*     */   }
/*     */   
/*     */   public UserEditSpec withUsername(String value) {
/*  87 */     Possible<String> newValue = Possible.of(value);
/*  88 */     return validate(new UserEditSpec(newValue, avatar()));
/*     */   }
/*     */   
/*     */   public UserEditSpec withAvatar(Possible<Image> value) {
/*  92 */     Possible<Image> newValue = Objects.<Possible<Image>>requireNonNull(value);
/*  93 */     return validate(new UserEditSpec(username(), newValue));
/*     */   }
/*     */   
/*     */   public UserEditSpec withAvatar(Image value) {
/*  97 */     Possible<Image> newValue = Possible.of(value);
/*  98 */     return validate(new UserEditSpec(username(), newValue));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 107 */     if (this == another) return true; 
/* 108 */     return (another instanceof UserEditSpec && 
/* 109 */       equalTo(0, (UserEditSpec)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, UserEditSpec another) {
/* 113 */     return (username().equals(another.username()) && 
/* 114 */       avatar().equals(another.avatar()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 123 */     int h = 5381;
/* 124 */     h += (h << 5) + username().hashCode();
/* 125 */     h += (h << 5) + avatar().hashCode();
/* 126 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 135 */     return "UserEditSpec{username=" + 
/* 136 */       username().toString() + ", avatar=" + 
/* 137 */       avatar().toString() + "}";
/*     */   }
/*     */ 
/*     */   
/* 141 */   private static final UserEditSpec INSTANCE = validate(new UserEditSpec());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static UserEditSpec create() {
/* 148 */     return INSTANCE;
/*     */   }
/*     */   
/*     */   private static UserEditSpec validate(UserEditSpec instance) {
/* 152 */     return (INSTANCE != null && INSTANCE.equalTo(0, instance)) ? INSTANCE : instance;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static UserEditSpec copyOf(UserEditSpecGenerator instance) {
/* 163 */     if (instance instanceof UserEditSpec) {
/* 164 */       return (UserEditSpec)instance;
/*     */     }
/* 166 */     return builder()
/* 167 */       .from(instance)
/* 168 */       .build();
/*     */   }
/*     */   
/*     */   public boolean isUsernamePresent() {
/* 172 */     return !this.username_absent;
/*     */   }
/*     */   
/*     */   public String usernameOrElse(String defaultValue) {
/* 176 */     return !this.username_absent ? this.username_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isAvatarPresent() {
/* 180 */     return !this.avatar_absent;
/*     */   }
/*     */   
/*     */   public Image avatarOrElse(Image defaultValue) {
/* 184 */     return !this.avatar_absent ? this.avatar_value : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 198 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "UserEditSpecGenerator", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/* 210 */     private Possible<String> username_possible = Possible.absent();
/* 211 */     private Possible<Image> avatar_possible = Possible.absent();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(UserEditSpec instance) {
/* 224 */       return from(instance);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     final Builder from(UserEditSpecGenerator instance) {
/* 234 */       Objects.requireNonNull(instance, "instance");
/* 235 */       username(instance.username());
/* 236 */       avatar(instance.avatar());
/* 237 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder username(Possible<String> value) {
/* 242 */       this.username_possible = value;
/* 243 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder username(String value) {
/* 248 */       this.username_possible = Possible.of(value);
/* 249 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder avatar(Possible<Image> value) {
/* 254 */       this.avatar_possible = value;
/* 255 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder avatar(Image value) {
/* 260 */       this.avatar_possible = Possible.of(value);
/* 261 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public UserEditSpec build() {
/* 270 */       return UserEditSpec.validate(new UserEditSpec(username_build(), avatar_build()));
/*     */     }
/*     */     
/*     */     private Possible<String> username_build() {
/* 274 */       return this.username_possible;
/*     */     }
/*     */     
/*     */     private Possible<Image> avatar_build() {
/* 278 */       return this.avatar_possible;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\UserEditSpec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */