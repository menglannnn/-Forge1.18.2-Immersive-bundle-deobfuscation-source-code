/*     */ package discord4j.core.spec;
/*     */ 
/*     */ import com.google.errorprone.annotations.CanIgnoreReturnValue;
/*     */ import discord4j.core.object.component.LayoutComponent;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.stream.StreamSupport;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "InteractionPresentModalSpecGenerator", generator = "Immutables")
/*     */ public final class InteractionPresentModalSpec
/*     */   implements InteractionPresentModalSpecGenerator
/*     */ {
/*     */   private final String title_value;
/*     */   private final boolean title_absent;
/*     */   private final String customId_value;
/*     */   private final boolean customId_absent;
/*     */   private final List<LayoutComponent> components_value;
/*     */   private final boolean components_absent;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   
/*     */   private InteractionPresentModalSpec() {
/*  36 */     Possible<String> title$impl = Possible.absent();
/*  37 */     Possible<String> customId$impl = Possible.absent();
/*  38 */     Possible<List<LayoutComponent>> components$impl = Possible.absent();
/*  39 */     this.title_value = title$impl.toOptional().orElse(null);
/*  40 */     this.title_absent = title$impl.isAbsent();
/*  41 */     this.customId_value = customId$impl.toOptional().orElse(null);
/*  42 */     this.customId_absent = customId$impl.isAbsent();
/*  43 */     this.components_value = components$impl.toOptional().orElse(null);
/*  44 */     this.components_absent = components$impl.isAbsent();
/*  45 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private InteractionPresentModalSpec(Possible<String> title, Possible<String> customId, Possible<List<LayoutComponent>> components) {
/*  52 */     Possible<String> title$impl = title;
/*  53 */     Possible<String> customId$impl = customId;
/*  54 */     Possible<List<LayoutComponent>> components$impl = components;
/*  55 */     this.title_value = title$impl.toOptional().orElse(null);
/*  56 */     this.title_absent = title$impl.isAbsent();
/*  57 */     this.customId_value = customId$impl.toOptional().orElse(null);
/*  58 */     this.customId_absent = customId$impl.isAbsent();
/*  59 */     this.components_value = components$impl.toOptional().orElse(null);
/*  60 */     this.components_absent = components$impl.isAbsent();
/*  61 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  67 */   private volatile transient InitShim initShim = new InitShim();
/*     */   
/*     */   @Generated(from = "InteractionPresentModalSpecGenerator", generator = "Immutables")
/*     */   private final class InitShim
/*     */   {
/*     */     private String formatInitCycleMessage() {
/*  73 */       List<String> attributes = new ArrayList<>();
/*  74 */       return "Cannot build InteractionPresentModalSpec, attribute initializers form cycle " + attributes;
/*     */     }
/*     */ 
/*     */     
/*     */     private InitShim() {}
/*     */   }
/*     */ 
/*     */   
/*     */   public Possible<String> title() {
/*  83 */     return this.title_absent ? Possible.absent() : Possible.of(this.title_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<String> customId() {
/*  91 */     return this.customId_absent ? Possible.absent() : Possible.of(this.customId_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<List<LayoutComponent>> components() {
/*  99 */     return this.components_absent ? Possible.absent() : 
/* 100 */       Possible.of(this.components_value);
/*     */   }
/*     */   
/*     */   public InteractionPresentModalSpec withTitle(Possible<String> value) {
/* 104 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/* 105 */     return validate(new InteractionPresentModalSpec(newValue, customId(), components()));
/*     */   }
/*     */   
/*     */   public InteractionPresentModalSpec withTitle(String value) {
/* 109 */     Possible<String> newValue = Possible.of(value);
/* 110 */     return validate(new InteractionPresentModalSpec(newValue, customId(), components()));
/*     */   }
/*     */   
/*     */   public InteractionPresentModalSpec withCustomId(Possible<String> value) {
/* 114 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/* 115 */     return validate(new InteractionPresentModalSpec(title(), newValue, components()));
/*     */   }
/*     */   
/*     */   public InteractionPresentModalSpec withCustomId(String value) {
/* 119 */     Possible<String> newValue = Possible.of(value);
/* 120 */     return validate(new InteractionPresentModalSpec(title(), newValue, components()));
/*     */   }
/*     */   
/*     */   public InteractionPresentModalSpec withComponents(Possible<List<LayoutComponent>> possible) {
/* 124 */     Possible<List<LayoutComponent>> newValue = Objects.<Possible<List<LayoutComponent>>>requireNonNull(possible);
/* 125 */     return validate(new InteractionPresentModalSpec(title(), customId(), newValue));
/*     */   }
/*     */   
/*     */   public InteractionPresentModalSpec withComponents(Iterable<LayoutComponent> elements) {
/* 129 */     Possible<List<LayoutComponent>> newValue = Possible.of(
/* 130 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/* 131 */     return validate(new InteractionPresentModalSpec(title(), customId(), newValue));
/*     */   }
/*     */   
/*     */   @SafeVarargs
/*     */   public final InteractionPresentModalSpec withComponents(LayoutComponent... elements) {
/* 136 */     Possible<List<LayoutComponent>> newValue = Possible.of(Arrays.asList(elements));
/* 137 */     return validate(new InteractionPresentModalSpec(title(), customId(), newValue));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 146 */     if (this == another) return true; 
/* 147 */     return (another instanceof InteractionPresentModalSpec && 
/* 148 */       equalTo(0, (InteractionPresentModalSpec)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, InteractionPresentModalSpec another) {
/* 152 */     return (title().equals(another.title()) && 
/* 153 */       customId().equals(another.customId()) && 
/* 154 */       Objects.equals(this.components_value, another.components_value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 163 */     int h = 5381;
/* 164 */     h += (h << 5) + title().hashCode();
/* 165 */     h += (h << 5) + customId().hashCode();
/* 166 */     h += (h << 5) + Objects.hashCode(this.components_value);
/* 167 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 176 */     return "InteractionPresentModalSpec{title=" + 
/* 177 */       title().toString() + ", customId=" + 
/* 178 */       customId().toString() + ", components=" + 
/* 179 */       Objects.toString(this.components_value) + "}";
/*     */   }
/*     */ 
/*     */   
/* 183 */   private static final InteractionPresentModalSpec INSTANCE = validate(new InteractionPresentModalSpec());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static InteractionPresentModalSpec create() {
/* 190 */     return INSTANCE;
/*     */   }
/*     */   
/*     */   private static InteractionPresentModalSpec validate(InteractionPresentModalSpec instance) {
/* 194 */     return (INSTANCE != null && INSTANCE.equalTo(0, instance)) ? INSTANCE : instance;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static InteractionPresentModalSpec copyOf(InteractionPresentModalSpecGenerator instance) {
/* 205 */     if (instance instanceof InteractionPresentModalSpec) {
/* 206 */       return (InteractionPresentModalSpec)instance;
/*     */     }
/* 208 */     return builder()
/* 209 */       .from(instance)
/* 210 */       .build();
/*     */   }
/*     */   
/*     */   public boolean isTitlePresent() {
/* 214 */     return !this.title_absent;
/*     */   }
/*     */   
/*     */   public String titleOrElse(String defaultValue) {
/* 218 */     return !this.title_absent ? this.title_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isCustomIdPresent() {
/* 222 */     return !this.customId_absent;
/*     */   }
/*     */   
/*     */   public String customIdOrElse(String defaultValue) {
/* 226 */     return !this.customId_absent ? this.customId_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isComponentsPresent() {
/* 230 */     return !this.components_absent;
/*     */   }
/*     */   
/*     */   public List<LayoutComponent> componentsOrElse(List<LayoutComponent> defaultValue) {
/* 234 */     return !this.components_absent ? this.components_value : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 249 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "InteractionPresentModalSpecGenerator", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/* 261 */     private Possible<String> title_possible = Possible.absent();
/* 262 */     private Possible<String> customId_possible = Possible.absent();
/* 263 */     private List<LayoutComponent> components_list = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(InteractionPresentModalSpec instance) {
/* 276 */       return from(instance);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     final Builder from(InteractionPresentModalSpecGenerator instance) {
/* 286 */       Objects.requireNonNull(instance, "instance");
/* 287 */       title(instance.title());
/* 288 */       customId(instance.customId());
/* 289 */       components(instance.components());
/* 290 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder title(Possible<String> value) {
/* 295 */       this.title_possible = value;
/* 296 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder title(String value) {
/* 301 */       this.title_possible = Possible.of(value);
/* 302 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder customId(Possible<String> value) {
/* 307 */       this.customId_possible = value;
/* 308 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder customId(String value) {
/* 313 */       this.customId_possible = Possible.of(value);
/* 314 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder addComponent(LayoutComponent element) {
/* 319 */       components_getOrCreate().add(element);
/* 320 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder addAllComponents(List<LayoutComponent> elements) {
/* 325 */       components_getOrCreate().addAll(elements);
/* 326 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder components(Possible<List<LayoutComponent>> elements) {
/* 331 */       this.components_list = null;
/* 332 */       elements.toOptional().ifPresent(e -> components_getOrCreate().addAll(e));
/* 333 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder components(List<LayoutComponent> elements) {
/* 338 */       this.components_list = new ArrayList<>(elements);
/* 339 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder components(Iterable<LayoutComponent> elements) {
/* 344 */       this.components_list = (List<LayoutComponent>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/* 345 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public InteractionPresentModalSpec build() {
/* 354 */       return InteractionPresentModalSpec.validate(new InteractionPresentModalSpec(title_build(), customId_build(), components_build()));
/*     */     }
/*     */     
/*     */     private Possible<String> title_build() {
/* 358 */       return this.title_possible;
/*     */     }
/*     */     
/*     */     private Possible<String> customId_build() {
/* 362 */       return this.customId_possible;
/*     */     }
/*     */     
/*     */     private Possible<List<LayoutComponent>> components_build() {
/* 366 */       return (this.components_list == null) ? Possible.absent() : 
/* 367 */         Possible.of(this.components_list);
/*     */     }
/*     */     
/*     */     private List<LayoutComponent> components_getOrCreate() {
/* 371 */       if (this.components_list == null) {
/* 372 */         this.components_list = new ArrayList<>();
/*     */       }
/* 374 */       return this.components_list;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\InteractionPresentModalSpec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */