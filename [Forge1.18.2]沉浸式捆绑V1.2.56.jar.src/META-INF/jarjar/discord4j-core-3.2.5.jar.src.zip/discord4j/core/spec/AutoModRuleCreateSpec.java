/*     */ package discord4j.core.spec;
/*     */ 
/*     */ import com.google.errorprone.annotations.CanIgnoreReturnValue;
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.discordjson.json.AutoModActionData;
/*     */ import discord4j.discordjson.json.AutoModActionMetaData;
/*     */ import discord4j.discordjson.json.AutoModTriggerMetaData;
/*     */ import discord4j.discordjson.json.ImmutableAutoModActionData;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.stream.StreamSupport;
/*     */ import org.immutables.value.Generated;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "AutoModRuleCreateSpecGenerator", generator = "Immutables")
/*     */ public final class AutoModRuleCreateSpec
/*     */   implements AutoModRuleCreateSpecGenerator
/*     */ {
/*     */   @Nullable
/*     */   private final String reason;
/*     */   private final String name;
/*     */   private final int eventType;
/*     */   private final int triggerType;
/*     */   private final AutoModTriggerMetaData triggerMetaData_value;
/*     */   private final boolean triggerMetaData_absent;
/*     */   private final List<AutoModActionData> actions;
/*     */   private final Boolean enabled_value;
/*     */   private final boolean enabled_absent;
/*     */   private final List<Snowflake> exemptRoles_value;
/*     */   private final boolean exemptRoles_absent;
/*     */   private final List<Snowflake> exemptChannels_value;
/*     */   private final boolean exemptChannels_absent;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   private volatile transient InitShim initShim;
/*     */   
/*     */   private AutoModRuleCreateSpec(String name, int eventType, int triggerType) {
/* 127 */     this.initShim = new InitShim(); this.name = Objects.<String>requireNonNull(name, "name"); this.eventType = eventType; this.triggerType = triggerType; this.reason = null; Possible<AutoModTriggerMetaData> triggerMetaData$impl = Possible.absent(); Possible<Boolean> enabled$impl = Possible.absent(); Possible<List<Snowflake>> exemptRoles$impl = Possible.absent(); Possible<List<Snowflake>> exemptChannels$impl = Possible.absent(); this.triggerMetaData_value = triggerMetaData$impl.toOptional().orElse(null); this.triggerMetaData_absent = triggerMetaData$impl.isAbsent(); this.enabled_value = enabled$impl.toOptional().orElse(null); this.enabled_absent = enabled$impl.isAbsent(); this.exemptRoles_value = exemptRoles$impl.toOptional().orElse(null); this.exemptRoles_absent = exemptRoles$impl.isAbsent(); this.exemptChannels_value = exemptChannels$impl.toOptional().orElse(null); this.exemptChannels_absent = exemptChannels$impl.isAbsent(); this.actions = this.initShim.actions(); this.initShim = null; } private AutoModRuleCreateSpec(Builder builder) { this.initShim = new InitShim(); this.reason = builder.reason; this.name = builder.name; this.eventType = builder.eventType; this.triggerType = builder.triggerType; Possible<AutoModTriggerMetaData> triggerMetaData$impl = builder.triggerMetaData_build(); Possible<Boolean> enabled$impl = builder.enabled_build(); Possible<List<Snowflake>> exemptRoles$impl = builder.exemptRoles_build(); Possible<List<Snowflake>> exemptChannels$impl = builder.exemptChannels_build(); if (builder.actionsIsSet()) this.initShim.actions(createUnmodifiableList(true, builder.actions));  this.triggerMetaData_value = triggerMetaData$impl.toOptional().orElse(null); this.triggerMetaData_absent = triggerMetaData$impl.isAbsent(); this.enabled_value = enabled$impl.toOptional().orElse(null); this.enabled_absent = enabled$impl.isAbsent(); this.exemptRoles_value = exemptRoles$impl.toOptional().orElse(null); this.exemptRoles_absent = exemptRoles$impl.isAbsent(); this.exemptChannels_value = exemptChannels$impl.toOptional().orElse(null); this.exemptChannels_absent = exemptChannels$impl.isAbsent(); this.actions = this.initShim.actions(); this.initShim = null; } private AutoModRuleCreateSpec(@Nullable String reason, String name, int eventType, int triggerType, Possible<AutoModTriggerMetaData> triggerMetaData, List<AutoModActionData> actions, Possible<Boolean> enabled, Possible<List<Snowflake>> exemptRoles, Possible<List<Snowflake>> exemptChannels) { this.initShim = new InitShim(); this.reason = reason; this.name = name; this.eventType = eventType; this.triggerType = triggerType; Possible<AutoModTriggerMetaData> triggerMetaData$impl = triggerMetaData; this.initShim.actions(actions); Possible<Boolean> enabled$impl = enabled; Possible<List<Snowflake>> exemptRoles$impl = exemptRoles; Possible<List<Snowflake>> exemptChannels$impl = exemptChannels; this.triggerMetaData_value = triggerMetaData$impl.toOptional().orElse(null); this.triggerMetaData_absent = triggerMetaData$impl.isAbsent(); this.enabled_value = enabled$impl.toOptional().orElse(null); this.enabled_absent = enabled$impl.isAbsent(); this.exemptRoles_value = exemptRoles$impl.toOptional().orElse(null);
/*     */     this.exemptRoles_absent = exemptRoles$impl.isAbsent();
/*     */     this.exemptChannels_value = exemptChannels$impl.toOptional().orElse(null);
/*     */     this.exemptChannels_absent = exemptChannels$impl.isAbsent();
/*     */     this.actions = this.initShim.actions();
/* 132 */     this.initShim = null; } @Generated(from = "AutoModRuleCreateSpecGenerator", generator = "Immutables") private final class InitShim { private byte actionsBuildStage = 0;
/*     */     private List<AutoModActionData> actions;
/*     */     
/*     */     List<AutoModActionData> actions() {
/* 136 */       if (this.actionsBuildStage == -1) throw new IllegalStateException(formatInitCycleMessage()); 
/* 137 */       if (this.actionsBuildStage == 0) {
/* 138 */         this.actionsBuildStage = -1;
/* 139 */         this.actions = (List)AutoModRuleCreateSpec.createUnmodifiableList(false, AutoModRuleCreateSpec.createSafeList((Iterable)AutoModRuleCreateSpec.this.actionsInitialize(), true, false));
/* 140 */         this.actionsBuildStage = 1;
/*     */       } 
/* 142 */       return this.actions;
/*     */     }
/*     */     
/*     */     void actions(List<AutoModActionData> actions) {
/* 146 */       this.actions = actions;
/* 147 */       this.actionsBuildStage = 1;
/*     */     }
/*     */     
/*     */     private String formatInitCycleMessage() {
/* 151 */       List<String> attributes = new ArrayList<>();
/* 152 */       if (this.actionsBuildStage == -1) attributes.add("actions"); 
/* 153 */       return "Cannot build AutoModRuleCreateSpec, attribute initializers form cycle " + attributes;
/*     */     }
/*     */     private InitShim() {} }
/*     */   
/*     */   private List<AutoModActionData> actionsInitialize() {
/* 158 */     return super.actions();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String reason() {
/* 167 */     return this.reason;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String name() {
/* 175 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int eventType() {
/* 183 */     return this.eventType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int triggerType() {
/* 191 */     return this.triggerType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<AutoModTriggerMetaData> triggerMetaData() {
/* 199 */     return this.triggerMetaData_absent ? Possible.absent() : Possible.of(this.triggerMetaData_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<AutoModActionData> actions() {
/* 207 */     InitShim shim = this.initShim;
/* 208 */     return (shim != null) ? 
/* 209 */       shim.actions() : 
/* 210 */       this.actions;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Boolean> enabled() {
/* 218 */     return this.enabled_absent ? Possible.absent() : Possible.of(this.enabled_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<List<Snowflake>> exemptRoles() {
/* 226 */     return this.exemptRoles_absent ? Possible.absent() : 
/* 227 */       Possible.of(this.exemptRoles_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<List<Snowflake>> exemptChannels() {
/* 235 */     return this.exemptChannels_absent ? Possible.absent() : 
/* 236 */       Possible.of(this.exemptChannels_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final AutoModRuleCreateSpec withReason(@Nullable String value) {
/* 246 */     if (Objects.equals(this.reason, value)) return this; 
/* 247 */     return new AutoModRuleCreateSpec(value, this.name, this.eventType, this.triggerType, 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 252 */         triggerMetaData(), this.actions, 
/*     */         
/* 254 */         enabled(), 
/* 255 */         exemptRoles(), 
/* 256 */         exemptChannels());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final AutoModRuleCreateSpec withName(String value) {
/* 266 */     String newValue = Objects.<String>requireNonNull(value, "name");
/* 267 */     if (this.name.equals(newValue)) return this; 
/* 268 */     return new AutoModRuleCreateSpec(this.reason, newValue, this.eventType, this.triggerType, 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 273 */         triggerMetaData(), this.actions, 
/*     */         
/* 275 */         enabled(), 
/* 276 */         exemptRoles(), 
/* 277 */         exemptChannels());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final AutoModRuleCreateSpec withEventType(int value) {
/* 287 */     if (this.eventType == value) return this; 
/* 288 */     return new AutoModRuleCreateSpec(this.reason, this.name, value, this.triggerType, 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 293 */         triggerMetaData(), this.actions, 
/*     */         
/* 295 */         enabled(), 
/* 296 */         exemptRoles(), 
/* 297 */         exemptChannels());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final AutoModRuleCreateSpec withTriggerType(int value) {
/* 307 */     if (this.triggerType == value) return this; 
/* 308 */     return new AutoModRuleCreateSpec(this.reason, this.name, this.eventType, value, 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 313 */         triggerMetaData(), this.actions, 
/*     */         
/* 315 */         enabled(), 
/* 316 */         exemptRoles(), 
/* 317 */         exemptChannels());
/*     */   }
/*     */   
/*     */   public AutoModRuleCreateSpec withTriggerMetaData(Possible<AutoModTriggerMetaData> value) {
/* 321 */     Possible<AutoModTriggerMetaData> newValue = Objects.<Possible<AutoModTriggerMetaData>>requireNonNull(value);
/* 322 */     return new AutoModRuleCreateSpec(this.reason, this.name, this.eventType, this.triggerType, newValue, this.actions, 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 329 */         enabled(), 
/* 330 */         exemptRoles(), 
/* 331 */         exemptChannels());
/*     */   }
/*     */   
/*     */   public AutoModRuleCreateSpec withTriggerMetaData(AutoModTriggerMetaData value) {
/* 335 */     Possible<AutoModTriggerMetaData> newValue = Possible.of(value);
/* 336 */     return new AutoModRuleCreateSpec(this.reason, this.name, this.eventType, this.triggerType, newValue, this.actions, 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 343 */         enabled(), 
/* 344 */         exemptRoles(), 
/* 345 */         exemptChannels());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final AutoModRuleCreateSpec withActions(AutoModActionData... elements) {
/* 354 */     List<AutoModActionData> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/* 355 */     return new AutoModRuleCreateSpec(this.reason, this.name, this.eventType, this.triggerType, 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 360 */         triggerMetaData(), newValue, 
/*     */         
/* 362 */         enabled(), 
/* 363 */         exemptRoles(), 
/* 364 */         exemptChannels());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final AutoModRuleCreateSpec withActions(Iterable<? extends AutoModActionData> elements) {
/* 374 */     if (this.actions == elements) return this; 
/* 375 */     List<AutoModActionData> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/* 376 */     return new AutoModRuleCreateSpec(this.reason, this.name, this.eventType, this.triggerType, 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 381 */         triggerMetaData(), newValue, 
/*     */         
/* 383 */         enabled(), 
/* 384 */         exemptRoles(), 
/* 385 */         exemptChannels());
/*     */   }
/*     */   
/*     */   public AutoModRuleCreateSpec withEnabled(Possible<Boolean> value) {
/* 389 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/* 390 */     return new AutoModRuleCreateSpec(this.reason, this.name, this.eventType, this.triggerType, 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 395 */         triggerMetaData(), this.actions, newValue, 
/*     */ 
/*     */         
/* 398 */         exemptRoles(), 
/* 399 */         exemptChannels());
/*     */   }
/*     */   
/*     */   public AutoModRuleCreateSpec withEnabled(Boolean value) {
/* 403 */     Possible<Boolean> newValue = Possible.of(value);
/* 404 */     return new AutoModRuleCreateSpec(this.reason, this.name, this.eventType, this.triggerType, 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 409 */         triggerMetaData(), this.actions, newValue, 
/*     */ 
/*     */         
/* 412 */         exemptRoles(), 
/* 413 */         exemptChannels());
/*     */   }
/*     */   
/*     */   public AutoModRuleCreateSpec withExemptRoles(Possible<List<Snowflake>> possible) {
/* 417 */     Possible<List<Snowflake>> newValue = Objects.<Possible<List<Snowflake>>>requireNonNull(possible);
/* 418 */     return new AutoModRuleCreateSpec(this.reason, this.name, this.eventType, this.triggerType, 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 423 */         triggerMetaData(), this.actions, 
/*     */         
/* 425 */         enabled(), newValue, 
/*     */         
/* 427 */         exemptChannels());
/*     */   }
/*     */   
/*     */   public AutoModRuleCreateSpec withExemptRoles(Iterable<Snowflake> elements) {
/* 431 */     Possible<List<Snowflake>> newValue = Possible.of(
/* 432 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/* 433 */     return new AutoModRuleCreateSpec(this.reason, this.name, this.eventType, this.triggerType, 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 438 */         triggerMetaData(), this.actions, 
/*     */         
/* 440 */         enabled(), newValue, 
/*     */         
/* 442 */         exemptChannels());
/*     */   }
/*     */   
/*     */   @SafeVarargs
/*     */   public final AutoModRuleCreateSpec withExemptRoles(Snowflake... elements) {
/* 447 */     Possible<List<Snowflake>> newValue = Possible.of(Arrays.asList(elements));
/* 448 */     return new AutoModRuleCreateSpec(this.reason, this.name, this.eventType, this.triggerType, 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 453 */         triggerMetaData(), this.actions, 
/*     */         
/* 455 */         enabled(), newValue, 
/*     */         
/* 457 */         exemptChannels());
/*     */   }
/*     */   
/*     */   public AutoModRuleCreateSpec withExemptChannels(Possible<List<Snowflake>> possible) {
/* 461 */     Possible<List<Snowflake>> newValue = Objects.<Possible<List<Snowflake>>>requireNonNull(possible);
/* 462 */     return new AutoModRuleCreateSpec(this.reason, this.name, this.eventType, this.triggerType, 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 467 */         triggerMetaData(), this.actions, 
/*     */         
/* 469 */         enabled(), 
/* 470 */         exemptRoles(), newValue);
/*     */   }
/*     */ 
/*     */   
/*     */   public AutoModRuleCreateSpec withExemptChannels(Iterable<Snowflake> elements) {
/* 475 */     Possible<List<Snowflake>> newValue = Possible.of(
/* 476 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/* 477 */     return new AutoModRuleCreateSpec(this.reason, this.name, this.eventType, this.triggerType, 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 482 */         triggerMetaData(), this.actions, 
/*     */         
/* 484 */         enabled(), 
/* 485 */         exemptRoles(), newValue);
/*     */   }
/*     */ 
/*     */   
/*     */   @SafeVarargs
/*     */   public final AutoModRuleCreateSpec withExemptChannels(Snowflake... elements) {
/* 491 */     Possible<List<Snowflake>> newValue = Possible.of(Arrays.asList(elements));
/* 492 */     return new AutoModRuleCreateSpec(this.reason, this.name, this.eventType, this.triggerType, 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 497 */         triggerMetaData(), this.actions, 
/*     */         
/* 499 */         enabled(), 
/* 500 */         exemptRoles(), newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 510 */     if (this == another) return true; 
/* 511 */     return (another instanceof AutoModRuleCreateSpec && 
/* 512 */       equalTo(0, (AutoModRuleCreateSpec)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, AutoModRuleCreateSpec another) {
/* 516 */     return (Objects.equals(this.reason, another.reason) && this.name
/* 517 */       .equals(another.name) && this.eventType == another.eventType && this.triggerType == another.triggerType && 
/*     */ 
/*     */       
/* 520 */       triggerMetaData().equals(another.triggerMetaData()) && this.actions
/* 521 */       .equals(another.actions) && 
/* 522 */       enabled().equals(another.enabled()) && 
/* 523 */       Objects.equals(this.exemptRoles_value, another.exemptRoles_value) && 
/* 524 */       Objects.equals(this.exemptChannels_value, another.exemptChannels_value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 533 */     int h = 5381;
/* 534 */     h += (h << 5) + Objects.hashCode(this.reason);
/* 535 */     h += (h << 5) + this.name.hashCode();
/* 536 */     h += (h << 5) + this.eventType;
/* 537 */     h += (h << 5) + this.triggerType;
/* 538 */     h += (h << 5) + triggerMetaData().hashCode();
/* 539 */     h += (h << 5) + this.actions.hashCode();
/* 540 */     h += (h << 5) + enabled().hashCode();
/* 541 */     h += (h << 5) + Objects.hashCode(this.exemptRoles_value);
/* 542 */     h += (h << 5) + Objects.hashCode(this.exemptChannels_value);
/* 543 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 552 */     return "AutoModRuleCreateSpec{reason=" + this.reason + ", name=" + this.name + ", eventType=" + this.eventType + ", triggerType=" + this.triggerType + ", triggerMetaData=" + 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 557 */       triggerMetaData().toString() + ", actions=" + this.actions + ", enabled=" + 
/*     */       
/* 559 */       enabled().toString() + ", exemptRoles=" + 
/* 560 */       Objects.toString(this.exemptRoles_value) + ", exemptChannels=" + 
/* 561 */       Objects.toString(this.exemptChannels_value) + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AutoModRuleCreateSpec of(String name, int eventType, int triggerType) {
/* 573 */     return new AutoModRuleCreateSpec(name, eventType, triggerType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static AutoModRuleCreateSpec copyOf(AutoModRuleCreateSpecGenerator instance) {
/* 584 */     if (instance instanceof AutoModRuleCreateSpec) {
/* 585 */       return (AutoModRuleCreateSpec)instance;
/*     */     }
/* 587 */     return builder()
/* 588 */       .from(instance)
/* 589 */       .build();
/*     */   }
/*     */   
/*     */   public boolean isTriggerMetaDataPresent() {
/* 593 */     return !this.triggerMetaData_absent;
/*     */   }
/*     */   
/*     */   public AutoModTriggerMetaData triggerMetaDataOrElse(AutoModTriggerMetaData defaultValue) {
/* 597 */     return !this.triggerMetaData_absent ? this.triggerMetaData_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isEnabledPresent() {
/* 601 */     return !this.enabled_absent;
/*     */   }
/*     */   
/*     */   public Boolean enabledOrElse(Boolean defaultValue) {
/* 605 */     return !this.enabled_absent ? this.enabled_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isExemptRolesPresent() {
/* 609 */     return !this.exemptRoles_absent;
/*     */   }
/*     */   
/*     */   public List<Snowflake> exemptRolesOrElse(List<Snowflake> defaultValue) {
/* 613 */     return !this.exemptRoles_absent ? this.exemptRoles_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isExemptChannelsPresent() {
/* 617 */     return !this.exemptChannels_absent;
/*     */   }
/*     */   
/*     */   public List<Snowflake> exemptChannelsOrElse(List<Snowflake> defaultValue) {
/* 621 */     return !this.exemptChannels_absent ? this.exemptChannels_value : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 642 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "AutoModRuleCreateSpecGenerator", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_NAME = 1L;
/*     */     
/*     */     private static final long INIT_BIT_EVENT_TYPE = 2L;
/*     */     
/*     */     private static final long INIT_BIT_TRIGGER_TYPE = 4L;
/*     */     
/*     */     private static final long OPT_BIT_ACTIONS = 1L;
/*     */     
/* 658 */     private long initBits = 7L;
/*     */     
/*     */     private long optBits;
/* 661 */     private Possible<AutoModTriggerMetaData> triggerMetaData_possible = Possible.absent();
/* 662 */     private Possible<Boolean> enabled_possible = Possible.absent();
/* 663 */     private List<Snowflake> exemptRoles_list = null;
/* 664 */     private List<Snowflake> exemptChannels_list = null;
/*     */     private String reason;
/*     */     private String name;
/*     */     private int eventType;
/*     */     private int triggerType;
/* 669 */     private List<AutoModActionData> actions = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(AutoModRuleCreateSpec instance) {
/* 683 */       return from(instance);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     final Builder from(AutoModRuleCreateSpecGenerator instance) {
/* 693 */       Objects.requireNonNull(instance, "instance");
/* 694 */       String reasonValue = instance.reason();
/* 695 */       if (reasonValue != null) {
/* 696 */         reason(reasonValue);
/*     */       }
/* 698 */       name(instance.name());
/* 699 */       eventType(instance.eventType());
/* 700 */       triggerType(instance.triggerType());
/* 701 */       triggerMetaData(instance.triggerMetaData());
/* 702 */       addAllActions(instance.actions());
/* 703 */       enabled(instance.enabled());
/* 704 */       exemptRoles(instance.exemptRoles());
/* 705 */       exemptChannels(instance.exemptChannels());
/* 706 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder reason(@Nullable String reason) {
/* 716 */       this.reason = reason;
/* 717 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder name(String name) {
/* 727 */       this.name = Objects.<String>requireNonNull(name, "name");
/* 728 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 729 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder eventType(int eventType) {
/* 739 */       this.eventType = eventType;
/* 740 */       this.initBits &= 0xFFFFFFFFFFFFFFFDL;
/* 741 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder triggerType(int triggerType) {
/* 751 */       this.triggerType = triggerType;
/* 752 */       this.initBits &= 0xFFFFFFFFFFFFFFFBL;
/* 753 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder triggerMetaData(Possible<AutoModTriggerMetaData> value) {
/* 758 */       this.triggerMetaData_possible = value;
/* 759 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder triggerMetaData(AutoModTriggerMetaData value) {
/* 764 */       this.triggerMetaData_possible = Possible.of(value);
/* 765 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder addAction(AutoModActionData element) {
/* 775 */       ImmutableAutoModActionData immutableAutoModActionData = ImmutableAutoModActionData.copyOf(element);
/* 776 */       this.actions.add((AutoModActionData)Objects.requireNonNull(immutableAutoModActionData, "actions element"));
/* 777 */       this.optBits |= 0x1L;
/* 778 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder addAction(int type, Possible<AutoModActionMetaData> metadata) {
/* 788 */       return addAction((AutoModActionData)ImmutableAutoModActionData.of(type, metadata));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder addActions(AutoModActionData... elements) {
/* 798 */       for (AutoModActionData element : elements) {
/* 799 */         ImmutableAutoModActionData immutableAutoModActionData = ImmutableAutoModActionData.copyOf(element);
/* 800 */         this.actions.add((AutoModActionData)Objects.requireNonNull(immutableAutoModActionData, "actions element"));
/*     */       } 
/* 802 */       this.optBits |= 0x1L;
/* 803 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder actions(Iterable<? extends AutoModActionData> elements) {
/* 814 */       this.actions.clear();
/* 815 */       return addAllActions(elements);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder addAllActions(Iterable<? extends AutoModActionData> elements) {
/* 825 */       for (AutoModActionData element : elements) {
/* 826 */         ImmutableAutoModActionData immutableAutoModActionData = ImmutableAutoModActionData.copyOf(element);
/* 827 */         this.actions.add((AutoModActionData)Objects.requireNonNull(immutableAutoModActionData, "actions element"));
/*     */       } 
/* 829 */       this.optBits |= 0x1L;
/* 830 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder enabled(Possible<Boolean> value) {
/* 835 */       this.enabled_possible = value;
/* 836 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder enabled(Boolean value) {
/* 841 */       this.enabled_possible = Possible.of(value);
/* 842 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder addExemptRole(Snowflake element) {
/* 847 */       exemptRoles_getOrCreate().add(element);
/* 848 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder addAllExemptRoles(List<Snowflake> elements) {
/* 853 */       exemptRoles_getOrCreate().addAll(elements);
/* 854 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder exemptRoles(Possible<List<Snowflake>> elements) {
/* 859 */       this.exemptRoles_list = null;
/* 860 */       elements.toOptional().ifPresent(e -> exemptRoles_getOrCreate().addAll(e));
/* 861 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder exemptRoles(List<Snowflake> elements) {
/* 866 */       this.exemptRoles_list = new ArrayList<>(elements);
/* 867 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder exemptRoles(Iterable<Snowflake> elements) {
/* 872 */       this.exemptRoles_list = (List<Snowflake>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/* 873 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder addExemptChannel(Snowflake element) {
/* 878 */       exemptChannels_getOrCreate().add(element);
/* 879 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder addAllExemptChannels(List<Snowflake> elements) {
/* 884 */       exemptChannels_getOrCreate().addAll(elements);
/* 885 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder exemptChannels(Possible<List<Snowflake>> elements) {
/* 890 */       this.exemptChannels_list = null;
/* 891 */       elements.toOptional().ifPresent(e -> exemptChannels_getOrCreate().addAll(e));
/* 892 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder exemptChannels(List<Snowflake> elements) {
/* 897 */       this.exemptChannels_list = new ArrayList<>(elements);
/* 898 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder exemptChannels(Iterable<Snowflake> elements) {
/* 903 */       this.exemptChannels_list = (List<Snowflake>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/* 904 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public AutoModRuleCreateSpec build() {
/* 913 */       if (this.initBits != 0L) {
/* 914 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 916 */       return new AutoModRuleCreateSpec(this);
/*     */     }
/*     */     
/*     */     private boolean actionsIsSet() {
/* 920 */       return ((this.optBits & 0x1L) != 0L);
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 924 */       List<String> attributes = new ArrayList<>();
/* 925 */       if ((this.initBits & 0x1L) != 0L) attributes.add("name"); 
/* 926 */       if ((this.initBits & 0x2L) != 0L) attributes.add("eventType"); 
/* 927 */       if ((this.initBits & 0x4L) != 0L) attributes.add("triggerType"); 
/* 928 */       return "Cannot build AutoModRuleCreateSpec, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Possible<AutoModTriggerMetaData> triggerMetaData_build() {
/* 932 */       return this.triggerMetaData_possible;
/*     */     }
/*     */     
/*     */     private Possible<Boolean> enabled_build() {
/* 936 */       return this.enabled_possible;
/*     */     }
/*     */     
/*     */     private Possible<List<Snowflake>> exemptRoles_build() {
/* 940 */       return (this.exemptRoles_list == null) ? Possible.absent() : 
/* 941 */         Possible.of(this.exemptRoles_list);
/*     */     }
/*     */     
/*     */     private List<Snowflake> exemptRoles_getOrCreate() {
/* 945 */       if (this.exemptRoles_list == null) {
/* 946 */         this.exemptRoles_list = new ArrayList<>();
/*     */       }
/* 948 */       return this.exemptRoles_list;
/*     */     }
/*     */     
/*     */     private Possible<List<Snowflake>> exemptChannels_build() {
/* 952 */       return (this.exemptChannels_list == null) ? Possible.absent() : 
/* 953 */         Possible.of(this.exemptChannels_list);
/*     */     }
/*     */     
/*     */     private List<Snowflake> exemptChannels_getOrCreate() {
/* 957 */       if (this.exemptChannels_list == null) {
/* 958 */         this.exemptChannels_list = new ArrayList<>();
/*     */       }
/* 960 */       return this.exemptChannels_list;
/*     */     }
/*     */     private Builder() {} }
/*     */   
/*     */   private static <T> List<T> createSafeList(Iterable<? extends T> iterable, boolean checkNulls, boolean skipNulls) {
/*     */     ArrayList<T> list;
/* 966 */     if (iterable instanceof Collection) {
/* 967 */       int size = ((Collection)iterable).size();
/* 968 */       if (size == 0) return Collections.emptyList(); 
/* 969 */       list = new ArrayList<>();
/*     */     } else {
/* 971 */       list = new ArrayList<>();
/*     */     } 
/* 973 */     for (T element : iterable) {
/* 974 */       if (skipNulls && element == null)
/* 975 */         continue;  if (checkNulls) Objects.requireNonNull(element, "element"); 
/* 976 */       list.add(element);
/*     */     } 
/* 978 */     return list;
/*     */   }
/*     */   
/*     */   private static <T> List<T> createUnmodifiableList(boolean clone, List<T> list) {
/* 982 */     switch (list.size()) { case 0:
/* 983 */         return Collections.emptyList();
/* 984 */       case 1: return Collections.singletonList(list.get(0)); }
/*     */     
/* 986 */     if (clone) {
/* 987 */       return Collections.unmodifiableList(new ArrayList<>(list));
/*     */     }
/* 989 */     if (list instanceof ArrayList) {
/* 990 */       ((ArrayList)list).trimToSize();
/*     */     }
/* 992 */     return Collections.unmodifiableList(list);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\AutoModRuleCreateSpec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */