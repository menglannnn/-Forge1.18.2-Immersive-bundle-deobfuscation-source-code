/*    */ package discord4j.core.spec;
/*    */ 
/*    */ import discord4j.core.object.entity.Message;
/*    */ import discord4j.discordjson.json.InteractionApplicationCommandCallbackData;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Immutable(singleton = true)
/*    */ interface InteractionCallbackSpecGenerator
/*    */   extends Spec<InteractionApplicationCommandCallbackData>
/*    */ {
/*    */   default InteractionApplicationCommandCallbackData asRequest() {
/* 38 */     return (InteractionApplicationCommandCallbackData)InteractionApplicationCommandCallbackData.builder()
/* 39 */       .flags(InternalSpecUtils.mapPossible(ephemeral(), eph -> Integer.valueOf(eph.booleanValue() ? Message.Flag.EPHEMERAL.getFlag() : 0)))
/* 40 */       .build();
/*    */   }
/*    */   
/*    */   Possible<Boolean> ephemeral();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\InteractionCallbackSpecGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */