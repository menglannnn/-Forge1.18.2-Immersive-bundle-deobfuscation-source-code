/*    */ package discord4j.core.spec;
/*    */ 
/*    */ import discord4j.common.util.Snowflake;
/*    */ import discord4j.discordjson.Id;
/*    */ import discord4j.discordjson.json.AutoModActionData;
/*    */ import discord4j.discordjson.json.AutoModRuleCreateRequest;
/*    */ import discord4j.discordjson.json.AutoModTriggerMetaData;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import java.util.stream.Collectors;
/*    */ import org.immutables.value.Value.Default;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Immutable
/*    */ interface AutoModRuleCreateSpecGenerator
/*    */   extends AuditSpec<AutoModRuleCreateRequest>
/*    */ {
/*    */   @Default
/*    */   default List<AutoModActionData> actions() {
/* 51 */     return Collections.emptyList();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   default AutoModRuleCreateRequest asRequest() {
/* 62 */     return (AutoModRuleCreateRequest)AutoModRuleCreateRequest.builder()
/* 63 */       .name(name())
/* 64 */       .eventType(eventType())
/* 65 */       .triggerType(triggerType())
/* 66 */       .triggerMetadata(triggerMetaData())
/* 67 */       .actions(actions())
/* 68 */       .enabled(enabled())
/* 69 */       .exemptRoles(InternalSpecUtils.mapPossible(exemptRoles(), r -> (List)r.stream().map(Snowflake::asLong).map(Id::of).collect(Collectors.toList())))
/* 70 */       .exemptChannels(InternalSpecUtils.mapPossible(exemptChannels(), r -> (List)r.stream().map(Snowflake::asLong).map(Id::of).collect(Collectors.toList())))
/* 71 */       .build();
/*    */   }
/*    */   
/*    */   String name();
/*    */   
/*    */   int eventType();
/*    */   
/*    */   int triggerType();
/*    */   
/*    */   Possible<AutoModTriggerMetaData> triggerMetaData();
/*    */   
/*    */   Possible<Boolean> enabled();
/*    */   
/*    */   Possible<List<Snowflake>> exemptRoles();
/*    */   
/*    */   Possible<List<Snowflake>> exemptChannels();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\AutoModRuleCreateSpecGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */