/*     */ package discord4j.core.spec;
/*     */ 
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.object.PermissionOverwrite;
/*     */ import discord4j.core.object.entity.channel.VoiceChannel;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.stream.StreamSupport;
/*     */ import org.immutables.value.Generated;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "VoiceChannelEditMonoGenerator", generator = "Immutables")
/*     */ public final class VoiceChannelEditMono
/*     */   extends VoiceChannelEditMonoGenerator
/*     */ {
/*     */   @Nullable
/*     */   private final String reason;
/*     */   private final String name_value;
/*     */   private final boolean name_absent;
/*     */   private final Integer bitrate_value;
/*     */   private final boolean bitrate_absent;
/*     */   private final Integer userLimit_value;
/*     */   private final boolean userLimit_absent;
/*     */   private final Integer position_value;
/*     */   private final boolean position_absent;
/*     */   private final Integer rateLimitPerUser_value;
/*     */   private final boolean rateLimitPerUser_absent;
/*     */   private final List<PermissionOverwrite> permissionOverwrites_value;
/*     */   private final boolean permissionOverwrites_absent;
/*     */   private final Snowflake parentId_value;
/*     */   private final boolean parentId_absent;
/*     */   private final String rtcRegion_value;
/*     */   private final boolean rtcRegion_absent;
/*     */   private final VoiceChannel.Mode videoQualityMode_value;
/*     */   private final boolean videoQualityMode_absent;
/*     */   private final VoiceChannel channel;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   private volatile transient InitShim initShim;
/*     */   
/*     */   private VoiceChannelEditMono(VoiceChannel channel) {
/* 129 */     this.initShim = new InitShim(); this.channel = Objects.<VoiceChannel>requireNonNull(channel, "channel"); this.reason = null; Possible<String> name$impl = Possible.absent(); Possible<Integer> bitrate$impl = Possible.absent(); Possible<Integer> userLimit$impl = Possible.absent(); Possible<Integer> position$impl = Possible.absent(); Possible<Integer> rateLimitPerUser$impl = Possible.absent(); Possible<List<PermissionOverwrite>> permissionOverwrites$impl = Possible.absent(); Possible<Optional<Snowflake>> parentId$impl = Possible.absent(); Possible<Optional<String>> rtcRegion$impl = Possible.absent(); Possible<Optional<VoiceChannel.Mode>> videoQualityMode$impl = Possible.absent(); this.name_value = name$impl.toOptional().orElse(null); this.name_absent = name$impl.isAbsent(); this.bitrate_value = bitrate$impl.toOptional().orElse(null); this.bitrate_absent = bitrate$impl.isAbsent(); this.userLimit_value = userLimit$impl.toOptional().orElse(null); this.userLimit_absent = userLimit$impl.isAbsent(); this.position_value = position$impl.toOptional().orElse(null); this.position_absent = position$impl.isAbsent(); this.rateLimitPerUser_value = rateLimitPerUser$impl.toOptional().orElse(null); this.rateLimitPerUser_absent = rateLimitPerUser$impl.isAbsent(); this.permissionOverwrites_value = permissionOverwrites$impl.toOptional().orElse(null); this.permissionOverwrites_absent = permissionOverwrites$impl.isAbsent(); this.parentId_value = Possible.flatOpt(parentId$impl).orElse(null); this.parentId_absent = parentId$impl.isAbsent(); this.rtcRegion_value = Possible.flatOpt(rtcRegion$impl).orElse(null); this.rtcRegion_absent = rtcRegion$impl.isAbsent(); this.videoQualityMode_value = Possible.flatOpt(videoQualityMode$impl).orElse(null); this.videoQualityMode_absent = videoQualityMode$impl.isAbsent(); this.initShim = null; } private VoiceChannelEditMono(@Nullable String reason, Possible<String> name, Possible<Integer> bitrate, Possible<Integer> userLimit, Possible<Integer> position, Possible<Integer> rateLimitPerUser, Possible<List<PermissionOverwrite>> permissionOverwrites, Possible<Optional<Snowflake>> parentId, Possible<Optional<String>> rtcRegion, Possible<Optional<VoiceChannel.Mode>> videoQualityMode, VoiceChannel channel) { this.initShim = new InitShim(); this.reason = reason; Possible<String> name$impl = name; Possible<Integer> bitrate$impl = bitrate; Possible<Integer> userLimit$impl = userLimit; Possible<Integer> position$impl = position; Possible<Integer> rateLimitPerUser$impl = rateLimitPerUser; Possible<List<PermissionOverwrite>> permissionOverwrites$impl = permissionOverwrites; Possible<Optional<Snowflake>> parentId$impl = parentId; Possible<Optional<String>> rtcRegion$impl = rtcRegion; Possible<Optional<VoiceChannel.Mode>> videoQualityMode$impl = videoQualityMode; this.channel = channel; this.name_value = name$impl.toOptional().orElse(null); this.name_absent = name$impl.isAbsent(); this.bitrate_value = bitrate$impl.toOptional().orElse(null); this.bitrate_absent = bitrate$impl.isAbsent(); this.userLimit_value = userLimit$impl.toOptional().orElse(null); this.userLimit_absent = userLimit$impl.isAbsent(); this.position_value = position$impl.toOptional().orElse(null); this.position_absent = position$impl.isAbsent(); this.rateLimitPerUser_value = rateLimitPerUser$impl.toOptional().orElse(null); this.rateLimitPerUser_absent = rateLimitPerUser$impl.isAbsent(); this.permissionOverwrites_value = permissionOverwrites$impl.toOptional().orElse(null); this.permissionOverwrites_absent = permissionOverwrites$impl.isAbsent(); this.parentId_value = Possible.flatOpt(parentId$impl).orElse(null);
/*     */     this.parentId_absent = parentId$impl.isAbsent();
/*     */     this.rtcRegion_value = Possible.flatOpt(rtcRegion$impl).orElse(null);
/*     */     this.rtcRegion_absent = rtcRegion$impl.isAbsent();
/*     */     this.videoQualityMode_value = Possible.flatOpt(videoQualityMode$impl).orElse(null);
/*     */     this.videoQualityMode_absent = videoQualityMode$impl.isAbsent();
/* 135 */     this.initShim = null; } @Generated(from = "VoiceChannelEditMonoGenerator", generator = "Immutables") private final class InitShim { private InitShim() {} private String formatInitCycleMessage() { List<String> attributes = new ArrayList<>();
/* 136 */       return "Cannot build VoiceChannelEditMono, attribute initializers form cycle " + attributes; }
/*     */      }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String reason() {
/* 146 */     return this.reason;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<String> name() {
/* 154 */     return this.name_absent ? Possible.absent() : Possible.of(this.name_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Integer> bitrate() {
/* 162 */     return this.bitrate_absent ? Possible.absent() : Possible.of(this.bitrate_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Integer> userLimit() {
/* 170 */     return this.userLimit_absent ? Possible.absent() : Possible.of(this.userLimit_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Integer> position() {
/* 178 */     return this.position_absent ? Possible.absent() : Possible.of(this.position_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Integer> rateLimitPerUser() {
/* 186 */     return this.rateLimitPerUser_absent ? Possible.absent() : Possible.of(this.rateLimitPerUser_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<List<PermissionOverwrite>> permissionOverwrites() {
/* 194 */     return this.permissionOverwrites_absent ? Possible.absent() : 
/* 195 */       Possible.of(this.permissionOverwrites_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Optional<Snowflake>> parentId() {
/* 203 */     return this.parentId_absent ? Possible.absent() : 
/* 204 */       Possible.of(Optional.ofNullable(this.parentId_value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Optional<String>> rtcRegion() {
/* 212 */     return this.rtcRegion_absent ? Possible.absent() : 
/* 213 */       Possible.of(Optional.ofNullable(this.rtcRegion_value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Optional<VoiceChannel.Mode>> videoQualityMode() {
/* 221 */     return this.videoQualityMode_absent ? Possible.absent() : 
/* 222 */       Possible.of(Optional.ofNullable(this.videoQualityMode_value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public VoiceChannel channel() {
/* 230 */     return this.channel;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final VoiceChannelEditMono withReason(@Nullable String value) {
/* 240 */     if (Objects.equals(this.reason, value)) return this; 
/* 241 */     return new VoiceChannelEditMono(value, 
/*     */         
/* 243 */         name(), 
/* 244 */         bitrate(), 
/* 245 */         userLimit(), 
/* 246 */         position(), 
/* 247 */         rateLimitPerUser(), 
/* 248 */         permissionOverwrites(), 
/* 249 */         parentId(), 
/* 250 */         rtcRegion(), 
/* 251 */         videoQualityMode(), this.channel);
/*     */   }
/*     */ 
/*     */   
/*     */   public VoiceChannelEditMono withName(Possible<String> value) {
/* 256 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/* 257 */     return new VoiceChannelEditMono(this.reason, newValue, 
/*     */ 
/*     */         
/* 260 */         bitrate(), 
/* 261 */         userLimit(), 
/* 262 */         position(), 
/* 263 */         rateLimitPerUser(), 
/* 264 */         permissionOverwrites(), 
/* 265 */         parentId(), 
/* 266 */         rtcRegion(), 
/* 267 */         videoQualityMode(), this.channel);
/*     */   }
/*     */ 
/*     */   
/*     */   public VoiceChannelEditMono withName(String value) {
/* 272 */     Possible<String> newValue = Possible.of(value);
/* 273 */     return new VoiceChannelEditMono(this.reason, newValue, 
/*     */ 
/*     */         
/* 276 */         bitrate(), 
/* 277 */         userLimit(), 
/* 278 */         position(), 
/* 279 */         rateLimitPerUser(), 
/* 280 */         permissionOverwrites(), 
/* 281 */         parentId(), 
/* 282 */         rtcRegion(), 
/* 283 */         videoQualityMode(), this.channel);
/*     */   }
/*     */ 
/*     */   
/*     */   public VoiceChannelEditMono withBitrate(Possible<Integer> value) {
/* 288 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/* 289 */     return new VoiceChannelEditMono(this.reason, 
/*     */         
/* 291 */         name(), newValue, 
/*     */         
/* 293 */         userLimit(), 
/* 294 */         position(), 
/* 295 */         rateLimitPerUser(), 
/* 296 */         permissionOverwrites(), 
/* 297 */         parentId(), 
/* 298 */         rtcRegion(), 
/* 299 */         videoQualityMode(), this.channel);
/*     */   }
/*     */ 
/*     */   
/*     */   public VoiceChannelEditMono withBitrate(Integer value) {
/* 304 */     Possible<Integer> newValue = Possible.of(value);
/* 305 */     return new VoiceChannelEditMono(this.reason, 
/*     */         
/* 307 */         name(), newValue, 
/*     */         
/* 309 */         userLimit(), 
/* 310 */         position(), 
/* 311 */         rateLimitPerUser(), 
/* 312 */         permissionOverwrites(), 
/* 313 */         parentId(), 
/* 314 */         rtcRegion(), 
/* 315 */         videoQualityMode(), this.channel);
/*     */   }
/*     */ 
/*     */   
/*     */   public VoiceChannelEditMono withUserLimit(Possible<Integer> value) {
/* 320 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/* 321 */     return new VoiceChannelEditMono(this.reason, 
/*     */         
/* 323 */         name(), 
/* 324 */         bitrate(), newValue, 
/*     */         
/* 326 */         position(), 
/* 327 */         rateLimitPerUser(), 
/* 328 */         permissionOverwrites(), 
/* 329 */         parentId(), 
/* 330 */         rtcRegion(), 
/* 331 */         videoQualityMode(), this.channel);
/*     */   }
/*     */ 
/*     */   
/*     */   public VoiceChannelEditMono withUserLimit(Integer value) {
/* 336 */     Possible<Integer> newValue = Possible.of(value);
/* 337 */     return new VoiceChannelEditMono(this.reason, 
/*     */         
/* 339 */         name(), 
/* 340 */         bitrate(), newValue, 
/*     */         
/* 342 */         position(), 
/* 343 */         rateLimitPerUser(), 
/* 344 */         permissionOverwrites(), 
/* 345 */         parentId(), 
/* 346 */         rtcRegion(), 
/* 347 */         videoQualityMode(), this.channel);
/*     */   }
/*     */ 
/*     */   
/*     */   public VoiceChannelEditMono withPosition(Possible<Integer> value) {
/* 352 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/* 353 */     return new VoiceChannelEditMono(this.reason, 
/*     */         
/* 355 */         name(), 
/* 356 */         bitrate(), 
/* 357 */         userLimit(), newValue, 
/*     */         
/* 359 */         rateLimitPerUser(), 
/* 360 */         permissionOverwrites(), 
/* 361 */         parentId(), 
/* 362 */         rtcRegion(), 
/* 363 */         videoQualityMode(), this.channel);
/*     */   }
/*     */ 
/*     */   
/*     */   public VoiceChannelEditMono withPosition(Integer value) {
/* 368 */     Possible<Integer> newValue = Possible.of(value);
/* 369 */     return new VoiceChannelEditMono(this.reason, 
/*     */         
/* 371 */         name(), 
/* 372 */         bitrate(), 
/* 373 */         userLimit(), newValue, 
/*     */         
/* 375 */         rateLimitPerUser(), 
/* 376 */         permissionOverwrites(), 
/* 377 */         parentId(), 
/* 378 */         rtcRegion(), 
/* 379 */         videoQualityMode(), this.channel);
/*     */   }
/*     */ 
/*     */   
/*     */   public VoiceChannelEditMono withRateLimitPerUser(Possible<Integer> value) {
/* 384 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/* 385 */     return new VoiceChannelEditMono(this.reason, 
/*     */         
/* 387 */         name(), 
/* 388 */         bitrate(), 
/* 389 */         userLimit(), 
/* 390 */         position(), newValue, 
/*     */         
/* 392 */         permissionOverwrites(), 
/* 393 */         parentId(), 
/* 394 */         rtcRegion(), 
/* 395 */         videoQualityMode(), this.channel);
/*     */   }
/*     */ 
/*     */   
/*     */   public VoiceChannelEditMono withRateLimitPerUser(Integer value) {
/* 400 */     Possible<Integer> newValue = Possible.of(value);
/* 401 */     return new VoiceChannelEditMono(this.reason, 
/*     */         
/* 403 */         name(), 
/* 404 */         bitrate(), 
/* 405 */         userLimit(), 
/* 406 */         position(), newValue, 
/*     */         
/* 408 */         permissionOverwrites(), 
/* 409 */         parentId(), 
/* 410 */         rtcRegion(), 
/* 411 */         videoQualityMode(), this.channel);
/*     */   }
/*     */ 
/*     */   
/*     */   public VoiceChannelEditMono withPermissionOverwrites(Possible<List<PermissionOverwrite>> possible) {
/* 416 */     Possible<List<PermissionOverwrite>> newValue = Objects.<Possible<List<PermissionOverwrite>>>requireNonNull(possible);
/* 417 */     return new VoiceChannelEditMono(this.reason, 
/*     */         
/* 419 */         name(), 
/* 420 */         bitrate(), 
/* 421 */         userLimit(), 
/* 422 */         position(), 
/* 423 */         rateLimitPerUser(), newValue, 
/*     */         
/* 425 */         parentId(), 
/* 426 */         rtcRegion(), 
/* 427 */         videoQualityMode(), this.channel);
/*     */   }
/*     */ 
/*     */   
/*     */   public VoiceChannelEditMono withPermissionOverwrites(Iterable<PermissionOverwrite> elements) {
/* 432 */     Possible<List<PermissionOverwrite>> newValue = Possible.of(
/* 433 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/* 434 */     return new VoiceChannelEditMono(this.reason, 
/*     */         
/* 436 */         name(), 
/* 437 */         bitrate(), 
/* 438 */         userLimit(), 
/* 439 */         position(), 
/* 440 */         rateLimitPerUser(), newValue, 
/*     */         
/* 442 */         parentId(), 
/* 443 */         rtcRegion(), 
/* 444 */         videoQualityMode(), this.channel);
/*     */   }
/*     */ 
/*     */   
/*     */   @SafeVarargs
/*     */   public final VoiceChannelEditMono withPermissionOverwrites(PermissionOverwrite... elements) {
/* 450 */     Possible<List<PermissionOverwrite>> newValue = Possible.of(Arrays.asList(elements));
/* 451 */     return new VoiceChannelEditMono(this.reason, 
/*     */         
/* 453 */         name(), 
/* 454 */         bitrate(), 
/* 455 */         userLimit(), 
/* 456 */         position(), 
/* 457 */         rateLimitPerUser(), newValue, 
/*     */         
/* 459 */         parentId(), 
/* 460 */         rtcRegion(), 
/* 461 */         videoQualityMode(), this.channel);
/*     */   }
/*     */ 
/*     */   
/*     */   public VoiceChannelEditMono withParentId(Possible<Optional<Snowflake>> value) {
/* 466 */     Possible<Optional<Snowflake>> newValue = Objects.<Possible<Optional<Snowflake>>>requireNonNull(value);
/* 467 */     return new VoiceChannelEditMono(this.reason, 
/*     */         
/* 469 */         name(), 
/* 470 */         bitrate(), 
/* 471 */         userLimit(), 
/* 472 */         position(), 
/* 473 */         rateLimitPerUser(), 
/* 474 */         permissionOverwrites(), newValue, 
/*     */         
/* 476 */         rtcRegion(), 
/* 477 */         videoQualityMode(), this.channel);
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public VoiceChannelEditMono withParentId(@Nullable Snowflake value) {
/* 483 */     Possible<Optional<Snowflake>> newValue = Possible.of(Optional.ofNullable(value));
/* 484 */     return new VoiceChannelEditMono(this.reason, 
/*     */         
/* 486 */         name(), 
/* 487 */         bitrate(), 
/* 488 */         userLimit(), 
/* 489 */         position(), 
/* 490 */         rateLimitPerUser(), 
/* 491 */         permissionOverwrites(), newValue, 
/*     */         
/* 493 */         rtcRegion(), 
/* 494 */         videoQualityMode(), this.channel);
/*     */   }
/*     */ 
/*     */   
/*     */   public VoiceChannelEditMono withParentIdOrNull(@Nullable Snowflake value) {
/* 499 */     Possible<Optional<Snowflake>> newValue = Possible.of(Optional.ofNullable(value));
/* 500 */     return new VoiceChannelEditMono(this.reason, 
/*     */         
/* 502 */         name(), 
/* 503 */         bitrate(), 
/* 504 */         userLimit(), 
/* 505 */         position(), 
/* 506 */         rateLimitPerUser(), 
/* 507 */         permissionOverwrites(), newValue, 
/*     */         
/* 509 */         rtcRegion(), 
/* 510 */         videoQualityMode(), this.channel);
/*     */   }
/*     */ 
/*     */   
/*     */   public VoiceChannelEditMono withRtcRegion(Possible<Optional<String>> value) {
/* 515 */     Possible<Optional<String>> newValue = Objects.<Possible<Optional<String>>>requireNonNull(value);
/* 516 */     return new VoiceChannelEditMono(this.reason, 
/*     */         
/* 518 */         name(), 
/* 519 */         bitrate(), 
/* 520 */         userLimit(), 
/* 521 */         position(), 
/* 522 */         rateLimitPerUser(), 
/* 523 */         permissionOverwrites(), 
/* 524 */         parentId(), newValue, 
/*     */         
/* 526 */         videoQualityMode(), this.channel);
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public VoiceChannelEditMono withRtcRegion(@Nullable String value) {
/* 532 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/* 533 */     return new VoiceChannelEditMono(this.reason, 
/*     */         
/* 535 */         name(), 
/* 536 */         bitrate(), 
/* 537 */         userLimit(), 
/* 538 */         position(), 
/* 539 */         rateLimitPerUser(), 
/* 540 */         permissionOverwrites(), 
/* 541 */         parentId(), newValue, 
/*     */         
/* 543 */         videoQualityMode(), this.channel);
/*     */   }
/*     */ 
/*     */   
/*     */   public VoiceChannelEditMono withRtcRegionOrNull(@Nullable String value) {
/* 548 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/* 549 */     return new VoiceChannelEditMono(this.reason, 
/*     */         
/* 551 */         name(), 
/* 552 */         bitrate(), 
/* 553 */         userLimit(), 
/* 554 */         position(), 
/* 555 */         rateLimitPerUser(), 
/* 556 */         permissionOverwrites(), 
/* 557 */         parentId(), newValue, 
/*     */         
/* 559 */         videoQualityMode(), this.channel);
/*     */   }
/*     */ 
/*     */   
/*     */   public VoiceChannelEditMono withVideoQualityMode(Possible<Optional<VoiceChannel.Mode>> value) {
/* 564 */     Possible<Optional<VoiceChannel.Mode>> newValue = Objects.<Possible<Optional<VoiceChannel.Mode>>>requireNonNull(value);
/* 565 */     return new VoiceChannelEditMono(this.reason, 
/*     */         
/* 567 */         name(), 
/* 568 */         bitrate(), 
/* 569 */         userLimit(), 
/* 570 */         position(), 
/* 571 */         rateLimitPerUser(), 
/* 572 */         permissionOverwrites(), 
/* 573 */         parentId(), 
/* 574 */         rtcRegion(), newValue, this.channel);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public VoiceChannelEditMono withVideoQualityMode(@Nullable VoiceChannel.Mode value) {
/* 581 */     Possible<Optional<VoiceChannel.Mode>> newValue = Possible.of(Optional.ofNullable(value));
/* 582 */     return new VoiceChannelEditMono(this.reason, 
/*     */         
/* 584 */         name(), 
/* 585 */         bitrate(), 
/* 586 */         userLimit(), 
/* 587 */         position(), 
/* 588 */         rateLimitPerUser(), 
/* 589 */         permissionOverwrites(), 
/* 590 */         parentId(), 
/* 591 */         rtcRegion(), newValue, this.channel);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public VoiceChannelEditMono withVideoQualityModeOrNull(@Nullable VoiceChannel.Mode value) {
/* 597 */     Possible<Optional<VoiceChannel.Mode>> newValue = Possible.of(Optional.ofNullable(value));
/* 598 */     return new VoiceChannelEditMono(this.reason, 
/*     */         
/* 600 */         name(), 
/* 601 */         bitrate(), 
/* 602 */         userLimit(), 
/* 603 */         position(), 
/* 604 */         rateLimitPerUser(), 
/* 605 */         permissionOverwrites(), 
/* 606 */         parentId(), 
/* 607 */         rtcRegion(), newValue, this.channel);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final VoiceChannelEditMono withChannel(VoiceChannel value) {
/* 619 */     if (this.channel == value) return this; 
/* 620 */     VoiceChannel newValue = Objects.<VoiceChannel>requireNonNull(value, "channel");
/* 621 */     return new VoiceChannelEditMono(this.reason, 
/*     */         
/* 623 */         name(), 
/* 624 */         bitrate(), 
/* 625 */         userLimit(), 
/* 626 */         position(), 
/* 627 */         rateLimitPerUser(), 
/* 628 */         permissionOverwrites(), 
/* 629 */         parentId(), 
/* 630 */         rtcRegion(), 
/* 631 */         videoQualityMode(), newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 641 */     if (this == another) return true; 
/* 642 */     return (another instanceof VoiceChannelEditMono && 
/* 643 */       equalTo(0, (VoiceChannelEditMono)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, VoiceChannelEditMono another) {
/* 647 */     return (Objects.equals(this.reason, another.reason) && 
/* 648 */       name().equals(another.name()) && 
/* 649 */       bitrate().equals(another.bitrate()) && 
/* 650 */       userLimit().equals(another.userLimit()) && 
/* 651 */       position().equals(another.position()) && 
/* 652 */       rateLimitPerUser().equals(another.rateLimitPerUser()) && 
/* 653 */       Objects.equals(this.permissionOverwrites_value, another.permissionOverwrites_value) && 
/* 654 */       parentId().equals(another.parentId()) && 
/* 655 */       rtcRegion().equals(another.rtcRegion()) && 
/* 656 */       videoQualityMode().equals(another.videoQualityMode()) && this.channel
/* 657 */       .equals(another.channel));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 666 */     int h = 5381;
/* 667 */     h += (h << 5) + Objects.hashCode(this.reason);
/* 668 */     h += (h << 5) + name().hashCode();
/* 669 */     h += (h << 5) + bitrate().hashCode();
/* 670 */     h += (h << 5) + userLimit().hashCode();
/* 671 */     h += (h << 5) + position().hashCode();
/* 672 */     h += (h << 5) + rateLimitPerUser().hashCode();
/* 673 */     h += (h << 5) + Objects.hashCode(this.permissionOverwrites_value);
/* 674 */     h += (h << 5) + parentId().hashCode();
/* 675 */     h += (h << 5) + rtcRegion().hashCode();
/* 676 */     h += (h << 5) + videoQualityMode().hashCode();
/* 677 */     h += (h << 5) + this.channel.hashCode();
/* 678 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 687 */     return "VoiceChannelEditMono{reason=" + this.reason + ", name=" + 
/*     */       
/* 689 */       name().toString() + ", bitrate=" + 
/* 690 */       bitrate().toString() + ", userLimit=" + 
/* 691 */       userLimit().toString() + ", position=" + 
/* 692 */       position().toString() + ", rateLimitPerUser=" + 
/* 693 */       rateLimitPerUser().toString() + ", permissionOverwrites=" + 
/* 694 */       Objects.toString(this.permissionOverwrites_value) + ", parentId=" + 
/* 695 */       parentId().toString() + ", rtcRegion=" + 
/* 696 */       rtcRegion().toString() + ", videoQualityMode=" + 
/* 697 */       videoQualityMode().toString() + ", channel=" + this.channel + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static VoiceChannelEditMono of(VoiceChannel channel) {
/* 708 */     return new VoiceChannelEditMono(channel);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static VoiceChannelEditMono copyOf(VoiceChannelEditMonoGenerator instance) {
/* 719 */     if (instance instanceof VoiceChannelEditMono) {
/* 720 */       return (VoiceChannelEditMono)instance;
/*     */     }
/* 722 */     return of(instance.channel())
/* 723 */       .withReason(instance.reason())
/* 724 */       .withName(instance.name())
/* 725 */       .withBitrate(instance.bitrate())
/* 726 */       .withUserLimit(instance.userLimit())
/* 727 */       .withPosition(instance.position())
/* 728 */       .withRateLimitPerUser(instance.rateLimitPerUser())
/* 729 */       .withPermissionOverwrites(instance.permissionOverwrites())
/* 730 */       .withParentId(instance.parentId())
/* 731 */       .withRtcRegion(instance.rtcRegion())
/* 732 */       .withVideoQualityMode(instance.videoQualityMode());
/*     */   }
/*     */   
/*     */   public boolean isNamePresent() {
/* 736 */     return !this.name_absent;
/*     */   }
/*     */   
/*     */   public String nameOrElse(String defaultValue) {
/* 740 */     return !this.name_absent ? this.name_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isBitratePresent() {
/* 744 */     return !this.bitrate_absent;
/*     */   }
/*     */   
/*     */   public Integer bitrateOrElse(Integer defaultValue) {
/* 748 */     return !this.bitrate_absent ? this.bitrate_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isUserLimitPresent() {
/* 752 */     return !this.userLimit_absent;
/*     */   }
/*     */   
/*     */   public Integer userLimitOrElse(Integer defaultValue) {
/* 756 */     return !this.userLimit_absent ? this.userLimit_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isPositionPresent() {
/* 760 */     return !this.position_absent;
/*     */   }
/*     */   
/*     */   public Integer positionOrElse(Integer defaultValue) {
/* 764 */     return !this.position_absent ? this.position_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isRateLimitPerUserPresent() {
/* 768 */     return !this.rateLimitPerUser_absent;
/*     */   }
/*     */   
/*     */   public Integer rateLimitPerUserOrElse(Integer defaultValue) {
/* 772 */     return !this.rateLimitPerUser_absent ? this.rateLimitPerUser_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isPermissionOverwritesPresent() {
/* 776 */     return !this.permissionOverwrites_absent;
/*     */   }
/*     */   
/*     */   public List<PermissionOverwrite> permissionOverwritesOrElse(List<PermissionOverwrite> defaultValue) {
/* 780 */     return !this.permissionOverwrites_absent ? this.permissionOverwrites_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isParentIdPresent() {
/* 784 */     return !this.parentId_absent;
/*     */   }
/*     */   
/*     */   public Snowflake parentIdOrElse(Snowflake defaultValue) {
/* 788 */     return !this.parentId_absent ? this.parentId_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isRtcRegionPresent() {
/* 792 */     return !this.rtcRegion_absent;
/*     */   }
/*     */   
/*     */   public String rtcRegionOrElse(String defaultValue) {
/* 796 */     return !this.rtcRegion_absent ? this.rtcRegion_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isVideoQualityModePresent() {
/* 800 */     return !this.videoQualityMode_absent;
/*     */   }
/*     */   
/*     */   public VoiceChannel.Mode videoQualityModeOrElse(VoiceChannel.Mode defaultValue) {
/* 804 */     return !this.videoQualityMode_absent ? this.videoQualityMode_value : defaultValue;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\VoiceChannelEditMono.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */