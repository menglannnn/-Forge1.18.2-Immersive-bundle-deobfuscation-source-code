/*     */ package discord4j.core.spec;
/*     */ 
/*     */ import com.google.errorprone.annotations.CanIgnoreReturnValue;
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.object.PermissionOverwrite;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.stream.StreamSupport;
/*     */ import org.immutables.value.Generated;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "NewsChannelEditSpecGenerator", generator = "Immutables")
/*     */ public final class NewsChannelEditSpec
/*     */   implements NewsChannelEditSpecGenerator
/*     */ {
/*     */   @Nullable
/*     */   private final String reason;
/*     */   private final String name_value;
/*     */   private final boolean name_absent;
/*     */   private final Integer position_value;
/*     */   private final boolean position_absent;
/*     */   private final Integer rateLimitPerUser_value;
/*     */   private final boolean rateLimitPerUser_absent;
/*     */   private final String topic_value;
/*     */   private final boolean topic_absent;
/*     */   private final Boolean nsfw_value;
/*     */   private final boolean nsfw_absent;
/*     */   private final List<PermissionOverwrite> permissionOverwrites_value;
/*     */   private final boolean permissionOverwrites_absent;
/*     */   private final Snowflake parentId_value;
/*     */   private final boolean parentId_absent;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   
/*     */   private NewsChannelEditSpec() {
/*  47 */     this.reason = null;
/*  48 */     Possible<String> name$impl = Possible.absent();
/*  49 */     Possible<Integer> position$impl = Possible.absent();
/*  50 */     Possible<Integer> rateLimitPerUser$impl = Possible.absent();
/*  51 */     Possible<String> topic$impl = Possible.absent();
/*  52 */     Possible<Boolean> nsfw$impl = Possible.absent();
/*  53 */     Possible<List<PermissionOverwrite>> permissionOverwrites$impl = Possible.absent();
/*  54 */     Possible<Optional<Snowflake>> parentId$impl = Possible.absent();
/*  55 */     this.name_value = name$impl.toOptional().orElse(null);
/*  56 */     this.name_absent = name$impl.isAbsent();
/*  57 */     this.position_value = position$impl.toOptional().orElse(null);
/*  58 */     this.position_absent = position$impl.isAbsent();
/*  59 */     this.rateLimitPerUser_value = rateLimitPerUser$impl.toOptional().orElse(null);
/*  60 */     this.rateLimitPerUser_absent = rateLimitPerUser$impl.isAbsent();
/*  61 */     this.topic_value = topic$impl.toOptional().orElse(null);
/*  62 */     this.topic_absent = topic$impl.isAbsent();
/*  63 */     this.nsfw_value = nsfw$impl.toOptional().orElse(null);
/*  64 */     this.nsfw_absent = nsfw$impl.isAbsent();
/*  65 */     this.permissionOverwrites_value = permissionOverwrites$impl.toOptional().orElse(null);
/*  66 */     this.permissionOverwrites_absent = permissionOverwrites$impl.isAbsent();
/*  67 */     this.parentId_value = Possible.flatOpt(parentId$impl).orElse(null);
/*  68 */     this.parentId_absent = parentId$impl.isAbsent();
/*  69 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private NewsChannelEditSpec(@Nullable String reason, Possible<String> name, Possible<Integer> position, Possible<Integer> rateLimitPerUser, Possible<String> topic, Possible<Boolean> nsfw, Possible<List<PermissionOverwrite>> permissionOverwrites, Possible<Optional<Snowflake>> parentId) {
/*  81 */     this.reason = reason;
/*  82 */     Possible<String> name$impl = name;
/*  83 */     Possible<Integer> position$impl = position;
/*  84 */     Possible<Integer> rateLimitPerUser$impl = rateLimitPerUser;
/*  85 */     Possible<String> topic$impl = topic;
/*  86 */     Possible<Boolean> nsfw$impl = nsfw;
/*  87 */     Possible<List<PermissionOverwrite>> permissionOverwrites$impl = permissionOverwrites;
/*  88 */     Possible<Optional<Snowflake>> parentId$impl = parentId;
/*  89 */     this.name_value = name$impl.toOptional().orElse(null);
/*  90 */     this.name_absent = name$impl.isAbsent();
/*  91 */     this.position_value = position$impl.toOptional().orElse(null);
/*  92 */     this.position_absent = position$impl.isAbsent();
/*  93 */     this.rateLimitPerUser_value = rateLimitPerUser$impl.toOptional().orElse(null);
/*  94 */     this.rateLimitPerUser_absent = rateLimitPerUser$impl.isAbsent();
/*  95 */     this.topic_value = topic$impl.toOptional().orElse(null);
/*  96 */     this.topic_absent = topic$impl.isAbsent();
/*  97 */     this.nsfw_value = nsfw$impl.toOptional().orElse(null);
/*  98 */     this.nsfw_absent = nsfw$impl.isAbsent();
/*  99 */     this.permissionOverwrites_value = permissionOverwrites$impl.toOptional().orElse(null);
/* 100 */     this.permissionOverwrites_absent = permissionOverwrites$impl.isAbsent();
/* 101 */     this.parentId_value = Possible.flatOpt(parentId$impl).orElse(null);
/* 102 */     this.parentId_absent = parentId$impl.isAbsent();
/* 103 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 109 */   private volatile transient InitShim initShim = new InitShim();
/*     */   
/*     */   @Generated(from = "NewsChannelEditSpecGenerator", generator = "Immutables")
/*     */   private final class InitShim
/*     */   {
/*     */     private String formatInitCycleMessage() {
/* 115 */       List<String> attributes = new ArrayList<>();
/* 116 */       return "Cannot build NewsChannelEditSpec, attribute initializers form cycle " + attributes;
/*     */     }
/*     */ 
/*     */     
/*     */     private InitShim() {}
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String reason() {
/* 126 */     return this.reason;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<String> name() {
/* 134 */     return this.name_absent ? Possible.absent() : Possible.of(this.name_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Integer> position() {
/* 142 */     return this.position_absent ? Possible.absent() : Possible.of(this.position_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Integer> rateLimitPerUser() {
/* 150 */     return this.rateLimitPerUser_absent ? Possible.absent() : Possible.of(this.rateLimitPerUser_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<String> topic() {
/* 158 */     return this.topic_absent ? Possible.absent() : Possible.of(this.topic_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Boolean> nsfw() {
/* 166 */     return this.nsfw_absent ? Possible.absent() : Possible.of(this.nsfw_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<List<PermissionOverwrite>> permissionOverwrites() {
/* 174 */     return this.permissionOverwrites_absent ? Possible.absent() : 
/* 175 */       Possible.of(this.permissionOverwrites_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Optional<Snowflake>> parentId() {
/* 183 */     return this.parentId_absent ? Possible.absent() : 
/* 184 */       Possible.of(Optional.ofNullable(this.parentId_value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final NewsChannelEditSpec withReason(@Nullable String value) {
/* 194 */     if (Objects.equals(this.reason, value)) return this; 
/* 195 */     return validate(new NewsChannelEditSpec(value, 
/*     */           
/* 197 */           name(), 
/* 198 */           position(), 
/* 199 */           rateLimitPerUser(), 
/* 200 */           topic(), 
/* 201 */           nsfw(), 
/* 202 */           permissionOverwrites(), 
/* 203 */           parentId()));
/*     */   }
/*     */   
/*     */   public NewsChannelEditSpec withName(Possible<String> value) {
/* 207 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/* 208 */     return validate(new NewsChannelEditSpec(this.reason, newValue, 
/*     */ 
/*     */           
/* 211 */           position(), 
/* 212 */           rateLimitPerUser(), 
/* 213 */           topic(), 
/* 214 */           nsfw(), 
/* 215 */           permissionOverwrites(), 
/* 216 */           parentId()));
/*     */   }
/*     */   
/*     */   public NewsChannelEditSpec withName(String value) {
/* 220 */     Possible<String> newValue = Possible.of(value);
/* 221 */     return validate(new NewsChannelEditSpec(this.reason, newValue, 
/*     */ 
/*     */           
/* 224 */           position(), 
/* 225 */           rateLimitPerUser(), 
/* 226 */           topic(), 
/* 227 */           nsfw(), 
/* 228 */           permissionOverwrites(), 
/* 229 */           parentId()));
/*     */   }
/*     */   
/*     */   public NewsChannelEditSpec withPosition(Possible<Integer> value) {
/* 233 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/* 234 */     return validate(new NewsChannelEditSpec(this.reason, 
/*     */           
/* 236 */           name(), newValue, 
/*     */           
/* 238 */           rateLimitPerUser(), 
/* 239 */           topic(), 
/* 240 */           nsfw(), 
/* 241 */           permissionOverwrites(), 
/* 242 */           parentId()));
/*     */   }
/*     */   
/*     */   public NewsChannelEditSpec withPosition(Integer value) {
/* 246 */     Possible<Integer> newValue = Possible.of(value);
/* 247 */     return validate(new NewsChannelEditSpec(this.reason, 
/*     */           
/* 249 */           name(), newValue, 
/*     */           
/* 251 */           rateLimitPerUser(), 
/* 252 */           topic(), 
/* 253 */           nsfw(), 
/* 254 */           permissionOverwrites(), 
/* 255 */           parentId()));
/*     */   }
/*     */   
/*     */   public NewsChannelEditSpec withRateLimitPerUser(Possible<Integer> value) {
/* 259 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/* 260 */     return validate(new NewsChannelEditSpec(this.reason, 
/*     */           
/* 262 */           name(), 
/* 263 */           position(), newValue, 
/*     */           
/* 265 */           topic(), 
/* 266 */           nsfw(), 
/* 267 */           permissionOverwrites(), 
/* 268 */           parentId()));
/*     */   }
/*     */   
/*     */   public NewsChannelEditSpec withRateLimitPerUser(Integer value) {
/* 272 */     Possible<Integer> newValue = Possible.of(value);
/* 273 */     return validate(new NewsChannelEditSpec(this.reason, 
/*     */           
/* 275 */           name(), 
/* 276 */           position(), newValue, 
/*     */           
/* 278 */           topic(), 
/* 279 */           nsfw(), 
/* 280 */           permissionOverwrites(), 
/* 281 */           parentId()));
/*     */   }
/*     */   
/*     */   public NewsChannelEditSpec withTopic(Possible<String> value) {
/* 285 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/* 286 */     return validate(new NewsChannelEditSpec(this.reason, 
/*     */           
/* 288 */           name(), 
/* 289 */           position(), 
/* 290 */           rateLimitPerUser(), newValue, 
/*     */           
/* 292 */           nsfw(), 
/* 293 */           permissionOverwrites(), 
/* 294 */           parentId()));
/*     */   }
/*     */   
/*     */   public NewsChannelEditSpec withTopic(String value) {
/* 298 */     Possible<String> newValue = Possible.of(value);
/* 299 */     return validate(new NewsChannelEditSpec(this.reason, 
/*     */           
/* 301 */           name(), 
/* 302 */           position(), 
/* 303 */           rateLimitPerUser(), newValue, 
/*     */           
/* 305 */           nsfw(), 
/* 306 */           permissionOverwrites(), 
/* 307 */           parentId()));
/*     */   }
/*     */   
/*     */   public NewsChannelEditSpec withNsfw(Possible<Boolean> value) {
/* 311 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/* 312 */     return validate(new NewsChannelEditSpec(this.reason, 
/*     */           
/* 314 */           name(), 
/* 315 */           position(), 
/* 316 */           rateLimitPerUser(), 
/* 317 */           topic(), newValue, 
/*     */           
/* 319 */           permissionOverwrites(), 
/* 320 */           parentId()));
/*     */   }
/*     */   
/*     */   public NewsChannelEditSpec withNsfw(Boolean value) {
/* 324 */     Possible<Boolean> newValue = Possible.of(value);
/* 325 */     return validate(new NewsChannelEditSpec(this.reason, 
/*     */           
/* 327 */           name(), 
/* 328 */           position(), 
/* 329 */           rateLimitPerUser(), 
/* 330 */           topic(), newValue, 
/*     */           
/* 332 */           permissionOverwrites(), 
/* 333 */           parentId()));
/*     */   }
/*     */   
/*     */   public NewsChannelEditSpec withPermissionOverwrites(Possible<List<PermissionOverwrite>> possible) {
/* 337 */     Possible<List<PermissionOverwrite>> newValue = Objects.<Possible<List<PermissionOverwrite>>>requireNonNull(possible);
/* 338 */     return validate(new NewsChannelEditSpec(this.reason, 
/*     */           
/* 340 */           name(), 
/* 341 */           position(), 
/* 342 */           rateLimitPerUser(), 
/* 343 */           topic(), 
/* 344 */           nsfw(), newValue, 
/*     */           
/* 346 */           parentId()));
/*     */   }
/*     */   
/*     */   public NewsChannelEditSpec withPermissionOverwrites(Iterable<PermissionOverwrite> elements) {
/* 350 */     Possible<List<PermissionOverwrite>> newValue = Possible.of(
/* 351 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/* 352 */     return validate(new NewsChannelEditSpec(this.reason, 
/*     */           
/* 354 */           name(), 
/* 355 */           position(), 
/* 356 */           rateLimitPerUser(), 
/* 357 */           topic(), 
/* 358 */           nsfw(), newValue, 
/*     */           
/* 360 */           parentId()));
/*     */   }
/*     */   
/*     */   @SafeVarargs
/*     */   public final NewsChannelEditSpec withPermissionOverwrites(PermissionOverwrite... elements) {
/* 365 */     Possible<List<PermissionOverwrite>> newValue = Possible.of(Arrays.asList(elements));
/* 366 */     return validate(new NewsChannelEditSpec(this.reason, 
/*     */           
/* 368 */           name(), 
/* 369 */           position(), 
/* 370 */           rateLimitPerUser(), 
/* 371 */           topic(), 
/* 372 */           nsfw(), newValue, 
/*     */           
/* 374 */           parentId()));
/*     */   }
/*     */   
/*     */   public NewsChannelEditSpec withParentId(Possible<Optional<Snowflake>> value) {
/* 378 */     Possible<Optional<Snowflake>> newValue = Objects.<Possible<Optional<Snowflake>>>requireNonNull(value);
/* 379 */     return validate(new NewsChannelEditSpec(this.reason, 
/*     */           
/* 381 */           name(), 
/* 382 */           position(), 
/* 383 */           rateLimitPerUser(), 
/* 384 */           topic(), 
/* 385 */           nsfw(), 
/* 386 */           permissionOverwrites(), newValue));
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public NewsChannelEditSpec withParentId(@Nullable Snowflake value) {
/* 392 */     Possible<Optional<Snowflake>> newValue = Possible.of(Optional.ofNullable(value));
/* 393 */     return validate(new NewsChannelEditSpec(this.reason, 
/*     */           
/* 395 */           name(), 
/* 396 */           position(), 
/* 397 */           rateLimitPerUser(), 
/* 398 */           topic(), 
/* 399 */           nsfw(), 
/* 400 */           permissionOverwrites(), newValue));
/*     */   }
/*     */ 
/*     */   
/*     */   public NewsChannelEditSpec withParentIdOrNull(@Nullable Snowflake value) {
/* 405 */     Possible<Optional<Snowflake>> newValue = Possible.of(Optional.ofNullable(value));
/* 406 */     return validate(new NewsChannelEditSpec(this.reason, 
/*     */           
/* 408 */           name(), 
/* 409 */           position(), 
/* 410 */           rateLimitPerUser(), 
/* 411 */           topic(), 
/* 412 */           nsfw(), 
/* 413 */           permissionOverwrites(), newValue));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 423 */     if (this == another) return true; 
/* 424 */     return (another instanceof NewsChannelEditSpec && 
/* 425 */       equalTo(0, (NewsChannelEditSpec)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, NewsChannelEditSpec another) {
/* 429 */     return (Objects.equals(this.reason, another.reason) && 
/* 430 */       name().equals(another.name()) && 
/* 431 */       position().equals(another.position()) && 
/* 432 */       rateLimitPerUser().equals(another.rateLimitPerUser()) && 
/* 433 */       topic().equals(another.topic()) && 
/* 434 */       nsfw().equals(another.nsfw()) && 
/* 435 */       Objects.equals(this.permissionOverwrites_value, another.permissionOverwrites_value) && 
/* 436 */       parentId().equals(another.parentId()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 445 */     int h = 5381;
/* 446 */     h += (h << 5) + Objects.hashCode(this.reason);
/* 447 */     h += (h << 5) + name().hashCode();
/* 448 */     h += (h << 5) + position().hashCode();
/* 449 */     h += (h << 5) + rateLimitPerUser().hashCode();
/* 450 */     h += (h << 5) + topic().hashCode();
/* 451 */     h += (h << 5) + nsfw().hashCode();
/* 452 */     h += (h << 5) + Objects.hashCode(this.permissionOverwrites_value);
/* 453 */     h += (h << 5) + parentId().hashCode();
/* 454 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 463 */     return "NewsChannelEditSpec{reason=" + this.reason + ", name=" + 
/*     */       
/* 465 */       name().toString() + ", position=" + 
/* 466 */       position().toString() + ", rateLimitPerUser=" + 
/* 467 */       rateLimitPerUser().toString() + ", topic=" + 
/* 468 */       topic().toString() + ", nsfw=" + 
/* 469 */       nsfw().toString() + ", permissionOverwrites=" + 
/* 470 */       Objects.toString(this.permissionOverwrites_value) + ", parentId=" + 
/* 471 */       parentId().toString() + "}";
/*     */   }
/*     */ 
/*     */   
/* 475 */   private static final NewsChannelEditSpec INSTANCE = validate(new NewsChannelEditSpec());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static NewsChannelEditSpec create() {
/* 482 */     return INSTANCE;
/*     */   }
/*     */   
/*     */   private static NewsChannelEditSpec validate(NewsChannelEditSpec instance) {
/* 486 */     return (INSTANCE != null && INSTANCE.equalTo(0, instance)) ? INSTANCE : instance;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static NewsChannelEditSpec copyOf(NewsChannelEditSpecGenerator instance) {
/* 497 */     if (instance instanceof NewsChannelEditSpec) {
/* 498 */       return (NewsChannelEditSpec)instance;
/*     */     }
/* 500 */     return builder()
/* 501 */       .from(instance)
/* 502 */       .build();
/*     */   }
/*     */   
/*     */   public boolean isNamePresent() {
/* 506 */     return !this.name_absent;
/*     */   }
/*     */   
/*     */   public String nameOrElse(String defaultValue) {
/* 510 */     return !this.name_absent ? this.name_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isPositionPresent() {
/* 514 */     return !this.position_absent;
/*     */   }
/*     */   
/*     */   public Integer positionOrElse(Integer defaultValue) {
/* 518 */     return !this.position_absent ? this.position_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isRateLimitPerUserPresent() {
/* 522 */     return !this.rateLimitPerUser_absent;
/*     */   }
/*     */   
/*     */   public Integer rateLimitPerUserOrElse(Integer defaultValue) {
/* 526 */     return !this.rateLimitPerUser_absent ? this.rateLimitPerUser_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isTopicPresent() {
/* 530 */     return !this.topic_absent;
/*     */   }
/*     */   
/*     */   public String topicOrElse(String defaultValue) {
/* 534 */     return !this.topic_absent ? this.topic_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isNsfwPresent() {
/* 538 */     return !this.nsfw_absent;
/*     */   }
/*     */   
/*     */   public Boolean nsfwOrElse(Boolean defaultValue) {
/* 542 */     return !this.nsfw_absent ? this.nsfw_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isPermissionOverwritesPresent() {
/* 546 */     return !this.permissionOverwrites_absent;
/*     */   }
/*     */   
/*     */   public List<PermissionOverwrite> permissionOverwritesOrElse(List<PermissionOverwrite> defaultValue) {
/* 550 */     return !this.permissionOverwrites_absent ? this.permissionOverwrites_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isParentIdPresent() {
/* 554 */     return !this.parentId_absent;
/*     */   }
/*     */   
/*     */   public Snowflake parentIdOrElse(Snowflake defaultValue) {
/* 558 */     return !this.parentId_absent ? this.parentId_value : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 578 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "NewsChannelEditSpecGenerator", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/* 590 */     private Possible<String> name_possible = Possible.absent();
/* 591 */     private Possible<Integer> position_possible = Possible.absent();
/* 592 */     private Possible<Integer> rateLimitPerUser_possible = Possible.absent();
/* 593 */     private Possible<String> topic_possible = Possible.absent();
/* 594 */     private Possible<Boolean> nsfw_possible = Possible.absent();
/* 595 */     private List<PermissionOverwrite> permissionOverwrites_list = null;
/* 596 */     private Possible<Optional<Snowflake>> parentId_possible = Possible.absent();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private String reason;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(NewsChannelEditSpec instance) {
/* 610 */       return from(instance);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     final Builder from(NewsChannelEditSpecGenerator instance) {
/* 620 */       Objects.requireNonNull(instance, "instance");
/* 621 */       String reasonValue = instance.reason();
/* 622 */       if (reasonValue != null) {
/* 623 */         reason(reasonValue);
/*     */       }
/* 625 */       name(instance.name());
/* 626 */       position(instance.position());
/* 627 */       rateLimitPerUser(instance.rateLimitPerUser());
/* 628 */       topic(instance.topic());
/* 629 */       nsfw(instance.nsfw());
/* 630 */       permissionOverwrites(instance.permissionOverwrites());
/* 631 */       parentId(instance.parentId());
/* 632 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder reason(@Nullable String reason) {
/* 642 */       this.reason = reason;
/* 643 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder name(Possible<String> value) {
/* 648 */       this.name_possible = value;
/* 649 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder name(String value) {
/* 654 */       this.name_possible = Possible.of(value);
/* 655 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder position(Possible<Integer> value) {
/* 660 */       this.position_possible = value;
/* 661 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder position(Integer value) {
/* 666 */       this.position_possible = Possible.of(value);
/* 667 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder rateLimitPerUser(Possible<Integer> value) {
/* 672 */       this.rateLimitPerUser_possible = value;
/* 673 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder rateLimitPerUser(Integer value) {
/* 678 */       this.rateLimitPerUser_possible = Possible.of(value);
/* 679 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder topic(Possible<String> value) {
/* 684 */       this.topic_possible = value;
/* 685 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder topic(String value) {
/* 690 */       this.topic_possible = Possible.of(value);
/* 691 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder nsfw(Possible<Boolean> value) {
/* 696 */       this.nsfw_possible = value;
/* 697 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder nsfw(Boolean value) {
/* 702 */       this.nsfw_possible = Possible.of(value);
/* 703 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder addPermissionOverwrite(PermissionOverwrite element) {
/* 708 */       permissionOverwrites_getOrCreate().add(element);
/* 709 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder addAllPermissionOverwrites(List<PermissionOverwrite> elements) {
/* 714 */       permissionOverwrites_getOrCreate().addAll(elements);
/* 715 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder permissionOverwrites(Possible<List<PermissionOverwrite>> elements) {
/* 720 */       this.permissionOverwrites_list = null;
/* 721 */       elements.toOptional().ifPresent(e -> permissionOverwrites_getOrCreate().addAll(e));
/* 722 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder permissionOverwrites(List<PermissionOverwrite> elements) {
/* 727 */       this.permissionOverwrites_list = new ArrayList<>(elements);
/* 728 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder permissionOverwrites(Iterable<PermissionOverwrite> elements) {
/* 733 */       this.permissionOverwrites_list = (List<PermissionOverwrite>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/* 734 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder parentId(Possible<Optional<Snowflake>> value) {
/* 739 */       this.parentId_possible = value;
/* 740 */       return this;
/*     */     }
/*     */     
/*     */     @Deprecated
/*     */     @CanIgnoreReturnValue
/*     */     public Builder parentId(@Nullable Snowflake value) {
/* 746 */       this.parentId_possible = Possible.of(Optional.ofNullable(value));
/* 747 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder parentIdOrNull(@Nullable Snowflake value) {
/* 752 */       this.parentId_possible = Possible.of(Optional.ofNullable(value));
/* 753 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public NewsChannelEditSpec build() {
/* 762 */       return NewsChannelEditSpec.validate(new NewsChannelEditSpec(this.reason, 
/*     */             
/* 764 */             name_build(), 
/* 765 */             position_build(), 
/* 766 */             rateLimitPerUser_build(), 
/* 767 */             topic_build(), 
/* 768 */             nsfw_build(), 
/* 769 */             permissionOverwrites_build(), 
/* 770 */             parentId_build()));
/*     */     }
/*     */     
/*     */     private Possible<String> name_build() {
/* 774 */       return this.name_possible;
/*     */     }
/*     */     
/*     */     private Possible<Integer> position_build() {
/* 778 */       return this.position_possible;
/*     */     }
/*     */     
/*     */     private Possible<Integer> rateLimitPerUser_build() {
/* 782 */       return this.rateLimitPerUser_possible;
/*     */     }
/*     */     
/*     */     private Possible<String> topic_build() {
/* 786 */       return this.topic_possible;
/*     */     }
/*     */     
/*     */     private Possible<Boolean> nsfw_build() {
/* 790 */       return this.nsfw_possible;
/*     */     }
/*     */     
/*     */     private Possible<List<PermissionOverwrite>> permissionOverwrites_build() {
/* 794 */       return (this.permissionOverwrites_list == null) ? Possible.absent() : 
/* 795 */         Possible.of(this.permissionOverwrites_list);
/*     */     }
/*     */     
/*     */     private List<PermissionOverwrite> permissionOverwrites_getOrCreate() {
/* 799 */       if (this.permissionOverwrites_list == null) {
/* 800 */         this.permissionOverwrites_list = new ArrayList<>();
/*     */       }
/* 802 */       return this.permissionOverwrites_list;
/*     */     }
/*     */     
/*     */     private Possible<Optional<Snowflake>> parentId_build() {
/* 806 */       return this.parentId_possible;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\NewsChannelEditSpec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */