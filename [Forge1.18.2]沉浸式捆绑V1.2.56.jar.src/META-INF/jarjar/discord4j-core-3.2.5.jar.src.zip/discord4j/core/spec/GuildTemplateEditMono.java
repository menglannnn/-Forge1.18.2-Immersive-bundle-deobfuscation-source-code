/*     */ package discord4j.core.spec;
/*     */ 
/*     */ import discord4j.core.object.GuildTemplate;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import org.immutables.value.Generated;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "GuildTemplateEditMonoGenerator", generator = "Immutables")
/*     */ public final class GuildTemplateEditMono
/*     */   extends GuildTemplateEditMonoGenerator
/*     */ {
/*     */   private final String name_value;
/*     */   private final boolean name_absent;
/*     */   private final String description_value;
/*     */   private final boolean description_absent;
/*     */   private final GuildTemplate guildTemplate;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   private volatile transient InitShim initShim;
/*     */   
/*     */   private GuildTemplateEditMono(GuildTemplate guildTemplate) {
/*  57 */     this.initShim = new InitShim(); this.guildTemplate = Objects.<GuildTemplate>requireNonNull(guildTemplate, "guildTemplate"); Possible<String> name$impl = Possible.absent(); Possible<Optional<String>> description$impl = Possible.absent(); this.name_value = name$impl.toOptional().orElse(null); this.name_absent = name$impl.isAbsent(); this.description_value = Possible.flatOpt(description$impl).orElse(null); this.description_absent = description$impl.isAbsent(); this.initShim = null; } private GuildTemplateEditMono(Possible<String> name, Possible<Optional<String>> description, GuildTemplate guildTemplate) { this.initShim = new InitShim(); Possible<String> name$impl = name; Possible<Optional<String>> description$impl = description;
/*     */     this.guildTemplate = guildTemplate;
/*     */     this.name_value = name$impl.toOptional().orElse(null);
/*     */     this.name_absent = name$impl.isAbsent();
/*     */     this.description_value = Possible.flatOpt(description$impl).orElse(null);
/*     */     this.description_absent = description$impl.isAbsent();
/*  63 */     this.initShim = null; } @Generated(from = "GuildTemplateEditMonoGenerator", generator = "Immutables") private final class InitShim { private InitShim() {} private String formatInitCycleMessage() { List<String> attributes = new ArrayList<>();
/*  64 */       return "Cannot build GuildTemplateEditMono, attribute initializers form cycle " + attributes; }
/*     */      }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<String> name() {
/*  73 */     return this.name_absent ? Possible.absent() : Possible.of(this.name_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Optional<String>> description() {
/*  81 */     return this.description_absent ? Possible.absent() : 
/*  82 */       Possible.of(Optional.ofNullable(this.description_value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GuildTemplate guildTemplate() {
/*  90 */     return this.guildTemplate;
/*     */   }
/*     */   
/*     */   public GuildTemplateEditMono withName(Possible<String> value) {
/*  94 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/*  95 */     return new GuildTemplateEditMono(newValue, description(), this.guildTemplate);
/*     */   }
/*     */   
/*     */   public GuildTemplateEditMono withName(String value) {
/*  99 */     Possible<String> newValue = Possible.of(value);
/* 100 */     return new GuildTemplateEditMono(newValue, description(), this.guildTemplate);
/*     */   }
/*     */   
/*     */   public GuildTemplateEditMono withDescription(Possible<Optional<String>> value) {
/* 104 */     Possible<Optional<String>> newValue = Objects.<Possible<Optional<String>>>requireNonNull(value);
/* 105 */     return new GuildTemplateEditMono(name(), newValue, this.guildTemplate);
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public GuildTemplateEditMono withDescription(@Nullable String value) {
/* 110 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/* 111 */     return new GuildTemplateEditMono(name(), newValue, this.guildTemplate);
/*     */   }
/*     */   
/*     */   public GuildTemplateEditMono withDescriptionOrNull(@Nullable String value) {
/* 115 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/* 116 */     return new GuildTemplateEditMono(name(), newValue, this.guildTemplate);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final GuildTemplateEditMono withGuildTemplate(GuildTemplate value) {
/* 126 */     if (this.guildTemplate == value) return this; 
/* 127 */     GuildTemplate newValue = Objects.<GuildTemplate>requireNonNull(value, "guildTemplate");
/* 128 */     return new GuildTemplateEditMono(name(), description(), newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 137 */     if (this == another) return true; 
/* 138 */     return (another instanceof GuildTemplateEditMono && 
/* 139 */       equalTo(0, (GuildTemplateEditMono)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, GuildTemplateEditMono another) {
/* 143 */     return (name().equals(another.name()) && 
/* 144 */       description().equals(another.description()) && this.guildTemplate
/* 145 */       .equals(another.guildTemplate));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 154 */     int h = 5381;
/* 155 */     h += (h << 5) + name().hashCode();
/* 156 */     h += (h << 5) + description().hashCode();
/* 157 */     h += (h << 5) + this.guildTemplate.hashCode();
/* 158 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 167 */     return "GuildTemplateEditMono{name=" + 
/* 168 */       name().toString() + ", description=" + 
/* 169 */       description().toString() + ", guildTemplate=" + this.guildTemplate + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static GuildTemplateEditMono of(GuildTemplate guildTemplate) {
/* 180 */     return new GuildTemplateEditMono(guildTemplate);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static GuildTemplateEditMono copyOf(GuildTemplateEditMonoGenerator instance) {
/* 191 */     if (instance instanceof GuildTemplateEditMono) {
/* 192 */       return (GuildTemplateEditMono)instance;
/*     */     }
/* 194 */     return of(instance.guildTemplate())
/* 195 */       .withName(instance.name())
/* 196 */       .withDescription(instance.description());
/*     */   }
/*     */   
/*     */   public boolean isNamePresent() {
/* 200 */     return !this.name_absent;
/*     */   }
/*     */   
/*     */   public String nameOrElse(String defaultValue) {
/* 204 */     return !this.name_absent ? this.name_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isDescriptionPresent() {
/* 208 */     return !this.description_absent;
/*     */   }
/*     */   
/*     */   public String descriptionOrElse(String defaultValue) {
/* 212 */     return !this.description_absent ? this.description_value : defaultValue;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\GuildTemplateEditMono.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */