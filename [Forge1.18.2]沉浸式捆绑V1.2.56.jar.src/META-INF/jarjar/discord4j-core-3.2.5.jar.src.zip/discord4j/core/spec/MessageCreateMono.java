/*     */ package discord4j.core.spec;
/*     */ 
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.object.component.LayoutComponent;
/*     */ import discord4j.core.object.entity.Message;
/*     */ import discord4j.core.object.entity.channel.MessageChannel;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import discord4j.rest.util.AllowedMentions;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.stream.StreamSupport;
/*     */ import org.immutables.value.Generated;
/*     */ import reactor.core.CoreSubscriber;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "MessageCreateMonoGenerator", generator = "Immutables")
/*     */ public final class MessageCreateMono
/*     */   extends MessageCreateMonoGenerator
/*     */ {
/*     */   private final String content_value;
/*     */   private final boolean content_absent;
/*     */   private final String nonce_value;
/*     */   private final boolean nonce_absent;
/*     */   private final Boolean tts_value;
/*     */   private final boolean tts_absent;
/*     */   private final List<EmbedCreateSpec> embeds_value;
/*     */   private final boolean embeds_absent;
/*     */   private final List<MessageCreateFields.File> files;
/*     */   private final List<MessageCreateFields.FileSpoiler> fileSpoilers;
/*     */   private final AllowedMentions allowedMentions_value;
/*     */   private final boolean allowedMentions_absent;
/*     */   private final Snowflake messageReference_value;
/*     */   private final boolean messageReference_absent;
/*     */   private final List<LayoutComponent> components_value;
/*     */   private final boolean components_absent;
/*     */   private final MessageChannel channel;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   private volatile transient InitShim initShim;
/*     */   
/*     */   private MessageCreateMono(MessageChannel channel) {
/* 118 */     this.initShim = new InitShim(); this.channel = Objects.<MessageChannel>requireNonNull(channel, "channel"); Possible<String> content$impl = Possible.absent(); Possible<String> nonce$impl = Possible.absent(); Possible<Boolean> tts$impl = Possible.absent(); Possible<List<EmbedCreateSpec>> embeds$impl = Possible.absent(); Possible<AllowedMentions> allowedMentions$impl = Possible.absent(); Possible<Snowflake> messageReference$impl = Possible.absent(); Possible<List<LayoutComponent>> components$impl = Possible.absent(); this.content_value = content$impl.toOptional().orElse(null); this.content_absent = content$impl.isAbsent(); this.nonce_value = nonce$impl.toOptional().orElse(null); this.nonce_absent = nonce$impl.isAbsent(); this.tts_value = tts$impl.toOptional().orElse(null); this.tts_absent = tts$impl.isAbsent(); this.embeds_value = embeds$impl.toOptional().orElse(null); this.embeds_absent = embeds$impl.isAbsent(); this.allowedMentions_value = allowedMentions$impl.toOptional().orElse(null); this.allowedMentions_absent = allowedMentions$impl.isAbsent(); this.messageReference_value = messageReference$impl.toOptional().orElse(null); this.messageReference_absent = messageReference$impl.isAbsent(); this.components_value = components$impl.toOptional().orElse(null); this.components_absent = components$impl.isAbsent(); this.files = this.initShim.files(); this.fileSpoilers = this.initShim.fileSpoilers(); this.initShim = null; } private MessageCreateMono(Possible<String> content, Possible<String> nonce, Possible<Boolean> tts, Possible<List<EmbedCreateSpec>> embeds, List<MessageCreateFields.File> files, List<MessageCreateFields.FileSpoiler> fileSpoilers, Possible<AllowedMentions> allowedMentions, Possible<Snowflake> messageReference, Possible<List<LayoutComponent>> components, MessageChannel channel) { this.initShim = new InitShim(); Possible<String> content$impl = content; Possible<String> nonce$impl = nonce; Possible<Boolean> tts$impl = tts; Possible<List<EmbedCreateSpec>> embeds$impl = embeds; this.initShim.files(files); this.initShim.fileSpoilers(fileSpoilers); Possible<AllowedMentions> allowedMentions$impl = allowedMentions; Possible<Snowflake> messageReference$impl = messageReference; Possible<List<LayoutComponent>> components$impl = components; this.channel = channel; this.content_value = content$impl.toOptional().orElse(null); this.content_absent = content$impl.isAbsent(); this.nonce_value = nonce$impl.toOptional().orElse(null); this.nonce_absent = nonce$impl.isAbsent(); this.tts_value = tts$impl.toOptional().orElse(null); this.tts_absent = tts$impl.isAbsent(); this.embeds_value = embeds$impl.toOptional().orElse(null); this.embeds_absent = embeds$impl.isAbsent(); this.allowedMentions_value = allowedMentions$impl.toOptional().orElse(null); this.allowedMentions_absent = allowedMentions$impl.isAbsent(); this.messageReference_value = messageReference$impl.toOptional().orElse(null); this.messageReference_absent = messageReference$impl.isAbsent();
/*     */     this.components_value = components$impl.toOptional().orElse(null);
/*     */     this.components_absent = components$impl.isAbsent();
/*     */     this.files = this.initShim.files();
/*     */     this.fileSpoilers = this.initShim.fileSpoilers();
/* 123 */     this.initShim = null; } @Generated(from = "MessageCreateMonoGenerator", generator = "Immutables") private final class InitShim { private byte filesBuildStage = 0;
/*     */     private List<MessageCreateFields.File> files;
/*     */     
/*     */     List<MessageCreateFields.File> files() {
/* 127 */       if (this.filesBuildStage == -1) throw new IllegalStateException(formatInitCycleMessage()); 
/* 128 */       if (this.filesBuildStage == 0) {
/* 129 */         this.filesBuildStage = -1;
/* 130 */         this.files = (List)MessageCreateMono.createUnmodifiableList(false, MessageCreateMono.createSafeList((Iterable)MessageCreateMono.this.files(), true, false));
/* 131 */         this.filesBuildStage = 1;
/*     */       } 
/* 133 */       return this.files;
/*     */     }
/*     */     
/*     */     void files(List<MessageCreateFields.File> files) {
/* 137 */       this.files = files;
/* 138 */       this.filesBuildStage = 1;
/*     */     }
/*     */     
/* 141 */     private byte fileSpoilersBuildStage = 0;
/*     */     private List<MessageCreateFields.FileSpoiler> fileSpoilers;
/*     */     
/*     */     List<MessageCreateFields.FileSpoiler> fileSpoilers() {
/* 145 */       if (this.fileSpoilersBuildStage == -1) throw new IllegalStateException(formatInitCycleMessage()); 
/* 146 */       if (this.fileSpoilersBuildStage == 0) {
/* 147 */         this.fileSpoilersBuildStage = -1;
/* 148 */         this.fileSpoilers = (List)MessageCreateMono.createUnmodifiableList(false, MessageCreateMono.createSafeList((Iterable)MessageCreateMono.this.fileSpoilers(), true, false));
/* 149 */         this.fileSpoilersBuildStage = 1;
/*     */       } 
/* 151 */       return this.fileSpoilers;
/*     */     }
/*     */     
/*     */     void fileSpoilers(List<MessageCreateFields.FileSpoiler> fileSpoilers) {
/* 155 */       this.fileSpoilers = fileSpoilers;
/* 156 */       this.fileSpoilersBuildStage = 1;
/*     */     }
/*     */     
/*     */     private String formatInitCycleMessage() {
/* 160 */       List<String> attributes = new ArrayList<>();
/* 161 */       if (this.filesBuildStage == -1) attributes.add("files"); 
/* 162 */       if (this.fileSpoilersBuildStage == -1) attributes.add("fileSpoilers"); 
/* 163 */       return "Cannot build MessageCreateMono, attribute initializers form cycle " + attributes;
/*     */     }
/*     */ 
/*     */     
/*     */     private InitShim() {} }
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<String> content() {
/* 172 */     return this.content_absent ? Possible.absent() : Possible.of(this.content_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<String> nonce() {
/* 180 */     return this.nonce_absent ? Possible.absent() : Possible.of(this.nonce_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Boolean> tts() {
/* 188 */     return this.tts_absent ? Possible.absent() : Possible.of(this.tts_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<List<EmbedCreateSpec>> embeds() {
/* 196 */     return this.embeds_absent ? Possible.absent() : 
/* 197 */       Possible.of(this.embeds_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<MessageCreateFields.File> files() {
/* 205 */     InitShim shim = this.initShim;
/* 206 */     return (shim != null) ? 
/* 207 */       shim.files() : 
/* 208 */       this.files;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<MessageCreateFields.FileSpoiler> fileSpoilers() {
/* 216 */     InitShim shim = this.initShim;
/* 217 */     return (shim != null) ? 
/* 218 */       shim.fileSpoilers() : 
/* 219 */       this.fileSpoilers;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<AllowedMentions> allowedMentions() {
/* 227 */     return this.allowedMentions_absent ? Possible.absent() : Possible.of(this.allowedMentions_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Snowflake> messageReference() {
/* 235 */     return this.messageReference_absent ? Possible.absent() : Possible.of(this.messageReference_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<List<LayoutComponent>> components() {
/* 243 */     return this.components_absent ? Possible.absent() : 
/* 244 */       Possible.of(this.components_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MessageChannel channel() {
/* 252 */     return this.channel;
/*     */   }
/*     */   
/*     */   public MessageCreateMono withContent(Possible<String> value) {
/* 256 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/* 257 */     return new MessageCreateMono(newValue, 
/*     */         
/* 259 */         nonce(), 
/* 260 */         tts(), 
/* 261 */         embeds(), this.files, this.fileSpoilers, 
/*     */ 
/*     */         
/* 264 */         allowedMentions(), 
/* 265 */         messageReference(), 
/* 266 */         components(), this.channel);
/*     */   }
/*     */ 
/*     */   
/*     */   public MessageCreateMono withContent(String value) {
/* 271 */     Possible<String> newValue = Possible.of(value);
/* 272 */     return new MessageCreateMono(newValue, 
/*     */         
/* 274 */         nonce(), 
/* 275 */         tts(), 
/* 276 */         embeds(), this.files, this.fileSpoilers, 
/*     */ 
/*     */         
/* 279 */         allowedMentions(), 
/* 280 */         messageReference(), 
/* 281 */         components(), this.channel);
/*     */   }
/*     */ 
/*     */   
/*     */   public MessageCreateMono withNonce(Possible<String> value) {
/* 286 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/* 287 */     return new MessageCreateMono(
/* 288 */         content(), newValue, 
/*     */         
/* 290 */         tts(), 
/* 291 */         embeds(), this.files, this.fileSpoilers, 
/*     */ 
/*     */         
/* 294 */         allowedMentions(), 
/* 295 */         messageReference(), 
/* 296 */         components(), this.channel);
/*     */   }
/*     */ 
/*     */   
/*     */   public MessageCreateMono withNonce(String value) {
/* 301 */     Possible<String> newValue = Possible.of(value);
/* 302 */     return new MessageCreateMono(
/* 303 */         content(), newValue, 
/*     */         
/* 305 */         tts(), 
/* 306 */         embeds(), this.files, this.fileSpoilers, 
/*     */ 
/*     */         
/* 309 */         allowedMentions(), 
/* 310 */         messageReference(), 
/* 311 */         components(), this.channel);
/*     */   }
/*     */ 
/*     */   
/*     */   public MessageCreateMono withTts(Possible<Boolean> value) {
/* 316 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/* 317 */     return new MessageCreateMono(
/* 318 */         content(), 
/* 319 */         nonce(), newValue, 
/*     */         
/* 321 */         embeds(), this.files, this.fileSpoilers, 
/*     */ 
/*     */         
/* 324 */         allowedMentions(), 
/* 325 */         messageReference(), 
/* 326 */         components(), this.channel);
/*     */   }
/*     */ 
/*     */   
/*     */   public MessageCreateMono withTts(Boolean value) {
/* 331 */     Possible<Boolean> newValue = Possible.of(value);
/* 332 */     return new MessageCreateMono(
/* 333 */         content(), 
/* 334 */         nonce(), newValue, 
/*     */         
/* 336 */         embeds(), this.files, this.fileSpoilers, 
/*     */ 
/*     */         
/* 339 */         allowedMentions(), 
/* 340 */         messageReference(), 
/* 341 */         components(), this.channel);
/*     */   }
/*     */ 
/*     */   
/*     */   public MessageCreateMono withEmbeds(Possible<List<EmbedCreateSpec>> possible) {
/* 346 */     Possible<List<EmbedCreateSpec>> newValue = Objects.<Possible<List<EmbedCreateSpec>>>requireNonNull(possible);
/* 347 */     return new MessageCreateMono(
/* 348 */         content(), 
/* 349 */         nonce(), 
/* 350 */         tts(), newValue, this.files, this.fileSpoilers, 
/*     */ 
/*     */ 
/*     */         
/* 354 */         allowedMentions(), 
/* 355 */         messageReference(), 
/* 356 */         components(), this.channel);
/*     */   }
/*     */ 
/*     */   
/*     */   public MessageCreateMono withEmbeds(Iterable<EmbedCreateSpec> elements) {
/* 361 */     Possible<List<EmbedCreateSpec>> newValue = Possible.of(
/* 362 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/* 363 */     return new MessageCreateMono(
/* 364 */         content(), 
/* 365 */         nonce(), 
/* 366 */         tts(), newValue, this.files, this.fileSpoilers, 
/*     */ 
/*     */ 
/*     */         
/* 370 */         allowedMentions(), 
/* 371 */         messageReference(), 
/* 372 */         components(), this.channel);
/*     */   }
/*     */ 
/*     */   
/*     */   @SafeVarargs
/*     */   public final MessageCreateMono withEmbeds(EmbedCreateSpec... elements) {
/* 378 */     Possible<List<EmbedCreateSpec>> newValue = Possible.of(Arrays.asList(elements));
/* 379 */     return new MessageCreateMono(
/* 380 */         content(), 
/* 381 */         nonce(), 
/* 382 */         tts(), newValue, this.files, this.fileSpoilers, 
/*     */ 
/*     */ 
/*     */         
/* 386 */         allowedMentions(), 
/* 387 */         messageReference(), 
/* 388 */         components(), this.channel);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final MessageCreateMono withFiles(MessageCreateFields.File... elements) {
/* 398 */     List<MessageCreateFields.File> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/* 399 */     return new MessageCreateMono(
/* 400 */         content(), 
/* 401 */         nonce(), 
/* 402 */         tts(), 
/* 403 */         embeds(), newValue, this.fileSpoilers, 
/*     */ 
/*     */         
/* 406 */         allowedMentions(), 
/* 407 */         messageReference(), 
/* 408 */         components(), this.channel);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final MessageCreateMono withFiles(Iterable<? extends MessageCreateFields.File> elements) {
/* 419 */     if (this.files == elements) return this; 
/* 420 */     List<MessageCreateFields.File> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/* 421 */     return new MessageCreateMono(
/* 422 */         content(), 
/* 423 */         nonce(), 
/* 424 */         tts(), 
/* 425 */         embeds(), newValue, this.fileSpoilers, 
/*     */ 
/*     */         
/* 428 */         allowedMentions(), 
/* 429 */         messageReference(), 
/* 430 */         components(), this.channel);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final MessageCreateMono withFileSpoilers(MessageCreateFields.FileSpoiler... elements) {
/* 440 */     List<MessageCreateFields.FileSpoiler> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/* 441 */     return new MessageCreateMono(
/* 442 */         content(), 
/* 443 */         nonce(), 
/* 444 */         tts(), 
/* 445 */         embeds(), this.files, newValue, 
/*     */ 
/*     */         
/* 448 */         allowedMentions(), 
/* 449 */         messageReference(), 
/* 450 */         components(), this.channel);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final MessageCreateMono withFileSpoilers(Iterable<? extends MessageCreateFields.FileSpoiler> elements) {
/* 461 */     if (this.fileSpoilers == elements) return this; 
/* 462 */     List<MessageCreateFields.FileSpoiler> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/* 463 */     return new MessageCreateMono(
/* 464 */         content(), 
/* 465 */         nonce(), 
/* 466 */         tts(), 
/* 467 */         embeds(), this.files, newValue, 
/*     */ 
/*     */         
/* 470 */         allowedMentions(), 
/* 471 */         messageReference(), 
/* 472 */         components(), this.channel);
/*     */   }
/*     */ 
/*     */   
/*     */   public MessageCreateMono withAllowedMentions(Possible<AllowedMentions> value) {
/* 477 */     Possible<AllowedMentions> newValue = Objects.<Possible<AllowedMentions>>requireNonNull(value);
/* 478 */     return new MessageCreateMono(
/* 479 */         content(), 
/* 480 */         nonce(), 
/* 481 */         tts(), 
/* 482 */         embeds(), this.files, this.fileSpoilers, newValue, 
/*     */ 
/*     */ 
/*     */         
/* 486 */         messageReference(), 
/* 487 */         components(), this.channel);
/*     */   }
/*     */ 
/*     */   
/*     */   public MessageCreateMono withAllowedMentions(AllowedMentions value) {
/* 492 */     Possible<AllowedMentions> newValue = Possible.of(value);
/* 493 */     return new MessageCreateMono(
/* 494 */         content(), 
/* 495 */         nonce(), 
/* 496 */         tts(), 
/* 497 */         embeds(), this.files, this.fileSpoilers, newValue, 
/*     */ 
/*     */ 
/*     */         
/* 501 */         messageReference(), 
/* 502 */         components(), this.channel);
/*     */   }
/*     */ 
/*     */   
/*     */   public MessageCreateMono withMessageReference(Possible<Snowflake> value) {
/* 507 */     Possible<Snowflake> newValue = Objects.<Possible<Snowflake>>requireNonNull(value);
/* 508 */     return new MessageCreateMono(
/* 509 */         content(), 
/* 510 */         nonce(), 
/* 511 */         tts(), 
/* 512 */         embeds(), this.files, this.fileSpoilers, 
/*     */ 
/*     */         
/* 515 */         allowedMentions(), newValue, 
/*     */         
/* 517 */         components(), this.channel);
/*     */   }
/*     */ 
/*     */   
/*     */   public MessageCreateMono withMessageReference(Snowflake value) {
/* 522 */     Possible<Snowflake> newValue = Possible.of(value);
/* 523 */     return new MessageCreateMono(
/* 524 */         content(), 
/* 525 */         nonce(), 
/* 526 */         tts(), 
/* 527 */         embeds(), this.files, this.fileSpoilers, 
/*     */ 
/*     */         
/* 530 */         allowedMentions(), newValue, 
/*     */         
/* 532 */         components(), this.channel);
/*     */   }
/*     */ 
/*     */   
/*     */   public MessageCreateMono withComponents(Possible<List<LayoutComponent>> possible) {
/* 537 */     Possible<List<LayoutComponent>> newValue = Objects.<Possible<List<LayoutComponent>>>requireNonNull(possible);
/* 538 */     return new MessageCreateMono(
/* 539 */         content(), 
/* 540 */         nonce(), 
/* 541 */         tts(), 
/* 542 */         embeds(), this.files, this.fileSpoilers, 
/*     */ 
/*     */         
/* 545 */         allowedMentions(), 
/* 546 */         messageReference(), newValue, this.channel);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public MessageCreateMono withComponents(Iterable<LayoutComponent> elements) {
/* 552 */     Possible<List<LayoutComponent>> newValue = Possible.of(
/* 553 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/* 554 */     return new MessageCreateMono(
/* 555 */         content(), 
/* 556 */         nonce(), 
/* 557 */         tts(), 
/* 558 */         embeds(), this.files, this.fileSpoilers, 
/*     */ 
/*     */         
/* 561 */         allowedMentions(), 
/* 562 */         messageReference(), newValue, this.channel);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SafeVarargs
/*     */   public final MessageCreateMono withComponents(LayoutComponent... elements) {
/* 569 */     Possible<List<LayoutComponent>> newValue = Possible.of(Arrays.asList(elements));
/* 570 */     return new MessageCreateMono(
/* 571 */         content(), 
/* 572 */         nonce(), 
/* 573 */         tts(), 
/* 574 */         embeds(), this.files, this.fileSpoilers, 
/*     */ 
/*     */         
/* 577 */         allowedMentions(), 
/* 578 */         messageReference(), newValue, this.channel);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final MessageCreateMono withChannel(MessageChannel value) {
/* 590 */     if (this.channel == value) return this; 
/* 591 */     MessageChannel newValue = Objects.<MessageChannel>requireNonNull(value, "channel");
/* 592 */     return new MessageCreateMono(
/* 593 */         content(), 
/* 594 */         nonce(), 
/* 595 */         tts(), 
/* 596 */         embeds(), this.files, this.fileSpoilers, 
/*     */ 
/*     */         
/* 599 */         allowedMentions(), 
/* 600 */         messageReference(), 
/* 601 */         components(), newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 611 */     if (this == another) return true; 
/* 612 */     return (another instanceof MessageCreateMono && 
/* 613 */       equalTo(0, (MessageCreateMono)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, MessageCreateMono another) {
/* 617 */     return (content().equals(another.content()) && 
/* 618 */       nonce().equals(another.nonce()) && 
/* 619 */       tts().equals(another.tts()) && 
/* 620 */       Objects.equals(this.embeds_value, another.embeds_value) && this.files
/* 621 */       .equals(another.files) && this.fileSpoilers
/* 622 */       .equals(another.fileSpoilers) && 
/* 623 */       allowedMentions().equals(another.allowedMentions()) && 
/* 624 */       messageReference().equals(another.messageReference()) && 
/* 625 */       Objects.equals(this.components_value, another.components_value) && this.channel
/* 626 */       .equals(another.channel));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 635 */     int h = 5381;
/* 636 */     h += (h << 5) + content().hashCode();
/* 637 */     h += (h << 5) + nonce().hashCode();
/* 638 */     h += (h << 5) + tts().hashCode();
/* 639 */     h += (h << 5) + Objects.hashCode(this.embeds_value);
/* 640 */     h += (h << 5) + this.files.hashCode();
/* 641 */     h += (h << 5) + this.fileSpoilers.hashCode();
/* 642 */     h += (h << 5) + allowedMentions().hashCode();
/* 643 */     h += (h << 5) + messageReference().hashCode();
/* 644 */     h += (h << 5) + Objects.hashCode(this.components_value);
/* 645 */     h += (h << 5) + this.channel.hashCode();
/* 646 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 655 */     return "MessageCreateMono{content=" + 
/* 656 */       content().toString() + ", nonce=" + 
/* 657 */       nonce().toString() + ", tts=" + 
/* 658 */       tts().toString() + ", embeds=" + 
/* 659 */       Objects.toString(this.embeds_value) + ", files=" + this.files + ", fileSpoilers=" + this.fileSpoilers + ", allowedMentions=" + 
/*     */ 
/*     */       
/* 662 */       allowedMentions().toString() + ", messageReference=" + 
/* 663 */       messageReference().toString() + ", components=" + 
/* 664 */       Objects.toString(this.components_value) + ", channel=" + this.channel + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MessageCreateMono of(MessageChannel channel) {
/* 675 */     return new MessageCreateMono(channel);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static MessageCreateMono copyOf(MessageCreateMonoGenerator instance) {
/* 686 */     if (instance instanceof MessageCreateMono) {
/* 687 */       return (MessageCreateMono)instance;
/*     */     }
/* 689 */     return of(instance.channel())
/* 690 */       .withContent(instance.content())
/* 691 */       .withNonce(instance.nonce())
/* 692 */       .withTts(instance.tts())
/* 693 */       .withEmbeds(instance.embeds())
/* 694 */       .withFiles(instance.files())
/* 695 */       .withFileSpoilers(instance.fileSpoilers())
/* 696 */       .withAllowedMentions(instance.allowedMentions())
/* 697 */       .withMessageReference(instance.messageReference())
/* 698 */       .withComponents(instance.components());
/*     */   }
/*     */   
/*     */   public boolean isContentPresent() {
/* 702 */     return !this.content_absent;
/*     */   }
/*     */   
/*     */   public String contentOrElse(String defaultValue) {
/* 706 */     return !this.content_absent ? this.content_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isNoncePresent() {
/* 710 */     return !this.nonce_absent;
/*     */   }
/*     */   
/*     */   public String nonceOrElse(String defaultValue) {
/* 714 */     return !this.nonce_absent ? this.nonce_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isTtsPresent() {
/* 718 */     return !this.tts_absent;
/*     */   }
/*     */   
/*     */   public Boolean ttsOrElse(Boolean defaultValue) {
/* 722 */     return !this.tts_absent ? this.tts_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isEmbedsPresent() {
/* 726 */     return !this.embeds_absent;
/*     */   }
/*     */   
/*     */   public List<EmbedCreateSpec> embedsOrElse(List<EmbedCreateSpec> defaultValue) {
/* 730 */     return !this.embeds_absent ? this.embeds_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isAllowedMentionsPresent() {
/* 734 */     return !this.allowedMentions_absent;
/*     */   }
/*     */   
/*     */   public AllowedMentions allowedMentionsOrElse(AllowedMentions defaultValue) {
/* 738 */     return !this.allowedMentions_absent ? this.allowedMentions_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isMessageReferencePresent() {
/* 742 */     return !this.messageReference_absent;
/*     */   }
/*     */   
/*     */   public Snowflake messageReferenceOrElse(Snowflake defaultValue) {
/* 746 */     return !this.messageReference_absent ? this.messageReference_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isComponentsPresent() {
/* 750 */     return !this.components_absent;
/*     */   }
/*     */   
/*     */   public List<LayoutComponent> componentsOrElse(List<LayoutComponent> defaultValue) {
/* 754 */     return !this.components_absent ? this.components_value : defaultValue;
/*     */   }
/*     */   
/*     */   private static <T> List<T> createSafeList(Iterable<? extends T> iterable, boolean checkNulls, boolean skipNulls) {
/*     */     ArrayList<T> list;
/* 759 */     if (iterable instanceof Collection) {
/* 760 */       int size = ((Collection)iterable).size();
/* 761 */       if (size == 0) return Collections.emptyList(); 
/* 762 */       list = new ArrayList<>();
/*     */     } else {
/* 764 */       list = new ArrayList<>();
/*     */     } 
/* 766 */     for (T element : iterable) {
/* 767 */       if (skipNulls && element == null)
/* 768 */         continue;  if (checkNulls) Objects.requireNonNull(element, "element"); 
/* 769 */       list.add(element);
/*     */     } 
/* 771 */     return list;
/*     */   }
/*     */   
/*     */   private static <T> List<T> createUnmodifiableList(boolean clone, List<T> list) {
/* 775 */     switch (list.size()) { case 0:
/* 776 */         return Collections.emptyList();
/* 777 */       case 1: return Collections.singletonList(list.get(0)); }
/*     */     
/* 779 */     if (clone) {
/* 780 */       return Collections.unmodifiableList(new ArrayList<>(list));
/*     */     }
/* 782 */     if (list instanceof ArrayList) {
/* 783 */       ((ArrayList)list).trimToSize();
/*     */     }
/* 785 */     return Collections.unmodifiableList(list);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\MessageCreateMono.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */