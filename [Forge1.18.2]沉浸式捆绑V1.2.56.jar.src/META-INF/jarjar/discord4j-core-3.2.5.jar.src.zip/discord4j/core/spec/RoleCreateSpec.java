/*     */ package discord4j.core.spec;
/*     */ 
/*     */ import com.google.errorprone.annotations.CanIgnoreReturnValue;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import discord4j.rest.util.Color;
/*     */ import discord4j.rest.util.PermissionSet;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import org.immutables.value.Generated;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "RoleCreateSpecGenerator", generator = "Immutables")
/*     */ public final class RoleCreateSpec
/*     */   implements RoleCreateSpecGenerator
/*     */ {
/*     */   @Nullable
/*     */   private final String reason;
/*     */   private final String name_value;
/*     */   private final boolean name_absent;
/*     */   private final PermissionSet permissions_value;
/*     */   private final boolean permissions_absent;
/*     */   private final Color color_value;
/*     */   private final boolean color_absent;
/*     */   private final Boolean hoist_value;
/*     */   private final boolean hoist_absent;
/*     */   private final Boolean mentionable_value;
/*     */   private final boolean mentionable_absent;
/*     */   private final String icon_value;
/*     */   private final boolean icon_absent;
/*     */   private final String unicodeEmoji_value;
/*     */   private final boolean unicodeEmoji_absent;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   
/*     */   private RoleCreateSpec() {
/*  44 */     this.reason = null;
/*  45 */     Possible<String> name$impl = Possible.absent();
/*  46 */     Possible<PermissionSet> permissions$impl = Possible.absent();
/*  47 */     Possible<Color> color$impl = Possible.absent();
/*  48 */     Possible<Boolean> hoist$impl = Possible.absent();
/*  49 */     Possible<Boolean> mentionable$impl = Possible.absent();
/*  50 */     Possible<Optional<String>> icon$impl = Possible.absent();
/*  51 */     Possible<Optional<String>> unicodeEmoji$impl = Possible.absent();
/*  52 */     this.name_value = name$impl.toOptional().orElse(null);
/*  53 */     this.name_absent = name$impl.isAbsent();
/*  54 */     this.permissions_value = permissions$impl.toOptional().orElse(null);
/*  55 */     this.permissions_absent = permissions$impl.isAbsent();
/*  56 */     this.color_value = color$impl.toOptional().orElse(null);
/*  57 */     this.color_absent = color$impl.isAbsent();
/*  58 */     this.hoist_value = hoist$impl.toOptional().orElse(null);
/*  59 */     this.hoist_absent = hoist$impl.isAbsent();
/*  60 */     this.mentionable_value = mentionable$impl.toOptional().orElse(null);
/*  61 */     this.mentionable_absent = mentionable$impl.isAbsent();
/*  62 */     this.icon_value = Possible.flatOpt(icon$impl).orElse(null);
/*  63 */     this.icon_absent = icon$impl.isAbsent();
/*  64 */     this.unicodeEmoji_value = Possible.flatOpt(unicodeEmoji$impl).orElse(null);
/*  65 */     this.unicodeEmoji_absent = unicodeEmoji$impl.isAbsent();
/*  66 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private RoleCreateSpec(@Nullable String reason, Possible<String> name, Possible<PermissionSet> permissions, Possible<Color> color, Possible<Boolean> hoist, Possible<Boolean> mentionable, Possible<Optional<String>> icon, Possible<Optional<String>> unicodeEmoji) {
/*  78 */     this.reason = reason;
/*  79 */     Possible<String> name$impl = name;
/*  80 */     Possible<PermissionSet> permissions$impl = permissions;
/*  81 */     Possible<Color> color$impl = color;
/*  82 */     Possible<Boolean> hoist$impl = hoist;
/*  83 */     Possible<Boolean> mentionable$impl = mentionable;
/*  84 */     Possible<Optional<String>> icon$impl = icon;
/*  85 */     Possible<Optional<String>> unicodeEmoji$impl = unicodeEmoji;
/*  86 */     this.name_value = name$impl.toOptional().orElse(null);
/*  87 */     this.name_absent = name$impl.isAbsent();
/*  88 */     this.permissions_value = permissions$impl.toOptional().orElse(null);
/*  89 */     this.permissions_absent = permissions$impl.isAbsent();
/*  90 */     this.color_value = color$impl.toOptional().orElse(null);
/*  91 */     this.color_absent = color$impl.isAbsent();
/*  92 */     this.hoist_value = hoist$impl.toOptional().orElse(null);
/*  93 */     this.hoist_absent = hoist$impl.isAbsent();
/*  94 */     this.mentionable_value = mentionable$impl.toOptional().orElse(null);
/*  95 */     this.mentionable_absent = mentionable$impl.isAbsent();
/*  96 */     this.icon_value = Possible.flatOpt(icon$impl).orElse(null);
/*  97 */     this.icon_absent = icon$impl.isAbsent();
/*  98 */     this.unicodeEmoji_value = Possible.flatOpt(unicodeEmoji$impl).orElse(null);
/*  99 */     this.unicodeEmoji_absent = unicodeEmoji$impl.isAbsent();
/* 100 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 106 */   private volatile transient InitShim initShim = new InitShim();
/*     */   
/*     */   @Generated(from = "RoleCreateSpecGenerator", generator = "Immutables")
/*     */   private final class InitShim
/*     */   {
/*     */     private String formatInitCycleMessage() {
/* 112 */       List<String> attributes = new ArrayList<>();
/* 113 */       return "Cannot build RoleCreateSpec, attribute initializers form cycle " + attributes;
/*     */     }
/*     */ 
/*     */     
/*     */     private InitShim() {}
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String reason() {
/* 123 */     return this.reason;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<String> name() {
/* 131 */     return this.name_absent ? Possible.absent() : Possible.of(this.name_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<PermissionSet> permissions() {
/* 139 */     return this.permissions_absent ? Possible.absent() : Possible.of(this.permissions_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Color> color() {
/* 147 */     return this.color_absent ? Possible.absent() : Possible.of(this.color_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Boolean> hoist() {
/* 155 */     return this.hoist_absent ? Possible.absent() : Possible.of(this.hoist_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Boolean> mentionable() {
/* 163 */     return this.mentionable_absent ? Possible.absent() : Possible.of(this.mentionable_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Optional<String>> icon() {
/* 171 */     return this.icon_absent ? Possible.absent() : 
/* 172 */       Possible.of(Optional.ofNullable(this.icon_value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Optional<String>> unicodeEmoji() {
/* 180 */     return this.unicodeEmoji_absent ? Possible.absent() : 
/* 181 */       Possible.of(Optional.ofNullable(this.unicodeEmoji_value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final RoleCreateSpec withReason(@Nullable String value) {
/* 191 */     if (Objects.equals(this.reason, value)) return this; 
/* 192 */     return validate(new RoleCreateSpec(value, 
/*     */           
/* 194 */           name(), 
/* 195 */           permissions(), 
/* 196 */           color(), 
/* 197 */           hoist(), 
/* 198 */           mentionable(), 
/* 199 */           icon(), 
/* 200 */           unicodeEmoji()));
/*     */   }
/*     */   
/*     */   public RoleCreateSpec withName(Possible<String> value) {
/* 204 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/* 205 */     return validate(new RoleCreateSpec(this.reason, newValue, 
/*     */ 
/*     */           
/* 208 */           permissions(), 
/* 209 */           color(), 
/* 210 */           hoist(), 
/* 211 */           mentionable(), 
/* 212 */           icon(), 
/* 213 */           unicodeEmoji()));
/*     */   }
/*     */   
/*     */   public RoleCreateSpec withName(String value) {
/* 217 */     Possible<String> newValue = Possible.of(value);
/* 218 */     return validate(new RoleCreateSpec(this.reason, newValue, 
/*     */ 
/*     */           
/* 221 */           permissions(), 
/* 222 */           color(), 
/* 223 */           hoist(), 
/* 224 */           mentionable(), 
/* 225 */           icon(), 
/* 226 */           unicodeEmoji()));
/*     */   }
/*     */   
/*     */   public RoleCreateSpec withPermissions(Possible<PermissionSet> value) {
/* 230 */     Possible<PermissionSet> newValue = Objects.<Possible<PermissionSet>>requireNonNull(value);
/* 231 */     return validate(new RoleCreateSpec(this.reason, 
/*     */           
/* 233 */           name(), newValue, 
/*     */           
/* 235 */           color(), 
/* 236 */           hoist(), 
/* 237 */           mentionable(), 
/* 238 */           icon(), 
/* 239 */           unicodeEmoji()));
/*     */   }
/*     */   
/*     */   public RoleCreateSpec withPermissions(PermissionSet value) {
/* 243 */     Possible<PermissionSet> newValue = Possible.of(value);
/* 244 */     return validate(new RoleCreateSpec(this.reason, 
/*     */           
/* 246 */           name(), newValue, 
/*     */           
/* 248 */           color(), 
/* 249 */           hoist(), 
/* 250 */           mentionable(), 
/* 251 */           icon(), 
/* 252 */           unicodeEmoji()));
/*     */   }
/*     */   
/*     */   public RoleCreateSpec withColor(Possible<Color> value) {
/* 256 */     Possible<Color> newValue = Objects.<Possible<Color>>requireNonNull(value);
/* 257 */     return validate(new RoleCreateSpec(this.reason, 
/*     */           
/* 259 */           name(), 
/* 260 */           permissions(), newValue, 
/*     */           
/* 262 */           hoist(), 
/* 263 */           mentionable(), 
/* 264 */           icon(), 
/* 265 */           unicodeEmoji()));
/*     */   }
/*     */   
/*     */   public RoleCreateSpec withColor(Color value) {
/* 269 */     Possible<Color> newValue = Possible.of(value);
/* 270 */     return validate(new RoleCreateSpec(this.reason, 
/*     */           
/* 272 */           name(), 
/* 273 */           permissions(), newValue, 
/*     */           
/* 275 */           hoist(), 
/* 276 */           mentionable(), 
/* 277 */           icon(), 
/* 278 */           unicodeEmoji()));
/*     */   }
/*     */   
/*     */   public RoleCreateSpec withHoist(Possible<Boolean> value) {
/* 282 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/* 283 */     return validate(new RoleCreateSpec(this.reason, 
/*     */           
/* 285 */           name(), 
/* 286 */           permissions(), 
/* 287 */           color(), newValue, 
/*     */           
/* 289 */           mentionable(), 
/* 290 */           icon(), 
/* 291 */           unicodeEmoji()));
/*     */   }
/*     */   
/*     */   public RoleCreateSpec withHoist(Boolean value) {
/* 295 */     Possible<Boolean> newValue = Possible.of(value);
/* 296 */     return validate(new RoleCreateSpec(this.reason, 
/*     */           
/* 298 */           name(), 
/* 299 */           permissions(), 
/* 300 */           color(), newValue, 
/*     */           
/* 302 */           mentionable(), 
/* 303 */           icon(), 
/* 304 */           unicodeEmoji()));
/*     */   }
/*     */   
/*     */   public RoleCreateSpec withMentionable(Possible<Boolean> value) {
/* 308 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/* 309 */     return validate(new RoleCreateSpec(this.reason, 
/*     */           
/* 311 */           name(), 
/* 312 */           permissions(), 
/* 313 */           color(), 
/* 314 */           hoist(), newValue, 
/*     */           
/* 316 */           icon(), 
/* 317 */           unicodeEmoji()));
/*     */   }
/*     */   
/*     */   public RoleCreateSpec withMentionable(Boolean value) {
/* 321 */     Possible<Boolean> newValue = Possible.of(value);
/* 322 */     return validate(new RoleCreateSpec(this.reason, 
/*     */           
/* 324 */           name(), 
/* 325 */           permissions(), 
/* 326 */           color(), 
/* 327 */           hoist(), newValue, 
/*     */           
/* 329 */           icon(), 
/* 330 */           unicodeEmoji()));
/*     */   }
/*     */   
/*     */   public RoleCreateSpec withIcon(Possible<Optional<String>> value) {
/* 334 */     Possible<Optional<String>> newValue = Objects.<Possible<Optional<String>>>requireNonNull(value);
/* 335 */     return validate(new RoleCreateSpec(this.reason, 
/*     */           
/* 337 */           name(), 
/* 338 */           permissions(), 
/* 339 */           color(), 
/* 340 */           hoist(), 
/* 341 */           mentionable(), newValue, 
/*     */           
/* 343 */           unicodeEmoji()));
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public RoleCreateSpec withIcon(@Nullable String value) {
/* 348 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/* 349 */     return validate(new RoleCreateSpec(this.reason, 
/*     */           
/* 351 */           name(), 
/* 352 */           permissions(), 
/* 353 */           color(), 
/* 354 */           hoist(), 
/* 355 */           mentionable(), newValue, 
/*     */           
/* 357 */           unicodeEmoji()));
/*     */   }
/*     */   
/*     */   public RoleCreateSpec withIconOrNull(@Nullable String value) {
/* 361 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/* 362 */     return validate(new RoleCreateSpec(this.reason, 
/*     */           
/* 364 */           name(), 
/* 365 */           permissions(), 
/* 366 */           color(), 
/* 367 */           hoist(), 
/* 368 */           mentionable(), newValue, 
/*     */           
/* 370 */           unicodeEmoji()));
/*     */   }
/*     */   
/*     */   public RoleCreateSpec withUnicodeEmoji(Possible<Optional<String>> value) {
/* 374 */     Possible<Optional<String>> newValue = Objects.<Possible<Optional<String>>>requireNonNull(value);
/* 375 */     return validate(new RoleCreateSpec(this.reason, 
/*     */           
/* 377 */           name(), 
/* 378 */           permissions(), 
/* 379 */           color(), 
/* 380 */           hoist(), 
/* 381 */           mentionable(), 
/* 382 */           icon(), newValue));
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public RoleCreateSpec withUnicodeEmoji(@Nullable String value) {
/* 388 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/* 389 */     return validate(new RoleCreateSpec(this.reason, 
/*     */           
/* 391 */           name(), 
/* 392 */           permissions(), 
/* 393 */           color(), 
/* 394 */           hoist(), 
/* 395 */           mentionable(), 
/* 396 */           icon(), newValue));
/*     */   }
/*     */ 
/*     */   
/*     */   public RoleCreateSpec withUnicodeEmojiOrNull(@Nullable String value) {
/* 401 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/* 402 */     return validate(new RoleCreateSpec(this.reason, 
/*     */           
/* 404 */           name(), 
/* 405 */           permissions(), 
/* 406 */           color(), 
/* 407 */           hoist(), 
/* 408 */           mentionable(), 
/* 409 */           icon(), newValue));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 419 */     if (this == another) return true; 
/* 420 */     return (another instanceof RoleCreateSpec && 
/* 421 */       equalTo(0, (RoleCreateSpec)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, RoleCreateSpec another) {
/* 425 */     return (Objects.equals(this.reason, another.reason) && 
/* 426 */       name().equals(another.name()) && 
/* 427 */       permissions().equals(another.permissions()) && 
/* 428 */       color().equals(another.color()) && 
/* 429 */       hoist().equals(another.hoist()) && 
/* 430 */       mentionable().equals(another.mentionable()) && 
/* 431 */       icon().equals(another.icon()) && 
/* 432 */       unicodeEmoji().equals(another.unicodeEmoji()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 441 */     int h = 5381;
/* 442 */     h += (h << 5) + Objects.hashCode(this.reason);
/* 443 */     h += (h << 5) + name().hashCode();
/* 444 */     h += (h << 5) + permissions().hashCode();
/* 445 */     h += (h << 5) + color().hashCode();
/* 446 */     h += (h << 5) + hoist().hashCode();
/* 447 */     h += (h << 5) + mentionable().hashCode();
/* 448 */     h += (h << 5) + icon().hashCode();
/* 449 */     h += (h << 5) + unicodeEmoji().hashCode();
/* 450 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 459 */     return "RoleCreateSpec{reason=" + this.reason + ", name=" + 
/*     */       
/* 461 */       name().toString() + ", permissions=" + 
/* 462 */       permissions().toString() + ", color=" + 
/* 463 */       color().toString() + ", hoist=" + 
/* 464 */       hoist().toString() + ", mentionable=" + 
/* 465 */       mentionable().toString() + ", icon=" + 
/* 466 */       icon().toString() + ", unicodeEmoji=" + 
/* 467 */       unicodeEmoji().toString() + "}";
/*     */   }
/*     */ 
/*     */   
/* 471 */   private static final RoleCreateSpec INSTANCE = validate(new RoleCreateSpec());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static RoleCreateSpec create() {
/* 478 */     return INSTANCE;
/*     */   }
/*     */   
/*     */   private static RoleCreateSpec validate(RoleCreateSpec instance) {
/* 482 */     return (INSTANCE != null && INSTANCE.equalTo(0, instance)) ? INSTANCE : instance;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static RoleCreateSpec copyOf(RoleCreateSpecGenerator instance) {
/* 493 */     if (instance instanceof RoleCreateSpec) {
/* 494 */       return (RoleCreateSpec)instance;
/*     */     }
/* 496 */     return builder()
/* 497 */       .from(instance)
/* 498 */       .build();
/*     */   }
/*     */   
/*     */   public boolean isNamePresent() {
/* 502 */     return !this.name_absent;
/*     */   }
/*     */   
/*     */   public String nameOrElse(String defaultValue) {
/* 506 */     return !this.name_absent ? this.name_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isPermissionsPresent() {
/* 510 */     return !this.permissions_absent;
/*     */   }
/*     */   
/*     */   public PermissionSet permissionsOrElse(PermissionSet defaultValue) {
/* 514 */     return !this.permissions_absent ? this.permissions_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isColorPresent() {
/* 518 */     return !this.color_absent;
/*     */   }
/*     */   
/*     */   public Color colorOrElse(Color defaultValue) {
/* 522 */     return !this.color_absent ? this.color_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isHoistPresent() {
/* 526 */     return !this.hoist_absent;
/*     */   }
/*     */   
/*     */   public Boolean hoistOrElse(Boolean defaultValue) {
/* 530 */     return !this.hoist_absent ? this.hoist_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isMentionablePresent() {
/* 534 */     return !this.mentionable_absent;
/*     */   }
/*     */   
/*     */   public Boolean mentionableOrElse(Boolean defaultValue) {
/* 538 */     return !this.mentionable_absent ? this.mentionable_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isIconPresent() {
/* 542 */     return !this.icon_absent;
/*     */   }
/*     */   
/*     */   public String iconOrElse(String defaultValue) {
/* 546 */     return !this.icon_absent ? this.icon_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isUnicodeEmojiPresent() {
/* 550 */     return !this.unicodeEmoji_absent;
/*     */   }
/*     */   
/*     */   public String unicodeEmojiOrElse(String defaultValue) {
/* 554 */     return !this.unicodeEmoji_absent ? this.unicodeEmoji_value : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 574 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "RoleCreateSpecGenerator", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/* 586 */     private Possible<String> name_possible = Possible.absent();
/* 587 */     private Possible<PermissionSet> permissions_possible = Possible.absent();
/* 588 */     private Possible<Color> color_possible = Possible.absent();
/* 589 */     private Possible<Boolean> hoist_possible = Possible.absent();
/* 590 */     private Possible<Boolean> mentionable_possible = Possible.absent();
/* 591 */     private Possible<Optional<String>> icon_possible = Possible.absent();
/* 592 */     private Possible<Optional<String>> unicodeEmoji_possible = Possible.absent();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private String reason;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(RoleCreateSpec instance) {
/* 606 */       return from(instance);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     final Builder from(RoleCreateSpecGenerator instance) {
/* 616 */       Objects.requireNonNull(instance, "instance");
/* 617 */       String reasonValue = instance.reason();
/* 618 */       if (reasonValue != null) {
/* 619 */         reason(reasonValue);
/*     */       }
/* 621 */       name(instance.name());
/* 622 */       permissions(instance.permissions());
/* 623 */       color(instance.color());
/* 624 */       hoist(instance.hoist());
/* 625 */       mentionable(instance.mentionable());
/* 626 */       icon(instance.icon());
/* 627 */       unicodeEmoji(instance.unicodeEmoji());
/* 628 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder reason(@Nullable String reason) {
/* 638 */       this.reason = reason;
/* 639 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder name(Possible<String> value) {
/* 644 */       this.name_possible = value;
/* 645 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder name(String value) {
/* 650 */       this.name_possible = Possible.of(value);
/* 651 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder permissions(Possible<PermissionSet> value) {
/* 656 */       this.permissions_possible = value;
/* 657 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder permissions(PermissionSet value) {
/* 662 */       this.permissions_possible = Possible.of(value);
/* 663 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder color(Possible<Color> value) {
/* 668 */       this.color_possible = value;
/* 669 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder color(Color value) {
/* 674 */       this.color_possible = Possible.of(value);
/* 675 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder hoist(Possible<Boolean> value) {
/* 680 */       this.hoist_possible = value;
/* 681 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder hoist(Boolean value) {
/* 686 */       this.hoist_possible = Possible.of(value);
/* 687 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder mentionable(Possible<Boolean> value) {
/* 692 */       this.mentionable_possible = value;
/* 693 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder mentionable(Boolean value) {
/* 698 */       this.mentionable_possible = Possible.of(value);
/* 699 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder icon(Possible<Optional<String>> value) {
/* 704 */       this.icon_possible = value;
/* 705 */       return this;
/*     */     }
/*     */     
/*     */     @Deprecated
/*     */     @CanIgnoreReturnValue
/*     */     public Builder icon(@Nullable String value) {
/* 711 */       this.icon_possible = Possible.of(Optional.ofNullable(value));
/* 712 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder iconOrNull(@Nullable String value) {
/* 717 */       this.icon_possible = Possible.of(Optional.ofNullable(value));
/* 718 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder unicodeEmoji(Possible<Optional<String>> value) {
/* 723 */       this.unicodeEmoji_possible = value;
/* 724 */       return this;
/*     */     }
/*     */     
/*     */     @Deprecated
/*     */     @CanIgnoreReturnValue
/*     */     public Builder unicodeEmoji(@Nullable String value) {
/* 730 */       this.unicodeEmoji_possible = Possible.of(Optional.ofNullable(value));
/* 731 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder unicodeEmojiOrNull(@Nullable String value) {
/* 736 */       this.unicodeEmoji_possible = Possible.of(Optional.ofNullable(value));
/* 737 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public RoleCreateSpec build() {
/* 746 */       return RoleCreateSpec.validate(new RoleCreateSpec(this.reason, 
/*     */             
/* 748 */             name_build(), 
/* 749 */             permissions_build(), 
/* 750 */             color_build(), 
/* 751 */             hoist_build(), 
/* 752 */             mentionable_build(), 
/* 753 */             icon_build(), 
/* 754 */             unicodeEmoji_build()));
/*     */     }
/*     */     
/*     */     private Possible<String> name_build() {
/* 758 */       return this.name_possible;
/*     */     }
/*     */     
/*     */     private Possible<PermissionSet> permissions_build() {
/* 762 */       return this.permissions_possible;
/*     */     }
/*     */     
/*     */     private Possible<Color> color_build() {
/* 766 */       return this.color_possible;
/*     */     }
/*     */     
/*     */     private Possible<Boolean> hoist_build() {
/* 770 */       return this.hoist_possible;
/*     */     }
/*     */     
/*     */     private Possible<Boolean> mentionable_build() {
/* 774 */       return this.mentionable_possible;
/*     */     }
/*     */     
/*     */     private Possible<Optional<String>> icon_build() {
/* 778 */       return this.icon_possible;
/*     */     }
/*     */     
/*     */     private Possible<Optional<String>> unicodeEmoji_build() {
/* 782 */       return this.unicodeEmoji_possible;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\RoleCreateSpec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */