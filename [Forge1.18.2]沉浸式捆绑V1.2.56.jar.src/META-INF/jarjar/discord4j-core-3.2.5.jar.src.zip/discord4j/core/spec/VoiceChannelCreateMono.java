/*     */ package discord4j.core.spec;
/*     */ 
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.object.PermissionOverwrite;
/*     */ import discord4j.core.object.entity.Guild;
/*     */ import discord4j.core.object.entity.channel.VoiceChannel;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.stream.StreamSupport;
/*     */ import org.immutables.value.Generated;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "VoiceChannelCreateMonoGenerator", generator = "Immutables")
/*     */ public final class VoiceChannelCreateMono
/*     */   extends VoiceChannelCreateMonoGenerator
/*     */ {
/*     */   @Nullable
/*     */   private final String reason;
/*     */   private final String name;
/*     */   private final Integer bitrate_value;
/*     */   private final boolean bitrate_absent;
/*     */   private final Integer userLimit_value;
/*     */   private final boolean userLimit_absent;
/*     */   private final Integer position_value;
/*     */   private final boolean position_absent;
/*     */   private final Integer rateLimitPerUser_value;
/*     */   private final boolean rateLimitPerUser_absent;
/*     */   private final List<PermissionOverwrite> permissionOverwrites_value;
/*     */   private final boolean permissionOverwrites_absent;
/*     */   private final Snowflake parentId_value;
/*     */   private final boolean parentId_absent;
/*     */   private final Guild guild;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   private volatile transient InitShim initShim;
/*     */   
/*     */   private VoiceChannelCreateMono(String name, Guild guild) {
/* 105 */     this.initShim = new InitShim(); this.name = Objects.<String>requireNonNull(name, "name"); this.guild = Objects.<Guild>requireNonNull(guild, "guild"); this.reason = null; Possible<Integer> bitrate$impl = Possible.absent(); Possible<Integer> userLimit$impl = Possible.absent(); Possible<Integer> position$impl = Possible.absent(); Possible<Integer> rateLimitPerUser$impl = Possible.absent(); Possible<List<PermissionOverwrite>> permissionOverwrites$impl = Possible.absent(); Possible<Snowflake> parentId$impl = Possible.absent(); this.bitrate_value = bitrate$impl.toOptional().orElse(null); this.bitrate_absent = bitrate$impl.isAbsent(); this.userLimit_value = userLimit$impl.toOptional().orElse(null); this.userLimit_absent = userLimit$impl.isAbsent(); this.position_value = position$impl.toOptional().orElse(null); this.position_absent = position$impl.isAbsent(); this.rateLimitPerUser_value = rateLimitPerUser$impl.toOptional().orElse(null); this.rateLimitPerUser_absent = rateLimitPerUser$impl.isAbsent(); this.permissionOverwrites_value = permissionOverwrites$impl.toOptional().orElse(null); this.permissionOverwrites_absent = permissionOverwrites$impl.isAbsent(); this.parentId_value = parentId$impl.toOptional().orElse(null); this.parentId_absent = parentId$impl.isAbsent(); this.initShim = null; } private VoiceChannelCreateMono(@Nullable String reason, String name, Possible<Integer> bitrate, Possible<Integer> userLimit, Possible<Integer> position, Possible<Integer> rateLimitPerUser, Possible<List<PermissionOverwrite>> permissionOverwrites, Possible<Snowflake> parentId, Guild guild) { this.initShim = new InitShim(); this.reason = reason; this.name = name; Possible<Integer> bitrate$impl = bitrate; Possible<Integer> userLimit$impl = userLimit; Possible<Integer> position$impl = position; Possible<Integer> rateLimitPerUser$impl = rateLimitPerUser; Possible<List<PermissionOverwrite>> permissionOverwrites$impl = permissionOverwrites; Possible<Snowflake> parentId$impl = parentId; this.guild = guild; this.bitrate_value = bitrate$impl.toOptional().orElse(null); this.bitrate_absent = bitrate$impl.isAbsent(); this.userLimit_value = userLimit$impl.toOptional().orElse(null); this.userLimit_absent = userLimit$impl.isAbsent(); this.position_value = position$impl.toOptional().orElse(null); this.position_absent = position$impl.isAbsent(); this.rateLimitPerUser_value = rateLimitPerUser$impl.toOptional().orElse(null);
/*     */     this.rateLimitPerUser_absent = rateLimitPerUser$impl.isAbsent();
/*     */     this.permissionOverwrites_value = permissionOverwrites$impl.toOptional().orElse(null);
/*     */     this.permissionOverwrites_absent = permissionOverwrites$impl.isAbsent();
/*     */     this.parentId_value = parentId$impl.toOptional().orElse(null);
/*     */     this.parentId_absent = parentId$impl.isAbsent();
/* 111 */     this.initShim = null; } @Generated(from = "VoiceChannelCreateMonoGenerator", generator = "Immutables") private final class InitShim { private InitShim() {} private String formatInitCycleMessage() { List<String> attributes = new ArrayList<>();
/* 112 */       return "Cannot build VoiceChannelCreateMono, attribute initializers form cycle " + attributes; }
/*     */      }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String reason() {
/* 122 */     return this.reason;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String name() {
/* 130 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Integer> bitrate() {
/* 138 */     return this.bitrate_absent ? Possible.absent() : Possible.of(this.bitrate_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Integer> userLimit() {
/* 146 */     return this.userLimit_absent ? Possible.absent() : Possible.of(this.userLimit_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Integer> position() {
/* 154 */     return this.position_absent ? Possible.absent() : Possible.of(this.position_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Integer> rateLimitPerUser() {
/* 162 */     return this.rateLimitPerUser_absent ? Possible.absent() : Possible.of(this.rateLimitPerUser_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<List<PermissionOverwrite>> permissionOverwrites() {
/* 170 */     return this.permissionOverwrites_absent ? Possible.absent() : 
/* 171 */       Possible.of(this.permissionOverwrites_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Snowflake> parentId() {
/* 179 */     return this.parentId_absent ? Possible.absent() : Possible.of(this.parentId_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Guild guild() {
/* 187 */     return this.guild;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final VoiceChannelCreateMono withReason(@Nullable String value) {
/* 197 */     if (Objects.equals(this.reason, value)) return this; 
/* 198 */     return new VoiceChannelCreateMono(value, this.name, 
/*     */ 
/*     */         
/* 201 */         bitrate(), 
/* 202 */         userLimit(), 
/* 203 */         position(), 
/* 204 */         rateLimitPerUser(), 
/* 205 */         permissionOverwrites(), 
/* 206 */         parentId(), this.guild);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final VoiceChannelCreateMono withName(String value) {
/* 217 */     String newValue = Objects.<String>requireNonNull(value, "name");
/* 218 */     if (this.name.equals(newValue)) return this; 
/* 219 */     return new VoiceChannelCreateMono(this.reason, newValue, 
/*     */ 
/*     */         
/* 222 */         bitrate(), 
/* 223 */         userLimit(), 
/* 224 */         position(), 
/* 225 */         rateLimitPerUser(), 
/* 226 */         permissionOverwrites(), 
/* 227 */         parentId(), this.guild);
/*     */   }
/*     */ 
/*     */   
/*     */   public VoiceChannelCreateMono withBitrate(Possible<Integer> value) {
/* 232 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/* 233 */     return new VoiceChannelCreateMono(this.reason, this.name, newValue, 
/*     */ 
/*     */ 
/*     */         
/* 237 */         userLimit(), 
/* 238 */         position(), 
/* 239 */         rateLimitPerUser(), 
/* 240 */         permissionOverwrites(), 
/* 241 */         parentId(), this.guild);
/*     */   }
/*     */ 
/*     */   
/*     */   public VoiceChannelCreateMono withBitrate(Integer value) {
/* 246 */     Possible<Integer> newValue = Possible.of(value);
/* 247 */     return new VoiceChannelCreateMono(this.reason, this.name, newValue, 
/*     */ 
/*     */ 
/*     */         
/* 251 */         userLimit(), 
/* 252 */         position(), 
/* 253 */         rateLimitPerUser(), 
/* 254 */         permissionOverwrites(), 
/* 255 */         parentId(), this.guild);
/*     */   }
/*     */ 
/*     */   
/*     */   public VoiceChannelCreateMono withUserLimit(Possible<Integer> value) {
/* 260 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/* 261 */     return new VoiceChannelCreateMono(this.reason, this.name, 
/*     */ 
/*     */         
/* 264 */         bitrate(), newValue, 
/*     */         
/* 266 */         position(), 
/* 267 */         rateLimitPerUser(), 
/* 268 */         permissionOverwrites(), 
/* 269 */         parentId(), this.guild);
/*     */   }
/*     */ 
/*     */   
/*     */   public VoiceChannelCreateMono withUserLimit(Integer value) {
/* 274 */     Possible<Integer> newValue = Possible.of(value);
/* 275 */     return new VoiceChannelCreateMono(this.reason, this.name, 
/*     */ 
/*     */         
/* 278 */         bitrate(), newValue, 
/*     */         
/* 280 */         position(), 
/* 281 */         rateLimitPerUser(), 
/* 282 */         permissionOverwrites(), 
/* 283 */         parentId(), this.guild);
/*     */   }
/*     */ 
/*     */   
/*     */   public VoiceChannelCreateMono withPosition(Possible<Integer> value) {
/* 288 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/* 289 */     return new VoiceChannelCreateMono(this.reason, this.name, 
/*     */ 
/*     */         
/* 292 */         bitrate(), 
/* 293 */         userLimit(), newValue, 
/*     */         
/* 295 */         rateLimitPerUser(), 
/* 296 */         permissionOverwrites(), 
/* 297 */         parentId(), this.guild);
/*     */   }
/*     */ 
/*     */   
/*     */   public VoiceChannelCreateMono withPosition(Integer value) {
/* 302 */     Possible<Integer> newValue = Possible.of(value);
/* 303 */     return new VoiceChannelCreateMono(this.reason, this.name, 
/*     */ 
/*     */         
/* 306 */         bitrate(), 
/* 307 */         userLimit(), newValue, 
/*     */         
/* 309 */         rateLimitPerUser(), 
/* 310 */         permissionOverwrites(), 
/* 311 */         parentId(), this.guild);
/*     */   }
/*     */ 
/*     */   
/*     */   public VoiceChannelCreateMono withRateLimitPerUser(Possible<Integer> value) {
/* 316 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/* 317 */     return new VoiceChannelCreateMono(this.reason, this.name, 
/*     */ 
/*     */         
/* 320 */         bitrate(), 
/* 321 */         userLimit(), 
/* 322 */         position(), newValue, 
/*     */         
/* 324 */         permissionOverwrites(), 
/* 325 */         parentId(), this.guild);
/*     */   }
/*     */ 
/*     */   
/*     */   public VoiceChannelCreateMono withRateLimitPerUser(Integer value) {
/* 330 */     Possible<Integer> newValue = Possible.of(value);
/* 331 */     return new VoiceChannelCreateMono(this.reason, this.name, 
/*     */ 
/*     */         
/* 334 */         bitrate(), 
/* 335 */         userLimit(), 
/* 336 */         position(), newValue, 
/*     */         
/* 338 */         permissionOverwrites(), 
/* 339 */         parentId(), this.guild);
/*     */   }
/*     */ 
/*     */   
/*     */   public VoiceChannelCreateMono withPermissionOverwrites(Possible<List<PermissionOverwrite>> possible) {
/* 344 */     Possible<List<PermissionOverwrite>> newValue = Objects.<Possible<List<PermissionOverwrite>>>requireNonNull(possible);
/* 345 */     return new VoiceChannelCreateMono(this.reason, this.name, 
/*     */ 
/*     */         
/* 348 */         bitrate(), 
/* 349 */         userLimit(), 
/* 350 */         position(), 
/* 351 */         rateLimitPerUser(), newValue, 
/*     */         
/* 353 */         parentId(), this.guild);
/*     */   }
/*     */ 
/*     */   
/*     */   public VoiceChannelCreateMono withPermissionOverwrites(Iterable<PermissionOverwrite> elements) {
/* 358 */     Possible<List<PermissionOverwrite>> newValue = Possible.of(
/* 359 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/* 360 */     return new VoiceChannelCreateMono(this.reason, this.name, 
/*     */ 
/*     */         
/* 363 */         bitrate(), 
/* 364 */         userLimit(), 
/* 365 */         position(), 
/* 366 */         rateLimitPerUser(), newValue, 
/*     */         
/* 368 */         parentId(), this.guild);
/*     */   }
/*     */ 
/*     */   
/*     */   @SafeVarargs
/*     */   public final VoiceChannelCreateMono withPermissionOverwrites(PermissionOverwrite... elements) {
/* 374 */     Possible<List<PermissionOverwrite>> newValue = Possible.of(Arrays.asList(elements));
/* 375 */     return new VoiceChannelCreateMono(this.reason, this.name, 
/*     */ 
/*     */         
/* 378 */         bitrate(), 
/* 379 */         userLimit(), 
/* 380 */         position(), 
/* 381 */         rateLimitPerUser(), newValue, 
/*     */         
/* 383 */         parentId(), this.guild);
/*     */   }
/*     */ 
/*     */   
/*     */   public VoiceChannelCreateMono withParentId(Possible<Snowflake> value) {
/* 388 */     Possible<Snowflake> newValue = Objects.<Possible<Snowflake>>requireNonNull(value);
/* 389 */     return new VoiceChannelCreateMono(this.reason, this.name, 
/*     */ 
/*     */         
/* 392 */         bitrate(), 
/* 393 */         userLimit(), 
/* 394 */         position(), 
/* 395 */         rateLimitPerUser(), 
/* 396 */         permissionOverwrites(), newValue, this.guild);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public VoiceChannelCreateMono withParentId(Snowflake value) {
/* 402 */     Possible<Snowflake> newValue = Possible.of(value);
/* 403 */     return new VoiceChannelCreateMono(this.reason, this.name, 
/*     */ 
/*     */         
/* 406 */         bitrate(), 
/* 407 */         userLimit(), 
/* 408 */         position(), 
/* 409 */         rateLimitPerUser(), 
/* 410 */         permissionOverwrites(), newValue, this.guild);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final VoiceChannelCreateMono withGuild(Guild value) {
/* 422 */     if (this.guild == value) return this; 
/* 423 */     Guild newValue = Objects.<Guild>requireNonNull(value, "guild");
/* 424 */     return new VoiceChannelCreateMono(this.reason, this.name, 
/*     */ 
/*     */         
/* 427 */         bitrate(), 
/* 428 */         userLimit(), 
/* 429 */         position(), 
/* 430 */         rateLimitPerUser(), 
/* 431 */         permissionOverwrites(), 
/* 432 */         parentId(), newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 442 */     if (this == another) return true; 
/* 443 */     return (another instanceof VoiceChannelCreateMono && 
/* 444 */       equalTo(0, (VoiceChannelCreateMono)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, VoiceChannelCreateMono another) {
/* 448 */     return (Objects.equals(this.reason, another.reason) && this.name
/* 449 */       .equals(another.name) && 
/* 450 */       bitrate().equals(another.bitrate()) && 
/* 451 */       userLimit().equals(another.userLimit()) && 
/* 452 */       position().equals(another.position()) && 
/* 453 */       rateLimitPerUser().equals(another.rateLimitPerUser()) && 
/* 454 */       Objects.equals(this.permissionOverwrites_value, another.permissionOverwrites_value) && 
/* 455 */       parentId().equals(another.parentId()) && this.guild
/* 456 */       .equals(another.guild));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 465 */     int h = 5381;
/* 466 */     h += (h << 5) + Objects.hashCode(this.reason);
/* 467 */     h += (h << 5) + this.name.hashCode();
/* 468 */     h += (h << 5) + bitrate().hashCode();
/* 469 */     h += (h << 5) + userLimit().hashCode();
/* 470 */     h += (h << 5) + position().hashCode();
/* 471 */     h += (h << 5) + rateLimitPerUser().hashCode();
/* 472 */     h += (h << 5) + Objects.hashCode(this.permissionOverwrites_value);
/* 473 */     h += (h << 5) + parentId().hashCode();
/* 474 */     h += (h << 5) + this.guild.hashCode();
/* 475 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 484 */     return "VoiceChannelCreateMono{reason=" + this.reason + ", name=" + this.name + ", bitrate=" + 
/*     */ 
/*     */       
/* 487 */       bitrate().toString() + ", userLimit=" + 
/* 488 */       userLimit().toString() + ", position=" + 
/* 489 */       position().toString() + ", rateLimitPerUser=" + 
/* 490 */       rateLimitPerUser().toString() + ", permissionOverwrites=" + 
/* 491 */       Objects.toString(this.permissionOverwrites_value) + ", parentId=" + 
/* 492 */       parentId().toString() + ", guild=" + this.guild + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static VoiceChannelCreateMono of(String name, Guild guild) {
/* 504 */     return new VoiceChannelCreateMono(name, guild);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static VoiceChannelCreateMono copyOf(VoiceChannelCreateMonoGenerator instance) {
/* 515 */     if (instance instanceof VoiceChannelCreateMono) {
/* 516 */       return (VoiceChannelCreateMono)instance;
/*     */     }
/* 518 */     return of(instance.name(), instance.guild())
/* 519 */       .withReason(instance.reason())
/* 520 */       .withBitrate(instance.bitrate())
/* 521 */       .withUserLimit(instance.userLimit())
/* 522 */       .withPosition(instance.position())
/* 523 */       .withRateLimitPerUser(instance.rateLimitPerUser())
/* 524 */       .withPermissionOverwrites(instance.permissionOverwrites())
/* 525 */       .withParentId(instance.parentId());
/*     */   }
/*     */   
/*     */   public boolean isBitratePresent() {
/* 529 */     return !this.bitrate_absent;
/*     */   }
/*     */   
/*     */   public Integer bitrateOrElse(Integer defaultValue) {
/* 533 */     return !this.bitrate_absent ? this.bitrate_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isUserLimitPresent() {
/* 537 */     return !this.userLimit_absent;
/*     */   }
/*     */   
/*     */   public Integer userLimitOrElse(Integer defaultValue) {
/* 541 */     return !this.userLimit_absent ? this.userLimit_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isPositionPresent() {
/* 545 */     return !this.position_absent;
/*     */   }
/*     */   
/*     */   public Integer positionOrElse(Integer defaultValue) {
/* 549 */     return !this.position_absent ? this.position_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isRateLimitPerUserPresent() {
/* 553 */     return !this.rateLimitPerUser_absent;
/*     */   }
/*     */   
/*     */   public Integer rateLimitPerUserOrElse(Integer defaultValue) {
/* 557 */     return !this.rateLimitPerUser_absent ? this.rateLimitPerUser_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isPermissionOverwritesPresent() {
/* 561 */     return !this.permissionOverwrites_absent;
/*     */   }
/*     */   
/*     */   public List<PermissionOverwrite> permissionOverwritesOrElse(List<PermissionOverwrite> defaultValue) {
/* 565 */     return !this.permissionOverwrites_absent ? this.permissionOverwrites_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isParentIdPresent() {
/* 569 */     return !this.parentId_absent;
/*     */   }
/*     */   
/*     */   public Snowflake parentIdOrElse(Snowflake defaultValue) {
/* 573 */     return !this.parentId_absent ? this.parentId_value : defaultValue;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\VoiceChannelCreateMono.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */