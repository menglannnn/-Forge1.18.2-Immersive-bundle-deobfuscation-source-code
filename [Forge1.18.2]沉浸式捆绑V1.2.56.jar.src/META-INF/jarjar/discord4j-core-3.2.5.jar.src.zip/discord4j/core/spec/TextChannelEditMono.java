/*     */ package discord4j.core.spec;
/*     */ 
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.object.PermissionOverwrite;
/*     */ import discord4j.core.object.entity.channel.TextChannel;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.stream.StreamSupport;
/*     */ import org.immutables.value.Generated;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "TextChannelEditMonoGenerator", generator = "Immutables")
/*     */ public final class TextChannelEditMono
/*     */   extends TextChannelEditMonoGenerator
/*     */ {
/*     */   @Nullable
/*     */   private final String reason;
/*     */   private final String name_value;
/*     */   private final boolean name_absent;
/*     */   private final Integer position_value;
/*     */   private final boolean position_absent;
/*     */   private final String topic_value;
/*     */   private final boolean topic_absent;
/*     */   private final Integer rateLimitPerUser_value;
/*     */   private final boolean rateLimitPerUser_absent;
/*     */   private final Boolean nsfw_value;
/*     */   private final boolean nsfw_absent;
/*     */   private final List<PermissionOverwrite> permissionOverwrites_value;
/*     */   private final boolean permissionOverwrites_absent;
/*     */   private final Snowflake parentId_value;
/*     */   private final boolean parentId_absent;
/*     */   private final TextChannel channel;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   private volatile transient InitShim initShim;
/*     */   
/*     */   private TextChannelEditMono(TextChannel channel) {
/* 111 */     this.initShim = new InitShim(); this.channel = Objects.<TextChannel>requireNonNull(channel, "channel"); this.reason = null; Possible<String> name$impl = Possible.absent(); Possible<Integer> position$impl = Possible.absent(); Possible<String> topic$impl = Possible.absent(); Possible<Integer> rateLimitPerUser$impl = Possible.absent(); Possible<Boolean> nsfw$impl = Possible.absent(); Possible<List<PermissionOverwrite>> permissionOverwrites$impl = Possible.absent(); Possible<Optional<Snowflake>> parentId$impl = Possible.absent(); this.name_value = name$impl.toOptional().orElse(null); this.name_absent = name$impl.isAbsent(); this.position_value = position$impl.toOptional().orElse(null); this.position_absent = position$impl.isAbsent(); this.topic_value = topic$impl.toOptional().orElse(null); this.topic_absent = topic$impl.isAbsent(); this.rateLimitPerUser_value = rateLimitPerUser$impl.toOptional().orElse(null); this.rateLimitPerUser_absent = rateLimitPerUser$impl.isAbsent(); this.nsfw_value = nsfw$impl.toOptional().orElse(null); this.nsfw_absent = nsfw$impl.isAbsent(); this.permissionOverwrites_value = permissionOverwrites$impl.toOptional().orElse(null); this.permissionOverwrites_absent = permissionOverwrites$impl.isAbsent(); this.parentId_value = Possible.flatOpt(parentId$impl).orElse(null); this.parentId_absent = parentId$impl.isAbsent(); this.initShim = null; } private TextChannelEditMono(@Nullable String reason, Possible<String> name, Possible<Integer> position, Possible<String> topic, Possible<Integer> rateLimitPerUser, Possible<Boolean> nsfw, Possible<List<PermissionOverwrite>> permissionOverwrites, Possible<Optional<Snowflake>> parentId, TextChannel channel) { this.initShim = new InitShim(); this.reason = reason; Possible<String> name$impl = name; Possible<Integer> position$impl = position; Possible<String> topic$impl = topic; Possible<Integer> rateLimitPerUser$impl = rateLimitPerUser; Possible<Boolean> nsfw$impl = nsfw; Possible<List<PermissionOverwrite>> permissionOverwrites$impl = permissionOverwrites; Possible<Optional<Snowflake>> parentId$impl = parentId; this.channel = channel; this.name_value = name$impl.toOptional().orElse(null); this.name_absent = name$impl.isAbsent(); this.position_value = position$impl.toOptional().orElse(null); this.position_absent = position$impl.isAbsent(); this.topic_value = topic$impl.toOptional().orElse(null); this.topic_absent = topic$impl.isAbsent(); this.rateLimitPerUser_value = rateLimitPerUser$impl.toOptional().orElse(null); this.rateLimitPerUser_absent = rateLimitPerUser$impl.isAbsent(); this.nsfw_value = nsfw$impl.toOptional().orElse(null);
/*     */     this.nsfw_absent = nsfw$impl.isAbsent();
/*     */     this.permissionOverwrites_value = permissionOverwrites$impl.toOptional().orElse(null);
/*     */     this.permissionOverwrites_absent = permissionOverwrites$impl.isAbsent();
/*     */     this.parentId_value = Possible.flatOpt(parentId$impl).orElse(null);
/*     */     this.parentId_absent = parentId$impl.isAbsent();
/* 117 */     this.initShim = null; } @Generated(from = "TextChannelEditMonoGenerator", generator = "Immutables") private final class InitShim { private InitShim() {} private String formatInitCycleMessage() { List<String> attributes = new ArrayList<>();
/* 118 */       return "Cannot build TextChannelEditMono, attribute initializers form cycle " + attributes; }
/*     */      }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String reason() {
/* 128 */     return this.reason;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<String> name() {
/* 136 */     return this.name_absent ? Possible.absent() : Possible.of(this.name_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Integer> position() {
/* 144 */     return this.position_absent ? Possible.absent() : Possible.of(this.position_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<String> topic() {
/* 152 */     return this.topic_absent ? Possible.absent() : Possible.of(this.topic_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Integer> rateLimitPerUser() {
/* 160 */     return this.rateLimitPerUser_absent ? Possible.absent() : Possible.of(this.rateLimitPerUser_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Boolean> nsfw() {
/* 168 */     return this.nsfw_absent ? Possible.absent() : Possible.of(this.nsfw_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<List<PermissionOverwrite>> permissionOverwrites() {
/* 176 */     return this.permissionOverwrites_absent ? Possible.absent() : 
/* 177 */       Possible.of(this.permissionOverwrites_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Optional<Snowflake>> parentId() {
/* 185 */     return this.parentId_absent ? Possible.absent() : 
/* 186 */       Possible.of(Optional.ofNullable(this.parentId_value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TextChannel channel() {
/* 194 */     return this.channel;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final TextChannelEditMono withReason(@Nullable String value) {
/* 204 */     if (Objects.equals(this.reason, value)) return this; 
/* 205 */     return new TextChannelEditMono(value, 
/*     */         
/* 207 */         name(), 
/* 208 */         position(), 
/* 209 */         topic(), 
/* 210 */         rateLimitPerUser(), 
/* 211 */         nsfw(), 
/* 212 */         permissionOverwrites(), 
/* 213 */         parentId(), this.channel);
/*     */   }
/*     */ 
/*     */   
/*     */   public TextChannelEditMono withName(Possible<String> value) {
/* 218 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/* 219 */     return new TextChannelEditMono(this.reason, newValue, 
/*     */ 
/*     */         
/* 222 */         position(), 
/* 223 */         topic(), 
/* 224 */         rateLimitPerUser(), 
/* 225 */         nsfw(), 
/* 226 */         permissionOverwrites(), 
/* 227 */         parentId(), this.channel);
/*     */   }
/*     */ 
/*     */   
/*     */   public TextChannelEditMono withName(String value) {
/* 232 */     Possible<String> newValue = Possible.of(value);
/* 233 */     return new TextChannelEditMono(this.reason, newValue, 
/*     */ 
/*     */         
/* 236 */         position(), 
/* 237 */         topic(), 
/* 238 */         rateLimitPerUser(), 
/* 239 */         nsfw(), 
/* 240 */         permissionOverwrites(), 
/* 241 */         parentId(), this.channel);
/*     */   }
/*     */ 
/*     */   
/*     */   public TextChannelEditMono withPosition(Possible<Integer> value) {
/* 246 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/* 247 */     return new TextChannelEditMono(this.reason, 
/*     */         
/* 249 */         name(), newValue, 
/*     */         
/* 251 */         topic(), 
/* 252 */         rateLimitPerUser(), 
/* 253 */         nsfw(), 
/* 254 */         permissionOverwrites(), 
/* 255 */         parentId(), this.channel);
/*     */   }
/*     */ 
/*     */   
/*     */   public TextChannelEditMono withPosition(Integer value) {
/* 260 */     Possible<Integer> newValue = Possible.of(value);
/* 261 */     return new TextChannelEditMono(this.reason, 
/*     */         
/* 263 */         name(), newValue, 
/*     */         
/* 265 */         topic(), 
/* 266 */         rateLimitPerUser(), 
/* 267 */         nsfw(), 
/* 268 */         permissionOverwrites(), 
/* 269 */         parentId(), this.channel);
/*     */   }
/*     */ 
/*     */   
/*     */   public TextChannelEditMono withTopic(Possible<String> value) {
/* 274 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/* 275 */     return new TextChannelEditMono(this.reason, 
/*     */         
/* 277 */         name(), 
/* 278 */         position(), newValue, 
/*     */         
/* 280 */         rateLimitPerUser(), 
/* 281 */         nsfw(), 
/* 282 */         permissionOverwrites(), 
/* 283 */         parentId(), this.channel);
/*     */   }
/*     */ 
/*     */   
/*     */   public TextChannelEditMono withTopic(String value) {
/* 288 */     Possible<String> newValue = Possible.of(value);
/* 289 */     return new TextChannelEditMono(this.reason, 
/*     */         
/* 291 */         name(), 
/* 292 */         position(), newValue, 
/*     */         
/* 294 */         rateLimitPerUser(), 
/* 295 */         nsfw(), 
/* 296 */         permissionOverwrites(), 
/* 297 */         parentId(), this.channel);
/*     */   }
/*     */ 
/*     */   
/*     */   public TextChannelEditMono withRateLimitPerUser(Possible<Integer> value) {
/* 302 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/* 303 */     return new TextChannelEditMono(this.reason, 
/*     */         
/* 305 */         name(), 
/* 306 */         position(), 
/* 307 */         topic(), newValue, 
/*     */         
/* 309 */         nsfw(), 
/* 310 */         permissionOverwrites(), 
/* 311 */         parentId(), this.channel);
/*     */   }
/*     */ 
/*     */   
/*     */   public TextChannelEditMono withRateLimitPerUser(Integer value) {
/* 316 */     Possible<Integer> newValue = Possible.of(value);
/* 317 */     return new TextChannelEditMono(this.reason, 
/*     */         
/* 319 */         name(), 
/* 320 */         position(), 
/* 321 */         topic(), newValue, 
/*     */         
/* 323 */         nsfw(), 
/* 324 */         permissionOverwrites(), 
/* 325 */         parentId(), this.channel);
/*     */   }
/*     */ 
/*     */   
/*     */   public TextChannelEditMono withNsfw(Possible<Boolean> value) {
/* 330 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/* 331 */     return new TextChannelEditMono(this.reason, 
/*     */         
/* 333 */         name(), 
/* 334 */         position(), 
/* 335 */         topic(), 
/* 336 */         rateLimitPerUser(), newValue, 
/*     */         
/* 338 */         permissionOverwrites(), 
/* 339 */         parentId(), this.channel);
/*     */   }
/*     */ 
/*     */   
/*     */   public TextChannelEditMono withNsfw(Boolean value) {
/* 344 */     Possible<Boolean> newValue = Possible.of(value);
/* 345 */     return new TextChannelEditMono(this.reason, 
/*     */         
/* 347 */         name(), 
/* 348 */         position(), 
/* 349 */         topic(), 
/* 350 */         rateLimitPerUser(), newValue, 
/*     */         
/* 352 */         permissionOverwrites(), 
/* 353 */         parentId(), this.channel);
/*     */   }
/*     */ 
/*     */   
/*     */   public TextChannelEditMono withPermissionOverwrites(Possible<List<PermissionOverwrite>> possible) {
/* 358 */     Possible<List<PermissionOverwrite>> newValue = Objects.<Possible<List<PermissionOverwrite>>>requireNonNull(possible);
/* 359 */     return new TextChannelEditMono(this.reason, 
/*     */         
/* 361 */         name(), 
/* 362 */         position(), 
/* 363 */         topic(), 
/* 364 */         rateLimitPerUser(), 
/* 365 */         nsfw(), newValue, 
/*     */         
/* 367 */         parentId(), this.channel);
/*     */   }
/*     */ 
/*     */   
/*     */   public TextChannelEditMono withPermissionOverwrites(Iterable<PermissionOverwrite> elements) {
/* 372 */     Possible<List<PermissionOverwrite>> newValue = Possible.of(
/* 373 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/* 374 */     return new TextChannelEditMono(this.reason, 
/*     */         
/* 376 */         name(), 
/* 377 */         position(), 
/* 378 */         topic(), 
/* 379 */         rateLimitPerUser(), 
/* 380 */         nsfw(), newValue, 
/*     */         
/* 382 */         parentId(), this.channel);
/*     */   }
/*     */ 
/*     */   
/*     */   @SafeVarargs
/*     */   public final TextChannelEditMono withPermissionOverwrites(PermissionOverwrite... elements) {
/* 388 */     Possible<List<PermissionOverwrite>> newValue = Possible.of(Arrays.asList(elements));
/* 389 */     return new TextChannelEditMono(this.reason, 
/*     */         
/* 391 */         name(), 
/* 392 */         position(), 
/* 393 */         topic(), 
/* 394 */         rateLimitPerUser(), 
/* 395 */         nsfw(), newValue, 
/*     */         
/* 397 */         parentId(), this.channel);
/*     */   }
/*     */ 
/*     */   
/*     */   public TextChannelEditMono withParentId(Possible<Optional<Snowflake>> value) {
/* 402 */     Possible<Optional<Snowflake>> newValue = Objects.<Possible<Optional<Snowflake>>>requireNonNull(value);
/* 403 */     return new TextChannelEditMono(this.reason, 
/*     */         
/* 405 */         name(), 
/* 406 */         position(), 
/* 407 */         topic(), 
/* 408 */         rateLimitPerUser(), 
/* 409 */         nsfw(), 
/* 410 */         permissionOverwrites(), newValue, this.channel);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public TextChannelEditMono withParentId(@Nullable Snowflake value) {
/* 417 */     Possible<Optional<Snowflake>> newValue = Possible.of(Optional.ofNullable(value));
/* 418 */     return new TextChannelEditMono(this.reason, 
/*     */         
/* 420 */         name(), 
/* 421 */         position(), 
/* 422 */         topic(), 
/* 423 */         rateLimitPerUser(), 
/* 424 */         nsfw(), 
/* 425 */         permissionOverwrites(), newValue, this.channel);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public TextChannelEditMono withParentIdOrNull(@Nullable Snowflake value) {
/* 431 */     Possible<Optional<Snowflake>> newValue = Possible.of(Optional.ofNullable(value));
/* 432 */     return new TextChannelEditMono(this.reason, 
/*     */         
/* 434 */         name(), 
/* 435 */         position(), 
/* 436 */         topic(), 
/* 437 */         rateLimitPerUser(), 
/* 438 */         nsfw(), 
/* 439 */         permissionOverwrites(), newValue, this.channel);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final TextChannelEditMono withChannel(TextChannel value) {
/* 451 */     if (this.channel == value) return this; 
/* 452 */     TextChannel newValue = Objects.<TextChannel>requireNonNull(value, "channel");
/* 453 */     return new TextChannelEditMono(this.reason, 
/*     */         
/* 455 */         name(), 
/* 456 */         position(), 
/* 457 */         topic(), 
/* 458 */         rateLimitPerUser(), 
/* 459 */         nsfw(), 
/* 460 */         permissionOverwrites(), 
/* 461 */         parentId(), newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 471 */     if (this == another) return true; 
/* 472 */     return (another instanceof TextChannelEditMono && 
/* 473 */       equalTo(0, (TextChannelEditMono)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, TextChannelEditMono another) {
/* 477 */     return (Objects.equals(this.reason, another.reason) && 
/* 478 */       name().equals(another.name()) && 
/* 479 */       position().equals(another.position()) && 
/* 480 */       topic().equals(another.topic()) && 
/* 481 */       rateLimitPerUser().equals(another.rateLimitPerUser()) && 
/* 482 */       nsfw().equals(another.nsfw()) && 
/* 483 */       Objects.equals(this.permissionOverwrites_value, another.permissionOverwrites_value) && 
/* 484 */       parentId().equals(another.parentId()) && this.channel
/* 485 */       .equals(another.channel));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 494 */     int h = 5381;
/* 495 */     h += (h << 5) + Objects.hashCode(this.reason);
/* 496 */     h += (h << 5) + name().hashCode();
/* 497 */     h += (h << 5) + position().hashCode();
/* 498 */     h += (h << 5) + topic().hashCode();
/* 499 */     h += (h << 5) + rateLimitPerUser().hashCode();
/* 500 */     h += (h << 5) + nsfw().hashCode();
/* 501 */     h += (h << 5) + Objects.hashCode(this.permissionOverwrites_value);
/* 502 */     h += (h << 5) + parentId().hashCode();
/* 503 */     h += (h << 5) + this.channel.hashCode();
/* 504 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 513 */     return "TextChannelEditMono{reason=" + this.reason + ", name=" + 
/*     */       
/* 515 */       name().toString() + ", position=" + 
/* 516 */       position().toString() + ", topic=" + 
/* 517 */       topic().toString() + ", rateLimitPerUser=" + 
/* 518 */       rateLimitPerUser().toString() + ", nsfw=" + 
/* 519 */       nsfw().toString() + ", permissionOverwrites=" + 
/* 520 */       Objects.toString(this.permissionOverwrites_value) + ", parentId=" + 
/* 521 */       parentId().toString() + ", channel=" + this.channel + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static TextChannelEditMono of(TextChannel channel) {
/* 532 */     return new TextChannelEditMono(channel);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static TextChannelEditMono copyOf(TextChannelEditMonoGenerator instance) {
/* 543 */     if (instance instanceof TextChannelEditMono) {
/* 544 */       return (TextChannelEditMono)instance;
/*     */     }
/* 546 */     return of(instance.channel())
/* 547 */       .withReason(instance.reason())
/* 548 */       .withName(instance.name())
/* 549 */       .withPosition(instance.position())
/* 550 */       .withTopic(instance.topic())
/* 551 */       .withRateLimitPerUser(instance.rateLimitPerUser())
/* 552 */       .withNsfw(instance.nsfw())
/* 553 */       .withPermissionOverwrites(instance.permissionOverwrites())
/* 554 */       .withParentId(instance.parentId());
/*     */   }
/*     */   
/*     */   public boolean isNamePresent() {
/* 558 */     return !this.name_absent;
/*     */   }
/*     */   
/*     */   public String nameOrElse(String defaultValue) {
/* 562 */     return !this.name_absent ? this.name_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isPositionPresent() {
/* 566 */     return !this.position_absent;
/*     */   }
/*     */   
/*     */   public Integer positionOrElse(Integer defaultValue) {
/* 570 */     return !this.position_absent ? this.position_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isTopicPresent() {
/* 574 */     return !this.topic_absent;
/*     */   }
/*     */   
/*     */   public String topicOrElse(String defaultValue) {
/* 578 */     return !this.topic_absent ? this.topic_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isRateLimitPerUserPresent() {
/* 582 */     return !this.rateLimitPerUser_absent;
/*     */   }
/*     */   
/*     */   public Integer rateLimitPerUserOrElse(Integer defaultValue) {
/* 586 */     return !this.rateLimitPerUser_absent ? this.rateLimitPerUser_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isNsfwPresent() {
/* 590 */     return !this.nsfw_absent;
/*     */   }
/*     */   
/*     */   public Boolean nsfwOrElse(Boolean defaultValue) {
/* 594 */     return !this.nsfw_absent ? this.nsfw_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isPermissionOverwritesPresent() {
/* 598 */     return !this.permissionOverwrites_absent;
/*     */   }
/*     */   
/*     */   public List<PermissionOverwrite> permissionOverwritesOrElse(List<PermissionOverwrite> defaultValue) {
/* 602 */     return !this.permissionOverwrites_absent ? this.permissionOverwrites_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isParentIdPresent() {
/* 606 */     return !this.parentId_absent;
/*     */   }
/*     */   
/*     */   public Snowflake parentIdOrElse(Snowflake defaultValue) {
/* 610 */     return !this.parentId_absent ? this.parentId_value : defaultValue;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\TextChannelEditMono.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */