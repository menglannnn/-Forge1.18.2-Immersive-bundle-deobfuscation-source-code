/*     */ package discord4j.core.spec;
/*     */ 
/*     */ import com.google.errorprone.annotations.CanIgnoreReturnValue;
/*     */ import discord4j.core.object.Region;
/*     */ import discord4j.core.object.entity.Guild;
/*     */ import discord4j.core.object.entity.channel.Channel;
/*     */ import discord4j.rest.util.Image;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "GuildCreateSpecGenerator", generator = "Immutables")
/*     */ public final class GuildCreateSpec
/*     */   implements GuildCreateSpecGenerator
/*     */ {
/*     */   private final String name;
/*     */   private final Region region;
/*     */   @Nullable
/*     */   private final Image icon;
/*     */   private final Guild.VerificationLevel verificationLevel;
/*     */   private final Guild.NotificationLevel defaultMessageNotificationLevel;
/*     */   private final Guild.ContentFilterLevel explicitContentFilter;
/*     */   private final List<RoleCreateSpec> roles;
/*     */   @Nullable
/*     */   private final RoleCreateSpec everyoneRole;
/*     */   private final List<GuildCreateFields.PartialChannel> channels;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   private volatile transient InitShim initShim;
/*     */   
/*     */   private GuildCreateSpec(String name, Region region) {
/* 106 */     this.initShim = new InitShim(); this.name = Objects.<String>requireNonNull(name, "name"); this.region = Objects.<Region>requireNonNull(region, "region"); this.icon = null; this.everyoneRole = null; this.verificationLevel = this.initShim.verificationLevel(); this.defaultMessageNotificationLevel = this.initShim.defaultMessageNotificationLevel(); this.explicitContentFilter = this.initShim.explicitContentFilter(); this.roles = this.initShim.roles(); this.channels = this.initShim.channels(); this.initShim = null; } private GuildCreateSpec(Builder builder) { this.initShim = new InitShim(); this.name = builder.name; this.region = builder.region; this.icon = builder.icon; this.everyoneRole = builder.everyoneRole; if (builder.verificationLevel != null) this.initShim.verificationLevel(builder.verificationLevel);  if (builder.defaultMessageNotificationLevel != null) this.initShim.defaultMessageNotificationLevel(builder.defaultMessageNotificationLevel);  if (builder.explicitContentFilter != null) this.initShim.explicitContentFilter(builder.explicitContentFilter);  if (builder.rolesIsSet()) this.initShim.roles(createUnmodifiableList(true, builder.roles));  if (builder.channelsIsSet()) this.initShim.channels(createUnmodifiableList(true, builder.channels));  this.verificationLevel = this.initShim.verificationLevel(); this.defaultMessageNotificationLevel = this.initShim.defaultMessageNotificationLevel(); this.explicitContentFilter = this.initShim.explicitContentFilter(); this.roles = this.initShim.roles(); this.channels = this.initShim.channels(); this.initShim = null; } private GuildCreateSpec(String name, Region region, @Nullable Image icon, Guild.VerificationLevel verificationLevel, Guild.NotificationLevel defaultMessageNotificationLevel, Guild.ContentFilterLevel explicitContentFilter, List<RoleCreateSpec> roles, @Nullable RoleCreateSpec everyoneRole, List<GuildCreateFields.PartialChannel> channels) { this.initShim = new InitShim(); this.name = name; this.region = region; this.icon = icon; this.verificationLevel = verificationLevel; this.defaultMessageNotificationLevel = defaultMessageNotificationLevel;
/*     */     this.explicitContentFilter = explicitContentFilter;
/*     */     this.roles = roles;
/*     */     this.everyoneRole = everyoneRole;
/*     */     this.channels = channels;
/* 111 */     this.initShim = null; } @Generated(from = "GuildCreateSpecGenerator", generator = "Immutables") private final class InitShim { private byte verificationLevelBuildStage = 0;
/*     */     private Guild.VerificationLevel verificationLevel;
/*     */     
/*     */     Guild.VerificationLevel verificationLevel() {
/* 115 */       if (this.verificationLevelBuildStage == -1) throw new IllegalStateException(formatInitCycleMessage()); 
/* 116 */       if (this.verificationLevelBuildStage == 0) {
/* 117 */         this.verificationLevelBuildStage = -1;
/* 118 */         this.verificationLevel = Objects.<Guild.VerificationLevel>requireNonNull(GuildCreateSpec.this.verificationLevelInitialize(), "verificationLevel");
/* 119 */         this.verificationLevelBuildStage = 1;
/*     */       } 
/* 121 */       return this.verificationLevel;
/*     */     }
/*     */     
/*     */     void verificationLevel(Guild.VerificationLevel verificationLevel) {
/* 125 */       this.verificationLevel = verificationLevel;
/* 126 */       this.verificationLevelBuildStage = 1;
/*     */     }
/*     */     
/* 129 */     private byte defaultMessageNotificationLevelBuildStage = 0;
/*     */     private Guild.NotificationLevel defaultMessageNotificationLevel;
/*     */     
/*     */     Guild.NotificationLevel defaultMessageNotificationLevel() {
/* 133 */       if (this.defaultMessageNotificationLevelBuildStage == -1) throw new IllegalStateException(formatInitCycleMessage()); 
/* 134 */       if (this.defaultMessageNotificationLevelBuildStage == 0) {
/* 135 */         this.defaultMessageNotificationLevelBuildStage = -1;
/* 136 */         this.defaultMessageNotificationLevel = Objects.<Guild.NotificationLevel>requireNonNull(GuildCreateSpec.this.defaultMessageNotificationLevelInitialize(), "defaultMessageNotificationLevel");
/* 137 */         this.defaultMessageNotificationLevelBuildStage = 1;
/*     */       } 
/* 139 */       return this.defaultMessageNotificationLevel;
/*     */     }
/*     */     
/*     */     void defaultMessageNotificationLevel(Guild.NotificationLevel defaultMessageNotificationLevel) {
/* 143 */       this.defaultMessageNotificationLevel = defaultMessageNotificationLevel;
/* 144 */       this.defaultMessageNotificationLevelBuildStage = 1;
/*     */     }
/*     */     
/* 147 */     private byte explicitContentFilterBuildStage = 0;
/*     */     private Guild.ContentFilterLevel explicitContentFilter;
/*     */     
/*     */     Guild.ContentFilterLevel explicitContentFilter() {
/* 151 */       if (this.explicitContentFilterBuildStage == -1) throw new IllegalStateException(formatInitCycleMessage()); 
/* 152 */       if (this.explicitContentFilterBuildStage == 0) {
/* 153 */         this.explicitContentFilterBuildStage = -1;
/* 154 */         this.explicitContentFilter = Objects.<Guild.ContentFilterLevel>requireNonNull(GuildCreateSpec.this.explicitContentFilterInitialize(), "explicitContentFilter");
/* 155 */         this.explicitContentFilterBuildStage = 1;
/*     */       } 
/* 157 */       return this.explicitContentFilter;
/*     */     }
/*     */     
/*     */     void explicitContentFilter(Guild.ContentFilterLevel explicitContentFilter) {
/* 161 */       this.explicitContentFilter = explicitContentFilter;
/* 162 */       this.explicitContentFilterBuildStage = 1;
/*     */     }
/*     */     
/* 165 */     private byte rolesBuildStage = 0;
/*     */     private List<RoleCreateSpec> roles;
/*     */     
/*     */     List<RoleCreateSpec> roles() {
/* 169 */       if (this.rolesBuildStage == -1) throw new IllegalStateException(formatInitCycleMessage()); 
/* 170 */       if (this.rolesBuildStage == 0) {
/* 171 */         this.rolesBuildStage = -1;
/* 172 */         this.roles = (List)GuildCreateSpec.createUnmodifiableList(false, GuildCreateSpec.createSafeList((Iterable)GuildCreateSpec.this.rolesInitialize(), true, false));
/* 173 */         this.rolesBuildStage = 1;
/*     */       } 
/* 175 */       return this.roles;
/*     */     }
/*     */     
/*     */     void roles(List<RoleCreateSpec> roles) {
/* 179 */       this.roles = roles;
/* 180 */       this.rolesBuildStage = 1;
/*     */     }
/*     */     
/* 183 */     private byte channelsBuildStage = 0;
/*     */     private List<GuildCreateFields.PartialChannel> channels;
/*     */     
/*     */     List<GuildCreateFields.PartialChannel> channels() {
/* 187 */       if (this.channelsBuildStage == -1) throw new IllegalStateException(formatInitCycleMessage()); 
/* 188 */       if (this.channelsBuildStage == 0) {
/* 189 */         this.channelsBuildStage = -1;
/* 190 */         this.channels = (List)GuildCreateSpec.createUnmodifiableList(false, GuildCreateSpec.createSafeList((Iterable)GuildCreateSpec.this.channelsInitialize(), true, false));
/* 191 */         this.channelsBuildStage = 1;
/*     */       } 
/* 193 */       return this.channels;
/*     */     }
/*     */     
/*     */     void channels(List<GuildCreateFields.PartialChannel> channels) {
/* 197 */       this.channels = channels;
/* 198 */       this.channelsBuildStage = 1;
/*     */     }
/*     */     
/*     */     private String formatInitCycleMessage() {
/* 202 */       List<String> attributes = new ArrayList<>();
/* 203 */       if (this.verificationLevelBuildStage == -1) attributes.add("verificationLevel"); 
/* 204 */       if (this.defaultMessageNotificationLevelBuildStage == -1) attributes.add("defaultMessageNotificationLevel"); 
/* 205 */       if (this.explicitContentFilterBuildStage == -1) attributes.add("explicitContentFilter"); 
/* 206 */       if (this.rolesBuildStage == -1) attributes.add("roles"); 
/* 207 */       if (this.channelsBuildStage == -1) attributes.add("channels"); 
/* 208 */       return "Cannot build GuildCreateSpec, attribute initializers form cycle " + attributes;
/*     */     }
/*     */     private InitShim() {} }
/*     */   
/*     */   private Guild.VerificationLevel verificationLevelInitialize() {
/* 213 */     return super.verificationLevel();
/*     */   }
/*     */   
/*     */   private Guild.NotificationLevel defaultMessageNotificationLevelInitialize() {
/* 217 */     return super.defaultMessageNotificationLevel();
/*     */   }
/*     */   
/*     */   private Guild.ContentFilterLevel explicitContentFilterInitialize() {
/* 221 */     return super.explicitContentFilter();
/*     */   }
/*     */   
/*     */   private List<RoleCreateSpec> rolesInitialize() {
/* 225 */     return super.roles();
/*     */   }
/*     */   
/*     */   private List<GuildCreateFields.PartialChannel> channelsInitialize() {
/* 229 */     return super.channels();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String name() {
/* 237 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Region region() {
/* 245 */     return this.region;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Image icon() {
/* 253 */     return this.icon;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Guild.VerificationLevel verificationLevel() {
/* 261 */     InitShim shim = this.initShim;
/* 262 */     return (shim != null) ? 
/* 263 */       shim.verificationLevel() : 
/* 264 */       this.verificationLevel;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Guild.NotificationLevel defaultMessageNotificationLevel() {
/* 272 */     InitShim shim = this.initShim;
/* 273 */     return (shim != null) ? 
/* 274 */       shim.defaultMessageNotificationLevel() : 
/* 275 */       this.defaultMessageNotificationLevel;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Guild.ContentFilterLevel explicitContentFilter() {
/* 283 */     InitShim shim = this.initShim;
/* 284 */     return (shim != null) ? 
/* 285 */       shim.explicitContentFilter() : 
/* 286 */       this.explicitContentFilter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<RoleCreateSpec> roles() {
/* 294 */     InitShim shim = this.initShim;
/* 295 */     return (shim != null) ? 
/* 296 */       shim.roles() : 
/* 297 */       this.roles;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public RoleCreateSpec everyoneRole() {
/* 305 */     return this.everyoneRole;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<GuildCreateFields.PartialChannel> channels() {
/* 313 */     InitShim shim = this.initShim;
/* 314 */     return (shim != null) ? 
/* 315 */       shim.channels() : 
/* 316 */       this.channels;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final GuildCreateSpec withName(String value) {
/* 326 */     String newValue = Objects.<String>requireNonNull(value, "name");
/* 327 */     if (this.name.equals(newValue)) return this; 
/* 328 */     return new GuildCreateSpec(newValue, this.region, this.icon, this.verificationLevel, this.defaultMessageNotificationLevel, this.explicitContentFilter, this.roles, this.everyoneRole, this.channels);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final GuildCreateSpec withRegion(Region value) {
/* 347 */     if (this.region == value) return this; 
/* 348 */     Region newValue = Objects.<Region>requireNonNull(value, "region");
/* 349 */     return new GuildCreateSpec(this.name, newValue, this.icon, this.verificationLevel, this.defaultMessageNotificationLevel, this.explicitContentFilter, this.roles, this.everyoneRole, this.channels);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final GuildCreateSpec withIcon(@Nullable Image value) {
/* 368 */     if (this.icon == value) return this; 
/* 369 */     return new GuildCreateSpec(this.name, this.region, value, this.verificationLevel, this.defaultMessageNotificationLevel, this.explicitContentFilter, this.roles, this.everyoneRole, this.channels);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final GuildCreateSpec withVerificationLevel(Guild.VerificationLevel value) {
/* 388 */     Guild.VerificationLevel newValue = Objects.<Guild.VerificationLevel>requireNonNull(value, "verificationLevel");
/* 389 */     if (this.verificationLevel == newValue) return this; 
/* 390 */     return new GuildCreateSpec(this.name, this.region, this.icon, newValue, this.defaultMessageNotificationLevel, this.explicitContentFilter, this.roles, this.everyoneRole, this.channels);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final GuildCreateSpec withDefaultMessageNotificationLevel(Guild.NotificationLevel value) {
/* 409 */     Guild.NotificationLevel newValue = Objects.<Guild.NotificationLevel>requireNonNull(value, "defaultMessageNotificationLevel");
/* 410 */     if (this.defaultMessageNotificationLevel == newValue) return this; 
/* 411 */     return new GuildCreateSpec(this.name, this.region, this.icon, this.verificationLevel, newValue, this.explicitContentFilter, this.roles, this.everyoneRole, this.channels);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final GuildCreateSpec withExplicitContentFilter(Guild.ContentFilterLevel value) {
/* 430 */     Guild.ContentFilterLevel newValue = Objects.<Guild.ContentFilterLevel>requireNonNull(value, "explicitContentFilter");
/* 431 */     if (this.explicitContentFilter == newValue) return this; 
/* 432 */     return new GuildCreateSpec(this.name, this.region, this.icon, this.verificationLevel, this.defaultMessageNotificationLevel, newValue, this.roles, this.everyoneRole, this.channels);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final GuildCreateSpec withRoles(RoleCreateSpec... elements) {
/* 450 */     List<RoleCreateSpec> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/* 451 */     return new GuildCreateSpec(this.name, this.region, this.icon, this.verificationLevel, this.defaultMessageNotificationLevel, this.explicitContentFilter, newValue, this.everyoneRole, this.channels);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final GuildCreateSpec withRoles(Iterable<? extends RoleCreateSpec> elements) {
/* 470 */     if (this.roles == elements) return this; 
/* 471 */     List<RoleCreateSpec> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/* 472 */     return new GuildCreateSpec(this.name, this.region, this.icon, this.verificationLevel, this.defaultMessageNotificationLevel, this.explicitContentFilter, newValue, this.everyoneRole, this.channels);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final GuildCreateSpec withEveryoneRole(@Nullable RoleCreateSpec value) {
/* 491 */     if (this.everyoneRole == value) return this; 
/* 492 */     return new GuildCreateSpec(this.name, this.region, this.icon, this.verificationLevel, this.defaultMessageNotificationLevel, this.explicitContentFilter, this.roles, value, this.channels);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final GuildCreateSpec withChannels(GuildCreateFields.PartialChannel... elements) {
/* 510 */     List<GuildCreateFields.PartialChannel> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/* 511 */     return new GuildCreateSpec(this.name, this.region, this.icon, this.verificationLevel, this.defaultMessageNotificationLevel, this.explicitContentFilter, this.roles, this.everyoneRole, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final GuildCreateSpec withChannels(Iterable<? extends GuildCreateFields.PartialChannel> elements) {
/* 530 */     if (this.channels == elements) return this; 
/* 531 */     List<GuildCreateFields.PartialChannel> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/* 532 */     return new GuildCreateSpec(this.name, this.region, this.icon, this.verificationLevel, this.defaultMessageNotificationLevel, this.explicitContentFilter, this.roles, this.everyoneRole, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 550 */     if (this == another) return true; 
/* 551 */     return (another instanceof GuildCreateSpec && 
/* 552 */       equalTo(0, (GuildCreateSpec)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, GuildCreateSpec another) {
/* 556 */     return (this.name.equals(another.name) && this.region
/* 557 */       .equals(another.region) && 
/* 558 */       Objects.equals(this.icon, another.icon) && this.verificationLevel
/* 559 */       .equals(another.verificationLevel) && this.defaultMessageNotificationLevel
/* 560 */       .equals(another.defaultMessageNotificationLevel) && this.explicitContentFilter
/* 561 */       .equals(another.explicitContentFilter) && this.roles
/* 562 */       .equals(another.roles) && 
/* 563 */       Objects.equals(this.everyoneRole, another.everyoneRole) && this.channels
/* 564 */       .equals(another.channels));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 573 */     int h = 5381;
/* 574 */     h += (h << 5) + this.name.hashCode();
/* 575 */     h += (h << 5) + this.region.hashCode();
/* 576 */     h += (h << 5) + Objects.hashCode(this.icon);
/* 577 */     h += (h << 5) + this.verificationLevel.hashCode();
/* 578 */     h += (h << 5) + this.defaultMessageNotificationLevel.hashCode();
/* 579 */     h += (h << 5) + this.explicitContentFilter.hashCode();
/* 580 */     h += (h << 5) + this.roles.hashCode();
/* 581 */     h += (h << 5) + Objects.hashCode(this.everyoneRole);
/* 582 */     h += (h << 5) + this.channels.hashCode();
/* 583 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 592 */     return "GuildCreateSpec{name=" + this.name + ", region=" + this.region + ", icon=" + this.icon + ", verificationLevel=" + this.verificationLevel + ", defaultMessageNotificationLevel=" + this.defaultMessageNotificationLevel + ", explicitContentFilter=" + this.explicitContentFilter + ", roles=" + this.roles + ", everyoneRole=" + this.everyoneRole + ", channels=" + this.channels + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static GuildCreateSpec of(String name, Region region) {
/* 612 */     return new GuildCreateSpec(name, region);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static GuildCreateSpec copyOf(GuildCreateSpecGenerator instance) {
/* 623 */     if (instance instanceof GuildCreateSpec) {
/* 624 */       return (GuildCreateSpec)instance;
/*     */     }
/* 626 */     return builder()
/* 627 */       .from(instance)
/* 628 */       .build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 649 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "GuildCreateSpecGenerator", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_NAME = 1L;
/*     */     
/*     */     private static final long INIT_BIT_REGION = 2L;
/*     */     
/*     */     private static final long OPT_BIT_ROLES = 1L;
/*     */     
/*     */     private static final long OPT_BIT_CHANNELS = 2L;
/*     */     
/* 665 */     private long initBits = 3L;
/*     */     
/*     */     private long optBits;
/*     */     private String name;
/*     */     private Region region;
/*     */     private Image icon;
/*     */     private Guild.VerificationLevel verificationLevel;
/*     */     private Guild.NotificationLevel defaultMessageNotificationLevel;
/*     */     private Guild.ContentFilterLevel explicitContentFilter;
/* 674 */     private List<RoleCreateSpec> roles = new ArrayList<>();
/*     */     private RoleCreateSpec everyoneRole;
/* 676 */     private List<GuildCreateFields.PartialChannel> channels = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(GuildCreateSpec instance) {
/* 690 */       return from(instance);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     final Builder from(GuildCreateSpecGenerator instance) {
/* 700 */       Objects.requireNonNull(instance, "instance");
/* 701 */       name(instance.name());
/* 702 */       region(instance.region());
/* 703 */       Image iconValue = instance.icon();
/* 704 */       if (iconValue != null) {
/* 705 */         icon(iconValue);
/*     */       }
/* 707 */       verificationLevel(instance.verificationLevel());
/* 708 */       defaultMessageNotificationLevel(instance.defaultMessageNotificationLevel());
/* 709 */       explicitContentFilter(instance.explicitContentFilter());
/* 710 */       addAllRoles(instance.roles());
/* 711 */       RoleCreateSpec everyoneRoleValue = instance.everyoneRole();
/* 712 */       if (everyoneRoleValue != null) {
/* 713 */         everyoneRole(everyoneRoleValue);
/*     */       }
/* 715 */       addAllChannels(instance.channels());
/* 716 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder name(String name) {
/* 726 */       this.name = Objects.<String>requireNonNull(name, "name");
/* 727 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 728 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder region(Region region) {
/* 738 */       this.region = Objects.<Region>requireNonNull(region, "region");
/* 739 */       this.initBits &= 0xFFFFFFFFFFFFFFFDL;
/* 740 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder icon(@Nullable Image icon) {
/* 750 */       this.icon = icon;
/* 751 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder verificationLevel(Guild.VerificationLevel verificationLevel) {
/* 762 */       this.verificationLevel = Objects.<Guild.VerificationLevel>requireNonNull(verificationLevel, "verificationLevel");
/* 763 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder defaultMessageNotificationLevel(Guild.NotificationLevel defaultMessageNotificationLevel) {
/* 774 */       this.defaultMessageNotificationLevel = Objects.<Guild.NotificationLevel>requireNonNull(defaultMessageNotificationLevel, "defaultMessageNotificationLevel");
/* 775 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder explicitContentFilter(Guild.ContentFilterLevel explicitContentFilter) {
/* 786 */       this.explicitContentFilter = Objects.<Guild.ContentFilterLevel>requireNonNull(explicitContentFilter, "explicitContentFilter");
/* 787 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder addRole(RoleCreateSpec element) {
/* 797 */       this.roles.add(Objects.<RoleCreateSpec>requireNonNull(element, "roles element"));
/* 798 */       this.optBits |= 0x1L;
/* 799 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder addRoles(RoleCreateSpec... elements) {
/* 809 */       for (RoleCreateSpec element : elements) {
/* 810 */         this.roles.add(Objects.<RoleCreateSpec>requireNonNull(element, "roles element"));
/*     */       }
/* 812 */       this.optBits |= 0x1L;
/* 813 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder roles(Iterable<? extends RoleCreateSpec> elements) {
/* 824 */       this.roles.clear();
/* 825 */       return addAllRoles(elements);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder addAllRoles(Iterable<? extends RoleCreateSpec> elements) {
/* 835 */       for (RoleCreateSpec element : elements) {
/* 836 */         this.roles.add(Objects.<RoleCreateSpec>requireNonNull(element, "roles element"));
/*     */       }
/* 838 */       this.optBits |= 0x1L;
/* 839 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder everyoneRole(@Nullable RoleCreateSpec everyoneRole) {
/* 849 */       this.everyoneRole = everyoneRole;
/* 850 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder addChannel(GuildCreateFields.PartialChannel element) {
/* 860 */       element = ImmutableGuildCreateFields.PartialChannel.copyOf(element);
/* 861 */       this.channels.add(Objects.<GuildCreateFields.PartialChannel>requireNonNull(element, "channels element"));
/* 862 */       this.optBits |= 0x2L;
/* 863 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder addChannel(String name, Channel.Type type) {
/* 873 */       return addChannel(ImmutableGuildCreateFields.PartialChannel.of(name, type));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder addChannels(GuildCreateFields.PartialChannel... elements) {
/* 883 */       for (GuildCreateFields.PartialChannel element : elements) {
/* 884 */         element = ImmutableGuildCreateFields.PartialChannel.copyOf(element);
/* 885 */         this.channels.add(Objects.<GuildCreateFields.PartialChannel>requireNonNull(element, "channels element"));
/*     */       } 
/* 887 */       this.optBits |= 0x2L;
/* 888 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder channels(Iterable<? extends GuildCreateFields.PartialChannel> elements) {
/* 899 */       this.channels.clear();
/* 900 */       return addAllChannels(elements);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder addAllChannels(Iterable<? extends GuildCreateFields.PartialChannel> elements) {
/* 910 */       for (GuildCreateFields.PartialChannel element : elements) {
/* 911 */         element = ImmutableGuildCreateFields.PartialChannel.copyOf(element);
/* 912 */         this.channels.add(Objects.<GuildCreateFields.PartialChannel>requireNonNull(element, "channels element"));
/*     */       } 
/* 914 */       this.optBits |= 0x2L;
/* 915 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public GuildCreateSpec build() {
/* 924 */       if (this.initBits != 0L) {
/* 925 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 927 */       return new GuildCreateSpec(this);
/*     */     }
/*     */     
/*     */     private boolean rolesIsSet() {
/* 931 */       return ((this.optBits & 0x1L) != 0L);
/*     */     }
/*     */     
/*     */     private boolean channelsIsSet() {
/* 935 */       return ((this.optBits & 0x2L) != 0L);
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 939 */       List<String> attributes = new ArrayList<>();
/* 940 */       if ((this.initBits & 0x1L) != 0L) attributes.add("name"); 
/* 941 */       if ((this.initBits & 0x2L) != 0L) attributes.add("region"); 
/* 942 */       return "Cannot build GuildCreateSpec, some of required attributes are not set " + attributes;
/*     */     }
/*     */     private Builder() {} }
/*     */   
/*     */   private static <T> List<T> createSafeList(Iterable<? extends T> iterable, boolean checkNulls, boolean skipNulls) {
/*     */     ArrayList<T> list;
/* 948 */     if (iterable instanceof Collection) {
/* 949 */       int size = ((Collection)iterable).size();
/* 950 */       if (size == 0) return Collections.emptyList(); 
/* 951 */       list = new ArrayList<>();
/*     */     } else {
/* 953 */       list = new ArrayList<>();
/*     */     } 
/* 955 */     for (T element : iterable) {
/* 956 */       if (skipNulls && element == null)
/* 957 */         continue;  if (checkNulls) Objects.requireNonNull(element, "element"); 
/* 958 */       list.add(element);
/*     */     } 
/* 960 */     return list;
/*     */   }
/*     */   
/*     */   private static <T> List<T> createUnmodifiableList(boolean clone, List<T> list) {
/* 964 */     switch (list.size()) { case 0:
/* 965 */         return Collections.emptyList();
/* 966 */       case 1: return Collections.singletonList(list.get(0)); }
/*     */     
/* 968 */     if (clone) {
/* 969 */       return Collections.unmodifiableList(new ArrayList<>(list));
/*     */     }
/* 971 */     if (list instanceof ArrayList) {
/* 972 */       ((ArrayList)list).trimToSize();
/*     */     }
/* 974 */     return Collections.unmodifiableList(list);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\GuildCreateSpec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */