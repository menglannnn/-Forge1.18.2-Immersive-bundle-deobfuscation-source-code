/*    */ package discord4j.core.spec;
/*    */ 
/*    */ import discord4j.core.object.entity.Guild;
/*    */ import discord4j.core.object.entity.Role;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ import reactor.core.CoreSubscriber;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Immutable(builder = false)
/*    */ abstract class RoleCreateMonoGenerator
/*    */   extends Mono<Role>
/*    */   implements RoleCreateSpecGenerator
/*    */ {
/*    */   abstract Guild guild();
/*    */   
/*    */   public void subscribe(CoreSubscriber<? super Role> actual) {
/* 73 */     guild().createRole(RoleCreateSpec.copyOf(this)).subscribe(actual);
/*    */   }
/*    */   
/*    */   public abstract String toString();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\RoleCreateMonoGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */