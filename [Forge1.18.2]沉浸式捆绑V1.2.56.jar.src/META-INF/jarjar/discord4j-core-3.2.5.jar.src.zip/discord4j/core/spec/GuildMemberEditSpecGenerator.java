/*    */ package discord4j.core.spec;
/*    */ 
/*    */ import discord4j.common.util.Snowflake;
/*    */ import discord4j.discordjson.json.GuildMemberModifyRequest;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import java.time.Instant;
/*    */ import java.util.List;
/*    */ import java.util.Optional;
/*    */ import java.util.stream.Collectors;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Immutable(singleton = true)
/*    */ interface GuildMemberEditSpecGenerator
/*    */   extends AuditSpec<GuildMemberModifyRequest>
/*    */ {
/*    */   default GuildMemberModifyRequest asRequest() {
/* 54 */     return (GuildMemberModifyRequest)GuildMemberModifyRequest.builder()
/* 55 */       .channelId(InternalSpecUtils.mapPossibleOptional(newVoiceChannel(), Snowflake::asString))
/* 56 */       .mute(mute())
/* 57 */       .deaf(deafen())
/* 58 */       .nick(nickname())
/* 59 */       .roles(InternalSpecUtils.mapPossible(roles(), r -> (List)r.stream().map(Snowflake::asString).collect(Collectors.toList())))
/* 60 */       .communicationDisabledUntil(InternalSpecUtils.mapPossibleOptional(communicationDisabledUntil(), Instant::toString))
/* 61 */       .build();
/*    */   }
/*    */   
/*    */   Possible<Optional<Snowflake>> newVoiceChannel();
/*    */   
/*    */   Possible<Boolean> mute();
/*    */   
/*    */   Possible<Boolean> deafen();
/*    */   
/*    */   Possible<Optional<String>> nickname();
/*    */   
/*    */   Possible<List<Snowflake>> roles();
/*    */   
/*    */   Possible<Optional<Instant>> communicationDisabledUntil();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\GuildMemberEditSpecGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */