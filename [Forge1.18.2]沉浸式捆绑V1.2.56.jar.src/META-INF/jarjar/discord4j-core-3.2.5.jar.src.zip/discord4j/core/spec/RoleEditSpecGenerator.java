/*    */ package discord4j.core.spec;
/*    */ 
/*    */ import discord4j.discordjson.json.RoleModifyRequest;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import discord4j.rest.util.Color;
/*    */ import discord4j.rest.util.PermissionSet;
/*    */ import java.util.Optional;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Immutable(singleton = true)
/*    */ interface RoleEditSpecGenerator
/*    */   extends AuditSpec<RoleModifyRequest>
/*    */ {
/*    */   default RoleModifyRequest asRequest() {
/* 51 */     return (RoleModifyRequest)RoleModifyRequest.builder()
/* 52 */       .name(name())
/* 53 */       .permissions(InternalSpecUtils.mapPossible(permissions(), PermissionSet::getRawValue))
/* 54 */       .color(InternalSpecUtils.mapPossible(color(), Color::getRGB))
/* 55 */       .hoist(hoist())
/* 56 */       .mentionable(mentionable())
/* 57 */       .icon(icon())
/* 58 */       .unicodeEmoji(unicodeEmoji())
/* 59 */       .build();
/*    */   }
/*    */   
/*    */   Possible<Optional<String>> unicodeEmoji();
/*    */   
/*    */   Possible<Optional<String>> icon();
/*    */   
/*    */   Possible<Boolean> mentionable();
/*    */   
/*    */   Possible<Boolean> hoist();
/*    */   
/*    */   Possible<Color> color();
/*    */   
/*    */   Possible<PermissionSet> permissions();
/*    */   
/*    */   Possible<String> name();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\RoleEditSpecGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */