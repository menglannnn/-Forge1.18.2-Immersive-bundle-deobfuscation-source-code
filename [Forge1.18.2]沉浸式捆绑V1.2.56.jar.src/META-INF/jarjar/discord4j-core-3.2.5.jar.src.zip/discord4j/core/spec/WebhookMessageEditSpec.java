/*     */ package discord4j.core.spec;
/*     */ 
/*     */ import com.google.errorprone.annotations.CanIgnoreReturnValue;
/*     */ import discord4j.core.object.component.LayoutComponent;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import discord4j.rest.util.AllowedMentions;
/*     */ import java.io.InputStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.stream.StreamSupport;
/*     */ import org.immutables.value.Generated;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "WebhookMessageEditSpecGenerator", generator = "Immutables")
/*     */ public final class WebhookMessageEditSpec
/*     */   implements WebhookMessageEditSpecGenerator
/*     */ {
/*     */   private final String content_value;
/*     */   private final boolean content_absent;
/*     */   private final List<MessageCreateFields.File> files;
/*     */   private final List<MessageCreateFields.FileSpoiler> fileSpoilers;
/*     */   private final List<EmbedCreateSpec> embeds;
/*     */   private final AllowedMentions allowedMentions_value;
/*     */   private final boolean allowedMentions_absent;
/*     */   private final List<LayoutComponent> components_value;
/*     */   private final boolean components_absent;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   
/*     */   private WebhookMessageEditSpec() {
/*  44 */     Possible<Optional<String>> content$impl = Possible.absent();
/*  45 */     Possible<Optional<AllowedMentions>> allowedMentions$impl = Possible.absent();
/*  46 */     Possible<List<LayoutComponent>> components$impl = Possible.absent();
/*  47 */     this.content_value = Possible.flatOpt(content$impl).orElse(null);
/*  48 */     this.content_absent = content$impl.isAbsent();
/*  49 */     this.allowedMentions_value = Possible.flatOpt(allowedMentions$impl).orElse(null);
/*  50 */     this.allowedMentions_absent = allowedMentions$impl.isAbsent();
/*  51 */     this.components_value = components$impl.toOptional().orElse(null);
/*  52 */     this.components_absent = components$impl.isAbsent();
/*  53 */     this.files = this.initShim.files();
/*  54 */     this.fileSpoilers = this.initShim.fileSpoilers();
/*  55 */     this.embeds = this.initShim.embeds();
/*  56 */     this.initShim = null;
/*     */   }
/*     */   
/*     */   private WebhookMessageEditSpec(Builder builder) {
/*  60 */     Possible<Optional<String>> content$impl = builder.content_build();
/*  61 */     Possible<Optional<AllowedMentions>> allowedMentions$impl = builder.allowedMentions_build();
/*  62 */     Possible<List<LayoutComponent>> components$impl = builder.components_build();
/*  63 */     if (builder.filesIsSet()) {
/*  64 */       this.initShim.files(createUnmodifiableList(true, builder.files));
/*     */     }
/*  66 */     if (builder.fileSpoilersIsSet()) {
/*  67 */       this.initShim.fileSpoilers(createUnmodifiableList(true, builder.fileSpoilers));
/*     */     }
/*  69 */     if (builder.embedsIsSet()) {
/*  70 */       this.initShim.embeds(createUnmodifiableList(true, builder.embeds));
/*     */     }
/*  72 */     this.content_value = Possible.flatOpt(content$impl).orElse(null);
/*  73 */     this.content_absent = content$impl.isAbsent();
/*  74 */     this.allowedMentions_value = Possible.flatOpt(allowedMentions$impl).orElse(null);
/*  75 */     this.allowedMentions_absent = allowedMentions$impl.isAbsent();
/*  76 */     this.components_value = components$impl.toOptional().orElse(null);
/*  77 */     this.components_absent = components$impl.isAbsent();
/*  78 */     this.files = this.initShim.files();
/*  79 */     this.fileSpoilers = this.initShim.fileSpoilers();
/*  80 */     this.embeds = this.initShim.embeds();
/*  81 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private WebhookMessageEditSpec(Possible<Optional<String>> content, List<MessageCreateFields.File> files, List<MessageCreateFields.FileSpoiler> fileSpoilers, List<EmbedCreateSpec> embeds, Possible<Optional<AllowedMentions>> allowedMentions, Possible<List<LayoutComponent>> components) {
/*  91 */     Possible<Optional<String>> content$impl = content;
/*  92 */     this.initShim.files(files);
/*  93 */     this.initShim.fileSpoilers(fileSpoilers);
/*  94 */     this.initShim.embeds(embeds);
/*  95 */     Possible<Optional<AllowedMentions>> allowedMentions$impl = allowedMentions;
/*  96 */     Possible<List<LayoutComponent>> components$impl = components;
/*  97 */     this.content_value = Possible.flatOpt(content$impl).orElse(null);
/*  98 */     this.content_absent = content$impl.isAbsent();
/*  99 */     this.allowedMentions_value = Possible.flatOpt(allowedMentions$impl).orElse(null);
/* 100 */     this.allowedMentions_absent = allowedMentions$impl.isAbsent();
/* 101 */     this.components_value = components$impl.toOptional().orElse(null);
/* 102 */     this.components_absent = components$impl.isAbsent();
/* 103 */     this.files = this.initShim.files();
/* 104 */     this.fileSpoilers = this.initShim.fileSpoilers();
/* 105 */     this.embeds = this.initShim.embeds();
/* 106 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 112 */   private volatile transient InitShim initShim = new InitShim();
/*     */   
/*     */   @Generated(from = "WebhookMessageEditSpecGenerator", generator = "Immutables")
/*     */   private final class InitShim
/*     */   {
/* 117 */     private byte filesBuildStage = 0;
/*     */     private List<MessageCreateFields.File> files;
/*     */     
/*     */     List<MessageCreateFields.File> files() {
/* 121 */       if (this.filesBuildStage == -1) throw new IllegalStateException(formatInitCycleMessage()); 
/* 122 */       if (this.filesBuildStage == 0) {
/* 123 */         this.filesBuildStage = -1;
/* 124 */         this.files = (List)WebhookMessageEditSpec.createUnmodifiableList(false, WebhookMessageEditSpec.createSafeList((Iterable)WebhookMessageEditSpec.this.filesInitialize(), true, false));
/* 125 */         this.filesBuildStage = 1;
/*     */       } 
/* 127 */       return this.files;
/*     */     }
/*     */     
/*     */     void files(List<MessageCreateFields.File> files) {
/* 131 */       this.files = files;
/* 132 */       this.filesBuildStage = 1;
/*     */     }
/*     */     
/* 135 */     private byte fileSpoilersBuildStage = 0;
/*     */     private List<MessageCreateFields.FileSpoiler> fileSpoilers;
/*     */     
/*     */     List<MessageCreateFields.FileSpoiler> fileSpoilers() {
/* 139 */       if (this.fileSpoilersBuildStage == -1) throw new IllegalStateException(formatInitCycleMessage()); 
/* 140 */       if (this.fileSpoilersBuildStage == 0) {
/* 141 */         this.fileSpoilersBuildStage = -1;
/* 142 */         this.fileSpoilers = (List)WebhookMessageEditSpec.createUnmodifiableList(false, WebhookMessageEditSpec.createSafeList((Iterable)WebhookMessageEditSpec.this.fileSpoilersInitialize(), true, false));
/* 143 */         this.fileSpoilersBuildStage = 1;
/*     */       } 
/* 145 */       return this.fileSpoilers;
/*     */     }
/*     */     
/*     */     void fileSpoilers(List<MessageCreateFields.FileSpoiler> fileSpoilers) {
/* 149 */       this.fileSpoilers = fileSpoilers;
/* 150 */       this.fileSpoilersBuildStage = 1;
/*     */     }
/*     */     
/* 153 */     private byte embedsBuildStage = 0;
/*     */     private List<EmbedCreateSpec> embeds;
/*     */     
/*     */     List<EmbedCreateSpec> embeds() {
/* 157 */       if (this.embedsBuildStage == -1) throw new IllegalStateException(formatInitCycleMessage()); 
/* 158 */       if (this.embedsBuildStage == 0) {
/* 159 */         this.embedsBuildStage = -1;
/* 160 */         this.embeds = (List)WebhookMessageEditSpec.createUnmodifiableList(false, WebhookMessageEditSpec.createSafeList((Iterable)WebhookMessageEditSpec.this.embedsInitialize(), true, false));
/* 161 */         this.embedsBuildStage = 1;
/*     */       } 
/* 163 */       return this.embeds;
/*     */     }
/*     */     
/*     */     void embeds(List<EmbedCreateSpec> embeds) {
/* 167 */       this.embeds = embeds;
/* 168 */       this.embedsBuildStage = 1;
/*     */     }
/*     */     private InitShim() {}
/*     */     private String formatInitCycleMessage() {
/* 172 */       List<String> attributes = new ArrayList<>();
/* 173 */       if (this.filesBuildStage == -1) attributes.add("files"); 
/* 174 */       if (this.fileSpoilersBuildStage == -1) attributes.add("fileSpoilers"); 
/* 175 */       if (this.embedsBuildStage == -1) attributes.add("embeds"); 
/* 176 */       return "Cannot build WebhookMessageEditSpec, attribute initializers form cycle " + attributes;
/*     */     }
/*     */   }
/*     */   
/*     */   private List<MessageCreateFields.File> filesInitialize() {
/* 181 */     return super.files();
/*     */   }
/*     */   
/*     */   private List<MessageCreateFields.FileSpoiler> fileSpoilersInitialize() {
/* 185 */     return super.fileSpoilers();
/*     */   }
/*     */   
/*     */   private List<EmbedCreateSpec> embedsInitialize() {
/* 189 */     return super.embeds();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Optional<String>> content() {
/* 197 */     return this.content_absent ? Possible.absent() : 
/* 198 */       Possible.of(Optional.ofNullable(this.content_value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<MessageCreateFields.File> files() {
/* 206 */     InitShim shim = this.initShim;
/* 207 */     return (shim != null) ? 
/* 208 */       shim.files() : 
/* 209 */       this.files;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<MessageCreateFields.FileSpoiler> fileSpoilers() {
/* 217 */     InitShim shim = this.initShim;
/* 218 */     return (shim != null) ? 
/* 219 */       shim.fileSpoilers() : 
/* 220 */       this.fileSpoilers;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<EmbedCreateSpec> embeds() {
/* 228 */     InitShim shim = this.initShim;
/* 229 */     return (shim != null) ? 
/* 230 */       shim.embeds() : 
/* 231 */       this.embeds;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Optional<AllowedMentions>> allowedMentions() {
/* 239 */     return this.allowedMentions_absent ? Possible.absent() : 
/* 240 */       Possible.of(Optional.ofNullable(this.allowedMentions_value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<List<LayoutComponent>> components() {
/* 248 */     return this.components_absent ? Possible.absent() : 
/* 249 */       Possible.of(this.components_value);
/*     */   }
/*     */   
/*     */   public WebhookMessageEditSpec withContent(Possible<Optional<String>> value) {
/* 253 */     Possible<Optional<String>> newValue = Objects.<Possible<Optional<String>>>requireNonNull(value);
/* 254 */     return validate(new WebhookMessageEditSpec(newValue, this.files, this.fileSpoilers, this.embeds, allowedMentions(), components()));
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public WebhookMessageEditSpec withContent(@Nullable String value) {
/* 259 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/* 260 */     return validate(new WebhookMessageEditSpec(newValue, this.files, this.fileSpoilers, this.embeds, allowedMentions(), components()));
/*     */   }
/*     */   
/*     */   public WebhookMessageEditSpec withContentOrNull(@Nullable String value) {
/* 264 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/* 265 */     return validate(new WebhookMessageEditSpec(newValue, this.files, this.fileSpoilers, this.embeds, allowedMentions(), components()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final WebhookMessageEditSpec withFiles(MessageCreateFields.File... elements) {
/* 274 */     List<MessageCreateFields.File> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/* 275 */     return validate(new WebhookMessageEditSpec(
/* 276 */           content(), newValue, this.fileSpoilers, this.embeds, 
/*     */ 
/*     */ 
/*     */           
/* 280 */           allowedMentions(), 
/* 281 */           components()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final WebhookMessageEditSpec withFiles(Iterable<? extends MessageCreateFields.File> elements) {
/* 291 */     if (this.files == elements) return this; 
/* 292 */     List<MessageCreateFields.File> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/* 293 */     return validate(new WebhookMessageEditSpec(
/* 294 */           content(), newValue, this.fileSpoilers, this.embeds, 
/*     */ 
/*     */ 
/*     */           
/* 298 */           allowedMentions(), 
/* 299 */           components()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final WebhookMessageEditSpec withFileSpoilers(MessageCreateFields.FileSpoiler... elements) {
/* 308 */     List<MessageCreateFields.FileSpoiler> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/* 309 */     return validate(new WebhookMessageEditSpec(content(), this.files, newValue, this.embeds, allowedMentions(), components()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final WebhookMessageEditSpec withFileSpoilers(Iterable<? extends MessageCreateFields.FileSpoiler> elements) {
/* 319 */     if (this.fileSpoilers == elements) return this; 
/* 320 */     List<MessageCreateFields.FileSpoiler> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/* 321 */     return validate(new WebhookMessageEditSpec(content(), this.files, newValue, this.embeds, allowedMentions(), components()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final WebhookMessageEditSpec withEmbeds(EmbedCreateSpec... elements) {
/* 330 */     List<EmbedCreateSpec> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/* 331 */     return validate(new WebhookMessageEditSpec(
/* 332 */           content(), this.files, this.fileSpoilers, newValue, 
/*     */ 
/*     */ 
/*     */           
/* 336 */           allowedMentions(), 
/* 337 */           components()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final WebhookMessageEditSpec withEmbeds(Iterable<? extends EmbedCreateSpec> elements) {
/* 347 */     if (this.embeds == elements) return this; 
/* 348 */     List<EmbedCreateSpec> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/* 349 */     return validate(new WebhookMessageEditSpec(
/* 350 */           content(), this.files, this.fileSpoilers, newValue, 
/*     */ 
/*     */ 
/*     */           
/* 354 */           allowedMentions(), 
/* 355 */           components()));
/*     */   }
/*     */   
/*     */   public WebhookMessageEditSpec withAllowedMentions(Possible<Optional<AllowedMentions>> value) {
/* 359 */     Possible<Optional<AllowedMentions>> newValue = Objects.<Possible<Optional<AllowedMentions>>>requireNonNull(value);
/* 360 */     return validate(new WebhookMessageEditSpec(content(), this.files, this.fileSpoilers, this.embeds, newValue, components()));
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public WebhookMessageEditSpec withAllowedMentions(@Nullable AllowedMentions value) {
/* 365 */     Possible<Optional<AllowedMentions>> newValue = Possible.of(Optional.ofNullable(value));
/* 366 */     return validate(new WebhookMessageEditSpec(content(), this.files, this.fileSpoilers, this.embeds, newValue, components()));
/*     */   }
/*     */   
/*     */   public WebhookMessageEditSpec withAllowedMentionsOrNull(@Nullable AllowedMentions value) {
/* 370 */     Possible<Optional<AllowedMentions>> newValue = Possible.of(Optional.ofNullable(value));
/* 371 */     return validate(new WebhookMessageEditSpec(content(), this.files, this.fileSpoilers, this.embeds, newValue, components()));
/*     */   }
/*     */   
/*     */   public WebhookMessageEditSpec withComponents(Possible<List<LayoutComponent>> possible) {
/* 375 */     Possible<List<LayoutComponent>> newValue = Objects.<Possible<List<LayoutComponent>>>requireNonNull(possible);
/* 376 */     return validate(new WebhookMessageEditSpec(content(), this.files, this.fileSpoilers, this.embeds, allowedMentions(), newValue));
/*     */   }
/*     */   
/*     */   public WebhookMessageEditSpec withComponents(Iterable<LayoutComponent> elements) {
/* 380 */     Possible<List<LayoutComponent>> newValue = Possible.of(
/* 381 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/* 382 */     return validate(new WebhookMessageEditSpec(content(), this.files, this.fileSpoilers, this.embeds, allowedMentions(), newValue));
/*     */   }
/*     */   
/*     */   @SafeVarargs
/*     */   public final WebhookMessageEditSpec withComponents(LayoutComponent... elements) {
/* 387 */     Possible<List<LayoutComponent>> newValue = Possible.of(Arrays.asList(elements));
/* 388 */     return validate(new WebhookMessageEditSpec(content(), this.files, this.fileSpoilers, this.embeds, allowedMentions(), newValue));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 397 */     if (this == another) return true; 
/* 398 */     return (another instanceof WebhookMessageEditSpec && 
/* 399 */       equalTo(0, (WebhookMessageEditSpec)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, WebhookMessageEditSpec another) {
/* 403 */     return (content().equals(another.content()) && this.files
/* 404 */       .equals(another.files) && this.fileSpoilers
/* 405 */       .equals(another.fileSpoilers) && this.embeds
/* 406 */       .equals(another.embeds) && 
/* 407 */       allowedMentions().equals(another.allowedMentions()) && 
/* 408 */       Objects.equals(this.components_value, another.components_value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 417 */     int h = 5381;
/* 418 */     h += (h << 5) + content().hashCode();
/* 419 */     h += (h << 5) + this.files.hashCode();
/* 420 */     h += (h << 5) + this.fileSpoilers.hashCode();
/* 421 */     h += (h << 5) + this.embeds.hashCode();
/* 422 */     h += (h << 5) + allowedMentions().hashCode();
/* 423 */     h += (h << 5) + Objects.hashCode(this.components_value);
/* 424 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 433 */     return "WebhookMessageEditSpec{content=" + 
/* 434 */       content().toString() + ", files=" + this.files + ", fileSpoilers=" + this.fileSpoilers + ", embeds=" + this.embeds + ", allowedMentions=" + 
/*     */ 
/*     */ 
/*     */       
/* 438 */       allowedMentions().toString() + ", components=" + 
/* 439 */       Objects.toString(this.components_value) + "}";
/*     */   }
/*     */ 
/*     */   
/* 443 */   private static final WebhookMessageEditSpec INSTANCE = validate(new WebhookMessageEditSpec());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static WebhookMessageEditSpec create() {
/* 450 */     return INSTANCE;
/*     */   }
/*     */   
/*     */   private static WebhookMessageEditSpec validate(WebhookMessageEditSpec instance) {
/* 454 */     return (INSTANCE != null && INSTANCE.equalTo(0, instance)) ? INSTANCE : instance;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static WebhookMessageEditSpec copyOf(WebhookMessageEditSpecGenerator instance) {
/* 465 */     if (instance instanceof WebhookMessageEditSpec) {
/* 466 */       return (WebhookMessageEditSpec)instance;
/*     */     }
/* 468 */     return builder()
/* 469 */       .from(instance)
/* 470 */       .build();
/*     */   }
/*     */   
/*     */   public boolean isContentPresent() {
/* 474 */     return !this.content_absent;
/*     */   }
/*     */   
/*     */   public String contentOrElse(String defaultValue) {
/* 478 */     return !this.content_absent ? this.content_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isAllowedMentionsPresent() {
/* 482 */     return !this.allowedMentions_absent;
/*     */   }
/*     */   
/*     */   public AllowedMentions allowedMentionsOrElse(AllowedMentions defaultValue) {
/* 486 */     return !this.allowedMentions_absent ? this.allowedMentions_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isComponentsPresent() {
/* 490 */     return !this.components_absent;
/*     */   }
/*     */   
/*     */   public List<LayoutComponent> componentsOrElse(List<LayoutComponent> defaultValue) {
/* 494 */     return !this.components_absent ? this.components_value : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 512 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "WebhookMessageEditSpecGenerator", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long OPT_BIT_FILES = 1L;
/*     */ 
/*     */     
/*     */     private static final long OPT_BIT_FILE_SPOILERS = 2L;
/*     */     
/*     */     private static final long OPT_BIT_EMBEDS = 4L;
/*     */     
/*     */     private long optBits;
/*     */     
/* 529 */     private Possible<Optional<String>> content_possible = Possible.absent();
/* 530 */     private Possible<Optional<AllowedMentions>> allowedMentions_possible = Possible.absent();
/* 531 */     private List<LayoutComponent> components_list = null;
/* 532 */     private List<MessageCreateFields.File> files = new ArrayList<>();
/* 533 */     private List<MessageCreateFields.FileSpoiler> fileSpoilers = new ArrayList<>();
/* 534 */     private List<EmbedCreateSpec> embeds = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder from(WebhookMessageEditSpecGenerator instance) {
/* 549 */       Objects.requireNonNull(instance, "instance");
/* 550 */       content(instance.content());
/* 551 */       addAllFiles(instance.files());
/* 552 */       addAllFileSpoilers(instance.fileSpoilers());
/* 553 */       addAllEmbeds(instance.embeds());
/* 554 */       allowedMentions(instance.allowedMentions());
/* 555 */       components(instance.components());
/* 556 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder content(Possible<Optional<String>> value) {
/* 561 */       this.content_possible = value;
/* 562 */       return this;
/*     */     }
/*     */     
/*     */     @Deprecated
/*     */     @CanIgnoreReturnValue
/*     */     public Builder content(@Nullable String value) {
/* 568 */       this.content_possible = Possible.of(Optional.ofNullable(value));
/* 569 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder contentOrNull(@Nullable String value) {
/* 574 */       this.content_possible = Possible.of(Optional.ofNullable(value));
/* 575 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder addFile(MessageCreateFields.File element) {
/* 585 */       element = ImmutableMessageCreateFields.File.copyOf(element);
/* 586 */       this.files.add(Objects.<MessageCreateFields.File>requireNonNull(element, "files element"));
/* 587 */       this.optBits |= 0x1L;
/* 588 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder addFile(String name, InputStream inputStream) {
/* 598 */       return addFile(ImmutableMessageCreateFields.File.of(name, inputStream));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder addFiles(MessageCreateFields.File... elements) {
/* 608 */       for (MessageCreateFields.File element : elements) {
/* 609 */         element = ImmutableMessageCreateFields.File.copyOf(element);
/* 610 */         this.files.add(Objects.<MessageCreateFields.File>requireNonNull(element, "files element"));
/*     */       } 
/* 612 */       this.optBits |= 0x1L;
/* 613 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder files(Iterable<? extends MessageCreateFields.File> elements) {
/* 624 */       this.files.clear();
/* 625 */       return addAllFiles(elements);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder addAllFiles(Iterable<? extends MessageCreateFields.File> elements) {
/* 635 */       for (MessageCreateFields.File element : elements) {
/* 636 */         element = ImmutableMessageCreateFields.File.copyOf(element);
/* 637 */         this.files.add(Objects.<MessageCreateFields.File>requireNonNull(element, "files element"));
/*     */       } 
/* 639 */       this.optBits |= 0x1L;
/* 640 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder addFileSpoiler(MessageCreateFields.FileSpoiler element) {
/* 650 */       element = ImmutableMessageCreateFields.FileSpoiler.copyOf(element);
/* 651 */       this.fileSpoilers.add(Objects.<MessageCreateFields.FileSpoiler>requireNonNull(element, "fileSpoilers element"));
/* 652 */       this.optBits |= 0x2L;
/* 653 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder addFileSpoiler(String name, InputStream inputStream) {
/* 663 */       return addFileSpoiler(ImmutableMessageCreateFields.FileSpoiler.of(name, inputStream));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder addFileSpoilers(MessageCreateFields.FileSpoiler... elements) {
/* 673 */       for (MessageCreateFields.FileSpoiler element : elements) {
/* 674 */         element = ImmutableMessageCreateFields.FileSpoiler.copyOf(element);
/* 675 */         this.fileSpoilers.add(Objects.<MessageCreateFields.FileSpoiler>requireNonNull(element, "fileSpoilers element"));
/*     */       } 
/* 677 */       this.optBits |= 0x2L;
/* 678 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder fileSpoilers(Iterable<? extends MessageCreateFields.FileSpoiler> elements) {
/* 689 */       this.fileSpoilers.clear();
/* 690 */       return addAllFileSpoilers(elements);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder addAllFileSpoilers(Iterable<? extends MessageCreateFields.FileSpoiler> elements) {
/* 700 */       for (MessageCreateFields.FileSpoiler element : elements) {
/* 701 */         element = ImmutableMessageCreateFields.FileSpoiler.copyOf(element);
/* 702 */         this.fileSpoilers.add(Objects.<MessageCreateFields.FileSpoiler>requireNonNull(element, "fileSpoilers element"));
/*     */       } 
/* 704 */       this.optBits |= 0x2L;
/* 705 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder addEmbed(EmbedCreateSpec element) {
/* 715 */       this.embeds.add(Objects.<EmbedCreateSpec>requireNonNull(element, "embeds element"));
/* 716 */       this.optBits |= 0x4L;
/* 717 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder addEmbeds(EmbedCreateSpec... elements) {
/* 727 */       for (EmbedCreateSpec element : elements) {
/* 728 */         this.embeds.add(Objects.<EmbedCreateSpec>requireNonNull(element, "embeds element"));
/*     */       }
/* 730 */       this.optBits |= 0x4L;
/* 731 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder embeds(Iterable<? extends EmbedCreateSpec> elements) {
/* 742 */       this.embeds.clear();
/* 743 */       return addAllEmbeds(elements);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder addAllEmbeds(Iterable<? extends EmbedCreateSpec> elements) {
/* 753 */       for (EmbedCreateSpec element : elements) {
/* 754 */         this.embeds.add(Objects.<EmbedCreateSpec>requireNonNull(element, "embeds element"));
/*     */       }
/* 756 */       this.optBits |= 0x4L;
/* 757 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder allowedMentions(Possible<Optional<AllowedMentions>> value) {
/* 762 */       this.allowedMentions_possible = value;
/* 763 */       return this;
/*     */     }
/*     */     
/*     */     @Deprecated
/*     */     @CanIgnoreReturnValue
/*     */     public Builder allowedMentions(@Nullable AllowedMentions value) {
/* 769 */       this.allowedMentions_possible = Possible.of(Optional.ofNullable(value));
/* 770 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder allowedMentionsOrNull(@Nullable AllowedMentions value) {
/* 775 */       this.allowedMentions_possible = Possible.of(Optional.ofNullable(value));
/* 776 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder addComponent(LayoutComponent element) {
/* 781 */       components_getOrCreate().add(element);
/* 782 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder addAllComponents(List<LayoutComponent> elements) {
/* 787 */       components_getOrCreate().addAll(elements);
/* 788 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder components(Possible<List<LayoutComponent>> elements) {
/* 793 */       this.components_list = null;
/* 794 */       elements.toOptional().ifPresent(e -> components_getOrCreate().addAll(e));
/* 795 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder components(List<LayoutComponent> elements) {
/* 800 */       this.components_list = new ArrayList<>(elements);
/* 801 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder components(Iterable<LayoutComponent> elements) {
/* 806 */       this.components_list = (List<LayoutComponent>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/* 807 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public WebhookMessageEditSpec build() {
/* 816 */       return WebhookMessageEditSpec.validate(new WebhookMessageEditSpec(this));
/*     */     }
/*     */     
/*     */     private boolean filesIsSet() {
/* 820 */       return ((this.optBits & 0x1L) != 0L);
/*     */     }
/*     */     
/*     */     private boolean fileSpoilersIsSet() {
/* 824 */       return ((this.optBits & 0x2L) != 0L);
/*     */     }
/*     */     
/*     */     private boolean embedsIsSet() {
/* 828 */       return ((this.optBits & 0x4L) != 0L);
/*     */     }
/*     */     
/*     */     private Possible<Optional<String>> content_build() {
/* 832 */       return this.content_possible;
/*     */     }
/*     */     
/*     */     private Possible<Optional<AllowedMentions>> allowedMentions_build() {
/* 836 */       return this.allowedMentions_possible;
/*     */     }
/*     */     
/*     */     private Possible<List<LayoutComponent>> components_build() {
/* 840 */       return (this.components_list == null) ? Possible.absent() : 
/* 841 */         Possible.of(this.components_list);
/*     */     }
/*     */     
/*     */     private List<LayoutComponent> components_getOrCreate() {
/* 845 */       if (this.components_list == null) {
/* 846 */         this.components_list = new ArrayList<>();
/*     */       }
/* 848 */       return this.components_list;
/*     */     }
/*     */     private Builder() {} }
/*     */   
/*     */   private static <T> List<T> createSafeList(Iterable<? extends T> iterable, boolean checkNulls, boolean skipNulls) {
/*     */     ArrayList<T> list;
/* 854 */     if (iterable instanceof Collection) {
/* 855 */       int size = ((Collection)iterable).size();
/* 856 */       if (size == 0) return Collections.emptyList(); 
/* 857 */       list = new ArrayList<>();
/*     */     } else {
/* 859 */       list = new ArrayList<>();
/*     */     } 
/* 861 */     for (T element : iterable) {
/* 862 */       if (skipNulls && element == null)
/* 863 */         continue;  if (checkNulls) Objects.requireNonNull(element, "element"); 
/* 864 */       list.add(element);
/*     */     } 
/* 866 */     return list;
/*     */   }
/*     */   
/*     */   private static <T> List<T> createUnmodifiableList(boolean clone, List<T> list) {
/* 870 */     switch (list.size()) { case 0:
/* 871 */         return Collections.emptyList();
/* 872 */       case 1: return Collections.singletonList(list.get(0)); }
/*     */     
/* 874 */     if (clone) {
/* 875 */       return Collections.unmodifiableList(new ArrayList<>(list));
/*     */     }
/* 877 */     if (list instanceof ArrayList) {
/* 878 */       ((ArrayList)list).trimToSize();
/*     */     }
/* 880 */     return Collections.unmodifiableList(list);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\WebhookMessageEditSpec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */