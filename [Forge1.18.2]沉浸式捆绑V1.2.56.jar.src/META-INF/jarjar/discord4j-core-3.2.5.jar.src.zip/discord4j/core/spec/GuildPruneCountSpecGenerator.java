/*    */ package discord4j.core.spec;
/*    */ 
/*    */ import discord4j.common.util.Snowflake;
/*    */ import discord4j.rest.util.Multimap;
/*    */ import java.util.List;
/*    */ import java.util.Set;
/*    */ import java.util.stream.Collectors;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Immutable
/*    */ interface GuildPruneCountSpecGenerator
/*    */   extends Spec<Multimap<String, Object>>
/*    */ {
/*    */   default Multimap<String, Object> asRequest() {
/* 44 */     Multimap<String, Object> map = new Multimap();
/* 45 */     InternalSpecUtils.setIfNotNull(map, "days", days());
/* 46 */     InternalSpecUtils.addAllIfNotNull(map, "include_roles", InternalSpecUtils.<Set<Snowflake>, List<Object>>mapNullable(roles(), r -> (List)r.stream().map(Snowflake::asString).collect(Collectors.toList())));
/*    */ 
/*    */     
/* 49 */     return map;
/*    */   }
/*    */   
/*    */   Integer days();
/*    */   
/*    */   @Nullable
/*    */   Set<Snowflake> roles();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\GuildPruneCountSpecGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */