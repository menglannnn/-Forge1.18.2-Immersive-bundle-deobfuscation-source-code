/*     */ package discord4j.core.spec;
/*     */ 
/*     */ import discord4j.core.event.domain.interaction.ComponentInteractionEvent;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ import reactor.core.CoreSubscriber;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "InteractionCallbackSpecDeferEditMonoGenerator", generator = "Immutables")
/*     */ public final class InteractionCallbackSpecDeferEditMono
/*     */   extends InteractionCallbackSpecDeferEditMonoGenerator
/*     */ {
/*     */   private final Boolean ephemeral_value;
/*     */   private final boolean ephemeral_absent;
/*     */   private final ComponentInteractionEvent event;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   private volatile transient InitShim initShim;
/*     */   
/*     */   private InteractionCallbackSpecDeferEditMono(ComponentInteractionEvent event) {
/*  47 */     this.initShim = new InitShim(); this.event = Objects.<ComponentInteractionEvent>requireNonNull(event, "event"); Possible<Boolean> ephemeral$impl = Possible.absent(); this.ephemeral_value = ephemeral$impl.toOptional().orElse(null); this.ephemeral_absent = ephemeral$impl.isAbsent(); this.initShim = null; } private InteractionCallbackSpecDeferEditMono(Possible<Boolean> ephemeral, ComponentInteractionEvent event) { this.initShim = new InitShim();
/*     */     Possible<Boolean> ephemeral$impl = ephemeral;
/*     */     this.event = event;
/*     */     this.ephemeral_value = ephemeral$impl.toOptional().orElse(null);
/*     */     this.ephemeral_absent = ephemeral$impl.isAbsent();
/*     */     this.initShim = null; } @Generated(from = "InteractionCallbackSpecDeferEditMonoGenerator", generator = "Immutables")
/*  53 */   private final class InitShim { private InitShim() {} private String formatInitCycleMessage() { List<String> attributes = new ArrayList<>();
/*  54 */       return "Cannot build InteractionCallbackSpecDeferEditMono, attribute initializers form cycle " + attributes; }
/*     */      }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Boolean> ephemeral() {
/*  63 */     return this.ephemeral_absent ? Possible.absent() : Possible.of(this.ephemeral_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ComponentInteractionEvent event() {
/*  71 */     return this.event;
/*     */   }
/*     */   
/*     */   public InteractionCallbackSpecDeferEditMono withEphemeral(Possible<Boolean> value) {
/*  75 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/*  76 */     return new InteractionCallbackSpecDeferEditMono(newValue, this.event);
/*     */   }
/*     */   
/*     */   public InteractionCallbackSpecDeferEditMono withEphemeral(Boolean value) {
/*  80 */     Possible<Boolean> newValue = Possible.of(value);
/*  81 */     return new InteractionCallbackSpecDeferEditMono(newValue, this.event);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final InteractionCallbackSpecDeferEditMono withEvent(ComponentInteractionEvent value) {
/*  91 */     if (this.event == value) return this; 
/*  92 */     ComponentInteractionEvent newValue = Objects.<ComponentInteractionEvent>requireNonNull(value, "event");
/*  93 */     return new InteractionCallbackSpecDeferEditMono(ephemeral(), newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 102 */     if (this == another) return true; 
/* 103 */     return (another instanceof InteractionCallbackSpecDeferEditMono && 
/* 104 */       equalTo(0, (InteractionCallbackSpecDeferEditMono)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, InteractionCallbackSpecDeferEditMono another) {
/* 108 */     return (ephemeral().equals(another.ephemeral()) && this.event
/* 109 */       .equals(another.event));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 118 */     int h = 5381;
/* 119 */     h += (h << 5) + ephemeral().hashCode();
/* 120 */     h += (h << 5) + this.event.hashCode();
/* 121 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 130 */     return "InteractionCallbackSpecDeferEditMono{ephemeral=" + 
/* 131 */       ephemeral().toString() + ", event=" + this.event + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static InteractionCallbackSpecDeferEditMono of(ComponentInteractionEvent event) {
/* 142 */     return new InteractionCallbackSpecDeferEditMono(event);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static InteractionCallbackSpecDeferEditMono copyOf(InteractionCallbackSpecDeferEditMonoGenerator instance) {
/* 153 */     if (instance instanceof InteractionCallbackSpecDeferEditMono) {
/* 154 */       return (InteractionCallbackSpecDeferEditMono)instance;
/*     */     }
/* 156 */     return of(instance.event())
/* 157 */       .withEphemeral(instance.ephemeral());
/*     */   }
/*     */   
/*     */   public boolean isEphemeralPresent() {
/* 161 */     return !this.ephemeral_absent;
/*     */   }
/*     */   
/*     */   public Boolean ephemeralOrElse(Boolean defaultValue) {
/* 165 */     return !this.ephemeral_absent ? this.ephemeral_value : defaultValue;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\InteractionCallbackSpecDeferEditMono.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */