/*    */ package discord4j.core.spec;
/*    */ 
/*    */ import discord4j.discordjson.json.TemplateCreateGuildRequest;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import discord4j.rest.util.Image;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Immutable
/*    */ interface GuildCreateFromTemplateSpecGenerator
/*    */   extends Spec<TemplateCreateGuildRequest>
/*    */ {
/*    */   default TemplateCreateGuildRequest asRequest() {
/* 40 */     return (TemplateCreateGuildRequest)TemplateCreateGuildRequest.builder()
/* 41 */       .name(name())
/* 42 */       .icon(InternalSpecUtils.mapPossible(icon(), Image::getDataUri))
/* 43 */       .build();
/*    */   }
/*    */   
/*    */   Possible<Image> icon();
/*    */   
/*    */   String name();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\GuildCreateFromTemplateSpecGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */