/*     */ package discord4j.core.spec;
/*     */ 
/*     */ import com.google.errorprone.annotations.CanIgnoreReturnValue;
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.object.Invite;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "InviteCreateSpecGenerator", generator = "Immutables")
/*     */ public final class InviteCreateSpec
/*     */   implements InviteCreateSpecGenerator
/*     */ {
/*     */   @Nullable
/*     */   private final String reason;
/*     */   private final Integer maxAge_value;
/*     */   private final boolean maxAge_absent;
/*     */   private final Integer maxUses_value;
/*     */   private final boolean maxUses_absent;
/*     */   private final Boolean temporary_value;
/*     */   private final boolean temporary_absent;
/*     */   private final Boolean unique_value;
/*     */   private final boolean unique_absent;
/*     */   private final Invite.Type targetType_value;
/*     */   private final boolean targetType_absent;
/*     */   private final Snowflake targetUserId_value;
/*     */   private final boolean targetUserId_absent;
/*     */   private final Snowflake targetApplicationId_value;
/*     */   private final boolean targetApplicationId_absent;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   
/*     */   private InviteCreateSpec() {
/*  43 */     this.reason = null;
/*  44 */     Possible<Integer> maxAge$impl = Possible.absent();
/*  45 */     Possible<Integer> maxUses$impl = Possible.absent();
/*  46 */     Possible<Boolean> temporary$impl = Possible.absent();
/*  47 */     Possible<Boolean> unique$impl = Possible.absent();
/*  48 */     Possible<Invite.Type> targetType$impl = Possible.absent();
/*  49 */     Possible<Snowflake> targetUserId$impl = Possible.absent();
/*  50 */     Possible<Snowflake> targetApplicationId$impl = Possible.absent();
/*  51 */     this.maxAge_value = maxAge$impl.toOptional().orElse(null);
/*  52 */     this.maxAge_absent = maxAge$impl.isAbsent();
/*  53 */     this.maxUses_value = maxUses$impl.toOptional().orElse(null);
/*  54 */     this.maxUses_absent = maxUses$impl.isAbsent();
/*  55 */     this.temporary_value = temporary$impl.toOptional().orElse(null);
/*  56 */     this.temporary_absent = temporary$impl.isAbsent();
/*  57 */     this.unique_value = unique$impl.toOptional().orElse(null);
/*  58 */     this.unique_absent = unique$impl.isAbsent();
/*  59 */     this.targetType_value = targetType$impl.toOptional().orElse(null);
/*  60 */     this.targetType_absent = targetType$impl.isAbsent();
/*  61 */     this.targetUserId_value = targetUserId$impl.toOptional().orElse(null);
/*  62 */     this.targetUserId_absent = targetUserId$impl.isAbsent();
/*  63 */     this.targetApplicationId_value = targetApplicationId$impl.toOptional().orElse(null);
/*  64 */     this.targetApplicationId_absent = targetApplicationId$impl.isAbsent();
/*  65 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private InviteCreateSpec(@Nullable String reason, Possible<Integer> maxAge, Possible<Integer> maxUses, Possible<Boolean> temporary, Possible<Boolean> unique, Possible<Invite.Type> targetType, Possible<Snowflake> targetUserId, Possible<Snowflake> targetApplicationId) {
/*  77 */     this.reason = reason;
/*  78 */     Possible<Integer> maxAge$impl = maxAge;
/*  79 */     Possible<Integer> maxUses$impl = maxUses;
/*  80 */     Possible<Boolean> temporary$impl = temporary;
/*  81 */     Possible<Boolean> unique$impl = unique;
/*  82 */     Possible<Invite.Type> targetType$impl = targetType;
/*  83 */     Possible<Snowflake> targetUserId$impl = targetUserId;
/*  84 */     Possible<Snowflake> targetApplicationId$impl = targetApplicationId;
/*  85 */     this.maxAge_value = maxAge$impl.toOptional().orElse(null);
/*  86 */     this.maxAge_absent = maxAge$impl.isAbsent();
/*  87 */     this.maxUses_value = maxUses$impl.toOptional().orElse(null);
/*  88 */     this.maxUses_absent = maxUses$impl.isAbsent();
/*  89 */     this.temporary_value = temporary$impl.toOptional().orElse(null);
/*  90 */     this.temporary_absent = temporary$impl.isAbsent();
/*  91 */     this.unique_value = unique$impl.toOptional().orElse(null);
/*  92 */     this.unique_absent = unique$impl.isAbsent();
/*  93 */     this.targetType_value = targetType$impl.toOptional().orElse(null);
/*  94 */     this.targetType_absent = targetType$impl.isAbsent();
/*  95 */     this.targetUserId_value = targetUserId$impl.toOptional().orElse(null);
/*  96 */     this.targetUserId_absent = targetUserId$impl.isAbsent();
/*  97 */     this.targetApplicationId_value = targetApplicationId$impl.toOptional().orElse(null);
/*  98 */     this.targetApplicationId_absent = targetApplicationId$impl.isAbsent();
/*  99 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 105 */   private volatile transient InitShim initShim = new InitShim();
/*     */   
/*     */   @Generated(from = "InviteCreateSpecGenerator", generator = "Immutables")
/*     */   private final class InitShim
/*     */   {
/*     */     private String formatInitCycleMessage() {
/* 111 */       List<String> attributes = new ArrayList<>();
/* 112 */       return "Cannot build InviteCreateSpec, attribute initializers form cycle " + attributes;
/*     */     }
/*     */ 
/*     */     
/*     */     private InitShim() {}
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String reason() {
/* 122 */     return this.reason;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Integer> maxAge() {
/* 130 */     return this.maxAge_absent ? Possible.absent() : Possible.of(this.maxAge_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Integer> maxUses() {
/* 138 */     return this.maxUses_absent ? Possible.absent() : Possible.of(this.maxUses_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Boolean> temporary() {
/* 146 */     return this.temporary_absent ? Possible.absent() : Possible.of(this.temporary_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Boolean> unique() {
/* 154 */     return this.unique_absent ? Possible.absent() : Possible.of(this.unique_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Invite.Type> targetType() {
/* 162 */     return this.targetType_absent ? Possible.absent() : Possible.of(this.targetType_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Snowflake> targetUserId() {
/* 170 */     return this.targetUserId_absent ? Possible.absent() : Possible.of(this.targetUserId_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Snowflake> targetApplicationId() {
/* 178 */     return this.targetApplicationId_absent ? Possible.absent() : Possible.of(this.targetApplicationId_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final InviteCreateSpec withReason(@Nullable String value) {
/* 188 */     if (Objects.equals(this.reason, value)) return this; 
/* 189 */     return validate(new InviteCreateSpec(value, 
/*     */           
/* 191 */           maxAge(), 
/* 192 */           maxUses(), 
/* 193 */           temporary(), 
/* 194 */           unique(), 
/* 195 */           targetType(), 
/* 196 */           targetUserId(), 
/* 197 */           targetApplicationId()));
/*     */   }
/*     */   
/*     */   public InviteCreateSpec withMaxAge(Possible<Integer> value) {
/* 201 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/* 202 */     return validate(new InviteCreateSpec(this.reason, newValue, 
/*     */ 
/*     */           
/* 205 */           maxUses(), 
/* 206 */           temporary(), 
/* 207 */           unique(), 
/* 208 */           targetType(), 
/* 209 */           targetUserId(), 
/* 210 */           targetApplicationId()));
/*     */   }
/*     */   
/*     */   public InviteCreateSpec withMaxAge(Integer value) {
/* 214 */     Possible<Integer> newValue = Possible.of(value);
/* 215 */     return validate(new InviteCreateSpec(this.reason, newValue, 
/*     */ 
/*     */           
/* 218 */           maxUses(), 
/* 219 */           temporary(), 
/* 220 */           unique(), 
/* 221 */           targetType(), 
/* 222 */           targetUserId(), 
/* 223 */           targetApplicationId()));
/*     */   }
/*     */   
/*     */   public InviteCreateSpec withMaxUses(Possible<Integer> value) {
/* 227 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/* 228 */     return validate(new InviteCreateSpec(this.reason, 
/*     */           
/* 230 */           maxAge(), newValue, 
/*     */           
/* 232 */           temporary(), 
/* 233 */           unique(), 
/* 234 */           targetType(), 
/* 235 */           targetUserId(), 
/* 236 */           targetApplicationId()));
/*     */   }
/*     */   
/*     */   public InviteCreateSpec withMaxUses(Integer value) {
/* 240 */     Possible<Integer> newValue = Possible.of(value);
/* 241 */     return validate(new InviteCreateSpec(this.reason, 
/*     */           
/* 243 */           maxAge(), newValue, 
/*     */           
/* 245 */           temporary(), 
/* 246 */           unique(), 
/* 247 */           targetType(), 
/* 248 */           targetUserId(), 
/* 249 */           targetApplicationId()));
/*     */   }
/*     */   
/*     */   public InviteCreateSpec withTemporary(Possible<Boolean> value) {
/* 253 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/* 254 */     return validate(new InviteCreateSpec(this.reason, 
/*     */           
/* 256 */           maxAge(), 
/* 257 */           maxUses(), newValue, 
/*     */           
/* 259 */           unique(), 
/* 260 */           targetType(), 
/* 261 */           targetUserId(), 
/* 262 */           targetApplicationId()));
/*     */   }
/*     */   
/*     */   public InviteCreateSpec withTemporary(Boolean value) {
/* 266 */     Possible<Boolean> newValue = Possible.of(value);
/* 267 */     return validate(new InviteCreateSpec(this.reason, 
/*     */           
/* 269 */           maxAge(), 
/* 270 */           maxUses(), newValue, 
/*     */           
/* 272 */           unique(), 
/* 273 */           targetType(), 
/* 274 */           targetUserId(), 
/* 275 */           targetApplicationId()));
/*     */   }
/*     */   
/*     */   public InviteCreateSpec withUnique(Possible<Boolean> value) {
/* 279 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/* 280 */     return validate(new InviteCreateSpec(this.reason, 
/*     */           
/* 282 */           maxAge(), 
/* 283 */           maxUses(), 
/* 284 */           temporary(), newValue, 
/*     */           
/* 286 */           targetType(), 
/* 287 */           targetUserId(), 
/* 288 */           targetApplicationId()));
/*     */   }
/*     */   
/*     */   public InviteCreateSpec withUnique(Boolean value) {
/* 292 */     Possible<Boolean> newValue = Possible.of(value);
/* 293 */     return validate(new InviteCreateSpec(this.reason, 
/*     */           
/* 295 */           maxAge(), 
/* 296 */           maxUses(), 
/* 297 */           temporary(), newValue, 
/*     */           
/* 299 */           targetType(), 
/* 300 */           targetUserId(), 
/* 301 */           targetApplicationId()));
/*     */   }
/*     */   
/*     */   public InviteCreateSpec withTargetType(Possible<Invite.Type> value) {
/* 305 */     Possible<Invite.Type> newValue = Objects.<Possible<Invite.Type>>requireNonNull(value);
/* 306 */     return validate(new InviteCreateSpec(this.reason, 
/*     */           
/* 308 */           maxAge(), 
/* 309 */           maxUses(), 
/* 310 */           temporary(), 
/* 311 */           unique(), newValue, 
/*     */           
/* 313 */           targetUserId(), 
/* 314 */           targetApplicationId()));
/*     */   }
/*     */   
/*     */   public InviteCreateSpec withTargetType(Invite.Type value) {
/* 318 */     Possible<Invite.Type> newValue = Possible.of(value);
/* 319 */     return validate(new InviteCreateSpec(this.reason, 
/*     */           
/* 321 */           maxAge(), 
/* 322 */           maxUses(), 
/* 323 */           temporary(), 
/* 324 */           unique(), newValue, 
/*     */           
/* 326 */           targetUserId(), 
/* 327 */           targetApplicationId()));
/*     */   }
/*     */   
/*     */   public InviteCreateSpec withTargetUserId(Possible<Snowflake> value) {
/* 331 */     Possible<Snowflake> newValue = Objects.<Possible<Snowflake>>requireNonNull(value);
/* 332 */     return validate(new InviteCreateSpec(this.reason, 
/*     */           
/* 334 */           maxAge(), 
/* 335 */           maxUses(), 
/* 336 */           temporary(), 
/* 337 */           unique(), 
/* 338 */           targetType(), newValue, 
/*     */           
/* 340 */           targetApplicationId()));
/*     */   }
/*     */   
/*     */   public InviteCreateSpec withTargetUserId(Snowflake value) {
/* 344 */     Possible<Snowflake> newValue = Possible.of(value);
/* 345 */     return validate(new InviteCreateSpec(this.reason, 
/*     */           
/* 347 */           maxAge(), 
/* 348 */           maxUses(), 
/* 349 */           temporary(), 
/* 350 */           unique(), 
/* 351 */           targetType(), newValue, 
/*     */           
/* 353 */           targetApplicationId()));
/*     */   }
/*     */   
/*     */   public InviteCreateSpec withTargetApplicationId(Possible<Snowflake> value) {
/* 357 */     Possible<Snowflake> newValue = Objects.<Possible<Snowflake>>requireNonNull(value);
/* 358 */     return validate(new InviteCreateSpec(this.reason, 
/*     */           
/* 360 */           maxAge(), 
/* 361 */           maxUses(), 
/* 362 */           temporary(), 
/* 363 */           unique(), 
/* 364 */           targetType(), 
/* 365 */           targetUserId(), newValue));
/*     */   }
/*     */ 
/*     */   
/*     */   public InviteCreateSpec withTargetApplicationId(Snowflake value) {
/* 370 */     Possible<Snowflake> newValue = Possible.of(value);
/* 371 */     return validate(new InviteCreateSpec(this.reason, 
/*     */           
/* 373 */           maxAge(), 
/* 374 */           maxUses(), 
/* 375 */           temporary(), 
/* 376 */           unique(), 
/* 377 */           targetType(), 
/* 378 */           targetUserId(), newValue));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 388 */     if (this == another) return true; 
/* 389 */     return (another instanceof InviteCreateSpec && 
/* 390 */       equalTo(0, (InviteCreateSpec)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, InviteCreateSpec another) {
/* 394 */     return (Objects.equals(this.reason, another.reason) && 
/* 395 */       maxAge().equals(another.maxAge()) && 
/* 396 */       maxUses().equals(another.maxUses()) && 
/* 397 */       temporary().equals(another.temporary()) && 
/* 398 */       unique().equals(another.unique()) && 
/* 399 */       targetType().equals(another.targetType()) && 
/* 400 */       targetUserId().equals(another.targetUserId()) && 
/* 401 */       targetApplicationId().equals(another.targetApplicationId()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 410 */     int h = 5381;
/* 411 */     h += (h << 5) + Objects.hashCode(this.reason);
/* 412 */     h += (h << 5) + maxAge().hashCode();
/* 413 */     h += (h << 5) + maxUses().hashCode();
/* 414 */     h += (h << 5) + temporary().hashCode();
/* 415 */     h += (h << 5) + unique().hashCode();
/* 416 */     h += (h << 5) + targetType().hashCode();
/* 417 */     h += (h << 5) + targetUserId().hashCode();
/* 418 */     h += (h << 5) + targetApplicationId().hashCode();
/* 419 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 428 */     return "InviteCreateSpec{reason=" + this.reason + ", maxAge=" + 
/*     */       
/* 430 */       maxAge().toString() + ", maxUses=" + 
/* 431 */       maxUses().toString() + ", temporary=" + 
/* 432 */       temporary().toString() + ", unique=" + 
/* 433 */       unique().toString() + ", targetType=" + 
/* 434 */       targetType().toString() + ", targetUserId=" + 
/* 435 */       targetUserId().toString() + ", targetApplicationId=" + 
/* 436 */       targetApplicationId().toString() + "}";
/*     */   }
/*     */ 
/*     */   
/* 440 */   private static final InviteCreateSpec INSTANCE = validate(new InviteCreateSpec());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static InviteCreateSpec create() {
/* 447 */     return INSTANCE;
/*     */   }
/*     */   
/*     */   private static InviteCreateSpec validate(InviteCreateSpec instance) {
/* 451 */     return (INSTANCE != null && INSTANCE.equalTo(0, instance)) ? INSTANCE : instance;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static InviteCreateSpec copyOf(InviteCreateSpecGenerator instance) {
/* 462 */     if (instance instanceof InviteCreateSpec) {
/* 463 */       return (InviteCreateSpec)instance;
/*     */     }
/* 465 */     return builder()
/* 466 */       .from(instance)
/* 467 */       .build();
/*     */   }
/*     */   
/*     */   public boolean isMaxAgePresent() {
/* 471 */     return !this.maxAge_absent;
/*     */   }
/*     */   
/*     */   public Integer maxAgeOrElse(Integer defaultValue) {
/* 475 */     return !this.maxAge_absent ? this.maxAge_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isMaxUsesPresent() {
/* 479 */     return !this.maxUses_absent;
/*     */   }
/*     */   
/*     */   public Integer maxUsesOrElse(Integer defaultValue) {
/* 483 */     return !this.maxUses_absent ? this.maxUses_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isTemporaryPresent() {
/* 487 */     return !this.temporary_absent;
/*     */   }
/*     */   
/*     */   public Boolean temporaryOrElse(Boolean defaultValue) {
/* 491 */     return !this.temporary_absent ? this.temporary_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isUniquePresent() {
/* 495 */     return !this.unique_absent;
/*     */   }
/*     */   
/*     */   public Boolean uniqueOrElse(Boolean defaultValue) {
/* 499 */     return !this.unique_absent ? this.unique_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isTargetTypePresent() {
/* 503 */     return !this.targetType_absent;
/*     */   }
/*     */   
/*     */   public Invite.Type targetTypeOrElse(Invite.Type defaultValue) {
/* 507 */     return !this.targetType_absent ? this.targetType_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isTargetUserIdPresent() {
/* 511 */     return !this.targetUserId_absent;
/*     */   }
/*     */   
/*     */   public Snowflake targetUserIdOrElse(Snowflake defaultValue) {
/* 515 */     return !this.targetUserId_absent ? this.targetUserId_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isTargetApplicationIdPresent() {
/* 519 */     return !this.targetApplicationId_absent;
/*     */   }
/*     */   
/*     */   public Snowflake targetApplicationIdOrElse(Snowflake defaultValue) {
/* 523 */     return !this.targetApplicationId_absent ? this.targetApplicationId_value : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 543 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "InviteCreateSpecGenerator", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/* 555 */     private Possible<Integer> maxAge_possible = Possible.absent();
/* 556 */     private Possible<Integer> maxUses_possible = Possible.absent();
/* 557 */     private Possible<Boolean> temporary_possible = Possible.absent();
/* 558 */     private Possible<Boolean> unique_possible = Possible.absent();
/* 559 */     private Possible<Invite.Type> targetType_possible = Possible.absent();
/* 560 */     private Possible<Snowflake> targetUserId_possible = Possible.absent();
/* 561 */     private Possible<Snowflake> targetApplicationId_possible = Possible.absent();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private String reason;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(InviteCreateSpec instance) {
/* 575 */       return from(instance);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     final Builder from(InviteCreateSpecGenerator instance) {
/* 585 */       Objects.requireNonNull(instance, "instance");
/* 586 */       String reasonValue = instance.reason();
/* 587 */       if (reasonValue != null) {
/* 588 */         reason(reasonValue);
/*     */       }
/* 590 */       maxAge(instance.maxAge());
/* 591 */       maxUses(instance.maxUses());
/* 592 */       temporary(instance.temporary());
/* 593 */       unique(instance.unique());
/* 594 */       targetType(instance.targetType());
/* 595 */       targetUserId(instance.targetUserId());
/* 596 */       targetApplicationId(instance.targetApplicationId());
/* 597 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder reason(@Nullable String reason) {
/* 607 */       this.reason = reason;
/* 608 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder maxAge(Possible<Integer> value) {
/* 613 */       this.maxAge_possible = value;
/* 614 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder maxAge(Integer value) {
/* 619 */       this.maxAge_possible = Possible.of(value);
/* 620 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder maxUses(Possible<Integer> value) {
/* 625 */       this.maxUses_possible = value;
/* 626 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder maxUses(Integer value) {
/* 631 */       this.maxUses_possible = Possible.of(value);
/* 632 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder temporary(Possible<Boolean> value) {
/* 637 */       this.temporary_possible = value;
/* 638 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder temporary(Boolean value) {
/* 643 */       this.temporary_possible = Possible.of(value);
/* 644 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder unique(Possible<Boolean> value) {
/* 649 */       this.unique_possible = value;
/* 650 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder unique(Boolean value) {
/* 655 */       this.unique_possible = Possible.of(value);
/* 656 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder targetType(Possible<Invite.Type> value) {
/* 661 */       this.targetType_possible = value;
/* 662 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder targetType(Invite.Type value) {
/* 667 */       this.targetType_possible = Possible.of(value);
/* 668 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder targetUserId(Possible<Snowflake> value) {
/* 673 */       this.targetUserId_possible = value;
/* 674 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder targetUserId(Snowflake value) {
/* 679 */       this.targetUserId_possible = Possible.of(value);
/* 680 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder targetApplicationId(Possible<Snowflake> value) {
/* 685 */       this.targetApplicationId_possible = value;
/* 686 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder targetApplicationId(Snowflake value) {
/* 691 */       this.targetApplicationId_possible = Possible.of(value);
/* 692 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public InviteCreateSpec build() {
/* 701 */       return InviteCreateSpec.validate(new InviteCreateSpec(this.reason, 
/*     */             
/* 703 */             maxAge_build(), 
/* 704 */             maxUses_build(), 
/* 705 */             temporary_build(), 
/* 706 */             unique_build(), 
/* 707 */             targetType_build(), 
/* 708 */             targetUserId_build(), 
/* 709 */             targetApplicationId_build()));
/*     */     }
/*     */     
/*     */     private Possible<Integer> maxAge_build() {
/* 713 */       return this.maxAge_possible;
/*     */     }
/*     */     
/*     */     private Possible<Integer> maxUses_build() {
/* 717 */       return this.maxUses_possible;
/*     */     }
/*     */     
/*     */     private Possible<Boolean> temporary_build() {
/* 721 */       return this.temporary_possible;
/*     */     }
/*     */     
/*     */     private Possible<Boolean> unique_build() {
/* 725 */       return this.unique_possible;
/*     */     }
/*     */     
/*     */     private Possible<Invite.Type> targetType_build() {
/* 729 */       return this.targetType_possible;
/*     */     }
/*     */     
/*     */     private Possible<Snowflake> targetUserId_build() {
/* 733 */       return this.targetUserId_possible;
/*     */     }
/*     */     
/*     */     private Possible<Snowflake> targetApplicationId_build() {
/* 737 */       return this.targetApplicationId_possible;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\InviteCreateSpec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */