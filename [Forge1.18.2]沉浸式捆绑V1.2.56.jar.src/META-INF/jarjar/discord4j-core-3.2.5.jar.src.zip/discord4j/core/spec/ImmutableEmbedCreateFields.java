/*     */ package discord4j.core.spec;
/*     */ 
/*     */ import com.google.errorprone.annotations.CanIgnoreReturnValue;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "EmbedCreateFields", generator = "Immutables")
/*     */ final class ImmutableEmbedCreateFields
/*     */ {
/*     */   @Generated(from = "EmbedCreateFields.Footer", generator = "Immutables")
/*     */   static final class Footer
/*     */     implements EmbedCreateFields.Footer
/*     */   {
/*     */     private final String text;
/*     */     @Nullable
/*     */     private final String iconUrl;
/*     */     
/*     */     private Footer(String text, @Nullable String iconUrl) {
/*  38 */       this.text = Objects.<String>requireNonNull(text, "text");
/*  39 */       this.iconUrl = iconUrl;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private Footer(Footer original, String text, @Nullable String iconUrl) {
/*  46 */       this.text = text;
/*  47 */       this.iconUrl = iconUrl;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String text() {
/*  55 */       return this.text;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public String iconUrl() {
/*  63 */       return this.iconUrl;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Footer withText(String value) {
/*  73 */       String newValue = Objects.<String>requireNonNull(value, "text");
/*  74 */       if (this.text.equals(newValue)) return this; 
/*  75 */       return new Footer(this, newValue, this.iconUrl);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Footer withIconUrl(@Nullable String value) {
/*  85 */       if (Objects.equals(this.iconUrl, value)) return this; 
/*  86 */       return new Footer(this, this.text, value);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean equals(Object another) {
/*  95 */       if (this == another) return true; 
/*  96 */       return (another instanceof Footer && 
/*  97 */         equalTo(0, (Footer)another));
/*     */     }
/*     */     
/*     */     private boolean equalTo(int synthetic, Footer another) {
/* 101 */       return (this.text.equals(another.text) && 
/* 102 */         Objects.equals(this.iconUrl, another.iconUrl));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 111 */       int h = 5381;
/* 112 */       h += (h << 5) + this.text.hashCode();
/* 113 */       h += (h << 5) + Objects.hashCode(this.iconUrl);
/* 114 */       return h;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String toString() {
/* 123 */       return "Footer{text=" + this.text + ", iconUrl=" + this.iconUrl + "}";
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Footer of(String text, @Nullable String iconUrl) {
/* 136 */       return new Footer(text, iconUrl);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Footer copyOf(EmbedCreateFields.Footer instance) {
/* 147 */       if (instance instanceof Footer) {
/* 148 */         return (Footer)instance;
/*     */       }
/* 150 */       return builder()
/* 151 */         .from(instance)
/* 152 */         .build();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Builder builder() {
/* 166 */       return new Builder();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Generated(from = "EmbedCreateFields.Footer", generator = "Immutables")
/*     */     public static final class Builder
/*     */     {
/*     */       private static final long INIT_BIT_TEXT = 1L;
/*     */ 
/*     */ 
/*     */       
/* 179 */       private long initBits = 1L;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       private String text;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       private String iconUrl;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @CanIgnoreReturnValue
/*     */       public final Builder from(EmbedCreateFields.Footer instance) {
/* 196 */         Objects.requireNonNull(instance, "instance");
/* 197 */         text(instance.text());
/* 198 */         String iconUrlValue = instance.iconUrl();
/* 199 */         if (iconUrlValue != null) {
/* 200 */           iconUrl(iconUrlValue);
/*     */         }
/* 202 */         return this;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @CanIgnoreReturnValue
/*     */       public final Builder text(String text) {
/* 212 */         this.text = Objects.<String>requireNonNull(text, "text");
/* 213 */         this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 214 */         return this;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @CanIgnoreReturnValue
/*     */       public final Builder iconUrl(@Nullable String iconUrl) {
/* 224 */         this.iconUrl = iconUrl;
/* 225 */         return this;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public ImmutableEmbedCreateFields.Footer build() {
/* 234 */         if (this.initBits != 0L) {
/* 235 */           throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */         }
/* 237 */         return new ImmutableEmbedCreateFields.Footer(null, this.text, this.iconUrl);
/*     */       }
/*     */       
/*     */       private String formatRequiredAttributesMessage() {
/* 241 */         List<String> attributes = new ArrayList<>();
/* 242 */         if ((this.initBits & 0x1L) != 0L) attributes.add("text"); 
/* 243 */         return "Cannot build Footer, some of required attributes are not set " + attributes;
/*     */       }
/*     */ 
/*     */       
/*     */       private Builder() {}
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   @Generated(from = "EmbedCreateFields.Author", generator = "Immutables")
/*     */   static final class Author
/*     */     implements EmbedCreateFields.Author
/*     */   {
/*     */     private final String name;
/*     */     
/*     */     @Nullable
/*     */     private final String url;
/*     */     
/*     */     @Nullable
/*     */     private final String iconUrl;
/*     */ 
/*     */     
/*     */     private Author(String name, @Nullable String url, @Nullable String iconUrl) {
/* 266 */       this.name = Objects.<String>requireNonNull(name, "name");
/* 267 */       this.url = url;
/* 268 */       this.iconUrl = iconUrl;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private Author(Author original, String name, @Nullable String url, @Nullable String iconUrl) {
/* 276 */       this.name = name;
/* 277 */       this.url = url;
/* 278 */       this.iconUrl = iconUrl;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String name() {
/* 286 */       return this.name;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public String url() {
/* 294 */       return this.url;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public String iconUrl() {
/* 302 */       return this.iconUrl;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Author withName(String value) {
/* 312 */       String newValue = Objects.<String>requireNonNull(value, "name");
/* 313 */       if (this.name.equals(newValue)) return this; 
/* 314 */       return new Author(this, newValue, this.url, this.iconUrl);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Author withUrl(@Nullable String value) {
/* 324 */       if (Objects.equals(this.url, value)) return this; 
/* 325 */       return new Author(this, this.name, value, this.iconUrl);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Author withIconUrl(@Nullable String value) {
/* 335 */       if (Objects.equals(this.iconUrl, value)) return this; 
/* 336 */       return new Author(this, this.name, this.url, value);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean equals(Object another) {
/* 345 */       if (this == another) return true; 
/* 346 */       return (another instanceof Author && 
/* 347 */         equalTo(0, (Author)another));
/*     */     }
/*     */     
/*     */     private boolean equalTo(int synthetic, Author another) {
/* 351 */       return (this.name.equals(another.name) && 
/* 352 */         Objects.equals(this.url, another.url) && 
/* 353 */         Objects.equals(this.iconUrl, another.iconUrl));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 362 */       int h = 5381;
/* 363 */       h += (h << 5) + this.name.hashCode();
/* 364 */       h += (h << 5) + Objects.hashCode(this.url);
/* 365 */       h += (h << 5) + Objects.hashCode(this.iconUrl);
/* 366 */       return h;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String toString() {
/* 375 */       return "Author{name=" + this.name + ", url=" + this.url + ", iconUrl=" + this.iconUrl + "}";
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Author of(String name, @Nullable String url, @Nullable String iconUrl) {
/* 390 */       return new Author(name, url, iconUrl);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Author copyOf(EmbedCreateFields.Author instance) {
/* 401 */       if (instance instanceof Author) {
/* 402 */         return (Author)instance;
/*     */       }
/* 404 */       return builder()
/* 405 */         .from(instance)
/* 406 */         .build();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Builder builder() {
/* 421 */       return new Builder();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Generated(from = "EmbedCreateFields.Author", generator = "Immutables")
/*     */     public static final class Builder
/*     */     {
/*     */       private static final long INIT_BIT_NAME = 1L;
/*     */ 
/*     */ 
/*     */       
/* 434 */       private long initBits = 1L;
/*     */ 
/*     */ 
/*     */       
/*     */       private String name;
/*     */ 
/*     */ 
/*     */       
/*     */       private String url;
/*     */ 
/*     */ 
/*     */       
/*     */       private String iconUrl;
/*     */ 
/*     */ 
/*     */       
/*     */       @CanIgnoreReturnValue
/*     */       public final Builder from(EmbedCreateFields.Author instance) {
/* 452 */         Objects.requireNonNull(instance, "instance");
/* 453 */         name(instance.name());
/* 454 */         String urlValue = instance.url();
/* 455 */         if (urlValue != null) {
/* 456 */           url(urlValue);
/*     */         }
/* 458 */         String iconUrlValue = instance.iconUrl();
/* 459 */         if (iconUrlValue != null) {
/* 460 */           iconUrl(iconUrlValue);
/*     */         }
/* 462 */         return this;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @CanIgnoreReturnValue
/*     */       public final Builder name(String name) {
/* 472 */         this.name = Objects.<String>requireNonNull(name, "name");
/* 473 */         this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 474 */         return this;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @CanIgnoreReturnValue
/*     */       public final Builder url(@Nullable String url) {
/* 484 */         this.url = url;
/* 485 */         return this;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @CanIgnoreReturnValue
/*     */       public final Builder iconUrl(@Nullable String iconUrl) {
/* 495 */         this.iconUrl = iconUrl;
/* 496 */         return this;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public ImmutableEmbedCreateFields.Author build() {
/* 505 */         if (this.initBits != 0L) {
/* 506 */           throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */         }
/* 508 */         return new ImmutableEmbedCreateFields.Author(null, this.name, this.url, this.iconUrl);
/*     */       }
/*     */       
/*     */       private String formatRequiredAttributesMessage() {
/* 512 */         List<String> attributes = new ArrayList<>();
/* 513 */         if ((this.initBits & 0x1L) != 0L) attributes.add("name"); 
/* 514 */         return "Cannot build Author, some of required attributes are not set " + attributes;
/*     */       }
/*     */ 
/*     */       
/*     */       private Builder() {}
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   @Generated(from = "EmbedCreateFields.Field", generator = "Immutables")
/*     */   static final class Field
/*     */     implements EmbedCreateFields.Field
/*     */   {
/*     */     private final String name;
/*     */     
/*     */     private final String value;
/*     */     
/*     */     private final boolean inline;
/*     */     
/*     */     private Field(String name, String value, boolean inline) {
/* 534 */       this.name = Objects.<String>requireNonNull(name, "name");
/* 535 */       this.value = Objects.<String>requireNonNull(value, "value");
/* 536 */       this.inline = inline;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private Field(Field original, String name, String value, boolean inline) {
/* 544 */       this.name = name;
/* 545 */       this.value = value;
/* 546 */       this.inline = inline;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String name() {
/* 554 */       return this.name;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String value() {
/* 562 */       return this.value;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean inline() {
/* 570 */       return this.inline;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Field withName(String value) {
/* 580 */       String newValue = Objects.<String>requireNonNull(value, "name");
/* 581 */       if (this.name.equals(newValue)) return this; 
/* 582 */       return new Field(this, newValue, this.value, this.inline);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Field withValue(String value) {
/* 592 */       String newValue = Objects.<String>requireNonNull(value, "value");
/* 593 */       if (this.value.equals(newValue)) return this; 
/* 594 */       return new Field(this, this.name, newValue, this.inline);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Field withInline(boolean value) {
/* 604 */       if (this.inline == value) return this; 
/* 605 */       return new Field(this, this.name, this.value, value);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean equals(Object another) {
/* 614 */       if (this == another) return true; 
/* 615 */       return (another instanceof Field && 
/* 616 */         equalTo(0, (Field)another));
/*     */     }
/*     */     
/*     */     private boolean equalTo(int synthetic, Field another) {
/* 620 */       return (this.name.equals(another.name) && this.value
/* 621 */         .equals(another.value) && this.inline == another.inline);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 631 */       int h = 5381;
/* 632 */       h += (h << 5) + this.name.hashCode();
/* 633 */       h += (h << 5) + this.value.hashCode();
/* 634 */       h += (h << 5) + Boolean.hashCode(this.inline);
/* 635 */       return h;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String toString() {
/* 644 */       return "Field{name=" + this.name + ", value=" + this.value + ", inline=" + this.inline + "}";
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Field of(String name, String value, boolean inline) {
/* 659 */       return new Field(name, value, inline);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Field copyOf(EmbedCreateFields.Field instance) {
/* 670 */       if (instance instanceof Field) {
/* 671 */         return (Field)instance;
/*     */       }
/* 673 */       return builder()
/* 674 */         .from(instance)
/* 675 */         .build();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Builder builder() {
/* 690 */       return new Builder();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     @Generated(from = "EmbedCreateFields.Field", generator = "Immutables")
/*     */     public static final class Builder
/*     */     {
/*     */       private static final long INIT_BIT_NAME = 1L;
/*     */ 
/*     */       
/*     */       private static final long INIT_BIT_VALUE = 2L;
/*     */       
/*     */       private static final long INIT_BIT_INLINE = 4L;
/*     */       
/* 705 */       private long initBits = 7L;
/*     */ 
/*     */ 
/*     */       
/*     */       private String name;
/*     */ 
/*     */ 
/*     */       
/*     */       private String value;
/*     */ 
/*     */ 
/*     */       
/*     */       private boolean inline;
/*     */ 
/*     */ 
/*     */       
/*     */       @CanIgnoreReturnValue
/*     */       public final Builder from(EmbedCreateFields.Field instance) {
/* 723 */         Objects.requireNonNull(instance, "instance");
/* 724 */         name(instance.name());
/* 725 */         value(instance.value());
/* 726 */         inline(instance.inline());
/* 727 */         return this;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @CanIgnoreReturnValue
/*     */       public final Builder name(String name) {
/* 737 */         this.name = Objects.<String>requireNonNull(name, "name");
/* 738 */         this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 739 */         return this;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @CanIgnoreReturnValue
/*     */       public final Builder value(String value) {
/* 749 */         this.value = Objects.<String>requireNonNull(value, "value");
/* 750 */         this.initBits &= 0xFFFFFFFFFFFFFFFDL;
/* 751 */         return this;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @CanIgnoreReturnValue
/*     */       public final Builder inline(boolean inline) {
/* 761 */         this.inline = inline;
/* 762 */         this.initBits &= 0xFFFFFFFFFFFFFFFBL;
/* 763 */         return this;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public ImmutableEmbedCreateFields.Field build() {
/* 772 */         if (this.initBits != 0L) {
/* 773 */           throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */         }
/* 775 */         return new ImmutableEmbedCreateFields.Field(null, this.name, this.value, this.inline);
/*     */       }
/*     */       
/*     */       private String formatRequiredAttributesMessage() {
/* 779 */         List<String> attributes = new ArrayList<>();
/* 780 */         if ((this.initBits & 0x1L) != 0L) attributes.add("name"); 
/* 781 */         if ((this.initBits & 0x2L) != 0L) attributes.add("value"); 
/* 782 */         if ((this.initBits & 0x4L) != 0L) attributes.add("inline"); 
/* 783 */         return "Cannot build Field, some of required attributes are not set " + attributes;
/*     */       }
/*     */       
/*     */       private Builder() {}
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\ImmutableEmbedCreateFields.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */