/*     */ package discord4j.core.spec;
/*     */ 
/*     */ import discord4j.core.object.entity.channel.VoiceChannel;
/*     */ import discord4j.voice.AudioProvider;
/*     */ import discord4j.voice.AudioReceiver;
/*     */ import discord4j.voice.VoiceConnection;
/*     */ import discord4j.voice.VoiceReceiveTaskFactory;
/*     */ import discord4j.voice.VoiceSendTaskFactory;
/*     */ import java.time.Duration;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.util.retry.RetrySpec;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "VoiceChannelJoinMonoGenerator", generator = "Immutables")
/*     */ public final class VoiceChannelJoinMono
/*     */   extends VoiceChannelJoinMonoGenerator
/*     */ {
/*     */   private final Duration timeout;
/*     */   private final AudioProvider provider;
/*     */   private final AudioReceiver receiver;
/*     */   private final VoiceSendTaskFactory sendTaskFactory;
/*     */   private final VoiceReceiveTaskFactory receiveTaskFactory;
/*     */   private final boolean selfDeaf;
/*     */   private final boolean selfMute;
/*     */   private final Duration ipDiscoveryTimeout;
/*     */   private final RetrySpec ipDiscoveryRetrySpec;
/*     */   private final VoiceChannel channel;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   private volatile transient InitShim initShim;
/*     */   
/*     */   private VoiceChannelJoinMono(VoiceChannel channel) {
/*  78 */     this.initShim = new InitShim(); this.channel = Objects.<VoiceChannel>requireNonNull(channel, "channel"); this.timeout = this.initShim.timeout(); this.provider = this.initShim.provider(); this.receiver = this.initShim.receiver(); this.sendTaskFactory = this.initShim.sendTaskFactory(); this.receiveTaskFactory = this.initShim.receiveTaskFactory(); this.selfDeaf = this.initShim.selfDeaf(); this.selfMute = this.initShim.selfMute(); this.ipDiscoveryTimeout = this.initShim.ipDiscoveryTimeout(); this.ipDiscoveryRetrySpec = this.initShim.ipDiscoveryRetrySpec(); this.initShim = null; } private VoiceChannelJoinMono(Duration timeout, AudioProvider provider, AudioReceiver receiver, VoiceSendTaskFactory sendTaskFactory, VoiceReceiveTaskFactory receiveTaskFactory, boolean selfDeaf, boolean selfMute, Duration ipDiscoveryTimeout, RetrySpec ipDiscoveryRetrySpec, VoiceChannel channel) { this.initShim = new InitShim(); this.timeout = timeout; this.provider = provider; this.receiver = receiver; this.sendTaskFactory = sendTaskFactory; this.receiveTaskFactory = receiveTaskFactory; this.selfDeaf = selfDeaf;
/*     */     this.selfMute = selfMute;
/*     */     this.ipDiscoveryTimeout = ipDiscoveryTimeout;
/*     */     this.ipDiscoveryRetrySpec = ipDiscoveryRetrySpec;
/*     */     this.channel = channel;
/*  83 */     this.initShim = null; } @Generated(from = "VoiceChannelJoinMonoGenerator", generator = "Immutables") private final class InitShim { private byte timeoutBuildStage = 0;
/*     */     private Duration timeout;
/*     */     
/*     */     Duration timeout() {
/*  87 */       if (this.timeoutBuildStage == -1) throw new IllegalStateException(formatInitCycleMessage()); 
/*  88 */       if (this.timeoutBuildStage == 0) {
/*  89 */         this.timeoutBuildStage = -1;
/*  90 */         this.timeout = Objects.<Duration>requireNonNull(VoiceChannelJoinMono.this.timeout(), "timeout");
/*  91 */         this.timeoutBuildStage = 1;
/*     */       } 
/*  93 */       return this.timeout;
/*     */     }
/*     */     
/*     */     void timeout(Duration timeout) {
/*  97 */       this.timeout = timeout;
/*  98 */       this.timeoutBuildStage = 1;
/*     */     }
/*     */     
/* 101 */     private byte providerBuildStage = 0;
/*     */     private AudioProvider provider;
/*     */     
/*     */     AudioProvider provider() {
/* 105 */       if (this.providerBuildStage == -1) throw new IllegalStateException(formatInitCycleMessage()); 
/* 106 */       if (this.providerBuildStage == 0) {
/* 107 */         this.providerBuildStage = -1;
/* 108 */         this.provider = Objects.<AudioProvider>requireNonNull(VoiceChannelJoinMono.this.provider(), "provider");
/* 109 */         this.providerBuildStage = 1;
/*     */       } 
/* 111 */       return this.provider;
/*     */     }
/*     */     
/*     */     void provider(AudioProvider provider) {
/* 115 */       this.provider = provider;
/* 116 */       this.providerBuildStage = 1;
/*     */     }
/*     */     
/* 119 */     private byte receiverBuildStage = 0;
/*     */     private AudioReceiver receiver;
/*     */     
/*     */     AudioReceiver receiver() {
/* 123 */       if (this.receiverBuildStage == -1) throw new IllegalStateException(formatInitCycleMessage()); 
/* 124 */       if (this.receiverBuildStage == 0) {
/* 125 */         this.receiverBuildStage = -1;
/* 126 */         this.receiver = Objects.<AudioReceiver>requireNonNull(VoiceChannelJoinMono.this.receiver(), "receiver");
/* 127 */         this.receiverBuildStage = 1;
/*     */       } 
/* 129 */       return this.receiver;
/*     */     }
/*     */     
/*     */     void receiver(AudioReceiver receiver) {
/* 133 */       this.receiver = receiver;
/* 134 */       this.receiverBuildStage = 1;
/*     */     }
/*     */     
/* 137 */     private byte sendTaskFactoryBuildStage = 0;
/*     */     private VoiceSendTaskFactory sendTaskFactory;
/*     */     
/*     */     VoiceSendTaskFactory sendTaskFactory() {
/* 141 */       if (this.sendTaskFactoryBuildStage == -1) throw new IllegalStateException(formatInitCycleMessage()); 
/* 142 */       if (this.sendTaskFactoryBuildStage == 0) {
/* 143 */         this.sendTaskFactoryBuildStage = -1;
/* 144 */         this.sendTaskFactory = Objects.<VoiceSendTaskFactory>requireNonNull(VoiceChannelJoinMono.this.sendTaskFactory(), "sendTaskFactory");
/* 145 */         this.sendTaskFactoryBuildStage = 1;
/*     */       } 
/* 147 */       return this.sendTaskFactory;
/*     */     }
/*     */     
/*     */     void sendTaskFactory(VoiceSendTaskFactory sendTaskFactory) {
/* 151 */       this.sendTaskFactory = sendTaskFactory;
/* 152 */       this.sendTaskFactoryBuildStage = 1;
/*     */     }
/*     */     
/* 155 */     private byte receiveTaskFactoryBuildStage = 0;
/*     */     private VoiceReceiveTaskFactory receiveTaskFactory;
/*     */     
/*     */     VoiceReceiveTaskFactory receiveTaskFactory() {
/* 159 */       if (this.receiveTaskFactoryBuildStage == -1) throw new IllegalStateException(formatInitCycleMessage()); 
/* 160 */       if (this.receiveTaskFactoryBuildStage == 0) {
/* 161 */         this.receiveTaskFactoryBuildStage = -1;
/* 162 */         this.receiveTaskFactory = Objects.<VoiceReceiveTaskFactory>requireNonNull(VoiceChannelJoinMono.this.receiveTaskFactory(), "receiveTaskFactory");
/* 163 */         this.receiveTaskFactoryBuildStage = 1;
/*     */       } 
/* 165 */       return this.receiveTaskFactory;
/*     */     }
/*     */     
/*     */     void receiveTaskFactory(VoiceReceiveTaskFactory receiveTaskFactory) {
/* 169 */       this.receiveTaskFactory = receiveTaskFactory;
/* 170 */       this.receiveTaskFactoryBuildStage = 1;
/*     */     }
/*     */     
/* 173 */     private byte selfDeafBuildStage = 0;
/*     */     private boolean selfDeaf;
/*     */     
/*     */     boolean selfDeaf() {
/* 177 */       if (this.selfDeafBuildStage == -1) throw new IllegalStateException(formatInitCycleMessage()); 
/* 178 */       if (this.selfDeafBuildStage == 0) {
/* 179 */         this.selfDeafBuildStage = -1;
/* 180 */         this.selfDeaf = VoiceChannelJoinMono.this.selfDeaf();
/* 181 */         this.selfDeafBuildStage = 1;
/*     */       } 
/* 183 */       return this.selfDeaf;
/*     */     }
/*     */     
/*     */     void selfDeaf(boolean selfDeaf) {
/* 187 */       this.selfDeaf = selfDeaf;
/* 188 */       this.selfDeafBuildStage = 1;
/*     */     }
/*     */     
/* 191 */     private byte selfMuteBuildStage = 0;
/*     */     private boolean selfMute;
/*     */     
/*     */     boolean selfMute() {
/* 195 */       if (this.selfMuteBuildStage == -1) throw new IllegalStateException(formatInitCycleMessage()); 
/* 196 */       if (this.selfMuteBuildStage == 0) {
/* 197 */         this.selfMuteBuildStage = -1;
/* 198 */         this.selfMute = VoiceChannelJoinMono.this.selfMute();
/* 199 */         this.selfMuteBuildStage = 1;
/*     */       } 
/* 201 */       return this.selfMute;
/*     */     }
/*     */     
/*     */     void selfMute(boolean selfMute) {
/* 205 */       this.selfMute = selfMute;
/* 206 */       this.selfMuteBuildStage = 1;
/*     */     }
/*     */     
/* 209 */     private byte ipDiscoveryTimeoutBuildStage = 0;
/*     */     private Duration ipDiscoveryTimeout;
/*     */     
/*     */     Duration ipDiscoveryTimeout() {
/* 213 */       if (this.ipDiscoveryTimeoutBuildStage == -1) throw new IllegalStateException(formatInitCycleMessage()); 
/* 214 */       if (this.ipDiscoveryTimeoutBuildStage == 0) {
/* 215 */         this.ipDiscoveryTimeoutBuildStage = -1;
/* 216 */         this.ipDiscoveryTimeout = Objects.<Duration>requireNonNull(VoiceChannelJoinMono.this.ipDiscoveryTimeout(), "ipDiscoveryTimeout");
/* 217 */         this.ipDiscoveryTimeoutBuildStage = 1;
/*     */       } 
/* 219 */       return this.ipDiscoveryTimeout;
/*     */     }
/*     */     
/*     */     void ipDiscoveryTimeout(Duration ipDiscoveryTimeout) {
/* 223 */       this.ipDiscoveryTimeout = ipDiscoveryTimeout;
/* 224 */       this.ipDiscoveryTimeoutBuildStage = 1;
/*     */     }
/*     */     
/* 227 */     private byte ipDiscoveryRetrySpecBuildStage = 0;
/*     */     private RetrySpec ipDiscoveryRetrySpec;
/*     */     
/*     */     RetrySpec ipDiscoveryRetrySpec() {
/* 231 */       if (this.ipDiscoveryRetrySpecBuildStage == -1) throw new IllegalStateException(formatInitCycleMessage()); 
/* 232 */       if (this.ipDiscoveryRetrySpecBuildStage == 0) {
/* 233 */         this.ipDiscoveryRetrySpecBuildStage = -1;
/* 234 */         this.ipDiscoveryRetrySpec = Objects.<RetrySpec>requireNonNull(VoiceChannelJoinMono.this.ipDiscoveryRetrySpec(), "ipDiscoveryRetrySpec");
/* 235 */         this.ipDiscoveryRetrySpecBuildStage = 1;
/*     */       } 
/* 237 */       return this.ipDiscoveryRetrySpec;
/*     */     }
/*     */     
/*     */     void ipDiscoveryRetrySpec(RetrySpec ipDiscoveryRetrySpec) {
/* 241 */       this.ipDiscoveryRetrySpec = ipDiscoveryRetrySpec;
/* 242 */       this.ipDiscoveryRetrySpecBuildStage = 1;
/*     */     }
/*     */     
/*     */     private String formatInitCycleMessage() {
/* 246 */       List<String> attributes = new ArrayList<>();
/* 247 */       if (this.timeoutBuildStage == -1) attributes.add("timeout"); 
/* 248 */       if (this.providerBuildStage == -1) attributes.add("provider"); 
/* 249 */       if (this.receiverBuildStage == -1) attributes.add("receiver"); 
/* 250 */       if (this.sendTaskFactoryBuildStage == -1) attributes.add("sendTaskFactory"); 
/* 251 */       if (this.receiveTaskFactoryBuildStage == -1) attributes.add("receiveTaskFactory"); 
/* 252 */       if (this.selfDeafBuildStage == -1) attributes.add("selfDeaf"); 
/* 253 */       if (this.selfMuteBuildStage == -1) attributes.add("selfMute"); 
/* 254 */       if (this.ipDiscoveryTimeoutBuildStage == -1) attributes.add("ipDiscoveryTimeout"); 
/* 255 */       if (this.ipDiscoveryRetrySpecBuildStage == -1) attributes.add("ipDiscoveryRetrySpec"); 
/* 256 */       return "Cannot build VoiceChannelJoinMono, attribute initializers form cycle " + attributes;
/*     */     }
/*     */ 
/*     */     
/*     */     private InitShim() {} }
/*     */ 
/*     */ 
/*     */   
/*     */   public Duration timeout() {
/* 265 */     InitShim shim = this.initShim;
/* 266 */     return (shim != null) ? 
/* 267 */       shim.timeout() : 
/* 268 */       this.timeout;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AudioProvider provider() {
/* 276 */     InitShim shim = this.initShim;
/* 277 */     return (shim != null) ? 
/* 278 */       shim.provider() : 
/* 279 */       this.provider;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public AudioReceiver receiver() {
/* 288 */     InitShim shim = this.initShim;
/* 289 */     return (shim != null) ? 
/* 290 */       shim.receiver() : 
/* 291 */       this.receiver;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public VoiceSendTaskFactory sendTaskFactory() {
/* 299 */     InitShim shim = this.initShim;
/* 300 */     return (shim != null) ? 
/* 301 */       shim.sendTaskFactory() : 
/* 302 */       this.sendTaskFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public VoiceReceiveTaskFactory receiveTaskFactory() {
/* 311 */     InitShim shim = this.initShim;
/* 312 */     return (shim != null) ? 
/* 313 */       shim.receiveTaskFactory() : 
/* 314 */       this.receiveTaskFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean selfDeaf() {
/* 322 */     InitShim shim = this.initShim;
/* 323 */     return (shim != null) ? 
/* 324 */       shim.selfDeaf() : 
/* 325 */       this.selfDeaf;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean selfMute() {
/* 333 */     InitShim shim = this.initShim;
/* 334 */     return (shim != null) ? 
/* 335 */       shim.selfMute() : 
/* 336 */       this.selfMute;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Duration ipDiscoveryTimeout() {
/* 344 */     InitShim shim = this.initShim;
/* 345 */     return (shim != null) ? 
/* 346 */       shim.ipDiscoveryTimeout() : 
/* 347 */       this.ipDiscoveryTimeout;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RetrySpec ipDiscoveryRetrySpec() {
/* 355 */     InitShim shim = this.initShim;
/* 356 */     return (shim != null) ? 
/* 357 */       shim.ipDiscoveryRetrySpec() : 
/* 358 */       this.ipDiscoveryRetrySpec;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public VoiceChannel channel() {
/* 366 */     return this.channel;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final VoiceChannelJoinMono withTimeout(Duration value) {
/* 376 */     if (this.timeout == value) return this; 
/* 377 */     Duration newValue = Objects.<Duration>requireNonNull(value, "timeout");
/* 378 */     return new VoiceChannelJoinMono(newValue, this.provider, this.receiver, this.sendTaskFactory, this.receiveTaskFactory, this.selfDeaf, this.selfMute, this.ipDiscoveryTimeout, this.ipDiscoveryRetrySpec, this.channel);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final VoiceChannelJoinMono withProvider(AudioProvider value) {
/* 398 */     if (this.provider == value) return this; 
/* 399 */     AudioProvider newValue = Objects.<AudioProvider>requireNonNull(value, "provider");
/* 400 */     return new VoiceChannelJoinMono(this.timeout, newValue, this.receiver, this.sendTaskFactory, this.receiveTaskFactory, this.selfDeaf, this.selfMute, this.ipDiscoveryTimeout, this.ipDiscoveryRetrySpec, this.channel);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public final VoiceChannelJoinMono withReceiver(AudioReceiver value) {
/* 421 */     if (this.receiver == value) return this; 
/* 422 */     AudioReceiver newValue = Objects.<AudioReceiver>requireNonNull(value, "receiver");
/* 423 */     return new VoiceChannelJoinMono(this.timeout, this.provider, newValue, this.sendTaskFactory, this.receiveTaskFactory, this.selfDeaf, this.selfMute, this.ipDiscoveryTimeout, this.ipDiscoveryRetrySpec, this.channel);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final VoiceChannelJoinMono withSendTaskFactory(VoiceSendTaskFactory value) {
/* 443 */     if (this.sendTaskFactory == value) return this; 
/* 444 */     VoiceSendTaskFactory newValue = Objects.<VoiceSendTaskFactory>requireNonNull(value, "sendTaskFactory");
/* 445 */     return new VoiceChannelJoinMono(this.timeout, this.provider, this.receiver, newValue, this.receiveTaskFactory, this.selfDeaf, this.selfMute, this.ipDiscoveryTimeout, this.ipDiscoveryRetrySpec, this.channel);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public final VoiceChannelJoinMono withReceiveTaskFactory(VoiceReceiveTaskFactory value) {
/* 466 */     if (this.receiveTaskFactory == value) return this; 
/* 467 */     VoiceReceiveTaskFactory newValue = Objects.<VoiceReceiveTaskFactory>requireNonNull(value, "receiveTaskFactory");
/* 468 */     return new VoiceChannelJoinMono(this.timeout, this.provider, this.receiver, this.sendTaskFactory, newValue, this.selfDeaf, this.selfMute, this.ipDiscoveryTimeout, this.ipDiscoveryRetrySpec, this.channel);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final VoiceChannelJoinMono withSelfDeaf(boolean value) {
/* 488 */     if (this.selfDeaf == value) return this; 
/* 489 */     return new VoiceChannelJoinMono(this.timeout, this.provider, this.receiver, this.sendTaskFactory, this.receiveTaskFactory, value, this.selfMute, this.ipDiscoveryTimeout, this.ipDiscoveryRetrySpec, this.channel);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final VoiceChannelJoinMono withSelfMute(boolean value) {
/* 509 */     if (this.selfMute == value) return this; 
/* 510 */     return new VoiceChannelJoinMono(this.timeout, this.provider, this.receiver, this.sendTaskFactory, this.receiveTaskFactory, this.selfDeaf, value, this.ipDiscoveryTimeout, this.ipDiscoveryRetrySpec, this.channel);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final VoiceChannelJoinMono withIpDiscoveryTimeout(Duration value) {
/* 530 */     if (this.ipDiscoveryTimeout == value) return this; 
/* 531 */     Duration newValue = Objects.<Duration>requireNonNull(value, "ipDiscoveryTimeout");
/* 532 */     return new VoiceChannelJoinMono(this.timeout, this.provider, this.receiver, this.sendTaskFactory, this.receiveTaskFactory, this.selfDeaf, this.selfMute, newValue, this.ipDiscoveryRetrySpec, this.channel);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final VoiceChannelJoinMono withIpDiscoveryRetrySpec(RetrySpec value) {
/* 552 */     if (this.ipDiscoveryRetrySpec == value) return this; 
/* 553 */     RetrySpec newValue = Objects.<RetrySpec>requireNonNull(value, "ipDiscoveryRetrySpec");
/* 554 */     return new VoiceChannelJoinMono(this.timeout, this.provider, this.receiver, this.sendTaskFactory, this.receiveTaskFactory, this.selfDeaf, this.selfMute, this.ipDiscoveryTimeout, newValue, this.channel);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final VoiceChannelJoinMono withChannel(VoiceChannel value) {
/* 574 */     if (this.channel == value) return this; 
/* 575 */     VoiceChannel newValue = Objects.<VoiceChannel>requireNonNull(value, "channel");
/* 576 */     return new VoiceChannelJoinMono(this.timeout, this.provider, this.receiver, this.sendTaskFactory, this.receiveTaskFactory, this.selfDeaf, this.selfMute, this.ipDiscoveryTimeout, this.ipDiscoveryRetrySpec, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 595 */     if (this == another) return true; 
/* 596 */     return (another instanceof VoiceChannelJoinMono && 
/* 597 */       equalTo(0, (VoiceChannelJoinMono)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, VoiceChannelJoinMono another) {
/* 601 */     return (this.timeout.equals(another.timeout) && this.provider
/* 602 */       .equals(another.provider) && this.receiver
/* 603 */       .equals(another.receiver) && this.sendTaskFactory
/* 604 */       .equals(another.sendTaskFactory) && this.receiveTaskFactory
/* 605 */       .equals(another.receiveTaskFactory) && this.selfDeaf == another.selfDeaf && this.selfMute == another.selfMute && this.ipDiscoveryTimeout
/*     */ 
/*     */       
/* 608 */       .equals(another.ipDiscoveryTimeout) && this.ipDiscoveryRetrySpec
/* 609 */       .equals(another.ipDiscoveryRetrySpec) && this.channel
/* 610 */       .equals(another.channel));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 619 */     int h = 5381;
/* 620 */     h += (h << 5) + this.timeout.hashCode();
/* 621 */     h += (h << 5) + this.provider.hashCode();
/* 622 */     h += (h << 5) + this.receiver.hashCode();
/* 623 */     h += (h << 5) + this.sendTaskFactory.hashCode();
/* 624 */     h += (h << 5) + this.receiveTaskFactory.hashCode();
/* 625 */     h += (h << 5) + Boolean.hashCode(this.selfDeaf);
/* 626 */     h += (h << 5) + Boolean.hashCode(this.selfMute);
/* 627 */     h += (h << 5) + this.ipDiscoveryTimeout.hashCode();
/* 628 */     h += (h << 5) + this.ipDiscoveryRetrySpec.hashCode();
/* 629 */     h += (h << 5) + this.channel.hashCode();
/* 630 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 639 */     return "VoiceChannelJoinMono{timeout=" + this.timeout + ", provider=" + this.provider + ", receiver=" + this.receiver + ", sendTaskFactory=" + this.sendTaskFactory + ", receiveTaskFactory=" + this.receiveTaskFactory + ", selfDeaf=" + this.selfDeaf + ", selfMute=" + this.selfMute + ", ipDiscoveryTimeout=" + this.ipDiscoveryTimeout + ", ipDiscoveryRetrySpec=" + this.ipDiscoveryRetrySpec + ", channel=" + this.channel + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static VoiceChannelJoinMono of(VoiceChannel channel) {
/* 659 */     return new VoiceChannelJoinMono(channel);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static VoiceChannelJoinMono copyOf(VoiceChannelJoinMonoGenerator instance) {
/* 670 */     if (instance instanceof VoiceChannelJoinMono) {
/* 671 */       return (VoiceChannelJoinMono)instance;
/*     */     }
/* 673 */     return of(instance.channel())
/* 674 */       .withTimeout(instance.timeout())
/* 675 */       .withProvider(instance.provider())
/* 676 */       .withReceiver(instance.receiver())
/* 677 */       .withSendTaskFactory(instance.sendTaskFactory())
/* 678 */       .withReceiveTaskFactory(instance.receiveTaskFactory())
/* 679 */       .withSelfDeaf(instance.selfDeaf())
/* 680 */       .withSelfMute(instance.selfMute())
/* 681 */       .withIpDiscoveryTimeout(instance.ipDiscoveryTimeout())
/* 682 */       .withIpDiscoveryRetrySpec(instance.ipDiscoveryRetrySpec());
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\VoiceChannelJoinMono.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */