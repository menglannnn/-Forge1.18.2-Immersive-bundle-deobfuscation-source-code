/*     */ package discord4j.core.spec;
/*     */ 
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.object.entity.Guild;
/*     */ import discord4j.core.object.entity.ScheduledEvent;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.time.Instant;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "ScheduledEventCreateMonoGenerator", generator = "Immutables")
/*     */ public final class ScheduledEventCreateMono
/*     */   extends ScheduledEventCreateMonoGenerator
/*     */ {
/*     */   @Nullable
/*     */   private final String reason;
/*     */   private final Snowflake channelId_value;
/*     */   private final boolean channelId_absent;
/*     */   private final ScheduledEventEntityMetadataSpec entityMetadata_value;
/*     */   private final boolean entityMetadata_absent;
/*     */   private final String name;
/*     */   private final ScheduledEvent.PrivacyLevel privacyLevel;
/*     */   private final Instant scheduledStartTime;
/*     */   private final Instant scheduledEndTime_value;
/*     */   private final boolean scheduledEndTime_absent;
/*     */   private final String description_value;
/*     */   private final boolean description_absent;
/*     */   private final ScheduledEvent.EntityType entityType;
/*     */   private final Guild guild;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   private volatile transient InitShim initShim;
/*     */   
/*     */   private ScheduledEventCreateMono(String name, ScheduledEvent.PrivacyLevel privacyLevel, Instant scheduledStartTime, ScheduledEvent.EntityType entityType, Guild guild) {
/* 102 */     this.initShim = new InitShim(); this.name = Objects.<String>requireNonNull(name, "name"); this.privacyLevel = Objects.<ScheduledEvent.PrivacyLevel>requireNonNull(privacyLevel, "privacyLevel"); this.scheduledStartTime = Objects.<Instant>requireNonNull(scheduledStartTime, "scheduledStartTime"); this.entityType = Objects.<ScheduledEvent.EntityType>requireNonNull(entityType, "entityType"); this.guild = Objects.<Guild>requireNonNull(guild, "guild"); this.reason = null; Possible<Snowflake> channelId$impl = Possible.absent(); Possible<ScheduledEventEntityMetadataSpec> entityMetadata$impl = Possible.absent(); Possible<Instant> scheduledEndTime$impl = Possible.absent(); Possible<String> description$impl = Possible.absent(); this.channelId_value = channelId$impl.toOptional().orElse(null); this.channelId_absent = channelId$impl.isAbsent(); this.entityMetadata_value = entityMetadata$impl.toOptional().orElse(null); this.entityMetadata_absent = entityMetadata$impl.isAbsent(); this.scheduledEndTime_value = scheduledEndTime$impl.toOptional().orElse(null); this.scheduledEndTime_absent = scheduledEndTime$impl.isAbsent(); this.description_value = description$impl.toOptional().orElse(null); this.description_absent = description$impl.isAbsent(); this.initShim = null; } private ScheduledEventCreateMono(@Nullable String reason, Possible<Snowflake> channelId, Possible<ScheduledEventEntityMetadataSpec> entityMetadata, String name, ScheduledEvent.PrivacyLevel privacyLevel, Instant scheduledStartTime, Possible<Instant> scheduledEndTime, Possible<String> description, ScheduledEvent.EntityType entityType, Guild guild) { this.initShim = new InitShim(); this.reason = reason; Possible<Snowflake> channelId$impl = channelId; Possible<ScheduledEventEntityMetadataSpec> entityMetadata$impl = entityMetadata; this.name = name; this.privacyLevel = privacyLevel; this.scheduledStartTime = scheduledStartTime; Possible<Instant> scheduledEndTime$impl = scheduledEndTime; Possible<String> description$impl = description; this.entityType = entityType; this.guild = guild; this.channelId_value = channelId$impl.toOptional().orElse(null); this.channelId_absent = channelId$impl.isAbsent(); this.entityMetadata_value = entityMetadata$impl.toOptional().orElse(null);
/*     */     this.entityMetadata_absent = entityMetadata$impl.isAbsent();
/*     */     this.scheduledEndTime_value = scheduledEndTime$impl.toOptional().orElse(null);
/*     */     this.scheduledEndTime_absent = scheduledEndTime$impl.isAbsent();
/*     */     this.description_value = description$impl.toOptional().orElse(null);
/*     */     this.description_absent = description$impl.isAbsent();
/* 108 */     this.initShim = null; } @Generated(from = "ScheduledEventCreateMonoGenerator", generator = "Immutables") private final class InitShim { private InitShim() {} private String formatInitCycleMessage() { List<String> attributes = new ArrayList<>();
/* 109 */       return "Cannot build ScheduledEventCreateMono, attribute initializers form cycle " + attributes; }
/*     */      }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String reason() {
/* 119 */     return this.reason;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Snowflake> channelId() {
/* 127 */     return this.channelId_absent ? Possible.absent() : Possible.of(this.channelId_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<ScheduledEventEntityMetadataSpec> entityMetadata() {
/* 135 */     return this.entityMetadata_absent ? Possible.absent() : Possible.of(this.entityMetadata_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String name() {
/* 143 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ScheduledEvent.PrivacyLevel privacyLevel() {
/* 151 */     return this.privacyLevel;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Instant scheduledStartTime() {
/* 159 */     return this.scheduledStartTime;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Instant> scheduledEndTime() {
/* 167 */     return this.scheduledEndTime_absent ? Possible.absent() : Possible.of(this.scheduledEndTime_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<String> description() {
/* 175 */     return this.description_absent ? Possible.absent() : Possible.of(this.description_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ScheduledEvent.EntityType entityType() {
/* 183 */     return this.entityType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Guild guild() {
/* 191 */     return this.guild;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ScheduledEventCreateMono withReason(@Nullable String value) {
/* 201 */     if (Objects.equals(this.reason, value)) return this; 
/* 202 */     return new ScheduledEventCreateMono(value, 
/*     */         
/* 204 */         channelId(), 
/* 205 */         entityMetadata(), this.name, this.privacyLevel, this.scheduledStartTime, 
/*     */ 
/*     */ 
/*     */         
/* 209 */         scheduledEndTime(), 
/* 210 */         description(), this.entityType, this.guild);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ScheduledEventCreateMono withChannelId(Possible<Snowflake> value) {
/* 216 */     Possible<Snowflake> newValue = Objects.<Possible<Snowflake>>requireNonNull(value);
/* 217 */     return new ScheduledEventCreateMono(this.reason, newValue, 
/*     */ 
/*     */         
/* 220 */         entityMetadata(), this.name, this.privacyLevel, this.scheduledStartTime, 
/*     */ 
/*     */ 
/*     */         
/* 224 */         scheduledEndTime(), 
/* 225 */         description(), this.entityType, this.guild);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ScheduledEventCreateMono withChannelId(Snowflake value) {
/* 231 */     Possible<Snowflake> newValue = Possible.of(value);
/* 232 */     return new ScheduledEventCreateMono(this.reason, newValue, 
/*     */ 
/*     */         
/* 235 */         entityMetadata(), this.name, this.privacyLevel, this.scheduledStartTime, 
/*     */ 
/*     */ 
/*     */         
/* 239 */         scheduledEndTime(), 
/* 240 */         description(), this.entityType, this.guild);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ScheduledEventCreateMono withEntityMetadata(Possible<ScheduledEventEntityMetadataSpec> value) {
/* 246 */     Possible<ScheduledEventEntityMetadataSpec> newValue = Objects.<Possible<ScheduledEventEntityMetadataSpec>>requireNonNull(value);
/* 247 */     return new ScheduledEventCreateMono(this.reason, 
/*     */         
/* 249 */         channelId(), newValue, this.name, this.privacyLevel, this.scheduledStartTime, 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 254 */         scheduledEndTime(), 
/* 255 */         description(), this.entityType, this.guild);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ScheduledEventCreateMono withEntityMetadata(ScheduledEventEntityMetadataSpec value) {
/* 261 */     Possible<ScheduledEventEntityMetadataSpec> newValue = Possible.of(value);
/* 262 */     return new ScheduledEventCreateMono(this.reason, 
/*     */         
/* 264 */         channelId(), newValue, this.name, this.privacyLevel, this.scheduledStartTime, 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 269 */         scheduledEndTime(), 
/* 270 */         description(), this.entityType, this.guild);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ScheduledEventCreateMono withName(String value) {
/* 282 */     String newValue = Objects.<String>requireNonNull(value, "name");
/* 283 */     if (this.name.equals(newValue)) return this; 
/* 284 */     return new ScheduledEventCreateMono(this.reason, 
/*     */         
/* 286 */         channelId(), 
/* 287 */         entityMetadata(), newValue, this.privacyLevel, this.scheduledStartTime, 
/*     */ 
/*     */ 
/*     */         
/* 291 */         scheduledEndTime(), 
/* 292 */         description(), this.entityType, this.guild);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ScheduledEventCreateMono withPrivacyLevel(ScheduledEvent.PrivacyLevel value) {
/* 304 */     ScheduledEvent.PrivacyLevel newValue = Objects.<ScheduledEvent.PrivacyLevel>requireNonNull(value, "privacyLevel");
/* 305 */     if (this.privacyLevel == newValue) return this; 
/* 306 */     return new ScheduledEventCreateMono(this.reason, 
/*     */         
/* 308 */         channelId(), 
/* 309 */         entityMetadata(), this.name, newValue, this.scheduledStartTime, 
/*     */ 
/*     */ 
/*     */         
/* 313 */         scheduledEndTime(), 
/* 314 */         description(), this.entityType, this.guild);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ScheduledEventCreateMono withScheduledStartTime(Instant value) {
/* 326 */     if (this.scheduledStartTime == value) return this; 
/* 327 */     Instant newValue = Objects.<Instant>requireNonNull(value, "scheduledStartTime");
/* 328 */     return new ScheduledEventCreateMono(this.reason, 
/*     */         
/* 330 */         channelId(), 
/* 331 */         entityMetadata(), this.name, this.privacyLevel, newValue, 
/*     */ 
/*     */ 
/*     */         
/* 335 */         scheduledEndTime(), 
/* 336 */         description(), this.entityType, this.guild);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ScheduledEventCreateMono withScheduledEndTime(Possible<Instant> value) {
/* 342 */     Possible<Instant> newValue = Objects.<Possible<Instant>>requireNonNull(value);
/* 343 */     return new ScheduledEventCreateMono(this.reason, 
/*     */         
/* 345 */         channelId(), 
/* 346 */         entityMetadata(), this.name, this.privacyLevel, this.scheduledStartTime, newValue, 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 351 */         description(), this.entityType, this.guild);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ScheduledEventCreateMono withScheduledEndTime(Instant value) {
/* 357 */     Possible<Instant> newValue = Possible.of(value);
/* 358 */     return new ScheduledEventCreateMono(this.reason, 
/*     */         
/* 360 */         channelId(), 
/* 361 */         entityMetadata(), this.name, this.privacyLevel, this.scheduledStartTime, newValue, 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 366 */         description(), this.entityType, this.guild);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ScheduledEventCreateMono withDescription(Possible<String> value) {
/* 372 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/* 373 */     return new ScheduledEventCreateMono(this.reason, 
/*     */         
/* 375 */         channelId(), 
/* 376 */         entityMetadata(), this.name, this.privacyLevel, this.scheduledStartTime, 
/*     */ 
/*     */ 
/*     */         
/* 380 */         scheduledEndTime(), newValue, this.entityType, this.guild);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ScheduledEventCreateMono withDescription(String value) {
/* 387 */     Possible<String> newValue = Possible.of(value);
/* 388 */     return new ScheduledEventCreateMono(this.reason, 
/*     */         
/* 390 */         channelId(), 
/* 391 */         entityMetadata(), this.name, this.privacyLevel, this.scheduledStartTime, 
/*     */ 
/*     */ 
/*     */         
/* 395 */         scheduledEndTime(), newValue, this.entityType, this.guild);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ScheduledEventCreateMono withEntityType(ScheduledEvent.EntityType value) {
/* 408 */     ScheduledEvent.EntityType newValue = Objects.<ScheduledEvent.EntityType>requireNonNull(value, "entityType");
/* 409 */     if (this.entityType == newValue) return this; 
/* 410 */     return new ScheduledEventCreateMono(this.reason, 
/*     */         
/* 412 */         channelId(), 
/* 413 */         entityMetadata(), this.name, this.privacyLevel, this.scheduledStartTime, 
/*     */ 
/*     */ 
/*     */         
/* 417 */         scheduledEndTime(), 
/* 418 */         description(), newValue, this.guild);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ScheduledEventCreateMono withGuild(Guild value) {
/* 430 */     if (this.guild == value) return this; 
/* 431 */     Guild newValue = Objects.<Guild>requireNonNull(value, "guild");
/* 432 */     return new ScheduledEventCreateMono(this.reason, 
/*     */         
/* 434 */         channelId(), 
/* 435 */         entityMetadata(), this.name, this.privacyLevel, this.scheduledStartTime, 
/*     */ 
/*     */ 
/*     */         
/* 439 */         scheduledEndTime(), 
/* 440 */         description(), this.entityType, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 451 */     if (this == another) return true; 
/* 452 */     return (another instanceof ScheduledEventCreateMono && 
/* 453 */       equalTo(0, (ScheduledEventCreateMono)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ScheduledEventCreateMono another) {
/* 457 */     return (Objects.equals(this.reason, another.reason) && 
/* 458 */       channelId().equals(another.channelId()) && 
/* 459 */       entityMetadata().equals(another.entityMetadata()) && this.name
/* 460 */       .equals(another.name) && this.privacyLevel
/* 461 */       .equals(another.privacyLevel) && this.scheduledStartTime
/* 462 */       .equals(another.scheduledStartTime) && 
/* 463 */       scheduledEndTime().equals(another.scheduledEndTime()) && 
/* 464 */       description().equals(another.description()) && this.entityType
/* 465 */       .equals(another.entityType) && this.guild
/* 466 */       .equals(another.guild));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 475 */     int h = 5381;
/* 476 */     h += (h << 5) + Objects.hashCode(this.reason);
/* 477 */     h += (h << 5) + channelId().hashCode();
/* 478 */     h += (h << 5) + entityMetadata().hashCode();
/* 479 */     h += (h << 5) + this.name.hashCode();
/* 480 */     h += (h << 5) + this.privacyLevel.hashCode();
/* 481 */     h += (h << 5) + this.scheduledStartTime.hashCode();
/* 482 */     h += (h << 5) + scheduledEndTime().hashCode();
/* 483 */     h += (h << 5) + description().hashCode();
/* 484 */     h += (h << 5) + this.entityType.hashCode();
/* 485 */     h += (h << 5) + this.guild.hashCode();
/* 486 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 495 */     return "ScheduledEventCreateMono{reason=" + this.reason + ", channelId=" + 
/*     */       
/* 497 */       channelId().toString() + ", entityMetadata=" + 
/* 498 */       entityMetadata().toString() + ", name=" + this.name + ", privacyLevel=" + this.privacyLevel + ", scheduledStartTime=" + this.scheduledStartTime + ", scheduledEndTime=" + 
/*     */ 
/*     */ 
/*     */       
/* 502 */       scheduledEndTime().toString() + ", description=" + 
/* 503 */       description().toString() + ", entityType=" + this.entityType + ", guild=" + this.guild + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ScheduledEventCreateMono of(String name, ScheduledEvent.PrivacyLevel privacyLevel, Instant scheduledStartTime, ScheduledEvent.EntityType entityType, Guild guild) {
/* 519 */     return new ScheduledEventCreateMono(name, privacyLevel, scheduledStartTime, entityType, guild);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static ScheduledEventCreateMono copyOf(ScheduledEventCreateMonoGenerator instance) {
/* 530 */     if (instance instanceof ScheduledEventCreateMono) {
/* 531 */       return (ScheduledEventCreateMono)instance;
/*     */     }
/* 533 */     return of(instance.name(), instance.privacyLevel(), instance.scheduledStartTime(), instance.entityType(), instance.guild())
/* 534 */       .withReason(instance.reason())
/* 535 */       .withChannelId(instance.channelId())
/* 536 */       .withEntityMetadata(instance.entityMetadata())
/* 537 */       .withScheduledEndTime(instance.scheduledEndTime())
/* 538 */       .withDescription(instance.description());
/*     */   }
/*     */   
/*     */   public boolean isChannelIdPresent() {
/* 542 */     return !this.channelId_absent;
/*     */   }
/*     */   
/*     */   public Snowflake channelIdOrElse(Snowflake defaultValue) {
/* 546 */     return !this.channelId_absent ? this.channelId_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isEntityMetadataPresent() {
/* 550 */     return !this.entityMetadata_absent;
/*     */   }
/*     */   
/*     */   public ScheduledEventEntityMetadataSpec entityMetadataOrElse(ScheduledEventEntityMetadataSpec defaultValue) {
/* 554 */     return !this.entityMetadata_absent ? this.entityMetadata_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isScheduledEndTimePresent() {
/* 558 */     return !this.scheduledEndTime_absent;
/*     */   }
/*     */   
/*     */   public Instant scheduledEndTimeOrElse(Instant defaultValue) {
/* 562 */     return !this.scheduledEndTime_absent ? this.scheduledEndTime_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isDescriptionPresent() {
/* 566 */     return !this.description_absent;
/*     */   }
/*     */   
/*     */   public String descriptionOrElse(String defaultValue) {
/* 570 */     return !this.description_absent ? this.description_value : defaultValue;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\ScheduledEventCreateMono.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */