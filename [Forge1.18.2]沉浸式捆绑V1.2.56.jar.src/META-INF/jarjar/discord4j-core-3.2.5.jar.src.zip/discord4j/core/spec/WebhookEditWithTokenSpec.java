/*     */ package discord4j.core.spec;
/*     */ 
/*     */ import com.google.errorprone.annotations.CanIgnoreReturnValue;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import discord4j.rest.util.Image;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "WebhookEditWithTokenSpecGenerator", generator = "Immutables")
/*     */ public final class WebhookEditWithTokenSpec
/*     */   implements WebhookEditWithTokenSpecGenerator
/*     */ {
/*     */   @Nullable
/*     */   private final String reason;
/*     */   private final String name_value;
/*     */   private final boolean name_absent;
/*     */   private final Image avatar_value;
/*     */   private final boolean avatar_absent;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   
/*     */   private WebhookEditWithTokenSpec() {
/*  32 */     this.reason = null;
/*  33 */     Possible<String> name$impl = Possible.absent();
/*  34 */     Possible<Image> avatar$impl = Possible.absent();
/*  35 */     this.name_value = name$impl.toOptional().orElse(null);
/*  36 */     this.name_absent = name$impl.isAbsent();
/*  37 */     this.avatar_value = avatar$impl.toOptional().orElse(null);
/*  38 */     this.avatar_absent = avatar$impl.isAbsent();
/*  39 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private WebhookEditWithTokenSpec(@Nullable String reason, Possible<String> name, Possible<Image> avatar) {
/*  46 */     this.reason = reason;
/*  47 */     Possible<String> name$impl = name;
/*  48 */     Possible<Image> avatar$impl = avatar;
/*  49 */     this.name_value = name$impl.toOptional().orElse(null);
/*  50 */     this.name_absent = name$impl.isAbsent();
/*  51 */     this.avatar_value = avatar$impl.toOptional().orElse(null);
/*  52 */     this.avatar_absent = avatar$impl.isAbsent();
/*  53 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  59 */   private volatile transient InitShim initShim = new InitShim();
/*     */   
/*     */   @Generated(from = "WebhookEditWithTokenSpecGenerator", generator = "Immutables")
/*     */   private final class InitShim
/*     */   {
/*     */     private String formatInitCycleMessage() {
/*  65 */       List<String> attributes = new ArrayList<>();
/*  66 */       return "Cannot build WebhookEditWithTokenSpec, attribute initializers form cycle " + attributes;
/*     */     }
/*     */ 
/*     */     
/*     */     private InitShim() {}
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String reason() {
/*  76 */     return this.reason;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<String> name() {
/*  84 */     return this.name_absent ? Possible.absent() : Possible.of(this.name_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Image> avatar() {
/*  92 */     return this.avatar_absent ? Possible.absent() : Possible.of(this.avatar_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final WebhookEditWithTokenSpec withReason(@Nullable String value) {
/* 102 */     if (Objects.equals(this.reason, value)) return this; 
/* 103 */     return validate(new WebhookEditWithTokenSpec(value, name(), avatar()));
/*     */   }
/*     */   
/*     */   public WebhookEditWithTokenSpec withName(Possible<String> value) {
/* 107 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/* 108 */     return validate(new WebhookEditWithTokenSpec(this.reason, newValue, avatar()));
/*     */   }
/*     */   
/*     */   public WebhookEditWithTokenSpec withName(String value) {
/* 112 */     Possible<String> newValue = Possible.of(value);
/* 113 */     return validate(new WebhookEditWithTokenSpec(this.reason, newValue, avatar()));
/*     */   }
/*     */   
/*     */   public WebhookEditWithTokenSpec withAvatar(Possible<Image> value) {
/* 117 */     Possible<Image> newValue = Objects.<Possible<Image>>requireNonNull(value);
/* 118 */     return validate(new WebhookEditWithTokenSpec(this.reason, name(), newValue));
/*     */   }
/*     */   
/*     */   public WebhookEditWithTokenSpec withAvatar(Image value) {
/* 122 */     Possible<Image> newValue = Possible.of(value);
/* 123 */     return validate(new WebhookEditWithTokenSpec(this.reason, name(), newValue));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 132 */     if (this == another) return true; 
/* 133 */     return (another instanceof WebhookEditWithTokenSpec && 
/* 134 */       equalTo(0, (WebhookEditWithTokenSpec)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, WebhookEditWithTokenSpec another) {
/* 138 */     return (Objects.equals(this.reason, another.reason) && 
/* 139 */       name().equals(another.name()) && 
/* 140 */       avatar().equals(another.avatar()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 149 */     int h = 5381;
/* 150 */     h += (h << 5) + Objects.hashCode(this.reason);
/* 151 */     h += (h << 5) + name().hashCode();
/* 152 */     h += (h << 5) + avatar().hashCode();
/* 153 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 162 */     return "WebhookEditWithTokenSpec{reason=" + this.reason + ", name=" + 
/*     */       
/* 164 */       name().toString() + ", avatar=" + 
/* 165 */       avatar().toString() + "}";
/*     */   }
/*     */ 
/*     */   
/* 169 */   private static final WebhookEditWithTokenSpec INSTANCE = validate(new WebhookEditWithTokenSpec());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static WebhookEditWithTokenSpec create() {
/* 176 */     return INSTANCE;
/*     */   }
/*     */   
/*     */   private static WebhookEditWithTokenSpec validate(WebhookEditWithTokenSpec instance) {
/* 180 */     return (INSTANCE != null && INSTANCE.equalTo(0, instance)) ? INSTANCE : instance;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static WebhookEditWithTokenSpec copyOf(WebhookEditWithTokenSpecGenerator instance) {
/* 191 */     if (instance instanceof WebhookEditWithTokenSpec) {
/* 192 */       return (WebhookEditWithTokenSpec)instance;
/*     */     }
/* 194 */     return builder()
/* 195 */       .from(instance)
/* 196 */       .build();
/*     */   }
/*     */   
/*     */   public boolean isNamePresent() {
/* 200 */     return !this.name_absent;
/*     */   }
/*     */   
/*     */   public String nameOrElse(String defaultValue) {
/* 204 */     return !this.name_absent ? this.name_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isAvatarPresent() {
/* 208 */     return !this.avatar_absent;
/*     */   }
/*     */   
/*     */   public Image avatarOrElse(Image defaultValue) {
/* 212 */     return !this.avatar_absent ? this.avatar_value : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 227 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "WebhookEditWithTokenSpecGenerator", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/* 239 */     private Possible<String> name_possible = Possible.absent();
/* 240 */     private Possible<Image> avatar_possible = Possible.absent();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private String reason;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(WebhookEditWithTokenSpec instance) {
/* 254 */       return from(instance);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     final Builder from(WebhookEditWithTokenSpecGenerator instance) {
/* 264 */       Objects.requireNonNull(instance, "instance");
/* 265 */       String reasonValue = instance.reason();
/* 266 */       if (reasonValue != null) {
/* 267 */         reason(reasonValue);
/*     */       }
/* 269 */       name(instance.name());
/* 270 */       avatar(instance.avatar());
/* 271 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder reason(@Nullable String reason) {
/* 281 */       this.reason = reason;
/* 282 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder name(Possible<String> value) {
/* 287 */       this.name_possible = value;
/* 288 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder name(String value) {
/* 293 */       this.name_possible = Possible.of(value);
/* 294 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder avatar(Possible<Image> value) {
/* 299 */       this.avatar_possible = value;
/* 300 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder avatar(Image value) {
/* 305 */       this.avatar_possible = Possible.of(value);
/* 306 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public WebhookEditWithTokenSpec build() {
/* 315 */       return WebhookEditWithTokenSpec.validate(new WebhookEditWithTokenSpec(this.reason, name_build(), avatar_build()));
/*     */     }
/*     */     
/*     */     private Possible<String> name_build() {
/* 319 */       return this.name_possible;
/*     */     }
/*     */     
/*     */     private Possible<Image> avatar_build() {
/* 323 */       return this.avatar_possible;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\WebhookEditWithTokenSpec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */