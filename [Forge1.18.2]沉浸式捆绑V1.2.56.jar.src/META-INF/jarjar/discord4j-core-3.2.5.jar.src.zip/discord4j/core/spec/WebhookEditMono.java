/*     */ package discord4j.core.spec;
/*     */ 
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.object.entity.Webhook;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import discord4j.rest.util.Image;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "WebhookEditMonoGenerator", generator = "Immutables")
/*     */ public final class WebhookEditMono
/*     */   extends WebhookEditMonoGenerator
/*     */ {
/*     */   @Nullable
/*     */   private final String reason;
/*     */   private final String name_value;
/*     */   private final boolean name_absent;
/*     */   private final Image avatar_value;
/*     */   private final boolean avatar_absent;
/*     */   private final Snowflake channelId_value;
/*     */   private final boolean channelId_absent;
/*     */   private final Webhook webhook;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   private volatile transient InitShim initShim;
/*     */   
/*     */   private WebhookEditMono(Webhook webhook) {
/*  71 */     this.initShim = new InitShim(); this.webhook = Objects.<Webhook>requireNonNull(webhook, "webhook"); this.reason = null; Possible<String> name$impl = Possible.absent(); Possible<Image> avatar$impl = Possible.absent(); Possible<Snowflake> channelId$impl = Possible.absent(); this.name_value = name$impl.toOptional().orElse(null); this.name_absent = name$impl.isAbsent(); this.avatar_value = avatar$impl.toOptional().orElse(null); this.avatar_absent = avatar$impl.isAbsent(); this.channelId_value = channelId$impl.toOptional().orElse(null); this.channelId_absent = channelId$impl.isAbsent(); this.initShim = null; } private WebhookEditMono(@Nullable String reason, Possible<String> name, Possible<Image> avatar, Possible<Snowflake> channelId, Webhook webhook) { this.initShim = new InitShim(); this.reason = reason; Possible<String> name$impl = name; Possible<Image> avatar$impl = avatar; Possible<Snowflake> channelId$impl = channelId; this.webhook = webhook; this.name_value = name$impl.toOptional().orElse(null);
/*     */     this.name_absent = name$impl.isAbsent();
/*     */     this.avatar_value = avatar$impl.toOptional().orElse(null);
/*     */     this.avatar_absent = avatar$impl.isAbsent();
/*     */     this.channelId_value = channelId$impl.toOptional().orElse(null);
/*     */     this.channelId_absent = channelId$impl.isAbsent();
/*  77 */     this.initShim = null; } @Generated(from = "WebhookEditMonoGenerator", generator = "Immutables") private final class InitShim { private InitShim() {} private String formatInitCycleMessage() { List<String> attributes = new ArrayList<>();
/*  78 */       return "Cannot build WebhookEditMono, attribute initializers form cycle " + attributes; }
/*     */      }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String reason() {
/*  88 */     return this.reason;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<String> name() {
/*  96 */     return this.name_absent ? Possible.absent() : Possible.of(this.name_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Image> avatar() {
/* 104 */     return this.avatar_absent ? Possible.absent() : Possible.of(this.avatar_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Snowflake> channelId() {
/* 112 */     return this.channelId_absent ? Possible.absent() : Possible.of(this.channelId_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Webhook webhook() {
/* 120 */     return this.webhook;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final WebhookEditMono withReason(@Nullable String value) {
/* 130 */     if (Objects.equals(this.reason, value)) return this; 
/* 131 */     return new WebhookEditMono(value, name(), avatar(), channelId(), this.webhook);
/*     */   }
/*     */   
/*     */   public WebhookEditMono withName(Possible<String> value) {
/* 135 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/* 136 */     return new WebhookEditMono(this.reason, newValue, avatar(), channelId(), this.webhook);
/*     */   }
/*     */   
/*     */   public WebhookEditMono withName(String value) {
/* 140 */     Possible<String> newValue = Possible.of(value);
/* 141 */     return new WebhookEditMono(this.reason, newValue, avatar(), channelId(), this.webhook);
/*     */   }
/*     */   
/*     */   public WebhookEditMono withAvatar(Possible<Image> value) {
/* 145 */     Possible<Image> newValue = Objects.<Possible<Image>>requireNonNull(value);
/* 146 */     return new WebhookEditMono(this.reason, name(), newValue, channelId(), this.webhook);
/*     */   }
/*     */   
/*     */   public WebhookEditMono withAvatar(Image value) {
/* 150 */     Possible<Image> newValue = Possible.of(value);
/* 151 */     return new WebhookEditMono(this.reason, name(), newValue, channelId(), this.webhook);
/*     */   }
/*     */   
/*     */   public WebhookEditMono withChannelId(Possible<Snowflake> value) {
/* 155 */     Possible<Snowflake> newValue = Objects.<Possible<Snowflake>>requireNonNull(value);
/* 156 */     return new WebhookEditMono(this.reason, name(), avatar(), newValue, this.webhook);
/*     */   }
/*     */   
/*     */   public WebhookEditMono withChannelId(Snowflake value) {
/* 160 */     Possible<Snowflake> newValue = Possible.of(value);
/* 161 */     return new WebhookEditMono(this.reason, name(), avatar(), newValue, this.webhook);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final WebhookEditMono withWebhook(Webhook value) {
/* 171 */     if (this.webhook == value) return this; 
/* 172 */     Webhook newValue = Objects.<Webhook>requireNonNull(value, "webhook");
/* 173 */     return new WebhookEditMono(this.reason, name(), avatar(), channelId(), newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 182 */     if (this == another) return true; 
/* 183 */     return (another instanceof WebhookEditMono && 
/* 184 */       equalTo(0, (WebhookEditMono)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, WebhookEditMono another) {
/* 188 */     return (Objects.equals(this.reason, another.reason) && 
/* 189 */       name().equals(another.name()) && 
/* 190 */       avatar().equals(another.avatar()) && 
/* 191 */       channelId().equals(another.channelId()) && this.webhook
/* 192 */       .equals(another.webhook));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 201 */     int h = 5381;
/* 202 */     h += (h << 5) + Objects.hashCode(this.reason);
/* 203 */     h += (h << 5) + name().hashCode();
/* 204 */     h += (h << 5) + avatar().hashCode();
/* 205 */     h += (h << 5) + channelId().hashCode();
/* 206 */     h += (h << 5) + this.webhook.hashCode();
/* 207 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 216 */     return "WebhookEditMono{reason=" + this.reason + ", name=" + 
/*     */       
/* 218 */       name().toString() + ", avatar=" + 
/* 219 */       avatar().toString() + ", channelId=" + 
/* 220 */       channelId().toString() + ", webhook=" + this.webhook + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static WebhookEditMono of(Webhook webhook) {
/* 231 */     return new WebhookEditMono(webhook);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static WebhookEditMono copyOf(WebhookEditMonoGenerator instance) {
/* 242 */     if (instance instanceof WebhookEditMono) {
/* 243 */       return (WebhookEditMono)instance;
/*     */     }
/* 245 */     return of(instance.webhook())
/* 246 */       .withReason(instance.reason())
/* 247 */       .withName(instance.name())
/* 248 */       .withAvatar(instance.avatar())
/* 249 */       .withChannelId(instance.channelId());
/*     */   }
/*     */   
/*     */   public boolean isNamePresent() {
/* 253 */     return !this.name_absent;
/*     */   }
/*     */   
/*     */   public String nameOrElse(String defaultValue) {
/* 257 */     return !this.name_absent ? this.name_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isAvatarPresent() {
/* 261 */     return !this.avatar_absent;
/*     */   }
/*     */   
/*     */   public Image avatarOrElse(Image defaultValue) {
/* 265 */     return !this.avatar_absent ? this.avatar_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isChannelIdPresent() {
/* 269 */     return !this.channelId_absent;
/*     */   }
/*     */   
/*     */   public Snowflake channelIdOrElse(Snowflake defaultValue) {
/* 273 */     return !this.channelId_absent ? this.channelId_value : defaultValue;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\WebhookEditMono.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */