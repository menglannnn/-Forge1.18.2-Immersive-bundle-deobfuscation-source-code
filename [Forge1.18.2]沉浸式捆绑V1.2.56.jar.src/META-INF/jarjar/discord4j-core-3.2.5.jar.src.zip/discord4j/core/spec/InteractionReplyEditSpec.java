/*      */ package discord4j.core.spec;
/*      */ 
/*      */ import com.google.errorprone.annotations.CanIgnoreReturnValue;
/*      */ import discord4j.core.object.component.LayoutComponent;
/*      */ import discord4j.core.object.entity.Attachment;
/*      */ import discord4j.discordjson.possible.Possible;
/*      */ import discord4j.rest.util.AllowedMentions;
/*      */ import java.io.InputStream;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.List;
/*      */ import java.util.Objects;
/*      */ import java.util.Optional;
/*      */ import java.util.stream.Collectors;
/*      */ import java.util.stream.StreamSupport;
/*      */ import org.immutables.value.Generated;
/*      */ import reactor.util.annotation.Nullable;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ @Generated(from = "InteractionReplyEditSpecGenerator", generator = "Immutables")
/*      */ public final class InteractionReplyEditSpec
/*      */   implements InteractionReplyEditSpecGenerator
/*      */ {
/*      */   private final String content_value;
/*      */   private final boolean content_absent;
/*      */   private final List<EmbedCreateSpec> embeds_value;
/*      */   private final boolean embeds_absent;
/*      */   private final List<MessageCreateFields.File> files;
/*      */   private final List<MessageCreateFields.FileSpoiler> fileSpoilers;
/*      */   private final AllowedMentions allowedMentions_value;
/*      */   private final boolean allowedMentions_absent;
/*      */   private final List<LayoutComponent> components_value;
/*      */   private final boolean components_absent;
/*      */   private final List<Attachment> attachments_value;
/*      */   private final boolean attachments_absent;
/*      */   private static final byte STAGE_INITIALIZING = -1;
/*      */   private static final byte STAGE_UNINITIALIZED = 0;
/*      */   private static final byte STAGE_INITIALIZED = 1;
/*      */   
/*      */   private InteractionReplyEditSpec() {
/*   45 */     Possible<Optional<String>> content$impl = Possible.absent();
/*   46 */     Possible<Optional<List<EmbedCreateSpec>>> embeds$impl = Possible.absent();
/*   47 */     Possible<Optional<AllowedMentions>> allowedMentions$impl = Possible.absent();
/*   48 */     Possible<Optional<List<LayoutComponent>>> components$impl = Possible.absent();
/*   49 */     Possible<Optional<List<Attachment>>> attachments$impl = Possible.absent();
/*   50 */     this.content_value = Possible.flatOpt(content$impl).orElse(null);
/*   51 */     this.content_absent = content$impl.isAbsent();
/*   52 */     this.embeds_value = Possible.flatOpt(embeds$impl).orElse(null);
/*   53 */     this.embeds_absent = embeds$impl.isAbsent();
/*   54 */     this.allowedMentions_value = Possible.flatOpt(allowedMentions$impl).orElse(null);
/*   55 */     this.allowedMentions_absent = allowedMentions$impl.isAbsent();
/*   56 */     this.components_value = Possible.flatOpt(components$impl).orElse(null);
/*   57 */     this.components_absent = components$impl.isAbsent();
/*   58 */     this.attachments_value = Possible.flatOpt(attachments$impl).orElse(null);
/*   59 */     this.attachments_absent = attachments$impl.isAbsent();
/*   60 */     this.files = this.initShim.files();
/*   61 */     this.fileSpoilers = this.initShim.fileSpoilers();
/*   62 */     this.initShim = null;
/*      */   }
/*      */   
/*      */   private InteractionReplyEditSpec(Builder builder) {
/*   66 */     Possible<Optional<String>> content$impl = builder.content_build();
/*   67 */     Possible<Optional<List<EmbedCreateSpec>>> embeds$impl = builder.embeds_build();
/*   68 */     Possible<Optional<AllowedMentions>> allowedMentions$impl = builder.allowedMentions_build();
/*   69 */     Possible<Optional<List<LayoutComponent>>> components$impl = builder.components_build();
/*   70 */     Possible<Optional<List<Attachment>>> attachments$impl = builder.attachments_build();
/*   71 */     if (builder.filesIsSet()) {
/*   72 */       this.initShim.files(createUnmodifiableList(true, builder.files));
/*      */     }
/*   74 */     if (builder.fileSpoilersIsSet()) {
/*   75 */       this.initShim.fileSpoilers(createUnmodifiableList(true, builder.fileSpoilers));
/*      */     }
/*   77 */     this.content_value = Possible.flatOpt(content$impl).orElse(null);
/*   78 */     this.content_absent = content$impl.isAbsent();
/*   79 */     this.embeds_value = Possible.flatOpt(embeds$impl).orElse(null);
/*   80 */     this.embeds_absent = embeds$impl.isAbsent();
/*   81 */     this.allowedMentions_value = Possible.flatOpt(allowedMentions$impl).orElse(null);
/*   82 */     this.allowedMentions_absent = allowedMentions$impl.isAbsent();
/*   83 */     this.components_value = Possible.flatOpt(components$impl).orElse(null);
/*   84 */     this.components_absent = components$impl.isAbsent();
/*   85 */     this.attachments_value = Possible.flatOpt(attachments$impl).orElse(null);
/*   86 */     this.attachments_absent = attachments$impl.isAbsent();
/*   87 */     this.files = this.initShim.files();
/*   88 */     this.fileSpoilers = this.initShim.fileSpoilers();
/*   89 */     this.initShim = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private InteractionReplyEditSpec(Possible<Optional<String>> content, Possible<Optional<List<EmbedCreateSpec>>> embeds, List<MessageCreateFields.File> files, List<MessageCreateFields.FileSpoiler> fileSpoilers, Possible<Optional<AllowedMentions>> allowedMentions, Possible<Optional<List<LayoutComponent>>> components, Possible<Optional<List<Attachment>>> attachments) {
/*  100 */     Possible<Optional<String>> content$impl = content;
/*  101 */     Possible<Optional<List<EmbedCreateSpec>>> embeds$impl = embeds;
/*  102 */     this.initShim.files(files);
/*  103 */     this.initShim.fileSpoilers(fileSpoilers);
/*  104 */     Possible<Optional<AllowedMentions>> allowedMentions$impl = allowedMentions;
/*  105 */     Possible<Optional<List<LayoutComponent>>> components$impl = components;
/*  106 */     Possible<Optional<List<Attachment>>> attachments$impl = attachments;
/*  107 */     this.content_value = Possible.flatOpt(content$impl).orElse(null);
/*  108 */     this.content_absent = content$impl.isAbsent();
/*  109 */     this.embeds_value = Possible.flatOpt(embeds$impl).orElse(null);
/*  110 */     this.embeds_absent = embeds$impl.isAbsent();
/*  111 */     this.allowedMentions_value = Possible.flatOpt(allowedMentions$impl).orElse(null);
/*  112 */     this.allowedMentions_absent = allowedMentions$impl.isAbsent();
/*  113 */     this.components_value = Possible.flatOpt(components$impl).orElse(null);
/*  114 */     this.components_absent = components$impl.isAbsent();
/*  115 */     this.attachments_value = Possible.flatOpt(attachments$impl).orElse(null);
/*  116 */     this.attachments_absent = attachments$impl.isAbsent();
/*  117 */     this.files = this.initShim.files();
/*  118 */     this.fileSpoilers = this.initShim.fileSpoilers();
/*  119 */     this.initShim = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  125 */   private volatile transient InitShim initShim = new InitShim();
/*      */   
/*      */   @Generated(from = "InteractionReplyEditSpecGenerator", generator = "Immutables")
/*      */   private final class InitShim
/*      */   {
/*  130 */     private byte filesBuildStage = 0;
/*      */     private List<MessageCreateFields.File> files;
/*      */     
/*      */     List<MessageCreateFields.File> files() {
/*  134 */       if (this.filesBuildStage == -1) throw new IllegalStateException(formatInitCycleMessage()); 
/*  135 */       if (this.filesBuildStage == 0) {
/*  136 */         this.filesBuildStage = -1;
/*  137 */         this.files = (List)InteractionReplyEditSpec.createUnmodifiableList(false, InteractionReplyEditSpec.createSafeList((Iterable)InteractionReplyEditSpec.this.filesInitialize(), true, false));
/*  138 */         this.filesBuildStage = 1;
/*      */       } 
/*  140 */       return this.files;
/*      */     }
/*      */     
/*      */     void files(List<MessageCreateFields.File> files) {
/*  144 */       this.files = files;
/*  145 */       this.filesBuildStage = 1;
/*      */     }
/*      */     
/*  148 */     private byte fileSpoilersBuildStage = 0;
/*      */     private List<MessageCreateFields.FileSpoiler> fileSpoilers;
/*      */     
/*      */     List<MessageCreateFields.FileSpoiler> fileSpoilers() {
/*  152 */       if (this.fileSpoilersBuildStage == -1) throw new IllegalStateException(formatInitCycleMessage()); 
/*  153 */       if (this.fileSpoilersBuildStage == 0) {
/*  154 */         this.fileSpoilersBuildStage = -1;
/*  155 */         this.fileSpoilers = (List)InteractionReplyEditSpec.createUnmodifiableList(false, InteractionReplyEditSpec.createSafeList((Iterable)InteractionReplyEditSpec.this.fileSpoilersInitialize(), true, false));
/*  156 */         this.fileSpoilersBuildStage = 1;
/*      */       } 
/*  158 */       return this.fileSpoilers;
/*      */     }
/*      */     
/*      */     void fileSpoilers(List<MessageCreateFields.FileSpoiler> fileSpoilers) {
/*  162 */       this.fileSpoilers = fileSpoilers;
/*  163 */       this.fileSpoilersBuildStage = 1;
/*      */     }
/*      */     private InitShim() {}
/*      */     private String formatInitCycleMessage() {
/*  167 */       List<String> attributes = new ArrayList<>();
/*  168 */       if (this.filesBuildStage == -1) attributes.add("files"); 
/*  169 */       if (this.fileSpoilersBuildStage == -1) attributes.add("fileSpoilers"); 
/*  170 */       return "Cannot build InteractionReplyEditSpec, attribute initializers form cycle " + attributes;
/*      */     }
/*      */   }
/*      */   
/*      */   private List<MessageCreateFields.File> filesInitialize() {
/*  175 */     return super.files();
/*      */   }
/*      */   
/*      */   private List<MessageCreateFields.FileSpoiler> fileSpoilersInitialize() {
/*  179 */     return super.fileSpoilers();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Possible<Optional<String>> content() {
/*  187 */     return this.content_absent ? Possible.absent() : 
/*  188 */       Possible.of(Optional.ofNullable(this.content_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Possible<Optional<List<EmbedCreateSpec>>> embeds() {
/*  196 */     return this.embeds_absent ? Possible.absent() : 
/*  197 */       Possible.of(Optional.ofNullable(this.embeds_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<MessageCreateFields.File> files() {
/*  205 */     InitShim shim = this.initShim;
/*  206 */     return (shim != null) ? 
/*  207 */       shim.files() : 
/*  208 */       this.files;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<MessageCreateFields.FileSpoiler> fileSpoilers() {
/*  216 */     InitShim shim = this.initShim;
/*  217 */     return (shim != null) ? 
/*  218 */       shim.fileSpoilers() : 
/*  219 */       this.fileSpoilers;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Possible<Optional<AllowedMentions>> allowedMentions() {
/*  227 */     return this.allowedMentions_absent ? Possible.absent() : 
/*  228 */       Possible.of(Optional.ofNullable(this.allowedMentions_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Possible<Optional<List<LayoutComponent>>> components() {
/*  236 */     return this.components_absent ? Possible.absent() : 
/*  237 */       Possible.of(Optional.ofNullable(this.components_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Possible<Optional<List<Attachment>>> attachments() {
/*  245 */     return this.attachments_absent ? Possible.absent() : 
/*  246 */       Possible.of(Optional.ofNullable(this.attachments_value));
/*      */   }
/*      */   
/*      */   public InteractionReplyEditSpec withContent(Possible<Optional<String>> value) {
/*  250 */     Possible<Optional<String>> newValue = Objects.<Possible<Optional<String>>>requireNonNull(value);
/*  251 */     return validate(new InteractionReplyEditSpec(newValue, 
/*      */           
/*  253 */           embeds(), this.files, this.fileSpoilers, 
/*      */ 
/*      */           
/*  256 */           allowedMentions(), 
/*  257 */           components(), 
/*  258 */           attachments()));
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public InteractionReplyEditSpec withContent(@Nullable String value) {
/*  263 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/*  264 */     return validate(new InteractionReplyEditSpec(newValue, 
/*      */           
/*  266 */           embeds(), this.files, this.fileSpoilers, 
/*      */ 
/*      */           
/*  269 */           allowedMentions(), 
/*  270 */           components(), 
/*  271 */           attachments()));
/*      */   }
/*      */   
/*      */   public InteractionReplyEditSpec withContentOrNull(@Nullable String value) {
/*  275 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/*  276 */     return validate(new InteractionReplyEditSpec(newValue, 
/*      */           
/*  278 */           embeds(), this.files, this.fileSpoilers, 
/*      */ 
/*      */           
/*  281 */           allowedMentions(), 
/*  282 */           components(), 
/*  283 */           attachments()));
/*      */   }
/*      */   
/*      */   public InteractionReplyEditSpec withEmbeds(Possible<Optional<List<EmbedCreateSpec>>> possible) {
/*  287 */     Possible<Optional<List<EmbedCreateSpec>>> newValue = Objects.<Possible<Optional<List<EmbedCreateSpec>>>>requireNonNull(possible);
/*  288 */     return validate(new InteractionReplyEditSpec(
/*  289 */           content(), newValue, this.files, this.fileSpoilers, 
/*      */ 
/*      */ 
/*      */           
/*  293 */           allowedMentions(), 
/*  294 */           components(), 
/*  295 */           attachments()));
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public InteractionReplyEditSpec withEmbeds(@Nullable Iterable<EmbedCreateSpec> elements) {
/*  300 */     Possible<Optional<List<EmbedCreateSpec>>> newValue = Possible.of(Optional.<Iterable<EmbedCreateSpec>>ofNullable(elements)
/*  301 */         .map(els -> (List)StreamSupport.stream(els.spliterator(), false).collect(Collectors.toList())));
/*  302 */     return validate(new InteractionReplyEditSpec(
/*  303 */           content(), newValue, this.files, this.fileSpoilers, 
/*      */ 
/*      */ 
/*      */           
/*  307 */           allowedMentions(), 
/*  308 */           components(), 
/*  309 */           attachments()));
/*      */   }
/*      */   
/*      */   public InteractionReplyEditSpec withEmbedsOrNull(@Nullable Iterable<EmbedCreateSpec> elements) {
/*  313 */     Possible<Optional<List<EmbedCreateSpec>>> newValue = Possible.of(Optional.<Iterable<EmbedCreateSpec>>ofNullable(elements)
/*  314 */         .map(els -> (List)StreamSupport.stream(els.spliterator(), false).collect(Collectors.toList())));
/*  315 */     return validate(new InteractionReplyEditSpec(
/*  316 */           content(), newValue, this.files, this.fileSpoilers, 
/*      */ 
/*      */ 
/*      */           
/*  320 */           allowedMentions(), 
/*  321 */           components(), 
/*  322 */           attachments()));
/*      */   }
/*      */   
/*      */   @SafeVarargs
/*      */   public final InteractionReplyEditSpec withEmbeds(EmbedCreateSpec... elements) {
/*  327 */     Possible<Optional<List<EmbedCreateSpec>>> newValue = Possible.of(Optional.of(Arrays.asList(elements)));
/*  328 */     return validate(new InteractionReplyEditSpec(
/*  329 */           content(), newValue, this.files, this.fileSpoilers, 
/*      */ 
/*      */ 
/*      */           
/*  333 */           allowedMentions(), 
/*  334 */           components(), 
/*  335 */           attachments()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final InteractionReplyEditSpec withFiles(MessageCreateFields.File... elements) {
/*  344 */     List<MessageCreateFields.File> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/*  345 */     return validate(new InteractionReplyEditSpec(
/*  346 */           content(), 
/*  347 */           embeds(), newValue, this.fileSpoilers, 
/*      */ 
/*      */           
/*  350 */           allowedMentions(), 
/*  351 */           components(), 
/*  352 */           attachments()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final InteractionReplyEditSpec withFiles(Iterable<? extends MessageCreateFields.File> elements) {
/*  362 */     if (this.files == elements) return this; 
/*  363 */     List<MessageCreateFields.File> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/*  364 */     return validate(new InteractionReplyEditSpec(
/*  365 */           content(), 
/*  366 */           embeds(), newValue, this.fileSpoilers, 
/*      */ 
/*      */           
/*  369 */           allowedMentions(), 
/*  370 */           components(), 
/*  371 */           attachments()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final InteractionReplyEditSpec withFileSpoilers(MessageCreateFields.FileSpoiler... elements) {
/*  380 */     List<MessageCreateFields.FileSpoiler> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/*  381 */     return validate(new InteractionReplyEditSpec(
/*  382 */           content(), 
/*  383 */           embeds(), this.files, newValue, 
/*      */ 
/*      */           
/*  386 */           allowedMentions(), 
/*  387 */           components(), 
/*  388 */           attachments()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final InteractionReplyEditSpec withFileSpoilers(Iterable<? extends MessageCreateFields.FileSpoiler> elements) {
/*  398 */     if (this.fileSpoilers == elements) return this; 
/*  399 */     List<MessageCreateFields.FileSpoiler> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/*  400 */     return validate(new InteractionReplyEditSpec(
/*  401 */           content(), 
/*  402 */           embeds(), this.files, newValue, 
/*      */ 
/*      */           
/*  405 */           allowedMentions(), 
/*  406 */           components(), 
/*  407 */           attachments()));
/*      */   }
/*      */   
/*      */   public InteractionReplyEditSpec withAllowedMentions(Possible<Optional<AllowedMentions>> value) {
/*  411 */     Possible<Optional<AllowedMentions>> newValue = Objects.<Possible<Optional<AllowedMentions>>>requireNonNull(value);
/*  412 */     return validate(new InteractionReplyEditSpec(
/*  413 */           content(), 
/*  414 */           embeds(), this.files, this.fileSpoilers, newValue, 
/*      */ 
/*      */ 
/*      */           
/*  418 */           components(), 
/*  419 */           attachments()));
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public InteractionReplyEditSpec withAllowedMentions(@Nullable AllowedMentions value) {
/*  424 */     Possible<Optional<AllowedMentions>> newValue = Possible.of(Optional.ofNullable(value));
/*  425 */     return validate(new InteractionReplyEditSpec(
/*  426 */           content(), 
/*  427 */           embeds(), this.files, this.fileSpoilers, newValue, 
/*      */ 
/*      */ 
/*      */           
/*  431 */           components(), 
/*  432 */           attachments()));
/*      */   }
/*      */   
/*      */   public InteractionReplyEditSpec withAllowedMentionsOrNull(@Nullable AllowedMentions value) {
/*  436 */     Possible<Optional<AllowedMentions>> newValue = Possible.of(Optional.ofNullable(value));
/*  437 */     return validate(new InteractionReplyEditSpec(
/*  438 */           content(), 
/*  439 */           embeds(), this.files, this.fileSpoilers, newValue, 
/*      */ 
/*      */ 
/*      */           
/*  443 */           components(), 
/*  444 */           attachments()));
/*      */   }
/*      */   
/*      */   public InteractionReplyEditSpec withComponents(Possible<Optional<List<LayoutComponent>>> possible) {
/*  448 */     Possible<Optional<List<LayoutComponent>>> newValue = Objects.<Possible<Optional<List<LayoutComponent>>>>requireNonNull(possible);
/*  449 */     return validate(new InteractionReplyEditSpec(
/*  450 */           content(), 
/*  451 */           embeds(), this.files, this.fileSpoilers, 
/*      */ 
/*      */           
/*  454 */           allowedMentions(), newValue, 
/*      */           
/*  456 */           attachments()));
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public InteractionReplyEditSpec withComponents(@Nullable Iterable<LayoutComponent> elements) {
/*  461 */     Possible<Optional<List<LayoutComponent>>> newValue = Possible.of(Optional.<Iterable<LayoutComponent>>ofNullable(elements)
/*  462 */         .map(els -> (List)StreamSupport.stream(els.spliterator(), false).collect(Collectors.toList())));
/*  463 */     return validate(new InteractionReplyEditSpec(
/*  464 */           content(), 
/*  465 */           embeds(), this.files, this.fileSpoilers, 
/*      */ 
/*      */           
/*  468 */           allowedMentions(), newValue, 
/*      */           
/*  470 */           attachments()));
/*      */   }
/*      */   
/*      */   public InteractionReplyEditSpec withComponentsOrNull(@Nullable Iterable<LayoutComponent> elements) {
/*  474 */     Possible<Optional<List<LayoutComponent>>> newValue = Possible.of(Optional.<Iterable<LayoutComponent>>ofNullable(elements)
/*  475 */         .map(els -> (List)StreamSupport.stream(els.spliterator(), false).collect(Collectors.toList())));
/*  476 */     return validate(new InteractionReplyEditSpec(
/*  477 */           content(), 
/*  478 */           embeds(), this.files, this.fileSpoilers, 
/*      */ 
/*      */           
/*  481 */           allowedMentions(), newValue, 
/*      */           
/*  483 */           attachments()));
/*      */   }
/*      */   
/*      */   @SafeVarargs
/*      */   public final InteractionReplyEditSpec withComponents(LayoutComponent... elements) {
/*  488 */     Possible<Optional<List<LayoutComponent>>> newValue = Possible.of(Optional.of(Arrays.asList(elements)));
/*  489 */     return validate(new InteractionReplyEditSpec(
/*  490 */           content(), 
/*  491 */           embeds(), this.files, this.fileSpoilers, 
/*      */ 
/*      */           
/*  494 */           allowedMentions(), newValue, 
/*      */           
/*  496 */           attachments()));
/*      */   }
/*      */   
/*      */   public InteractionReplyEditSpec withAttachments(Possible<Optional<List<Attachment>>> possible) {
/*  500 */     Possible<Optional<List<Attachment>>> newValue = Objects.<Possible<Optional<List<Attachment>>>>requireNonNull(possible);
/*  501 */     return validate(new InteractionReplyEditSpec(
/*  502 */           content(), 
/*  503 */           embeds(), this.files, this.fileSpoilers, 
/*      */ 
/*      */           
/*  506 */           allowedMentions(), 
/*  507 */           components(), newValue));
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public InteractionReplyEditSpec withAttachments(@Nullable Iterable<Attachment> elements) {
/*  513 */     Possible<Optional<List<Attachment>>> newValue = Possible.of(Optional.<Iterable<Attachment>>ofNullable(elements)
/*  514 */         .map(els -> (List)StreamSupport.stream(els.spliterator(), false).collect(Collectors.toList())));
/*  515 */     return validate(new InteractionReplyEditSpec(
/*  516 */           content(), 
/*  517 */           embeds(), this.files, this.fileSpoilers, 
/*      */ 
/*      */           
/*  520 */           allowedMentions(), 
/*  521 */           components(), newValue));
/*      */   }
/*      */ 
/*      */   
/*      */   public InteractionReplyEditSpec withAttachmentsOrNull(@Nullable Iterable<Attachment> elements) {
/*  526 */     Possible<Optional<List<Attachment>>> newValue = Possible.of(Optional.<Iterable<Attachment>>ofNullable(elements)
/*  527 */         .map(els -> (List)StreamSupport.stream(els.spliterator(), false).collect(Collectors.toList())));
/*  528 */     return validate(new InteractionReplyEditSpec(
/*  529 */           content(), 
/*  530 */           embeds(), this.files, this.fileSpoilers, 
/*      */ 
/*      */           
/*  533 */           allowedMentions(), 
/*  534 */           components(), newValue));
/*      */   }
/*      */ 
/*      */   
/*      */   @SafeVarargs
/*      */   public final InteractionReplyEditSpec withAttachments(Attachment... elements) {
/*  540 */     Possible<Optional<List<Attachment>>> newValue = Possible.of(Optional.of(Arrays.asList(elements)));
/*  541 */     return validate(new InteractionReplyEditSpec(
/*  542 */           content(), 
/*  543 */           embeds(), this.files, this.fileSpoilers, 
/*      */ 
/*      */           
/*  546 */           allowedMentions(), 
/*  547 */           components(), newValue));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean equals(Object another) {
/*  557 */     if (this == another) return true; 
/*  558 */     return (another instanceof InteractionReplyEditSpec && 
/*  559 */       equalTo(0, (InteractionReplyEditSpec)another));
/*      */   }
/*      */   
/*      */   private boolean equalTo(int synthetic, InteractionReplyEditSpec another) {
/*  563 */     return (content().equals(another.content()) && 
/*  564 */       Objects.equals(this.embeds_value, another.embeds_value) && this.files
/*  565 */       .equals(another.files) && this.fileSpoilers
/*  566 */       .equals(another.fileSpoilers) && 
/*  567 */       allowedMentions().equals(another.allowedMentions()) && 
/*  568 */       Objects.equals(this.components_value, another.components_value) && 
/*  569 */       Objects.equals(this.attachments_value, another.attachments_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int hashCode() {
/*  578 */     int h = 5381;
/*  579 */     h += (h << 5) + content().hashCode();
/*  580 */     h += (h << 5) + Objects.hashCode(this.embeds_value);
/*  581 */     h += (h << 5) + this.files.hashCode();
/*  582 */     h += (h << 5) + this.fileSpoilers.hashCode();
/*  583 */     h += (h << 5) + allowedMentions().hashCode();
/*  584 */     h += (h << 5) + Objects.hashCode(this.components_value);
/*  585 */     h += (h << 5) + Objects.hashCode(this.attachments_value);
/*  586 */     return h;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/*  595 */     return "InteractionReplyEditSpec{content=" + 
/*  596 */       content().toString() + ", embeds=" + 
/*  597 */       Objects.toString(this.embeds_value) + ", files=" + this.files + ", fileSpoilers=" + this.fileSpoilers + ", allowedMentions=" + 
/*      */ 
/*      */       
/*  600 */       allowedMentions().toString() + ", components=" + 
/*  601 */       Objects.toString(this.components_value) + ", attachments=" + 
/*  602 */       Objects.toString(this.attachments_value) + "}";
/*      */   }
/*      */ 
/*      */   
/*  606 */   private static final InteractionReplyEditSpec INSTANCE = validate(new InteractionReplyEditSpec());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static InteractionReplyEditSpec create() {
/*  613 */     return INSTANCE;
/*      */   }
/*      */   
/*      */   private static InteractionReplyEditSpec validate(InteractionReplyEditSpec instance) {
/*  617 */     return (INSTANCE != null && INSTANCE.equalTo(0, instance)) ? INSTANCE : instance;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static InteractionReplyEditSpec copyOf(InteractionReplyEditSpecGenerator instance) {
/*  628 */     if (instance instanceof InteractionReplyEditSpec) {
/*  629 */       return (InteractionReplyEditSpec)instance;
/*      */     }
/*  631 */     return builder()
/*  632 */       .from(instance)
/*  633 */       .build();
/*      */   }
/*      */   
/*      */   public boolean isContentPresent() {
/*  637 */     return !this.content_absent;
/*      */   }
/*      */   
/*      */   public String contentOrElse(String defaultValue) {
/*  641 */     return !this.content_absent ? this.content_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isEmbedsPresent() {
/*  645 */     return !this.embeds_absent;
/*      */   }
/*      */   
/*      */   public List<EmbedCreateSpec> embedsOrElse(List<EmbedCreateSpec> defaultValue) {
/*  649 */     return !this.embeds_absent ? this.embeds_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isAllowedMentionsPresent() {
/*  653 */     return !this.allowedMentions_absent;
/*      */   }
/*      */   
/*      */   public AllowedMentions allowedMentionsOrElse(AllowedMentions defaultValue) {
/*  657 */     return !this.allowedMentions_absent ? this.allowedMentions_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isComponentsPresent() {
/*  661 */     return !this.components_absent;
/*      */   }
/*      */   
/*      */   public List<LayoutComponent> componentsOrElse(List<LayoutComponent> defaultValue) {
/*  665 */     return !this.components_absent ? this.components_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isAttachmentsPresent() {
/*  669 */     return !this.attachments_absent;
/*      */   }
/*      */   
/*      */   public List<Attachment> attachmentsOrElse(List<Attachment> defaultValue) {
/*  673 */     return !this.attachments_absent ? this.attachments_value : defaultValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Builder builder() {
/*  692 */     return new Builder();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   @Generated(from = "InteractionReplyEditSpecGenerator", generator = "Immutables")
/*      */   public static final class Builder
/*      */   {
/*      */     private static final long OPT_BIT_FILES = 1L;
/*      */ 
/*      */     
/*      */     private static final long OPT_BIT_FILE_SPOILERS = 2L;
/*      */ 
/*      */     
/*      */     private long optBits;
/*      */     
/*  708 */     private Possible<Optional<String>> content_possible = Possible.absent();
/*  709 */     private List<EmbedCreateSpec> embeds_list = null;
/*      */     private boolean embeds_explicitNull;
/*  711 */     private Possible<Optional<AllowedMentions>> allowedMentions_possible = Possible.absent();
/*  712 */     private List<LayoutComponent> components_list = null;
/*      */     private boolean components_explicitNull;
/*  714 */     private List<Attachment> attachments_list = null;
/*      */     private boolean attachments_explicitNull;
/*  716 */     private List<MessageCreateFields.File> files = new ArrayList<>();
/*  717 */     private List<MessageCreateFields.FileSpoiler> fileSpoilers = new ArrayList<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder from(InteractionReplyEditSpec instance) {
/*  731 */       return from(instance);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     final Builder from(InteractionReplyEditSpecGenerator instance) {
/*  741 */       Objects.requireNonNull(instance, "instance");
/*  742 */       content(instance.content());
/*  743 */       embeds(instance.embeds());
/*  744 */       addAllFiles(instance.files());
/*  745 */       addAllFileSpoilers(instance.fileSpoilers());
/*  746 */       allowedMentions(instance.allowedMentions());
/*  747 */       components(instance.components());
/*  748 */       attachments(instance.attachments());
/*  749 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder content(Possible<Optional<String>> value) {
/*  754 */       this.content_possible = value;
/*  755 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     @CanIgnoreReturnValue
/*      */     public Builder content(@Nullable String value) {
/*  761 */       this.content_possible = Possible.of(Optional.ofNullable(value));
/*  762 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder contentOrNull(@Nullable String value) {
/*  767 */       this.content_possible = Possible.of(Optional.ofNullable(value));
/*  768 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder addEmbed(EmbedCreateSpec element) {
/*  773 */       embeds_getOrCreate().add(element);
/*  774 */       this.embeds_explicitNull = false;
/*  775 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder addAllEmbeds(List<EmbedCreateSpec> elements) {
/*  780 */       embeds_getOrCreate().addAll(elements);
/*  781 */       this.embeds_explicitNull = false;
/*  782 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder embeds(Possible<Optional<List<EmbedCreateSpec>>> elements) {
/*  787 */       this.embeds_list = null;
/*  788 */       this.embeds_explicitNull = false;
/*  789 */       elements.toOptional().ifPresent(e -> {
/*      */             if (e.isPresent()) {
/*      */               embeds_getOrCreate().addAll(e.get());
/*      */             } else {
/*      */               this.embeds_explicitNull = true;
/*      */             } 
/*      */           });
/*  796 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder embeds(List<EmbedCreateSpec> elements) {
/*  801 */       this.embeds_list = new ArrayList<>(elements);
/*  802 */       this.embeds_explicitNull = false;
/*  803 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     @CanIgnoreReturnValue
/*      */     public Builder embeds(@Nullable Iterable<EmbedCreateSpec> elements) {
/*  809 */       if (elements == null) {
/*  810 */         this.embeds_list = null;
/*  811 */         this.embeds_explicitNull = true;
/*      */       } else {
/*  813 */         this.embeds_list = (List<EmbedCreateSpec>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/*  814 */         this.embeds_explicitNull = false;
/*      */       } 
/*  816 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder embedsOrNull(@Nullable Iterable<EmbedCreateSpec> elements) {
/*  821 */       if (elements == null) {
/*  822 */         this.embeds_list = null;
/*  823 */         this.embeds_explicitNull = true;
/*      */       } else {
/*  825 */         this.embeds_list = (List<EmbedCreateSpec>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/*  826 */         this.embeds_explicitNull = false;
/*      */       } 
/*  828 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public final Builder addFile(MessageCreateFields.File element) {
/*  838 */       element = ImmutableMessageCreateFields.File.copyOf(element);
/*  839 */       this.files.add(Objects.<MessageCreateFields.File>requireNonNull(element, "files element"));
/*  840 */       this.optBits |= 0x1L;
/*  841 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addFile(String name, InputStream inputStream) {
/*  851 */       return addFile(ImmutableMessageCreateFields.File.of(name, inputStream));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public final Builder addFiles(MessageCreateFields.File... elements) {
/*  861 */       for (MessageCreateFields.File element : elements) {
/*  862 */         element = ImmutableMessageCreateFields.File.copyOf(element);
/*  863 */         this.files.add(Objects.<MessageCreateFields.File>requireNonNull(element, "files element"));
/*      */       } 
/*  865 */       this.optBits |= 0x1L;
/*  866 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public final Builder files(Iterable<? extends MessageCreateFields.File> elements) {
/*  877 */       this.files.clear();
/*  878 */       return addAllFiles(elements);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public final Builder addAllFiles(Iterable<? extends MessageCreateFields.File> elements) {
/*  888 */       for (MessageCreateFields.File element : elements) {
/*  889 */         element = ImmutableMessageCreateFields.File.copyOf(element);
/*  890 */         this.files.add(Objects.<MessageCreateFields.File>requireNonNull(element, "files element"));
/*      */       } 
/*  892 */       this.optBits |= 0x1L;
/*  893 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public final Builder addFileSpoiler(MessageCreateFields.FileSpoiler element) {
/*  903 */       element = ImmutableMessageCreateFields.FileSpoiler.copyOf(element);
/*  904 */       this.fileSpoilers.add(Objects.<MessageCreateFields.FileSpoiler>requireNonNull(element, "fileSpoilers element"));
/*  905 */       this.optBits |= 0x2L;
/*  906 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addFileSpoiler(String name, InputStream inputStream) {
/*  916 */       return addFileSpoiler(ImmutableMessageCreateFields.FileSpoiler.of(name, inputStream));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public final Builder addFileSpoilers(MessageCreateFields.FileSpoiler... elements) {
/*  926 */       for (MessageCreateFields.FileSpoiler element : elements) {
/*  927 */         element = ImmutableMessageCreateFields.FileSpoiler.copyOf(element);
/*  928 */         this.fileSpoilers.add(Objects.<MessageCreateFields.FileSpoiler>requireNonNull(element, "fileSpoilers element"));
/*      */       } 
/*  930 */       this.optBits |= 0x2L;
/*  931 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public final Builder fileSpoilers(Iterable<? extends MessageCreateFields.FileSpoiler> elements) {
/*  942 */       this.fileSpoilers.clear();
/*  943 */       return addAllFileSpoilers(elements);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public final Builder addAllFileSpoilers(Iterable<? extends MessageCreateFields.FileSpoiler> elements) {
/*  953 */       for (MessageCreateFields.FileSpoiler element : elements) {
/*  954 */         element = ImmutableMessageCreateFields.FileSpoiler.copyOf(element);
/*  955 */         this.fileSpoilers.add(Objects.<MessageCreateFields.FileSpoiler>requireNonNull(element, "fileSpoilers element"));
/*      */       } 
/*  957 */       this.optBits |= 0x2L;
/*  958 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder allowedMentions(Possible<Optional<AllowedMentions>> value) {
/*  963 */       this.allowedMentions_possible = value;
/*  964 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     @CanIgnoreReturnValue
/*      */     public Builder allowedMentions(@Nullable AllowedMentions value) {
/*  970 */       this.allowedMentions_possible = Possible.of(Optional.ofNullable(value));
/*  971 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder allowedMentionsOrNull(@Nullable AllowedMentions value) {
/*  976 */       this.allowedMentions_possible = Possible.of(Optional.ofNullable(value));
/*  977 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder addComponent(LayoutComponent element) {
/*  982 */       components_getOrCreate().add(element);
/*  983 */       this.components_explicitNull = false;
/*  984 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder addAllComponents(List<LayoutComponent> elements) {
/*  989 */       components_getOrCreate().addAll(elements);
/*  990 */       this.components_explicitNull = false;
/*  991 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder components(Possible<Optional<List<LayoutComponent>>> elements) {
/*  996 */       this.components_list = null;
/*  997 */       this.components_explicitNull = false;
/*  998 */       elements.toOptional().ifPresent(e -> {
/*      */             if (e.isPresent()) {
/*      */               components_getOrCreate().addAll(e.get());
/*      */             } else {
/*      */               this.components_explicitNull = true;
/*      */             } 
/*      */           });
/* 1005 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder components(List<LayoutComponent> elements) {
/* 1010 */       this.components_list = new ArrayList<>(elements);
/* 1011 */       this.components_explicitNull = false;
/* 1012 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     @CanIgnoreReturnValue
/*      */     public Builder components(@Nullable Iterable<LayoutComponent> elements) {
/* 1018 */       if (elements == null) {
/* 1019 */         this.components_list = null;
/* 1020 */         this.components_explicitNull = true;
/*      */       } else {
/* 1022 */         this.components_list = (List<LayoutComponent>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/* 1023 */         this.components_explicitNull = false;
/*      */       } 
/* 1025 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder componentsOrNull(@Nullable Iterable<LayoutComponent> elements) {
/* 1030 */       if (elements == null) {
/* 1031 */         this.components_list = null;
/* 1032 */         this.components_explicitNull = true;
/*      */       } else {
/* 1034 */         this.components_list = (List<LayoutComponent>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/* 1035 */         this.components_explicitNull = false;
/*      */       } 
/* 1037 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder addAttachment(Attachment element) {
/* 1042 */       attachments_getOrCreate().add(element);
/* 1043 */       this.attachments_explicitNull = false;
/* 1044 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder addAllAttachments(List<Attachment> elements) {
/* 1049 */       attachments_getOrCreate().addAll(elements);
/* 1050 */       this.attachments_explicitNull = false;
/* 1051 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder attachments(Possible<Optional<List<Attachment>>> elements) {
/* 1056 */       this.attachments_list = null;
/* 1057 */       this.attachments_explicitNull = false;
/* 1058 */       elements.toOptional().ifPresent(e -> {
/*      */             if (e.isPresent()) {
/*      */               attachments_getOrCreate().addAll(e.get());
/*      */             } else {
/*      */               this.attachments_explicitNull = true;
/*      */             } 
/*      */           });
/* 1065 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder attachments(List<Attachment> elements) {
/* 1070 */       this.attachments_list = new ArrayList<>(elements);
/* 1071 */       this.attachments_explicitNull = false;
/* 1072 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     @CanIgnoreReturnValue
/*      */     public Builder attachments(@Nullable Iterable<Attachment> elements) {
/* 1078 */       if (elements == null) {
/* 1079 */         this.attachments_list = null;
/* 1080 */         this.attachments_explicitNull = true;
/*      */       } else {
/* 1082 */         this.attachments_list = (List<Attachment>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/* 1083 */         this.attachments_explicitNull = false;
/*      */       } 
/* 1085 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder attachmentsOrNull(@Nullable Iterable<Attachment> elements) {
/* 1090 */       if (elements == null) {
/* 1091 */         this.attachments_list = null;
/* 1092 */         this.attachments_explicitNull = true;
/*      */       } else {
/* 1094 */         this.attachments_list = (List<Attachment>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/* 1095 */         this.attachments_explicitNull = false;
/*      */       } 
/* 1097 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public InteractionReplyEditSpec build() {
/* 1106 */       return InteractionReplyEditSpec.validate(new InteractionReplyEditSpec(this));
/*      */     }
/*      */     
/*      */     private boolean filesIsSet() {
/* 1110 */       return ((this.optBits & 0x1L) != 0L);
/*      */     }
/*      */     
/*      */     private boolean fileSpoilersIsSet() {
/* 1114 */       return ((this.optBits & 0x2L) != 0L);
/*      */     }
/*      */     
/*      */     private Possible<Optional<String>> content_build() {
/* 1118 */       return this.content_possible;
/*      */     }
/*      */     
/*      */     private Possible<Optional<List<EmbedCreateSpec>>> embeds_build() {
/* 1122 */       return (this.embeds_list == null && !this.embeds_explicitNull) ? Possible.absent() : 
/* 1123 */         Possible.of(Optional.ofNullable(this.embeds_list));
/*      */     }
/*      */     
/*      */     private List<EmbedCreateSpec> embeds_getOrCreate() {
/* 1127 */       if (this.embeds_list == null) {
/* 1128 */         this.embeds_list = new ArrayList<>();
/*      */       }
/* 1130 */       return this.embeds_list;
/*      */     }
/*      */     
/*      */     private Possible<Optional<AllowedMentions>> allowedMentions_build() {
/* 1134 */       return this.allowedMentions_possible;
/*      */     }
/*      */     
/*      */     private Possible<Optional<List<LayoutComponent>>> components_build() {
/* 1138 */       return (this.components_list == null && !this.components_explicitNull) ? Possible.absent() : 
/* 1139 */         Possible.of(Optional.ofNullable(this.components_list));
/*      */     }
/*      */     
/*      */     private List<LayoutComponent> components_getOrCreate() {
/* 1143 */       if (this.components_list == null) {
/* 1144 */         this.components_list = new ArrayList<>();
/*      */       }
/* 1146 */       return this.components_list;
/*      */     }
/*      */     
/*      */     private Possible<Optional<List<Attachment>>> attachments_build() {
/* 1150 */       return (this.attachments_list == null && !this.attachments_explicitNull) ? Possible.absent() : 
/* 1151 */         Possible.of(Optional.ofNullable(this.attachments_list));
/*      */     }
/*      */     
/*      */     private List<Attachment> attachments_getOrCreate() {
/* 1155 */       if (this.attachments_list == null) {
/* 1156 */         this.attachments_list = new ArrayList<>();
/*      */       }
/* 1158 */       return this.attachments_list;
/*      */     }
/*      */     private Builder() {} }
/*      */   
/*      */   private static <T> List<T> createSafeList(Iterable<? extends T> iterable, boolean checkNulls, boolean skipNulls) {
/*      */     ArrayList<T> list;
/* 1164 */     if (iterable instanceof Collection) {
/* 1165 */       int size = ((Collection)iterable).size();
/* 1166 */       if (size == 0) return Collections.emptyList(); 
/* 1167 */       list = new ArrayList<>();
/*      */     } else {
/* 1169 */       list = new ArrayList<>();
/*      */     } 
/* 1171 */     for (T element : iterable) {
/* 1172 */       if (skipNulls && element == null)
/* 1173 */         continue;  if (checkNulls) Objects.requireNonNull(element, "element"); 
/* 1174 */       list.add(element);
/*      */     } 
/* 1176 */     return list;
/*      */   }
/*      */   
/*      */   private static <T> List<T> createUnmodifiableList(boolean clone, List<T> list) {
/* 1180 */     switch (list.size()) { case 0:
/* 1181 */         return Collections.emptyList();
/* 1182 */       case 1: return Collections.singletonList(list.get(0)); }
/*      */     
/* 1184 */     if (clone) {
/* 1185 */       return Collections.unmodifiableList(new ArrayList<>(list));
/*      */     }
/* 1187 */     if (list instanceof ArrayList) {
/* 1188 */       ((ArrayList)list).trimToSize();
/*      */     }
/* 1190 */     return Collections.unmodifiableList(list);
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\InteractionReplyEditSpec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */