/*      */ package discord4j.core.spec;
/*      */ 
/*      */ import com.google.errorprone.annotations.CanIgnoreReturnValue;
/*      */ import discord4j.core.object.component.LayoutComponent;
/*      */ import discord4j.discordjson.possible.Possible;
/*      */ import discord4j.rest.util.AllowedMentions;
/*      */ import java.io.InputStream;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.List;
/*      */ import java.util.Objects;
/*      */ import java.util.stream.Collectors;
/*      */ import java.util.stream.StreamSupport;
/*      */ import org.immutables.value.Generated;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ @Generated(from = "InteractionApplicationCommandCallbackSpecGenerator", generator = "Immutables")
/*      */ public final class InteractionApplicationCommandCallbackSpec
/*      */   implements InteractionApplicationCommandCallbackSpecGenerator
/*      */ {
/*      */   private final String content_value;
/*      */   private final boolean content_absent;
/*      */   private final Boolean tts_value;
/*      */   private final boolean tts_absent;
/*      */   private final Boolean ephemeral_value;
/*      */   private final boolean ephemeral_absent;
/*      */   private final List<EmbedCreateSpec> embeds_value;
/*      */   private final boolean embeds_absent;
/*      */   private final List<MessageCreateFields.File> files;
/*      */   private final List<MessageCreateFields.FileSpoiler> fileSpoilers;
/*      */   private final AllowedMentions allowedMentions_value;
/*      */   private final boolean allowedMentions_absent;
/*      */   private final List<LayoutComponent> components_value;
/*      */   private final boolean components_absent;
/*      */   private static final byte STAGE_INITIALIZING = -1;
/*      */   private static final byte STAGE_UNINITIALIZED = 0;
/*      */   private static final byte STAGE_INITIALIZED = 1;
/*      */   
/*      */   private InteractionApplicationCommandCallbackSpec() {
/*   48 */     Possible<String> content$impl = Possible.absent();
/*   49 */     Possible<Boolean> tts$impl = Possible.absent();
/*   50 */     Possible<Boolean> ephemeral$impl = Possible.absent();
/*   51 */     Possible<List<EmbedCreateSpec>> embeds$impl = Possible.absent();
/*   52 */     Possible<AllowedMentions> allowedMentions$impl = Possible.absent();
/*   53 */     Possible<List<LayoutComponent>> components$impl = Possible.absent();
/*   54 */     this.content_value = content$impl.toOptional().orElse(null);
/*   55 */     this.content_absent = content$impl.isAbsent();
/*   56 */     this.tts_value = tts$impl.toOptional().orElse(null);
/*   57 */     this.tts_absent = tts$impl.isAbsent();
/*   58 */     this.ephemeral_value = ephemeral$impl.toOptional().orElse(null);
/*   59 */     this.ephemeral_absent = ephemeral$impl.isAbsent();
/*   60 */     this.embeds_value = embeds$impl.toOptional().orElse(null);
/*   61 */     this.embeds_absent = embeds$impl.isAbsent();
/*   62 */     this.allowedMentions_value = allowedMentions$impl.toOptional().orElse(null);
/*   63 */     this.allowedMentions_absent = allowedMentions$impl.isAbsent();
/*   64 */     this.components_value = components$impl.toOptional().orElse(null);
/*   65 */     this.components_absent = components$impl.isAbsent();
/*   66 */     this.files = this.initShim.files();
/*   67 */     this.fileSpoilers = this.initShim.fileSpoilers();
/*   68 */     this.initShim = null;
/*      */   }
/*      */   
/*      */   private InteractionApplicationCommandCallbackSpec(Builder builder) {
/*   72 */     Possible<String> content$impl = builder.content_build();
/*   73 */     Possible<Boolean> tts$impl = builder.tts_build();
/*   74 */     Possible<Boolean> ephemeral$impl = builder.ephemeral_build();
/*   75 */     Possible<List<EmbedCreateSpec>> embeds$impl = builder.embeds_build();
/*   76 */     Possible<AllowedMentions> allowedMentions$impl = builder.allowedMentions_build();
/*   77 */     Possible<List<LayoutComponent>> components$impl = builder.components_build();
/*   78 */     if (builder.filesIsSet()) {
/*   79 */       this.initShim.files(createUnmodifiableList(true, builder.files));
/*      */     }
/*   81 */     if (builder.fileSpoilersIsSet()) {
/*   82 */       this.initShim.fileSpoilers(createUnmodifiableList(true, builder.fileSpoilers));
/*      */     }
/*   84 */     this.content_value = content$impl.toOptional().orElse(null);
/*   85 */     this.content_absent = content$impl.isAbsent();
/*   86 */     this.tts_value = tts$impl.toOptional().orElse(null);
/*   87 */     this.tts_absent = tts$impl.isAbsent();
/*   88 */     this.ephemeral_value = ephemeral$impl.toOptional().orElse(null);
/*   89 */     this.ephemeral_absent = ephemeral$impl.isAbsent();
/*   90 */     this.embeds_value = embeds$impl.toOptional().orElse(null);
/*   91 */     this.embeds_absent = embeds$impl.isAbsent();
/*   92 */     this.allowedMentions_value = allowedMentions$impl.toOptional().orElse(null);
/*   93 */     this.allowedMentions_absent = allowedMentions$impl.isAbsent();
/*   94 */     this.components_value = components$impl.toOptional().orElse(null);
/*   95 */     this.components_absent = components$impl.isAbsent();
/*   96 */     this.files = this.initShim.files();
/*   97 */     this.fileSpoilers = this.initShim.fileSpoilers();
/*   98 */     this.initShim = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private InteractionApplicationCommandCallbackSpec(Possible<String> content, Possible<Boolean> tts, Possible<Boolean> ephemeral, Possible<List<EmbedCreateSpec>> embeds, List<MessageCreateFields.File> files, List<MessageCreateFields.FileSpoiler> fileSpoilers, Possible<AllowedMentions> allowedMentions, Possible<List<LayoutComponent>> components) {
/*  110 */     Possible<String> content$impl = content;
/*  111 */     Possible<Boolean> tts$impl = tts;
/*  112 */     Possible<Boolean> ephemeral$impl = ephemeral;
/*  113 */     Possible<List<EmbedCreateSpec>> embeds$impl = embeds;
/*  114 */     this.initShim.files(files);
/*  115 */     this.initShim.fileSpoilers(fileSpoilers);
/*  116 */     Possible<AllowedMentions> allowedMentions$impl = allowedMentions;
/*  117 */     Possible<List<LayoutComponent>> components$impl = components;
/*  118 */     this.content_value = content$impl.toOptional().orElse(null);
/*  119 */     this.content_absent = content$impl.isAbsent();
/*  120 */     this.tts_value = tts$impl.toOptional().orElse(null);
/*  121 */     this.tts_absent = tts$impl.isAbsent();
/*  122 */     this.ephemeral_value = ephemeral$impl.toOptional().orElse(null);
/*  123 */     this.ephemeral_absent = ephemeral$impl.isAbsent();
/*  124 */     this.embeds_value = embeds$impl.toOptional().orElse(null);
/*  125 */     this.embeds_absent = embeds$impl.isAbsent();
/*  126 */     this.allowedMentions_value = allowedMentions$impl.toOptional().orElse(null);
/*  127 */     this.allowedMentions_absent = allowedMentions$impl.isAbsent();
/*  128 */     this.components_value = components$impl.toOptional().orElse(null);
/*  129 */     this.components_absent = components$impl.isAbsent();
/*  130 */     this.files = this.initShim.files();
/*  131 */     this.fileSpoilers = this.initShim.fileSpoilers();
/*  132 */     this.initShim = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  138 */   private volatile transient InitShim initShim = new InitShim();
/*      */   
/*      */   @Generated(from = "InteractionApplicationCommandCallbackSpecGenerator", generator = "Immutables")
/*      */   private final class InitShim
/*      */   {
/*  143 */     private byte filesBuildStage = 0;
/*      */     private List<MessageCreateFields.File> files;
/*      */     
/*      */     List<MessageCreateFields.File> files() {
/*  147 */       if (this.filesBuildStage == -1) throw new IllegalStateException(formatInitCycleMessage()); 
/*  148 */       if (this.filesBuildStage == 0) {
/*  149 */         this.filesBuildStage = -1;
/*  150 */         this.files = (List)InteractionApplicationCommandCallbackSpec.createUnmodifiableList(false, InteractionApplicationCommandCallbackSpec.createSafeList((Iterable)InteractionApplicationCommandCallbackSpec.this.filesInitialize(), true, false));
/*  151 */         this.filesBuildStage = 1;
/*      */       } 
/*  153 */       return this.files;
/*      */     }
/*      */     
/*      */     void files(List<MessageCreateFields.File> files) {
/*  157 */       this.files = files;
/*  158 */       this.filesBuildStage = 1;
/*      */     }
/*      */     
/*  161 */     private byte fileSpoilersBuildStage = 0;
/*      */     private List<MessageCreateFields.FileSpoiler> fileSpoilers;
/*      */     
/*      */     List<MessageCreateFields.FileSpoiler> fileSpoilers() {
/*  165 */       if (this.fileSpoilersBuildStage == -1) throw new IllegalStateException(formatInitCycleMessage()); 
/*  166 */       if (this.fileSpoilersBuildStage == 0) {
/*  167 */         this.fileSpoilersBuildStage = -1;
/*  168 */         this.fileSpoilers = (List)InteractionApplicationCommandCallbackSpec.createUnmodifiableList(false, InteractionApplicationCommandCallbackSpec.createSafeList((Iterable)InteractionApplicationCommandCallbackSpec.this.fileSpoilersInitialize(), true, false));
/*  169 */         this.fileSpoilersBuildStage = 1;
/*      */       } 
/*  171 */       return this.fileSpoilers;
/*      */     }
/*      */     
/*      */     void fileSpoilers(List<MessageCreateFields.FileSpoiler> fileSpoilers) {
/*  175 */       this.fileSpoilers = fileSpoilers;
/*  176 */       this.fileSpoilersBuildStage = 1;
/*      */     }
/*      */     private InitShim() {}
/*      */     private String formatInitCycleMessage() {
/*  180 */       List<String> attributes = new ArrayList<>();
/*  181 */       if (this.filesBuildStage == -1) attributes.add("files"); 
/*  182 */       if (this.fileSpoilersBuildStage == -1) attributes.add("fileSpoilers"); 
/*  183 */       return "Cannot build InteractionApplicationCommandCallbackSpec, attribute initializers form cycle " + attributes;
/*      */     }
/*      */   }
/*      */   
/*      */   private List<MessageCreateFields.File> filesInitialize() {
/*  188 */     return super.files();
/*      */   }
/*      */   
/*      */   private List<MessageCreateFields.FileSpoiler> fileSpoilersInitialize() {
/*  192 */     return super.fileSpoilers();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Possible<String> content() {
/*  200 */     return this.content_absent ? Possible.absent() : Possible.of(this.content_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Possible<Boolean> tts() {
/*  208 */     return this.tts_absent ? Possible.absent() : Possible.of(this.tts_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Possible<Boolean> ephemeral() {
/*  216 */     return this.ephemeral_absent ? Possible.absent() : Possible.of(this.ephemeral_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Possible<List<EmbedCreateSpec>> embeds() {
/*  224 */     return this.embeds_absent ? Possible.absent() : 
/*  225 */       Possible.of(this.embeds_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<MessageCreateFields.File> files() {
/*  233 */     InitShim shim = this.initShim;
/*  234 */     return (shim != null) ? 
/*  235 */       shim.files() : 
/*  236 */       this.files;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<MessageCreateFields.FileSpoiler> fileSpoilers() {
/*  244 */     InitShim shim = this.initShim;
/*  245 */     return (shim != null) ? 
/*  246 */       shim.fileSpoilers() : 
/*  247 */       this.fileSpoilers;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Possible<AllowedMentions> allowedMentions() {
/*  255 */     return this.allowedMentions_absent ? Possible.absent() : Possible.of(this.allowedMentions_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Possible<List<LayoutComponent>> components() {
/*  263 */     return this.components_absent ? Possible.absent() : 
/*  264 */       Possible.of(this.components_value);
/*      */   }
/*      */   
/*      */   public InteractionApplicationCommandCallbackSpec withContent(Possible<String> value) {
/*  268 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/*  269 */     return validate(new InteractionApplicationCommandCallbackSpec(newValue, 
/*      */           
/*  271 */           tts(), 
/*  272 */           ephemeral(), 
/*  273 */           embeds(), this.files, this.fileSpoilers, 
/*      */ 
/*      */           
/*  276 */           allowedMentions(), 
/*  277 */           components()));
/*      */   }
/*      */   
/*      */   public InteractionApplicationCommandCallbackSpec withContent(String value) {
/*  281 */     Possible<String> newValue = Possible.of(value);
/*  282 */     return validate(new InteractionApplicationCommandCallbackSpec(newValue, 
/*      */           
/*  284 */           tts(), 
/*  285 */           ephemeral(), 
/*  286 */           embeds(), this.files, this.fileSpoilers, 
/*      */ 
/*      */           
/*  289 */           allowedMentions(), 
/*  290 */           components()));
/*      */   }
/*      */   
/*      */   public InteractionApplicationCommandCallbackSpec withTts(Possible<Boolean> value) {
/*  294 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/*  295 */     return validate(new InteractionApplicationCommandCallbackSpec(
/*  296 */           content(), newValue, 
/*      */           
/*  298 */           ephemeral(), 
/*  299 */           embeds(), this.files, this.fileSpoilers, 
/*      */ 
/*      */           
/*  302 */           allowedMentions(), 
/*  303 */           components()));
/*      */   }
/*      */   
/*      */   public InteractionApplicationCommandCallbackSpec withTts(Boolean value) {
/*  307 */     Possible<Boolean> newValue = Possible.of(value);
/*  308 */     return validate(new InteractionApplicationCommandCallbackSpec(
/*  309 */           content(), newValue, 
/*      */           
/*  311 */           ephemeral(), 
/*  312 */           embeds(), this.files, this.fileSpoilers, 
/*      */ 
/*      */           
/*  315 */           allowedMentions(), 
/*  316 */           components()));
/*      */   }
/*      */   
/*      */   public InteractionApplicationCommandCallbackSpec withEphemeral(Possible<Boolean> value) {
/*  320 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/*  321 */     return validate(new InteractionApplicationCommandCallbackSpec(
/*  322 */           content(), 
/*  323 */           tts(), newValue, 
/*      */           
/*  325 */           embeds(), this.files, this.fileSpoilers, 
/*      */ 
/*      */           
/*  328 */           allowedMentions(), 
/*  329 */           components()));
/*      */   }
/*      */   
/*      */   public InteractionApplicationCommandCallbackSpec withEphemeral(Boolean value) {
/*  333 */     Possible<Boolean> newValue = Possible.of(value);
/*  334 */     return validate(new InteractionApplicationCommandCallbackSpec(
/*  335 */           content(), 
/*  336 */           tts(), newValue, 
/*      */           
/*  338 */           embeds(), this.files, this.fileSpoilers, 
/*      */ 
/*      */           
/*  341 */           allowedMentions(), 
/*  342 */           components()));
/*      */   }
/*      */   
/*      */   public InteractionApplicationCommandCallbackSpec withEmbeds(Possible<List<EmbedCreateSpec>> possible) {
/*  346 */     Possible<List<EmbedCreateSpec>> newValue = Objects.<Possible<List<EmbedCreateSpec>>>requireNonNull(possible);
/*  347 */     return validate(new InteractionApplicationCommandCallbackSpec(
/*  348 */           content(), 
/*  349 */           tts(), 
/*  350 */           ephemeral(), newValue, this.files, this.fileSpoilers, 
/*      */ 
/*      */ 
/*      */           
/*  354 */           allowedMentions(), 
/*  355 */           components()));
/*      */   }
/*      */   
/*      */   public InteractionApplicationCommandCallbackSpec withEmbeds(Iterable<EmbedCreateSpec> elements) {
/*  359 */     Possible<List<EmbedCreateSpec>> newValue = Possible.of(
/*  360 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/*  361 */     return validate(new InteractionApplicationCommandCallbackSpec(
/*  362 */           content(), 
/*  363 */           tts(), 
/*  364 */           ephemeral(), newValue, this.files, this.fileSpoilers, 
/*      */ 
/*      */ 
/*      */           
/*  368 */           allowedMentions(), 
/*  369 */           components()));
/*      */   }
/*      */   
/*      */   @SafeVarargs
/*      */   public final InteractionApplicationCommandCallbackSpec withEmbeds(EmbedCreateSpec... elements) {
/*  374 */     Possible<List<EmbedCreateSpec>> newValue = Possible.of(Arrays.asList(elements));
/*  375 */     return validate(new InteractionApplicationCommandCallbackSpec(
/*  376 */           content(), 
/*  377 */           tts(), 
/*  378 */           ephemeral(), newValue, this.files, this.fileSpoilers, 
/*      */ 
/*      */ 
/*      */           
/*  382 */           allowedMentions(), 
/*  383 */           components()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final InteractionApplicationCommandCallbackSpec withFiles(MessageCreateFields.File... elements) {
/*  392 */     List<MessageCreateFields.File> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/*  393 */     return validate(new InteractionApplicationCommandCallbackSpec(
/*  394 */           content(), 
/*  395 */           tts(), 
/*  396 */           ephemeral(), 
/*  397 */           embeds(), newValue, this.fileSpoilers, 
/*      */ 
/*      */           
/*  400 */           allowedMentions(), 
/*  401 */           components()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final InteractionApplicationCommandCallbackSpec withFiles(Iterable<? extends MessageCreateFields.File> elements) {
/*  411 */     if (this.files == elements) return this; 
/*  412 */     List<MessageCreateFields.File> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/*  413 */     return validate(new InteractionApplicationCommandCallbackSpec(
/*  414 */           content(), 
/*  415 */           tts(), 
/*  416 */           ephemeral(), 
/*  417 */           embeds(), newValue, this.fileSpoilers, 
/*      */ 
/*      */           
/*  420 */           allowedMentions(), 
/*  421 */           components()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final InteractionApplicationCommandCallbackSpec withFileSpoilers(MessageCreateFields.FileSpoiler... elements) {
/*  430 */     List<MessageCreateFields.FileSpoiler> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/*  431 */     return validate(new InteractionApplicationCommandCallbackSpec(
/*  432 */           content(), 
/*  433 */           tts(), 
/*  434 */           ephemeral(), 
/*  435 */           embeds(), this.files, newValue, 
/*      */ 
/*      */           
/*  438 */           allowedMentions(), 
/*  439 */           components()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final InteractionApplicationCommandCallbackSpec withFileSpoilers(Iterable<? extends MessageCreateFields.FileSpoiler> elements) {
/*  449 */     if (this.fileSpoilers == elements) return this; 
/*  450 */     List<MessageCreateFields.FileSpoiler> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/*  451 */     return validate(new InteractionApplicationCommandCallbackSpec(
/*  452 */           content(), 
/*  453 */           tts(), 
/*  454 */           ephemeral(), 
/*  455 */           embeds(), this.files, newValue, 
/*      */ 
/*      */           
/*  458 */           allowedMentions(), 
/*  459 */           components()));
/*      */   }
/*      */   
/*      */   public InteractionApplicationCommandCallbackSpec withAllowedMentions(Possible<AllowedMentions> value) {
/*  463 */     Possible<AllowedMentions> newValue = Objects.<Possible<AllowedMentions>>requireNonNull(value);
/*  464 */     return validate(new InteractionApplicationCommandCallbackSpec(
/*  465 */           content(), 
/*  466 */           tts(), 
/*  467 */           ephemeral(), 
/*  468 */           embeds(), this.files, this.fileSpoilers, newValue, 
/*      */ 
/*      */ 
/*      */           
/*  472 */           components()));
/*      */   }
/*      */   
/*      */   public InteractionApplicationCommandCallbackSpec withAllowedMentions(AllowedMentions value) {
/*  476 */     Possible<AllowedMentions> newValue = Possible.of(value);
/*  477 */     return validate(new InteractionApplicationCommandCallbackSpec(
/*  478 */           content(), 
/*  479 */           tts(), 
/*  480 */           ephemeral(), 
/*  481 */           embeds(), this.files, this.fileSpoilers, newValue, 
/*      */ 
/*      */ 
/*      */           
/*  485 */           components()));
/*      */   }
/*      */   
/*      */   public InteractionApplicationCommandCallbackSpec withComponents(Possible<List<LayoutComponent>> possible) {
/*  489 */     Possible<List<LayoutComponent>> newValue = Objects.<Possible<List<LayoutComponent>>>requireNonNull(possible);
/*  490 */     return validate(new InteractionApplicationCommandCallbackSpec(
/*  491 */           content(), 
/*  492 */           tts(), 
/*  493 */           ephemeral(), 
/*  494 */           embeds(), this.files, this.fileSpoilers, 
/*      */ 
/*      */           
/*  497 */           allowedMentions(), newValue));
/*      */   }
/*      */ 
/*      */   
/*      */   public InteractionApplicationCommandCallbackSpec withComponents(Iterable<LayoutComponent> elements) {
/*  502 */     Possible<List<LayoutComponent>> newValue = Possible.of(
/*  503 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/*  504 */     return validate(new InteractionApplicationCommandCallbackSpec(
/*  505 */           content(), 
/*  506 */           tts(), 
/*  507 */           ephemeral(), 
/*  508 */           embeds(), this.files, this.fileSpoilers, 
/*      */ 
/*      */           
/*  511 */           allowedMentions(), newValue));
/*      */   }
/*      */ 
/*      */   
/*      */   @SafeVarargs
/*      */   public final InteractionApplicationCommandCallbackSpec withComponents(LayoutComponent... elements) {
/*  517 */     Possible<List<LayoutComponent>> newValue = Possible.of(Arrays.asList(elements));
/*  518 */     return validate(new InteractionApplicationCommandCallbackSpec(
/*  519 */           content(), 
/*  520 */           tts(), 
/*  521 */           ephemeral(), 
/*  522 */           embeds(), this.files, this.fileSpoilers, 
/*      */ 
/*      */           
/*  525 */           allowedMentions(), newValue));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean equals(Object another) {
/*  535 */     if (this == another) return true; 
/*  536 */     return (another instanceof InteractionApplicationCommandCallbackSpec && 
/*  537 */       equalTo(0, (InteractionApplicationCommandCallbackSpec)another));
/*      */   }
/*      */   
/*      */   private boolean equalTo(int synthetic, InteractionApplicationCommandCallbackSpec another) {
/*  541 */     return (content().equals(another.content()) && 
/*  542 */       tts().equals(another.tts()) && 
/*  543 */       ephemeral().equals(another.ephemeral()) && 
/*  544 */       Objects.equals(this.embeds_value, another.embeds_value) && this.files
/*  545 */       .equals(another.files) && this.fileSpoilers
/*  546 */       .equals(another.fileSpoilers) && 
/*  547 */       allowedMentions().equals(another.allowedMentions()) && 
/*  548 */       Objects.equals(this.components_value, another.components_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int hashCode() {
/*  557 */     int h = 5381;
/*  558 */     h += (h << 5) + content().hashCode();
/*  559 */     h += (h << 5) + tts().hashCode();
/*  560 */     h += (h << 5) + ephemeral().hashCode();
/*  561 */     h += (h << 5) + Objects.hashCode(this.embeds_value);
/*  562 */     h += (h << 5) + this.files.hashCode();
/*  563 */     h += (h << 5) + this.fileSpoilers.hashCode();
/*  564 */     h += (h << 5) + allowedMentions().hashCode();
/*  565 */     h += (h << 5) + Objects.hashCode(this.components_value);
/*  566 */     return h;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/*  575 */     return "InteractionApplicationCommandCallbackSpec{content=" + 
/*  576 */       content().toString() + ", tts=" + 
/*  577 */       tts().toString() + ", ephemeral=" + 
/*  578 */       ephemeral().toString() + ", embeds=" + 
/*  579 */       Objects.toString(this.embeds_value) + ", files=" + this.files + ", fileSpoilers=" + this.fileSpoilers + ", allowedMentions=" + 
/*      */ 
/*      */       
/*  582 */       allowedMentions().toString() + ", components=" + 
/*  583 */       Objects.toString(this.components_value) + "}";
/*      */   }
/*      */ 
/*      */   
/*  587 */   private static final InteractionApplicationCommandCallbackSpec INSTANCE = validate(new InteractionApplicationCommandCallbackSpec());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static InteractionApplicationCommandCallbackSpec create() {
/*  594 */     return INSTANCE;
/*      */   }
/*      */   
/*      */   private static InteractionApplicationCommandCallbackSpec validate(InteractionApplicationCommandCallbackSpec instance) {
/*  598 */     return (INSTANCE != null && INSTANCE.equalTo(0, instance)) ? INSTANCE : instance;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static InteractionApplicationCommandCallbackSpec copyOf(InteractionApplicationCommandCallbackSpecGenerator instance) {
/*  609 */     if (instance instanceof InteractionApplicationCommandCallbackSpec) {
/*  610 */       return (InteractionApplicationCommandCallbackSpec)instance;
/*      */     }
/*  612 */     return builder()
/*  613 */       .from(instance)
/*  614 */       .build();
/*      */   }
/*      */   
/*      */   public boolean isContentPresent() {
/*  618 */     return !this.content_absent;
/*      */   }
/*      */   
/*      */   public String contentOrElse(String defaultValue) {
/*  622 */     return !this.content_absent ? this.content_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isTtsPresent() {
/*  626 */     return !this.tts_absent;
/*      */   }
/*      */   
/*      */   public Boolean ttsOrElse(Boolean defaultValue) {
/*  630 */     return !this.tts_absent ? this.tts_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isEphemeralPresent() {
/*  634 */     return !this.ephemeral_absent;
/*      */   }
/*      */   
/*      */   public Boolean ephemeralOrElse(Boolean defaultValue) {
/*  638 */     return !this.ephemeral_absent ? this.ephemeral_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isEmbedsPresent() {
/*  642 */     return !this.embeds_absent;
/*      */   }
/*      */   
/*      */   public List<EmbedCreateSpec> embedsOrElse(List<EmbedCreateSpec> defaultValue) {
/*  646 */     return !this.embeds_absent ? this.embeds_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isAllowedMentionsPresent() {
/*  650 */     return !this.allowedMentions_absent;
/*      */   }
/*      */   
/*      */   public AllowedMentions allowedMentionsOrElse(AllowedMentions defaultValue) {
/*  654 */     return !this.allowedMentions_absent ? this.allowedMentions_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isComponentsPresent() {
/*  658 */     return !this.components_absent;
/*      */   }
/*      */   
/*      */   public List<LayoutComponent> componentsOrElse(List<LayoutComponent> defaultValue) {
/*  662 */     return !this.components_absent ? this.components_value : defaultValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Builder builder() {
/*  682 */     return new Builder();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   @Generated(from = "InteractionApplicationCommandCallbackSpecGenerator", generator = "Immutables")
/*      */   public static final class Builder
/*      */   {
/*      */     private static final long OPT_BIT_FILES = 1L;
/*      */ 
/*      */     
/*      */     private static final long OPT_BIT_FILE_SPOILERS = 2L;
/*      */ 
/*      */     
/*      */     private long optBits;
/*      */     
/*  698 */     private Possible<String> content_possible = Possible.absent();
/*  699 */     private Possible<Boolean> tts_possible = Possible.absent();
/*  700 */     private Possible<Boolean> ephemeral_possible = Possible.absent();
/*  701 */     private List<EmbedCreateSpec> embeds_list = null;
/*  702 */     private Possible<AllowedMentions> allowedMentions_possible = Possible.absent();
/*  703 */     private List<LayoutComponent> components_list = null;
/*  704 */     private List<MessageCreateFields.File> files = new ArrayList<>();
/*  705 */     private List<MessageCreateFields.FileSpoiler> fileSpoilers = new ArrayList<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder from(InteractionApplicationCommandCallbackSpec instance) {
/*  719 */       return from(instance);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     final Builder from(InteractionApplicationCommandCallbackSpecGenerator instance) {
/*  729 */       Objects.requireNonNull(instance, "instance");
/*  730 */       content(instance.content());
/*  731 */       tts(instance.tts());
/*  732 */       ephemeral(instance.ephemeral());
/*  733 */       embeds(instance.embeds());
/*  734 */       addAllFiles(instance.files());
/*  735 */       addAllFileSpoilers(instance.fileSpoilers());
/*  736 */       allowedMentions(instance.allowedMentions());
/*  737 */       components(instance.components());
/*  738 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder content(Possible<String> value) {
/*  743 */       this.content_possible = value;
/*  744 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder content(String value) {
/*  749 */       this.content_possible = Possible.of(value);
/*  750 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder tts(Possible<Boolean> value) {
/*  755 */       this.tts_possible = value;
/*  756 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder tts(Boolean value) {
/*  761 */       this.tts_possible = Possible.of(value);
/*  762 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder ephemeral(Possible<Boolean> value) {
/*  767 */       this.ephemeral_possible = value;
/*  768 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder ephemeral(Boolean value) {
/*  773 */       this.ephemeral_possible = Possible.of(value);
/*  774 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder addEmbed(EmbedCreateSpec element) {
/*  779 */       embeds_getOrCreate().add(element);
/*  780 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder addAllEmbeds(List<EmbedCreateSpec> elements) {
/*  785 */       embeds_getOrCreate().addAll(elements);
/*  786 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder embeds(Possible<List<EmbedCreateSpec>> elements) {
/*  791 */       this.embeds_list = null;
/*  792 */       elements.toOptional().ifPresent(e -> embeds_getOrCreate().addAll(e));
/*  793 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder embeds(List<EmbedCreateSpec> elements) {
/*  798 */       this.embeds_list = new ArrayList<>(elements);
/*  799 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder embeds(Iterable<EmbedCreateSpec> elements) {
/*  804 */       this.embeds_list = (List<EmbedCreateSpec>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/*  805 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public final Builder addFile(MessageCreateFields.File element) {
/*  815 */       element = ImmutableMessageCreateFields.File.copyOf(element);
/*  816 */       this.files.add(Objects.<MessageCreateFields.File>requireNonNull(element, "files element"));
/*  817 */       this.optBits |= 0x1L;
/*  818 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addFile(String name, InputStream inputStream) {
/*  828 */       return addFile(ImmutableMessageCreateFields.File.of(name, inputStream));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public final Builder addFiles(MessageCreateFields.File... elements) {
/*  838 */       for (MessageCreateFields.File element : elements) {
/*  839 */         element = ImmutableMessageCreateFields.File.copyOf(element);
/*  840 */         this.files.add(Objects.<MessageCreateFields.File>requireNonNull(element, "files element"));
/*      */       } 
/*  842 */       this.optBits |= 0x1L;
/*  843 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public final Builder files(Iterable<? extends MessageCreateFields.File> elements) {
/*  854 */       this.files.clear();
/*  855 */       return addAllFiles(elements);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public final Builder addAllFiles(Iterable<? extends MessageCreateFields.File> elements) {
/*  865 */       for (MessageCreateFields.File element : elements) {
/*  866 */         element = ImmutableMessageCreateFields.File.copyOf(element);
/*  867 */         this.files.add(Objects.<MessageCreateFields.File>requireNonNull(element, "files element"));
/*      */       } 
/*  869 */       this.optBits |= 0x1L;
/*  870 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public final Builder addFileSpoiler(MessageCreateFields.FileSpoiler element) {
/*  880 */       element = ImmutableMessageCreateFields.FileSpoiler.copyOf(element);
/*  881 */       this.fileSpoilers.add(Objects.<MessageCreateFields.FileSpoiler>requireNonNull(element, "fileSpoilers element"));
/*  882 */       this.optBits |= 0x2L;
/*  883 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addFileSpoiler(String name, InputStream inputStream) {
/*  893 */       return addFileSpoiler(ImmutableMessageCreateFields.FileSpoiler.of(name, inputStream));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public final Builder addFileSpoilers(MessageCreateFields.FileSpoiler... elements) {
/*  903 */       for (MessageCreateFields.FileSpoiler element : elements) {
/*  904 */         element = ImmutableMessageCreateFields.FileSpoiler.copyOf(element);
/*  905 */         this.fileSpoilers.add(Objects.<MessageCreateFields.FileSpoiler>requireNonNull(element, "fileSpoilers element"));
/*      */       } 
/*  907 */       this.optBits |= 0x2L;
/*  908 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public final Builder fileSpoilers(Iterable<? extends MessageCreateFields.FileSpoiler> elements) {
/*  919 */       this.fileSpoilers.clear();
/*  920 */       return addAllFileSpoilers(elements);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public final Builder addAllFileSpoilers(Iterable<? extends MessageCreateFields.FileSpoiler> elements) {
/*  930 */       for (MessageCreateFields.FileSpoiler element : elements) {
/*  931 */         element = ImmutableMessageCreateFields.FileSpoiler.copyOf(element);
/*  932 */         this.fileSpoilers.add(Objects.<MessageCreateFields.FileSpoiler>requireNonNull(element, "fileSpoilers element"));
/*      */       } 
/*  934 */       this.optBits |= 0x2L;
/*  935 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder allowedMentions(Possible<AllowedMentions> value) {
/*  940 */       this.allowedMentions_possible = value;
/*  941 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder allowedMentions(AllowedMentions value) {
/*  946 */       this.allowedMentions_possible = Possible.of(value);
/*  947 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder addComponent(LayoutComponent element) {
/*  952 */       components_getOrCreate().add(element);
/*  953 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder addAllComponents(List<LayoutComponent> elements) {
/*  958 */       components_getOrCreate().addAll(elements);
/*  959 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder components(Possible<List<LayoutComponent>> elements) {
/*  964 */       this.components_list = null;
/*  965 */       elements.toOptional().ifPresent(e -> components_getOrCreate().addAll(e));
/*  966 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder components(List<LayoutComponent> elements) {
/*  971 */       this.components_list = new ArrayList<>(elements);
/*  972 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder components(Iterable<LayoutComponent> elements) {
/*  977 */       this.components_list = (List<LayoutComponent>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/*  978 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public InteractionApplicationCommandCallbackSpec build() {
/*  987 */       return InteractionApplicationCommandCallbackSpec.validate(new InteractionApplicationCommandCallbackSpec(this));
/*      */     }
/*      */     
/*      */     private boolean filesIsSet() {
/*  991 */       return ((this.optBits & 0x1L) != 0L);
/*      */     }
/*      */     
/*      */     private boolean fileSpoilersIsSet() {
/*  995 */       return ((this.optBits & 0x2L) != 0L);
/*      */     }
/*      */     
/*      */     private Possible<String> content_build() {
/*  999 */       return this.content_possible;
/*      */     }
/*      */     
/*      */     private Possible<Boolean> tts_build() {
/* 1003 */       return this.tts_possible;
/*      */     }
/*      */     
/*      */     private Possible<Boolean> ephemeral_build() {
/* 1007 */       return this.ephemeral_possible;
/*      */     }
/*      */     
/*      */     private Possible<List<EmbedCreateSpec>> embeds_build() {
/* 1011 */       return (this.embeds_list == null) ? Possible.absent() : 
/* 1012 */         Possible.of(this.embeds_list);
/*      */     }
/*      */     
/*      */     private List<EmbedCreateSpec> embeds_getOrCreate() {
/* 1016 */       if (this.embeds_list == null) {
/* 1017 */         this.embeds_list = new ArrayList<>();
/*      */       }
/* 1019 */       return this.embeds_list;
/*      */     }
/*      */     
/*      */     private Possible<AllowedMentions> allowedMentions_build() {
/* 1023 */       return this.allowedMentions_possible;
/*      */     }
/*      */     
/*      */     private Possible<List<LayoutComponent>> components_build() {
/* 1027 */       return (this.components_list == null) ? Possible.absent() : 
/* 1028 */         Possible.of(this.components_list);
/*      */     }
/*      */     
/*      */     private List<LayoutComponent> components_getOrCreate() {
/* 1032 */       if (this.components_list == null) {
/* 1033 */         this.components_list = new ArrayList<>();
/*      */       }
/* 1035 */       return this.components_list;
/*      */     }
/*      */     private Builder() {} }
/*      */   
/*      */   private static <T> List<T> createSafeList(Iterable<? extends T> iterable, boolean checkNulls, boolean skipNulls) {
/*      */     ArrayList<T> list;
/* 1041 */     if (iterable instanceof Collection) {
/* 1042 */       int size = ((Collection)iterable).size();
/* 1043 */       if (size == 0) return Collections.emptyList(); 
/* 1044 */       list = new ArrayList<>();
/*      */     } else {
/* 1046 */       list = new ArrayList<>();
/*      */     } 
/* 1048 */     for (T element : iterable) {
/* 1049 */       if (skipNulls && element == null)
/* 1050 */         continue;  if (checkNulls) Objects.requireNonNull(element, "element"); 
/* 1051 */       list.add(element);
/*      */     } 
/* 1053 */     return list;
/*      */   }
/*      */   
/*      */   private static <T> List<T> createUnmodifiableList(boolean clone, List<T> list) {
/* 1057 */     switch (list.size()) { case 0:
/* 1058 */         return Collections.emptyList();
/* 1059 */       case 1: return Collections.singletonList(list.get(0)); }
/*      */     
/* 1061 */     if (clone) {
/* 1062 */       return Collections.unmodifiableList(new ArrayList<>(list));
/*      */     }
/* 1064 */     if (list instanceof ArrayList) {
/* 1065 */       ((ArrayList)list).trimToSize();
/*      */     }
/* 1067 */     return Collections.unmodifiableList(list);
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\InteractionApplicationCommandCallbackSpec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */