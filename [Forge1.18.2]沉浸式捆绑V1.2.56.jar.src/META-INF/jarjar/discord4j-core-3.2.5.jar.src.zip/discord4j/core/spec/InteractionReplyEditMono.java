/*     */ package discord4j.core.spec;
/*     */ 
/*     */ import discord4j.core.event.domain.interaction.DeferrableInteractionEvent;
/*     */ import discord4j.core.object.component.LayoutComponent;
/*     */ import discord4j.core.object.entity.Attachment;
/*     */ import discord4j.core.object.entity.Message;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import discord4j.rest.util.AllowedMentions;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.stream.StreamSupport;
/*     */ import org.immutables.value.Generated;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "InteractionReplyEditMonoGenerator", generator = "Immutables")
/*     */ public final class InteractionReplyEditMono
/*     */   extends InteractionReplyEditMonoGenerator
/*     */ {
/*     */   private final String content_value;
/*     */   private final boolean content_absent;
/*     */   private final List<EmbedCreateSpec> embeds_value;
/*     */   private final boolean embeds_absent;
/*     */   private final List<MessageCreateFields.File> files;
/*     */   private final List<MessageCreateFields.FileSpoiler> fileSpoilers;
/*     */   private final AllowedMentions allowedMentions_value;
/*     */   private final boolean allowedMentions_absent;
/*     */   private final List<LayoutComponent> components_value;
/*     */   private final boolean components_absent;
/*     */   private final List<Attachment> attachments_value;
/*     */   private final boolean attachments_absent;
/*     */   private final DeferrableInteractionEvent event;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   private volatile transient InitShim initShim;
/*     */   
/*     */   private InteractionReplyEditMono(DeferrableInteractionEvent event) {
/* 100 */     this.initShim = new InitShim(); this.event = Objects.<DeferrableInteractionEvent>requireNonNull(event, "event"); Possible<Optional<String>> content$impl = Possible.absent(); Possible<Optional<List<EmbedCreateSpec>>> embeds$impl = Possible.absent(); Possible<Optional<AllowedMentions>> allowedMentions$impl = Possible.absent(); Possible<Optional<List<LayoutComponent>>> components$impl = Possible.absent(); Possible<Optional<List<Attachment>>> attachments$impl = Possible.absent(); this.content_value = Possible.flatOpt(content$impl).orElse(null); this.content_absent = content$impl.isAbsent(); this.embeds_value = Possible.flatOpt(embeds$impl).orElse(null); this.embeds_absent = embeds$impl.isAbsent(); this.allowedMentions_value = Possible.flatOpt(allowedMentions$impl).orElse(null); this.allowedMentions_absent = allowedMentions$impl.isAbsent(); this.components_value = Possible.flatOpt(components$impl).orElse(null); this.components_absent = components$impl.isAbsent(); this.attachments_value = Possible.flatOpt(attachments$impl).orElse(null); this.attachments_absent = attachments$impl.isAbsent(); this.files = this.initShim.files(); this.fileSpoilers = this.initShim.fileSpoilers(); this.initShim = null; } private InteractionReplyEditMono(Possible<Optional<String>> content, Possible<Optional<List<EmbedCreateSpec>>> embeds, List<MessageCreateFields.File> files, List<MessageCreateFields.FileSpoiler> fileSpoilers, Possible<Optional<AllowedMentions>> allowedMentions, Possible<Optional<List<LayoutComponent>>> components, Possible<Optional<List<Attachment>>> attachments, DeferrableInteractionEvent event) { this.initShim = new InitShim(); Possible<Optional<String>> content$impl = content; Possible<Optional<List<EmbedCreateSpec>>> embeds$impl = embeds; this.initShim.files(files); this.initShim.fileSpoilers(fileSpoilers); Possible<Optional<AllowedMentions>> allowedMentions$impl = allowedMentions; Possible<Optional<List<LayoutComponent>>> components$impl = components; Possible<Optional<List<Attachment>>> attachments$impl = attachments; this.event = event; this.content_value = Possible.flatOpt(content$impl).orElse(null); this.content_absent = content$impl.isAbsent(); this.embeds_value = Possible.flatOpt(embeds$impl).orElse(null); this.embeds_absent = embeds$impl.isAbsent(); this.allowedMentions_value = Possible.flatOpt(allowedMentions$impl).orElse(null); this.allowedMentions_absent = allowedMentions$impl.isAbsent(); this.components_value = Possible.flatOpt(components$impl).orElse(null); this.components_absent = components$impl.isAbsent();
/*     */     this.attachments_value = Possible.flatOpt(attachments$impl).orElse(null);
/*     */     this.attachments_absent = attachments$impl.isAbsent();
/*     */     this.files = this.initShim.files();
/*     */     this.fileSpoilers = this.initShim.fileSpoilers();
/* 105 */     this.initShim = null; } @Generated(from = "InteractionReplyEditMonoGenerator", generator = "Immutables") private final class InitShim { private byte filesBuildStage = 0;
/*     */     private List<MessageCreateFields.File> files;
/*     */     
/*     */     List<MessageCreateFields.File> files() {
/* 109 */       if (this.filesBuildStage == -1) throw new IllegalStateException(formatInitCycleMessage()); 
/* 110 */       if (this.filesBuildStage == 0) {
/* 111 */         this.filesBuildStage = -1;
/* 112 */         this.files = (List)InteractionReplyEditMono.createUnmodifiableList(false, InteractionReplyEditMono.createSafeList((Iterable)InteractionReplyEditMono.this.files(), true, false));
/* 113 */         this.filesBuildStage = 1;
/*     */       } 
/* 115 */       return this.files;
/*     */     }
/*     */     
/*     */     void files(List<MessageCreateFields.File> files) {
/* 119 */       this.files = files;
/* 120 */       this.filesBuildStage = 1;
/*     */     }
/*     */     
/* 123 */     private byte fileSpoilersBuildStage = 0;
/*     */     private List<MessageCreateFields.FileSpoiler> fileSpoilers;
/*     */     
/*     */     List<MessageCreateFields.FileSpoiler> fileSpoilers() {
/* 127 */       if (this.fileSpoilersBuildStage == -1) throw new IllegalStateException(formatInitCycleMessage()); 
/* 128 */       if (this.fileSpoilersBuildStage == 0) {
/* 129 */         this.fileSpoilersBuildStage = -1;
/* 130 */         this.fileSpoilers = (List)InteractionReplyEditMono.createUnmodifiableList(false, InteractionReplyEditMono.createSafeList((Iterable)InteractionReplyEditMono.this.fileSpoilers(), true, false));
/* 131 */         this.fileSpoilersBuildStage = 1;
/*     */       } 
/* 133 */       return this.fileSpoilers;
/*     */     }
/*     */     
/*     */     void fileSpoilers(List<MessageCreateFields.FileSpoiler> fileSpoilers) {
/* 137 */       this.fileSpoilers = fileSpoilers;
/* 138 */       this.fileSpoilersBuildStage = 1;
/*     */     }
/*     */     
/*     */     private String formatInitCycleMessage() {
/* 142 */       List<String> attributes = new ArrayList<>();
/* 143 */       if (this.filesBuildStage == -1) attributes.add("files"); 
/* 144 */       if (this.fileSpoilersBuildStage == -1) attributes.add("fileSpoilers"); 
/* 145 */       return "Cannot build InteractionReplyEditMono, attribute initializers form cycle " + attributes;
/*     */     }
/*     */ 
/*     */     
/*     */     private InitShim() {} }
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Optional<String>> content() {
/* 154 */     return this.content_absent ? Possible.absent() : 
/* 155 */       Possible.of(Optional.ofNullable(this.content_value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Optional<List<EmbedCreateSpec>>> embeds() {
/* 163 */     return this.embeds_absent ? Possible.absent() : 
/* 164 */       Possible.of(Optional.ofNullable(this.embeds_value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<MessageCreateFields.File> files() {
/* 172 */     InitShim shim = this.initShim;
/* 173 */     return (shim != null) ? 
/* 174 */       shim.files() : 
/* 175 */       this.files;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<MessageCreateFields.FileSpoiler> fileSpoilers() {
/* 183 */     InitShim shim = this.initShim;
/* 184 */     return (shim != null) ? 
/* 185 */       shim.fileSpoilers() : 
/* 186 */       this.fileSpoilers;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Optional<AllowedMentions>> allowedMentions() {
/* 194 */     return this.allowedMentions_absent ? Possible.absent() : 
/* 195 */       Possible.of(Optional.ofNullable(this.allowedMentions_value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Optional<List<LayoutComponent>>> components() {
/* 203 */     return this.components_absent ? Possible.absent() : 
/* 204 */       Possible.of(Optional.ofNullable(this.components_value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Optional<List<Attachment>>> attachments() {
/* 212 */     return this.attachments_absent ? Possible.absent() : 
/* 213 */       Possible.of(Optional.ofNullable(this.attachments_value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DeferrableInteractionEvent event() {
/* 221 */     return this.event;
/*     */   }
/*     */   
/*     */   public InteractionReplyEditMono withContent(Possible<Optional<String>> value) {
/* 225 */     Possible<Optional<String>> newValue = Objects.<Possible<Optional<String>>>requireNonNull(value);
/* 226 */     return new InteractionReplyEditMono(newValue, 
/*     */         
/* 228 */         embeds(), this.files, this.fileSpoilers, 
/*     */ 
/*     */         
/* 231 */         allowedMentions(), 
/* 232 */         components(), 
/* 233 */         attachments(), this.event);
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public InteractionReplyEditMono withContent(@Nullable String value) {
/* 239 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/* 240 */     return new InteractionReplyEditMono(newValue, 
/*     */         
/* 242 */         embeds(), this.files, this.fileSpoilers, 
/*     */ 
/*     */         
/* 245 */         allowedMentions(), 
/* 246 */         components(), 
/* 247 */         attachments(), this.event);
/*     */   }
/*     */ 
/*     */   
/*     */   public InteractionReplyEditMono withContentOrNull(@Nullable String value) {
/* 252 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/* 253 */     return new InteractionReplyEditMono(newValue, 
/*     */         
/* 255 */         embeds(), this.files, this.fileSpoilers, 
/*     */ 
/*     */         
/* 258 */         allowedMentions(), 
/* 259 */         components(), 
/* 260 */         attachments(), this.event);
/*     */   }
/*     */ 
/*     */   
/*     */   public InteractionReplyEditMono withEmbeds(Possible<Optional<List<EmbedCreateSpec>>> possible) {
/* 265 */     Possible<Optional<List<EmbedCreateSpec>>> newValue = Objects.<Possible<Optional<List<EmbedCreateSpec>>>>requireNonNull(possible);
/* 266 */     return new InteractionReplyEditMono(
/* 267 */         content(), newValue, this.files, this.fileSpoilers, 
/*     */ 
/*     */ 
/*     */         
/* 271 */         allowedMentions(), 
/* 272 */         components(), 
/* 273 */         attachments(), this.event);
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public InteractionReplyEditMono withEmbeds(@Nullable Iterable<EmbedCreateSpec> elements) {
/* 279 */     Possible<Optional<List<EmbedCreateSpec>>> newValue = Possible.of(Optional.<Iterable<EmbedCreateSpec>>ofNullable(elements)
/* 280 */         .map(els -> (List)StreamSupport.stream(els.spliterator(), false).collect(Collectors.toList())));
/* 281 */     return new InteractionReplyEditMono(
/* 282 */         content(), newValue, this.files, this.fileSpoilers, 
/*     */ 
/*     */ 
/*     */         
/* 286 */         allowedMentions(), 
/* 287 */         components(), 
/* 288 */         attachments(), this.event);
/*     */   }
/*     */ 
/*     */   
/*     */   public InteractionReplyEditMono withEmbedsOrNull(@Nullable Iterable<EmbedCreateSpec> elements) {
/* 293 */     Possible<Optional<List<EmbedCreateSpec>>> newValue = Possible.of(Optional.<Iterable<EmbedCreateSpec>>ofNullable(elements)
/* 294 */         .map(els -> (List)StreamSupport.stream(els.spliterator(), false).collect(Collectors.toList())));
/* 295 */     return new InteractionReplyEditMono(
/* 296 */         content(), newValue, this.files, this.fileSpoilers, 
/*     */ 
/*     */ 
/*     */         
/* 300 */         allowedMentions(), 
/* 301 */         components(), 
/* 302 */         attachments(), this.event);
/*     */   }
/*     */ 
/*     */   
/*     */   @SafeVarargs
/*     */   public final InteractionReplyEditMono withEmbeds(EmbedCreateSpec... elements) {
/* 308 */     Possible<Optional<List<EmbedCreateSpec>>> newValue = Possible.of(Optional.of(Arrays.asList(elements)));
/* 309 */     return new InteractionReplyEditMono(
/* 310 */         content(), newValue, this.files, this.fileSpoilers, 
/*     */ 
/*     */ 
/*     */         
/* 314 */         allowedMentions(), 
/* 315 */         components(), 
/* 316 */         attachments(), this.event);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final InteractionReplyEditMono withFiles(MessageCreateFields.File... elements) {
/* 326 */     List<MessageCreateFields.File> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/* 327 */     return new InteractionReplyEditMono(
/* 328 */         content(), 
/* 329 */         embeds(), newValue, this.fileSpoilers, 
/*     */ 
/*     */         
/* 332 */         allowedMentions(), 
/* 333 */         components(), 
/* 334 */         attachments(), this.event);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final InteractionReplyEditMono withFiles(Iterable<? extends MessageCreateFields.File> elements) {
/* 345 */     if (this.files == elements) return this; 
/* 346 */     List<MessageCreateFields.File> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/* 347 */     return new InteractionReplyEditMono(
/* 348 */         content(), 
/* 349 */         embeds(), newValue, this.fileSpoilers, 
/*     */ 
/*     */         
/* 352 */         allowedMentions(), 
/* 353 */         components(), 
/* 354 */         attachments(), this.event);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final InteractionReplyEditMono withFileSpoilers(MessageCreateFields.FileSpoiler... elements) {
/* 364 */     List<MessageCreateFields.FileSpoiler> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/* 365 */     return new InteractionReplyEditMono(
/* 366 */         content(), 
/* 367 */         embeds(), this.files, newValue, 
/*     */ 
/*     */         
/* 370 */         allowedMentions(), 
/* 371 */         components(), 
/* 372 */         attachments(), this.event);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final InteractionReplyEditMono withFileSpoilers(Iterable<? extends MessageCreateFields.FileSpoiler> elements) {
/* 383 */     if (this.fileSpoilers == elements) return this; 
/* 384 */     List<MessageCreateFields.FileSpoiler> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/* 385 */     return new InteractionReplyEditMono(
/* 386 */         content(), 
/* 387 */         embeds(), this.files, newValue, 
/*     */ 
/*     */         
/* 390 */         allowedMentions(), 
/* 391 */         components(), 
/* 392 */         attachments(), this.event);
/*     */   }
/*     */ 
/*     */   
/*     */   public InteractionReplyEditMono withAllowedMentions(Possible<Optional<AllowedMentions>> value) {
/* 397 */     Possible<Optional<AllowedMentions>> newValue = Objects.<Possible<Optional<AllowedMentions>>>requireNonNull(value);
/* 398 */     return new InteractionReplyEditMono(
/* 399 */         content(), 
/* 400 */         embeds(), this.files, this.fileSpoilers, newValue, 
/*     */ 
/*     */ 
/*     */         
/* 404 */         components(), 
/* 405 */         attachments(), this.event);
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public InteractionReplyEditMono withAllowedMentions(@Nullable AllowedMentions value) {
/* 411 */     Possible<Optional<AllowedMentions>> newValue = Possible.of(Optional.ofNullable(value));
/* 412 */     return new InteractionReplyEditMono(
/* 413 */         content(), 
/* 414 */         embeds(), this.files, this.fileSpoilers, newValue, 
/*     */ 
/*     */ 
/*     */         
/* 418 */         components(), 
/* 419 */         attachments(), this.event);
/*     */   }
/*     */ 
/*     */   
/*     */   public InteractionReplyEditMono withAllowedMentionsOrNull(@Nullable AllowedMentions value) {
/* 424 */     Possible<Optional<AllowedMentions>> newValue = Possible.of(Optional.ofNullable(value));
/* 425 */     return new InteractionReplyEditMono(
/* 426 */         content(), 
/* 427 */         embeds(), this.files, this.fileSpoilers, newValue, 
/*     */ 
/*     */ 
/*     */         
/* 431 */         components(), 
/* 432 */         attachments(), this.event);
/*     */   }
/*     */ 
/*     */   
/*     */   public InteractionReplyEditMono withComponents(Possible<Optional<List<LayoutComponent>>> possible) {
/* 437 */     Possible<Optional<List<LayoutComponent>>> newValue = Objects.<Possible<Optional<List<LayoutComponent>>>>requireNonNull(possible);
/* 438 */     return new InteractionReplyEditMono(
/* 439 */         content(), 
/* 440 */         embeds(), this.files, this.fileSpoilers, 
/*     */ 
/*     */         
/* 443 */         allowedMentions(), newValue, 
/*     */         
/* 445 */         attachments(), this.event);
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public InteractionReplyEditMono withComponents(@Nullable Iterable<LayoutComponent> elements) {
/* 451 */     Possible<Optional<List<LayoutComponent>>> newValue = Possible.of(Optional.<Iterable<LayoutComponent>>ofNullable(elements)
/* 452 */         .map(els -> (List)StreamSupport.stream(els.spliterator(), false).collect(Collectors.toList())));
/* 453 */     return new InteractionReplyEditMono(
/* 454 */         content(), 
/* 455 */         embeds(), this.files, this.fileSpoilers, 
/*     */ 
/*     */         
/* 458 */         allowedMentions(), newValue, 
/*     */         
/* 460 */         attachments(), this.event);
/*     */   }
/*     */ 
/*     */   
/*     */   public InteractionReplyEditMono withComponentsOrNull(@Nullable Iterable<LayoutComponent> elements) {
/* 465 */     Possible<Optional<List<LayoutComponent>>> newValue = Possible.of(Optional.<Iterable<LayoutComponent>>ofNullable(elements)
/* 466 */         .map(els -> (List)StreamSupport.stream(els.spliterator(), false).collect(Collectors.toList())));
/* 467 */     return new InteractionReplyEditMono(
/* 468 */         content(), 
/* 469 */         embeds(), this.files, this.fileSpoilers, 
/*     */ 
/*     */         
/* 472 */         allowedMentions(), newValue, 
/*     */         
/* 474 */         attachments(), this.event);
/*     */   }
/*     */ 
/*     */   
/*     */   @SafeVarargs
/*     */   public final InteractionReplyEditMono withComponents(LayoutComponent... elements) {
/* 480 */     Possible<Optional<List<LayoutComponent>>> newValue = Possible.of(Optional.of(Arrays.asList(elements)));
/* 481 */     return new InteractionReplyEditMono(
/* 482 */         content(), 
/* 483 */         embeds(), this.files, this.fileSpoilers, 
/*     */ 
/*     */         
/* 486 */         allowedMentions(), newValue, 
/*     */         
/* 488 */         attachments(), this.event);
/*     */   }
/*     */ 
/*     */   
/*     */   public InteractionReplyEditMono withAttachments(Possible<Optional<List<Attachment>>> possible) {
/* 493 */     Possible<Optional<List<Attachment>>> newValue = Objects.<Possible<Optional<List<Attachment>>>>requireNonNull(possible);
/* 494 */     return new InteractionReplyEditMono(
/* 495 */         content(), 
/* 496 */         embeds(), this.files, this.fileSpoilers, 
/*     */ 
/*     */         
/* 499 */         allowedMentions(), 
/* 500 */         components(), newValue, this.event);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public InteractionReplyEditMono withAttachments(@Nullable Iterable<Attachment> elements) {
/* 507 */     Possible<Optional<List<Attachment>>> newValue = Possible.of(Optional.<Iterable<Attachment>>ofNullable(elements)
/* 508 */         .map(els -> (List)StreamSupport.stream(els.spliterator(), false).collect(Collectors.toList())));
/* 509 */     return new InteractionReplyEditMono(
/* 510 */         content(), 
/* 511 */         embeds(), this.files, this.fileSpoilers, 
/*     */ 
/*     */         
/* 514 */         allowedMentions(), 
/* 515 */         components(), newValue, this.event);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public InteractionReplyEditMono withAttachmentsOrNull(@Nullable Iterable<Attachment> elements) {
/* 521 */     Possible<Optional<List<Attachment>>> newValue = Possible.of(Optional.<Iterable<Attachment>>ofNullable(elements)
/* 522 */         .map(els -> (List)StreamSupport.stream(els.spliterator(), false).collect(Collectors.toList())));
/* 523 */     return new InteractionReplyEditMono(
/* 524 */         content(), 
/* 525 */         embeds(), this.files, this.fileSpoilers, 
/*     */ 
/*     */         
/* 528 */         allowedMentions(), 
/* 529 */         components(), newValue, this.event);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SafeVarargs
/*     */   public final InteractionReplyEditMono withAttachments(Attachment... elements) {
/* 536 */     Possible<Optional<List<Attachment>>> newValue = Possible.of(Optional.of(Arrays.asList(elements)));
/* 537 */     return new InteractionReplyEditMono(
/* 538 */         content(), 
/* 539 */         embeds(), this.files, this.fileSpoilers, 
/*     */ 
/*     */         
/* 542 */         allowedMentions(), 
/* 543 */         components(), newValue, this.event);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final InteractionReplyEditMono withEvent(DeferrableInteractionEvent value) {
/* 555 */     if (this.event == value) return this; 
/* 556 */     DeferrableInteractionEvent newValue = Objects.<DeferrableInteractionEvent>requireNonNull(value, "event");
/* 557 */     return new InteractionReplyEditMono(
/* 558 */         content(), 
/* 559 */         embeds(), this.files, this.fileSpoilers, 
/*     */ 
/*     */         
/* 562 */         allowedMentions(), 
/* 563 */         components(), 
/* 564 */         attachments(), newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 574 */     if (this == another) return true; 
/* 575 */     return (another instanceof InteractionReplyEditMono && 
/* 576 */       equalTo(0, (InteractionReplyEditMono)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, InteractionReplyEditMono another) {
/* 580 */     return (content().equals(another.content()) && 
/* 581 */       Objects.equals(this.embeds_value, another.embeds_value) && this.files
/* 582 */       .equals(another.files) && this.fileSpoilers
/* 583 */       .equals(another.fileSpoilers) && 
/* 584 */       allowedMentions().equals(another.allowedMentions()) && 
/* 585 */       Objects.equals(this.components_value, another.components_value) && 
/* 586 */       Objects.equals(this.attachments_value, another.attachments_value) && this.event
/* 587 */       .equals(another.event));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 596 */     int h = 5381;
/* 597 */     h += (h << 5) + content().hashCode();
/* 598 */     h += (h << 5) + Objects.hashCode(this.embeds_value);
/* 599 */     h += (h << 5) + this.files.hashCode();
/* 600 */     h += (h << 5) + this.fileSpoilers.hashCode();
/* 601 */     h += (h << 5) + allowedMentions().hashCode();
/* 602 */     h += (h << 5) + Objects.hashCode(this.components_value);
/* 603 */     h += (h << 5) + Objects.hashCode(this.attachments_value);
/* 604 */     h += (h << 5) + this.event.hashCode();
/* 605 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 614 */     return "InteractionReplyEditMono{content=" + 
/* 615 */       content().toString() + ", embeds=" + 
/* 616 */       Objects.toString(this.embeds_value) + ", files=" + this.files + ", fileSpoilers=" + this.fileSpoilers + ", allowedMentions=" + 
/*     */ 
/*     */       
/* 619 */       allowedMentions().toString() + ", components=" + 
/* 620 */       Objects.toString(this.components_value) + ", attachments=" + 
/* 621 */       Objects.toString(this.attachments_value) + ", event=" + this.event + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static InteractionReplyEditMono of(DeferrableInteractionEvent event) {
/* 632 */     return new InteractionReplyEditMono(event);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static InteractionReplyEditMono copyOf(InteractionReplyEditMonoGenerator instance) {
/* 643 */     if (instance instanceof InteractionReplyEditMono) {
/* 644 */       return (InteractionReplyEditMono)instance;
/*     */     }
/* 646 */     return of(instance.event())
/* 647 */       .withContent(instance.content())
/* 648 */       .withEmbeds(instance.embeds())
/* 649 */       .withFiles(instance.files())
/* 650 */       .withFileSpoilers(instance.fileSpoilers())
/* 651 */       .withAllowedMentions(instance.allowedMentions())
/* 652 */       .withComponents(instance.components())
/* 653 */       .withAttachments(instance.attachments());
/*     */   }
/*     */   
/*     */   public boolean isContentPresent() {
/* 657 */     return !this.content_absent;
/*     */   }
/*     */   
/*     */   public String contentOrElse(String defaultValue) {
/* 661 */     return !this.content_absent ? this.content_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isEmbedsPresent() {
/* 665 */     return !this.embeds_absent;
/*     */   }
/*     */   
/*     */   public List<EmbedCreateSpec> embedsOrElse(List<EmbedCreateSpec> defaultValue) {
/* 669 */     return !this.embeds_absent ? this.embeds_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isAllowedMentionsPresent() {
/* 673 */     return !this.allowedMentions_absent;
/*     */   }
/*     */   
/*     */   public AllowedMentions allowedMentionsOrElse(AllowedMentions defaultValue) {
/* 677 */     return !this.allowedMentions_absent ? this.allowedMentions_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isComponentsPresent() {
/* 681 */     return !this.components_absent;
/*     */   }
/*     */   
/*     */   public List<LayoutComponent> componentsOrElse(List<LayoutComponent> defaultValue) {
/* 685 */     return !this.components_absent ? this.components_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isAttachmentsPresent() {
/* 689 */     return !this.attachments_absent;
/*     */   }
/*     */   
/*     */   public List<Attachment> attachmentsOrElse(List<Attachment> defaultValue) {
/* 693 */     return !this.attachments_absent ? this.attachments_value : defaultValue;
/*     */   }
/*     */   
/*     */   private static <T> List<T> createSafeList(Iterable<? extends T> iterable, boolean checkNulls, boolean skipNulls) {
/*     */     ArrayList<T> list;
/* 698 */     if (iterable instanceof Collection) {
/* 699 */       int size = ((Collection)iterable).size();
/* 700 */       if (size == 0) return Collections.emptyList(); 
/* 701 */       list = new ArrayList<>();
/*     */     } else {
/* 703 */       list = new ArrayList<>();
/*     */     } 
/* 705 */     for (T element : iterable) {
/* 706 */       if (skipNulls && element == null)
/* 707 */         continue;  if (checkNulls) Objects.requireNonNull(element, "element"); 
/* 708 */       list.add(element);
/*     */     } 
/* 710 */     return list;
/*     */   }
/*     */   
/*     */   private static <T> List<T> createUnmodifiableList(boolean clone, List<T> list) {
/* 714 */     switch (list.size()) { case 0:
/* 715 */         return Collections.emptyList();
/* 716 */       case 1: return Collections.singletonList(list.get(0)); }
/*     */     
/* 718 */     if (clone) {
/* 719 */       return Collections.unmodifiableList(new ArrayList<>(list));
/*     */     }
/* 721 */     if (list instanceof ArrayList) {
/* 722 */       ((ArrayList)list).trimToSize();
/*     */     }
/* 724 */     return Collections.unmodifiableList(list);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\InteractionReplyEditMono.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */