/*     */ package discord4j.core.spec;
/*     */ 
/*     */ import com.google.errorprone.annotations.CanIgnoreReturnValue;
/*     */ import discord4j.core.object.PermissionOverwrite;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.stream.StreamSupport;
/*     */ import org.immutables.value.Generated;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "CategoryEditSpecGenerator", generator = "Immutables")
/*     */ public final class CategoryEditSpec
/*     */   implements CategoryEditSpecGenerator
/*     */ {
/*     */   @Nullable
/*     */   private final String reason;
/*     */   private final String name_value;
/*     */   private final boolean name_absent;
/*     */   private final Integer position_value;
/*     */   private final boolean position_absent;
/*     */   private final List<PermissionOverwrite> permissionOverwrites_value;
/*     */   private final boolean permissionOverwrites_absent;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   
/*     */   private CategoryEditSpec() {
/*  37 */     this.reason = null;
/*  38 */     Possible<String> name$impl = Possible.absent();
/*  39 */     Possible<Integer> position$impl = Possible.absent();
/*  40 */     Possible<List<PermissionOverwrite>> permissionOverwrites$impl = Possible.absent();
/*  41 */     this.name_value = name$impl.toOptional().orElse(null);
/*  42 */     this.name_absent = name$impl.isAbsent();
/*  43 */     this.position_value = position$impl.toOptional().orElse(null);
/*  44 */     this.position_absent = position$impl.isAbsent();
/*  45 */     this.permissionOverwrites_value = permissionOverwrites$impl.toOptional().orElse(null);
/*  46 */     this.permissionOverwrites_absent = permissionOverwrites$impl.isAbsent();
/*  47 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private CategoryEditSpec(@Nullable String reason, Possible<String> name, Possible<Integer> position, Possible<List<PermissionOverwrite>> permissionOverwrites) {
/*  55 */     this.reason = reason;
/*  56 */     Possible<String> name$impl = name;
/*  57 */     Possible<Integer> position$impl = position;
/*  58 */     Possible<List<PermissionOverwrite>> permissionOverwrites$impl = permissionOverwrites;
/*  59 */     this.name_value = name$impl.toOptional().orElse(null);
/*  60 */     this.name_absent = name$impl.isAbsent();
/*  61 */     this.position_value = position$impl.toOptional().orElse(null);
/*  62 */     this.position_absent = position$impl.isAbsent();
/*  63 */     this.permissionOverwrites_value = permissionOverwrites$impl.toOptional().orElse(null);
/*  64 */     this.permissionOverwrites_absent = permissionOverwrites$impl.isAbsent();
/*  65 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  71 */   private volatile transient InitShim initShim = new InitShim();
/*     */   
/*     */   @Generated(from = "CategoryEditSpecGenerator", generator = "Immutables")
/*     */   private final class InitShim
/*     */   {
/*     */     private String formatInitCycleMessage() {
/*  77 */       List<String> attributes = new ArrayList<>();
/*  78 */       return "Cannot build CategoryEditSpec, attribute initializers form cycle " + attributes;
/*     */     }
/*     */ 
/*     */     
/*     */     private InitShim() {}
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String reason() {
/*  88 */     return this.reason;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<String> name() {
/*  96 */     return this.name_absent ? Possible.absent() : Possible.of(this.name_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Integer> position() {
/* 104 */     return this.position_absent ? Possible.absent() : Possible.of(this.position_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<List<PermissionOverwrite>> permissionOverwrites() {
/* 112 */     return this.permissionOverwrites_absent ? Possible.absent() : 
/* 113 */       Possible.of(this.permissionOverwrites_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final CategoryEditSpec withReason(@Nullable String value) {
/* 123 */     if (Objects.equals(this.reason, value)) return this; 
/* 124 */     return validate(new CategoryEditSpec(value, name(), position(), permissionOverwrites()));
/*     */   }
/*     */   
/*     */   public CategoryEditSpec withName(Possible<String> value) {
/* 128 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/* 129 */     return validate(new CategoryEditSpec(this.reason, newValue, position(), permissionOverwrites()));
/*     */   }
/*     */   
/*     */   public CategoryEditSpec withName(String value) {
/* 133 */     Possible<String> newValue = Possible.of(value);
/* 134 */     return validate(new CategoryEditSpec(this.reason, newValue, position(), permissionOverwrites()));
/*     */   }
/*     */   
/*     */   public CategoryEditSpec withPosition(Possible<Integer> value) {
/* 138 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/* 139 */     return validate(new CategoryEditSpec(this.reason, name(), newValue, permissionOverwrites()));
/*     */   }
/*     */   
/*     */   public CategoryEditSpec withPosition(Integer value) {
/* 143 */     Possible<Integer> newValue = Possible.of(value);
/* 144 */     return validate(new CategoryEditSpec(this.reason, name(), newValue, permissionOverwrites()));
/*     */   }
/*     */   
/*     */   public CategoryEditSpec withPermissionOverwrites(Possible<List<PermissionOverwrite>> possible) {
/* 148 */     Possible<List<PermissionOverwrite>> newValue = Objects.<Possible<List<PermissionOverwrite>>>requireNonNull(possible);
/* 149 */     return validate(new CategoryEditSpec(this.reason, name(), position(), newValue));
/*     */   }
/*     */   
/*     */   public CategoryEditSpec withPermissionOverwrites(Iterable<PermissionOverwrite> elements) {
/* 153 */     Possible<List<PermissionOverwrite>> newValue = Possible.of(
/* 154 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/* 155 */     return validate(new CategoryEditSpec(this.reason, name(), position(), newValue));
/*     */   }
/*     */   
/*     */   @SafeVarargs
/*     */   public final CategoryEditSpec withPermissionOverwrites(PermissionOverwrite... elements) {
/* 160 */     Possible<List<PermissionOverwrite>> newValue = Possible.of(Arrays.asList(elements));
/* 161 */     return validate(new CategoryEditSpec(this.reason, name(), position(), newValue));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 170 */     if (this == another) return true; 
/* 171 */     return (another instanceof CategoryEditSpec && 
/* 172 */       equalTo(0, (CategoryEditSpec)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, CategoryEditSpec another) {
/* 176 */     return (Objects.equals(this.reason, another.reason) && 
/* 177 */       name().equals(another.name()) && 
/* 178 */       position().equals(another.position()) && 
/* 179 */       Objects.equals(this.permissionOverwrites_value, another.permissionOverwrites_value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 188 */     int h = 5381;
/* 189 */     h += (h << 5) + Objects.hashCode(this.reason);
/* 190 */     h += (h << 5) + name().hashCode();
/* 191 */     h += (h << 5) + position().hashCode();
/* 192 */     h += (h << 5) + Objects.hashCode(this.permissionOverwrites_value);
/* 193 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 202 */     return "CategoryEditSpec{reason=" + this.reason + ", name=" + 
/*     */       
/* 204 */       name().toString() + ", position=" + 
/* 205 */       position().toString() + ", permissionOverwrites=" + 
/* 206 */       Objects.toString(this.permissionOverwrites_value) + "}";
/*     */   }
/*     */ 
/*     */   
/* 210 */   private static final CategoryEditSpec INSTANCE = validate(new CategoryEditSpec());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CategoryEditSpec create() {
/* 217 */     return INSTANCE;
/*     */   }
/*     */   
/*     */   private static CategoryEditSpec validate(CategoryEditSpec instance) {
/* 221 */     return (INSTANCE != null && INSTANCE.equalTo(0, instance)) ? INSTANCE : instance;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static CategoryEditSpec copyOf(CategoryEditSpecGenerator instance) {
/* 232 */     if (instance instanceof CategoryEditSpec) {
/* 233 */       return (CategoryEditSpec)instance;
/*     */     }
/* 235 */     return builder()
/* 236 */       .from(instance)
/* 237 */       .build();
/*     */   }
/*     */   
/*     */   public boolean isNamePresent() {
/* 241 */     return !this.name_absent;
/*     */   }
/*     */   
/*     */   public String nameOrElse(String defaultValue) {
/* 245 */     return !this.name_absent ? this.name_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isPositionPresent() {
/* 249 */     return !this.position_absent;
/*     */   }
/*     */   
/*     */   public Integer positionOrElse(Integer defaultValue) {
/* 253 */     return !this.position_absent ? this.position_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isPermissionOverwritesPresent() {
/* 257 */     return !this.permissionOverwrites_absent;
/*     */   }
/*     */   
/*     */   public List<PermissionOverwrite> permissionOverwritesOrElse(List<PermissionOverwrite> defaultValue) {
/* 261 */     return !this.permissionOverwrites_absent ? this.permissionOverwrites_value : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 277 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "CategoryEditSpecGenerator", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/* 289 */     private Possible<String> name_possible = Possible.absent();
/* 290 */     private Possible<Integer> position_possible = Possible.absent();
/* 291 */     private List<PermissionOverwrite> permissionOverwrites_list = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private String reason;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(CategoryEditSpec instance) {
/* 305 */       return from(instance);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     final Builder from(CategoryEditSpecGenerator instance) {
/* 315 */       Objects.requireNonNull(instance, "instance");
/* 316 */       String reasonValue = instance.reason();
/* 317 */       if (reasonValue != null) {
/* 318 */         reason(reasonValue);
/*     */       }
/* 320 */       name(instance.name());
/* 321 */       position(instance.position());
/* 322 */       permissionOverwrites(instance.permissionOverwrites());
/* 323 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder reason(@Nullable String reason) {
/* 333 */       this.reason = reason;
/* 334 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder name(Possible<String> value) {
/* 339 */       this.name_possible = value;
/* 340 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder name(String value) {
/* 345 */       this.name_possible = Possible.of(value);
/* 346 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder position(Possible<Integer> value) {
/* 351 */       this.position_possible = value;
/* 352 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder position(Integer value) {
/* 357 */       this.position_possible = Possible.of(value);
/* 358 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder addPermissionOverwrite(PermissionOverwrite element) {
/* 363 */       permissionOverwrites_getOrCreate().add(element);
/* 364 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder addAllPermissionOverwrites(List<PermissionOverwrite> elements) {
/* 369 */       permissionOverwrites_getOrCreate().addAll(elements);
/* 370 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder permissionOverwrites(Possible<List<PermissionOverwrite>> elements) {
/* 375 */       this.permissionOverwrites_list = null;
/* 376 */       elements.toOptional().ifPresent(e -> permissionOverwrites_getOrCreate().addAll(e));
/* 377 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder permissionOverwrites(List<PermissionOverwrite> elements) {
/* 382 */       this.permissionOverwrites_list = new ArrayList<>(elements);
/* 383 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder permissionOverwrites(Iterable<PermissionOverwrite> elements) {
/* 388 */       this.permissionOverwrites_list = (List<PermissionOverwrite>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/* 389 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public CategoryEditSpec build() {
/* 398 */       return CategoryEditSpec.validate(new CategoryEditSpec(this.reason, name_build(), position_build(), permissionOverwrites_build()));
/*     */     }
/*     */     
/*     */     private Possible<String> name_build() {
/* 402 */       return this.name_possible;
/*     */     }
/*     */     
/*     */     private Possible<Integer> position_build() {
/* 406 */       return this.position_possible;
/*     */     }
/*     */     
/*     */     private Possible<List<PermissionOverwrite>> permissionOverwrites_build() {
/* 410 */       return (this.permissionOverwrites_list == null) ? Possible.absent() : 
/* 411 */         Possible.of(this.permissionOverwrites_list);
/*     */     }
/*     */     
/*     */     private List<PermissionOverwrite> permissionOverwrites_getOrCreate() {
/* 415 */       if (this.permissionOverwrites_list == null) {
/* 416 */         this.permissionOverwrites_list = new ArrayList<>();
/*     */       }
/* 418 */       return this.permissionOverwrites_list;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\CategoryEditSpec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */