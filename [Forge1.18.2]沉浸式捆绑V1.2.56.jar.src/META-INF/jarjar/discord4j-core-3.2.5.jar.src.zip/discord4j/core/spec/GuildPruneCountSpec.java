/*     */ package discord4j.core.spec;
/*     */ 
/*     */ import com.google.errorprone.annotations.CanIgnoreReturnValue;
/*     */ import discord4j.common.util.Snowflake;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ import org.immutables.value.Generated;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "GuildPruneCountSpecGenerator", generator = "Immutables")
/*     */ public final class GuildPruneCountSpec
/*     */   implements GuildPruneCountSpecGenerator
/*     */ {
/*     */   private final Integer days;
/*     */   @Nullable
/*     */   private final Set<Snowflake> roles;
/*     */   
/*     */   private GuildPruneCountSpec(Integer days) {
/*  33 */     this.days = Objects.<Integer>requireNonNull(days, "days");
/*  34 */     this.roles = null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private GuildPruneCountSpec(Integer days, @Nullable Set<Snowflake> roles) {
/*  40 */     this.days = days;
/*  41 */     this.roles = roles;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Integer days() {
/*  49 */     return this.days;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Set<Snowflake> roles() {
/*  57 */     return this.roles;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final GuildPruneCountSpec withDays(Integer value) {
/*  67 */     Integer newValue = Objects.<Integer>requireNonNull(value, "days");
/*  68 */     if (this.days.equals(newValue)) return this; 
/*  69 */     return new GuildPruneCountSpec(newValue, this.roles);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final GuildPruneCountSpec withRoles(@Nullable Snowflake... elements) {
/*  78 */     if (elements == null) {
/*  79 */       return new GuildPruneCountSpec(this.days, null);
/*     */     }
/*  81 */     Set<Snowflake> newValue = (Arrays.asList(elements) == null) ? null : createUnmodifiableSet(createSafeList(Arrays.asList(elements), true, false));
/*  82 */     return new GuildPruneCountSpec(this.days, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final GuildPruneCountSpec withRoles(@Nullable Iterable<? extends Snowflake> elements) {
/*  92 */     if (this.roles == elements) return this; 
/*  93 */     Set<Snowflake> newValue = (elements == null) ? null : createUnmodifiableSet(createSafeList(elements, true, false));
/*  94 */     return new GuildPruneCountSpec(this.days, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 103 */     if (this == another) return true; 
/* 104 */     return (another instanceof GuildPruneCountSpec && 
/* 105 */       equalTo(0, (GuildPruneCountSpec)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, GuildPruneCountSpec another) {
/* 109 */     return (this.days.equals(another.days) && 
/* 110 */       Objects.equals(this.roles, another.roles));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 119 */     int h = 5381;
/* 120 */     h += (h << 5) + this.days.hashCode();
/* 121 */     h += (h << 5) + Objects.hashCode(this.roles);
/* 122 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 131 */     return "GuildPruneCountSpec{days=" + this.days + ", roles=" + this.roles + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static GuildPruneCountSpec of(Integer days) {
/* 143 */     return new GuildPruneCountSpec(days);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static GuildPruneCountSpec copyOf(GuildPruneCountSpecGenerator instance) {
/* 154 */     if (instance instanceof GuildPruneCountSpec) {
/* 155 */       return (GuildPruneCountSpec)instance;
/*     */     }
/* 157 */     return builder()
/* 158 */       .from(instance)
/* 159 */       .build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 173 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "GuildPruneCountSpecGenerator", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_DAYS = 1L;
/*     */ 
/*     */ 
/*     */     
/* 186 */     private long initBits = 1L;
/*     */     
/*     */     private Integer days;
/* 189 */     private List<Snowflake> roles = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(GuildPruneCountSpec instance) {
/* 203 */       return from(instance);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     final Builder from(GuildPruneCountSpecGenerator instance) {
/* 213 */       Objects.requireNonNull(instance, "instance");
/* 214 */       days(instance.days());
/* 215 */       Set<Snowflake> rolesValue = instance.roles();
/* 216 */       if (rolesValue != null) {
/* 217 */         addAllRoles(rolesValue);
/*     */       }
/* 219 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder days(Integer days) {
/* 229 */       this.days = Objects.<Integer>requireNonNull(days, "days");
/* 230 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 231 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder addRole(Snowflake element) {
/* 241 */       if (this.roles == null) {
/* 242 */         this.roles = new ArrayList<>();
/*     */       }
/* 244 */       this.roles.add(Objects.<Snowflake>requireNonNull(element, "roles element"));
/* 245 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder addRoles(Snowflake... elements) {
/* 255 */       if (this.roles == null) {
/* 256 */         this.roles = new ArrayList<>();
/*     */       }
/* 258 */       for (Snowflake element : elements) {
/* 259 */         this.roles.add(Objects.<Snowflake>requireNonNull(element, "roles element"));
/*     */       }
/* 261 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder roles(@Nullable Iterable<? extends Snowflake> elements) {
/* 272 */       if (elements == null) {
/* 273 */         this.roles = null;
/* 274 */         return this;
/*     */       } 
/* 276 */       this.roles = new ArrayList<>();
/* 277 */       return addAllRoles(elements);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder addAllRoles(Iterable<? extends Snowflake> elements) {
/* 287 */       Objects.requireNonNull(elements, "roles element");
/* 288 */       if (this.roles == null) {
/* 289 */         this.roles = new ArrayList<>();
/*     */       }
/* 291 */       for (Snowflake element : elements) {
/* 292 */         this.roles.add(Objects.<Snowflake>requireNonNull(element, "roles element"));
/*     */       }
/* 294 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public GuildPruneCountSpec build() {
/* 303 */       if (this.initBits != 0L) {
/* 304 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 306 */       return new GuildPruneCountSpec(this.days, (this.roles == null) ? null : GuildPruneCountSpec.createUnmodifiableSet((List)this.roles));
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 310 */       List<String> attributes = new ArrayList<>();
/* 311 */       if ((this.initBits & 0x1L) != 0L) attributes.add("days"); 
/* 312 */       return "Cannot build GuildPruneCountSpec, some of required attributes are not set " + attributes;
/*     */     }
/*     */     private Builder() {} }
/*     */   
/*     */   private static <T> List<T> createSafeList(Iterable<? extends T> iterable, boolean checkNulls, boolean skipNulls) {
/*     */     ArrayList<T> list;
/* 318 */     if (iterable instanceof Collection) {
/* 319 */       int size = ((Collection)iterable).size();
/* 320 */       if (size == 0) return Collections.emptyList(); 
/* 321 */       list = new ArrayList<>();
/*     */     } else {
/* 323 */       list = new ArrayList<>();
/*     */     } 
/* 325 */     for (T element : iterable) {
/* 326 */       if (skipNulls && element == null)
/* 327 */         continue;  if (checkNulls) Objects.requireNonNull(element, "element"); 
/* 328 */       list.add(element);
/*     */     } 
/* 330 */     return list;
/*     */   }
/*     */ 
/*     */   
/*     */   private static <T> Set<T> createUnmodifiableSet(List<T> list) {
/* 335 */     switch (list.size()) { case 0:
/* 336 */         return Collections.emptySet();
/* 337 */       case 1: return Collections.singleton(list.get(0)); }
/*     */     
/* 339 */     Set<T> set = new LinkedHashSet<>(list.size());
/* 340 */     set.addAll(list);
/* 341 */     return Collections.unmodifiableSet(set);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\GuildPruneCountSpec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */