/*      */ package discord4j.core.spec;
/*      */ 
/*      */ import com.google.errorprone.annotations.CanIgnoreReturnValue;
/*      */ import discord4j.core.object.component.LayoutComponent;
/*      */ import discord4j.discordjson.possible.Possible;
/*      */ import discord4j.rest.util.AllowedMentions;
/*      */ import java.io.InputStream;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.List;
/*      */ import java.util.Objects;
/*      */ import java.util.stream.Collectors;
/*      */ import java.util.stream.StreamSupport;
/*      */ import org.immutables.value.Generated;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ @Generated(from = "WebhookExecuteSpecGenerator", generator = "Immutables")
/*      */ public final class WebhookExecuteSpec
/*      */   implements WebhookExecuteSpecGenerator
/*      */ {
/*      */   private final String content_value;
/*      */   private final boolean content_absent;
/*      */   private final String username_value;
/*      */   private final boolean username_absent;
/*      */   private final String avatarUrl_value;
/*      */   private final boolean avatarUrl_absent;
/*      */   private final boolean tts;
/*      */   private final List<MessageCreateFields.File> files;
/*      */   private final List<MessageCreateFields.FileSpoiler> fileSpoilers;
/*      */   private final List<EmbedCreateSpec> embeds;
/*      */   private final AllowedMentions allowedMentions_value;
/*      */   private final boolean allowedMentions_absent;
/*      */   private final List<LayoutComponent> components_value;
/*      */   private final boolean components_absent;
/*      */   private static final byte STAGE_INITIALIZING = -1;
/*      */   private static final byte STAGE_UNINITIALIZED = 0;
/*      */   private static final byte STAGE_INITIALIZED = 1;
/*      */   
/*      */   private WebhookExecuteSpec() {
/*   47 */     Possible<String> content$impl = Possible.absent();
/*   48 */     Possible<String> username$impl = Possible.absent();
/*   49 */     Possible<String> avatarUrl$impl = Possible.absent();
/*   50 */     Possible<AllowedMentions> allowedMentions$impl = Possible.absent();
/*   51 */     Possible<List<LayoutComponent>> components$impl = Possible.absent();
/*   52 */     this.content_value = content$impl.toOptional().orElse(null);
/*   53 */     this.content_absent = content$impl.isAbsent();
/*   54 */     this.username_value = username$impl.toOptional().orElse(null);
/*   55 */     this.username_absent = username$impl.isAbsent();
/*   56 */     this.avatarUrl_value = avatarUrl$impl.toOptional().orElse(null);
/*   57 */     this.avatarUrl_absent = avatarUrl$impl.isAbsent();
/*   58 */     this.allowedMentions_value = allowedMentions$impl.toOptional().orElse(null);
/*   59 */     this.allowedMentions_absent = allowedMentions$impl.isAbsent();
/*   60 */     this.components_value = components$impl.toOptional().orElse(null);
/*   61 */     this.components_absent = components$impl.isAbsent();
/*   62 */     this.tts = this.initShim.tts();
/*   63 */     this.files = this.initShim.files();
/*   64 */     this.fileSpoilers = this.initShim.fileSpoilers();
/*   65 */     this.embeds = this.initShim.embeds();
/*   66 */     this.initShim = null;
/*      */   }
/*      */   
/*      */   private WebhookExecuteSpec(Builder builder) {
/*   70 */     Possible<String> content$impl = builder.content_build();
/*   71 */     Possible<String> username$impl = builder.username_build();
/*   72 */     Possible<String> avatarUrl$impl = builder.avatarUrl_build();
/*   73 */     Possible<AllowedMentions> allowedMentions$impl = builder.allowedMentions_build();
/*   74 */     Possible<List<LayoutComponent>> components$impl = builder.components_build();
/*   75 */     if (builder.ttsIsSet()) {
/*   76 */       this.initShim.tts(builder.tts);
/*      */     }
/*   78 */     if (builder.filesIsSet()) {
/*   79 */       this.initShim.files(createUnmodifiableList(true, builder.files));
/*      */     }
/*   81 */     if (builder.fileSpoilersIsSet()) {
/*   82 */       this.initShim.fileSpoilers(createUnmodifiableList(true, builder.fileSpoilers));
/*      */     }
/*   84 */     if (builder.embedsIsSet()) {
/*   85 */       this.initShim.embeds(createUnmodifiableList(true, builder.embeds));
/*      */     }
/*   87 */     this.content_value = content$impl.toOptional().orElse(null);
/*   88 */     this.content_absent = content$impl.isAbsent();
/*   89 */     this.username_value = username$impl.toOptional().orElse(null);
/*   90 */     this.username_absent = username$impl.isAbsent();
/*   91 */     this.avatarUrl_value = avatarUrl$impl.toOptional().orElse(null);
/*   92 */     this.avatarUrl_absent = avatarUrl$impl.isAbsent();
/*   93 */     this.allowedMentions_value = allowedMentions$impl.toOptional().orElse(null);
/*   94 */     this.allowedMentions_absent = allowedMentions$impl.isAbsent();
/*   95 */     this.components_value = components$impl.toOptional().orElse(null);
/*   96 */     this.components_absent = components$impl.isAbsent();
/*   97 */     this.tts = this.initShim.tts();
/*   98 */     this.files = this.initShim.files();
/*   99 */     this.fileSpoilers = this.initShim.fileSpoilers();
/*  100 */     this.embeds = this.initShim.embeds();
/*  101 */     this.initShim = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private WebhookExecuteSpec(Possible<String> content, Possible<String> username, Possible<String> avatarUrl, boolean tts, List<MessageCreateFields.File> files, List<MessageCreateFields.FileSpoiler> fileSpoilers, List<EmbedCreateSpec> embeds, Possible<AllowedMentions> allowedMentions, Possible<List<LayoutComponent>> components) {
/*  114 */     Possible<String> content$impl = content;
/*  115 */     Possible<String> username$impl = username;
/*  116 */     Possible<String> avatarUrl$impl = avatarUrl;
/*  117 */     this.initShim.tts(tts);
/*  118 */     this.initShim.files(files);
/*  119 */     this.initShim.fileSpoilers(fileSpoilers);
/*  120 */     this.initShim.embeds(embeds);
/*  121 */     Possible<AllowedMentions> allowedMentions$impl = allowedMentions;
/*  122 */     Possible<List<LayoutComponent>> components$impl = components;
/*  123 */     this.content_value = content$impl.toOptional().orElse(null);
/*  124 */     this.content_absent = content$impl.isAbsent();
/*  125 */     this.username_value = username$impl.toOptional().orElse(null);
/*  126 */     this.username_absent = username$impl.isAbsent();
/*  127 */     this.avatarUrl_value = avatarUrl$impl.toOptional().orElse(null);
/*  128 */     this.avatarUrl_absent = avatarUrl$impl.isAbsent();
/*  129 */     this.allowedMentions_value = allowedMentions$impl.toOptional().orElse(null);
/*  130 */     this.allowedMentions_absent = allowedMentions$impl.isAbsent();
/*  131 */     this.components_value = components$impl.toOptional().orElse(null);
/*  132 */     this.components_absent = components$impl.isAbsent();
/*  133 */     this.tts = this.initShim.tts();
/*  134 */     this.files = this.initShim.files();
/*  135 */     this.fileSpoilers = this.initShim.fileSpoilers();
/*  136 */     this.embeds = this.initShim.embeds();
/*  137 */     this.initShim = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  143 */   private volatile transient InitShim initShim = new InitShim();
/*      */   
/*      */   @Generated(from = "WebhookExecuteSpecGenerator", generator = "Immutables")
/*      */   private final class InitShim
/*      */   {
/*  148 */     private byte ttsBuildStage = 0;
/*      */     private boolean tts;
/*      */     
/*      */     boolean tts() {
/*  152 */       if (this.ttsBuildStage == -1) throw new IllegalStateException(formatInitCycleMessage()); 
/*  153 */       if (this.ttsBuildStage == 0) {
/*  154 */         this.ttsBuildStage = -1;
/*  155 */         this.tts = WebhookExecuteSpec.this.ttsInitialize();
/*  156 */         this.ttsBuildStage = 1;
/*      */       } 
/*  158 */       return this.tts;
/*      */     }
/*      */     
/*      */     void tts(boolean tts) {
/*  162 */       this.tts = tts;
/*  163 */       this.ttsBuildStage = 1;
/*      */     }
/*      */     
/*  166 */     private byte filesBuildStage = 0;
/*      */     private List<MessageCreateFields.File> files;
/*      */     
/*      */     List<MessageCreateFields.File> files() {
/*  170 */       if (this.filesBuildStage == -1) throw new IllegalStateException(formatInitCycleMessage()); 
/*  171 */       if (this.filesBuildStage == 0) {
/*  172 */         this.filesBuildStage = -1;
/*  173 */         this.files = (List)WebhookExecuteSpec.createUnmodifiableList(false, WebhookExecuteSpec.createSafeList((Iterable)WebhookExecuteSpec.this.filesInitialize(), true, false));
/*  174 */         this.filesBuildStage = 1;
/*      */       } 
/*  176 */       return this.files;
/*      */     }
/*      */     
/*      */     void files(List<MessageCreateFields.File> files) {
/*  180 */       this.files = files;
/*  181 */       this.filesBuildStage = 1;
/*      */     }
/*      */     
/*  184 */     private byte fileSpoilersBuildStage = 0;
/*      */     private List<MessageCreateFields.FileSpoiler> fileSpoilers;
/*      */     
/*      */     List<MessageCreateFields.FileSpoiler> fileSpoilers() {
/*  188 */       if (this.fileSpoilersBuildStage == -1) throw new IllegalStateException(formatInitCycleMessage()); 
/*  189 */       if (this.fileSpoilersBuildStage == 0) {
/*  190 */         this.fileSpoilersBuildStage = -1;
/*  191 */         this.fileSpoilers = (List)WebhookExecuteSpec.createUnmodifiableList(false, WebhookExecuteSpec.createSafeList((Iterable)WebhookExecuteSpec.this.fileSpoilersInitialize(), true, false));
/*  192 */         this.fileSpoilersBuildStage = 1;
/*      */       } 
/*  194 */       return this.fileSpoilers;
/*      */     }
/*      */     
/*      */     void fileSpoilers(List<MessageCreateFields.FileSpoiler> fileSpoilers) {
/*  198 */       this.fileSpoilers = fileSpoilers;
/*  199 */       this.fileSpoilersBuildStage = 1;
/*      */     }
/*      */     
/*  202 */     private byte embedsBuildStage = 0;
/*      */     private List<EmbedCreateSpec> embeds;
/*      */     
/*      */     List<EmbedCreateSpec> embeds() {
/*  206 */       if (this.embedsBuildStage == -1) throw new IllegalStateException(formatInitCycleMessage()); 
/*  207 */       if (this.embedsBuildStage == 0) {
/*  208 */         this.embedsBuildStage = -1;
/*  209 */         this.embeds = (List)WebhookExecuteSpec.createUnmodifiableList(false, WebhookExecuteSpec.createSafeList((Iterable)WebhookExecuteSpec.this.embedsInitialize(), true, false));
/*  210 */         this.embedsBuildStage = 1;
/*      */       } 
/*  212 */       return this.embeds;
/*      */     }
/*      */     
/*      */     void embeds(List<EmbedCreateSpec> embeds) {
/*  216 */       this.embeds = embeds;
/*  217 */       this.embedsBuildStage = 1;
/*      */     }
/*      */     private InitShim() {}
/*      */     private String formatInitCycleMessage() {
/*  221 */       List<String> attributes = new ArrayList<>();
/*  222 */       if (this.ttsBuildStage == -1) attributes.add("tts"); 
/*  223 */       if (this.filesBuildStage == -1) attributes.add("files"); 
/*  224 */       if (this.fileSpoilersBuildStage == -1) attributes.add("fileSpoilers"); 
/*  225 */       if (this.embedsBuildStage == -1) attributes.add("embeds"); 
/*  226 */       return "Cannot build WebhookExecuteSpec, attribute initializers form cycle " + attributes;
/*      */     }
/*      */   }
/*      */   
/*      */   private boolean ttsInitialize() {
/*  231 */     return super.tts();
/*      */   }
/*      */   
/*      */   private List<MessageCreateFields.File> filesInitialize() {
/*  235 */     return super.files();
/*      */   }
/*      */   
/*      */   private List<MessageCreateFields.FileSpoiler> fileSpoilersInitialize() {
/*  239 */     return super.fileSpoilers();
/*      */   }
/*      */   
/*      */   private List<EmbedCreateSpec> embedsInitialize() {
/*  243 */     return super.embeds();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Possible<String> content() {
/*  251 */     return this.content_absent ? Possible.absent() : Possible.of(this.content_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Possible<String> username() {
/*  259 */     return this.username_absent ? Possible.absent() : Possible.of(this.username_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Possible<String> avatarUrl() {
/*  267 */     return this.avatarUrl_absent ? Possible.absent() : Possible.of(this.avatarUrl_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean tts() {
/*  275 */     InitShim shim = this.initShim;
/*  276 */     return (shim != null) ? 
/*  277 */       shim.tts() : 
/*  278 */       this.tts;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<MessageCreateFields.File> files() {
/*  286 */     InitShim shim = this.initShim;
/*  287 */     return (shim != null) ? 
/*  288 */       shim.files() : 
/*  289 */       this.files;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<MessageCreateFields.FileSpoiler> fileSpoilers() {
/*  297 */     InitShim shim = this.initShim;
/*  298 */     return (shim != null) ? 
/*  299 */       shim.fileSpoilers() : 
/*  300 */       this.fileSpoilers;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<EmbedCreateSpec> embeds() {
/*  308 */     InitShim shim = this.initShim;
/*  309 */     return (shim != null) ? 
/*  310 */       shim.embeds() : 
/*  311 */       this.embeds;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Possible<AllowedMentions> allowedMentions() {
/*  319 */     return this.allowedMentions_absent ? Possible.absent() : Possible.of(this.allowedMentions_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Possible<List<LayoutComponent>> components() {
/*  327 */     return this.components_absent ? Possible.absent() : 
/*  328 */       Possible.of(this.components_value);
/*      */   }
/*      */   
/*      */   public WebhookExecuteSpec withContent(Possible<String> value) {
/*  332 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/*  333 */     return validate(new WebhookExecuteSpec(newValue, 
/*      */           
/*  335 */           username(), 
/*  336 */           avatarUrl(), this.tts, this.files, this.fileSpoilers, this.embeds, 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  341 */           allowedMentions(), 
/*  342 */           components()));
/*      */   }
/*      */   
/*      */   public WebhookExecuteSpec withContent(String value) {
/*  346 */     Possible<String> newValue = Possible.of(value);
/*  347 */     return validate(new WebhookExecuteSpec(newValue, 
/*      */           
/*  349 */           username(), 
/*  350 */           avatarUrl(), this.tts, this.files, this.fileSpoilers, this.embeds, 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  355 */           allowedMentions(), 
/*  356 */           components()));
/*      */   }
/*      */   
/*      */   public WebhookExecuteSpec withUsername(Possible<String> value) {
/*  360 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/*  361 */     return validate(new WebhookExecuteSpec(
/*  362 */           content(), newValue, 
/*      */           
/*  364 */           avatarUrl(), this.tts, this.files, this.fileSpoilers, this.embeds, 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  369 */           allowedMentions(), 
/*  370 */           components()));
/*      */   }
/*      */   
/*      */   public WebhookExecuteSpec withUsername(String value) {
/*  374 */     Possible<String> newValue = Possible.of(value);
/*  375 */     return validate(new WebhookExecuteSpec(
/*  376 */           content(), newValue, 
/*      */           
/*  378 */           avatarUrl(), this.tts, this.files, this.fileSpoilers, this.embeds, 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  383 */           allowedMentions(), 
/*  384 */           components()));
/*      */   }
/*      */   
/*      */   public WebhookExecuteSpec withAvatarUrl(Possible<String> value) {
/*  388 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/*  389 */     return validate(new WebhookExecuteSpec(
/*  390 */           content(), 
/*  391 */           username(), newValue, this.tts, this.files, this.fileSpoilers, this.embeds, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  397 */           allowedMentions(), 
/*  398 */           components()));
/*      */   }
/*      */   
/*      */   public WebhookExecuteSpec withAvatarUrl(String value) {
/*  402 */     Possible<String> newValue = Possible.of(value);
/*  403 */     return validate(new WebhookExecuteSpec(
/*  404 */           content(), 
/*  405 */           username(), newValue, this.tts, this.files, this.fileSpoilers, this.embeds, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  411 */           allowedMentions(), 
/*  412 */           components()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final WebhookExecuteSpec withTts(boolean value) {
/*  422 */     if (this.tts == value) return this; 
/*  423 */     return validate(new WebhookExecuteSpec(
/*  424 */           content(), 
/*  425 */           username(), 
/*  426 */           avatarUrl(), value, this.files, this.fileSpoilers, this.embeds, 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  431 */           allowedMentions(), 
/*  432 */           components()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final WebhookExecuteSpec withFiles(MessageCreateFields.File... elements) {
/*  441 */     List<MessageCreateFields.File> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/*  442 */     return validate(new WebhookExecuteSpec(
/*  443 */           content(), 
/*  444 */           username(), 
/*  445 */           avatarUrl(), this.tts, newValue, this.fileSpoilers, this.embeds, 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  450 */           allowedMentions(), 
/*  451 */           components()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final WebhookExecuteSpec withFiles(Iterable<? extends MessageCreateFields.File> elements) {
/*  461 */     if (this.files == elements) return this; 
/*  462 */     List<MessageCreateFields.File> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/*  463 */     return validate(new WebhookExecuteSpec(
/*  464 */           content(), 
/*  465 */           username(), 
/*  466 */           avatarUrl(), this.tts, newValue, this.fileSpoilers, this.embeds, 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  471 */           allowedMentions(), 
/*  472 */           components()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final WebhookExecuteSpec withFileSpoilers(MessageCreateFields.FileSpoiler... elements) {
/*  481 */     List<MessageCreateFields.FileSpoiler> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/*  482 */     return validate(new WebhookExecuteSpec(
/*  483 */           content(), 
/*  484 */           username(), 
/*  485 */           avatarUrl(), this.tts, this.files, newValue, this.embeds, 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  490 */           allowedMentions(), 
/*  491 */           components()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final WebhookExecuteSpec withFileSpoilers(Iterable<? extends MessageCreateFields.FileSpoiler> elements) {
/*  501 */     if (this.fileSpoilers == elements) return this; 
/*  502 */     List<MessageCreateFields.FileSpoiler> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/*  503 */     return validate(new WebhookExecuteSpec(
/*  504 */           content(), 
/*  505 */           username(), 
/*  506 */           avatarUrl(), this.tts, this.files, newValue, this.embeds, 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  511 */           allowedMentions(), 
/*  512 */           components()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final WebhookExecuteSpec withEmbeds(EmbedCreateSpec... elements) {
/*  521 */     List<EmbedCreateSpec> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/*  522 */     return validate(new WebhookExecuteSpec(
/*  523 */           content(), 
/*  524 */           username(), 
/*  525 */           avatarUrl(), this.tts, this.files, this.fileSpoilers, newValue, 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  530 */           allowedMentions(), 
/*  531 */           components()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final WebhookExecuteSpec withEmbeds(Iterable<? extends EmbedCreateSpec> elements) {
/*  541 */     if (this.embeds == elements) return this; 
/*  542 */     List<EmbedCreateSpec> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/*  543 */     return validate(new WebhookExecuteSpec(
/*  544 */           content(), 
/*  545 */           username(), 
/*  546 */           avatarUrl(), this.tts, this.files, this.fileSpoilers, newValue, 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  551 */           allowedMentions(), 
/*  552 */           components()));
/*      */   }
/*      */   
/*      */   public WebhookExecuteSpec withAllowedMentions(Possible<AllowedMentions> value) {
/*  556 */     Possible<AllowedMentions> newValue = Objects.<Possible<AllowedMentions>>requireNonNull(value);
/*  557 */     return validate(new WebhookExecuteSpec(
/*  558 */           content(), 
/*  559 */           username(), 
/*  560 */           avatarUrl(), this.tts, this.files, this.fileSpoilers, this.embeds, newValue, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  566 */           components()));
/*      */   }
/*      */   
/*      */   public WebhookExecuteSpec withAllowedMentions(AllowedMentions value) {
/*  570 */     Possible<AllowedMentions> newValue = Possible.of(value);
/*  571 */     return validate(new WebhookExecuteSpec(
/*  572 */           content(), 
/*  573 */           username(), 
/*  574 */           avatarUrl(), this.tts, this.files, this.fileSpoilers, this.embeds, newValue, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  580 */           components()));
/*      */   }
/*      */   
/*      */   public WebhookExecuteSpec withComponents(Possible<List<LayoutComponent>> possible) {
/*  584 */     Possible<List<LayoutComponent>> newValue = Objects.<Possible<List<LayoutComponent>>>requireNonNull(possible);
/*  585 */     return validate(new WebhookExecuteSpec(
/*  586 */           content(), 
/*  587 */           username(), 
/*  588 */           avatarUrl(), this.tts, this.files, this.fileSpoilers, this.embeds, 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  593 */           allowedMentions(), newValue));
/*      */   }
/*      */ 
/*      */   
/*      */   public WebhookExecuteSpec withComponents(Iterable<LayoutComponent> elements) {
/*  598 */     Possible<List<LayoutComponent>> newValue = Possible.of(
/*  599 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/*  600 */     return validate(new WebhookExecuteSpec(
/*  601 */           content(), 
/*  602 */           username(), 
/*  603 */           avatarUrl(), this.tts, this.files, this.fileSpoilers, this.embeds, 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  608 */           allowedMentions(), newValue));
/*      */   }
/*      */ 
/*      */   
/*      */   @SafeVarargs
/*      */   public final WebhookExecuteSpec withComponents(LayoutComponent... elements) {
/*  614 */     Possible<List<LayoutComponent>> newValue = Possible.of(Arrays.asList(elements));
/*  615 */     return validate(new WebhookExecuteSpec(
/*  616 */           content(), 
/*  617 */           username(), 
/*  618 */           avatarUrl(), this.tts, this.files, this.fileSpoilers, this.embeds, 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  623 */           allowedMentions(), newValue));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean equals(Object another) {
/*  633 */     if (this == another) return true; 
/*  634 */     return (another instanceof WebhookExecuteSpec && 
/*  635 */       equalTo(0, (WebhookExecuteSpec)another));
/*      */   }
/*      */   
/*      */   private boolean equalTo(int synthetic, WebhookExecuteSpec another) {
/*  639 */     return (content().equals(another.content()) && 
/*  640 */       username().equals(another.username()) && 
/*  641 */       avatarUrl().equals(another.avatarUrl()) && this.tts == another.tts && this.files
/*      */       
/*  643 */       .equals(another.files) && this.fileSpoilers
/*  644 */       .equals(another.fileSpoilers) && this.embeds
/*  645 */       .equals(another.embeds) && 
/*  646 */       allowedMentions().equals(another.allowedMentions()) && 
/*  647 */       Objects.equals(this.components_value, another.components_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int hashCode() {
/*  656 */     int h = 5381;
/*  657 */     h += (h << 5) + content().hashCode();
/*  658 */     h += (h << 5) + username().hashCode();
/*  659 */     h += (h << 5) + avatarUrl().hashCode();
/*  660 */     h += (h << 5) + Boolean.hashCode(this.tts);
/*  661 */     h += (h << 5) + this.files.hashCode();
/*  662 */     h += (h << 5) + this.fileSpoilers.hashCode();
/*  663 */     h += (h << 5) + this.embeds.hashCode();
/*  664 */     h += (h << 5) + allowedMentions().hashCode();
/*  665 */     h += (h << 5) + Objects.hashCode(this.components_value);
/*  666 */     return h;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/*  675 */     return "WebhookExecuteSpec{content=" + 
/*  676 */       content().toString() + ", username=" + 
/*  677 */       username().toString() + ", avatarUrl=" + 
/*  678 */       avatarUrl().toString() + ", tts=" + this.tts + ", files=" + this.files + ", fileSpoilers=" + this.fileSpoilers + ", embeds=" + this.embeds + ", allowedMentions=" + 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  683 */       allowedMentions().toString() + ", components=" + 
/*  684 */       Objects.toString(this.components_value) + "}";
/*      */   }
/*      */ 
/*      */   
/*  688 */   private static final WebhookExecuteSpec INSTANCE = validate(new WebhookExecuteSpec());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static WebhookExecuteSpec create() {
/*  695 */     return INSTANCE;
/*      */   }
/*      */   
/*      */   private static WebhookExecuteSpec validate(WebhookExecuteSpec instance) {
/*  699 */     return (INSTANCE != null && INSTANCE.equalTo(0, instance)) ? INSTANCE : instance;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static WebhookExecuteSpec copyOf(WebhookExecuteSpecGenerator instance) {
/*  710 */     if (instance instanceof WebhookExecuteSpec) {
/*  711 */       return (WebhookExecuteSpec)instance;
/*      */     }
/*  713 */     return builder()
/*  714 */       .from(instance)
/*  715 */       .build();
/*      */   }
/*      */   
/*      */   public boolean isContentPresent() {
/*  719 */     return !this.content_absent;
/*      */   }
/*      */   
/*      */   public String contentOrElse(String defaultValue) {
/*  723 */     return !this.content_absent ? this.content_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isUsernamePresent() {
/*  727 */     return !this.username_absent;
/*      */   }
/*      */   
/*      */   public String usernameOrElse(String defaultValue) {
/*  731 */     return !this.username_absent ? this.username_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isAvatarUrlPresent() {
/*  735 */     return !this.avatarUrl_absent;
/*      */   }
/*      */   
/*      */   public String avatarUrlOrElse(String defaultValue) {
/*  739 */     return !this.avatarUrl_absent ? this.avatarUrl_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isAllowedMentionsPresent() {
/*  743 */     return !this.allowedMentions_absent;
/*      */   }
/*      */   
/*      */   public AllowedMentions allowedMentionsOrElse(AllowedMentions defaultValue) {
/*  747 */     return !this.allowedMentions_absent ? this.allowedMentions_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isComponentsPresent() {
/*  751 */     return !this.components_absent;
/*      */   }
/*      */   
/*      */   public List<LayoutComponent> componentsOrElse(List<LayoutComponent> defaultValue) {
/*  755 */     return !this.components_absent ? this.components_value : defaultValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Builder builder() {
/*  776 */     return new Builder();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   @Generated(from = "WebhookExecuteSpecGenerator", generator = "Immutables")
/*      */   public static final class Builder
/*      */   {
/*      */     private static final long OPT_BIT_TTS = 1L;
/*      */     
/*      */     private static final long OPT_BIT_FILES = 2L;
/*      */     
/*      */     private static final long OPT_BIT_FILE_SPOILERS = 4L;
/*      */     
/*      */     private static final long OPT_BIT_EMBEDS = 8L;
/*      */     
/*      */     private long optBits;
/*      */     
/*  794 */     private Possible<String> content_possible = Possible.absent();
/*  795 */     private Possible<String> username_possible = Possible.absent();
/*  796 */     private Possible<String> avatarUrl_possible = Possible.absent();
/*  797 */     private Possible<AllowedMentions> allowedMentions_possible = Possible.absent();
/*  798 */     private List<LayoutComponent> components_list = null;
/*      */     private boolean tts;
/*  800 */     private List<MessageCreateFields.File> files = new ArrayList<>();
/*  801 */     private List<MessageCreateFields.FileSpoiler> fileSpoilers = new ArrayList<>();
/*  802 */     private List<EmbedCreateSpec> embeds = new ArrayList<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder from(WebhookExecuteSpec instance) {
/*  816 */       return from(instance);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     final Builder from(WebhookExecuteSpecGenerator instance) {
/*  826 */       Objects.requireNonNull(instance, "instance");
/*  827 */       content(instance.content());
/*  828 */       username(instance.username());
/*  829 */       avatarUrl(instance.avatarUrl());
/*  830 */       tts(instance.tts());
/*  831 */       addAllFiles(instance.files());
/*  832 */       addAllFileSpoilers(instance.fileSpoilers());
/*  833 */       addAllEmbeds(instance.embeds());
/*  834 */       allowedMentions(instance.allowedMentions());
/*  835 */       components(instance.components());
/*  836 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder content(Possible<String> value) {
/*  841 */       this.content_possible = value;
/*  842 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder content(String value) {
/*  847 */       this.content_possible = Possible.of(value);
/*  848 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder username(Possible<String> value) {
/*  853 */       this.username_possible = value;
/*  854 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder username(String value) {
/*  859 */       this.username_possible = Possible.of(value);
/*  860 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder avatarUrl(Possible<String> value) {
/*  865 */       this.avatarUrl_possible = value;
/*  866 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder avatarUrl(String value) {
/*  871 */       this.avatarUrl_possible = Possible.of(value);
/*  872 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public final Builder tts(boolean tts) {
/*  883 */       this.tts = tts;
/*  884 */       this.optBits |= 0x1L;
/*  885 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public final Builder addFile(MessageCreateFields.File element) {
/*  895 */       element = ImmutableMessageCreateFields.File.copyOf(element);
/*  896 */       this.files.add(Objects.<MessageCreateFields.File>requireNonNull(element, "files element"));
/*  897 */       this.optBits |= 0x2L;
/*  898 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addFile(String name, InputStream inputStream) {
/*  908 */       return addFile(ImmutableMessageCreateFields.File.of(name, inputStream));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public final Builder addFiles(MessageCreateFields.File... elements) {
/*  918 */       for (MessageCreateFields.File element : elements) {
/*  919 */         element = ImmutableMessageCreateFields.File.copyOf(element);
/*  920 */         this.files.add(Objects.<MessageCreateFields.File>requireNonNull(element, "files element"));
/*      */       } 
/*  922 */       this.optBits |= 0x2L;
/*  923 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public final Builder files(Iterable<? extends MessageCreateFields.File> elements) {
/*  934 */       this.files.clear();
/*  935 */       return addAllFiles(elements);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public final Builder addAllFiles(Iterable<? extends MessageCreateFields.File> elements) {
/*  945 */       for (MessageCreateFields.File element : elements) {
/*  946 */         element = ImmutableMessageCreateFields.File.copyOf(element);
/*  947 */         this.files.add(Objects.<MessageCreateFields.File>requireNonNull(element, "files element"));
/*      */       } 
/*  949 */       this.optBits |= 0x2L;
/*  950 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public final Builder addFileSpoiler(MessageCreateFields.FileSpoiler element) {
/*  960 */       element = ImmutableMessageCreateFields.FileSpoiler.copyOf(element);
/*  961 */       this.fileSpoilers.add(Objects.<MessageCreateFields.FileSpoiler>requireNonNull(element, "fileSpoilers element"));
/*  962 */       this.optBits |= 0x4L;
/*  963 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addFileSpoiler(String name, InputStream inputStream) {
/*  973 */       return addFileSpoiler(ImmutableMessageCreateFields.FileSpoiler.of(name, inputStream));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public final Builder addFileSpoilers(MessageCreateFields.FileSpoiler... elements) {
/*  983 */       for (MessageCreateFields.FileSpoiler element : elements) {
/*  984 */         element = ImmutableMessageCreateFields.FileSpoiler.copyOf(element);
/*  985 */         this.fileSpoilers.add(Objects.<MessageCreateFields.FileSpoiler>requireNonNull(element, "fileSpoilers element"));
/*      */       } 
/*  987 */       this.optBits |= 0x4L;
/*  988 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public final Builder fileSpoilers(Iterable<? extends MessageCreateFields.FileSpoiler> elements) {
/*  999 */       this.fileSpoilers.clear();
/* 1000 */       return addAllFileSpoilers(elements);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public final Builder addAllFileSpoilers(Iterable<? extends MessageCreateFields.FileSpoiler> elements) {
/* 1010 */       for (MessageCreateFields.FileSpoiler element : elements) {
/* 1011 */         element = ImmutableMessageCreateFields.FileSpoiler.copyOf(element);
/* 1012 */         this.fileSpoilers.add(Objects.<MessageCreateFields.FileSpoiler>requireNonNull(element, "fileSpoilers element"));
/*      */       } 
/* 1014 */       this.optBits |= 0x4L;
/* 1015 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public final Builder addEmbed(EmbedCreateSpec element) {
/* 1025 */       this.embeds.add(Objects.<EmbedCreateSpec>requireNonNull(element, "embeds element"));
/* 1026 */       this.optBits |= 0x8L;
/* 1027 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public final Builder addEmbeds(EmbedCreateSpec... elements) {
/* 1037 */       for (EmbedCreateSpec element : elements) {
/* 1038 */         this.embeds.add(Objects.<EmbedCreateSpec>requireNonNull(element, "embeds element"));
/*      */       }
/* 1040 */       this.optBits |= 0x8L;
/* 1041 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public final Builder embeds(Iterable<? extends EmbedCreateSpec> elements) {
/* 1052 */       this.embeds.clear();
/* 1053 */       return addAllEmbeds(elements);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public final Builder addAllEmbeds(Iterable<? extends EmbedCreateSpec> elements) {
/* 1063 */       for (EmbedCreateSpec element : elements) {
/* 1064 */         this.embeds.add(Objects.<EmbedCreateSpec>requireNonNull(element, "embeds element"));
/*      */       }
/* 1066 */       this.optBits |= 0x8L;
/* 1067 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder allowedMentions(Possible<AllowedMentions> value) {
/* 1072 */       this.allowedMentions_possible = value;
/* 1073 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder allowedMentions(AllowedMentions value) {
/* 1078 */       this.allowedMentions_possible = Possible.of(value);
/* 1079 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder addComponent(LayoutComponent element) {
/* 1084 */       components_getOrCreate().add(element);
/* 1085 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder addAllComponents(List<LayoutComponent> elements) {
/* 1090 */       components_getOrCreate().addAll(elements);
/* 1091 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder components(Possible<List<LayoutComponent>> elements) {
/* 1096 */       this.components_list = null;
/* 1097 */       elements.toOptional().ifPresent(e -> components_getOrCreate().addAll(e));
/* 1098 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder components(List<LayoutComponent> elements) {
/* 1103 */       this.components_list = new ArrayList<>(elements);
/* 1104 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder components(Iterable<LayoutComponent> elements) {
/* 1109 */       this.components_list = (List<LayoutComponent>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/* 1110 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public WebhookExecuteSpec build() {
/* 1119 */       return WebhookExecuteSpec.validate(new WebhookExecuteSpec(this));
/*      */     }
/*      */     
/*      */     private boolean ttsIsSet() {
/* 1123 */       return ((this.optBits & 0x1L) != 0L);
/*      */     }
/*      */     
/*      */     private boolean filesIsSet() {
/* 1127 */       return ((this.optBits & 0x2L) != 0L);
/*      */     }
/*      */     
/*      */     private boolean fileSpoilersIsSet() {
/* 1131 */       return ((this.optBits & 0x4L) != 0L);
/*      */     }
/*      */     
/*      */     private boolean embedsIsSet() {
/* 1135 */       return ((this.optBits & 0x8L) != 0L);
/*      */     }
/*      */     
/*      */     private Possible<String> content_build() {
/* 1139 */       return this.content_possible;
/*      */     }
/*      */     
/*      */     private Possible<String> username_build() {
/* 1143 */       return this.username_possible;
/*      */     }
/*      */     
/*      */     private Possible<String> avatarUrl_build() {
/* 1147 */       return this.avatarUrl_possible;
/*      */     }
/*      */     
/*      */     private Possible<AllowedMentions> allowedMentions_build() {
/* 1151 */       return this.allowedMentions_possible;
/*      */     }
/*      */     
/*      */     private Possible<List<LayoutComponent>> components_build() {
/* 1155 */       return (this.components_list == null) ? Possible.absent() : 
/* 1156 */         Possible.of(this.components_list);
/*      */     }
/*      */     
/*      */     private List<LayoutComponent> components_getOrCreate() {
/* 1160 */       if (this.components_list == null) {
/* 1161 */         this.components_list = new ArrayList<>();
/*      */       }
/* 1163 */       return this.components_list;
/*      */     }
/*      */     private Builder() {} }
/*      */   
/*      */   private static <T> List<T> createSafeList(Iterable<? extends T> iterable, boolean checkNulls, boolean skipNulls) {
/*      */     ArrayList<T> list;
/* 1169 */     if (iterable instanceof Collection) {
/* 1170 */       int size = ((Collection)iterable).size();
/* 1171 */       if (size == 0) return Collections.emptyList(); 
/* 1172 */       list = new ArrayList<>();
/*      */     } else {
/* 1174 */       list = new ArrayList<>();
/*      */     } 
/* 1176 */     for (T element : iterable) {
/* 1177 */       if (skipNulls && element == null)
/* 1178 */         continue;  if (checkNulls) Objects.requireNonNull(element, "element"); 
/* 1179 */       list.add(element);
/*      */     } 
/* 1181 */     return list;
/*      */   }
/*      */   
/*      */   private static <T> List<T> createUnmodifiableList(boolean clone, List<T> list) {
/* 1185 */     switch (list.size()) { case 0:
/* 1186 */         return Collections.emptyList();
/* 1187 */       case 1: return Collections.singletonList(list.get(0)); }
/*      */     
/* 1189 */     if (clone) {
/* 1190 */       return Collections.unmodifiableList(new ArrayList<>(list));
/*      */     }
/* 1192 */     if (list instanceof ArrayList) {
/* 1193 */       ((ArrayList)list).trimToSize();
/*      */     }
/* 1195 */     return Collections.unmodifiableList(list);
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\WebhookExecuteSpec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */