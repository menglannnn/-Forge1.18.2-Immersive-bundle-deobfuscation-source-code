/*     */ package discord4j.core.spec.legacy;
/*     */ 
/*     */ import discord4j.discordjson.json.RoleCreateRequest;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import discord4j.rest.util.Color;
/*     */ import discord4j.rest.util.PermissionSet;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LegacyRoleCreateSpec
/*     */   implements LegacyAuditSpec<RoleCreateRequest>
/*     */ {
/*     */   private String name;
/*     */   private Long permissions;
/*     */   private Integer color;
/*     */   private Boolean hoist;
/*     */   private Boolean mentionable;
/*     */   @Nullable
/*     */   private String reason;
/*     */   
/*     */   public LegacyRoleCreateSpec setName(String name) {
/*  49 */     this.name = name;
/*  50 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyRoleCreateSpec setPermissions(PermissionSet permissions) {
/*  60 */     this.permissions = Long.valueOf(permissions.getRawValue());
/*  61 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyRoleCreateSpec setColor(Color color) {
/*  71 */     this.color = Integer.valueOf(color.getRGB());
/*  72 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyRoleCreateSpec setHoist(boolean hoist) {
/*  82 */     this.hoist = Boolean.valueOf(hoist);
/*  83 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyRoleCreateSpec setMentionable(boolean mentionable) {
/*  93 */     this.mentionable = Boolean.valueOf(mentionable);
/*  94 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public LegacyRoleCreateSpec setReason(@Nullable String reason) {
/*  99 */     this.reason = reason;
/* 100 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String getReason() {
/* 106 */     return this.reason;
/*     */   }
/*     */ 
/*     */   
/*     */   public RoleCreateRequest asRequest() {
/* 111 */     return (RoleCreateRequest)RoleCreateRequest.builder()
/* 112 */       .name((this.name == null) ? Possible.absent() : Possible.of(this.name))
/* 113 */       .permissions((this.permissions == null) ? Possible.absent() : Possible.of(this.permissions))
/* 114 */       .color((this.color == null) ? Possible.absent() : Possible.of(this.color))
/* 115 */       .hoist((this.hoist == null) ? Possible.absent() : Possible.of(this.hoist))
/* 116 */       .mentionable((this.mentionable == null) ? Possible.absent() : Possible.of(this.mentionable))
/* 117 */       .build();
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\legacy\LegacyRoleCreateSpec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */