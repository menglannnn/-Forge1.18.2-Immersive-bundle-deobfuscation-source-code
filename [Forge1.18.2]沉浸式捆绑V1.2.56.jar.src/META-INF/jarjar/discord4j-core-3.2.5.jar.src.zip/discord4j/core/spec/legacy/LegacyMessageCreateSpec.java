/*     */ package discord4j.core.spec.legacy;
/*     */ 
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.object.component.LayoutComponent;
/*     */ import discord4j.core.object.component.MessageComponent;
/*     */ import discord4j.discordjson.json.AllowedMentionsData;
/*     */ import discord4j.discordjson.json.EmbedData;
/*     */ import discord4j.discordjson.json.ImmutableMessageCreateRequest;
/*     */ import discord4j.discordjson.json.MessageCreateRequest;
/*     */ import discord4j.discordjson.json.MessageReferenceData;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import discord4j.rest.util.AllowedMentions;
/*     */ import discord4j.rest.util.MultipartRequest;
/*     */ import java.io.InputStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.stream.Collectors;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.function.Tuple2;
/*     */ import reactor.util.function.Tuples;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LegacyMessageCreateSpec
/*     */   implements LegacySpec<MultipartRequest<MessageCreateRequest>>
/*     */ {
/*     */   @Nullable
/*     */   private String content;
/*     */   @Nullable
/*     */   private String nonce;
/*     */   private boolean tts;
/*     */   private List<EmbedData> embeds;
/*     */   private List<Tuple2<String, InputStream>> files;
/*     */   private AllowedMentionsData allowedMentionsData;
/*     */   private MessageReferenceData messageReferenceData;
/*     */   private List<LayoutComponent> components;
/*     */   
/*     */   public LegacyMessageCreateSpec setContent(String content) {
/*  71 */     this.content = content;
/*  72 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyMessageCreateSpec setNonce(Snowflake nonce) {
/*  82 */     this.nonce = nonce.asString();
/*  83 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyMessageCreateSpec setTts(boolean tts) {
/*  93 */     this.tts = tts;
/*  94 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public LegacyMessageCreateSpec setEmbed(Consumer<? super LegacyEmbedCreateSpec> spec) {
/* 108 */     LegacyEmbedCreateSpec mutatedSpec = new LegacyEmbedCreateSpec();
/* 109 */     spec.accept(mutatedSpec);
/* 110 */     this.embeds = Collections.singletonList(mutatedSpec.asRequest());
/* 111 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyMessageCreateSpec addEmbed(Consumer<? super LegacyEmbedCreateSpec> spec) {
/* 123 */     LegacyEmbedCreateSpec mutatedSpec = new LegacyEmbedCreateSpec();
/* 124 */     spec.accept(mutatedSpec);
/* 125 */     if (this.embeds == null) {
/* 126 */       this.embeds = new ArrayList<>(1);
/*     */     }
/* 128 */     this.embeds.add(mutatedSpec.asRequest());
/* 129 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyMessageCreateSpec addFile(String fileName, InputStream file) {
/* 140 */     if (this.files == null) {
/* 141 */       this.files = new ArrayList<>(1);
/*     */     }
/* 143 */     this.files.add(Tuples.of(fileName, file));
/* 144 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyMessageCreateSpec addFileSpoiler(String fileName, InputStream file) {
/* 155 */     return addFile("SPOILER_" + fileName, file);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyMessageCreateSpec setAllowedMentions(@Nullable AllowedMentions allowedMentions) {
/* 166 */     this.allowedMentionsData = (allowedMentions != null) ? allowedMentions.toData() : null;
/* 167 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyMessageCreateSpec setMessageReference(Snowflake messageId) {
/* 178 */     LegacyMessageReferenceSpec spec = new LegacyMessageReferenceSpec();
/* 179 */     spec.setMessageId(messageId);
/* 180 */     this.messageReferenceData = spec.asRequest();
/* 181 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyMessageCreateSpec setComponents(LayoutComponent... components) {
/* 191 */     return setComponents(Arrays.asList(components));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyMessageCreateSpec setComponents(List<LayoutComponent> components) {
/* 201 */     this.components = components;
/* 202 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MultipartRequest<MessageCreateRequest> asRequest() {
/* 216 */     ImmutableMessageCreateRequest immutableMessageCreateRequest = MessageCreateRequest.builder().content((this.content == null) ? Possible.absent() : Possible.of(this.content)).nonce((this.nonce == null) ? Possible.absent() : Possible.of(this.nonce)).tts(Boolean.valueOf(this.tts)).embeds((this.embeds == null) ? Possible.absent() : Possible.of(this.embeds)).allowedMentions((this.allowedMentionsData == null) ? Possible.absent() : Possible.of(this.allowedMentionsData)).messageReference((this.messageReferenceData == null) ? Possible.absent() : Possible.of(this.messageReferenceData)).components((this.components == null) ? Possible.absent() : Possible.of(this.components.stream().map(MessageComponent::getData).collect(Collectors.toList()))).build();
/* 217 */     return MultipartRequest.ofRequestAndFiles(immutableMessageCreateRequest, (this.files == null) ? Collections.emptyList() : this.files);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\legacy\LegacyMessageCreateSpec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */