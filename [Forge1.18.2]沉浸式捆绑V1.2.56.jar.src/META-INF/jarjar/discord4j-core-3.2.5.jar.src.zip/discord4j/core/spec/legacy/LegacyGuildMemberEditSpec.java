/*     */ package discord4j.core.spec.legacy;
/*     */ 
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.discordjson.json.GuildMemberModifyRequest;
/*     */ import discord4j.discordjson.json.ImmutableGuildMemberModifyRequest;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.List;
/*     */ import java.util.Optional;
/*     */ import java.util.Set;
/*     */ import java.util.stream.Collectors;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LegacyGuildMemberEditSpec
/*     */   implements LegacyAuditSpec<GuildMemberModifyRequest>
/*     */ {
/*  38 */   private final ImmutableGuildMemberModifyRequest.Builder builder = GuildMemberModifyRequest.builder();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private String reason;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyGuildMemberEditSpec setNewVoiceChannel(@Nullable Snowflake channel) {
/*  50 */     this.builder.channelId(Possible.of(Optional.<Snowflake>ofNullable(channel).map(Snowflake::asString)));
/*  51 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyGuildMemberEditSpec setMute(boolean mute) {
/*  62 */     this.builder.mute(Boolean.valueOf(mute));
/*  63 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyGuildMemberEditSpec setDeafen(boolean deaf) {
/*  74 */     this.builder.deaf(Boolean.valueOf(deaf));
/*  75 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyGuildMemberEditSpec setNickname(@Nullable String nickname) {
/*  85 */     this.builder.nickOrNull(nickname);
/*  86 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyGuildMemberEditSpec setRoles(Set<Snowflake> roles) {
/*  97 */     this.builder.roles((List)roles.stream().map(Snowflake::asString).collect(Collectors.toList()));
/*  98 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public LegacyGuildMemberEditSpec setReason(@Nullable String reason) {
/* 103 */     this.reason = reason;
/* 104 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String getReason() {
/* 110 */     return this.reason;
/*     */   }
/*     */ 
/*     */   
/*     */   public GuildMemberModifyRequest asRequest() {
/* 115 */     return (GuildMemberModifyRequest)this.builder.build();
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\legacy\LegacyGuildMemberEditSpec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */