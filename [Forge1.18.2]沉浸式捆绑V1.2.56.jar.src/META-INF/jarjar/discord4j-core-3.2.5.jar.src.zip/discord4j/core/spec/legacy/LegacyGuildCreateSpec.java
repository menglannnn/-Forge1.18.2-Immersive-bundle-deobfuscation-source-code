/*     */ package discord4j.core.spec.legacy;
/*     */ 
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.object.Region;
/*     */ import discord4j.core.object.entity.Guild;
/*     */ import discord4j.core.object.entity.channel.Channel;
/*     */ import discord4j.discordjson.Id;
/*     */ import discord4j.discordjson.json.GuildCreateRequest;
/*     */ import discord4j.discordjson.json.ImmutableGuildCreateRequest;
/*     */ import discord4j.discordjson.json.PartialChannelCreateRequest;
/*     */ import discord4j.discordjson.json.RoleCreateRequest;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import discord4j.rest.util.Image;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.function.Consumer;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LegacyGuildCreateSpec
/*     */   implements LegacySpec<GuildCreateRequest>
/*     */ {
/*  50 */   private final ImmutableGuildCreateRequest.Builder builder = GuildCreateRequest.builder();
/*  51 */   private final List<RoleCreateRequest> roles = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyGuildCreateSpec setName(String name) {
/*  60 */     this.builder.name(name);
/*  61 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyGuildCreateSpec setRegion(Region.Id regionId) {
/*  71 */     this.builder.region(regionId.getValue());
/*  72 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyGuildCreateSpec setRegion(@Nullable String regionId) {
/*  82 */     this.builder.region((regionId == null) ? Possible.absent() : Possible.of(regionId));
/*  83 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyGuildCreateSpec setIcon(@Nullable Image icon) {
/*  93 */     this.builder.icon((icon == null) ? Possible.absent() : Possible.of(icon.getDataUri()));
/*  94 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyGuildCreateSpec setVerificationLevel(@Nullable Guild.VerificationLevel verificationLevel) {
/* 104 */     this.builder.verificationLevel((verificationLevel == null) ? 
/* 105 */         Possible.absent() : Possible.of(Integer.valueOf(verificationLevel.getValue())));
/* 106 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyGuildCreateSpec setDefaultMessageNotificationLevel(@Nullable Guild.NotificationLevel notificationLevel) {
/* 116 */     this.builder.defaultMessageNotifications((notificationLevel == null) ? 
/* 117 */         Possible.absent() : Possible.of(Integer.valueOf(notificationLevel.getValue())));
/* 118 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyGuildCreateSpec setExplicitContentFilter(@Nullable Guild.ContentFilterLevel explicitContentFilter) {
/* 128 */     this.builder.explicitContentFilter((explicitContentFilter == null) ? 
/* 129 */         Possible.absent() : Possible.of(Integer.valueOf(explicitContentFilter.getValue())));
/* 130 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyGuildCreateSpec addRole(Consumer<? super LegacyRoleCreateSpec> legacyroleSpec) {
/* 140 */     LegacyRoleCreateSpec mutatedSpec = new LegacyRoleCreateSpec();
/* 141 */     legacyroleSpec.accept(mutatedSpec);
/* 142 */     this.roles.add(mutatedSpec.asRequest());
/* 143 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyGuildCreateSpec addEveryoneRole(Consumer<? super LegacyRoleCreateSpec> legacyroleSpec) {
/* 157 */     LegacyRoleCreateSpec mutatedSpec = new LegacyRoleCreateSpec();
/* 158 */     legacyroleSpec.accept(mutatedSpec);
/* 159 */     this.roles.add(0, mutatedSpec.asRequest());
/* 160 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyGuildCreateSpec addChannel(String name, Channel.Type type) {
/* 171 */     this.builder.addChannel((PartialChannelCreateRequest)PartialChannelCreateRequest.builder()
/* 172 */         .name(name)
/* 173 */         .type(type.getValue())
/* 174 */         .build());
/* 175 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyGuildCreateSpec setAfkChannelId(@Nullable Snowflake id) {
/* 185 */     this.builder.afkChannelId((id == null) ? Possible.absent() : Possible.of(Id.of(id.asLong())));
/* 186 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyGuildCreateSpec setAfkTimeout(@Nullable Integer afkTimeout) {
/* 196 */     this.builder.afkTimeout((afkTimeout == null) ? Possible.absent() : Possible.of(afkTimeout));
/* 197 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyGuildCreateSpec setSystemChannelId(@Nullable Snowflake id) {
/* 208 */     this.builder.systemChannelId((id == null) ? Possible.absent() : Possible.of(Id.of(id.asLong())));
/* 209 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyGuildCreateSpec setSystemChannelFlags(@Nullable Guild.SystemChannelFlag... flags) {
/* 219 */     if (flags != null) {
/* 220 */       this.builder.systemChannelFlags(Possible.of(Integer.valueOf(Arrays.<Guild.SystemChannelFlag>stream(flags)
/* 221 */               .mapToInt(Guild.SystemChannelFlag::getValue)
/* 222 */               .reduce(0, (left, right) -> left | right))));
/*     */     } else {
/* 224 */       this.builder.systemChannelFlags(Possible.absent());
/*     */     } 
/* 226 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public GuildCreateRequest asRequest() {
/* 231 */     this.builder.roles(this.roles);
/* 232 */     return (GuildCreateRequest)this.builder.build();
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\legacy\LegacyGuildCreateSpec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */