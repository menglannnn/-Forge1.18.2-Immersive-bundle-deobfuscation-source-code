/*    */ package discord4j.core.spec.legacy;
/*    */ 
/*    */ import discord4j.common.util.Snowflake;
/*    */ import discord4j.discordjson.json.WebhookModifyRequest;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import discord4j.rest.util.Image;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LegacyWebhookEditSpec
/*    */   implements LegacyAuditSpec<WebhookModifyRequest>
/*    */ {
/* 33 */   private Possible<String> name = Possible.absent();
/* 34 */   private Possible<String> avatar = Possible.absent();
/*    */   @Nullable
/*    */   private String reason;
/* 37 */   private Possible<String> channelId = Possible.absent();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public LegacyWebhookEditSpec setName(String name) {
/* 46 */     this.name = Possible.of(name);
/* 47 */     return this;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public LegacyWebhookEditSpec setAvatar(@Nullable Image avatar) {
/* 57 */     this.avatar = (avatar == null) ? Possible.absent() : Possible.of(avatar.getDataUri());
/* 58 */     return this;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public LegacyWebhookEditSpec setChannel(@Nullable Snowflake id) {
/* 68 */     this.channelId = (id == null) ? Possible.absent() : Possible.of(id.asString());
/* 69 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public LegacyWebhookEditSpec setReason(String reason) {
/* 74 */     this.reason = reason;
/* 75 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public String getReason() {
/* 81 */     return this.reason;
/*    */   }
/*    */ 
/*    */   
/*    */   public WebhookModifyRequest asRequest() {
/* 86 */     return (WebhookModifyRequest)WebhookModifyRequest.builder()
/* 87 */       .name(this.name)
/* 88 */       .avatar(this.avatar)
/* 89 */       .channelId(this.channelId)
/* 90 */       .build();
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\legacy\LegacyWebhookEditSpec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */