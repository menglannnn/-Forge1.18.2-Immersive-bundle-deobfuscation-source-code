/*    */ package discord4j.core.spec.legacy;
/*    */ 
/*    */ import discord4j.common.util.Snowflake;
/*    */ import discord4j.discordjson.json.GuildEmojiModifyRequest;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import java.util.List;
/*    */ import java.util.Set;
/*    */ import java.util.stream.Collectors;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LegacyGuildEmojiEditSpec
/*    */   implements LegacyAuditSpec<GuildEmojiModifyRequest>
/*    */ {
/* 36 */   private Possible<String> name = Possible.absent();
/* 37 */   private Possible<List<String>> roles = Possible.absent();
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   private String reason;
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public LegacyGuildEmojiEditSpec setName(String name) {
/* 48 */     this.name = Possible.of(name);
/* 49 */     return this;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public LegacyGuildEmojiEditSpec setRoles(Set<Snowflake> roles) {
/* 59 */     this.roles = Possible.of(roles.stream().map(Snowflake::asString).collect(Collectors.toList()));
/* 60 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public LegacyGuildEmojiEditSpec setReason(@Nullable String reason) {
/* 65 */     this.reason = reason;
/* 66 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public String getReason() {
/* 72 */     return this.reason;
/*    */   }
/*    */ 
/*    */   
/*    */   public GuildEmojiModifyRequest asRequest() {
/* 77 */     return (GuildEmojiModifyRequest)GuildEmojiModifyRequest.builder()
/* 78 */       .name(this.name)
/* 79 */       .roles(this.roles)
/* 80 */       .build();
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\legacy\LegacyGuildEmojiEditSpec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */