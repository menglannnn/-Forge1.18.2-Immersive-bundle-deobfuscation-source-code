/*    */ package discord4j.core.spec.legacy;
/*    */ 
/*    */ import discord4j.common.util.Snowflake;
/*    */ import discord4j.discordjson.json.ImmutableMessageReferenceData;
/*    */ import discord4j.discordjson.json.MessageReferenceData;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LegacyMessageReferenceSpec
/*    */   implements LegacySpec<MessageReferenceData>
/*    */ {
/* 31 */   private final ImmutableMessageReferenceData.Builder requestBuilder = MessageReferenceData.builder();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public LegacyMessageReferenceSpec setMessageId(Snowflake messageId) {
/* 40 */     this.requestBuilder.messageId(messageId.asString());
/* 41 */     return this;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public LegacyMessageReferenceSpec setChannelId(Snowflake channelId) {
/* 51 */     this.requestBuilder.channelId(channelId.asString());
/* 52 */     return this;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public LegacyMessageReferenceSpec setGuildId(Snowflake guildId) {
/* 62 */     this.requestBuilder.guildId(guildId.asString());
/* 63 */     return this;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public LegacyMessageReferenceSpec setFailIfNotExists(boolean failIfNotExists) {
/* 75 */     this.requestBuilder.failIfNotExists(Boolean.valueOf(failIfNotExists));
/* 76 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public MessageReferenceData asRequest() {
/* 81 */     return (MessageReferenceData)this.requestBuilder.build();
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\legacy\LegacyMessageReferenceSpec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */