/*     */ package discord4j.core.spec.legacy;
/*     */ 
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.object.Region;
/*     */ import discord4j.core.object.entity.Guild;
/*     */ import discord4j.discordjson.json.GuildModifyRequest;
/*     */ import discord4j.discordjson.json.ImmutableGuildModifyRequest;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import discord4j.rest.util.Image;
/*     */ import java.util.Arrays;
/*     */ import java.util.Locale;
/*     */ import java.util.Optional;
/*     */ import java.util.Set;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LegacyGuildEditSpec
/*     */   implements LegacyAuditSpec<GuildModifyRequest>
/*     */ {
/*  40 */   private final ImmutableGuildModifyRequest.Builder requestBuilder = GuildModifyRequest.builder();
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private String reason;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyGuildEditSpec setName(String name) {
/*  51 */     this.requestBuilder.name(name);
/*  52 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyGuildEditSpec setRegion(Region.Id regionId) {
/*  62 */     this.requestBuilder.region(Possible.of(Optional.<Region.Id>of(regionId).map(Region.Id::getValue)));
/*  63 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyGuildEditSpec setRegion(@Nullable String regionId) {
/*  73 */     this.requestBuilder.region(Possible.of(Optional.ofNullable(regionId)));
/*  74 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyGuildEditSpec setVerificationLevel(Guild.VerificationLevel verificationLevel) {
/*  84 */     this.requestBuilder.verificationLevelOrNull(Integer.valueOf(verificationLevel.getValue()));
/*  85 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyGuildEditSpec setDefaultMessageNotificationsLevel(Guild.NotificationLevel notificationsLevel) {
/*  95 */     this.requestBuilder.defaultMessageNotificationsOrNull(Integer.valueOf(notificationsLevel.getValue()));
/*  96 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyGuildEditSpec setExplicitContentFilter(Guild.ContentFilterLevel level) {
/* 106 */     this.requestBuilder.explicitContentFilterOrNull(Integer.valueOf(level.getValue()));
/* 107 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyGuildEditSpec setAfkChannelId(@Nullable Snowflake afkChannelId) {
/* 117 */     this.requestBuilder.afkChannelId(Possible.of(Optional.<Snowflake>ofNullable(afkChannelId).map(Snowflake::asString)));
/* 118 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyGuildEditSpec setAfkTimeout(int afkTimeout) {
/* 128 */     this.requestBuilder.afkTimeout(Integer.valueOf(afkTimeout));
/* 129 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyGuildEditSpec setIcon(@Nullable Image icon) {
/* 139 */     this.requestBuilder.icon(Possible.of(Optional.<Image>ofNullable(icon).map(Image::getDataUri)));
/* 140 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyGuildEditSpec setOwnerId(Snowflake ownerId) {
/* 150 */     this.requestBuilder.ownerId(ownerId.asString());
/* 151 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyGuildEditSpec setSplash(@Nullable Image splash) {
/* 161 */     this.requestBuilder.splash(Possible.of(Optional.<Image>ofNullable(splash).map(Image::getDataUri)));
/* 162 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyGuildEditSpec setDiscoverySplash(@Nullable Image discoverySplash) {
/* 172 */     this.requestBuilder.splash(Possible.of(Optional.<Image>ofNullable(discoverySplash).map(Image::getDataUri)));
/* 173 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyGuildEditSpec setBanner(@Nullable Image banner) {
/* 183 */     this.requestBuilder.banner(Possible.of(Optional.<Image>ofNullable(banner).map(Image::getDataUri)));
/* 184 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyGuildEditSpec setSystemChannelId(@Nullable Snowflake systemChannelId) {
/* 195 */     this.requestBuilder.systemChannelId(Possible.of(Optional.<Snowflake>ofNullable(systemChannelId).map(Snowflake::asString)));
/* 196 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public LegacyGuildEditSpec setSystemChannelFlags(@Nullable Guild.SystemChannelFlag flag) {
/* 208 */     this.requestBuilder.systemChannelFlags((flag == null) ? Possible.absent() : Possible.of(Integer.valueOf(flag.getValue())));
/* 209 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyGuildEditSpec setSystemChannelFlags(@Nullable Guild.SystemChannelFlag... flags) {
/* 219 */     if (flags != null) {
/* 220 */       this.requestBuilder.systemChannelFlags(Possible.of(Integer.valueOf(Arrays.<Guild.SystemChannelFlag>stream(flags)
/* 221 */               .mapToInt(Guild.SystemChannelFlag::getValue)
/* 222 */               .reduce(0, (left, right) -> left | right))));
/*     */     } else {
/* 224 */       this.requestBuilder.systemChannelFlags(Possible.absent());
/*     */     } 
/* 226 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyGuildEditSpec setRulesChannelId(@Nullable Snowflake rulesChannelId) {
/* 236 */     this.requestBuilder.rulesChannelId(Possible.of(Optional.<Snowflake>ofNullable(rulesChannelId).map(Snowflake::asString)));
/* 237 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyGuildEditSpec setPublicUpdatesChannelId(@Nullable Snowflake publicUpdatesChannelId) {
/* 248 */     this.requestBuilder.publicUpdatesChannelId(Possible.of(Optional.<Snowflake>ofNullable(publicUpdatesChannelId)
/* 249 */           .map(Snowflake::asString)));
/* 250 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyGuildEditSpec setPreferredLocale(@Nullable Locale preferredLocale) {
/* 261 */     this.requestBuilder.preferredLocale(Possible.of(Optional.<Locale>ofNullable(preferredLocale).map(Locale::toLanguageTag)));
/* 262 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyGuildEditSpec setFeatures(Set<String> features) {
/* 275 */     this.requestBuilder.features(features);
/* 276 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyGuildEditSpec setDescription(@Nullable String description) {
/* 286 */     this.requestBuilder.descriptionOrNull(description);
/* 287 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public LegacyGuildEditSpec setReason(@Nullable String reason) {
/* 292 */     this.reason = reason;
/* 293 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String getReason() {
/* 299 */     return this.reason;
/*     */   }
/*     */ 
/*     */   
/*     */   public GuildModifyRequest asRequest() {
/* 304 */     return (GuildModifyRequest)this.requestBuilder.build();
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\legacy\LegacyGuildEditSpec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */