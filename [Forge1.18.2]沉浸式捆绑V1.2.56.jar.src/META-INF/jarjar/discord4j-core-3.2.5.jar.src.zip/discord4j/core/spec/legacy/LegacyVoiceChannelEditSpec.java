/*     */ package discord4j.core.spec.legacy;
/*     */ 
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.object.PermissionOverwrite;
/*     */ import discord4j.core.object.entity.channel.VoiceChannel;
/*     */ import discord4j.discordjson.json.ChannelModifyRequest;
/*     */ import discord4j.discordjson.json.ImmutableChannelModifyRequest;
/*     */ import discord4j.discordjson.json.OverwriteData;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.List;
/*     */ import java.util.Optional;
/*     */ import java.util.Set;
/*     */ import java.util.stream.Collectors;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LegacyVoiceChannelEditSpec
/*     */   implements LegacyAuditSpec<ChannelModifyRequest>
/*     */ {
/*  42 */   private final ImmutableChannelModifyRequest.Builder requestBuilder = ChannelModifyRequest.builder();
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private String reason;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyVoiceChannelEditSpec setName(String name) {
/*  53 */     this.requestBuilder.name(name);
/*  54 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyVoiceChannelEditSpec setPosition(int position) {
/*  64 */     this.requestBuilder.position(Integer.valueOf(position));
/*  65 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyVoiceChannelEditSpec setPermissionOverwrites(Set<? extends PermissionOverwrite> permissionOverwrites) {
/*  77 */     List<OverwriteData> raw = (List<OverwriteData>)permissionOverwrites.stream().map(PermissionOverwrite::getData).collect(Collectors.toList());
/*     */     
/*  79 */     this.requestBuilder.permissionOverwrites(raw);
/*  80 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyVoiceChannelEditSpec setParentId(@Nullable Snowflake parentId) {
/*  92 */     this.requestBuilder.parentId((parentId == null) ? Possible.of(Optional.empty()) : Possible.of(Optional.of(parentId.asString())));
/*  93 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyVoiceChannelEditSpec setBitrate(int bitrate) {
/* 104 */     this.requestBuilder.bitrate(Integer.valueOf(bitrate));
/* 105 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyVoiceChannelEditSpec setUserLimit(int userLimit) {
/* 118 */     this.requestBuilder.userLimit(Integer.valueOf(userLimit));
/* 119 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyVoiceChannelEditSpec setRtcRegion(@Nullable String rtcRegion) {
/* 129 */     this.requestBuilder.rtcRegionOrNull(rtcRegion);
/* 130 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyVoiceChannelEditSpec setVideoQualityMode(VoiceChannel.Mode videoQualityMode) {
/* 140 */     this.requestBuilder.videoQualityModeOrNull(Integer.valueOf(videoQualityMode.getValue()));
/* 141 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public LegacyVoiceChannelEditSpec setReason(@Nullable String reason) {
/* 146 */     this.reason = reason;
/* 147 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String getReason() {
/* 153 */     return this.reason;
/*     */   }
/*     */ 
/*     */   
/*     */   public ChannelModifyRequest asRequest() {
/* 158 */     return (ChannelModifyRequest)this.requestBuilder.build();
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\legacy\LegacyVoiceChannelEditSpec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */