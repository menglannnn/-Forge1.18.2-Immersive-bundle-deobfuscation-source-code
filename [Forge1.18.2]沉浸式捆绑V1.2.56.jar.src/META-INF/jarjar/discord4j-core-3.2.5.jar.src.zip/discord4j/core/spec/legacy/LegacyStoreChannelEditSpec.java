/*    */ package discord4j.core.spec.legacy;
/*    */ 
/*    */ import discord4j.core.object.PermissionOverwrite;
/*    */ import discord4j.discordjson.json.ChannelModifyRequest;
/*    */ import discord4j.discordjson.json.ImmutableChannelModifyRequest;
/*    */ import discord4j.discordjson.json.OverwriteData;
/*    */ import java.util.List;
/*    */ import java.util.Set;
/*    */ import java.util.stream.Collectors;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LegacyStoreChannelEditSpec
/*    */   implements LegacyAuditSpec<ChannelModifyRequest>
/*    */ {
/* 37 */   private final ImmutableChannelModifyRequest.Builder requestBuilder = ChannelModifyRequest.builder();
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   private String reason;
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public LegacyStoreChannelEditSpec setName(String name) {
/* 48 */     this.requestBuilder.name(name);
/* 49 */     return this;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public LegacyStoreChannelEditSpec setPosition(int position) {
/* 59 */     this.requestBuilder.position(Integer.valueOf(position));
/* 60 */     return this;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public LegacyStoreChannelEditSpec setPermissionOverwrites(Set<? extends PermissionOverwrite> permissionOverwrites) {
/* 72 */     List<OverwriteData> raw = (List<OverwriteData>)permissionOverwrites.stream().map(PermissionOverwrite::getData).collect(Collectors.toList());
/*    */     
/* 74 */     this.requestBuilder.permissionOverwrites(raw);
/* 75 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public LegacyStoreChannelEditSpec setReason(@Nullable String reason) {
/* 80 */     this.reason = reason;
/* 81 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public String getReason() {
/* 87 */     return this.reason;
/*    */   }
/*    */ 
/*    */   
/*    */   public ChannelModifyRequest asRequest() {
/* 92 */     return (ChannelModifyRequest)this.requestBuilder.build();
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\legacy\LegacyStoreChannelEditSpec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */