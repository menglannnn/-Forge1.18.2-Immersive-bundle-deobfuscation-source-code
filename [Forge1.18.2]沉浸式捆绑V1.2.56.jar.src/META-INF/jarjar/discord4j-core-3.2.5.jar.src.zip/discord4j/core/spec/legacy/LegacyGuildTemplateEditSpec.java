/*    */ package discord4j.core.spec.legacy;
/*    */ 
/*    */ import discord4j.discordjson.json.TemplateModifyRequest;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import java.util.Optional;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LegacyGuildTemplateEditSpec
/*    */   implements LegacySpec<TemplateModifyRequest>
/*    */ {
/* 31 */   private Possible<String> name = Possible.absent();
/* 32 */   private Possible<Optional<String>> description = Possible.absent();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public LegacyGuildTemplateEditSpec setName(String name) {
/* 41 */     this.name = Possible.of(name);
/* 42 */     return this;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public LegacyGuildTemplateEditSpec setDescription(String description) {
/* 52 */     this.description = Possible.of(Optional.of(description));
/* 53 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public TemplateModifyRequest asRequest() {
/* 58 */     return (TemplateModifyRequest)TemplateModifyRequest.builder()
/* 59 */       .name(this.name)
/* 60 */       .description(this.description)
/* 61 */       .build();
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\legacy\LegacyGuildTemplateEditSpec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */