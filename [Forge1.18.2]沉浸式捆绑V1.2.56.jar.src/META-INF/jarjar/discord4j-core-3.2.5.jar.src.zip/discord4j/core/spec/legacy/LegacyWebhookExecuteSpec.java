/*     */ package discord4j.core.spec.legacy;
/*     */ 
/*     */ import discord4j.discordjson.json.AllowedMentionsData;
/*     */ import discord4j.discordjson.json.EmbedData;
/*     */ import discord4j.discordjson.json.WebhookExecuteRequest;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import discord4j.rest.util.AllowedMentions;
/*     */ import discord4j.rest.util.MultipartRequest;
/*     */ import java.io.InputStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.function.Consumer;
/*     */ import reactor.util.function.Tuple2;
/*     */ import reactor.util.function.Tuples;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LegacyWebhookExecuteSpec
/*     */   implements LegacySpec<MultipartRequest<WebhookExecuteRequest>>
/*     */ {
/*  43 */   private Possible<String> content = Possible.absent();
/*  44 */   private Possible<String> username = Possible.absent();
/*  45 */   private Possible<String> avatarUrl = Possible.absent();
/*  46 */   private Possible<Boolean> tts = Possible.absent();
/*  47 */   private List<Tuple2<String, InputStream>> files = null;
/*  48 */   private List<EmbedData> embeds = null;
/*  49 */   private Possible<AllowedMentionsData> allowedMentions = Possible.absent();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyWebhookExecuteSpec setContent(String content) {
/*  58 */     this.content = Possible.of(content);
/*  59 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyWebhookExecuteSpec setUsername(String username) {
/*  69 */     this.username = Possible.of(username);
/*  70 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyWebhookExecuteSpec setAvatarUrl(String avatarUrl) {
/*  80 */     this.avatarUrl = Possible.of(avatarUrl);
/*  81 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyWebhookExecuteSpec setTts(boolean tts) {
/*  91 */     this.tts = Possible.of(Boolean.valueOf(tts));
/*  92 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyWebhookExecuteSpec addFile(String fileName, InputStream file) {
/* 103 */     if (this.files == null) {
/* 104 */       this.files = new ArrayList<>(1);
/*     */     }
/* 106 */     this.files.add(Tuples.of(fileName, file));
/* 107 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyWebhookExecuteSpec addFileSpoiler(String fileName, InputStream file) {
/* 118 */     return addFile("SPOILER_" + fileName, file);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyWebhookExecuteSpec addEmbed(Consumer<? super LegacyEmbedCreateSpec> spec) {
/* 128 */     LegacyEmbedCreateSpec mutatedSpec = new LegacyEmbedCreateSpec();
/* 129 */     spec.accept(mutatedSpec);
/* 130 */     if (this.embeds == null) {
/* 131 */       this.embeds = new ArrayList<>(1);
/*     */     }
/* 133 */     this.embeds.add(mutatedSpec.asRequest());
/* 134 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyWebhookExecuteSpec setAllowedMentions(AllowedMentions allowedMentions) {
/* 143 */     this.allowedMentions = Possible.of(allowedMentions.toData());
/* 144 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public MultipartRequest<WebhookExecuteRequest> asRequest() {
/* 149 */     return MultipartRequest.ofRequestAndFiles(
/*     */         
/* 151 */         WebhookExecuteRequest.builder()
/* 152 */         .content(this.content)
/* 153 */         .username(this.username)
/* 154 */         .avatarUrl(this.avatarUrl)
/* 155 */         .tts(this.tts)
/* 156 */         .embeds((this.embeds == null) ? Possible.absent() : Possible.of(this.embeds))
/* 157 */         .allowedMentions(this.allowedMentions)
/* 158 */         .build(), 
/* 159 */         (this.files == null) ? Collections.emptyList() : this.files);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\legacy\LegacyWebhookExecuteSpec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */