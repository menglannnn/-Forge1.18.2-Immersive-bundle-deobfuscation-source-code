/*     */ package discord4j.core.spec.legacy;
/*     */ 
/*     */ import discord4j.common.LogUtil;
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.GatewayDiscordClient;
/*     */ import discord4j.core.event.domain.VoiceServerUpdateEvent;
/*     */ import discord4j.core.event.domain.VoiceStateUpdateEvent;
/*     */ import discord4j.core.object.VoiceState;
/*     */ import discord4j.core.object.entity.PartialMember;
/*     */ import discord4j.core.object.entity.channel.VoiceChannel;
/*     */ import discord4j.discordjson.json.gateway.VoiceStateUpdate;
/*     */ import discord4j.gateway.GatewayClientGroup;
/*     */ import discord4j.gateway.intent.Intent;
/*     */ import discord4j.gateway.json.ShardGatewayPayload;
/*     */ import discord4j.voice.AudioProvider;
/*     */ import discord4j.voice.AudioReceiver;
/*     */ import discord4j.voice.LocalVoiceReceiveTaskFactory;
/*     */ import discord4j.voice.LocalVoiceSendTaskFactory;
/*     */ import discord4j.voice.VoiceChannelRetrieveTask;
/*     */ import discord4j.voice.VoiceConnection;
/*     */ import discord4j.voice.VoiceDisconnectTask;
/*     */ import discord4j.voice.VoiceGatewayOptions;
/*     */ import discord4j.voice.VoiceReceiveTaskFactory;
/*     */ import discord4j.voice.VoiceSendTaskFactory;
/*     */ import discord4j.voice.VoiceServerOptions;
/*     */ import discord4j.voice.VoiceServerUpdateTask;
/*     */ import discord4j.voice.VoiceStateUpdateTask;
/*     */ import java.time.Duration;
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.TimeoutException;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.core.publisher.Signal;
/*     */ import reactor.core.publisher.SignalType;
/*     */ import reactor.function.TupleUtils;
/*     */ import reactor.util.Logger;
/*     */ import reactor.util.Loggers;
/*     */ import reactor.util.context.Context;
/*     */ import reactor.util.retry.RetrySpec;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LegacyVoiceChannelJoinSpec
/*     */   implements LegacySpec<Mono<VoiceConnection>>
/*     */ {
/*  51 */   private static final Logger log = Loggers.getLogger(LegacyVoiceChannelJoinSpec.class);
/*     */ 
/*     */   
/*     */   private static final int DEFAULT_TIMEOUT = 10;
/*     */ 
/*     */   
/*     */   private static final int DEFAULT_DISCOVERY_TIMEOUT = 5;
/*     */   
/*  59 */   private Duration timeout = Duration.ofSeconds(10L);
/*  60 */   private AudioProvider provider = AudioProvider.NO_OP;
/*  61 */   private AudioReceiver receiver = AudioReceiver.NO_OP;
/*  62 */   private VoiceSendTaskFactory sendTaskFactory = (VoiceSendTaskFactory)new LocalVoiceSendTaskFactory();
/*  63 */   private VoiceReceiveTaskFactory receiveTaskFactory = (VoiceReceiveTaskFactory)new LocalVoiceReceiveTaskFactory();
/*     */   private boolean selfDeaf;
/*     */   private boolean selfMute;
/*  66 */   private Duration ipDiscoveryTimeout = Duration.ofSeconds(5L);
/*  67 */   private RetrySpec LegacyipDiscoveryRetrySpec = RetrySpec.maxInARow(1L);
/*     */   
/*     */   private final GatewayDiscordClient gateway;
/*     */   private final VoiceChannel voiceChannel;
/*     */   
/*     */   public LegacyVoiceChannelJoinSpec(GatewayDiscordClient gateway, VoiceChannel voiceChannel) {
/*  73 */     this.gateway = Objects.<GatewayDiscordClient>requireNonNull(gateway);
/*  74 */     this.voiceChannel = voiceChannel;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyVoiceChannelJoinSpec setProvider(AudioProvider provider) {
/*  84 */     this.provider = provider;
/*  85 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public LegacyVoiceChannelJoinSpec setReceiver(AudioReceiver receiver) {
/*  98 */     this.receiver = receiver;
/*  99 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyVoiceChannelJoinSpec setSendTaskFactory(VoiceSendTaskFactory sendTaskFactory) {
/* 110 */     this.sendTaskFactory = sendTaskFactory;
/* 111 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public LegacyVoiceChannelJoinSpec setReceiveTaskFactory(VoiceReceiveTaskFactory receiveTaskFactory) {
/* 125 */     this.receiveTaskFactory = receiveTaskFactory;
/* 126 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyVoiceChannelJoinSpec setSelfDeaf(boolean selfDeaf) {
/* 136 */     this.selfDeaf = selfDeaf;
/* 137 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyVoiceChannelJoinSpec setSelfMute(boolean selfMute) {
/* 147 */     this.selfMute = selfMute;
/* 148 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyVoiceChannelJoinSpec setTimeout(Duration timeout) {
/* 161 */     this.timeout = Objects.<Duration>requireNonNull(timeout);
/* 162 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyVoiceChannelJoinSpec setIpDiscoveryTimeout(Duration ipDiscoveryTimeout) {
/* 175 */     this.ipDiscoveryTimeout = Objects.<Duration>requireNonNull(ipDiscoveryTimeout);
/* 176 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyVoiceChannelJoinSpec LegacysetIpDiscoveryRetrySpec(RetrySpec LegacyipDiscoveryRetrySpec) {
/* 189 */     this.LegacyipDiscoveryRetrySpec = Objects.<RetrySpec>requireNonNull(LegacyipDiscoveryRetrySpec);
/* 190 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<VoiceConnection> asRequest() {
/* 195 */     if (!this.gateway.getGatewayResources().getIntents().contains(Intent.GUILD_VOICE_STATES)) {
/* 196 */       return Mono.error(new IllegalArgumentException("GUILD_VOICE_STATES intent is required to establish a voice connection"));
/*     */     }
/*     */ 
/*     */     
/* 200 */     Snowflake guildId = this.voiceChannel.getGuildId();
/* 201 */     Snowflake channelId = this.voiceChannel.getId();
/* 202 */     GatewayClientGroup clientGroup = this.voiceChannel.getClient().getGatewayClientGroup();
/* 203 */     int shardId = clientGroup.computeShardIndex(guildId);
/* 204 */     Mono<Void> sendVoiceStateUpdate = clientGroup.unicast(ShardGatewayPayload.voiceStateUpdate(
/* 205 */           (VoiceStateUpdate)VoiceStateUpdate.builder()
/* 206 */           .guildId(guildId.asString())
/* 207 */           .channelId(channelId.asString())
/* 208 */           .selfMute(this.selfMute)
/* 209 */           .selfDeaf(this.selfDeaf)
/* 210 */           .build(), shardId));
/*     */     
/* 212 */     Mono<VoiceStateUpdateEvent> waitForVoiceStateUpdate = onVoiceStateUpdates(this.gateway, guildId).next();
/* 213 */     Mono<VoiceServerUpdateEvent> waitForVoiceServerUpdate = onVoiceServerUpdate(this.gateway, guildId);
/*     */     
/* 215 */     VoiceDisconnectTask disconnectTask = id -> this.voiceChannel.sendDisconnectVoiceState().then(this.gateway.getVoiceConnectionRegistry().disconnect(id));
/*     */ 
/*     */     
/* 218 */     VoiceServerUpdateTask serverUpdateTask = id -> onVoiceServerUpdate(this.gateway, id).map(());
/*     */     
/* 220 */     VoiceStateUpdateTask stateUpdateTask = id -> onVoiceStateUpdates(this.gateway, id).map(());
/*     */     
/* 222 */     VoiceChannelRetrieveTask channelRetrieveTask = () -> this.gateway.getMemberById(this.voiceChannel.getGuildId(), this.gateway.getSelfId()).flatMap(PartialMember::getVoiceState).flatMap(());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 262 */     Mono<VoiceConnection> newConnection = sendVoiceStateUpdate.then(Mono.zip(waitForVoiceStateUpdate, waitForVoiceServerUpdate)).flatMap(TupleUtils.function((voiceState, voiceServer) -> { String session = voiceState.getCurrent().getSessionId(); VoiceServerOptions voiceServerOptions = new VoiceServerOptions(voiceServer.getToken(), voiceServer.getEndpoint()); VoiceGatewayOptions voiceGatewayOptions = new VoiceGatewayOptions(guildId, this.gateway.getSelfId(), session, voiceServerOptions, this.gateway.getCoreResources().getJacksonResources(), this.gateway.getGatewayResources().getVoiceReactorResources(), this.gateway.getGatewayResources().getVoiceReconnectOptions(), this.provider, this.receiver, this.sendTaskFactory, this.receiveTaskFactory, disconnectTask, serverUpdateTask, stateUpdateTask, channelRetrieveTask, this.ipDiscoveryTimeout, this.LegacyipDiscoveryRetrySpec); return this.gateway.getVoiceConnectionFactory().create(voiceGatewayOptions).flatMap(()).doOnEach(()).contextWrite(()); })).timeout(this.timeout).doFinally(signal -> log.debug("Voice connection handshake to guild {} done after {}", new Object[] { Long.valueOf(guildId.asLong()), signal })).onErrorResume(TimeoutException.class, t -> this.gateway.getVoiceConnectionRegistry().getVoiceConnection(guildId).switchIfEmpty(this.voiceChannel.sendDisconnectVoiceState().then(Mono.error(t))));
/*     */ 
/*     */ 
/*     */     
/* 266 */     return this.gateway.getVoiceConnectionRegistry().getVoiceConnection(guildId)
/* 267 */       .flatMap(existing -> sendVoiceStateUpdate.then(waitForVoiceStateUpdate).thenReturn(existing))
/* 268 */       .switchIfEmpty(newConnection);
/*     */   }
/*     */   
/*     */   static Flux<VoiceStateUpdateEvent> onVoiceStateUpdates(GatewayDiscordClient gateway, Snowflake guildId) {
/* 272 */     return gateway.getEventDispatcher()
/* 273 */       .on(VoiceStateUpdateEvent.class)
/* 274 */       .filter(vsu -> {
/*     */           Snowflake vsuUser = vsu.getCurrent().getUserId();
/*     */           
/*     */           Snowflake vsuGuild = vsu.getCurrent().getGuildId();
/* 278 */           return (vsuUser.equals(gateway.getSelfId()) && vsuGuild.equals(guildId));
/*     */         });
/*     */   }
/*     */   
/*     */   static Mono<VoiceServerUpdateEvent> onVoiceServerUpdate(GatewayDiscordClient gateway, Snowflake guildId) {
/* 283 */     return gateway.getEventDispatcher()
/* 284 */       .on(VoiceServerUpdateEvent.class)
/* 285 */       .filter(vsu -> (vsu.getGuildId().equals(guildId) && vsu.getEndpoint() != null))
/* 286 */       .next();
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\legacy\LegacyVoiceChannelJoinSpec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */