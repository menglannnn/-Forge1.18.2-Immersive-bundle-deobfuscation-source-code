/*     */ package discord4j.core.spec.legacy;
/*     */ 
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.object.Invite;
/*     */ import discord4j.discordjson.json.ImmutableInviteCreateRequest;
/*     */ import discord4j.discordjson.json.InviteCreateRequest;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LegacyInviteCreateSpec
/*     */   implements LegacyAuditSpec<InviteCreateRequest>
/*     */ {
/*  33 */   private final ImmutableInviteCreateRequest.Builder requestBuilder = InviteCreateRequest.builder();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private String reason;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyInviteCreateSpec setMaxAge(int maxAge) {
/*  45 */     this.requestBuilder.maxAge(Integer.valueOf(maxAge));
/*  46 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyInviteCreateSpec setMaxUses(int maxUses) {
/*  57 */     this.requestBuilder.maxUses(Integer.valueOf(maxUses));
/*  58 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyInviteCreateSpec setTemporary(boolean temporary) {
/*  69 */     this.requestBuilder.temporary(Boolean.valueOf(temporary));
/*  70 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyInviteCreateSpec setUnique(boolean unique) {
/*  81 */     this.requestBuilder.unique(Boolean.valueOf(unique));
/*  82 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyInviteCreateSpec setTargetType(Invite.Type targetType) {
/*  92 */     this.requestBuilder.targetType(Integer.valueOf(targetType.getValue()));
/*  93 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyInviteCreateSpec setTargetUserId(Snowflake targetUserId) {
/* 104 */     this.requestBuilder.targetUserId(targetUserId.asString());
/* 105 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyInviteCreateSpec setTargetApplicationId(Snowflake targetApplicationId) {
/* 116 */     this.requestBuilder.targetApplicationId(targetApplicationId.asString());
/* 117 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public LegacyInviteCreateSpec setReason(@Nullable String reason) {
/* 122 */     this.reason = reason;
/* 123 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String getReason() {
/* 129 */     return this.reason;
/*     */   }
/*     */ 
/*     */   
/*     */   public InviteCreateRequest asRequest() {
/* 134 */     return (InviteCreateRequest)this.requestBuilder.build();
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\legacy\LegacyInviteCreateSpec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */