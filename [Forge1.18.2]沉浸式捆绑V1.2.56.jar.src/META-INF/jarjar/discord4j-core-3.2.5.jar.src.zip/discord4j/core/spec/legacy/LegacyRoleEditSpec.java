/*     */ package discord4j.core.spec.legacy;
/*     */ 
/*     */ import discord4j.discordjson.json.ImmutableRoleModifyRequest;
/*     */ import discord4j.discordjson.json.RoleModifyRequest;
/*     */ import discord4j.rest.util.Color;
/*     */ import discord4j.rest.util.PermissionSet;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LegacyRoleEditSpec
/*     */   implements LegacyAuditSpec<RoleModifyRequest>
/*     */ {
/*  34 */   private final ImmutableRoleModifyRequest.Builder requestBuilder = RoleModifyRequest.builder();
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private String reason;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyRoleEditSpec setName(String name) {
/*  45 */     this.requestBuilder.name(name);
/*  46 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyRoleEditSpec setPermissions(PermissionSet permissions) {
/*  56 */     this.requestBuilder.permissions(Long.valueOf(permissions.getRawValue()));
/*  57 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyRoleEditSpec setColor(Color color) {
/*  67 */     this.requestBuilder.color(Integer.valueOf(color.getRGB()));
/*  68 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyRoleEditSpec setHoist(boolean hoist) {
/*  78 */     this.requestBuilder.hoist(Boolean.valueOf(hoist));
/*  79 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyRoleEditSpec setMentionable(boolean mentionable) {
/*  89 */     this.requestBuilder.mentionable(Boolean.valueOf(mentionable));
/*  90 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public LegacyRoleEditSpec setReason(@Nullable String reason) {
/*  95 */     this.reason = reason;
/*  96 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String getReason() {
/* 102 */     return this.reason;
/*     */   }
/*     */ 
/*     */   
/*     */   public RoleModifyRequest asRequest() {
/* 107 */     return (RoleModifyRequest)this.requestBuilder.build();
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\legacy\LegacyRoleEditSpec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */