/*     */ package discord4j.core.spec.legacy;
/*     */ 
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.object.PermissionOverwrite;
/*     */ import discord4j.core.object.entity.channel.Channel;
/*     */ import discord4j.discordjson.json.ChannelCreateRequest;
/*     */ import discord4j.discordjson.json.ImmutableChannelCreateRequest;
/*     */ import discord4j.discordjson.json.OverwriteData;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.stream.Collectors;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LegacyNewsChannelCreateSpec
/*     */   implements LegacyAuditSpec<ChannelCreateRequest>
/*     */ {
/*  40 */   private final ImmutableChannelCreateRequest.Builder requestBuilder = ChannelCreateRequest.builder()
/*  41 */     .type(Integer.valueOf(Channel.Type.GUILD_NEWS.getValue()));
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private String reason;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyNewsChannelCreateSpec setName(String name) {
/*  52 */     this.requestBuilder.name(name);
/*  53 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyNewsChannelCreateSpec setTopic(String topic) {
/*  63 */     this.requestBuilder.topic(topic);
/*  64 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyNewsChannelCreateSpec setPosition(int position) {
/*  74 */     this.requestBuilder.position(Integer.valueOf(position));
/*  75 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyNewsChannelCreateSpec setPermissionOverwrites(Set<? extends PermissionOverwrite> permissionOverwrites) {
/*  87 */     List<OverwriteData> raw = (List<OverwriteData>)permissionOverwrites.stream().map(PermissionOverwrite::getData).collect(Collectors.toList());
/*     */     
/*  89 */     this.requestBuilder.permissionOverwrites(raw);
/*  90 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyNewsChannelCreateSpec setParentId(@Nullable Snowflake parentId) {
/* 100 */     this.requestBuilder.parentId((parentId == null) ? Possible.absent() : Possible.of(parentId.asString()));
/* 101 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyNewsChannelCreateSpec setNsfw(boolean nsfw) {
/* 111 */     this.requestBuilder.nsfw(Boolean.valueOf(nsfw));
/* 112 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public LegacyNewsChannelCreateSpec setReason(@Nullable String reason) {
/* 117 */     this.reason = reason;
/* 118 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String getReason() {
/* 124 */     return this.reason;
/*     */   }
/*     */ 
/*     */   
/*     */   public ChannelCreateRequest asRequest() {
/* 129 */     return (ChannelCreateRequest)this.requestBuilder.build();
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\legacy\LegacyNewsChannelCreateSpec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */