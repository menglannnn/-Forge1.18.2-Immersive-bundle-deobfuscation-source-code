/*    */ package discord4j.core.spec.legacy;
/*    */ 
/*    */ import discord4j.discordjson.json.UserModifyRequest;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import discord4j.rest.util.Image;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LegacyUserEditSpec
/*    */   implements LegacySpec<UserModifyRequest>
/*    */ {
/* 31 */   private Possible<String> username = Possible.absent();
/* 32 */   private Possible<String> avatar = Possible.absent();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public LegacyUserEditSpec setUsername(String username) {
/* 41 */     this.username = Possible.of(username);
/* 42 */     return this;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public LegacyUserEditSpec setAvatar(@Nullable Image avatar) {
/* 52 */     this.avatar = (avatar == null) ? Possible.absent() : Possible.of(avatar.getDataUri());
/* 53 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public UserModifyRequest asRequest() {
/* 58 */     return (UserModifyRequest)UserModifyRequest.builder()
/* 59 */       .username(this.username)
/* 60 */       .avatar(this.avatar)
/* 61 */       .build();
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\legacy\LegacyUserEditSpec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */