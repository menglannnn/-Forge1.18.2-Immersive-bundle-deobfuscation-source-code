/*     */ package discord4j.core.spec.legacy;
/*     */ 
/*     */ import discord4j.core.object.component.LayoutComponent;
/*     */ import discord4j.core.object.component.MessageComponent;
/*     */ import discord4j.core.object.entity.Message;
/*     */ import discord4j.discordjson.json.AllowedMentionsData;
/*     */ import discord4j.discordjson.json.ComponentData;
/*     */ import discord4j.discordjson.json.EmbedData;
/*     */ import discord4j.discordjson.json.MessageEditRequest;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import discord4j.rest.util.AllowedMentions;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Optional;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.stream.Collectors;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LegacyMessageEditSpec
/*     */   implements LegacySpec<MessageEditRequest>
/*     */ {
/*  40 */   private Possible<Optional<String>> content = Possible.absent();
/*  41 */   private Possible<Optional<List<EmbedData>>> embeds = Possible.absent();
/*  42 */   private Possible<Optional<AllowedMentionsData>> allowedMentions = Possible.absent();
/*  43 */   private Possible<Optional<Integer>> flags = Possible.absent();
/*  44 */   private Possible<Optional<List<ComponentData>>> components = Possible.absent();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyMessageEditSpec setContent(@Nullable String content) {
/*  53 */     this.content = Possible.of(Optional.ofNullable(content));
/*  54 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public LegacyMessageEditSpec setEmbed(@Nullable Consumer<? super LegacyEmbedCreateSpec> spec) {
/*  66 */     if (spec != null) {
/*  67 */       LegacyEmbedCreateSpec mutatedSpec = new LegacyEmbedCreateSpec();
/*  68 */       spec.accept(mutatedSpec);
/*  69 */       this.embeds = Possible.of(Optional.of(Collections.singletonList(mutatedSpec.asRequest())));
/*     */     } else {
/*  71 */       this.embeds = Possible.of(Optional.empty());
/*     */     } 
/*     */     
/*  74 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyMessageEditSpec addEmbed(Consumer<? super LegacyEmbedCreateSpec> spec) {
/*  89 */     LegacyEmbedCreateSpec mutatedSpec = new LegacyEmbedCreateSpec();
/*  90 */     spec.accept(mutatedSpec);
/*     */ 
/*     */     
/*  93 */     if (this.embeds.isAbsent() || !((Optional)this.embeds.get()).isPresent()) {
/*  94 */       this.embeds = Possible.of(Optional.of(new ArrayList(1)));
/*     */     }
/*     */     
/*  97 */     ((List<EmbedData>)((Optional<List<EmbedData>>)this.embeds.get()).get()).add(mutatedSpec.asRequest());
/*  98 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyMessageEditSpec removeEmbeds() {
/* 107 */     this.embeds = Possible.of(Optional.empty());
/* 108 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyMessageEditSpec setAllowedMentions(@Nullable AllowedMentions allowedMentions) {
/* 118 */     this.allowedMentions = Possible.of(Optional.<AllowedMentions>ofNullable(allowedMentions).map(AllowedMentions::toData));
/* 119 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyMessageEditSpec setFlags(@Nullable Message.Flag... flags) {
/* 129 */     if (flags != null) {
/* 130 */       this.flags = Possible.of(Optional.of(Integer.valueOf(Arrays.<Message.Flag>stream(flags)
/* 131 */               .mapToInt(Message.Flag::getFlag)
/* 132 */               .reduce(0, (left, right) -> left | right))));
/*     */     } else {
/* 134 */       this.flags = Possible.of(Optional.empty());
/*     */     } 
/* 136 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyMessageEditSpec setComponents(LayoutComponent... components) {
/* 146 */     return setComponents(Arrays.asList(components));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyMessageEditSpec setComponents(List<LayoutComponent> components) {
/* 156 */     this.components = Possible.of(Optional.of((List)components.stream().map(MessageComponent::getData).collect(Collectors.toList())));
/* 157 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public MessageEditRequest asRequest() {
/* 162 */     return (MessageEditRequest)MessageEditRequest.builder()
/* 163 */       .content(this.content)
/* 164 */       .embeds(this.embeds)
/* 165 */       .allowedMentions(this.allowedMentions)
/* 166 */       .flags(this.flags)
/* 167 */       .components(this.components)
/* 168 */       .build();
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\legacy\LegacyMessageEditSpec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */