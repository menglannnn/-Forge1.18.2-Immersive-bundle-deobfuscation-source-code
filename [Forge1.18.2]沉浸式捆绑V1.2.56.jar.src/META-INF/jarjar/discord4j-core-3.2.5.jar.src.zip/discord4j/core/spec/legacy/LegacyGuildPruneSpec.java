/*     */ package discord4j.core.spec.legacy;
/*     */ 
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.rest.util.Multimap;
/*     */ import java.util.Collection;
/*     */ import java.util.stream.Collectors;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LegacyGuildPruneSpec
/*     */   implements LegacyAuditSpec<Multimap<String, Object>>
/*     */ {
/*  35 */   private final Multimap<String, Object> map = new Multimap();
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private String reason;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyGuildPruneSpec setDays(int days) {
/*  46 */     this.map.set("days", Integer.valueOf(days));
/*  47 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyGuildPruneSpec addRole(Snowflake roleId) {
/*  58 */     this.map.add("include_roles", roleId.asString());
/*  59 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyGuildPruneSpec addRoles(Collection<Snowflake> roleIds) {
/*  70 */     this.map.addAll("include_roles", (Collection)roleIds.stream().map(Snowflake::asString).collect(Collectors.toList()));
/*  71 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyGuildPruneSpec setComputePruneCount(boolean enable) {
/*  83 */     this.map.set("compute_prune_count", Boolean.valueOf(enable));
/*  84 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public LegacyGuildPruneSpec setReason(String reason) {
/*  89 */     this.reason = reason;
/*  90 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getReason() {
/*  95 */     return this.reason;
/*     */   }
/*     */ 
/*     */   
/*     */   public Multimap<String, Object> asRequest() {
/* 100 */     return this.map;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\legacy\LegacyGuildPruneSpec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */