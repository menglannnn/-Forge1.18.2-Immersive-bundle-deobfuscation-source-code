/*    */ package discord4j.core.spec.legacy;
/*    */ 
/*    */ import discord4j.discordjson.json.WebhookModifyWithTokenRequest;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import discord4j.rest.util.Image;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LegacyWebhookEditWithTokenSpec
/*    */   implements LegacySpec<WebhookModifyWithTokenRequest>
/*    */ {
/* 27 */   private Possible<String> name = Possible.absent();
/* 28 */   private Possible<String> avatar = Possible.absent();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public LegacyWebhookEditWithTokenSpec setName(String name) {
/* 37 */     this.name = Possible.of(name);
/* 38 */     return this;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public LegacyWebhookEditWithTokenSpec setAvatar(@Nullable Image avatar) {
/* 48 */     this.avatar = (avatar == null) ? Possible.absent() : Possible.of(avatar.getDataUri());
/* 49 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public WebhookModifyWithTokenRequest asRequest() {
/* 54 */     return (WebhookModifyWithTokenRequest)WebhookModifyWithTokenRequest.builder()
/* 55 */       .name(this.name)
/* 56 */       .avatar(this.avatar)
/* 57 */       .build();
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\legacy\LegacyWebhookEditWithTokenSpec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */