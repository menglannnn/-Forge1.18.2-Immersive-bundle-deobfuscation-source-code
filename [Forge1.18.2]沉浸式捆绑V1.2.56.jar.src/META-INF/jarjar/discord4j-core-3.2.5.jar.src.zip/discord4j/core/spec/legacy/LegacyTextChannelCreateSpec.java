/*     */ package discord4j.core.spec.legacy;
/*     */ 
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.object.PermissionOverwrite;
/*     */ import discord4j.core.object.entity.channel.Channel;
/*     */ import discord4j.discordjson.json.ChannelCreateRequest;
/*     */ import discord4j.discordjson.json.ImmutableChannelCreateRequest;
/*     */ import discord4j.discordjson.json.OverwriteData;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.stream.Collectors;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LegacyTextChannelCreateSpec
/*     */   implements LegacyAuditSpec<ChannelCreateRequest>
/*     */ {
/*  41 */   private final ImmutableChannelCreateRequest.Builder requestBuilder = ChannelCreateRequest.builder()
/*  42 */     .type(Integer.valueOf(Channel.Type.GUILD_TEXT.getValue()));
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private String reason;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyTextChannelCreateSpec setName(String name) {
/*  53 */     this.requestBuilder.name(name);
/*  54 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyTextChannelCreateSpec setTopic(@Nullable String topic) {
/*  64 */     this.requestBuilder.topic((topic == null) ? Possible.absent() : Possible.of(topic));
/*  65 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyTextChannelCreateSpec setRateLimitPerUser(int rateLimitPerUser) {
/*  77 */     this.requestBuilder.rateLimitPerUser(Integer.valueOf(rateLimitPerUser));
/*  78 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyTextChannelCreateSpec setPosition(int position) {
/*  88 */     this.requestBuilder.position(Integer.valueOf(position));
/*  89 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyTextChannelCreateSpec setPermissionOverwrites(Set<? extends PermissionOverwrite> permissionOverwrites) {
/* 101 */     List<OverwriteData> raw = (List<OverwriteData>)permissionOverwrites.stream().map(PermissionOverwrite::getData).collect(Collectors.toList());
/*     */     
/* 103 */     this.requestBuilder.permissionOverwrites(raw);
/* 104 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyTextChannelCreateSpec setParentId(@Nullable Snowflake parentId) {
/* 114 */     this.requestBuilder.parentId((parentId == null) ? Possible.absent() : Possible.of(parentId.asString()));
/* 115 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyTextChannelCreateSpec setNsfw(boolean nsfw) {
/* 125 */     this.requestBuilder.nsfw(Boolean.valueOf(nsfw));
/* 126 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public LegacyTextChannelCreateSpec setReason(@Nullable String reason) {
/* 131 */     this.reason = reason;
/* 132 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String getReason() {
/* 138 */     return this.reason;
/*     */   }
/*     */ 
/*     */   
/*     */   public ChannelCreateRequest asRequest() {
/* 143 */     return (ChannelCreateRequest)this.requestBuilder.build();
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\legacy\LegacyTextChannelCreateSpec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */