/*     */ package discord4j.core.spec.legacy;
/*     */ 
/*     */ import discord4j.discordjson.json.EmbedAuthorData;
/*     */ import discord4j.discordjson.json.EmbedData;
/*     */ import discord4j.discordjson.json.EmbedFieldData;
/*     */ import discord4j.discordjson.json.EmbedFooterData;
/*     */ import discord4j.discordjson.json.EmbedImageData;
/*     */ import discord4j.discordjson.json.EmbedThumbnailData;
/*     */ import discord4j.discordjson.json.ImmutableEmbedData;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import discord4j.rest.util.Color;
/*     */ import java.time.Instant;
/*     */ import java.time.format.DateTimeFormatter;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.function.Supplier;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LegacyEmbedCreateSpec
/*     */   implements LegacySpec<EmbedData>
/*     */ {
/*  36 */   private final ImmutableEmbedData.Builder requestBuilder = EmbedData.builder();
/*  37 */   private final List<EmbedFieldData> fields = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyEmbedCreateSpec setTitle(String title) {
/*  46 */     this.requestBuilder.title(title);
/*  47 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyEmbedCreateSpec setDescription(String description) {
/*  57 */     this.requestBuilder.description(description);
/*  58 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyEmbedCreateSpec setUrl(String url) {
/*  68 */     this.requestBuilder.url(url);
/*  69 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyEmbedCreateSpec setTimestamp(Instant timestamp) {
/*  79 */     this.requestBuilder.timestamp(DateTimeFormatter.ISO_INSTANT.format(timestamp));
/*  80 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyEmbedCreateSpec setColor(Color color) {
/*  90 */     this.requestBuilder.color(Integer.valueOf(color.getRGB()));
/*  91 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyEmbedCreateSpec setFooter(String text, @Nullable String iconUrl) {
/* 102 */     this.requestBuilder.footer((EmbedFooterData)EmbedFooterData.builder()
/* 103 */         .text(text)
/* 104 */         .iconUrl((iconUrl == null) ? Possible.absent() : Possible.of(iconUrl))
/* 105 */         .build());
/* 106 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyEmbedCreateSpec setImage(String url) {
/* 116 */     this.requestBuilder.image((EmbedImageData)EmbedImageData.builder()
/* 117 */         .url(url)
/* 118 */         .build());
/* 119 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyEmbedCreateSpec setThumbnail(String url) {
/* 129 */     this.requestBuilder.thumbnail((EmbedThumbnailData)EmbedThumbnailData.builder()
/* 130 */         .url(url)
/* 131 */         .build());
/* 132 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyEmbedCreateSpec setAuthor(String name, @Nullable String url, @Nullable String iconUrl) {
/* 144 */     this.requestBuilder.author((EmbedAuthorData)EmbedAuthorData.builder()
/* 145 */         .name(name)
/* 146 */         .url((url == null) ? Possible.absent() : Possible.of(url))
/* 147 */         .iconUrl((iconUrl == null) ? Possible.absent() : Possible.of(iconUrl))
/* 148 */         .build());
/* 149 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyEmbedCreateSpec addField(String name, String value, boolean inline) {
/* 161 */     this.fields.add(EmbedFieldData.builder()
/* 162 */         .name(name)
/* 163 */         .value(value)
/* 164 */         .inline(Boolean.valueOf(inline))
/* 165 */         .build());
/* 166 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyEmbedCreateSpec from(EmbedData embedData) {
/* 177 */     this.requestBuilder.from(embedData);
/* 178 */     this.fields.clear();
/* 179 */     this.fields.addAll(embedData.fields()
/* 180 */         .toOptional()
/* 181 */         .orElseGet(ArrayList::new));
/* 182 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public EmbedData asRequest() {
/* 187 */     this.requestBuilder.fields(this.fields);
/* 188 */     return (EmbedData)this.requestBuilder.build();
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\legacy\LegacyEmbedCreateSpec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */