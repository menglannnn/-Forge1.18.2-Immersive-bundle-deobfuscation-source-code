package discord4j.core.spec.legacy;

import reactor.util.annotation.Nullable;

public interface LegacyAuditSpec<T> extends LegacySpec<T> {
  LegacyAuditSpec<T> setReason(@Nullable String paramString);
  
  @Nullable
  String getReason();
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\legacy\LegacyAuditSpec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */