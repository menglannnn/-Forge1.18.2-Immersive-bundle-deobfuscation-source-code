package discord4j.core.spec.legacy;

@FunctionalInterface
public interface LegacySpec<T> {
  T asRequest();
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\legacy\LegacySpec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */