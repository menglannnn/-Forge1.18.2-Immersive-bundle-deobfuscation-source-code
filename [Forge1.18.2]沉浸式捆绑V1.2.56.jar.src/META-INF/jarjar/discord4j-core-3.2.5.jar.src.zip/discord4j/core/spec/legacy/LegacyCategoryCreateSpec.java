/*    */ package discord4j.core.spec.legacy;
/*    */ 
/*    */ import discord4j.core.object.PermissionOverwrite;
/*    */ import discord4j.core.object.entity.channel.Channel;
/*    */ import discord4j.discordjson.json.ChannelCreateRequest;
/*    */ import discord4j.discordjson.json.ImmutableChannelCreateRequest;
/*    */ import discord4j.discordjson.json.OverwriteData;
/*    */ import java.util.List;
/*    */ import java.util.Set;
/*    */ import java.util.stream.Collectors;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LegacyCategoryCreateSpec
/*    */   implements LegacyAuditSpec<ChannelCreateRequest>
/*    */ {
/* 34 */   private final ImmutableChannelCreateRequest.Builder requestBuilder = ChannelCreateRequest.builder()
/* 35 */     .type(Integer.valueOf(Channel.Type.GUILD_CATEGORY.getValue()));
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   private String reason;
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public LegacyCategoryCreateSpec setName(String name) {
/* 46 */     this.requestBuilder.name(name);
/* 47 */     return this;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public LegacyCategoryCreateSpec setPosition(int position) {
/* 57 */     this.requestBuilder.position(Integer.valueOf(position));
/* 58 */     return this;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public LegacyCategoryCreateSpec setPermissionOverwrites(Set<? extends PermissionOverwrite> permissionOverwrites) {
/* 70 */     List<OverwriteData> raw = (List<OverwriteData>)permissionOverwrites.stream().map(PermissionOverwrite::getData).collect(Collectors.toList());
/*    */     
/* 72 */     this.requestBuilder.permissionOverwrites(raw);
/* 73 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public LegacyCategoryCreateSpec setReason(@Nullable String reason) {
/* 78 */     this.reason = reason;
/* 79 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public String getReason() {
/* 85 */     return this.reason;
/*    */   }
/*    */ 
/*    */   
/*    */   public ChannelCreateRequest asRequest() {
/* 90 */     return (ChannelCreateRequest)this.requestBuilder.build();
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\legacy\LegacyCategoryCreateSpec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */