/*    */ package discord4j.core.spec.legacy;
/*    */ 
/*    */ import discord4j.common.util.Snowflake;
/*    */ import discord4j.core.object.audit.ActionType;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class LegacyAuditLogQuerySpec
/*    */   implements LegacySpec<Map<String, Object>>
/*    */ {
/* 28 */   private final Map<String, Object> request = new HashMap<>(4);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public LegacyAuditLogQuerySpec setResponsibleUser(Snowflake userId) {
/* 37 */     this.request.put("user_id", Long.valueOf(userId.asLong()));
/* 38 */     return this;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public LegacyAuditLogQuerySpec setActionType(ActionType actionType) {
/* 48 */     this.request.put("action_type", Integer.valueOf(actionType.getValue()));
/* 49 */     return this;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public LegacyAuditLogQuerySpec setBefore(Snowflake beforeId) {
/* 59 */     this.request.put("before", beforeId.asString());
/* 60 */     return this;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public LegacyAuditLogQuerySpec setLimit(int limit) {
/* 70 */     this.request.put("limit", Integer.valueOf(limit));
/* 71 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public Map<String, Object> asRequest() {
/* 76 */     return this.request;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\legacy\LegacyAuditLogQuerySpec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */