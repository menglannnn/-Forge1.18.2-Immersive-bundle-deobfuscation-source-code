/*    */ package discord4j.core.spec.legacy;
/*    */ 
/*    */ import discord4j.common.annotations.Experimental;
/*    */ import discord4j.core.object.component.LayoutComponent;
/*    */ import discord4j.core.object.component.MessageComponent;
/*    */ import discord4j.core.object.entity.Message;
/*    */ import discord4j.discordjson.json.AllowedMentionsData;
/*    */ import discord4j.discordjson.json.EmbedData;
/*    */ import discord4j.discordjson.json.InteractionApplicationCommandCallbackData;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import discord4j.rest.util.AllowedMentions;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ import java.util.function.Consumer;
/*    */ import java.util.stream.Collectors;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Experimental
/*    */ public class LegacyInteractionApplicationCommandCallbackSpec
/*    */   implements LegacySpec<InteractionApplicationCommandCallbackData>
/*    */ {
/*    */   @Nullable
/*    */   private String content;
/*    */   private boolean tts;
/*    */   private List<EmbedData> embeds;
/*    */   private AllowedMentionsData allowedMentionsData;
/*    */   private int flags;
/*    */   private List<LayoutComponent> components;
/*    */   
/*    */   public LegacyInteractionApplicationCommandCallbackSpec setContent(String content) {
/* 48 */     this.content = content;
/* 49 */     return this;
/*    */   }
/*    */   
/*    */   public LegacyInteractionApplicationCommandCallbackSpec setTts(boolean tts) {
/* 53 */     this.tts = tts;
/* 54 */     return this;
/*    */   }
/*    */   
/*    */   public LegacyInteractionApplicationCommandCallbackSpec setEphemeral(boolean ephemeral) {
/* 58 */     this.flags = ephemeral ? Message.Flag.EPHEMERAL.getFlag() : 0;
/* 59 */     return this;
/*    */   }
/*    */   
/*    */   public LegacyInteractionApplicationCommandCallbackSpec addEmbed(Consumer<? super LegacyEmbedCreateSpec> spec) {
/* 63 */     if (this.embeds == null) {
/* 64 */       this.embeds = new ArrayList<>(1);
/*    */     }
/* 66 */     LegacyEmbedCreateSpec mutatedSpec = new LegacyEmbedCreateSpec();
/* 67 */     spec.accept(mutatedSpec);
/* 68 */     this.embeds.add(mutatedSpec.asRequest());
/* 69 */     return this;
/*    */   }
/*    */   
/*    */   public LegacyInteractionApplicationCommandCallbackSpec setAllowedMentions(@Nullable AllowedMentions allowedMentions) {
/* 73 */     this.allowedMentionsData = (allowedMentions != null) ? allowedMentions.toData() : null;
/* 74 */     return this;
/*    */   }
/*    */   
/*    */   public LegacyInteractionApplicationCommandCallbackSpec setComponents(LayoutComponent... components) {
/* 78 */     return setComponents(Arrays.asList(components));
/*    */   }
/*    */   
/*    */   public LegacyInteractionApplicationCommandCallbackSpec setComponents(List<LayoutComponent> components) {
/* 82 */     this.components = components;
/* 83 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public InteractionApplicationCommandCallbackData asRequest() {
/* 88 */     return (InteractionApplicationCommandCallbackData)InteractionApplicationCommandCallbackData.builder()
/* 89 */       .content((this.content == null) ? Possible.absent() : Possible.of(this.content))
/* 90 */       .tts(Boolean.valueOf(this.tts))
/* 91 */       .flags((this.flags == 0) ? Possible.absent() : Possible.of(Integer.valueOf(this.flags)))
/* 92 */       .embeds((this.embeds == null) ? Possible.absent() : Possible.of(this.embeds))
/* 93 */       .allowedMentions((this.allowedMentionsData == null) ? Possible.absent() : Possible.of(this.allowedMentionsData))
/* 94 */       .components((this.components == null) ? Possible.absent() : 
/* 95 */         Possible.of(this.components.stream().map(MessageComponent::getData).collect(Collectors.toList())))
/* 96 */       .build();
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\legacy\LegacyInteractionApplicationCommandCallbackSpec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */