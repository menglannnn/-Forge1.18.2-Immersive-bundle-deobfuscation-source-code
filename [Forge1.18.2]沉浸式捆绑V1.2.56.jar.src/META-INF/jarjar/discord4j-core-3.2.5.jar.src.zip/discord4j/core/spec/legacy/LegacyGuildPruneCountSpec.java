/*    */ package discord4j.core.spec.legacy;
/*    */ 
/*    */ import discord4j.common.util.Snowflake;
/*    */ import discord4j.rest.util.Multimap;
/*    */ import java.util.Collection;
/*    */ import java.util.stream.Collectors;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LegacyGuildPruneCountSpec
/*    */   implements LegacySpec<Multimap<String, Object>>
/*    */ {
/* 34 */   private final Multimap<String, Object> map = new Multimap();
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   private String reason;
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public LegacyGuildPruneCountSpec setDays(int days) {
/* 45 */     this.map.set("days", Integer.valueOf(days));
/* 46 */     return this;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public LegacyGuildPruneCountSpec addRole(Snowflake roleId) {
/* 57 */     this.map.add("include_roles", roleId.asString());
/* 58 */     return this;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public LegacyGuildPruneCountSpec addRoles(Collection<Snowflake> roleIds) {
/* 69 */     this.map.addAll("include_roles", (Collection)roleIds.stream().map(Snowflake::asString).collect(Collectors.toList()));
/* 70 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public Multimap<String, Object> asRequest() {
/* 75 */     return this.map;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\legacy\LegacyGuildPruneCountSpec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */