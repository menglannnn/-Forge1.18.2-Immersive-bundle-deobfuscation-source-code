/*     */ package discord4j.core.spec.legacy;
/*     */ 
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.object.PermissionOverwrite;
/*     */ import discord4j.discordjson.json.ChannelModifyRequest;
/*     */ import discord4j.discordjson.json.ImmutableChannelModifyRequest;
/*     */ import discord4j.discordjson.json.OverwriteData;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.List;
/*     */ import java.util.Optional;
/*     */ import java.util.Set;
/*     */ import java.util.stream.Collectors;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LegacyTextChannelEditSpec
/*     */   implements LegacyAuditSpec<ChannelModifyRequest>
/*     */ {
/*  41 */   private final ImmutableChannelModifyRequest.Builder requestBuilder = ChannelModifyRequest.builder();
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private String reason;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyTextChannelEditSpec setName(String name) {
/*  52 */     this.requestBuilder.name(name);
/*  53 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyTextChannelEditSpec setPosition(int position) {
/*  63 */     this.requestBuilder.position(Integer.valueOf(position));
/*  64 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyTextChannelEditSpec setTopic(String topic) {
/*  74 */     this.requestBuilder.topic(topic);
/*  75 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyTextChannelEditSpec setNsfw(boolean nsfw) {
/*  85 */     this.requestBuilder.nsfw(Boolean.valueOf(nsfw));
/*  86 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyTextChannelEditSpec setPermissionOverwrites(Set<? extends PermissionOverwrite> permissionOverwrites) {
/*  98 */     List<OverwriteData> raw = (List<OverwriteData>)permissionOverwrites.stream().map(PermissionOverwrite::getData).collect(Collectors.toList());
/*     */     
/* 100 */     this.requestBuilder.permissionOverwrites(raw);
/* 101 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyTextChannelEditSpec setParentId(@Nullable Snowflake parentId) {
/* 111 */     this.requestBuilder.parentId((parentId == null) ? Possible.of(Optional.empty()) : Possible.of(Optional.of(parentId.asString())));
/* 112 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyTextChannelEditSpec setRateLimitPerUser(int rateLimitPerUser) {
/* 124 */     this.requestBuilder.rateLimitPerUser(Integer.valueOf(rateLimitPerUser));
/* 125 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public LegacyTextChannelEditSpec setReason(@Nullable String reason) {
/* 130 */     this.reason = reason;
/* 131 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String getReason() {
/* 137 */     return this.reason;
/*     */   }
/*     */ 
/*     */   
/*     */   public ChannelModifyRequest asRequest() {
/* 142 */     return (ChannelModifyRequest)this.requestBuilder.build();
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\legacy\LegacyTextChannelEditSpec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */