/*    */ package discord4j.core.spec.legacy;
/*    */ 
/*    */ import discord4j.discordjson.json.TemplateCreateGuildRequest;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import discord4j.rest.util.Image;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LegacyGuildCreateFromTemplateSpec
/*    */   implements LegacySpec<TemplateCreateGuildRequest>
/*    */ {
/* 30 */   private String name = null;
/* 31 */   private Possible<String> icon = Possible.absent();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public LegacyGuildCreateFromTemplateSpec setName(String name) {
/* 40 */     this.name = name;
/* 41 */     return this;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public LegacyGuildCreateFromTemplateSpec setIcon(Image icon) {
/* 51 */     this.icon = Possible.of(icon.getDataUri());
/* 52 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public TemplateCreateGuildRequest asRequest() {
/* 57 */     return (TemplateCreateGuildRequest)TemplateCreateGuildRequest.builder()
/* 58 */       .name(this.name)
/* 59 */       .icon(this.icon)
/* 60 */       .build();
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\legacy\LegacyGuildCreateFromTemplateSpec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */