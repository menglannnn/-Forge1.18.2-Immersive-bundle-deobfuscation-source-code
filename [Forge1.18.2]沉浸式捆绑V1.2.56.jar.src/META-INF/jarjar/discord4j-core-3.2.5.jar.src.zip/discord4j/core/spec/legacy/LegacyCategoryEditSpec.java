/*    */ package discord4j.core.spec.legacy;
/*    */ 
/*    */ import discord4j.core.object.PermissionOverwrite;
/*    */ import discord4j.discordjson.json.ChannelModifyRequest;
/*    */ import discord4j.discordjson.json.ImmutableChannelModifyRequest;
/*    */ import discord4j.discordjson.json.OverwriteData;
/*    */ import java.util.List;
/*    */ import java.util.Set;
/*    */ import java.util.stream.Collectors;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LegacyCategoryEditSpec
/*    */   implements LegacyAuditSpec<ChannelModifyRequest>
/*    */ {
/* 33 */   private final ImmutableChannelModifyRequest.Builder requestBuilder = ChannelModifyRequest.builder();
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   private String reason;
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public LegacyCategoryEditSpec setName(String name) {
/* 44 */     this.requestBuilder.name(name);
/* 45 */     return this;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public LegacyCategoryEditSpec setPosition(int position) {
/* 55 */     this.requestBuilder.position(Integer.valueOf(position));
/* 56 */     return this;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public LegacyCategoryEditSpec setPermissionOverwrites(Set<? extends PermissionOverwrite> permissionOverwrites) {
/* 68 */     List<OverwriteData> raw = (List<OverwriteData>)permissionOverwrites.stream().map(PermissionOverwrite::getData).collect(Collectors.toList());
/*    */     
/* 70 */     this.requestBuilder.permissionOverwrites(raw);
/* 71 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public LegacyCategoryEditSpec setReason(@Nullable String reason) {
/* 76 */     this.reason = reason;
/* 77 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public String getReason() {
/* 83 */     return this.reason;
/*    */   }
/*    */ 
/*    */   
/*    */   public ChannelModifyRequest asRequest() {
/* 88 */     return (ChannelModifyRequest)this.requestBuilder.build();
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\legacy\LegacyCategoryEditSpec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */