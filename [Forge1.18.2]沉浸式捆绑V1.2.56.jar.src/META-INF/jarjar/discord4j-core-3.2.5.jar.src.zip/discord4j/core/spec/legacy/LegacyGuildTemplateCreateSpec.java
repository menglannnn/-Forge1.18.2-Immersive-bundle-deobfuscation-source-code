/*    */ package discord4j.core.spec.legacy;
/*    */ 
/*    */ import discord4j.discordjson.json.TemplateCreateRequest;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import java.util.Optional;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LegacyGuildTemplateCreateSpec
/*    */   implements LegacySpec<TemplateCreateRequest>
/*    */ {
/* 31 */   private String name = null;
/* 32 */   private Possible<Optional<String>> description = Possible.absent();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public LegacyGuildTemplateCreateSpec setName(String name) {
/* 41 */     this.name = name;
/* 42 */     return this;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public LegacyGuildTemplateCreateSpec setDescription(String description) {
/* 52 */     this.description = Possible.of(Optional.of(description));
/* 53 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public TemplateCreateRequest asRequest() {
/* 58 */     return (TemplateCreateRequest)TemplateCreateRequest.builder()
/* 59 */       .name(this.name)
/* 60 */       .description(this.description)
/* 61 */       .build();
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\legacy\LegacyGuildTemplateCreateSpec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */