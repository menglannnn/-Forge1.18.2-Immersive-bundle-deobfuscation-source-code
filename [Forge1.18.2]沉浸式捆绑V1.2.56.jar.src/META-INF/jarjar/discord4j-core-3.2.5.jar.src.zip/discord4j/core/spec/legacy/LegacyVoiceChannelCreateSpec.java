/*     */ package discord4j.core.spec.legacy;
/*     */ 
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.object.PermissionOverwrite;
/*     */ import discord4j.core.object.entity.channel.Channel;
/*     */ import discord4j.discordjson.json.ChannelCreateRequest;
/*     */ import discord4j.discordjson.json.ImmutableChannelCreateRequest;
/*     */ import discord4j.discordjson.json.OverwriteData;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.stream.Collectors;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LegacyVoiceChannelCreateSpec
/*     */   implements LegacyAuditSpec<ChannelCreateRequest>
/*     */ {
/*  38 */   private final ImmutableChannelCreateRequest.Builder requestBuilder = ChannelCreateRequest.builder()
/*  39 */     .type(Integer.valueOf(Channel.Type.GUILD_VOICE.getValue()));
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private String reason;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyVoiceChannelCreateSpec setName(String name) {
/*  50 */     this.requestBuilder.name(name);
/*  51 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyVoiceChannelCreateSpec setBitrate(int bitrate) {
/*  62 */     this.requestBuilder.bitrate(Integer.valueOf(bitrate));
/*  63 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyVoiceChannelCreateSpec setUserLimit(int userLimit) {
/*  76 */     this.requestBuilder.userLimit(Integer.valueOf(userLimit));
/*  77 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyVoiceChannelCreateSpec setPosition(int position) {
/*  87 */     this.requestBuilder.position(Integer.valueOf(position));
/*  88 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyVoiceChannelCreateSpec setPermissionOverwrites(Set<? extends PermissionOverwrite> permissionOverwrites) {
/* 100 */     List<OverwriteData> raw = (List<OverwriteData>)permissionOverwrites.stream().map(PermissionOverwrite::getData).collect(Collectors.toList());
/*     */     
/* 102 */     this.requestBuilder.permissionOverwrites(raw);
/* 103 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyVoiceChannelCreateSpec setParentId(@Nullable Snowflake parentId) {
/* 116 */     this.requestBuilder.parentId((parentId == null) ? Possible.absent() : Possible.of(parentId.asString()));
/* 117 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public LegacyVoiceChannelCreateSpec setReason(@Nullable String reason) {
/* 122 */     this.reason = reason;
/* 123 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String getReason() {
/* 129 */     return this.reason;
/*     */   }
/*     */ 
/*     */   
/*     */   public ChannelCreateRequest asRequest() {
/* 134 */     return (ChannelCreateRequest)this.requestBuilder.build();
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\legacy\LegacyVoiceChannelCreateSpec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */