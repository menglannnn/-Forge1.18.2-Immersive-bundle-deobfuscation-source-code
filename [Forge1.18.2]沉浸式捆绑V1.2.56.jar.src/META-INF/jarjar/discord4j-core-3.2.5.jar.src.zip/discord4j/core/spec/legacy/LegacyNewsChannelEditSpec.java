/*     */ package discord4j.core.spec.legacy;
/*     */ 
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.object.PermissionOverwrite;
/*     */ import discord4j.discordjson.json.ChannelModifyRequest;
/*     */ import discord4j.discordjson.json.ImmutableChannelModifyRequest;
/*     */ import discord4j.discordjson.json.OverwriteData;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.List;
/*     */ import java.util.Optional;
/*     */ import java.util.Set;
/*     */ import java.util.stream.Collectors;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LegacyNewsChannelEditSpec
/*     */   implements LegacyAuditSpec<ChannelModifyRequest>
/*     */ {
/*  40 */   private final ImmutableChannelModifyRequest.Builder requestBuilder = ChannelModifyRequest.builder();
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private String reason;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyNewsChannelEditSpec setName(String name) {
/*  51 */     this.requestBuilder.name(name);
/*  52 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyNewsChannelEditSpec setPosition(int position) {
/*  62 */     this.requestBuilder.position(Integer.valueOf(position));
/*  63 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyNewsChannelEditSpec setTopic(String topic) {
/*  73 */     this.requestBuilder.topic(topic);
/*  74 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyNewsChannelEditSpec setNsfw(boolean nsfw) {
/*  84 */     this.requestBuilder.nsfw(Boolean.valueOf(nsfw));
/*  85 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyNewsChannelEditSpec setPermissionOverwrites(Set<? extends PermissionOverwrite> permissionOverwrites) {
/*  97 */     List<OverwriteData> raw = (List<OverwriteData>)permissionOverwrites.stream().map(PermissionOverwrite::getData).collect(Collectors.toList());
/*     */     
/*  99 */     this.requestBuilder.permissionOverwrites(raw);
/* 100 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyNewsChannelEditSpec setParentId(@Nullable Snowflake parentId) {
/* 110 */     this.requestBuilder.parentId(Possible.of(Optional.<Snowflake>ofNullable(parentId).map(Snowflake::asString)));
/* 111 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public LegacyNewsChannelEditSpec setReason(@Nullable String reason) {
/* 116 */     this.reason = reason;
/* 117 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String getReason() {
/* 123 */     return this.reason;
/*     */   }
/*     */ 
/*     */   
/*     */   public ChannelModifyRequest asRequest() {
/* 128 */     return (ChannelModifyRequest)this.requestBuilder.build();
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\legacy\LegacyNewsChannelEditSpec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */