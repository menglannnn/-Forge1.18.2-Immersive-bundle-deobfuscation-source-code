/*    */ package discord4j.core.spec.legacy;
/*    */ 
/*    */ import discord4j.discordjson.json.WebhookCreateRequest;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import discord4j.rest.util.Image;
/*    */ import java.util.Optional;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LegacyWebhookCreateSpec
/*    */   implements LegacyAuditSpec<WebhookCreateRequest>
/*    */ {
/*    */   private String name;
/*    */   @Nullable
/*    */   private String avatar;
/*    */   @Nullable
/*    */   private String reason;
/*    */   
/*    */   public LegacyWebhookCreateSpec setName(String name) {
/* 47 */     this.name = name;
/* 48 */     return this;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public LegacyWebhookCreateSpec setAvatar(@Nullable Image avatar) {
/* 58 */     this.avatar = (avatar == null) ? null : avatar.getDataUri();
/* 59 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public LegacyWebhookCreateSpec setReason(@Nullable String reason) {
/* 64 */     this.reason = reason;
/* 65 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public String getReason() {
/* 71 */     return this.reason;
/*    */   }
/*    */ 
/*    */   
/*    */   public WebhookCreateRequest asRequest() {
/* 76 */     return (WebhookCreateRequest)WebhookCreateRequest.builder()
/* 77 */       .name(this.name)
/* 78 */       .avatar(Possible.of(Optional.ofNullable(this.avatar)))
/* 79 */       .build();
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\legacy\LegacyWebhookCreateSpec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */