/*    */ package discord4j.core.spec.legacy;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class LegacyBanQuerySpec
/*    */   implements LegacyAuditSpec<Map<String, Object>>
/*    */ {
/* 27 */   private final Map<String, Object> request = new HashMap<>(2);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public LegacyBanQuerySpec setDeleteMessageDays(int days) {
/* 36 */     this.request.put("delete_message_days", Integer.valueOf(days));
/* 37 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public LegacyBanQuerySpec setReason(@Nullable String reason) {
/* 42 */     this.request.put("reason", reason);
/* 43 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public String getReason() {
/* 49 */     return (String)this.request.get("reason");
/*    */   }
/*    */ 
/*    */   
/*    */   public Map<String, Object> asRequest() {
/* 54 */     return this.request;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\legacy\LegacyBanQuerySpec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */