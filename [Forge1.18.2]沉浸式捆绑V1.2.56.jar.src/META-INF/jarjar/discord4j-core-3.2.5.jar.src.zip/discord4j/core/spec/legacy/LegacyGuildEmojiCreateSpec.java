/*    */ package discord4j.core.spec.legacy;
/*    */ 
/*    */ import discord4j.common.util.Snowflake;
/*    */ import discord4j.discordjson.json.GuildEmojiCreateRequest;
/*    */ import discord4j.rest.util.Image;
/*    */ import java.util.HashSet;
/*    */ import java.util.Set;
/*    */ import java.util.stream.Collectors;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LegacyGuildEmojiCreateSpec
/*    */   implements LegacyAuditSpec<GuildEmojiCreateRequest>
/*    */ {
/*    */   private String name;
/*    */   private String image;
/* 38 */   private final Set<Snowflake> roles = new HashSet<>();
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   private String reason;
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public LegacyGuildEmojiCreateSpec setName(String name) {
/* 49 */     this.name = name;
/* 50 */     return this;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public LegacyGuildEmojiCreateSpec setImage(Image image) {
/* 60 */     this.image = image.getDataUri();
/* 61 */     return this;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public LegacyGuildEmojiCreateSpec addRole(Snowflake roleId) {
/* 71 */     this.roles.add(roleId);
/* 72 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public LegacyGuildEmojiCreateSpec setReason(@Nullable String reason) {
/* 77 */     this.reason = reason;
/* 78 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public String getReason() {
/* 84 */     return this.reason;
/*    */   }
/*    */ 
/*    */   
/*    */   public GuildEmojiCreateRequest asRequest() {
/* 89 */     return (GuildEmojiCreateRequest)GuildEmojiCreateRequest.builder()
/* 90 */       .name(this.name)
/* 91 */       .image(this.image)
/* 92 */       .roles((Iterable)this.roles.stream().map(Snowflake::asString).collect(Collectors.toList()))
/* 93 */       .build();
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\legacy\LegacyGuildEmojiCreateSpec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */