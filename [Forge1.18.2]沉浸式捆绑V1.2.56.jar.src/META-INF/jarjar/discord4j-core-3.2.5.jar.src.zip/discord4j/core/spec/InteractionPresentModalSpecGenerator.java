/*    */ package discord4j.core.spec;
/*    */ 
/*    */ import discord4j.core.object.component.LayoutComponent;
/*    */ import discord4j.core.object.component.MessageComponent;
/*    */ import discord4j.discordjson.json.InteractionApplicationCommandCallbackData;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import java.util.List;
/*    */ import java.util.stream.Collectors;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Immutable(singleton = true)
/*    */ interface InteractionPresentModalSpecGenerator
/*    */   extends Spec<InteractionApplicationCommandCallbackData>
/*    */ {
/*    */   default InteractionApplicationCommandCallbackData asRequest() {
/* 44 */     return (InteractionApplicationCommandCallbackData)InteractionApplicationCommandCallbackData.builder()
/* 45 */       .title(title())
/* 46 */       .customId(customId())
/* 47 */       .components(InternalSpecUtils.mapPossible(components(), components -> (List)components.stream().map(MessageComponent::getData).collect(Collectors.toList())))
/*    */ 
/*    */       
/* 50 */       .build();
/*    */   }
/*    */   
/*    */   Possible<String> title();
/*    */   
/*    */   Possible<String> customId();
/*    */   
/*    */   Possible<List<LayoutComponent>> components();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\InteractionPresentModalSpecGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */