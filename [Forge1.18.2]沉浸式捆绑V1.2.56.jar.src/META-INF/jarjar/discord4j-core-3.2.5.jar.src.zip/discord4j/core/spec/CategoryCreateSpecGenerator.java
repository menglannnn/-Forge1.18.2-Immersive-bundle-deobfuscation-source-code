/*    */ package discord4j.core.spec;
/*    */ 
/*    */ import discord4j.core.object.PermissionOverwrite;
/*    */ import discord4j.core.object.entity.channel.Channel;
/*    */ import discord4j.discordjson.json.ChannelCreateRequest;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import java.util.List;
/*    */ import java.util.stream.Collectors;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Immutable
/*    */ interface CategoryCreateSpecGenerator
/*    */   extends AuditSpec<ChannelCreateRequest>
/*    */ {
/*    */   default ChannelCreateRequest asRequest() {
/* 46 */     return (ChannelCreateRequest)ChannelCreateRequest.builder()
/* 47 */       .type(Integer.valueOf(Channel.Type.GUILD_CATEGORY.getValue()))
/* 48 */       .name(name())
/* 49 */       .position(position())
/* 50 */       .permissionOverwrites(InternalSpecUtils.mapPossible(permissionOverwrites(), po -> (List)po.stream().map(PermissionOverwrite::getData).collect(Collectors.toList())))
/*    */ 
/*    */       
/* 53 */       .build();
/*    */   }
/*    */   
/*    */   String name();
/*    */   
/*    */   Possible<Integer> position();
/*    */   
/*    */   Possible<List<PermissionOverwrite>> permissionOverwrites();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\CategoryCreateSpecGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */