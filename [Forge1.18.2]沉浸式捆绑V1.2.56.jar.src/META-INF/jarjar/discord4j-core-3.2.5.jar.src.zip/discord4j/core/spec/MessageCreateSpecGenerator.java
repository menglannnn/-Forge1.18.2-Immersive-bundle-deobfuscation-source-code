/*    */ package discord4j.core.spec;
/*    */ 
/*    */ import discord4j.common.util.Snowflake;
/*    */ import discord4j.core.object.component.LayoutComponent;
/*    */ import discord4j.core.object.component.MessageComponent;
/*    */ import discord4j.discordjson.json.ImmutableMessageCreateRequest;
/*    */ import discord4j.discordjson.json.MessageCreateRequest;
/*    */ import discord4j.discordjson.json.MessageReferenceData;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import discord4j.rest.util.AllowedMentions;
/*    */ import discord4j.rest.util.MultipartRequest;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import java.util.stream.Collectors;
/*    */ import java.util.stream.Stream;
/*    */ import org.immutables.value.Value.Default;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Immutable(singleton = true)
/*    */ interface MessageCreateSpecGenerator
/*    */   extends Spec<MultipartRequest<MessageCreateRequest>>
/*    */ {
/*    */   @Default
/*    */   default List<MessageCreateFields.File> files() {
/* 52 */     return Collections.emptyList();
/*    */   }
/*    */   
/*    */   @Default
/*    */   default List<MessageCreateFields.FileSpoiler> fileSpoilers() {
/* 57 */     return Collections.emptyList();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   default MultipartRequest<MessageCreateRequest> asRequest() {
/* 83 */     ImmutableMessageCreateRequest immutableMessageCreateRequest = MessageCreateRequest.builder().content(content()).nonce(nonce()).tts(tts()).embeds(InternalSpecUtils.mapPossible(embeds(), embeds -> (List)embeds.stream().map(EmbedCreateSpecGenerator::asRequest).collect(Collectors.toList()))).allowedMentions(InternalSpecUtils.mapPossible(allowedMentions(), AllowedMentions::toData)).messageReference(InternalSpecUtils.mapPossible(messageReference(), ref -> MessageReferenceData.builder().messageId(ref.asString()).build())).components(InternalSpecUtils.mapPossible(components(), components -> (List)components.stream().map(MessageComponent::getData).collect(Collectors.toList()))).build();
/* 84 */     return MultipartRequest.ofRequestAndFiles(immutableMessageCreateRequest, (List)Stream.concat(files().stream(), fileSpoilers().stream())
/* 85 */         .map(MessageCreateFields.File::asRequest)
/* 86 */         .collect(Collectors.toList()));
/*    */   }
/*    */   
/*    */   Possible<String> content();
/*    */   
/*    */   Possible<String> nonce();
/*    */   
/*    */   Possible<Boolean> tts();
/*    */   
/*    */   Possible<List<EmbedCreateSpec>> embeds();
/*    */   
/*    */   Possible<AllowedMentions> allowedMentions();
/*    */   
/*    */   Possible<Snowflake> messageReference();
/*    */   
/*    */   Possible<List<LayoutComponent>> components();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\MessageCreateSpecGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */