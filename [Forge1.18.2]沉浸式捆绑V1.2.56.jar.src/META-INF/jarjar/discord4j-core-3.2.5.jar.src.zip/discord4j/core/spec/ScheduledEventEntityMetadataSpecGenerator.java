/*    */ package discord4j.core.spec;
/*    */ 
/*    */ import discord4j.discordjson.json.GuildScheduledEventEntityMetadataData;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ 
/*    */ 
/*    */ @Immutable
/*    */ public interface ScheduledEventEntityMetadataSpecGenerator
/*    */   extends Spec<GuildScheduledEventEntityMetadataData>
/*    */ {
/*    */   default GuildScheduledEventEntityMetadataData asRequest() {
/* 14 */     return (GuildScheduledEventEntityMetadataData)GuildScheduledEventEntityMetadataData.builder()
/* 15 */       .location(location())
/* 16 */       .build();
/*    */   }
/*    */   
/*    */   Possible<String> location();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\ScheduledEventEntityMetadataSpecGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */