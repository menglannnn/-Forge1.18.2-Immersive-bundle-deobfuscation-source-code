/*     */ package discord4j.core.spec;
/*     */ 
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.object.entity.Member;
/*     */ import discord4j.core.object.entity.PartialMember;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.time.Instant;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.stream.StreamSupport;
/*     */ import org.immutables.value.Generated;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "GuildMemberEditMonoGenerator", generator = "Immutables")
/*     */ public final class GuildMemberEditMono
/*     */   extends GuildMemberEditMonoGenerator
/*     */ {
/*     */   @Nullable
/*     */   private final String reason;
/*     */   private final Snowflake newVoiceChannel_value;
/*     */   private final boolean newVoiceChannel_absent;
/*     */   private final Boolean mute_value;
/*     */   private final boolean mute_absent;
/*     */   private final Boolean deafen_value;
/*     */   private final boolean deafen_absent;
/*     */   private final String nickname_value;
/*     */   private final boolean nickname_absent;
/*     */   private final List<Snowflake> roles_value;
/*     */   private final boolean roles_absent;
/*     */   private final Instant communicationDisabledUntil_value;
/*     */   private final boolean communicationDisabledUntil_absent;
/*     */   private final PartialMember member;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   private volatile transient InitShim initShim;
/*     */   
/*     */   private GuildMemberEditMono(PartialMember member) {
/* 102 */     this.initShim = new InitShim(); this.member = Objects.<PartialMember>requireNonNull(member, "member"); this.reason = null; Possible<Optional<Snowflake>> newVoiceChannel$impl = Possible.absent(); Possible<Boolean> mute$impl = Possible.absent(); Possible<Boolean> deafen$impl = Possible.absent(); Possible<Optional<String>> nickname$impl = Possible.absent(); Possible<List<Snowflake>> roles$impl = Possible.absent(); Possible<Optional<Instant>> communicationDisabledUntil$impl = Possible.absent(); this.newVoiceChannel_value = Possible.flatOpt(newVoiceChannel$impl).orElse(null); this.newVoiceChannel_absent = newVoiceChannel$impl.isAbsent(); this.mute_value = mute$impl.toOptional().orElse(null); this.mute_absent = mute$impl.isAbsent(); this.deafen_value = deafen$impl.toOptional().orElse(null); this.deafen_absent = deafen$impl.isAbsent(); this.nickname_value = Possible.flatOpt(nickname$impl).orElse(null); this.nickname_absent = nickname$impl.isAbsent(); this.roles_value = roles$impl.toOptional().orElse(null); this.roles_absent = roles$impl.isAbsent(); this.communicationDisabledUntil_value = Possible.flatOpt(communicationDisabledUntil$impl).orElse(null); this.communicationDisabledUntil_absent = communicationDisabledUntil$impl.isAbsent(); this.initShim = null; } private GuildMemberEditMono(@Nullable String reason, Possible<Optional<Snowflake>> newVoiceChannel, Possible<Boolean> mute, Possible<Boolean> deafen, Possible<Optional<String>> nickname, Possible<List<Snowflake>> roles, Possible<Optional<Instant>> communicationDisabledUntil, PartialMember member) { this.initShim = new InitShim(); this.reason = reason; Possible<Optional<Snowflake>> newVoiceChannel$impl = newVoiceChannel; Possible<Boolean> mute$impl = mute; Possible<Boolean> deafen$impl = deafen; Possible<Optional<String>> nickname$impl = nickname; Possible<List<Snowflake>> roles$impl = roles; Possible<Optional<Instant>> communicationDisabledUntil$impl = communicationDisabledUntil; this.member = member; this.newVoiceChannel_value = Possible.flatOpt(newVoiceChannel$impl).orElse(null); this.newVoiceChannel_absent = newVoiceChannel$impl.isAbsent(); this.mute_value = mute$impl.toOptional().orElse(null); this.mute_absent = mute$impl.isAbsent(); this.deafen_value = deafen$impl.toOptional().orElse(null); this.deafen_absent = deafen$impl.isAbsent(); this.nickname_value = Possible.flatOpt(nickname$impl).orElse(null);
/*     */     this.nickname_absent = nickname$impl.isAbsent();
/*     */     this.roles_value = roles$impl.toOptional().orElse(null);
/*     */     this.roles_absent = roles$impl.isAbsent();
/*     */     this.communicationDisabledUntil_value = Possible.flatOpt(communicationDisabledUntil$impl).orElse(null);
/*     */     this.communicationDisabledUntil_absent = communicationDisabledUntil$impl.isAbsent();
/* 108 */     this.initShim = null; } @Generated(from = "GuildMemberEditMonoGenerator", generator = "Immutables") private final class InitShim { private InitShim() {} private String formatInitCycleMessage() { List<String> attributes = new ArrayList<>();
/* 109 */       return "Cannot build GuildMemberEditMono, attribute initializers form cycle " + attributes; }
/*     */      }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String reason() {
/* 119 */     return this.reason;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Optional<Snowflake>> newVoiceChannel() {
/* 127 */     return this.newVoiceChannel_absent ? Possible.absent() : 
/* 128 */       Possible.of(Optional.ofNullable(this.newVoiceChannel_value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Boolean> mute() {
/* 136 */     return this.mute_absent ? Possible.absent() : Possible.of(this.mute_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Boolean> deafen() {
/* 144 */     return this.deafen_absent ? Possible.absent() : Possible.of(this.deafen_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Optional<String>> nickname() {
/* 152 */     return this.nickname_absent ? Possible.absent() : 
/* 153 */       Possible.of(Optional.ofNullable(this.nickname_value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<List<Snowflake>> roles() {
/* 161 */     return this.roles_absent ? Possible.absent() : 
/* 162 */       Possible.of(this.roles_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Optional<Instant>> communicationDisabledUntil() {
/* 170 */     return this.communicationDisabledUntil_absent ? Possible.absent() : 
/* 171 */       Possible.of(Optional.ofNullable(this.communicationDisabledUntil_value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PartialMember member() {
/* 179 */     return this.member;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final GuildMemberEditMono withReason(@Nullable String value) {
/* 189 */     if (Objects.equals(this.reason, value)) return this; 
/* 190 */     return new GuildMemberEditMono(value, 
/*     */         
/* 192 */         newVoiceChannel(), 
/* 193 */         mute(), 
/* 194 */         deafen(), 
/* 195 */         nickname(), 
/* 196 */         roles(), 
/* 197 */         communicationDisabledUntil(), this.member);
/*     */   }
/*     */ 
/*     */   
/*     */   public GuildMemberEditMono withNewVoiceChannel(Possible<Optional<Snowflake>> value) {
/* 202 */     Possible<Optional<Snowflake>> newValue = Objects.<Possible<Optional<Snowflake>>>requireNonNull(value);
/* 203 */     return new GuildMemberEditMono(this.reason, newValue, 
/*     */ 
/*     */         
/* 206 */         mute(), 
/* 207 */         deafen(), 
/* 208 */         nickname(), 
/* 209 */         roles(), 
/* 210 */         communicationDisabledUntil(), this.member);
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public GuildMemberEditMono withNewVoiceChannel(@Nullable Snowflake value) {
/* 216 */     Possible<Optional<Snowflake>> newValue = Possible.of(Optional.ofNullable(value));
/* 217 */     return new GuildMemberEditMono(this.reason, newValue, 
/*     */ 
/*     */         
/* 220 */         mute(), 
/* 221 */         deafen(), 
/* 222 */         nickname(), 
/* 223 */         roles(), 
/* 224 */         communicationDisabledUntil(), this.member);
/*     */   }
/*     */ 
/*     */   
/*     */   public GuildMemberEditMono withNewVoiceChannelOrNull(@Nullable Snowflake value) {
/* 229 */     Possible<Optional<Snowflake>> newValue = Possible.of(Optional.ofNullable(value));
/* 230 */     return new GuildMemberEditMono(this.reason, newValue, 
/*     */ 
/*     */         
/* 233 */         mute(), 
/* 234 */         deafen(), 
/* 235 */         nickname(), 
/* 236 */         roles(), 
/* 237 */         communicationDisabledUntil(), this.member);
/*     */   }
/*     */ 
/*     */   
/*     */   public GuildMemberEditMono withMute(Possible<Boolean> value) {
/* 242 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/* 243 */     return new GuildMemberEditMono(this.reason, 
/*     */         
/* 245 */         newVoiceChannel(), newValue, 
/*     */         
/* 247 */         deafen(), 
/* 248 */         nickname(), 
/* 249 */         roles(), 
/* 250 */         communicationDisabledUntil(), this.member);
/*     */   }
/*     */ 
/*     */   
/*     */   public GuildMemberEditMono withMute(Boolean value) {
/* 255 */     Possible<Boolean> newValue = Possible.of(value);
/* 256 */     return new GuildMemberEditMono(this.reason, 
/*     */         
/* 258 */         newVoiceChannel(), newValue, 
/*     */         
/* 260 */         deafen(), 
/* 261 */         nickname(), 
/* 262 */         roles(), 
/* 263 */         communicationDisabledUntil(), this.member);
/*     */   }
/*     */ 
/*     */   
/*     */   public GuildMemberEditMono withDeafen(Possible<Boolean> value) {
/* 268 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/* 269 */     return new GuildMemberEditMono(this.reason, 
/*     */         
/* 271 */         newVoiceChannel(), 
/* 272 */         mute(), newValue, 
/*     */         
/* 274 */         nickname(), 
/* 275 */         roles(), 
/* 276 */         communicationDisabledUntil(), this.member);
/*     */   }
/*     */ 
/*     */   
/*     */   public GuildMemberEditMono withDeafen(Boolean value) {
/* 281 */     Possible<Boolean> newValue = Possible.of(value);
/* 282 */     return new GuildMemberEditMono(this.reason, 
/*     */         
/* 284 */         newVoiceChannel(), 
/* 285 */         mute(), newValue, 
/*     */         
/* 287 */         nickname(), 
/* 288 */         roles(), 
/* 289 */         communicationDisabledUntil(), this.member);
/*     */   }
/*     */ 
/*     */   
/*     */   public GuildMemberEditMono withNickname(Possible<Optional<String>> value) {
/* 294 */     Possible<Optional<String>> newValue = Objects.<Possible<Optional<String>>>requireNonNull(value);
/* 295 */     return new GuildMemberEditMono(this.reason, 
/*     */         
/* 297 */         newVoiceChannel(), 
/* 298 */         mute(), 
/* 299 */         deafen(), newValue, 
/*     */         
/* 301 */         roles(), 
/* 302 */         communicationDisabledUntil(), this.member);
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public GuildMemberEditMono withNickname(@Nullable String value) {
/* 308 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/* 309 */     return new GuildMemberEditMono(this.reason, 
/*     */         
/* 311 */         newVoiceChannel(), 
/* 312 */         mute(), 
/* 313 */         deafen(), newValue, 
/*     */         
/* 315 */         roles(), 
/* 316 */         communicationDisabledUntil(), this.member);
/*     */   }
/*     */ 
/*     */   
/*     */   public GuildMemberEditMono withNicknameOrNull(@Nullable String value) {
/* 321 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/* 322 */     return new GuildMemberEditMono(this.reason, 
/*     */         
/* 324 */         newVoiceChannel(), 
/* 325 */         mute(), 
/* 326 */         deafen(), newValue, 
/*     */         
/* 328 */         roles(), 
/* 329 */         communicationDisabledUntil(), this.member);
/*     */   }
/*     */ 
/*     */   
/*     */   public GuildMemberEditMono withRoles(Possible<List<Snowflake>> possible) {
/* 334 */     Possible<List<Snowflake>> newValue = Objects.<Possible<List<Snowflake>>>requireNonNull(possible);
/* 335 */     return new GuildMemberEditMono(this.reason, 
/*     */         
/* 337 */         newVoiceChannel(), 
/* 338 */         mute(), 
/* 339 */         deafen(), 
/* 340 */         nickname(), newValue, 
/*     */         
/* 342 */         communicationDisabledUntil(), this.member);
/*     */   }
/*     */ 
/*     */   
/*     */   public GuildMemberEditMono withRoles(Iterable<Snowflake> elements) {
/* 347 */     Possible<List<Snowflake>> newValue = Possible.of(
/* 348 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/* 349 */     return new GuildMemberEditMono(this.reason, 
/*     */         
/* 351 */         newVoiceChannel(), 
/* 352 */         mute(), 
/* 353 */         deafen(), 
/* 354 */         nickname(), newValue, 
/*     */         
/* 356 */         communicationDisabledUntil(), this.member);
/*     */   }
/*     */ 
/*     */   
/*     */   @SafeVarargs
/*     */   public final GuildMemberEditMono withRoles(Snowflake... elements) {
/* 362 */     Possible<List<Snowflake>> newValue = Possible.of(Arrays.asList(elements));
/* 363 */     return new GuildMemberEditMono(this.reason, 
/*     */         
/* 365 */         newVoiceChannel(), 
/* 366 */         mute(), 
/* 367 */         deafen(), 
/* 368 */         nickname(), newValue, 
/*     */         
/* 370 */         communicationDisabledUntil(), this.member);
/*     */   }
/*     */ 
/*     */   
/*     */   public GuildMemberEditMono withCommunicationDisabledUntil(Possible<Optional<Instant>> value) {
/* 375 */     Possible<Optional<Instant>> newValue = Objects.<Possible<Optional<Instant>>>requireNonNull(value);
/* 376 */     return new GuildMemberEditMono(this.reason, 
/*     */         
/* 378 */         newVoiceChannel(), 
/* 379 */         mute(), 
/* 380 */         deafen(), 
/* 381 */         nickname(), 
/* 382 */         roles(), newValue, this.member);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public GuildMemberEditMono withCommunicationDisabledUntil(@Nullable Instant value) {
/* 389 */     Possible<Optional<Instant>> newValue = Possible.of(Optional.ofNullable(value));
/* 390 */     return new GuildMemberEditMono(this.reason, 
/*     */         
/* 392 */         newVoiceChannel(), 
/* 393 */         mute(), 
/* 394 */         deafen(), 
/* 395 */         nickname(), 
/* 396 */         roles(), newValue, this.member);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public GuildMemberEditMono withCommunicationDisabledUntilOrNull(@Nullable Instant value) {
/* 402 */     Possible<Optional<Instant>> newValue = Possible.of(Optional.ofNullable(value));
/* 403 */     return new GuildMemberEditMono(this.reason, 
/*     */         
/* 405 */         newVoiceChannel(), 
/* 406 */         mute(), 
/* 407 */         deafen(), 
/* 408 */         nickname(), 
/* 409 */         roles(), newValue, this.member);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final GuildMemberEditMono withMember(PartialMember value) {
/* 421 */     if (this.member == value) return this; 
/* 422 */     PartialMember newValue = Objects.<PartialMember>requireNonNull(value, "member");
/* 423 */     return new GuildMemberEditMono(this.reason, 
/*     */         
/* 425 */         newVoiceChannel(), 
/* 426 */         mute(), 
/* 427 */         deafen(), 
/* 428 */         nickname(), 
/* 429 */         roles(), 
/* 430 */         communicationDisabledUntil(), newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 440 */     if (this == another) return true; 
/* 441 */     return (another instanceof GuildMemberEditMono && 
/* 442 */       equalTo(0, (GuildMemberEditMono)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, GuildMemberEditMono another) {
/* 446 */     return (Objects.equals(this.reason, another.reason) && 
/* 447 */       newVoiceChannel().equals(another.newVoiceChannel()) && 
/* 448 */       mute().equals(another.mute()) && 
/* 449 */       deafen().equals(another.deafen()) && 
/* 450 */       nickname().equals(another.nickname()) && 
/* 451 */       Objects.equals(this.roles_value, another.roles_value) && 
/* 452 */       communicationDisabledUntil().equals(another.communicationDisabledUntil()) && this.member
/* 453 */       .equals(another.member));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 462 */     int h = 5381;
/* 463 */     h += (h << 5) + Objects.hashCode(this.reason);
/* 464 */     h += (h << 5) + newVoiceChannel().hashCode();
/* 465 */     h += (h << 5) + mute().hashCode();
/* 466 */     h += (h << 5) + deafen().hashCode();
/* 467 */     h += (h << 5) + nickname().hashCode();
/* 468 */     h += (h << 5) + Objects.hashCode(this.roles_value);
/* 469 */     h += (h << 5) + communicationDisabledUntil().hashCode();
/* 470 */     h += (h << 5) + this.member.hashCode();
/* 471 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 480 */     return "GuildMemberEditMono{reason=" + this.reason + ", newVoiceChannel=" + 
/*     */       
/* 482 */       newVoiceChannel().toString() + ", mute=" + 
/* 483 */       mute().toString() + ", deafen=" + 
/* 484 */       deafen().toString() + ", nickname=" + 
/* 485 */       nickname().toString() + ", roles=" + 
/* 486 */       Objects.toString(this.roles_value) + ", communicationDisabledUntil=" + 
/* 487 */       communicationDisabledUntil().toString() + ", member=" + this.member + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static GuildMemberEditMono of(PartialMember member) {
/* 498 */     return new GuildMemberEditMono(member);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static GuildMemberEditMono copyOf(GuildMemberEditMonoGenerator instance) {
/* 509 */     if (instance instanceof GuildMemberEditMono) {
/* 510 */       return (GuildMemberEditMono)instance;
/*     */     }
/* 512 */     return of(instance.member())
/* 513 */       .withReason(instance.reason())
/* 514 */       .withNewVoiceChannel(instance.newVoiceChannel())
/* 515 */       .withMute(instance.mute())
/* 516 */       .withDeafen(instance.deafen())
/* 517 */       .withNickname(instance.nickname())
/* 518 */       .withRoles(instance.roles())
/* 519 */       .withCommunicationDisabledUntil(instance.communicationDisabledUntil());
/*     */   }
/*     */   
/*     */   public boolean isNewVoiceChannelPresent() {
/* 523 */     return !this.newVoiceChannel_absent;
/*     */   }
/*     */   
/*     */   public Snowflake newVoiceChannelOrElse(Snowflake defaultValue) {
/* 527 */     return !this.newVoiceChannel_absent ? this.newVoiceChannel_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isMutePresent() {
/* 531 */     return !this.mute_absent;
/*     */   }
/*     */   
/*     */   public Boolean muteOrElse(Boolean defaultValue) {
/* 535 */     return !this.mute_absent ? this.mute_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isDeafenPresent() {
/* 539 */     return !this.deafen_absent;
/*     */   }
/*     */   
/*     */   public Boolean deafenOrElse(Boolean defaultValue) {
/* 543 */     return !this.deafen_absent ? this.deafen_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isNicknamePresent() {
/* 547 */     return !this.nickname_absent;
/*     */   }
/*     */   
/*     */   public String nicknameOrElse(String defaultValue) {
/* 551 */     return !this.nickname_absent ? this.nickname_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isRolesPresent() {
/* 555 */     return !this.roles_absent;
/*     */   }
/*     */   
/*     */   public List<Snowflake> rolesOrElse(List<Snowflake> defaultValue) {
/* 559 */     return !this.roles_absent ? this.roles_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isCommunicationDisabledUntilPresent() {
/* 563 */     return !this.communicationDisabledUntil_absent;
/*     */   }
/*     */   
/*     */   public Instant communicationDisabledUntilOrElse(Instant defaultValue) {
/* 567 */     return !this.communicationDisabledUntil_absent ? this.communicationDisabledUntil_value : defaultValue;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\GuildMemberEditMono.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */