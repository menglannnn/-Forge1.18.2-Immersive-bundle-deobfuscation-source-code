/*     */ package discord4j.core.spec;
/*     */ 
/*     */ import discord4j.core.object.GuildTemplate;
/*     */ import discord4j.core.object.entity.Guild;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import org.immutables.value.Generated;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "GuildTemplateCreateMonoGenerator", generator = "Immutables")
/*     */ public final class GuildTemplateCreateMono
/*     */   extends GuildTemplateCreateMonoGenerator
/*     */ {
/*     */   private final String name;
/*     */   private final String description_value;
/*     */   private final boolean description_absent;
/*     */   private final Guild guild;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   private volatile transient InitShim initShim;
/*     */   
/*     */   private GuildTemplateCreateMono(String name, Guild guild) {
/*  52 */     this.initShim = new InitShim(); this.name = Objects.<String>requireNonNull(name, "name"); this.guild = Objects.<Guild>requireNonNull(guild, "guild"); Possible<Optional<String>> description$impl = Possible.absent(); this.description_value = Possible.flatOpt(description$impl).orElse(null); this.description_absent = description$impl.isAbsent(); this.initShim = null; } private GuildTemplateCreateMono(String name, Possible<Optional<String>> description, Guild guild) { this.initShim = new InitShim();
/*     */     this.name = name;
/*     */     Possible<Optional<String>> description$impl = description;
/*     */     this.guild = guild;
/*     */     this.description_value = Possible.flatOpt(description$impl).orElse(null);
/*     */     this.description_absent = description$impl.isAbsent();
/*  58 */     this.initShim = null; } @Generated(from = "GuildTemplateCreateMonoGenerator", generator = "Immutables") private final class InitShim { private InitShim() {} private String formatInitCycleMessage() { List<String> attributes = new ArrayList<>();
/*  59 */       return "Cannot build GuildTemplateCreateMono, attribute initializers form cycle " + attributes; }
/*     */      }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String name() {
/*  68 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Optional<String>> description() {
/*  76 */     return this.description_absent ? Possible.absent() : 
/*  77 */       Possible.of(Optional.ofNullable(this.description_value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Guild guild() {
/*  85 */     return this.guild;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final GuildTemplateCreateMono withName(String value) {
/*  95 */     String newValue = Objects.<String>requireNonNull(value, "name");
/*  96 */     if (this.name.equals(newValue)) return this; 
/*  97 */     return new GuildTemplateCreateMono(newValue, description(), this.guild);
/*     */   }
/*     */   
/*     */   public GuildTemplateCreateMono withDescription(Possible<Optional<String>> value) {
/* 101 */     Possible<Optional<String>> newValue = Objects.<Possible<Optional<String>>>requireNonNull(value);
/* 102 */     return new GuildTemplateCreateMono(this.name, newValue, this.guild);
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public GuildTemplateCreateMono withDescription(@Nullable String value) {
/* 107 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/* 108 */     return new GuildTemplateCreateMono(this.name, newValue, this.guild);
/*     */   }
/*     */   
/*     */   public GuildTemplateCreateMono withDescriptionOrNull(@Nullable String value) {
/* 112 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/* 113 */     return new GuildTemplateCreateMono(this.name, newValue, this.guild);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final GuildTemplateCreateMono withGuild(Guild value) {
/* 123 */     if (this.guild == value) return this; 
/* 124 */     Guild newValue = Objects.<Guild>requireNonNull(value, "guild");
/* 125 */     return new GuildTemplateCreateMono(this.name, description(), newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 134 */     if (this == another) return true; 
/* 135 */     return (another instanceof GuildTemplateCreateMono && 
/* 136 */       equalTo(0, (GuildTemplateCreateMono)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, GuildTemplateCreateMono another) {
/* 140 */     return (this.name.equals(another.name) && 
/* 141 */       description().equals(another.description()) && this.guild
/* 142 */       .equals(another.guild));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 151 */     int h = 5381;
/* 152 */     h += (h << 5) + this.name.hashCode();
/* 153 */     h += (h << 5) + description().hashCode();
/* 154 */     h += (h << 5) + this.guild.hashCode();
/* 155 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 164 */     return "GuildTemplateCreateMono{name=" + this.name + ", description=" + 
/*     */       
/* 166 */       description().toString() + ", guild=" + this.guild + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static GuildTemplateCreateMono of(String name, Guild guild) {
/* 178 */     return new GuildTemplateCreateMono(name, guild);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static GuildTemplateCreateMono copyOf(GuildTemplateCreateMonoGenerator instance) {
/* 189 */     if (instance instanceof GuildTemplateCreateMono) {
/* 190 */       return (GuildTemplateCreateMono)instance;
/*     */     }
/* 192 */     return of(instance.name(), instance.guild())
/* 193 */       .withDescription(instance.description());
/*     */   }
/*     */   
/*     */   public boolean isDescriptionPresent() {
/* 197 */     return !this.description_absent;
/*     */   }
/*     */   
/*     */   public String descriptionOrElse(String defaultValue) {
/* 201 */     return !this.description_absent ? this.description_value : defaultValue;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\GuildTemplateCreateMono.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */