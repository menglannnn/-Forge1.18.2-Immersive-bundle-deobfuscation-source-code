/*     */ package discord4j.core.spec;
/*     */ 
/*     */ import discord4j.core.object.PermissionOverwrite;
/*     */ import discord4j.core.object.entity.channel.Category;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.stream.StreamSupport;
/*     */ import org.immutables.value.Generated;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "CategoryEditMonoGenerator", generator = "Immutables")
/*     */ public final class CategoryEditMono
/*     */   extends CategoryEditMonoGenerator
/*     */ {
/*     */   @Nullable
/*     */   private final String reason;
/*     */   private final String name_value;
/*     */   private final boolean name_absent;
/*     */   private final Integer position_value;
/*     */   private final boolean position_absent;
/*     */   private final List<PermissionOverwrite> permissionOverwrites_value;
/*     */   private final boolean permissionOverwrites_absent;
/*     */   private final Category category;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   private volatile transient InitShim initShim;
/*     */   
/*     */   private CategoryEditMono(Category category) {
/*  73 */     this.initShim = new InitShim(); this.category = Objects.<Category>requireNonNull(category, "category"); this.reason = null; Possible<String> name$impl = Possible.absent(); Possible<Integer> position$impl = Possible.absent(); Possible<List<PermissionOverwrite>> permissionOverwrites$impl = Possible.absent(); this.name_value = name$impl.toOptional().orElse(null); this.name_absent = name$impl.isAbsent(); this.position_value = position$impl.toOptional().orElse(null); this.position_absent = position$impl.isAbsent(); this.permissionOverwrites_value = permissionOverwrites$impl.toOptional().orElse(null); this.permissionOverwrites_absent = permissionOverwrites$impl.isAbsent(); this.initShim = null; } private CategoryEditMono(@Nullable String reason, Possible<String> name, Possible<Integer> position, Possible<List<PermissionOverwrite>> permissionOverwrites, Category category) { this.initShim = new InitShim(); this.reason = reason; Possible<String> name$impl = name; Possible<Integer> position$impl = position; Possible<List<PermissionOverwrite>> permissionOverwrites$impl = permissionOverwrites; this.category = category; this.name_value = name$impl.toOptional().orElse(null);
/*     */     this.name_absent = name$impl.isAbsent();
/*     */     this.position_value = position$impl.toOptional().orElse(null);
/*     */     this.position_absent = position$impl.isAbsent();
/*     */     this.permissionOverwrites_value = permissionOverwrites$impl.toOptional().orElse(null);
/*     */     this.permissionOverwrites_absent = permissionOverwrites$impl.isAbsent();
/*  79 */     this.initShim = null; } @Generated(from = "CategoryEditMonoGenerator", generator = "Immutables") private final class InitShim { private InitShim() {} private String formatInitCycleMessage() { List<String> attributes = new ArrayList<>();
/*  80 */       return "Cannot build CategoryEditMono, attribute initializers form cycle " + attributes; }
/*     */      }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String reason() {
/*  90 */     return this.reason;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<String> name() {
/*  98 */     return this.name_absent ? Possible.absent() : Possible.of(this.name_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Integer> position() {
/* 106 */     return this.position_absent ? Possible.absent() : Possible.of(this.position_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<List<PermissionOverwrite>> permissionOverwrites() {
/* 114 */     return this.permissionOverwrites_absent ? Possible.absent() : 
/* 115 */       Possible.of(this.permissionOverwrites_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Category category() {
/* 123 */     return this.category;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final CategoryEditMono withReason(@Nullable String value) {
/* 133 */     if (Objects.equals(this.reason, value)) return this; 
/* 134 */     return new CategoryEditMono(value, name(), position(), permissionOverwrites(), this.category);
/*     */   }
/*     */   
/*     */   public CategoryEditMono withName(Possible<String> value) {
/* 138 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/* 139 */     return new CategoryEditMono(this.reason, newValue, position(), permissionOverwrites(), this.category);
/*     */   }
/*     */   
/*     */   public CategoryEditMono withName(String value) {
/* 143 */     Possible<String> newValue = Possible.of(value);
/* 144 */     return new CategoryEditMono(this.reason, newValue, position(), permissionOverwrites(), this.category);
/*     */   }
/*     */   
/*     */   public CategoryEditMono withPosition(Possible<Integer> value) {
/* 148 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/* 149 */     return new CategoryEditMono(this.reason, name(), newValue, permissionOverwrites(), this.category);
/*     */   }
/*     */   
/*     */   public CategoryEditMono withPosition(Integer value) {
/* 153 */     Possible<Integer> newValue = Possible.of(value);
/* 154 */     return new CategoryEditMono(this.reason, name(), newValue, permissionOverwrites(), this.category);
/*     */   }
/*     */   
/*     */   public CategoryEditMono withPermissionOverwrites(Possible<List<PermissionOverwrite>> possible) {
/* 158 */     Possible<List<PermissionOverwrite>> newValue = Objects.<Possible<List<PermissionOverwrite>>>requireNonNull(possible);
/* 159 */     return new CategoryEditMono(this.reason, name(), position(), newValue, this.category);
/*     */   }
/*     */   
/*     */   public CategoryEditMono withPermissionOverwrites(Iterable<PermissionOverwrite> elements) {
/* 163 */     Possible<List<PermissionOverwrite>> newValue = Possible.of(
/* 164 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/* 165 */     return new CategoryEditMono(this.reason, name(), position(), newValue, this.category);
/*     */   }
/*     */   
/*     */   @SafeVarargs
/*     */   public final CategoryEditMono withPermissionOverwrites(PermissionOverwrite... elements) {
/* 170 */     Possible<List<PermissionOverwrite>> newValue = Possible.of(Arrays.asList(elements));
/* 171 */     return new CategoryEditMono(this.reason, name(), position(), newValue, this.category);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final CategoryEditMono withCategory(Category value) {
/* 181 */     if (this.category == value) return this; 
/* 182 */     Category newValue = Objects.<Category>requireNonNull(value, "category");
/* 183 */     return new CategoryEditMono(this.reason, name(), position(), permissionOverwrites(), newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 192 */     if (this == another) return true; 
/* 193 */     return (another instanceof CategoryEditMono && 
/* 194 */       equalTo(0, (CategoryEditMono)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, CategoryEditMono another) {
/* 198 */     return (Objects.equals(this.reason, another.reason) && 
/* 199 */       name().equals(another.name()) && 
/* 200 */       position().equals(another.position()) && 
/* 201 */       Objects.equals(this.permissionOverwrites_value, another.permissionOverwrites_value) && this.category
/* 202 */       .equals(another.category));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 211 */     int h = 5381;
/* 212 */     h += (h << 5) + Objects.hashCode(this.reason);
/* 213 */     h += (h << 5) + name().hashCode();
/* 214 */     h += (h << 5) + position().hashCode();
/* 215 */     h += (h << 5) + Objects.hashCode(this.permissionOverwrites_value);
/* 216 */     h += (h << 5) + this.category.hashCode();
/* 217 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 226 */     return "CategoryEditMono{reason=" + this.reason + ", name=" + 
/*     */       
/* 228 */       name().toString() + ", position=" + 
/* 229 */       position().toString() + ", permissionOverwrites=" + 
/* 230 */       Objects.toString(this.permissionOverwrites_value) + ", category=" + this.category + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CategoryEditMono of(Category category) {
/* 241 */     return new CategoryEditMono(category);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static CategoryEditMono copyOf(CategoryEditMonoGenerator instance) {
/* 252 */     if (instance instanceof CategoryEditMono) {
/* 253 */       return (CategoryEditMono)instance;
/*     */     }
/* 255 */     return of(instance.category())
/* 256 */       .withReason(instance.reason())
/* 257 */       .withName(instance.name())
/* 258 */       .withPosition(instance.position())
/* 259 */       .withPermissionOverwrites(instance.permissionOverwrites());
/*     */   }
/*     */   
/*     */   public boolean isNamePresent() {
/* 263 */     return !this.name_absent;
/*     */   }
/*     */   
/*     */   public String nameOrElse(String defaultValue) {
/* 267 */     return !this.name_absent ? this.name_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isPositionPresent() {
/* 271 */     return !this.position_absent;
/*     */   }
/*     */   
/*     */   public Integer positionOrElse(Integer defaultValue) {
/* 275 */     return !this.position_absent ? this.position_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isPermissionOverwritesPresent() {
/* 279 */     return !this.permissionOverwrites_absent;
/*     */   }
/*     */   
/*     */   public List<PermissionOverwrite> permissionOverwritesOrElse(List<PermissionOverwrite> defaultValue) {
/* 283 */     return !this.permissionOverwrites_absent ? this.permissionOverwrites_value : defaultValue;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\CategoryEditMono.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */