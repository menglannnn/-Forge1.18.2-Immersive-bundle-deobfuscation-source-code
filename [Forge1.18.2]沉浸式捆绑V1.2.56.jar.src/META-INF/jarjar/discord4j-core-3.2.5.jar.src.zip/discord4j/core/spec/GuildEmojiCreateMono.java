/*     */ package discord4j.core.spec;
/*     */ 
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.object.entity.Guild;
/*     */ import discord4j.core.object.entity.GuildEmoji;
/*     */ import discord4j.rest.util.Image;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "GuildEmojiCreateMonoGenerator", generator = "Immutables")
/*     */ public final class GuildEmojiCreateMono
/*     */   extends GuildEmojiCreateMonoGenerator
/*     */ {
/*     */   @Nullable
/*     */   private final String reason;
/*     */   private final String name;
/*     */   private final Image image;
/*     */   private final List<Snowflake> roles;
/*     */   private final Guild guild;
/*     */   
/*     */   private GuildEmojiCreateMono(String name, Image image, Guild guild) {
/*  33 */     this.name = Objects.<String>requireNonNull(name, "name");
/*  34 */     this.image = Objects.<Image>requireNonNull(image, "image");
/*  35 */     this.guild = Objects.<Guild>requireNonNull(guild, "guild");
/*  36 */     this.reason = null;
/*  37 */     this.roles = createUnmodifiableList(false, createSafeList(super.roles(), true, false));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private GuildEmojiCreateMono(@Nullable String reason, String name, Image image, List<Snowflake> roles, Guild guild) {
/*  46 */     this.reason = reason;
/*  47 */     this.name = name;
/*  48 */     this.image = image;
/*  49 */     this.roles = roles;
/*  50 */     this.guild = guild;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String reason() {
/*  59 */     return this.reason;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String name() {
/*  67 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Image image() {
/*  75 */     return this.image;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Snowflake> roles() {
/*  83 */     return this.roles;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Guild guild() {
/*  91 */     return this.guild;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final GuildEmojiCreateMono withReason(@Nullable String value) {
/* 101 */     if (Objects.equals(this.reason, value)) return this; 
/* 102 */     return new GuildEmojiCreateMono(value, this.name, this.image, this.roles, this.guild);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final GuildEmojiCreateMono withName(String value) {
/* 112 */     String newValue = Objects.<String>requireNonNull(value, "name");
/* 113 */     if (this.name.equals(newValue)) return this; 
/* 114 */     return new GuildEmojiCreateMono(this.reason, newValue, this.image, this.roles, this.guild);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final GuildEmojiCreateMono withImage(Image value) {
/* 124 */     if (this.image == value) return this; 
/* 125 */     Image newValue = Objects.<Image>requireNonNull(value, "image");
/* 126 */     return new GuildEmojiCreateMono(this.reason, this.name, newValue, this.roles, this.guild);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final GuildEmojiCreateMono withRoles(Snowflake... elements) {
/* 135 */     List<Snowflake> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/* 136 */     return new GuildEmojiCreateMono(this.reason, this.name, this.image, newValue, this.guild);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final GuildEmojiCreateMono withRoles(Iterable<? extends Snowflake> elements) {
/* 146 */     if (this.roles == elements) return this; 
/* 147 */     List<Snowflake> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/* 148 */     return new GuildEmojiCreateMono(this.reason, this.name, this.image, newValue, this.guild);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final GuildEmojiCreateMono withGuild(Guild value) {
/* 158 */     if (this.guild == value) return this; 
/* 159 */     Guild newValue = Objects.<Guild>requireNonNull(value, "guild");
/* 160 */     return new GuildEmojiCreateMono(this.reason, this.name, this.image, this.roles, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 169 */     if (this == another) return true; 
/* 170 */     return (another instanceof GuildEmojiCreateMono && 
/* 171 */       equalTo(0, (GuildEmojiCreateMono)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, GuildEmojiCreateMono another) {
/* 175 */     return (Objects.equals(this.reason, another.reason) && this.name
/* 176 */       .equals(another.name) && this.image
/* 177 */       .equals(another.image) && this.roles
/* 178 */       .equals(another.roles) && this.guild
/* 179 */       .equals(another.guild));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 188 */     int h = 5381;
/* 189 */     h += (h << 5) + Objects.hashCode(this.reason);
/* 190 */     h += (h << 5) + this.name.hashCode();
/* 191 */     h += (h << 5) + this.image.hashCode();
/* 192 */     h += (h << 5) + this.roles.hashCode();
/* 193 */     h += (h << 5) + this.guild.hashCode();
/* 194 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 203 */     return "GuildEmojiCreateMono{reason=" + this.reason + ", name=" + this.name + ", image=" + this.image + ", roles=" + this.roles + ", guild=" + this.guild + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static GuildEmojiCreateMono of(String name, Image image, Guild guild) {
/* 220 */     return new GuildEmojiCreateMono(name, image, guild);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static GuildEmojiCreateMono copyOf(GuildEmojiCreateMonoGenerator instance) {
/* 231 */     if (instance instanceof GuildEmojiCreateMono) {
/* 232 */       return (GuildEmojiCreateMono)instance;
/*     */     }
/* 234 */     return of(instance.name(), instance.image(), instance.guild())
/* 235 */       .withReason(instance.reason())
/* 236 */       .withRoles(instance.roles());
/*     */   }
/*     */   
/*     */   private static <T> List<T> createSafeList(Iterable<? extends T> iterable, boolean checkNulls, boolean skipNulls) {
/*     */     ArrayList<T> list;
/* 241 */     if (iterable instanceof Collection) {
/* 242 */       int size = ((Collection)iterable).size();
/* 243 */       if (size == 0) return Collections.emptyList(); 
/* 244 */       list = new ArrayList<>();
/*     */     } else {
/* 246 */       list = new ArrayList<>();
/*     */     } 
/* 248 */     for (T element : iterable) {
/* 249 */       if (skipNulls && element == null)
/* 250 */         continue;  if (checkNulls) Objects.requireNonNull(element, "element"); 
/* 251 */       list.add(element);
/*     */     } 
/* 253 */     return list;
/*     */   }
/*     */   
/*     */   private static <T> List<T> createUnmodifiableList(boolean clone, List<T> list) {
/* 257 */     switch (list.size()) { case 0:
/* 258 */         return Collections.emptyList();
/* 259 */       case 1: return Collections.singletonList(list.get(0)); }
/*     */     
/* 261 */     if (clone) {
/* 262 */       return Collections.unmodifiableList(new ArrayList<>(list));
/*     */     }
/* 264 */     if (list instanceof ArrayList) {
/* 265 */       ((ArrayList)list).trimToSize();
/*     */     }
/* 267 */     return Collections.unmodifiableList(list);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\GuildEmojiCreateMono.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */