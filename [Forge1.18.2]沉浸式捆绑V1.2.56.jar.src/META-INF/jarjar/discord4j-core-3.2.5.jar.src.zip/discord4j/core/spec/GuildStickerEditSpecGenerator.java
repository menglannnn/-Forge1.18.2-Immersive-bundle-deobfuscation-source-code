/*    */ package discord4j.core.spec;
/*    */ 
/*    */ import discord4j.discordjson.json.GuildStickerModifyRequest;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Immutable(singleton = true)
/*    */ interface GuildStickerEditSpecGenerator
/*    */   extends AuditSpec<GuildStickerModifyRequest>
/*    */ {
/*    */   default GuildStickerModifyRequest asRequest() {
/* 38 */     return (GuildStickerModifyRequest)GuildStickerModifyRequest.builder()
/* 39 */       .name(name())
/* 40 */       .description(description())
/* 41 */       .tags(tags())
/* 42 */       .build();
/*    */   }
/*    */   
/*    */   Possible<String> tags();
/*    */   
/*    */   Possible<String> description();
/*    */   
/*    */   Possible<String> name();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\GuildStickerEditSpecGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */