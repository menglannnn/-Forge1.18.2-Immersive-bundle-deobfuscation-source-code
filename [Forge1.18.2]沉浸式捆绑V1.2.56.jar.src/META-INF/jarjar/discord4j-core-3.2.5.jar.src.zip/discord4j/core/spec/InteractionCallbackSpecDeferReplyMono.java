/*     */ package discord4j.core.spec;
/*     */ 
/*     */ import discord4j.core.event.domain.interaction.DeferrableInteractionEvent;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ import reactor.core.CoreSubscriber;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "InteractionCallbackSpecDeferReplyMonoGenerator", generator = "Immutables")
/*     */ public final class InteractionCallbackSpecDeferReplyMono
/*     */   extends InteractionCallbackSpecDeferReplyMonoGenerator
/*     */ {
/*     */   private final Boolean ephemeral_value;
/*     */   private final boolean ephemeral_absent;
/*     */   private final DeferrableInteractionEvent event;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   private volatile transient InitShim initShim;
/*     */   
/*     */   private InteractionCallbackSpecDeferReplyMono(DeferrableInteractionEvent event) {
/*  47 */     this.initShim = new InitShim(); this.event = Objects.<DeferrableInteractionEvent>requireNonNull(event, "event"); Possible<Boolean> ephemeral$impl = Possible.absent(); this.ephemeral_value = ephemeral$impl.toOptional().orElse(null); this.ephemeral_absent = ephemeral$impl.isAbsent(); this.initShim = null; } private InteractionCallbackSpecDeferReplyMono(Possible<Boolean> ephemeral, DeferrableInteractionEvent event) { this.initShim = new InitShim();
/*     */     Possible<Boolean> ephemeral$impl = ephemeral;
/*     */     this.event = event;
/*     */     this.ephemeral_value = ephemeral$impl.toOptional().orElse(null);
/*     */     this.ephemeral_absent = ephemeral$impl.isAbsent();
/*     */     this.initShim = null; } @Generated(from = "InteractionCallbackSpecDeferReplyMonoGenerator", generator = "Immutables")
/*  53 */   private final class InitShim { private InitShim() {} private String formatInitCycleMessage() { List<String> attributes = new ArrayList<>();
/*  54 */       return "Cannot build InteractionCallbackSpecDeferReplyMono, attribute initializers form cycle " + attributes; }
/*     */      }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Boolean> ephemeral() {
/*  63 */     return this.ephemeral_absent ? Possible.absent() : Possible.of(this.ephemeral_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DeferrableInteractionEvent event() {
/*  71 */     return this.event;
/*     */   }
/*     */   
/*     */   public InteractionCallbackSpecDeferReplyMono withEphemeral(Possible<Boolean> value) {
/*  75 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/*  76 */     return new InteractionCallbackSpecDeferReplyMono(newValue, this.event);
/*     */   }
/*     */   
/*     */   public InteractionCallbackSpecDeferReplyMono withEphemeral(Boolean value) {
/*  80 */     Possible<Boolean> newValue = Possible.of(value);
/*  81 */     return new InteractionCallbackSpecDeferReplyMono(newValue, this.event);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final InteractionCallbackSpecDeferReplyMono withEvent(DeferrableInteractionEvent value) {
/*  91 */     if (this.event == value) return this; 
/*  92 */     DeferrableInteractionEvent newValue = Objects.<DeferrableInteractionEvent>requireNonNull(value, "event");
/*  93 */     return new InteractionCallbackSpecDeferReplyMono(ephemeral(), newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 102 */     if (this == another) return true; 
/* 103 */     return (another instanceof InteractionCallbackSpecDeferReplyMono && 
/* 104 */       equalTo(0, (InteractionCallbackSpecDeferReplyMono)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, InteractionCallbackSpecDeferReplyMono another) {
/* 108 */     return (ephemeral().equals(another.ephemeral()) && this.event
/* 109 */       .equals(another.event));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 118 */     int h = 5381;
/* 119 */     h += (h << 5) + ephemeral().hashCode();
/* 120 */     h += (h << 5) + this.event.hashCode();
/* 121 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 130 */     return "InteractionCallbackSpecDeferReplyMono{ephemeral=" + 
/* 131 */       ephemeral().toString() + ", event=" + this.event + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static InteractionCallbackSpecDeferReplyMono of(DeferrableInteractionEvent event) {
/* 142 */     return new InteractionCallbackSpecDeferReplyMono(event);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static InteractionCallbackSpecDeferReplyMono copyOf(InteractionCallbackSpecDeferReplyMonoGenerator instance) {
/* 153 */     if (instance instanceof InteractionCallbackSpecDeferReplyMono) {
/* 154 */       return (InteractionCallbackSpecDeferReplyMono)instance;
/*     */     }
/* 156 */     return of(instance.event())
/* 157 */       .withEphemeral(instance.ephemeral());
/*     */   }
/*     */   
/*     */   public boolean isEphemeralPresent() {
/* 161 */     return !this.ephemeral_absent;
/*     */   }
/*     */   
/*     */   public Boolean ephemeralOrElse(Boolean defaultValue) {
/* 165 */     return !this.ephemeral_absent ? this.ephemeral_value : defaultValue;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\InteractionCallbackSpecDeferReplyMono.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */