/*     */ package discord4j.core.spec;
/*     */ 
/*     */ import com.google.errorprone.annotations.CanIgnoreReturnValue;
/*     */ import discord4j.voice.AudioProvider;
/*     */ import discord4j.voice.AudioReceiver;
/*     */ import discord4j.voice.VoiceReceiveTaskFactory;
/*     */ import discord4j.voice.VoiceSendTaskFactory;
/*     */ import java.time.Duration;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ import reactor.util.retry.RetrySpec;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "VoiceChannelJoinSpecGenerator", generator = "Immutables")
/*     */ public final class VoiceChannelJoinSpec
/*     */   implements VoiceChannelJoinSpecGenerator
/*     */ {
/*     */   private final Duration timeout;
/*     */   private final AudioProvider provider;
/*     */   private final AudioReceiver receiver;
/*     */   private final VoiceSendTaskFactory sendTaskFactory;
/*     */   private final VoiceReceiveTaskFactory receiveTaskFactory;
/*     */   private final boolean selfDeaf;
/*     */   private final boolean selfMute;
/*     */   private final Duration ipDiscoveryTimeout;
/*     */   private final RetrySpec ipDiscoveryRetrySpec;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   private volatile transient InitShim initShim;
/*     */   
/*     */   private VoiceChannelJoinSpec() {
/* 116 */     this.initShim = new InitShim(); this.timeout = this.initShim.timeout(); this.provider = this.initShim.provider(); this.receiver = this.initShim.receiver(); this.sendTaskFactory = this.initShim.sendTaskFactory(); this.receiveTaskFactory = this.initShim.receiveTaskFactory(); this.selfDeaf = this.initShim.selfDeaf(); this.selfMute = this.initShim.selfMute(); this.ipDiscoveryTimeout = this.initShim.ipDiscoveryTimeout(); this.ipDiscoveryRetrySpec = this.initShim.ipDiscoveryRetrySpec(); this.initShim = null; } private VoiceChannelJoinSpec(Builder builder) { this.initShim = new InitShim(); if (builder.timeout != null) this.initShim.timeout(builder.timeout);  if (builder.provider != null) this.initShim.provider(builder.provider);  if (builder.receiver != null) this.initShim.receiver(builder.receiver);  if (builder.sendTaskFactory != null) this.initShim.sendTaskFactory(builder.sendTaskFactory);  if (builder.receiveTaskFactory != null) this.initShim.receiveTaskFactory(builder.receiveTaskFactory);  if (builder.selfDeafIsSet()) this.initShim.selfDeaf(builder.selfDeaf);  if (builder.selfMuteIsSet()) this.initShim.selfMute(builder.selfMute);  if (builder.ipDiscoveryTimeout != null) this.initShim.ipDiscoveryTimeout(builder.ipDiscoveryTimeout);  if (builder.ipDiscoveryRetrySpec != null) this.initShim.ipDiscoveryRetrySpec(builder.ipDiscoveryRetrySpec);  this.timeout = this.initShim.timeout(); this.provider = this.initShim.provider(); this.receiver = this.initShim.receiver(); this.sendTaskFactory = this.initShim.sendTaskFactory(); this.receiveTaskFactory = this.initShim.receiveTaskFactory(); this.selfDeaf = this.initShim.selfDeaf(); this.selfMute = this.initShim.selfMute(); this.ipDiscoveryTimeout = this.initShim.ipDiscoveryTimeout(); this.ipDiscoveryRetrySpec = this.initShim.ipDiscoveryRetrySpec(); this.initShim = null; } private VoiceChannelJoinSpec(Duration timeout, AudioProvider provider, AudioReceiver receiver, VoiceSendTaskFactory sendTaskFactory, VoiceReceiveTaskFactory receiveTaskFactory, boolean selfDeaf, boolean selfMute, Duration ipDiscoveryTimeout, RetrySpec ipDiscoveryRetrySpec) { this.initShim = new InitShim(); this.timeout = timeout; this.provider = provider; this.receiver = receiver; this.sendTaskFactory = sendTaskFactory; this.receiveTaskFactory = receiveTaskFactory;
/*     */     this.selfDeaf = selfDeaf;
/*     */     this.selfMute = selfMute;
/*     */     this.ipDiscoveryTimeout = ipDiscoveryTimeout;
/*     */     this.ipDiscoveryRetrySpec = ipDiscoveryRetrySpec;
/* 121 */     this.initShim = null; } @Generated(from = "VoiceChannelJoinSpecGenerator", generator = "Immutables") private final class InitShim { private byte timeoutBuildStage = 0;
/*     */     private Duration timeout;
/*     */     
/*     */     Duration timeout() {
/* 125 */       if (this.timeoutBuildStage == -1) throw new IllegalStateException(formatInitCycleMessage()); 
/* 126 */       if (this.timeoutBuildStage == 0) {
/* 127 */         this.timeoutBuildStage = -1;
/* 128 */         this.timeout = Objects.<Duration>requireNonNull(VoiceChannelJoinSpec.this.timeoutInitialize(), "timeout");
/* 129 */         this.timeoutBuildStage = 1;
/*     */       } 
/* 131 */       return this.timeout;
/*     */     }
/*     */     
/*     */     void timeout(Duration timeout) {
/* 135 */       this.timeout = timeout;
/* 136 */       this.timeoutBuildStage = 1;
/*     */     }
/*     */     
/* 139 */     private byte providerBuildStage = 0;
/*     */     private AudioProvider provider;
/*     */     
/*     */     AudioProvider provider() {
/* 143 */       if (this.providerBuildStage == -1) throw new IllegalStateException(formatInitCycleMessage()); 
/* 144 */       if (this.providerBuildStage == 0) {
/* 145 */         this.providerBuildStage = -1;
/* 146 */         this.provider = Objects.<AudioProvider>requireNonNull(VoiceChannelJoinSpec.this.providerInitialize(), "provider");
/* 147 */         this.providerBuildStage = 1;
/*     */       } 
/* 149 */       return this.provider;
/*     */     }
/*     */     
/*     */     void provider(AudioProvider provider) {
/* 153 */       this.provider = provider;
/* 154 */       this.providerBuildStage = 1;
/*     */     }
/*     */     
/* 157 */     private byte receiverBuildStage = 0;
/*     */     private AudioReceiver receiver;
/*     */     
/*     */     AudioReceiver receiver() {
/* 161 */       if (this.receiverBuildStage == -1) throw new IllegalStateException(formatInitCycleMessage()); 
/* 162 */       if (this.receiverBuildStage == 0) {
/* 163 */         this.receiverBuildStage = -1;
/* 164 */         this.receiver = Objects.<AudioReceiver>requireNonNull(VoiceChannelJoinSpec.this.receiverInitialize(), "receiver");
/* 165 */         this.receiverBuildStage = 1;
/*     */       } 
/* 167 */       return this.receiver;
/*     */     }
/*     */     
/*     */     void receiver(AudioReceiver receiver) {
/* 171 */       this.receiver = receiver;
/* 172 */       this.receiverBuildStage = 1;
/*     */     }
/*     */     
/* 175 */     private byte sendTaskFactoryBuildStage = 0;
/*     */     private VoiceSendTaskFactory sendTaskFactory;
/*     */     
/*     */     VoiceSendTaskFactory sendTaskFactory() {
/* 179 */       if (this.sendTaskFactoryBuildStage == -1) throw new IllegalStateException(formatInitCycleMessage()); 
/* 180 */       if (this.sendTaskFactoryBuildStage == 0) {
/* 181 */         this.sendTaskFactoryBuildStage = -1;
/* 182 */         this.sendTaskFactory = Objects.<VoiceSendTaskFactory>requireNonNull(VoiceChannelJoinSpec.this.sendTaskFactoryInitialize(), "sendTaskFactory");
/* 183 */         this.sendTaskFactoryBuildStage = 1;
/*     */       } 
/* 185 */       return this.sendTaskFactory;
/*     */     }
/*     */     
/*     */     void sendTaskFactory(VoiceSendTaskFactory sendTaskFactory) {
/* 189 */       this.sendTaskFactory = sendTaskFactory;
/* 190 */       this.sendTaskFactoryBuildStage = 1;
/*     */     }
/*     */     
/* 193 */     private byte receiveTaskFactoryBuildStage = 0;
/*     */     private VoiceReceiveTaskFactory receiveTaskFactory;
/*     */     
/*     */     VoiceReceiveTaskFactory receiveTaskFactory() {
/* 197 */       if (this.receiveTaskFactoryBuildStage == -1) throw new IllegalStateException(formatInitCycleMessage()); 
/* 198 */       if (this.receiveTaskFactoryBuildStage == 0) {
/* 199 */         this.receiveTaskFactoryBuildStage = -1;
/* 200 */         this.receiveTaskFactory = Objects.<VoiceReceiveTaskFactory>requireNonNull(VoiceChannelJoinSpec.this.receiveTaskFactoryInitialize(), "receiveTaskFactory");
/* 201 */         this.receiveTaskFactoryBuildStage = 1;
/*     */       } 
/* 203 */       return this.receiveTaskFactory;
/*     */     }
/*     */     
/*     */     void receiveTaskFactory(VoiceReceiveTaskFactory receiveTaskFactory) {
/* 207 */       this.receiveTaskFactory = receiveTaskFactory;
/* 208 */       this.receiveTaskFactoryBuildStage = 1;
/*     */     }
/*     */     
/* 211 */     private byte selfDeafBuildStage = 0;
/*     */     private boolean selfDeaf;
/*     */     
/*     */     boolean selfDeaf() {
/* 215 */       if (this.selfDeafBuildStage == -1) throw new IllegalStateException(formatInitCycleMessage()); 
/* 216 */       if (this.selfDeafBuildStage == 0) {
/* 217 */         this.selfDeafBuildStage = -1;
/* 218 */         this.selfDeaf = VoiceChannelJoinSpec.this.selfDeafInitialize();
/* 219 */         this.selfDeafBuildStage = 1;
/*     */       } 
/* 221 */       return this.selfDeaf;
/*     */     }
/*     */     
/*     */     void selfDeaf(boolean selfDeaf) {
/* 225 */       this.selfDeaf = selfDeaf;
/* 226 */       this.selfDeafBuildStage = 1;
/*     */     }
/*     */     
/* 229 */     private byte selfMuteBuildStage = 0;
/*     */     private boolean selfMute;
/*     */     
/*     */     boolean selfMute() {
/* 233 */       if (this.selfMuteBuildStage == -1) throw new IllegalStateException(formatInitCycleMessage()); 
/* 234 */       if (this.selfMuteBuildStage == 0) {
/* 235 */         this.selfMuteBuildStage = -1;
/* 236 */         this.selfMute = VoiceChannelJoinSpec.this.selfMuteInitialize();
/* 237 */         this.selfMuteBuildStage = 1;
/*     */       } 
/* 239 */       return this.selfMute;
/*     */     }
/*     */     
/*     */     void selfMute(boolean selfMute) {
/* 243 */       this.selfMute = selfMute;
/* 244 */       this.selfMuteBuildStage = 1;
/*     */     }
/*     */     
/* 247 */     private byte ipDiscoveryTimeoutBuildStage = 0;
/*     */     private Duration ipDiscoveryTimeout;
/*     */     
/*     */     Duration ipDiscoveryTimeout() {
/* 251 */       if (this.ipDiscoveryTimeoutBuildStage == -1) throw new IllegalStateException(formatInitCycleMessage()); 
/* 252 */       if (this.ipDiscoveryTimeoutBuildStage == 0) {
/* 253 */         this.ipDiscoveryTimeoutBuildStage = -1;
/* 254 */         this.ipDiscoveryTimeout = Objects.<Duration>requireNonNull(VoiceChannelJoinSpec.this.ipDiscoveryTimeoutInitialize(), "ipDiscoveryTimeout");
/* 255 */         this.ipDiscoveryTimeoutBuildStage = 1;
/*     */       } 
/* 257 */       return this.ipDiscoveryTimeout;
/*     */     }
/*     */     
/*     */     void ipDiscoveryTimeout(Duration ipDiscoveryTimeout) {
/* 261 */       this.ipDiscoveryTimeout = ipDiscoveryTimeout;
/* 262 */       this.ipDiscoveryTimeoutBuildStage = 1;
/*     */     }
/*     */     
/* 265 */     private byte ipDiscoveryRetrySpecBuildStage = 0;
/*     */     private RetrySpec ipDiscoveryRetrySpec;
/*     */     
/*     */     RetrySpec ipDiscoveryRetrySpec() {
/* 269 */       if (this.ipDiscoveryRetrySpecBuildStage == -1) throw new IllegalStateException(formatInitCycleMessage()); 
/* 270 */       if (this.ipDiscoveryRetrySpecBuildStage == 0) {
/* 271 */         this.ipDiscoveryRetrySpecBuildStage = -1;
/* 272 */         this.ipDiscoveryRetrySpec = Objects.<RetrySpec>requireNonNull(VoiceChannelJoinSpec.this.ipDiscoveryRetrySpecInitialize(), "ipDiscoveryRetrySpec");
/* 273 */         this.ipDiscoveryRetrySpecBuildStage = 1;
/*     */       } 
/* 275 */       return this.ipDiscoveryRetrySpec;
/*     */     }
/*     */     
/*     */     void ipDiscoveryRetrySpec(RetrySpec ipDiscoveryRetrySpec) {
/* 279 */       this.ipDiscoveryRetrySpec = ipDiscoveryRetrySpec;
/* 280 */       this.ipDiscoveryRetrySpecBuildStage = 1;
/*     */     }
/*     */     
/*     */     private String formatInitCycleMessage() {
/* 284 */       List<String> attributes = new ArrayList<>();
/* 285 */       if (this.timeoutBuildStage == -1) attributes.add("timeout"); 
/* 286 */       if (this.providerBuildStage == -1) attributes.add("provider"); 
/* 287 */       if (this.receiverBuildStage == -1) attributes.add("receiver"); 
/* 288 */       if (this.sendTaskFactoryBuildStage == -1) attributes.add("sendTaskFactory"); 
/* 289 */       if (this.receiveTaskFactoryBuildStage == -1) attributes.add("receiveTaskFactory"); 
/* 290 */       if (this.selfDeafBuildStage == -1) attributes.add("selfDeaf"); 
/* 291 */       if (this.selfMuteBuildStage == -1) attributes.add("selfMute"); 
/* 292 */       if (this.ipDiscoveryTimeoutBuildStage == -1) attributes.add("ipDiscoveryTimeout"); 
/* 293 */       if (this.ipDiscoveryRetrySpecBuildStage == -1) attributes.add("ipDiscoveryRetrySpec"); 
/* 294 */       return "Cannot build VoiceChannelJoinSpec, attribute initializers form cycle " + attributes;
/*     */     }
/*     */     private InitShim() {} }
/*     */   
/*     */   private Duration timeoutInitialize() {
/* 299 */     return super.timeout();
/*     */   }
/*     */   
/*     */   private AudioProvider providerInitialize() {
/* 303 */     return super.provider();
/*     */   }
/*     */   
/*     */   private AudioReceiver receiverInitialize() {
/* 307 */     return super.receiver();
/*     */   }
/*     */   
/*     */   private VoiceSendTaskFactory sendTaskFactoryInitialize() {
/* 311 */     return super.sendTaskFactory();
/*     */   }
/*     */   
/*     */   private VoiceReceiveTaskFactory receiveTaskFactoryInitialize() {
/* 315 */     return super.receiveTaskFactory();
/*     */   }
/*     */   
/*     */   private boolean selfDeafInitialize() {
/* 319 */     return super.selfDeaf();
/*     */   }
/*     */   
/*     */   private boolean selfMuteInitialize() {
/* 323 */     return super.selfMute();
/*     */   }
/*     */   
/*     */   private Duration ipDiscoveryTimeoutInitialize() {
/* 327 */     return super.ipDiscoveryTimeout();
/*     */   }
/*     */   
/*     */   private RetrySpec ipDiscoveryRetrySpecInitialize() {
/* 331 */     return super.ipDiscoveryRetrySpec();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Duration timeout() {
/* 339 */     InitShim shim = this.initShim;
/* 340 */     return (shim != null) ? 
/* 341 */       shim.timeout() : 
/* 342 */       this.timeout;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AudioProvider provider() {
/* 350 */     InitShim shim = this.initShim;
/* 351 */     return (shim != null) ? 
/* 352 */       shim.provider() : 
/* 353 */       this.provider;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public AudioReceiver receiver() {
/* 362 */     InitShim shim = this.initShim;
/* 363 */     return (shim != null) ? 
/* 364 */       shim.receiver() : 
/* 365 */       this.receiver;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public VoiceSendTaskFactory sendTaskFactory() {
/* 373 */     InitShim shim = this.initShim;
/* 374 */     return (shim != null) ? 
/* 375 */       shim.sendTaskFactory() : 
/* 376 */       this.sendTaskFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public VoiceReceiveTaskFactory receiveTaskFactory() {
/* 385 */     InitShim shim = this.initShim;
/* 386 */     return (shim != null) ? 
/* 387 */       shim.receiveTaskFactory() : 
/* 388 */       this.receiveTaskFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean selfDeaf() {
/* 396 */     InitShim shim = this.initShim;
/* 397 */     return (shim != null) ? 
/* 398 */       shim.selfDeaf() : 
/* 399 */       this.selfDeaf;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean selfMute() {
/* 407 */     InitShim shim = this.initShim;
/* 408 */     return (shim != null) ? 
/* 409 */       shim.selfMute() : 
/* 410 */       this.selfMute;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Duration ipDiscoveryTimeout() {
/* 418 */     InitShim shim = this.initShim;
/* 419 */     return (shim != null) ? 
/* 420 */       shim.ipDiscoveryTimeout() : 
/* 421 */       this.ipDiscoveryTimeout;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RetrySpec ipDiscoveryRetrySpec() {
/* 429 */     InitShim shim = this.initShim;
/* 430 */     return (shim != null) ? 
/* 431 */       shim.ipDiscoveryRetrySpec() : 
/* 432 */       this.ipDiscoveryRetrySpec;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final VoiceChannelJoinSpec withTimeout(Duration value) {
/* 442 */     if (this.timeout == value) return this; 
/* 443 */     Duration newValue = Objects.<Duration>requireNonNull(value, "timeout");
/* 444 */     return validate(new VoiceChannelJoinSpec(newValue, this.provider, this.receiver, this.sendTaskFactory, this.receiveTaskFactory, this.selfDeaf, this.selfMute, this.ipDiscoveryTimeout, this.ipDiscoveryRetrySpec));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final VoiceChannelJoinSpec withProvider(AudioProvider value) {
/* 463 */     if (this.provider == value) return this; 
/* 464 */     AudioProvider newValue = Objects.<AudioProvider>requireNonNull(value, "provider");
/* 465 */     return validate(new VoiceChannelJoinSpec(this.timeout, newValue, this.receiver, this.sendTaskFactory, this.receiveTaskFactory, this.selfDeaf, this.selfMute, this.ipDiscoveryTimeout, this.ipDiscoveryRetrySpec));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public final VoiceChannelJoinSpec withReceiver(AudioReceiver value) {
/* 485 */     if (this.receiver == value) return this; 
/* 486 */     AudioReceiver newValue = Objects.<AudioReceiver>requireNonNull(value, "receiver");
/* 487 */     return validate(new VoiceChannelJoinSpec(this.timeout, this.provider, newValue, this.sendTaskFactory, this.receiveTaskFactory, this.selfDeaf, this.selfMute, this.ipDiscoveryTimeout, this.ipDiscoveryRetrySpec));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final VoiceChannelJoinSpec withSendTaskFactory(VoiceSendTaskFactory value) {
/* 506 */     if (this.sendTaskFactory == value) return this; 
/* 507 */     VoiceSendTaskFactory newValue = Objects.<VoiceSendTaskFactory>requireNonNull(value, "sendTaskFactory");
/* 508 */     return validate(new VoiceChannelJoinSpec(this.timeout, this.provider, this.receiver, newValue, this.receiveTaskFactory, this.selfDeaf, this.selfMute, this.ipDiscoveryTimeout, this.ipDiscoveryRetrySpec));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public final VoiceChannelJoinSpec withReceiveTaskFactory(VoiceReceiveTaskFactory value) {
/* 528 */     if (this.receiveTaskFactory == value) return this; 
/* 529 */     VoiceReceiveTaskFactory newValue = Objects.<VoiceReceiveTaskFactory>requireNonNull(value, "receiveTaskFactory");
/* 530 */     return validate(new VoiceChannelJoinSpec(this.timeout, this.provider, this.receiver, this.sendTaskFactory, newValue, this.selfDeaf, this.selfMute, this.ipDiscoveryTimeout, this.ipDiscoveryRetrySpec));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final VoiceChannelJoinSpec withSelfDeaf(boolean value) {
/* 549 */     if (this.selfDeaf == value) return this; 
/* 550 */     return validate(new VoiceChannelJoinSpec(this.timeout, this.provider, this.receiver, this.sendTaskFactory, this.receiveTaskFactory, value, this.selfMute, this.ipDiscoveryTimeout, this.ipDiscoveryRetrySpec));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final VoiceChannelJoinSpec withSelfMute(boolean value) {
/* 569 */     if (this.selfMute == value) return this; 
/* 570 */     return validate(new VoiceChannelJoinSpec(this.timeout, this.provider, this.receiver, this.sendTaskFactory, this.receiveTaskFactory, this.selfDeaf, value, this.ipDiscoveryTimeout, this.ipDiscoveryRetrySpec));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final VoiceChannelJoinSpec withIpDiscoveryTimeout(Duration value) {
/* 589 */     if (this.ipDiscoveryTimeout == value) return this; 
/* 590 */     Duration newValue = Objects.<Duration>requireNonNull(value, "ipDiscoveryTimeout");
/* 591 */     return validate(new VoiceChannelJoinSpec(this.timeout, this.provider, this.receiver, this.sendTaskFactory, this.receiveTaskFactory, this.selfDeaf, this.selfMute, newValue, this.ipDiscoveryRetrySpec));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final VoiceChannelJoinSpec withIpDiscoveryRetrySpec(RetrySpec value) {
/* 610 */     if (this.ipDiscoveryRetrySpec == value) return this; 
/* 611 */     RetrySpec newValue = Objects.<RetrySpec>requireNonNull(value, "ipDiscoveryRetrySpec");
/* 612 */     return validate(new VoiceChannelJoinSpec(this.timeout, this.provider, this.receiver, this.sendTaskFactory, this.receiveTaskFactory, this.selfDeaf, this.selfMute, this.ipDiscoveryTimeout, newValue));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 630 */     if (this == another) return true; 
/* 631 */     return (another instanceof VoiceChannelJoinSpec && 
/* 632 */       equalTo(0, (VoiceChannelJoinSpec)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, VoiceChannelJoinSpec another) {
/* 636 */     return (this.timeout.equals(another.timeout) && this.provider
/* 637 */       .equals(another.provider) && this.receiver
/* 638 */       .equals(another.receiver) && this.sendTaskFactory
/* 639 */       .equals(another.sendTaskFactory) && this.receiveTaskFactory
/* 640 */       .equals(another.receiveTaskFactory) && this.selfDeaf == another.selfDeaf && this.selfMute == another.selfMute && this.ipDiscoveryTimeout
/*     */ 
/*     */       
/* 643 */       .equals(another.ipDiscoveryTimeout) && this.ipDiscoveryRetrySpec
/* 644 */       .equals(another.ipDiscoveryRetrySpec));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 653 */     int h = 5381;
/* 654 */     h += (h << 5) + this.timeout.hashCode();
/* 655 */     h += (h << 5) + this.provider.hashCode();
/* 656 */     h += (h << 5) + this.receiver.hashCode();
/* 657 */     h += (h << 5) + this.sendTaskFactory.hashCode();
/* 658 */     h += (h << 5) + this.receiveTaskFactory.hashCode();
/* 659 */     h += (h << 5) + Boolean.hashCode(this.selfDeaf);
/* 660 */     h += (h << 5) + Boolean.hashCode(this.selfMute);
/* 661 */     h += (h << 5) + this.ipDiscoveryTimeout.hashCode();
/* 662 */     h += (h << 5) + this.ipDiscoveryRetrySpec.hashCode();
/* 663 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 672 */     return "VoiceChannelJoinSpec{timeout=" + this.timeout + ", provider=" + this.provider + ", receiver=" + this.receiver + ", sendTaskFactory=" + this.sendTaskFactory + ", receiveTaskFactory=" + this.receiveTaskFactory + ", selfDeaf=" + this.selfDeaf + ", selfMute=" + this.selfMute + ", ipDiscoveryTimeout=" + this.ipDiscoveryTimeout + ", ipDiscoveryRetrySpec=" + this.ipDiscoveryRetrySpec + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 685 */   private static final VoiceChannelJoinSpec INSTANCE = validate(new VoiceChannelJoinSpec());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static VoiceChannelJoinSpec create() {
/* 692 */     return INSTANCE;
/*     */   }
/*     */   
/*     */   private static VoiceChannelJoinSpec validate(VoiceChannelJoinSpec instance) {
/* 696 */     return (INSTANCE != null && INSTANCE.equalTo(0, instance)) ? INSTANCE : instance;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static VoiceChannelJoinSpec copyOf(VoiceChannelJoinSpecGenerator instance) {
/* 707 */     if (instance instanceof VoiceChannelJoinSpec) {
/* 708 */       return (VoiceChannelJoinSpec)instance;
/*     */     }
/* 710 */     return builder()
/* 711 */       .from(instance)
/* 712 */       .build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 733 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "VoiceChannelJoinSpecGenerator", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long OPT_BIT_SELF_DEAF = 1L;
/*     */     
/*     */     private static final long OPT_BIT_SELF_MUTE = 2L;
/*     */     
/*     */     private long optBits;
/*     */     
/*     */     private Duration timeout;
/*     */     
/*     */     private AudioProvider provider;
/*     */     
/*     */     private AudioReceiver receiver;
/*     */     
/*     */     private VoiceSendTaskFactory sendTaskFactory;
/*     */     
/*     */     private VoiceReceiveTaskFactory receiveTaskFactory;
/*     */     
/*     */     private boolean selfDeaf;
/*     */     
/*     */     private boolean selfMute;
/*     */     
/*     */     private Duration ipDiscoveryTimeout;
/*     */     
/*     */     private RetrySpec ipDiscoveryRetrySpec;
/*     */ 
/*     */     
/*     */     private Builder() {}
/*     */ 
/*     */     
/*     */     public final Builder from(VoiceChannelJoinSpec instance) {
/* 770 */       return from(instance);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     final Builder from(VoiceChannelJoinSpecGenerator instance) {
/* 780 */       Objects.requireNonNull(instance, "instance");
/* 781 */       timeout(instance.timeout());
/* 782 */       provider(instance.provider());
/* 783 */       receiver(instance.receiver());
/* 784 */       sendTaskFactory(instance.sendTaskFactory());
/* 785 */       receiveTaskFactory(instance.receiveTaskFactory());
/* 786 */       selfDeaf(instance.selfDeaf());
/* 787 */       selfMute(instance.selfMute());
/* 788 */       ipDiscoveryTimeout(instance.ipDiscoveryTimeout());
/* 789 */       ipDiscoveryRetrySpec(instance.ipDiscoveryRetrySpec());
/* 790 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder timeout(Duration timeout) {
/* 801 */       this.timeout = Objects.<Duration>requireNonNull(timeout, "timeout");
/* 802 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder provider(AudioProvider provider) {
/* 813 */       this.provider = Objects.<AudioProvider>requireNonNull(provider, "provider");
/* 814 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Deprecated
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder receiver(AudioReceiver receiver) {
/* 826 */       this.receiver = Objects.<AudioReceiver>requireNonNull(receiver, "receiver");
/* 827 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder sendTaskFactory(VoiceSendTaskFactory sendTaskFactory) {
/* 838 */       this.sendTaskFactory = Objects.<VoiceSendTaskFactory>requireNonNull(sendTaskFactory, "sendTaskFactory");
/* 839 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Deprecated
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder receiveTaskFactory(VoiceReceiveTaskFactory receiveTaskFactory) {
/* 851 */       this.receiveTaskFactory = Objects.<VoiceReceiveTaskFactory>requireNonNull(receiveTaskFactory, "receiveTaskFactory");
/* 852 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder selfDeaf(boolean selfDeaf) {
/* 863 */       this.selfDeaf = selfDeaf;
/* 864 */       this.optBits |= 0x1L;
/* 865 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder selfMute(boolean selfMute) {
/* 876 */       this.selfMute = selfMute;
/* 877 */       this.optBits |= 0x2L;
/* 878 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder ipDiscoveryTimeout(Duration ipDiscoveryTimeout) {
/* 889 */       this.ipDiscoveryTimeout = Objects.<Duration>requireNonNull(ipDiscoveryTimeout, "ipDiscoveryTimeout");
/* 890 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder ipDiscoveryRetrySpec(RetrySpec ipDiscoveryRetrySpec) {
/* 901 */       this.ipDiscoveryRetrySpec = Objects.<RetrySpec>requireNonNull(ipDiscoveryRetrySpec, "ipDiscoveryRetrySpec");
/* 902 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public VoiceChannelJoinSpec build() {
/* 911 */       return VoiceChannelJoinSpec.validate(new VoiceChannelJoinSpec(this));
/*     */     }
/*     */     
/*     */     private boolean selfDeafIsSet() {
/* 915 */       return ((this.optBits & 0x1L) != 0L);
/*     */     }
/*     */     
/*     */     private boolean selfMuteIsSet() {
/* 919 */       return ((this.optBits & 0x2L) != 0L);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\VoiceChannelJoinSpec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */