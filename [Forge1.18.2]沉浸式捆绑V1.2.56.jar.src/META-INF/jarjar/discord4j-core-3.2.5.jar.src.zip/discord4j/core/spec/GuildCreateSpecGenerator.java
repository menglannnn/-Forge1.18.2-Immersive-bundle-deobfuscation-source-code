/*    */ package discord4j.core.spec;
/*    */ 
/*    */ import discord4j.core.object.Region;
/*    */ import discord4j.core.object.entity.Guild;
/*    */ import discord4j.discordjson.json.GuildCreateRequest;
/*    */ import discord4j.discordjson.json.PartialChannelCreateRequest;
/*    */ import discord4j.discordjson.json.RoleCreateRequest;
/*    */ import discord4j.rest.util.Image;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import java.util.function.Supplier;
/*    */ import java.util.stream.Collectors;
/*    */ import org.immutables.value.Value.Default;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Immutable
/*    */ interface GuildCreateSpecGenerator
/*    */   extends Spec<GuildCreateRequest>
/*    */ {
/*    */   @Default
/*    */   default Guild.VerificationLevel verificationLevel() {
/* 51 */     return Guild.VerificationLevel.NONE;
/*    */   }
/*    */   
/*    */   @Default
/*    */   default Guild.NotificationLevel defaultMessageNotificationLevel() {
/* 56 */     return Guild.NotificationLevel.ALL_MESSAGES;
/*    */   }
/*    */   
/*    */   @Default
/*    */   default Guild.ContentFilterLevel explicitContentFilter() {
/* 61 */     return Guild.ContentFilterLevel.DISABLED;
/*    */   }
/*    */   
/*    */   @Default
/*    */   default List<RoleCreateSpec> roles() {
/* 66 */     return Collections.emptyList();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Default
/*    */   default List<GuildCreateFields.PartialChannel> channels() {
/* 74 */     return Collections.emptyList();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   default GuildCreateRequest asRequest() {
/* 81 */     List<RoleCreateRequest> roles = (List<RoleCreateRequest>)roles().stream().map(RoleCreateSpecGenerator::asRequest).collect(Collectors.toCollection(java.util.ArrayList::new));
/* 82 */     RoleCreateSpec everyoneRole = everyoneRole();
/* 83 */     if (everyoneRole != null) {
/* 84 */       roles.add(0, everyoneRole.asRequest());
/*    */     }
/*    */ 
/*    */     
/* 88 */     List<PartialChannelCreateRequest> channels = (List<PartialChannelCreateRequest>)channels().stream().map(GuildCreateFields.PartialChannel::asRequest).collect(Collectors.toList());
/* 89 */     return (GuildCreateRequest)GuildCreateRequest.builder()
/* 90 */       .name(name())
/* 91 */       .region(region().getId())
/* 92 */       .icon(InternalSpecUtils.<Image, String>mapNullable(icon(), Image::getDataUri))
/* 93 */       .verificationLevel(Integer.valueOf(verificationLevel().getValue()))
/* 94 */       .defaultMessageNotifications(Integer.valueOf(defaultMessageNotificationLevel().getValue()))
/* 95 */       .explicitContentFilter(Integer.valueOf(explicitContentFilter().getValue()))
/* 96 */       .roles(roles)
/* 97 */       .channels(channels)
/* 98 */       .build();
/*    */   }
/*    */   
/*    */   String name();
/*    */   
/*    */   Region region();
/*    */   
/*    */   @Nullable
/*    */   Image icon();
/*    */   
/*    */   @Nullable
/*    */   RoleCreateSpec everyoneRole();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\GuildCreateSpecGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */