/*     */ package discord4j.core.spec;
/*     */ 
/*     */ import discord4j.core.object.component.LayoutComponent;
/*     */ import discord4j.core.object.entity.Message;
/*     */ import discord4j.core.object.entity.Webhook;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import discord4j.rest.util.AllowedMentions;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.stream.StreamSupport;
/*     */ import org.immutables.value.Generated;
/*     */ import reactor.core.CoreSubscriber;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "WebhookExecuteMonoGenerator", generator = "Immutables")
/*     */ public final class WebhookExecuteMono
/*     */   extends WebhookExecuteMonoGenerator
/*     */ {
/*     */   private final String content_value;
/*     */   private final boolean content_absent;
/*     */   private final String username_value;
/*     */   private final boolean username_absent;
/*     */   private final String avatarUrl_value;
/*     */   private final boolean avatarUrl_absent;
/*     */   private final boolean tts;
/*     */   private final List<MessageCreateFields.File> files;
/*     */   private final List<MessageCreateFields.FileSpoiler> fileSpoilers;
/*     */   private final List<EmbedCreateSpec> embeds;
/*     */   private final AllowedMentions allowedMentions_value;
/*     */   private final boolean allowedMentions_absent;
/*     */   private final List<LayoutComponent> components_value;
/*     */   private final boolean components_absent;
/*     */   private final boolean waitForMessage;
/*     */   private final Webhook webhook;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   private volatile transient InitShim initShim;
/*     */   
/*     */   private WebhookExecuteMono(boolean waitForMessage, Webhook webhook) {
/* 113 */     this.initShim = new InitShim(); this.waitForMessage = waitForMessage; this.webhook = Objects.<Webhook>requireNonNull(webhook, "webhook"); Possible<String> content$impl = Possible.absent(); Possible<String> username$impl = Possible.absent(); Possible<String> avatarUrl$impl = Possible.absent(); Possible<AllowedMentions> allowedMentions$impl = Possible.absent(); Possible<List<LayoutComponent>> components$impl = Possible.absent(); this.content_value = content$impl.toOptional().orElse(null); this.content_absent = content$impl.isAbsent(); this.username_value = username$impl.toOptional().orElse(null); this.username_absent = username$impl.isAbsent(); this.avatarUrl_value = avatarUrl$impl.toOptional().orElse(null); this.avatarUrl_absent = avatarUrl$impl.isAbsent(); this.allowedMentions_value = allowedMentions$impl.toOptional().orElse(null); this.allowedMentions_absent = allowedMentions$impl.isAbsent(); this.components_value = components$impl.toOptional().orElse(null); this.components_absent = components$impl.isAbsent(); this.tts = this.initShim.tts(); this.files = this.initShim.files(); this.fileSpoilers = this.initShim.fileSpoilers(); this.embeds = this.initShim.embeds(); this.initShim = null; } private WebhookExecuteMono(Possible<String> content, Possible<String> username, Possible<String> avatarUrl, boolean tts, List<MessageCreateFields.File> files, List<MessageCreateFields.FileSpoiler> fileSpoilers, List<EmbedCreateSpec> embeds, Possible<AllowedMentions> allowedMentions, Possible<List<LayoutComponent>> components, boolean waitForMessage, Webhook webhook) { this.initShim = new InitShim(); Possible<String> content$impl = content; Possible<String> username$impl = username; Possible<String> avatarUrl$impl = avatarUrl; this.initShim.tts(tts); this.initShim.files(files); this.initShim.fileSpoilers(fileSpoilers); this.initShim.embeds(embeds); Possible<AllowedMentions> allowedMentions$impl = allowedMentions; Possible<List<LayoutComponent>> components$impl = components; this.waitForMessage = waitForMessage; this.webhook = webhook; this.content_value = content$impl.toOptional().orElse(null); this.content_absent = content$impl.isAbsent(); this.username_value = username$impl.toOptional().orElse(null); this.username_absent = username$impl.isAbsent(); this.avatarUrl_value = avatarUrl$impl.toOptional().orElse(null); this.avatarUrl_absent = avatarUrl$impl.isAbsent(); this.allowedMentions_value = allowedMentions$impl.toOptional().orElse(null); this.allowedMentions_absent = allowedMentions$impl.isAbsent(); this.components_value = components$impl.toOptional().orElse(null); this.components_absent = components$impl.isAbsent();
/*     */     this.tts = this.initShim.tts();
/*     */     this.files = this.initShim.files();
/*     */     this.fileSpoilers = this.initShim.fileSpoilers();
/*     */     this.embeds = this.initShim.embeds();
/* 118 */     this.initShim = null; } @Generated(from = "WebhookExecuteMonoGenerator", generator = "Immutables") private final class InitShim { private byte ttsBuildStage = 0;
/*     */     private boolean tts;
/*     */     
/*     */     boolean tts() {
/* 122 */       if (this.ttsBuildStage == -1) throw new IllegalStateException(formatInitCycleMessage()); 
/* 123 */       if (this.ttsBuildStage == 0) {
/* 124 */         this.ttsBuildStage = -1;
/* 125 */         this.tts = WebhookExecuteMono.this.tts();
/* 126 */         this.ttsBuildStage = 1;
/*     */       } 
/* 128 */       return this.tts;
/*     */     }
/*     */     
/*     */     void tts(boolean tts) {
/* 132 */       this.tts = tts;
/* 133 */       this.ttsBuildStage = 1;
/*     */     }
/*     */     
/* 136 */     private byte filesBuildStage = 0;
/*     */     private List<MessageCreateFields.File> files;
/*     */     
/*     */     List<MessageCreateFields.File> files() {
/* 140 */       if (this.filesBuildStage == -1) throw new IllegalStateException(formatInitCycleMessage()); 
/* 141 */       if (this.filesBuildStage == 0) {
/* 142 */         this.filesBuildStage = -1;
/* 143 */         this.files = (List)WebhookExecuteMono.createUnmodifiableList(false, WebhookExecuteMono.createSafeList((Iterable)WebhookExecuteMono.this.files(), true, false));
/* 144 */         this.filesBuildStage = 1;
/*     */       } 
/* 146 */       return this.files;
/*     */     }
/*     */     
/*     */     void files(List<MessageCreateFields.File> files) {
/* 150 */       this.files = files;
/* 151 */       this.filesBuildStage = 1;
/*     */     }
/*     */     
/* 154 */     private byte fileSpoilersBuildStage = 0;
/*     */     private List<MessageCreateFields.FileSpoiler> fileSpoilers;
/*     */     
/*     */     List<MessageCreateFields.FileSpoiler> fileSpoilers() {
/* 158 */       if (this.fileSpoilersBuildStage == -1) throw new IllegalStateException(formatInitCycleMessage()); 
/* 159 */       if (this.fileSpoilersBuildStage == 0) {
/* 160 */         this.fileSpoilersBuildStage = -1;
/* 161 */         this.fileSpoilers = (List)WebhookExecuteMono.createUnmodifiableList(false, WebhookExecuteMono.createSafeList((Iterable)WebhookExecuteMono.this.fileSpoilers(), true, false));
/* 162 */         this.fileSpoilersBuildStage = 1;
/*     */       } 
/* 164 */       return this.fileSpoilers;
/*     */     }
/*     */     
/*     */     void fileSpoilers(List<MessageCreateFields.FileSpoiler> fileSpoilers) {
/* 168 */       this.fileSpoilers = fileSpoilers;
/* 169 */       this.fileSpoilersBuildStage = 1;
/*     */     }
/*     */     
/* 172 */     private byte embedsBuildStage = 0;
/*     */     private List<EmbedCreateSpec> embeds;
/*     */     
/*     */     List<EmbedCreateSpec> embeds() {
/* 176 */       if (this.embedsBuildStage == -1) throw new IllegalStateException(formatInitCycleMessage()); 
/* 177 */       if (this.embedsBuildStage == 0) {
/* 178 */         this.embedsBuildStage = -1;
/* 179 */         this.embeds = (List)WebhookExecuteMono.createUnmodifiableList(false, WebhookExecuteMono.createSafeList((Iterable)WebhookExecuteMono.this.embeds(), true, false));
/* 180 */         this.embedsBuildStage = 1;
/*     */       } 
/* 182 */       return this.embeds;
/*     */     }
/*     */     
/*     */     void embeds(List<EmbedCreateSpec> embeds) {
/* 186 */       this.embeds = embeds;
/* 187 */       this.embedsBuildStage = 1;
/*     */     }
/*     */     
/*     */     private String formatInitCycleMessage() {
/* 191 */       List<String> attributes = new ArrayList<>();
/* 192 */       if (this.ttsBuildStage == -1) attributes.add("tts"); 
/* 193 */       if (this.filesBuildStage == -1) attributes.add("files"); 
/* 194 */       if (this.fileSpoilersBuildStage == -1) attributes.add("fileSpoilers"); 
/* 195 */       if (this.embedsBuildStage == -1) attributes.add("embeds"); 
/* 196 */       return "Cannot build WebhookExecuteMono, attribute initializers form cycle " + attributes;
/*     */     }
/*     */ 
/*     */     
/*     */     private InitShim() {} }
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<String> content() {
/* 205 */     return this.content_absent ? Possible.absent() : Possible.of(this.content_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<String> username() {
/* 213 */     return this.username_absent ? Possible.absent() : Possible.of(this.username_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<String> avatarUrl() {
/* 221 */     return this.avatarUrl_absent ? Possible.absent() : Possible.of(this.avatarUrl_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean tts() {
/* 229 */     InitShim shim = this.initShim;
/* 230 */     return (shim != null) ? 
/* 231 */       shim.tts() : 
/* 232 */       this.tts;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<MessageCreateFields.File> files() {
/* 240 */     InitShim shim = this.initShim;
/* 241 */     return (shim != null) ? 
/* 242 */       shim.files() : 
/* 243 */       this.files;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<MessageCreateFields.FileSpoiler> fileSpoilers() {
/* 251 */     InitShim shim = this.initShim;
/* 252 */     return (shim != null) ? 
/* 253 */       shim.fileSpoilers() : 
/* 254 */       this.fileSpoilers;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<EmbedCreateSpec> embeds() {
/* 262 */     InitShim shim = this.initShim;
/* 263 */     return (shim != null) ? 
/* 264 */       shim.embeds() : 
/* 265 */       this.embeds;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<AllowedMentions> allowedMentions() {
/* 273 */     return this.allowedMentions_absent ? Possible.absent() : Possible.of(this.allowedMentions_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<List<LayoutComponent>> components() {
/* 281 */     return this.components_absent ? Possible.absent() : 
/* 282 */       Possible.of(this.components_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean waitForMessage() {
/* 290 */     return this.waitForMessage;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Webhook webhook() {
/* 298 */     return this.webhook;
/*     */   }
/*     */   
/*     */   public WebhookExecuteMono withContent(Possible<String> value) {
/* 302 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/* 303 */     return new WebhookExecuteMono(newValue, 
/*     */         
/* 305 */         username(), 
/* 306 */         avatarUrl(), this.tts, this.files, this.fileSpoilers, this.embeds, 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 311 */         allowedMentions(), 
/* 312 */         components(), this.waitForMessage, this.webhook);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public WebhookExecuteMono withContent(String value) {
/* 318 */     Possible<String> newValue = Possible.of(value);
/* 319 */     return new WebhookExecuteMono(newValue, 
/*     */         
/* 321 */         username(), 
/* 322 */         avatarUrl(), this.tts, this.files, this.fileSpoilers, this.embeds, 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 327 */         allowedMentions(), 
/* 328 */         components(), this.waitForMessage, this.webhook);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public WebhookExecuteMono withUsername(Possible<String> value) {
/* 334 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/* 335 */     return new WebhookExecuteMono(
/* 336 */         content(), newValue, 
/*     */         
/* 338 */         avatarUrl(), this.tts, this.files, this.fileSpoilers, this.embeds, 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 343 */         allowedMentions(), 
/* 344 */         components(), this.waitForMessage, this.webhook);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public WebhookExecuteMono withUsername(String value) {
/* 350 */     Possible<String> newValue = Possible.of(value);
/* 351 */     return new WebhookExecuteMono(
/* 352 */         content(), newValue, 
/*     */         
/* 354 */         avatarUrl(), this.tts, this.files, this.fileSpoilers, this.embeds, 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 359 */         allowedMentions(), 
/* 360 */         components(), this.waitForMessage, this.webhook);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public WebhookExecuteMono withAvatarUrl(Possible<String> value) {
/* 366 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/* 367 */     return new WebhookExecuteMono(
/* 368 */         content(), 
/* 369 */         username(), newValue, this.tts, this.files, this.fileSpoilers, this.embeds, 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 375 */         allowedMentions(), 
/* 376 */         components(), this.waitForMessage, this.webhook);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public WebhookExecuteMono withAvatarUrl(String value) {
/* 382 */     Possible<String> newValue = Possible.of(value);
/* 383 */     return new WebhookExecuteMono(
/* 384 */         content(), 
/* 385 */         username(), newValue, this.tts, this.files, this.fileSpoilers, this.embeds, 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 391 */         allowedMentions(), 
/* 392 */         components(), this.waitForMessage, this.webhook);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final WebhookExecuteMono withTts(boolean value) {
/* 404 */     if (this.tts == value) return this; 
/* 405 */     return new WebhookExecuteMono(
/* 406 */         content(), 
/* 407 */         username(), 
/* 408 */         avatarUrl(), value, this.files, this.fileSpoilers, this.embeds, 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 413 */         allowedMentions(), 
/* 414 */         components(), this.waitForMessage, this.webhook);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final WebhookExecuteMono withFiles(MessageCreateFields.File... elements) {
/* 425 */     List<MessageCreateFields.File> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/* 426 */     return new WebhookExecuteMono(
/* 427 */         content(), 
/* 428 */         username(), 
/* 429 */         avatarUrl(), this.tts, newValue, this.fileSpoilers, this.embeds, 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 434 */         allowedMentions(), 
/* 435 */         components(), this.waitForMessage, this.webhook);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final WebhookExecuteMono withFiles(Iterable<? extends MessageCreateFields.File> elements) {
/* 447 */     if (this.files == elements) return this; 
/* 448 */     List<MessageCreateFields.File> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/* 449 */     return new WebhookExecuteMono(
/* 450 */         content(), 
/* 451 */         username(), 
/* 452 */         avatarUrl(), this.tts, newValue, this.fileSpoilers, this.embeds, 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 457 */         allowedMentions(), 
/* 458 */         components(), this.waitForMessage, this.webhook);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final WebhookExecuteMono withFileSpoilers(MessageCreateFields.FileSpoiler... elements) {
/* 469 */     List<MessageCreateFields.FileSpoiler> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/* 470 */     return new WebhookExecuteMono(
/* 471 */         content(), 
/* 472 */         username(), 
/* 473 */         avatarUrl(), this.tts, this.files, newValue, this.embeds, 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 478 */         allowedMentions(), 
/* 479 */         components(), this.waitForMessage, this.webhook);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final WebhookExecuteMono withFileSpoilers(Iterable<? extends MessageCreateFields.FileSpoiler> elements) {
/* 491 */     if (this.fileSpoilers == elements) return this; 
/* 492 */     List<MessageCreateFields.FileSpoiler> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/* 493 */     return new WebhookExecuteMono(
/* 494 */         content(), 
/* 495 */         username(), 
/* 496 */         avatarUrl(), this.tts, this.files, newValue, this.embeds, 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 501 */         allowedMentions(), 
/* 502 */         components(), this.waitForMessage, this.webhook);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final WebhookExecuteMono withEmbeds(EmbedCreateSpec... elements) {
/* 513 */     List<EmbedCreateSpec> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/* 514 */     return new WebhookExecuteMono(
/* 515 */         content(), 
/* 516 */         username(), 
/* 517 */         avatarUrl(), this.tts, this.files, this.fileSpoilers, newValue, 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 522 */         allowedMentions(), 
/* 523 */         components(), this.waitForMessage, this.webhook);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final WebhookExecuteMono withEmbeds(Iterable<? extends EmbedCreateSpec> elements) {
/* 535 */     if (this.embeds == elements) return this; 
/* 536 */     List<EmbedCreateSpec> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/* 537 */     return new WebhookExecuteMono(
/* 538 */         content(), 
/* 539 */         username(), 
/* 540 */         avatarUrl(), this.tts, this.files, this.fileSpoilers, newValue, 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 545 */         allowedMentions(), 
/* 546 */         components(), this.waitForMessage, this.webhook);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public WebhookExecuteMono withAllowedMentions(Possible<AllowedMentions> value) {
/* 552 */     Possible<AllowedMentions> newValue = Objects.<Possible<AllowedMentions>>requireNonNull(value);
/* 553 */     return new WebhookExecuteMono(
/* 554 */         content(), 
/* 555 */         username(), 
/* 556 */         avatarUrl(), this.tts, this.files, this.fileSpoilers, this.embeds, newValue, 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 562 */         components(), this.waitForMessage, this.webhook);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public WebhookExecuteMono withAllowedMentions(AllowedMentions value) {
/* 568 */     Possible<AllowedMentions> newValue = Possible.of(value);
/* 569 */     return new WebhookExecuteMono(
/* 570 */         content(), 
/* 571 */         username(), 
/* 572 */         avatarUrl(), this.tts, this.files, this.fileSpoilers, this.embeds, newValue, 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 578 */         components(), this.waitForMessage, this.webhook);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public WebhookExecuteMono withComponents(Possible<List<LayoutComponent>> possible) {
/* 584 */     Possible<List<LayoutComponent>> newValue = Objects.<Possible<List<LayoutComponent>>>requireNonNull(possible);
/* 585 */     return new WebhookExecuteMono(
/* 586 */         content(), 
/* 587 */         username(), 
/* 588 */         avatarUrl(), this.tts, this.files, this.fileSpoilers, this.embeds, 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 593 */         allowedMentions(), newValue, this.waitForMessage, this.webhook);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebhookExecuteMono withComponents(Iterable<LayoutComponent> elements) {
/* 600 */     Possible<List<LayoutComponent>> newValue = Possible.of(
/* 601 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/* 602 */     return new WebhookExecuteMono(
/* 603 */         content(), 
/* 604 */         username(), 
/* 605 */         avatarUrl(), this.tts, this.files, this.fileSpoilers, this.embeds, 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 610 */         allowedMentions(), newValue, this.waitForMessage, this.webhook);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SafeVarargs
/*     */   public final WebhookExecuteMono withComponents(LayoutComponent... elements) {
/* 618 */     Possible<List<LayoutComponent>> newValue = Possible.of(Arrays.asList(elements));
/* 619 */     return new WebhookExecuteMono(
/* 620 */         content(), 
/* 621 */         username(), 
/* 622 */         avatarUrl(), this.tts, this.files, this.fileSpoilers, this.embeds, 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 627 */         allowedMentions(), newValue, this.waitForMessage, this.webhook);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final WebhookExecuteMono withWaitForMessage(boolean value) {
/* 640 */     if (this.waitForMessage == value) return this; 
/* 641 */     return new WebhookExecuteMono(
/* 642 */         content(), 
/* 643 */         username(), 
/* 644 */         avatarUrl(), this.tts, this.files, this.fileSpoilers, this.embeds, 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 649 */         allowedMentions(), 
/* 650 */         components(), value, this.webhook);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final WebhookExecuteMono withWebhook(Webhook value) {
/* 662 */     if (this.webhook == value) return this; 
/* 663 */     Webhook newValue = Objects.<Webhook>requireNonNull(value, "webhook");
/* 664 */     return new WebhookExecuteMono(
/* 665 */         content(), 
/* 666 */         username(), 
/* 667 */         avatarUrl(), this.tts, this.files, this.fileSpoilers, this.embeds, 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 672 */         allowedMentions(), 
/* 673 */         components(), this.waitForMessage, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 684 */     if (this == another) return true; 
/* 685 */     return (another instanceof WebhookExecuteMono && 
/* 686 */       equalTo(0, (WebhookExecuteMono)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, WebhookExecuteMono another) {
/* 690 */     return (content().equals(another.content()) && 
/* 691 */       username().equals(another.username()) && 
/* 692 */       avatarUrl().equals(another.avatarUrl()) && this.tts == another.tts && this.files
/*     */       
/* 694 */       .equals(another.files) && this.fileSpoilers
/* 695 */       .equals(another.fileSpoilers) && this.embeds
/* 696 */       .equals(another.embeds) && 
/* 697 */       allowedMentions().equals(another.allowedMentions()) && 
/* 698 */       Objects.equals(this.components_value, another.components_value) && this.waitForMessage == another.waitForMessage && this.webhook
/*     */       
/* 700 */       .equals(another.webhook));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 709 */     int h = 5381;
/* 710 */     h += (h << 5) + content().hashCode();
/* 711 */     h += (h << 5) + username().hashCode();
/* 712 */     h += (h << 5) + avatarUrl().hashCode();
/* 713 */     h += (h << 5) + Boolean.hashCode(this.tts);
/* 714 */     h += (h << 5) + this.files.hashCode();
/* 715 */     h += (h << 5) + this.fileSpoilers.hashCode();
/* 716 */     h += (h << 5) + this.embeds.hashCode();
/* 717 */     h += (h << 5) + allowedMentions().hashCode();
/* 718 */     h += (h << 5) + Objects.hashCode(this.components_value);
/* 719 */     h += (h << 5) + Boolean.hashCode(this.waitForMessage);
/* 720 */     h += (h << 5) + this.webhook.hashCode();
/* 721 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 730 */     return "WebhookExecuteMono{content=" + 
/* 731 */       content().toString() + ", username=" + 
/* 732 */       username().toString() + ", avatarUrl=" + 
/* 733 */       avatarUrl().toString() + ", tts=" + this.tts + ", files=" + this.files + ", fileSpoilers=" + this.fileSpoilers + ", embeds=" + this.embeds + ", allowedMentions=" + 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 738 */       allowedMentions().toString() + ", components=" + 
/* 739 */       Objects.toString(this.components_value) + ", waitForMessage=" + this.waitForMessage + ", webhook=" + this.webhook + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static WebhookExecuteMono of(boolean waitForMessage, Webhook webhook) {
/* 752 */     return new WebhookExecuteMono(waitForMessage, webhook);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static WebhookExecuteMono copyOf(WebhookExecuteMonoGenerator instance) {
/* 763 */     if (instance instanceof WebhookExecuteMono) {
/* 764 */       return (WebhookExecuteMono)instance;
/*     */     }
/* 766 */     return of(instance.waitForMessage(), instance.webhook())
/* 767 */       .withContent(instance.content())
/* 768 */       .withUsername(instance.username())
/* 769 */       .withAvatarUrl(instance.avatarUrl())
/* 770 */       .withTts(instance.tts())
/* 771 */       .withFiles(instance.files())
/* 772 */       .withFileSpoilers(instance.fileSpoilers())
/* 773 */       .withEmbeds(instance.embeds())
/* 774 */       .withAllowedMentions(instance.allowedMentions())
/* 775 */       .withComponents(instance.components());
/*     */   }
/*     */   
/*     */   public boolean isContentPresent() {
/* 779 */     return !this.content_absent;
/*     */   }
/*     */   
/*     */   public String contentOrElse(String defaultValue) {
/* 783 */     return !this.content_absent ? this.content_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isUsernamePresent() {
/* 787 */     return !this.username_absent;
/*     */   }
/*     */   
/*     */   public String usernameOrElse(String defaultValue) {
/* 791 */     return !this.username_absent ? this.username_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isAvatarUrlPresent() {
/* 795 */     return !this.avatarUrl_absent;
/*     */   }
/*     */   
/*     */   public String avatarUrlOrElse(String defaultValue) {
/* 799 */     return !this.avatarUrl_absent ? this.avatarUrl_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isAllowedMentionsPresent() {
/* 803 */     return !this.allowedMentions_absent;
/*     */   }
/*     */   
/*     */   public AllowedMentions allowedMentionsOrElse(AllowedMentions defaultValue) {
/* 807 */     return !this.allowedMentions_absent ? this.allowedMentions_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isComponentsPresent() {
/* 811 */     return !this.components_absent;
/*     */   }
/*     */   
/*     */   public List<LayoutComponent> componentsOrElse(List<LayoutComponent> defaultValue) {
/* 815 */     return !this.components_absent ? this.components_value : defaultValue;
/*     */   }
/*     */   
/*     */   private static <T> List<T> createSafeList(Iterable<? extends T> iterable, boolean checkNulls, boolean skipNulls) {
/*     */     ArrayList<T> list;
/* 820 */     if (iterable instanceof Collection) {
/* 821 */       int size = ((Collection)iterable).size();
/* 822 */       if (size == 0) return Collections.emptyList(); 
/* 823 */       list = new ArrayList<>();
/*     */     } else {
/* 825 */       list = new ArrayList<>();
/*     */     } 
/* 827 */     for (T element : iterable) {
/* 828 */       if (skipNulls && element == null)
/* 829 */         continue;  if (checkNulls) Objects.requireNonNull(element, "element"); 
/* 830 */       list.add(element);
/*     */     } 
/* 832 */     return list;
/*     */   }
/*     */   
/*     */   private static <T> List<T> createUnmodifiableList(boolean clone, List<T> list) {
/* 836 */     switch (list.size()) { case 0:
/* 837 */         return Collections.emptyList();
/* 838 */       case 1: return Collections.singletonList(list.get(0)); }
/*     */     
/* 840 */     if (clone) {
/* 841 */       return Collections.unmodifiableList(new ArrayList<>(list));
/*     */     }
/* 843 */     if (list instanceof ArrayList) {
/* 844 */       ((ArrayList)list).trimToSize();
/*     */     }
/* 846 */     return Collections.unmodifiableList(list);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\WebhookExecuteMono.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */