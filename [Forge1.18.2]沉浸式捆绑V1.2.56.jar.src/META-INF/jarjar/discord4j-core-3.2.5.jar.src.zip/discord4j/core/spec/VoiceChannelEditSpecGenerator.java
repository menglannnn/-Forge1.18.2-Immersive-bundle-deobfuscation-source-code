/*    */ package discord4j.core.spec;
/*    */ 
/*    */ import discord4j.common.util.Snowflake;
/*    */ import discord4j.core.object.PermissionOverwrite;
/*    */ import discord4j.core.object.entity.channel.VoiceChannel;
/*    */ import discord4j.discordjson.json.ChannelModifyRequest;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import java.util.List;
/*    */ import java.util.Optional;
/*    */ import java.util.stream.Collectors;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Immutable(singleton = true)
/*    */ interface VoiceChannelEditSpecGenerator
/*    */   extends AuditSpec<ChannelModifyRequest>
/*    */ {
/*    */   default ChannelModifyRequest asRequest() {
/* 58 */     return (ChannelModifyRequest)ChannelModifyRequest.builder()
/* 59 */       .name(name())
/* 60 */       .bitrate(bitrate())
/* 61 */       .userLimit(userLimit())
/* 62 */       .position(position())
/* 63 */       .rateLimitPerUser(rateLimitPerUser())
/* 64 */       .permissionOverwrites(InternalSpecUtils.mapPossible(permissionOverwrites(), po -> (List)po.stream().map(PermissionOverwrite::getData).collect(Collectors.toList())))
/*    */ 
/*    */       
/* 67 */       .parentId(InternalSpecUtils.mapPossibleOptional(parentId(), Snowflake::asString))
/* 68 */       .rtcRegion(rtcRegion())
/* 69 */       .videoQualityMode(InternalSpecUtils.mapPossibleOptional(videoQualityMode(), VoiceChannel.Mode::getValue))
/* 70 */       .build();
/*    */   }
/*    */   
/*    */   Possible<String> name();
/*    */   
/*    */   Possible<Integer> bitrate();
/*    */   
/*    */   Possible<Integer> userLimit();
/*    */   
/*    */   Possible<Integer> position();
/*    */   
/*    */   Possible<Integer> rateLimitPerUser();
/*    */   
/*    */   Possible<List<PermissionOverwrite>> permissionOverwrites();
/*    */   
/*    */   Possible<Optional<Snowflake>> parentId();
/*    */   
/*    */   Possible<Optional<String>> rtcRegion();
/*    */   
/*    */   Possible<Optional<VoiceChannel.Mode>> videoQualityMode();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\VoiceChannelEditSpecGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */