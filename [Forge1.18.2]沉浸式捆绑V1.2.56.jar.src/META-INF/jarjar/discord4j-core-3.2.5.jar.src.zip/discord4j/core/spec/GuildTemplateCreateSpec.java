/*     */ package discord4j.core.spec;
/*     */ 
/*     */ import com.google.errorprone.annotations.CanIgnoreReturnValue;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import org.immutables.value.Generated;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "GuildTemplateCreateSpecGenerator", generator = "Immutables")
/*     */ public final class GuildTemplateCreateSpec
/*     */   implements GuildTemplateCreateSpecGenerator
/*     */ {
/*     */   private final String name;
/*     */   private final String description_value;
/*     */   private final boolean description_absent;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   private volatile transient InitShim initShim;
/*     */   
/*     */   private GuildTemplateCreateSpec(String name) {
/*  50 */     this.initShim = new InitShim(); this.name = Objects.<String>requireNonNull(name, "name"); Possible<Optional<String>> description$impl = Possible.absent(); this.description_value = Possible.flatOpt(description$impl).orElse(null); this.description_absent = description$impl.isAbsent(); this.initShim = null; } private GuildTemplateCreateSpec(String name, Possible<Optional<String>> description) { this.initShim = new InitShim();
/*     */     this.name = name;
/*     */     Possible<Optional<String>> description$impl = description;
/*     */     this.description_value = Possible.flatOpt(description$impl).orElse(null);
/*     */     this.description_absent = description$impl.isAbsent();
/*     */     this.initShim = null; } @Generated(from = "GuildTemplateCreateSpecGenerator", generator = "Immutables")
/*  56 */   private final class InitShim { private InitShim() {} private String formatInitCycleMessage() { List<String> attributes = new ArrayList<>();
/*  57 */       return "Cannot build GuildTemplateCreateSpec, attribute initializers form cycle " + attributes; }
/*     */      }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String name() {
/*  66 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Optional<String>> description() {
/*  74 */     return this.description_absent ? Possible.absent() : 
/*  75 */       Possible.of(Optional.ofNullable(this.description_value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final GuildTemplateCreateSpec withName(String value) {
/*  85 */     String newValue = Objects.<String>requireNonNull(value, "name");
/*  86 */     if (this.name.equals(newValue)) return this; 
/*  87 */     return new GuildTemplateCreateSpec(newValue, description());
/*     */   }
/*     */   
/*     */   public GuildTemplateCreateSpec withDescription(Possible<Optional<String>> value) {
/*  91 */     Possible<Optional<String>> newValue = Objects.<Possible<Optional<String>>>requireNonNull(value);
/*  92 */     return new GuildTemplateCreateSpec(this.name, newValue);
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public GuildTemplateCreateSpec withDescription(@Nullable String value) {
/*  97 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/*  98 */     return new GuildTemplateCreateSpec(this.name, newValue);
/*     */   }
/*     */   
/*     */   public GuildTemplateCreateSpec withDescriptionOrNull(@Nullable String value) {
/* 102 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/* 103 */     return new GuildTemplateCreateSpec(this.name, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 112 */     if (this == another) return true; 
/* 113 */     return (another instanceof GuildTemplateCreateSpec && 
/* 114 */       equalTo(0, (GuildTemplateCreateSpec)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, GuildTemplateCreateSpec another) {
/* 118 */     return (this.name.equals(another.name) && 
/* 119 */       description().equals(another.description()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 128 */     int h = 5381;
/* 129 */     h += (h << 5) + this.name.hashCode();
/* 130 */     h += (h << 5) + description().hashCode();
/* 131 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 140 */     return "GuildTemplateCreateSpec{name=" + this.name + ", description=" + 
/*     */       
/* 142 */       description().toString() + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static GuildTemplateCreateSpec of(String name) {
/* 152 */     return new GuildTemplateCreateSpec(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static GuildTemplateCreateSpec copyOf(GuildTemplateCreateSpecGenerator instance) {
/* 163 */     if (instance instanceof GuildTemplateCreateSpec) {
/* 164 */       return (GuildTemplateCreateSpec)instance;
/*     */     }
/* 166 */     return builder()
/* 167 */       .from(instance)
/* 168 */       .build();
/*     */   }
/*     */   
/*     */   public boolean isDescriptionPresent() {
/* 172 */     return !this.description_absent;
/*     */   }
/*     */   
/*     */   public String descriptionOrElse(String defaultValue) {
/* 176 */     return !this.description_absent ? this.description_value : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 190 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "GuildTemplateCreateSpecGenerator", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_NAME = 1L;
/*     */ 
/*     */ 
/*     */     
/* 203 */     private long initBits = 1L;
/*     */     
/* 205 */     private Possible<Optional<String>> description_possible = Possible.absent();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private String name;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(GuildTemplateCreateSpec instance) {
/* 219 */       return from(instance);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     final Builder from(GuildTemplateCreateSpecGenerator instance) {
/* 229 */       Objects.requireNonNull(instance, "instance");
/* 230 */       name(instance.name());
/* 231 */       description(instance.description());
/* 232 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder name(String name) {
/* 242 */       this.name = Objects.<String>requireNonNull(name, "name");
/* 243 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 244 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder description(Possible<Optional<String>> value) {
/* 249 */       this.description_possible = value;
/* 250 */       return this;
/*     */     }
/*     */     
/*     */     @Deprecated
/*     */     @CanIgnoreReturnValue
/*     */     public Builder description(@Nullable String value) {
/* 256 */       this.description_possible = Possible.of(Optional.ofNullable(value));
/* 257 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder descriptionOrNull(@Nullable String value) {
/* 262 */       this.description_possible = Possible.of(Optional.ofNullable(value));
/* 263 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public GuildTemplateCreateSpec build() {
/* 272 */       if (this.initBits != 0L) {
/* 273 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 275 */       return new GuildTemplateCreateSpec(this.name, description_build());
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 279 */       List<String> attributes = new ArrayList<>();
/* 280 */       if ((this.initBits & 0x1L) != 0L) attributes.add("name"); 
/* 281 */       return "Cannot build GuildTemplateCreateSpec, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Possible<Optional<String>> description_build() {
/* 285 */       return this.description_possible;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\GuildTemplateCreateSpec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */