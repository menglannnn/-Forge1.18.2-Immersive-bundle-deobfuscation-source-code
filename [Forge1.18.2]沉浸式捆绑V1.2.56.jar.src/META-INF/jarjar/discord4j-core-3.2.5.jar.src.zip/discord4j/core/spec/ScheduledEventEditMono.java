/*     */ package discord4j.core.spec;
/*     */ 
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.object.entity.ScheduledEvent;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.time.Instant;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import org.immutables.value.Generated;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "ScheduledEventEditMonoGenerator", generator = "Immutables")
/*     */ public final class ScheduledEventEditMono
/*     */   extends ScheduledEventEditMonoGenerator
/*     */ {
/*     */   @Nullable
/*     */   private final String reason;
/*     */   private final Snowflake channelId_value;
/*     */   private final boolean channelId_absent;
/*     */   private final ScheduledEventEntityMetadataSpec entityMetadata_value;
/*     */   private final boolean entityMetadata_absent;
/*     */   private final String name_value;
/*     */   private final boolean name_absent;
/*     */   private final ScheduledEvent.PrivacyLevel privacyLevel_value;
/*     */   private final boolean privacyLevel_absent;
/*     */   private final Instant scheduledStartTime_value;
/*     */   private final boolean scheduledStartTime_absent;
/*     */   private final Instant scheduledEndTime_value;
/*     */   private final boolean scheduledEndTime_absent;
/*     */   private final String description_value;
/*     */   private final boolean description_absent;
/*     */   private final ScheduledEvent.EntityType entityType_value;
/*     */   private final boolean entityType_absent;
/*     */   private final ScheduledEvent event;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   private volatile transient InitShim initShim;
/*     */   
/*     */   private ScheduledEventEditMono(ScheduledEvent event) {
/* 117 */     this.initShim = new InitShim(); this.event = Objects.<ScheduledEvent>requireNonNull(event, "event"); this.reason = null; Possible<Optional<Snowflake>> channelId$impl = Possible.absent(); Possible<ScheduledEventEntityMetadataSpec> entityMetadata$impl = Possible.absent(); Possible<String> name$impl = Possible.absent(); Possible<ScheduledEvent.PrivacyLevel> privacyLevel$impl = Possible.absent(); Possible<Instant> scheduledStartTime$impl = Possible.absent(); Possible<Instant> scheduledEndTime$impl = Possible.absent(); Possible<String> description$impl = Possible.absent(); Possible<ScheduledEvent.EntityType> entityType$impl = Possible.absent(); this.channelId_value = Possible.flatOpt(channelId$impl).orElse(null); this.channelId_absent = channelId$impl.isAbsent(); this.entityMetadata_value = entityMetadata$impl.toOptional().orElse(null); this.entityMetadata_absent = entityMetadata$impl.isAbsent(); this.name_value = name$impl.toOptional().orElse(null); this.name_absent = name$impl.isAbsent(); this.privacyLevel_value = privacyLevel$impl.toOptional().orElse(null); this.privacyLevel_absent = privacyLevel$impl.isAbsent(); this.scheduledStartTime_value = scheduledStartTime$impl.toOptional().orElse(null); this.scheduledStartTime_absent = scheduledStartTime$impl.isAbsent(); this.scheduledEndTime_value = scheduledEndTime$impl.toOptional().orElse(null); this.scheduledEndTime_absent = scheduledEndTime$impl.isAbsent(); this.description_value = description$impl.toOptional().orElse(null); this.description_absent = description$impl.isAbsent(); this.entityType_value = entityType$impl.toOptional().orElse(null); this.entityType_absent = entityType$impl.isAbsent(); this.initShim = null; } private ScheduledEventEditMono(@Nullable String reason, Possible<Optional<Snowflake>> channelId, Possible<ScheduledEventEntityMetadataSpec> entityMetadata, Possible<String> name, Possible<ScheduledEvent.PrivacyLevel> privacyLevel, Possible<Instant> scheduledStartTime, Possible<Instant> scheduledEndTime, Possible<String> description, Possible<ScheduledEvent.EntityType> entityType, ScheduledEvent event) { this.initShim = new InitShim(); this.reason = reason; Possible<Optional<Snowflake>> channelId$impl = channelId; Possible<ScheduledEventEntityMetadataSpec> entityMetadata$impl = entityMetadata; Possible<String> name$impl = name; Possible<ScheduledEvent.PrivacyLevel> privacyLevel$impl = privacyLevel; Possible<Instant> scheduledStartTime$impl = scheduledStartTime; Possible<Instant> scheduledEndTime$impl = scheduledEndTime; Possible<String> description$impl = description; Possible<ScheduledEvent.EntityType> entityType$impl = entityType; this.event = event; this.channelId_value = Possible.flatOpt(channelId$impl).orElse(null); this.channelId_absent = channelId$impl.isAbsent(); this.entityMetadata_value = entityMetadata$impl.toOptional().orElse(null); this.entityMetadata_absent = entityMetadata$impl.isAbsent(); this.name_value = name$impl.toOptional().orElse(null); this.name_absent = name$impl.isAbsent(); this.privacyLevel_value = privacyLevel$impl.toOptional().orElse(null); this.privacyLevel_absent = privacyLevel$impl.isAbsent(); this.scheduledStartTime_value = scheduledStartTime$impl.toOptional().orElse(null); this.scheduledStartTime_absent = scheduledStartTime$impl.isAbsent(); this.scheduledEndTime_value = scheduledEndTime$impl.toOptional().orElse(null);
/*     */     this.scheduledEndTime_absent = scheduledEndTime$impl.isAbsent();
/*     */     this.description_value = description$impl.toOptional().orElse(null);
/*     */     this.description_absent = description$impl.isAbsent();
/*     */     this.entityType_value = entityType$impl.toOptional().orElse(null);
/*     */     this.entityType_absent = entityType$impl.isAbsent();
/* 123 */     this.initShim = null; } @Generated(from = "ScheduledEventEditMonoGenerator", generator = "Immutables") private final class InitShim { private InitShim() {} private String formatInitCycleMessage() { List<String> attributes = new ArrayList<>();
/* 124 */       return "Cannot build ScheduledEventEditMono, attribute initializers form cycle " + attributes; }
/*     */      }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String reason() {
/* 134 */     return this.reason;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Optional<Snowflake>> channelId() {
/* 142 */     return this.channelId_absent ? Possible.absent() : 
/* 143 */       Possible.of(Optional.ofNullable(this.channelId_value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<ScheduledEventEntityMetadataSpec> entityMetadata() {
/* 151 */     return this.entityMetadata_absent ? Possible.absent() : Possible.of(this.entityMetadata_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<String> name() {
/* 159 */     return this.name_absent ? Possible.absent() : Possible.of(this.name_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<ScheduledEvent.PrivacyLevel> privacyLevel() {
/* 167 */     return this.privacyLevel_absent ? Possible.absent() : Possible.of(this.privacyLevel_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Instant> scheduledStartTime() {
/* 175 */     return this.scheduledStartTime_absent ? Possible.absent() : Possible.of(this.scheduledStartTime_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Instant> scheduledEndTime() {
/* 183 */     return this.scheduledEndTime_absent ? Possible.absent() : Possible.of(this.scheduledEndTime_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<String> description() {
/* 191 */     return this.description_absent ? Possible.absent() : Possible.of(this.description_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<ScheduledEvent.EntityType> entityType() {
/* 199 */     return this.entityType_absent ? Possible.absent() : Possible.of(this.entityType_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ScheduledEvent event() {
/* 207 */     return this.event;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ScheduledEventEditMono withReason(@Nullable String value) {
/* 217 */     if (Objects.equals(this.reason, value)) return this; 
/* 218 */     return new ScheduledEventEditMono(value, 
/*     */         
/* 220 */         channelId(), 
/* 221 */         entityMetadata(), 
/* 222 */         name(), 
/* 223 */         privacyLevel(), 
/* 224 */         scheduledStartTime(), 
/* 225 */         scheduledEndTime(), 
/* 226 */         description(), 
/* 227 */         entityType(), this.event);
/*     */   }
/*     */ 
/*     */   
/*     */   public ScheduledEventEditMono withChannelId(Possible<Optional<Snowflake>> value) {
/* 232 */     Possible<Optional<Snowflake>> newValue = Objects.<Possible<Optional<Snowflake>>>requireNonNull(value);
/* 233 */     return new ScheduledEventEditMono(this.reason, newValue, 
/*     */ 
/*     */         
/* 236 */         entityMetadata(), 
/* 237 */         name(), 
/* 238 */         privacyLevel(), 
/* 239 */         scheduledStartTime(), 
/* 240 */         scheduledEndTime(), 
/* 241 */         description(), 
/* 242 */         entityType(), this.event);
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public ScheduledEventEditMono withChannelId(@Nullable Snowflake value) {
/* 248 */     Possible<Optional<Snowflake>> newValue = Possible.of(Optional.ofNullable(value));
/* 249 */     return new ScheduledEventEditMono(this.reason, newValue, 
/*     */ 
/*     */         
/* 252 */         entityMetadata(), 
/* 253 */         name(), 
/* 254 */         privacyLevel(), 
/* 255 */         scheduledStartTime(), 
/* 256 */         scheduledEndTime(), 
/* 257 */         description(), 
/* 258 */         entityType(), this.event);
/*     */   }
/*     */ 
/*     */   
/*     */   public ScheduledEventEditMono withChannelIdOrNull(@Nullable Snowflake value) {
/* 263 */     Possible<Optional<Snowflake>> newValue = Possible.of(Optional.ofNullable(value));
/* 264 */     return new ScheduledEventEditMono(this.reason, newValue, 
/*     */ 
/*     */         
/* 267 */         entityMetadata(), 
/* 268 */         name(), 
/* 269 */         privacyLevel(), 
/* 270 */         scheduledStartTime(), 
/* 271 */         scheduledEndTime(), 
/* 272 */         description(), 
/* 273 */         entityType(), this.event);
/*     */   }
/*     */ 
/*     */   
/*     */   public ScheduledEventEditMono withEntityMetadata(Possible<ScheduledEventEntityMetadataSpec> value) {
/* 278 */     Possible<ScheduledEventEntityMetadataSpec> newValue = Objects.<Possible<ScheduledEventEntityMetadataSpec>>requireNonNull(value);
/* 279 */     return new ScheduledEventEditMono(this.reason, 
/*     */         
/* 281 */         channelId(), newValue, 
/*     */         
/* 283 */         name(), 
/* 284 */         privacyLevel(), 
/* 285 */         scheduledStartTime(), 
/* 286 */         scheduledEndTime(), 
/* 287 */         description(), 
/* 288 */         entityType(), this.event);
/*     */   }
/*     */ 
/*     */   
/*     */   public ScheduledEventEditMono withEntityMetadata(ScheduledEventEntityMetadataSpec value) {
/* 293 */     Possible<ScheduledEventEntityMetadataSpec> newValue = Possible.of(value);
/* 294 */     return new ScheduledEventEditMono(this.reason, 
/*     */         
/* 296 */         channelId(), newValue, 
/*     */         
/* 298 */         name(), 
/* 299 */         privacyLevel(), 
/* 300 */         scheduledStartTime(), 
/* 301 */         scheduledEndTime(), 
/* 302 */         description(), 
/* 303 */         entityType(), this.event);
/*     */   }
/*     */ 
/*     */   
/*     */   public ScheduledEventEditMono withName(Possible<String> value) {
/* 308 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/* 309 */     return new ScheduledEventEditMono(this.reason, 
/*     */         
/* 311 */         channelId(), 
/* 312 */         entityMetadata(), newValue, 
/*     */         
/* 314 */         privacyLevel(), 
/* 315 */         scheduledStartTime(), 
/* 316 */         scheduledEndTime(), 
/* 317 */         description(), 
/* 318 */         entityType(), this.event);
/*     */   }
/*     */ 
/*     */   
/*     */   public ScheduledEventEditMono withName(String value) {
/* 323 */     Possible<String> newValue = Possible.of(value);
/* 324 */     return new ScheduledEventEditMono(this.reason, 
/*     */         
/* 326 */         channelId(), 
/* 327 */         entityMetadata(), newValue, 
/*     */         
/* 329 */         privacyLevel(), 
/* 330 */         scheduledStartTime(), 
/* 331 */         scheduledEndTime(), 
/* 332 */         description(), 
/* 333 */         entityType(), this.event);
/*     */   }
/*     */ 
/*     */   
/*     */   public ScheduledEventEditMono withPrivacyLevel(Possible<ScheduledEvent.PrivacyLevel> value) {
/* 338 */     Possible<ScheduledEvent.PrivacyLevel> newValue = Objects.<Possible<ScheduledEvent.PrivacyLevel>>requireNonNull(value);
/* 339 */     return new ScheduledEventEditMono(this.reason, 
/*     */         
/* 341 */         channelId(), 
/* 342 */         entityMetadata(), 
/* 343 */         name(), newValue, 
/*     */         
/* 345 */         scheduledStartTime(), 
/* 346 */         scheduledEndTime(), 
/* 347 */         description(), 
/* 348 */         entityType(), this.event);
/*     */   }
/*     */ 
/*     */   
/*     */   public ScheduledEventEditMono withPrivacyLevel(ScheduledEvent.PrivacyLevel value) {
/* 353 */     Possible<ScheduledEvent.PrivacyLevel> newValue = Possible.of(value);
/* 354 */     return new ScheduledEventEditMono(this.reason, 
/*     */         
/* 356 */         channelId(), 
/* 357 */         entityMetadata(), 
/* 358 */         name(), newValue, 
/*     */         
/* 360 */         scheduledStartTime(), 
/* 361 */         scheduledEndTime(), 
/* 362 */         description(), 
/* 363 */         entityType(), this.event);
/*     */   }
/*     */ 
/*     */   
/*     */   public ScheduledEventEditMono withScheduledStartTime(Possible<Instant> value) {
/* 368 */     Possible<Instant> newValue = Objects.<Possible<Instant>>requireNonNull(value);
/* 369 */     return new ScheduledEventEditMono(this.reason, 
/*     */         
/* 371 */         channelId(), 
/* 372 */         entityMetadata(), 
/* 373 */         name(), 
/* 374 */         privacyLevel(), newValue, 
/*     */         
/* 376 */         scheduledEndTime(), 
/* 377 */         description(), 
/* 378 */         entityType(), this.event);
/*     */   }
/*     */ 
/*     */   
/*     */   public ScheduledEventEditMono withScheduledStartTime(Instant value) {
/* 383 */     Possible<Instant> newValue = Possible.of(value);
/* 384 */     return new ScheduledEventEditMono(this.reason, 
/*     */         
/* 386 */         channelId(), 
/* 387 */         entityMetadata(), 
/* 388 */         name(), 
/* 389 */         privacyLevel(), newValue, 
/*     */         
/* 391 */         scheduledEndTime(), 
/* 392 */         description(), 
/* 393 */         entityType(), this.event);
/*     */   }
/*     */ 
/*     */   
/*     */   public ScheduledEventEditMono withScheduledEndTime(Possible<Instant> value) {
/* 398 */     Possible<Instant> newValue = Objects.<Possible<Instant>>requireNonNull(value);
/* 399 */     return new ScheduledEventEditMono(this.reason, 
/*     */         
/* 401 */         channelId(), 
/* 402 */         entityMetadata(), 
/* 403 */         name(), 
/* 404 */         privacyLevel(), 
/* 405 */         scheduledStartTime(), newValue, 
/*     */         
/* 407 */         description(), 
/* 408 */         entityType(), this.event);
/*     */   }
/*     */ 
/*     */   
/*     */   public ScheduledEventEditMono withScheduledEndTime(Instant value) {
/* 413 */     Possible<Instant> newValue = Possible.of(value);
/* 414 */     return new ScheduledEventEditMono(this.reason, 
/*     */         
/* 416 */         channelId(), 
/* 417 */         entityMetadata(), 
/* 418 */         name(), 
/* 419 */         privacyLevel(), 
/* 420 */         scheduledStartTime(), newValue, 
/*     */         
/* 422 */         description(), 
/* 423 */         entityType(), this.event);
/*     */   }
/*     */ 
/*     */   
/*     */   public ScheduledEventEditMono withDescription(Possible<String> value) {
/* 428 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/* 429 */     return new ScheduledEventEditMono(this.reason, 
/*     */         
/* 431 */         channelId(), 
/* 432 */         entityMetadata(), 
/* 433 */         name(), 
/* 434 */         privacyLevel(), 
/* 435 */         scheduledStartTime(), 
/* 436 */         scheduledEndTime(), newValue, 
/*     */         
/* 438 */         entityType(), this.event);
/*     */   }
/*     */ 
/*     */   
/*     */   public ScheduledEventEditMono withDescription(String value) {
/* 443 */     Possible<String> newValue = Possible.of(value);
/* 444 */     return new ScheduledEventEditMono(this.reason, 
/*     */         
/* 446 */         channelId(), 
/* 447 */         entityMetadata(), 
/* 448 */         name(), 
/* 449 */         privacyLevel(), 
/* 450 */         scheduledStartTime(), 
/* 451 */         scheduledEndTime(), newValue, 
/*     */         
/* 453 */         entityType(), this.event);
/*     */   }
/*     */ 
/*     */   
/*     */   public ScheduledEventEditMono withEntityType(Possible<ScheduledEvent.EntityType> value) {
/* 458 */     Possible<ScheduledEvent.EntityType> newValue = Objects.<Possible<ScheduledEvent.EntityType>>requireNonNull(value);
/* 459 */     return new ScheduledEventEditMono(this.reason, 
/*     */         
/* 461 */         channelId(), 
/* 462 */         entityMetadata(), 
/* 463 */         name(), 
/* 464 */         privacyLevel(), 
/* 465 */         scheduledStartTime(), 
/* 466 */         scheduledEndTime(), 
/* 467 */         description(), newValue, this.event);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ScheduledEventEditMono withEntityType(ScheduledEvent.EntityType value) {
/* 473 */     Possible<ScheduledEvent.EntityType> newValue = Possible.of(value);
/* 474 */     return new ScheduledEventEditMono(this.reason, 
/*     */         
/* 476 */         channelId(), 
/* 477 */         entityMetadata(), 
/* 478 */         name(), 
/* 479 */         privacyLevel(), 
/* 480 */         scheduledStartTime(), 
/* 481 */         scheduledEndTime(), 
/* 482 */         description(), newValue, this.event);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ScheduledEventEditMono withEvent(ScheduledEvent value) {
/* 494 */     if (this.event == value) return this; 
/* 495 */     ScheduledEvent newValue = Objects.<ScheduledEvent>requireNonNull(value, "event");
/* 496 */     return new ScheduledEventEditMono(this.reason, 
/*     */         
/* 498 */         channelId(), 
/* 499 */         entityMetadata(), 
/* 500 */         name(), 
/* 501 */         privacyLevel(), 
/* 502 */         scheduledStartTime(), 
/* 503 */         scheduledEndTime(), 
/* 504 */         description(), 
/* 505 */         entityType(), newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 515 */     if (this == another) return true; 
/* 516 */     return (another instanceof ScheduledEventEditMono && 
/* 517 */       equalTo(0, (ScheduledEventEditMono)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ScheduledEventEditMono another) {
/* 521 */     return (Objects.equals(this.reason, another.reason) && 
/* 522 */       channelId().equals(another.channelId()) && 
/* 523 */       entityMetadata().equals(another.entityMetadata()) && 
/* 524 */       name().equals(another.name()) && 
/* 525 */       privacyLevel().equals(another.privacyLevel()) && 
/* 526 */       scheduledStartTime().equals(another.scheduledStartTime()) && 
/* 527 */       scheduledEndTime().equals(another.scheduledEndTime()) && 
/* 528 */       description().equals(another.description()) && 
/* 529 */       entityType().equals(another.entityType()) && this.event
/* 530 */       .equals(another.event));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 539 */     int h = 5381;
/* 540 */     h += (h << 5) + Objects.hashCode(this.reason);
/* 541 */     h += (h << 5) + channelId().hashCode();
/* 542 */     h += (h << 5) + entityMetadata().hashCode();
/* 543 */     h += (h << 5) + name().hashCode();
/* 544 */     h += (h << 5) + privacyLevel().hashCode();
/* 545 */     h += (h << 5) + scheduledStartTime().hashCode();
/* 546 */     h += (h << 5) + scheduledEndTime().hashCode();
/* 547 */     h += (h << 5) + description().hashCode();
/* 548 */     h += (h << 5) + entityType().hashCode();
/* 549 */     h += (h << 5) + this.event.hashCode();
/* 550 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 559 */     return "ScheduledEventEditMono{reason=" + this.reason + ", channelId=" + 
/*     */       
/* 561 */       channelId().toString() + ", entityMetadata=" + 
/* 562 */       entityMetadata().toString() + ", name=" + 
/* 563 */       name().toString() + ", privacyLevel=" + 
/* 564 */       privacyLevel().toString() + ", scheduledStartTime=" + 
/* 565 */       scheduledStartTime().toString() + ", scheduledEndTime=" + 
/* 566 */       scheduledEndTime().toString() + ", description=" + 
/* 567 */       description().toString() + ", entityType=" + 
/* 568 */       entityType().toString() + ", event=" + this.event + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ScheduledEventEditMono of(ScheduledEvent event) {
/* 579 */     return new ScheduledEventEditMono(event);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static ScheduledEventEditMono copyOf(ScheduledEventEditMonoGenerator instance) {
/* 590 */     if (instance instanceof ScheduledEventEditMono) {
/* 591 */       return (ScheduledEventEditMono)instance;
/*     */     }
/* 593 */     return of(instance.event())
/* 594 */       .withReason(instance.reason())
/* 595 */       .withChannelId(instance.channelId())
/* 596 */       .withEntityMetadata(instance.entityMetadata())
/* 597 */       .withName(instance.name())
/* 598 */       .withPrivacyLevel(instance.privacyLevel())
/* 599 */       .withScheduledStartTime(instance.scheduledStartTime())
/* 600 */       .withScheduledEndTime(instance.scheduledEndTime())
/* 601 */       .withDescription(instance.description())
/* 602 */       .withEntityType(instance.entityType());
/*     */   }
/*     */   
/*     */   public boolean isChannelIdPresent() {
/* 606 */     return !this.channelId_absent;
/*     */   }
/*     */   
/*     */   public Snowflake channelIdOrElse(Snowflake defaultValue) {
/* 610 */     return !this.channelId_absent ? this.channelId_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isEntityMetadataPresent() {
/* 614 */     return !this.entityMetadata_absent;
/*     */   }
/*     */   
/*     */   public ScheduledEventEntityMetadataSpec entityMetadataOrElse(ScheduledEventEntityMetadataSpec defaultValue) {
/* 618 */     return !this.entityMetadata_absent ? this.entityMetadata_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isNamePresent() {
/* 622 */     return !this.name_absent;
/*     */   }
/*     */   
/*     */   public String nameOrElse(String defaultValue) {
/* 626 */     return !this.name_absent ? this.name_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isPrivacyLevelPresent() {
/* 630 */     return !this.privacyLevel_absent;
/*     */   }
/*     */   
/*     */   public ScheduledEvent.PrivacyLevel privacyLevelOrElse(ScheduledEvent.PrivacyLevel defaultValue) {
/* 634 */     return !this.privacyLevel_absent ? this.privacyLevel_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isScheduledStartTimePresent() {
/* 638 */     return !this.scheduledStartTime_absent;
/*     */   }
/*     */   
/*     */   public Instant scheduledStartTimeOrElse(Instant defaultValue) {
/* 642 */     return !this.scheduledStartTime_absent ? this.scheduledStartTime_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isScheduledEndTimePresent() {
/* 646 */     return !this.scheduledEndTime_absent;
/*     */   }
/*     */   
/*     */   public Instant scheduledEndTimeOrElse(Instant defaultValue) {
/* 650 */     return !this.scheduledEndTime_absent ? this.scheduledEndTime_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isDescriptionPresent() {
/* 654 */     return !this.description_absent;
/*     */   }
/*     */   
/*     */   public String descriptionOrElse(String defaultValue) {
/* 658 */     return !this.description_absent ? this.description_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isEntityTypePresent() {
/* 662 */     return !this.entityType_absent;
/*     */   }
/*     */   
/*     */   public ScheduledEvent.EntityType entityTypeOrElse(ScheduledEvent.EntityType defaultValue) {
/* 666 */     return !this.entityType_absent ? this.entityType_value : defaultValue;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\ScheduledEventEditMono.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */