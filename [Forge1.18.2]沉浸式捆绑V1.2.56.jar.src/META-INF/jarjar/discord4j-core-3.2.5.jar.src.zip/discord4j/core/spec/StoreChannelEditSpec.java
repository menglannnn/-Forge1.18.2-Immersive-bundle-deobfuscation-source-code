/*     */ package discord4j.core.spec;
/*     */ 
/*     */ import com.google.errorprone.annotations.CanIgnoreReturnValue;
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.object.PermissionOverwrite;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.stream.StreamSupport;
/*     */ import org.immutables.value.Generated;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "StoreChannelEditSpecGenerator", generator = "Immutables")
/*     */ public final class StoreChannelEditSpec
/*     */   implements StoreChannelEditSpecGenerator
/*     */ {
/*     */   @Nullable
/*     */   private final String reason;
/*     */   private final String name_value;
/*     */   private final boolean name_absent;
/*     */   private final Integer position_value;
/*     */   private final boolean position_absent;
/*     */   private final List<PermissionOverwrite> permissionOverwrites_value;
/*     */   private final boolean permissionOverwrites_absent;
/*     */   private final Snowflake parentId_value;
/*     */   private final boolean parentId_absent;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   
/*     */   private StoreChannelEditSpec() {
/*  41 */     this.reason = null;
/*  42 */     Possible<String> name$impl = Possible.absent();
/*  43 */     Possible<Integer> position$impl = Possible.absent();
/*  44 */     Possible<List<PermissionOverwrite>> permissionOverwrites$impl = Possible.absent();
/*  45 */     Possible<Optional<Snowflake>> parentId$impl = Possible.absent();
/*  46 */     this.name_value = name$impl.toOptional().orElse(null);
/*  47 */     this.name_absent = name$impl.isAbsent();
/*  48 */     this.position_value = position$impl.toOptional().orElse(null);
/*  49 */     this.position_absent = position$impl.isAbsent();
/*  50 */     this.permissionOverwrites_value = permissionOverwrites$impl.toOptional().orElse(null);
/*  51 */     this.permissionOverwrites_absent = permissionOverwrites$impl.isAbsent();
/*  52 */     this.parentId_value = Possible.flatOpt(parentId$impl).orElse(null);
/*  53 */     this.parentId_absent = parentId$impl.isAbsent();
/*  54 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private StoreChannelEditSpec(@Nullable String reason, Possible<String> name, Possible<Integer> position, Possible<List<PermissionOverwrite>> permissionOverwrites, Possible<Optional<Snowflake>> parentId) {
/*  63 */     this.reason = reason;
/*  64 */     Possible<String> name$impl = name;
/*  65 */     Possible<Integer> position$impl = position;
/*  66 */     Possible<List<PermissionOverwrite>> permissionOverwrites$impl = permissionOverwrites;
/*  67 */     Possible<Optional<Snowflake>> parentId$impl = parentId;
/*  68 */     this.name_value = name$impl.toOptional().orElse(null);
/*  69 */     this.name_absent = name$impl.isAbsent();
/*  70 */     this.position_value = position$impl.toOptional().orElse(null);
/*  71 */     this.position_absent = position$impl.isAbsent();
/*  72 */     this.permissionOverwrites_value = permissionOverwrites$impl.toOptional().orElse(null);
/*  73 */     this.permissionOverwrites_absent = permissionOverwrites$impl.isAbsent();
/*  74 */     this.parentId_value = Possible.flatOpt(parentId$impl).orElse(null);
/*  75 */     this.parentId_absent = parentId$impl.isAbsent();
/*  76 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  82 */   private volatile transient InitShim initShim = new InitShim();
/*     */   
/*     */   @Generated(from = "StoreChannelEditSpecGenerator", generator = "Immutables")
/*     */   private final class InitShim
/*     */   {
/*     */     private String formatInitCycleMessage() {
/*  88 */       List<String> attributes = new ArrayList<>();
/*  89 */       return "Cannot build StoreChannelEditSpec, attribute initializers form cycle " + attributes;
/*     */     }
/*     */ 
/*     */     
/*     */     private InitShim() {}
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String reason() {
/*  99 */     return this.reason;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<String> name() {
/* 107 */     return this.name_absent ? Possible.absent() : Possible.of(this.name_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Integer> position() {
/* 115 */     return this.position_absent ? Possible.absent() : Possible.of(this.position_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<List<PermissionOverwrite>> permissionOverwrites() {
/* 123 */     return this.permissionOverwrites_absent ? Possible.absent() : 
/* 124 */       Possible.of(this.permissionOverwrites_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Optional<Snowflake>> parentId() {
/* 132 */     return this.parentId_absent ? Possible.absent() : 
/* 133 */       Possible.of(Optional.ofNullable(this.parentId_value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final StoreChannelEditSpec withReason(@Nullable String value) {
/* 143 */     if (Objects.equals(this.reason, value)) return this; 
/* 144 */     return validate(new StoreChannelEditSpec(value, name(), position(), permissionOverwrites(), parentId()));
/*     */   }
/*     */   
/*     */   public StoreChannelEditSpec withName(Possible<String> value) {
/* 148 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/* 149 */     return validate(new StoreChannelEditSpec(this.reason, newValue, position(), permissionOverwrites(), parentId()));
/*     */   }
/*     */   
/*     */   public StoreChannelEditSpec withName(String value) {
/* 153 */     Possible<String> newValue = Possible.of(value);
/* 154 */     return validate(new StoreChannelEditSpec(this.reason, newValue, position(), permissionOverwrites(), parentId()));
/*     */   }
/*     */   
/*     */   public StoreChannelEditSpec withPosition(Possible<Integer> value) {
/* 158 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/* 159 */     return validate(new StoreChannelEditSpec(this.reason, name(), newValue, permissionOverwrites(), parentId()));
/*     */   }
/*     */   
/*     */   public StoreChannelEditSpec withPosition(Integer value) {
/* 163 */     Possible<Integer> newValue = Possible.of(value);
/* 164 */     return validate(new StoreChannelEditSpec(this.reason, name(), newValue, permissionOverwrites(), parentId()));
/*     */   }
/*     */   
/*     */   public StoreChannelEditSpec withPermissionOverwrites(Possible<List<PermissionOverwrite>> possible) {
/* 168 */     Possible<List<PermissionOverwrite>> newValue = Objects.<Possible<List<PermissionOverwrite>>>requireNonNull(possible);
/* 169 */     return validate(new StoreChannelEditSpec(this.reason, name(), position(), newValue, parentId()));
/*     */   }
/*     */   
/*     */   public StoreChannelEditSpec withPermissionOverwrites(Iterable<PermissionOverwrite> elements) {
/* 173 */     Possible<List<PermissionOverwrite>> newValue = Possible.of(
/* 174 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/* 175 */     return validate(new StoreChannelEditSpec(this.reason, name(), position(), newValue, parentId()));
/*     */   }
/*     */   
/*     */   @SafeVarargs
/*     */   public final StoreChannelEditSpec withPermissionOverwrites(PermissionOverwrite... elements) {
/* 180 */     Possible<List<PermissionOverwrite>> newValue = Possible.of(Arrays.asList(elements));
/* 181 */     return validate(new StoreChannelEditSpec(this.reason, name(), position(), newValue, parentId()));
/*     */   }
/*     */   
/*     */   public StoreChannelEditSpec withParentId(Possible<Optional<Snowflake>> value) {
/* 185 */     Possible<Optional<Snowflake>> newValue = Objects.<Possible<Optional<Snowflake>>>requireNonNull(value);
/* 186 */     return validate(new StoreChannelEditSpec(this.reason, name(), position(), permissionOverwrites(), newValue));
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public StoreChannelEditSpec withParentId(@Nullable Snowflake value) {
/* 191 */     Possible<Optional<Snowflake>> newValue = Possible.of(Optional.ofNullable(value));
/* 192 */     return validate(new StoreChannelEditSpec(this.reason, name(), position(), permissionOverwrites(), newValue));
/*     */   }
/*     */   
/*     */   public StoreChannelEditSpec withParentIdOrNull(@Nullable Snowflake value) {
/* 196 */     Possible<Optional<Snowflake>> newValue = Possible.of(Optional.ofNullable(value));
/* 197 */     return validate(new StoreChannelEditSpec(this.reason, name(), position(), permissionOverwrites(), newValue));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 206 */     if (this == another) return true; 
/* 207 */     return (another instanceof StoreChannelEditSpec && 
/* 208 */       equalTo(0, (StoreChannelEditSpec)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, StoreChannelEditSpec another) {
/* 212 */     return (Objects.equals(this.reason, another.reason) && 
/* 213 */       name().equals(another.name()) && 
/* 214 */       position().equals(another.position()) && 
/* 215 */       Objects.equals(this.permissionOverwrites_value, another.permissionOverwrites_value) && 
/* 216 */       parentId().equals(another.parentId()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 225 */     int h = 5381;
/* 226 */     h += (h << 5) + Objects.hashCode(this.reason);
/* 227 */     h += (h << 5) + name().hashCode();
/* 228 */     h += (h << 5) + position().hashCode();
/* 229 */     h += (h << 5) + Objects.hashCode(this.permissionOverwrites_value);
/* 230 */     h += (h << 5) + parentId().hashCode();
/* 231 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 240 */     return "StoreChannelEditSpec{reason=" + this.reason + ", name=" + 
/*     */       
/* 242 */       name().toString() + ", position=" + 
/* 243 */       position().toString() + ", permissionOverwrites=" + 
/* 244 */       Objects.toString(this.permissionOverwrites_value) + ", parentId=" + 
/* 245 */       parentId().toString() + "}";
/*     */   }
/*     */ 
/*     */   
/* 249 */   private static final StoreChannelEditSpec INSTANCE = validate(new StoreChannelEditSpec());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static StoreChannelEditSpec create() {
/* 256 */     return INSTANCE;
/*     */   }
/*     */   
/*     */   private static StoreChannelEditSpec validate(StoreChannelEditSpec instance) {
/* 260 */     return (INSTANCE != null && INSTANCE.equalTo(0, instance)) ? INSTANCE : instance;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static StoreChannelEditSpec copyOf(StoreChannelEditSpecGenerator instance) {
/* 271 */     if (instance instanceof StoreChannelEditSpec) {
/* 272 */       return (StoreChannelEditSpec)instance;
/*     */     }
/* 274 */     return builder()
/* 275 */       .from(instance)
/* 276 */       .build();
/*     */   }
/*     */   
/*     */   public boolean isNamePresent() {
/* 280 */     return !this.name_absent;
/*     */   }
/*     */   
/*     */   public String nameOrElse(String defaultValue) {
/* 284 */     return !this.name_absent ? this.name_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isPositionPresent() {
/* 288 */     return !this.position_absent;
/*     */   }
/*     */   
/*     */   public Integer positionOrElse(Integer defaultValue) {
/* 292 */     return !this.position_absent ? this.position_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isPermissionOverwritesPresent() {
/* 296 */     return !this.permissionOverwrites_absent;
/*     */   }
/*     */   
/*     */   public List<PermissionOverwrite> permissionOverwritesOrElse(List<PermissionOverwrite> defaultValue) {
/* 300 */     return !this.permissionOverwrites_absent ? this.permissionOverwrites_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isParentIdPresent() {
/* 304 */     return !this.parentId_absent;
/*     */   }
/*     */   
/*     */   public Snowflake parentIdOrElse(Snowflake defaultValue) {
/* 308 */     return !this.parentId_absent ? this.parentId_value : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 325 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "StoreChannelEditSpecGenerator", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/* 337 */     private Possible<String> name_possible = Possible.absent();
/* 338 */     private Possible<Integer> position_possible = Possible.absent();
/* 339 */     private List<PermissionOverwrite> permissionOverwrites_list = null;
/* 340 */     private Possible<Optional<Snowflake>> parentId_possible = Possible.absent();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private String reason;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(StoreChannelEditSpec instance) {
/* 354 */       return from(instance);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     final Builder from(StoreChannelEditSpecGenerator instance) {
/* 364 */       Objects.requireNonNull(instance, "instance");
/* 365 */       String reasonValue = instance.reason();
/* 366 */       if (reasonValue != null) {
/* 367 */         reason(reasonValue);
/*     */       }
/* 369 */       name(instance.name());
/* 370 */       position(instance.position());
/* 371 */       permissionOverwrites(instance.permissionOverwrites());
/* 372 */       parentId(instance.parentId());
/* 373 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder reason(@Nullable String reason) {
/* 383 */       this.reason = reason;
/* 384 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder name(Possible<String> value) {
/* 389 */       this.name_possible = value;
/* 390 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder name(String value) {
/* 395 */       this.name_possible = Possible.of(value);
/* 396 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder position(Possible<Integer> value) {
/* 401 */       this.position_possible = value;
/* 402 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder position(Integer value) {
/* 407 */       this.position_possible = Possible.of(value);
/* 408 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder addPermissionOverwrite(PermissionOverwrite element) {
/* 413 */       permissionOverwrites_getOrCreate().add(element);
/* 414 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder addAllPermissionOverwrites(List<PermissionOverwrite> elements) {
/* 419 */       permissionOverwrites_getOrCreate().addAll(elements);
/* 420 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder permissionOverwrites(Possible<List<PermissionOverwrite>> elements) {
/* 425 */       this.permissionOverwrites_list = null;
/* 426 */       elements.toOptional().ifPresent(e -> permissionOverwrites_getOrCreate().addAll(e));
/* 427 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder permissionOverwrites(List<PermissionOverwrite> elements) {
/* 432 */       this.permissionOverwrites_list = new ArrayList<>(elements);
/* 433 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder permissionOverwrites(Iterable<PermissionOverwrite> elements) {
/* 438 */       this.permissionOverwrites_list = (List<PermissionOverwrite>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/* 439 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder parentId(Possible<Optional<Snowflake>> value) {
/* 444 */       this.parentId_possible = value;
/* 445 */       return this;
/*     */     }
/*     */     
/*     */     @Deprecated
/*     */     @CanIgnoreReturnValue
/*     */     public Builder parentId(@Nullable Snowflake value) {
/* 451 */       this.parentId_possible = Possible.of(Optional.ofNullable(value));
/* 452 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder parentIdOrNull(@Nullable Snowflake value) {
/* 457 */       this.parentId_possible = Possible.of(Optional.ofNullable(value));
/* 458 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public StoreChannelEditSpec build() {
/* 467 */       return StoreChannelEditSpec.validate(new StoreChannelEditSpec(this.reason, name_build(), position_build(), permissionOverwrites_build(), parentId_build()));
/*     */     }
/*     */     
/*     */     private Possible<String> name_build() {
/* 471 */       return this.name_possible;
/*     */     }
/*     */     
/*     */     private Possible<Integer> position_build() {
/* 475 */       return this.position_possible;
/*     */     }
/*     */     
/*     */     private Possible<List<PermissionOverwrite>> permissionOverwrites_build() {
/* 479 */       return (this.permissionOverwrites_list == null) ? Possible.absent() : 
/* 480 */         Possible.of(this.permissionOverwrites_list);
/*     */     }
/*     */     
/*     */     private List<PermissionOverwrite> permissionOverwrites_getOrCreate() {
/* 484 */       if (this.permissionOverwrites_list == null) {
/* 485 */         this.permissionOverwrites_list = new ArrayList<>();
/*     */       }
/* 487 */       return this.permissionOverwrites_list;
/*     */     }
/*     */     
/*     */     private Possible<Optional<Snowflake>> parentId_build() {
/* 491 */       return this.parentId_possible;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\StoreChannelEditSpec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */