/*     */ package discord4j.core.spec;
/*     */ 
/*     */ import com.google.errorprone.annotations.CanIgnoreReturnValue;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "ScheduledEventEntityMetadataSpecGenerator", generator = "Immutables")
/*     */ public final class ScheduledEventEntityMetadataSpec
/*     */   implements ScheduledEventEntityMetadataSpecGenerator
/*     */ {
/*     */   private final String location_value;
/*     */   private final boolean location_absent;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   
/*     */   private ScheduledEventEntityMetadataSpec(Possible<String> location) {
/*  26 */     Possible<String> location$impl = location;
/*  27 */     this.location_value = location$impl.toOptional().orElse(null);
/*  28 */     this.location_absent = location$impl.isAbsent();
/*  29 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  35 */   private volatile transient InitShim initShim = new InitShim();
/*     */   
/*     */   @Generated(from = "ScheduledEventEntityMetadataSpecGenerator", generator = "Immutables")
/*     */   private final class InitShim
/*     */   {
/*     */     private String formatInitCycleMessage() {
/*  41 */       List<String> attributes = new ArrayList<>();
/*  42 */       return "Cannot build ScheduledEventEntityMetadataSpec, attribute initializers form cycle " + attributes;
/*     */     }
/*     */ 
/*     */     
/*     */     private InitShim() {}
/*     */   }
/*     */ 
/*     */   
/*     */   public Possible<String> location() {
/*  51 */     return this.location_absent ? Possible.absent() : Possible.of(this.location_value);
/*     */   }
/*     */   
/*     */   public ScheduledEventEntityMetadataSpec withLocation(Possible<String> value) {
/*  55 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/*  56 */     return new ScheduledEventEntityMetadataSpec(newValue);
/*     */   }
/*     */   
/*     */   public ScheduledEventEntityMetadataSpec withLocation(String value) {
/*  60 */     Possible<String> newValue = Possible.of(value);
/*  61 */     return new ScheduledEventEntityMetadataSpec(newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/*  70 */     if (this == another) return true; 
/*  71 */     return (another instanceof ScheduledEventEntityMetadataSpec && 
/*  72 */       equalTo(0, (ScheduledEventEntityMetadataSpec)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ScheduledEventEntityMetadataSpec another) {
/*  76 */     return location().equals(another.location());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  85 */     int h = 5381;
/*  86 */     h += (h << 5) + location().hashCode();
/*  87 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/*  96 */     return "ScheduledEventEntityMetadataSpec{location=" + 
/*  97 */       location().toString() + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ScheduledEventEntityMetadataSpec copyOf(ScheduledEventEntityMetadataSpecGenerator instance) {
/* 109 */     if (instance instanceof ScheduledEventEntityMetadataSpec) {
/* 110 */       return (ScheduledEventEntityMetadataSpec)instance;
/*     */     }
/* 112 */     return builder()
/* 113 */       .from(instance)
/* 114 */       .build();
/*     */   }
/*     */   
/*     */   public boolean isLocationPresent() {
/* 118 */     return !this.location_absent;
/*     */   }
/*     */   
/*     */   public String locationOrElse(String defaultValue) {
/* 122 */     return !this.location_absent ? this.location_value : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 135 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "ScheduledEventEntityMetadataSpecGenerator", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/* 147 */     private Possible<String> location_possible = Possible.absent();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder from(ScheduledEventEntityMetadataSpecGenerator instance) {
/* 161 */       Objects.requireNonNull(instance, "instance");
/* 162 */       location(instance.location());
/* 163 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder location(Possible<String> value) {
/* 168 */       this.location_possible = value;
/* 169 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder location(String value) {
/* 174 */       this.location_possible = Possible.of(value);
/* 175 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ScheduledEventEntityMetadataSpec build() {
/* 184 */       return new ScheduledEventEntityMetadataSpec(location_build());
/*     */     }
/*     */     
/*     */     private Possible<String> location_build() {
/* 188 */       return this.location_possible;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\ScheduledEventEntityMetadataSpec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */