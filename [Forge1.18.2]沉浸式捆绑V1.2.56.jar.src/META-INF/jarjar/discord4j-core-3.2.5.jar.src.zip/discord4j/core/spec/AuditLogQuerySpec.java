/*     */ package discord4j.core.spec;
/*     */ 
/*     */ import com.google.errorprone.annotations.CanIgnoreReturnValue;
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.object.audit.ActionType;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "AuditLogQuerySpecGenerator", generator = "Immutables")
/*     */ public final class AuditLogQuerySpec
/*     */   implements AuditLogQuerySpecGenerator
/*     */ {
/*     */   @Nullable
/*     */   private final Snowflake userId;
/*     */   @Nullable
/*     */   private final ActionType actionType;
/*     */   @Nullable
/*     */   private final Snowflake before;
/*     */   @Nullable
/*     */   private final Integer limit;
/*     */   
/*     */   private AuditLogQuerySpec() {
/*  29 */     this.userId = null;
/*  30 */     this.actionType = null;
/*  31 */     this.before = null;
/*  32 */     this.limit = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private AuditLogQuerySpec(@Nullable Snowflake userId, @Nullable ActionType actionType, @Nullable Snowflake before, @Nullable Integer limit) {
/*  40 */     this.userId = userId;
/*  41 */     this.actionType = actionType;
/*  42 */     this.before = before;
/*  43 */     this.limit = limit;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Snowflake userId() {
/*  51 */     return this.userId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public ActionType actionType() {
/*  59 */     return this.actionType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Snowflake before() {
/*  67 */     return this.before;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Integer limit() {
/*  75 */     return this.limit;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final AuditLogQuerySpec withUserId(@Nullable Snowflake value) {
/*  85 */     if (this.userId == value) return this; 
/*  86 */     return validate(new AuditLogQuerySpec(value, this.actionType, this.before, this.limit));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final AuditLogQuerySpec withActionType(@Nullable ActionType value) {
/*  96 */     if (this.actionType == value) return this; 
/*  97 */     return validate(new AuditLogQuerySpec(this.userId, value, this.before, this.limit));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final AuditLogQuerySpec withBefore(@Nullable Snowflake value) {
/* 107 */     if (this.before == value) return this; 
/* 108 */     return validate(new AuditLogQuerySpec(this.userId, this.actionType, value, this.limit));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final AuditLogQuerySpec withLimit(@Nullable Integer value) {
/* 118 */     if (Objects.equals(this.limit, value)) return this; 
/* 119 */     return validate(new AuditLogQuerySpec(this.userId, this.actionType, this.before, value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 128 */     if (this == another) return true; 
/* 129 */     return (another instanceof AuditLogQuerySpec && 
/* 130 */       equalTo(0, (AuditLogQuerySpec)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, AuditLogQuerySpec another) {
/* 134 */     return (Objects.equals(this.userId, another.userId) && 
/* 135 */       Objects.equals(this.actionType, another.actionType) && 
/* 136 */       Objects.equals(this.before, another.before) && 
/* 137 */       Objects.equals(this.limit, another.limit));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 146 */     int h = 5381;
/* 147 */     h += (h << 5) + Objects.hashCode(this.userId);
/* 148 */     h += (h << 5) + Objects.hashCode(this.actionType);
/* 149 */     h += (h << 5) + Objects.hashCode(this.before);
/* 150 */     h += (h << 5) + Objects.hashCode(this.limit);
/* 151 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 160 */     return "AuditLogQuerySpec{userId=" + this.userId + ", actionType=" + this.actionType + ", before=" + this.before + ", limit=" + this.limit + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 168 */   private static final AuditLogQuerySpec INSTANCE = validate(new AuditLogQuerySpec());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AuditLogQuerySpec create() {
/* 175 */     return INSTANCE;
/*     */   }
/*     */   
/*     */   private static AuditLogQuerySpec validate(AuditLogQuerySpec instance) {
/* 179 */     return (INSTANCE != null && INSTANCE.equalTo(0, instance)) ? INSTANCE : instance;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static AuditLogQuerySpec copyOf(AuditLogQuerySpecGenerator instance) {
/* 190 */     if (instance instanceof AuditLogQuerySpec) {
/* 191 */       return (AuditLogQuerySpec)instance;
/*     */     }
/* 193 */     return builder()
/* 194 */       .from(instance)
/* 195 */       .build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 211 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "AuditLogQuerySpecGenerator", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private Snowflake userId;
/*     */ 
/*     */ 
/*     */     
/*     */     private ActionType actionType;
/*     */ 
/*     */     
/*     */     private Snowflake before;
/*     */ 
/*     */     
/*     */     private Integer limit;
/*     */ 
/*     */ 
/*     */     
/*     */     private Builder() {}
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(AuditLogQuerySpec instance) {
/* 239 */       return from(instance);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     final Builder from(AuditLogQuerySpecGenerator instance) {
/* 249 */       Objects.requireNonNull(instance, "instance");
/* 250 */       Snowflake userIdValue = instance.userId();
/* 251 */       if (userIdValue != null) {
/* 252 */         userId(userIdValue);
/*     */       }
/* 254 */       ActionType actionTypeValue = instance.actionType();
/* 255 */       if (actionTypeValue != null) {
/* 256 */         actionType(actionTypeValue);
/*     */       }
/* 258 */       Snowflake beforeValue = instance.before();
/* 259 */       if (beforeValue != null) {
/* 260 */         before(beforeValue);
/*     */       }
/* 262 */       Integer limitValue = instance.limit();
/* 263 */       if (limitValue != null) {
/* 264 */         limit(limitValue);
/*     */       }
/* 266 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder userId(@Nullable Snowflake userId) {
/* 276 */       this.userId = userId;
/* 277 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder actionType(@Nullable ActionType actionType) {
/* 287 */       this.actionType = actionType;
/* 288 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder before(@Nullable Snowflake before) {
/* 298 */       this.before = before;
/* 299 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder limit(@Nullable Integer limit) {
/* 309 */       this.limit = limit;
/* 310 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public AuditLogQuerySpec build() {
/* 319 */       return AuditLogQuerySpec.validate(new AuditLogQuerySpec(this.userId, this.actionType, this.before, this.limit));
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\AuditLogQuerySpec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */