/*    */ package discord4j.core.spec;
/*    */ 
/*    */ import discord4j.common.util.Snowflake;
/*    */ import discord4j.core.object.Invite;
/*    */ import discord4j.discordjson.json.InviteCreateRequest;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Immutable(singleton = true)
/*    */ interface InviteCreateSpecGenerator
/*    */   extends AuditSpec<InviteCreateRequest>
/*    */ {
/*    */   default InviteCreateRequest asRequest() {
/* 51 */     return (InviteCreateRequest)InviteCreateRequest.builder()
/* 52 */       .maxAge(maxAge())
/* 53 */       .maxUses(maxUses())
/* 54 */       .temporary(temporary())
/* 55 */       .unique(unique())
/* 56 */       .targetType(InternalSpecUtils.mapPossible(targetType(), Invite.Type::getValue))
/* 57 */       .targetUserId(InternalSpecUtils.mapPossible(targetUserId(), Snowflake::asString))
/* 58 */       .targetApplicationId(InternalSpecUtils.mapPossible(targetApplicationId(), Snowflake::asString))
/* 59 */       .build();
/*    */   }
/*    */   
/*    */   Possible<Snowflake> targetApplicationId();
/*    */   
/*    */   Possible<Snowflake> targetUserId();
/*    */   
/*    */   Possible<Invite.Type> targetType();
/*    */   
/*    */   Possible<Boolean> unique();
/*    */   
/*    */   Possible<Boolean> temporary();
/*    */   
/*    */   Possible<Integer> maxUses();
/*    */   
/*    */   Possible<Integer> maxAge();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\InviteCreateSpecGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */