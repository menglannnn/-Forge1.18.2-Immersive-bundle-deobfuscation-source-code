/*    */ package discord4j.core.spec;
/*    */ 
/*    */ import discord4j.common.util.Snowflake;
/*    */ import discord4j.rest.util.Multimap;
/*    */ import java.util.List;
/*    */ import java.util.Set;
/*    */ import java.util.stream.Collectors;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Immutable
/*    */ interface GuildPruneSpecGenerator
/*    */   extends AuditSpec<Multimap<String, Object>>
/*    */ {
/*    */   default Multimap<String, Object> asRequest() {
/* 47 */     Multimap<String, Object> map = new Multimap();
/* 48 */     InternalSpecUtils.setIfNotNull(map, "days", days());
/* 49 */     InternalSpecUtils.addAllIfNotNull(map, "include_roles", InternalSpecUtils.<Set<Snowflake>, List<Object>>mapNullable(roles(), r -> (List)r.stream().map(Snowflake::asString).collect(Collectors.toList())));
/*    */ 
/*    */     
/* 52 */     InternalSpecUtils.setIfNotNull(map, "compute_prune_count", computePruneCount());
/* 53 */     return map;
/*    */   }
/*    */   
/*    */   Integer days();
/*    */   
/*    */   @Nullable
/*    */   Set<Snowflake> roles();
/*    */   
/*    */   @Nullable
/*    */   Boolean computePruneCount();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\GuildPruneSpecGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */