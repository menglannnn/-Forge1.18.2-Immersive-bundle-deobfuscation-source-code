/*     */ package discord4j.core.spec;
/*     */ 
/*     */ import com.google.errorprone.annotations.CanIgnoreReturnValue;
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.stream.StreamSupport;
/*     */ import org.immutables.value.Generated;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "GuildEmojiEditSpecGenerator", generator = "Immutables")
/*     */ public final class GuildEmojiEditSpec
/*     */   implements GuildEmojiEditSpecGenerator
/*     */ {
/*     */   @Nullable
/*     */   private final String reason;
/*     */   private final String name_value;
/*     */   private final boolean name_absent;
/*     */   private final List<Snowflake> roles_value;
/*     */   private final boolean roles_absent;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   
/*     */   private GuildEmojiEditSpec() {
/*  35 */     this.reason = null;
/*  36 */     Possible<String> name$impl = Possible.absent();
/*  37 */     Possible<List<Snowflake>> roles$impl = Possible.absent();
/*  38 */     this.name_value = name$impl.toOptional().orElse(null);
/*  39 */     this.name_absent = name$impl.isAbsent();
/*  40 */     this.roles_value = roles$impl.toOptional().orElse(null);
/*  41 */     this.roles_absent = roles$impl.isAbsent();
/*  42 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private GuildEmojiEditSpec(@Nullable String reason, Possible<String> name, Possible<List<Snowflake>> roles) {
/*  49 */     this.reason = reason;
/*  50 */     Possible<String> name$impl = name;
/*  51 */     Possible<List<Snowflake>> roles$impl = roles;
/*  52 */     this.name_value = name$impl.toOptional().orElse(null);
/*  53 */     this.name_absent = name$impl.isAbsent();
/*  54 */     this.roles_value = roles$impl.toOptional().orElse(null);
/*  55 */     this.roles_absent = roles$impl.isAbsent();
/*  56 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  62 */   private volatile transient InitShim initShim = new InitShim();
/*     */   
/*     */   @Generated(from = "GuildEmojiEditSpecGenerator", generator = "Immutables")
/*     */   private final class InitShim
/*     */   {
/*     */     private String formatInitCycleMessage() {
/*  68 */       List<String> attributes = new ArrayList<>();
/*  69 */       return "Cannot build GuildEmojiEditSpec, attribute initializers form cycle " + attributes;
/*     */     }
/*     */ 
/*     */     
/*     */     private InitShim() {}
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String reason() {
/*  79 */     return this.reason;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<String> name() {
/*  87 */     return this.name_absent ? Possible.absent() : Possible.of(this.name_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<List<Snowflake>> roles() {
/*  95 */     return this.roles_absent ? Possible.absent() : 
/*  96 */       Possible.of(this.roles_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final GuildEmojiEditSpec withReason(@Nullable String value) {
/* 106 */     if (Objects.equals(this.reason, value)) return this; 
/* 107 */     return validate(new GuildEmojiEditSpec(value, name(), roles()));
/*     */   }
/*     */   
/*     */   public GuildEmojiEditSpec withName(Possible<String> value) {
/* 111 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/* 112 */     return validate(new GuildEmojiEditSpec(this.reason, newValue, roles()));
/*     */   }
/*     */   
/*     */   public GuildEmojiEditSpec withName(String value) {
/* 116 */     Possible<String> newValue = Possible.of(value);
/* 117 */     return validate(new GuildEmojiEditSpec(this.reason, newValue, roles()));
/*     */   }
/*     */   
/*     */   public GuildEmojiEditSpec withRoles(Possible<List<Snowflake>> possible) {
/* 121 */     Possible<List<Snowflake>> newValue = Objects.<Possible<List<Snowflake>>>requireNonNull(possible);
/* 122 */     return validate(new GuildEmojiEditSpec(this.reason, name(), newValue));
/*     */   }
/*     */   
/*     */   public GuildEmojiEditSpec withRoles(Iterable<Snowflake> elements) {
/* 126 */     Possible<List<Snowflake>> newValue = Possible.of(
/* 127 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/* 128 */     return validate(new GuildEmojiEditSpec(this.reason, name(), newValue));
/*     */   }
/*     */   
/*     */   @SafeVarargs
/*     */   public final GuildEmojiEditSpec withRoles(Snowflake... elements) {
/* 133 */     Possible<List<Snowflake>> newValue = Possible.of(Arrays.asList(elements));
/* 134 */     return validate(new GuildEmojiEditSpec(this.reason, name(), newValue));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 143 */     if (this == another) return true; 
/* 144 */     return (another instanceof GuildEmojiEditSpec && 
/* 145 */       equalTo(0, (GuildEmojiEditSpec)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, GuildEmojiEditSpec another) {
/* 149 */     return (Objects.equals(this.reason, another.reason) && 
/* 150 */       name().equals(another.name()) && 
/* 151 */       Objects.equals(this.roles_value, another.roles_value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 160 */     int h = 5381;
/* 161 */     h += (h << 5) + Objects.hashCode(this.reason);
/* 162 */     h += (h << 5) + name().hashCode();
/* 163 */     h += (h << 5) + Objects.hashCode(this.roles_value);
/* 164 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 173 */     return "GuildEmojiEditSpec{reason=" + this.reason + ", name=" + 
/*     */       
/* 175 */       name().toString() + ", roles=" + 
/* 176 */       Objects.toString(this.roles_value) + "}";
/*     */   }
/*     */ 
/*     */   
/* 180 */   private static final GuildEmojiEditSpec INSTANCE = validate(new GuildEmojiEditSpec());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static GuildEmojiEditSpec create() {
/* 187 */     return INSTANCE;
/*     */   }
/*     */   
/*     */   private static GuildEmojiEditSpec validate(GuildEmojiEditSpec instance) {
/* 191 */     return (INSTANCE != null && INSTANCE.equalTo(0, instance)) ? INSTANCE : instance;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static GuildEmojiEditSpec copyOf(GuildEmojiEditSpecGenerator instance) {
/* 202 */     if (instance instanceof GuildEmojiEditSpec) {
/* 203 */       return (GuildEmojiEditSpec)instance;
/*     */     }
/* 205 */     return builder()
/* 206 */       .from(instance)
/* 207 */       .build();
/*     */   }
/*     */   
/*     */   public boolean isNamePresent() {
/* 211 */     return !this.name_absent;
/*     */   }
/*     */   
/*     */   public String nameOrElse(String defaultValue) {
/* 215 */     return !this.name_absent ? this.name_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isRolesPresent() {
/* 219 */     return !this.roles_absent;
/*     */   }
/*     */   
/*     */   public List<Snowflake> rolesOrElse(List<Snowflake> defaultValue) {
/* 223 */     return !this.roles_absent ? this.roles_value : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 238 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "GuildEmojiEditSpecGenerator", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/* 250 */     private Possible<String> name_possible = Possible.absent();
/* 251 */     private List<Snowflake> roles_list = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private String reason;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(GuildEmojiEditSpec instance) {
/* 265 */       return from(instance);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     final Builder from(GuildEmojiEditSpecGenerator instance) {
/* 275 */       Objects.requireNonNull(instance, "instance");
/* 276 */       String reasonValue = instance.reason();
/* 277 */       if (reasonValue != null) {
/* 278 */         reason(reasonValue);
/*     */       }
/* 280 */       name(instance.name());
/* 281 */       roles(instance.roles());
/* 282 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder reason(@Nullable String reason) {
/* 292 */       this.reason = reason;
/* 293 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder name(Possible<String> value) {
/* 298 */       this.name_possible = value;
/* 299 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder name(String value) {
/* 304 */       this.name_possible = Possible.of(value);
/* 305 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder addRole(Snowflake element) {
/* 310 */       roles_getOrCreate().add(element);
/* 311 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder addAllRoles(List<Snowflake> elements) {
/* 316 */       roles_getOrCreate().addAll(elements);
/* 317 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder roles(Possible<List<Snowflake>> elements) {
/* 322 */       this.roles_list = null;
/* 323 */       elements.toOptional().ifPresent(e -> roles_getOrCreate().addAll(e));
/* 324 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder roles(List<Snowflake> elements) {
/* 329 */       this.roles_list = new ArrayList<>(elements);
/* 330 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder roles(Iterable<Snowflake> elements) {
/* 335 */       this.roles_list = (List<Snowflake>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/* 336 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public GuildEmojiEditSpec build() {
/* 345 */       return GuildEmojiEditSpec.validate(new GuildEmojiEditSpec(this.reason, name_build(), roles_build()));
/*     */     }
/*     */     
/*     */     private Possible<String> name_build() {
/* 349 */       return this.name_possible;
/*     */     }
/*     */     
/*     */     private Possible<List<Snowflake>> roles_build() {
/* 353 */       return (this.roles_list == null) ? Possible.absent() : 
/* 354 */         Possible.of(this.roles_list);
/*     */     }
/*     */     
/*     */     private List<Snowflake> roles_getOrCreate() {
/* 358 */       if (this.roles_list == null) {
/* 359 */         this.roles_list = new ArrayList<>();
/*     */       }
/* 361 */       return this.roles_list;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\GuildEmojiEditSpec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */