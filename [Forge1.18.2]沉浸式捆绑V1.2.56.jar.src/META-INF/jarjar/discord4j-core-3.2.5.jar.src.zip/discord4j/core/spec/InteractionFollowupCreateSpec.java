/*      */ package discord4j.core.spec;
/*      */ 
/*      */ import com.google.errorprone.annotations.CanIgnoreReturnValue;
/*      */ import discord4j.core.object.component.LayoutComponent;
/*      */ import discord4j.discordjson.possible.Possible;
/*      */ import discord4j.rest.util.AllowedMentions;
/*      */ import java.io.InputStream;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.List;
/*      */ import java.util.Objects;
/*      */ import java.util.stream.Collectors;
/*      */ import java.util.stream.StreamSupport;
/*      */ import org.immutables.value.Generated;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ @Generated(from = "InteractionFollowupCreateSpecGenerator", generator = "Immutables")
/*      */ public final class InteractionFollowupCreateSpec
/*      */   implements InteractionFollowupCreateSpecGenerator
/*      */ {
/*      */   private final String content_value;
/*      */   private final boolean content_absent;
/*      */   private final String username_value;
/*      */   private final boolean username_absent;
/*      */   private final String avatarUrl_value;
/*      */   private final boolean avatarUrl_absent;
/*      */   private final boolean tts;
/*      */   private final List<MessageCreateFields.File> files;
/*      */   private final List<MessageCreateFields.FileSpoiler> fileSpoilers;
/*      */   private final List<EmbedCreateSpec> embeds;
/*      */   private final AllowedMentions allowedMentions_value;
/*      */   private final boolean allowedMentions_absent;
/*      */   private final List<LayoutComponent> components_value;
/*      */   private final boolean components_absent;
/*      */   private final Boolean ephemeral_value;
/*      */   private final boolean ephemeral_absent;
/*      */   private static final byte STAGE_INITIALIZING = -1;
/*      */   private static final byte STAGE_UNINITIALIZED = 0;
/*      */   private static final byte STAGE_INITIALIZED = 1;
/*      */   
/*      */   private InteractionFollowupCreateSpec() {
/*   50 */     Possible<String> content$impl = Possible.absent();
/*   51 */     Possible<String> username$impl = Possible.absent();
/*   52 */     Possible<String> avatarUrl$impl = Possible.absent();
/*   53 */     Possible<AllowedMentions> allowedMentions$impl = Possible.absent();
/*   54 */     Possible<List<LayoutComponent>> components$impl = Possible.absent();
/*   55 */     Possible<Boolean> ephemeral$impl = Possible.absent();
/*   56 */     this.content_value = content$impl.toOptional().orElse(null);
/*   57 */     this.content_absent = content$impl.isAbsent();
/*   58 */     this.username_value = username$impl.toOptional().orElse(null);
/*   59 */     this.username_absent = username$impl.isAbsent();
/*   60 */     this.avatarUrl_value = avatarUrl$impl.toOptional().orElse(null);
/*   61 */     this.avatarUrl_absent = avatarUrl$impl.isAbsent();
/*   62 */     this.allowedMentions_value = allowedMentions$impl.toOptional().orElse(null);
/*   63 */     this.allowedMentions_absent = allowedMentions$impl.isAbsent();
/*   64 */     this.components_value = components$impl.toOptional().orElse(null);
/*   65 */     this.components_absent = components$impl.isAbsent();
/*   66 */     this.ephemeral_value = ephemeral$impl.toOptional().orElse(null);
/*   67 */     this.ephemeral_absent = ephemeral$impl.isAbsent();
/*   68 */     this.tts = this.initShim.tts();
/*   69 */     this.files = this.initShim.files();
/*   70 */     this.fileSpoilers = this.initShim.fileSpoilers();
/*   71 */     this.embeds = this.initShim.embeds();
/*   72 */     this.initShim = null;
/*      */   }
/*      */   
/*      */   private InteractionFollowupCreateSpec(Builder builder) {
/*   76 */     Possible<String> content$impl = builder.content_build();
/*   77 */     Possible<String> username$impl = builder.username_build();
/*   78 */     Possible<String> avatarUrl$impl = builder.avatarUrl_build();
/*   79 */     Possible<AllowedMentions> allowedMentions$impl = builder.allowedMentions_build();
/*   80 */     Possible<List<LayoutComponent>> components$impl = builder.components_build();
/*   81 */     Possible<Boolean> ephemeral$impl = builder.ephemeral_build();
/*   82 */     if (builder.ttsIsSet()) {
/*   83 */       this.initShim.tts(builder.tts);
/*      */     }
/*   85 */     if (builder.filesIsSet()) {
/*   86 */       this.initShim.files(createUnmodifiableList(true, builder.files));
/*      */     }
/*   88 */     if (builder.fileSpoilersIsSet()) {
/*   89 */       this.initShim.fileSpoilers(createUnmodifiableList(true, builder.fileSpoilers));
/*      */     }
/*   91 */     if (builder.embedsIsSet()) {
/*   92 */       this.initShim.embeds(createUnmodifiableList(true, builder.embeds));
/*      */     }
/*   94 */     this.content_value = content$impl.toOptional().orElse(null);
/*   95 */     this.content_absent = content$impl.isAbsent();
/*   96 */     this.username_value = username$impl.toOptional().orElse(null);
/*   97 */     this.username_absent = username$impl.isAbsent();
/*   98 */     this.avatarUrl_value = avatarUrl$impl.toOptional().orElse(null);
/*   99 */     this.avatarUrl_absent = avatarUrl$impl.isAbsent();
/*  100 */     this.allowedMentions_value = allowedMentions$impl.toOptional().orElse(null);
/*  101 */     this.allowedMentions_absent = allowedMentions$impl.isAbsent();
/*  102 */     this.components_value = components$impl.toOptional().orElse(null);
/*  103 */     this.components_absent = components$impl.isAbsent();
/*  104 */     this.ephemeral_value = ephemeral$impl.toOptional().orElse(null);
/*  105 */     this.ephemeral_absent = ephemeral$impl.isAbsent();
/*  106 */     this.tts = this.initShim.tts();
/*  107 */     this.files = this.initShim.files();
/*  108 */     this.fileSpoilers = this.initShim.fileSpoilers();
/*  109 */     this.embeds = this.initShim.embeds();
/*  110 */     this.initShim = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private InteractionFollowupCreateSpec(Possible<String> content, Possible<String> username, Possible<String> avatarUrl, boolean tts, List<MessageCreateFields.File> files, List<MessageCreateFields.FileSpoiler> fileSpoilers, List<EmbedCreateSpec> embeds, Possible<AllowedMentions> allowedMentions, Possible<List<LayoutComponent>> components, Possible<Boolean> ephemeral) {
/*  124 */     Possible<String> content$impl = content;
/*  125 */     Possible<String> username$impl = username;
/*  126 */     Possible<String> avatarUrl$impl = avatarUrl;
/*  127 */     this.initShim.tts(tts);
/*  128 */     this.initShim.files(files);
/*  129 */     this.initShim.fileSpoilers(fileSpoilers);
/*  130 */     this.initShim.embeds(embeds);
/*  131 */     Possible<AllowedMentions> allowedMentions$impl = allowedMentions;
/*  132 */     Possible<List<LayoutComponent>> components$impl = components;
/*  133 */     Possible<Boolean> ephemeral$impl = ephemeral;
/*  134 */     this.content_value = content$impl.toOptional().orElse(null);
/*  135 */     this.content_absent = content$impl.isAbsent();
/*  136 */     this.username_value = username$impl.toOptional().orElse(null);
/*  137 */     this.username_absent = username$impl.isAbsent();
/*  138 */     this.avatarUrl_value = avatarUrl$impl.toOptional().orElse(null);
/*  139 */     this.avatarUrl_absent = avatarUrl$impl.isAbsent();
/*  140 */     this.allowedMentions_value = allowedMentions$impl.toOptional().orElse(null);
/*  141 */     this.allowedMentions_absent = allowedMentions$impl.isAbsent();
/*  142 */     this.components_value = components$impl.toOptional().orElse(null);
/*  143 */     this.components_absent = components$impl.isAbsent();
/*  144 */     this.ephemeral_value = ephemeral$impl.toOptional().orElse(null);
/*  145 */     this.ephemeral_absent = ephemeral$impl.isAbsent();
/*  146 */     this.tts = this.initShim.tts();
/*  147 */     this.files = this.initShim.files();
/*  148 */     this.fileSpoilers = this.initShim.fileSpoilers();
/*  149 */     this.embeds = this.initShim.embeds();
/*  150 */     this.initShim = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  156 */   private volatile transient InitShim initShim = new InitShim();
/*      */   
/*      */   @Generated(from = "InteractionFollowupCreateSpecGenerator", generator = "Immutables")
/*      */   private final class InitShim
/*      */   {
/*  161 */     private byte ttsBuildStage = 0;
/*      */     private boolean tts;
/*      */     
/*      */     boolean tts() {
/*  165 */       if (this.ttsBuildStage == -1) throw new IllegalStateException(formatInitCycleMessage()); 
/*  166 */       if (this.ttsBuildStage == 0) {
/*  167 */         this.ttsBuildStage = -1;
/*  168 */         this.tts = InteractionFollowupCreateSpec.this.ttsInitialize();
/*  169 */         this.ttsBuildStage = 1;
/*      */       } 
/*  171 */       return this.tts;
/*      */     }
/*      */     
/*      */     void tts(boolean tts) {
/*  175 */       this.tts = tts;
/*  176 */       this.ttsBuildStage = 1;
/*      */     }
/*      */     
/*  179 */     private byte filesBuildStage = 0;
/*      */     private List<MessageCreateFields.File> files;
/*      */     
/*      */     List<MessageCreateFields.File> files() {
/*  183 */       if (this.filesBuildStage == -1) throw new IllegalStateException(formatInitCycleMessage()); 
/*  184 */       if (this.filesBuildStage == 0) {
/*  185 */         this.filesBuildStage = -1;
/*  186 */         this.files = (List)InteractionFollowupCreateSpec.createUnmodifiableList(false, InteractionFollowupCreateSpec.createSafeList((Iterable)InteractionFollowupCreateSpec.this.filesInitialize(), true, false));
/*  187 */         this.filesBuildStage = 1;
/*      */       } 
/*  189 */       return this.files;
/*      */     }
/*      */     
/*      */     void files(List<MessageCreateFields.File> files) {
/*  193 */       this.files = files;
/*  194 */       this.filesBuildStage = 1;
/*      */     }
/*      */     
/*  197 */     private byte fileSpoilersBuildStage = 0;
/*      */     private List<MessageCreateFields.FileSpoiler> fileSpoilers;
/*      */     
/*      */     List<MessageCreateFields.FileSpoiler> fileSpoilers() {
/*  201 */       if (this.fileSpoilersBuildStage == -1) throw new IllegalStateException(formatInitCycleMessage()); 
/*  202 */       if (this.fileSpoilersBuildStage == 0) {
/*  203 */         this.fileSpoilersBuildStage = -1;
/*  204 */         this.fileSpoilers = (List)InteractionFollowupCreateSpec.createUnmodifiableList(false, InteractionFollowupCreateSpec.createSafeList((Iterable)InteractionFollowupCreateSpec.this.fileSpoilersInitialize(), true, false));
/*  205 */         this.fileSpoilersBuildStage = 1;
/*      */       } 
/*  207 */       return this.fileSpoilers;
/*      */     }
/*      */     
/*      */     void fileSpoilers(List<MessageCreateFields.FileSpoiler> fileSpoilers) {
/*  211 */       this.fileSpoilers = fileSpoilers;
/*  212 */       this.fileSpoilersBuildStage = 1;
/*      */     }
/*      */     
/*  215 */     private byte embedsBuildStage = 0;
/*      */     private List<EmbedCreateSpec> embeds;
/*      */     
/*      */     List<EmbedCreateSpec> embeds() {
/*  219 */       if (this.embedsBuildStage == -1) throw new IllegalStateException(formatInitCycleMessage()); 
/*  220 */       if (this.embedsBuildStage == 0) {
/*  221 */         this.embedsBuildStage = -1;
/*  222 */         this.embeds = (List)InteractionFollowupCreateSpec.createUnmodifiableList(false, InteractionFollowupCreateSpec.createSafeList((Iterable)InteractionFollowupCreateSpec.this.embedsInitialize(), true, false));
/*  223 */         this.embedsBuildStage = 1;
/*      */       } 
/*  225 */       return this.embeds;
/*      */     }
/*      */     
/*      */     void embeds(List<EmbedCreateSpec> embeds) {
/*  229 */       this.embeds = embeds;
/*  230 */       this.embedsBuildStage = 1;
/*      */     }
/*      */     private InitShim() {}
/*      */     private String formatInitCycleMessage() {
/*  234 */       List<String> attributes = new ArrayList<>();
/*  235 */       if (this.ttsBuildStage == -1) attributes.add("tts"); 
/*  236 */       if (this.filesBuildStage == -1) attributes.add("files"); 
/*  237 */       if (this.fileSpoilersBuildStage == -1) attributes.add("fileSpoilers"); 
/*  238 */       if (this.embedsBuildStage == -1) attributes.add("embeds"); 
/*  239 */       return "Cannot build InteractionFollowupCreateSpec, attribute initializers form cycle " + attributes;
/*      */     }
/*      */   }
/*      */   
/*      */   private boolean ttsInitialize() {
/*  244 */     return super.tts();
/*      */   }
/*      */   
/*      */   private List<MessageCreateFields.File> filesInitialize() {
/*  248 */     return super.files();
/*      */   }
/*      */   
/*      */   private List<MessageCreateFields.FileSpoiler> fileSpoilersInitialize() {
/*  252 */     return super.fileSpoilers();
/*      */   }
/*      */   
/*      */   private List<EmbedCreateSpec> embedsInitialize() {
/*  256 */     return super.embeds();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Possible<String> content() {
/*  264 */     return this.content_absent ? Possible.absent() : Possible.of(this.content_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Possible<String> username() {
/*  272 */     return this.username_absent ? Possible.absent() : Possible.of(this.username_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Possible<String> avatarUrl() {
/*  280 */     return this.avatarUrl_absent ? Possible.absent() : Possible.of(this.avatarUrl_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean tts() {
/*  288 */     InitShim shim = this.initShim;
/*  289 */     return (shim != null) ? 
/*  290 */       shim.tts() : 
/*  291 */       this.tts;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<MessageCreateFields.File> files() {
/*  299 */     InitShim shim = this.initShim;
/*  300 */     return (shim != null) ? 
/*  301 */       shim.files() : 
/*  302 */       this.files;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<MessageCreateFields.FileSpoiler> fileSpoilers() {
/*  310 */     InitShim shim = this.initShim;
/*  311 */     return (shim != null) ? 
/*  312 */       shim.fileSpoilers() : 
/*  313 */       this.fileSpoilers;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<EmbedCreateSpec> embeds() {
/*  321 */     InitShim shim = this.initShim;
/*  322 */     return (shim != null) ? 
/*  323 */       shim.embeds() : 
/*  324 */       this.embeds;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Possible<AllowedMentions> allowedMentions() {
/*  332 */     return this.allowedMentions_absent ? Possible.absent() : Possible.of(this.allowedMentions_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Possible<List<LayoutComponent>> components() {
/*  340 */     return this.components_absent ? Possible.absent() : 
/*  341 */       Possible.of(this.components_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Possible<Boolean> ephemeral() {
/*  349 */     return this.ephemeral_absent ? Possible.absent() : Possible.of(this.ephemeral_value);
/*      */   }
/*      */   
/*      */   public InteractionFollowupCreateSpec withContent(Possible<String> value) {
/*  353 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/*  354 */     return validate(new InteractionFollowupCreateSpec(newValue, 
/*      */           
/*  356 */           username(), 
/*  357 */           avatarUrl(), this.tts, this.files, this.fileSpoilers, this.embeds, 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  362 */           allowedMentions(), 
/*  363 */           components(), 
/*  364 */           ephemeral()));
/*      */   }
/*      */   
/*      */   public InteractionFollowupCreateSpec withContent(String value) {
/*  368 */     Possible<String> newValue = Possible.of(value);
/*  369 */     return validate(new InteractionFollowupCreateSpec(newValue, 
/*      */           
/*  371 */           username(), 
/*  372 */           avatarUrl(), this.tts, this.files, this.fileSpoilers, this.embeds, 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  377 */           allowedMentions(), 
/*  378 */           components(), 
/*  379 */           ephemeral()));
/*      */   }
/*      */   
/*      */   public InteractionFollowupCreateSpec withUsername(Possible<String> value) {
/*  383 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/*  384 */     return validate(new InteractionFollowupCreateSpec(
/*  385 */           content(), newValue, 
/*      */           
/*  387 */           avatarUrl(), this.tts, this.files, this.fileSpoilers, this.embeds, 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  392 */           allowedMentions(), 
/*  393 */           components(), 
/*  394 */           ephemeral()));
/*      */   }
/*      */   
/*      */   public InteractionFollowupCreateSpec withUsername(String value) {
/*  398 */     Possible<String> newValue = Possible.of(value);
/*  399 */     return validate(new InteractionFollowupCreateSpec(
/*  400 */           content(), newValue, 
/*      */           
/*  402 */           avatarUrl(), this.tts, this.files, this.fileSpoilers, this.embeds, 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  407 */           allowedMentions(), 
/*  408 */           components(), 
/*  409 */           ephemeral()));
/*      */   }
/*      */   
/*      */   public InteractionFollowupCreateSpec withAvatarUrl(Possible<String> value) {
/*  413 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/*  414 */     return validate(new InteractionFollowupCreateSpec(
/*  415 */           content(), 
/*  416 */           username(), newValue, this.tts, this.files, this.fileSpoilers, this.embeds, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  422 */           allowedMentions(), 
/*  423 */           components(), 
/*  424 */           ephemeral()));
/*      */   }
/*      */   
/*      */   public InteractionFollowupCreateSpec withAvatarUrl(String value) {
/*  428 */     Possible<String> newValue = Possible.of(value);
/*  429 */     return validate(new InteractionFollowupCreateSpec(
/*  430 */           content(), 
/*  431 */           username(), newValue, this.tts, this.files, this.fileSpoilers, this.embeds, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  437 */           allowedMentions(), 
/*  438 */           components(), 
/*  439 */           ephemeral()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final InteractionFollowupCreateSpec withTts(boolean value) {
/*  449 */     if (this.tts == value) return this; 
/*  450 */     return validate(new InteractionFollowupCreateSpec(
/*  451 */           content(), 
/*  452 */           username(), 
/*  453 */           avatarUrl(), value, this.files, this.fileSpoilers, this.embeds, 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  458 */           allowedMentions(), 
/*  459 */           components(), 
/*  460 */           ephemeral()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final InteractionFollowupCreateSpec withFiles(MessageCreateFields.File... elements) {
/*  469 */     List<MessageCreateFields.File> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/*  470 */     return validate(new InteractionFollowupCreateSpec(
/*  471 */           content(), 
/*  472 */           username(), 
/*  473 */           avatarUrl(), this.tts, newValue, this.fileSpoilers, this.embeds, 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  478 */           allowedMentions(), 
/*  479 */           components(), 
/*  480 */           ephemeral()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final InteractionFollowupCreateSpec withFiles(Iterable<? extends MessageCreateFields.File> elements) {
/*  490 */     if (this.files == elements) return this; 
/*  491 */     List<MessageCreateFields.File> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/*  492 */     return validate(new InteractionFollowupCreateSpec(
/*  493 */           content(), 
/*  494 */           username(), 
/*  495 */           avatarUrl(), this.tts, newValue, this.fileSpoilers, this.embeds, 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  500 */           allowedMentions(), 
/*  501 */           components(), 
/*  502 */           ephemeral()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final InteractionFollowupCreateSpec withFileSpoilers(MessageCreateFields.FileSpoiler... elements) {
/*  511 */     List<MessageCreateFields.FileSpoiler> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/*  512 */     return validate(new InteractionFollowupCreateSpec(
/*  513 */           content(), 
/*  514 */           username(), 
/*  515 */           avatarUrl(), this.tts, this.files, newValue, this.embeds, 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  520 */           allowedMentions(), 
/*  521 */           components(), 
/*  522 */           ephemeral()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final InteractionFollowupCreateSpec withFileSpoilers(Iterable<? extends MessageCreateFields.FileSpoiler> elements) {
/*  532 */     if (this.fileSpoilers == elements) return this; 
/*  533 */     List<MessageCreateFields.FileSpoiler> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/*  534 */     return validate(new InteractionFollowupCreateSpec(
/*  535 */           content(), 
/*  536 */           username(), 
/*  537 */           avatarUrl(), this.tts, this.files, newValue, this.embeds, 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  542 */           allowedMentions(), 
/*  543 */           components(), 
/*  544 */           ephemeral()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final InteractionFollowupCreateSpec withEmbeds(EmbedCreateSpec... elements) {
/*  553 */     List<EmbedCreateSpec> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/*  554 */     return validate(new InteractionFollowupCreateSpec(
/*  555 */           content(), 
/*  556 */           username(), 
/*  557 */           avatarUrl(), this.tts, this.files, this.fileSpoilers, newValue, 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  562 */           allowedMentions(), 
/*  563 */           components(), 
/*  564 */           ephemeral()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final InteractionFollowupCreateSpec withEmbeds(Iterable<? extends EmbedCreateSpec> elements) {
/*  574 */     if (this.embeds == elements) return this; 
/*  575 */     List<EmbedCreateSpec> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/*  576 */     return validate(new InteractionFollowupCreateSpec(
/*  577 */           content(), 
/*  578 */           username(), 
/*  579 */           avatarUrl(), this.tts, this.files, this.fileSpoilers, newValue, 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  584 */           allowedMentions(), 
/*  585 */           components(), 
/*  586 */           ephemeral()));
/*      */   }
/*      */   
/*      */   public InteractionFollowupCreateSpec withAllowedMentions(Possible<AllowedMentions> value) {
/*  590 */     Possible<AllowedMentions> newValue = Objects.<Possible<AllowedMentions>>requireNonNull(value);
/*  591 */     return validate(new InteractionFollowupCreateSpec(
/*  592 */           content(), 
/*  593 */           username(), 
/*  594 */           avatarUrl(), this.tts, this.files, this.fileSpoilers, this.embeds, newValue, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  600 */           components(), 
/*  601 */           ephemeral()));
/*      */   }
/*      */   
/*      */   public InteractionFollowupCreateSpec withAllowedMentions(AllowedMentions value) {
/*  605 */     Possible<AllowedMentions> newValue = Possible.of(value);
/*  606 */     return validate(new InteractionFollowupCreateSpec(
/*  607 */           content(), 
/*  608 */           username(), 
/*  609 */           avatarUrl(), this.tts, this.files, this.fileSpoilers, this.embeds, newValue, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  615 */           components(), 
/*  616 */           ephemeral()));
/*      */   }
/*      */   
/*      */   public InteractionFollowupCreateSpec withComponents(Possible<List<LayoutComponent>> possible) {
/*  620 */     Possible<List<LayoutComponent>> newValue = Objects.<Possible<List<LayoutComponent>>>requireNonNull(possible);
/*  621 */     return validate(new InteractionFollowupCreateSpec(
/*  622 */           content(), 
/*  623 */           username(), 
/*  624 */           avatarUrl(), this.tts, this.files, this.fileSpoilers, this.embeds, 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  629 */           allowedMentions(), newValue, 
/*      */           
/*  631 */           ephemeral()));
/*      */   }
/*      */   
/*      */   public InteractionFollowupCreateSpec withComponents(Iterable<LayoutComponent> elements) {
/*  635 */     Possible<List<LayoutComponent>> newValue = Possible.of(
/*  636 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/*  637 */     return validate(new InteractionFollowupCreateSpec(
/*  638 */           content(), 
/*  639 */           username(), 
/*  640 */           avatarUrl(), this.tts, this.files, this.fileSpoilers, this.embeds, 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  645 */           allowedMentions(), newValue, 
/*      */           
/*  647 */           ephemeral()));
/*      */   }
/*      */   
/*      */   @SafeVarargs
/*      */   public final InteractionFollowupCreateSpec withComponents(LayoutComponent... elements) {
/*  652 */     Possible<List<LayoutComponent>> newValue = Possible.of(Arrays.asList(elements));
/*  653 */     return validate(new InteractionFollowupCreateSpec(
/*  654 */           content(), 
/*  655 */           username(), 
/*  656 */           avatarUrl(), this.tts, this.files, this.fileSpoilers, this.embeds, 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  661 */           allowedMentions(), newValue, 
/*      */           
/*  663 */           ephemeral()));
/*      */   }
/*      */   
/*      */   public InteractionFollowupCreateSpec withEphemeral(Possible<Boolean> value) {
/*  667 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/*  668 */     return validate(new InteractionFollowupCreateSpec(
/*  669 */           content(), 
/*  670 */           username(), 
/*  671 */           avatarUrl(), this.tts, this.files, this.fileSpoilers, this.embeds, 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  676 */           allowedMentions(), 
/*  677 */           components(), newValue));
/*      */   }
/*      */ 
/*      */   
/*      */   public InteractionFollowupCreateSpec withEphemeral(Boolean value) {
/*  682 */     Possible<Boolean> newValue = Possible.of(value);
/*  683 */     return validate(new InteractionFollowupCreateSpec(
/*  684 */           content(), 
/*  685 */           username(), 
/*  686 */           avatarUrl(), this.tts, this.files, this.fileSpoilers, this.embeds, 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  691 */           allowedMentions(), 
/*  692 */           components(), newValue));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean equals(Object another) {
/*  702 */     if (this == another) return true; 
/*  703 */     return (another instanceof InteractionFollowupCreateSpec && 
/*  704 */       equalTo(0, (InteractionFollowupCreateSpec)another));
/*      */   }
/*      */   
/*      */   private boolean equalTo(int synthetic, InteractionFollowupCreateSpec another) {
/*  708 */     return (content().equals(another.content()) && 
/*  709 */       username().equals(another.username()) && 
/*  710 */       avatarUrl().equals(another.avatarUrl()) && this.tts == another.tts && this.files
/*      */       
/*  712 */       .equals(another.files) && this.fileSpoilers
/*  713 */       .equals(another.fileSpoilers) && this.embeds
/*  714 */       .equals(another.embeds) && 
/*  715 */       allowedMentions().equals(another.allowedMentions()) && 
/*  716 */       Objects.equals(this.components_value, another.components_value) && 
/*  717 */       ephemeral().equals(another.ephemeral()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int hashCode() {
/*  726 */     int h = 5381;
/*  727 */     h += (h << 5) + content().hashCode();
/*  728 */     h += (h << 5) + username().hashCode();
/*  729 */     h += (h << 5) + avatarUrl().hashCode();
/*  730 */     h += (h << 5) + Boolean.hashCode(this.tts);
/*  731 */     h += (h << 5) + this.files.hashCode();
/*  732 */     h += (h << 5) + this.fileSpoilers.hashCode();
/*  733 */     h += (h << 5) + this.embeds.hashCode();
/*  734 */     h += (h << 5) + allowedMentions().hashCode();
/*  735 */     h += (h << 5) + Objects.hashCode(this.components_value);
/*  736 */     h += (h << 5) + ephemeral().hashCode();
/*  737 */     return h;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/*  746 */     return "InteractionFollowupCreateSpec{content=" + 
/*  747 */       content().toString() + ", username=" + 
/*  748 */       username().toString() + ", avatarUrl=" + 
/*  749 */       avatarUrl().toString() + ", tts=" + this.tts + ", files=" + this.files + ", fileSpoilers=" + this.fileSpoilers + ", embeds=" + this.embeds + ", allowedMentions=" + 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  754 */       allowedMentions().toString() + ", components=" + 
/*  755 */       Objects.toString(this.components_value) + ", ephemeral=" + 
/*  756 */       ephemeral().toString() + "}";
/*      */   }
/*      */ 
/*      */   
/*  760 */   private static final InteractionFollowupCreateSpec INSTANCE = validate(new InteractionFollowupCreateSpec());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static InteractionFollowupCreateSpec create() {
/*  767 */     return INSTANCE;
/*      */   }
/*      */   
/*      */   private static InteractionFollowupCreateSpec validate(InteractionFollowupCreateSpec instance) {
/*  771 */     return (INSTANCE != null && INSTANCE.equalTo(0, instance)) ? INSTANCE : instance;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static InteractionFollowupCreateSpec copyOf(InteractionFollowupCreateSpecGenerator instance) {
/*  782 */     if (instance instanceof InteractionFollowupCreateSpec) {
/*  783 */       return (InteractionFollowupCreateSpec)instance;
/*      */     }
/*  785 */     return builder()
/*  786 */       .from(instance)
/*  787 */       .build();
/*      */   }
/*      */   
/*      */   public boolean isContentPresent() {
/*  791 */     return !this.content_absent;
/*      */   }
/*      */   
/*      */   public String contentOrElse(String defaultValue) {
/*  795 */     return !this.content_absent ? this.content_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isUsernamePresent() {
/*  799 */     return !this.username_absent;
/*      */   }
/*      */   
/*      */   public String usernameOrElse(String defaultValue) {
/*  803 */     return !this.username_absent ? this.username_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isAvatarUrlPresent() {
/*  807 */     return !this.avatarUrl_absent;
/*      */   }
/*      */   
/*      */   public String avatarUrlOrElse(String defaultValue) {
/*  811 */     return !this.avatarUrl_absent ? this.avatarUrl_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isAllowedMentionsPresent() {
/*  815 */     return !this.allowedMentions_absent;
/*      */   }
/*      */   
/*      */   public AllowedMentions allowedMentionsOrElse(AllowedMentions defaultValue) {
/*  819 */     return !this.allowedMentions_absent ? this.allowedMentions_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isComponentsPresent() {
/*  823 */     return !this.components_absent;
/*      */   }
/*      */   
/*      */   public List<LayoutComponent> componentsOrElse(List<LayoutComponent> defaultValue) {
/*  827 */     return !this.components_absent ? this.components_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isEphemeralPresent() {
/*  831 */     return !this.ephemeral_absent;
/*      */   }
/*      */   
/*      */   public Boolean ephemeralOrElse(Boolean defaultValue) {
/*  835 */     return !this.ephemeral_absent ? this.ephemeral_value : defaultValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Builder builder() {
/*  857 */     return new Builder();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   @Generated(from = "InteractionFollowupCreateSpecGenerator", generator = "Immutables")
/*      */   public static final class Builder
/*      */   {
/*      */     private static final long OPT_BIT_TTS = 1L;
/*      */     
/*      */     private static final long OPT_BIT_FILES = 2L;
/*      */     
/*      */     private static final long OPT_BIT_FILE_SPOILERS = 4L;
/*      */     
/*      */     private static final long OPT_BIT_EMBEDS = 8L;
/*      */     
/*      */     private long optBits;
/*      */     
/*  875 */     private Possible<String> content_possible = Possible.absent();
/*  876 */     private Possible<String> username_possible = Possible.absent();
/*  877 */     private Possible<String> avatarUrl_possible = Possible.absent();
/*  878 */     private Possible<AllowedMentions> allowedMentions_possible = Possible.absent();
/*  879 */     private List<LayoutComponent> components_list = null;
/*  880 */     private Possible<Boolean> ephemeral_possible = Possible.absent();
/*      */     private boolean tts;
/*  882 */     private List<MessageCreateFields.File> files = new ArrayList<>();
/*  883 */     private List<MessageCreateFields.FileSpoiler> fileSpoilers = new ArrayList<>();
/*  884 */     private List<EmbedCreateSpec> embeds = new ArrayList<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder from(InteractionFollowupCreateSpec instance) {
/*  898 */       return from(instance);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     final Builder from(InteractionFollowupCreateSpecGenerator instance) {
/*  908 */       Objects.requireNonNull(instance, "instance");
/*  909 */       content(instance.content());
/*  910 */       username(instance.username());
/*  911 */       avatarUrl(instance.avatarUrl());
/*  912 */       tts(instance.tts());
/*  913 */       addAllFiles(instance.files());
/*  914 */       addAllFileSpoilers(instance.fileSpoilers());
/*  915 */       addAllEmbeds(instance.embeds());
/*  916 */       allowedMentions(instance.allowedMentions());
/*  917 */       components(instance.components());
/*  918 */       ephemeral(instance.ephemeral());
/*  919 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder content(Possible<String> value) {
/*  924 */       this.content_possible = value;
/*  925 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder content(String value) {
/*  930 */       this.content_possible = Possible.of(value);
/*  931 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder username(Possible<String> value) {
/*  936 */       this.username_possible = value;
/*  937 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder username(String value) {
/*  942 */       this.username_possible = Possible.of(value);
/*  943 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder avatarUrl(Possible<String> value) {
/*  948 */       this.avatarUrl_possible = value;
/*  949 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder avatarUrl(String value) {
/*  954 */       this.avatarUrl_possible = Possible.of(value);
/*  955 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public final Builder tts(boolean tts) {
/*  966 */       this.tts = tts;
/*  967 */       this.optBits |= 0x1L;
/*  968 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public final Builder addFile(MessageCreateFields.File element) {
/*  978 */       element = ImmutableMessageCreateFields.File.copyOf(element);
/*  979 */       this.files.add(Objects.<MessageCreateFields.File>requireNonNull(element, "files element"));
/*  980 */       this.optBits |= 0x2L;
/*  981 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addFile(String name, InputStream inputStream) {
/*  991 */       return addFile(ImmutableMessageCreateFields.File.of(name, inputStream));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public final Builder addFiles(MessageCreateFields.File... elements) {
/* 1001 */       for (MessageCreateFields.File element : elements) {
/* 1002 */         element = ImmutableMessageCreateFields.File.copyOf(element);
/* 1003 */         this.files.add(Objects.<MessageCreateFields.File>requireNonNull(element, "files element"));
/*      */       } 
/* 1005 */       this.optBits |= 0x2L;
/* 1006 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public final Builder files(Iterable<? extends MessageCreateFields.File> elements) {
/* 1017 */       this.files.clear();
/* 1018 */       return addAllFiles(elements);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public final Builder addAllFiles(Iterable<? extends MessageCreateFields.File> elements) {
/* 1028 */       for (MessageCreateFields.File element : elements) {
/* 1029 */         element = ImmutableMessageCreateFields.File.copyOf(element);
/* 1030 */         this.files.add(Objects.<MessageCreateFields.File>requireNonNull(element, "files element"));
/*      */       } 
/* 1032 */       this.optBits |= 0x2L;
/* 1033 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public final Builder addFileSpoiler(MessageCreateFields.FileSpoiler element) {
/* 1043 */       element = ImmutableMessageCreateFields.FileSpoiler.copyOf(element);
/* 1044 */       this.fileSpoilers.add(Objects.<MessageCreateFields.FileSpoiler>requireNonNull(element, "fileSpoilers element"));
/* 1045 */       this.optBits |= 0x4L;
/* 1046 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addFileSpoiler(String name, InputStream inputStream) {
/* 1056 */       return addFileSpoiler(ImmutableMessageCreateFields.FileSpoiler.of(name, inputStream));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public final Builder addFileSpoilers(MessageCreateFields.FileSpoiler... elements) {
/* 1066 */       for (MessageCreateFields.FileSpoiler element : elements) {
/* 1067 */         element = ImmutableMessageCreateFields.FileSpoiler.copyOf(element);
/* 1068 */         this.fileSpoilers.add(Objects.<MessageCreateFields.FileSpoiler>requireNonNull(element, "fileSpoilers element"));
/*      */       } 
/* 1070 */       this.optBits |= 0x4L;
/* 1071 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public final Builder fileSpoilers(Iterable<? extends MessageCreateFields.FileSpoiler> elements) {
/* 1082 */       this.fileSpoilers.clear();
/* 1083 */       return addAllFileSpoilers(elements);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public final Builder addAllFileSpoilers(Iterable<? extends MessageCreateFields.FileSpoiler> elements) {
/* 1093 */       for (MessageCreateFields.FileSpoiler element : elements) {
/* 1094 */         element = ImmutableMessageCreateFields.FileSpoiler.copyOf(element);
/* 1095 */         this.fileSpoilers.add(Objects.<MessageCreateFields.FileSpoiler>requireNonNull(element, "fileSpoilers element"));
/*      */       } 
/* 1097 */       this.optBits |= 0x4L;
/* 1098 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public final Builder addEmbed(EmbedCreateSpec element) {
/* 1108 */       this.embeds.add(Objects.<EmbedCreateSpec>requireNonNull(element, "embeds element"));
/* 1109 */       this.optBits |= 0x8L;
/* 1110 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public final Builder addEmbeds(EmbedCreateSpec... elements) {
/* 1120 */       for (EmbedCreateSpec element : elements) {
/* 1121 */         this.embeds.add(Objects.<EmbedCreateSpec>requireNonNull(element, "embeds element"));
/*      */       }
/* 1123 */       this.optBits |= 0x8L;
/* 1124 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public final Builder embeds(Iterable<? extends EmbedCreateSpec> elements) {
/* 1135 */       this.embeds.clear();
/* 1136 */       return addAllEmbeds(elements);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public final Builder addAllEmbeds(Iterable<? extends EmbedCreateSpec> elements) {
/* 1146 */       for (EmbedCreateSpec element : elements) {
/* 1147 */         this.embeds.add(Objects.<EmbedCreateSpec>requireNonNull(element, "embeds element"));
/*      */       }
/* 1149 */       this.optBits |= 0x8L;
/* 1150 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder allowedMentions(Possible<AllowedMentions> value) {
/* 1155 */       this.allowedMentions_possible = value;
/* 1156 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder allowedMentions(AllowedMentions value) {
/* 1161 */       this.allowedMentions_possible = Possible.of(value);
/* 1162 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder addComponent(LayoutComponent element) {
/* 1167 */       components_getOrCreate().add(element);
/* 1168 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder addAllComponents(List<LayoutComponent> elements) {
/* 1173 */       components_getOrCreate().addAll(elements);
/* 1174 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder components(Possible<List<LayoutComponent>> elements) {
/* 1179 */       this.components_list = null;
/* 1180 */       elements.toOptional().ifPresent(e -> components_getOrCreate().addAll(e));
/* 1181 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder components(List<LayoutComponent> elements) {
/* 1186 */       this.components_list = new ArrayList<>(elements);
/* 1187 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder components(Iterable<LayoutComponent> elements) {
/* 1192 */       this.components_list = (List<LayoutComponent>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/* 1193 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder ephemeral(Possible<Boolean> value) {
/* 1198 */       this.ephemeral_possible = value;
/* 1199 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder ephemeral(Boolean value) {
/* 1204 */       this.ephemeral_possible = Possible.of(value);
/* 1205 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public InteractionFollowupCreateSpec build() {
/* 1214 */       return InteractionFollowupCreateSpec.validate(new InteractionFollowupCreateSpec(this));
/*      */     }
/*      */     
/*      */     private boolean ttsIsSet() {
/* 1218 */       return ((this.optBits & 0x1L) != 0L);
/*      */     }
/*      */     
/*      */     private boolean filesIsSet() {
/* 1222 */       return ((this.optBits & 0x2L) != 0L);
/*      */     }
/*      */     
/*      */     private boolean fileSpoilersIsSet() {
/* 1226 */       return ((this.optBits & 0x4L) != 0L);
/*      */     }
/*      */     
/*      */     private boolean embedsIsSet() {
/* 1230 */       return ((this.optBits & 0x8L) != 0L);
/*      */     }
/*      */     
/*      */     private Possible<String> content_build() {
/* 1234 */       return this.content_possible;
/*      */     }
/*      */     
/*      */     private Possible<String> username_build() {
/* 1238 */       return this.username_possible;
/*      */     }
/*      */     
/*      */     private Possible<String> avatarUrl_build() {
/* 1242 */       return this.avatarUrl_possible;
/*      */     }
/*      */     
/*      */     private Possible<AllowedMentions> allowedMentions_build() {
/* 1246 */       return this.allowedMentions_possible;
/*      */     }
/*      */     
/*      */     private Possible<List<LayoutComponent>> components_build() {
/* 1250 */       return (this.components_list == null) ? Possible.absent() : 
/* 1251 */         Possible.of(this.components_list);
/*      */     }
/*      */     
/*      */     private List<LayoutComponent> components_getOrCreate() {
/* 1255 */       if (this.components_list == null) {
/* 1256 */         this.components_list = new ArrayList<>();
/*      */       }
/* 1258 */       return this.components_list;
/*      */     }
/*      */     
/*      */     private Possible<Boolean> ephemeral_build() {
/* 1262 */       return this.ephemeral_possible;
/*      */     }
/*      */     private Builder() {} }
/*      */   
/*      */   private static <T> List<T> createSafeList(Iterable<? extends T> iterable, boolean checkNulls, boolean skipNulls) {
/*      */     ArrayList<T> list;
/* 1268 */     if (iterable instanceof Collection) {
/* 1269 */       int size = ((Collection)iterable).size();
/* 1270 */       if (size == 0) return Collections.emptyList(); 
/* 1271 */       list = new ArrayList<>();
/*      */     } else {
/* 1273 */       list = new ArrayList<>();
/*      */     } 
/* 1275 */     for (T element : iterable) {
/* 1276 */       if (skipNulls && element == null)
/* 1277 */         continue;  if (checkNulls) Objects.requireNonNull(element, "element"); 
/* 1278 */       list.add(element);
/*      */     } 
/* 1280 */     return list;
/*      */   }
/*      */   
/*      */   private static <T> List<T> createUnmodifiableList(boolean clone, List<T> list) {
/* 1284 */     switch (list.size()) { case 0:
/* 1285 */         return Collections.emptyList();
/* 1286 */       case 1: return Collections.singletonList(list.get(0)); }
/*      */     
/* 1288 */     if (clone) {
/* 1289 */       return Collections.unmodifiableList(new ArrayList<>(list));
/*      */     }
/* 1291 */     if (list instanceof ArrayList) {
/* 1292 */       ((ArrayList)list).trimToSize();
/*      */     }
/* 1294 */     return Collections.unmodifiableList(list);
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\InteractionFollowupCreateSpec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */