/*    */ package discord4j.core.spec;
/*    */ 
/*    */ import discord4j.common.util.Snowflake;
/*    */ import discord4j.core.object.audit.ActionType;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Immutable(singleton = true)
/*    */ interface AuditLogQuerySpecGenerator
/*    */   extends Spec<Map<String, Object>>
/*    */ {
/*    */   default Map<String, Object> asRequest() {
/* 53 */     Map<String, Object> request = new HashMap<>(4);
/* 54 */     InternalSpecUtils.putIfNotNull(request, "user_id", InternalSpecUtils.mapNullable(userId(), Snowflake::asString));
/* 55 */     InternalSpecUtils.putIfNotNull(request, "action_type", InternalSpecUtils.mapNullable(actionType(), ActionType::getValue));
/* 56 */     InternalSpecUtils.putIfNotNull(request, "before", InternalSpecUtils.mapNullable(before(), Snowflake::asString));
/* 57 */     InternalSpecUtils.putIfNotNull(request, "limit", limit());
/* 58 */     return request;
/*    */   }
/*    */   
/*    */   @Nullable
/*    */   Integer limit();
/*    */   
/*    */   @Nullable
/*    */   Snowflake before();
/*    */   
/*    */   @Nullable
/*    */   ActionType actionType();
/*    */   
/*    */   @Nullable
/*    */   Snowflake userId();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\AuditLogQuerySpecGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */