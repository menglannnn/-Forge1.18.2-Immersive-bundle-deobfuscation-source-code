/*     */ package discord4j.core.spec;
/*     */ 
/*     */ import com.google.errorprone.annotations.CanIgnoreReturnValue;
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.discordjson.json.AutoModActionData;
/*     */ import discord4j.discordjson.json.AutoModActionMetaData;
/*     */ import discord4j.discordjson.json.AutoModTriggerMetaData;
/*     */ import discord4j.discordjson.json.ImmutableAutoModActionData;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "AutoModRuleEditSpecGenerator", generator = "Immutables")
/*     */ public final class AutoModRuleEditSpec
/*     */   implements AutoModRuleEditSpecGenerator
/*     */ {
/*     */   @Nullable
/*     */   private final String reason;
/*     */   private final String name;
/*     */   private final int eventType;
/*     */   private final AutoModTriggerMetaData triggerMetaData_value;
/*     */   private final boolean triggerMetaData_absent;
/*     */   private final List<AutoModActionData> actions;
/*     */   private final boolean enabled;
/*     */   private final List<Snowflake> exemptRoles;
/*     */   private final List<Snowflake> exemptChannels;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   private volatile transient InitShim initShim;
/*     */   
/*     */   private AutoModRuleEditSpec(String name, int eventType, boolean enabled) {
/* 107 */     this.initShim = new InitShim(); this.name = Objects.<String>requireNonNull(name, "name"); this.eventType = eventType; this.enabled = enabled; this.reason = null; Possible<AutoModTriggerMetaData> triggerMetaData$impl = Possible.absent(); this.triggerMetaData_value = triggerMetaData$impl.toOptional().orElse(null); this.triggerMetaData_absent = triggerMetaData$impl.isAbsent(); this.actions = this.initShim.actions(); this.exemptRoles = this.initShim.exemptRoles(); this.exemptChannels = this.initShim.exemptChannels(); this.initShim = null; } private AutoModRuleEditSpec(Builder builder) { this.initShim = new InitShim(); this.reason = builder.reason; this.name = builder.name; this.eventType = builder.eventType; Possible<AutoModTriggerMetaData> triggerMetaData$impl = builder.triggerMetaData_build(); this.enabled = builder.enabled; if (builder.actionsIsSet()) this.initShim.actions(createUnmodifiableList(true, builder.actions));  if (builder.exemptRolesIsSet()) this.initShim.exemptRoles(createUnmodifiableList(true, builder.exemptRoles));  if (builder.exemptChannelsIsSet()) this.initShim.exemptChannels(createUnmodifiableList(true, builder.exemptChannels));  this.triggerMetaData_value = triggerMetaData$impl.toOptional().orElse(null); this.triggerMetaData_absent = triggerMetaData$impl.isAbsent(); this.actions = this.initShim.actions(); this.exemptRoles = this.initShim.exemptRoles(); this.exemptChannels = this.initShim.exemptChannels(); this.initShim = null; } private AutoModRuleEditSpec(@Nullable String reason, String name, int eventType, Possible<AutoModTriggerMetaData> triggerMetaData, List<AutoModActionData> actions, boolean enabled, List<Snowflake> exemptRoles, List<Snowflake> exemptChannels) { this.initShim = new InitShim(); this.reason = reason; this.name = name; this.eventType = eventType; Possible<AutoModTriggerMetaData> triggerMetaData$impl = triggerMetaData; this.initShim.actions(actions); this.enabled = enabled; this.initShim.exemptRoles(exemptRoles); this.initShim.exemptChannels(exemptChannels); this.triggerMetaData_value = triggerMetaData$impl.toOptional().orElse(null);
/*     */     this.triggerMetaData_absent = triggerMetaData$impl.isAbsent();
/*     */     this.actions = this.initShim.actions();
/*     */     this.exemptRoles = this.initShim.exemptRoles();
/*     */     this.exemptChannels = this.initShim.exemptChannels();
/* 112 */     this.initShim = null; } @Generated(from = "AutoModRuleEditSpecGenerator", generator = "Immutables") private final class InitShim { private byte actionsBuildStage = 0;
/*     */     private List<AutoModActionData> actions;
/*     */     
/*     */     List<AutoModActionData> actions() {
/* 116 */       if (this.actionsBuildStage == -1) throw new IllegalStateException(formatInitCycleMessage()); 
/* 117 */       if (this.actionsBuildStage == 0) {
/* 118 */         this.actionsBuildStage = -1;
/* 119 */         this.actions = (List)AutoModRuleEditSpec.createUnmodifiableList(false, AutoModRuleEditSpec.createSafeList((Iterable)AutoModRuleEditSpec.this.actionsInitialize(), true, false));
/* 120 */         this.actionsBuildStage = 1;
/*     */       } 
/* 122 */       return this.actions;
/*     */     }
/*     */     
/*     */     void actions(List<AutoModActionData> actions) {
/* 126 */       this.actions = actions;
/* 127 */       this.actionsBuildStage = 1;
/*     */     }
/*     */     
/* 130 */     private byte exemptRolesBuildStage = 0;
/*     */     private List<Snowflake> exemptRoles;
/*     */     
/*     */     List<Snowflake> exemptRoles() {
/* 134 */       if (this.exemptRolesBuildStage == -1) throw new IllegalStateException(formatInitCycleMessage()); 
/* 135 */       if (this.exemptRolesBuildStage == 0) {
/* 136 */         this.exemptRolesBuildStage = -1;
/* 137 */         this.exemptRoles = (List)AutoModRuleEditSpec.createUnmodifiableList(false, AutoModRuleEditSpec.createSafeList((Iterable)AutoModRuleEditSpec.this.exemptRolesInitialize(), true, false));
/* 138 */         this.exemptRolesBuildStage = 1;
/*     */       } 
/* 140 */       return this.exemptRoles;
/*     */     }
/*     */     
/*     */     void exemptRoles(List<Snowflake> exemptRoles) {
/* 144 */       this.exemptRoles = exemptRoles;
/* 145 */       this.exemptRolesBuildStage = 1;
/*     */     }
/*     */     
/* 148 */     private byte exemptChannelsBuildStage = 0;
/*     */     private List<Snowflake> exemptChannels;
/*     */     
/*     */     List<Snowflake> exemptChannels() {
/* 152 */       if (this.exemptChannelsBuildStage == -1) throw new IllegalStateException(formatInitCycleMessage()); 
/* 153 */       if (this.exemptChannelsBuildStage == 0) {
/* 154 */         this.exemptChannelsBuildStage = -1;
/* 155 */         this.exemptChannels = (List)AutoModRuleEditSpec.createUnmodifiableList(false, AutoModRuleEditSpec.createSafeList((Iterable)AutoModRuleEditSpec.this.exemptChannelsInitialize(), true, false));
/* 156 */         this.exemptChannelsBuildStage = 1;
/*     */       } 
/* 158 */       return this.exemptChannels;
/*     */     }
/*     */     
/*     */     void exemptChannels(List<Snowflake> exemptChannels) {
/* 162 */       this.exemptChannels = exemptChannels;
/* 163 */       this.exemptChannelsBuildStage = 1;
/*     */     }
/*     */     
/*     */     private String formatInitCycleMessage() {
/* 167 */       List<String> attributes = new ArrayList<>();
/* 168 */       if (this.actionsBuildStage == -1) attributes.add("actions"); 
/* 169 */       if (this.exemptRolesBuildStage == -1) attributes.add("exemptRoles"); 
/* 170 */       if (this.exemptChannelsBuildStage == -1) attributes.add("exemptChannels"); 
/* 171 */       return "Cannot build AutoModRuleEditSpec, attribute initializers form cycle " + attributes;
/*     */     }
/*     */     private InitShim() {} }
/*     */   
/*     */   private List<AutoModActionData> actionsInitialize() {
/* 176 */     return super.actions();
/*     */   }
/*     */   
/*     */   private List<Snowflake> exemptRolesInitialize() {
/* 180 */     return super.exemptRoles();
/*     */   }
/*     */   
/*     */   private List<Snowflake> exemptChannelsInitialize() {
/* 184 */     return super.exemptChannels();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String reason() {
/* 193 */     return this.reason;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String name() {
/* 201 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int eventType() {
/* 209 */     return this.eventType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<AutoModTriggerMetaData> triggerMetaData() {
/* 217 */     return this.triggerMetaData_absent ? Possible.absent() : Possible.of(this.triggerMetaData_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<AutoModActionData> actions() {
/* 225 */     InitShim shim = this.initShim;
/* 226 */     return (shim != null) ? 
/* 227 */       shim.actions() : 
/* 228 */       this.actions;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean enabled() {
/* 236 */     return this.enabled;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Snowflake> exemptRoles() {
/* 244 */     InitShim shim = this.initShim;
/* 245 */     return (shim != null) ? 
/* 246 */       shim.exemptRoles() : 
/* 247 */       this.exemptRoles;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Snowflake> exemptChannels() {
/* 255 */     InitShim shim = this.initShim;
/* 256 */     return (shim != null) ? 
/* 257 */       shim.exemptChannels() : 
/* 258 */       this.exemptChannels;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final AutoModRuleEditSpec withReason(@Nullable String value) {
/* 268 */     if (Objects.equals(this.reason, value)) return this; 
/* 269 */     return new AutoModRuleEditSpec(value, this.name, this.eventType, 
/*     */ 
/*     */ 
/*     */         
/* 273 */         triggerMetaData(), this.actions, this.enabled, this.exemptRoles, this.exemptChannels);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final AutoModRuleEditSpec withName(String value) {
/* 287 */     String newValue = Objects.<String>requireNonNull(value, "name");
/* 288 */     if (this.name.equals(newValue)) return this; 
/* 289 */     return new AutoModRuleEditSpec(this.reason, newValue, this.eventType, 
/*     */ 
/*     */ 
/*     */         
/* 293 */         triggerMetaData(), this.actions, this.enabled, this.exemptRoles, this.exemptChannels);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final AutoModRuleEditSpec withEventType(int value) {
/* 307 */     if (this.eventType == value) return this; 
/* 308 */     return new AutoModRuleEditSpec(this.reason, this.name, value, 
/*     */ 
/*     */ 
/*     */         
/* 312 */         triggerMetaData(), this.actions, this.enabled, this.exemptRoles, this.exemptChannels);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AutoModRuleEditSpec withTriggerMetaData(Possible<AutoModTriggerMetaData> value) {
/* 320 */     Possible<AutoModTriggerMetaData> newValue = Objects.<Possible<AutoModTriggerMetaData>>requireNonNull(value);
/* 321 */     return new AutoModRuleEditSpec(this.reason, this.name, this.eventType, newValue, this.actions, this.enabled, this.exemptRoles, this.exemptChannels);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AutoModRuleEditSpec withTriggerMetaData(AutoModTriggerMetaData value) {
/* 333 */     Possible<AutoModTriggerMetaData> newValue = Possible.of(value);
/* 334 */     return new AutoModRuleEditSpec(this.reason, this.name, this.eventType, newValue, this.actions, this.enabled, this.exemptRoles, this.exemptChannels);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final AutoModRuleEditSpec withActions(AutoModActionData... elements) {
/* 351 */     List<AutoModActionData> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/* 352 */     return new AutoModRuleEditSpec(this.reason, this.name, this.eventType, 
/*     */ 
/*     */ 
/*     */         
/* 356 */         triggerMetaData(), newValue, this.enabled, this.exemptRoles, this.exemptChannels);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final AutoModRuleEditSpec withActions(Iterable<? extends AutoModActionData> elements) {
/* 370 */     if (this.actions == elements) return this; 
/* 371 */     List<AutoModActionData> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/* 372 */     return new AutoModRuleEditSpec(this.reason, this.name, this.eventType, 
/*     */ 
/*     */ 
/*     */         
/* 376 */         triggerMetaData(), newValue, this.enabled, this.exemptRoles, this.exemptChannels);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final AutoModRuleEditSpec withEnabled(boolean value) {
/* 390 */     if (this.enabled == value) return this; 
/* 391 */     return new AutoModRuleEditSpec(this.reason, this.name, this.eventType, 
/*     */ 
/*     */ 
/*     */         
/* 395 */         triggerMetaData(), this.actions, value, this.exemptRoles, this.exemptChannels);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final AutoModRuleEditSpec withExemptRoles(Snowflake... elements) {
/* 408 */     List<Snowflake> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/* 409 */     return new AutoModRuleEditSpec(this.reason, this.name, this.eventType, 
/*     */ 
/*     */ 
/*     */         
/* 413 */         triggerMetaData(), this.actions, this.enabled, newValue, this.exemptChannels);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final AutoModRuleEditSpec withExemptRoles(Iterable<? extends Snowflake> elements) {
/* 427 */     if (this.exemptRoles == elements) return this; 
/* 428 */     List<Snowflake> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/* 429 */     return new AutoModRuleEditSpec(this.reason, this.name, this.eventType, 
/*     */ 
/*     */ 
/*     */         
/* 433 */         triggerMetaData(), this.actions, this.enabled, newValue, this.exemptChannels);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final AutoModRuleEditSpec withExemptChannels(Snowflake... elements) {
/* 446 */     List<Snowflake> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/* 447 */     return new AutoModRuleEditSpec(this.reason, this.name, this.eventType, 
/*     */ 
/*     */ 
/*     */         
/* 451 */         triggerMetaData(), this.actions, this.enabled, this.exemptRoles, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final AutoModRuleEditSpec withExemptChannels(Iterable<? extends Snowflake> elements) {
/* 465 */     if (this.exemptChannels == elements) return this; 
/* 466 */     List<Snowflake> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/* 467 */     return new AutoModRuleEditSpec(this.reason, this.name, this.eventType, 
/*     */ 
/*     */ 
/*     */         
/* 471 */         triggerMetaData(), this.actions, this.enabled, this.exemptRoles, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 484 */     if (this == another) return true; 
/* 485 */     return (another instanceof AutoModRuleEditSpec && 
/* 486 */       equalTo(0, (AutoModRuleEditSpec)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, AutoModRuleEditSpec another) {
/* 490 */     return (Objects.equals(this.reason, another.reason) && this.name
/* 491 */       .equals(another.name) && this.eventType == another.eventType && 
/*     */       
/* 493 */       triggerMetaData().equals(another.triggerMetaData()) && this.actions
/* 494 */       .equals(another.actions) && this.enabled == another.enabled && this.exemptRoles
/*     */       
/* 496 */       .equals(another.exemptRoles) && this.exemptChannels
/* 497 */       .equals(another.exemptChannels));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 506 */     int h = 5381;
/* 507 */     h += (h << 5) + Objects.hashCode(this.reason);
/* 508 */     h += (h << 5) + this.name.hashCode();
/* 509 */     h += (h << 5) + this.eventType;
/* 510 */     h += (h << 5) + triggerMetaData().hashCode();
/* 511 */     h += (h << 5) + this.actions.hashCode();
/* 512 */     h += (h << 5) + Boolean.hashCode(this.enabled);
/* 513 */     h += (h << 5) + this.exemptRoles.hashCode();
/* 514 */     h += (h << 5) + this.exemptChannels.hashCode();
/* 515 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 524 */     return "AutoModRuleEditSpec{reason=" + this.reason + ", name=" + this.name + ", eventType=" + this.eventType + ", triggerMetaData=" + 
/*     */ 
/*     */ 
/*     */       
/* 528 */       triggerMetaData().toString() + ", actions=" + this.actions + ", enabled=" + this.enabled + ", exemptRoles=" + this.exemptRoles + ", exemptChannels=" + this.exemptChannels + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AutoModRuleEditSpec of(String name, int eventType, boolean enabled) {
/* 544 */     return new AutoModRuleEditSpec(name, eventType, enabled);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AutoModRuleEditSpec copyOf(AutoModRuleEditSpecGenerator instance) {
/* 555 */     if (instance instanceof AutoModRuleEditSpec) {
/* 556 */       return (AutoModRuleEditSpec)instance;
/*     */     }
/* 558 */     return builder()
/* 559 */       .from(instance)
/* 560 */       .build();
/*     */   }
/*     */   
/*     */   public boolean isTriggerMetaDataPresent() {
/* 564 */     return !this.triggerMetaData_absent;
/*     */   }
/*     */   
/*     */   public AutoModTriggerMetaData triggerMetaDataOrElse(AutoModTriggerMetaData defaultValue) {
/* 568 */     return !this.triggerMetaData_absent ? this.triggerMetaData_value : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 588 */     return new Builder();
/*     */   }
/*     */ 
/*     */   
/*     */   @Generated(from = "AutoModRuleEditSpecGenerator", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_NAME = 1L;
/*     */     
/*     */     private static final long INIT_BIT_EVENT_TYPE = 2L;
/*     */     
/*     */     private static final long INIT_BIT_ENABLED = 4L;
/*     */     
/*     */     private static final long OPT_BIT_ACTIONS = 1L;
/*     */     
/*     */     private static final long OPT_BIT_EXEMPT_ROLES = 2L;
/*     */     
/*     */     private static final long OPT_BIT_EXEMPT_CHANNELS = 4L;
/* 606 */     private long initBits = 7L;
/*     */     
/*     */     private long optBits;
/* 609 */     private Possible<AutoModTriggerMetaData> triggerMetaData_possible = Possible.absent();
/*     */     private String reason;
/*     */     private String name;
/*     */     private int eventType;
/* 613 */     private List<AutoModActionData> actions = new ArrayList<>();
/*     */     private boolean enabled;
/* 615 */     private List<Snowflake> exemptRoles = new ArrayList<>();
/* 616 */     private List<Snowflake> exemptChannels = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder from(AutoModRuleEditSpecGenerator instance) {
/* 631 */       Objects.requireNonNull(instance, "instance");
/* 632 */       String reasonValue = instance.reason();
/* 633 */       if (reasonValue != null) {
/* 634 */         reason(reasonValue);
/*     */       }
/* 636 */       name(instance.name());
/* 637 */       eventType(instance.eventType());
/* 638 */       triggerMetaData(instance.triggerMetaData());
/* 639 */       addAllActions(instance.actions());
/* 640 */       enabled(instance.enabled());
/* 641 */       addAllExemptRoles(instance.exemptRoles());
/* 642 */       addAllExemptChannels(instance.exemptChannels());
/* 643 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder reason(@Nullable String reason) {
/* 653 */       this.reason = reason;
/* 654 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder name(String name) {
/* 664 */       this.name = Objects.<String>requireNonNull(name, "name");
/* 665 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 666 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder eventType(int eventType) {
/* 676 */       this.eventType = eventType;
/* 677 */       this.initBits &= 0xFFFFFFFFFFFFFFFDL;
/* 678 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder triggerMetaData(Possible<AutoModTriggerMetaData> value) {
/* 683 */       this.triggerMetaData_possible = value;
/* 684 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder triggerMetaData(AutoModTriggerMetaData value) {
/* 689 */       this.triggerMetaData_possible = Possible.of(value);
/* 690 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder addAction(AutoModActionData element) {
/* 700 */       ImmutableAutoModActionData immutableAutoModActionData = ImmutableAutoModActionData.copyOf(element);
/* 701 */       this.actions.add((AutoModActionData)Objects.requireNonNull(immutableAutoModActionData, "actions element"));
/* 702 */       this.optBits |= 0x1L;
/* 703 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder addAction(int type, Possible<AutoModActionMetaData> metadata) {
/* 713 */       return addAction((AutoModActionData)ImmutableAutoModActionData.of(type, metadata));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder addActions(AutoModActionData... elements) {
/* 723 */       for (AutoModActionData element : elements) {
/* 724 */         ImmutableAutoModActionData immutableAutoModActionData = ImmutableAutoModActionData.copyOf(element);
/* 725 */         this.actions.add((AutoModActionData)Objects.requireNonNull(immutableAutoModActionData, "actions element"));
/*     */       } 
/* 727 */       this.optBits |= 0x1L;
/* 728 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder actions(Iterable<? extends AutoModActionData> elements) {
/* 739 */       this.actions.clear();
/* 740 */       return addAllActions(elements);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder addAllActions(Iterable<? extends AutoModActionData> elements) {
/* 750 */       for (AutoModActionData element : elements) {
/* 751 */         ImmutableAutoModActionData immutableAutoModActionData = ImmutableAutoModActionData.copyOf(element);
/* 752 */         this.actions.add((AutoModActionData)Objects.requireNonNull(immutableAutoModActionData, "actions element"));
/*     */       } 
/* 754 */       this.optBits |= 0x1L;
/* 755 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder enabled(boolean enabled) {
/* 765 */       this.enabled = enabled;
/* 766 */       this.initBits &= 0xFFFFFFFFFFFFFFFBL;
/* 767 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder addExemptRole(Snowflake element) {
/* 777 */       this.exemptRoles.add(Objects.<Snowflake>requireNonNull(element, "exemptRoles element"));
/* 778 */       this.optBits |= 0x2L;
/* 779 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder addExemptRoles(Snowflake... elements) {
/* 789 */       for (Snowflake element : elements) {
/* 790 */         this.exemptRoles.add(Objects.<Snowflake>requireNonNull(element, "exemptRoles element"));
/*     */       }
/* 792 */       this.optBits |= 0x2L;
/* 793 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder exemptRoles(Iterable<? extends Snowflake> elements) {
/* 804 */       this.exemptRoles.clear();
/* 805 */       return addAllExemptRoles(elements);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder addAllExemptRoles(Iterable<? extends Snowflake> elements) {
/* 815 */       for (Snowflake element : elements) {
/* 816 */         this.exemptRoles.add(Objects.<Snowflake>requireNonNull(element, "exemptRoles element"));
/*     */       }
/* 818 */       this.optBits |= 0x2L;
/* 819 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder addExemptChannel(Snowflake element) {
/* 829 */       this.exemptChannels.add(Objects.<Snowflake>requireNonNull(element, "exemptChannels element"));
/* 830 */       this.optBits |= 0x4L;
/* 831 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder addExemptChannels(Snowflake... elements) {
/* 841 */       for (Snowflake element : elements) {
/* 842 */         this.exemptChannels.add(Objects.<Snowflake>requireNonNull(element, "exemptChannels element"));
/*     */       }
/* 844 */       this.optBits |= 0x4L;
/* 845 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder exemptChannels(Iterable<? extends Snowflake> elements) {
/* 856 */       this.exemptChannels.clear();
/* 857 */       return addAllExemptChannels(elements);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder addAllExemptChannels(Iterable<? extends Snowflake> elements) {
/* 867 */       for (Snowflake element : elements) {
/* 868 */         this.exemptChannels.add(Objects.<Snowflake>requireNonNull(element, "exemptChannels element"));
/*     */       }
/* 870 */       this.optBits |= 0x4L;
/* 871 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public AutoModRuleEditSpec build() {
/* 880 */       if (this.initBits != 0L) {
/* 881 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 883 */       return new AutoModRuleEditSpec(this);
/*     */     }
/*     */     
/*     */     private boolean actionsIsSet() {
/* 887 */       return ((this.optBits & 0x1L) != 0L);
/*     */     }
/*     */     
/*     */     private boolean exemptRolesIsSet() {
/* 891 */       return ((this.optBits & 0x2L) != 0L);
/*     */     }
/*     */     
/*     */     private boolean exemptChannelsIsSet() {
/* 895 */       return ((this.optBits & 0x4L) != 0L);
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 899 */       List<String> attributes = new ArrayList<>();
/* 900 */       if ((this.initBits & 0x1L) != 0L) attributes.add("name"); 
/* 901 */       if ((this.initBits & 0x2L) != 0L) attributes.add("eventType"); 
/* 902 */       if ((this.initBits & 0x4L) != 0L) attributes.add("enabled"); 
/* 903 */       return "Cannot build AutoModRuleEditSpec, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Possible<AutoModTriggerMetaData> triggerMetaData_build() {
/* 907 */       return this.triggerMetaData_possible;
/*     */     }
/*     */     private Builder() {} }
/*     */   
/*     */   private static <T> List<T> createSafeList(Iterable<? extends T> iterable, boolean checkNulls, boolean skipNulls) {
/*     */     ArrayList<T> list;
/* 913 */     if (iterable instanceof Collection) {
/* 914 */       int size = ((Collection)iterable).size();
/* 915 */       if (size == 0) return Collections.emptyList(); 
/* 916 */       list = new ArrayList<>();
/*     */     } else {
/* 918 */       list = new ArrayList<>();
/*     */     } 
/* 920 */     for (T element : iterable) {
/* 921 */       if (skipNulls && element == null)
/* 922 */         continue;  if (checkNulls) Objects.requireNonNull(element, "element"); 
/* 923 */       list.add(element);
/*     */     } 
/* 925 */     return list;
/*     */   }
/*     */   
/*     */   private static <T> List<T> createUnmodifiableList(boolean clone, List<T> list) {
/* 929 */     switch (list.size()) { case 0:
/* 930 */         return Collections.emptyList();
/* 931 */       case 1: return Collections.singletonList(list.get(0)); }
/*     */     
/* 933 */     if (clone) {
/* 934 */       return Collections.unmodifiableList(new ArrayList<>(list));
/*     */     }
/* 936 */     if (list instanceof ArrayList) {
/* 937 */       ((ArrayList)list).trimToSize();
/*     */     }
/* 939 */     return Collections.unmodifiableList(list);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\AutoModRuleEditSpec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */