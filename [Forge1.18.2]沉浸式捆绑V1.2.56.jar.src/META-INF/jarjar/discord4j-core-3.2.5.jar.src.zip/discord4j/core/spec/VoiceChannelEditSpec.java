/*      */ package discord4j.core.spec;
/*      */ 
/*      */ import com.google.errorprone.annotations.CanIgnoreReturnValue;
/*      */ import discord4j.common.util.Snowflake;
/*      */ import discord4j.core.object.PermissionOverwrite;
/*      */ import discord4j.core.object.entity.channel.VoiceChannel;
/*      */ import discord4j.discordjson.possible.Possible;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.List;
/*      */ import java.util.Objects;
/*      */ import java.util.Optional;
/*      */ import java.util.stream.Collectors;
/*      */ import java.util.stream.StreamSupport;
/*      */ import org.immutables.value.Generated;
/*      */ import reactor.util.annotation.Nullable;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ @Generated(from = "VoiceChannelEditSpecGenerator", generator = "Immutables")
/*      */ public final class VoiceChannelEditSpec
/*      */   implements VoiceChannelEditSpecGenerator
/*      */ {
/*      */   @Nullable
/*      */   private final String reason;
/*      */   private final String name_value;
/*      */   private final boolean name_absent;
/*      */   private final Integer bitrate_value;
/*      */   private final boolean bitrate_absent;
/*      */   private final Integer userLimit_value;
/*      */   private final boolean userLimit_absent;
/*      */   private final Integer position_value;
/*      */   private final boolean position_absent;
/*      */   private final Integer rateLimitPerUser_value;
/*      */   private final boolean rateLimitPerUser_absent;
/*      */   private final List<PermissionOverwrite> permissionOverwrites_value;
/*      */   private final boolean permissionOverwrites_absent;
/*      */   private final Snowflake parentId_value;
/*      */   private final boolean parentId_absent;
/*      */   private final String rtcRegion_value;
/*      */   private final boolean rtcRegion_absent;
/*      */   private final VoiceChannel.Mode videoQualityMode_value;
/*      */   private final boolean videoQualityMode_absent;
/*      */   private static final byte STAGE_INITIALIZING = -1;
/*      */   private static final byte STAGE_UNINITIALIZED = 0;
/*      */   private static final byte STAGE_INITIALIZED = 1;
/*      */   
/*      */   private VoiceChannelEditSpec() {
/*   52 */     this.reason = null;
/*   53 */     Possible<String> name$impl = Possible.absent();
/*   54 */     Possible<Integer> bitrate$impl = Possible.absent();
/*   55 */     Possible<Integer> userLimit$impl = Possible.absent();
/*   56 */     Possible<Integer> position$impl = Possible.absent();
/*   57 */     Possible<Integer> rateLimitPerUser$impl = Possible.absent();
/*   58 */     Possible<List<PermissionOverwrite>> permissionOverwrites$impl = Possible.absent();
/*   59 */     Possible<Optional<Snowflake>> parentId$impl = Possible.absent();
/*   60 */     Possible<Optional<String>> rtcRegion$impl = Possible.absent();
/*   61 */     Possible<Optional<VoiceChannel.Mode>> videoQualityMode$impl = Possible.absent();
/*   62 */     this.name_value = name$impl.toOptional().orElse(null);
/*   63 */     this.name_absent = name$impl.isAbsent();
/*   64 */     this.bitrate_value = bitrate$impl.toOptional().orElse(null);
/*   65 */     this.bitrate_absent = bitrate$impl.isAbsent();
/*   66 */     this.userLimit_value = userLimit$impl.toOptional().orElse(null);
/*   67 */     this.userLimit_absent = userLimit$impl.isAbsent();
/*   68 */     this.position_value = position$impl.toOptional().orElse(null);
/*   69 */     this.position_absent = position$impl.isAbsent();
/*   70 */     this.rateLimitPerUser_value = rateLimitPerUser$impl.toOptional().orElse(null);
/*   71 */     this.rateLimitPerUser_absent = rateLimitPerUser$impl.isAbsent();
/*   72 */     this.permissionOverwrites_value = permissionOverwrites$impl.toOptional().orElse(null);
/*   73 */     this.permissionOverwrites_absent = permissionOverwrites$impl.isAbsent();
/*   74 */     this.parentId_value = Possible.flatOpt(parentId$impl).orElse(null);
/*   75 */     this.parentId_absent = parentId$impl.isAbsent();
/*   76 */     this.rtcRegion_value = Possible.flatOpt(rtcRegion$impl).orElse(null);
/*   77 */     this.rtcRegion_absent = rtcRegion$impl.isAbsent();
/*   78 */     this.videoQualityMode_value = Possible.flatOpt(videoQualityMode$impl).orElse(null);
/*   79 */     this.videoQualityMode_absent = videoQualityMode$impl.isAbsent();
/*   80 */     this.initShim = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private VoiceChannelEditSpec(@Nullable String reason, Possible<String> name, Possible<Integer> bitrate, Possible<Integer> userLimit, Possible<Integer> position, Possible<Integer> rateLimitPerUser, Possible<List<PermissionOverwrite>> permissionOverwrites, Possible<Optional<Snowflake>> parentId, Possible<Optional<String>> rtcRegion, Possible<Optional<VoiceChannel.Mode>> videoQualityMode) {
/*   94 */     this.reason = reason;
/*   95 */     Possible<String> name$impl = name;
/*   96 */     Possible<Integer> bitrate$impl = bitrate;
/*   97 */     Possible<Integer> userLimit$impl = userLimit;
/*   98 */     Possible<Integer> position$impl = position;
/*   99 */     Possible<Integer> rateLimitPerUser$impl = rateLimitPerUser;
/*  100 */     Possible<List<PermissionOverwrite>> permissionOverwrites$impl = permissionOverwrites;
/*  101 */     Possible<Optional<Snowflake>> parentId$impl = parentId;
/*  102 */     Possible<Optional<String>> rtcRegion$impl = rtcRegion;
/*  103 */     Possible<Optional<VoiceChannel.Mode>> videoQualityMode$impl = videoQualityMode;
/*  104 */     this.name_value = name$impl.toOptional().orElse(null);
/*  105 */     this.name_absent = name$impl.isAbsent();
/*  106 */     this.bitrate_value = bitrate$impl.toOptional().orElse(null);
/*  107 */     this.bitrate_absent = bitrate$impl.isAbsent();
/*  108 */     this.userLimit_value = userLimit$impl.toOptional().orElse(null);
/*  109 */     this.userLimit_absent = userLimit$impl.isAbsent();
/*  110 */     this.position_value = position$impl.toOptional().orElse(null);
/*  111 */     this.position_absent = position$impl.isAbsent();
/*  112 */     this.rateLimitPerUser_value = rateLimitPerUser$impl.toOptional().orElse(null);
/*  113 */     this.rateLimitPerUser_absent = rateLimitPerUser$impl.isAbsent();
/*  114 */     this.permissionOverwrites_value = permissionOverwrites$impl.toOptional().orElse(null);
/*  115 */     this.permissionOverwrites_absent = permissionOverwrites$impl.isAbsent();
/*  116 */     this.parentId_value = Possible.flatOpt(parentId$impl).orElse(null);
/*  117 */     this.parentId_absent = parentId$impl.isAbsent();
/*  118 */     this.rtcRegion_value = Possible.flatOpt(rtcRegion$impl).orElse(null);
/*  119 */     this.rtcRegion_absent = rtcRegion$impl.isAbsent();
/*  120 */     this.videoQualityMode_value = Possible.flatOpt(videoQualityMode$impl).orElse(null);
/*  121 */     this.videoQualityMode_absent = videoQualityMode$impl.isAbsent();
/*  122 */     this.initShim = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  128 */   private volatile transient InitShim initShim = new InitShim();
/*      */   
/*      */   @Generated(from = "VoiceChannelEditSpecGenerator", generator = "Immutables")
/*      */   private final class InitShim
/*      */   {
/*      */     private String formatInitCycleMessage() {
/*  134 */       List<String> attributes = new ArrayList<>();
/*  135 */       return "Cannot build VoiceChannelEditSpec, attribute initializers form cycle " + attributes;
/*      */     }
/*      */ 
/*      */     
/*      */     private InitShim() {}
/*      */   }
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public String reason() {
/*  145 */     return this.reason;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Possible<String> name() {
/*  153 */     return this.name_absent ? Possible.absent() : Possible.of(this.name_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Possible<Integer> bitrate() {
/*  161 */     return this.bitrate_absent ? Possible.absent() : Possible.of(this.bitrate_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Possible<Integer> userLimit() {
/*  169 */     return this.userLimit_absent ? Possible.absent() : Possible.of(this.userLimit_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Possible<Integer> position() {
/*  177 */     return this.position_absent ? Possible.absent() : Possible.of(this.position_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Possible<Integer> rateLimitPerUser() {
/*  185 */     return this.rateLimitPerUser_absent ? Possible.absent() : Possible.of(this.rateLimitPerUser_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Possible<List<PermissionOverwrite>> permissionOverwrites() {
/*  193 */     return this.permissionOverwrites_absent ? Possible.absent() : 
/*  194 */       Possible.of(this.permissionOverwrites_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Possible<Optional<Snowflake>> parentId() {
/*  202 */     return this.parentId_absent ? Possible.absent() : 
/*  203 */       Possible.of(Optional.ofNullable(this.parentId_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Possible<Optional<String>> rtcRegion() {
/*  211 */     return this.rtcRegion_absent ? Possible.absent() : 
/*  212 */       Possible.of(Optional.ofNullable(this.rtcRegion_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Possible<Optional<VoiceChannel.Mode>> videoQualityMode() {
/*  220 */     return this.videoQualityMode_absent ? Possible.absent() : 
/*  221 */       Possible.of(Optional.ofNullable(this.videoQualityMode_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final VoiceChannelEditSpec withReason(@Nullable String value) {
/*  231 */     if (Objects.equals(this.reason, value)) return this; 
/*  232 */     return validate(new VoiceChannelEditSpec(value, 
/*      */           
/*  234 */           name(), 
/*  235 */           bitrate(), 
/*  236 */           userLimit(), 
/*  237 */           position(), 
/*  238 */           rateLimitPerUser(), 
/*  239 */           permissionOverwrites(), 
/*  240 */           parentId(), 
/*  241 */           rtcRegion(), 
/*  242 */           videoQualityMode()));
/*      */   }
/*      */   
/*      */   public VoiceChannelEditSpec withName(Possible<String> value) {
/*  246 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/*  247 */     return validate(new VoiceChannelEditSpec(this.reason, newValue, 
/*      */ 
/*      */           
/*  250 */           bitrate(), 
/*  251 */           userLimit(), 
/*  252 */           position(), 
/*  253 */           rateLimitPerUser(), 
/*  254 */           permissionOverwrites(), 
/*  255 */           parentId(), 
/*  256 */           rtcRegion(), 
/*  257 */           videoQualityMode()));
/*      */   }
/*      */   
/*      */   public VoiceChannelEditSpec withName(String value) {
/*  261 */     Possible<String> newValue = Possible.of(value);
/*  262 */     return validate(new VoiceChannelEditSpec(this.reason, newValue, 
/*      */ 
/*      */           
/*  265 */           bitrate(), 
/*  266 */           userLimit(), 
/*  267 */           position(), 
/*  268 */           rateLimitPerUser(), 
/*  269 */           permissionOverwrites(), 
/*  270 */           parentId(), 
/*  271 */           rtcRegion(), 
/*  272 */           videoQualityMode()));
/*      */   }
/*      */   
/*      */   public VoiceChannelEditSpec withBitrate(Possible<Integer> value) {
/*  276 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/*  277 */     return validate(new VoiceChannelEditSpec(this.reason, 
/*      */           
/*  279 */           name(), newValue, 
/*      */           
/*  281 */           userLimit(), 
/*  282 */           position(), 
/*  283 */           rateLimitPerUser(), 
/*  284 */           permissionOverwrites(), 
/*  285 */           parentId(), 
/*  286 */           rtcRegion(), 
/*  287 */           videoQualityMode()));
/*      */   }
/*      */   
/*      */   public VoiceChannelEditSpec withBitrate(Integer value) {
/*  291 */     Possible<Integer> newValue = Possible.of(value);
/*  292 */     return validate(new VoiceChannelEditSpec(this.reason, 
/*      */           
/*  294 */           name(), newValue, 
/*      */           
/*  296 */           userLimit(), 
/*  297 */           position(), 
/*  298 */           rateLimitPerUser(), 
/*  299 */           permissionOverwrites(), 
/*  300 */           parentId(), 
/*  301 */           rtcRegion(), 
/*  302 */           videoQualityMode()));
/*      */   }
/*      */   
/*      */   public VoiceChannelEditSpec withUserLimit(Possible<Integer> value) {
/*  306 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/*  307 */     return validate(new VoiceChannelEditSpec(this.reason, 
/*      */           
/*  309 */           name(), 
/*  310 */           bitrate(), newValue, 
/*      */           
/*  312 */           position(), 
/*  313 */           rateLimitPerUser(), 
/*  314 */           permissionOverwrites(), 
/*  315 */           parentId(), 
/*  316 */           rtcRegion(), 
/*  317 */           videoQualityMode()));
/*      */   }
/*      */   
/*      */   public VoiceChannelEditSpec withUserLimit(Integer value) {
/*  321 */     Possible<Integer> newValue = Possible.of(value);
/*  322 */     return validate(new VoiceChannelEditSpec(this.reason, 
/*      */           
/*  324 */           name(), 
/*  325 */           bitrate(), newValue, 
/*      */           
/*  327 */           position(), 
/*  328 */           rateLimitPerUser(), 
/*  329 */           permissionOverwrites(), 
/*  330 */           parentId(), 
/*  331 */           rtcRegion(), 
/*  332 */           videoQualityMode()));
/*      */   }
/*      */   
/*      */   public VoiceChannelEditSpec withPosition(Possible<Integer> value) {
/*  336 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/*  337 */     return validate(new VoiceChannelEditSpec(this.reason, 
/*      */           
/*  339 */           name(), 
/*  340 */           bitrate(), 
/*  341 */           userLimit(), newValue, 
/*      */           
/*  343 */           rateLimitPerUser(), 
/*  344 */           permissionOverwrites(), 
/*  345 */           parentId(), 
/*  346 */           rtcRegion(), 
/*  347 */           videoQualityMode()));
/*      */   }
/*      */   
/*      */   public VoiceChannelEditSpec withPosition(Integer value) {
/*  351 */     Possible<Integer> newValue = Possible.of(value);
/*  352 */     return validate(new VoiceChannelEditSpec(this.reason, 
/*      */           
/*  354 */           name(), 
/*  355 */           bitrate(), 
/*  356 */           userLimit(), newValue, 
/*      */           
/*  358 */           rateLimitPerUser(), 
/*  359 */           permissionOverwrites(), 
/*  360 */           parentId(), 
/*  361 */           rtcRegion(), 
/*  362 */           videoQualityMode()));
/*      */   }
/*      */   
/*      */   public VoiceChannelEditSpec withRateLimitPerUser(Possible<Integer> value) {
/*  366 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/*  367 */     return validate(new VoiceChannelEditSpec(this.reason, 
/*      */           
/*  369 */           name(), 
/*  370 */           bitrate(), 
/*  371 */           userLimit(), 
/*  372 */           position(), newValue, 
/*      */           
/*  374 */           permissionOverwrites(), 
/*  375 */           parentId(), 
/*  376 */           rtcRegion(), 
/*  377 */           videoQualityMode()));
/*      */   }
/*      */   
/*      */   public VoiceChannelEditSpec withRateLimitPerUser(Integer value) {
/*  381 */     Possible<Integer> newValue = Possible.of(value);
/*  382 */     return validate(new VoiceChannelEditSpec(this.reason, 
/*      */           
/*  384 */           name(), 
/*  385 */           bitrate(), 
/*  386 */           userLimit(), 
/*  387 */           position(), newValue, 
/*      */           
/*  389 */           permissionOverwrites(), 
/*  390 */           parentId(), 
/*  391 */           rtcRegion(), 
/*  392 */           videoQualityMode()));
/*      */   }
/*      */   
/*      */   public VoiceChannelEditSpec withPermissionOverwrites(Possible<List<PermissionOverwrite>> possible) {
/*  396 */     Possible<List<PermissionOverwrite>> newValue = Objects.<Possible<List<PermissionOverwrite>>>requireNonNull(possible);
/*  397 */     return validate(new VoiceChannelEditSpec(this.reason, 
/*      */           
/*  399 */           name(), 
/*  400 */           bitrate(), 
/*  401 */           userLimit(), 
/*  402 */           position(), 
/*  403 */           rateLimitPerUser(), newValue, 
/*      */           
/*  405 */           parentId(), 
/*  406 */           rtcRegion(), 
/*  407 */           videoQualityMode()));
/*      */   }
/*      */   
/*      */   public VoiceChannelEditSpec withPermissionOverwrites(Iterable<PermissionOverwrite> elements) {
/*  411 */     Possible<List<PermissionOverwrite>> newValue = Possible.of(
/*  412 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/*  413 */     return validate(new VoiceChannelEditSpec(this.reason, 
/*      */           
/*  415 */           name(), 
/*  416 */           bitrate(), 
/*  417 */           userLimit(), 
/*  418 */           position(), 
/*  419 */           rateLimitPerUser(), newValue, 
/*      */           
/*  421 */           parentId(), 
/*  422 */           rtcRegion(), 
/*  423 */           videoQualityMode()));
/*      */   }
/*      */   
/*      */   @SafeVarargs
/*      */   public final VoiceChannelEditSpec withPermissionOverwrites(PermissionOverwrite... elements) {
/*  428 */     Possible<List<PermissionOverwrite>> newValue = Possible.of(Arrays.asList(elements));
/*  429 */     return validate(new VoiceChannelEditSpec(this.reason, 
/*      */           
/*  431 */           name(), 
/*  432 */           bitrate(), 
/*  433 */           userLimit(), 
/*  434 */           position(), 
/*  435 */           rateLimitPerUser(), newValue, 
/*      */           
/*  437 */           parentId(), 
/*  438 */           rtcRegion(), 
/*  439 */           videoQualityMode()));
/*      */   }
/*      */   
/*      */   public VoiceChannelEditSpec withParentId(Possible<Optional<Snowflake>> value) {
/*  443 */     Possible<Optional<Snowflake>> newValue = Objects.<Possible<Optional<Snowflake>>>requireNonNull(value);
/*  444 */     return validate(new VoiceChannelEditSpec(this.reason, 
/*      */           
/*  446 */           name(), 
/*  447 */           bitrate(), 
/*  448 */           userLimit(), 
/*  449 */           position(), 
/*  450 */           rateLimitPerUser(), 
/*  451 */           permissionOverwrites(), newValue, 
/*      */           
/*  453 */           rtcRegion(), 
/*  454 */           videoQualityMode()));
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public VoiceChannelEditSpec withParentId(@Nullable Snowflake value) {
/*  459 */     Possible<Optional<Snowflake>> newValue = Possible.of(Optional.ofNullable(value));
/*  460 */     return validate(new VoiceChannelEditSpec(this.reason, 
/*      */           
/*  462 */           name(), 
/*  463 */           bitrate(), 
/*  464 */           userLimit(), 
/*  465 */           position(), 
/*  466 */           rateLimitPerUser(), 
/*  467 */           permissionOverwrites(), newValue, 
/*      */           
/*  469 */           rtcRegion(), 
/*  470 */           videoQualityMode()));
/*      */   }
/*      */   
/*      */   public VoiceChannelEditSpec withParentIdOrNull(@Nullable Snowflake value) {
/*  474 */     Possible<Optional<Snowflake>> newValue = Possible.of(Optional.ofNullable(value));
/*  475 */     return validate(new VoiceChannelEditSpec(this.reason, 
/*      */           
/*  477 */           name(), 
/*  478 */           bitrate(), 
/*  479 */           userLimit(), 
/*  480 */           position(), 
/*  481 */           rateLimitPerUser(), 
/*  482 */           permissionOverwrites(), newValue, 
/*      */           
/*  484 */           rtcRegion(), 
/*  485 */           videoQualityMode()));
/*      */   }
/*      */   
/*      */   public VoiceChannelEditSpec withRtcRegion(Possible<Optional<String>> value) {
/*  489 */     Possible<Optional<String>> newValue = Objects.<Possible<Optional<String>>>requireNonNull(value);
/*  490 */     return validate(new VoiceChannelEditSpec(this.reason, 
/*      */           
/*  492 */           name(), 
/*  493 */           bitrate(), 
/*  494 */           userLimit(), 
/*  495 */           position(), 
/*  496 */           rateLimitPerUser(), 
/*  497 */           permissionOverwrites(), 
/*  498 */           parentId(), newValue, 
/*      */           
/*  500 */           videoQualityMode()));
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public VoiceChannelEditSpec withRtcRegion(@Nullable String value) {
/*  505 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/*  506 */     return validate(new VoiceChannelEditSpec(this.reason, 
/*      */           
/*  508 */           name(), 
/*  509 */           bitrate(), 
/*  510 */           userLimit(), 
/*  511 */           position(), 
/*  512 */           rateLimitPerUser(), 
/*  513 */           permissionOverwrites(), 
/*  514 */           parentId(), newValue, 
/*      */           
/*  516 */           videoQualityMode()));
/*      */   }
/*      */   
/*      */   public VoiceChannelEditSpec withRtcRegionOrNull(@Nullable String value) {
/*  520 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/*  521 */     return validate(new VoiceChannelEditSpec(this.reason, 
/*      */           
/*  523 */           name(), 
/*  524 */           bitrate(), 
/*  525 */           userLimit(), 
/*  526 */           position(), 
/*  527 */           rateLimitPerUser(), 
/*  528 */           permissionOverwrites(), 
/*  529 */           parentId(), newValue, 
/*      */           
/*  531 */           videoQualityMode()));
/*      */   }
/*      */   
/*      */   public VoiceChannelEditSpec withVideoQualityMode(Possible<Optional<VoiceChannel.Mode>> value) {
/*  535 */     Possible<Optional<VoiceChannel.Mode>> newValue = Objects.<Possible<Optional<VoiceChannel.Mode>>>requireNonNull(value);
/*  536 */     return validate(new VoiceChannelEditSpec(this.reason, 
/*      */           
/*  538 */           name(), 
/*  539 */           bitrate(), 
/*  540 */           userLimit(), 
/*  541 */           position(), 
/*  542 */           rateLimitPerUser(), 
/*  543 */           permissionOverwrites(), 
/*  544 */           parentId(), 
/*  545 */           rtcRegion(), newValue));
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public VoiceChannelEditSpec withVideoQualityMode(@Nullable VoiceChannel.Mode value) {
/*  551 */     Possible<Optional<VoiceChannel.Mode>> newValue = Possible.of(Optional.ofNullable(value));
/*  552 */     return validate(new VoiceChannelEditSpec(this.reason, 
/*      */           
/*  554 */           name(), 
/*  555 */           bitrate(), 
/*  556 */           userLimit(), 
/*  557 */           position(), 
/*  558 */           rateLimitPerUser(), 
/*  559 */           permissionOverwrites(), 
/*  560 */           parentId(), 
/*  561 */           rtcRegion(), newValue));
/*      */   }
/*      */ 
/*      */   
/*      */   public VoiceChannelEditSpec withVideoQualityModeOrNull(@Nullable VoiceChannel.Mode value) {
/*  566 */     Possible<Optional<VoiceChannel.Mode>> newValue = Possible.of(Optional.ofNullable(value));
/*  567 */     return validate(new VoiceChannelEditSpec(this.reason, 
/*      */           
/*  569 */           name(), 
/*  570 */           bitrate(), 
/*  571 */           userLimit(), 
/*  572 */           position(), 
/*  573 */           rateLimitPerUser(), 
/*  574 */           permissionOverwrites(), 
/*  575 */           parentId(), 
/*  576 */           rtcRegion(), newValue));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean equals(Object another) {
/*  586 */     if (this == another) return true; 
/*  587 */     return (another instanceof VoiceChannelEditSpec && 
/*  588 */       equalTo(0, (VoiceChannelEditSpec)another));
/*      */   }
/*      */   
/*      */   private boolean equalTo(int synthetic, VoiceChannelEditSpec another) {
/*  592 */     return (Objects.equals(this.reason, another.reason) && 
/*  593 */       name().equals(another.name()) && 
/*  594 */       bitrate().equals(another.bitrate()) && 
/*  595 */       userLimit().equals(another.userLimit()) && 
/*  596 */       position().equals(another.position()) && 
/*  597 */       rateLimitPerUser().equals(another.rateLimitPerUser()) && 
/*  598 */       Objects.equals(this.permissionOverwrites_value, another.permissionOverwrites_value) && 
/*  599 */       parentId().equals(another.parentId()) && 
/*  600 */       rtcRegion().equals(another.rtcRegion()) && 
/*  601 */       videoQualityMode().equals(another.videoQualityMode()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int hashCode() {
/*  610 */     int h = 5381;
/*  611 */     h += (h << 5) + Objects.hashCode(this.reason);
/*  612 */     h += (h << 5) + name().hashCode();
/*  613 */     h += (h << 5) + bitrate().hashCode();
/*  614 */     h += (h << 5) + userLimit().hashCode();
/*  615 */     h += (h << 5) + position().hashCode();
/*  616 */     h += (h << 5) + rateLimitPerUser().hashCode();
/*  617 */     h += (h << 5) + Objects.hashCode(this.permissionOverwrites_value);
/*  618 */     h += (h << 5) + parentId().hashCode();
/*  619 */     h += (h << 5) + rtcRegion().hashCode();
/*  620 */     h += (h << 5) + videoQualityMode().hashCode();
/*  621 */     return h;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/*  630 */     return "VoiceChannelEditSpec{reason=" + this.reason + ", name=" + 
/*      */       
/*  632 */       name().toString() + ", bitrate=" + 
/*  633 */       bitrate().toString() + ", userLimit=" + 
/*  634 */       userLimit().toString() + ", position=" + 
/*  635 */       position().toString() + ", rateLimitPerUser=" + 
/*  636 */       rateLimitPerUser().toString() + ", permissionOverwrites=" + 
/*  637 */       Objects.toString(this.permissionOverwrites_value) + ", parentId=" + 
/*  638 */       parentId().toString() + ", rtcRegion=" + 
/*  639 */       rtcRegion().toString() + ", videoQualityMode=" + 
/*  640 */       videoQualityMode().toString() + "}";
/*      */   }
/*      */ 
/*      */   
/*  644 */   private static final VoiceChannelEditSpec INSTANCE = validate(new VoiceChannelEditSpec());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static VoiceChannelEditSpec create() {
/*  651 */     return INSTANCE;
/*      */   }
/*      */   
/*      */   private static VoiceChannelEditSpec validate(VoiceChannelEditSpec instance) {
/*  655 */     return (INSTANCE != null && INSTANCE.equalTo(0, instance)) ? INSTANCE : instance;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static VoiceChannelEditSpec copyOf(VoiceChannelEditSpecGenerator instance) {
/*  666 */     if (instance instanceof VoiceChannelEditSpec) {
/*  667 */       return (VoiceChannelEditSpec)instance;
/*      */     }
/*  669 */     return builder()
/*  670 */       .from(instance)
/*  671 */       .build();
/*      */   }
/*      */   
/*      */   public boolean isNamePresent() {
/*  675 */     return !this.name_absent;
/*      */   }
/*      */   
/*      */   public String nameOrElse(String defaultValue) {
/*  679 */     return !this.name_absent ? this.name_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isBitratePresent() {
/*  683 */     return !this.bitrate_absent;
/*      */   }
/*      */   
/*      */   public Integer bitrateOrElse(Integer defaultValue) {
/*  687 */     return !this.bitrate_absent ? this.bitrate_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isUserLimitPresent() {
/*  691 */     return !this.userLimit_absent;
/*      */   }
/*      */   
/*      */   public Integer userLimitOrElse(Integer defaultValue) {
/*  695 */     return !this.userLimit_absent ? this.userLimit_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isPositionPresent() {
/*  699 */     return !this.position_absent;
/*      */   }
/*      */   
/*      */   public Integer positionOrElse(Integer defaultValue) {
/*  703 */     return !this.position_absent ? this.position_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isRateLimitPerUserPresent() {
/*  707 */     return !this.rateLimitPerUser_absent;
/*      */   }
/*      */   
/*      */   public Integer rateLimitPerUserOrElse(Integer defaultValue) {
/*  711 */     return !this.rateLimitPerUser_absent ? this.rateLimitPerUser_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isPermissionOverwritesPresent() {
/*  715 */     return !this.permissionOverwrites_absent;
/*      */   }
/*      */   
/*      */   public List<PermissionOverwrite> permissionOverwritesOrElse(List<PermissionOverwrite> defaultValue) {
/*  719 */     return !this.permissionOverwrites_absent ? this.permissionOverwrites_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isParentIdPresent() {
/*  723 */     return !this.parentId_absent;
/*      */   }
/*      */   
/*      */   public Snowflake parentIdOrElse(Snowflake defaultValue) {
/*  727 */     return !this.parentId_absent ? this.parentId_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isRtcRegionPresent() {
/*  731 */     return !this.rtcRegion_absent;
/*      */   }
/*      */   
/*      */   public String rtcRegionOrElse(String defaultValue) {
/*  735 */     return !this.rtcRegion_absent ? this.rtcRegion_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isVideoQualityModePresent() {
/*  739 */     return !this.videoQualityMode_absent;
/*      */   }
/*      */   
/*      */   public VoiceChannel.Mode videoQualityModeOrElse(VoiceChannel.Mode defaultValue) {
/*  743 */     return !this.videoQualityMode_absent ? this.videoQualityMode_value : defaultValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Builder builder() {
/*  765 */     return new Builder();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Generated(from = "VoiceChannelEditSpecGenerator", generator = "Immutables")
/*      */   public static final class Builder
/*      */   {
/*  777 */     private Possible<String> name_possible = Possible.absent();
/*  778 */     private Possible<Integer> bitrate_possible = Possible.absent();
/*  779 */     private Possible<Integer> userLimit_possible = Possible.absent();
/*  780 */     private Possible<Integer> position_possible = Possible.absent();
/*  781 */     private Possible<Integer> rateLimitPerUser_possible = Possible.absent();
/*  782 */     private List<PermissionOverwrite> permissionOverwrites_list = null;
/*  783 */     private Possible<Optional<Snowflake>> parentId_possible = Possible.absent();
/*  784 */     private Possible<Optional<String>> rtcRegion_possible = Possible.absent();
/*  785 */     private Possible<Optional<VoiceChannel.Mode>> videoQualityMode_possible = Possible.absent();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private String reason;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder from(VoiceChannelEditSpec instance) {
/*  799 */       return from(instance);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     final Builder from(VoiceChannelEditSpecGenerator instance) {
/*  809 */       Objects.requireNonNull(instance, "instance");
/*  810 */       String reasonValue = instance.reason();
/*  811 */       if (reasonValue != null) {
/*  812 */         reason(reasonValue);
/*      */       }
/*  814 */       name(instance.name());
/*  815 */       bitrate(instance.bitrate());
/*  816 */       userLimit(instance.userLimit());
/*  817 */       position(instance.position());
/*  818 */       rateLimitPerUser(instance.rateLimitPerUser());
/*  819 */       permissionOverwrites(instance.permissionOverwrites());
/*  820 */       parentId(instance.parentId());
/*  821 */       rtcRegion(instance.rtcRegion());
/*  822 */       videoQualityMode(instance.videoQualityMode());
/*  823 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public final Builder reason(@Nullable String reason) {
/*  833 */       this.reason = reason;
/*  834 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder name(Possible<String> value) {
/*  839 */       this.name_possible = value;
/*  840 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder name(String value) {
/*  845 */       this.name_possible = Possible.of(value);
/*  846 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder bitrate(Possible<Integer> value) {
/*  851 */       this.bitrate_possible = value;
/*  852 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder bitrate(Integer value) {
/*  857 */       this.bitrate_possible = Possible.of(value);
/*  858 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder userLimit(Possible<Integer> value) {
/*  863 */       this.userLimit_possible = value;
/*  864 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder userLimit(Integer value) {
/*  869 */       this.userLimit_possible = Possible.of(value);
/*  870 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder position(Possible<Integer> value) {
/*  875 */       this.position_possible = value;
/*  876 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder position(Integer value) {
/*  881 */       this.position_possible = Possible.of(value);
/*  882 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder rateLimitPerUser(Possible<Integer> value) {
/*  887 */       this.rateLimitPerUser_possible = value;
/*  888 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder rateLimitPerUser(Integer value) {
/*  893 */       this.rateLimitPerUser_possible = Possible.of(value);
/*  894 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder addPermissionOverwrite(PermissionOverwrite element) {
/*  899 */       permissionOverwrites_getOrCreate().add(element);
/*  900 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder addAllPermissionOverwrites(List<PermissionOverwrite> elements) {
/*  905 */       permissionOverwrites_getOrCreate().addAll(elements);
/*  906 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder permissionOverwrites(Possible<List<PermissionOverwrite>> elements) {
/*  911 */       this.permissionOverwrites_list = null;
/*  912 */       elements.toOptional().ifPresent(e -> permissionOverwrites_getOrCreate().addAll(e));
/*  913 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder permissionOverwrites(List<PermissionOverwrite> elements) {
/*  918 */       this.permissionOverwrites_list = new ArrayList<>(elements);
/*  919 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder permissionOverwrites(Iterable<PermissionOverwrite> elements) {
/*  924 */       this.permissionOverwrites_list = (List<PermissionOverwrite>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/*  925 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder parentId(Possible<Optional<Snowflake>> value) {
/*  930 */       this.parentId_possible = value;
/*  931 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     @CanIgnoreReturnValue
/*      */     public Builder parentId(@Nullable Snowflake value) {
/*  937 */       this.parentId_possible = Possible.of(Optional.ofNullable(value));
/*  938 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder parentIdOrNull(@Nullable Snowflake value) {
/*  943 */       this.parentId_possible = Possible.of(Optional.ofNullable(value));
/*  944 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder rtcRegion(Possible<Optional<String>> value) {
/*  949 */       this.rtcRegion_possible = value;
/*  950 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     @CanIgnoreReturnValue
/*      */     public Builder rtcRegion(@Nullable String value) {
/*  956 */       this.rtcRegion_possible = Possible.of(Optional.ofNullable(value));
/*  957 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder rtcRegionOrNull(@Nullable String value) {
/*  962 */       this.rtcRegion_possible = Possible.of(Optional.ofNullable(value));
/*  963 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder videoQualityMode(Possible<Optional<VoiceChannel.Mode>> value) {
/*  968 */       this.videoQualityMode_possible = value;
/*  969 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     @CanIgnoreReturnValue
/*      */     public Builder videoQualityMode(@Nullable VoiceChannel.Mode value) {
/*  975 */       this.videoQualityMode_possible = Possible.of(Optional.ofNullable(value));
/*  976 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder videoQualityModeOrNull(@Nullable VoiceChannel.Mode value) {
/*  981 */       this.videoQualityMode_possible = Possible.of(Optional.ofNullable(value));
/*  982 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public VoiceChannelEditSpec build() {
/*  991 */       return VoiceChannelEditSpec.validate(new VoiceChannelEditSpec(this.reason, 
/*      */             
/*  993 */             name_build(), 
/*  994 */             bitrate_build(), 
/*  995 */             userLimit_build(), 
/*  996 */             position_build(), 
/*  997 */             rateLimitPerUser_build(), 
/*  998 */             permissionOverwrites_build(), 
/*  999 */             parentId_build(), 
/* 1000 */             rtcRegion_build(), 
/* 1001 */             videoQualityMode_build()));
/*      */     }
/*      */     
/*      */     private Possible<String> name_build() {
/* 1005 */       return this.name_possible;
/*      */     }
/*      */     
/*      */     private Possible<Integer> bitrate_build() {
/* 1009 */       return this.bitrate_possible;
/*      */     }
/*      */     
/*      */     private Possible<Integer> userLimit_build() {
/* 1013 */       return this.userLimit_possible;
/*      */     }
/*      */     
/*      */     private Possible<Integer> position_build() {
/* 1017 */       return this.position_possible;
/*      */     }
/*      */     
/*      */     private Possible<Integer> rateLimitPerUser_build() {
/* 1021 */       return this.rateLimitPerUser_possible;
/*      */     }
/*      */     
/*      */     private Possible<List<PermissionOverwrite>> permissionOverwrites_build() {
/* 1025 */       return (this.permissionOverwrites_list == null) ? Possible.absent() : 
/* 1026 */         Possible.of(this.permissionOverwrites_list);
/*      */     }
/*      */     
/*      */     private List<PermissionOverwrite> permissionOverwrites_getOrCreate() {
/* 1030 */       if (this.permissionOverwrites_list == null) {
/* 1031 */         this.permissionOverwrites_list = new ArrayList<>();
/*      */       }
/* 1033 */       return this.permissionOverwrites_list;
/*      */     }
/*      */     
/*      */     private Possible<Optional<Snowflake>> parentId_build() {
/* 1037 */       return this.parentId_possible;
/*      */     }
/*      */     
/*      */     private Possible<Optional<String>> rtcRegion_build() {
/* 1041 */       return this.rtcRegion_possible;
/*      */     }
/*      */     
/*      */     private Possible<Optional<VoiceChannel.Mode>> videoQualityMode_build() {
/* 1045 */       return this.videoQualityMode_possible;
/*      */     }
/*      */     
/*      */     private Builder() {}
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\VoiceChannelEditSpec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */