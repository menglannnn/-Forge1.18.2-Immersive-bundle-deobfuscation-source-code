/*     */ package discord4j.core.spec;
/*     */ 
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.object.Region;
/*     */ import discord4j.core.object.entity.Guild;
/*     */ import discord4j.discordjson.json.GuildModifyRequest;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import discord4j.rest.util.Image;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Optional;
/*     */ import java.util.function.Function;
/*     */ import org.immutables.value.Value.Immutable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Immutable(singleton = true)
/*     */ interface GuildEditSpecGenerator
/*     */   extends AuditSpec<GuildModifyRequest>
/*     */ {
/*     */   default GuildModifyRequest asRequest() {
/*  83 */     return (GuildModifyRequest)GuildModifyRequest.builder()
/*  84 */       .name(name())
/*  85 */       .region(InternalSpecUtils.mapPossibleOptional(region(), Region::getId))
/*  86 */       .verificationLevel(InternalSpecUtils.mapPossibleOptional(verificationLevel(), Guild.VerificationLevel::getValue))
/*  87 */       .defaultMessageNotifications(InternalSpecUtils.mapPossibleOptional(defaultMessageNotificationsLevel(), Guild.NotificationLevel::getValue))
/*     */       
/*  89 */       .explicitContentFilter(InternalSpecUtils.mapPossibleOptional(explicitContentFilter(), Guild.ContentFilterLevel::getValue))
/*  90 */       .afkChannelId(InternalSpecUtils.mapPossibleOptional(afkChannelId(), Snowflake::asString))
/*  91 */       .afkTimeout(afkTimeout())
/*  92 */       .icon(InternalSpecUtils.mapPossibleOptional(icon(), Image::getDataUri))
/*  93 */       .ownerId(InternalSpecUtils.mapPossible(ownerId(), Snowflake::asString))
/*  94 */       .splash(InternalSpecUtils.mapPossibleOptional(splash(), Image::getDataUri))
/*  95 */       .discoverySplash(InternalSpecUtils.mapPossibleOptional(discoverySplash(), Image::getDataUri))
/*  96 */       .banner(InternalSpecUtils.mapPossibleOptional(banner(), Image::getDataUri))
/*  97 */       .systemChannelId(InternalSpecUtils.mapPossibleOptional(systemChannelId(), Snowflake::asString))
/*  98 */       .systemChannelFlags(InternalSpecUtils.mapPossible(systemChannelFlags(), Guild.SystemChannelFlag::getValue))
/*  99 */       .rulesChannelId(InternalSpecUtils.mapPossibleOptional(rulesChannelId(), Snowflake::asString))
/* 100 */       .safetyAlertsChannelId(InternalSpecUtils.mapPossibleOptional(safetyAlertsChannelId(), Snowflake::asString))
/* 101 */       .publicUpdatesChannelId(InternalSpecUtils.mapPossibleOptional(publicUpdatesChannelId(), Snowflake::asString))
/* 102 */       .preferredLocale(InternalSpecUtils.mapPossibleOptional(preferredLocale(), Locale::toLanguageTag))
/* 103 */       .features(InternalSpecUtils.mapPossible(features(), java.util.ArrayList::new))
/* 104 */       .description(description())
/* 105 */       .build();
/*     */   }
/*     */   
/*     */   Possible<Optional<Snowflake>> safetyAlertsChannelId();
/*     */   
/*     */   Possible<Optional<String>> description();
/*     */   
/*     */   Possible<List<String>> features();
/*     */   
/*     */   Possible<Optional<Locale>> preferredLocale();
/*     */   
/*     */   Possible<Optional<Snowflake>> publicUpdatesChannelId();
/*     */   
/*     */   Possible<Optional<Snowflake>> rulesChannelId();
/*     */   
/*     */   Possible<Guild.SystemChannelFlag> systemChannelFlags();
/*     */   
/*     */   Possible<Optional<Snowflake>> systemChannelId();
/*     */   
/*     */   Possible<Optional<Image>> banner();
/*     */   
/*     */   Possible<Optional<Image>> discoverySplash();
/*     */   
/*     */   Possible<Optional<Image>> splash();
/*     */   
/*     */   Possible<Snowflake> ownerId();
/*     */   
/*     */   Possible<Optional<Image>> icon();
/*     */   
/*     */   Possible<Integer> afkTimeout();
/*     */   
/*     */   Possible<Optional<Snowflake>> afkChannelId();
/*     */   
/*     */   Possible<Optional<Guild.ContentFilterLevel>> explicitContentFilter();
/*     */   
/*     */   Possible<Optional<Guild.NotificationLevel>> defaultMessageNotificationsLevel();
/*     */   
/*     */   Possible<Optional<Guild.VerificationLevel>> verificationLevel();
/*     */   
/*     */   Possible<Optional<Region>> region();
/*     */   
/*     */   Possible<String> name();
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\GuildEditSpecGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */