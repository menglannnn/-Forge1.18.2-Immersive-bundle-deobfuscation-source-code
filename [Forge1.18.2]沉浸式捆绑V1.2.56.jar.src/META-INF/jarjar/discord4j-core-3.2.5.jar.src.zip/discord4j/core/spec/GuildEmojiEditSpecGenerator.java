/*    */ package discord4j.core.spec;
/*    */ 
/*    */ import discord4j.common.util.Snowflake;
/*    */ import discord4j.discordjson.json.GuildEmojiModifyRequest;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import java.util.List;
/*    */ import java.util.stream.Collectors;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Immutable(singleton = true)
/*    */ interface GuildEmojiEditSpecGenerator
/*    */   extends AuditSpec<GuildEmojiModifyRequest>
/*    */ {
/*    */   default GuildEmojiModifyRequest asRequest() {
/* 42 */     return (GuildEmojiModifyRequest)GuildEmojiModifyRequest.builder()
/* 43 */       .name(name())
/* 44 */       .roles(InternalSpecUtils.mapPossible(roles(), r -> (List)r.stream().map(Snowflake::asString).collect(Collectors.toList())))
/* 45 */       .build();
/*    */   }
/*    */   
/*    */   Possible<String> name();
/*    */   
/*    */   Possible<List<Snowflake>> roles();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\GuildEmojiEditSpecGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */