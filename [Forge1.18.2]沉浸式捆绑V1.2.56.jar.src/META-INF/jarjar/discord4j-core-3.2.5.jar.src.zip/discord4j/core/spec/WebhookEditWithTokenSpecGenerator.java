/*    */ package discord4j.core.spec;
/*    */ 
/*    */ import discord4j.discordjson.json.WebhookModifyWithTokenRequest;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import discord4j.rest.util.Image;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Immutable(singleton = true)
/*    */ interface WebhookEditWithTokenSpecGenerator
/*    */   extends AuditSpec<WebhookModifyWithTokenRequest>
/*    */ {
/*    */   default WebhookModifyWithTokenRequest asRequest() {
/* 39 */     return (WebhookModifyWithTokenRequest)WebhookModifyWithTokenRequest.builder()
/* 40 */       .name(name())
/* 41 */       .avatar(InternalSpecUtils.mapPossible(avatar(), Image::getDataUri))
/* 42 */       .build();
/*    */   }
/*    */   
/*    */   Possible<Image> avatar();
/*    */   
/*    */   Possible<String> name();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\WebhookEditWithTokenSpecGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */