/*     */ package discord4j.core.spec;
/*     */ 
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.object.entity.Guild;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ import org.immutables.value.Generated;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "GuildPruneMonoGenerator", generator = "Immutables")
/*     */ public final class GuildPruneMono
/*     */   extends GuildPruneMonoGenerator
/*     */ {
/*     */   @Nullable
/*     */   private final String reason;
/*     */   private final Integer days;
/*     */   @Nullable
/*     */   private final Set<Snowflake> roles;
/*     */   @Nullable
/*     */   private final Boolean computePruneCount;
/*     */   private final Guild guild;
/*     */   
/*     */   private GuildPruneMono(Integer days, Guild guild) {
/*  34 */     this.days = Objects.<Integer>requireNonNull(days, "days");
/*  35 */     this.guild = Objects.<Guild>requireNonNull(guild, "guild");
/*  36 */     this.reason = null;
/*  37 */     this.roles = null;
/*  38 */     this.computePruneCount = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private GuildPruneMono(@Nullable String reason, Integer days, @Nullable Set<Snowflake> roles, @Nullable Boolean computePruneCount, Guild guild) {
/*  47 */     this.reason = reason;
/*  48 */     this.days = days;
/*  49 */     this.roles = roles;
/*  50 */     this.computePruneCount = computePruneCount;
/*  51 */     this.guild = guild;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String reason() {
/*  60 */     return this.reason;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Integer days() {
/*  68 */     return this.days;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Set<Snowflake> roles() {
/*  76 */     return this.roles;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Boolean computePruneCount() {
/*  84 */     return this.computePruneCount;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Guild guild() {
/*  92 */     return this.guild;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final GuildPruneMono withReason(@Nullable String value) {
/* 102 */     if (Objects.equals(this.reason, value)) return this; 
/* 103 */     return new GuildPruneMono(value, this.days, this.roles, this.computePruneCount, this.guild);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final GuildPruneMono withDays(Integer value) {
/* 113 */     Integer newValue = Objects.<Integer>requireNonNull(value, "days");
/* 114 */     if (this.days.equals(newValue)) return this; 
/* 115 */     return new GuildPruneMono(this.reason, newValue, this.roles, this.computePruneCount, this.guild);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final GuildPruneMono withRoles(@Nullable Snowflake... elements) {
/* 124 */     if (elements == null) {
/* 125 */       return new GuildPruneMono(this.reason, this.days, null, this.computePruneCount, this.guild);
/*     */     }
/* 127 */     Set<Snowflake> newValue = (Arrays.asList(elements) == null) ? null : createUnmodifiableSet(createSafeList(Arrays.asList(elements), true, false));
/* 128 */     return new GuildPruneMono(this.reason, this.days, newValue, this.computePruneCount, this.guild);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final GuildPruneMono withRoles(@Nullable Iterable<? extends Snowflake> elements) {
/* 138 */     if (this.roles == elements) return this; 
/* 139 */     Set<Snowflake> newValue = (elements == null) ? null : createUnmodifiableSet(createSafeList(elements, true, false));
/* 140 */     return new GuildPruneMono(this.reason, this.days, newValue, this.computePruneCount, this.guild);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final GuildPruneMono withComputePruneCount(@Nullable Boolean value) {
/* 150 */     if (Objects.equals(this.computePruneCount, value)) return this; 
/* 151 */     return new GuildPruneMono(this.reason, this.days, this.roles, value, this.guild);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final GuildPruneMono withGuild(Guild value) {
/* 161 */     if (this.guild == value) return this; 
/* 162 */     Guild newValue = Objects.<Guild>requireNonNull(value, "guild");
/* 163 */     return new GuildPruneMono(this.reason, this.days, this.roles, this.computePruneCount, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 172 */     if (this == another) return true; 
/* 173 */     return (another instanceof GuildPruneMono && 
/* 174 */       equalTo(0, (GuildPruneMono)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, GuildPruneMono another) {
/* 178 */     return (Objects.equals(this.reason, another.reason) && this.days
/* 179 */       .equals(another.days) && 
/* 180 */       Objects.equals(this.roles, another.roles) && 
/* 181 */       Objects.equals(this.computePruneCount, another.computePruneCount) && this.guild
/* 182 */       .equals(another.guild));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 191 */     int h = 5381;
/* 192 */     h += (h << 5) + Objects.hashCode(this.reason);
/* 193 */     h += (h << 5) + this.days.hashCode();
/* 194 */     h += (h << 5) + Objects.hashCode(this.roles);
/* 195 */     h += (h << 5) + Objects.hashCode(this.computePruneCount);
/* 196 */     h += (h << 5) + this.guild.hashCode();
/* 197 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 206 */     return "GuildPruneMono{reason=" + this.reason + ", days=" + this.days + ", roles=" + this.roles + ", computePruneCount=" + this.computePruneCount + ", guild=" + this.guild + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static GuildPruneMono of(Integer days, Guild guild) {
/* 222 */     return new GuildPruneMono(days, guild);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static GuildPruneMono copyOf(GuildPruneMonoGenerator instance) {
/* 233 */     if (instance instanceof GuildPruneMono) {
/* 234 */       return (GuildPruneMono)instance;
/*     */     }
/* 236 */     return of(instance.days(), instance.guild())
/* 237 */       .withReason(instance.reason())
/* 238 */       .withRoles(instance.roles())
/* 239 */       .withComputePruneCount(instance.computePruneCount());
/*     */   }
/*     */   
/*     */   private static <T> List<T> createSafeList(Iterable<? extends T> iterable, boolean checkNulls, boolean skipNulls) {
/*     */     ArrayList<T> list;
/* 244 */     if (iterable instanceof Collection) {
/* 245 */       int size = ((Collection)iterable).size();
/* 246 */       if (size == 0) return Collections.emptyList(); 
/* 247 */       list = new ArrayList<>();
/*     */     } else {
/* 249 */       list = new ArrayList<>();
/*     */     } 
/* 251 */     for (T element : iterable) {
/* 252 */       if (skipNulls && element == null)
/* 253 */         continue;  if (checkNulls) Objects.requireNonNull(element, "element"); 
/* 254 */       list.add(element);
/*     */     } 
/* 256 */     return list;
/*     */   }
/*     */ 
/*     */   
/*     */   private static <T> Set<T> createUnmodifiableSet(List<T> list) {
/* 261 */     switch (list.size()) { case 0:
/* 262 */         return Collections.emptySet();
/* 263 */       case 1: return Collections.singleton(list.get(0)); }
/*     */     
/* 265 */     Set<T> set = new LinkedHashSet<>(list.size());
/* 266 */     set.addAll(list);
/* 267 */     return Collections.unmodifiableSet(set);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\GuildPruneMono.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */