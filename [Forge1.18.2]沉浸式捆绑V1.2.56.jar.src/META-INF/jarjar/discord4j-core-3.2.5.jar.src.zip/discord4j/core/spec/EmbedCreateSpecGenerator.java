/*    */ package discord4j.core.spec;
/*    */ 
/*    */ import discord4j.discordjson.json.EmbedData;
/*    */ import discord4j.discordjson.json.EmbedImageData;
/*    */ import discord4j.discordjson.json.EmbedThumbnailData;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import discord4j.rest.util.Color;
/*    */ import java.time.Instant;
/*    */ import java.time.format.DateTimeFormatter;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import java.util.Objects;
/*    */ import java.util.stream.Collectors;
/*    */ import org.immutables.value.Value.Default;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Immutable(singleton = true)
/*    */ interface EmbedCreateSpecGenerator
/*    */   extends Spec<EmbedData>
/*    */ {
/*    */   @Default
/*    */   default List<EmbedCreateFields.Field> fields() {
/* 62 */     return Collections.emptyList();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   default EmbedData asRequest() {
/* 71 */     Objects.requireNonNull(DateTimeFormatter.ISO_INSTANT); return (EmbedData)EmbedData.builder().title(title()).description(description()).url(url()).timestamp(InternalSpecUtils.mapPossible(timestamp(), DateTimeFormatter.ISO_INSTANT::format))
/* 72 */       .color(InternalSpecUtils.mapPossible(color(), Color::getRGB))
/* 73 */       .footer(InternalSpecUtils.mapPossible(InternalSpecUtils.toPossible(footer()), EmbedCreateFields.Footer::asRequest))
/* 74 */       .image(InternalSpecUtils.mapPossible(image(), url -> EmbedImageData.builder().url(url).build()))
/* 75 */       .thumbnail(InternalSpecUtils.mapPossible(thumbnail(), url -> EmbedThumbnailData.builder().url(url).build()))
/* 76 */       .author(InternalSpecUtils.mapPossible(InternalSpecUtils.toPossible(author()), EmbedCreateFields.Author::asRequest))
/* 77 */       .fields((List)fields().stream().map(EmbedCreateFields.Field::asRequest).collect(Collectors.toList()))
/* 78 */       .build();
/*    */   }
/*    */   
/*    */   Possible<String> title();
/*    */   
/*    */   Possible<String> description();
/*    */   
/*    */   Possible<String> url();
/*    */   
/*    */   Possible<Instant> timestamp();
/*    */   
/*    */   Possible<Color> color();
/*    */   
/*    */   @Nullable
/*    */   EmbedCreateFields.Footer footer();
/*    */   
/*    */   Possible<String> image();
/*    */   
/*    */   Possible<String> thumbnail();
/*    */   
/*    */   @Nullable
/*    */   EmbedCreateFields.Author author();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\EmbedCreateSpecGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */