/*     */ package discord4j.core.spec;
/*     */ 
/*     */ import com.google.errorprone.annotations.CanIgnoreReturnValue;
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.object.entity.ScheduledEvent;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.time.Instant;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "ScheduledEventCreateSpecGenerator", generator = "Immutables")
/*     */ public final class ScheduledEventCreateSpec
/*     */   implements ScheduledEventCreateSpecGenerator
/*     */ {
/*     */   @Nullable
/*     */   private final String reason;
/*     */   private final Snowflake channelId_value;
/*     */   private final boolean channelId_absent;
/*     */   private final ScheduledEventEntityMetadataSpec entityMetadata_value;
/*     */   private final boolean entityMetadata_absent;
/*     */   private final String name;
/*     */   private final ScheduledEvent.PrivacyLevel privacyLevel;
/*     */   private final Instant scheduledStartTime;
/*     */   private final Instant scheduledEndTime_value;
/*     */   private final boolean scheduledEndTime_absent;
/*     */   private final String description_value;
/*     */   private final boolean description_absent;
/*     */   private final ScheduledEvent.EntityType entityType;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   private volatile transient InitShim initShim;
/*     */   
/*     */   private ScheduledEventCreateSpec(String name, ScheduledEvent.PrivacyLevel privacyLevel, Instant scheduledStartTime, ScheduledEvent.EntityType entityType) {
/*  99 */     this.initShim = new InitShim(); this.name = Objects.<String>requireNonNull(name, "name"); this.privacyLevel = Objects.<ScheduledEvent.PrivacyLevel>requireNonNull(privacyLevel, "privacyLevel"); this.scheduledStartTime = Objects.<Instant>requireNonNull(scheduledStartTime, "scheduledStartTime"); this.entityType = Objects.<ScheduledEvent.EntityType>requireNonNull(entityType, "entityType"); this.reason = null; Possible<Snowflake> channelId$impl = Possible.absent(); Possible<ScheduledEventEntityMetadataSpec> entityMetadata$impl = Possible.absent(); Possible<Instant> scheduledEndTime$impl = Possible.absent(); Possible<String> description$impl = Possible.absent(); this.channelId_value = channelId$impl.toOptional().orElse(null); this.channelId_absent = channelId$impl.isAbsent(); this.entityMetadata_value = entityMetadata$impl.toOptional().orElse(null); this.entityMetadata_absent = entityMetadata$impl.isAbsent(); this.scheduledEndTime_value = scheduledEndTime$impl.toOptional().orElse(null); this.scheduledEndTime_absent = scheduledEndTime$impl.isAbsent(); this.description_value = description$impl.toOptional().orElse(null); this.description_absent = description$impl.isAbsent(); this.initShim = null; } private ScheduledEventCreateSpec(@Nullable String reason, Possible<Snowflake> channelId, Possible<ScheduledEventEntityMetadataSpec> entityMetadata, String name, ScheduledEvent.PrivacyLevel privacyLevel, Instant scheduledStartTime, Possible<Instant> scheduledEndTime, Possible<String> description, ScheduledEvent.EntityType entityType) { this.initShim = new InitShim(); this.reason = reason; Possible<Snowflake> channelId$impl = channelId; Possible<ScheduledEventEntityMetadataSpec> entityMetadata$impl = entityMetadata; this.name = name; this.privacyLevel = privacyLevel; this.scheduledStartTime = scheduledStartTime; Possible<Instant> scheduledEndTime$impl = scheduledEndTime; Possible<String> description$impl = description; this.entityType = entityType; this.channelId_value = channelId$impl.toOptional().orElse(null); this.channelId_absent = channelId$impl.isAbsent(); this.entityMetadata_value = entityMetadata$impl.toOptional().orElse(null);
/*     */     this.entityMetadata_absent = entityMetadata$impl.isAbsent();
/*     */     this.scheduledEndTime_value = scheduledEndTime$impl.toOptional().orElse(null);
/*     */     this.scheduledEndTime_absent = scheduledEndTime$impl.isAbsent();
/*     */     this.description_value = description$impl.toOptional().orElse(null);
/*     */     this.description_absent = description$impl.isAbsent();
/* 105 */     this.initShim = null; } @Generated(from = "ScheduledEventCreateSpecGenerator", generator = "Immutables") private final class InitShim { private InitShim() {} private String formatInitCycleMessage() { List<String> attributes = new ArrayList<>();
/* 106 */       return "Cannot build ScheduledEventCreateSpec, attribute initializers form cycle " + attributes; }
/*     */      }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String reason() {
/* 116 */     return this.reason;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Snowflake> channelId() {
/* 124 */     return this.channelId_absent ? Possible.absent() : Possible.of(this.channelId_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<ScheduledEventEntityMetadataSpec> entityMetadata() {
/* 132 */     return this.entityMetadata_absent ? Possible.absent() : Possible.of(this.entityMetadata_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String name() {
/* 140 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ScheduledEvent.PrivacyLevel privacyLevel() {
/* 148 */     return this.privacyLevel;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Instant scheduledStartTime() {
/* 156 */     return this.scheduledStartTime;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Instant> scheduledEndTime() {
/* 164 */     return this.scheduledEndTime_absent ? Possible.absent() : Possible.of(this.scheduledEndTime_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<String> description() {
/* 172 */     return this.description_absent ? Possible.absent() : Possible.of(this.description_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ScheduledEvent.EntityType entityType() {
/* 180 */     return this.entityType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ScheduledEventCreateSpec withReason(@Nullable String value) {
/* 190 */     if (Objects.equals(this.reason, value)) return this; 
/* 191 */     return new ScheduledEventCreateSpec(value, 
/*     */         
/* 193 */         channelId(), 
/* 194 */         entityMetadata(), this.name, this.privacyLevel, this.scheduledStartTime, 
/*     */ 
/*     */ 
/*     */         
/* 198 */         scheduledEndTime(), 
/* 199 */         description(), this.entityType);
/*     */   }
/*     */ 
/*     */   
/*     */   public ScheduledEventCreateSpec withChannelId(Possible<Snowflake> value) {
/* 204 */     Possible<Snowflake> newValue = Objects.<Possible<Snowflake>>requireNonNull(value);
/* 205 */     return new ScheduledEventCreateSpec(this.reason, newValue, 
/*     */ 
/*     */         
/* 208 */         entityMetadata(), this.name, this.privacyLevel, this.scheduledStartTime, 
/*     */ 
/*     */ 
/*     */         
/* 212 */         scheduledEndTime(), 
/* 213 */         description(), this.entityType);
/*     */   }
/*     */ 
/*     */   
/*     */   public ScheduledEventCreateSpec withChannelId(Snowflake value) {
/* 218 */     Possible<Snowflake> newValue = Possible.of(value);
/* 219 */     return new ScheduledEventCreateSpec(this.reason, newValue, 
/*     */ 
/*     */         
/* 222 */         entityMetadata(), this.name, this.privacyLevel, this.scheduledStartTime, 
/*     */ 
/*     */ 
/*     */         
/* 226 */         scheduledEndTime(), 
/* 227 */         description(), this.entityType);
/*     */   }
/*     */ 
/*     */   
/*     */   public ScheduledEventCreateSpec withEntityMetadata(Possible<ScheduledEventEntityMetadataSpec> value) {
/* 232 */     Possible<ScheduledEventEntityMetadataSpec> newValue = Objects.<Possible<ScheduledEventEntityMetadataSpec>>requireNonNull(value);
/* 233 */     return new ScheduledEventCreateSpec(this.reason, 
/*     */         
/* 235 */         channelId(), newValue, this.name, this.privacyLevel, this.scheduledStartTime, 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 240 */         scheduledEndTime(), 
/* 241 */         description(), this.entityType);
/*     */   }
/*     */ 
/*     */   
/*     */   public ScheduledEventCreateSpec withEntityMetadata(ScheduledEventEntityMetadataSpec value) {
/* 246 */     Possible<ScheduledEventEntityMetadataSpec> newValue = Possible.of(value);
/* 247 */     return new ScheduledEventCreateSpec(this.reason, 
/*     */         
/* 249 */         channelId(), newValue, this.name, this.privacyLevel, this.scheduledStartTime, 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 254 */         scheduledEndTime(), 
/* 255 */         description(), this.entityType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ScheduledEventCreateSpec withName(String value) {
/* 266 */     String newValue = Objects.<String>requireNonNull(value, "name");
/* 267 */     if (this.name.equals(newValue)) return this; 
/* 268 */     return new ScheduledEventCreateSpec(this.reason, 
/*     */         
/* 270 */         channelId(), 
/* 271 */         entityMetadata(), newValue, this.privacyLevel, this.scheduledStartTime, 
/*     */ 
/*     */ 
/*     */         
/* 275 */         scheduledEndTime(), 
/* 276 */         description(), this.entityType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ScheduledEventCreateSpec withPrivacyLevel(ScheduledEvent.PrivacyLevel value) {
/* 287 */     ScheduledEvent.PrivacyLevel newValue = Objects.<ScheduledEvent.PrivacyLevel>requireNonNull(value, "privacyLevel");
/* 288 */     if (this.privacyLevel == newValue) return this; 
/* 289 */     return new ScheduledEventCreateSpec(this.reason, 
/*     */         
/* 291 */         channelId(), 
/* 292 */         entityMetadata(), this.name, newValue, this.scheduledStartTime, 
/*     */ 
/*     */ 
/*     */         
/* 296 */         scheduledEndTime(), 
/* 297 */         description(), this.entityType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ScheduledEventCreateSpec withScheduledStartTime(Instant value) {
/* 308 */     if (this.scheduledStartTime == value) return this; 
/* 309 */     Instant newValue = Objects.<Instant>requireNonNull(value, "scheduledStartTime");
/* 310 */     return new ScheduledEventCreateSpec(this.reason, 
/*     */         
/* 312 */         channelId(), 
/* 313 */         entityMetadata(), this.name, this.privacyLevel, newValue, 
/*     */ 
/*     */ 
/*     */         
/* 317 */         scheduledEndTime(), 
/* 318 */         description(), this.entityType);
/*     */   }
/*     */ 
/*     */   
/*     */   public ScheduledEventCreateSpec withScheduledEndTime(Possible<Instant> value) {
/* 323 */     Possible<Instant> newValue = Objects.<Possible<Instant>>requireNonNull(value);
/* 324 */     return new ScheduledEventCreateSpec(this.reason, 
/*     */         
/* 326 */         channelId(), 
/* 327 */         entityMetadata(), this.name, this.privacyLevel, this.scheduledStartTime, newValue, 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 332 */         description(), this.entityType);
/*     */   }
/*     */ 
/*     */   
/*     */   public ScheduledEventCreateSpec withScheduledEndTime(Instant value) {
/* 337 */     Possible<Instant> newValue = Possible.of(value);
/* 338 */     return new ScheduledEventCreateSpec(this.reason, 
/*     */         
/* 340 */         channelId(), 
/* 341 */         entityMetadata(), this.name, this.privacyLevel, this.scheduledStartTime, newValue, 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 346 */         description(), this.entityType);
/*     */   }
/*     */ 
/*     */   
/*     */   public ScheduledEventCreateSpec withDescription(Possible<String> value) {
/* 351 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/* 352 */     return new ScheduledEventCreateSpec(this.reason, 
/*     */         
/* 354 */         channelId(), 
/* 355 */         entityMetadata(), this.name, this.privacyLevel, this.scheduledStartTime, 
/*     */ 
/*     */ 
/*     */         
/* 359 */         scheduledEndTime(), newValue, this.entityType);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ScheduledEventCreateSpec withDescription(String value) {
/* 365 */     Possible<String> newValue = Possible.of(value);
/* 366 */     return new ScheduledEventCreateSpec(this.reason, 
/*     */         
/* 368 */         channelId(), 
/* 369 */         entityMetadata(), this.name, this.privacyLevel, this.scheduledStartTime, 
/*     */ 
/*     */ 
/*     */         
/* 373 */         scheduledEndTime(), newValue, this.entityType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ScheduledEventCreateSpec withEntityType(ScheduledEvent.EntityType value) {
/* 385 */     ScheduledEvent.EntityType newValue = Objects.<ScheduledEvent.EntityType>requireNonNull(value, "entityType");
/* 386 */     if (this.entityType == newValue) return this; 
/* 387 */     return new ScheduledEventCreateSpec(this.reason, 
/*     */         
/* 389 */         channelId(), 
/* 390 */         entityMetadata(), this.name, this.privacyLevel, this.scheduledStartTime, 
/*     */ 
/*     */ 
/*     */         
/* 394 */         scheduledEndTime(), 
/* 395 */         description(), newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 405 */     if (this == another) return true; 
/* 406 */     return (another instanceof ScheduledEventCreateSpec && 
/* 407 */       equalTo(0, (ScheduledEventCreateSpec)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ScheduledEventCreateSpec another) {
/* 411 */     return (Objects.equals(this.reason, another.reason) && 
/* 412 */       channelId().equals(another.channelId()) && 
/* 413 */       entityMetadata().equals(another.entityMetadata()) && this.name
/* 414 */       .equals(another.name) && this.privacyLevel
/* 415 */       .equals(another.privacyLevel) && this.scheduledStartTime
/* 416 */       .equals(another.scheduledStartTime) && 
/* 417 */       scheduledEndTime().equals(another.scheduledEndTime()) && 
/* 418 */       description().equals(another.description()) && this.entityType
/* 419 */       .equals(another.entityType));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 428 */     int h = 5381;
/* 429 */     h += (h << 5) + Objects.hashCode(this.reason);
/* 430 */     h += (h << 5) + channelId().hashCode();
/* 431 */     h += (h << 5) + entityMetadata().hashCode();
/* 432 */     h += (h << 5) + this.name.hashCode();
/* 433 */     h += (h << 5) + this.privacyLevel.hashCode();
/* 434 */     h += (h << 5) + this.scheduledStartTime.hashCode();
/* 435 */     h += (h << 5) + scheduledEndTime().hashCode();
/* 436 */     h += (h << 5) + description().hashCode();
/* 437 */     h += (h << 5) + this.entityType.hashCode();
/* 438 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 447 */     return "ScheduledEventCreateSpec{reason=" + this.reason + ", channelId=" + 
/*     */       
/* 449 */       channelId().toString() + ", entityMetadata=" + 
/* 450 */       entityMetadata().toString() + ", name=" + this.name + ", privacyLevel=" + this.privacyLevel + ", scheduledStartTime=" + this.scheduledStartTime + ", scheduledEndTime=" + 
/*     */ 
/*     */ 
/*     */       
/* 454 */       scheduledEndTime().toString() + ", description=" + 
/* 455 */       description().toString() + ", entityType=" + this.entityType + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ScheduledEventCreateSpec of(String name, ScheduledEvent.PrivacyLevel privacyLevel, Instant scheduledStartTime, ScheduledEvent.EntityType entityType) {
/* 469 */     return new ScheduledEventCreateSpec(name, privacyLevel, scheduledStartTime, entityType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ScheduledEventCreateSpec copyOf(ScheduledEventCreateSpecGenerator instance) {
/* 480 */     if (instance instanceof ScheduledEventCreateSpec) {
/* 481 */       return (ScheduledEventCreateSpec)instance;
/*     */     }
/* 483 */     return builder()
/* 484 */       .from(instance)
/* 485 */       .build();
/*     */   }
/*     */   
/*     */   public boolean isChannelIdPresent() {
/* 489 */     return !this.channelId_absent;
/*     */   }
/*     */   
/*     */   public Snowflake channelIdOrElse(Snowflake defaultValue) {
/* 493 */     return !this.channelId_absent ? this.channelId_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isEntityMetadataPresent() {
/* 497 */     return !this.entityMetadata_absent;
/*     */   }
/*     */   
/*     */   public ScheduledEventEntityMetadataSpec entityMetadataOrElse(ScheduledEventEntityMetadataSpec defaultValue) {
/* 501 */     return !this.entityMetadata_absent ? this.entityMetadata_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isScheduledEndTimePresent() {
/* 505 */     return !this.scheduledEndTime_absent;
/*     */   }
/*     */   
/*     */   public Instant scheduledEndTimeOrElse(Instant defaultValue) {
/* 509 */     return !this.scheduledEndTime_absent ? this.scheduledEndTime_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isDescriptionPresent() {
/* 513 */     return !this.description_absent;
/*     */   }
/*     */   
/*     */   public String descriptionOrElse(String defaultValue) {
/* 517 */     return !this.description_absent ? this.description_value : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 538 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "ScheduledEventCreateSpecGenerator", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_NAME = 1L;
/*     */     
/*     */     private static final long INIT_BIT_PRIVACY_LEVEL = 2L;
/*     */     
/*     */     private static final long INIT_BIT_SCHEDULED_START_TIME = 4L;
/*     */     
/*     */     private static final long INIT_BIT_ENTITY_TYPE = 8L;
/*     */     
/* 554 */     private long initBits = 15L;
/*     */     
/* 556 */     private Possible<Snowflake> channelId_possible = Possible.absent();
/* 557 */     private Possible<ScheduledEventEntityMetadataSpec> entityMetadata_possible = Possible.absent();
/* 558 */     private Possible<Instant> scheduledEndTime_possible = Possible.absent();
/* 559 */     private Possible<String> description_possible = Possible.absent();
/*     */ 
/*     */     
/*     */     private String reason;
/*     */ 
/*     */     
/*     */     private String name;
/*     */ 
/*     */     
/*     */     private ScheduledEvent.PrivacyLevel privacyLevel;
/*     */ 
/*     */     
/*     */     private Instant scheduledStartTime;
/*     */     
/*     */     private ScheduledEvent.EntityType entityType;
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder from(ScheduledEventCreateSpecGenerator instance) {
/* 578 */       Objects.requireNonNull(instance, "instance");
/* 579 */       String reasonValue = instance.reason();
/* 580 */       if (reasonValue != null) {
/* 581 */         reason(reasonValue);
/*     */       }
/* 583 */       channelId(instance.channelId());
/* 584 */       entityMetadata(instance.entityMetadata());
/* 585 */       name(instance.name());
/* 586 */       privacyLevel(instance.privacyLevel());
/* 587 */       scheduledStartTime(instance.scheduledStartTime());
/* 588 */       scheduledEndTime(instance.scheduledEndTime());
/* 589 */       description(instance.description());
/* 590 */       entityType(instance.entityType());
/* 591 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder reason(@Nullable String reason) {
/* 601 */       this.reason = reason;
/* 602 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder channelId(Possible<Snowflake> value) {
/* 607 */       this.channelId_possible = value;
/* 608 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder channelId(Snowflake value) {
/* 613 */       this.channelId_possible = Possible.of(value);
/* 614 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder entityMetadata(Possible<ScheduledEventEntityMetadataSpec> value) {
/* 619 */       this.entityMetadata_possible = value;
/* 620 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder entityMetadata(ScheduledEventEntityMetadataSpec value) {
/* 625 */       this.entityMetadata_possible = Possible.of(value);
/* 626 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder name(String name) {
/* 636 */       this.name = Objects.<String>requireNonNull(name, "name");
/* 637 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 638 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder privacyLevel(ScheduledEvent.PrivacyLevel privacyLevel) {
/* 648 */       this.privacyLevel = Objects.<ScheduledEvent.PrivacyLevel>requireNonNull(privacyLevel, "privacyLevel");
/* 649 */       this.initBits &= 0xFFFFFFFFFFFFFFFDL;
/* 650 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder scheduledStartTime(Instant scheduledStartTime) {
/* 660 */       this.scheduledStartTime = Objects.<Instant>requireNonNull(scheduledStartTime, "scheduledStartTime");
/* 661 */       this.initBits &= 0xFFFFFFFFFFFFFFFBL;
/* 662 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder scheduledEndTime(Possible<Instant> value) {
/* 667 */       this.scheduledEndTime_possible = value;
/* 668 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder scheduledEndTime(Instant value) {
/* 673 */       this.scheduledEndTime_possible = Possible.of(value);
/* 674 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder description(Possible<String> value) {
/* 679 */       this.description_possible = value;
/* 680 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder description(String value) {
/* 685 */       this.description_possible = Possible.of(value);
/* 686 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder entityType(ScheduledEvent.EntityType entityType) {
/* 696 */       this.entityType = Objects.<ScheduledEvent.EntityType>requireNonNull(entityType, "entityType");
/* 697 */       this.initBits &= 0xFFFFFFFFFFFFFFF7L;
/* 698 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ScheduledEventCreateSpec build() {
/* 707 */       if (this.initBits != 0L) {
/* 708 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 710 */       return new ScheduledEventCreateSpec(this.reason, 
/*     */           
/* 712 */           channelId_build(), 
/* 713 */           entityMetadata_build(), this.name, this.privacyLevel, this.scheduledStartTime, 
/*     */ 
/*     */ 
/*     */           
/* 717 */           scheduledEndTime_build(), 
/* 718 */           description_build(), this.entityType);
/*     */     }
/*     */ 
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 723 */       List<String> attributes = new ArrayList<>();
/* 724 */       if ((this.initBits & 0x1L) != 0L) attributes.add("name"); 
/* 725 */       if ((this.initBits & 0x2L) != 0L) attributes.add("privacyLevel"); 
/* 726 */       if ((this.initBits & 0x4L) != 0L) attributes.add("scheduledStartTime"); 
/* 727 */       if ((this.initBits & 0x8L) != 0L) attributes.add("entityType"); 
/* 728 */       return "Cannot build ScheduledEventCreateSpec, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Possible<Snowflake> channelId_build() {
/* 732 */       return this.channelId_possible;
/*     */     }
/*     */     
/*     */     private Possible<ScheduledEventEntityMetadataSpec> entityMetadata_build() {
/* 736 */       return this.entityMetadata_possible;
/*     */     }
/*     */     
/*     */     private Possible<Instant> scheduledEndTime_build() {
/* 740 */       return this.scheduledEndTime_possible;
/*     */     }
/*     */     
/*     */     private Possible<String> description_build() {
/* 744 */       return this.description_possible;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\ScheduledEventCreateSpec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */