/*     */ package discord4j.core.spec;
/*     */ 
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.object.entity.Guild;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ import org.immutables.value.Generated;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "GuildPruneCountMonoGenerator", generator = "Immutables")
/*     */ public final class GuildPruneCountMono
/*     */   extends GuildPruneCountMonoGenerator
/*     */ {
/*     */   private final Integer days;
/*     */   @Nullable
/*     */   private final Set<Snowflake> roles;
/*     */   private final Guild guild;
/*     */   
/*     */   private GuildPruneCountMono(Integer days, Guild guild) {
/*  32 */     this.days = Objects.<Integer>requireNonNull(days, "days");
/*  33 */     this.guild = Objects.<Guild>requireNonNull(guild, "guild");
/*  34 */     this.roles = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private GuildPruneCountMono(Integer days, @Nullable Set<Snowflake> roles, Guild guild) {
/*  41 */     this.days = days;
/*  42 */     this.roles = roles;
/*  43 */     this.guild = guild;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Integer days() {
/*  51 */     return this.days;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Set<Snowflake> roles() {
/*  59 */     return this.roles;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Guild guild() {
/*  67 */     return this.guild;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final GuildPruneCountMono withDays(Integer value) {
/*  77 */     Integer newValue = Objects.<Integer>requireNonNull(value, "days");
/*  78 */     if (this.days.equals(newValue)) return this; 
/*  79 */     return new GuildPruneCountMono(newValue, this.roles, this.guild);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final GuildPruneCountMono withRoles(@Nullable Snowflake... elements) {
/*  88 */     if (elements == null) {
/*  89 */       return new GuildPruneCountMono(this.days, null, this.guild);
/*     */     }
/*  91 */     Set<Snowflake> newValue = (Arrays.asList(elements) == null) ? null : createUnmodifiableSet(createSafeList(Arrays.asList(elements), true, false));
/*  92 */     return new GuildPruneCountMono(this.days, newValue, this.guild);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final GuildPruneCountMono withRoles(@Nullable Iterable<? extends Snowflake> elements) {
/* 102 */     if (this.roles == elements) return this; 
/* 103 */     Set<Snowflake> newValue = (elements == null) ? null : createUnmodifiableSet(createSafeList(elements, true, false));
/* 104 */     return new GuildPruneCountMono(this.days, newValue, this.guild);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final GuildPruneCountMono withGuild(Guild value) {
/* 114 */     if (this.guild == value) return this; 
/* 115 */     Guild newValue = Objects.<Guild>requireNonNull(value, "guild");
/* 116 */     return new GuildPruneCountMono(this.days, this.roles, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 125 */     if (this == another) return true; 
/* 126 */     return (another instanceof GuildPruneCountMono && 
/* 127 */       equalTo(0, (GuildPruneCountMono)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, GuildPruneCountMono another) {
/* 131 */     return (this.days.equals(another.days) && 
/* 132 */       Objects.equals(this.roles, another.roles) && this.guild
/* 133 */       .equals(another.guild));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 142 */     int h = 5381;
/* 143 */     h += (h << 5) + this.days.hashCode();
/* 144 */     h += (h << 5) + Objects.hashCode(this.roles);
/* 145 */     h += (h << 5) + this.guild.hashCode();
/* 146 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 155 */     return "GuildPruneCountMono{days=" + this.days + ", roles=" + this.roles + ", guild=" + this.guild + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static GuildPruneCountMono of(Integer days, Guild guild) {
/* 169 */     return new GuildPruneCountMono(days, guild);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static GuildPruneCountMono copyOf(GuildPruneCountMonoGenerator instance) {
/* 180 */     if (instance instanceof GuildPruneCountMono) {
/* 181 */       return (GuildPruneCountMono)instance;
/*     */     }
/* 183 */     return of(instance.days(), instance.guild())
/* 184 */       .withRoles(instance.roles());
/*     */   }
/*     */   
/*     */   private static <T> List<T> createSafeList(Iterable<? extends T> iterable, boolean checkNulls, boolean skipNulls) {
/*     */     ArrayList<T> list;
/* 189 */     if (iterable instanceof Collection) {
/* 190 */       int size = ((Collection)iterable).size();
/* 191 */       if (size == 0) return Collections.emptyList(); 
/* 192 */       list = new ArrayList<>();
/*     */     } else {
/* 194 */       list = new ArrayList<>();
/*     */     } 
/* 196 */     for (T element : iterable) {
/* 197 */       if (skipNulls && element == null)
/* 198 */         continue;  if (checkNulls) Objects.requireNonNull(element, "element"); 
/* 199 */       list.add(element);
/*     */     } 
/* 201 */     return list;
/*     */   }
/*     */ 
/*     */   
/*     */   private static <T> Set<T> createUnmodifiableSet(List<T> list) {
/* 206 */     switch (list.size()) { case 0:
/* 207 */         return Collections.emptySet();
/* 208 */       case 1: return Collections.singleton(list.get(0)); }
/*     */     
/* 210 */     Set<T> set = new LinkedHashSet<>(list.size());
/* 211 */     set.addAll(list);
/* 212 */     return Collections.unmodifiableSet(set);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\GuildPruneCountMono.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */