/*    */ package discord4j.core.spec;
/*    */ 
/*    */ import discord4j.common.util.Snowflake;
/*    */ import discord4j.discordjson.Id;
/*    */ import discord4j.discordjson.json.AutoModActionData;
/*    */ import discord4j.discordjson.json.AutoModRuleModifyRequest;
/*    */ import discord4j.discordjson.json.AutoModTriggerMetaData;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import java.util.stream.Collectors;
/*    */ import org.immutables.value.Value.Default;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Immutable
/*    */ public interface AutoModRuleEditSpecGenerator
/*    */   extends AuditSpec<AutoModRuleModifyRequest>
/*    */ {
/*    */   @Default
/*    */   default List<AutoModActionData> actions() {
/* 46 */     return Collections.emptyList();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   @Default
/*    */   default List<Snowflake> exemptRoles() {
/* 53 */     return Collections.emptyList();
/*    */   }
/*    */   
/*    */   @Default
/*    */   default List<Snowflake> exemptChannels() {
/* 58 */     return Collections.emptyList();
/*    */   }
/*    */ 
/*    */   
/*    */   default AutoModRuleModifyRequest asRequest() {
/* 63 */     return (AutoModRuleModifyRequest)AutoModRuleModifyRequest.builder()
/* 64 */       .name(name())
/* 65 */       .eventType(eventType())
/* 66 */       .triggerMetadata(triggerMetaData())
/* 67 */       .actions(actions())
/* 68 */       .enabled(enabled())
/* 69 */       .exemptRoles((List)exemptRoles().stream().map(Snowflake::asLong).map(Id::of).collect(Collectors.toList()))
/* 70 */       .exemptChannels((List)exemptChannels().stream().map(Snowflake::asLong).map(Id::of).collect(Collectors.toList()))
/* 71 */       .build();
/*    */   }
/*    */   
/*    */   String name();
/*    */   
/*    */   int eventType();
/*    */   
/*    */   Possible<AutoModTriggerMetaData> triggerMetaData();
/*    */   
/*    */   boolean enabled();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\AutoModRuleEditSpecGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */