/*     */ package discord4j.core.spec;
/*     */ 
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.event.domain.interaction.DeferrableInteractionEvent;
/*     */ import discord4j.core.object.component.LayoutComponent;
/*     */ import discord4j.core.object.entity.Attachment;
/*     */ import discord4j.core.object.entity.Message;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import discord4j.rest.util.AllowedMentions;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.stream.StreamSupport;
/*     */ import org.immutables.value.Generated;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "InteractionFollowupEditMonoGenerator", generator = "Immutables")
/*     */ public final class InteractionFollowupEditMono
/*     */   extends InteractionFollowupEditMonoGenerator
/*     */ {
/*     */   private final String content_value;
/*     */   private final boolean content_absent;
/*     */   private final List<EmbedCreateSpec> embeds_value;
/*     */   private final boolean embeds_absent;
/*     */   private final List<MessageCreateFields.File> files;
/*     */   private final List<MessageCreateFields.FileSpoiler> fileSpoilers;
/*     */   private final AllowedMentions allowedMentions_value;
/*     */   private final boolean allowedMentions_absent;
/*     */   private final List<LayoutComponent> components_value;
/*     */   private final boolean components_absent;
/*     */   private final List<Attachment> attachments_value;
/*     */   private final boolean attachments_absent;
/*     */   private final Snowflake messageId;
/*     */   private final DeferrableInteractionEvent event;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   private volatile transient InitShim initShim;
/*     */   
/*     */   private InteractionFollowupEditMono(Snowflake messageId, DeferrableInteractionEvent event) {
/* 108 */     this.initShim = new InitShim(); this.messageId = Objects.<Snowflake>requireNonNull(messageId, "messageId"); this.event = Objects.<DeferrableInteractionEvent>requireNonNull(event, "event"); Possible<Optional<String>> content$impl = Possible.absent(); Possible<Optional<List<EmbedCreateSpec>>> embeds$impl = Possible.absent(); Possible<Optional<AllowedMentions>> allowedMentions$impl = Possible.absent(); Possible<Optional<List<LayoutComponent>>> components$impl = Possible.absent(); Possible<Optional<List<Attachment>>> attachments$impl = Possible.absent(); this.content_value = Possible.flatOpt(content$impl).orElse(null); this.content_absent = content$impl.isAbsent(); this.embeds_value = Possible.flatOpt(embeds$impl).orElse(null); this.embeds_absent = embeds$impl.isAbsent(); this.allowedMentions_value = Possible.flatOpt(allowedMentions$impl).orElse(null); this.allowedMentions_absent = allowedMentions$impl.isAbsent(); this.components_value = Possible.flatOpt(components$impl).orElse(null); this.components_absent = components$impl.isAbsent(); this.attachments_value = Possible.flatOpt(attachments$impl).orElse(null); this.attachments_absent = attachments$impl.isAbsent(); this.files = this.initShim.files(); this.fileSpoilers = this.initShim.fileSpoilers(); this.initShim = null; } private InteractionFollowupEditMono(Possible<Optional<String>> content, Possible<Optional<List<EmbedCreateSpec>>> embeds, List<MessageCreateFields.File> files, List<MessageCreateFields.FileSpoiler> fileSpoilers, Possible<Optional<AllowedMentions>> allowedMentions, Possible<Optional<List<LayoutComponent>>> components, Possible<Optional<List<Attachment>>> attachments, Snowflake messageId, DeferrableInteractionEvent event) { this.initShim = new InitShim(); Possible<Optional<String>> content$impl = content; Possible<Optional<List<EmbedCreateSpec>>> embeds$impl = embeds; this.initShim.files(files); this.initShim.fileSpoilers(fileSpoilers); Possible<Optional<AllowedMentions>> allowedMentions$impl = allowedMentions; Possible<Optional<List<LayoutComponent>>> components$impl = components; Possible<Optional<List<Attachment>>> attachments$impl = attachments; this.messageId = messageId; this.event = event; this.content_value = Possible.flatOpt(content$impl).orElse(null); this.content_absent = content$impl.isAbsent(); this.embeds_value = Possible.flatOpt(embeds$impl).orElse(null); this.embeds_absent = embeds$impl.isAbsent(); this.allowedMentions_value = Possible.flatOpt(allowedMentions$impl).orElse(null); this.allowedMentions_absent = allowedMentions$impl.isAbsent(); this.components_value = Possible.flatOpt(components$impl).orElse(null); this.components_absent = components$impl.isAbsent();
/*     */     this.attachments_value = Possible.flatOpt(attachments$impl).orElse(null);
/*     */     this.attachments_absent = attachments$impl.isAbsent();
/*     */     this.files = this.initShim.files();
/*     */     this.fileSpoilers = this.initShim.fileSpoilers();
/* 113 */     this.initShim = null; } @Generated(from = "InteractionFollowupEditMonoGenerator", generator = "Immutables") private final class InitShim { private byte filesBuildStage = 0;
/*     */     private List<MessageCreateFields.File> files;
/*     */     
/*     */     List<MessageCreateFields.File> files() {
/* 117 */       if (this.filesBuildStage == -1) throw new IllegalStateException(formatInitCycleMessage()); 
/* 118 */       if (this.filesBuildStage == 0) {
/* 119 */         this.filesBuildStage = -1;
/* 120 */         this.files = (List)InteractionFollowupEditMono.createUnmodifiableList(false, InteractionFollowupEditMono.createSafeList((Iterable)InteractionFollowupEditMono.this.files(), true, false));
/* 121 */         this.filesBuildStage = 1;
/*     */       } 
/* 123 */       return this.files;
/*     */     }
/*     */     
/*     */     void files(List<MessageCreateFields.File> files) {
/* 127 */       this.files = files;
/* 128 */       this.filesBuildStage = 1;
/*     */     }
/*     */     
/* 131 */     private byte fileSpoilersBuildStage = 0;
/*     */     private List<MessageCreateFields.FileSpoiler> fileSpoilers;
/*     */     
/*     */     List<MessageCreateFields.FileSpoiler> fileSpoilers() {
/* 135 */       if (this.fileSpoilersBuildStage == -1) throw new IllegalStateException(formatInitCycleMessage()); 
/* 136 */       if (this.fileSpoilersBuildStage == 0) {
/* 137 */         this.fileSpoilersBuildStage = -1;
/* 138 */         this.fileSpoilers = (List)InteractionFollowupEditMono.createUnmodifiableList(false, InteractionFollowupEditMono.createSafeList((Iterable)InteractionFollowupEditMono.this.fileSpoilers(), true, false));
/* 139 */         this.fileSpoilersBuildStage = 1;
/*     */       } 
/* 141 */       return this.fileSpoilers;
/*     */     }
/*     */     
/*     */     void fileSpoilers(List<MessageCreateFields.FileSpoiler> fileSpoilers) {
/* 145 */       this.fileSpoilers = fileSpoilers;
/* 146 */       this.fileSpoilersBuildStage = 1;
/*     */     }
/*     */     
/*     */     private String formatInitCycleMessage() {
/* 150 */       List<String> attributes = new ArrayList<>();
/* 151 */       if (this.filesBuildStage == -1) attributes.add("files"); 
/* 152 */       if (this.fileSpoilersBuildStage == -1) attributes.add("fileSpoilers"); 
/* 153 */       return "Cannot build InteractionFollowupEditMono, attribute initializers form cycle " + attributes;
/*     */     }
/*     */ 
/*     */     
/*     */     private InitShim() {} }
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Optional<String>> content() {
/* 162 */     return this.content_absent ? Possible.absent() : 
/* 163 */       Possible.of(Optional.ofNullable(this.content_value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Optional<List<EmbedCreateSpec>>> embeds() {
/* 171 */     return this.embeds_absent ? Possible.absent() : 
/* 172 */       Possible.of(Optional.ofNullable(this.embeds_value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<MessageCreateFields.File> files() {
/* 180 */     InitShim shim = this.initShim;
/* 181 */     return (shim != null) ? 
/* 182 */       shim.files() : 
/* 183 */       this.files;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<MessageCreateFields.FileSpoiler> fileSpoilers() {
/* 191 */     InitShim shim = this.initShim;
/* 192 */     return (shim != null) ? 
/* 193 */       shim.fileSpoilers() : 
/* 194 */       this.fileSpoilers;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Optional<AllowedMentions>> allowedMentions() {
/* 202 */     return this.allowedMentions_absent ? Possible.absent() : 
/* 203 */       Possible.of(Optional.ofNullable(this.allowedMentions_value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Optional<List<LayoutComponent>>> components() {
/* 211 */     return this.components_absent ? Possible.absent() : 
/* 212 */       Possible.of(Optional.ofNullable(this.components_value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Optional<List<Attachment>>> attachments() {
/* 220 */     return this.attachments_absent ? Possible.absent() : 
/* 221 */       Possible.of(Optional.ofNullable(this.attachments_value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Snowflake messageId() {
/* 229 */     return this.messageId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DeferrableInteractionEvent event() {
/* 237 */     return this.event;
/*     */   }
/*     */   
/*     */   public InteractionFollowupEditMono withContent(Possible<Optional<String>> value) {
/* 241 */     Possible<Optional<String>> newValue = Objects.<Possible<Optional<String>>>requireNonNull(value);
/* 242 */     return new InteractionFollowupEditMono(newValue, 
/*     */         
/* 244 */         embeds(), this.files, this.fileSpoilers, 
/*     */ 
/*     */         
/* 247 */         allowedMentions(), 
/* 248 */         components(), 
/* 249 */         attachments(), this.messageId, this.event);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public InteractionFollowupEditMono withContent(@Nullable String value) {
/* 256 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/* 257 */     return new InteractionFollowupEditMono(newValue, 
/*     */         
/* 259 */         embeds(), this.files, this.fileSpoilers, 
/*     */ 
/*     */         
/* 262 */         allowedMentions(), 
/* 263 */         components(), 
/* 264 */         attachments(), this.messageId, this.event);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public InteractionFollowupEditMono withContentOrNull(@Nullable String value) {
/* 270 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/* 271 */     return new InteractionFollowupEditMono(newValue, 
/*     */         
/* 273 */         embeds(), this.files, this.fileSpoilers, 
/*     */ 
/*     */         
/* 276 */         allowedMentions(), 
/* 277 */         components(), 
/* 278 */         attachments(), this.messageId, this.event);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public InteractionFollowupEditMono withEmbeds(Possible<Optional<List<EmbedCreateSpec>>> possible) {
/* 284 */     Possible<Optional<List<EmbedCreateSpec>>> newValue = Objects.<Possible<Optional<List<EmbedCreateSpec>>>>requireNonNull(possible);
/* 285 */     return new InteractionFollowupEditMono(
/* 286 */         content(), newValue, this.files, this.fileSpoilers, 
/*     */ 
/*     */ 
/*     */         
/* 290 */         allowedMentions(), 
/* 291 */         components(), 
/* 292 */         attachments(), this.messageId, this.event);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public InteractionFollowupEditMono withEmbeds(@Nullable Iterable<EmbedCreateSpec> elements) {
/* 299 */     Possible<Optional<List<EmbedCreateSpec>>> newValue = Possible.of(Optional.<Iterable<EmbedCreateSpec>>ofNullable(elements)
/* 300 */         .map(els -> (List)StreamSupport.stream(els.spliterator(), false).collect(Collectors.toList())));
/* 301 */     return new InteractionFollowupEditMono(
/* 302 */         content(), newValue, this.files, this.fileSpoilers, 
/*     */ 
/*     */ 
/*     */         
/* 306 */         allowedMentions(), 
/* 307 */         components(), 
/* 308 */         attachments(), this.messageId, this.event);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public InteractionFollowupEditMono withEmbedsOrNull(@Nullable Iterable<EmbedCreateSpec> elements) {
/* 314 */     Possible<Optional<List<EmbedCreateSpec>>> newValue = Possible.of(Optional.<Iterable<EmbedCreateSpec>>ofNullable(elements)
/* 315 */         .map(els -> (List)StreamSupport.stream(els.spliterator(), false).collect(Collectors.toList())));
/* 316 */     return new InteractionFollowupEditMono(
/* 317 */         content(), newValue, this.files, this.fileSpoilers, 
/*     */ 
/*     */ 
/*     */         
/* 321 */         allowedMentions(), 
/* 322 */         components(), 
/* 323 */         attachments(), this.messageId, this.event);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SafeVarargs
/*     */   public final InteractionFollowupEditMono withEmbeds(EmbedCreateSpec... elements) {
/* 330 */     Possible<Optional<List<EmbedCreateSpec>>> newValue = Possible.of(Optional.of(Arrays.asList(elements)));
/* 331 */     return new InteractionFollowupEditMono(
/* 332 */         content(), newValue, this.files, this.fileSpoilers, 
/*     */ 
/*     */ 
/*     */         
/* 336 */         allowedMentions(), 
/* 337 */         components(), 
/* 338 */         attachments(), this.messageId, this.event);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final InteractionFollowupEditMono withFiles(MessageCreateFields.File... elements) {
/* 349 */     List<MessageCreateFields.File> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/* 350 */     return new InteractionFollowupEditMono(
/* 351 */         content(), 
/* 352 */         embeds(), newValue, this.fileSpoilers, 
/*     */ 
/*     */         
/* 355 */         allowedMentions(), 
/* 356 */         components(), 
/* 357 */         attachments(), this.messageId, this.event);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final InteractionFollowupEditMono withFiles(Iterable<? extends MessageCreateFields.File> elements) {
/* 369 */     if (this.files == elements) return this; 
/* 370 */     List<MessageCreateFields.File> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/* 371 */     return new InteractionFollowupEditMono(
/* 372 */         content(), 
/* 373 */         embeds(), newValue, this.fileSpoilers, 
/*     */ 
/*     */         
/* 376 */         allowedMentions(), 
/* 377 */         components(), 
/* 378 */         attachments(), this.messageId, this.event);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final InteractionFollowupEditMono withFileSpoilers(MessageCreateFields.FileSpoiler... elements) {
/* 389 */     List<MessageCreateFields.FileSpoiler> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/* 390 */     return new InteractionFollowupEditMono(
/* 391 */         content(), 
/* 392 */         embeds(), this.files, newValue, 
/*     */ 
/*     */         
/* 395 */         allowedMentions(), 
/* 396 */         components(), 
/* 397 */         attachments(), this.messageId, this.event);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final InteractionFollowupEditMono withFileSpoilers(Iterable<? extends MessageCreateFields.FileSpoiler> elements) {
/* 409 */     if (this.fileSpoilers == elements) return this; 
/* 410 */     List<MessageCreateFields.FileSpoiler> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/* 411 */     return new InteractionFollowupEditMono(
/* 412 */         content(), 
/* 413 */         embeds(), this.files, newValue, 
/*     */ 
/*     */         
/* 416 */         allowedMentions(), 
/* 417 */         components(), 
/* 418 */         attachments(), this.messageId, this.event);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public InteractionFollowupEditMono withAllowedMentions(Possible<Optional<AllowedMentions>> value) {
/* 424 */     Possible<Optional<AllowedMentions>> newValue = Objects.<Possible<Optional<AllowedMentions>>>requireNonNull(value);
/* 425 */     return new InteractionFollowupEditMono(
/* 426 */         content(), 
/* 427 */         embeds(), this.files, this.fileSpoilers, newValue, 
/*     */ 
/*     */ 
/*     */         
/* 431 */         components(), 
/* 432 */         attachments(), this.messageId, this.event);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public InteractionFollowupEditMono withAllowedMentions(@Nullable AllowedMentions value) {
/* 439 */     Possible<Optional<AllowedMentions>> newValue = Possible.of(Optional.ofNullable(value));
/* 440 */     return new InteractionFollowupEditMono(
/* 441 */         content(), 
/* 442 */         embeds(), this.files, this.fileSpoilers, newValue, 
/*     */ 
/*     */ 
/*     */         
/* 446 */         components(), 
/* 447 */         attachments(), this.messageId, this.event);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public InteractionFollowupEditMono withAllowedMentionsOrNull(@Nullable AllowedMentions value) {
/* 453 */     Possible<Optional<AllowedMentions>> newValue = Possible.of(Optional.ofNullable(value));
/* 454 */     return new InteractionFollowupEditMono(
/* 455 */         content(), 
/* 456 */         embeds(), this.files, this.fileSpoilers, newValue, 
/*     */ 
/*     */ 
/*     */         
/* 460 */         components(), 
/* 461 */         attachments(), this.messageId, this.event);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public InteractionFollowupEditMono withComponents(Possible<Optional<List<LayoutComponent>>> possible) {
/* 467 */     Possible<Optional<List<LayoutComponent>>> newValue = Objects.<Possible<Optional<List<LayoutComponent>>>>requireNonNull(possible);
/* 468 */     return new InteractionFollowupEditMono(
/* 469 */         content(), 
/* 470 */         embeds(), this.files, this.fileSpoilers, 
/*     */ 
/*     */         
/* 473 */         allowedMentions(), newValue, 
/*     */         
/* 475 */         attachments(), this.messageId, this.event);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public InteractionFollowupEditMono withComponents(@Nullable Iterable<LayoutComponent> elements) {
/* 482 */     Possible<Optional<List<LayoutComponent>>> newValue = Possible.of(Optional.<Iterable<LayoutComponent>>ofNullable(elements)
/* 483 */         .map(els -> (List)StreamSupport.stream(els.spliterator(), false).collect(Collectors.toList())));
/* 484 */     return new InteractionFollowupEditMono(
/* 485 */         content(), 
/* 486 */         embeds(), this.files, this.fileSpoilers, 
/*     */ 
/*     */         
/* 489 */         allowedMentions(), newValue, 
/*     */         
/* 491 */         attachments(), this.messageId, this.event);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public InteractionFollowupEditMono withComponentsOrNull(@Nullable Iterable<LayoutComponent> elements) {
/* 497 */     Possible<Optional<List<LayoutComponent>>> newValue = Possible.of(Optional.<Iterable<LayoutComponent>>ofNullable(elements)
/* 498 */         .map(els -> (List)StreamSupport.stream(els.spliterator(), false).collect(Collectors.toList())));
/* 499 */     return new InteractionFollowupEditMono(
/* 500 */         content(), 
/* 501 */         embeds(), this.files, this.fileSpoilers, 
/*     */ 
/*     */         
/* 504 */         allowedMentions(), newValue, 
/*     */         
/* 506 */         attachments(), this.messageId, this.event);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SafeVarargs
/*     */   public final InteractionFollowupEditMono withComponents(LayoutComponent... elements) {
/* 513 */     Possible<Optional<List<LayoutComponent>>> newValue = Possible.of(Optional.of(Arrays.asList(elements)));
/* 514 */     return new InteractionFollowupEditMono(
/* 515 */         content(), 
/* 516 */         embeds(), this.files, this.fileSpoilers, 
/*     */ 
/*     */         
/* 519 */         allowedMentions(), newValue, 
/*     */         
/* 521 */         attachments(), this.messageId, this.event);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public InteractionFollowupEditMono withAttachments(Possible<Optional<List<Attachment>>> possible) {
/* 527 */     Possible<Optional<List<Attachment>>> newValue = Objects.<Possible<Optional<List<Attachment>>>>requireNonNull(possible);
/* 528 */     return new InteractionFollowupEditMono(
/* 529 */         content(), 
/* 530 */         embeds(), this.files, this.fileSpoilers, 
/*     */ 
/*     */         
/* 533 */         allowedMentions(), 
/* 534 */         components(), newValue, this.messageId, this.event);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public InteractionFollowupEditMono withAttachments(@Nullable Iterable<Attachment> elements) {
/* 542 */     Possible<Optional<List<Attachment>>> newValue = Possible.of(Optional.<Iterable<Attachment>>ofNullable(elements)
/* 543 */         .map(els -> (List)StreamSupport.stream(els.spliterator(), false).collect(Collectors.toList())));
/* 544 */     return new InteractionFollowupEditMono(
/* 545 */         content(), 
/* 546 */         embeds(), this.files, this.fileSpoilers, 
/*     */ 
/*     */         
/* 549 */         allowedMentions(), 
/* 550 */         components(), newValue, this.messageId, this.event);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InteractionFollowupEditMono withAttachmentsOrNull(@Nullable Iterable<Attachment> elements) {
/* 557 */     Possible<Optional<List<Attachment>>> newValue = Possible.of(Optional.<Iterable<Attachment>>ofNullable(elements)
/* 558 */         .map(els -> (List)StreamSupport.stream(els.spliterator(), false).collect(Collectors.toList())));
/* 559 */     return new InteractionFollowupEditMono(
/* 560 */         content(), 
/* 561 */         embeds(), this.files, this.fileSpoilers, 
/*     */ 
/*     */         
/* 564 */         allowedMentions(), 
/* 565 */         components(), newValue, this.messageId, this.event);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SafeVarargs
/*     */   public final InteractionFollowupEditMono withAttachments(Attachment... elements) {
/* 573 */     Possible<Optional<List<Attachment>>> newValue = Possible.of(Optional.of(Arrays.asList(elements)));
/* 574 */     return new InteractionFollowupEditMono(
/* 575 */         content(), 
/* 576 */         embeds(), this.files, this.fileSpoilers, 
/*     */ 
/*     */         
/* 579 */         allowedMentions(), 
/* 580 */         components(), newValue, this.messageId, this.event);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final InteractionFollowupEditMono withMessageId(Snowflake value) {
/* 593 */     if (this.messageId == value) return this; 
/* 594 */     Snowflake newValue = Objects.<Snowflake>requireNonNull(value, "messageId");
/* 595 */     return new InteractionFollowupEditMono(
/* 596 */         content(), 
/* 597 */         embeds(), this.files, this.fileSpoilers, 
/*     */ 
/*     */         
/* 600 */         allowedMentions(), 
/* 601 */         components(), 
/* 602 */         attachments(), newValue, this.event);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final InteractionFollowupEditMono withEvent(DeferrableInteractionEvent value) {
/* 614 */     if (this.event == value) return this; 
/* 615 */     DeferrableInteractionEvent newValue = Objects.<DeferrableInteractionEvent>requireNonNull(value, "event");
/* 616 */     return new InteractionFollowupEditMono(
/* 617 */         content(), 
/* 618 */         embeds(), this.files, this.fileSpoilers, 
/*     */ 
/*     */         
/* 621 */         allowedMentions(), 
/* 622 */         components(), 
/* 623 */         attachments(), this.messageId, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 634 */     if (this == another) return true; 
/* 635 */     return (another instanceof InteractionFollowupEditMono && 
/* 636 */       equalTo(0, (InteractionFollowupEditMono)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, InteractionFollowupEditMono another) {
/* 640 */     return (content().equals(another.content()) && 
/* 641 */       Objects.equals(this.embeds_value, another.embeds_value) && this.files
/* 642 */       .equals(another.files) && this.fileSpoilers
/* 643 */       .equals(another.fileSpoilers) && 
/* 644 */       allowedMentions().equals(another.allowedMentions()) && 
/* 645 */       Objects.equals(this.components_value, another.components_value) && 
/* 646 */       Objects.equals(this.attachments_value, another.attachments_value) && this.messageId
/* 647 */       .equals(another.messageId) && this.event
/* 648 */       .equals(another.event));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 657 */     int h = 5381;
/* 658 */     h += (h << 5) + content().hashCode();
/* 659 */     h += (h << 5) + Objects.hashCode(this.embeds_value);
/* 660 */     h += (h << 5) + this.files.hashCode();
/* 661 */     h += (h << 5) + this.fileSpoilers.hashCode();
/* 662 */     h += (h << 5) + allowedMentions().hashCode();
/* 663 */     h += (h << 5) + Objects.hashCode(this.components_value);
/* 664 */     h += (h << 5) + Objects.hashCode(this.attachments_value);
/* 665 */     h += (h << 5) + this.messageId.hashCode();
/* 666 */     h += (h << 5) + this.event.hashCode();
/* 667 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 676 */     return "InteractionFollowupEditMono{content=" + 
/* 677 */       content().toString() + ", embeds=" + 
/* 678 */       Objects.toString(this.embeds_value) + ", files=" + this.files + ", fileSpoilers=" + this.fileSpoilers + ", allowedMentions=" + 
/*     */ 
/*     */       
/* 681 */       allowedMentions().toString() + ", components=" + 
/* 682 */       Objects.toString(this.components_value) + ", attachments=" + 
/* 683 */       Objects.toString(this.attachments_value) + ", messageId=" + this.messageId + ", event=" + this.event + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static InteractionFollowupEditMono of(Snowflake messageId, DeferrableInteractionEvent event) {
/* 696 */     return new InteractionFollowupEditMono(messageId, event);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static InteractionFollowupEditMono copyOf(InteractionFollowupEditMonoGenerator instance) {
/* 707 */     if (instance instanceof InteractionFollowupEditMono) {
/* 708 */       return (InteractionFollowupEditMono)instance;
/*     */     }
/* 710 */     return of(instance.messageId(), instance.event())
/* 711 */       .withContent(instance.content())
/* 712 */       .withEmbeds(instance.embeds())
/* 713 */       .withFiles(instance.files())
/* 714 */       .withFileSpoilers(instance.fileSpoilers())
/* 715 */       .withAllowedMentions(instance.allowedMentions())
/* 716 */       .withComponents(instance.components())
/* 717 */       .withAttachments(instance.attachments());
/*     */   }
/*     */   
/*     */   public boolean isContentPresent() {
/* 721 */     return !this.content_absent;
/*     */   }
/*     */   
/*     */   public String contentOrElse(String defaultValue) {
/* 725 */     return !this.content_absent ? this.content_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isEmbedsPresent() {
/* 729 */     return !this.embeds_absent;
/*     */   }
/*     */   
/*     */   public List<EmbedCreateSpec> embedsOrElse(List<EmbedCreateSpec> defaultValue) {
/* 733 */     return !this.embeds_absent ? this.embeds_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isAllowedMentionsPresent() {
/* 737 */     return !this.allowedMentions_absent;
/*     */   }
/*     */   
/*     */   public AllowedMentions allowedMentionsOrElse(AllowedMentions defaultValue) {
/* 741 */     return !this.allowedMentions_absent ? this.allowedMentions_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isComponentsPresent() {
/* 745 */     return !this.components_absent;
/*     */   }
/*     */   
/*     */   public List<LayoutComponent> componentsOrElse(List<LayoutComponent> defaultValue) {
/* 749 */     return !this.components_absent ? this.components_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isAttachmentsPresent() {
/* 753 */     return !this.attachments_absent;
/*     */   }
/*     */   
/*     */   public List<Attachment> attachmentsOrElse(List<Attachment> defaultValue) {
/* 757 */     return !this.attachments_absent ? this.attachments_value : defaultValue;
/*     */   }
/*     */   
/*     */   private static <T> List<T> createSafeList(Iterable<? extends T> iterable, boolean checkNulls, boolean skipNulls) {
/*     */     ArrayList<T> list;
/* 762 */     if (iterable instanceof Collection) {
/* 763 */       int size = ((Collection)iterable).size();
/* 764 */       if (size == 0) return Collections.emptyList(); 
/* 765 */       list = new ArrayList<>();
/*     */     } else {
/* 767 */       list = new ArrayList<>();
/*     */     } 
/* 769 */     for (T element : iterable) {
/* 770 */       if (skipNulls && element == null)
/* 771 */         continue;  if (checkNulls) Objects.requireNonNull(element, "element"); 
/* 772 */       list.add(element);
/*     */     } 
/* 774 */     return list;
/*     */   }
/*     */   
/*     */   private static <T> List<T> createUnmodifiableList(boolean clone, List<T> list) {
/* 778 */     switch (list.size()) { case 0:
/* 779 */         return Collections.emptyList();
/* 780 */       case 1: return Collections.singletonList(list.get(0)); }
/*     */     
/* 782 */     if (clone) {
/* 783 */       return Collections.unmodifiableList(new ArrayList<>(list));
/*     */     }
/* 785 */     if (list instanceof ArrayList) {
/* 786 */       ((ArrayList)list).trimToSize();
/*     */     }
/* 788 */     return Collections.unmodifiableList(list);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\InteractionFollowupEditMono.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */