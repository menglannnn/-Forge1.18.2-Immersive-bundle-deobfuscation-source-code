/*     */ package discord4j.core.spec;
/*     */ 
/*     */ import com.google.errorprone.annotations.CanIgnoreReturnValue;
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.rest.util.Image;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "GuildEmojiCreateSpecGenerator", generator = "Immutables")
/*     */ public final class GuildEmojiCreateSpec
/*     */   implements GuildEmojiCreateSpecGenerator
/*     */ {
/*     */   @Nullable
/*     */   private final String reason;
/*     */   private final String name;
/*     */   private final Image image;
/*     */   private final List<Snowflake> roles;
/*     */   
/*     */   private GuildEmojiCreateSpec(String name, Image image) {
/*  34 */     this.name = Objects.<String>requireNonNull(name, "name");
/*  35 */     this.image = Objects.<Image>requireNonNull(image, "image");
/*  36 */     this.reason = null;
/*  37 */     this.roles = createUnmodifiableList(false, createSafeList(super.roles(), true, false));
/*     */   }
/*     */   
/*     */   private GuildEmojiCreateSpec(Builder builder) {
/*  41 */     this.reason = builder.reason;
/*  42 */     this.name = builder.name;
/*  43 */     this.image = builder.image;
/*  44 */     this
/*     */       
/*  46 */       .roles = builder.rolesIsSet() ? createUnmodifiableList(true, builder.roles) : createUnmodifiableList(false, createSafeList(super.roles(), true, false));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private GuildEmojiCreateSpec(@Nullable String reason, String name, Image image, List<Snowflake> roles) {
/*  54 */     this.reason = reason;
/*  55 */     this.name = name;
/*  56 */     this.image = image;
/*  57 */     this.roles = roles;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String reason() {
/*  66 */     return this.reason;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String name() {
/*  74 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Image image() {
/*  82 */     return this.image;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Snowflake> roles() {
/*  90 */     return this.roles;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final GuildEmojiCreateSpec withReason(@Nullable String value) {
/* 100 */     if (Objects.equals(this.reason, value)) return this; 
/* 101 */     return new GuildEmojiCreateSpec(value, this.name, this.image, this.roles);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final GuildEmojiCreateSpec withName(String value) {
/* 111 */     String newValue = Objects.<String>requireNonNull(value, "name");
/* 112 */     if (this.name.equals(newValue)) return this; 
/* 113 */     return new GuildEmojiCreateSpec(this.reason, newValue, this.image, this.roles);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final GuildEmojiCreateSpec withImage(Image value) {
/* 123 */     if (this.image == value) return this; 
/* 124 */     Image newValue = Objects.<Image>requireNonNull(value, "image");
/* 125 */     return new GuildEmojiCreateSpec(this.reason, this.name, newValue, this.roles);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final GuildEmojiCreateSpec withRoles(Snowflake... elements) {
/* 134 */     List<Snowflake> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/* 135 */     return new GuildEmojiCreateSpec(this.reason, this.name, this.image, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final GuildEmojiCreateSpec withRoles(Iterable<? extends Snowflake> elements) {
/* 145 */     if (this.roles == elements) return this; 
/* 146 */     List<Snowflake> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/* 147 */     return new GuildEmojiCreateSpec(this.reason, this.name, this.image, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 156 */     if (this == another) return true; 
/* 157 */     return (another instanceof GuildEmojiCreateSpec && 
/* 158 */       equalTo(0, (GuildEmojiCreateSpec)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, GuildEmojiCreateSpec another) {
/* 162 */     return (Objects.equals(this.reason, another.reason) && this.name
/* 163 */       .equals(another.name) && this.image
/* 164 */       .equals(another.image) && this.roles
/* 165 */       .equals(another.roles));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 174 */     int h = 5381;
/* 175 */     h += (h << 5) + Objects.hashCode(this.reason);
/* 176 */     h += (h << 5) + this.name.hashCode();
/* 177 */     h += (h << 5) + this.image.hashCode();
/* 178 */     h += (h << 5) + this.roles.hashCode();
/* 179 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 188 */     return "GuildEmojiCreateSpec{reason=" + this.reason + ", name=" + this.name + ", image=" + this.image + ", roles=" + this.roles + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static GuildEmojiCreateSpec of(String name, Image image) {
/* 203 */     return new GuildEmojiCreateSpec(name, image);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static GuildEmojiCreateSpec copyOf(GuildEmojiCreateSpecGenerator instance) {
/* 214 */     if (instance instanceof GuildEmojiCreateSpec) {
/* 215 */       return (GuildEmojiCreateSpec)instance;
/*     */     }
/* 217 */     return builder()
/* 218 */       .from(instance)
/* 219 */       .build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 235 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "GuildEmojiCreateSpecGenerator", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_NAME = 1L;
/*     */ 
/*     */     
/*     */     private static final long INIT_BIT_IMAGE = 2L;
/*     */     
/*     */     private static final long OPT_BIT_ROLES = 1L;
/*     */     
/* 250 */     private long initBits = 3L;
/*     */     
/*     */     private long optBits;
/*     */     private String reason;
/*     */     private String name;
/*     */     private Image image;
/* 256 */     private List<Snowflake> roles = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(GuildEmojiCreateSpec instance) {
/* 270 */       return from(instance);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     final Builder from(GuildEmojiCreateSpecGenerator instance) {
/* 280 */       Objects.requireNonNull(instance, "instance");
/* 281 */       String reasonValue = instance.reason();
/* 282 */       if (reasonValue != null) {
/* 283 */         reason(reasonValue);
/*     */       }
/* 285 */       name(instance.name());
/* 286 */       image(instance.image());
/* 287 */       addAllRoles(instance.roles());
/* 288 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder reason(@Nullable String reason) {
/* 298 */       this.reason = reason;
/* 299 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder name(String name) {
/* 309 */       this.name = Objects.<String>requireNonNull(name, "name");
/* 310 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 311 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder image(Image image) {
/* 321 */       this.image = Objects.<Image>requireNonNull(image, "image");
/* 322 */       this.initBits &= 0xFFFFFFFFFFFFFFFDL;
/* 323 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder addRole(Snowflake element) {
/* 333 */       this.roles.add(Objects.<Snowflake>requireNonNull(element, "roles element"));
/* 334 */       this.optBits |= 0x1L;
/* 335 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder addRoles(Snowflake... elements) {
/* 345 */       for (Snowflake element : elements) {
/* 346 */         this.roles.add(Objects.<Snowflake>requireNonNull(element, "roles element"));
/*     */       }
/* 348 */       this.optBits |= 0x1L;
/* 349 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder roles(Iterable<? extends Snowflake> elements) {
/* 360 */       this.roles.clear();
/* 361 */       return addAllRoles(elements);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder addAllRoles(Iterable<? extends Snowflake> elements) {
/* 371 */       for (Snowflake element : elements) {
/* 372 */         this.roles.add(Objects.<Snowflake>requireNonNull(element, "roles element"));
/*     */       }
/* 374 */       this.optBits |= 0x1L;
/* 375 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public GuildEmojiCreateSpec build() {
/* 384 */       if (this.initBits != 0L) {
/* 385 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 387 */       return new GuildEmojiCreateSpec(this);
/*     */     }
/*     */     
/*     */     private boolean rolesIsSet() {
/* 391 */       return ((this.optBits & 0x1L) != 0L);
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 395 */       List<String> attributes = new ArrayList<>();
/* 396 */       if ((this.initBits & 0x1L) != 0L) attributes.add("name"); 
/* 397 */       if ((this.initBits & 0x2L) != 0L) attributes.add("image"); 
/* 398 */       return "Cannot build GuildEmojiCreateSpec, some of required attributes are not set " + attributes;
/*     */     }
/*     */     private Builder() {} }
/*     */   
/*     */   private static <T> List<T> createSafeList(Iterable<? extends T> iterable, boolean checkNulls, boolean skipNulls) {
/*     */     ArrayList<T> list;
/* 404 */     if (iterable instanceof Collection) {
/* 405 */       int size = ((Collection)iterable).size();
/* 406 */       if (size == 0) return Collections.emptyList(); 
/* 407 */       list = new ArrayList<>();
/*     */     } else {
/* 409 */       list = new ArrayList<>();
/*     */     } 
/* 411 */     for (T element : iterable) {
/* 412 */       if (skipNulls && element == null)
/* 413 */         continue;  if (checkNulls) Objects.requireNonNull(element, "element"); 
/* 414 */       list.add(element);
/*     */     } 
/* 416 */     return list;
/*     */   }
/*     */   
/*     */   private static <T> List<T> createUnmodifiableList(boolean clone, List<T> list) {
/* 420 */     switch (list.size()) { case 0:
/* 421 */         return Collections.emptyList();
/* 422 */       case 1: return Collections.singletonList(list.get(0)); }
/*     */     
/* 424 */     if (clone) {
/* 425 */       return Collections.unmodifiableList(new ArrayList<>(list));
/*     */     }
/* 427 */     if (list instanceof ArrayList) {
/* 428 */       ((ArrayList)list).trimToSize();
/*     */     }
/* 430 */     return Collections.unmodifiableList(list);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\GuildEmojiCreateSpec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */