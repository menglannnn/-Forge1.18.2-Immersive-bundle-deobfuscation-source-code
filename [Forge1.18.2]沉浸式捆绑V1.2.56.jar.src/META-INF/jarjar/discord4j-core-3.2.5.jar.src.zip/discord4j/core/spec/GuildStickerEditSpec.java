/*     */ package discord4j.core.spec;
/*     */ 
/*     */ import com.google.errorprone.annotations.CanIgnoreReturnValue;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "GuildStickerEditSpecGenerator", generator = "Immutables")
/*     */ public final class GuildStickerEditSpec
/*     */   implements GuildStickerEditSpecGenerator
/*     */ {
/*     */   @Nullable
/*     */   private final String reason;
/*     */   private final String name_value;
/*     */   private final boolean name_absent;
/*     */   private final String description_value;
/*     */   private final boolean description_absent;
/*     */   private final String tags_value;
/*     */   private final boolean tags_absent;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   
/*     */   private GuildStickerEditSpec() {
/*  33 */     this.reason = null;
/*  34 */     Possible<String> name$impl = Possible.absent();
/*  35 */     Possible<String> description$impl = Possible.absent();
/*  36 */     Possible<String> tags$impl = Possible.absent();
/*  37 */     this.name_value = name$impl.toOptional().orElse(null);
/*  38 */     this.name_absent = name$impl.isAbsent();
/*  39 */     this.description_value = description$impl.toOptional().orElse(null);
/*  40 */     this.description_absent = description$impl.isAbsent();
/*  41 */     this.tags_value = tags$impl.toOptional().orElse(null);
/*  42 */     this.tags_absent = tags$impl.isAbsent();
/*  43 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private GuildStickerEditSpec(@Nullable String reason, Possible<String> name, Possible<String> description, Possible<String> tags) {
/*  51 */     this.reason = reason;
/*  52 */     Possible<String> name$impl = name;
/*  53 */     Possible<String> description$impl = description;
/*  54 */     Possible<String> tags$impl = tags;
/*  55 */     this.name_value = name$impl.toOptional().orElse(null);
/*  56 */     this.name_absent = name$impl.isAbsent();
/*  57 */     this.description_value = description$impl.toOptional().orElse(null);
/*  58 */     this.description_absent = description$impl.isAbsent();
/*  59 */     this.tags_value = tags$impl.toOptional().orElse(null);
/*  60 */     this.tags_absent = tags$impl.isAbsent();
/*  61 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  67 */   private volatile transient InitShim initShim = new InitShim();
/*     */   
/*     */   @Generated(from = "GuildStickerEditSpecGenerator", generator = "Immutables")
/*     */   private final class InitShim
/*     */   {
/*     */     private String formatInitCycleMessage() {
/*  73 */       List<String> attributes = new ArrayList<>();
/*  74 */       return "Cannot build GuildStickerEditSpec, attribute initializers form cycle " + attributes;
/*     */     }
/*     */ 
/*     */     
/*     */     private InitShim() {}
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String reason() {
/*  84 */     return this.reason;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<String> name() {
/*  92 */     return this.name_absent ? Possible.absent() : Possible.of(this.name_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<String> description() {
/* 100 */     return this.description_absent ? Possible.absent() : Possible.of(this.description_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<String> tags() {
/* 108 */     return this.tags_absent ? Possible.absent() : Possible.of(this.tags_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final GuildStickerEditSpec withReason(@Nullable String value) {
/* 118 */     if (Objects.equals(this.reason, value)) return this; 
/* 119 */     return validate(new GuildStickerEditSpec(value, name(), description(), tags()));
/*     */   }
/*     */   
/*     */   public GuildStickerEditSpec withName(Possible<String> value) {
/* 123 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/* 124 */     return validate(new GuildStickerEditSpec(this.reason, newValue, description(), tags()));
/*     */   }
/*     */   
/*     */   public GuildStickerEditSpec withName(String value) {
/* 128 */     Possible<String> newValue = Possible.of(value);
/* 129 */     return validate(new GuildStickerEditSpec(this.reason, newValue, description(), tags()));
/*     */   }
/*     */   
/*     */   public GuildStickerEditSpec withDescription(Possible<String> value) {
/* 133 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/* 134 */     return validate(new GuildStickerEditSpec(this.reason, name(), newValue, tags()));
/*     */   }
/*     */   
/*     */   public GuildStickerEditSpec withDescription(String value) {
/* 138 */     Possible<String> newValue = Possible.of(value);
/* 139 */     return validate(new GuildStickerEditSpec(this.reason, name(), newValue, tags()));
/*     */   }
/*     */   
/*     */   public GuildStickerEditSpec withTags(Possible<String> value) {
/* 143 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/* 144 */     return validate(new GuildStickerEditSpec(this.reason, name(), description(), newValue));
/*     */   }
/*     */   
/*     */   public GuildStickerEditSpec withTags(String value) {
/* 148 */     Possible<String> newValue = Possible.of(value);
/* 149 */     return validate(new GuildStickerEditSpec(this.reason, name(), description(), newValue));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 158 */     if (this == another) return true; 
/* 159 */     return (another instanceof GuildStickerEditSpec && 
/* 160 */       equalTo(0, (GuildStickerEditSpec)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, GuildStickerEditSpec another) {
/* 164 */     return (Objects.equals(this.reason, another.reason) && 
/* 165 */       name().equals(another.name()) && 
/* 166 */       description().equals(another.description()) && 
/* 167 */       tags().equals(another.tags()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 176 */     int h = 5381;
/* 177 */     h += (h << 5) + Objects.hashCode(this.reason);
/* 178 */     h += (h << 5) + name().hashCode();
/* 179 */     h += (h << 5) + description().hashCode();
/* 180 */     h += (h << 5) + tags().hashCode();
/* 181 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 190 */     return "GuildStickerEditSpec{reason=" + this.reason + ", name=" + 
/*     */       
/* 192 */       name().toString() + ", description=" + 
/* 193 */       description().toString() + ", tags=" + 
/* 194 */       tags().toString() + "}";
/*     */   }
/*     */ 
/*     */   
/* 198 */   private static final GuildStickerEditSpec INSTANCE = validate(new GuildStickerEditSpec());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static GuildStickerEditSpec create() {
/* 205 */     return INSTANCE;
/*     */   }
/*     */   
/*     */   private static GuildStickerEditSpec validate(GuildStickerEditSpec instance) {
/* 209 */     return (INSTANCE != null && INSTANCE.equalTo(0, instance)) ? INSTANCE : instance;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static GuildStickerEditSpec copyOf(GuildStickerEditSpecGenerator instance) {
/* 220 */     if (instance instanceof GuildStickerEditSpec) {
/* 221 */       return (GuildStickerEditSpec)instance;
/*     */     }
/* 223 */     return builder()
/* 224 */       .from(instance)
/* 225 */       .build();
/*     */   }
/*     */   
/*     */   public boolean isNamePresent() {
/* 229 */     return !this.name_absent;
/*     */   }
/*     */   
/*     */   public String nameOrElse(String defaultValue) {
/* 233 */     return !this.name_absent ? this.name_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isDescriptionPresent() {
/* 237 */     return !this.description_absent;
/*     */   }
/*     */   
/*     */   public String descriptionOrElse(String defaultValue) {
/* 241 */     return !this.description_absent ? this.description_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isTagsPresent() {
/* 245 */     return !this.tags_absent;
/*     */   }
/*     */   
/*     */   public String tagsOrElse(String defaultValue) {
/* 249 */     return !this.tags_absent ? this.tags_value : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 265 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "GuildStickerEditSpecGenerator", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/* 277 */     private Possible<String> name_possible = Possible.absent();
/* 278 */     private Possible<String> description_possible = Possible.absent();
/* 279 */     private Possible<String> tags_possible = Possible.absent();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private String reason;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(GuildStickerEditSpec instance) {
/* 293 */       return from(instance);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     final Builder from(GuildStickerEditSpecGenerator instance) {
/* 303 */       Objects.requireNonNull(instance, "instance");
/* 304 */       String reasonValue = instance.reason();
/* 305 */       if (reasonValue != null) {
/* 306 */         reason(reasonValue);
/*     */       }
/* 308 */       name(instance.name());
/* 309 */       description(instance.description());
/* 310 */       tags(instance.tags());
/* 311 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder reason(@Nullable String reason) {
/* 321 */       this.reason = reason;
/* 322 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder name(Possible<String> value) {
/* 327 */       this.name_possible = value;
/* 328 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder name(String value) {
/* 333 */       this.name_possible = Possible.of(value);
/* 334 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder description(Possible<String> value) {
/* 339 */       this.description_possible = value;
/* 340 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder description(String value) {
/* 345 */       this.description_possible = Possible.of(value);
/* 346 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder tags(Possible<String> value) {
/* 351 */       this.tags_possible = value;
/* 352 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder tags(String value) {
/* 357 */       this.tags_possible = Possible.of(value);
/* 358 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public GuildStickerEditSpec build() {
/* 367 */       return GuildStickerEditSpec.validate(new GuildStickerEditSpec(this.reason, name_build(), description_build(), tags_build()));
/*     */     }
/*     */     
/*     */     private Possible<String> name_build() {
/* 371 */       return this.name_possible;
/*     */     }
/*     */     
/*     */     private Possible<String> description_build() {
/* 375 */       return this.description_possible;
/*     */     }
/*     */     
/*     */     private Possible<String> tags_build() {
/* 379 */       return this.tags_possible;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\GuildStickerEditSpec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */