/*    */ package discord4j.core.spec;
/*    */ 
/*    */ import discord4j.common.util.Snowflake;
/*    */ import discord4j.core.object.PermissionOverwrite;
/*    */ import discord4j.discordjson.json.ChannelModifyRequest;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import java.util.List;
/*    */ import java.util.Optional;
/*    */ import java.util.stream.Collectors;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Immutable(singleton = true)
/*    */ interface StoreChannelEditSpecGenerator
/*    */   extends AuditSpec<ChannelModifyRequest>
/*    */ {
/*    */   default ChannelModifyRequest asRequest() {
/* 48 */     return (ChannelModifyRequest)ChannelModifyRequest.builder()
/* 49 */       .name(name())
/* 50 */       .position(position())
/* 51 */       .permissionOverwrites(InternalSpecUtils.mapPossible(permissionOverwrites(), po -> (List)po.stream().map(PermissionOverwrite::getData).collect(Collectors.toList())))
/*    */ 
/*    */       
/* 54 */       .parentId(InternalSpecUtils.mapPossibleOptional(parentId(), Snowflake::asString))
/* 55 */       .build();
/*    */   }
/*    */   
/*    */   Possible<String> name();
/*    */   
/*    */   Possible<Integer> position();
/*    */   
/*    */   Possible<List<PermissionOverwrite>> permissionOverwrites();
/*    */   
/*    */   Possible<Optional<Snowflake>> parentId();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\StoreChannelEditSpecGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */