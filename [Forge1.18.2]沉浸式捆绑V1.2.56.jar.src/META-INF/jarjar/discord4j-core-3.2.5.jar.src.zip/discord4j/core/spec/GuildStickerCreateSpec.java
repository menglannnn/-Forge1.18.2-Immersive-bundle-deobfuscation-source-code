/*     */ package discord4j.core.spec;
/*     */ 
/*     */ import com.google.errorprone.annotations.CanIgnoreReturnValue;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "GuildStickerCreateSpecGenerator", generator = "Immutables")
/*     */ public final class GuildStickerCreateSpec
/*     */   implements GuildStickerCreateSpecGenerator
/*     */ {
/*     */   @Nullable
/*     */   private final String reason;
/*     */   private final String name;
/*     */   private final String description;
/*     */   private final String tags;
/*     */   private final String file;
/*     */   
/*     */   private GuildStickerCreateSpec(String name, String description, String tags, String file) {
/*  30 */     this.name = Objects.<String>requireNonNull(name, "name");
/*  31 */     this.description = Objects.<String>requireNonNull(description, "description");
/*  32 */     this.tags = Objects.<String>requireNonNull(tags, "tags");
/*  33 */     this.file = Objects.<String>requireNonNull(file, "file");
/*  34 */     this.reason = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private GuildStickerCreateSpec(@Nullable String reason, String name, String description, String tags, String file) {
/*  43 */     this.reason = reason;
/*  44 */     this.name = name;
/*  45 */     this.description = description;
/*  46 */     this.tags = tags;
/*  47 */     this.file = file;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String reason() {
/*  56 */     return this.reason;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String name() {
/*  64 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String description() {
/*  72 */     return this.description;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String tags() {
/*  80 */     return this.tags;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String file() {
/*  88 */     return this.file;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final GuildStickerCreateSpec withReason(@Nullable String value) {
/*  98 */     if (Objects.equals(this.reason, value)) return this; 
/*  99 */     return new GuildStickerCreateSpec(value, this.name, this.description, this.tags, this.file);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final GuildStickerCreateSpec withName(String value) {
/* 109 */     String newValue = Objects.<String>requireNonNull(value, "name");
/* 110 */     if (this.name.equals(newValue)) return this; 
/* 111 */     return new GuildStickerCreateSpec(this.reason, newValue, this.description, this.tags, this.file);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final GuildStickerCreateSpec withDescription(String value) {
/* 121 */     String newValue = Objects.<String>requireNonNull(value, "description");
/* 122 */     if (this.description.equals(newValue)) return this; 
/* 123 */     return new GuildStickerCreateSpec(this.reason, this.name, newValue, this.tags, this.file);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final GuildStickerCreateSpec withTags(String value) {
/* 133 */     String newValue = Objects.<String>requireNonNull(value, "tags");
/* 134 */     if (this.tags.equals(newValue)) return this; 
/* 135 */     return new GuildStickerCreateSpec(this.reason, this.name, this.description, newValue, this.file);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final GuildStickerCreateSpec withFile(String value) {
/* 145 */     String newValue = Objects.<String>requireNonNull(value, "file");
/* 146 */     if (this.file.equals(newValue)) return this; 
/* 147 */     return new GuildStickerCreateSpec(this.reason, this.name, this.description, this.tags, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 156 */     if (this == another) return true; 
/* 157 */     return (another instanceof GuildStickerCreateSpec && 
/* 158 */       equalTo(0, (GuildStickerCreateSpec)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, GuildStickerCreateSpec another) {
/* 162 */     return (Objects.equals(this.reason, another.reason) && this.name
/* 163 */       .equals(another.name) && this.description
/* 164 */       .equals(another.description) && this.tags
/* 165 */       .equals(another.tags) && this.file
/* 166 */       .equals(another.file));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 175 */     int h = 5381;
/* 176 */     h += (h << 5) + Objects.hashCode(this.reason);
/* 177 */     h += (h << 5) + this.name.hashCode();
/* 178 */     h += (h << 5) + this.description.hashCode();
/* 179 */     h += (h << 5) + this.tags.hashCode();
/* 180 */     h += (h << 5) + this.file.hashCode();
/* 181 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 190 */     return "GuildStickerCreateSpec{reason=" + this.reason + ", name=" + this.name + ", description=" + this.description + ", tags=" + this.tags + ", file=" + this.file + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static GuildStickerCreateSpec of(String name, String description, String tags, String file) {
/* 208 */     return new GuildStickerCreateSpec(name, description, tags, file);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static GuildStickerCreateSpec copyOf(GuildStickerCreateSpecGenerator instance) {
/* 219 */     if (instance instanceof GuildStickerCreateSpec) {
/* 220 */       return (GuildStickerCreateSpec)instance;
/*     */     }
/* 222 */     return builder()
/* 223 */       .from(instance)
/* 224 */       .build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 241 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "GuildStickerCreateSpecGenerator", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_NAME = 1L;
/*     */     
/*     */     private static final long INIT_BIT_DESCRIPTION = 2L;
/*     */     
/*     */     private static final long INIT_BIT_TAGS = 4L;
/*     */     
/*     */     private static final long INIT_BIT_FILE = 8L;
/*     */     
/* 257 */     private long initBits = 15L;
/*     */ 
/*     */     
/*     */     private String reason;
/*     */ 
/*     */     
/*     */     private String name;
/*     */ 
/*     */     
/*     */     private String description;
/*     */ 
/*     */     
/*     */     private String tags;
/*     */ 
/*     */     
/*     */     private String file;
/*     */ 
/*     */     
/*     */     public final Builder from(GuildStickerCreateSpec instance) {
/* 276 */       return from(instance);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     final Builder from(GuildStickerCreateSpecGenerator instance) {
/* 286 */       Objects.requireNonNull(instance, "instance");
/* 287 */       String reasonValue = instance.reason();
/* 288 */       if (reasonValue != null) {
/* 289 */         reason(reasonValue);
/*     */       }
/* 291 */       name(instance.name());
/* 292 */       description(instance.description());
/* 293 */       tags(instance.tags());
/* 294 */       file(instance.file());
/* 295 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder reason(@Nullable String reason) {
/* 305 */       this.reason = reason;
/* 306 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder name(String name) {
/* 316 */       this.name = Objects.<String>requireNonNull(name, "name");
/* 317 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 318 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder description(String description) {
/* 328 */       this.description = Objects.<String>requireNonNull(description, "description");
/* 329 */       this.initBits &= 0xFFFFFFFFFFFFFFFDL;
/* 330 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder tags(String tags) {
/* 340 */       this.tags = Objects.<String>requireNonNull(tags, "tags");
/* 341 */       this.initBits &= 0xFFFFFFFFFFFFFFFBL;
/* 342 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder file(String file) {
/* 352 */       this.file = Objects.<String>requireNonNull(file, "file");
/* 353 */       this.initBits &= 0xFFFFFFFFFFFFFFF7L;
/* 354 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public GuildStickerCreateSpec build() {
/* 363 */       if (this.initBits != 0L) {
/* 364 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 366 */       return new GuildStickerCreateSpec(this.reason, this.name, this.description, this.tags, this.file);
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 370 */       List<String> attributes = new ArrayList<>();
/* 371 */       if ((this.initBits & 0x1L) != 0L) attributes.add("name"); 
/* 372 */       if ((this.initBits & 0x2L) != 0L) attributes.add("description"); 
/* 373 */       if ((this.initBits & 0x4L) != 0L) attributes.add("tags"); 
/* 374 */       if ((this.initBits & 0x8L) != 0L) attributes.add("file"); 
/* 375 */       return "Cannot build GuildStickerCreateSpec, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\GuildStickerCreateSpec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */