/*     */ package discord4j.core.spec;
/*     */ 
/*     */ import discord4j.core.object.entity.PartialMember;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "MemberBanQueryMonoGenerator", generator = "Immutables")
/*     */ public final class MemberBanQueryMono
/*     */   extends MemberBanQueryMonoGenerator
/*     */ {
/*     */   @Nullable
/*     */   private final String reason;
/*     */   @Nullable
/*     */   private final Integer deleteMessageSeconds;
/*     */   @Nullable
/*     */   private final Integer deleteMessageDays;
/*     */   private final PartialMember member;
/*     */   
/*     */   private MemberBanQueryMono(PartialMember member) {
/*  25 */     this.member = Objects.<PartialMember>requireNonNull(member, "member");
/*  26 */     this.reason = null;
/*  27 */     this.deleteMessageSeconds = null;
/*  28 */     this.deleteMessageDays = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MemberBanQueryMono(@Nullable String reason, @Nullable Integer deleteMessageSeconds, @Nullable Integer deleteMessageDays, PartialMember member) {
/*  36 */     this.reason = reason;
/*  37 */     this.deleteMessageSeconds = deleteMessageSeconds;
/*  38 */     this.deleteMessageDays = deleteMessageDays;
/*  39 */     this.member = member;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String reason() {
/*  48 */     return this.reason;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Integer deleteMessageSeconds() {
/*  56 */     return this.deleteMessageSeconds;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @Nullable
/*     */   public Integer deleteMessageDays() {
/*  65 */     return this.deleteMessageDays;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PartialMember member() {
/*  73 */     return this.member;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final MemberBanQueryMono withReason(@Nullable String value) {
/*  83 */     if (Objects.equals(this.reason, value)) return this; 
/*  84 */     return new MemberBanQueryMono(value, this.deleteMessageSeconds, this.deleteMessageDays, this.member);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final MemberBanQueryMono withDeleteMessageSeconds(@Nullable Integer value) {
/*  94 */     if (Objects.equals(this.deleteMessageSeconds, value)) return this; 
/*  95 */     return new MemberBanQueryMono(this.reason, value, this.deleteMessageDays, this.member);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public final MemberBanQueryMono withDeleteMessageDays(@Nullable Integer value) {
/* 106 */     if (Objects.equals(this.deleteMessageDays, value)) return this; 
/* 107 */     return new MemberBanQueryMono(this.reason, this.deleteMessageSeconds, value, this.member);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final MemberBanQueryMono withMember(PartialMember value) {
/* 117 */     if (this.member == value) return this; 
/* 118 */     PartialMember newValue = Objects.<PartialMember>requireNonNull(value, "member");
/* 119 */     return new MemberBanQueryMono(this.reason, this.deleteMessageSeconds, this.deleteMessageDays, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 128 */     if (this == another) return true; 
/* 129 */     return (another instanceof MemberBanQueryMono && 
/* 130 */       equalTo(0, (MemberBanQueryMono)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, MemberBanQueryMono another) {
/* 134 */     return (Objects.equals(this.reason, another.reason) && 
/* 135 */       Objects.equals(this.deleteMessageSeconds, another.deleteMessageSeconds) && 
/* 136 */       Objects.equals(this.deleteMessageDays, another.deleteMessageDays) && this.member
/* 137 */       .equals(another.member));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 146 */     int h = 5381;
/* 147 */     h += (h << 5) + Objects.hashCode(this.reason);
/* 148 */     h += (h << 5) + Objects.hashCode(this.deleteMessageSeconds);
/* 149 */     h += (h << 5) + Objects.hashCode(this.deleteMessageDays);
/* 150 */     h += (h << 5) + this.member.hashCode();
/* 151 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 160 */     return "MemberBanQueryMono{reason=" + this.reason + ", deleteMessageSeconds=" + this.deleteMessageSeconds + ", deleteMessageDays=" + this.deleteMessageDays + ", member=" + this.member + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MemberBanQueryMono of(PartialMember member) {
/* 174 */     return new MemberBanQueryMono(member);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static MemberBanQueryMono copyOf(MemberBanQueryMonoGenerator instance) {
/* 185 */     if (instance instanceof MemberBanQueryMono) {
/* 186 */       return (MemberBanQueryMono)instance;
/*     */     }
/* 188 */     return of(instance.member())
/* 189 */       .withReason(instance.reason())
/* 190 */       .withDeleteMessageSeconds(instance.deleteMessageSeconds())
/* 191 */       .withDeleteMessageDays(instance.deleteMessageDays());
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\MemberBanQueryMono.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */