/*     */ package discord4j.core.spec;
/*     */ 
/*     */ import discord4j.core.GatewayDiscordClient;
/*     */ import discord4j.core.object.entity.User;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import discord4j.rest.util.Image;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ import reactor.core.CoreSubscriber;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "UserEditMonoGenerator", generator = "Immutables")
/*     */ public final class UserEditMono
/*     */   extends UserEditMonoGenerator
/*     */ {
/*     */   private final String username_value;
/*     */   private final boolean username_absent;
/*     */   private final Image avatar_value;
/*     */   private final boolean avatar_absent;
/*     */   private final GatewayDiscordClient gateway;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   private volatile transient InitShim initShim;
/*     */   
/*     */   private UserEditMono(GatewayDiscordClient gateway) {
/*  56 */     this.initShim = new InitShim(); this.gateway = Objects.<GatewayDiscordClient>requireNonNull(gateway, "gateway"); Possible<String> username$impl = Possible.absent(); Possible<Image> avatar$impl = Possible.absent(); this.username_value = username$impl.toOptional().orElse(null); this.username_absent = username$impl.isAbsent(); this.avatar_value = avatar$impl.toOptional().orElse(null); this.avatar_absent = avatar$impl.isAbsent(); this.initShim = null; } private UserEditMono(Possible<String> username, Possible<Image> avatar, GatewayDiscordClient gateway) { this.initShim = new InitShim(); Possible<String> username$impl = username; Possible<Image> avatar$impl = avatar;
/*     */     this.gateway = gateway;
/*     */     this.username_value = username$impl.toOptional().orElse(null);
/*     */     this.username_absent = username$impl.isAbsent();
/*     */     this.avatar_value = avatar$impl.toOptional().orElse(null);
/*     */     this.avatar_absent = avatar$impl.isAbsent();
/*  62 */     this.initShim = null; } @Generated(from = "UserEditMonoGenerator", generator = "Immutables") private final class InitShim { private InitShim() {} private String formatInitCycleMessage() { List<String> attributes = new ArrayList<>();
/*  63 */       return "Cannot build UserEditMono, attribute initializers form cycle " + attributes; }
/*     */      }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<String> username() {
/*  72 */     return this.username_absent ? Possible.absent() : Possible.of(this.username_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Image> avatar() {
/*  80 */     return this.avatar_absent ? Possible.absent() : Possible.of(this.avatar_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GatewayDiscordClient gateway() {
/*  88 */     return this.gateway;
/*     */   }
/*     */   
/*     */   public UserEditMono withUsername(Possible<String> value) {
/*  92 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/*  93 */     return new UserEditMono(newValue, avatar(), this.gateway);
/*     */   }
/*     */   
/*     */   public UserEditMono withUsername(String value) {
/*  97 */     Possible<String> newValue = Possible.of(value);
/*  98 */     return new UserEditMono(newValue, avatar(), this.gateway);
/*     */   }
/*     */   
/*     */   public UserEditMono withAvatar(Possible<Image> value) {
/* 102 */     Possible<Image> newValue = Objects.<Possible<Image>>requireNonNull(value);
/* 103 */     return new UserEditMono(username(), newValue, this.gateway);
/*     */   }
/*     */   
/*     */   public UserEditMono withAvatar(Image value) {
/* 107 */     Possible<Image> newValue = Possible.of(value);
/* 108 */     return new UserEditMono(username(), newValue, this.gateway);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final UserEditMono withGateway(GatewayDiscordClient value) {
/* 118 */     if (this.gateway == value) return this; 
/* 119 */     GatewayDiscordClient newValue = Objects.<GatewayDiscordClient>requireNonNull(value, "gateway");
/* 120 */     return new UserEditMono(username(), avatar(), newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 129 */     if (this == another) return true; 
/* 130 */     return (another instanceof UserEditMono && 
/* 131 */       equalTo(0, (UserEditMono)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, UserEditMono another) {
/* 135 */     return (username().equals(another.username()) && 
/* 136 */       avatar().equals(another.avatar()) && this.gateway
/* 137 */       .equals(another.gateway));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 146 */     int h = 5381;
/* 147 */     h += (h << 5) + username().hashCode();
/* 148 */     h += (h << 5) + avatar().hashCode();
/* 149 */     h += (h << 5) + this.gateway.hashCode();
/* 150 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 159 */     return "UserEditMono{username=" + 
/* 160 */       username().toString() + ", avatar=" + 
/* 161 */       avatar().toString() + ", gateway=" + this.gateway + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static UserEditMono of(GatewayDiscordClient gateway) {
/* 172 */     return new UserEditMono(gateway);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static UserEditMono copyOf(UserEditMonoGenerator instance) {
/* 183 */     if (instance instanceof UserEditMono) {
/* 184 */       return (UserEditMono)instance;
/*     */     }
/* 186 */     return of(instance.gateway())
/* 187 */       .withUsername(instance.username())
/* 188 */       .withAvatar(instance.avatar());
/*     */   }
/*     */   
/*     */   public boolean isUsernamePresent() {
/* 192 */     return !this.username_absent;
/*     */   }
/*     */   
/*     */   public String usernameOrElse(String defaultValue) {
/* 196 */     return !this.username_absent ? this.username_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isAvatarPresent() {
/* 200 */     return !this.avatar_absent;
/*     */   }
/*     */   
/*     */   public Image avatarOrElse(Image defaultValue) {
/* 204 */     return !this.avatar_absent ? this.avatar_value : defaultValue;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\UserEditMono.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */