/*     */ package discord4j.core.spec;
/*     */ 
/*     */ import com.google.errorprone.annotations.CanIgnoreReturnValue;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "BanQuerySpecGenerator", generator = "Immutables")
/*     */ public final class BanQuerySpec
/*     */   implements BanQuerySpecGenerator
/*     */ {
/*     */   @Nullable
/*     */   private final String reason;
/*     */   @Nullable
/*     */   private final Integer deleteMessageSeconds;
/*     */   @Nullable
/*     */   private final Integer deleteMessageDays;
/*     */   
/*     */   private BanQuerySpec() {
/*  26 */     this.reason = null;
/*  27 */     this.deleteMessageSeconds = null;
/*  28 */     this.deleteMessageDays = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private BanQuerySpec(@Nullable String reason, @Nullable Integer deleteMessageSeconds, @Nullable Integer deleteMessageDays) {
/*  35 */     this.reason = reason;
/*  36 */     this.deleteMessageSeconds = deleteMessageSeconds;
/*  37 */     this.deleteMessageDays = deleteMessageDays;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String reason() {
/*  46 */     return this.reason;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Integer deleteMessageSeconds() {
/*  54 */     return this.deleteMessageSeconds;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @Nullable
/*     */   public Integer deleteMessageDays() {
/*  63 */     return this.deleteMessageDays;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final BanQuerySpec withReason(@Nullable String value) {
/*  73 */     if (Objects.equals(this.reason, value)) return this; 
/*  74 */     return validate(new BanQuerySpec(value, this.deleteMessageSeconds, this.deleteMessageDays));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final BanQuerySpec withDeleteMessageSeconds(@Nullable Integer value) {
/*  84 */     if (Objects.equals(this.deleteMessageSeconds, value)) return this; 
/*  85 */     return validate(new BanQuerySpec(this.reason, value, this.deleteMessageDays));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public final BanQuerySpec withDeleteMessageDays(@Nullable Integer value) {
/*  96 */     if (Objects.equals(this.deleteMessageDays, value)) return this; 
/*  97 */     return validate(new BanQuerySpec(this.reason, this.deleteMessageSeconds, value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 106 */     if (this == another) return true; 
/* 107 */     return (another instanceof BanQuerySpec && 
/* 108 */       equalTo(0, (BanQuerySpec)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, BanQuerySpec another) {
/* 112 */     return (Objects.equals(this.reason, another.reason) && 
/* 113 */       Objects.equals(this.deleteMessageSeconds, another.deleteMessageSeconds) && 
/* 114 */       Objects.equals(this.deleteMessageDays, another.deleteMessageDays));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 123 */     int h = 5381;
/* 124 */     h += (h << 5) + Objects.hashCode(this.reason);
/* 125 */     h += (h << 5) + Objects.hashCode(this.deleteMessageSeconds);
/* 126 */     h += (h << 5) + Objects.hashCode(this.deleteMessageDays);
/* 127 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 136 */     return "BanQuerySpec{reason=" + this.reason + ", deleteMessageSeconds=" + this.deleteMessageSeconds + ", deleteMessageDays=" + this.deleteMessageDays + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 143 */   private static final BanQuerySpec INSTANCE = validate(new BanQuerySpec());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static BanQuerySpec create() {
/* 150 */     return INSTANCE;
/*     */   }
/*     */   
/*     */   private static BanQuerySpec validate(BanQuerySpec instance) {
/* 154 */     return (INSTANCE != null && INSTANCE.equalTo(0, instance)) ? INSTANCE : instance;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static BanQuerySpec copyOf(BanQuerySpecGenerator instance) {
/* 165 */     if (instance instanceof BanQuerySpec) {
/* 166 */       return (BanQuerySpec)instance;
/*     */     }
/* 168 */     return builder()
/* 169 */       .from(instance)
/* 170 */       .build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 185 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "BanQuerySpecGenerator", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private String reason;
/*     */ 
/*     */ 
/*     */     
/*     */     private Integer deleteMessageSeconds;
/*     */ 
/*     */ 
/*     */     
/*     */     private Integer deleteMessageDays;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private Builder() {}
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(BanQuerySpec instance) {
/* 212 */       return from(instance);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     final Builder from(BanQuerySpecGenerator instance) {
/* 222 */       Objects.requireNonNull(instance, "instance");
/* 223 */       String reasonValue = instance.reason();
/* 224 */       if (reasonValue != null) {
/* 225 */         reason(reasonValue);
/*     */       }
/* 227 */       Integer deleteMessageSecondsValue = instance.deleteMessageSeconds();
/* 228 */       if (deleteMessageSecondsValue != null) {
/* 229 */         deleteMessageSeconds(deleteMessageSecondsValue);
/*     */       }
/* 231 */       Integer deleteMessageDaysValue = instance.deleteMessageDays();
/* 232 */       if (deleteMessageDaysValue != null) {
/* 233 */         deleteMessageDays(deleteMessageDaysValue);
/*     */       }
/* 235 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder reason(@Nullable String reason) {
/* 245 */       this.reason = reason;
/* 246 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder deleteMessageSeconds(@Nullable Integer deleteMessageSeconds) {
/* 256 */       this.deleteMessageSeconds = deleteMessageSeconds;
/* 257 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Deprecated
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder deleteMessageDays(@Nullable Integer deleteMessageDays) {
/* 268 */       this.deleteMessageDays = deleteMessageDays;
/* 269 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public BanQuerySpec build() {
/* 278 */       return BanQuerySpec.validate(new BanQuerySpec(this.reason, this.deleteMessageSeconds, this.deleteMessageDays));
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\BanQuerySpec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */