/*      */ package discord4j.core.spec;
/*      */ 
/*      */ import com.google.errorprone.annotations.CanIgnoreReturnValue;
/*      */ import discord4j.core.object.component.LayoutComponent;
/*      */ import discord4j.core.object.entity.Attachment;
/*      */ import discord4j.core.object.entity.Message;
/*      */ import discord4j.discordjson.possible.Possible;
/*      */ import discord4j.rest.util.AllowedMentions;
/*      */ import java.io.InputStream;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.List;
/*      */ import java.util.Objects;
/*      */ import java.util.Optional;
/*      */ import java.util.stream.Collectors;
/*      */ import java.util.stream.StreamSupport;
/*      */ import org.immutables.value.Generated;
/*      */ import reactor.util.annotation.Nullable;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ @Generated(from = "MessageEditSpecGenerator", generator = "Immutables")
/*      */ public final class MessageEditSpec
/*      */   implements MessageEditSpecGenerator
/*      */ {
/*      */   private final String content_value;
/*      */   private final boolean content_absent;
/*      */   private final List<EmbedCreateSpec> embeds_value;
/*      */   private final boolean embeds_absent;
/*      */   private final List<MessageCreateFields.File> files;
/*      */   private final List<MessageCreateFields.FileSpoiler> fileSpoilers;
/*      */   private final AllowedMentions allowedMentions_value;
/*      */   private final boolean allowedMentions_absent;
/*      */   private final List<Message.Flag> flags_value;
/*      */   private final boolean flags_absent;
/*      */   private final List<LayoutComponent> components_value;
/*      */   private final boolean components_absent;
/*      */   private final List<Attachment> attachments_value;
/*      */   private final boolean attachments_absent;
/*      */   private static final byte STAGE_INITIALIZING = -1;
/*      */   private static final byte STAGE_UNINITIALIZED = 0;
/*      */   private static final byte STAGE_INITIALIZED = 1;
/*      */   
/*      */   private MessageEditSpec() {
/*   48 */     Possible<Optional<String>> content$impl = Possible.absent();
/*   49 */     Possible<Optional<List<EmbedCreateSpec>>> embeds$impl = Possible.absent();
/*   50 */     Possible<Optional<AllowedMentions>> allowedMentions$impl = Possible.absent();
/*   51 */     Possible<Optional<List<Message.Flag>>> flags$impl = Possible.absent();
/*   52 */     Possible<Optional<List<LayoutComponent>>> components$impl = Possible.absent();
/*   53 */     Possible<Optional<List<Attachment>>> attachments$impl = Possible.absent();
/*   54 */     this.content_value = Possible.flatOpt(content$impl).orElse(null);
/*   55 */     this.content_absent = content$impl.isAbsent();
/*   56 */     this.embeds_value = Possible.flatOpt(embeds$impl).orElse(null);
/*   57 */     this.embeds_absent = embeds$impl.isAbsent();
/*   58 */     this.allowedMentions_value = Possible.flatOpt(allowedMentions$impl).orElse(null);
/*   59 */     this.allowedMentions_absent = allowedMentions$impl.isAbsent();
/*   60 */     this.flags_value = Possible.flatOpt(flags$impl).orElse(null);
/*   61 */     this.flags_absent = flags$impl.isAbsent();
/*   62 */     this.components_value = Possible.flatOpt(components$impl).orElse(null);
/*   63 */     this.components_absent = components$impl.isAbsent();
/*   64 */     this.attachments_value = Possible.flatOpt(attachments$impl).orElse(null);
/*   65 */     this.attachments_absent = attachments$impl.isAbsent();
/*   66 */     this.files = this.initShim.files();
/*   67 */     this.fileSpoilers = this.initShim.fileSpoilers();
/*   68 */     this.initShim = null;
/*      */   }
/*      */   
/*      */   private MessageEditSpec(Builder builder) {
/*   72 */     Possible<Optional<String>> content$impl = builder.content_build();
/*   73 */     Possible<Optional<List<EmbedCreateSpec>>> embeds$impl = builder.embeds_build();
/*   74 */     Possible<Optional<AllowedMentions>> allowedMentions$impl = builder.allowedMentions_build();
/*   75 */     Possible<Optional<List<Message.Flag>>> flags$impl = builder.flags_build();
/*   76 */     Possible<Optional<List<LayoutComponent>>> components$impl = builder.components_build();
/*   77 */     Possible<Optional<List<Attachment>>> attachments$impl = builder.attachments_build();
/*   78 */     if (builder.filesIsSet()) {
/*   79 */       this.initShim.files(createUnmodifiableList(true, builder.files));
/*      */     }
/*   81 */     if (builder.fileSpoilersIsSet()) {
/*   82 */       this.initShim.fileSpoilers(createUnmodifiableList(true, builder.fileSpoilers));
/*      */     }
/*   84 */     this.content_value = Possible.flatOpt(content$impl).orElse(null);
/*   85 */     this.content_absent = content$impl.isAbsent();
/*   86 */     this.embeds_value = Possible.flatOpt(embeds$impl).orElse(null);
/*   87 */     this.embeds_absent = embeds$impl.isAbsent();
/*   88 */     this.allowedMentions_value = Possible.flatOpt(allowedMentions$impl).orElse(null);
/*   89 */     this.allowedMentions_absent = allowedMentions$impl.isAbsent();
/*   90 */     this.flags_value = Possible.flatOpt(flags$impl).orElse(null);
/*   91 */     this.flags_absent = flags$impl.isAbsent();
/*   92 */     this.components_value = Possible.flatOpt(components$impl).orElse(null);
/*   93 */     this.components_absent = components$impl.isAbsent();
/*   94 */     this.attachments_value = Possible.flatOpt(attachments$impl).orElse(null);
/*   95 */     this.attachments_absent = attachments$impl.isAbsent();
/*   96 */     this.files = this.initShim.files();
/*   97 */     this.fileSpoilers = this.initShim.fileSpoilers();
/*   98 */     this.initShim = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private MessageEditSpec(Possible<Optional<String>> content, Possible<Optional<List<EmbedCreateSpec>>> embeds, List<MessageCreateFields.File> files, List<MessageCreateFields.FileSpoiler> fileSpoilers, Possible<Optional<AllowedMentions>> allowedMentions, Possible<Optional<List<Message.Flag>>> flags, Possible<Optional<List<LayoutComponent>>> components, Possible<Optional<List<Attachment>>> attachments) {
/*  110 */     Possible<Optional<String>> content$impl = content;
/*  111 */     Possible<Optional<List<EmbedCreateSpec>>> embeds$impl = embeds;
/*  112 */     this.initShim.files(files);
/*  113 */     this.initShim.fileSpoilers(fileSpoilers);
/*  114 */     Possible<Optional<AllowedMentions>> allowedMentions$impl = allowedMentions;
/*  115 */     Possible<Optional<List<Message.Flag>>> flags$impl = flags;
/*  116 */     Possible<Optional<List<LayoutComponent>>> components$impl = components;
/*  117 */     Possible<Optional<List<Attachment>>> attachments$impl = attachments;
/*  118 */     this.content_value = Possible.flatOpt(content$impl).orElse(null);
/*  119 */     this.content_absent = content$impl.isAbsent();
/*  120 */     this.embeds_value = Possible.flatOpt(embeds$impl).orElse(null);
/*  121 */     this.embeds_absent = embeds$impl.isAbsent();
/*  122 */     this.allowedMentions_value = Possible.flatOpt(allowedMentions$impl).orElse(null);
/*  123 */     this.allowedMentions_absent = allowedMentions$impl.isAbsent();
/*  124 */     this.flags_value = Possible.flatOpt(flags$impl).orElse(null);
/*  125 */     this.flags_absent = flags$impl.isAbsent();
/*  126 */     this.components_value = Possible.flatOpt(components$impl).orElse(null);
/*  127 */     this.components_absent = components$impl.isAbsent();
/*  128 */     this.attachments_value = Possible.flatOpt(attachments$impl).orElse(null);
/*  129 */     this.attachments_absent = attachments$impl.isAbsent();
/*  130 */     this.files = this.initShim.files();
/*  131 */     this.fileSpoilers = this.initShim.fileSpoilers();
/*  132 */     this.initShim = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  138 */   private volatile transient InitShim initShim = new InitShim();
/*      */   
/*      */   @Generated(from = "MessageEditSpecGenerator", generator = "Immutables")
/*      */   private final class InitShim
/*      */   {
/*  143 */     private byte filesBuildStage = 0;
/*      */     private List<MessageCreateFields.File> files;
/*      */     
/*      */     List<MessageCreateFields.File> files() {
/*  147 */       if (this.filesBuildStage == -1) throw new IllegalStateException(formatInitCycleMessage()); 
/*  148 */       if (this.filesBuildStage == 0) {
/*  149 */         this.filesBuildStage = -1;
/*  150 */         this.files = (List)MessageEditSpec.createUnmodifiableList(false, MessageEditSpec.createSafeList((Iterable)MessageEditSpec.this.filesInitialize(), true, false));
/*  151 */         this.filesBuildStage = 1;
/*      */       } 
/*  153 */       return this.files;
/*      */     }
/*      */     
/*      */     void files(List<MessageCreateFields.File> files) {
/*  157 */       this.files = files;
/*  158 */       this.filesBuildStage = 1;
/*      */     }
/*      */     
/*  161 */     private byte fileSpoilersBuildStage = 0;
/*      */     private List<MessageCreateFields.FileSpoiler> fileSpoilers;
/*      */     
/*      */     List<MessageCreateFields.FileSpoiler> fileSpoilers() {
/*  165 */       if (this.fileSpoilersBuildStage == -1) throw new IllegalStateException(formatInitCycleMessage()); 
/*  166 */       if (this.fileSpoilersBuildStage == 0) {
/*  167 */         this.fileSpoilersBuildStage = -1;
/*  168 */         this.fileSpoilers = (List)MessageEditSpec.createUnmodifiableList(false, MessageEditSpec.createSafeList((Iterable)MessageEditSpec.this.fileSpoilersInitialize(), true, false));
/*  169 */         this.fileSpoilersBuildStage = 1;
/*      */       } 
/*  171 */       return this.fileSpoilers;
/*      */     }
/*      */     
/*      */     void fileSpoilers(List<MessageCreateFields.FileSpoiler> fileSpoilers) {
/*  175 */       this.fileSpoilers = fileSpoilers;
/*  176 */       this.fileSpoilersBuildStage = 1;
/*      */     }
/*      */     private InitShim() {}
/*      */     private String formatInitCycleMessage() {
/*  180 */       List<String> attributes = new ArrayList<>();
/*  181 */       if (this.filesBuildStage == -1) attributes.add("files"); 
/*  182 */       if (this.fileSpoilersBuildStage == -1) attributes.add("fileSpoilers"); 
/*  183 */       return "Cannot build MessageEditSpec, attribute initializers form cycle " + attributes;
/*      */     }
/*      */   }
/*      */   
/*      */   private List<MessageCreateFields.File> filesInitialize() {
/*  188 */     return super.files();
/*      */   }
/*      */   
/*      */   private List<MessageCreateFields.FileSpoiler> fileSpoilersInitialize() {
/*  192 */     return super.fileSpoilers();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Possible<Optional<String>> content() {
/*  200 */     return this.content_absent ? Possible.absent() : 
/*  201 */       Possible.of(Optional.ofNullable(this.content_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Possible<Optional<List<EmbedCreateSpec>>> embeds() {
/*  209 */     return this.embeds_absent ? Possible.absent() : 
/*  210 */       Possible.of(Optional.ofNullable(this.embeds_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<MessageCreateFields.File> files() {
/*  218 */     InitShim shim = this.initShim;
/*  219 */     return (shim != null) ? 
/*  220 */       shim.files() : 
/*  221 */       this.files;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<MessageCreateFields.FileSpoiler> fileSpoilers() {
/*  229 */     InitShim shim = this.initShim;
/*  230 */     return (shim != null) ? 
/*  231 */       shim.fileSpoilers() : 
/*  232 */       this.fileSpoilers;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Possible<Optional<AllowedMentions>> allowedMentions() {
/*  240 */     return this.allowedMentions_absent ? Possible.absent() : 
/*  241 */       Possible.of(Optional.ofNullable(this.allowedMentions_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Possible<Optional<List<Message.Flag>>> flags() {
/*  249 */     return this.flags_absent ? Possible.absent() : 
/*  250 */       Possible.of(Optional.ofNullable(this.flags_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Possible<Optional<List<LayoutComponent>>> components() {
/*  258 */     return this.components_absent ? Possible.absent() : 
/*  259 */       Possible.of(Optional.ofNullable(this.components_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Possible<Optional<List<Attachment>>> attachments() {
/*  267 */     return this.attachments_absent ? Possible.absent() : 
/*  268 */       Possible.of(Optional.ofNullable(this.attachments_value));
/*      */   }
/*      */   
/*      */   public MessageEditSpec withContent(Possible<Optional<String>> value) {
/*  272 */     Possible<Optional<String>> newValue = Objects.<Possible<Optional<String>>>requireNonNull(value);
/*  273 */     return validate(new MessageEditSpec(newValue, 
/*      */           
/*  275 */           embeds(), this.files, this.fileSpoilers, 
/*      */ 
/*      */           
/*  278 */           allowedMentions(), 
/*  279 */           flags(), 
/*  280 */           components(), 
/*  281 */           attachments()));
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public MessageEditSpec withContent(@Nullable String value) {
/*  286 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/*  287 */     return validate(new MessageEditSpec(newValue, 
/*      */           
/*  289 */           embeds(), this.files, this.fileSpoilers, 
/*      */ 
/*      */           
/*  292 */           allowedMentions(), 
/*  293 */           flags(), 
/*  294 */           components(), 
/*  295 */           attachments()));
/*      */   }
/*      */   
/*      */   public MessageEditSpec withContentOrNull(@Nullable String value) {
/*  299 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/*  300 */     return validate(new MessageEditSpec(newValue, 
/*      */           
/*  302 */           embeds(), this.files, this.fileSpoilers, 
/*      */ 
/*      */           
/*  305 */           allowedMentions(), 
/*  306 */           flags(), 
/*  307 */           components(), 
/*  308 */           attachments()));
/*      */   }
/*      */   
/*      */   public MessageEditSpec withEmbeds(Possible<Optional<List<EmbedCreateSpec>>> possible) {
/*  312 */     Possible<Optional<List<EmbedCreateSpec>>> newValue = Objects.<Possible<Optional<List<EmbedCreateSpec>>>>requireNonNull(possible);
/*  313 */     return validate(new MessageEditSpec(
/*  314 */           content(), newValue, this.files, this.fileSpoilers, 
/*      */ 
/*      */ 
/*      */           
/*  318 */           allowedMentions(), 
/*  319 */           flags(), 
/*  320 */           components(), 
/*  321 */           attachments()));
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public MessageEditSpec withEmbeds(@Nullable Iterable<EmbedCreateSpec> elements) {
/*  326 */     Possible<Optional<List<EmbedCreateSpec>>> newValue = Possible.of(Optional.<Iterable<EmbedCreateSpec>>ofNullable(elements)
/*  327 */         .map(els -> (List)StreamSupport.stream(els.spliterator(), false).collect(Collectors.toList())));
/*  328 */     return validate(new MessageEditSpec(
/*  329 */           content(), newValue, this.files, this.fileSpoilers, 
/*      */ 
/*      */ 
/*      */           
/*  333 */           allowedMentions(), 
/*  334 */           flags(), 
/*  335 */           components(), 
/*  336 */           attachments()));
/*      */   }
/*      */   
/*      */   public MessageEditSpec withEmbedsOrNull(@Nullable Iterable<EmbedCreateSpec> elements) {
/*  340 */     Possible<Optional<List<EmbedCreateSpec>>> newValue = Possible.of(Optional.<Iterable<EmbedCreateSpec>>ofNullable(elements)
/*  341 */         .map(els -> (List)StreamSupport.stream(els.spliterator(), false).collect(Collectors.toList())));
/*  342 */     return validate(new MessageEditSpec(
/*  343 */           content(), newValue, this.files, this.fileSpoilers, 
/*      */ 
/*      */ 
/*      */           
/*  347 */           allowedMentions(), 
/*  348 */           flags(), 
/*  349 */           components(), 
/*  350 */           attachments()));
/*      */   }
/*      */   
/*      */   @SafeVarargs
/*      */   public final MessageEditSpec withEmbeds(EmbedCreateSpec... elements) {
/*  355 */     Possible<Optional<List<EmbedCreateSpec>>> newValue = Possible.of(Optional.of(Arrays.asList(elements)));
/*  356 */     return validate(new MessageEditSpec(
/*  357 */           content(), newValue, this.files, this.fileSpoilers, 
/*      */ 
/*      */ 
/*      */           
/*  361 */           allowedMentions(), 
/*  362 */           flags(), 
/*  363 */           components(), 
/*  364 */           attachments()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final MessageEditSpec withFiles(MessageCreateFields.File... elements) {
/*  373 */     List<MessageCreateFields.File> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/*  374 */     return validate(new MessageEditSpec(
/*  375 */           content(), 
/*  376 */           embeds(), newValue, this.fileSpoilers, 
/*      */ 
/*      */           
/*  379 */           allowedMentions(), 
/*  380 */           flags(), 
/*  381 */           components(), 
/*  382 */           attachments()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final MessageEditSpec withFiles(Iterable<? extends MessageCreateFields.File> elements) {
/*  392 */     if (this.files == elements) return this; 
/*  393 */     List<MessageCreateFields.File> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/*  394 */     return validate(new MessageEditSpec(
/*  395 */           content(), 
/*  396 */           embeds(), newValue, this.fileSpoilers, 
/*      */ 
/*      */           
/*  399 */           allowedMentions(), 
/*  400 */           flags(), 
/*  401 */           components(), 
/*  402 */           attachments()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final MessageEditSpec withFileSpoilers(MessageCreateFields.FileSpoiler... elements) {
/*  411 */     List<MessageCreateFields.FileSpoiler> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/*  412 */     return validate(new MessageEditSpec(
/*  413 */           content(), 
/*  414 */           embeds(), this.files, newValue, 
/*      */ 
/*      */           
/*  417 */           allowedMentions(), 
/*  418 */           flags(), 
/*  419 */           components(), 
/*  420 */           attachments()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final MessageEditSpec withFileSpoilers(Iterable<? extends MessageCreateFields.FileSpoiler> elements) {
/*  430 */     if (this.fileSpoilers == elements) return this; 
/*  431 */     List<MessageCreateFields.FileSpoiler> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/*  432 */     return validate(new MessageEditSpec(
/*  433 */           content(), 
/*  434 */           embeds(), this.files, newValue, 
/*      */ 
/*      */           
/*  437 */           allowedMentions(), 
/*  438 */           flags(), 
/*  439 */           components(), 
/*  440 */           attachments()));
/*      */   }
/*      */   
/*      */   public MessageEditSpec withAllowedMentions(Possible<Optional<AllowedMentions>> value) {
/*  444 */     Possible<Optional<AllowedMentions>> newValue = Objects.<Possible<Optional<AllowedMentions>>>requireNonNull(value);
/*  445 */     return validate(new MessageEditSpec(
/*  446 */           content(), 
/*  447 */           embeds(), this.files, this.fileSpoilers, newValue, 
/*      */ 
/*      */ 
/*      */           
/*  451 */           flags(), 
/*  452 */           components(), 
/*  453 */           attachments()));
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public MessageEditSpec withAllowedMentions(@Nullable AllowedMentions value) {
/*  458 */     Possible<Optional<AllowedMentions>> newValue = Possible.of(Optional.ofNullable(value));
/*  459 */     return validate(new MessageEditSpec(
/*  460 */           content(), 
/*  461 */           embeds(), this.files, this.fileSpoilers, newValue, 
/*      */ 
/*      */ 
/*      */           
/*  465 */           flags(), 
/*  466 */           components(), 
/*  467 */           attachments()));
/*      */   }
/*      */   
/*      */   public MessageEditSpec withAllowedMentionsOrNull(@Nullable AllowedMentions value) {
/*  471 */     Possible<Optional<AllowedMentions>> newValue = Possible.of(Optional.ofNullable(value));
/*  472 */     return validate(new MessageEditSpec(
/*  473 */           content(), 
/*  474 */           embeds(), this.files, this.fileSpoilers, newValue, 
/*      */ 
/*      */ 
/*      */           
/*  478 */           flags(), 
/*  479 */           components(), 
/*  480 */           attachments()));
/*      */   }
/*      */   
/*      */   public MessageEditSpec withFlags(Possible<Optional<List<Message.Flag>>> possible) {
/*  484 */     Possible<Optional<List<Message.Flag>>> newValue = Objects.<Possible<Optional<List<Message.Flag>>>>requireNonNull(possible);
/*  485 */     return validate(new MessageEditSpec(
/*  486 */           content(), 
/*  487 */           embeds(), this.files, this.fileSpoilers, 
/*      */ 
/*      */           
/*  490 */           allowedMentions(), newValue, 
/*      */           
/*  492 */           components(), 
/*  493 */           attachments()));
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public MessageEditSpec withFlags(@Nullable Iterable<Message.Flag> elements) {
/*  498 */     Possible<Optional<List<Message.Flag>>> newValue = Possible.of(Optional.<Iterable<Message.Flag>>ofNullable(elements)
/*  499 */         .map(els -> (List)StreamSupport.stream(els.spliterator(), false).collect(Collectors.toList())));
/*  500 */     return validate(new MessageEditSpec(
/*  501 */           content(), 
/*  502 */           embeds(), this.files, this.fileSpoilers, 
/*      */ 
/*      */           
/*  505 */           allowedMentions(), newValue, 
/*      */           
/*  507 */           components(), 
/*  508 */           attachments()));
/*      */   }
/*      */   
/*      */   public MessageEditSpec withFlagsOrNull(@Nullable Iterable<Message.Flag> elements) {
/*  512 */     Possible<Optional<List<Message.Flag>>> newValue = Possible.of(Optional.<Iterable<Message.Flag>>ofNullable(elements)
/*  513 */         .map(els -> (List)StreamSupport.stream(els.spliterator(), false).collect(Collectors.toList())));
/*  514 */     return validate(new MessageEditSpec(
/*  515 */           content(), 
/*  516 */           embeds(), this.files, this.fileSpoilers, 
/*      */ 
/*      */           
/*  519 */           allowedMentions(), newValue, 
/*      */           
/*  521 */           components(), 
/*  522 */           attachments()));
/*      */   }
/*      */   
/*      */   @SafeVarargs
/*      */   public final MessageEditSpec withFlags(Message.Flag... elements) {
/*  527 */     Possible<Optional<List<Message.Flag>>> newValue = Possible.of(Optional.of(Arrays.asList(elements)));
/*  528 */     return validate(new MessageEditSpec(
/*  529 */           content(), 
/*  530 */           embeds(), this.files, this.fileSpoilers, 
/*      */ 
/*      */           
/*  533 */           allowedMentions(), newValue, 
/*      */           
/*  535 */           components(), 
/*  536 */           attachments()));
/*      */   }
/*      */   
/*      */   public MessageEditSpec withComponents(Possible<Optional<List<LayoutComponent>>> possible) {
/*  540 */     Possible<Optional<List<LayoutComponent>>> newValue = Objects.<Possible<Optional<List<LayoutComponent>>>>requireNonNull(possible);
/*  541 */     return validate(new MessageEditSpec(
/*  542 */           content(), 
/*  543 */           embeds(), this.files, this.fileSpoilers, 
/*      */ 
/*      */           
/*  546 */           allowedMentions(), 
/*  547 */           flags(), newValue, 
/*      */           
/*  549 */           attachments()));
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public MessageEditSpec withComponents(@Nullable Iterable<LayoutComponent> elements) {
/*  554 */     Possible<Optional<List<LayoutComponent>>> newValue = Possible.of(Optional.<Iterable<LayoutComponent>>ofNullable(elements)
/*  555 */         .map(els -> (List)StreamSupport.stream(els.spliterator(), false).collect(Collectors.toList())));
/*  556 */     return validate(new MessageEditSpec(
/*  557 */           content(), 
/*  558 */           embeds(), this.files, this.fileSpoilers, 
/*      */ 
/*      */           
/*  561 */           allowedMentions(), 
/*  562 */           flags(), newValue, 
/*      */           
/*  564 */           attachments()));
/*      */   }
/*      */   
/*      */   public MessageEditSpec withComponentsOrNull(@Nullable Iterable<LayoutComponent> elements) {
/*  568 */     Possible<Optional<List<LayoutComponent>>> newValue = Possible.of(Optional.<Iterable<LayoutComponent>>ofNullable(elements)
/*  569 */         .map(els -> (List)StreamSupport.stream(els.spliterator(), false).collect(Collectors.toList())));
/*  570 */     return validate(new MessageEditSpec(
/*  571 */           content(), 
/*  572 */           embeds(), this.files, this.fileSpoilers, 
/*      */ 
/*      */           
/*  575 */           allowedMentions(), 
/*  576 */           flags(), newValue, 
/*      */           
/*  578 */           attachments()));
/*      */   }
/*      */   
/*      */   @SafeVarargs
/*      */   public final MessageEditSpec withComponents(LayoutComponent... elements) {
/*  583 */     Possible<Optional<List<LayoutComponent>>> newValue = Possible.of(Optional.of(Arrays.asList(elements)));
/*  584 */     return validate(new MessageEditSpec(
/*  585 */           content(), 
/*  586 */           embeds(), this.files, this.fileSpoilers, 
/*      */ 
/*      */           
/*  589 */           allowedMentions(), 
/*  590 */           flags(), newValue, 
/*      */           
/*  592 */           attachments()));
/*      */   }
/*      */   
/*      */   public MessageEditSpec withAttachments(Possible<Optional<List<Attachment>>> possible) {
/*  596 */     Possible<Optional<List<Attachment>>> newValue = Objects.<Possible<Optional<List<Attachment>>>>requireNonNull(possible);
/*  597 */     return validate(new MessageEditSpec(
/*  598 */           content(), 
/*  599 */           embeds(), this.files, this.fileSpoilers, 
/*      */ 
/*      */           
/*  602 */           allowedMentions(), 
/*  603 */           flags(), 
/*  604 */           components(), newValue));
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public MessageEditSpec withAttachments(@Nullable Iterable<Attachment> elements) {
/*  610 */     Possible<Optional<List<Attachment>>> newValue = Possible.of(Optional.<Iterable<Attachment>>ofNullable(elements)
/*  611 */         .map(els -> (List)StreamSupport.stream(els.spliterator(), false).collect(Collectors.toList())));
/*  612 */     return validate(new MessageEditSpec(
/*  613 */           content(), 
/*  614 */           embeds(), this.files, this.fileSpoilers, 
/*      */ 
/*      */           
/*  617 */           allowedMentions(), 
/*  618 */           flags(), 
/*  619 */           components(), newValue));
/*      */   }
/*      */ 
/*      */   
/*      */   public MessageEditSpec withAttachmentsOrNull(@Nullable Iterable<Attachment> elements) {
/*  624 */     Possible<Optional<List<Attachment>>> newValue = Possible.of(Optional.<Iterable<Attachment>>ofNullable(elements)
/*  625 */         .map(els -> (List)StreamSupport.stream(els.spliterator(), false).collect(Collectors.toList())));
/*  626 */     return validate(new MessageEditSpec(
/*  627 */           content(), 
/*  628 */           embeds(), this.files, this.fileSpoilers, 
/*      */ 
/*      */           
/*  631 */           allowedMentions(), 
/*  632 */           flags(), 
/*  633 */           components(), newValue));
/*      */   }
/*      */ 
/*      */   
/*      */   @SafeVarargs
/*      */   public final MessageEditSpec withAttachments(Attachment... elements) {
/*  639 */     Possible<Optional<List<Attachment>>> newValue = Possible.of(Optional.of(Arrays.asList(elements)));
/*  640 */     return validate(new MessageEditSpec(
/*  641 */           content(), 
/*  642 */           embeds(), this.files, this.fileSpoilers, 
/*      */ 
/*      */           
/*  645 */           allowedMentions(), 
/*  646 */           flags(), 
/*  647 */           components(), newValue));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean equals(Object another) {
/*  657 */     if (this == another) return true; 
/*  658 */     return (another instanceof MessageEditSpec && 
/*  659 */       equalTo(0, (MessageEditSpec)another));
/*      */   }
/*      */   
/*      */   private boolean equalTo(int synthetic, MessageEditSpec another) {
/*  663 */     return (content().equals(another.content()) && 
/*  664 */       Objects.equals(this.embeds_value, another.embeds_value) && this.files
/*  665 */       .equals(another.files) && this.fileSpoilers
/*  666 */       .equals(another.fileSpoilers) && 
/*  667 */       allowedMentions().equals(another.allowedMentions()) && 
/*  668 */       Objects.equals(this.flags_value, another.flags_value) && 
/*  669 */       Objects.equals(this.components_value, another.components_value) && 
/*  670 */       Objects.equals(this.attachments_value, another.attachments_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int hashCode() {
/*  679 */     int h = 5381;
/*  680 */     h += (h << 5) + content().hashCode();
/*  681 */     h += (h << 5) + Objects.hashCode(this.embeds_value);
/*  682 */     h += (h << 5) + this.files.hashCode();
/*  683 */     h += (h << 5) + this.fileSpoilers.hashCode();
/*  684 */     h += (h << 5) + allowedMentions().hashCode();
/*  685 */     h += (h << 5) + Objects.hashCode(this.flags_value);
/*  686 */     h += (h << 5) + Objects.hashCode(this.components_value);
/*  687 */     h += (h << 5) + Objects.hashCode(this.attachments_value);
/*  688 */     return h;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/*  697 */     return "MessageEditSpec{content=" + 
/*  698 */       content().toString() + ", embeds=" + 
/*  699 */       Objects.toString(this.embeds_value) + ", files=" + this.files + ", fileSpoilers=" + this.fileSpoilers + ", allowedMentions=" + 
/*      */ 
/*      */       
/*  702 */       allowedMentions().toString() + ", flags=" + 
/*  703 */       Objects.toString(this.flags_value) + ", components=" + 
/*  704 */       Objects.toString(this.components_value) + ", attachments=" + 
/*  705 */       Objects.toString(this.attachments_value) + "}";
/*      */   }
/*      */ 
/*      */   
/*  709 */   private static final MessageEditSpec INSTANCE = validate(new MessageEditSpec());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static MessageEditSpec create() {
/*  716 */     return INSTANCE;
/*      */   }
/*      */   
/*      */   private static MessageEditSpec validate(MessageEditSpec instance) {
/*  720 */     return (INSTANCE != null && INSTANCE.equalTo(0, instance)) ? INSTANCE : instance;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static MessageEditSpec copyOf(MessageEditSpecGenerator instance) {
/*  731 */     if (instance instanceof MessageEditSpec) {
/*  732 */       return (MessageEditSpec)instance;
/*      */     }
/*  734 */     return builder()
/*  735 */       .from(instance)
/*  736 */       .build();
/*      */   }
/*      */   
/*      */   public boolean isContentPresent() {
/*  740 */     return !this.content_absent;
/*      */   }
/*      */   
/*      */   public String contentOrElse(String defaultValue) {
/*  744 */     return !this.content_absent ? this.content_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isEmbedsPresent() {
/*  748 */     return !this.embeds_absent;
/*      */   }
/*      */   
/*      */   public List<EmbedCreateSpec> embedsOrElse(List<EmbedCreateSpec> defaultValue) {
/*  752 */     return !this.embeds_absent ? this.embeds_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isAllowedMentionsPresent() {
/*  756 */     return !this.allowedMentions_absent;
/*      */   }
/*      */   
/*      */   public AllowedMentions allowedMentionsOrElse(AllowedMentions defaultValue) {
/*  760 */     return !this.allowedMentions_absent ? this.allowedMentions_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isFlagsPresent() {
/*  764 */     return !this.flags_absent;
/*      */   }
/*      */   
/*      */   public List<Message.Flag> flagsOrElse(List<Message.Flag> defaultValue) {
/*  768 */     return !this.flags_absent ? this.flags_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isComponentsPresent() {
/*  772 */     return !this.components_absent;
/*      */   }
/*      */   
/*      */   public List<LayoutComponent> componentsOrElse(List<LayoutComponent> defaultValue) {
/*  776 */     return !this.components_absent ? this.components_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isAttachmentsPresent() {
/*  780 */     return !this.attachments_absent;
/*      */   }
/*      */   
/*      */   public List<Attachment> attachmentsOrElse(List<Attachment> defaultValue) {
/*  784 */     return !this.attachments_absent ? this.attachments_value : defaultValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Builder builder() {
/*  804 */     return new Builder();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   @Generated(from = "MessageEditSpecGenerator", generator = "Immutables")
/*      */   public static final class Builder
/*      */   {
/*      */     private static final long OPT_BIT_FILES = 1L;
/*      */ 
/*      */     
/*      */     private static final long OPT_BIT_FILE_SPOILERS = 2L;
/*      */ 
/*      */     
/*      */     private long optBits;
/*      */     
/*  820 */     private Possible<Optional<String>> content_possible = Possible.absent();
/*  821 */     private List<EmbedCreateSpec> embeds_list = null;
/*      */     private boolean embeds_explicitNull;
/*  823 */     private Possible<Optional<AllowedMentions>> allowedMentions_possible = Possible.absent();
/*  824 */     private List<Message.Flag> flags_list = null;
/*      */     private boolean flags_explicitNull;
/*  826 */     private List<LayoutComponent> components_list = null;
/*      */     private boolean components_explicitNull;
/*  828 */     private List<Attachment> attachments_list = null;
/*      */     private boolean attachments_explicitNull;
/*  830 */     private List<MessageCreateFields.File> files = new ArrayList<>();
/*  831 */     private List<MessageCreateFields.FileSpoiler> fileSpoilers = new ArrayList<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder from(MessageEditSpec instance) {
/*  845 */       return from(instance);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     final Builder from(MessageEditSpecGenerator instance) {
/*  855 */       Objects.requireNonNull(instance, "instance");
/*  856 */       content(instance.content());
/*  857 */       embeds(instance.embeds());
/*  858 */       addAllFiles(instance.files());
/*  859 */       addAllFileSpoilers(instance.fileSpoilers());
/*  860 */       allowedMentions(instance.allowedMentions());
/*  861 */       flags(instance.flags());
/*  862 */       components(instance.components());
/*  863 */       attachments(instance.attachments());
/*  864 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder content(Possible<Optional<String>> value) {
/*  869 */       this.content_possible = value;
/*  870 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     @CanIgnoreReturnValue
/*      */     public Builder content(@Nullable String value) {
/*  876 */       this.content_possible = Possible.of(Optional.ofNullable(value));
/*  877 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder contentOrNull(@Nullable String value) {
/*  882 */       this.content_possible = Possible.of(Optional.ofNullable(value));
/*  883 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder addEmbed(EmbedCreateSpec element) {
/*  888 */       embeds_getOrCreate().add(element);
/*  889 */       this.embeds_explicitNull = false;
/*  890 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder addAllEmbeds(List<EmbedCreateSpec> elements) {
/*  895 */       embeds_getOrCreate().addAll(elements);
/*  896 */       this.embeds_explicitNull = false;
/*  897 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder embeds(Possible<Optional<List<EmbedCreateSpec>>> elements) {
/*  902 */       this.embeds_list = null;
/*  903 */       this.embeds_explicitNull = false;
/*  904 */       elements.toOptional().ifPresent(e -> {
/*      */             if (e.isPresent()) {
/*      */               embeds_getOrCreate().addAll(e.get());
/*      */             } else {
/*      */               this.embeds_explicitNull = true;
/*      */             } 
/*      */           });
/*  911 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder embeds(List<EmbedCreateSpec> elements) {
/*  916 */       this.embeds_list = new ArrayList<>(elements);
/*  917 */       this.embeds_explicitNull = false;
/*  918 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     @CanIgnoreReturnValue
/*      */     public Builder embeds(@Nullable Iterable<EmbedCreateSpec> elements) {
/*  924 */       if (elements == null) {
/*  925 */         this.embeds_list = null;
/*  926 */         this.embeds_explicitNull = true;
/*      */       } else {
/*  928 */         this.embeds_list = (List<EmbedCreateSpec>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/*  929 */         this.embeds_explicitNull = false;
/*      */       } 
/*  931 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder embedsOrNull(@Nullable Iterable<EmbedCreateSpec> elements) {
/*  936 */       if (elements == null) {
/*  937 */         this.embeds_list = null;
/*  938 */         this.embeds_explicitNull = true;
/*      */       } else {
/*  940 */         this.embeds_list = (List<EmbedCreateSpec>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/*  941 */         this.embeds_explicitNull = false;
/*      */       } 
/*  943 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public final Builder addFile(MessageCreateFields.File element) {
/*  953 */       element = ImmutableMessageCreateFields.File.copyOf(element);
/*  954 */       this.files.add(Objects.<MessageCreateFields.File>requireNonNull(element, "files element"));
/*  955 */       this.optBits |= 0x1L;
/*  956 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addFile(String name, InputStream inputStream) {
/*  966 */       return addFile(ImmutableMessageCreateFields.File.of(name, inputStream));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public final Builder addFiles(MessageCreateFields.File... elements) {
/*  976 */       for (MessageCreateFields.File element : elements) {
/*  977 */         element = ImmutableMessageCreateFields.File.copyOf(element);
/*  978 */         this.files.add(Objects.<MessageCreateFields.File>requireNonNull(element, "files element"));
/*      */       } 
/*  980 */       this.optBits |= 0x1L;
/*  981 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public final Builder files(Iterable<? extends MessageCreateFields.File> elements) {
/*  992 */       this.files.clear();
/*  993 */       return addAllFiles(elements);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public final Builder addAllFiles(Iterable<? extends MessageCreateFields.File> elements) {
/* 1003 */       for (MessageCreateFields.File element : elements) {
/* 1004 */         element = ImmutableMessageCreateFields.File.copyOf(element);
/* 1005 */         this.files.add(Objects.<MessageCreateFields.File>requireNonNull(element, "files element"));
/*      */       } 
/* 1007 */       this.optBits |= 0x1L;
/* 1008 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public final Builder addFileSpoiler(MessageCreateFields.FileSpoiler element) {
/* 1018 */       element = ImmutableMessageCreateFields.FileSpoiler.copyOf(element);
/* 1019 */       this.fileSpoilers.add(Objects.<MessageCreateFields.FileSpoiler>requireNonNull(element, "fileSpoilers element"));
/* 1020 */       this.optBits |= 0x2L;
/* 1021 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addFileSpoiler(String name, InputStream inputStream) {
/* 1031 */       return addFileSpoiler(ImmutableMessageCreateFields.FileSpoiler.of(name, inputStream));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public final Builder addFileSpoilers(MessageCreateFields.FileSpoiler... elements) {
/* 1041 */       for (MessageCreateFields.FileSpoiler element : elements) {
/* 1042 */         element = ImmutableMessageCreateFields.FileSpoiler.copyOf(element);
/* 1043 */         this.fileSpoilers.add(Objects.<MessageCreateFields.FileSpoiler>requireNonNull(element, "fileSpoilers element"));
/*      */       } 
/* 1045 */       this.optBits |= 0x2L;
/* 1046 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public final Builder fileSpoilers(Iterable<? extends MessageCreateFields.FileSpoiler> elements) {
/* 1057 */       this.fileSpoilers.clear();
/* 1058 */       return addAllFileSpoilers(elements);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public final Builder addAllFileSpoilers(Iterable<? extends MessageCreateFields.FileSpoiler> elements) {
/* 1068 */       for (MessageCreateFields.FileSpoiler element : elements) {
/* 1069 */         element = ImmutableMessageCreateFields.FileSpoiler.copyOf(element);
/* 1070 */         this.fileSpoilers.add(Objects.<MessageCreateFields.FileSpoiler>requireNonNull(element, "fileSpoilers element"));
/*      */       } 
/* 1072 */       this.optBits |= 0x2L;
/* 1073 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder allowedMentions(Possible<Optional<AllowedMentions>> value) {
/* 1078 */       this.allowedMentions_possible = value;
/* 1079 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     @CanIgnoreReturnValue
/*      */     public Builder allowedMentions(@Nullable AllowedMentions value) {
/* 1085 */       this.allowedMentions_possible = Possible.of(Optional.ofNullable(value));
/* 1086 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder allowedMentionsOrNull(@Nullable AllowedMentions value) {
/* 1091 */       this.allowedMentions_possible = Possible.of(Optional.ofNullable(value));
/* 1092 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder addFlag(Message.Flag element) {
/* 1097 */       flags_getOrCreate().add(element);
/* 1098 */       this.flags_explicitNull = false;
/* 1099 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder addAllFlags(List<Message.Flag> elements) {
/* 1104 */       flags_getOrCreate().addAll(elements);
/* 1105 */       this.flags_explicitNull = false;
/* 1106 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder flags(Possible<Optional<List<Message.Flag>>> elements) {
/* 1111 */       this.flags_list = null;
/* 1112 */       this.flags_explicitNull = false;
/* 1113 */       elements.toOptional().ifPresent(e -> {
/*      */             if (e.isPresent()) {
/*      */               flags_getOrCreate().addAll(e.get());
/*      */             } else {
/*      */               this.flags_explicitNull = true;
/*      */             } 
/*      */           });
/* 1120 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder flags(List<Message.Flag> elements) {
/* 1125 */       this.flags_list = new ArrayList<>(elements);
/* 1126 */       this.flags_explicitNull = false;
/* 1127 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     @CanIgnoreReturnValue
/*      */     public Builder flags(@Nullable Iterable<Message.Flag> elements) {
/* 1133 */       if (elements == null) {
/* 1134 */         this.flags_list = null;
/* 1135 */         this.flags_explicitNull = true;
/*      */       } else {
/* 1137 */         this.flags_list = (List<Message.Flag>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/* 1138 */         this.flags_explicitNull = false;
/*      */       } 
/* 1140 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder flagsOrNull(@Nullable Iterable<Message.Flag> elements) {
/* 1145 */       if (elements == null) {
/* 1146 */         this.flags_list = null;
/* 1147 */         this.flags_explicitNull = true;
/*      */       } else {
/* 1149 */         this.flags_list = (List<Message.Flag>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/* 1150 */         this.flags_explicitNull = false;
/*      */       } 
/* 1152 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder addComponent(LayoutComponent element) {
/* 1157 */       components_getOrCreate().add(element);
/* 1158 */       this.components_explicitNull = false;
/* 1159 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder addAllComponents(List<LayoutComponent> elements) {
/* 1164 */       components_getOrCreate().addAll(elements);
/* 1165 */       this.components_explicitNull = false;
/* 1166 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder components(Possible<Optional<List<LayoutComponent>>> elements) {
/* 1171 */       this.components_list = null;
/* 1172 */       this.components_explicitNull = false;
/* 1173 */       elements.toOptional().ifPresent(e -> {
/*      */             if (e.isPresent()) {
/*      */               components_getOrCreate().addAll(e.get());
/*      */             } else {
/*      */               this.components_explicitNull = true;
/*      */             } 
/*      */           });
/* 1180 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder components(List<LayoutComponent> elements) {
/* 1185 */       this.components_list = new ArrayList<>(elements);
/* 1186 */       this.components_explicitNull = false;
/* 1187 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     @CanIgnoreReturnValue
/*      */     public Builder components(@Nullable Iterable<LayoutComponent> elements) {
/* 1193 */       if (elements == null) {
/* 1194 */         this.components_list = null;
/* 1195 */         this.components_explicitNull = true;
/*      */       } else {
/* 1197 */         this.components_list = (List<LayoutComponent>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/* 1198 */         this.components_explicitNull = false;
/*      */       } 
/* 1200 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder componentsOrNull(@Nullable Iterable<LayoutComponent> elements) {
/* 1205 */       if (elements == null) {
/* 1206 */         this.components_list = null;
/* 1207 */         this.components_explicitNull = true;
/*      */       } else {
/* 1209 */         this.components_list = (List<LayoutComponent>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/* 1210 */         this.components_explicitNull = false;
/*      */       } 
/* 1212 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder addAttachment(Attachment element) {
/* 1217 */       attachments_getOrCreate().add(element);
/* 1218 */       this.attachments_explicitNull = false;
/* 1219 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder addAllAttachments(List<Attachment> elements) {
/* 1224 */       attachments_getOrCreate().addAll(elements);
/* 1225 */       this.attachments_explicitNull = false;
/* 1226 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder attachments(Possible<Optional<List<Attachment>>> elements) {
/* 1231 */       this.attachments_list = null;
/* 1232 */       this.attachments_explicitNull = false;
/* 1233 */       elements.toOptional().ifPresent(e -> {
/*      */             if (e.isPresent()) {
/*      */               attachments_getOrCreate().addAll(e.get());
/*      */             } else {
/*      */               this.attachments_explicitNull = true;
/*      */             } 
/*      */           });
/* 1240 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder attachments(List<Attachment> elements) {
/* 1245 */       this.attachments_list = new ArrayList<>(elements);
/* 1246 */       this.attachments_explicitNull = false;
/* 1247 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     @CanIgnoreReturnValue
/*      */     public Builder attachments(@Nullable Iterable<Attachment> elements) {
/* 1253 */       if (elements == null) {
/* 1254 */         this.attachments_list = null;
/* 1255 */         this.attachments_explicitNull = true;
/*      */       } else {
/* 1257 */         this.attachments_list = (List<Attachment>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/* 1258 */         this.attachments_explicitNull = false;
/*      */       } 
/* 1260 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder attachmentsOrNull(@Nullable Iterable<Attachment> elements) {
/* 1265 */       if (elements == null) {
/* 1266 */         this.attachments_list = null;
/* 1267 */         this.attachments_explicitNull = true;
/*      */       } else {
/* 1269 */         this.attachments_list = (List<Attachment>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/* 1270 */         this.attachments_explicitNull = false;
/*      */       } 
/* 1272 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public MessageEditSpec build() {
/* 1281 */       return MessageEditSpec.validate(new MessageEditSpec(this));
/*      */     }
/*      */     
/*      */     private boolean filesIsSet() {
/* 1285 */       return ((this.optBits & 0x1L) != 0L);
/*      */     }
/*      */     
/*      */     private boolean fileSpoilersIsSet() {
/* 1289 */       return ((this.optBits & 0x2L) != 0L);
/*      */     }
/*      */     
/*      */     private Possible<Optional<String>> content_build() {
/* 1293 */       return this.content_possible;
/*      */     }
/*      */     
/*      */     private Possible<Optional<List<EmbedCreateSpec>>> embeds_build() {
/* 1297 */       return (this.embeds_list == null && !this.embeds_explicitNull) ? Possible.absent() : 
/* 1298 */         Possible.of(Optional.ofNullable(this.embeds_list));
/*      */     }
/*      */     
/*      */     private List<EmbedCreateSpec> embeds_getOrCreate() {
/* 1302 */       if (this.embeds_list == null) {
/* 1303 */         this.embeds_list = new ArrayList<>();
/*      */       }
/* 1305 */       return this.embeds_list;
/*      */     }
/*      */     
/*      */     private Possible<Optional<AllowedMentions>> allowedMentions_build() {
/* 1309 */       return this.allowedMentions_possible;
/*      */     }
/*      */     
/*      */     private Possible<Optional<List<Message.Flag>>> flags_build() {
/* 1313 */       return (this.flags_list == null && !this.flags_explicitNull) ? Possible.absent() : 
/* 1314 */         Possible.of(Optional.ofNullable(this.flags_list));
/*      */     }
/*      */     
/*      */     private List<Message.Flag> flags_getOrCreate() {
/* 1318 */       if (this.flags_list == null) {
/* 1319 */         this.flags_list = new ArrayList<>();
/*      */       }
/* 1321 */       return this.flags_list;
/*      */     }
/*      */     
/*      */     private Possible<Optional<List<LayoutComponent>>> components_build() {
/* 1325 */       return (this.components_list == null && !this.components_explicitNull) ? Possible.absent() : 
/* 1326 */         Possible.of(Optional.ofNullable(this.components_list));
/*      */     }
/*      */     
/*      */     private List<LayoutComponent> components_getOrCreate() {
/* 1330 */       if (this.components_list == null) {
/* 1331 */         this.components_list = new ArrayList<>();
/*      */       }
/* 1333 */       return this.components_list;
/*      */     }
/*      */     
/*      */     private Possible<Optional<List<Attachment>>> attachments_build() {
/* 1337 */       return (this.attachments_list == null && !this.attachments_explicitNull) ? Possible.absent() : 
/* 1338 */         Possible.of(Optional.ofNullable(this.attachments_list));
/*      */     }
/*      */     
/*      */     private List<Attachment> attachments_getOrCreate() {
/* 1342 */       if (this.attachments_list == null) {
/* 1343 */         this.attachments_list = new ArrayList<>();
/*      */       }
/* 1345 */       return this.attachments_list;
/*      */     }
/*      */     private Builder() {} }
/*      */   
/*      */   private static <T> List<T> createSafeList(Iterable<? extends T> iterable, boolean checkNulls, boolean skipNulls) {
/*      */     ArrayList<T> list;
/* 1351 */     if (iterable instanceof Collection) {
/* 1352 */       int size = ((Collection)iterable).size();
/* 1353 */       if (size == 0) return Collections.emptyList(); 
/* 1354 */       list = new ArrayList<>();
/*      */     } else {
/* 1356 */       list = new ArrayList<>();
/*      */     } 
/* 1358 */     for (T element : iterable) {
/* 1359 */       if (skipNulls && element == null)
/* 1360 */         continue;  if (checkNulls) Objects.requireNonNull(element, "element"); 
/* 1361 */       list.add(element);
/*      */     } 
/* 1363 */     return list;
/*      */   }
/*      */   
/*      */   private static <T> List<T> createUnmodifiableList(boolean clone, List<T> list) {
/* 1367 */     switch (list.size()) { case 0:
/* 1368 */         return Collections.emptyList();
/* 1369 */       case 1: return Collections.singletonList(list.get(0)); }
/*      */     
/* 1371 */     if (clone) {
/* 1372 */       return Collections.unmodifiableList(new ArrayList<>(list));
/*      */     }
/* 1374 */     if (list instanceof ArrayList) {
/* 1375 */       ((ArrayList)list).trimToSize();
/*      */     }
/* 1377 */     return Collections.unmodifiableList(list);
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\MessageEditSpec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */