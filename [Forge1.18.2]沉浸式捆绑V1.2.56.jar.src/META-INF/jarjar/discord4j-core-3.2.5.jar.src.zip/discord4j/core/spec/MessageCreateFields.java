/*    */ package discord4j.core.spec;
/*    */ 
/*    */ import java.io.InputStream;
/*    */ import org.immutables.value.Value.Enclosing;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ import reactor.util.function.Tuple2;
/*    */ import reactor.util.function.Tuples;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @InlineFieldStyle
/*    */ @Enclosing
/*    */ public final class MessageCreateFields
/*    */ {
/*    */   private MessageCreateFields() {
/* 32 */     throw new AssertionError();
/*    */   }
/*    */   
/*    */   @Immutable
/*    */   public static interface File
/*    */     extends Spec<Tuple2<String, InputStream>> {
/*    */     static File of(String name, InputStream inputStream) {
/* 39 */       return ImmutableMessageCreateFields.File.of(name, inputStream);
/*    */     }
/*    */ 
/*    */ 
/*    */     
/*    */     String name();
/*    */ 
/*    */     
/*    */     default Tuple2<String, InputStream> asRequest() {
/* 48 */       return Tuples.of(name(), inputStream());
/*    */     }
/*    */     
/*    */     InputStream inputStream();
/*    */   }
/*    */   
/*    */   @Immutable
/*    */   public static interface FileSpoiler extends File {
/*    */     static FileSpoiler of(String name, InputStream inputStream) {
/* 57 */       return ImmutableMessageCreateFields.FileSpoiler.of(name, inputStream);
/*    */     }
/*    */ 
/*    */     
/*    */     default Tuple2<String, InputStream> asRequest() {
/* 62 */       return Tuples.of("SPOILER_" + name(), inputStream());
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\MessageCreateFields.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */