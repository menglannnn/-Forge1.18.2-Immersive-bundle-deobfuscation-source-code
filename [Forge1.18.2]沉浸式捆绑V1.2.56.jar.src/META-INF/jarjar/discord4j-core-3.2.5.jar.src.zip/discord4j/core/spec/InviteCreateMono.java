/*     */ package discord4j.core.spec;
/*     */ 
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.object.ExtendedInvite;
/*     */ import discord4j.core.object.Invite;
/*     */ import discord4j.core.object.entity.channel.CategorizableChannel;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "InviteCreateMonoGenerator", generator = "Immutables")
/*     */ public final class InviteCreateMono
/*     */   extends InviteCreateMonoGenerator
/*     */ {
/*     */   @Nullable
/*     */   private final String reason;
/*     */   private final Integer maxAge_value;
/*     */   private final boolean maxAge_absent;
/*     */   private final Integer maxUses_value;
/*     */   private final boolean maxUses_absent;
/*     */   private final Boolean temporary_value;
/*     */   private final boolean temporary_absent;
/*     */   private final Boolean unique_value;
/*     */   private final boolean unique_absent;
/*     */   private final Invite.Type targetType_value;
/*     */   private final boolean targetType_absent;
/*     */   private final Snowflake targetUserId_value;
/*     */   private final boolean targetUserId_absent;
/*     */   private final Snowflake targetApplicationId_value;
/*     */   private final boolean targetApplicationId_absent;
/*     */   private final CategorizableChannel channel;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   private volatile transient InitShim initShim;
/*     */   
/*     */   private InviteCreateMono(CategorizableChannel channel) {
/* 107 */     this.initShim = new InitShim(); this.channel = Objects.<CategorizableChannel>requireNonNull(channel, "channel"); this.reason = null; Possible<Integer> maxAge$impl = Possible.absent(); Possible<Integer> maxUses$impl = Possible.absent(); Possible<Boolean> temporary$impl = Possible.absent(); Possible<Boolean> unique$impl = Possible.absent(); Possible<Invite.Type> targetType$impl = Possible.absent(); Possible<Snowflake> targetUserId$impl = Possible.absent(); Possible<Snowflake> targetApplicationId$impl = Possible.absent(); this.maxAge_value = maxAge$impl.toOptional().orElse(null); this.maxAge_absent = maxAge$impl.isAbsent(); this.maxUses_value = maxUses$impl.toOptional().orElse(null); this.maxUses_absent = maxUses$impl.isAbsent(); this.temporary_value = temporary$impl.toOptional().orElse(null); this.temporary_absent = temporary$impl.isAbsent(); this.unique_value = unique$impl.toOptional().orElse(null); this.unique_absent = unique$impl.isAbsent(); this.targetType_value = targetType$impl.toOptional().orElse(null); this.targetType_absent = targetType$impl.isAbsent(); this.targetUserId_value = targetUserId$impl.toOptional().orElse(null); this.targetUserId_absent = targetUserId$impl.isAbsent(); this.targetApplicationId_value = targetApplicationId$impl.toOptional().orElse(null); this.targetApplicationId_absent = targetApplicationId$impl.isAbsent(); this.initShim = null; } private InviteCreateMono(@Nullable String reason, Possible<Integer> maxAge, Possible<Integer> maxUses, Possible<Boolean> temporary, Possible<Boolean> unique, Possible<Invite.Type> targetType, Possible<Snowflake> targetUserId, Possible<Snowflake> targetApplicationId, CategorizableChannel channel) { this.initShim = new InitShim(); this.reason = reason; Possible<Integer> maxAge$impl = maxAge; Possible<Integer> maxUses$impl = maxUses; Possible<Boolean> temporary$impl = temporary; Possible<Boolean> unique$impl = unique; Possible<Invite.Type> targetType$impl = targetType; Possible<Snowflake> targetUserId$impl = targetUserId; Possible<Snowflake> targetApplicationId$impl = targetApplicationId; this.channel = channel; this.maxAge_value = maxAge$impl.toOptional().orElse(null); this.maxAge_absent = maxAge$impl.isAbsent(); this.maxUses_value = maxUses$impl.toOptional().orElse(null); this.maxUses_absent = maxUses$impl.isAbsent(); this.temporary_value = temporary$impl.toOptional().orElse(null); this.temporary_absent = temporary$impl.isAbsent(); this.unique_value = unique$impl.toOptional().orElse(null); this.unique_absent = unique$impl.isAbsent(); this.targetType_value = targetType$impl.toOptional().orElse(null);
/*     */     this.targetType_absent = targetType$impl.isAbsent();
/*     */     this.targetUserId_value = targetUserId$impl.toOptional().orElse(null);
/*     */     this.targetUserId_absent = targetUserId$impl.isAbsent();
/*     */     this.targetApplicationId_value = targetApplicationId$impl.toOptional().orElse(null);
/*     */     this.targetApplicationId_absent = targetApplicationId$impl.isAbsent();
/* 113 */     this.initShim = null; } @Generated(from = "InviteCreateMonoGenerator", generator = "Immutables") private final class InitShim { private InitShim() {} private String formatInitCycleMessage() { List<String> attributes = new ArrayList<>();
/* 114 */       return "Cannot build InviteCreateMono, attribute initializers form cycle " + attributes; }
/*     */      }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String reason() {
/* 124 */     return this.reason;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Integer> maxAge() {
/* 132 */     return this.maxAge_absent ? Possible.absent() : Possible.of(this.maxAge_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Integer> maxUses() {
/* 140 */     return this.maxUses_absent ? Possible.absent() : Possible.of(this.maxUses_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Boolean> temporary() {
/* 148 */     return this.temporary_absent ? Possible.absent() : Possible.of(this.temporary_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Boolean> unique() {
/* 156 */     return this.unique_absent ? Possible.absent() : Possible.of(this.unique_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Invite.Type> targetType() {
/* 164 */     return this.targetType_absent ? Possible.absent() : Possible.of(this.targetType_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Snowflake> targetUserId() {
/* 172 */     return this.targetUserId_absent ? Possible.absent() : Possible.of(this.targetUserId_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Snowflake> targetApplicationId() {
/* 180 */     return this.targetApplicationId_absent ? Possible.absent() : Possible.of(this.targetApplicationId_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CategorizableChannel channel() {
/* 188 */     return this.channel;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final InviteCreateMono withReason(@Nullable String value) {
/* 198 */     if (Objects.equals(this.reason, value)) return this; 
/* 199 */     return new InviteCreateMono(value, 
/*     */         
/* 201 */         maxAge(), 
/* 202 */         maxUses(), 
/* 203 */         temporary(), 
/* 204 */         unique(), 
/* 205 */         targetType(), 
/* 206 */         targetUserId(), 
/* 207 */         targetApplicationId(), this.channel);
/*     */   }
/*     */ 
/*     */   
/*     */   public InviteCreateMono withMaxAge(Possible<Integer> value) {
/* 212 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/* 213 */     return new InviteCreateMono(this.reason, newValue, 
/*     */ 
/*     */         
/* 216 */         maxUses(), 
/* 217 */         temporary(), 
/* 218 */         unique(), 
/* 219 */         targetType(), 
/* 220 */         targetUserId(), 
/* 221 */         targetApplicationId(), this.channel);
/*     */   }
/*     */ 
/*     */   
/*     */   public InviteCreateMono withMaxAge(Integer value) {
/* 226 */     Possible<Integer> newValue = Possible.of(value);
/* 227 */     return new InviteCreateMono(this.reason, newValue, 
/*     */ 
/*     */         
/* 230 */         maxUses(), 
/* 231 */         temporary(), 
/* 232 */         unique(), 
/* 233 */         targetType(), 
/* 234 */         targetUserId(), 
/* 235 */         targetApplicationId(), this.channel);
/*     */   }
/*     */ 
/*     */   
/*     */   public InviteCreateMono withMaxUses(Possible<Integer> value) {
/* 240 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/* 241 */     return new InviteCreateMono(this.reason, 
/*     */         
/* 243 */         maxAge(), newValue, 
/*     */         
/* 245 */         temporary(), 
/* 246 */         unique(), 
/* 247 */         targetType(), 
/* 248 */         targetUserId(), 
/* 249 */         targetApplicationId(), this.channel);
/*     */   }
/*     */ 
/*     */   
/*     */   public InviteCreateMono withMaxUses(Integer value) {
/* 254 */     Possible<Integer> newValue = Possible.of(value);
/* 255 */     return new InviteCreateMono(this.reason, 
/*     */         
/* 257 */         maxAge(), newValue, 
/*     */         
/* 259 */         temporary(), 
/* 260 */         unique(), 
/* 261 */         targetType(), 
/* 262 */         targetUserId(), 
/* 263 */         targetApplicationId(), this.channel);
/*     */   }
/*     */ 
/*     */   
/*     */   public InviteCreateMono withTemporary(Possible<Boolean> value) {
/* 268 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/* 269 */     return new InviteCreateMono(this.reason, 
/*     */         
/* 271 */         maxAge(), 
/* 272 */         maxUses(), newValue, 
/*     */         
/* 274 */         unique(), 
/* 275 */         targetType(), 
/* 276 */         targetUserId(), 
/* 277 */         targetApplicationId(), this.channel);
/*     */   }
/*     */ 
/*     */   
/*     */   public InviteCreateMono withTemporary(Boolean value) {
/* 282 */     Possible<Boolean> newValue = Possible.of(value);
/* 283 */     return new InviteCreateMono(this.reason, 
/*     */         
/* 285 */         maxAge(), 
/* 286 */         maxUses(), newValue, 
/*     */         
/* 288 */         unique(), 
/* 289 */         targetType(), 
/* 290 */         targetUserId(), 
/* 291 */         targetApplicationId(), this.channel);
/*     */   }
/*     */ 
/*     */   
/*     */   public InviteCreateMono withUnique(Possible<Boolean> value) {
/* 296 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/* 297 */     return new InviteCreateMono(this.reason, 
/*     */         
/* 299 */         maxAge(), 
/* 300 */         maxUses(), 
/* 301 */         temporary(), newValue, 
/*     */         
/* 303 */         targetType(), 
/* 304 */         targetUserId(), 
/* 305 */         targetApplicationId(), this.channel);
/*     */   }
/*     */ 
/*     */   
/*     */   public InviteCreateMono withUnique(Boolean value) {
/* 310 */     Possible<Boolean> newValue = Possible.of(value);
/* 311 */     return new InviteCreateMono(this.reason, 
/*     */         
/* 313 */         maxAge(), 
/* 314 */         maxUses(), 
/* 315 */         temporary(), newValue, 
/*     */         
/* 317 */         targetType(), 
/* 318 */         targetUserId(), 
/* 319 */         targetApplicationId(), this.channel);
/*     */   }
/*     */ 
/*     */   
/*     */   public InviteCreateMono withTargetType(Possible<Invite.Type> value) {
/* 324 */     Possible<Invite.Type> newValue = Objects.<Possible<Invite.Type>>requireNonNull(value);
/* 325 */     return new InviteCreateMono(this.reason, 
/*     */         
/* 327 */         maxAge(), 
/* 328 */         maxUses(), 
/* 329 */         temporary(), 
/* 330 */         unique(), newValue, 
/*     */         
/* 332 */         targetUserId(), 
/* 333 */         targetApplicationId(), this.channel);
/*     */   }
/*     */ 
/*     */   
/*     */   public InviteCreateMono withTargetType(Invite.Type value) {
/* 338 */     Possible<Invite.Type> newValue = Possible.of(value);
/* 339 */     return new InviteCreateMono(this.reason, 
/*     */         
/* 341 */         maxAge(), 
/* 342 */         maxUses(), 
/* 343 */         temporary(), 
/* 344 */         unique(), newValue, 
/*     */         
/* 346 */         targetUserId(), 
/* 347 */         targetApplicationId(), this.channel);
/*     */   }
/*     */ 
/*     */   
/*     */   public InviteCreateMono withTargetUserId(Possible<Snowflake> value) {
/* 352 */     Possible<Snowflake> newValue = Objects.<Possible<Snowflake>>requireNonNull(value);
/* 353 */     return new InviteCreateMono(this.reason, 
/*     */         
/* 355 */         maxAge(), 
/* 356 */         maxUses(), 
/* 357 */         temporary(), 
/* 358 */         unique(), 
/* 359 */         targetType(), newValue, 
/*     */         
/* 361 */         targetApplicationId(), this.channel);
/*     */   }
/*     */ 
/*     */   
/*     */   public InviteCreateMono withTargetUserId(Snowflake value) {
/* 366 */     Possible<Snowflake> newValue = Possible.of(value);
/* 367 */     return new InviteCreateMono(this.reason, 
/*     */         
/* 369 */         maxAge(), 
/* 370 */         maxUses(), 
/* 371 */         temporary(), 
/* 372 */         unique(), 
/* 373 */         targetType(), newValue, 
/*     */         
/* 375 */         targetApplicationId(), this.channel);
/*     */   }
/*     */ 
/*     */   
/*     */   public InviteCreateMono withTargetApplicationId(Possible<Snowflake> value) {
/* 380 */     Possible<Snowflake> newValue = Objects.<Possible<Snowflake>>requireNonNull(value);
/* 381 */     return new InviteCreateMono(this.reason, 
/*     */         
/* 383 */         maxAge(), 
/* 384 */         maxUses(), 
/* 385 */         temporary(), 
/* 386 */         unique(), 
/* 387 */         targetType(), 
/* 388 */         targetUserId(), newValue, this.channel);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public InviteCreateMono withTargetApplicationId(Snowflake value) {
/* 394 */     Possible<Snowflake> newValue = Possible.of(value);
/* 395 */     return new InviteCreateMono(this.reason, 
/*     */         
/* 397 */         maxAge(), 
/* 398 */         maxUses(), 
/* 399 */         temporary(), 
/* 400 */         unique(), 
/* 401 */         targetType(), 
/* 402 */         targetUserId(), newValue, this.channel);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final InviteCreateMono withChannel(CategorizableChannel value) {
/* 414 */     if (this.channel == value) return this; 
/* 415 */     CategorizableChannel newValue = Objects.<CategorizableChannel>requireNonNull(value, "channel");
/* 416 */     return new InviteCreateMono(this.reason, 
/*     */         
/* 418 */         maxAge(), 
/* 419 */         maxUses(), 
/* 420 */         temporary(), 
/* 421 */         unique(), 
/* 422 */         targetType(), 
/* 423 */         targetUserId(), 
/* 424 */         targetApplicationId(), newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 434 */     if (this == another) return true; 
/* 435 */     return (another instanceof InviteCreateMono && 
/* 436 */       equalTo(0, (InviteCreateMono)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, InviteCreateMono another) {
/* 440 */     return (Objects.equals(this.reason, another.reason) && 
/* 441 */       maxAge().equals(another.maxAge()) && 
/* 442 */       maxUses().equals(another.maxUses()) && 
/* 443 */       temporary().equals(another.temporary()) && 
/* 444 */       unique().equals(another.unique()) && 
/* 445 */       targetType().equals(another.targetType()) && 
/* 446 */       targetUserId().equals(another.targetUserId()) && 
/* 447 */       targetApplicationId().equals(another.targetApplicationId()) && this.channel
/* 448 */       .equals(another.channel));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 457 */     int h = 5381;
/* 458 */     h += (h << 5) + Objects.hashCode(this.reason);
/* 459 */     h += (h << 5) + maxAge().hashCode();
/* 460 */     h += (h << 5) + maxUses().hashCode();
/* 461 */     h += (h << 5) + temporary().hashCode();
/* 462 */     h += (h << 5) + unique().hashCode();
/* 463 */     h += (h << 5) + targetType().hashCode();
/* 464 */     h += (h << 5) + targetUserId().hashCode();
/* 465 */     h += (h << 5) + targetApplicationId().hashCode();
/* 466 */     h += (h << 5) + this.channel.hashCode();
/* 467 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 476 */     return "InviteCreateMono{reason=" + this.reason + ", maxAge=" + 
/*     */       
/* 478 */       maxAge().toString() + ", maxUses=" + 
/* 479 */       maxUses().toString() + ", temporary=" + 
/* 480 */       temporary().toString() + ", unique=" + 
/* 481 */       unique().toString() + ", targetType=" + 
/* 482 */       targetType().toString() + ", targetUserId=" + 
/* 483 */       targetUserId().toString() + ", targetApplicationId=" + 
/* 484 */       targetApplicationId().toString() + ", channel=" + this.channel + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static InviteCreateMono of(CategorizableChannel channel) {
/* 495 */     return new InviteCreateMono(channel);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static InviteCreateMono copyOf(InviteCreateMonoGenerator instance) {
/* 506 */     if (instance instanceof InviteCreateMono) {
/* 507 */       return (InviteCreateMono)instance;
/*     */     }
/* 509 */     return of(instance.channel())
/* 510 */       .withReason(instance.reason())
/* 511 */       .withMaxAge(instance.maxAge())
/* 512 */       .withMaxUses(instance.maxUses())
/* 513 */       .withTemporary(instance.temporary())
/* 514 */       .withUnique(instance.unique())
/* 515 */       .withTargetType(instance.targetType())
/* 516 */       .withTargetUserId(instance.targetUserId())
/* 517 */       .withTargetApplicationId(instance.targetApplicationId());
/*     */   }
/*     */   
/*     */   public boolean isMaxAgePresent() {
/* 521 */     return !this.maxAge_absent;
/*     */   }
/*     */   
/*     */   public Integer maxAgeOrElse(Integer defaultValue) {
/* 525 */     return !this.maxAge_absent ? this.maxAge_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isMaxUsesPresent() {
/* 529 */     return !this.maxUses_absent;
/*     */   }
/*     */   
/*     */   public Integer maxUsesOrElse(Integer defaultValue) {
/* 533 */     return !this.maxUses_absent ? this.maxUses_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isTemporaryPresent() {
/* 537 */     return !this.temporary_absent;
/*     */   }
/*     */   
/*     */   public Boolean temporaryOrElse(Boolean defaultValue) {
/* 541 */     return !this.temporary_absent ? this.temporary_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isUniquePresent() {
/* 545 */     return !this.unique_absent;
/*     */   }
/*     */   
/*     */   public Boolean uniqueOrElse(Boolean defaultValue) {
/* 549 */     return !this.unique_absent ? this.unique_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isTargetTypePresent() {
/* 553 */     return !this.targetType_absent;
/*     */   }
/*     */   
/*     */   public Invite.Type targetTypeOrElse(Invite.Type defaultValue) {
/* 557 */     return !this.targetType_absent ? this.targetType_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isTargetUserIdPresent() {
/* 561 */     return !this.targetUserId_absent;
/*     */   }
/*     */   
/*     */   public Snowflake targetUserIdOrElse(Snowflake defaultValue) {
/* 565 */     return !this.targetUserId_absent ? this.targetUserId_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isTargetApplicationIdPresent() {
/* 569 */     return !this.targetApplicationId_absent;
/*     */   }
/*     */   
/*     */   public Snowflake targetApplicationIdOrElse(Snowflake defaultValue) {
/* 573 */     return !this.targetApplicationId_absent ? this.targetApplicationId_value : defaultValue;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\InviteCreateMono.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */