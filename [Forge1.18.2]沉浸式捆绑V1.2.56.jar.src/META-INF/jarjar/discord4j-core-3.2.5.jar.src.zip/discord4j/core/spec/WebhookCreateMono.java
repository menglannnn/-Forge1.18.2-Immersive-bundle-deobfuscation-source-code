/*     */ package discord4j.core.spec;
/*     */ 
/*     */ import discord4j.core.object.entity.Webhook;
/*     */ import discord4j.core.object.entity.channel.GuildMessageChannel;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import discord4j.rest.util.Image;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import org.immutables.value.Generated;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "WebhookCreateMonoGenerator", generator = "Immutables")
/*     */ public final class WebhookCreateMono
/*     */   extends WebhookCreateMonoGenerator
/*     */ {
/*     */   @Nullable
/*     */   private final String reason;
/*     */   private final String name;
/*     */   private final Image avatar_value;
/*     */   private final boolean avatar_absent;
/*     */   private final GuildMessageChannel channel;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   private volatile transient InitShim initShim;
/*     */   
/*     */   private WebhookCreateMono(String name, GuildMessageChannel channel) {
/*  57 */     this.initShim = new InitShim(); this.name = Objects.<String>requireNonNull(name, "name"); this.channel = Objects.<GuildMessageChannel>requireNonNull(channel, "channel"); this.reason = null; Possible<Optional<Image>> avatar$impl = Possible.absent(); this.avatar_value = Possible.flatOpt(avatar$impl).orElse(null); this.avatar_absent = avatar$impl.isAbsent(); this.initShim = null; } private WebhookCreateMono(@Nullable String reason, String name, Possible<Optional<Image>> avatar, GuildMessageChannel channel) { this.initShim = new InitShim(); this.reason = reason;
/*     */     this.name = name;
/*     */     Possible<Optional<Image>> avatar$impl = avatar;
/*     */     this.channel = channel;
/*     */     this.avatar_value = Possible.flatOpt(avatar$impl).orElse(null);
/*     */     this.avatar_absent = avatar$impl.isAbsent();
/*  63 */     this.initShim = null; } @Generated(from = "WebhookCreateMonoGenerator", generator = "Immutables") private final class InitShim { private InitShim() {} private String formatInitCycleMessage() { List<String> attributes = new ArrayList<>();
/*  64 */       return "Cannot build WebhookCreateMono, attribute initializers form cycle " + attributes; }
/*     */      }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String reason() {
/*  74 */     return this.reason;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String name() {
/*  82 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Optional<Image>> avatar() {
/*  90 */     return this.avatar_absent ? Possible.absent() : 
/*  91 */       Possible.of(Optional.ofNullable(this.avatar_value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GuildMessageChannel channel() {
/*  99 */     return this.channel;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final WebhookCreateMono withReason(@Nullable String value) {
/* 109 */     if (Objects.equals(this.reason, value)) return this; 
/* 110 */     return new WebhookCreateMono(value, this.name, avatar(), this.channel);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final WebhookCreateMono withName(String value) {
/* 120 */     String newValue = Objects.<String>requireNonNull(value, "name");
/* 121 */     if (this.name.equals(newValue)) return this; 
/* 122 */     return new WebhookCreateMono(this.reason, newValue, avatar(), this.channel);
/*     */   }
/*     */   
/*     */   public WebhookCreateMono withAvatar(Possible<Optional<Image>> value) {
/* 126 */     Possible<Optional<Image>> newValue = Objects.<Possible<Optional<Image>>>requireNonNull(value);
/* 127 */     return new WebhookCreateMono(this.reason, this.name, newValue, this.channel);
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public WebhookCreateMono withAvatar(@Nullable Image value) {
/* 132 */     Possible<Optional<Image>> newValue = Possible.of(Optional.ofNullable(value));
/* 133 */     return new WebhookCreateMono(this.reason, this.name, newValue, this.channel);
/*     */   }
/*     */   
/*     */   public WebhookCreateMono withAvatarOrNull(@Nullable Image value) {
/* 137 */     Possible<Optional<Image>> newValue = Possible.of(Optional.ofNullable(value));
/* 138 */     return new WebhookCreateMono(this.reason, this.name, newValue, this.channel);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final WebhookCreateMono withChannel(GuildMessageChannel value) {
/* 148 */     if (this.channel == value) return this; 
/* 149 */     GuildMessageChannel newValue = Objects.<GuildMessageChannel>requireNonNull(value, "channel");
/* 150 */     return new WebhookCreateMono(this.reason, this.name, avatar(), newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 159 */     if (this == another) return true; 
/* 160 */     return (another instanceof WebhookCreateMono && 
/* 161 */       equalTo(0, (WebhookCreateMono)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, WebhookCreateMono another) {
/* 165 */     return (Objects.equals(this.reason, another.reason) && this.name
/* 166 */       .equals(another.name) && 
/* 167 */       avatar().equals(another.avatar()) && this.channel
/* 168 */       .equals(another.channel));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 177 */     int h = 5381;
/* 178 */     h += (h << 5) + Objects.hashCode(this.reason);
/* 179 */     h += (h << 5) + this.name.hashCode();
/* 180 */     h += (h << 5) + avatar().hashCode();
/* 181 */     h += (h << 5) + this.channel.hashCode();
/* 182 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 191 */     return "WebhookCreateMono{reason=" + this.reason + ", name=" + this.name + ", avatar=" + 
/*     */ 
/*     */       
/* 194 */       avatar().toString() + ", channel=" + this.channel + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static WebhookCreateMono of(String name, GuildMessageChannel channel) {
/* 206 */     return new WebhookCreateMono(name, channel);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static WebhookCreateMono copyOf(WebhookCreateMonoGenerator instance) {
/* 217 */     if (instance instanceof WebhookCreateMono) {
/* 218 */       return (WebhookCreateMono)instance;
/*     */     }
/* 220 */     return of(instance.name(), instance.channel())
/* 221 */       .withReason(instance.reason())
/* 222 */       .withAvatar(instance.avatar());
/*     */   }
/*     */   
/*     */   public boolean isAvatarPresent() {
/* 226 */     return !this.avatar_absent;
/*     */   }
/*     */   
/*     */   public Image avatarOrElse(Image defaultValue) {
/* 230 */     return !this.avatar_absent ? this.avatar_value : defaultValue;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\WebhookCreateMono.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */