/*     */ package discord4j.core.spec;
/*     */ 
/*     */ import discord4j.core.event.domain.interaction.DeferrableInteractionEvent;
/*     */ import discord4j.core.object.component.LayoutComponent;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.stream.StreamSupport;
/*     */ import org.immutables.value.Generated;
/*     */ import reactor.core.CoreSubscriber;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "InteractionPresentModalMonoGenerator", generator = "Immutables")
/*     */ public final class InteractionPresentModalMono
/*     */   extends InteractionPresentModalMonoGenerator
/*     */ {
/*     */   private final String title_value;
/*     */   private final boolean title_absent;
/*     */   private final String customId_value;
/*     */   private final boolean customId_absent;
/*     */   private final List<LayoutComponent> components_value;
/*     */   private final boolean components_absent;
/*     */   private final DeferrableInteractionEvent event;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   private volatile transient InitShim initShim;
/*     */   
/*     */   private InteractionPresentModalMono(DeferrableInteractionEvent event) {
/*  69 */     this.initShim = new InitShim(); this.event = Objects.<DeferrableInteractionEvent>requireNonNull(event, "event"); Possible<String> title$impl = Possible.absent(); Possible<String> customId$impl = Possible.absent(); Possible<List<LayoutComponent>> components$impl = Possible.absent(); this.title_value = title$impl.toOptional().orElse(null); this.title_absent = title$impl.isAbsent(); this.customId_value = customId$impl.toOptional().orElse(null); this.customId_absent = customId$impl.isAbsent(); this.components_value = components$impl.toOptional().orElse(null); this.components_absent = components$impl.isAbsent(); this.initShim = null; } private InteractionPresentModalMono(Possible<String> title, Possible<String> customId, Possible<List<LayoutComponent>> components, DeferrableInteractionEvent event) { this.initShim = new InitShim(); Possible<String> title$impl = title; Possible<String> customId$impl = customId; Possible<List<LayoutComponent>> components$impl = components; this.event = event; this.title_value = title$impl.toOptional().orElse(null);
/*     */     this.title_absent = title$impl.isAbsent();
/*     */     this.customId_value = customId$impl.toOptional().orElse(null);
/*     */     this.customId_absent = customId$impl.isAbsent();
/*     */     this.components_value = components$impl.toOptional().orElse(null);
/*     */     this.components_absent = components$impl.isAbsent();
/*  75 */     this.initShim = null; } @Generated(from = "InteractionPresentModalMonoGenerator", generator = "Immutables") private final class InitShim { private InitShim() {} private String formatInitCycleMessage() { List<String> attributes = new ArrayList<>();
/*  76 */       return "Cannot build InteractionPresentModalMono, attribute initializers form cycle " + attributes; }
/*     */      }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<String> title() {
/*  85 */     return this.title_absent ? Possible.absent() : Possible.of(this.title_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<String> customId() {
/*  93 */     return this.customId_absent ? Possible.absent() : Possible.of(this.customId_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<List<LayoutComponent>> components() {
/* 101 */     return this.components_absent ? Possible.absent() : 
/* 102 */       Possible.of(this.components_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DeferrableInteractionEvent event() {
/* 110 */     return this.event;
/*     */   }
/*     */   
/*     */   public InteractionPresentModalMono withTitle(Possible<String> value) {
/* 114 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/* 115 */     return new InteractionPresentModalMono(newValue, customId(), components(), this.event);
/*     */   }
/*     */   
/*     */   public InteractionPresentModalMono withTitle(String value) {
/* 119 */     Possible<String> newValue = Possible.of(value);
/* 120 */     return new InteractionPresentModalMono(newValue, customId(), components(), this.event);
/*     */   }
/*     */   
/*     */   public InteractionPresentModalMono withCustomId(Possible<String> value) {
/* 124 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/* 125 */     return new InteractionPresentModalMono(title(), newValue, components(), this.event);
/*     */   }
/*     */   
/*     */   public InteractionPresentModalMono withCustomId(String value) {
/* 129 */     Possible<String> newValue = Possible.of(value);
/* 130 */     return new InteractionPresentModalMono(title(), newValue, components(), this.event);
/*     */   }
/*     */   
/*     */   public InteractionPresentModalMono withComponents(Possible<List<LayoutComponent>> possible) {
/* 134 */     Possible<List<LayoutComponent>> newValue = Objects.<Possible<List<LayoutComponent>>>requireNonNull(possible);
/* 135 */     return new InteractionPresentModalMono(title(), customId(), newValue, this.event);
/*     */   }
/*     */   
/*     */   public InteractionPresentModalMono withComponents(Iterable<LayoutComponent> elements) {
/* 139 */     Possible<List<LayoutComponent>> newValue = Possible.of(
/* 140 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/* 141 */     return new InteractionPresentModalMono(title(), customId(), newValue, this.event);
/*     */   }
/*     */   
/*     */   @SafeVarargs
/*     */   public final InteractionPresentModalMono withComponents(LayoutComponent... elements) {
/* 146 */     Possible<List<LayoutComponent>> newValue = Possible.of(Arrays.asList(elements));
/* 147 */     return new InteractionPresentModalMono(title(), customId(), newValue, this.event);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final InteractionPresentModalMono withEvent(DeferrableInteractionEvent value) {
/* 157 */     if (this.event == value) return this; 
/* 158 */     DeferrableInteractionEvent newValue = Objects.<DeferrableInteractionEvent>requireNonNull(value, "event");
/* 159 */     return new InteractionPresentModalMono(title(), customId(), components(), newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 168 */     if (this == another) return true; 
/* 169 */     return (another instanceof InteractionPresentModalMono && 
/* 170 */       equalTo(0, (InteractionPresentModalMono)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, InteractionPresentModalMono another) {
/* 174 */     return (title().equals(another.title()) && 
/* 175 */       customId().equals(another.customId()) && 
/* 176 */       Objects.equals(this.components_value, another.components_value) && this.event
/* 177 */       .equals(another.event));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 186 */     int h = 5381;
/* 187 */     h += (h << 5) + title().hashCode();
/* 188 */     h += (h << 5) + customId().hashCode();
/* 189 */     h += (h << 5) + Objects.hashCode(this.components_value);
/* 190 */     h += (h << 5) + this.event.hashCode();
/* 191 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 200 */     return "InteractionPresentModalMono{title=" + 
/* 201 */       title().toString() + ", customId=" + 
/* 202 */       customId().toString() + ", components=" + 
/* 203 */       Objects.toString(this.components_value) + ", event=" + this.event + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static InteractionPresentModalMono of(DeferrableInteractionEvent event) {
/* 214 */     return new InteractionPresentModalMono(event);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static InteractionPresentModalMono copyOf(InteractionPresentModalMonoGenerator instance) {
/* 225 */     if (instance instanceof InteractionPresentModalMono) {
/* 226 */       return (InteractionPresentModalMono)instance;
/*     */     }
/* 228 */     return of(instance.event())
/* 229 */       .withTitle(instance.title())
/* 230 */       .withCustomId(instance.customId())
/* 231 */       .withComponents(instance.components());
/*     */   }
/*     */   
/*     */   public boolean isTitlePresent() {
/* 235 */     return !this.title_absent;
/*     */   }
/*     */   
/*     */   public String titleOrElse(String defaultValue) {
/* 239 */     return !this.title_absent ? this.title_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isCustomIdPresent() {
/* 243 */     return !this.customId_absent;
/*     */   }
/*     */   
/*     */   public String customIdOrElse(String defaultValue) {
/* 247 */     return !this.customId_absent ? this.customId_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isComponentsPresent() {
/* 251 */     return !this.components_absent;
/*     */   }
/*     */   
/*     */   public List<LayoutComponent> componentsOrElse(List<LayoutComponent> defaultValue) {
/* 255 */     return !this.components_absent ? this.components_value : defaultValue;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\InteractionPresentModalMono.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */