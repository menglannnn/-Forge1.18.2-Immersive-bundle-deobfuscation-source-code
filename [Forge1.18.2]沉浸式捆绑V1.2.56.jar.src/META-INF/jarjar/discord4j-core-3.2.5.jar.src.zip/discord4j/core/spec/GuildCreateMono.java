/*     */ package discord4j.core.spec;
/*     */ 
/*     */ import discord4j.core.GatewayDiscordClient;
/*     */ import discord4j.core.object.Region;
/*     */ import discord4j.core.object.entity.Guild;
/*     */ import discord4j.rest.util.Image;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "GuildCreateMonoGenerator", generator = "Immutables")
/*     */ public final class GuildCreateMono
/*     */   extends GuildCreateMonoGenerator
/*     */ {
/*     */   private final String name;
/*     */   private final Region region;
/*     */   @Nullable
/*     */   private final Image icon;
/*     */   private final Guild.VerificationLevel verificationLevel;
/*     */   private final Guild.NotificationLevel defaultMessageNotificationLevel;
/*     */   private final Guild.ContentFilterLevel explicitContentFilter;
/*     */   private final List<RoleCreateSpec> roles;
/*     */   @Nullable
/*     */   private final RoleCreateSpec everyoneRole;
/*     */   private final List<GuildCreateFields.PartialChannel> channels;
/*     */   private final GatewayDiscordClient gateway;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   private volatile transient InitShim initShim;
/*     */   
/*     */   private GuildCreateMono(String name, Region region, GatewayDiscordClient gateway) {
/*  82 */     this.initShim = new InitShim(); this.name = Objects.<String>requireNonNull(name, "name"); this.region = Objects.<Region>requireNonNull(region, "region"); this.gateway = Objects.<GatewayDiscordClient>requireNonNull(gateway, "gateway"); this.icon = null; this.everyoneRole = null; this.verificationLevel = this.initShim.verificationLevel(); this.defaultMessageNotificationLevel = this.initShim.defaultMessageNotificationLevel(); this.explicitContentFilter = this.initShim.explicitContentFilter(); this.roles = this.initShim.roles(); this.channels = this.initShim.channels(); this.initShim = null; } private GuildCreateMono(String name, Region region, @Nullable Image icon, Guild.VerificationLevel verificationLevel, Guild.NotificationLevel defaultMessageNotificationLevel, Guild.ContentFilterLevel explicitContentFilter, List<RoleCreateSpec> roles, @Nullable RoleCreateSpec everyoneRole, List<GuildCreateFields.PartialChannel> channels, GatewayDiscordClient gateway) { this.initShim = new InitShim(); this.name = name; this.region = region; this.icon = icon; this.verificationLevel = verificationLevel; this.defaultMessageNotificationLevel = defaultMessageNotificationLevel; this.explicitContentFilter = explicitContentFilter;
/*     */     this.roles = roles;
/*     */     this.everyoneRole = everyoneRole;
/*     */     this.channels = channels;
/*     */     this.gateway = gateway;
/*  87 */     this.initShim = null; } @Generated(from = "GuildCreateMonoGenerator", generator = "Immutables") private final class InitShim { private byte verificationLevelBuildStage = 0;
/*     */     private Guild.VerificationLevel verificationLevel;
/*     */     
/*     */     Guild.VerificationLevel verificationLevel() {
/*  91 */       if (this.verificationLevelBuildStage == -1) throw new IllegalStateException(formatInitCycleMessage()); 
/*  92 */       if (this.verificationLevelBuildStage == 0) {
/*  93 */         this.verificationLevelBuildStage = -1;
/*  94 */         this.verificationLevel = Objects.<Guild.VerificationLevel>requireNonNull(GuildCreateMono.this.verificationLevel(), "verificationLevel");
/*  95 */         this.verificationLevelBuildStage = 1;
/*     */       } 
/*  97 */       return this.verificationLevel;
/*     */     }
/*     */     
/*     */     void verificationLevel(Guild.VerificationLevel verificationLevel) {
/* 101 */       this.verificationLevel = verificationLevel;
/* 102 */       this.verificationLevelBuildStage = 1;
/*     */     }
/*     */     
/* 105 */     private byte defaultMessageNotificationLevelBuildStage = 0;
/*     */     private Guild.NotificationLevel defaultMessageNotificationLevel;
/*     */     
/*     */     Guild.NotificationLevel defaultMessageNotificationLevel() {
/* 109 */       if (this.defaultMessageNotificationLevelBuildStage == -1) throw new IllegalStateException(formatInitCycleMessage()); 
/* 110 */       if (this.defaultMessageNotificationLevelBuildStage == 0) {
/* 111 */         this.defaultMessageNotificationLevelBuildStage = -1;
/* 112 */         this.defaultMessageNotificationLevel = Objects.<Guild.NotificationLevel>requireNonNull(GuildCreateMono.this.defaultMessageNotificationLevel(), "defaultMessageNotificationLevel");
/* 113 */         this.defaultMessageNotificationLevelBuildStage = 1;
/*     */       } 
/* 115 */       return this.defaultMessageNotificationLevel;
/*     */     }
/*     */     
/*     */     void defaultMessageNotificationLevel(Guild.NotificationLevel defaultMessageNotificationLevel) {
/* 119 */       this.defaultMessageNotificationLevel = defaultMessageNotificationLevel;
/* 120 */       this.defaultMessageNotificationLevelBuildStage = 1;
/*     */     }
/*     */     
/* 123 */     private byte explicitContentFilterBuildStage = 0;
/*     */     private Guild.ContentFilterLevel explicitContentFilter;
/*     */     
/*     */     Guild.ContentFilterLevel explicitContentFilter() {
/* 127 */       if (this.explicitContentFilterBuildStage == -1) throw new IllegalStateException(formatInitCycleMessage()); 
/* 128 */       if (this.explicitContentFilterBuildStage == 0) {
/* 129 */         this.explicitContentFilterBuildStage = -1;
/* 130 */         this.explicitContentFilter = Objects.<Guild.ContentFilterLevel>requireNonNull(GuildCreateMono.this.explicitContentFilter(), "explicitContentFilter");
/* 131 */         this.explicitContentFilterBuildStage = 1;
/*     */       } 
/* 133 */       return this.explicitContentFilter;
/*     */     }
/*     */     
/*     */     void explicitContentFilter(Guild.ContentFilterLevel explicitContentFilter) {
/* 137 */       this.explicitContentFilter = explicitContentFilter;
/* 138 */       this.explicitContentFilterBuildStage = 1;
/*     */     }
/*     */     
/* 141 */     private byte rolesBuildStage = 0;
/*     */     private List<RoleCreateSpec> roles;
/*     */     
/*     */     List<RoleCreateSpec> roles() {
/* 145 */       if (this.rolesBuildStage == -1) throw new IllegalStateException(formatInitCycleMessage()); 
/* 146 */       if (this.rolesBuildStage == 0) {
/* 147 */         this.rolesBuildStage = -1;
/* 148 */         this.roles = (List)GuildCreateMono.createUnmodifiableList(false, GuildCreateMono.createSafeList((Iterable)GuildCreateMono.this.roles(), true, false));
/* 149 */         this.rolesBuildStage = 1;
/*     */       } 
/* 151 */       return this.roles;
/*     */     }
/*     */     
/*     */     void roles(List<RoleCreateSpec> roles) {
/* 155 */       this.roles = roles;
/* 156 */       this.rolesBuildStage = 1;
/*     */     }
/*     */     
/* 159 */     private byte channelsBuildStage = 0;
/*     */     private List<GuildCreateFields.PartialChannel> channels;
/*     */     
/*     */     List<GuildCreateFields.PartialChannel> channels() {
/* 163 */       if (this.channelsBuildStage == -1) throw new IllegalStateException(formatInitCycleMessage()); 
/* 164 */       if (this.channelsBuildStage == 0) {
/* 165 */         this.channelsBuildStage = -1;
/* 166 */         this.channels = (List)GuildCreateMono.createUnmodifiableList(false, GuildCreateMono.createSafeList((Iterable)GuildCreateMono.this.channels(), true, false));
/* 167 */         this.channelsBuildStage = 1;
/*     */       } 
/* 169 */       return this.channels;
/*     */     }
/*     */     
/*     */     void channels(List<GuildCreateFields.PartialChannel> channels) {
/* 173 */       this.channels = channels;
/* 174 */       this.channelsBuildStage = 1;
/*     */     }
/*     */     
/*     */     private String formatInitCycleMessage() {
/* 178 */       List<String> attributes = new ArrayList<>();
/* 179 */       if (this.verificationLevelBuildStage == -1) attributes.add("verificationLevel"); 
/* 180 */       if (this.defaultMessageNotificationLevelBuildStage == -1) attributes.add("defaultMessageNotificationLevel"); 
/* 181 */       if (this.explicitContentFilterBuildStage == -1) attributes.add("explicitContentFilter"); 
/* 182 */       if (this.rolesBuildStage == -1) attributes.add("roles"); 
/* 183 */       if (this.channelsBuildStage == -1) attributes.add("channels"); 
/* 184 */       return "Cannot build GuildCreateMono, attribute initializers form cycle " + attributes;
/*     */     }
/*     */ 
/*     */     
/*     */     private InitShim() {} }
/*     */ 
/*     */ 
/*     */   
/*     */   public String name() {
/* 193 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Region region() {
/* 201 */     return this.region;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Image icon() {
/* 209 */     return this.icon;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Guild.VerificationLevel verificationLevel() {
/* 217 */     InitShim shim = this.initShim;
/* 218 */     return (shim != null) ? 
/* 219 */       shim.verificationLevel() : 
/* 220 */       this.verificationLevel;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Guild.NotificationLevel defaultMessageNotificationLevel() {
/* 228 */     InitShim shim = this.initShim;
/* 229 */     return (shim != null) ? 
/* 230 */       shim.defaultMessageNotificationLevel() : 
/* 231 */       this.defaultMessageNotificationLevel;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Guild.ContentFilterLevel explicitContentFilter() {
/* 239 */     InitShim shim = this.initShim;
/* 240 */     return (shim != null) ? 
/* 241 */       shim.explicitContentFilter() : 
/* 242 */       this.explicitContentFilter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<RoleCreateSpec> roles() {
/* 250 */     InitShim shim = this.initShim;
/* 251 */     return (shim != null) ? 
/* 252 */       shim.roles() : 
/* 253 */       this.roles;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public RoleCreateSpec everyoneRole() {
/* 261 */     return this.everyoneRole;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<GuildCreateFields.PartialChannel> channels() {
/* 269 */     InitShim shim = this.initShim;
/* 270 */     return (shim != null) ? 
/* 271 */       shim.channels() : 
/* 272 */       this.channels;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GatewayDiscordClient gateway() {
/* 280 */     return this.gateway;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final GuildCreateMono withName(String value) {
/* 290 */     String newValue = Objects.<String>requireNonNull(value, "name");
/* 291 */     if (this.name.equals(newValue)) return this; 
/* 292 */     return new GuildCreateMono(newValue, this.region, this.icon, this.verificationLevel, this.defaultMessageNotificationLevel, this.explicitContentFilter, this.roles, this.everyoneRole, this.channels, this.gateway);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final GuildCreateMono withRegion(Region value) {
/* 312 */     if (this.region == value) return this; 
/* 313 */     Region newValue = Objects.<Region>requireNonNull(value, "region");
/* 314 */     return new GuildCreateMono(this.name, newValue, this.icon, this.verificationLevel, this.defaultMessageNotificationLevel, this.explicitContentFilter, this.roles, this.everyoneRole, this.channels, this.gateway);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final GuildCreateMono withIcon(@Nullable Image value) {
/* 334 */     if (this.icon == value) return this; 
/* 335 */     return new GuildCreateMono(this.name, this.region, value, this.verificationLevel, this.defaultMessageNotificationLevel, this.explicitContentFilter, this.roles, this.everyoneRole, this.channels, this.gateway);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final GuildCreateMono withVerificationLevel(Guild.VerificationLevel value) {
/* 355 */     Guild.VerificationLevel newValue = Objects.<Guild.VerificationLevel>requireNonNull(value, "verificationLevel");
/* 356 */     if (this.verificationLevel == newValue) return this; 
/* 357 */     return new GuildCreateMono(this.name, this.region, this.icon, newValue, this.defaultMessageNotificationLevel, this.explicitContentFilter, this.roles, this.everyoneRole, this.channels, this.gateway);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final GuildCreateMono withDefaultMessageNotificationLevel(Guild.NotificationLevel value) {
/* 377 */     Guild.NotificationLevel newValue = Objects.<Guild.NotificationLevel>requireNonNull(value, "defaultMessageNotificationLevel");
/* 378 */     if (this.defaultMessageNotificationLevel == newValue) return this; 
/* 379 */     return new GuildCreateMono(this.name, this.region, this.icon, this.verificationLevel, newValue, this.explicitContentFilter, this.roles, this.everyoneRole, this.channels, this.gateway);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final GuildCreateMono withExplicitContentFilter(Guild.ContentFilterLevel value) {
/* 399 */     Guild.ContentFilterLevel newValue = Objects.<Guild.ContentFilterLevel>requireNonNull(value, "explicitContentFilter");
/* 400 */     if (this.explicitContentFilter == newValue) return this; 
/* 401 */     return new GuildCreateMono(this.name, this.region, this.icon, this.verificationLevel, this.defaultMessageNotificationLevel, newValue, this.roles, this.everyoneRole, this.channels, this.gateway);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final GuildCreateMono withRoles(RoleCreateSpec... elements) {
/* 420 */     List<RoleCreateSpec> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/* 421 */     return new GuildCreateMono(this.name, this.region, this.icon, this.verificationLevel, this.defaultMessageNotificationLevel, this.explicitContentFilter, newValue, this.everyoneRole, this.channels, this.gateway);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final GuildCreateMono withRoles(Iterable<? extends RoleCreateSpec> elements) {
/* 441 */     if (this.roles == elements) return this; 
/* 442 */     List<RoleCreateSpec> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/* 443 */     return new GuildCreateMono(this.name, this.region, this.icon, this.verificationLevel, this.defaultMessageNotificationLevel, this.explicitContentFilter, newValue, this.everyoneRole, this.channels, this.gateway);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final GuildCreateMono withEveryoneRole(@Nullable RoleCreateSpec value) {
/* 463 */     if (this.everyoneRole == value) return this; 
/* 464 */     return new GuildCreateMono(this.name, this.region, this.icon, this.verificationLevel, this.defaultMessageNotificationLevel, this.explicitContentFilter, this.roles, value, this.channels, this.gateway);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final GuildCreateMono withChannels(GuildCreateFields.PartialChannel... elements) {
/* 483 */     List<GuildCreateFields.PartialChannel> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/* 484 */     return new GuildCreateMono(this.name, this.region, this.icon, this.verificationLevel, this.defaultMessageNotificationLevel, this.explicitContentFilter, this.roles, this.everyoneRole, newValue, this.gateway);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final GuildCreateMono withChannels(Iterable<? extends GuildCreateFields.PartialChannel> elements) {
/* 504 */     if (this.channels == elements) return this; 
/* 505 */     List<GuildCreateFields.PartialChannel> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/* 506 */     return new GuildCreateMono(this.name, this.region, this.icon, this.verificationLevel, this.defaultMessageNotificationLevel, this.explicitContentFilter, this.roles, this.everyoneRole, newValue, this.gateway);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final GuildCreateMono withGateway(GatewayDiscordClient value) {
/* 526 */     if (this.gateway == value) return this; 
/* 527 */     GatewayDiscordClient newValue = Objects.<GatewayDiscordClient>requireNonNull(value, "gateway");
/* 528 */     return new GuildCreateMono(this.name, this.region, this.icon, this.verificationLevel, this.defaultMessageNotificationLevel, this.explicitContentFilter, this.roles, this.everyoneRole, this.channels, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 547 */     if (this == another) return true; 
/* 548 */     return (another instanceof GuildCreateMono && 
/* 549 */       equalTo(0, (GuildCreateMono)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, GuildCreateMono another) {
/* 553 */     return (this.name.equals(another.name) && this.region
/* 554 */       .equals(another.region) && 
/* 555 */       Objects.equals(this.icon, another.icon) && this.verificationLevel
/* 556 */       .equals(another.verificationLevel) && this.defaultMessageNotificationLevel
/* 557 */       .equals(another.defaultMessageNotificationLevel) && this.explicitContentFilter
/* 558 */       .equals(another.explicitContentFilter) && this.roles
/* 559 */       .equals(another.roles) && 
/* 560 */       Objects.equals(this.everyoneRole, another.everyoneRole) && this.channels
/* 561 */       .equals(another.channels) && this.gateway
/* 562 */       .equals(another.gateway));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 571 */     int h = 5381;
/* 572 */     h += (h << 5) + this.name.hashCode();
/* 573 */     h += (h << 5) + this.region.hashCode();
/* 574 */     h += (h << 5) + Objects.hashCode(this.icon);
/* 575 */     h += (h << 5) + this.verificationLevel.hashCode();
/* 576 */     h += (h << 5) + this.defaultMessageNotificationLevel.hashCode();
/* 577 */     h += (h << 5) + this.explicitContentFilter.hashCode();
/* 578 */     h += (h << 5) + this.roles.hashCode();
/* 579 */     h += (h << 5) + Objects.hashCode(this.everyoneRole);
/* 580 */     h += (h << 5) + this.channels.hashCode();
/* 581 */     h += (h << 5) + this.gateway.hashCode();
/* 582 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 591 */     return "GuildCreateMono{name=" + this.name + ", region=" + this.region + ", icon=" + this.icon + ", verificationLevel=" + this.verificationLevel + ", defaultMessageNotificationLevel=" + this.defaultMessageNotificationLevel + ", explicitContentFilter=" + this.explicitContentFilter + ", roles=" + this.roles + ", everyoneRole=" + this.everyoneRole + ", channels=" + this.channels + ", gateway=" + this.gateway + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static GuildCreateMono of(String name, Region region, GatewayDiscordClient gateway) {
/* 613 */     return new GuildCreateMono(name, region, gateway);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static GuildCreateMono copyOf(GuildCreateMonoGenerator instance) {
/* 624 */     if (instance instanceof GuildCreateMono) {
/* 625 */       return (GuildCreateMono)instance;
/*     */     }
/* 627 */     return of(instance.name(), instance.region(), instance.gateway())
/* 628 */       .withIcon(instance.icon())
/* 629 */       .withVerificationLevel(instance.verificationLevel())
/* 630 */       .withDefaultMessageNotificationLevel(instance.defaultMessageNotificationLevel())
/* 631 */       .withExplicitContentFilter(instance.explicitContentFilter())
/* 632 */       .withRoles(instance.roles())
/* 633 */       .withEveryoneRole(instance.everyoneRole())
/* 634 */       .withChannels(instance.channels());
/*     */   }
/*     */   
/*     */   private static <T> List<T> createSafeList(Iterable<? extends T> iterable, boolean checkNulls, boolean skipNulls) {
/*     */     ArrayList<T> list;
/* 639 */     if (iterable instanceof Collection) {
/* 640 */       int size = ((Collection)iterable).size();
/* 641 */       if (size == 0) return Collections.emptyList(); 
/* 642 */       list = new ArrayList<>();
/*     */     } else {
/* 644 */       list = new ArrayList<>();
/*     */     } 
/* 646 */     for (T element : iterable) {
/* 647 */       if (skipNulls && element == null)
/* 648 */         continue;  if (checkNulls) Objects.requireNonNull(element, "element"); 
/* 649 */       list.add(element);
/*     */     } 
/* 651 */     return list;
/*     */   }
/*     */   
/*     */   private static <T> List<T> createUnmodifiableList(boolean clone, List<T> list) {
/* 655 */     switch (list.size()) { case 0:
/* 656 */         return Collections.emptyList();
/* 657 */       case 1: return Collections.singletonList(list.get(0)); }
/*     */     
/* 659 */     if (clone) {
/* 660 */       return Collections.unmodifiableList(new ArrayList<>(list));
/*     */     }
/* 662 */     if (list instanceof ArrayList) {
/* 663 */       ((ArrayList)list).trimToSize();
/*     */     }
/* 665 */     return Collections.unmodifiableList(list);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\GuildCreateMono.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */