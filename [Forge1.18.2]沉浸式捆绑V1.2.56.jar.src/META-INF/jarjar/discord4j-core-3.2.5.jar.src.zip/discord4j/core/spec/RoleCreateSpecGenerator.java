/*    */ package discord4j.core.spec;
/*    */ 
/*    */ import discord4j.discordjson.json.RoleCreateRequest;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import discord4j.rest.util.Color;
/*    */ import discord4j.rest.util.PermissionSet;
/*    */ import java.util.Optional;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Immutable(singleton = true)
/*    */ interface RoleCreateSpecGenerator
/*    */   extends AuditSpec<RoleCreateRequest>
/*    */ {
/*    */   default RoleCreateRequest asRequest() {
/* 53 */     return (RoleCreateRequest)RoleCreateRequest.builder()
/* 54 */       .name(name())
/* 55 */       .permissions(InternalSpecUtils.mapPossible(permissions(), PermissionSet::getRawValue))
/* 56 */       .color(InternalSpecUtils.mapPossible(color(), Color::getRGB))
/* 57 */       .hoist(hoist())
/* 58 */       .mentionable(mentionable())
/* 59 */       .icon(icon())
/* 60 */       .unicodeEmoji(unicodeEmoji())
/* 61 */       .build();
/*    */   }
/*    */   
/*    */   Possible<Optional<String>> unicodeEmoji();
/*    */   
/*    */   Possible<Optional<String>> icon();
/*    */   
/*    */   Possible<Boolean> mentionable();
/*    */   
/*    */   Possible<Boolean> hoist();
/*    */   
/*    */   Possible<Color> color();
/*    */   
/*    */   Possible<PermissionSet> permissions();
/*    */   
/*    */   Possible<String> name();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\RoleCreateSpecGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */