/*    */ package discord4j.core.spec;
/*    */ 
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import discord4j.rest.util.Multimap;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import java.util.Optional;
/*    */ import java.util.function.Function;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class InternalSpecUtils
/*    */ {
/*    */   private InternalSpecUtils() {
/* 31 */     throw new AssertionError();
/*    */   }
/*    */   
/*    */   static <T> Possible<T> toPossible(@Nullable T value) {
/* 35 */     return (value == null) ? Possible.absent() : Possible.of(value);
/*    */   }
/*    */   
/*    */   @Nullable
/*    */   static <T, R> R mapNullable(@Nullable T value, Function<? super T, ? extends R> mapper) {
/* 40 */     return (value != null) ? mapper.apply(value) : null;
/*    */   }
/*    */   
/*    */   static void putIfNotNull(Map<String, Object> map, String key, @Nullable Object value) {
/* 44 */     if (value != null) {
/* 45 */       map.put(key, value);
/*    */     }
/*    */   }
/*    */   
/*    */   static void setIfNotNull(Multimap<String, Object> map, String key, @Nullable Object value) {
/* 50 */     if (value != null) {
/* 51 */       map.set(key, value);
/*    */     }
/*    */   }
/*    */   
/*    */   static void addAllIfNotNull(Multimap<String, Object> map, String key, @Nullable List<Object> values) {
/* 56 */     if (values != null) {
/* 57 */       map.addAll(key, values);
/*    */     }
/*    */   }
/*    */   
/*    */   static <T, R> Possible<R> mapPossible(Possible<T> value, Function<? super T, ? extends R> mapper) {
/* 62 */     return value.isAbsent() ? Possible.absent() : Possible.of(mapper.apply((T)value.get()));
/*    */   }
/*    */ 
/*    */   
/*    */   static <T, R> Possible<Optional<R>> mapPossibleOptional(Possible<Optional<T>> value, Function<? super T, ? extends R> mapper) {
/* 67 */     return value.isAbsent() ? Possible.absent() : Possible.of(((Optional<T>)value.get()).map(mapper));
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\InternalSpecUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */