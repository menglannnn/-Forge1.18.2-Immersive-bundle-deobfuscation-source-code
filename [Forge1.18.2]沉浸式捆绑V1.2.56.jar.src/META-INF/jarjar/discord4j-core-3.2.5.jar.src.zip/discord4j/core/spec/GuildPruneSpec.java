/*     */ package discord4j.core.spec;
/*     */ 
/*     */ import com.google.errorprone.annotations.CanIgnoreReturnValue;
/*     */ import discord4j.common.util.Snowflake;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ import org.immutables.value.Generated;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "GuildPruneSpecGenerator", generator = "Immutables")
/*     */ public final class GuildPruneSpec
/*     */   implements GuildPruneSpecGenerator
/*     */ {
/*     */   @Nullable
/*     */   private final String reason;
/*     */   private final Integer days;
/*     */   @Nullable
/*     */   private final Set<Snowflake> roles;
/*     */   @Nullable
/*     */   private final Boolean computePruneCount;
/*     */   
/*     */   private GuildPruneSpec(Integer days) {
/*  35 */     this.days = Objects.<Integer>requireNonNull(days, "days");
/*  36 */     this.reason = null;
/*  37 */     this.roles = null;
/*  38 */     this.computePruneCount = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private GuildPruneSpec(@Nullable String reason, Integer days, @Nullable Set<Snowflake> roles, @Nullable Boolean computePruneCount) {
/*  46 */     this.reason = reason;
/*  47 */     this.days = days;
/*  48 */     this.roles = roles;
/*  49 */     this.computePruneCount = computePruneCount;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String reason() {
/*  58 */     return this.reason;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Integer days() {
/*  66 */     return this.days;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Set<Snowflake> roles() {
/*  74 */     return this.roles;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Boolean computePruneCount() {
/*  82 */     return this.computePruneCount;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final GuildPruneSpec withReason(@Nullable String value) {
/*  92 */     if (Objects.equals(this.reason, value)) return this; 
/*  93 */     return new GuildPruneSpec(value, this.days, this.roles, this.computePruneCount);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final GuildPruneSpec withDays(Integer value) {
/* 103 */     Integer newValue = Objects.<Integer>requireNonNull(value, "days");
/* 104 */     if (this.days.equals(newValue)) return this; 
/* 105 */     return new GuildPruneSpec(this.reason, newValue, this.roles, this.computePruneCount);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final GuildPruneSpec withRoles(@Nullable Snowflake... elements) {
/* 114 */     if (elements == null) {
/* 115 */       return new GuildPruneSpec(this.reason, this.days, null, this.computePruneCount);
/*     */     }
/* 117 */     Set<Snowflake> newValue = (Arrays.asList(elements) == null) ? null : createUnmodifiableSet(createSafeList(Arrays.asList(elements), true, false));
/* 118 */     return new GuildPruneSpec(this.reason, this.days, newValue, this.computePruneCount);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final GuildPruneSpec withRoles(@Nullable Iterable<? extends Snowflake> elements) {
/* 128 */     if (this.roles == elements) return this; 
/* 129 */     Set<Snowflake> newValue = (elements == null) ? null : createUnmodifiableSet(createSafeList(elements, true, false));
/* 130 */     return new GuildPruneSpec(this.reason, this.days, newValue, this.computePruneCount);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final GuildPruneSpec withComputePruneCount(@Nullable Boolean value) {
/* 140 */     if (Objects.equals(this.computePruneCount, value)) return this; 
/* 141 */     return new GuildPruneSpec(this.reason, this.days, this.roles, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 150 */     if (this == another) return true; 
/* 151 */     return (another instanceof GuildPruneSpec && 
/* 152 */       equalTo(0, (GuildPruneSpec)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, GuildPruneSpec another) {
/* 156 */     return (Objects.equals(this.reason, another.reason) && this.days
/* 157 */       .equals(another.days) && 
/* 158 */       Objects.equals(this.roles, another.roles) && 
/* 159 */       Objects.equals(this.computePruneCount, another.computePruneCount));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 168 */     int h = 5381;
/* 169 */     h += (h << 5) + Objects.hashCode(this.reason);
/* 170 */     h += (h << 5) + this.days.hashCode();
/* 171 */     h += (h << 5) + Objects.hashCode(this.roles);
/* 172 */     h += (h << 5) + Objects.hashCode(this.computePruneCount);
/* 173 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 182 */     return "GuildPruneSpec{reason=" + this.reason + ", days=" + this.days + ", roles=" + this.roles + ", computePruneCount=" + this.computePruneCount + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static GuildPruneSpec of(Integer days) {
/* 196 */     return new GuildPruneSpec(days);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static GuildPruneSpec copyOf(GuildPruneSpecGenerator instance) {
/* 207 */     if (instance instanceof GuildPruneSpec) {
/* 208 */       return (GuildPruneSpec)instance;
/*     */     }
/* 210 */     return builder()
/* 211 */       .from(instance)
/* 212 */       .build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 228 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "GuildPruneSpecGenerator", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_DAYS = 1L;
/*     */ 
/*     */ 
/*     */     
/* 241 */     private long initBits = 1L;
/*     */     
/*     */     private String reason;
/*     */     private Integer days;
/* 245 */     private List<Snowflake> roles = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private Boolean computePruneCount;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(GuildPruneSpec instance) {
/* 260 */       return from(instance);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     final Builder from(GuildPruneSpecGenerator instance) {
/* 270 */       Objects.requireNonNull(instance, "instance");
/* 271 */       String reasonValue = instance.reason();
/* 272 */       if (reasonValue != null) {
/* 273 */         reason(reasonValue);
/*     */       }
/* 275 */       days(instance.days());
/* 276 */       Set<Snowflake> rolesValue = instance.roles();
/* 277 */       if (rolesValue != null) {
/* 278 */         addAllRoles(rolesValue);
/*     */       }
/* 280 */       Boolean computePruneCountValue = instance.computePruneCount();
/* 281 */       if (computePruneCountValue != null) {
/* 282 */         computePruneCount(computePruneCountValue);
/*     */       }
/* 284 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder reason(@Nullable String reason) {
/* 294 */       this.reason = reason;
/* 295 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder days(Integer days) {
/* 305 */       this.days = Objects.<Integer>requireNonNull(days, "days");
/* 306 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 307 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder addRole(Snowflake element) {
/* 317 */       if (this.roles == null) {
/* 318 */         this.roles = new ArrayList<>();
/*     */       }
/* 320 */       this.roles.add(Objects.<Snowflake>requireNonNull(element, "roles element"));
/* 321 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder addRoles(Snowflake... elements) {
/* 331 */       if (this.roles == null) {
/* 332 */         this.roles = new ArrayList<>();
/*     */       }
/* 334 */       for (Snowflake element : elements) {
/* 335 */         this.roles.add(Objects.<Snowflake>requireNonNull(element, "roles element"));
/*     */       }
/* 337 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder roles(@Nullable Iterable<? extends Snowflake> elements) {
/* 348 */       if (elements == null) {
/* 349 */         this.roles = null;
/* 350 */         return this;
/*     */       } 
/* 352 */       this.roles = new ArrayList<>();
/* 353 */       return addAllRoles(elements);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder addAllRoles(Iterable<? extends Snowflake> elements) {
/* 363 */       Objects.requireNonNull(elements, "roles element");
/* 364 */       if (this.roles == null) {
/* 365 */         this.roles = new ArrayList<>();
/*     */       }
/* 367 */       for (Snowflake element : elements) {
/* 368 */         this.roles.add(Objects.<Snowflake>requireNonNull(element, "roles element"));
/*     */       }
/* 370 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder computePruneCount(@Nullable Boolean computePruneCount) {
/* 380 */       this.computePruneCount = computePruneCount;
/* 381 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public GuildPruneSpec build() {
/* 390 */       if (this.initBits != 0L) {
/* 391 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 393 */       return new GuildPruneSpec(this.reason, this.days, (this.roles == null) ? null : GuildPruneSpec.createUnmodifiableSet((List)this.roles), this.computePruneCount);
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 397 */       List<String> attributes = new ArrayList<>();
/* 398 */       if ((this.initBits & 0x1L) != 0L) attributes.add("days"); 
/* 399 */       return "Cannot build GuildPruneSpec, some of required attributes are not set " + attributes;
/*     */     }
/*     */     private Builder() {} }
/*     */   
/*     */   private static <T> List<T> createSafeList(Iterable<? extends T> iterable, boolean checkNulls, boolean skipNulls) {
/*     */     ArrayList<T> list;
/* 405 */     if (iterable instanceof Collection) {
/* 406 */       int size = ((Collection)iterable).size();
/* 407 */       if (size == 0) return Collections.emptyList(); 
/* 408 */       list = new ArrayList<>();
/*     */     } else {
/* 410 */       list = new ArrayList<>();
/*     */     } 
/* 412 */     for (T element : iterable) {
/* 413 */       if (skipNulls && element == null)
/* 414 */         continue;  if (checkNulls) Objects.requireNonNull(element, "element"); 
/* 415 */       list.add(element);
/*     */     } 
/* 417 */     return list;
/*     */   }
/*     */ 
/*     */   
/*     */   private static <T> Set<T> createUnmodifiableSet(List<T> list) {
/* 422 */     switch (list.size()) { case 0:
/* 423 */         return Collections.emptySet();
/* 424 */       case 1: return Collections.singleton(list.get(0)); }
/*     */     
/* 426 */     Set<T> set = new LinkedHashSet<>(list.size());
/* 427 */     set.addAll(list);
/* 428 */     return Collections.unmodifiableSet(set);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\GuildPruneSpec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */