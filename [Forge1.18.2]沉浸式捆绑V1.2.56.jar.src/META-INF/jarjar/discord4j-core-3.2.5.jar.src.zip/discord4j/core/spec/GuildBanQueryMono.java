/*     */ package discord4j.core.spec;
/*     */ 
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.object.entity.Guild;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "GuildBanQueryMonoGenerator", generator = "Immutables")
/*     */ public final class GuildBanQueryMono
/*     */   extends GuildBanQueryMonoGenerator
/*     */ {
/*     */   @Nullable
/*     */   private final String reason;
/*     */   @Nullable
/*     */   private final Integer deleteMessageSeconds;
/*     */   @Nullable
/*     */   private final Integer deleteMessageDays;
/*     */   private final Snowflake userId;
/*     */   private final Guild guild;
/*     */   
/*     */   private GuildBanQueryMono(Snowflake userId, Guild guild) {
/*  27 */     this.userId = Objects.<Snowflake>requireNonNull(userId, "userId");
/*  28 */     this.guild = Objects.<Guild>requireNonNull(guild, "guild");
/*  29 */     this.reason = null;
/*  30 */     this.deleteMessageSeconds = null;
/*  31 */     this.deleteMessageDays = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private GuildBanQueryMono(@Nullable String reason, @Nullable Integer deleteMessageSeconds, @Nullable Integer deleteMessageDays, Snowflake userId, Guild guild) {
/*  40 */     this.reason = reason;
/*  41 */     this.deleteMessageSeconds = deleteMessageSeconds;
/*  42 */     this.deleteMessageDays = deleteMessageDays;
/*  43 */     this.userId = userId;
/*  44 */     this.guild = guild;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String reason() {
/*  53 */     return this.reason;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Integer deleteMessageSeconds() {
/*  61 */     return this.deleteMessageSeconds;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @Nullable
/*     */   public Integer deleteMessageDays() {
/*  70 */     return this.deleteMessageDays;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Snowflake userId() {
/*  78 */     return this.userId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Guild guild() {
/*  86 */     return this.guild;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final GuildBanQueryMono withReason(@Nullable String value) {
/*  96 */     if (Objects.equals(this.reason, value)) return this; 
/*  97 */     return new GuildBanQueryMono(value, this.deleteMessageSeconds, this.deleteMessageDays, this.userId, this.guild);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final GuildBanQueryMono withDeleteMessageSeconds(@Nullable Integer value) {
/* 107 */     if (Objects.equals(this.deleteMessageSeconds, value)) return this; 
/* 108 */     return new GuildBanQueryMono(this.reason, value, this.deleteMessageDays, this.userId, this.guild);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public final GuildBanQueryMono withDeleteMessageDays(@Nullable Integer value) {
/* 119 */     if (Objects.equals(this.deleteMessageDays, value)) return this; 
/* 120 */     return new GuildBanQueryMono(this.reason, this.deleteMessageSeconds, value, this.userId, this.guild);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final GuildBanQueryMono withUserId(Snowflake value) {
/* 130 */     if (this.userId == value) return this; 
/* 131 */     Snowflake newValue = Objects.<Snowflake>requireNonNull(value, "userId");
/* 132 */     return new GuildBanQueryMono(this.reason, this.deleteMessageSeconds, this.deleteMessageDays, newValue, this.guild);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final GuildBanQueryMono withGuild(Guild value) {
/* 142 */     if (this.guild == value) return this; 
/* 143 */     Guild newValue = Objects.<Guild>requireNonNull(value, "guild");
/* 144 */     return new GuildBanQueryMono(this.reason, this.deleteMessageSeconds, this.deleteMessageDays, this.userId, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 153 */     if (this == another) return true; 
/* 154 */     return (another instanceof GuildBanQueryMono && 
/* 155 */       equalTo(0, (GuildBanQueryMono)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, GuildBanQueryMono another) {
/* 159 */     return (Objects.equals(this.reason, another.reason) && 
/* 160 */       Objects.equals(this.deleteMessageSeconds, another.deleteMessageSeconds) && 
/* 161 */       Objects.equals(this.deleteMessageDays, another.deleteMessageDays) && this.userId
/* 162 */       .equals(another.userId) && this.guild
/* 163 */       .equals(another.guild));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 172 */     int h = 5381;
/* 173 */     h += (h << 5) + Objects.hashCode(this.reason);
/* 174 */     h += (h << 5) + Objects.hashCode(this.deleteMessageSeconds);
/* 175 */     h += (h << 5) + Objects.hashCode(this.deleteMessageDays);
/* 176 */     h += (h << 5) + this.userId.hashCode();
/* 177 */     h += (h << 5) + this.guild.hashCode();
/* 178 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 187 */     return "GuildBanQueryMono{reason=" + this.reason + ", deleteMessageSeconds=" + this.deleteMessageSeconds + ", deleteMessageDays=" + this.deleteMessageDays + ", userId=" + this.userId + ", guild=" + this.guild + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static GuildBanQueryMono of(Snowflake userId, Guild guild) {
/* 203 */     return new GuildBanQueryMono(userId, guild);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static GuildBanQueryMono copyOf(GuildBanQueryMonoGenerator instance) {
/* 214 */     if (instance instanceof GuildBanQueryMono) {
/* 215 */       return (GuildBanQueryMono)instance;
/*     */     }
/* 217 */     return of(instance.userId(), instance.guild())
/* 218 */       .withReason(instance.reason())
/* 219 */       .withDeleteMessageSeconds(instance.deleteMessageSeconds())
/* 220 */       .withDeleteMessageDays(instance.deleteMessageDays());
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\GuildBanQueryMono.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */