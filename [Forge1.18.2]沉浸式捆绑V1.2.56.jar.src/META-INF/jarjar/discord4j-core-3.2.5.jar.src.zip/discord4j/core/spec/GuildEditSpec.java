/*      */ package discord4j.core.spec;
/*      */ 
/*      */ import com.google.errorprone.annotations.CanIgnoreReturnValue;
/*      */ import discord4j.common.util.Snowflake;
/*      */ import discord4j.core.object.Region;
/*      */ import discord4j.core.object.entity.Guild;
/*      */ import discord4j.discordjson.possible.Possible;
/*      */ import discord4j.rest.util.Image;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.Objects;
/*      */ import java.util.Optional;
/*      */ import java.util.stream.Collectors;
/*      */ import java.util.stream.StreamSupport;
/*      */ import org.immutables.value.Generated;
/*      */ import reactor.util.annotation.Nullable;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ @Generated(from = "GuildEditSpecGenerator", generator = "Immutables")
/*      */ public final class GuildEditSpec
/*      */   implements GuildEditSpecGenerator
/*      */ {
/*      */   @Nullable
/*      */   private final String reason;
/*      */   private final String name_value;
/*      */   private final boolean name_absent;
/*      */   private final Region region_value;
/*      */   private final boolean region_absent;
/*      */   private final Guild.VerificationLevel verificationLevel_value;
/*      */   private final boolean verificationLevel_absent;
/*      */   private final Guild.NotificationLevel defaultMessageNotificationsLevel_value;
/*      */   private final boolean defaultMessageNotificationsLevel_absent;
/*      */   private final Guild.ContentFilterLevel explicitContentFilter_value;
/*      */   private final boolean explicitContentFilter_absent;
/*      */   private final Snowflake afkChannelId_value;
/*      */   private final boolean afkChannelId_absent;
/*      */   private final Integer afkTimeout_value;
/*      */   private final boolean afkTimeout_absent;
/*      */   private final Image icon_value;
/*      */   private final boolean icon_absent;
/*      */   private final Snowflake ownerId_value;
/*      */   private final boolean ownerId_absent;
/*      */   private final Image splash_value;
/*      */   private final boolean splash_absent;
/*      */   private final Image discoverySplash_value;
/*      */   private final boolean discoverySplash_absent;
/*      */   private final Image banner_value;
/*      */   private final boolean banner_absent;
/*      */   private final Snowflake systemChannelId_value;
/*      */   private final boolean systemChannelId_absent;
/*      */   private final Guild.SystemChannelFlag systemChannelFlags_value;
/*      */   private final boolean systemChannelFlags_absent;
/*      */   private final Snowflake rulesChannelId_value;
/*      */   private final boolean rulesChannelId_absent;
/*      */   private final Snowflake publicUpdatesChannelId_value;
/*      */   private final boolean publicUpdatesChannelId_absent;
/*      */   private final Locale preferredLocale_value;
/*      */   private final boolean preferredLocale_absent;
/*      */   private final List<String> features_value;
/*      */   private final boolean features_absent;
/*      */   private final String description_value;
/*      */   private final boolean description_absent;
/*      */   private final Snowflake safetyAlertsChannelId_value;
/*      */   private final boolean safetyAlertsChannelId_absent;
/*      */   private static final byte STAGE_INITIALIZING = -1;
/*      */   private static final byte STAGE_UNINITIALIZED = 0;
/*      */   private static final byte STAGE_INITIALIZED = 1;
/*      */   
/*      */   private GuildEditSpec() {
/*   76 */     this.reason = null;
/*   77 */     Possible<String> name$impl = Possible.absent();
/*   78 */     Possible<Optional<Region>> region$impl = Possible.absent();
/*   79 */     Possible<Optional<Guild.VerificationLevel>> verificationLevel$impl = Possible.absent();
/*   80 */     Possible<Optional<Guild.NotificationLevel>> defaultMessageNotificationsLevel$impl = Possible.absent();
/*   81 */     Possible<Optional<Guild.ContentFilterLevel>> explicitContentFilter$impl = Possible.absent();
/*   82 */     Possible<Optional<Snowflake>> afkChannelId$impl = Possible.absent();
/*   83 */     Possible<Integer> afkTimeout$impl = Possible.absent();
/*   84 */     Possible<Optional<Image>> icon$impl = Possible.absent();
/*   85 */     Possible<Snowflake> ownerId$impl = Possible.absent();
/*   86 */     Possible<Optional<Image>> splash$impl = Possible.absent();
/*   87 */     Possible<Optional<Image>> discoverySplash$impl = Possible.absent();
/*   88 */     Possible<Optional<Image>> banner$impl = Possible.absent();
/*   89 */     Possible<Optional<Snowflake>> systemChannelId$impl = Possible.absent();
/*   90 */     Possible<Guild.SystemChannelFlag> systemChannelFlags$impl = Possible.absent();
/*   91 */     Possible<Optional<Snowflake>> rulesChannelId$impl = Possible.absent();
/*   92 */     Possible<Optional<Snowflake>> publicUpdatesChannelId$impl = Possible.absent();
/*   93 */     Possible<Optional<Locale>> preferredLocale$impl = Possible.absent();
/*   94 */     Possible<List<String>> features$impl = Possible.absent();
/*   95 */     Possible<Optional<String>> description$impl = Possible.absent();
/*   96 */     Possible<Optional<Snowflake>> safetyAlertsChannelId$impl = Possible.absent();
/*   97 */     this.name_value = name$impl.toOptional().orElse(null);
/*   98 */     this.name_absent = name$impl.isAbsent();
/*   99 */     this.region_value = Possible.flatOpt(region$impl).orElse(null);
/*  100 */     this.region_absent = region$impl.isAbsent();
/*  101 */     this.verificationLevel_value = Possible.flatOpt(verificationLevel$impl).orElse(null);
/*  102 */     this.verificationLevel_absent = verificationLevel$impl.isAbsent();
/*  103 */     this.defaultMessageNotificationsLevel_value = Possible.flatOpt(defaultMessageNotificationsLevel$impl).orElse(null);
/*  104 */     this.defaultMessageNotificationsLevel_absent = defaultMessageNotificationsLevel$impl.isAbsent();
/*  105 */     this.explicitContentFilter_value = Possible.flatOpt(explicitContentFilter$impl).orElse(null);
/*  106 */     this.explicitContentFilter_absent = explicitContentFilter$impl.isAbsent();
/*  107 */     this.afkChannelId_value = Possible.flatOpt(afkChannelId$impl).orElse(null);
/*  108 */     this.afkChannelId_absent = afkChannelId$impl.isAbsent();
/*  109 */     this.afkTimeout_value = afkTimeout$impl.toOptional().orElse(null);
/*  110 */     this.afkTimeout_absent = afkTimeout$impl.isAbsent();
/*  111 */     this.icon_value = Possible.flatOpt(icon$impl).orElse(null);
/*  112 */     this.icon_absent = icon$impl.isAbsent();
/*  113 */     this.ownerId_value = ownerId$impl.toOptional().orElse(null);
/*  114 */     this.ownerId_absent = ownerId$impl.isAbsent();
/*  115 */     this.splash_value = Possible.flatOpt(splash$impl).orElse(null);
/*  116 */     this.splash_absent = splash$impl.isAbsent();
/*  117 */     this.discoverySplash_value = Possible.flatOpt(discoverySplash$impl).orElse(null);
/*  118 */     this.discoverySplash_absent = discoverySplash$impl.isAbsent();
/*  119 */     this.banner_value = Possible.flatOpt(banner$impl).orElse(null);
/*  120 */     this.banner_absent = banner$impl.isAbsent();
/*  121 */     this.systemChannelId_value = Possible.flatOpt(systemChannelId$impl).orElse(null);
/*  122 */     this.systemChannelId_absent = systemChannelId$impl.isAbsent();
/*  123 */     this.systemChannelFlags_value = systemChannelFlags$impl.toOptional().orElse(null);
/*  124 */     this.systemChannelFlags_absent = systemChannelFlags$impl.isAbsent();
/*  125 */     this.rulesChannelId_value = Possible.flatOpt(rulesChannelId$impl).orElse(null);
/*  126 */     this.rulesChannelId_absent = rulesChannelId$impl.isAbsent();
/*  127 */     this.publicUpdatesChannelId_value = Possible.flatOpt(publicUpdatesChannelId$impl).orElse(null);
/*  128 */     this.publicUpdatesChannelId_absent = publicUpdatesChannelId$impl.isAbsent();
/*  129 */     this.preferredLocale_value = Possible.flatOpt(preferredLocale$impl).orElse(null);
/*  130 */     this.preferredLocale_absent = preferredLocale$impl.isAbsent();
/*  131 */     this.features_value = features$impl.toOptional().orElse(null);
/*  132 */     this.features_absent = features$impl.isAbsent();
/*  133 */     this.description_value = Possible.flatOpt(description$impl).orElse(null);
/*  134 */     this.description_absent = description$impl.isAbsent();
/*  135 */     this.safetyAlertsChannelId_value = Possible.flatOpt(safetyAlertsChannelId$impl).orElse(null);
/*  136 */     this.safetyAlertsChannelId_absent = safetyAlertsChannelId$impl.isAbsent();
/*  137 */     this.initShim = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private GuildEditSpec(@Nullable String reason, Possible<String> name, Possible<Optional<Region>> region, Possible<Optional<Guild.VerificationLevel>> verificationLevel, Possible<Optional<Guild.NotificationLevel>> defaultMessageNotificationsLevel, Possible<Optional<Guild.ContentFilterLevel>> explicitContentFilter, Possible<Optional<Snowflake>> afkChannelId, Possible<Integer> afkTimeout, Possible<Optional<Image>> icon, Possible<Snowflake> ownerId, Possible<Optional<Image>> splash, Possible<Optional<Image>> discoverySplash, Possible<Optional<Image>> banner, Possible<Optional<Snowflake>> systemChannelId, Possible<Guild.SystemChannelFlag> systemChannelFlags, Possible<Optional<Snowflake>> rulesChannelId, Possible<Optional<Snowflake>> publicUpdatesChannelId, Possible<Optional<Locale>> preferredLocale, Possible<List<String>> features, Possible<Optional<String>> description, Possible<Optional<Snowflake>> safetyAlertsChannelId) {
/*  162 */     this.reason = reason;
/*  163 */     Possible<String> name$impl = name;
/*  164 */     Possible<Optional<Region>> region$impl = region;
/*  165 */     Possible<Optional<Guild.VerificationLevel>> verificationLevel$impl = verificationLevel;
/*  166 */     Possible<Optional<Guild.NotificationLevel>> defaultMessageNotificationsLevel$impl = defaultMessageNotificationsLevel;
/*  167 */     Possible<Optional<Guild.ContentFilterLevel>> explicitContentFilter$impl = explicitContentFilter;
/*  168 */     Possible<Optional<Snowflake>> afkChannelId$impl = afkChannelId;
/*  169 */     Possible<Integer> afkTimeout$impl = afkTimeout;
/*  170 */     Possible<Optional<Image>> icon$impl = icon;
/*  171 */     Possible<Snowflake> ownerId$impl = ownerId;
/*  172 */     Possible<Optional<Image>> splash$impl = splash;
/*  173 */     Possible<Optional<Image>> discoverySplash$impl = discoverySplash;
/*  174 */     Possible<Optional<Image>> banner$impl = banner;
/*  175 */     Possible<Optional<Snowflake>> systemChannelId$impl = systemChannelId;
/*  176 */     Possible<Guild.SystemChannelFlag> systemChannelFlags$impl = systemChannelFlags;
/*  177 */     Possible<Optional<Snowflake>> rulesChannelId$impl = rulesChannelId;
/*  178 */     Possible<Optional<Snowflake>> publicUpdatesChannelId$impl = publicUpdatesChannelId;
/*  179 */     Possible<Optional<Locale>> preferredLocale$impl = preferredLocale;
/*  180 */     Possible<List<String>> features$impl = features;
/*  181 */     Possible<Optional<String>> description$impl = description;
/*  182 */     Possible<Optional<Snowflake>> safetyAlertsChannelId$impl = safetyAlertsChannelId;
/*  183 */     this.name_value = name$impl.toOptional().orElse(null);
/*  184 */     this.name_absent = name$impl.isAbsent();
/*  185 */     this.region_value = Possible.flatOpt(region$impl).orElse(null);
/*  186 */     this.region_absent = region$impl.isAbsent();
/*  187 */     this.verificationLevel_value = Possible.flatOpt(verificationLevel$impl).orElse(null);
/*  188 */     this.verificationLevel_absent = verificationLevel$impl.isAbsent();
/*  189 */     this.defaultMessageNotificationsLevel_value = Possible.flatOpt(defaultMessageNotificationsLevel$impl).orElse(null);
/*  190 */     this.defaultMessageNotificationsLevel_absent = defaultMessageNotificationsLevel$impl.isAbsent();
/*  191 */     this.explicitContentFilter_value = Possible.flatOpt(explicitContentFilter$impl).orElse(null);
/*  192 */     this.explicitContentFilter_absent = explicitContentFilter$impl.isAbsent();
/*  193 */     this.afkChannelId_value = Possible.flatOpt(afkChannelId$impl).orElse(null);
/*  194 */     this.afkChannelId_absent = afkChannelId$impl.isAbsent();
/*  195 */     this.afkTimeout_value = afkTimeout$impl.toOptional().orElse(null);
/*  196 */     this.afkTimeout_absent = afkTimeout$impl.isAbsent();
/*  197 */     this.icon_value = Possible.flatOpt(icon$impl).orElse(null);
/*  198 */     this.icon_absent = icon$impl.isAbsent();
/*  199 */     this.ownerId_value = ownerId$impl.toOptional().orElse(null);
/*  200 */     this.ownerId_absent = ownerId$impl.isAbsent();
/*  201 */     this.splash_value = Possible.flatOpt(splash$impl).orElse(null);
/*  202 */     this.splash_absent = splash$impl.isAbsent();
/*  203 */     this.discoverySplash_value = Possible.flatOpt(discoverySplash$impl).orElse(null);
/*  204 */     this.discoverySplash_absent = discoverySplash$impl.isAbsent();
/*  205 */     this.banner_value = Possible.flatOpt(banner$impl).orElse(null);
/*  206 */     this.banner_absent = banner$impl.isAbsent();
/*  207 */     this.systemChannelId_value = Possible.flatOpt(systemChannelId$impl).orElse(null);
/*  208 */     this.systemChannelId_absent = systemChannelId$impl.isAbsent();
/*  209 */     this.systemChannelFlags_value = systemChannelFlags$impl.toOptional().orElse(null);
/*  210 */     this.systemChannelFlags_absent = systemChannelFlags$impl.isAbsent();
/*  211 */     this.rulesChannelId_value = Possible.flatOpt(rulesChannelId$impl).orElse(null);
/*  212 */     this.rulesChannelId_absent = rulesChannelId$impl.isAbsent();
/*  213 */     this.publicUpdatesChannelId_value = Possible.flatOpt(publicUpdatesChannelId$impl).orElse(null);
/*  214 */     this.publicUpdatesChannelId_absent = publicUpdatesChannelId$impl.isAbsent();
/*  215 */     this.preferredLocale_value = Possible.flatOpt(preferredLocale$impl).orElse(null);
/*  216 */     this.preferredLocale_absent = preferredLocale$impl.isAbsent();
/*  217 */     this.features_value = features$impl.toOptional().orElse(null);
/*  218 */     this.features_absent = features$impl.isAbsent();
/*  219 */     this.description_value = Possible.flatOpt(description$impl).orElse(null);
/*  220 */     this.description_absent = description$impl.isAbsent();
/*  221 */     this.safetyAlertsChannelId_value = Possible.flatOpt(safetyAlertsChannelId$impl).orElse(null);
/*  222 */     this.safetyAlertsChannelId_absent = safetyAlertsChannelId$impl.isAbsent();
/*  223 */     this.initShim = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  229 */   private volatile transient InitShim initShim = new InitShim();
/*      */   
/*      */   @Generated(from = "GuildEditSpecGenerator", generator = "Immutables")
/*      */   private final class InitShim
/*      */   {
/*      */     private String formatInitCycleMessage() {
/*  235 */       List<String> attributes = new ArrayList<>();
/*  236 */       return "Cannot build GuildEditSpec, attribute initializers form cycle " + attributes;
/*      */     }
/*      */ 
/*      */     
/*      */     private InitShim() {}
/*      */   }
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public String reason() {
/*  246 */     return this.reason;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Possible<String> name() {
/*  254 */     return this.name_absent ? Possible.absent() : Possible.of(this.name_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Possible<Optional<Region>> region() {
/*  262 */     return this.region_absent ? Possible.absent() : 
/*  263 */       Possible.of(Optional.ofNullable(this.region_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Possible<Optional<Guild.VerificationLevel>> verificationLevel() {
/*  271 */     return this.verificationLevel_absent ? Possible.absent() : 
/*  272 */       Possible.of(Optional.ofNullable(this.verificationLevel_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Possible<Optional<Guild.NotificationLevel>> defaultMessageNotificationsLevel() {
/*  280 */     return this.defaultMessageNotificationsLevel_absent ? Possible.absent() : 
/*  281 */       Possible.of(Optional.ofNullable(this.defaultMessageNotificationsLevel_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Possible<Optional<Guild.ContentFilterLevel>> explicitContentFilter() {
/*  289 */     return this.explicitContentFilter_absent ? Possible.absent() : 
/*  290 */       Possible.of(Optional.ofNullable(this.explicitContentFilter_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Possible<Optional<Snowflake>> afkChannelId() {
/*  298 */     return this.afkChannelId_absent ? Possible.absent() : 
/*  299 */       Possible.of(Optional.ofNullable(this.afkChannelId_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Possible<Integer> afkTimeout() {
/*  307 */     return this.afkTimeout_absent ? Possible.absent() : Possible.of(this.afkTimeout_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Possible<Optional<Image>> icon() {
/*  315 */     return this.icon_absent ? Possible.absent() : 
/*  316 */       Possible.of(Optional.ofNullable(this.icon_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Possible<Snowflake> ownerId() {
/*  324 */     return this.ownerId_absent ? Possible.absent() : Possible.of(this.ownerId_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Possible<Optional<Image>> splash() {
/*  332 */     return this.splash_absent ? Possible.absent() : 
/*  333 */       Possible.of(Optional.ofNullable(this.splash_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Possible<Optional<Image>> discoverySplash() {
/*  341 */     return this.discoverySplash_absent ? Possible.absent() : 
/*  342 */       Possible.of(Optional.ofNullable(this.discoverySplash_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Possible<Optional<Image>> banner() {
/*  350 */     return this.banner_absent ? Possible.absent() : 
/*  351 */       Possible.of(Optional.ofNullable(this.banner_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Possible<Optional<Snowflake>> systemChannelId() {
/*  359 */     return this.systemChannelId_absent ? Possible.absent() : 
/*  360 */       Possible.of(Optional.ofNullable(this.systemChannelId_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Possible<Guild.SystemChannelFlag> systemChannelFlags() {
/*  368 */     return this.systemChannelFlags_absent ? Possible.absent() : Possible.of(this.systemChannelFlags_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Possible<Optional<Snowflake>> rulesChannelId() {
/*  376 */     return this.rulesChannelId_absent ? Possible.absent() : 
/*  377 */       Possible.of(Optional.ofNullable(this.rulesChannelId_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Possible<Optional<Snowflake>> publicUpdatesChannelId() {
/*  385 */     return this.publicUpdatesChannelId_absent ? Possible.absent() : 
/*  386 */       Possible.of(Optional.ofNullable(this.publicUpdatesChannelId_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Possible<Optional<Locale>> preferredLocale() {
/*  394 */     return this.preferredLocale_absent ? Possible.absent() : 
/*  395 */       Possible.of(Optional.ofNullable(this.preferredLocale_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Possible<List<String>> features() {
/*  403 */     return this.features_absent ? Possible.absent() : 
/*  404 */       Possible.of(this.features_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Possible<Optional<String>> description() {
/*  412 */     return this.description_absent ? Possible.absent() : 
/*  413 */       Possible.of(Optional.ofNullable(this.description_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Possible<Optional<Snowflake>> safetyAlertsChannelId() {
/*  421 */     return this.safetyAlertsChannelId_absent ? Possible.absent() : 
/*  422 */       Possible.of(Optional.ofNullable(this.safetyAlertsChannelId_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final GuildEditSpec withReason(@Nullable String value) {
/*  432 */     if (Objects.equals(this.reason, value)) return this; 
/*  433 */     return validate(new GuildEditSpec(value, 
/*      */           
/*  435 */           name(), 
/*  436 */           region(), 
/*  437 */           verificationLevel(), 
/*  438 */           defaultMessageNotificationsLevel(), 
/*  439 */           explicitContentFilter(), 
/*  440 */           afkChannelId(), 
/*  441 */           afkTimeout(), 
/*  442 */           icon(), 
/*  443 */           ownerId(), 
/*  444 */           splash(), 
/*  445 */           discoverySplash(), 
/*  446 */           banner(), 
/*  447 */           systemChannelId(), 
/*  448 */           systemChannelFlags(), 
/*  449 */           rulesChannelId(), 
/*  450 */           publicUpdatesChannelId(), 
/*  451 */           preferredLocale(), 
/*  452 */           features(), 
/*  453 */           description(), 
/*  454 */           safetyAlertsChannelId()));
/*      */   }
/*      */   
/*      */   public GuildEditSpec withName(Possible<String> value) {
/*  458 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/*  459 */     return validate(new GuildEditSpec(this.reason, newValue, 
/*      */ 
/*      */           
/*  462 */           region(), 
/*  463 */           verificationLevel(), 
/*  464 */           defaultMessageNotificationsLevel(), 
/*  465 */           explicitContentFilter(), 
/*  466 */           afkChannelId(), 
/*  467 */           afkTimeout(), 
/*  468 */           icon(), 
/*  469 */           ownerId(), 
/*  470 */           splash(), 
/*  471 */           discoverySplash(), 
/*  472 */           banner(), 
/*  473 */           systemChannelId(), 
/*  474 */           systemChannelFlags(), 
/*  475 */           rulesChannelId(), 
/*  476 */           publicUpdatesChannelId(), 
/*  477 */           preferredLocale(), 
/*  478 */           features(), 
/*  479 */           description(), 
/*  480 */           safetyAlertsChannelId()));
/*      */   }
/*      */   
/*      */   public GuildEditSpec withName(String value) {
/*  484 */     Possible<String> newValue = Possible.of(value);
/*  485 */     return validate(new GuildEditSpec(this.reason, newValue, 
/*      */ 
/*      */           
/*  488 */           region(), 
/*  489 */           verificationLevel(), 
/*  490 */           defaultMessageNotificationsLevel(), 
/*  491 */           explicitContentFilter(), 
/*  492 */           afkChannelId(), 
/*  493 */           afkTimeout(), 
/*  494 */           icon(), 
/*  495 */           ownerId(), 
/*  496 */           splash(), 
/*  497 */           discoverySplash(), 
/*  498 */           banner(), 
/*  499 */           systemChannelId(), 
/*  500 */           systemChannelFlags(), 
/*  501 */           rulesChannelId(), 
/*  502 */           publicUpdatesChannelId(), 
/*  503 */           preferredLocale(), 
/*  504 */           features(), 
/*  505 */           description(), 
/*  506 */           safetyAlertsChannelId()));
/*      */   }
/*      */   
/*      */   public GuildEditSpec withRegion(Possible<Optional<Region>> value) {
/*  510 */     Possible<Optional<Region>> newValue = Objects.<Possible<Optional<Region>>>requireNonNull(value);
/*  511 */     return validate(new GuildEditSpec(this.reason, 
/*      */           
/*  513 */           name(), newValue, 
/*      */           
/*  515 */           verificationLevel(), 
/*  516 */           defaultMessageNotificationsLevel(), 
/*  517 */           explicitContentFilter(), 
/*  518 */           afkChannelId(), 
/*  519 */           afkTimeout(), 
/*  520 */           icon(), 
/*  521 */           ownerId(), 
/*  522 */           splash(), 
/*  523 */           discoverySplash(), 
/*  524 */           banner(), 
/*  525 */           systemChannelId(), 
/*  526 */           systemChannelFlags(), 
/*  527 */           rulesChannelId(), 
/*  528 */           publicUpdatesChannelId(), 
/*  529 */           preferredLocale(), 
/*  530 */           features(), 
/*  531 */           description(), 
/*  532 */           safetyAlertsChannelId()));
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public GuildEditSpec withRegion(@Nullable Region value) {
/*  537 */     Possible<Optional<Region>> newValue = Possible.of(Optional.ofNullable(value));
/*  538 */     return validate(new GuildEditSpec(this.reason, 
/*      */           
/*  540 */           name(), newValue, 
/*      */           
/*  542 */           verificationLevel(), 
/*  543 */           defaultMessageNotificationsLevel(), 
/*  544 */           explicitContentFilter(), 
/*  545 */           afkChannelId(), 
/*  546 */           afkTimeout(), 
/*  547 */           icon(), 
/*  548 */           ownerId(), 
/*  549 */           splash(), 
/*  550 */           discoverySplash(), 
/*  551 */           banner(), 
/*  552 */           systemChannelId(), 
/*  553 */           systemChannelFlags(), 
/*  554 */           rulesChannelId(), 
/*  555 */           publicUpdatesChannelId(), 
/*  556 */           preferredLocale(), 
/*  557 */           features(), 
/*  558 */           description(), 
/*  559 */           safetyAlertsChannelId()));
/*      */   }
/*      */   
/*      */   public GuildEditSpec withRegionOrNull(@Nullable Region value) {
/*  563 */     Possible<Optional<Region>> newValue = Possible.of(Optional.ofNullable(value));
/*  564 */     return validate(new GuildEditSpec(this.reason, 
/*      */           
/*  566 */           name(), newValue, 
/*      */           
/*  568 */           verificationLevel(), 
/*  569 */           defaultMessageNotificationsLevel(), 
/*  570 */           explicitContentFilter(), 
/*  571 */           afkChannelId(), 
/*  572 */           afkTimeout(), 
/*  573 */           icon(), 
/*  574 */           ownerId(), 
/*  575 */           splash(), 
/*  576 */           discoverySplash(), 
/*  577 */           banner(), 
/*  578 */           systemChannelId(), 
/*  579 */           systemChannelFlags(), 
/*  580 */           rulesChannelId(), 
/*  581 */           publicUpdatesChannelId(), 
/*  582 */           preferredLocale(), 
/*  583 */           features(), 
/*  584 */           description(), 
/*  585 */           safetyAlertsChannelId()));
/*      */   }
/*      */   
/*      */   public GuildEditSpec withVerificationLevel(Possible<Optional<Guild.VerificationLevel>> value) {
/*  589 */     Possible<Optional<Guild.VerificationLevel>> newValue = Objects.<Possible<Optional<Guild.VerificationLevel>>>requireNonNull(value);
/*  590 */     return validate(new GuildEditSpec(this.reason, 
/*      */           
/*  592 */           name(), 
/*  593 */           region(), newValue, 
/*      */           
/*  595 */           defaultMessageNotificationsLevel(), 
/*  596 */           explicitContentFilter(), 
/*  597 */           afkChannelId(), 
/*  598 */           afkTimeout(), 
/*  599 */           icon(), 
/*  600 */           ownerId(), 
/*  601 */           splash(), 
/*  602 */           discoverySplash(), 
/*  603 */           banner(), 
/*  604 */           systemChannelId(), 
/*  605 */           systemChannelFlags(), 
/*  606 */           rulesChannelId(), 
/*  607 */           publicUpdatesChannelId(), 
/*  608 */           preferredLocale(), 
/*  609 */           features(), 
/*  610 */           description(), 
/*  611 */           safetyAlertsChannelId()));
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public GuildEditSpec withVerificationLevel(@Nullable Guild.VerificationLevel value) {
/*  616 */     Possible<Optional<Guild.VerificationLevel>> newValue = Possible.of(Optional.ofNullable(value));
/*  617 */     return validate(new GuildEditSpec(this.reason, 
/*      */           
/*  619 */           name(), 
/*  620 */           region(), newValue, 
/*      */           
/*  622 */           defaultMessageNotificationsLevel(), 
/*  623 */           explicitContentFilter(), 
/*  624 */           afkChannelId(), 
/*  625 */           afkTimeout(), 
/*  626 */           icon(), 
/*  627 */           ownerId(), 
/*  628 */           splash(), 
/*  629 */           discoverySplash(), 
/*  630 */           banner(), 
/*  631 */           systemChannelId(), 
/*  632 */           systemChannelFlags(), 
/*  633 */           rulesChannelId(), 
/*  634 */           publicUpdatesChannelId(), 
/*  635 */           preferredLocale(), 
/*  636 */           features(), 
/*  637 */           description(), 
/*  638 */           safetyAlertsChannelId()));
/*      */   }
/*      */   
/*      */   public GuildEditSpec withVerificationLevelOrNull(@Nullable Guild.VerificationLevel value) {
/*  642 */     Possible<Optional<Guild.VerificationLevel>> newValue = Possible.of(Optional.ofNullable(value));
/*  643 */     return validate(new GuildEditSpec(this.reason, 
/*      */           
/*  645 */           name(), 
/*  646 */           region(), newValue, 
/*      */           
/*  648 */           defaultMessageNotificationsLevel(), 
/*  649 */           explicitContentFilter(), 
/*  650 */           afkChannelId(), 
/*  651 */           afkTimeout(), 
/*  652 */           icon(), 
/*  653 */           ownerId(), 
/*  654 */           splash(), 
/*  655 */           discoverySplash(), 
/*  656 */           banner(), 
/*  657 */           systemChannelId(), 
/*  658 */           systemChannelFlags(), 
/*  659 */           rulesChannelId(), 
/*  660 */           publicUpdatesChannelId(), 
/*  661 */           preferredLocale(), 
/*  662 */           features(), 
/*  663 */           description(), 
/*  664 */           safetyAlertsChannelId()));
/*      */   }
/*      */   
/*      */   public GuildEditSpec withDefaultMessageNotificationsLevel(Possible<Optional<Guild.NotificationLevel>> value) {
/*  668 */     Possible<Optional<Guild.NotificationLevel>> newValue = Objects.<Possible<Optional<Guild.NotificationLevel>>>requireNonNull(value);
/*  669 */     return validate(new GuildEditSpec(this.reason, 
/*      */           
/*  671 */           name(), 
/*  672 */           region(), 
/*  673 */           verificationLevel(), newValue, 
/*      */           
/*  675 */           explicitContentFilter(), 
/*  676 */           afkChannelId(), 
/*  677 */           afkTimeout(), 
/*  678 */           icon(), 
/*  679 */           ownerId(), 
/*  680 */           splash(), 
/*  681 */           discoverySplash(), 
/*  682 */           banner(), 
/*  683 */           systemChannelId(), 
/*  684 */           systemChannelFlags(), 
/*  685 */           rulesChannelId(), 
/*  686 */           publicUpdatesChannelId(), 
/*  687 */           preferredLocale(), 
/*  688 */           features(), 
/*  689 */           description(), 
/*  690 */           safetyAlertsChannelId()));
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public GuildEditSpec withDefaultMessageNotificationsLevel(@Nullable Guild.NotificationLevel value) {
/*  695 */     Possible<Optional<Guild.NotificationLevel>> newValue = Possible.of(Optional.ofNullable(value));
/*  696 */     return validate(new GuildEditSpec(this.reason, 
/*      */           
/*  698 */           name(), 
/*  699 */           region(), 
/*  700 */           verificationLevel(), newValue, 
/*      */           
/*  702 */           explicitContentFilter(), 
/*  703 */           afkChannelId(), 
/*  704 */           afkTimeout(), 
/*  705 */           icon(), 
/*  706 */           ownerId(), 
/*  707 */           splash(), 
/*  708 */           discoverySplash(), 
/*  709 */           banner(), 
/*  710 */           systemChannelId(), 
/*  711 */           systemChannelFlags(), 
/*  712 */           rulesChannelId(), 
/*  713 */           publicUpdatesChannelId(), 
/*  714 */           preferredLocale(), 
/*  715 */           features(), 
/*  716 */           description(), 
/*  717 */           safetyAlertsChannelId()));
/*      */   }
/*      */   
/*      */   public GuildEditSpec withDefaultMessageNotificationsLevelOrNull(@Nullable Guild.NotificationLevel value) {
/*  721 */     Possible<Optional<Guild.NotificationLevel>> newValue = Possible.of(Optional.ofNullable(value));
/*  722 */     return validate(new GuildEditSpec(this.reason, 
/*      */           
/*  724 */           name(), 
/*  725 */           region(), 
/*  726 */           verificationLevel(), newValue, 
/*      */           
/*  728 */           explicitContentFilter(), 
/*  729 */           afkChannelId(), 
/*  730 */           afkTimeout(), 
/*  731 */           icon(), 
/*  732 */           ownerId(), 
/*  733 */           splash(), 
/*  734 */           discoverySplash(), 
/*  735 */           banner(), 
/*  736 */           systemChannelId(), 
/*  737 */           systemChannelFlags(), 
/*  738 */           rulesChannelId(), 
/*  739 */           publicUpdatesChannelId(), 
/*  740 */           preferredLocale(), 
/*  741 */           features(), 
/*  742 */           description(), 
/*  743 */           safetyAlertsChannelId()));
/*      */   }
/*      */   
/*      */   public GuildEditSpec withExplicitContentFilter(Possible<Optional<Guild.ContentFilterLevel>> value) {
/*  747 */     Possible<Optional<Guild.ContentFilterLevel>> newValue = Objects.<Possible<Optional<Guild.ContentFilterLevel>>>requireNonNull(value);
/*  748 */     return validate(new GuildEditSpec(this.reason, 
/*      */           
/*  750 */           name(), 
/*  751 */           region(), 
/*  752 */           verificationLevel(), 
/*  753 */           defaultMessageNotificationsLevel(), newValue, 
/*      */           
/*  755 */           afkChannelId(), 
/*  756 */           afkTimeout(), 
/*  757 */           icon(), 
/*  758 */           ownerId(), 
/*  759 */           splash(), 
/*  760 */           discoverySplash(), 
/*  761 */           banner(), 
/*  762 */           systemChannelId(), 
/*  763 */           systemChannelFlags(), 
/*  764 */           rulesChannelId(), 
/*  765 */           publicUpdatesChannelId(), 
/*  766 */           preferredLocale(), 
/*  767 */           features(), 
/*  768 */           description(), 
/*  769 */           safetyAlertsChannelId()));
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public GuildEditSpec withExplicitContentFilter(@Nullable Guild.ContentFilterLevel value) {
/*  774 */     Possible<Optional<Guild.ContentFilterLevel>> newValue = Possible.of(Optional.ofNullable(value));
/*  775 */     return validate(new GuildEditSpec(this.reason, 
/*      */           
/*  777 */           name(), 
/*  778 */           region(), 
/*  779 */           verificationLevel(), 
/*  780 */           defaultMessageNotificationsLevel(), newValue, 
/*      */           
/*  782 */           afkChannelId(), 
/*  783 */           afkTimeout(), 
/*  784 */           icon(), 
/*  785 */           ownerId(), 
/*  786 */           splash(), 
/*  787 */           discoverySplash(), 
/*  788 */           banner(), 
/*  789 */           systemChannelId(), 
/*  790 */           systemChannelFlags(), 
/*  791 */           rulesChannelId(), 
/*  792 */           publicUpdatesChannelId(), 
/*  793 */           preferredLocale(), 
/*  794 */           features(), 
/*  795 */           description(), 
/*  796 */           safetyAlertsChannelId()));
/*      */   }
/*      */   
/*      */   public GuildEditSpec withExplicitContentFilterOrNull(@Nullable Guild.ContentFilterLevel value) {
/*  800 */     Possible<Optional<Guild.ContentFilterLevel>> newValue = Possible.of(Optional.ofNullable(value));
/*  801 */     return validate(new GuildEditSpec(this.reason, 
/*      */           
/*  803 */           name(), 
/*  804 */           region(), 
/*  805 */           verificationLevel(), 
/*  806 */           defaultMessageNotificationsLevel(), newValue, 
/*      */           
/*  808 */           afkChannelId(), 
/*  809 */           afkTimeout(), 
/*  810 */           icon(), 
/*  811 */           ownerId(), 
/*  812 */           splash(), 
/*  813 */           discoverySplash(), 
/*  814 */           banner(), 
/*  815 */           systemChannelId(), 
/*  816 */           systemChannelFlags(), 
/*  817 */           rulesChannelId(), 
/*  818 */           publicUpdatesChannelId(), 
/*  819 */           preferredLocale(), 
/*  820 */           features(), 
/*  821 */           description(), 
/*  822 */           safetyAlertsChannelId()));
/*      */   }
/*      */   
/*      */   public GuildEditSpec withAfkChannelId(Possible<Optional<Snowflake>> value) {
/*  826 */     Possible<Optional<Snowflake>> newValue = Objects.<Possible<Optional<Snowflake>>>requireNonNull(value);
/*  827 */     return validate(new GuildEditSpec(this.reason, 
/*      */           
/*  829 */           name(), 
/*  830 */           region(), 
/*  831 */           verificationLevel(), 
/*  832 */           defaultMessageNotificationsLevel(), 
/*  833 */           explicitContentFilter(), newValue, 
/*      */           
/*  835 */           afkTimeout(), 
/*  836 */           icon(), 
/*  837 */           ownerId(), 
/*  838 */           splash(), 
/*  839 */           discoverySplash(), 
/*  840 */           banner(), 
/*  841 */           systemChannelId(), 
/*  842 */           systemChannelFlags(), 
/*  843 */           rulesChannelId(), 
/*  844 */           publicUpdatesChannelId(), 
/*  845 */           preferredLocale(), 
/*  846 */           features(), 
/*  847 */           description(), 
/*  848 */           safetyAlertsChannelId()));
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public GuildEditSpec withAfkChannelId(@Nullable Snowflake value) {
/*  853 */     Possible<Optional<Snowflake>> newValue = Possible.of(Optional.ofNullable(value));
/*  854 */     return validate(new GuildEditSpec(this.reason, 
/*      */           
/*  856 */           name(), 
/*  857 */           region(), 
/*  858 */           verificationLevel(), 
/*  859 */           defaultMessageNotificationsLevel(), 
/*  860 */           explicitContentFilter(), newValue, 
/*      */           
/*  862 */           afkTimeout(), 
/*  863 */           icon(), 
/*  864 */           ownerId(), 
/*  865 */           splash(), 
/*  866 */           discoverySplash(), 
/*  867 */           banner(), 
/*  868 */           systemChannelId(), 
/*  869 */           systemChannelFlags(), 
/*  870 */           rulesChannelId(), 
/*  871 */           publicUpdatesChannelId(), 
/*  872 */           preferredLocale(), 
/*  873 */           features(), 
/*  874 */           description(), 
/*  875 */           safetyAlertsChannelId()));
/*      */   }
/*      */   
/*      */   public GuildEditSpec withAfkChannelIdOrNull(@Nullable Snowflake value) {
/*  879 */     Possible<Optional<Snowflake>> newValue = Possible.of(Optional.ofNullable(value));
/*  880 */     return validate(new GuildEditSpec(this.reason, 
/*      */           
/*  882 */           name(), 
/*  883 */           region(), 
/*  884 */           verificationLevel(), 
/*  885 */           defaultMessageNotificationsLevel(), 
/*  886 */           explicitContentFilter(), newValue, 
/*      */           
/*  888 */           afkTimeout(), 
/*  889 */           icon(), 
/*  890 */           ownerId(), 
/*  891 */           splash(), 
/*  892 */           discoverySplash(), 
/*  893 */           banner(), 
/*  894 */           systemChannelId(), 
/*  895 */           systemChannelFlags(), 
/*  896 */           rulesChannelId(), 
/*  897 */           publicUpdatesChannelId(), 
/*  898 */           preferredLocale(), 
/*  899 */           features(), 
/*  900 */           description(), 
/*  901 */           safetyAlertsChannelId()));
/*      */   }
/*      */   
/*      */   public GuildEditSpec withAfkTimeout(Possible<Integer> value) {
/*  905 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/*  906 */     return validate(new GuildEditSpec(this.reason, 
/*      */           
/*  908 */           name(), 
/*  909 */           region(), 
/*  910 */           verificationLevel(), 
/*  911 */           defaultMessageNotificationsLevel(), 
/*  912 */           explicitContentFilter(), 
/*  913 */           afkChannelId(), newValue, 
/*      */           
/*  915 */           icon(), 
/*  916 */           ownerId(), 
/*  917 */           splash(), 
/*  918 */           discoverySplash(), 
/*  919 */           banner(), 
/*  920 */           systemChannelId(), 
/*  921 */           systemChannelFlags(), 
/*  922 */           rulesChannelId(), 
/*  923 */           publicUpdatesChannelId(), 
/*  924 */           preferredLocale(), 
/*  925 */           features(), 
/*  926 */           description(), 
/*  927 */           safetyAlertsChannelId()));
/*      */   }
/*      */   
/*      */   public GuildEditSpec withAfkTimeout(Integer value) {
/*  931 */     Possible<Integer> newValue = Possible.of(value);
/*  932 */     return validate(new GuildEditSpec(this.reason, 
/*      */           
/*  934 */           name(), 
/*  935 */           region(), 
/*  936 */           verificationLevel(), 
/*  937 */           defaultMessageNotificationsLevel(), 
/*  938 */           explicitContentFilter(), 
/*  939 */           afkChannelId(), newValue, 
/*      */           
/*  941 */           icon(), 
/*  942 */           ownerId(), 
/*  943 */           splash(), 
/*  944 */           discoverySplash(), 
/*  945 */           banner(), 
/*  946 */           systemChannelId(), 
/*  947 */           systemChannelFlags(), 
/*  948 */           rulesChannelId(), 
/*  949 */           publicUpdatesChannelId(), 
/*  950 */           preferredLocale(), 
/*  951 */           features(), 
/*  952 */           description(), 
/*  953 */           safetyAlertsChannelId()));
/*      */   }
/*      */   
/*      */   public GuildEditSpec withIcon(Possible<Optional<Image>> value) {
/*  957 */     Possible<Optional<Image>> newValue = Objects.<Possible<Optional<Image>>>requireNonNull(value);
/*  958 */     return validate(new GuildEditSpec(this.reason, 
/*      */           
/*  960 */           name(), 
/*  961 */           region(), 
/*  962 */           verificationLevel(), 
/*  963 */           defaultMessageNotificationsLevel(), 
/*  964 */           explicitContentFilter(), 
/*  965 */           afkChannelId(), 
/*  966 */           afkTimeout(), newValue, 
/*      */           
/*  968 */           ownerId(), 
/*  969 */           splash(), 
/*  970 */           discoverySplash(), 
/*  971 */           banner(), 
/*  972 */           systemChannelId(), 
/*  973 */           systemChannelFlags(), 
/*  974 */           rulesChannelId(), 
/*  975 */           publicUpdatesChannelId(), 
/*  976 */           preferredLocale(), 
/*  977 */           features(), 
/*  978 */           description(), 
/*  979 */           safetyAlertsChannelId()));
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public GuildEditSpec withIcon(@Nullable Image value) {
/*  984 */     Possible<Optional<Image>> newValue = Possible.of(Optional.ofNullable(value));
/*  985 */     return validate(new GuildEditSpec(this.reason, 
/*      */           
/*  987 */           name(), 
/*  988 */           region(), 
/*  989 */           verificationLevel(), 
/*  990 */           defaultMessageNotificationsLevel(), 
/*  991 */           explicitContentFilter(), 
/*  992 */           afkChannelId(), 
/*  993 */           afkTimeout(), newValue, 
/*      */           
/*  995 */           ownerId(), 
/*  996 */           splash(), 
/*  997 */           discoverySplash(), 
/*  998 */           banner(), 
/*  999 */           systemChannelId(), 
/* 1000 */           systemChannelFlags(), 
/* 1001 */           rulesChannelId(), 
/* 1002 */           publicUpdatesChannelId(), 
/* 1003 */           preferredLocale(), 
/* 1004 */           features(), 
/* 1005 */           description(), 
/* 1006 */           safetyAlertsChannelId()));
/*      */   }
/*      */   
/*      */   public GuildEditSpec withIconOrNull(@Nullable Image value) {
/* 1010 */     Possible<Optional<Image>> newValue = Possible.of(Optional.ofNullable(value));
/* 1011 */     return validate(new GuildEditSpec(this.reason, 
/*      */           
/* 1013 */           name(), 
/* 1014 */           region(), 
/* 1015 */           verificationLevel(), 
/* 1016 */           defaultMessageNotificationsLevel(), 
/* 1017 */           explicitContentFilter(), 
/* 1018 */           afkChannelId(), 
/* 1019 */           afkTimeout(), newValue, 
/*      */           
/* 1021 */           ownerId(), 
/* 1022 */           splash(), 
/* 1023 */           discoverySplash(), 
/* 1024 */           banner(), 
/* 1025 */           systemChannelId(), 
/* 1026 */           systemChannelFlags(), 
/* 1027 */           rulesChannelId(), 
/* 1028 */           publicUpdatesChannelId(), 
/* 1029 */           preferredLocale(), 
/* 1030 */           features(), 
/* 1031 */           description(), 
/* 1032 */           safetyAlertsChannelId()));
/*      */   }
/*      */   
/*      */   public GuildEditSpec withOwnerId(Possible<Snowflake> value) {
/* 1036 */     Possible<Snowflake> newValue = Objects.<Possible<Snowflake>>requireNonNull(value);
/* 1037 */     return validate(new GuildEditSpec(this.reason, 
/*      */           
/* 1039 */           name(), 
/* 1040 */           region(), 
/* 1041 */           verificationLevel(), 
/* 1042 */           defaultMessageNotificationsLevel(), 
/* 1043 */           explicitContentFilter(), 
/* 1044 */           afkChannelId(), 
/* 1045 */           afkTimeout(), 
/* 1046 */           icon(), newValue, 
/*      */           
/* 1048 */           splash(), 
/* 1049 */           discoverySplash(), 
/* 1050 */           banner(), 
/* 1051 */           systemChannelId(), 
/* 1052 */           systemChannelFlags(), 
/* 1053 */           rulesChannelId(), 
/* 1054 */           publicUpdatesChannelId(), 
/* 1055 */           preferredLocale(), 
/* 1056 */           features(), 
/* 1057 */           description(), 
/* 1058 */           safetyAlertsChannelId()));
/*      */   }
/*      */   
/*      */   public GuildEditSpec withOwnerId(Snowflake value) {
/* 1062 */     Possible<Snowflake> newValue = Possible.of(value);
/* 1063 */     return validate(new GuildEditSpec(this.reason, 
/*      */           
/* 1065 */           name(), 
/* 1066 */           region(), 
/* 1067 */           verificationLevel(), 
/* 1068 */           defaultMessageNotificationsLevel(), 
/* 1069 */           explicitContentFilter(), 
/* 1070 */           afkChannelId(), 
/* 1071 */           afkTimeout(), 
/* 1072 */           icon(), newValue, 
/*      */           
/* 1074 */           splash(), 
/* 1075 */           discoverySplash(), 
/* 1076 */           banner(), 
/* 1077 */           systemChannelId(), 
/* 1078 */           systemChannelFlags(), 
/* 1079 */           rulesChannelId(), 
/* 1080 */           publicUpdatesChannelId(), 
/* 1081 */           preferredLocale(), 
/* 1082 */           features(), 
/* 1083 */           description(), 
/* 1084 */           safetyAlertsChannelId()));
/*      */   }
/*      */   
/*      */   public GuildEditSpec withSplash(Possible<Optional<Image>> value) {
/* 1088 */     Possible<Optional<Image>> newValue = Objects.<Possible<Optional<Image>>>requireNonNull(value);
/* 1089 */     return validate(new GuildEditSpec(this.reason, 
/*      */           
/* 1091 */           name(), 
/* 1092 */           region(), 
/* 1093 */           verificationLevel(), 
/* 1094 */           defaultMessageNotificationsLevel(), 
/* 1095 */           explicitContentFilter(), 
/* 1096 */           afkChannelId(), 
/* 1097 */           afkTimeout(), 
/* 1098 */           icon(), 
/* 1099 */           ownerId(), newValue, 
/*      */           
/* 1101 */           discoverySplash(), 
/* 1102 */           banner(), 
/* 1103 */           systemChannelId(), 
/* 1104 */           systemChannelFlags(), 
/* 1105 */           rulesChannelId(), 
/* 1106 */           publicUpdatesChannelId(), 
/* 1107 */           preferredLocale(), 
/* 1108 */           features(), 
/* 1109 */           description(), 
/* 1110 */           safetyAlertsChannelId()));
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public GuildEditSpec withSplash(@Nullable Image value) {
/* 1115 */     Possible<Optional<Image>> newValue = Possible.of(Optional.ofNullable(value));
/* 1116 */     return validate(new GuildEditSpec(this.reason, 
/*      */           
/* 1118 */           name(), 
/* 1119 */           region(), 
/* 1120 */           verificationLevel(), 
/* 1121 */           defaultMessageNotificationsLevel(), 
/* 1122 */           explicitContentFilter(), 
/* 1123 */           afkChannelId(), 
/* 1124 */           afkTimeout(), 
/* 1125 */           icon(), 
/* 1126 */           ownerId(), newValue, 
/*      */           
/* 1128 */           discoverySplash(), 
/* 1129 */           banner(), 
/* 1130 */           systemChannelId(), 
/* 1131 */           systemChannelFlags(), 
/* 1132 */           rulesChannelId(), 
/* 1133 */           publicUpdatesChannelId(), 
/* 1134 */           preferredLocale(), 
/* 1135 */           features(), 
/* 1136 */           description(), 
/* 1137 */           safetyAlertsChannelId()));
/*      */   }
/*      */   
/*      */   public GuildEditSpec withSplashOrNull(@Nullable Image value) {
/* 1141 */     Possible<Optional<Image>> newValue = Possible.of(Optional.ofNullable(value));
/* 1142 */     return validate(new GuildEditSpec(this.reason, 
/*      */           
/* 1144 */           name(), 
/* 1145 */           region(), 
/* 1146 */           verificationLevel(), 
/* 1147 */           defaultMessageNotificationsLevel(), 
/* 1148 */           explicitContentFilter(), 
/* 1149 */           afkChannelId(), 
/* 1150 */           afkTimeout(), 
/* 1151 */           icon(), 
/* 1152 */           ownerId(), newValue, 
/*      */           
/* 1154 */           discoverySplash(), 
/* 1155 */           banner(), 
/* 1156 */           systemChannelId(), 
/* 1157 */           systemChannelFlags(), 
/* 1158 */           rulesChannelId(), 
/* 1159 */           publicUpdatesChannelId(), 
/* 1160 */           preferredLocale(), 
/* 1161 */           features(), 
/* 1162 */           description(), 
/* 1163 */           safetyAlertsChannelId()));
/*      */   }
/*      */   
/*      */   public GuildEditSpec withDiscoverySplash(Possible<Optional<Image>> value) {
/* 1167 */     Possible<Optional<Image>> newValue = Objects.<Possible<Optional<Image>>>requireNonNull(value);
/* 1168 */     return validate(new GuildEditSpec(this.reason, 
/*      */           
/* 1170 */           name(), 
/* 1171 */           region(), 
/* 1172 */           verificationLevel(), 
/* 1173 */           defaultMessageNotificationsLevel(), 
/* 1174 */           explicitContentFilter(), 
/* 1175 */           afkChannelId(), 
/* 1176 */           afkTimeout(), 
/* 1177 */           icon(), 
/* 1178 */           ownerId(), 
/* 1179 */           splash(), newValue, 
/*      */           
/* 1181 */           banner(), 
/* 1182 */           systemChannelId(), 
/* 1183 */           systemChannelFlags(), 
/* 1184 */           rulesChannelId(), 
/* 1185 */           publicUpdatesChannelId(), 
/* 1186 */           preferredLocale(), 
/* 1187 */           features(), 
/* 1188 */           description(), 
/* 1189 */           safetyAlertsChannelId()));
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public GuildEditSpec withDiscoverySplash(@Nullable Image value) {
/* 1194 */     Possible<Optional<Image>> newValue = Possible.of(Optional.ofNullable(value));
/* 1195 */     return validate(new GuildEditSpec(this.reason, 
/*      */           
/* 1197 */           name(), 
/* 1198 */           region(), 
/* 1199 */           verificationLevel(), 
/* 1200 */           defaultMessageNotificationsLevel(), 
/* 1201 */           explicitContentFilter(), 
/* 1202 */           afkChannelId(), 
/* 1203 */           afkTimeout(), 
/* 1204 */           icon(), 
/* 1205 */           ownerId(), 
/* 1206 */           splash(), newValue, 
/*      */           
/* 1208 */           banner(), 
/* 1209 */           systemChannelId(), 
/* 1210 */           systemChannelFlags(), 
/* 1211 */           rulesChannelId(), 
/* 1212 */           publicUpdatesChannelId(), 
/* 1213 */           preferredLocale(), 
/* 1214 */           features(), 
/* 1215 */           description(), 
/* 1216 */           safetyAlertsChannelId()));
/*      */   }
/*      */   
/*      */   public GuildEditSpec withDiscoverySplashOrNull(@Nullable Image value) {
/* 1220 */     Possible<Optional<Image>> newValue = Possible.of(Optional.ofNullable(value));
/* 1221 */     return validate(new GuildEditSpec(this.reason, 
/*      */           
/* 1223 */           name(), 
/* 1224 */           region(), 
/* 1225 */           verificationLevel(), 
/* 1226 */           defaultMessageNotificationsLevel(), 
/* 1227 */           explicitContentFilter(), 
/* 1228 */           afkChannelId(), 
/* 1229 */           afkTimeout(), 
/* 1230 */           icon(), 
/* 1231 */           ownerId(), 
/* 1232 */           splash(), newValue, 
/*      */           
/* 1234 */           banner(), 
/* 1235 */           systemChannelId(), 
/* 1236 */           systemChannelFlags(), 
/* 1237 */           rulesChannelId(), 
/* 1238 */           publicUpdatesChannelId(), 
/* 1239 */           preferredLocale(), 
/* 1240 */           features(), 
/* 1241 */           description(), 
/* 1242 */           safetyAlertsChannelId()));
/*      */   }
/*      */   
/*      */   public GuildEditSpec withBanner(Possible<Optional<Image>> value) {
/* 1246 */     Possible<Optional<Image>> newValue = Objects.<Possible<Optional<Image>>>requireNonNull(value);
/* 1247 */     return validate(new GuildEditSpec(this.reason, 
/*      */           
/* 1249 */           name(), 
/* 1250 */           region(), 
/* 1251 */           verificationLevel(), 
/* 1252 */           defaultMessageNotificationsLevel(), 
/* 1253 */           explicitContentFilter(), 
/* 1254 */           afkChannelId(), 
/* 1255 */           afkTimeout(), 
/* 1256 */           icon(), 
/* 1257 */           ownerId(), 
/* 1258 */           splash(), 
/* 1259 */           discoverySplash(), newValue, 
/*      */           
/* 1261 */           systemChannelId(), 
/* 1262 */           systemChannelFlags(), 
/* 1263 */           rulesChannelId(), 
/* 1264 */           publicUpdatesChannelId(), 
/* 1265 */           preferredLocale(), 
/* 1266 */           features(), 
/* 1267 */           description(), 
/* 1268 */           safetyAlertsChannelId()));
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public GuildEditSpec withBanner(@Nullable Image value) {
/* 1273 */     Possible<Optional<Image>> newValue = Possible.of(Optional.ofNullable(value));
/* 1274 */     return validate(new GuildEditSpec(this.reason, 
/*      */           
/* 1276 */           name(), 
/* 1277 */           region(), 
/* 1278 */           verificationLevel(), 
/* 1279 */           defaultMessageNotificationsLevel(), 
/* 1280 */           explicitContentFilter(), 
/* 1281 */           afkChannelId(), 
/* 1282 */           afkTimeout(), 
/* 1283 */           icon(), 
/* 1284 */           ownerId(), 
/* 1285 */           splash(), 
/* 1286 */           discoverySplash(), newValue, 
/*      */           
/* 1288 */           systemChannelId(), 
/* 1289 */           systemChannelFlags(), 
/* 1290 */           rulesChannelId(), 
/* 1291 */           publicUpdatesChannelId(), 
/* 1292 */           preferredLocale(), 
/* 1293 */           features(), 
/* 1294 */           description(), 
/* 1295 */           safetyAlertsChannelId()));
/*      */   }
/*      */   
/*      */   public GuildEditSpec withBannerOrNull(@Nullable Image value) {
/* 1299 */     Possible<Optional<Image>> newValue = Possible.of(Optional.ofNullable(value));
/* 1300 */     return validate(new GuildEditSpec(this.reason, 
/*      */           
/* 1302 */           name(), 
/* 1303 */           region(), 
/* 1304 */           verificationLevel(), 
/* 1305 */           defaultMessageNotificationsLevel(), 
/* 1306 */           explicitContentFilter(), 
/* 1307 */           afkChannelId(), 
/* 1308 */           afkTimeout(), 
/* 1309 */           icon(), 
/* 1310 */           ownerId(), 
/* 1311 */           splash(), 
/* 1312 */           discoverySplash(), newValue, 
/*      */           
/* 1314 */           systemChannelId(), 
/* 1315 */           systemChannelFlags(), 
/* 1316 */           rulesChannelId(), 
/* 1317 */           publicUpdatesChannelId(), 
/* 1318 */           preferredLocale(), 
/* 1319 */           features(), 
/* 1320 */           description(), 
/* 1321 */           safetyAlertsChannelId()));
/*      */   }
/*      */   
/*      */   public GuildEditSpec withSystemChannelId(Possible<Optional<Snowflake>> value) {
/* 1325 */     Possible<Optional<Snowflake>> newValue = Objects.<Possible<Optional<Snowflake>>>requireNonNull(value);
/* 1326 */     return validate(new GuildEditSpec(this.reason, 
/*      */           
/* 1328 */           name(), 
/* 1329 */           region(), 
/* 1330 */           verificationLevel(), 
/* 1331 */           defaultMessageNotificationsLevel(), 
/* 1332 */           explicitContentFilter(), 
/* 1333 */           afkChannelId(), 
/* 1334 */           afkTimeout(), 
/* 1335 */           icon(), 
/* 1336 */           ownerId(), 
/* 1337 */           splash(), 
/* 1338 */           discoverySplash(), 
/* 1339 */           banner(), newValue, 
/*      */           
/* 1341 */           systemChannelFlags(), 
/* 1342 */           rulesChannelId(), 
/* 1343 */           publicUpdatesChannelId(), 
/* 1344 */           preferredLocale(), 
/* 1345 */           features(), 
/* 1346 */           description(), 
/* 1347 */           safetyAlertsChannelId()));
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public GuildEditSpec withSystemChannelId(@Nullable Snowflake value) {
/* 1352 */     Possible<Optional<Snowflake>> newValue = Possible.of(Optional.ofNullable(value));
/* 1353 */     return validate(new GuildEditSpec(this.reason, 
/*      */           
/* 1355 */           name(), 
/* 1356 */           region(), 
/* 1357 */           verificationLevel(), 
/* 1358 */           defaultMessageNotificationsLevel(), 
/* 1359 */           explicitContentFilter(), 
/* 1360 */           afkChannelId(), 
/* 1361 */           afkTimeout(), 
/* 1362 */           icon(), 
/* 1363 */           ownerId(), 
/* 1364 */           splash(), 
/* 1365 */           discoverySplash(), 
/* 1366 */           banner(), newValue, 
/*      */           
/* 1368 */           systemChannelFlags(), 
/* 1369 */           rulesChannelId(), 
/* 1370 */           publicUpdatesChannelId(), 
/* 1371 */           preferredLocale(), 
/* 1372 */           features(), 
/* 1373 */           description(), 
/* 1374 */           safetyAlertsChannelId()));
/*      */   }
/*      */   
/*      */   public GuildEditSpec withSystemChannelIdOrNull(@Nullable Snowflake value) {
/* 1378 */     Possible<Optional<Snowflake>> newValue = Possible.of(Optional.ofNullable(value));
/* 1379 */     return validate(new GuildEditSpec(this.reason, 
/*      */           
/* 1381 */           name(), 
/* 1382 */           region(), 
/* 1383 */           verificationLevel(), 
/* 1384 */           defaultMessageNotificationsLevel(), 
/* 1385 */           explicitContentFilter(), 
/* 1386 */           afkChannelId(), 
/* 1387 */           afkTimeout(), 
/* 1388 */           icon(), 
/* 1389 */           ownerId(), 
/* 1390 */           splash(), 
/* 1391 */           discoverySplash(), 
/* 1392 */           banner(), newValue, 
/*      */           
/* 1394 */           systemChannelFlags(), 
/* 1395 */           rulesChannelId(), 
/* 1396 */           publicUpdatesChannelId(), 
/* 1397 */           preferredLocale(), 
/* 1398 */           features(), 
/* 1399 */           description(), 
/* 1400 */           safetyAlertsChannelId()));
/*      */   }
/*      */   
/*      */   public GuildEditSpec withSystemChannelFlags(Possible<Guild.SystemChannelFlag> value) {
/* 1404 */     Possible<Guild.SystemChannelFlag> newValue = Objects.<Possible<Guild.SystemChannelFlag>>requireNonNull(value);
/* 1405 */     return validate(new GuildEditSpec(this.reason, 
/*      */           
/* 1407 */           name(), 
/* 1408 */           region(), 
/* 1409 */           verificationLevel(), 
/* 1410 */           defaultMessageNotificationsLevel(), 
/* 1411 */           explicitContentFilter(), 
/* 1412 */           afkChannelId(), 
/* 1413 */           afkTimeout(), 
/* 1414 */           icon(), 
/* 1415 */           ownerId(), 
/* 1416 */           splash(), 
/* 1417 */           discoverySplash(), 
/* 1418 */           banner(), 
/* 1419 */           systemChannelId(), newValue, 
/*      */           
/* 1421 */           rulesChannelId(), 
/* 1422 */           publicUpdatesChannelId(), 
/* 1423 */           preferredLocale(), 
/* 1424 */           features(), 
/* 1425 */           description(), 
/* 1426 */           safetyAlertsChannelId()));
/*      */   }
/*      */   
/*      */   public GuildEditSpec withSystemChannelFlags(Guild.SystemChannelFlag value) {
/* 1430 */     Possible<Guild.SystemChannelFlag> newValue = Possible.of(value);
/* 1431 */     return validate(new GuildEditSpec(this.reason, 
/*      */           
/* 1433 */           name(), 
/* 1434 */           region(), 
/* 1435 */           verificationLevel(), 
/* 1436 */           defaultMessageNotificationsLevel(), 
/* 1437 */           explicitContentFilter(), 
/* 1438 */           afkChannelId(), 
/* 1439 */           afkTimeout(), 
/* 1440 */           icon(), 
/* 1441 */           ownerId(), 
/* 1442 */           splash(), 
/* 1443 */           discoverySplash(), 
/* 1444 */           banner(), 
/* 1445 */           systemChannelId(), newValue, 
/*      */           
/* 1447 */           rulesChannelId(), 
/* 1448 */           publicUpdatesChannelId(), 
/* 1449 */           preferredLocale(), 
/* 1450 */           features(), 
/* 1451 */           description(), 
/* 1452 */           safetyAlertsChannelId()));
/*      */   }
/*      */   
/*      */   public GuildEditSpec withRulesChannelId(Possible<Optional<Snowflake>> value) {
/* 1456 */     Possible<Optional<Snowflake>> newValue = Objects.<Possible<Optional<Snowflake>>>requireNonNull(value);
/* 1457 */     return validate(new GuildEditSpec(this.reason, 
/*      */           
/* 1459 */           name(), 
/* 1460 */           region(), 
/* 1461 */           verificationLevel(), 
/* 1462 */           defaultMessageNotificationsLevel(), 
/* 1463 */           explicitContentFilter(), 
/* 1464 */           afkChannelId(), 
/* 1465 */           afkTimeout(), 
/* 1466 */           icon(), 
/* 1467 */           ownerId(), 
/* 1468 */           splash(), 
/* 1469 */           discoverySplash(), 
/* 1470 */           banner(), 
/* 1471 */           systemChannelId(), 
/* 1472 */           systemChannelFlags(), newValue, 
/*      */           
/* 1474 */           publicUpdatesChannelId(), 
/* 1475 */           preferredLocale(), 
/* 1476 */           features(), 
/* 1477 */           description(), 
/* 1478 */           safetyAlertsChannelId()));
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public GuildEditSpec withRulesChannelId(@Nullable Snowflake value) {
/* 1483 */     Possible<Optional<Snowflake>> newValue = Possible.of(Optional.ofNullable(value));
/* 1484 */     return validate(new GuildEditSpec(this.reason, 
/*      */           
/* 1486 */           name(), 
/* 1487 */           region(), 
/* 1488 */           verificationLevel(), 
/* 1489 */           defaultMessageNotificationsLevel(), 
/* 1490 */           explicitContentFilter(), 
/* 1491 */           afkChannelId(), 
/* 1492 */           afkTimeout(), 
/* 1493 */           icon(), 
/* 1494 */           ownerId(), 
/* 1495 */           splash(), 
/* 1496 */           discoverySplash(), 
/* 1497 */           banner(), 
/* 1498 */           systemChannelId(), 
/* 1499 */           systemChannelFlags(), newValue, 
/*      */           
/* 1501 */           publicUpdatesChannelId(), 
/* 1502 */           preferredLocale(), 
/* 1503 */           features(), 
/* 1504 */           description(), 
/* 1505 */           safetyAlertsChannelId()));
/*      */   }
/*      */   
/*      */   public GuildEditSpec withRulesChannelIdOrNull(@Nullable Snowflake value) {
/* 1509 */     Possible<Optional<Snowflake>> newValue = Possible.of(Optional.ofNullable(value));
/* 1510 */     return validate(new GuildEditSpec(this.reason, 
/*      */           
/* 1512 */           name(), 
/* 1513 */           region(), 
/* 1514 */           verificationLevel(), 
/* 1515 */           defaultMessageNotificationsLevel(), 
/* 1516 */           explicitContentFilter(), 
/* 1517 */           afkChannelId(), 
/* 1518 */           afkTimeout(), 
/* 1519 */           icon(), 
/* 1520 */           ownerId(), 
/* 1521 */           splash(), 
/* 1522 */           discoverySplash(), 
/* 1523 */           banner(), 
/* 1524 */           systemChannelId(), 
/* 1525 */           systemChannelFlags(), newValue, 
/*      */           
/* 1527 */           publicUpdatesChannelId(), 
/* 1528 */           preferredLocale(), 
/* 1529 */           features(), 
/* 1530 */           description(), 
/* 1531 */           safetyAlertsChannelId()));
/*      */   }
/*      */   
/*      */   public GuildEditSpec withPublicUpdatesChannelId(Possible<Optional<Snowflake>> value) {
/* 1535 */     Possible<Optional<Snowflake>> newValue = Objects.<Possible<Optional<Snowflake>>>requireNonNull(value);
/* 1536 */     return validate(new GuildEditSpec(this.reason, 
/*      */           
/* 1538 */           name(), 
/* 1539 */           region(), 
/* 1540 */           verificationLevel(), 
/* 1541 */           defaultMessageNotificationsLevel(), 
/* 1542 */           explicitContentFilter(), 
/* 1543 */           afkChannelId(), 
/* 1544 */           afkTimeout(), 
/* 1545 */           icon(), 
/* 1546 */           ownerId(), 
/* 1547 */           splash(), 
/* 1548 */           discoverySplash(), 
/* 1549 */           banner(), 
/* 1550 */           systemChannelId(), 
/* 1551 */           systemChannelFlags(), 
/* 1552 */           rulesChannelId(), newValue, 
/*      */           
/* 1554 */           preferredLocale(), 
/* 1555 */           features(), 
/* 1556 */           description(), 
/* 1557 */           safetyAlertsChannelId()));
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public GuildEditSpec withPublicUpdatesChannelId(@Nullable Snowflake value) {
/* 1562 */     Possible<Optional<Snowflake>> newValue = Possible.of(Optional.ofNullable(value));
/* 1563 */     return validate(new GuildEditSpec(this.reason, 
/*      */           
/* 1565 */           name(), 
/* 1566 */           region(), 
/* 1567 */           verificationLevel(), 
/* 1568 */           defaultMessageNotificationsLevel(), 
/* 1569 */           explicitContentFilter(), 
/* 1570 */           afkChannelId(), 
/* 1571 */           afkTimeout(), 
/* 1572 */           icon(), 
/* 1573 */           ownerId(), 
/* 1574 */           splash(), 
/* 1575 */           discoverySplash(), 
/* 1576 */           banner(), 
/* 1577 */           systemChannelId(), 
/* 1578 */           systemChannelFlags(), 
/* 1579 */           rulesChannelId(), newValue, 
/*      */           
/* 1581 */           preferredLocale(), 
/* 1582 */           features(), 
/* 1583 */           description(), 
/* 1584 */           safetyAlertsChannelId()));
/*      */   }
/*      */   
/*      */   public GuildEditSpec withPublicUpdatesChannelIdOrNull(@Nullable Snowflake value) {
/* 1588 */     Possible<Optional<Snowflake>> newValue = Possible.of(Optional.ofNullable(value));
/* 1589 */     return validate(new GuildEditSpec(this.reason, 
/*      */           
/* 1591 */           name(), 
/* 1592 */           region(), 
/* 1593 */           verificationLevel(), 
/* 1594 */           defaultMessageNotificationsLevel(), 
/* 1595 */           explicitContentFilter(), 
/* 1596 */           afkChannelId(), 
/* 1597 */           afkTimeout(), 
/* 1598 */           icon(), 
/* 1599 */           ownerId(), 
/* 1600 */           splash(), 
/* 1601 */           discoverySplash(), 
/* 1602 */           banner(), 
/* 1603 */           systemChannelId(), 
/* 1604 */           systemChannelFlags(), 
/* 1605 */           rulesChannelId(), newValue, 
/*      */           
/* 1607 */           preferredLocale(), 
/* 1608 */           features(), 
/* 1609 */           description(), 
/* 1610 */           safetyAlertsChannelId()));
/*      */   }
/*      */   
/*      */   public GuildEditSpec withPreferredLocale(Possible<Optional<Locale>> value) {
/* 1614 */     Possible<Optional<Locale>> newValue = Objects.<Possible<Optional<Locale>>>requireNonNull(value);
/* 1615 */     return validate(new GuildEditSpec(this.reason, 
/*      */           
/* 1617 */           name(), 
/* 1618 */           region(), 
/* 1619 */           verificationLevel(), 
/* 1620 */           defaultMessageNotificationsLevel(), 
/* 1621 */           explicitContentFilter(), 
/* 1622 */           afkChannelId(), 
/* 1623 */           afkTimeout(), 
/* 1624 */           icon(), 
/* 1625 */           ownerId(), 
/* 1626 */           splash(), 
/* 1627 */           discoverySplash(), 
/* 1628 */           banner(), 
/* 1629 */           systemChannelId(), 
/* 1630 */           systemChannelFlags(), 
/* 1631 */           rulesChannelId(), 
/* 1632 */           publicUpdatesChannelId(), newValue, 
/*      */           
/* 1634 */           features(), 
/* 1635 */           description(), 
/* 1636 */           safetyAlertsChannelId()));
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public GuildEditSpec withPreferredLocale(@Nullable Locale value) {
/* 1641 */     Possible<Optional<Locale>> newValue = Possible.of(Optional.ofNullable(value));
/* 1642 */     return validate(new GuildEditSpec(this.reason, 
/*      */           
/* 1644 */           name(), 
/* 1645 */           region(), 
/* 1646 */           verificationLevel(), 
/* 1647 */           defaultMessageNotificationsLevel(), 
/* 1648 */           explicitContentFilter(), 
/* 1649 */           afkChannelId(), 
/* 1650 */           afkTimeout(), 
/* 1651 */           icon(), 
/* 1652 */           ownerId(), 
/* 1653 */           splash(), 
/* 1654 */           discoverySplash(), 
/* 1655 */           banner(), 
/* 1656 */           systemChannelId(), 
/* 1657 */           systemChannelFlags(), 
/* 1658 */           rulesChannelId(), 
/* 1659 */           publicUpdatesChannelId(), newValue, 
/*      */           
/* 1661 */           features(), 
/* 1662 */           description(), 
/* 1663 */           safetyAlertsChannelId()));
/*      */   }
/*      */   
/*      */   public GuildEditSpec withPreferredLocaleOrNull(@Nullable Locale value) {
/* 1667 */     Possible<Optional<Locale>> newValue = Possible.of(Optional.ofNullable(value));
/* 1668 */     return validate(new GuildEditSpec(this.reason, 
/*      */           
/* 1670 */           name(), 
/* 1671 */           region(), 
/* 1672 */           verificationLevel(), 
/* 1673 */           defaultMessageNotificationsLevel(), 
/* 1674 */           explicitContentFilter(), 
/* 1675 */           afkChannelId(), 
/* 1676 */           afkTimeout(), 
/* 1677 */           icon(), 
/* 1678 */           ownerId(), 
/* 1679 */           splash(), 
/* 1680 */           discoverySplash(), 
/* 1681 */           banner(), 
/* 1682 */           systemChannelId(), 
/* 1683 */           systemChannelFlags(), 
/* 1684 */           rulesChannelId(), 
/* 1685 */           publicUpdatesChannelId(), newValue, 
/*      */           
/* 1687 */           features(), 
/* 1688 */           description(), 
/* 1689 */           safetyAlertsChannelId()));
/*      */   }
/*      */   
/*      */   public GuildEditSpec withFeatures(Possible<List<String>> possible) {
/* 1693 */     Possible<List<String>> newValue = Objects.<Possible<List<String>>>requireNonNull(possible);
/* 1694 */     return validate(new GuildEditSpec(this.reason, 
/*      */           
/* 1696 */           name(), 
/* 1697 */           region(), 
/* 1698 */           verificationLevel(), 
/* 1699 */           defaultMessageNotificationsLevel(), 
/* 1700 */           explicitContentFilter(), 
/* 1701 */           afkChannelId(), 
/* 1702 */           afkTimeout(), 
/* 1703 */           icon(), 
/* 1704 */           ownerId(), 
/* 1705 */           splash(), 
/* 1706 */           discoverySplash(), 
/* 1707 */           banner(), 
/* 1708 */           systemChannelId(), 
/* 1709 */           systemChannelFlags(), 
/* 1710 */           rulesChannelId(), 
/* 1711 */           publicUpdatesChannelId(), 
/* 1712 */           preferredLocale(), newValue, 
/*      */           
/* 1714 */           description(), 
/* 1715 */           safetyAlertsChannelId()));
/*      */   }
/*      */   
/*      */   public GuildEditSpec withFeatures(Iterable<String> elements) {
/* 1719 */     Possible<List<String>> newValue = Possible.of(
/* 1720 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/* 1721 */     return validate(new GuildEditSpec(this.reason, 
/*      */           
/* 1723 */           name(), 
/* 1724 */           region(), 
/* 1725 */           verificationLevel(), 
/* 1726 */           defaultMessageNotificationsLevel(), 
/* 1727 */           explicitContentFilter(), 
/* 1728 */           afkChannelId(), 
/* 1729 */           afkTimeout(), 
/* 1730 */           icon(), 
/* 1731 */           ownerId(), 
/* 1732 */           splash(), 
/* 1733 */           discoverySplash(), 
/* 1734 */           banner(), 
/* 1735 */           systemChannelId(), 
/* 1736 */           systemChannelFlags(), 
/* 1737 */           rulesChannelId(), 
/* 1738 */           publicUpdatesChannelId(), 
/* 1739 */           preferredLocale(), newValue, 
/*      */           
/* 1741 */           description(), 
/* 1742 */           safetyAlertsChannelId()));
/*      */   }
/*      */   
/*      */   @SafeVarargs
/*      */   public final GuildEditSpec withFeatures(String... elements) {
/* 1747 */     Possible<List<String>> newValue = Possible.of(Arrays.asList(elements));
/* 1748 */     return validate(new GuildEditSpec(this.reason, 
/*      */           
/* 1750 */           name(), 
/* 1751 */           region(), 
/* 1752 */           verificationLevel(), 
/* 1753 */           defaultMessageNotificationsLevel(), 
/* 1754 */           explicitContentFilter(), 
/* 1755 */           afkChannelId(), 
/* 1756 */           afkTimeout(), 
/* 1757 */           icon(), 
/* 1758 */           ownerId(), 
/* 1759 */           splash(), 
/* 1760 */           discoverySplash(), 
/* 1761 */           banner(), 
/* 1762 */           systemChannelId(), 
/* 1763 */           systemChannelFlags(), 
/* 1764 */           rulesChannelId(), 
/* 1765 */           publicUpdatesChannelId(), 
/* 1766 */           preferredLocale(), newValue, 
/*      */           
/* 1768 */           description(), 
/* 1769 */           safetyAlertsChannelId()));
/*      */   }
/*      */   
/*      */   public GuildEditSpec withDescription(Possible<Optional<String>> value) {
/* 1773 */     Possible<Optional<String>> newValue = Objects.<Possible<Optional<String>>>requireNonNull(value);
/* 1774 */     return validate(new GuildEditSpec(this.reason, 
/*      */           
/* 1776 */           name(), 
/* 1777 */           region(), 
/* 1778 */           verificationLevel(), 
/* 1779 */           defaultMessageNotificationsLevel(), 
/* 1780 */           explicitContentFilter(), 
/* 1781 */           afkChannelId(), 
/* 1782 */           afkTimeout(), 
/* 1783 */           icon(), 
/* 1784 */           ownerId(), 
/* 1785 */           splash(), 
/* 1786 */           discoverySplash(), 
/* 1787 */           banner(), 
/* 1788 */           systemChannelId(), 
/* 1789 */           systemChannelFlags(), 
/* 1790 */           rulesChannelId(), 
/* 1791 */           publicUpdatesChannelId(), 
/* 1792 */           preferredLocale(), 
/* 1793 */           features(), newValue, 
/*      */           
/* 1795 */           safetyAlertsChannelId()));
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public GuildEditSpec withDescription(@Nullable String value) {
/* 1800 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/* 1801 */     return validate(new GuildEditSpec(this.reason, 
/*      */           
/* 1803 */           name(), 
/* 1804 */           region(), 
/* 1805 */           verificationLevel(), 
/* 1806 */           defaultMessageNotificationsLevel(), 
/* 1807 */           explicitContentFilter(), 
/* 1808 */           afkChannelId(), 
/* 1809 */           afkTimeout(), 
/* 1810 */           icon(), 
/* 1811 */           ownerId(), 
/* 1812 */           splash(), 
/* 1813 */           discoverySplash(), 
/* 1814 */           banner(), 
/* 1815 */           systemChannelId(), 
/* 1816 */           systemChannelFlags(), 
/* 1817 */           rulesChannelId(), 
/* 1818 */           publicUpdatesChannelId(), 
/* 1819 */           preferredLocale(), 
/* 1820 */           features(), newValue, 
/*      */           
/* 1822 */           safetyAlertsChannelId()));
/*      */   }
/*      */   
/*      */   public GuildEditSpec withDescriptionOrNull(@Nullable String value) {
/* 1826 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/* 1827 */     return validate(new GuildEditSpec(this.reason, 
/*      */           
/* 1829 */           name(), 
/* 1830 */           region(), 
/* 1831 */           verificationLevel(), 
/* 1832 */           defaultMessageNotificationsLevel(), 
/* 1833 */           explicitContentFilter(), 
/* 1834 */           afkChannelId(), 
/* 1835 */           afkTimeout(), 
/* 1836 */           icon(), 
/* 1837 */           ownerId(), 
/* 1838 */           splash(), 
/* 1839 */           discoverySplash(), 
/* 1840 */           banner(), 
/* 1841 */           systemChannelId(), 
/* 1842 */           systemChannelFlags(), 
/* 1843 */           rulesChannelId(), 
/* 1844 */           publicUpdatesChannelId(), 
/* 1845 */           preferredLocale(), 
/* 1846 */           features(), newValue, 
/*      */           
/* 1848 */           safetyAlertsChannelId()));
/*      */   }
/*      */   
/*      */   public GuildEditSpec withSafetyAlertsChannelId(Possible<Optional<Snowflake>> value) {
/* 1852 */     Possible<Optional<Snowflake>> newValue = Objects.<Possible<Optional<Snowflake>>>requireNonNull(value);
/* 1853 */     return validate(new GuildEditSpec(this.reason, 
/*      */           
/* 1855 */           name(), 
/* 1856 */           region(), 
/* 1857 */           verificationLevel(), 
/* 1858 */           defaultMessageNotificationsLevel(), 
/* 1859 */           explicitContentFilter(), 
/* 1860 */           afkChannelId(), 
/* 1861 */           afkTimeout(), 
/* 1862 */           icon(), 
/* 1863 */           ownerId(), 
/* 1864 */           splash(), 
/* 1865 */           discoverySplash(), 
/* 1866 */           banner(), 
/* 1867 */           systemChannelId(), 
/* 1868 */           systemChannelFlags(), 
/* 1869 */           rulesChannelId(), 
/* 1870 */           publicUpdatesChannelId(), 
/* 1871 */           preferredLocale(), 
/* 1872 */           features(), 
/* 1873 */           description(), newValue));
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public GuildEditSpec withSafetyAlertsChannelId(@Nullable Snowflake value) {
/* 1879 */     Possible<Optional<Snowflake>> newValue = Possible.of(Optional.ofNullable(value));
/* 1880 */     return validate(new GuildEditSpec(this.reason, 
/*      */           
/* 1882 */           name(), 
/* 1883 */           region(), 
/* 1884 */           verificationLevel(), 
/* 1885 */           defaultMessageNotificationsLevel(), 
/* 1886 */           explicitContentFilter(), 
/* 1887 */           afkChannelId(), 
/* 1888 */           afkTimeout(), 
/* 1889 */           icon(), 
/* 1890 */           ownerId(), 
/* 1891 */           splash(), 
/* 1892 */           discoverySplash(), 
/* 1893 */           banner(), 
/* 1894 */           systemChannelId(), 
/* 1895 */           systemChannelFlags(), 
/* 1896 */           rulesChannelId(), 
/* 1897 */           publicUpdatesChannelId(), 
/* 1898 */           preferredLocale(), 
/* 1899 */           features(), 
/* 1900 */           description(), newValue));
/*      */   }
/*      */ 
/*      */   
/*      */   public GuildEditSpec withSafetyAlertsChannelIdOrNull(@Nullable Snowflake value) {
/* 1905 */     Possible<Optional<Snowflake>> newValue = Possible.of(Optional.ofNullable(value));
/* 1906 */     return validate(new GuildEditSpec(this.reason, 
/*      */           
/* 1908 */           name(), 
/* 1909 */           region(), 
/* 1910 */           verificationLevel(), 
/* 1911 */           defaultMessageNotificationsLevel(), 
/* 1912 */           explicitContentFilter(), 
/* 1913 */           afkChannelId(), 
/* 1914 */           afkTimeout(), 
/* 1915 */           icon(), 
/* 1916 */           ownerId(), 
/* 1917 */           splash(), 
/* 1918 */           discoverySplash(), 
/* 1919 */           banner(), 
/* 1920 */           systemChannelId(), 
/* 1921 */           systemChannelFlags(), 
/* 1922 */           rulesChannelId(), 
/* 1923 */           publicUpdatesChannelId(), 
/* 1924 */           preferredLocale(), 
/* 1925 */           features(), 
/* 1926 */           description(), newValue));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean equals(Object another) {
/* 1936 */     if (this == another) return true; 
/* 1937 */     return (another instanceof GuildEditSpec && 
/* 1938 */       equalTo(0, (GuildEditSpec)another));
/*      */   }
/*      */   
/*      */   private boolean equalTo(int synthetic, GuildEditSpec another) {
/* 1942 */     return (Objects.equals(this.reason, another.reason) && 
/* 1943 */       name().equals(another.name()) && 
/* 1944 */       region().equals(another.region()) && 
/* 1945 */       verificationLevel().equals(another.verificationLevel()) && 
/* 1946 */       defaultMessageNotificationsLevel().equals(another.defaultMessageNotificationsLevel()) && 
/* 1947 */       explicitContentFilter().equals(another.explicitContentFilter()) && 
/* 1948 */       afkChannelId().equals(another.afkChannelId()) && 
/* 1949 */       afkTimeout().equals(another.afkTimeout()) && 
/* 1950 */       icon().equals(another.icon()) && 
/* 1951 */       ownerId().equals(another.ownerId()) && 
/* 1952 */       splash().equals(another.splash()) && 
/* 1953 */       discoverySplash().equals(another.discoverySplash()) && 
/* 1954 */       banner().equals(another.banner()) && 
/* 1955 */       systemChannelId().equals(another.systemChannelId()) && 
/* 1956 */       systemChannelFlags().equals(another.systemChannelFlags()) && 
/* 1957 */       rulesChannelId().equals(another.rulesChannelId()) && 
/* 1958 */       publicUpdatesChannelId().equals(another.publicUpdatesChannelId()) && 
/* 1959 */       preferredLocale().equals(another.preferredLocale()) && 
/* 1960 */       Objects.equals(this.features_value, another.features_value) && 
/* 1961 */       description().equals(another.description()) && 
/* 1962 */       safetyAlertsChannelId().equals(another.safetyAlertsChannelId()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int hashCode() {
/* 1971 */     int h = 5381;
/* 1972 */     h += (h << 5) + Objects.hashCode(this.reason);
/* 1973 */     h += (h << 5) + name().hashCode();
/* 1974 */     h += (h << 5) + region().hashCode();
/* 1975 */     h += (h << 5) + verificationLevel().hashCode();
/* 1976 */     h += (h << 5) + defaultMessageNotificationsLevel().hashCode();
/* 1977 */     h += (h << 5) + explicitContentFilter().hashCode();
/* 1978 */     h += (h << 5) + afkChannelId().hashCode();
/* 1979 */     h += (h << 5) + afkTimeout().hashCode();
/* 1980 */     h += (h << 5) + icon().hashCode();
/* 1981 */     h += (h << 5) + ownerId().hashCode();
/* 1982 */     h += (h << 5) + splash().hashCode();
/* 1983 */     h += (h << 5) + discoverySplash().hashCode();
/* 1984 */     h += (h << 5) + banner().hashCode();
/* 1985 */     h += (h << 5) + systemChannelId().hashCode();
/* 1986 */     h += (h << 5) + systemChannelFlags().hashCode();
/* 1987 */     h += (h << 5) + rulesChannelId().hashCode();
/* 1988 */     h += (h << 5) + publicUpdatesChannelId().hashCode();
/* 1989 */     h += (h << 5) + preferredLocale().hashCode();
/* 1990 */     h += (h << 5) + Objects.hashCode(this.features_value);
/* 1991 */     h += (h << 5) + description().hashCode();
/* 1992 */     h += (h << 5) + safetyAlertsChannelId().hashCode();
/* 1993 */     return h;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/* 2002 */     return "GuildEditSpec{reason=" + this.reason + ", name=" + 
/*      */       
/* 2004 */       name().toString() + ", region=" + 
/* 2005 */       region().toString() + ", verificationLevel=" + 
/* 2006 */       verificationLevel().toString() + ", defaultMessageNotificationsLevel=" + 
/* 2007 */       defaultMessageNotificationsLevel().toString() + ", explicitContentFilter=" + 
/* 2008 */       explicitContentFilter().toString() + ", afkChannelId=" + 
/* 2009 */       afkChannelId().toString() + ", afkTimeout=" + 
/* 2010 */       afkTimeout().toString() + ", icon=" + 
/* 2011 */       icon().toString() + ", ownerId=" + 
/* 2012 */       ownerId().toString() + ", splash=" + 
/* 2013 */       splash().toString() + ", discoverySplash=" + 
/* 2014 */       discoverySplash().toString() + ", banner=" + 
/* 2015 */       banner().toString() + ", systemChannelId=" + 
/* 2016 */       systemChannelId().toString() + ", systemChannelFlags=" + 
/* 2017 */       systemChannelFlags().toString() + ", rulesChannelId=" + 
/* 2018 */       rulesChannelId().toString() + ", publicUpdatesChannelId=" + 
/* 2019 */       publicUpdatesChannelId().toString() + ", preferredLocale=" + 
/* 2020 */       preferredLocale().toString() + ", features=" + 
/* 2021 */       Objects.toString(this.features_value) + ", description=" + 
/* 2022 */       description().toString() + ", safetyAlertsChannelId=" + 
/* 2023 */       safetyAlertsChannelId().toString() + "}";
/*      */   }
/*      */ 
/*      */   
/* 2027 */   private static final GuildEditSpec INSTANCE = validate(new GuildEditSpec());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static GuildEditSpec create() {
/* 2034 */     return INSTANCE;
/*      */   }
/*      */   
/*      */   private static GuildEditSpec validate(GuildEditSpec instance) {
/* 2038 */     return (INSTANCE != null && INSTANCE.equalTo(0, instance)) ? INSTANCE : instance;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static GuildEditSpec copyOf(GuildEditSpecGenerator instance) {
/* 2049 */     if (instance instanceof GuildEditSpec) {
/* 2050 */       return (GuildEditSpec)instance;
/*      */     }
/* 2052 */     return builder()
/* 2053 */       .from(instance)
/* 2054 */       .build();
/*      */   }
/*      */   
/*      */   public boolean isNamePresent() {
/* 2058 */     return !this.name_absent;
/*      */   }
/*      */   
/*      */   public String nameOrElse(String defaultValue) {
/* 2062 */     return !this.name_absent ? this.name_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isRegionPresent() {
/* 2066 */     return !this.region_absent;
/*      */   }
/*      */   
/*      */   public Region regionOrElse(Region defaultValue) {
/* 2070 */     return !this.region_absent ? this.region_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isVerificationLevelPresent() {
/* 2074 */     return !this.verificationLevel_absent;
/*      */   }
/*      */   
/*      */   public Guild.VerificationLevel verificationLevelOrElse(Guild.VerificationLevel defaultValue) {
/* 2078 */     return !this.verificationLevel_absent ? this.verificationLevel_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isDefaultMessageNotificationsLevelPresent() {
/* 2082 */     return !this.defaultMessageNotificationsLevel_absent;
/*      */   }
/*      */   
/*      */   public Guild.NotificationLevel defaultMessageNotificationsLevelOrElse(Guild.NotificationLevel defaultValue) {
/* 2086 */     return !this.defaultMessageNotificationsLevel_absent ? this.defaultMessageNotificationsLevel_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isExplicitContentFilterPresent() {
/* 2090 */     return !this.explicitContentFilter_absent;
/*      */   }
/*      */   
/*      */   public Guild.ContentFilterLevel explicitContentFilterOrElse(Guild.ContentFilterLevel defaultValue) {
/* 2094 */     return !this.explicitContentFilter_absent ? this.explicitContentFilter_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isAfkChannelIdPresent() {
/* 2098 */     return !this.afkChannelId_absent;
/*      */   }
/*      */   
/*      */   public Snowflake afkChannelIdOrElse(Snowflake defaultValue) {
/* 2102 */     return !this.afkChannelId_absent ? this.afkChannelId_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isAfkTimeoutPresent() {
/* 2106 */     return !this.afkTimeout_absent;
/*      */   }
/*      */   
/*      */   public Integer afkTimeoutOrElse(Integer defaultValue) {
/* 2110 */     return !this.afkTimeout_absent ? this.afkTimeout_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isIconPresent() {
/* 2114 */     return !this.icon_absent;
/*      */   }
/*      */   
/*      */   public Image iconOrElse(Image defaultValue) {
/* 2118 */     return !this.icon_absent ? this.icon_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isOwnerIdPresent() {
/* 2122 */     return !this.ownerId_absent;
/*      */   }
/*      */   
/*      */   public Snowflake ownerIdOrElse(Snowflake defaultValue) {
/* 2126 */     return !this.ownerId_absent ? this.ownerId_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isSplashPresent() {
/* 2130 */     return !this.splash_absent;
/*      */   }
/*      */   
/*      */   public Image splashOrElse(Image defaultValue) {
/* 2134 */     return !this.splash_absent ? this.splash_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isDiscoverySplashPresent() {
/* 2138 */     return !this.discoverySplash_absent;
/*      */   }
/*      */   
/*      */   public Image discoverySplashOrElse(Image defaultValue) {
/* 2142 */     return !this.discoverySplash_absent ? this.discoverySplash_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isBannerPresent() {
/* 2146 */     return !this.banner_absent;
/*      */   }
/*      */   
/*      */   public Image bannerOrElse(Image defaultValue) {
/* 2150 */     return !this.banner_absent ? this.banner_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isSystemChannelIdPresent() {
/* 2154 */     return !this.systemChannelId_absent;
/*      */   }
/*      */   
/*      */   public Snowflake systemChannelIdOrElse(Snowflake defaultValue) {
/* 2158 */     return !this.systemChannelId_absent ? this.systemChannelId_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isSystemChannelFlagsPresent() {
/* 2162 */     return !this.systemChannelFlags_absent;
/*      */   }
/*      */   
/*      */   public Guild.SystemChannelFlag systemChannelFlagsOrElse(Guild.SystemChannelFlag defaultValue) {
/* 2166 */     return !this.systemChannelFlags_absent ? this.systemChannelFlags_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isRulesChannelIdPresent() {
/* 2170 */     return !this.rulesChannelId_absent;
/*      */   }
/*      */   
/*      */   public Snowflake rulesChannelIdOrElse(Snowflake defaultValue) {
/* 2174 */     return !this.rulesChannelId_absent ? this.rulesChannelId_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isPublicUpdatesChannelIdPresent() {
/* 2178 */     return !this.publicUpdatesChannelId_absent;
/*      */   }
/*      */   
/*      */   public Snowflake publicUpdatesChannelIdOrElse(Snowflake defaultValue) {
/* 2182 */     return !this.publicUpdatesChannelId_absent ? this.publicUpdatesChannelId_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isPreferredLocalePresent() {
/* 2186 */     return !this.preferredLocale_absent;
/*      */   }
/*      */   
/*      */   public Locale preferredLocaleOrElse(Locale defaultValue) {
/* 2190 */     return !this.preferredLocale_absent ? this.preferredLocale_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isFeaturesPresent() {
/* 2194 */     return !this.features_absent;
/*      */   }
/*      */   
/*      */   public List<String> featuresOrElse(List<String> defaultValue) {
/* 2198 */     return !this.features_absent ? this.features_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isDescriptionPresent() {
/* 2202 */     return !this.description_absent;
/*      */   }
/*      */   
/*      */   public String descriptionOrElse(String defaultValue) {
/* 2206 */     return !this.description_absent ? this.description_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isSafetyAlertsChannelIdPresent() {
/* 2210 */     return !this.safetyAlertsChannelId_absent;
/*      */   }
/*      */   
/*      */   public Snowflake safetyAlertsChannelIdOrElse(Snowflake defaultValue) {
/* 2214 */     return !this.safetyAlertsChannelId_absent ? this.safetyAlertsChannelId_value : defaultValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Builder builder() {
/* 2247 */     return new Builder();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Generated(from = "GuildEditSpecGenerator", generator = "Immutables")
/*      */   public static final class Builder
/*      */   {
/* 2259 */     private Possible<String> name_possible = Possible.absent();
/* 2260 */     private Possible<Optional<Region>> region_possible = Possible.absent();
/* 2261 */     private Possible<Optional<Guild.VerificationLevel>> verificationLevel_possible = Possible.absent();
/* 2262 */     private Possible<Optional<Guild.NotificationLevel>> defaultMessageNotificationsLevel_possible = Possible.absent();
/* 2263 */     private Possible<Optional<Guild.ContentFilterLevel>> explicitContentFilter_possible = Possible.absent();
/* 2264 */     private Possible<Optional<Snowflake>> afkChannelId_possible = Possible.absent();
/* 2265 */     private Possible<Integer> afkTimeout_possible = Possible.absent();
/* 2266 */     private Possible<Optional<Image>> icon_possible = Possible.absent();
/* 2267 */     private Possible<Snowflake> ownerId_possible = Possible.absent();
/* 2268 */     private Possible<Optional<Image>> splash_possible = Possible.absent();
/* 2269 */     private Possible<Optional<Image>> discoverySplash_possible = Possible.absent();
/* 2270 */     private Possible<Optional<Image>> banner_possible = Possible.absent();
/* 2271 */     private Possible<Optional<Snowflake>> systemChannelId_possible = Possible.absent();
/* 2272 */     private Possible<Guild.SystemChannelFlag> systemChannelFlags_possible = Possible.absent();
/* 2273 */     private Possible<Optional<Snowflake>> rulesChannelId_possible = Possible.absent();
/* 2274 */     private Possible<Optional<Snowflake>> publicUpdatesChannelId_possible = Possible.absent();
/* 2275 */     private Possible<Optional<Locale>> preferredLocale_possible = Possible.absent();
/* 2276 */     private List<String> features_list = null;
/* 2277 */     private Possible<Optional<String>> description_possible = Possible.absent();
/* 2278 */     private Possible<Optional<Snowflake>> safetyAlertsChannelId_possible = Possible.absent();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private String reason;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder from(GuildEditSpec instance) {
/* 2292 */       return from(instance);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     final Builder from(GuildEditSpecGenerator instance) {
/* 2302 */       Objects.requireNonNull(instance, "instance");
/* 2303 */       String reasonValue = instance.reason();
/* 2304 */       if (reasonValue != null) {
/* 2305 */         reason(reasonValue);
/*      */       }
/* 2307 */       name(instance.name());
/* 2308 */       region(instance.region());
/* 2309 */       verificationLevel(instance.verificationLevel());
/* 2310 */       defaultMessageNotificationsLevel(instance.defaultMessageNotificationsLevel());
/* 2311 */       explicitContentFilter(instance.explicitContentFilter());
/* 2312 */       afkChannelId(instance.afkChannelId());
/* 2313 */       afkTimeout(instance.afkTimeout());
/* 2314 */       icon(instance.icon());
/* 2315 */       ownerId(instance.ownerId());
/* 2316 */       splash(instance.splash());
/* 2317 */       discoverySplash(instance.discoverySplash());
/* 2318 */       banner(instance.banner());
/* 2319 */       systemChannelId(instance.systemChannelId());
/* 2320 */       systemChannelFlags(instance.systemChannelFlags());
/* 2321 */       rulesChannelId(instance.rulesChannelId());
/* 2322 */       publicUpdatesChannelId(instance.publicUpdatesChannelId());
/* 2323 */       preferredLocale(instance.preferredLocale());
/* 2324 */       features(instance.features());
/* 2325 */       description(instance.description());
/* 2326 */       safetyAlertsChannelId(instance.safetyAlertsChannelId());
/* 2327 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public final Builder reason(@Nullable String reason) {
/* 2337 */       this.reason = reason;
/* 2338 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder name(Possible<String> value) {
/* 2343 */       this.name_possible = value;
/* 2344 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder name(String value) {
/* 2349 */       this.name_possible = Possible.of(value);
/* 2350 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder region(Possible<Optional<Region>> value) {
/* 2355 */       this.region_possible = value;
/* 2356 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     @CanIgnoreReturnValue
/*      */     public Builder region(@Nullable Region value) {
/* 2362 */       this.region_possible = Possible.of(Optional.ofNullable(value));
/* 2363 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder regionOrNull(@Nullable Region value) {
/* 2368 */       this.region_possible = Possible.of(Optional.ofNullable(value));
/* 2369 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder verificationLevel(Possible<Optional<Guild.VerificationLevel>> value) {
/* 2374 */       this.verificationLevel_possible = value;
/* 2375 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     @CanIgnoreReturnValue
/*      */     public Builder verificationLevel(@Nullable Guild.VerificationLevel value) {
/* 2381 */       this.verificationLevel_possible = Possible.of(Optional.ofNullable(value));
/* 2382 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder verificationLevelOrNull(@Nullable Guild.VerificationLevel value) {
/* 2387 */       this.verificationLevel_possible = Possible.of(Optional.ofNullable(value));
/* 2388 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder defaultMessageNotificationsLevel(Possible<Optional<Guild.NotificationLevel>> value) {
/* 2393 */       this.defaultMessageNotificationsLevel_possible = value;
/* 2394 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     @CanIgnoreReturnValue
/*      */     public Builder defaultMessageNotificationsLevel(@Nullable Guild.NotificationLevel value) {
/* 2400 */       this.defaultMessageNotificationsLevel_possible = Possible.of(Optional.ofNullable(value));
/* 2401 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder defaultMessageNotificationsLevelOrNull(@Nullable Guild.NotificationLevel value) {
/* 2406 */       this.defaultMessageNotificationsLevel_possible = Possible.of(Optional.ofNullable(value));
/* 2407 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder explicitContentFilter(Possible<Optional<Guild.ContentFilterLevel>> value) {
/* 2412 */       this.explicitContentFilter_possible = value;
/* 2413 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     @CanIgnoreReturnValue
/*      */     public Builder explicitContentFilter(@Nullable Guild.ContentFilterLevel value) {
/* 2419 */       this.explicitContentFilter_possible = Possible.of(Optional.ofNullable(value));
/* 2420 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder explicitContentFilterOrNull(@Nullable Guild.ContentFilterLevel value) {
/* 2425 */       this.explicitContentFilter_possible = Possible.of(Optional.ofNullable(value));
/* 2426 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder afkChannelId(Possible<Optional<Snowflake>> value) {
/* 2431 */       this.afkChannelId_possible = value;
/* 2432 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     @CanIgnoreReturnValue
/*      */     public Builder afkChannelId(@Nullable Snowflake value) {
/* 2438 */       this.afkChannelId_possible = Possible.of(Optional.ofNullable(value));
/* 2439 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder afkChannelIdOrNull(@Nullable Snowflake value) {
/* 2444 */       this.afkChannelId_possible = Possible.of(Optional.ofNullable(value));
/* 2445 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder afkTimeout(Possible<Integer> value) {
/* 2450 */       this.afkTimeout_possible = value;
/* 2451 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder afkTimeout(Integer value) {
/* 2456 */       this.afkTimeout_possible = Possible.of(value);
/* 2457 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder icon(Possible<Optional<Image>> value) {
/* 2462 */       this.icon_possible = value;
/* 2463 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     @CanIgnoreReturnValue
/*      */     public Builder icon(@Nullable Image value) {
/* 2469 */       this.icon_possible = Possible.of(Optional.ofNullable(value));
/* 2470 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder iconOrNull(@Nullable Image value) {
/* 2475 */       this.icon_possible = Possible.of(Optional.ofNullable(value));
/* 2476 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder ownerId(Possible<Snowflake> value) {
/* 2481 */       this.ownerId_possible = value;
/* 2482 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder ownerId(Snowflake value) {
/* 2487 */       this.ownerId_possible = Possible.of(value);
/* 2488 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder splash(Possible<Optional<Image>> value) {
/* 2493 */       this.splash_possible = value;
/* 2494 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     @CanIgnoreReturnValue
/*      */     public Builder splash(@Nullable Image value) {
/* 2500 */       this.splash_possible = Possible.of(Optional.ofNullable(value));
/* 2501 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder splashOrNull(@Nullable Image value) {
/* 2506 */       this.splash_possible = Possible.of(Optional.ofNullable(value));
/* 2507 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder discoverySplash(Possible<Optional<Image>> value) {
/* 2512 */       this.discoverySplash_possible = value;
/* 2513 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     @CanIgnoreReturnValue
/*      */     public Builder discoverySplash(@Nullable Image value) {
/* 2519 */       this.discoverySplash_possible = Possible.of(Optional.ofNullable(value));
/* 2520 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder discoverySplashOrNull(@Nullable Image value) {
/* 2525 */       this.discoverySplash_possible = Possible.of(Optional.ofNullable(value));
/* 2526 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder banner(Possible<Optional<Image>> value) {
/* 2531 */       this.banner_possible = value;
/* 2532 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     @CanIgnoreReturnValue
/*      */     public Builder banner(@Nullable Image value) {
/* 2538 */       this.banner_possible = Possible.of(Optional.ofNullable(value));
/* 2539 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder bannerOrNull(@Nullable Image value) {
/* 2544 */       this.banner_possible = Possible.of(Optional.ofNullable(value));
/* 2545 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder systemChannelId(Possible<Optional<Snowflake>> value) {
/* 2550 */       this.systemChannelId_possible = value;
/* 2551 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     @CanIgnoreReturnValue
/*      */     public Builder systemChannelId(@Nullable Snowflake value) {
/* 2557 */       this.systemChannelId_possible = Possible.of(Optional.ofNullable(value));
/* 2558 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder systemChannelIdOrNull(@Nullable Snowflake value) {
/* 2563 */       this.systemChannelId_possible = Possible.of(Optional.ofNullable(value));
/* 2564 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder systemChannelFlags(Possible<Guild.SystemChannelFlag> value) {
/* 2569 */       this.systemChannelFlags_possible = value;
/* 2570 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder systemChannelFlags(Guild.SystemChannelFlag value) {
/* 2575 */       this.systemChannelFlags_possible = Possible.of(value);
/* 2576 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder rulesChannelId(Possible<Optional<Snowflake>> value) {
/* 2581 */       this.rulesChannelId_possible = value;
/* 2582 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     @CanIgnoreReturnValue
/*      */     public Builder rulesChannelId(@Nullable Snowflake value) {
/* 2588 */       this.rulesChannelId_possible = Possible.of(Optional.ofNullable(value));
/* 2589 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder rulesChannelIdOrNull(@Nullable Snowflake value) {
/* 2594 */       this.rulesChannelId_possible = Possible.of(Optional.ofNullable(value));
/* 2595 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder publicUpdatesChannelId(Possible<Optional<Snowflake>> value) {
/* 2600 */       this.publicUpdatesChannelId_possible = value;
/* 2601 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     @CanIgnoreReturnValue
/*      */     public Builder publicUpdatesChannelId(@Nullable Snowflake value) {
/* 2607 */       this.publicUpdatesChannelId_possible = Possible.of(Optional.ofNullable(value));
/* 2608 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder publicUpdatesChannelIdOrNull(@Nullable Snowflake value) {
/* 2613 */       this.publicUpdatesChannelId_possible = Possible.of(Optional.ofNullable(value));
/* 2614 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder preferredLocale(Possible<Optional<Locale>> value) {
/* 2619 */       this.preferredLocale_possible = value;
/* 2620 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     @CanIgnoreReturnValue
/*      */     public Builder preferredLocale(@Nullable Locale value) {
/* 2626 */       this.preferredLocale_possible = Possible.of(Optional.ofNullable(value));
/* 2627 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder preferredLocaleOrNull(@Nullable Locale value) {
/* 2632 */       this.preferredLocale_possible = Possible.of(Optional.ofNullable(value));
/* 2633 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder addFeature(String element) {
/* 2638 */       features_getOrCreate().add(element);
/* 2639 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder addAllFeatures(List<String> elements) {
/* 2644 */       features_getOrCreate().addAll(elements);
/* 2645 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder features(Possible<List<String>> elements) {
/* 2650 */       this.features_list = null;
/* 2651 */       elements.toOptional().ifPresent(e -> features_getOrCreate().addAll(e));
/* 2652 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder features(List<String> elements) {
/* 2657 */       this.features_list = new ArrayList<>(elements);
/* 2658 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder features(Iterable<String> elements) {
/* 2663 */       this.features_list = (List<String>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/* 2664 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder description(Possible<Optional<String>> value) {
/* 2669 */       this.description_possible = value;
/* 2670 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     @CanIgnoreReturnValue
/*      */     public Builder description(@Nullable String value) {
/* 2676 */       this.description_possible = Possible.of(Optional.ofNullable(value));
/* 2677 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder descriptionOrNull(@Nullable String value) {
/* 2682 */       this.description_possible = Possible.of(Optional.ofNullable(value));
/* 2683 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder safetyAlertsChannelId(Possible<Optional<Snowflake>> value) {
/* 2688 */       this.safetyAlertsChannelId_possible = value;
/* 2689 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     @CanIgnoreReturnValue
/*      */     public Builder safetyAlertsChannelId(@Nullable Snowflake value) {
/* 2695 */       this.safetyAlertsChannelId_possible = Possible.of(Optional.ofNullable(value));
/* 2696 */       return this;
/*      */     }
/*      */     
/*      */     @CanIgnoreReturnValue
/*      */     public Builder safetyAlertsChannelIdOrNull(@Nullable Snowflake value) {
/* 2701 */       this.safetyAlertsChannelId_possible = Possible.of(Optional.ofNullable(value));
/* 2702 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public GuildEditSpec build() {
/* 2711 */       return GuildEditSpec.validate(new GuildEditSpec(this.reason, 
/*      */             
/* 2713 */             name_build(), 
/* 2714 */             region_build(), 
/* 2715 */             verificationLevel_build(), 
/* 2716 */             defaultMessageNotificationsLevel_build(), 
/* 2717 */             explicitContentFilter_build(), 
/* 2718 */             afkChannelId_build(), 
/* 2719 */             afkTimeout_build(), 
/* 2720 */             icon_build(), 
/* 2721 */             ownerId_build(), 
/* 2722 */             splash_build(), 
/* 2723 */             discoverySplash_build(), 
/* 2724 */             banner_build(), 
/* 2725 */             systemChannelId_build(), 
/* 2726 */             systemChannelFlags_build(), 
/* 2727 */             rulesChannelId_build(), 
/* 2728 */             publicUpdatesChannelId_build(), 
/* 2729 */             preferredLocale_build(), 
/* 2730 */             features_build(), 
/* 2731 */             description_build(), 
/* 2732 */             safetyAlertsChannelId_build()));
/*      */     }
/*      */     
/*      */     private Possible<String> name_build() {
/* 2736 */       return this.name_possible;
/*      */     }
/*      */     
/*      */     private Possible<Optional<Region>> region_build() {
/* 2740 */       return this.region_possible;
/*      */     }
/*      */     
/*      */     private Possible<Optional<Guild.VerificationLevel>> verificationLevel_build() {
/* 2744 */       return this.verificationLevel_possible;
/*      */     }
/*      */     
/*      */     private Possible<Optional<Guild.NotificationLevel>> defaultMessageNotificationsLevel_build() {
/* 2748 */       return this.defaultMessageNotificationsLevel_possible;
/*      */     }
/*      */     
/*      */     private Possible<Optional<Guild.ContentFilterLevel>> explicitContentFilter_build() {
/* 2752 */       return this.explicitContentFilter_possible;
/*      */     }
/*      */     
/*      */     private Possible<Optional<Snowflake>> afkChannelId_build() {
/* 2756 */       return this.afkChannelId_possible;
/*      */     }
/*      */     
/*      */     private Possible<Integer> afkTimeout_build() {
/* 2760 */       return this.afkTimeout_possible;
/*      */     }
/*      */     
/*      */     private Possible<Optional<Image>> icon_build() {
/* 2764 */       return this.icon_possible;
/*      */     }
/*      */     
/*      */     private Possible<Snowflake> ownerId_build() {
/* 2768 */       return this.ownerId_possible;
/*      */     }
/*      */     
/*      */     private Possible<Optional<Image>> splash_build() {
/* 2772 */       return this.splash_possible;
/*      */     }
/*      */     
/*      */     private Possible<Optional<Image>> discoverySplash_build() {
/* 2776 */       return this.discoverySplash_possible;
/*      */     }
/*      */     
/*      */     private Possible<Optional<Image>> banner_build() {
/* 2780 */       return this.banner_possible;
/*      */     }
/*      */     
/*      */     private Possible<Optional<Snowflake>> systemChannelId_build() {
/* 2784 */       return this.systemChannelId_possible;
/*      */     }
/*      */     
/*      */     private Possible<Guild.SystemChannelFlag> systemChannelFlags_build() {
/* 2788 */       return this.systemChannelFlags_possible;
/*      */     }
/*      */     
/*      */     private Possible<Optional<Snowflake>> rulesChannelId_build() {
/* 2792 */       return this.rulesChannelId_possible;
/*      */     }
/*      */     
/*      */     private Possible<Optional<Snowflake>> publicUpdatesChannelId_build() {
/* 2796 */       return this.publicUpdatesChannelId_possible;
/*      */     }
/*      */     
/*      */     private Possible<Optional<Locale>> preferredLocale_build() {
/* 2800 */       return this.preferredLocale_possible;
/*      */     }
/*      */     
/*      */     private Possible<List<String>> features_build() {
/* 2804 */       return (this.features_list == null) ? Possible.absent() : 
/* 2805 */         Possible.of(this.features_list);
/*      */     }
/*      */     
/*      */     private List<String> features_getOrCreate() {
/* 2809 */       if (this.features_list == null) {
/* 2810 */         this.features_list = new ArrayList<>();
/*      */       }
/* 2812 */       return this.features_list;
/*      */     }
/*      */     
/*      */     private Possible<Optional<String>> description_build() {
/* 2816 */       return this.description_possible;
/*      */     }
/*      */     
/*      */     private Possible<Optional<Snowflake>> safetyAlertsChannelId_build() {
/* 2820 */       return this.safetyAlertsChannelId_possible;
/*      */     }
/*      */     
/*      */     private Builder() {}
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\GuildEditSpec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */