/*     */ package discord4j.core.spec;
/*     */ 
/*     */ import com.google.errorprone.annotations.CanIgnoreReturnValue;
/*     */ import java.io.InputStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "MessageCreateFields", generator = "Immutables")
/*     */ final class ImmutableMessageCreateFields
/*     */ {
/*     */   @Generated(from = "MessageCreateFields.File", generator = "Immutables")
/*     */   static final class File
/*     */     implements MessageCreateFields.File
/*     */   {
/*     */     private final String name;
/*     */     private final InputStream inputStream;
/*     */     
/*     */     private File(String name, InputStream inputStream) {
/*  37 */       this.name = Objects.<String>requireNonNull(name, "name");
/*  38 */       this.inputStream = Objects.<InputStream>requireNonNull(inputStream, "inputStream");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private File(File original, String name, InputStream inputStream) {
/*  45 */       this.name = name;
/*  46 */       this.inputStream = inputStream;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String name() {
/*  54 */       return this.name;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public InputStream inputStream() {
/*  62 */       return this.inputStream;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final File withName(String value) {
/*  72 */       String newValue = Objects.<String>requireNonNull(value, "name");
/*  73 */       if (this.name.equals(newValue)) return this; 
/*  74 */       return new File(this, newValue, this.inputStream);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final File withInputStream(InputStream value) {
/*  84 */       if (this.inputStream == value) return this; 
/*  85 */       InputStream newValue = Objects.<InputStream>requireNonNull(value, "inputStream");
/*  86 */       return new File(this, this.name, newValue);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean equals(Object another) {
/*  95 */       if (this == another) return true; 
/*  96 */       return (another instanceof File && 
/*  97 */         equalTo(0, (File)another));
/*     */     }
/*     */     
/*     */     private boolean equalTo(int synthetic, File another) {
/* 101 */       return (this.name.equals(another.name) && this.inputStream
/* 102 */         .equals(another.inputStream));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 111 */       int h = 5381;
/* 112 */       h += (h << 5) + this.name.hashCode();
/* 113 */       h += (h << 5) + this.inputStream.hashCode();
/* 114 */       return h;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String toString() {
/* 123 */       return "File{name=" + this.name + ", inputStream=" + this.inputStream + "}";
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static File of(String name, InputStream inputStream) {
/* 136 */       return new File(name, inputStream);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static File copyOf(MessageCreateFields.File instance) {
/* 147 */       if (instance instanceof File) {
/* 148 */         return (File)instance;
/*     */       }
/* 150 */       return builder()
/* 151 */         .from(instance)
/* 152 */         .build();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Builder builder() {
/* 166 */       return new Builder();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     @Generated(from = "MessageCreateFields.File", generator = "Immutables")
/*     */     public static final class Builder
/*     */     {
/*     */       private static final long INIT_BIT_NAME = 1L;
/*     */ 
/*     */       
/*     */       private static final long INIT_BIT_INPUT_STREAM = 2L;
/*     */ 
/*     */       
/* 180 */       private long initBits = 3L;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       private String name;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       private InputStream inputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @CanIgnoreReturnValue
/*     */       public final Builder from(MessageCreateFields.File instance) {
/* 197 */         Objects.requireNonNull(instance, "instance");
/* 198 */         name(instance.name());
/* 199 */         inputStream(instance.inputStream());
/* 200 */         return this;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @CanIgnoreReturnValue
/*     */       public final Builder name(String name) {
/* 210 */         this.name = Objects.<String>requireNonNull(name, "name");
/* 211 */         this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 212 */         return this;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @CanIgnoreReturnValue
/*     */       public final Builder inputStream(InputStream inputStream) {
/* 222 */         this.inputStream = Objects.<InputStream>requireNonNull(inputStream, "inputStream");
/* 223 */         this.initBits &= 0xFFFFFFFFFFFFFFFDL;
/* 224 */         return this;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public ImmutableMessageCreateFields.File build() {
/* 233 */         if (this.initBits != 0L) {
/* 234 */           throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */         }
/* 236 */         return new ImmutableMessageCreateFields.File(null, this.name, this.inputStream);
/*     */       }
/*     */       
/*     */       private String formatRequiredAttributesMessage() {
/* 240 */         List<String> attributes = new ArrayList<>();
/* 241 */         if ((this.initBits & 0x1L) != 0L) attributes.add("name"); 
/* 242 */         if ((this.initBits & 0x2L) != 0L) attributes.add("inputStream"); 
/* 243 */         return "Cannot build File, some of required attributes are not set " + attributes;
/*     */       }
/*     */ 
/*     */       
/*     */       private Builder() {}
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   @Generated(from = "MessageCreateFields.FileSpoiler", generator = "Immutables")
/*     */   static final class FileSpoiler
/*     */     implements MessageCreateFields.FileSpoiler
/*     */   {
/*     */     private final String name;
/*     */     
/*     */     private final InputStream inputStream;
/*     */ 
/*     */     
/*     */     private FileSpoiler(String name, InputStream inputStream) {
/* 262 */       this.name = Objects.<String>requireNonNull(name, "name");
/* 263 */       this.inputStream = Objects.<InputStream>requireNonNull(inputStream, "inputStream");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private FileSpoiler(FileSpoiler original, String name, InputStream inputStream) {
/* 270 */       this.name = name;
/* 271 */       this.inputStream = inputStream;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String name() {
/* 279 */       return this.name;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public InputStream inputStream() {
/* 287 */       return this.inputStream;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final FileSpoiler withName(String value) {
/* 297 */       String newValue = Objects.<String>requireNonNull(value, "name");
/* 298 */       if (this.name.equals(newValue)) return this; 
/* 299 */       return new FileSpoiler(this, newValue, this.inputStream);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final FileSpoiler withInputStream(InputStream value) {
/* 309 */       if (this.inputStream == value) return this; 
/* 310 */       InputStream newValue = Objects.<InputStream>requireNonNull(value, "inputStream");
/* 311 */       return new FileSpoiler(this, this.name, newValue);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean equals(Object another) {
/* 320 */       if (this == another) return true; 
/* 321 */       return (another instanceof FileSpoiler && 
/* 322 */         equalTo(0, (FileSpoiler)another));
/*     */     }
/*     */     
/*     */     private boolean equalTo(int synthetic, FileSpoiler another) {
/* 326 */       return (this.name.equals(another.name) && this.inputStream
/* 327 */         .equals(another.inputStream));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 336 */       int h = 5381;
/* 337 */       h += (h << 5) + this.name.hashCode();
/* 338 */       h += (h << 5) + this.inputStream.hashCode();
/* 339 */       return h;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String toString() {
/* 348 */       return "FileSpoiler{name=" + this.name + ", inputStream=" + this.inputStream + "}";
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static FileSpoiler of(String name, InputStream inputStream) {
/* 361 */       return new FileSpoiler(name, inputStream);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static FileSpoiler copyOf(MessageCreateFields.FileSpoiler instance) {
/* 372 */       if (instance instanceof FileSpoiler) {
/* 373 */         return (FileSpoiler)instance;
/*     */       }
/* 375 */       return builder()
/* 376 */         .from(instance)
/* 377 */         .build();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Builder builder() {
/* 391 */       return new Builder();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     @Generated(from = "MessageCreateFields.FileSpoiler", generator = "Immutables")
/*     */     public static final class Builder
/*     */     {
/*     */       private static final long INIT_BIT_NAME = 1L;
/*     */ 
/*     */       
/*     */       private static final long INIT_BIT_INPUT_STREAM = 2L;
/*     */ 
/*     */       
/* 405 */       private long initBits = 3L;
/*     */ 
/*     */ 
/*     */       
/*     */       private String name;
/*     */ 
/*     */ 
/*     */       
/*     */       private InputStream inputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @CanIgnoreReturnValue
/*     */       public final Builder from(MessageCreateFields.File instance) {
/* 420 */         Objects.requireNonNull(instance, "instance");
/* 421 */         from(instance);
/* 422 */         return this;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @CanIgnoreReturnValue
/*     */       public final Builder from(MessageCreateFields.FileSpoiler instance) {
/* 432 */         Objects.requireNonNull(instance, "instance");
/* 433 */         from(instance);
/* 434 */         return this;
/*     */       }
/*     */       
/*     */       private void from(Object object) {
/* 438 */         long bits = 0L;
/* 439 */         if (object instanceof MessageCreateFields.File) {
/* 440 */           MessageCreateFields.File instance = (MessageCreateFields.File)object;
/* 441 */           if ((bits & 0x1L) == 0L) {
/* 442 */             name(instance.name());
/* 443 */             bits |= 0x1L;
/*     */           } 
/* 445 */           if ((bits & 0x2L) == 0L) {
/* 446 */             inputStream(instance.inputStream());
/* 447 */             bits |= 0x2L;
/*     */           } 
/*     */         } 
/* 450 */         if (object instanceof MessageCreateFields.FileSpoiler) {
/* 451 */           MessageCreateFields.FileSpoiler instance = (MessageCreateFields.FileSpoiler)object;
/* 452 */           if ((bits & 0x1L) == 0L) {
/* 453 */             name(instance.name());
/* 454 */             bits |= 0x1L;
/*     */           } 
/* 456 */           if ((bits & 0x2L) == 0L) {
/* 457 */             inputStream(instance.inputStream());
/* 458 */             bits |= 0x2L;
/*     */           } 
/*     */         } 
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @CanIgnoreReturnValue
/*     */       public final Builder name(String name) {
/* 470 */         this.name = Objects.<String>requireNonNull(name, "name");
/* 471 */         this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 472 */         return this;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @CanIgnoreReturnValue
/*     */       public final Builder inputStream(InputStream inputStream) {
/* 482 */         this.inputStream = Objects.<InputStream>requireNonNull(inputStream, "inputStream");
/* 483 */         this.initBits &= 0xFFFFFFFFFFFFFFFDL;
/* 484 */         return this;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public ImmutableMessageCreateFields.FileSpoiler build() {
/* 493 */         if (this.initBits != 0L) {
/* 494 */           throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */         }
/* 496 */         return new ImmutableMessageCreateFields.FileSpoiler(null, this.name, this.inputStream);
/*     */       }
/*     */       
/*     */       private String formatRequiredAttributesMessage() {
/* 500 */         List<String> attributes = new ArrayList<>();
/* 501 */         if ((this.initBits & 0x1L) != 0L) attributes.add("name"); 
/* 502 */         if ((this.initBits & 0x2L) != 0L) attributes.add("inputStream"); 
/* 503 */         return "Cannot build FileSpoiler, some of required attributes are not set " + attributes;
/*     */       }
/*     */       
/*     */       private Builder() {}
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\ImmutableMessageCreateFields.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */