/*     */ package discord4j.core.spec;
/*     */ 
/*     */ import com.google.errorprone.annotations.CanIgnoreReturnValue;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import discord4j.rest.util.Image;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "GuildCreateFromTemplateSpecGenerator", generator = "Immutables")
/*     */ public final class GuildCreateFromTemplateSpec
/*     */   implements GuildCreateFromTemplateSpecGenerator
/*     */ {
/*     */   private final String name;
/*     */   private final Image icon_value;
/*     */   private final boolean icon_absent;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   private volatile transient InitShim initShim;
/*     */   
/*     */   private GuildCreateFromTemplateSpec(String name) {
/*  48 */     this.initShim = new InitShim(); this.name = Objects.<String>requireNonNull(name, "name"); Possible<Image> icon$impl = Possible.absent(); this.icon_value = icon$impl.toOptional().orElse(null); this.icon_absent = icon$impl.isAbsent(); this.initShim = null; } private GuildCreateFromTemplateSpec(String name, Possible<Image> icon) { this.initShim = new InitShim();
/*     */     this.name = name;
/*     */     Possible<Image> icon$impl = icon;
/*     */     this.icon_value = icon$impl.toOptional().orElse(null);
/*     */     this.icon_absent = icon$impl.isAbsent();
/*     */     this.initShim = null; } @Generated(from = "GuildCreateFromTemplateSpecGenerator", generator = "Immutables")
/*  54 */   private final class InitShim { private InitShim() {} private String formatInitCycleMessage() { List<String> attributes = new ArrayList<>();
/*  55 */       return "Cannot build GuildCreateFromTemplateSpec, attribute initializers form cycle " + attributes; }
/*     */      }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String name() {
/*  64 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Image> icon() {
/*  72 */     return this.icon_absent ? Possible.absent() : Possible.of(this.icon_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final GuildCreateFromTemplateSpec withName(String value) {
/*  82 */     String newValue = Objects.<String>requireNonNull(value, "name");
/*  83 */     if (this.name.equals(newValue)) return this; 
/*  84 */     return new GuildCreateFromTemplateSpec(newValue, icon());
/*     */   }
/*     */   
/*     */   public GuildCreateFromTemplateSpec withIcon(Possible<Image> value) {
/*  88 */     Possible<Image> newValue = Objects.<Possible<Image>>requireNonNull(value);
/*  89 */     return new GuildCreateFromTemplateSpec(this.name, newValue);
/*     */   }
/*     */   
/*     */   public GuildCreateFromTemplateSpec withIcon(Image value) {
/*  93 */     Possible<Image> newValue = Possible.of(value);
/*  94 */     return new GuildCreateFromTemplateSpec(this.name, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 103 */     if (this == another) return true; 
/* 104 */     return (another instanceof GuildCreateFromTemplateSpec && 
/* 105 */       equalTo(0, (GuildCreateFromTemplateSpec)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, GuildCreateFromTemplateSpec another) {
/* 109 */     return (this.name.equals(another.name) && 
/* 110 */       icon().equals(another.icon()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 119 */     int h = 5381;
/* 120 */     h += (h << 5) + this.name.hashCode();
/* 121 */     h += (h << 5) + icon().hashCode();
/* 122 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 131 */     return "GuildCreateFromTemplateSpec{name=" + this.name + ", icon=" + 
/*     */       
/* 133 */       icon().toString() + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static GuildCreateFromTemplateSpec of(String name) {
/* 143 */     return new GuildCreateFromTemplateSpec(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static GuildCreateFromTemplateSpec copyOf(GuildCreateFromTemplateSpecGenerator instance) {
/* 154 */     if (instance instanceof GuildCreateFromTemplateSpec) {
/* 155 */       return (GuildCreateFromTemplateSpec)instance;
/*     */     }
/* 157 */     return builder()
/* 158 */       .from(instance)
/* 159 */       .build();
/*     */   }
/*     */   
/*     */   public boolean isIconPresent() {
/* 163 */     return !this.icon_absent;
/*     */   }
/*     */   
/*     */   public Image iconOrElse(Image defaultValue) {
/* 167 */     return !this.icon_absent ? this.icon_value : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 181 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "GuildCreateFromTemplateSpecGenerator", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_NAME = 1L;
/*     */ 
/*     */ 
/*     */     
/* 194 */     private long initBits = 1L;
/*     */     
/* 196 */     private Possible<Image> icon_possible = Possible.absent();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private String name;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(GuildCreateFromTemplateSpec instance) {
/* 210 */       return from(instance);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     final Builder from(GuildCreateFromTemplateSpecGenerator instance) {
/* 220 */       Objects.requireNonNull(instance, "instance");
/* 221 */       name(instance.name());
/* 222 */       icon(instance.icon());
/* 223 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public final Builder name(String name) {
/* 233 */       this.name = Objects.<String>requireNonNull(name, "name");
/* 234 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 235 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder icon(Possible<Image> value) {
/* 240 */       this.icon_possible = value;
/* 241 */       return this;
/*     */     }
/*     */     
/*     */     @CanIgnoreReturnValue
/*     */     public Builder icon(Image value) {
/* 246 */       this.icon_possible = Possible.of(value);
/* 247 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public GuildCreateFromTemplateSpec build() {
/* 256 */       if (this.initBits != 0L) {
/* 257 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 259 */       return new GuildCreateFromTemplateSpec(this.name, icon_build());
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 263 */       List<String> attributes = new ArrayList<>();
/* 264 */       if ((this.initBits & 0x1L) != 0L) attributes.add("name"); 
/* 265 */       return "Cannot build GuildCreateFromTemplateSpec, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Possible<Image> icon_build() {
/* 269 */       return this.icon_possible;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\GuildCreateFromTemplateSpec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */