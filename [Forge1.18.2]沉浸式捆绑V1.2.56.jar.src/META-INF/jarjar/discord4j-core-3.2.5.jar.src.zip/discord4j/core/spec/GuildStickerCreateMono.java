/*     */ package discord4j.core.spec;
/*     */ 
/*     */ import discord4j.core.object.entity.Guild;
/*     */ import discord4j.core.object.entity.GuildSticker;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "GuildStickerCreateMonoGenerator", generator = "Immutables")
/*     */ public final class GuildStickerCreateMono
/*     */   extends GuildStickerCreateMonoGenerator
/*     */ {
/*     */   @Nullable
/*     */   private final String reason;
/*     */   private final String name;
/*     */   private final String description;
/*     */   private final String tags;
/*     */   private final String file;
/*     */   private final Guild guild;
/*     */   
/*     */   private GuildStickerCreateMono(String name, String description, String tags, String file, Guild guild) {
/*  32 */     this.name = Objects.<String>requireNonNull(name, "name");
/*  33 */     this.description = Objects.<String>requireNonNull(description, "description");
/*  34 */     this.tags = Objects.<String>requireNonNull(tags, "tags");
/*  35 */     this.file = Objects.<String>requireNonNull(file, "file");
/*  36 */     this.guild = Objects.<Guild>requireNonNull(guild, "guild");
/*  37 */     this.reason = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private GuildStickerCreateMono(@Nullable String reason, String name, String description, String tags, String file, Guild guild) {
/*  47 */     this.reason = reason;
/*  48 */     this.name = name;
/*  49 */     this.description = description;
/*  50 */     this.tags = tags;
/*  51 */     this.file = file;
/*  52 */     this.guild = guild;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String reason() {
/*  61 */     return this.reason;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String name() {
/*  69 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String description() {
/*  77 */     return this.description;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String tags() {
/*  85 */     return this.tags;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String file() {
/*  93 */     return this.file;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Guild guild() {
/* 101 */     return this.guild;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final GuildStickerCreateMono withReason(@Nullable String value) {
/* 111 */     if (Objects.equals(this.reason, value)) return this; 
/* 112 */     return new GuildStickerCreateMono(value, this.name, this.description, this.tags, this.file, this.guild);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final GuildStickerCreateMono withName(String value) {
/* 122 */     String newValue = Objects.<String>requireNonNull(value, "name");
/* 123 */     if (this.name.equals(newValue)) return this; 
/* 124 */     return new GuildStickerCreateMono(this.reason, newValue, this.description, this.tags, this.file, this.guild);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final GuildStickerCreateMono withDescription(String value) {
/* 134 */     String newValue = Objects.<String>requireNonNull(value, "description");
/* 135 */     if (this.description.equals(newValue)) return this; 
/* 136 */     return new GuildStickerCreateMono(this.reason, this.name, newValue, this.tags, this.file, this.guild);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final GuildStickerCreateMono withTags(String value) {
/* 146 */     String newValue = Objects.<String>requireNonNull(value, "tags");
/* 147 */     if (this.tags.equals(newValue)) return this; 
/* 148 */     return new GuildStickerCreateMono(this.reason, this.name, this.description, newValue, this.file, this.guild);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final GuildStickerCreateMono withFile(String value) {
/* 158 */     String newValue = Objects.<String>requireNonNull(value, "file");
/* 159 */     if (this.file.equals(newValue)) return this; 
/* 160 */     return new GuildStickerCreateMono(this.reason, this.name, this.description, this.tags, newValue, this.guild);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final GuildStickerCreateMono withGuild(Guild value) {
/* 170 */     if (this.guild == value) return this; 
/* 171 */     Guild newValue = Objects.<Guild>requireNonNull(value, "guild");
/* 172 */     return new GuildStickerCreateMono(this.reason, this.name, this.description, this.tags, this.file, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 181 */     if (this == another) return true; 
/* 182 */     return (another instanceof GuildStickerCreateMono && 
/* 183 */       equalTo(0, (GuildStickerCreateMono)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, GuildStickerCreateMono another) {
/* 187 */     return (Objects.equals(this.reason, another.reason) && this.name
/* 188 */       .equals(another.name) && this.description
/* 189 */       .equals(another.description) && this.tags
/* 190 */       .equals(another.tags) && this.file
/* 191 */       .equals(another.file) && this.guild
/* 192 */       .equals(another.guild));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 201 */     int h = 5381;
/* 202 */     h += (h << 5) + Objects.hashCode(this.reason);
/* 203 */     h += (h << 5) + this.name.hashCode();
/* 204 */     h += (h << 5) + this.description.hashCode();
/* 205 */     h += (h << 5) + this.tags.hashCode();
/* 206 */     h += (h << 5) + this.file.hashCode();
/* 207 */     h += (h << 5) + this.guild.hashCode();
/* 208 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 217 */     return "GuildStickerCreateMono{reason=" + this.reason + ", name=" + this.name + ", description=" + this.description + ", tags=" + this.tags + ", file=" + this.file + ", guild=" + this.guild + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static GuildStickerCreateMono of(String name, String description, String tags, String file, Guild guild) {
/* 237 */     return new GuildStickerCreateMono(name, description, tags, file, guild);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static GuildStickerCreateMono copyOf(GuildStickerCreateMonoGenerator instance) {
/* 248 */     if (instance instanceof GuildStickerCreateMono) {
/* 249 */       return (GuildStickerCreateMono)instance;
/*     */     }
/* 251 */     return of(instance.name(), instance.description(), instance.tags(), instance.file(), instance.guild())
/* 252 */       .withReason(instance.reason());
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\GuildStickerCreateMono.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */