/*    */ package discord4j.core.spec;
/*    */ 
/*    */ import discord4j.discordjson.json.WebhookCreateRequest;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import discord4j.rest.util.Image;
/*    */ import java.util.Optional;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Immutable
/*    */ interface WebhookCreateSpecGenerator
/*    */   extends AuditSpec<WebhookCreateRequest>
/*    */ {
/*    */   default WebhookCreateRequest asRequest() {
/* 42 */     return (WebhookCreateRequest)WebhookCreateRequest.builder()
/* 43 */       .name(name())
/* 44 */       .avatar(InternalSpecUtils.mapPossibleOptional(avatar(), Image::getDataUri))
/* 45 */       .build();
/*    */   }
/*    */   
/*    */   Possible<Optional<Image>> avatar();
/*    */   
/*    */   String name();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\WebhookCreateSpecGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */