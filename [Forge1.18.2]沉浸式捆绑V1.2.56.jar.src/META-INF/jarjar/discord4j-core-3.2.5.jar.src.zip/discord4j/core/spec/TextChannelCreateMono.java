/*     */ package discord4j.core.spec;
/*     */ 
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.object.PermissionOverwrite;
/*     */ import discord4j.core.object.entity.Guild;
/*     */ import discord4j.core.object.entity.channel.TextChannel;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.stream.StreamSupport;
/*     */ import org.immutables.value.Generated;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "TextChannelCreateMonoGenerator", generator = "Immutables")
/*     */ public final class TextChannelCreateMono
/*     */   extends TextChannelCreateMonoGenerator
/*     */ {
/*     */   @Nullable
/*     */   private final String reason;
/*     */   private final String name;
/*     */   private final String topic_value;
/*     */   private final boolean topic_absent;
/*     */   private final Integer rateLimitPerUser_value;
/*     */   private final boolean rateLimitPerUser_absent;
/*     */   private final Integer position_value;
/*     */   private final boolean position_absent;
/*     */   private final List<PermissionOverwrite> permissionOverwrites_value;
/*     */   private final boolean permissionOverwrites_absent;
/*     */   private final Snowflake parentId_value;
/*     */   private final boolean parentId_absent;
/*     */   private final Boolean nsfw_value;
/*     */   private final boolean nsfw_absent;
/*     */   private final Guild guild;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   private volatile transient InitShim initShim;
/*     */   
/*     */   private TextChannelCreateMono(String name, Guild guild) {
/* 105 */     this.initShim = new InitShim(); this.name = Objects.<String>requireNonNull(name, "name"); this.guild = Objects.<Guild>requireNonNull(guild, "guild"); this.reason = null; Possible<String> topic$impl = Possible.absent(); Possible<Integer> rateLimitPerUser$impl = Possible.absent(); Possible<Integer> position$impl = Possible.absent(); Possible<List<PermissionOverwrite>> permissionOverwrites$impl = Possible.absent(); Possible<Snowflake> parentId$impl = Possible.absent(); Possible<Boolean> nsfw$impl = Possible.absent(); this.topic_value = topic$impl.toOptional().orElse(null); this.topic_absent = topic$impl.isAbsent(); this.rateLimitPerUser_value = rateLimitPerUser$impl.toOptional().orElse(null); this.rateLimitPerUser_absent = rateLimitPerUser$impl.isAbsent(); this.position_value = position$impl.toOptional().orElse(null); this.position_absent = position$impl.isAbsent(); this.permissionOverwrites_value = permissionOverwrites$impl.toOptional().orElse(null); this.permissionOverwrites_absent = permissionOverwrites$impl.isAbsent(); this.parentId_value = parentId$impl.toOptional().orElse(null); this.parentId_absent = parentId$impl.isAbsent(); this.nsfw_value = nsfw$impl.toOptional().orElse(null); this.nsfw_absent = nsfw$impl.isAbsent(); this.initShim = null; } private TextChannelCreateMono(@Nullable String reason, String name, Possible<String> topic, Possible<Integer> rateLimitPerUser, Possible<Integer> position, Possible<List<PermissionOverwrite>> permissionOverwrites, Possible<Snowflake> parentId, Possible<Boolean> nsfw, Guild guild) { this.initShim = new InitShim(); this.reason = reason; this.name = name; Possible<String> topic$impl = topic; Possible<Integer> rateLimitPerUser$impl = rateLimitPerUser; Possible<Integer> position$impl = position; Possible<List<PermissionOverwrite>> permissionOverwrites$impl = permissionOverwrites; Possible<Snowflake> parentId$impl = parentId; Possible<Boolean> nsfw$impl = nsfw; this.guild = guild; this.topic_value = topic$impl.toOptional().orElse(null); this.topic_absent = topic$impl.isAbsent(); this.rateLimitPerUser_value = rateLimitPerUser$impl.toOptional().orElse(null); this.rateLimitPerUser_absent = rateLimitPerUser$impl.isAbsent(); this.position_value = position$impl.toOptional().orElse(null); this.position_absent = position$impl.isAbsent(); this.permissionOverwrites_value = permissionOverwrites$impl.toOptional().orElse(null);
/*     */     this.permissionOverwrites_absent = permissionOverwrites$impl.isAbsent();
/*     */     this.parentId_value = parentId$impl.toOptional().orElse(null);
/*     */     this.parentId_absent = parentId$impl.isAbsent();
/*     */     this.nsfw_value = nsfw$impl.toOptional().orElse(null);
/*     */     this.nsfw_absent = nsfw$impl.isAbsent();
/* 111 */     this.initShim = null; } @Generated(from = "TextChannelCreateMonoGenerator", generator = "Immutables") private final class InitShim { private InitShim() {} private String formatInitCycleMessage() { List<String> attributes = new ArrayList<>();
/* 112 */       return "Cannot build TextChannelCreateMono, attribute initializers form cycle " + attributes; }
/*     */      }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String reason() {
/* 122 */     return this.reason;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String name() {
/* 130 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<String> topic() {
/* 138 */     return this.topic_absent ? Possible.absent() : Possible.of(this.topic_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Integer> rateLimitPerUser() {
/* 146 */     return this.rateLimitPerUser_absent ? Possible.absent() : Possible.of(this.rateLimitPerUser_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Integer> position() {
/* 154 */     return this.position_absent ? Possible.absent() : Possible.of(this.position_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<List<PermissionOverwrite>> permissionOverwrites() {
/* 162 */     return this.permissionOverwrites_absent ? Possible.absent() : 
/* 163 */       Possible.of(this.permissionOverwrites_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Snowflake> parentId() {
/* 171 */     return this.parentId_absent ? Possible.absent() : Possible.of(this.parentId_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Boolean> nsfw() {
/* 179 */     return this.nsfw_absent ? Possible.absent() : Possible.of(this.nsfw_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Guild guild() {
/* 187 */     return this.guild;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final TextChannelCreateMono withReason(@Nullable String value) {
/* 197 */     if (Objects.equals(this.reason, value)) return this; 
/* 198 */     return new TextChannelCreateMono(value, this.name, 
/*     */ 
/*     */         
/* 201 */         topic(), 
/* 202 */         rateLimitPerUser(), 
/* 203 */         position(), 
/* 204 */         permissionOverwrites(), 
/* 205 */         parentId(), 
/* 206 */         nsfw(), this.guild);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final TextChannelCreateMono withName(String value) {
/* 217 */     String newValue = Objects.<String>requireNonNull(value, "name");
/* 218 */     if (this.name.equals(newValue)) return this; 
/* 219 */     return new TextChannelCreateMono(this.reason, newValue, 
/*     */ 
/*     */         
/* 222 */         topic(), 
/* 223 */         rateLimitPerUser(), 
/* 224 */         position(), 
/* 225 */         permissionOverwrites(), 
/* 226 */         parentId(), 
/* 227 */         nsfw(), this.guild);
/*     */   }
/*     */ 
/*     */   
/*     */   public TextChannelCreateMono withTopic(Possible<String> value) {
/* 232 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/* 233 */     return new TextChannelCreateMono(this.reason, this.name, newValue, 
/*     */ 
/*     */ 
/*     */         
/* 237 */         rateLimitPerUser(), 
/* 238 */         position(), 
/* 239 */         permissionOverwrites(), 
/* 240 */         parentId(), 
/* 241 */         nsfw(), this.guild);
/*     */   }
/*     */ 
/*     */   
/*     */   public TextChannelCreateMono withTopic(String value) {
/* 246 */     Possible<String> newValue = Possible.of(value);
/* 247 */     return new TextChannelCreateMono(this.reason, this.name, newValue, 
/*     */ 
/*     */ 
/*     */         
/* 251 */         rateLimitPerUser(), 
/* 252 */         position(), 
/* 253 */         permissionOverwrites(), 
/* 254 */         parentId(), 
/* 255 */         nsfw(), this.guild);
/*     */   }
/*     */ 
/*     */   
/*     */   public TextChannelCreateMono withRateLimitPerUser(Possible<Integer> value) {
/* 260 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/* 261 */     return new TextChannelCreateMono(this.reason, this.name, 
/*     */ 
/*     */         
/* 264 */         topic(), newValue, 
/*     */         
/* 266 */         position(), 
/* 267 */         permissionOverwrites(), 
/* 268 */         parentId(), 
/* 269 */         nsfw(), this.guild);
/*     */   }
/*     */ 
/*     */   
/*     */   public TextChannelCreateMono withRateLimitPerUser(Integer value) {
/* 274 */     Possible<Integer> newValue = Possible.of(value);
/* 275 */     return new TextChannelCreateMono(this.reason, this.name, 
/*     */ 
/*     */         
/* 278 */         topic(), newValue, 
/*     */         
/* 280 */         position(), 
/* 281 */         permissionOverwrites(), 
/* 282 */         parentId(), 
/* 283 */         nsfw(), this.guild);
/*     */   }
/*     */ 
/*     */   
/*     */   public TextChannelCreateMono withPosition(Possible<Integer> value) {
/* 288 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/* 289 */     return new TextChannelCreateMono(this.reason, this.name, 
/*     */ 
/*     */         
/* 292 */         topic(), 
/* 293 */         rateLimitPerUser(), newValue, 
/*     */         
/* 295 */         permissionOverwrites(), 
/* 296 */         parentId(), 
/* 297 */         nsfw(), this.guild);
/*     */   }
/*     */ 
/*     */   
/*     */   public TextChannelCreateMono withPosition(Integer value) {
/* 302 */     Possible<Integer> newValue = Possible.of(value);
/* 303 */     return new TextChannelCreateMono(this.reason, this.name, 
/*     */ 
/*     */         
/* 306 */         topic(), 
/* 307 */         rateLimitPerUser(), newValue, 
/*     */         
/* 309 */         permissionOverwrites(), 
/* 310 */         parentId(), 
/* 311 */         nsfw(), this.guild);
/*     */   }
/*     */ 
/*     */   
/*     */   public TextChannelCreateMono withPermissionOverwrites(Possible<List<PermissionOverwrite>> possible) {
/* 316 */     Possible<List<PermissionOverwrite>> newValue = Objects.<Possible<List<PermissionOverwrite>>>requireNonNull(possible);
/* 317 */     return new TextChannelCreateMono(this.reason, this.name, 
/*     */ 
/*     */         
/* 320 */         topic(), 
/* 321 */         rateLimitPerUser(), 
/* 322 */         position(), newValue, 
/*     */         
/* 324 */         parentId(), 
/* 325 */         nsfw(), this.guild);
/*     */   }
/*     */ 
/*     */   
/*     */   public TextChannelCreateMono withPermissionOverwrites(Iterable<PermissionOverwrite> elements) {
/* 330 */     Possible<List<PermissionOverwrite>> newValue = Possible.of(
/* 331 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/* 332 */     return new TextChannelCreateMono(this.reason, this.name, 
/*     */ 
/*     */         
/* 335 */         topic(), 
/* 336 */         rateLimitPerUser(), 
/* 337 */         position(), newValue, 
/*     */         
/* 339 */         parentId(), 
/* 340 */         nsfw(), this.guild);
/*     */   }
/*     */ 
/*     */   
/*     */   @SafeVarargs
/*     */   public final TextChannelCreateMono withPermissionOverwrites(PermissionOverwrite... elements) {
/* 346 */     Possible<List<PermissionOverwrite>> newValue = Possible.of(Arrays.asList(elements));
/* 347 */     return new TextChannelCreateMono(this.reason, this.name, 
/*     */ 
/*     */         
/* 350 */         topic(), 
/* 351 */         rateLimitPerUser(), 
/* 352 */         position(), newValue, 
/*     */         
/* 354 */         parentId(), 
/* 355 */         nsfw(), this.guild);
/*     */   }
/*     */ 
/*     */   
/*     */   public TextChannelCreateMono withParentId(Possible<Snowflake> value) {
/* 360 */     Possible<Snowflake> newValue = Objects.<Possible<Snowflake>>requireNonNull(value);
/* 361 */     return new TextChannelCreateMono(this.reason, this.name, 
/*     */ 
/*     */         
/* 364 */         topic(), 
/* 365 */         rateLimitPerUser(), 
/* 366 */         position(), 
/* 367 */         permissionOverwrites(), newValue, 
/*     */         
/* 369 */         nsfw(), this.guild);
/*     */   }
/*     */ 
/*     */   
/*     */   public TextChannelCreateMono withParentId(Snowflake value) {
/* 374 */     Possible<Snowflake> newValue = Possible.of(value);
/* 375 */     return new TextChannelCreateMono(this.reason, this.name, 
/*     */ 
/*     */         
/* 378 */         topic(), 
/* 379 */         rateLimitPerUser(), 
/* 380 */         position(), 
/* 381 */         permissionOverwrites(), newValue, 
/*     */         
/* 383 */         nsfw(), this.guild);
/*     */   }
/*     */ 
/*     */   
/*     */   public TextChannelCreateMono withNsfw(Possible<Boolean> value) {
/* 388 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/* 389 */     return new TextChannelCreateMono(this.reason, this.name, 
/*     */ 
/*     */         
/* 392 */         topic(), 
/* 393 */         rateLimitPerUser(), 
/* 394 */         position(), 
/* 395 */         permissionOverwrites(), 
/* 396 */         parentId(), newValue, this.guild);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public TextChannelCreateMono withNsfw(Boolean value) {
/* 402 */     Possible<Boolean> newValue = Possible.of(value);
/* 403 */     return new TextChannelCreateMono(this.reason, this.name, 
/*     */ 
/*     */         
/* 406 */         topic(), 
/* 407 */         rateLimitPerUser(), 
/* 408 */         position(), 
/* 409 */         permissionOverwrites(), 
/* 410 */         parentId(), newValue, this.guild);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final TextChannelCreateMono withGuild(Guild value) {
/* 422 */     if (this.guild == value) return this; 
/* 423 */     Guild newValue = Objects.<Guild>requireNonNull(value, "guild");
/* 424 */     return new TextChannelCreateMono(this.reason, this.name, 
/*     */ 
/*     */         
/* 427 */         topic(), 
/* 428 */         rateLimitPerUser(), 
/* 429 */         position(), 
/* 430 */         permissionOverwrites(), 
/* 431 */         parentId(), 
/* 432 */         nsfw(), newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 442 */     if (this == another) return true; 
/* 443 */     return (another instanceof TextChannelCreateMono && 
/* 444 */       equalTo(0, (TextChannelCreateMono)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, TextChannelCreateMono another) {
/* 448 */     return (Objects.equals(this.reason, another.reason) && this.name
/* 449 */       .equals(another.name) && 
/* 450 */       topic().equals(another.topic()) && 
/* 451 */       rateLimitPerUser().equals(another.rateLimitPerUser()) && 
/* 452 */       position().equals(another.position()) && 
/* 453 */       Objects.equals(this.permissionOverwrites_value, another.permissionOverwrites_value) && 
/* 454 */       parentId().equals(another.parentId()) && 
/* 455 */       nsfw().equals(another.nsfw()) && this.guild
/* 456 */       .equals(another.guild));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 465 */     int h = 5381;
/* 466 */     h += (h << 5) + Objects.hashCode(this.reason);
/* 467 */     h += (h << 5) + this.name.hashCode();
/* 468 */     h += (h << 5) + topic().hashCode();
/* 469 */     h += (h << 5) + rateLimitPerUser().hashCode();
/* 470 */     h += (h << 5) + position().hashCode();
/* 471 */     h += (h << 5) + Objects.hashCode(this.permissionOverwrites_value);
/* 472 */     h += (h << 5) + parentId().hashCode();
/* 473 */     h += (h << 5) + nsfw().hashCode();
/* 474 */     h += (h << 5) + this.guild.hashCode();
/* 475 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 484 */     return "TextChannelCreateMono{reason=" + this.reason + ", name=" + this.name + ", topic=" + 
/*     */ 
/*     */       
/* 487 */       topic().toString() + ", rateLimitPerUser=" + 
/* 488 */       rateLimitPerUser().toString() + ", position=" + 
/* 489 */       position().toString() + ", permissionOverwrites=" + 
/* 490 */       Objects.toString(this.permissionOverwrites_value) + ", parentId=" + 
/* 491 */       parentId().toString() + ", nsfw=" + 
/* 492 */       nsfw().toString() + ", guild=" + this.guild + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static TextChannelCreateMono of(String name, Guild guild) {
/* 504 */     return new TextChannelCreateMono(name, guild);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static TextChannelCreateMono copyOf(TextChannelCreateMonoGenerator instance) {
/* 515 */     if (instance instanceof TextChannelCreateMono) {
/* 516 */       return (TextChannelCreateMono)instance;
/*     */     }
/* 518 */     return of(instance.name(), instance.guild())
/* 519 */       .withReason(instance.reason())
/* 520 */       .withTopic(instance.topic())
/* 521 */       .withRateLimitPerUser(instance.rateLimitPerUser())
/* 522 */       .withPosition(instance.position())
/* 523 */       .withPermissionOverwrites(instance.permissionOverwrites())
/* 524 */       .withParentId(instance.parentId())
/* 525 */       .withNsfw(instance.nsfw());
/*     */   }
/*     */   
/*     */   public boolean isTopicPresent() {
/* 529 */     return !this.topic_absent;
/*     */   }
/*     */   
/*     */   public String topicOrElse(String defaultValue) {
/* 533 */     return !this.topic_absent ? this.topic_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isRateLimitPerUserPresent() {
/* 537 */     return !this.rateLimitPerUser_absent;
/*     */   }
/*     */   
/*     */   public Integer rateLimitPerUserOrElse(Integer defaultValue) {
/* 541 */     return !this.rateLimitPerUser_absent ? this.rateLimitPerUser_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isPositionPresent() {
/* 545 */     return !this.position_absent;
/*     */   }
/*     */   
/*     */   public Integer positionOrElse(Integer defaultValue) {
/* 549 */     return !this.position_absent ? this.position_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isPermissionOverwritesPresent() {
/* 553 */     return !this.permissionOverwrites_absent;
/*     */   }
/*     */   
/*     */   public List<PermissionOverwrite> permissionOverwritesOrElse(List<PermissionOverwrite> defaultValue) {
/* 557 */     return !this.permissionOverwrites_absent ? this.permissionOverwrites_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isParentIdPresent() {
/* 561 */     return !this.parentId_absent;
/*     */   }
/*     */   
/*     */   public Snowflake parentIdOrElse(Snowflake defaultValue) {
/* 565 */     return !this.parentId_absent ? this.parentId_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isNsfwPresent() {
/* 569 */     return !this.nsfw_absent;
/*     */   }
/*     */   
/*     */   public Boolean nsfwOrElse(Boolean defaultValue) {
/* 573 */     return !this.nsfw_absent ? this.nsfw_value : defaultValue;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\TextChannelCreateMono.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */