/*    */ package discord4j.core.spec;
/*    */ 
/*    */ import discord4j.common.util.Snowflake;
/*    */ import discord4j.core.object.PermissionOverwrite;
/*    */ import discord4j.core.object.entity.channel.Channel;
/*    */ import discord4j.discordjson.json.ChannelCreateRequest;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import java.util.List;
/*    */ import java.util.stream.Collectors;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Immutable
/*    */ interface TextChannelCreateSpecGenerator
/*    */   extends AuditSpec<ChannelCreateRequest>
/*    */ {
/*    */   default ChannelCreateRequest asRequest() {
/* 55 */     return (ChannelCreateRequest)ChannelCreateRequest.builder()
/* 56 */       .type(Integer.valueOf(Channel.Type.GUILD_TEXT.getValue()))
/* 57 */       .name(name())
/* 58 */       .topic(topic())
/* 59 */       .rateLimitPerUser(rateLimitPerUser())
/* 60 */       .position(position())
/* 61 */       .permissionOverwrites(InternalSpecUtils.mapPossible(permissionOverwrites(), po -> (List)po.stream().map(PermissionOverwrite::getData).collect(Collectors.toList())))
/*    */ 
/*    */       
/* 64 */       .parentId(InternalSpecUtils.mapPossible(parentId(), Snowflake::asString))
/* 65 */       .nsfw(nsfw())
/* 66 */       .build();
/*    */   }
/*    */   
/*    */   String name();
/*    */   
/*    */   Possible<String> topic();
/*    */   
/*    */   Possible<Integer> rateLimitPerUser();
/*    */   
/*    */   Possible<Integer> position();
/*    */   
/*    */   Possible<List<PermissionOverwrite>> permissionOverwrites();
/*    */   
/*    */   Possible<Snowflake> parentId();
/*    */   
/*    */   Possible<Boolean> nsfw();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\TextChannelCreateSpecGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */