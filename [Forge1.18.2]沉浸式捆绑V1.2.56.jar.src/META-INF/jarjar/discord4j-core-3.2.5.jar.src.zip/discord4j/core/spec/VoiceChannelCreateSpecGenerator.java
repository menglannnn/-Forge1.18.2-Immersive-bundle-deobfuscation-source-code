/*    */ package discord4j.core.spec;
/*    */ 
/*    */ import discord4j.common.util.Snowflake;
/*    */ import discord4j.core.object.PermissionOverwrite;
/*    */ import discord4j.core.object.entity.channel.Channel;
/*    */ import discord4j.discordjson.json.ChannelCreateRequest;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import java.util.List;
/*    */ import java.util.stream.Collectors;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Immutable
/*    */ interface VoiceChannelCreateSpecGenerator
/*    */   extends AuditSpec<ChannelCreateRequest>
/*    */ {
/*    */   default ChannelCreateRequest asRequest() {
/* 55 */     return (ChannelCreateRequest)ChannelCreateRequest.builder()
/* 56 */       .type(Integer.valueOf(Channel.Type.GUILD_VOICE.getValue()))
/* 57 */       .name(name())
/* 58 */       .bitrate(bitrate())
/* 59 */       .userLimit(userLimit())
/* 60 */       .position(position())
/* 61 */       .rateLimitPerUser(rateLimitPerUser())
/* 62 */       .permissionOverwrites(InternalSpecUtils.mapPossible(permissionOverwrites(), po -> (List)po.stream().map(PermissionOverwrite::getData).collect(Collectors.toList())))
/*    */ 
/*    */       
/* 65 */       .parentId(InternalSpecUtils.mapPossible(parentId(), Snowflake::asString))
/* 66 */       .build();
/*    */   }
/*    */   
/*    */   String name();
/*    */   
/*    */   Possible<Integer> bitrate();
/*    */   
/*    */   Possible<Integer> userLimit();
/*    */   
/*    */   Possible<Integer> position();
/*    */   
/*    */   Possible<Integer> rateLimitPerUser();
/*    */   
/*    */   Possible<List<PermissionOverwrite>> permissionOverwrites();
/*    */   
/*    */   Possible<Snowflake> parentId();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\VoiceChannelCreateSpecGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */