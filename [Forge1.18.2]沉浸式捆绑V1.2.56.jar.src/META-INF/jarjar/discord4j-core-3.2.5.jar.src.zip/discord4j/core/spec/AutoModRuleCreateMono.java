/*     */ package discord4j.core.spec;
/*     */ 
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.object.automod.AutoModRule;
/*     */ import discord4j.core.object.entity.Guild;
/*     */ import discord4j.discordjson.json.AutoModActionData;
/*     */ import discord4j.discordjson.json.AutoModTriggerMetaData;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.stream.StreamSupport;
/*     */ import org.immutables.value.Generated;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "AutoModRuleCreateMonoGenerator", generator = "Immutables")
/*     */ public final class AutoModRuleCreateMono
/*     */   extends AutoModRuleCreateMonoGenerator
/*     */ {
/*     */   @Nullable
/*     */   private final String reason;
/*     */   private final String name;
/*     */   private final int eventType;
/*     */   private final int triggerType;
/*     */   private final AutoModTriggerMetaData triggerMetaData_value;
/*     */   private final boolean triggerMetaData_absent;
/*     */   private final List<AutoModActionData> actions;
/*     */   private final Boolean enabled_value;
/*     */   private final boolean enabled_absent;
/*     */   private final List<Snowflake> exemptRoles_value;
/*     */   private final boolean exemptRoles_absent;
/*     */   private final List<Snowflake> exemptChannels_value;
/*     */   private final boolean exemptChannels_absent;
/*     */   private final Guild guild;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   private volatile transient InitShim initShim;
/*     */   
/*     */   private AutoModRuleCreateMono(String name, int eventType, int triggerType, Guild guild) {
/* 103 */     this.initShim = new InitShim(); this.name = Objects.<String>requireNonNull(name, "name"); this.eventType = eventType; this.triggerType = triggerType; this.guild = Objects.<Guild>requireNonNull(guild, "guild"); this.reason = null; Possible<AutoModTriggerMetaData> triggerMetaData$impl = Possible.absent(); Possible<Boolean> enabled$impl = Possible.absent(); Possible<List<Snowflake>> exemptRoles$impl = Possible.absent(); Possible<List<Snowflake>> exemptChannels$impl = Possible.absent(); this.triggerMetaData_value = triggerMetaData$impl.toOptional().orElse(null); this.triggerMetaData_absent = triggerMetaData$impl.isAbsent(); this.enabled_value = enabled$impl.toOptional().orElse(null); this.enabled_absent = enabled$impl.isAbsent(); this.exemptRoles_value = exemptRoles$impl.toOptional().orElse(null); this.exemptRoles_absent = exemptRoles$impl.isAbsent(); this.exemptChannels_value = exemptChannels$impl.toOptional().orElse(null); this.exemptChannels_absent = exemptChannels$impl.isAbsent(); this.actions = this.initShim.actions(); this.initShim = null; } private AutoModRuleCreateMono(@Nullable String reason, String name, int eventType, int triggerType, Possible<AutoModTriggerMetaData> triggerMetaData, List<AutoModActionData> actions, Possible<Boolean> enabled, Possible<List<Snowflake>> exemptRoles, Possible<List<Snowflake>> exemptChannels, Guild guild) { this.initShim = new InitShim(); this.reason = reason; this.name = name; this.eventType = eventType; this.triggerType = triggerType; Possible<AutoModTriggerMetaData> triggerMetaData$impl = triggerMetaData; this.initShim.actions(actions); Possible<Boolean> enabled$impl = enabled; Possible<List<Snowflake>> exemptRoles$impl = exemptRoles; Possible<List<Snowflake>> exemptChannels$impl = exemptChannels; this.guild = guild; this.triggerMetaData_value = triggerMetaData$impl.toOptional().orElse(null); this.triggerMetaData_absent = triggerMetaData$impl.isAbsent(); this.enabled_value = enabled$impl.toOptional().orElse(null); this.enabled_absent = enabled$impl.isAbsent(); this.exemptRoles_value = exemptRoles$impl.toOptional().orElse(null);
/*     */     this.exemptRoles_absent = exemptRoles$impl.isAbsent();
/*     */     this.exemptChannels_value = exemptChannels$impl.toOptional().orElse(null);
/*     */     this.exemptChannels_absent = exemptChannels$impl.isAbsent();
/*     */     this.actions = this.initShim.actions();
/* 108 */     this.initShim = null; } @Generated(from = "AutoModRuleCreateMonoGenerator", generator = "Immutables") private final class InitShim { private byte actionsBuildStage = 0;
/*     */     private List<AutoModActionData> actions;
/*     */     
/*     */     List<AutoModActionData> actions() {
/* 112 */       if (this.actionsBuildStage == -1) throw new IllegalStateException(formatInitCycleMessage()); 
/* 113 */       if (this.actionsBuildStage == 0) {
/* 114 */         this.actionsBuildStage = -1;
/* 115 */         this.actions = (List)AutoModRuleCreateMono.createUnmodifiableList(false, AutoModRuleCreateMono.createSafeList((Iterable)AutoModRuleCreateMono.this.actions(), true, false));
/* 116 */         this.actionsBuildStage = 1;
/*     */       } 
/* 118 */       return this.actions;
/*     */     }
/*     */     
/*     */     void actions(List<AutoModActionData> actions) {
/* 122 */       this.actions = actions;
/* 123 */       this.actionsBuildStage = 1;
/*     */     }
/*     */     
/*     */     private String formatInitCycleMessage() {
/* 127 */       List<String> attributes = new ArrayList<>();
/* 128 */       if (this.actionsBuildStage == -1) attributes.add("actions"); 
/* 129 */       return "Cannot build AutoModRuleCreateMono, attribute initializers form cycle " + attributes;
/*     */     }
/*     */ 
/*     */     
/*     */     private InitShim() {} }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String reason() {
/* 139 */     return this.reason;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String name() {
/* 147 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int eventType() {
/* 155 */     return this.eventType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int triggerType() {
/* 163 */     return this.triggerType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<AutoModTriggerMetaData> triggerMetaData() {
/* 171 */     return this.triggerMetaData_absent ? Possible.absent() : Possible.of(this.triggerMetaData_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<AutoModActionData> actions() {
/* 179 */     InitShim shim = this.initShim;
/* 180 */     return (shim != null) ? 
/* 181 */       shim.actions() : 
/* 182 */       this.actions;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<Boolean> enabled() {
/* 190 */     return this.enabled_absent ? Possible.absent() : Possible.of(this.enabled_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<List<Snowflake>> exemptRoles() {
/* 198 */     return this.exemptRoles_absent ? Possible.absent() : 
/* 199 */       Possible.of(this.exemptRoles_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Possible<List<Snowflake>> exemptChannels() {
/* 207 */     return this.exemptChannels_absent ? Possible.absent() : 
/* 208 */       Possible.of(this.exemptChannels_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Guild guild() {
/* 216 */     return this.guild;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final AutoModRuleCreateMono withReason(@Nullable String value) {
/* 226 */     if (Objects.equals(this.reason, value)) return this; 
/* 227 */     return new AutoModRuleCreateMono(value, this.name, this.eventType, this.triggerType, 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 232 */         triggerMetaData(), this.actions, 
/*     */         
/* 234 */         enabled(), 
/* 235 */         exemptRoles(), 
/* 236 */         exemptChannels(), this.guild);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final AutoModRuleCreateMono withName(String value) {
/* 247 */     String newValue = Objects.<String>requireNonNull(value, "name");
/* 248 */     if (this.name.equals(newValue)) return this; 
/* 249 */     return new AutoModRuleCreateMono(this.reason, newValue, this.eventType, this.triggerType, 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 254 */         triggerMetaData(), this.actions, 
/*     */         
/* 256 */         enabled(), 
/* 257 */         exemptRoles(), 
/* 258 */         exemptChannels(), this.guild);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final AutoModRuleCreateMono withEventType(int value) {
/* 269 */     if (this.eventType == value) return this; 
/* 270 */     return new AutoModRuleCreateMono(this.reason, this.name, value, this.triggerType, 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 275 */         triggerMetaData(), this.actions, 
/*     */         
/* 277 */         enabled(), 
/* 278 */         exemptRoles(), 
/* 279 */         exemptChannels(), this.guild);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final AutoModRuleCreateMono withTriggerType(int value) {
/* 290 */     if (this.triggerType == value) return this; 
/* 291 */     return new AutoModRuleCreateMono(this.reason, this.name, this.eventType, value, 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 296 */         triggerMetaData(), this.actions, 
/*     */         
/* 298 */         enabled(), 
/* 299 */         exemptRoles(), 
/* 300 */         exemptChannels(), this.guild);
/*     */   }
/*     */ 
/*     */   
/*     */   public AutoModRuleCreateMono withTriggerMetaData(Possible<AutoModTriggerMetaData> value) {
/* 305 */     Possible<AutoModTriggerMetaData> newValue = Objects.<Possible<AutoModTriggerMetaData>>requireNonNull(value);
/* 306 */     return new AutoModRuleCreateMono(this.reason, this.name, this.eventType, this.triggerType, newValue, this.actions, 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 313 */         enabled(), 
/* 314 */         exemptRoles(), 
/* 315 */         exemptChannels(), this.guild);
/*     */   }
/*     */ 
/*     */   
/*     */   public AutoModRuleCreateMono withTriggerMetaData(AutoModTriggerMetaData value) {
/* 320 */     Possible<AutoModTriggerMetaData> newValue = Possible.of(value);
/* 321 */     return new AutoModRuleCreateMono(this.reason, this.name, this.eventType, this.triggerType, newValue, this.actions, 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 328 */         enabled(), 
/* 329 */         exemptRoles(), 
/* 330 */         exemptChannels(), this.guild);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final AutoModRuleCreateMono withActions(AutoModActionData... elements) {
/* 340 */     List<AutoModActionData> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/* 341 */     return new AutoModRuleCreateMono(this.reason, this.name, this.eventType, this.triggerType, 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 346 */         triggerMetaData(), newValue, 
/*     */         
/* 348 */         enabled(), 
/* 349 */         exemptRoles(), 
/* 350 */         exemptChannels(), this.guild);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final AutoModRuleCreateMono withActions(Iterable<? extends AutoModActionData> elements) {
/* 361 */     if (this.actions == elements) return this; 
/* 362 */     List<AutoModActionData> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/* 363 */     return new AutoModRuleCreateMono(this.reason, this.name, this.eventType, this.triggerType, 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 368 */         triggerMetaData(), newValue, 
/*     */         
/* 370 */         enabled(), 
/* 371 */         exemptRoles(), 
/* 372 */         exemptChannels(), this.guild);
/*     */   }
/*     */ 
/*     */   
/*     */   public AutoModRuleCreateMono withEnabled(Possible<Boolean> value) {
/* 377 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/* 378 */     return new AutoModRuleCreateMono(this.reason, this.name, this.eventType, this.triggerType, 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 383 */         triggerMetaData(), this.actions, newValue, 
/*     */ 
/*     */         
/* 386 */         exemptRoles(), 
/* 387 */         exemptChannels(), this.guild);
/*     */   }
/*     */ 
/*     */   
/*     */   public AutoModRuleCreateMono withEnabled(Boolean value) {
/* 392 */     Possible<Boolean> newValue = Possible.of(value);
/* 393 */     return new AutoModRuleCreateMono(this.reason, this.name, this.eventType, this.triggerType, 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 398 */         triggerMetaData(), this.actions, newValue, 
/*     */ 
/*     */         
/* 401 */         exemptRoles(), 
/* 402 */         exemptChannels(), this.guild);
/*     */   }
/*     */ 
/*     */   
/*     */   public AutoModRuleCreateMono withExemptRoles(Possible<List<Snowflake>> possible) {
/* 407 */     Possible<List<Snowflake>> newValue = Objects.<Possible<List<Snowflake>>>requireNonNull(possible);
/* 408 */     return new AutoModRuleCreateMono(this.reason, this.name, this.eventType, this.triggerType, 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 413 */         triggerMetaData(), this.actions, 
/*     */         
/* 415 */         enabled(), newValue, 
/*     */         
/* 417 */         exemptChannels(), this.guild);
/*     */   }
/*     */ 
/*     */   
/*     */   public AutoModRuleCreateMono withExemptRoles(Iterable<Snowflake> elements) {
/* 422 */     Possible<List<Snowflake>> newValue = Possible.of(
/* 423 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/* 424 */     return new AutoModRuleCreateMono(this.reason, this.name, this.eventType, this.triggerType, 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 429 */         triggerMetaData(), this.actions, 
/*     */         
/* 431 */         enabled(), newValue, 
/*     */         
/* 433 */         exemptChannels(), this.guild);
/*     */   }
/*     */ 
/*     */   
/*     */   @SafeVarargs
/*     */   public final AutoModRuleCreateMono withExemptRoles(Snowflake... elements) {
/* 439 */     Possible<List<Snowflake>> newValue = Possible.of(Arrays.asList(elements));
/* 440 */     return new AutoModRuleCreateMono(this.reason, this.name, this.eventType, this.triggerType, 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 445 */         triggerMetaData(), this.actions, 
/*     */         
/* 447 */         enabled(), newValue, 
/*     */         
/* 449 */         exemptChannels(), this.guild);
/*     */   }
/*     */ 
/*     */   
/*     */   public AutoModRuleCreateMono withExemptChannels(Possible<List<Snowflake>> possible) {
/* 454 */     Possible<List<Snowflake>> newValue = Objects.<Possible<List<Snowflake>>>requireNonNull(possible);
/* 455 */     return new AutoModRuleCreateMono(this.reason, this.name, this.eventType, this.triggerType, 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 460 */         triggerMetaData(), this.actions, 
/*     */         
/* 462 */         enabled(), 
/* 463 */         exemptRoles(), newValue, this.guild);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public AutoModRuleCreateMono withExemptChannels(Iterable<Snowflake> elements) {
/* 469 */     Possible<List<Snowflake>> newValue = Possible.of(
/* 470 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/* 471 */     return new AutoModRuleCreateMono(this.reason, this.name, this.eventType, this.triggerType, 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 476 */         triggerMetaData(), this.actions, 
/*     */         
/* 478 */         enabled(), 
/* 479 */         exemptRoles(), newValue, this.guild);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SafeVarargs
/*     */   public final AutoModRuleCreateMono withExemptChannels(Snowflake... elements) {
/* 486 */     Possible<List<Snowflake>> newValue = Possible.of(Arrays.asList(elements));
/* 487 */     return new AutoModRuleCreateMono(this.reason, this.name, this.eventType, this.triggerType, 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 492 */         triggerMetaData(), this.actions, 
/*     */         
/* 494 */         enabled(), 
/* 495 */         exemptRoles(), newValue, this.guild);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final AutoModRuleCreateMono withGuild(Guild value) {
/* 507 */     if (this.guild == value) return this; 
/* 508 */     Guild newValue = Objects.<Guild>requireNonNull(value, "guild");
/* 509 */     return new AutoModRuleCreateMono(this.reason, this.name, this.eventType, this.triggerType, 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 514 */         triggerMetaData(), this.actions, 
/*     */         
/* 516 */         enabled(), 
/* 517 */         exemptRoles(), 
/* 518 */         exemptChannels(), newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 528 */     if (this == another) return true; 
/* 529 */     return (another instanceof AutoModRuleCreateMono && 
/* 530 */       equalTo(0, (AutoModRuleCreateMono)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, AutoModRuleCreateMono another) {
/* 534 */     return (Objects.equals(this.reason, another.reason) && this.name
/* 535 */       .equals(another.name) && this.eventType == another.eventType && this.triggerType == another.triggerType && 
/*     */ 
/*     */       
/* 538 */       triggerMetaData().equals(another.triggerMetaData()) && this.actions
/* 539 */       .equals(another.actions) && 
/* 540 */       enabled().equals(another.enabled()) && 
/* 541 */       Objects.equals(this.exemptRoles_value, another.exemptRoles_value) && 
/* 542 */       Objects.equals(this.exemptChannels_value, another.exemptChannels_value) && this.guild
/* 543 */       .equals(another.guild));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 552 */     int h = 5381;
/* 553 */     h += (h << 5) + Objects.hashCode(this.reason);
/* 554 */     h += (h << 5) + this.name.hashCode();
/* 555 */     h += (h << 5) + this.eventType;
/* 556 */     h += (h << 5) + this.triggerType;
/* 557 */     h += (h << 5) + triggerMetaData().hashCode();
/* 558 */     h += (h << 5) + this.actions.hashCode();
/* 559 */     h += (h << 5) + enabled().hashCode();
/* 560 */     h += (h << 5) + Objects.hashCode(this.exemptRoles_value);
/* 561 */     h += (h << 5) + Objects.hashCode(this.exemptChannels_value);
/* 562 */     h += (h << 5) + this.guild.hashCode();
/* 563 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 572 */     return "AutoModRuleCreateMono{reason=" + this.reason + ", name=" + this.name + ", eventType=" + this.eventType + ", triggerType=" + this.triggerType + ", triggerMetaData=" + 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 577 */       triggerMetaData().toString() + ", actions=" + this.actions + ", enabled=" + 
/*     */       
/* 579 */       enabled().toString() + ", exemptRoles=" + 
/* 580 */       Objects.toString(this.exemptRoles_value) + ", exemptChannels=" + 
/* 581 */       Objects.toString(this.exemptChannels_value) + ", guild=" + this.guild + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AutoModRuleCreateMono of(String name, int eventType, int triggerType, Guild guild) {
/* 595 */     return new AutoModRuleCreateMono(name, eventType, triggerType, guild);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static AutoModRuleCreateMono copyOf(AutoModRuleCreateMonoGenerator instance) {
/* 606 */     if (instance instanceof AutoModRuleCreateMono) {
/* 607 */       return (AutoModRuleCreateMono)instance;
/*     */     }
/* 609 */     return of(instance.name(), instance.eventType(), instance.triggerType(), instance.guild())
/* 610 */       .withReason(instance.reason())
/* 611 */       .withTriggerMetaData(instance.triggerMetaData())
/* 612 */       .withActions(instance.actions())
/* 613 */       .withEnabled(instance.enabled())
/* 614 */       .withExemptRoles(instance.exemptRoles())
/* 615 */       .withExemptChannels(instance.exemptChannels());
/*     */   }
/*     */   
/*     */   public boolean isTriggerMetaDataPresent() {
/* 619 */     return !this.triggerMetaData_absent;
/*     */   }
/*     */   
/*     */   public AutoModTriggerMetaData triggerMetaDataOrElse(AutoModTriggerMetaData defaultValue) {
/* 623 */     return !this.triggerMetaData_absent ? this.triggerMetaData_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isEnabledPresent() {
/* 627 */     return !this.enabled_absent;
/*     */   }
/*     */   
/*     */   public Boolean enabledOrElse(Boolean defaultValue) {
/* 631 */     return !this.enabled_absent ? this.enabled_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isExemptRolesPresent() {
/* 635 */     return !this.exemptRoles_absent;
/*     */   }
/*     */   
/*     */   public List<Snowflake> exemptRolesOrElse(List<Snowflake> defaultValue) {
/* 639 */     return !this.exemptRoles_absent ? this.exemptRoles_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isExemptChannelsPresent() {
/* 643 */     return !this.exemptChannels_absent;
/*     */   }
/*     */   
/*     */   public List<Snowflake> exemptChannelsOrElse(List<Snowflake> defaultValue) {
/* 647 */     return !this.exemptChannels_absent ? this.exemptChannels_value : defaultValue;
/*     */   }
/*     */   
/*     */   private static <T> List<T> createSafeList(Iterable<? extends T> iterable, boolean checkNulls, boolean skipNulls) {
/*     */     ArrayList<T> list;
/* 652 */     if (iterable instanceof Collection) {
/* 653 */       int size = ((Collection)iterable).size();
/* 654 */       if (size == 0) return Collections.emptyList(); 
/* 655 */       list = new ArrayList<>();
/*     */     } else {
/* 657 */       list = new ArrayList<>();
/*     */     } 
/* 659 */     for (T element : iterable) {
/* 660 */       if (skipNulls && element == null)
/* 661 */         continue;  if (checkNulls) Objects.requireNonNull(element, "element"); 
/* 662 */       list.add(element);
/*     */     } 
/* 664 */     return list;
/*     */   }
/*     */   
/*     */   private static <T> List<T> createUnmodifiableList(boolean clone, List<T> list) {
/* 668 */     switch (list.size()) { case 0:
/* 669 */         return Collections.emptyList();
/* 670 */       case 1: return Collections.singletonList(list.get(0)); }
/*     */     
/* 672 */     if (clone) {
/* 673 */       return Collections.unmodifiableList(new ArrayList<>(list));
/*     */     }
/* 675 */     if (list instanceof ArrayList) {
/* 676 */       ((ArrayList)list).trimToSize();
/*     */     }
/* 678 */     return Collections.unmodifiableList(list);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\spec\AutoModRuleCreateMono.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */