/*     */ package discord4j.core;
/*     */ 
/*     */ import discord4j.common.LogUtil;
/*     */ import discord4j.common.store.action.read.ReadActions;
/*     */ import discord4j.common.store.api.StoreAction;
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.event.EventDispatcher;
/*     */ import discord4j.core.event.ReactiveEventAdapter;
/*     */ import discord4j.core.event.domain.Event;
/*     */ import discord4j.core.object.GuildTemplate;
/*     */ import discord4j.core.object.Invite;
/*     */ import discord4j.core.object.Region;
/*     */ import discord4j.core.object.ScheduledEventUser;
/*     */ import discord4j.core.object.automod.AutoModRule;
/*     */ import discord4j.core.object.entity.ApplicationInfo;
/*     */ import discord4j.core.object.entity.Guild;
/*     */ import discord4j.core.object.entity.GuildEmoji;
/*     */ import discord4j.core.object.entity.GuildSticker;
/*     */ import discord4j.core.object.entity.Member;
/*     */ import discord4j.core.object.entity.Message;
/*     */ import discord4j.core.object.entity.Role;
/*     */ import discord4j.core.object.entity.ScheduledEvent;
/*     */ import discord4j.core.object.entity.User;
/*     */ import discord4j.core.object.entity.Webhook;
/*     */ import discord4j.core.object.entity.channel.Channel;
/*     */ import discord4j.core.object.entity.channel.GuildChannel;
/*     */ import discord4j.core.object.presence.ClientPresence;
/*     */ import discord4j.core.retriever.EntityRetrievalStrategy;
/*     */ import discord4j.core.retriever.EntityRetriever;
/*     */ import discord4j.core.spec.GuildCreateMono;
/*     */ import discord4j.core.spec.GuildCreateSpec;
/*     */ import discord4j.core.spec.UserEditMono;
/*     */ import discord4j.core.spec.UserEditSpec;
/*     */ import discord4j.core.spec.legacy.LegacyGuildCreateSpec;
/*     */ import discord4j.core.spec.legacy.LegacyUserEditSpec;
/*     */ import discord4j.core.util.ValidationUtil;
/*     */ import discord4j.discordjson.json.ApplicationInfoData;
/*     */ import discord4j.discordjson.json.EmojiData;
/*     */ import discord4j.discordjson.json.GuildData;
/*     */ import discord4j.discordjson.json.GuildUpdateData;
/*     */ import discord4j.discordjson.json.GuildUpdateFields;
/*     */ import discord4j.discordjson.json.InviteData;
/*     */ import discord4j.discordjson.json.MemberData;
/*     */ import discord4j.discordjson.json.RegionData;
/*     */ import discord4j.discordjson.json.RoleDataFields;
/*     */ import discord4j.discordjson.json.TemplateData;
/*     */ import discord4j.discordjson.json.UserData;
/*     */ import discord4j.discordjson.json.WebhookData;
/*     */ import discord4j.discordjson.json.gateway.GuildMembersChunk;
/*     */ import discord4j.discordjson.json.gateway.RequestGuildMembers;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import discord4j.gateway.GatewayClient;
/*     */ import discord4j.gateway.GatewayClientGroup;
/*     */ import discord4j.gateway.json.GatewayPayload;
/*     */ import discord4j.gateway.json.ShardGatewayPayload;
/*     */ import discord4j.rest.RestClient;
/*     */ import discord4j.voice.LocalVoiceConnectionRegistry;
/*     */ import discord4j.voice.VoiceConnectionFactory;
/*     */ import discord4j.voice.VoiceConnectionRegistry;
/*     */ import java.time.ZonedDateTime;
/*     */ import java.time.format.DateTimeFormatter;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import java.util.Set;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Supplier;
/*     */ import java.util.stream.Collectors;
/*     */ import org.reactivestreams.Publisher;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.util.Logger;
/*     */ import reactor.util.Loggers;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ import reactor.util.context.ContextView;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GatewayDiscordClient
/*     */   implements EntityRetriever
/*     */ {
/* 100 */   private static final Logger log = Loggers.getLogger(GatewayDiscordClient.class);
/*     */   
/*     */   private final DiscordClient discordClient;
/*     */   
/*     */   private final GatewayResources gatewayResources;
/*     */   
/*     */   private final Mono<Void> onDisconnect;
/*     */   
/*     */   private final GatewayClientGroup gatewayClientGroup;
/*     */   
/*     */   private final VoiceConnectionFactory voiceConnectionFactory;
/*     */   private final VoiceConnectionRegistry voiceConnectionRegistry;
/*     */   private final EntityRetriever entityRetriever;
/*     */   private final Set<String> completingChunkNonces;
/*     */   
/*     */   public GatewayDiscordClient(DiscordClient discordClient, GatewayResources gatewayResources, Mono<Void> onDisconnect, GatewayClientGroup gatewayClientGroup, VoiceConnectionFactory voiceConnectionFactory, EntityRetrievalStrategy entityRetrievalStrategy, Set<String> completingChunkNonces) {
/* 116 */     this.discordClient = discordClient;
/* 117 */     this.gatewayResources = gatewayResources;
/* 118 */     this.onDisconnect = onDisconnect;
/* 119 */     this.gatewayClientGroup = gatewayClientGroup;
/* 120 */     this.voiceConnectionFactory = voiceConnectionFactory;
/* 121 */     this.voiceConnectionRegistry = (VoiceConnectionRegistry)new LocalVoiceConnectionRegistry();
/* 122 */     this.entityRetriever = (EntityRetriever)entityRetrievalStrategy.apply(this);
/* 123 */     this.completingChunkNonces = completingChunkNonces;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DiscordClient rest() {
/* 132 */     return this.discordClient;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CoreResources getCoreResources() {
/* 143 */     return this.discordClient.getCoreResources();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GatewayResources getGatewayResources() {
/* 153 */     return this.gatewayResources;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EventDispatcher getEventDispatcher() {
/* 164 */     return this.gatewayResources.getEventDispatcher();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<GatewayClient> getGatewayClient(int shardId) {
/* 175 */     return this.gatewayClientGroup.find(shardId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GatewayClientGroup getGatewayClientGroup() {
/* 185 */     return this.gatewayClientGroup;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public VoiceConnectionFactory getVoiceConnectionFactory() {
/* 194 */     return this.voiceConnectionFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public VoiceConnectionRegistry getVoiceConnectionRegistry() {
/* 204 */     return this.voiceConnectionRegistry;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RestClient getRestClient() {
/* 213 */     return rest();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Webhook> getWebhookById(Snowflake webhookId) {
/* 225 */     return getRestClient().getWebhookService()
/* 226 */       .getWebhook(webhookId.asLong())
/* 227 */       .map(data -> new Webhook(this, data));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Webhook> getWebhookByIdWithToken(Snowflake webhookId, String token) {
/* 241 */     return getRestClient().getWebhookService()
/* 242 */       .getWebhookWithToken(webhookId.asLong(), token)
/* 243 */       .map(data -> new Webhook(this, data));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<ApplicationInfo> getApplicationInfo() {
/* 254 */     return getRestClient().getApplicationService()
/* 255 */       .getCurrentApplicationInfo()
/* 256 */       .map(data -> new ApplicationInfo(this, data));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Flux<User> getUsers() {
/* 266 */     return Flux.from(this.gatewayResources.getStore().execute((StoreAction)ReadActions.getUsers()))
/* 267 */       .map(data -> new User(this, data));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Flux<Region> getRegions() {
/* 277 */     return getRestClient().getVoiceService().getVoiceRegions()
/* 278 */       .map(data -> new Region(this, data));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<GuildTemplate> getTemplateByCode(String templateCode) {
/* 289 */     return getRestClient().getTemplateService()
/* 290 */       .getTemplate(templateCode)
/* 291 */       .map(data -> new GuildTemplate(this, data));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Snowflake getSelfId() {
/* 300 */     return getCoreResources().getSelfId();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public Mono<Guild> createGuild(Consumer<? super LegacyGuildCreateSpec> spec) {
/* 314 */     return Mono.defer(() -> {
/*     */           LegacyGuildCreateSpec mutatedSpec = new LegacyGuildCreateSpec();
/*     */           
/*     */           spec.accept(mutatedSpec);
/*     */           
/*     */           return getRestClient().getGuildService().createGuild(mutatedSpec.asRequest());
/* 320 */         }).map(data -> new Guild(this, toGuildData(data)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GuildCreateMono createGuild(String name, Region region) {
/* 333 */     return GuildCreateMono.of(name, region, this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Guild> createGuild(GuildCreateSpec spec) {
/* 344 */     Objects.requireNonNull(spec);
/* 345 */     return Mono.defer(() -> getRestClient().getGuildService().createGuild(spec.asRequest()))
/* 346 */       .map(data -> new Guild(this, toGuildData(data)));
/*     */   }
/*     */   
/*     */   private GuildData toGuildData(GuildUpdateData guild) {
/* 350 */     return (GuildData)GuildData.builder()
/* 351 */       .from((GuildUpdateFields)guild)
/* 352 */       .roles((List)guild.roles().stream()
/* 353 */         .map(RoleDataFields::id)
/* 354 */         .collect(Collectors.toList()))
/* 355 */       .emojis((List)guild.emojis().stream()
/* 356 */         .map(EmojiData::id)
/* 357 */         .filter(Optional::isPresent)
/* 358 */         .map(Optional::get)
/* 359 */         .collect(Collectors.toList()))
/* 360 */       .channels(Collections.emptyList())
/* 361 */       .members(Collections.emptyList())
/* 362 */       .joinedAt(DateTimeFormatter.ISO_OFFSET_DATE_TIME.format(ZonedDateTime.now()))
/* 363 */       .large(false)
/* 364 */       .memberCount(1)
/* 365 */       .build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Void> updatePresence(ClientPresence clientPresence) {
/* 376 */     return this.gatewayClientGroup.multicast(GatewayPayload.statusUpdate(clientPresence.getStatusUpdate()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Void> updatePresence(ClientPresence clientPresence, int shardId) {
/* 387 */     return this.gatewayClientGroup.unicast(ShardGatewayPayload.statusUpdate(clientPresence.getStatusUpdate(), shardId));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Invite> getInvite(String inviteCode) {
/* 398 */     return getRestClient().getInviteService()
/* 399 */       .getInvite(inviteCode)
/* 400 */       .map(data -> new Invite(this, data));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Invite> getInvite(String inviteCode, boolean withCounts, boolean withExpiration, @Nullable Snowflake guildScheduledEventId) {
/* 415 */     Map<String, Object> queryParams = new HashMap<>();
/* 416 */     queryParams.put("with_counts", Boolean.valueOf(withCounts));
/* 417 */     queryParams.put("with_expiration", Boolean.valueOf(withExpiration));
/* 418 */     if (guildScheduledEventId != null) {
/* 419 */       queryParams.put("guild_scheduled_event_id", guildScheduledEventId.asString());
/*     */     }
/* 421 */     return getRestClient().getInviteService()
/* 422 */       .getInvite(inviteCode, queryParams)
/* 423 */       .map(data -> new Invite(this, data));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public Mono<User> edit(Consumer<? super LegacyUserEditSpec> spec) {
/* 436 */     return Mono.defer(() -> {
/*     */           LegacyUserEditSpec mutatedSpec = new LegacyUserEditSpec();
/*     */           
/*     */           spec.accept(mutatedSpec);
/*     */           
/*     */           return getRestClient().getUserService().modifyCurrentUser(mutatedSpec.asRequest());
/* 442 */         }).map(data -> new User(this, data));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UserEditMono edit() {
/* 453 */     return UserEditMono.of(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<User> edit(UserEditSpec spec) {
/* 464 */     Objects.requireNonNull(spec);
/* 465 */     return Mono.defer(() -> getRestClient().getUserService().modifyCurrentUser(spec.asRequest()))
/* 466 */       .map(data -> new User(this, data));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Void> logout() {
/* 478 */     return this.gatewayClientGroup.logout();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Void> onDisconnect() {
/* 489 */     return this.onDisconnect;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <E extends Event> Flux<E> on(Class<E> eventClass) {
/* 523 */     return getEventDispatcher().on(eventClass)
/* 524 */       .contextWrite(ctx -> ctx.put("discord4j.gateway", Integer.toHexString(hashCode())));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <E extends Event, T> Flux<T> on(Class<E> eventClass, Function<E, Publisher<T>> mapper) {
/* 558 */     return getEventDispatcher().on(eventClass, mapper)
/* 559 */       .contextWrite(ctx -> ctx.put("discord4j.gateway", Integer.toHexString(hashCode())));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Flux<Event> on(ReactiveEventAdapter adapter) {
/* 599 */     return getEventDispatcher().on(adapter)
/* 600 */       .contextWrite(ctx -> ctx.put("discord4j.gateway", Integer.toHexString(hashCode())));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Flux<Member> requestMembers(Snowflake guildId) {
/* 613 */     return requestMembers((RequestGuildMembers)RequestGuildMembers.builder()
/* 614 */         .guildId(guildId.asString())
/* 615 */         .query("")
/* 616 */         .limit(0)
/* 617 */         .build());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Flux<Member> requestMembers(Snowflake guildId, Set<Snowflake> userIds) {
/* 631 */     return Flux.fromIterable(userIds)
/* 632 */       .map(Snowflake::asString)
/* 633 */       .buffer(100)
/* 634 */       .concatMap(userIdBuffer -> requestMembers((RequestGuildMembers)RequestGuildMembers.builder().guildId(guildId.asString()).userIds(userIdBuffer).limit(0).build()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Flux<Member> requestMembers(RequestGuildMembers request) {
/* 651 */     Snowflake guildId = Snowflake.of(request.guildId());
/* 652 */     return requestMemberChunks(request)
/* 653 */       .flatMapIterable(chunk -> (Iterable)chunk.members().stream().map(()).collect(Collectors.toList()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Flux<GuildMembersChunk> requestMemberChunks(RequestGuildMembers request) {
/*     */     try {
/* 675 */       ValidationUtil.validateRequestGuildMembers(request, Possible.of(this.gatewayResources.getIntents()));
/* 676 */     } catch (Throwable t) {
/* 677 */       return Flux.error(t);
/*     */     } 
/* 679 */     Snowflake guildId = Snowflake.of(request.guildId());
/* 680 */     int shardId = this.gatewayClientGroup.computeShardIndex(guildId);
/* 681 */     String nonce = String.valueOf(System.nanoTime());
/* 682 */     Supplier<Flux<GuildMembersChunk>> incomingMembers = () -> (Flux)this.gatewayClientGroup.find(shardId).map(()).orElseThrow(());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 691 */     return Flux.deferContextual(ctx -> getGuildById(guildId).then(this.gatewayClientGroup.unicast(ShardGatewayPayload.requestGuildMembers((RequestGuildMembers)RequestGuildMembers.builder().from(request).nonce(nonce).build(), shardId)).then(Mono.fromRunnable(()))).thenMany((Publisher)Flux.defer(incomingMembers)).doOnComplete(()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EntityRetriever withRetrievalStrategy(EntityRetrievalStrategy retrievalStrategy) {
/* 714 */     return (EntityRetriever)retrievalStrategy.apply(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Channel> getChannelById(Snowflake channelId) {
/* 719 */     return this.entityRetriever.getChannelById(channelId);
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Guild> getGuildById(Snowflake guildId) {
/* 724 */     return this.entityRetriever.getGuildById(guildId);
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<GuildSticker> getGuildStickerById(Snowflake guildId, Snowflake stickerId) {
/* 729 */     return this.entityRetriever.getGuildStickerById(guildId, stickerId);
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<GuildEmoji> getGuildEmojiById(Snowflake guildId, Snowflake emojiId) {
/* 734 */     return this.entityRetriever.getGuildEmojiById(guildId, emojiId);
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Member> getMemberById(Snowflake guildId, Snowflake userId) {
/* 739 */     return this.entityRetriever.getMemberById(guildId, userId);
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Message> getMessageById(Snowflake channelId, Snowflake messageId) {
/* 744 */     return this.entityRetriever.getMessageById(channelId, messageId);
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Role> getRoleById(Snowflake guildId, Snowflake roleId) {
/* 749 */     return this.entityRetriever.getRoleById(guildId, roleId);
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<User> getUserById(Snowflake userId) {
/* 754 */     return this.entityRetriever.getUserById(userId);
/*     */   }
/*     */ 
/*     */   
/*     */   public Flux<Guild> getGuilds() {
/* 759 */     return this.entityRetriever.getGuilds();
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<User> getSelf() {
/* 764 */     return this.entityRetriever.getSelf();
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Member> getSelfMember(Snowflake guildId) {
/* 769 */     return this.entityRetriever.getSelfMember(guildId);
/*     */   }
/*     */ 
/*     */   
/*     */   public Flux<Member> getGuildMembers(Snowflake guildId) {
/* 774 */     return this.entityRetriever.getGuildMembers(guildId);
/*     */   }
/*     */ 
/*     */   
/*     */   public Flux<GuildChannel> getGuildChannels(Snowflake guildId) {
/* 779 */     return this.entityRetriever.getGuildChannels(guildId);
/*     */   }
/*     */ 
/*     */   
/*     */   public Flux<Role> getGuildRoles(Snowflake guildId) {
/* 784 */     return this.entityRetriever.getGuildRoles(guildId);
/*     */   }
/*     */ 
/*     */   
/*     */   public Flux<GuildEmoji> getGuildEmojis(Snowflake guildId) {
/* 789 */     return this.entityRetriever.getGuildEmojis(guildId);
/*     */   }
/*     */ 
/*     */   
/*     */   public Flux<GuildSticker> getGuildStickers(Snowflake guildId) {
/* 794 */     return this.entityRetriever.getGuildStickers(guildId);
/*     */   }
/*     */ 
/*     */   
/*     */   public Flux<AutoModRule> getGuildAutoModRules(Snowflake guildId) {
/* 799 */     return this.entityRetriever.getGuildAutoModRules(guildId);
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<ScheduledEvent> getScheduledEventById(Snowflake guildId, Snowflake eventId) {
/* 804 */     return this.entityRetriever.getScheduledEventById(guildId, eventId);
/*     */   }
/*     */ 
/*     */   
/*     */   public Flux<ScheduledEvent> getScheduledEvents(Snowflake guildId) {
/* 809 */     return this.entityRetriever.getScheduledEvents(guildId);
/*     */   }
/*     */ 
/*     */   
/*     */   public Flux<ScheduledEventUser> getScheduledEventUsers(Snowflake guildId, Snowflake eventId) {
/* 814 */     return this.entityRetriever.getScheduledEventUsers(guildId, eventId);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\GatewayDiscordClient.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */