/*    */ package discord4j.core.util;
/*    */ 
/*    */ import discord4j.discordjson.json.gateway.RequestGuildMembers;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import discord4j.gateway.intent.Intent;
/*    */ import discord4j.gateway.intent.IntentSet;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ValidationUtil
/*    */ {
/*    */   public static void validateRequestGuildMembers(RequestGuildMembers request, Possible<IntentSet> possibleIntents) {
/* 36 */     if (request.query().isAbsent() == request.userIds().isAbsent()) {
/* 37 */       throw new IllegalArgumentException("One of query or user ids is required.");
/*    */     }
/*    */ 
/*    */     
/* 41 */     if (possibleIntents.isAbsent()) {
/*    */       return;
/*    */     }
/* 44 */     IntentSet intents = (IntentSet)possibleIntents.get();
/*    */     
/* 46 */     boolean requestingPresences = ((Boolean)request.presences().toOptional().orElse(Boolean.valueOf(false))).booleanValue();
/* 47 */     if (requestingPresences && !intents.contains(Intent.GUILD_PRESENCES)) {
/* 48 */       throw new IllegalArgumentException("GUILD_PRESENCES intent is required to set presences = true.");
/*    */     }
/*    */     
/* 51 */     if (isRequestingEntireList(request) && !intents.contains(Intent.GUILD_MEMBERS)) {
/* 52 */       throw new IllegalArgumentException("GUILD_MEMBERS intent is required to request the entire member list");
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static boolean isRequestingEntireList(RequestGuildMembers request) {
/* 64 */     return (((Boolean)request.query().toOptional().map(String::isEmpty).orElse(Boolean.valueOf(false))).booleanValue() && request.limit() == 0);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\cor\\util\ValidationUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */