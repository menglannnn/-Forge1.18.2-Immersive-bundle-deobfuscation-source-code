/*     */ package discord4j.core.util;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ import java.util.Arrays;
/*     */ import java.util.Objects;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ArrayUtil
/*     */ {
/*     */   public static <T> T[] remove(T[] array, T t) {
/*  27 */     T[] ret = (T[])Array.newInstance(array.getClass().getComponentType(), array.length - 1);
/*  28 */     for (int i = 0; i < array.length; i++) {
/*  29 */       if (array[i].equals(t)) {
/*  30 */         System.arraycopy(array, 0, ret, 0, i);
/*  31 */         if (i < array.length - 1) {
/*  32 */           System.arraycopy(array, i + 1, ret, i, array.length - i - 1);
/*     */         }
/*     */         break;
/*     */       } 
/*     */     } 
/*  37 */     return ret;
/*     */   }
/*     */   
/*     */   public static long[] remove(long[] array, long l) {
/*  41 */     long[] ret = new long[Math.max(0, array.length - 1)];
/*  42 */     for (int i = 0; i < array.length; i++) {
/*  43 */       if (array[i] == l) {
/*  44 */         System.arraycopy(array, 0, ret, 0, i);
/*  45 */         if (i < array.length - 1) {
/*  46 */           System.arraycopy(array, i + 1, ret, i, array.length - i - 1);
/*     */         }
/*     */         break;
/*     */       } 
/*     */     } 
/*  51 */     return ret;
/*     */   }
/*     */ 
/*     */   
/*     */   public static <T> T[] add(T[] array, T t) {
/*  56 */     T[] ret = (T[])Array.newInstance(array.getClass().getComponentType(), array.length + 1);
/*  57 */     System.arraycopy(array, 0, ret, 0, ret.length - 1);
/*  58 */     ret[ret.length - 1] = t;
/*  59 */     return ret;
/*     */   }
/*     */   
/*     */   public static long[] add(long[] array, long l) {
/*  63 */     long[] ret = new long[array.length + 1];
/*  64 */     System.arraycopy(array, 0, ret, 0, ret.length - 1);
/*  65 */     ret[ret.length - 1] = l;
/*  66 */     return ret;
/*     */   }
/*     */   
/*     */   public static long[] addAll(long[] array0, long[] array1) {
/*  70 */     long[] ret = new long[array0.length + array1.length];
/*  71 */     System.arraycopy(array0, 0, ret, 0, array0.length);
/*  72 */     System.arraycopy(array1, 0, ret, array0.length, array1.length);
/*  73 */     return ret;
/*     */   }
/*     */   
/*     */   public static Long[] toObject(long[] array) {
/*  77 */     Long[] ret = new Long[array.length];
/*  78 */     for (int i = 0; i < array.length; i++) {
/*  79 */       ret[i] = Long.valueOf(array[i]);
/*     */     }
/*  81 */     return ret;
/*     */   }
/*     */   
/*     */   public static <T> T[] replace(T[] array, T old, T replacement) {
/*  85 */     T[] copy = Arrays.copyOf(array, array.length);
/*  86 */     for (int i = 0; i < array.length; i++) {
/*  87 */       if (Objects.equals(array[i], old)) {
/*  88 */         copy[i] = replacement;
/*     */       }
/*     */     } 
/*  91 */     return copy;
/*     */   }
/*     */   
/*     */   public static boolean contains(long[] array, long l) {
/*  95 */     for (int i = 0; i < array.length; i++) {
/*  96 */       if (array[i] == l) {
/*  97 */         return true;
/*     */       }
/*     */     } 
/* 100 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\cor\\util\ArrayUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */