/*     */ package discord4j.core.util;
/*     */ 
/*     */ import discord4j.core.GatewayDiscordClient;
/*     */ import discord4j.core.object.entity.Entity;
/*     */ import discord4j.core.object.entity.channel.Category;
/*     */ import discord4j.core.object.entity.channel.Channel;
/*     */ import discord4j.core.object.entity.channel.NewsChannel;
/*     */ import discord4j.core.object.entity.channel.PrivateChannel;
/*     */ import discord4j.core.object.entity.channel.StoreChannel;
/*     */ import discord4j.core.object.entity.channel.TextChannel;
/*     */ import discord4j.core.object.entity.channel.UnknownChannel;
/*     */ import discord4j.core.object.entity.channel.VoiceChannel;
/*     */ import discord4j.core.object.reaction.ReactionEmoji;
/*     */ import discord4j.discordjson.json.ChannelData;
/*     */ import reactor.util.Logger;
/*     */ import reactor.util.Loggers;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class EntityUtil
/*     */ {
/*  32 */   private static final Logger log = Loggers.getLogger(EntityUtil.class);
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static final long DISCORD_EPOCH = 1420070400000L;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getEmojiString(ReactionEmoji emoji) {
/*  43 */     if (emoji instanceof ReactionEmoji.Unicode) {
/*  44 */       return ((ReactionEmoji.Unicode)emoji).getRaw();
/*     */     }
/*  46 */     ReactionEmoji.Custom custom = (ReactionEmoji.Custom)emoji;
/*  47 */     return custom.getName() + ":" + custom.getId().asString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Channel getChannel(GatewayDiscordClient gateway, ChannelData data) {
/*  60 */     switch (Channel.Type.of(data.type())) { case GUILD_TEXT:
/*  61 */         return (Channel)new TextChannel(gateway, data);
/*  62 */       case DM: return (Channel)new PrivateChannel(gateway, data);
/*     */       case GUILD_VOICE:
/*     */       case GUILD_STAGE_VOICE:
/*  65 */         return (Channel)new VoiceChannel(gateway, data);
/*  66 */       case GUILD_CATEGORY: return (Channel)new Category(gateway, data);
/*  67 */       case GUILD_NEWS: return (Channel)new NewsChannel(gateway, data);
/*  68 */       case GUILD_STORE: return (Channel)new StoreChannel(gateway, data); }
/*     */     
/*  70 */     log.info("Unknown channel type {} with data: {}", new Object[] { Integer.valueOf(data.type()), data });
/*  71 */     return (Channel)new UnknownChannel(gateway, data);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static <T> T throwUnsupportedDiscordValue(Object value) {
/*  86 */     throw new UnsupportedOperationException("Unknown Value: " + value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean equals(Entity entity, @Nullable Object obj) {
/*  97 */     return (entity.getClass().isInstance(obj) && ((Entity)obj).getId().equals(entity.getId()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int hashCode(Entity entity) {
/* 107 */     return entity.getId().hashCode();
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\cor\\util\EntityUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */