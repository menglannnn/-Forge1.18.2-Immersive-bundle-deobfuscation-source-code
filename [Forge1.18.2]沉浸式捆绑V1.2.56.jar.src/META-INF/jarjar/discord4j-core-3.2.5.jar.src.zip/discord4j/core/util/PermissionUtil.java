/*    */ package discord4j.core.util;
/*    */ 
/*    */ import discord4j.core.object.PermissionOverwrite;
/*    */ import discord4j.rest.util.Permission;
/*    */ import discord4j.rest.util.PermissionSet;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class PermissionUtil
/*    */ {
/*    */   public static PermissionSet computeBasePermissions(PermissionSet everyonePerms, List<PermissionSet> rolePerms) {
/* 40 */     return rolePerms.stream().reduce(everyonePerms, PermissionSet::or);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static PermissionSet computePermissions(PermissionSet base, @Nullable PermissionOverwrite everyoneOverwrite, List<PermissionOverwrite> roleOverwrites, @Nullable PermissionOverwrite memberOverwrite) {
/* 58 */     if (base.contains(Permission.ADMINISTRATOR)) {
/* 59 */       return PermissionSet.all();
/*    */     }
/*    */     
/* 62 */     List<PermissionOverwrite> allOverwrites = new ArrayList<>();
/* 63 */     if (everyoneOverwrite != null) allOverwrites.add(everyoneOverwrite); 
/* 64 */     allOverwrites.addAll(roleOverwrites);
/* 65 */     if (memberOverwrite != null) allOverwrites.add(memberOverwrite);
/*    */     
/* 67 */     return (PermissionSet)allOverwrites.stream().reduce(base, PermissionUtil::applyOverwrite, PermissionSet::or);
/*    */   }
/*    */   
/*    */   private static PermissionSet applyOverwrite(PermissionSet base, PermissionOverwrite overwrite) {
/* 71 */     return base.and(overwrite.getDenied().not()).or(overwrite.getAllowed());
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\cor\\util\PermissionUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */