/*     */ package discord4j.core.util;
/*     */ 
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.object.entity.Entity;
/*     */ import discord4j.core.object.entity.Role;
/*     */ import discord4j.core.object.entity.channel.CategorizableChannel;
/*     */ import discord4j.core.object.entity.channel.Category;
/*     */ import discord4j.core.object.entity.channel.GuildChannel;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Comparator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.SortedSet;
/*     */ import java.util.TreeMap;
/*     */ import java.util.TreeSet;
/*     */ import reactor.core.publisher.Flux;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class OrderUtil
/*     */ {
/*  40 */   public static final Comparator<Role> ROLE_ORDER = Comparator.comparing(Role::getRawPosition).thenComparing(Role::getId);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  52 */   public static final Comparator<GuildChannel> CHANNEL_ORDER = Comparator.comparing(GuildChannel::getRawPosition).thenComparing(Entity::getId);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final Comparator<CategorizableChannel> BUCKETED_CHANNEL_ORDER;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  69 */     BUCKETED_CHANNEL_ORDER = (Comparator)Comparator.comparingInt(c -> (c instanceof discord4j.core.object.entity.channel.VoiceChannel) ? 1 : 0).thenComparing(CHANNEL_ORDER);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Flux<GuildChannel> orderGuildChannels(Flux<GuildChannel> channels) {
/*  88 */     return channels
/*  89 */       .collectMap(Entity::getId)
/*  90 */       .flatMapIterable(OrderUtil::orderGuildChannels);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Flux<Role> orderRoles(Flux<Role> roles) {
/* 109 */     return roles.sort(ROLE_ORDER);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static List<GuildChannel> orderGuildChannels(Map<Snowflake, GuildChannel> channels) {
/* 116 */     Map<Category, SortedSet<CategorizableChannel>> byCategory = new TreeMap<>((Comparator)Comparator.nullsFirst(CHANNEL_ORDER));
/* 117 */     channels.forEach((id, channel) -> {
/*     */           if (channel instanceof CategorizableChannel) {
/*     */             CategorizableChannel categorizable = (CategorizableChannel)channel;
/*     */ 
/*     */ 
/*     */             
/*     */             Category parent = (Category)channels.get(categorizable.getCategoryId().orElse(null));
/*     */ 
/*     */             
/*     */             ((SortedSet<CategorizableChannel>)byCategory.computeIfAbsent(parent, ())).add(categorizable);
/*     */           } else {
/*     */             byCategory.putIfAbsent((Category)channel, new TreeSet<>(BUCKETED_CHANNEL_ORDER));
/*     */           } 
/*     */         });
/*     */ 
/*     */     
/* 133 */     List<GuildChannel> sorted = new ArrayList<>();
/* 134 */     byCategory.forEach((category, children) -> {
/*     */           if (category != null) {
/*     */             sorted.add(category);
/*     */           }
/*     */           
/*     */           sorted.addAll(children);
/*     */         });
/* 141 */     return sorted;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\cor\\util\OrderUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */