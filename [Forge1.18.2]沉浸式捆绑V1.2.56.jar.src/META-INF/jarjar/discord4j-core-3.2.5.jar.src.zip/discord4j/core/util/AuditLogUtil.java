/*    */ package discord4j.core.util;
/*    */ 
/*    */ import discord4j.core.object.audit.OptionKey;
/*    */ import discord4j.discordjson.Id;
/*    */ import discord4j.discordjson.json.AuditEntryInfoData;
/*    */ import discord4j.discordjson.json.AuditLogChangeData;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import java.util.function.Function;
/*    */ import java.util.stream.Collector;
/*    */ import java.util.stream.Collectors;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AuditLogUtil
/*    */ {
/*    */   public static Collector<AuditLogChangeData, ?, Map<String, AuditLogChangeData>> changeCollector() {
/* 33 */     return Collectors.toMap(AuditLogChangeData::key, (Function)Function.identity());
/*    */   }
/*    */   
/*    */   public static Map<String, String> createOptionMap(AuditEntryInfoData options) {
/* 37 */     HashMap<String, String> map = new HashMap<>();
/* 38 */     options.deleteMemberDays().toOptional().ifPresent(it -> map.put(OptionKey.DELETE_MEMBER_DAYS.getField(), it));
/* 39 */     options.membersRemoved().toOptional().ifPresent(it -> map.put(OptionKey.MEMBERS_REMOVED.getField(), it));
/* 40 */     options.channelId().toOptional().ifPresent(it -> map.put(OptionKey.CHANNEL_ID.getField(), it.asString()));
/* 41 */     options.messageId().toOptional().ifPresent(it -> map.put(OptionKey.MESSAGE_ID.getField(), it.asString()));
/* 42 */     options.count().toOptional().ifPresent(it -> map.put(OptionKey.COUNT.getField(), it));
/* 43 */     options.id().toOptional().ifPresent(it -> map.put(OptionKey.ID.getField(), it.asString()));
/* 44 */     options.type().toOptional().ifPresent(it -> map.put(OptionKey.TYPE.getField(), it));
/* 45 */     options.roleName().toOptional().ifPresent(it -> map.put(OptionKey.ROLE_NAME.getField(), it));
/* 46 */     return map;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\cor\\util\AuditLogUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */