/*    */ package discord4j.core.util;
/*    */ 
/*    */ import discord4j.rest.util.Image;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ImageUtil
/*    */ {
/*    */   private static final String BASE_URL = "https://cdn.discordapp.com/";
/*    */   private static final String URL_FORMAT = "https://cdn.discordapp.com/%s.%s";
/*    */   
/*    */   public static String getUrl(String path, Image.Format format) {
/* 38 */     return String.format("https://cdn.discordapp.com/%s.%s", new Object[] { path, format.getExtension() });
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\cor\\util\ImageUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */