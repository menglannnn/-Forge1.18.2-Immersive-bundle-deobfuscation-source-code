/*    */ package discord4j.core.util;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ import java.util.Collections;
/*    */ import java.util.LinkedHashSet;
/*    */ import java.util.List;
/*    */ import java.util.Objects;
/*    */ import java.util.Set;
/*    */ import java.util.function.Predicate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ListUtil
/*    */ {
/*    */   public static <T> List<T> add(List<T> source, T element) {
/* 26 */     List<T> list = new ArrayList<>(source);
/* 27 */     list.add(element);
/* 28 */     return Collections.unmodifiableList(list);
/*    */   }
/*    */   
/*    */   public static <T> Collection<T> addAllDistinct(List<T> source, List<T> elements) {
/* 32 */     Set<T> set = new LinkedHashSet<>(source);
/* 33 */     set.addAll(elements);
/* 34 */     return Collections.unmodifiableCollection(set);
/*    */   }
/*    */   
/*    */   public static <T> List<T> remove(List<T> source, Predicate<T> filter) {
/* 38 */     if (source.isEmpty()) {
/* 39 */       return source;
/*    */     }
/* 41 */     List<T> list = new ArrayList<>(source);
/* 42 */     list.removeIf(filter);
/* 43 */     return Collections.unmodifiableList(list);
/*    */   }
/*    */ 
/*    */   
/*    */   public static <T> List<T> replace(List<T> source, T old, T replacement) {
/* 48 */     List<T> list = new ArrayList<>(source);
/* 49 */     for (int i = 0; i < list.size(); i++) {
/* 50 */       if (Objects.equals(list.get(i), old)) {
/* 51 */         list.set(i, replacement);
/*    */       }
/*    */     } 
/* 54 */     return Collections.unmodifiableList(list);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\cor\\util\ListUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */