/*     */ package discord4j.core;
/*     */ 
/*     */ import discord4j.common.retry.ReconnectOptions;
/*     */ import discord4j.common.store.Store;
/*     */ import discord4j.core.event.EventDispatcher;
/*     */ import discord4j.core.shard.MemberRequestFilter;
/*     */ import discord4j.core.shard.ShardCoordinator;
/*     */ import discord4j.gateway.GatewayReactorResources;
/*     */ import discord4j.gateway.intent.IntentSet;
/*     */ import discord4j.voice.VoiceReactorResources;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GatewayResources
/*     */ {
/*     */   private final Store store;
/*     */   private final EventDispatcher eventDispatcher;
/*     */   private final ShardCoordinator shardCoordinator;
/*     */   private final MemberRequestFilter memberRequestFilter;
/*     */   private final GatewayReactorResources gatewayReactorResources;
/*     */   private final VoiceReactorResources voiceReactorResources;
/*     */   private final ReconnectOptions voiceReconnectOptions;
/*     */   private final IntentSet intents;
/*     */   
/*     */   public GatewayResources(Store store, EventDispatcher eventDispatcher, ShardCoordinator shardCoordinator, MemberRequestFilter memberRequestFilter, GatewayReactorResources gatewayReactorResources, VoiceReactorResources voiceReactorResources, ReconnectOptions voiceReconnectOptions, IntentSet intents) {
/*  62 */     this.store = store;
/*  63 */     this.eventDispatcher = eventDispatcher;
/*  64 */     this.shardCoordinator = shardCoordinator;
/*  65 */     this.memberRequestFilter = memberRequestFilter;
/*  66 */     this.gatewayReactorResources = gatewayReactorResources;
/*  67 */     this.voiceReactorResources = voiceReactorResources;
/*  68 */     this.voiceReconnectOptions = voiceReconnectOptions;
/*  69 */     this.intents = intents;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IntentSet getIntents() {
/*  78 */     return this.intents;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Store getStore() {
/*  87 */     return this.store;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EventDispatcher getEventDispatcher() {
/*  98 */     return this.eventDispatcher;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ShardCoordinator getShardCoordinator() {
/* 107 */     return this.shardCoordinator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MemberRequestFilter getMemberRequestFilter() {
/* 116 */     return this.memberRequestFilter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GatewayReactorResources getGatewayReactorResources() {
/* 125 */     return this.gatewayReactorResources;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public VoiceReactorResources getVoiceReactorResources() {
/* 134 */     return this.voiceReactorResources;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReconnectOptions getVoiceReconnectOptions() {
/* 143 */     return this.voiceReconnectOptions;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\GatewayResources.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */