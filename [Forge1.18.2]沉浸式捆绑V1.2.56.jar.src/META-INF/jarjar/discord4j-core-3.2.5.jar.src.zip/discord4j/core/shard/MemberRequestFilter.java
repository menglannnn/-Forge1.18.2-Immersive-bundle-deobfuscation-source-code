/*     */ package discord4j.core.shard;
/*     */ 
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.discordjson.json.GuildCreateData;
/*     */ import java.util.function.Function;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @FunctionalInterface
/*     */ public interface MemberRequestFilter
/*     */ {
/*  45 */   public static final MemberRequestFilter DEFAULT = withLargeGuilds();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static MemberRequestFilter all() {
/*  53 */     return data -> Mono.just(Boolean.valueOf(true));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static MemberRequestFilter none() {
/*  62 */     return data -> Mono.just(Boolean.valueOf(false));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static MemberRequestFilter withLargeGuilds() {
/*  71 */     return data -> Mono.just(Boolean.valueOf(data.large()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static MemberRequestFilter withGuilds(Snowflake... guildIds) {
/*  80 */     return data -> Flux.fromArray((Object[])guildIds).hasElement(Snowflake.of(data.id()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default MemberRequestFilter as(Function<Mono<Boolean>, Mono<Boolean>> transformer) {
/* 100 */     return data -> (Mono)apply(data).as(transformer);
/*     */   }
/*     */   
/*     */   Mono<Boolean> apply(GuildCreateData paramGuildCreateData);
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\shard\MemberRequestFilter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */