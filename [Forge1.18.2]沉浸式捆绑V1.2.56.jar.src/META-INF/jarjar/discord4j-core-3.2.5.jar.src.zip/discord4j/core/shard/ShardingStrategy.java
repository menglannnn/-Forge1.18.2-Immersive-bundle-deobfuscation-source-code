/*     */ package discord4j.core.shard;
/*     */ 
/*     */ import discord4j.discordjson.json.GatewayData;
/*     */ import discord4j.discordjson.json.SessionStartLimitData;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import discord4j.gateway.ShardInfo;
/*     */ import discord4j.rest.RestClient;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface ShardingStrategy
/*     */ {
/*     */   default Flux<ShardInfo> getShards(int shardCount) {
/*  49 */     return Flux.range(0, shardCount).map(index -> ShardInfo.create(index.intValue(), shardCount));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Mono<Integer> getMaxConcurrency(RestClient restClient) {
/*  82 */     return Mono.just(Integer.valueOf(getMaxConcurrency()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static ShardingStrategy recommended() {
/*  92 */     return new ShardingStrategy()
/*     */       {
/*     */         public Mono<Integer> getShardCount(RestClient restClient)
/*     */         {
/*  96 */           return restClient.getGatewayService().getGatewayBot()
/*  97 */             .map(GatewayData::shards)
/*  98 */             .map(Possible::get);
/*     */         }
/*     */ 
/*     */         
/*     */         public GatewayClientGroupManager getGroupManager(int shardCount) {
/* 103 */           return new ShardingGatewayClientGroup(shardCount);
/*     */         }
/*     */ 
/*     */         
/*     */         public int getMaxConcurrency() {
/* 108 */           return 1;
/*     */         }
/*     */ 
/*     */         
/*     */         public Mono<Integer> getMaxConcurrency(RestClient restClient) {
/* 113 */           return restClient.getGatewayService().getGatewayBot()
/* 114 */             .map(GatewayData::sessionStartLimit)
/* 115 */             .map(sessionStartLimit -> (Integer)sessionStartLimit.toOptional().map(SessionStartLimitData::maxConcurrency).flatMap(Possible::toOptional).orElseGet(this::getMaxConcurrency));
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static ShardingStrategy fixed(final int count) {
/* 132 */     return new ShardingStrategy()
/*     */       {
/*     */         public Mono<Integer> getShardCount(RestClient restClient)
/*     */         {
/* 136 */           return Mono.just(Integer.valueOf(count));
/*     */         }
/*     */ 
/*     */         
/*     */         public GatewayClientGroupManager getGroupManager(int shardCount) {
/* 141 */           return new ShardingGatewayClientGroup(shardCount);
/*     */         }
/*     */ 
/*     */         
/*     */         public int getMaxConcurrency() {
/* 146 */           return 1;
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static ShardingStrategy single() {
/* 158 */     return new ShardingStrategy()
/*     */       {
/*     */         public Mono<Integer> getShardCount(RestClient restClient)
/*     */         {
/* 162 */           return Mono.just(Integer.valueOf(1));
/*     */         }
/*     */ 
/*     */         
/*     */         public GatewayClientGroupManager getGroupManager(int shardCount) {
/* 167 */           return new SingleGatewayClientGroup();
/*     */         }
/*     */ 
/*     */         
/*     */         public int getMaxConcurrency() {
/* 172 */           return 1;
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static DefaultShardingStrategy.Builder builder() {
/* 183 */     return new DefaultShardingStrategy.Builder();
/*     */   }
/*     */   
/*     */   Mono<Integer> getShardCount(RestClient paramRestClient);
/*     */   
/*     */   GatewayClientGroupManager getGroupManager(int paramInt);
/*     */   
/*     */   @Deprecated
/*     */   int getMaxConcurrency();
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\shard\ShardingStrategy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */