/*     */ package discord4j.core.shard;
/*     */ 
/*     */ import discord4j.common.LogUtil;
/*     */ import discord4j.gateway.SessionInfo;
/*     */ import discord4j.gateway.ShardInfo;
/*     */ import discord4j.gateway.limiter.PayloadTransformer;
/*     */ import discord4j.gateway.limiter.RateLimitTransformer;
/*     */ import java.time.Duration;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.function.Supplier;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.util.Logger;
/*     */ import reactor.util.Loggers;
/*     */ import reactor.util.context.ContextView;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LocalShardCoordinator
/*     */   implements ShardCoordinator
/*     */ {
/*  42 */   private static final Logger log = Loggers.getLogger(LocalShardCoordinator.class);
/*     */ 
/*     */   
/*     */   public static final Supplier<PayloadTransformer> DEFAULT_IDENTIFY_LIMITER_FACTORY = () -> new RateLimitTransformer(1, Duration.ofSeconds(6L));
/*     */   
/*  47 */   private final Map<Integer, PayloadTransformer> limiters = new ConcurrentHashMap<>(1);
/*     */   private final Supplier<PayloadTransformer> identifyLimiterFactory;
/*  49 */   private final Set<Integer> shards = ConcurrentHashMap.newKeySet();
/*     */   
/*     */   private LocalShardCoordinator(Supplier<PayloadTransformer> identifyLimiterFactory) {
/*  52 */     this.identifyLimiterFactory = identifyLimiterFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static LocalShardCoordinator create() {
/*  60 */     return new LocalShardCoordinator(DEFAULT_IDENTIFY_LIMITER_FACTORY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static LocalShardCoordinator create(Supplier<PayloadTransformer> identifyLimiterFactory) {
/*  71 */     return new LocalShardCoordinator(identifyLimiterFactory);
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> publishConnected(ShardInfo shardInfo) {
/*  76 */     return Mono.deferContextual(ctx -> {
/*     */           boolean isNew = this.shards.add(Integer.valueOf(shardInfo.getIndex()));
/*     */           if (isNew) {
/*     */             log.info(LogUtil.format(ctx, "Shard connected"));
/*     */           }
/*     */           return Mono.empty();
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> publishDisconnected(ShardInfo shardInfo, SessionInfo sessionInfo) {
/*  87 */     return Mono.deferContextual(ctx -> {
/*     */           boolean wasRemoved = this.shards.remove(Integer.valueOf(shardInfo.getIndex()));
/*     */           if (wasRemoved) {
/*     */             log.info(LogUtil.format(ctx, "Shard disconnected"));
/*     */           }
/*     */           return Mono.empty();
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   public PayloadTransformer getIdentifyLimiter(ShardInfo shardInfo, int maxConcurrency) {
/*  98 */     return this.limiters.computeIfAbsent(Integer.valueOf(shardInfo.getIndex() % maxConcurrency), k -> (PayloadTransformer)this.identifyLimiterFactory.get());
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Integer> getConnectedCount() {
/* 103 */     Objects.requireNonNull(this.shards); return Mono.fromCallable(this.shards::size);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\shard\LocalShardCoordinator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */