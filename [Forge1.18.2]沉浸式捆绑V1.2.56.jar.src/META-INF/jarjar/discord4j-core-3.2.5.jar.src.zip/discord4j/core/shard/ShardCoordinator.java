package discord4j.core.shard;

import discord4j.gateway.SessionInfo;
import discord4j.gateway.ShardInfo;
import discord4j.gateway.limiter.PayloadTransformer;
import reactor.core.publisher.Mono;
import reactor.util.annotation.Nullable;

public interface ShardCoordinator {
  PayloadTransformer getIdentifyLimiter(ShardInfo paramShardInfo, int paramInt);
  
  Mono<Void> publishConnected(ShardInfo paramShardInfo);
  
  Mono<Void> publishDisconnected(ShardInfo paramShardInfo, @Nullable SessionInfo paramSessionInfo);
  
  Mono<Integer> getConnectedCount();
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\shard\ShardCoordinator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */