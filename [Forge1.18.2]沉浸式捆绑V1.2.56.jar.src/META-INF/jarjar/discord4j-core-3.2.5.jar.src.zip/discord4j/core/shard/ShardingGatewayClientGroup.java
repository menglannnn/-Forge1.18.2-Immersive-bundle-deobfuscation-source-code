/*    */ package discord4j.core.shard;
/*    */ 
/*    */ import discord4j.gateway.GatewayClient;
/*    */ import discord4j.gateway.json.GatewayPayload;
/*    */ import discord4j.gateway.json.ShardGatewayPayload;
/*    */ import java.util.Map;
/*    */ import java.util.Optional;
/*    */ import java.util.concurrent.ConcurrentHashMap;
/*    */ import java.util.stream.Collectors;
/*    */ import org.reactivestreams.Publisher;
/*    */ import reactor.core.publisher.Flux;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ShardingGatewayClientGroup
/*    */   implements GatewayClientGroupManager
/*    */ {
/* 33 */   private final Map<Integer, GatewayClient> map = new ConcurrentHashMap<>();
/*    */   private final int shardCount;
/*    */   
/*    */   ShardingGatewayClientGroup(int shardCount) {
/* 37 */     this.shardCount = shardCount;
/*    */   }
/*    */ 
/*    */   
/*    */   public void add(int key, GatewayClient gatewayClient) {
/* 42 */     this.map.put(Integer.valueOf(key), gatewayClient);
/*    */   }
/*    */ 
/*    */   
/*    */   public void remove(int key) {
/* 47 */     this.map.remove(Integer.valueOf(key));
/*    */   }
/*    */ 
/*    */   
/*    */   public Optional<GatewayClient> find(int index) {
/* 52 */     return Optional.ofNullable(this.map.get(Integer.valueOf(index)));
/*    */   }
/*    */ 
/*    */   
/*    */   public int getShardCount() {
/* 57 */     return this.shardCount;
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<Void> multicast(GatewayPayload<?> payload) {
/* 62 */     return Flux.fromIterable(this.map.values())
/*    */       
/* 64 */       .flatMap(client -> client.send((Publisher)Mono.just(payload)))
/* 65 */       .then();
/*    */   }
/*    */   
/*    */   public Mono<Void> unicast(ShardGatewayPayload<?> payload) {
/* 69 */     return Mono.justOrEmpty(find(payload.getShardIndex()))
/* 70 */       .flatMap(client -> client.send((Publisher)Mono.just(payload)))
/* 71 */       .then();
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<Void> logout() {
/* 76 */     return Mono.whenDelayError((Iterable)this.map.values().stream()
/* 77 */         .map(client -> client.close(false))
/* 78 */         .collect(Collectors.toList()));
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\shard\ShardingGatewayClientGroup.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */