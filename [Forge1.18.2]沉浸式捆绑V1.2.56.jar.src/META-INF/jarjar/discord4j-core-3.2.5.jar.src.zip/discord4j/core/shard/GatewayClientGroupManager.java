package discord4j.core.shard;

import discord4j.gateway.GatewayClient;
import discord4j.gateway.GatewayClientGroup;

interface GatewayClientGroupManager extends GatewayClientGroup {
  void add(int paramInt, GatewayClient paramGatewayClient);
  
  void remove(int paramInt);
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\shard\GatewayClientGroupManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */