/*     */ package discord4j.core.shard;
/*     */ 
/*     */ import discord4j.discordjson.json.GatewayData;
/*     */ import discord4j.gateway.ShardInfo;
/*     */ import discord4j.rest.RestClient;
/*     */ import java.util.Arrays;
/*     */ import java.util.Objects;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Predicate;
/*     */ import org.reactivestreams.Publisher;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultShardingStrategy
/*     */   implements ShardingStrategy
/*     */ {
/*  37 */   public static int RECOMMENDED_SHARD_COUNT = 0;
/*     */   
/*     */   private final int count;
/*     */   private final Function<Integer, Publisher<Integer>> indexSource;
/*     */   private final Predicate<ShardInfo> filter;
/*     */   private final int maxConcurrency;
/*     */   
/*     */   public DefaultShardingStrategy(Builder builder) {
/*  45 */     this.count = builder.shardCount;
/*  46 */     this.indexSource = builder.shardIndexSource;
/*  47 */     this.filter = builder.shardFilter;
/*  48 */     this.maxConcurrency = builder.maxConcurrency;
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Integer> getShardCount(RestClient restClient) {
/*  53 */     if (this.count > 0)
/*  54 */       return Mono.just(Integer.valueOf(this.count)); 
/*  55 */     if (this.count == 0) {
/*  56 */       return restClient.getGatewayService().getGatewayBot()
/*  57 */         .map(data -> (Integer)data.shards().get());
/*     */     }
/*  59 */     return Mono.error(new RuntimeException("Invalid shard count: " + this.count));
/*     */   }
/*     */ 
/*     */   
/*     */   public Flux<ShardInfo> getShards(int shardCount) {
/*  64 */     return Flux.from(this.indexSource.apply(Integer.valueOf(shardCount)))
/*  65 */       .filter(index -> (index.intValue() >= 0 && index.intValue() < shardCount))
/*  66 */       .map(index -> ShardInfo.create(index.intValue(), shardCount))
/*  67 */       .filter(this.filter);
/*     */   }
/*     */ 
/*     */   
/*     */   public GatewayClientGroupManager getGroupManager(int count) {
/*  72 */     return new ShardingGatewayClientGroup(count);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getMaxConcurrency() {
/*  77 */     return this.maxConcurrency;
/*     */   }
/*     */   
/*     */   public static class Builder {
/*     */     private int shardCount;
/*     */     private Function<Integer, Publisher<Integer>> shardIndexSource;
/*     */     
/*     */     public Builder() {
/*  85 */       this.shardCount = DefaultShardingStrategy.RECOMMENDED_SHARD_COUNT;
/*  86 */       this.shardIndexSource = (count -> Flux.range(0, count.intValue()));
/*  87 */       this.shardFilter = (shard -> true);
/*  88 */       this.maxConcurrency = 1;
/*     */     }
/*     */ 
/*     */     
/*     */     private Predicate<ShardInfo> shardFilter;
/*     */     
/*     */     private int maxConcurrency;
/*     */     
/*     */     public Builder count(int shardCount) {
/*  97 */       if (shardCount < 0) {
/*  98 */         throw new IllegalArgumentException("shardCount < 0");
/*     */       }
/* 100 */       this.shardCount = shardCount;
/* 101 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder indices(int... shardIndices) {
/* 112 */       this.shardIndexSource = (count -> Flux.fromStream(Arrays.stream(shardIndices).boxed()));
/* 113 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder indices(Function<Integer, Publisher<Integer>> shardIndexSource) {
/* 125 */       this.shardIndexSource = Objects.<Function<Integer, Publisher<Integer>>>requireNonNull(shardIndexSource);
/* 126 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder filter(Predicate<ShardInfo> shardFilter) {
/* 138 */       this.shardFilter = Objects.<Predicate<ShardInfo>>requireNonNull(shardFilter);
/* 139 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder maxConcurrency(int maxConcurrency) {
/* 152 */       if (maxConcurrency < 1) {
/* 153 */         throw new IllegalArgumentException("maxConcurrency < 1");
/*     */       }
/* 155 */       if ((maxConcurrency & maxConcurrency - 1) != 0) {
/* 156 */         throw new IllegalArgumentException("maxConcurrency must be a power of 2");
/*     */       }
/* 158 */       this.maxConcurrency = maxConcurrency;
/* 159 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ShardingStrategy build() {
/* 168 */       return new DefaultShardingStrategy(this);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\shard\DefaultShardingStrategy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */