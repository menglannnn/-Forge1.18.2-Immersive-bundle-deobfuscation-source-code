/*     */ package discord4j.core.shard;
/*     */ 
/*     */ import discord4j.common.close.CloseStatus;
/*     */ import discord4j.discordjson.json.gateway.Dispatch;
/*     */ import discord4j.gateway.GatewayClient;
/*     */ import discord4j.gateway.GatewayConnection;
/*     */ import discord4j.gateway.json.GatewayPayload;
/*     */ import discord4j.gateway.json.ShardGatewayPayload;
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import java.time.Duration;
/*     */ import java.util.Optional;
/*     */ import java.util.concurrent.atomic.AtomicReference;
/*     */ import java.util.function.Function;
/*     */ import org.reactivestreams.Publisher;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.core.publisher.Sinks;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SingleGatewayClientGroup
/*     */   implements GatewayClientGroupManager
/*     */ {
/*  41 */   private final AtomicReference<GatewayClient> client = new AtomicReference<>();
/*     */ 
/*     */   
/*     */   public void add(int key, GatewayClient gatewayClient) {
/*  45 */     this.client.set(gatewayClient);
/*     */   }
/*     */ 
/*     */   
/*     */   public void remove(int key) {
/*  50 */     this.client.set(null);
/*     */   }
/*     */   
/*     */   private Optional<GatewayClient> instance() {
/*  54 */     return Optional.ofNullable(this.client.get());
/*     */   }
/*     */ 
/*     */   
/*     */   public Optional<GatewayClient> find(int index) {
/*  59 */     return instance().map(client -> new RoutableGatewayClient(client, index));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getShardCount() {
/*  65 */     return ((Integer)instance()
/*  66 */       .map(GatewayClient::getShardCount)
/*  67 */       .orElseThrow(() -> new IllegalStateException("Missing shard count information"))).intValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> multicast(GatewayPayload<?> payload) {
/*  72 */     return Mono.defer(() -> Mono.just(Integer.valueOf(getShardCount())))
/*  73 */       .flatMapMany(count -> Flux.range(0, count.intValue()))
/*  74 */       .flatMap(index -> unicast(makeShardAware(payload, index.intValue())))
/*  75 */       .then();
/*     */   }
/*     */   
/*     */   private static ShardGatewayPayload<?> makeShardAware(GatewayPayload<?> payload, int shardIndex) {
/*  79 */     if (payload instanceof ShardGatewayPayload) {
/*  80 */       ShardGatewayPayload<?> shardedPayload = (ShardGatewayPayload)payload;
/*  81 */       if (shardedPayload.getShardIndex() != shardIndex) {
/*  82 */         return new ShardGatewayPayload(payload, shardIndex);
/*     */       }
/*     */     } 
/*  85 */     return new ShardGatewayPayload(payload, shardIndex);
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> unicast(ShardGatewayPayload<?> payload) {
/*  90 */     return Mono.defer(() -> Mono.justOrEmpty(instance()).switchIfEmpty(Mono.error(new IllegalStateException("Missing gateway client"))))
/*     */       
/*  92 */       .flatMap(client -> client.send((Publisher)Mono.just(payload)));
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> logout() {
/*  97 */     return Mono.defer(() -> Mono.justOrEmpty(instance()))
/*  98 */       .flatMap(client -> client.close(false).then());
/*     */   }
/*     */   
/*     */   private static class RoutableGatewayClient
/*     */     implements GatewayClient {
/*     */     private final GatewayClient client;
/*     */     private final int shardIndex;
/*     */     
/*     */     private RoutableGatewayClient(GatewayClient client, int shardIndex) {
/* 107 */       this.client = client;
/* 108 */       this.shardIndex = shardIndex;
/*     */     }
/*     */ 
/*     */     
/*     */     public Mono<Void> execute(String gatewayUrl) {
/* 113 */       return this.client.execute(gatewayUrl);
/*     */     }
/*     */ 
/*     */     
/*     */     public Mono<CloseStatus> close(boolean allowResume) {
/* 118 */       return this.client.close(allowResume);
/*     */     }
/*     */ 
/*     */     
/*     */     public Flux<Dispatch> dispatch() {
/* 123 */       return this.client.dispatch();
/*     */     }
/*     */ 
/*     */     
/*     */     public Flux<GatewayPayload<?>> receiver() {
/* 128 */       return this.client.receiver();
/*     */     }
/*     */ 
/*     */     
/*     */     public <T> Flux<T> receiver(Function<ByteBuf, Publisher<? extends T>> mapper) {
/* 133 */       return this.client.receiver(mapper);
/*     */     }
/*     */ 
/*     */     
/*     */     public Mono<Void> send(Publisher<? extends GatewayPayload<?>> publisher) {
/* 138 */       return Flux.from(publisher)
/* 139 */         .doOnNext(payload -> sender().emitNext(SingleGatewayClientGroup.makeShardAware(payload, this.shardIndex), Sinks.EmitFailureHandler.FAIL_FAST))
/* 140 */         .then();
/*     */     }
/*     */ 
/*     */     
/*     */     public Sinks.Many<GatewayPayload<?>> sender() {
/* 145 */       return this.client.sender();
/*     */     }
/*     */ 
/*     */     
/*     */     public Mono<Void> sendBuffer(Publisher<ByteBuf> publisher) {
/* 150 */       return this.client.sendBuffer(publisher);
/*     */     }
/*     */ 
/*     */     
/*     */     public int getShardCount() {
/* 155 */       return this.client.getShardCount();
/*     */     }
/*     */ 
/*     */     
/*     */     public String getSessionId() {
/* 160 */       return this.client.getSessionId();
/*     */     }
/*     */ 
/*     */     
/*     */     public int getSequence() {
/* 165 */       return this.client.getSequence();
/*     */     }
/*     */ 
/*     */     
/*     */     public Flux<GatewayConnection.State> stateEvents() {
/* 170 */       return this.client.stateEvents();
/*     */     }
/*     */ 
/*     */     
/*     */     public Mono<Boolean> isConnected() {
/* 175 */       return this.client.isConnected();
/*     */     }
/*     */ 
/*     */     
/*     */     public Duration getResponseTime() {
/* 180 */       return this.client.getResponseTime();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\shard\SingleGatewayClientGroup.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */