/*     */ package discord4j.core.shard;
/*     */ 
/*     */ import discord4j.common.LogUtil;
/*     */ import discord4j.common.ReactorResources;
/*     */ import discord4j.common.annotations.Experimental;
/*     */ import discord4j.common.retry.ReconnectOptions;
/*     */ import discord4j.common.store.Store;
/*     */ import discord4j.common.store.action.gateway.GatewayActions;
/*     */ import discord4j.common.store.api.StoreAction;
/*     */ import discord4j.common.store.api.layout.StoreLayout;
/*     */ import discord4j.common.store.impl.LocalStoreLayout;
/*     */ import discord4j.common.util.Snowflake;
/*     */ import discord4j.core.DiscordClient;
/*     */ import discord4j.core.GatewayDiscordClient;
/*     */ import discord4j.core.GatewayResources;
/*     */ import discord4j.core.event.EventDispatcher;
/*     */ import discord4j.core.event.dispatch.DispatchContext;
/*     */ import discord4j.core.event.dispatch.DispatchEventMapper;
/*     */ import discord4j.core.object.presence.ClientPresence;
/*     */ import discord4j.core.retriever.EntityRetrievalStrategy;
/*     */ import discord4j.discordjson.json.GatewayData;
/*     */ import discord4j.discordjson.json.gateway.GuildMembersChunk;
/*     */ import discord4j.discordjson.json.gateway.StatusUpdate;
/*     */ import discord4j.gateway.GatewayClient;
/*     */ import discord4j.gateway.GatewayObserver;
/*     */ import discord4j.gateway.GatewayOptions;
/*     */ import discord4j.gateway.GatewayReactorResources;
/*     */ import discord4j.gateway.IdentifyOptions;
/*     */ import discord4j.gateway.SessionInfo;
/*     */ import discord4j.gateway.ShardInfo;
/*     */ import discord4j.gateway.intent.Intent;
/*     */ import discord4j.gateway.intent.IntentSet;
/*     */ import discord4j.gateway.limiter.PayloadTransformer;
/*     */ import discord4j.gateway.limiter.RateLimitTransformer;
/*     */ import discord4j.gateway.payload.JacksonPayloadReader;
/*     */ import discord4j.gateway.payload.JacksonPayloadWriter;
/*     */ import discord4j.gateway.payload.PayloadReader;
/*     */ import discord4j.gateway.payload.PayloadWriter;
/*     */ import discord4j.gateway.retry.GatewayStateChange;
/*     */ import discord4j.gateway.state.DispatchStoreLayer;
/*     */ import discord4j.gateway.state.StatefulDispatch;
/*     */ import discord4j.rest.RestClient;
/*     */ import discord4j.rest.util.Multimap;
/*     */ import discord4j.rest.util.RouteUtils;
/*     */ import discord4j.voice.DefaultVoiceConnectionFactory;
/*     */ import discord4j.voice.VoiceConnectionFactory;
/*     */ import discord4j.voice.VoiceReactorResources;
/*     */ import java.time.Duration;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.atomic.AtomicReference;
/*     */ import java.util.concurrent.locks.LockSupport;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Supplier;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.Disposable;
/*     */ import reactor.core.Disposables;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.GroupedFlux;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.core.publisher.MonoSink;
/*     */ import reactor.core.publisher.Signal;
/*     */ import reactor.core.publisher.SignalType;
/*     */ import reactor.core.publisher.Sinks;
/*     */ import reactor.function.TupleUtils;
/*     */ import reactor.netty.resources.ConnectionProvider;
/*     */ import reactor.util.Logger;
/*     */ import reactor.util.Loggers;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ import reactor.util.context.ContextView;
/*     */ import reactor.util.retry.Retry;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GatewayBootstrap<O extends GatewayOptions>
/*     */ {
/* 113 */   private static final Logger log = Loggers.getLogger(GatewayBootstrap.class);
/*     */   
/*     */   private final DiscordClient client;
/*     */   
/*     */   private final Function<GatewayOptions, O> optionsModifier;
/* 118 */   private ShardingStrategy shardingStrategy = ShardingStrategy.recommended();
/* 119 */   private Boolean awaitConnections = null;
/* 120 */   private ShardCoordinator shardCoordinator = null;
/* 121 */   private EventDispatcher eventDispatcher = null;
/* 122 */   private Store store = null;
/* 123 */   private MemberRequestFilter memberRequestFilter = null;
/*     */   private Function<ShardInfo, ClientPresence> initialPresence = shard -> null;
/*     */   private Function<ShardInfo, SessionInfo> resumeOptions = shard -> null;
/* 126 */   private IntentSet intents = IntentSet.nonPrivileged();
/* 127 */   private Boolean guildSubscriptions = null;
/* 128 */   private Function<GatewayDiscordClient, Mono<Void>> destroyHandler = shutdownDestroyHandler();
/* 129 */   private PayloadReader payloadReader = null;
/* 130 */   private PayloadWriter payloadWriter = null;
/* 131 */   private ReconnectOptions reconnectOptions = null;
/* 132 */   private ReconnectOptions voiceReconnectOptions = null;
/* 133 */   private GatewayObserver gatewayObserver = GatewayObserver.NOOP_LISTENER;
/* 134 */   private Function<ReactorResources, GatewayReactorResources> gatewayReactorResources = null;
/* 135 */   private Function<ReactorResources, VoiceReactorResources> voiceReactorResources = null;
/* 136 */   private VoiceConnectionFactory voiceConnectionFactory = defaultVoiceConnectionFactory();
/* 137 */   private EntityRetrievalStrategy entityRetrievalStrategy = null;
/* 138 */   private DispatchEventMapper dispatchEventMapper = null;
/* 139 */   private int maxMissedHeartbeatAck = 1;
/*     */ 
/*     */   
/*     */   private Function<EventDispatcher, Publisher<?>> dispatcherFunction;
/*     */ 
/*     */   
/*     */   private static final Sinks.EmitFailureHandler OPTIMISTIC;
/*     */ 
/*     */ 
/*     */   
/*     */   public static GatewayBootstrap<GatewayOptions> create(DiscordClient client) {
/* 150 */     return new GatewayBootstrap<>(client, Function.identity());
/*     */   }
/*     */   
/*     */   GatewayBootstrap(DiscordClient client, Function<GatewayOptions, O> optionsModifier) {
/* 154 */     this.client = client;
/* 155 */     this.optionsModifier = optionsModifier;
/*     */   }
/*     */   
/*     */   GatewayBootstrap(GatewayBootstrap<?> source, Function<GatewayOptions, O> optionsModifier) {
/* 159 */     this.optionsModifier = optionsModifier;
/*     */     
/* 161 */     this.client = source.client;
/* 162 */     this.shardingStrategy = source.shardingStrategy;
/* 163 */     this.awaitConnections = source.awaitConnections;
/* 164 */     this.shardCoordinator = source.shardCoordinator;
/* 165 */     this.eventDispatcher = source.eventDispatcher;
/* 166 */     this.store = source.store;
/* 167 */     this.memberRequestFilter = source.memberRequestFilter;
/* 168 */     this.initialPresence = source.initialPresence;
/* 169 */     this.resumeOptions = source.resumeOptions;
/* 170 */     this.intents = source.intents;
/* 171 */     this.guildSubscriptions = source.guildSubscriptions;
/* 172 */     this.destroyHandler = source.destroyHandler;
/* 173 */     this.payloadReader = source.payloadReader;
/* 174 */     this.payloadWriter = source.payloadWriter;
/* 175 */     this.reconnectOptions = source.reconnectOptions;
/* 176 */     this.voiceReconnectOptions = source.voiceReconnectOptions;
/* 177 */     this.gatewayObserver = source.gatewayObserver;
/* 178 */     this.gatewayReactorResources = source.gatewayReactorResources;
/* 179 */     this.voiceReactorResources = source.voiceReactorResources;
/* 180 */     this.voiceConnectionFactory = source.voiceConnectionFactory;
/* 181 */     this.entityRetrievalStrategy = source.entityRetrievalStrategy;
/* 182 */     this.dispatchEventMapper = source.dispatchEventMapper;
/* 183 */     this.maxMissedHeartbeatAck = source.maxMissedHeartbeatAck;
/* 184 */     this.dispatcherFunction = source.dispatcherFunction;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <O2 extends GatewayOptions> GatewayBootstrap<O2> setExtraOptions(Function<? super O, O2> optionsModifier) {
/* 197 */     return new GatewayBootstrap(this, this.optionsModifier.andThen(optionsModifier));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GatewayBootstrap<O> setSharding(ShardingStrategy shardingStrategy) {
/* 220 */     this.shardingStrategy = shardingStrategy;
/* 221 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GatewayBootstrap<O> setAwaitConnections(boolean awaitConnections) {
/* 233 */     this.awaitConnections = Boolean.valueOf(awaitConnections);
/* 234 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GatewayBootstrap<O> setShardCoordinator(ShardCoordinator shardCoordinator) {
/* 246 */     this.shardCoordinator = Objects.<ShardCoordinator>requireNonNull(shardCoordinator);
/* 247 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GatewayBootstrap<O> setEventDispatcher(@Nullable EventDispatcher eventDispatcher) {
/* 259 */     this.eventDispatcher = eventDispatcher;
/* 260 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GatewayBootstrap<O> setStore(@Nullable Store store) {
/* 270 */     this.store = store;
/* 271 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GatewayBootstrap<O> setMemberRequestFilter(MemberRequestFilter memberRequestFilter) {
/* 284 */     this.memberRequestFilter = memberRequestFilter;
/* 285 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GatewayBootstrap<O> setDestroyHandler(Function<GatewayDiscordClient, Mono<Void>> destroyHandler) {
/* 298 */     this.destroyHandler = Objects.<Function<GatewayDiscordClient, Mono<Void>>>requireNonNull(destroyHandler, "destroyHandler");
/* 299 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GatewayBootstrap<O> setInitialPresence(Function<ShardInfo, ClientPresence> initialPresence) {
/* 310 */     this.initialPresence = Objects.<Function<ShardInfo, ClientPresence>>requireNonNull(initialPresence, "initialPresence");
/* 311 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public GatewayBootstrap<O> setInitialStatus(Function<ShardInfo, ClientPresence> initialStatus) {
/* 324 */     this.initialPresence = Objects.<Function<ShardInfo, ClientPresence>>requireNonNull(initialStatus, "initialStatus");
/* 325 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GatewayBootstrap<O> setResumeOptions(Function<ShardInfo, SessionInfo> resumeOptions) {
/* 338 */     this.resumeOptions = Objects.<Function<ShardInfo, SessionInfo>>requireNonNull(resumeOptions, "resumeOptions");
/* 339 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GatewayBootstrap<O> setEnabledIntents(IntentSet intents) {
/* 371 */     this.intents = Objects.<IntentSet>requireNonNull(intents);
/* 372 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GatewayBootstrap<O> setDisabledIntents(IntentSet intents) {
/* 405 */     this.intents = IntentSet.all().andNot(Objects.<IntentSet>requireNonNull(intents));
/* 406 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GatewayBootstrap<O> setPayloadReader(@Nullable PayloadReader payloadReader) {
/* 416 */     this.payloadReader = payloadReader;
/* 417 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GatewayBootstrap<O> setPayloadWriter(@Nullable PayloadWriter payloadWriter) {
/* 427 */     this.payloadWriter = payloadWriter;
/* 428 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GatewayBootstrap<O> setReconnectOptions(ReconnectOptions reconnectOptions) {
/* 439 */     this.reconnectOptions = Objects.<ReconnectOptions>requireNonNull(reconnectOptions);
/* 440 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GatewayBootstrap<O> setVoiceReconnectOptions(ReconnectOptions voiceReconnectOptions) {
/* 451 */     this.voiceReconnectOptions = Objects.<ReconnectOptions>requireNonNull(voiceReconnectOptions);
/* 452 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GatewayBootstrap<O> setGatewayObserver(GatewayObserver gatewayObserver) {
/* 462 */     this.gatewayObserver = Objects.<GatewayObserver>requireNonNull(gatewayObserver);
/* 463 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GatewayBootstrap<O> setGatewayReactorResources(Function<ReactorResources, GatewayReactorResources> gatewayReactorResources) {
/* 475 */     this.gatewayReactorResources = Objects.<Function<ReactorResources, GatewayReactorResources>>requireNonNull(gatewayReactorResources);
/* 476 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GatewayBootstrap<O> setVoiceReactorResources(Function<ReactorResources, VoiceReactorResources> voiceReactorResources) {
/* 488 */     this.voiceReactorResources = Objects.<Function<ReactorResources, VoiceReactorResources>>requireNonNull(voiceReactorResources);
/* 489 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GatewayBootstrap<O> setVoiceConnectionFactory(VoiceConnectionFactory voiceConnectionFactory) {
/* 500 */     this.voiceConnectionFactory = Objects.<VoiceConnectionFactory>requireNonNull(voiceConnectionFactory);
/* 501 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GatewayBootstrap<O> setEntityRetrievalStrategy(@Nullable EntityRetrievalStrategy entityRetrievalStrategy) {
/* 512 */     this.entityRetrievalStrategy = entityRetrievalStrategy;
/* 513 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GatewayBootstrap<O> setDispatchEventMapper(DispatchEventMapper dispatchEventMapper) {
/* 525 */     this.dispatchEventMapper = Objects.<DispatchEventMapper>requireNonNull(dispatchEventMapper);
/* 526 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GatewayBootstrap<O> setMaxMissedHeartbeatAck(int maxMissedHeartbeatAck) {
/* 538 */     this.maxMissedHeartbeatAck = Math.max(0, maxMissedHeartbeatAck);
/* 539 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Experimental
/*     */   public GatewayBootstrap<O> withEventDispatcher(Function<EventDispatcher, Publisher<?>> dispatcherFunction) {
/* 555 */     this.dispatcherFunction = Objects.<Function<EventDispatcher, Publisher<?>>>requireNonNull(dispatcherFunction);
/* 556 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Void> withGateway(Function<GatewayDiscordClient, Publisher<?>> whileConnectedFunction) {
/* 576 */     return usingConnection(gateway -> Flux.from(whileConnectedFunction.apply(gateway)).then(gateway.onDisconnect()));
/*     */   }
/*     */   
/*     */   private <T> Mono<T> usingConnection(Function<GatewayDiscordClient, Mono<T>> onConnectedFunction) {
/* 580 */     return Mono.usingWhen((Publisher)login(), onConnectedFunction, GatewayDiscordClient::logout);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<GatewayDiscordClient> login() {
/* 601 */     return login(discord4j.gateway.DefaultGatewayClient::new);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<GatewayDiscordClient> login(Function<O, GatewayClient> clientFactory) {
/* 614 */     return Mono.fromCallable(() -> new GatewayBootstrap(this, this.optionsModifier))
/* 615 */       .zipWhen(b -> b.shardingStrategy.getShardCount((RestClient)b.client))
/* 616 */       .flatMap(TupleUtils.function((b, count) -> {
/*     */             Store store = b.initStore();
/*     */ 
/*     */ 
/*     */             
/*     */             EventDispatcher eventDispatcher = b.initEventDispatcher();
/*     */ 
/*     */ 
/*     */             
/*     */             GatewayReactorResources gatewayReactorResources = b.initGatewayReactorResources(count.intValue());
/*     */ 
/*     */ 
/*     */             
/*     */             ShardCoordinator shardCoordinator = b.initShardCoordinator((ReactorResources)gatewayReactorResources);
/*     */ 
/*     */ 
/*     */             
/*     */             VoiceReactorResources voiceReactorResources = b.initVoiceReactorResources();
/*     */ 
/*     */ 
/*     */             
/*     */             GatewayResources resources = new GatewayResources(store, eventDispatcher, shardCoordinator, b.initMemberRequestFilter(b.intents), gatewayReactorResources, b.initVoiceReactorResources(), b.initReconnectOptions(voiceReactorResources), b.intents);
/*     */ 
/*     */ 
/*     */             
/*     */             Sinks.Empty<Void> onCloseSink = Sinks.empty();
/*     */ 
/*     */ 
/*     */             
/*     */             AtomicReference<Throwable> dispatcherFunctionError = new AtomicReference<>();
/*     */ 
/*     */ 
/*     */             
/*     */             EntityRetrievalStrategy entityRetrievalStrategy = b.initEntityRetrievalStrategy();
/*     */ 
/*     */ 
/*     */             
/*     */             DispatchEventMapper dispatchMapper = b.initDispatchEventMapper();
/*     */ 
/*     */             
/*     */             Set<String> completingChunkNonces = ConcurrentHashMap.newKeySet();
/*     */ 
/*     */             
/*     */             GatewayClientGroupManager clientGroup = b.shardingStrategy.getGroupManager(count.intValue());
/*     */ 
/*     */             
/*     */             GatewayDiscordClient gateway = new GatewayDiscordClient(b.client, resources, onCloseSink.asMono(), clientGroup, b.voiceConnectionFactory, entityRetrievalStrategy, completingChunkNonces);
/*     */ 
/*     */             
/*     */             Mono<Void> destroySequence = Mono.deferContextual(()).cache();
/*     */ 
/*     */             
/*     */             Flux<ShardInfo> connections = b.shardingStrategy.getMaxConcurrency((RestClient)b.client).flatMapMany(());
/*     */ 
/*     */             
/*     */             Supplier<Mono<Void>> withEventDispatcherFunction = ();
/*     */ 
/*     */             
/*     */             Function<MonoSink<GatewayDiscordClient>, Flux<ShardInfo>> onFirstConnection = ();
/*     */ 
/*     */             
/* 677 */             return ((b.awaitConnections == null) ? (count.intValue() == 1) : b.awaitConnections.booleanValue()) ? ((b.dispatcherFunction != null) ? Mono.create(()) : connections.then(Mono.just(gateway))) : ((b.dispatcherFunction != null) ? Mono.create(()) : Mono.create(()));
/*     */           }));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Mono<ShardInfo> acquireConnection(GatewayBootstrap<O> b, ShardInfo shard, Function<O, GatewayClient> clientFactory, GatewayDiscordClient gateway, ShardCoordinator shardCoordinator, Store store, EventDispatcher eventDispatcher, GatewayClientGroupManager clientGroup, Sinks.Empty<Void> onCloseSink, DispatchEventMapper dispatchMapper, Set<String> completingChunkNonces, Mono<Void> destroySequence, int maxConcurrency) {
/* 727 */     return Mono.deferContextual(ctx -> Mono.create(()))
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 844 */       .contextWrite(buildContext(gateway, shard));
/*     */   }
/*     */   
/*     */   private Function<Context, Context> buildContext(GatewayDiscordClient gateway, ShardInfo shard) {
/* 848 */     return ctx -> ctx.put("discord4j.gateway", Integer.toHexString(gateway.hashCode())).put("discord4j.shard", Integer.valueOf(shard.getIndex()));
/*     */   }
/*     */ 
/*     */   
/*     */   private PayloadReader initPayloadReader() {
/* 853 */     if (this.payloadReader != null) {
/* 854 */       return this.payloadReader;
/*     */     }
/* 856 */     return (PayloadReader)new JacksonPayloadReader(this.client.getCoreResources().getJacksonResources().getObjectMapper());
/*     */   }
/*     */   
/*     */   private PayloadWriter initPayloadWriter() {
/* 860 */     if (this.payloadWriter != null) {
/* 861 */       return this.payloadWriter;
/*     */     }
/* 863 */     return (PayloadWriter)new JacksonPayloadWriter(this.client.getCoreResources().getJacksonResources().getObjectMapper());
/*     */   }
/*     */   
/*     */   private ReconnectOptions initReconnectOptions(GatewayReactorResources resources) {
/* 867 */     if (this.reconnectOptions != null) {
/* 868 */       return this.reconnectOptions;
/*     */     }
/* 870 */     return ReconnectOptions.builder()
/* 871 */       .setBackoffScheduler(resources.getTimerTaskScheduler())
/* 872 */       .build();
/*     */   }
/*     */   
/*     */   private ReconnectOptions initReconnectOptions(VoiceReactorResources resources) {
/* 876 */     if (this.reconnectOptions != null) {
/* 877 */       return this.reconnectOptions;
/*     */     }
/* 879 */     return ReconnectOptions.builder()
/* 880 */       .setBackoffScheduler(resources.getTimerTaskScheduler())
/* 881 */       .build();
/*     */   }
/*     */   
/*     */   private GatewayReactorResources initGatewayReactorResources(int count) {
/* 885 */     if (this.gatewayReactorResources == null) {
/* 886 */       int maxConnections = Math.max(ConnectionProvider.DEFAULT_POOL_MAX_CONNECTIONS, count);
/* 887 */       this.gatewayReactorResources = (res -> GatewayReactorResources.builder(res).httpClient(ReactorResources.newHttpClient(ConnectionProvider.create("d4j-gateway", maxConnections))).build());
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 892 */     return this.gatewayReactorResources.apply(this.client.getCoreResources().getReactorResources());
/*     */   }
/*     */   
/*     */   private VoiceReactorResources initVoiceReactorResources() {
/* 896 */     if (this.voiceReactorResources == null) {
/* 897 */       this.voiceReactorResources = VoiceReactorResources::new;
/*     */     }
/* 899 */     return this.voiceReactorResources.apply(this.client.getCoreResources().getReactorResources());
/*     */   }
/*     */   
/*     */   private EventDispatcher initEventDispatcher() {
/* 903 */     if (this.eventDispatcher != null) {
/* 904 */       return this.eventDispatcher;
/*     */     }
/* 906 */     return EventDispatcher.buffering();
/*     */   }
/*     */   
/*     */   private ShardCoordinator initShardCoordinator(ReactorResources reactorResources) {
/* 910 */     if (this.shardCoordinator != null) {
/* 911 */       return this.shardCoordinator;
/*     */     }
/* 913 */     return LocalShardCoordinator.create(() -> new RateLimitTransformer(1, Duration.ofSeconds(6L), reactorResources.getTimerTaskScheduler()));
/*     */   }
/*     */ 
/*     */   
/*     */   private EntityRetrievalStrategy initEntityRetrievalStrategy() {
/* 918 */     if (this.entityRetrievalStrategy != null) {
/* 919 */       return this.entityRetrievalStrategy;
/*     */     }
/* 921 */     return EntityRetrievalStrategy.STORE_FALLBACK_REST;
/*     */   }
/*     */   
/*     */   private DispatchEventMapper initDispatchEventMapper() {
/* 925 */     if (this.dispatchEventMapper != null) {
/* 926 */       return this.dispatchEventMapper;
/*     */     }
/* 928 */     return DispatchEventMapper.emitEvents();
/*     */   }
/*     */   
/*     */   private Store initStore() {
/* 932 */     if (this.store != null) {
/* 933 */       return this.store;
/*     */     }
/* 935 */     return Store.fromLayout((StoreLayout)LocalStoreLayout.create());
/*     */   }
/*     */   
/*     */   private MemberRequestFilter initMemberRequestFilter(IntentSet intents) {
/* 939 */     if (this.memberRequestFilter != null)
/* 940 */       return this.memberRequestFilter; 
/* 941 */     if (intents.contains(Intent.GUILD_MEMBERS)) {
/* 942 */       return MemberRequestFilter.withLargeGuilds();
/*     */     }
/* 944 */     return MemberRequestFilter.none();
/*     */   }
/*     */ 
/*     */   
/*     */   private Multimap<String, Object> getGatewayParameters() {
/* 949 */     Multimap<String, Object> parameters = new Multimap(3);
/* 950 */     parameters.add("compress", "zlib-stream");
/* 951 */     parameters.add("encoding", "json");
/* 952 */     parameters.add("v", Integer.valueOf(8));
/* 953 */     return parameters;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Function<GatewayDiscordClient, Mono<Void>> noopDestroyHandler() {
/* 962 */     return gateway -> Mono.empty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Function<GatewayDiscordClient, Mono<Void>> shutdownDestroyHandler() {
/* 972 */     return gateway -> {
/*     */         gateway.getEventDispatcher().shutdown();
/*     */         return Mono.empty();
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static VoiceConnectionFactory defaultVoiceConnectionFactory() {
/* 984 */     return (VoiceConnectionFactory)new DefaultVoiceConnectionFactory();
/*     */   }
/*     */   static {
/* 987 */     OPTIMISTIC = ((signalType, emitResult) -> {
/*     */         if (emitResult == Sinks.EmitResult.FAIL_NON_SERIALIZED) {
/*     */           LockSupport.parkNanos(10L);
/*     */           return true;
/*     */         } 
/*     */         return false;
/*     */       });
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-core-3.2.5.jar!\discord4j\core\shard\GatewayBootstrap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */