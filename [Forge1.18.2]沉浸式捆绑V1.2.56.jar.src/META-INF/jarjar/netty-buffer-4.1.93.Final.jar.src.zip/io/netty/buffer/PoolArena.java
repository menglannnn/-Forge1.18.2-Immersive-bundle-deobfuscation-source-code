/*     */ package io.netty.buffer;
/*     */ 
/*     */ import io.netty.util.internal.LongCounter;
/*     */ import io.netty.util.internal.PlatformDependent;
/*     */ import io.netty.util.internal.StringUtil;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class PoolArena<T>
/*     */   extends SizeClasses
/*     */   implements PoolArenaMetric
/*     */ {
/*     */   final PooledByteBufAllocator parent;
/*     */   final int numSmallSubpagePools;
/*     */   final int directMemoryCacheAlignment;
/*     */   private final PoolSubpage<T>[] smallSubpagePools;
/*     */   private final PoolChunkList<T> q050;
/*     */   private final PoolChunkList<T> q025;
/*     */   private final PoolChunkList<T> q000;
/*     */   private final PoolChunkList<T> qInit;
/*     */   private final PoolChunkList<T> q075;
/*     */   private final PoolChunkList<T> q100;
/*     */   private final List<PoolChunkListMetric> chunkListMetrics;
/*     */   private long allocationsNormal;
/*  34 */   private static final boolean HAS_UNSAFE = PlatformDependent.hasUnsafe();
/*     */   
/*     */   enum SizeClass {
/*  37 */     Small,
/*  38 */     Normal;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  59 */   private final LongCounter allocationsSmall = PlatformDependent.newLongCounter();
/*  60 */   private final LongCounter allocationsHuge = PlatformDependent.newLongCounter();
/*  61 */   private final LongCounter activeBytesHuge = PlatformDependent.newLongCounter();
/*     */   
/*     */   private long deallocationsSmall;
/*     */   
/*     */   private long deallocationsNormal;
/*     */   
/*  67 */   private final LongCounter deallocationsHuge = PlatformDependent.newLongCounter();
/*     */ 
/*     */   
/*  70 */   final AtomicInteger numThreadCaches = new AtomicInteger();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  75 */   private final ReentrantLock lock = new ReentrantLock();
/*     */ 
/*     */   
/*     */   protected PoolArena(PooledByteBufAllocator parent, int pageSize, int pageShifts, int chunkSize, int cacheAlignment) {
/*  79 */     super(pageSize, pageShifts, chunkSize, cacheAlignment);
/*  80 */     this.parent = parent;
/*  81 */     this.directMemoryCacheAlignment = cacheAlignment;
/*     */     
/*  83 */     this.numSmallSubpagePools = this.nSubpages;
/*  84 */     this.smallSubpagePools = newSubpagePoolArray(this.numSmallSubpagePools);
/*  85 */     for (int i = 0; i < this.smallSubpagePools.length; i++) {
/*  86 */       this.smallSubpagePools[i] = newSubpagePoolHead();
/*     */     }
/*     */     
/*  89 */     this.q100 = new PoolChunkList<T>(this, null, 100, 2147483647, chunkSize);
/*  90 */     this.q075 = new PoolChunkList<T>(this, this.q100, 75, 100, chunkSize);
/*  91 */     this.q050 = new PoolChunkList<T>(this, this.q075, 50, 100, chunkSize);
/*  92 */     this.q025 = new PoolChunkList<T>(this, this.q050, 25, 75, chunkSize);
/*  93 */     this.q000 = new PoolChunkList<T>(this, this.q025, 1, 50, chunkSize);
/*  94 */     this.qInit = new PoolChunkList<T>(this, this.q000, -2147483648, 25, chunkSize);
/*     */     
/*  96 */     this.q100.prevList(this.q075);
/*  97 */     this.q075.prevList(this.q050);
/*  98 */     this.q050.prevList(this.q025);
/*  99 */     this.q025.prevList(this.q000);
/* 100 */     this.q000.prevList(null);
/* 101 */     this.qInit.prevList(this.qInit);
/*     */     
/* 103 */     List<PoolChunkListMetric> metrics = new ArrayList<PoolChunkListMetric>(6);
/* 104 */     metrics.add(this.qInit);
/* 105 */     metrics.add(this.q000);
/* 106 */     metrics.add(this.q025);
/* 107 */     metrics.add(this.q050);
/* 108 */     metrics.add(this.q075);
/* 109 */     metrics.add(this.q100);
/* 110 */     this.chunkListMetrics = Collections.unmodifiableList(metrics);
/*     */   }
/*     */   
/*     */   private PoolSubpage<T> newSubpagePoolHead() {
/* 114 */     PoolSubpage<T> head = new PoolSubpage<T>();
/* 115 */     head.prev = head;
/* 116 */     head.next = head;
/* 117 */     return head;
/*     */   }
/*     */ 
/*     */   
/*     */   private PoolSubpage<T>[] newSubpagePoolArray(int size) {
/* 122 */     return (PoolSubpage<T>[])new PoolSubpage[size];
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   PooledByteBuf<T> allocate(PoolThreadCache cache, int reqCapacity, int maxCapacity) {
/* 128 */     PooledByteBuf<T> buf = newByteBuf(maxCapacity);
/* 129 */     allocate(cache, buf, reqCapacity);
/* 130 */     return buf;
/*     */   }
/*     */   
/*     */   private void allocate(PoolThreadCache cache, PooledByteBuf<T> buf, int reqCapacity) {
/* 134 */     int sizeIdx = size2SizeIdx(reqCapacity);
/*     */     
/* 136 */     if (sizeIdx <= this.smallMaxSizeIdx) {
/* 137 */       tcacheAllocateSmall(cache, buf, reqCapacity, sizeIdx);
/* 138 */     } else if (sizeIdx < this.nSizes) {
/* 139 */       tcacheAllocateNormal(cache, buf, reqCapacity, sizeIdx);
/*     */     } else {
/*     */       
/* 142 */       int normCapacity = (this.directMemoryCacheAlignment > 0) ? normalizeSize(reqCapacity) : reqCapacity;
/*     */       
/* 144 */       allocateHuge(buf, normCapacity);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void tcacheAllocateSmall(PoolThreadCache cache, PooledByteBuf<T> buf, int reqCapacity, int sizeIdx) {
/*     */     boolean needsNormalAllocation;
/* 151 */     if (cache.allocateSmall(this, buf, reqCapacity, sizeIdx)) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 160 */     PoolSubpage<T> head = findSubpagePoolHead(sizeIdx);
/*     */     
/* 162 */     head.lock();
/*     */     try {
/* 164 */       PoolSubpage<T> s = head.next;
/* 165 */       needsNormalAllocation = (s == head);
/* 166 */       if (!needsNormalAllocation) {
/* 167 */         assert s.doNotDestroy && s.elemSize == sizeIdx2size(sizeIdx) : "doNotDestroy=" + s.doNotDestroy + ", elemSize=" + s.elemSize + ", sizeIdx=" + sizeIdx;
/*     */         
/* 169 */         long handle = s.allocate();
/* 170 */         assert handle >= 0L;
/* 171 */         s.chunk.initBufWithSubpage(buf, null, handle, reqCapacity, cache);
/*     */       } 
/*     */     } finally {
/* 174 */       head.unlock();
/*     */     } 
/*     */     
/* 177 */     if (needsNormalAllocation) {
/* 178 */       lock();
/*     */       try {
/* 180 */         allocateNormal(buf, reqCapacity, sizeIdx, cache);
/*     */       } finally {
/* 182 */         unlock();
/*     */       } 
/*     */     } 
/*     */     
/* 186 */     incSmallAllocation();
/*     */   }
/*     */ 
/*     */   
/*     */   private void tcacheAllocateNormal(PoolThreadCache cache, PooledByteBuf<T> buf, int reqCapacity, int sizeIdx) {
/* 191 */     if (cache.allocateNormal(this, buf, reqCapacity, sizeIdx)) {
/*     */       return;
/*     */     }
/*     */     
/* 195 */     lock();
/*     */     try {
/* 197 */       allocateNormal(buf, reqCapacity, sizeIdx, cache);
/* 198 */       this.allocationsNormal++;
/*     */     } finally {
/* 200 */       unlock();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void allocateNormal(PooledByteBuf<T> buf, int reqCapacity, int sizeIdx, PoolThreadCache threadCache) {
/* 205 */     assert this.lock.isHeldByCurrentThread();
/* 206 */     if (this.q050.allocate(buf, reqCapacity, sizeIdx, threadCache) || this.q025
/* 207 */       .allocate(buf, reqCapacity, sizeIdx, threadCache) || this.q000
/* 208 */       .allocate(buf, reqCapacity, sizeIdx, threadCache) || this.qInit
/* 209 */       .allocate(buf, reqCapacity, sizeIdx, threadCache) || this.q075
/* 210 */       .allocate(buf, reqCapacity, sizeIdx, threadCache)) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 215 */     PoolChunk<T> c = newChunk(this.pageSize, this.nPSizes, this.pageShifts, this.chunkSize);
/* 216 */     boolean success = c.allocate(buf, reqCapacity, sizeIdx, threadCache);
/* 217 */     assert success;
/* 218 */     this.qInit.add(c);
/*     */   }
/*     */   
/*     */   private void incSmallAllocation() {
/* 222 */     this.allocationsSmall.increment();
/*     */   }
/*     */   
/*     */   private void allocateHuge(PooledByteBuf<T> buf, int reqCapacity) {
/* 226 */     PoolChunk<T> chunk = newUnpooledChunk(reqCapacity);
/* 227 */     this.activeBytesHuge.add(chunk.chunkSize());
/* 228 */     buf.initUnpooled(chunk, reqCapacity);
/* 229 */     this.allocationsHuge.increment();
/*     */   }
/*     */   
/*     */   void free(PoolChunk<T> chunk, ByteBuffer nioBuffer, long handle, int normCapacity, PoolThreadCache cache) {
/* 233 */     if (chunk.unpooled) {
/* 234 */       int size = chunk.chunkSize();
/* 235 */       destroyChunk(chunk);
/* 236 */       this.activeBytesHuge.add(-size);
/* 237 */       this.deallocationsHuge.increment();
/*     */     } else {
/* 239 */       SizeClass sizeClass = sizeClass(handle);
/* 240 */       if (cache != null && cache.add(this, chunk, nioBuffer, handle, normCapacity, sizeClass)) {
/*     */         return;
/*     */       }
/*     */ 
/*     */       
/* 245 */       freeChunk(chunk, handle, normCapacity, sizeClass, nioBuffer, false);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static SizeClass sizeClass(long handle) {
/* 250 */     return PoolChunk.isSubpage(handle) ? SizeClass.Small : SizeClass.Normal;
/*     */   }
/*     */ 
/*     */   
/*     */   void freeChunk(PoolChunk<T> chunk, long handle, int normCapacity, SizeClass sizeClass, ByteBuffer nioBuffer, boolean finalizer) {
/*     */     boolean destroyChunk;
/* 256 */     lock();
/*     */ 
/*     */     
/*     */     try {
/* 260 */       if (!finalizer) {
/* 261 */         switch (sizeClass) {
/*     */           case Normal:
/* 263 */             this.deallocationsNormal++;
/*     */             break;
/*     */           case Small:
/* 266 */             this.deallocationsSmall++;
/*     */             break;
/*     */           default:
/* 269 */             throw new Error();
/*     */         } 
/*     */       }
/* 272 */       destroyChunk = !chunk.parent.free(chunk, handle, normCapacity, nioBuffer);
/*     */     } finally {
/* 274 */       unlock();
/*     */     } 
/* 276 */     if (destroyChunk)
/*     */     {
/* 278 */       destroyChunk(chunk);
/*     */     }
/*     */   }
/*     */   
/*     */   PoolSubpage<T> findSubpagePoolHead(int sizeIdx) {
/* 283 */     return this.smallSubpagePools[sizeIdx];
/*     */   }
/*     */   void reallocate(PooledByteBuf<T> buf, int newCapacity, boolean freeOldMemory) {
/*     */     int bytesToCopy;
/* 287 */     assert newCapacity >= 0 && newCapacity <= buf.maxCapacity();
/*     */     
/* 289 */     int oldCapacity = buf.length;
/* 290 */     if (oldCapacity == newCapacity) {
/*     */       return;
/*     */     }
/*     */     
/* 294 */     PoolChunk<T> oldChunk = buf.chunk;
/* 295 */     ByteBuffer oldNioBuffer = buf.tmpNioBuf;
/* 296 */     long oldHandle = buf.handle;
/* 297 */     T oldMemory = buf.memory;
/* 298 */     int oldOffset = buf.offset;
/* 299 */     int oldMaxLength = buf.maxLength;
/*     */ 
/*     */     
/* 302 */     allocate(this.parent.threadCache(), buf, newCapacity);
/*     */     
/* 304 */     if (newCapacity > oldCapacity) {
/* 305 */       bytesToCopy = oldCapacity;
/*     */     } else {
/* 307 */       buf.trimIndicesToCapacity(newCapacity);
/* 308 */       bytesToCopy = newCapacity;
/*     */     } 
/* 310 */     memoryCopy(oldMemory, oldOffset, buf, bytesToCopy);
/* 311 */     if (freeOldMemory) {
/* 312 */       free(oldChunk, oldNioBuffer, oldHandle, oldMaxLength, buf.cache);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public int numThreadCaches() {
/* 318 */     return this.numThreadCaches.get();
/*     */   }
/*     */ 
/*     */   
/*     */   public int numTinySubpages() {
/* 323 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public int numSmallSubpages() {
/* 328 */     return this.smallSubpagePools.length;
/*     */   }
/*     */ 
/*     */   
/*     */   public int numChunkLists() {
/* 333 */     return this.chunkListMetrics.size();
/*     */   }
/*     */ 
/*     */   
/*     */   public List<PoolSubpageMetric> tinySubpages() {
/* 338 */     return Collections.emptyList();
/*     */   }
/*     */ 
/*     */   
/*     */   public List<PoolSubpageMetric> smallSubpages() {
/* 343 */     return subPageMetricList((PoolSubpage<?>[])this.smallSubpagePools);
/*     */   }
/*     */ 
/*     */   
/*     */   public List<PoolChunkListMetric> chunkLists() {
/* 348 */     return this.chunkListMetrics;
/*     */   }
/*     */   
/*     */   private static List<PoolSubpageMetric> subPageMetricList(PoolSubpage<?>[] pages) {
/* 352 */     List<PoolSubpageMetric> metrics = new ArrayList<PoolSubpageMetric>();
/* 353 */     for (PoolSubpage<?> head : pages) {
/* 354 */       if (head.next != head) {
/*     */ 
/*     */         
/* 357 */         PoolSubpage<?> s = head.next;
/*     */         do {
/* 359 */           metrics.add(s);
/* 360 */           s = s.next;
/* 361 */         } while (s != head);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 366 */     return metrics;
/*     */   }
/*     */ 
/*     */   
/*     */   public long numAllocations() {
/*     */     long allocsNormal;
/* 372 */     lock();
/*     */     try {
/* 374 */       allocsNormal = this.allocationsNormal;
/*     */     } finally {
/* 376 */       unlock();
/*     */     } 
/* 378 */     return this.allocationsSmall.value() + allocsNormal + this.allocationsHuge.value();
/*     */   }
/*     */ 
/*     */   
/*     */   public long numTinyAllocations() {
/* 383 */     return 0L;
/*     */   }
/*     */ 
/*     */   
/*     */   public long numSmallAllocations() {
/* 388 */     return this.allocationsSmall.value();
/*     */   }
/*     */ 
/*     */   
/*     */   public long numNormalAllocations() {
/* 393 */     lock();
/*     */     try {
/* 395 */       return this.allocationsNormal;
/*     */     } finally {
/* 397 */       unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public long numDeallocations() {
/*     */     long deallocs;
/* 404 */     lock();
/*     */     try {
/* 406 */       deallocs = this.deallocationsSmall + this.deallocationsNormal;
/*     */     } finally {
/* 408 */       unlock();
/*     */     } 
/* 410 */     return deallocs + this.deallocationsHuge.value();
/*     */   }
/*     */ 
/*     */   
/*     */   public long numTinyDeallocations() {
/* 415 */     return 0L;
/*     */   }
/*     */ 
/*     */   
/*     */   public long numSmallDeallocations() {
/* 420 */     lock();
/*     */     try {
/* 422 */       return this.deallocationsSmall;
/*     */     } finally {
/* 424 */       unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public long numNormalDeallocations() {
/* 430 */     lock();
/*     */     try {
/* 432 */       return this.deallocationsNormal;
/*     */     } finally {
/* 434 */       unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public long numHugeAllocations() {
/* 440 */     return this.allocationsHuge.value();
/*     */   }
/*     */ 
/*     */   
/*     */   public long numHugeDeallocations() {
/* 445 */     return this.deallocationsHuge.value();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long numActiveAllocations() {
/* 451 */     long val = this.allocationsSmall.value() + this.allocationsHuge.value() - this.deallocationsHuge.value();
/* 452 */     lock();
/*     */     try {
/* 454 */       val += this.allocationsNormal - this.deallocationsSmall + this.deallocationsNormal;
/*     */     } finally {
/* 456 */       unlock();
/*     */     } 
/* 458 */     return Math.max(val, 0L);
/*     */   }
/*     */ 
/*     */   
/*     */   public long numActiveTinyAllocations() {
/* 463 */     return 0L;
/*     */   }
/*     */ 
/*     */   
/*     */   public long numActiveSmallAllocations() {
/* 468 */     return Math.max(numSmallAllocations() - numSmallDeallocations(), 0L);
/*     */   }
/*     */ 
/*     */   
/*     */   public long numActiveNormalAllocations() {
/*     */     long val;
/* 474 */     lock();
/*     */     try {
/* 476 */       val = this.allocationsNormal - this.deallocationsNormal;
/*     */     } finally {
/* 478 */       unlock();
/*     */     } 
/* 480 */     return Math.max(val, 0L);
/*     */   }
/*     */ 
/*     */   
/*     */   public long numActiveHugeAllocations() {
/* 485 */     return Math.max(numHugeAllocations() - numHugeDeallocations(), 0L);
/*     */   }
/*     */ 
/*     */   
/*     */   public long numActiveBytes() {
/* 490 */     long val = this.activeBytesHuge.value();
/* 491 */     lock();
/*     */     try {
/* 493 */       for (int i = 0; i < this.chunkListMetrics.size(); i++) {
/* 494 */         for (PoolChunkMetric m : this.chunkListMetrics.get(i)) {
/* 495 */           val += m.chunkSize();
/*     */         }
/*     */       } 
/*     */     } finally {
/* 499 */       unlock();
/*     */     } 
/* 501 */     return Math.max(0L, val);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long numPinnedBytes() {
/* 509 */     long val = this.activeBytesHuge.value();
/* 510 */     lock();
/*     */     try {
/* 512 */       for (int i = 0; i < this.chunkListMetrics.size(); i++) {
/* 513 */         for (PoolChunkMetric m : this.chunkListMetrics.get(i)) {
/* 514 */           val += ((PoolChunk)m).pinnedBytes();
/*     */         }
/*     */       } 
/*     */     } finally {
/* 518 */       unlock();
/*     */     } 
/* 520 */     return Math.max(0L, val);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 531 */     lock();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 558 */       StringBuilder buf = (new StringBuilder()).append("Chunk(s) at 0~25%:").append(StringUtil.NEWLINE).append(this.qInit).append(StringUtil.NEWLINE).append("Chunk(s) at 0~50%:").append(StringUtil.NEWLINE).append(this.q000).append(StringUtil.NEWLINE).append("Chunk(s) at 25~75%:").append(StringUtil.NEWLINE).append(this.q025).append(StringUtil.NEWLINE).append("Chunk(s) at 50~100%:").append(StringUtil.NEWLINE).append(this.q050).append(StringUtil.NEWLINE).append("Chunk(s) at 75~100%:").append(StringUtil.NEWLINE).append(this.q075).append(StringUtil.NEWLINE).append("Chunk(s) at 100%:").append(StringUtil.NEWLINE).append(this.q100).append(StringUtil.NEWLINE).append("small subpages:");
/* 559 */       appendPoolSubPages(buf, (PoolSubpage<?>[])this.smallSubpagePools);
/* 560 */       buf.append(StringUtil.NEWLINE);
/* 561 */       return buf.toString();
/*     */     } finally {
/* 563 */       unlock();
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void appendPoolSubPages(StringBuilder buf, PoolSubpage<?>[] subpages) {
/* 568 */     for (int i = 0; i < subpages.length; i++) {
/* 569 */       PoolSubpage<?> head = subpages[i];
/* 570 */       if (head.next != head && head.next != null) {
/*     */ 
/*     */ 
/*     */         
/* 574 */         buf.append(StringUtil.NEWLINE)
/* 575 */           .append(i)
/* 576 */           .append(": ");
/* 577 */         PoolSubpage<?> s = head.next;
/* 578 */         while (s != null) {
/* 579 */           buf.append(s);
/* 580 */           s = s.next;
/* 581 */           if (s == head) {
/*     */             break;
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   protected final void finalize() throws Throwable {
/*     */     try {
/* 591 */       super.finalize();
/*     */     } finally {
/* 593 */       destroyPoolSubPages((PoolSubpage<?>[])this.smallSubpagePools);
/* 594 */       destroyPoolChunkLists((PoolChunkList<T>[])new PoolChunkList[] { this.qInit, this.q000, this.q025, this.q050, this.q075, this.q100 });
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void destroyPoolSubPages(PoolSubpage<?>[] pages) {
/* 599 */     for (PoolSubpage<?> page : pages) {
/* 600 */       page.destroy();
/*     */     }
/*     */   }
/*     */   
/*     */   private void destroyPoolChunkLists(PoolChunkList<T>... chunkLists) {
/* 605 */     for (PoolChunkList<T> chunkList : chunkLists) {
/* 606 */       chunkList.destroy(this);
/*     */     }
/*     */   }
/*     */   
/*     */   static final class HeapArena
/*     */     extends PoolArena<byte[]>
/*     */   {
/*     */     HeapArena(PooledByteBufAllocator parent, int pageSize, int pageShifts, int chunkSize) {
/* 614 */       super(parent, pageSize, pageShifts, chunkSize, 0);
/*     */     }
/*     */ 
/*     */     
/*     */     private static byte[] newByteArray(int size) {
/* 619 */       return PlatformDependent.allocateUninitializedArray(size);
/*     */     }
/*     */ 
/*     */     
/*     */     boolean isDirect() {
/* 624 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     protected PoolChunk<byte[]> newChunk(int pageSize, int maxPageIdx, int pageShifts, int chunkSize) {
/* 629 */       return (PoolChunk)new PoolChunk<byte>(this, null, 
/* 630 */           newByteArray(chunkSize), pageSize, pageShifts, chunkSize, maxPageIdx);
/*     */     }
/*     */ 
/*     */     
/*     */     protected PoolChunk<byte[]> newUnpooledChunk(int capacity) {
/* 635 */       return (PoolChunk)new PoolChunk<byte>(this, null, newByteArray(capacity), capacity);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     protected void destroyChunk(PoolChunk<byte[]> chunk) {}
/*     */ 
/*     */ 
/*     */     
/*     */     protected PooledByteBuf<byte[]> newByteBuf(int maxCapacity) {
/* 645 */       return PoolArena.HAS_UNSAFE ? PooledUnsafeHeapByteBuf.newUnsafeInstance(maxCapacity) : 
/* 646 */         PooledHeapByteBuf.newInstance(maxCapacity);
/*     */     }
/*     */ 
/*     */     
/*     */     protected void memoryCopy(byte[] src, int srcOffset, PooledByteBuf<byte[]> dst, int length) {
/* 651 */       if (length == 0) {
/*     */         return;
/*     */       }
/*     */       
/* 655 */       System.arraycopy(src, srcOffset, dst.memory, dst.offset, length);
/*     */     }
/*     */   }
/*     */   
/*     */   static final class DirectArena
/*     */     extends PoolArena<ByteBuffer>
/*     */   {
/*     */     DirectArena(PooledByteBufAllocator parent, int pageSize, int pageShifts, int chunkSize, int directMemoryCacheAlignment) {
/* 663 */       super(parent, pageSize, pageShifts, chunkSize, directMemoryCacheAlignment);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     boolean isDirect() {
/* 669 */       return true;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     protected PoolChunk<ByteBuffer> newChunk(int pageSize, int maxPageIdx, int pageShifts, int chunkSize) {
/* 675 */       if (this.directMemoryCacheAlignment == 0) {
/* 676 */         ByteBuffer byteBuffer = allocateDirect(chunkSize);
/* 677 */         return new PoolChunk<ByteBuffer>(this, byteBuffer, byteBuffer, pageSize, pageShifts, chunkSize, maxPageIdx);
/*     */       } 
/*     */ 
/*     */       
/* 681 */       ByteBuffer base = allocateDirect(chunkSize + this.directMemoryCacheAlignment);
/* 682 */       ByteBuffer memory = PlatformDependent.alignDirectBuffer(base, this.directMemoryCacheAlignment);
/* 683 */       return new PoolChunk<ByteBuffer>(this, base, memory, pageSize, pageShifts, chunkSize, maxPageIdx);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     protected PoolChunk<ByteBuffer> newUnpooledChunk(int capacity) {
/* 689 */       if (this.directMemoryCacheAlignment == 0) {
/* 690 */         ByteBuffer byteBuffer = allocateDirect(capacity);
/* 691 */         return new PoolChunk<ByteBuffer>(this, byteBuffer, byteBuffer, capacity);
/*     */       } 
/*     */       
/* 694 */       ByteBuffer base = allocateDirect(capacity + this.directMemoryCacheAlignment);
/* 695 */       ByteBuffer memory = PlatformDependent.alignDirectBuffer(base, this.directMemoryCacheAlignment);
/* 696 */       return new PoolChunk<ByteBuffer>(this, base, memory, capacity);
/*     */     }
/*     */     
/*     */     private static ByteBuffer allocateDirect(int capacity) {
/* 700 */       return PlatformDependent.useDirectBufferNoCleaner() ? 
/* 701 */         PlatformDependent.allocateDirectNoCleaner(capacity) : ByteBuffer.allocateDirect(capacity);
/*     */     }
/*     */ 
/*     */     
/*     */     protected void destroyChunk(PoolChunk<ByteBuffer> chunk) {
/* 706 */       if (PlatformDependent.useDirectBufferNoCleaner()) {
/* 707 */         PlatformDependent.freeDirectNoCleaner((ByteBuffer)chunk.base);
/*     */       } else {
/* 709 */         PlatformDependent.freeDirectBuffer((ByteBuffer)chunk.base);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     protected PooledByteBuf<ByteBuffer> newByteBuf(int maxCapacity) {
/* 715 */       if (PoolArena.HAS_UNSAFE) {
/* 716 */         return PooledUnsafeDirectByteBuf.newInstance(maxCapacity);
/*     */       }
/* 718 */       return PooledDirectByteBuf.newInstance(maxCapacity);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     protected void memoryCopy(ByteBuffer src, int srcOffset, PooledByteBuf<ByteBuffer> dstBuf, int length) {
/* 724 */       if (length == 0) {
/*     */         return;
/*     */       }
/*     */       
/* 728 */       if (PoolArena.HAS_UNSAFE) {
/* 729 */         PlatformDependent.copyMemory(
/* 730 */             PlatformDependent.directBufferAddress(src) + srcOffset, 
/* 731 */             PlatformDependent.directBufferAddress((ByteBuffer)dstBuf.memory) + dstBuf.offset, length);
/*     */       } else {
/*     */         
/* 734 */         src = src.duplicate();
/* 735 */         ByteBuffer dst = dstBuf.internalNioBuffer();
/* 736 */         src.position(srcOffset).limit(srcOffset + length);
/* 737 */         dst.position(dstBuf.offset);
/* 738 */         dst.put(src);
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   void lock() {
/* 744 */     this.lock.lock();
/*     */   }
/*     */   
/*     */   void unlock() {
/* 748 */     this.lock.unlock();
/*     */   }
/*     */   
/*     */   abstract boolean isDirect();
/*     */   
/*     */   protected abstract PoolChunk<T> newChunk(int paramInt1, int paramInt2, int paramInt3, int paramInt4);
/*     */   
/*     */   protected abstract PoolChunk<T> newUnpooledChunk(int paramInt);
/*     */   
/*     */   protected abstract PooledByteBuf<T> newByteBuf(int paramInt);
/*     */   
/*     */   protected abstract void memoryCopy(T paramT, int paramInt1, PooledByteBuf<T> paramPooledByteBuf, int paramInt2);
/*     */   
/*     */   protected abstract void destroyChunk(PoolChunk<T> paramPoolChunk);
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-buffer-4.1.93.Final.jar!\io\netty\buffer\PoolArena.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */