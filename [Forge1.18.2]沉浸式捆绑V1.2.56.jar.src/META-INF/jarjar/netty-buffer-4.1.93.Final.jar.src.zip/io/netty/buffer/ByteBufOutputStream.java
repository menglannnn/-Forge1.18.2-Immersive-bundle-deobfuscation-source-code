/*     */ package io.netty.buffer;
/*     */ 
/*     */ import io.netty.util.CharsetUtil;
/*     */ import io.netty.util.internal.ObjectUtil;
/*     */ import java.io.DataOutput;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ByteBufOutputStream
/*     */   extends OutputStream
/*     */   implements DataOutput
/*     */ {
/*     */   private final ByteBuf buffer;
/*     */   private final int startIndex;
/*     */   private DataOutputStream utf8out;
/*     */   private boolean closed;
/*     */   
/*     */   public ByteBufOutputStream(ByteBuf buffer) {
/*  50 */     this.buffer = (ByteBuf)ObjectUtil.checkNotNull(buffer, "buffer");
/*  51 */     this.startIndex = buffer.writerIndex();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int writtenBytes() {
/*  58 */     return this.buffer.writerIndex() - this.startIndex;
/*     */   }
/*     */ 
/*     */   
/*     */   public void write(byte[] b, int off, int len) throws IOException {
/*  63 */     if (len == 0) {
/*     */       return;
/*     */     }
/*     */     
/*  67 */     this.buffer.writeBytes(b, off, len);
/*     */   }
/*     */ 
/*     */   
/*     */   public void write(byte[] b) throws IOException {
/*  72 */     this.buffer.writeBytes(b);
/*     */   }
/*     */ 
/*     */   
/*     */   public void write(int b) throws IOException {
/*  77 */     this.buffer.writeByte(b);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeBoolean(boolean v) throws IOException {
/*  82 */     this.buffer.writeBoolean(v);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeByte(int v) throws IOException {
/*  87 */     this.buffer.writeByte(v);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeBytes(String s) throws IOException {
/*  92 */     this.buffer.writeCharSequence(s, CharsetUtil.US_ASCII);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeChar(int v) throws IOException {
/*  97 */     this.buffer.writeChar(v);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeChars(String s) throws IOException {
/* 102 */     int len = s.length();
/* 103 */     for (int i = 0; i < len; i++) {
/* 104 */       this.buffer.writeChar(s.charAt(i));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeDouble(double v) throws IOException {
/* 110 */     this.buffer.writeDouble(v);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeFloat(float v) throws IOException {
/* 115 */     this.buffer.writeFloat(v);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeInt(int v) throws IOException {
/* 120 */     this.buffer.writeInt(v);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeLong(long v) throws IOException {
/* 125 */     this.buffer.writeLong(v);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeShort(int v) throws IOException {
/* 130 */     this.buffer.writeShort((short)v);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeUTF(String s) throws IOException {
/* 135 */     DataOutputStream out = this.utf8out;
/* 136 */     if (out == null) {
/* 137 */       if (this.closed) {
/* 138 */         throw new IOException("The stream is closed");
/*     */       }
/*     */       
/* 141 */       this.utf8out = out = new DataOutputStream(this);
/*     */     } 
/* 143 */     out.writeUTF(s);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ByteBuf buffer() {
/* 150 */     return this.buffer;
/*     */   }
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/* 155 */     if (this.closed) {
/*     */       return;
/*     */     }
/* 158 */     this.closed = true;
/*     */     
/*     */     try {
/* 161 */       super.close();
/*     */     } finally {
/* 163 */       if (this.utf8out != null)
/* 164 */         this.utf8out.close(); 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-buffer-4.1.93.Final.jar!\io\netty\buffer\ByteBufOutputStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */