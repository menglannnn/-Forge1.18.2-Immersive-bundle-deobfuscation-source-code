/*     */ package io.netty.buffer;
/*     */ 
/*     */ import io.netty.util.ReferenceCounted;
/*     */ import io.netty.util.internal.ReferenceCountUpdater;
/*     */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractReferenceCountedByteBuf
/*     */   extends AbstractByteBuf
/*     */ {
/*  28 */   private static final long REFCNT_FIELD_OFFSET = ReferenceCountUpdater.getUnsafeOffset(AbstractReferenceCountedByteBuf.class, "refCnt");
/*     */   
/*  30 */   private static final AtomicIntegerFieldUpdater<AbstractReferenceCountedByteBuf> AIF_UPDATER = AtomicIntegerFieldUpdater.newUpdater(AbstractReferenceCountedByteBuf.class, "refCnt");
/*     */   
/*  32 */   private static final ReferenceCountUpdater<AbstractReferenceCountedByteBuf> updater = new ReferenceCountUpdater<AbstractReferenceCountedByteBuf>()
/*     */     {
/*     */       protected AtomicIntegerFieldUpdater<AbstractReferenceCountedByteBuf> updater()
/*     */       {
/*  36 */         return AbstractReferenceCountedByteBuf.AIF_UPDATER;
/*     */       }
/*     */       
/*     */       protected long unsafeOffset() {
/*  40 */         return AbstractReferenceCountedByteBuf.REFCNT_FIELD_OFFSET;
/*     */       }
/*     */     };
/*     */ 
/*     */   
/*     */   private volatile int refCnt;
/*     */ 
/*     */   
/*     */   protected AbstractReferenceCountedByteBuf(int maxCapacity) {
/*  49 */     super(maxCapacity);
/*  50 */     updater.setInitialValue(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isAccessible() {
/*  57 */     return updater.isLiveNonVolatile(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public int refCnt() {
/*  62 */     return updater.refCnt(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void setRefCnt(int refCnt) {
/*  69 */     updater.setRefCnt(this, refCnt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void resetRefCnt() {
/*  76 */     updater.resetRefCnt(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public ByteBuf retain() {
/*  81 */     return (ByteBuf)updater.retain(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public ByteBuf retain(int increment) {
/*  86 */     return (ByteBuf)updater.retain(this, increment);
/*     */   }
/*     */ 
/*     */   
/*     */   public ByteBuf touch() {
/*  91 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public ByteBuf touch(Object hint) {
/*  96 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean release() {
/* 101 */     return handleRelease(updater.release(this));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean release(int decrement) {
/* 106 */     return handleRelease(updater.release(this, decrement));
/*     */   }
/*     */   
/*     */   private boolean handleRelease(boolean result) {
/* 110 */     if (result) {
/* 111 */       deallocate();
/*     */     }
/* 113 */     return result;
/*     */   }
/*     */   
/*     */   protected abstract void deallocate();
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-buffer-4.1.93.Final.jar!\io\netty\buffer\AbstractReferenceCountedByteBuf.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */