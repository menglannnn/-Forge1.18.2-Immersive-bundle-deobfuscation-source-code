package io.netty.buffer;

public interface SizeClassesMetric {
  int sizeIdx2size(int paramInt);
  
  int sizeIdx2sizeCompute(int paramInt);
  
  long pageIdx2size(int paramInt);
  
  long pageIdx2sizeCompute(int paramInt);
  
  int size2SizeIdx(int paramInt);
  
  int pages2pageIdx(int paramInt);
  
  int pages2pageIdxFloor(int paramInt);
  
  int normalizeSize(int paramInt);
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-buffer-4.1.93.Final.jar!\io\netty\buffer\SizeClassesMetric.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */