/*     */ package io.netty.buffer;
/*     */ 
/*     */ import io.netty.util.NettyRuntime;
/*     */ import io.netty.util.concurrent.EventExecutor;
/*     */ import io.netty.util.concurrent.FastThreadLocal;
/*     */ import io.netty.util.internal.ObjectUtil;
/*     */ import io.netty.util.internal.PlatformDependent;
/*     */ import io.netty.util.internal.StringUtil;
/*     */ import io.netty.util.internal.SystemPropertyUtil;
/*     */ import io.netty.util.internal.ThreadExecutorMap;
/*     */ import io.netty.util.internal.logging.InternalLogger;
/*     */ import io.netty.util.internal.logging.InternalLoggerFactory;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PooledByteBufAllocator
/*     */   extends AbstractByteBufAllocator
/*     */   implements ByteBufAllocatorMetricProvider
/*     */ {
/*  40 */   private static final InternalLogger logger = InternalLoggerFactory.getInstance(PooledByteBufAllocator.class);
/*     */   
/*     */   private static final int DEFAULT_NUM_HEAP_ARENA;
/*     */   
/*     */   private static final int DEFAULT_NUM_DIRECT_ARENA;
/*     */   
/*     */   private static final int DEFAULT_PAGE_SIZE;
/*     */   private static final int DEFAULT_MAX_ORDER;
/*     */   private static final int DEFAULT_SMALL_CACHE_SIZE;
/*     */   private static final int DEFAULT_NORMAL_CACHE_SIZE;
/*     */   static final int DEFAULT_MAX_CACHED_BUFFER_CAPACITY;
/*     */   private static final int DEFAULT_CACHE_TRIM_INTERVAL;
/*     */   private static final long DEFAULT_CACHE_TRIM_INTERVAL_MILLIS;
/*     */   private static final boolean DEFAULT_USE_CACHE_FOR_ALL_THREADS;
/*     */   private static final int DEFAULT_DIRECT_MEMORY_CACHE_ALIGNMENT;
/*     */   static final int DEFAULT_MAX_CACHED_BYTEBUFFERS_PER_CHUNK;
/*     */   private static final int MIN_PAGE_SIZE = 4096;
/*     */   private static final int MAX_CHUNK_SIZE = 1073741824;
/*     */   private static final int CACHE_NOT_USED = 0;
/*     */   
/*  60 */   private final Runnable trimTask = new Runnable()
/*     */     {
/*     */       public void run() {
/*  63 */         PooledByteBufAllocator.this.trimCurrentThreadCache();
/*     */       }
/*     */     };
/*     */   public static final PooledByteBufAllocator DEFAULT;
/*     */   static {
/*  68 */     int defaultAlignment = SystemPropertyUtil.getInt("io.netty.allocator.directMemoryCacheAlignment", 0);
/*     */     
/*  70 */     int defaultPageSize = SystemPropertyUtil.getInt("io.netty.allocator.pageSize", 8192);
/*  71 */     Throwable pageSizeFallbackCause = null;
/*     */     try {
/*  73 */       validateAndCalculatePageShifts(defaultPageSize, defaultAlignment);
/*  74 */     } catch (Throwable t) {
/*  75 */       pageSizeFallbackCause = t;
/*  76 */       defaultPageSize = 8192;
/*  77 */       defaultAlignment = 0;
/*     */     } 
/*  79 */     DEFAULT_PAGE_SIZE = defaultPageSize;
/*  80 */     DEFAULT_DIRECT_MEMORY_CACHE_ALIGNMENT = defaultAlignment;
/*     */     
/*  82 */     int defaultMaxOrder = SystemPropertyUtil.getInt("io.netty.allocator.maxOrder", 9);
/*  83 */     Throwable maxOrderFallbackCause = null;
/*     */     try {
/*  85 */       validateAndCalculateChunkSize(DEFAULT_PAGE_SIZE, defaultMaxOrder);
/*  86 */     } catch (Throwable t) {
/*  87 */       maxOrderFallbackCause = t;
/*  88 */       defaultMaxOrder = 9;
/*     */     } 
/*  90 */     DEFAULT_MAX_ORDER = defaultMaxOrder;
/*     */ 
/*     */ 
/*     */     
/*  94 */     Runtime runtime = Runtime.getRuntime();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 103 */     int defaultMinNumArena = NettyRuntime.availableProcessors() * 2;
/* 104 */     int defaultChunkSize = DEFAULT_PAGE_SIZE << DEFAULT_MAX_ORDER;
/* 105 */     DEFAULT_NUM_HEAP_ARENA = Math.max(0, 
/* 106 */         SystemPropertyUtil.getInt("io.netty.allocator.numHeapArenas", 
/*     */           
/* 108 */           (int)Math.min(defaultMinNumArena, runtime
/*     */             
/* 110 */             .maxMemory() / defaultChunkSize / 2L / 3L)));
/* 111 */     DEFAULT_NUM_DIRECT_ARENA = Math.max(0, 
/* 112 */         SystemPropertyUtil.getInt("io.netty.allocator.numDirectArenas", 
/*     */           
/* 114 */           (int)Math.min(defaultMinNumArena, 
/*     */             
/* 116 */             PlatformDependent.maxDirectMemory() / defaultChunkSize / 2L / 3L)));
/*     */ 
/*     */     
/* 119 */     DEFAULT_SMALL_CACHE_SIZE = SystemPropertyUtil.getInt("io.netty.allocator.smallCacheSize", 256);
/* 120 */     DEFAULT_NORMAL_CACHE_SIZE = SystemPropertyUtil.getInt("io.netty.allocator.normalCacheSize", 64);
/*     */ 
/*     */ 
/*     */     
/* 124 */     DEFAULT_MAX_CACHED_BUFFER_CAPACITY = SystemPropertyUtil.getInt("io.netty.allocator.maxCachedBufferCapacity", 32768);
/*     */ 
/*     */ 
/*     */     
/* 128 */     DEFAULT_CACHE_TRIM_INTERVAL = SystemPropertyUtil.getInt("io.netty.allocator.cacheTrimInterval", 8192);
/*     */ 
/*     */     
/* 131 */     if (SystemPropertyUtil.contains("io.netty.allocation.cacheTrimIntervalMillis")) {
/* 132 */       logger.warn("-Dio.netty.allocation.cacheTrimIntervalMillis is deprecated, use -Dio.netty.allocator.cacheTrimIntervalMillis");
/*     */ 
/*     */       
/* 135 */       if (SystemPropertyUtil.contains("io.netty.allocator.cacheTrimIntervalMillis")) {
/*     */         
/* 137 */         DEFAULT_CACHE_TRIM_INTERVAL_MILLIS = SystemPropertyUtil.getLong("io.netty.allocator.cacheTrimIntervalMillis", 0L);
/*     */       } else {
/*     */         
/* 140 */         DEFAULT_CACHE_TRIM_INTERVAL_MILLIS = SystemPropertyUtil.getLong("io.netty.allocation.cacheTrimIntervalMillis", 0L);
/*     */       } 
/*     */     } else {
/*     */       
/* 144 */       DEFAULT_CACHE_TRIM_INTERVAL_MILLIS = SystemPropertyUtil.getLong("io.netty.allocator.cacheTrimIntervalMillis", 0L);
/*     */     } 
/*     */ 
/*     */     
/* 148 */     DEFAULT_USE_CACHE_FOR_ALL_THREADS = SystemPropertyUtil.getBoolean("io.netty.allocator.useCacheForAllThreads", false);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 153 */     DEFAULT_MAX_CACHED_BYTEBUFFERS_PER_CHUNK = SystemPropertyUtil.getInt("io.netty.allocator.maxCachedByteBuffersPerChunk", 1023);
/*     */ 
/*     */     
/* 156 */     if (logger.isDebugEnabled()) {
/* 157 */       logger.debug("-Dio.netty.allocator.numHeapArenas: {}", Integer.valueOf(DEFAULT_NUM_HEAP_ARENA));
/* 158 */       logger.debug("-Dio.netty.allocator.numDirectArenas: {}", Integer.valueOf(DEFAULT_NUM_DIRECT_ARENA));
/* 159 */       if (pageSizeFallbackCause == null) {
/* 160 */         logger.debug("-Dio.netty.allocator.pageSize: {}", Integer.valueOf(DEFAULT_PAGE_SIZE));
/*     */       } else {
/* 162 */         logger.debug("-Dio.netty.allocator.pageSize: {}", Integer.valueOf(DEFAULT_PAGE_SIZE), pageSizeFallbackCause);
/*     */       } 
/* 164 */       if (maxOrderFallbackCause == null) {
/* 165 */         logger.debug("-Dio.netty.allocator.maxOrder: {}", Integer.valueOf(DEFAULT_MAX_ORDER));
/*     */       } else {
/* 167 */         logger.debug("-Dio.netty.allocator.maxOrder: {}", Integer.valueOf(DEFAULT_MAX_ORDER), maxOrderFallbackCause);
/*     */       } 
/* 169 */       logger.debug("-Dio.netty.allocator.chunkSize: {}", Integer.valueOf(DEFAULT_PAGE_SIZE << DEFAULT_MAX_ORDER));
/* 170 */       logger.debug("-Dio.netty.allocator.smallCacheSize: {}", Integer.valueOf(DEFAULT_SMALL_CACHE_SIZE));
/* 171 */       logger.debug("-Dio.netty.allocator.normalCacheSize: {}", Integer.valueOf(DEFAULT_NORMAL_CACHE_SIZE));
/* 172 */       logger.debug("-Dio.netty.allocator.maxCachedBufferCapacity: {}", Integer.valueOf(DEFAULT_MAX_CACHED_BUFFER_CAPACITY));
/* 173 */       logger.debug("-Dio.netty.allocator.cacheTrimInterval: {}", Integer.valueOf(DEFAULT_CACHE_TRIM_INTERVAL));
/* 174 */       logger.debug("-Dio.netty.allocator.cacheTrimIntervalMillis: {}", Long.valueOf(DEFAULT_CACHE_TRIM_INTERVAL_MILLIS));
/* 175 */       logger.debug("-Dio.netty.allocator.useCacheForAllThreads: {}", Boolean.valueOf(DEFAULT_USE_CACHE_FOR_ALL_THREADS));
/* 176 */       logger.debug("-Dio.netty.allocator.maxCachedByteBuffersPerChunk: {}", 
/* 177 */           Integer.valueOf(DEFAULT_MAX_CACHED_BYTEBUFFERS_PER_CHUNK));
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 182 */     DEFAULT = new PooledByteBufAllocator(PlatformDependent.directBufferPreferred());
/*     */   }
/*     */   private final PoolArena<byte[]>[] heapArenas;
/*     */   private final PoolArena<ByteBuffer>[] directArenas;
/*     */   private final int smallCacheSize;
/*     */   private final int normalCacheSize;
/*     */   private final List<PoolArenaMetric> heapArenaMetrics;
/*     */   private final List<PoolArenaMetric> directArenaMetrics;
/*     */   private final PoolThreadLocalCache threadCache;
/*     */   private final int chunkSize;
/*     */   private final PooledByteBufAllocatorMetric metric;
/*     */   
/*     */   public PooledByteBufAllocator() {
/* 195 */     this(false);
/*     */   }
/*     */ 
/*     */   
/*     */   public PooledByteBufAllocator(boolean preferDirect) {
/* 200 */     this(preferDirect, DEFAULT_NUM_HEAP_ARENA, DEFAULT_NUM_DIRECT_ARENA, DEFAULT_PAGE_SIZE, DEFAULT_MAX_ORDER);
/*     */   }
/*     */ 
/*     */   
/*     */   public PooledByteBufAllocator(int nHeapArena, int nDirectArena, int pageSize, int maxOrder) {
/* 205 */     this(false, nHeapArena, nDirectArena, pageSize, maxOrder);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public PooledByteBufAllocator(boolean preferDirect, int nHeapArena, int nDirectArena, int pageSize, int maxOrder) {
/* 214 */     this(preferDirect, nHeapArena, nDirectArena, pageSize, maxOrder, 0, DEFAULT_SMALL_CACHE_SIZE, DEFAULT_NORMAL_CACHE_SIZE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public PooledByteBufAllocator(boolean preferDirect, int nHeapArena, int nDirectArena, int pageSize, int maxOrder, int tinyCacheSize, int smallCacheSize, int normalCacheSize) {
/* 225 */     this(preferDirect, nHeapArena, nDirectArena, pageSize, maxOrder, smallCacheSize, normalCacheSize, DEFAULT_USE_CACHE_FOR_ALL_THREADS, DEFAULT_DIRECT_MEMORY_CACHE_ALIGNMENT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public PooledByteBufAllocator(boolean preferDirect, int nHeapArena, int nDirectArena, int pageSize, int maxOrder, int tinyCacheSize, int smallCacheSize, int normalCacheSize, boolean useCacheForAllThreads) {
/* 238 */     this(preferDirect, nHeapArena, nDirectArena, pageSize, maxOrder, smallCacheSize, normalCacheSize, useCacheForAllThreads);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PooledByteBufAllocator(boolean preferDirect, int nHeapArena, int nDirectArena, int pageSize, int maxOrder, int smallCacheSize, int normalCacheSize, boolean useCacheForAllThreads) {
/* 247 */     this(preferDirect, nHeapArena, nDirectArena, pageSize, maxOrder, smallCacheSize, normalCacheSize, useCacheForAllThreads, DEFAULT_DIRECT_MEMORY_CACHE_ALIGNMENT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public PooledByteBufAllocator(boolean preferDirect, int nHeapArena, int nDirectArena, int pageSize, int maxOrder, int tinyCacheSize, int smallCacheSize, int normalCacheSize, boolean useCacheForAllThreads, int directMemoryCacheAlignment) {
/* 260 */     this(preferDirect, nHeapArena, nDirectArena, pageSize, maxOrder, smallCacheSize, normalCacheSize, useCacheForAllThreads, directMemoryCacheAlignment);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PooledByteBufAllocator(boolean preferDirect, int nHeapArena, int nDirectArena, int pageSize, int maxOrder, int smallCacheSize, int normalCacheSize, boolean useCacheForAllThreads, int directMemoryCacheAlignment) {
/* 268 */     super(preferDirect);
/* 269 */     this.threadCache = new PoolThreadLocalCache(useCacheForAllThreads);
/* 270 */     this.smallCacheSize = smallCacheSize;
/* 271 */     this.normalCacheSize = normalCacheSize;
/*     */     
/* 273 */     if (directMemoryCacheAlignment != 0) {
/* 274 */       if (!PlatformDependent.hasAlignDirectByteBuffer()) {
/* 275 */         throw new UnsupportedOperationException("Buffer alignment is not supported. Either Unsafe or ByteBuffer.alignSlice() must be available.");
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 280 */       pageSize = (int)PlatformDependent.align(pageSize, directMemoryCacheAlignment);
/*     */     } 
/*     */     
/* 283 */     this.chunkSize = validateAndCalculateChunkSize(pageSize, maxOrder);
/*     */     
/* 285 */     ObjectUtil.checkPositiveOrZero(nHeapArena, "nHeapArena");
/* 286 */     ObjectUtil.checkPositiveOrZero(nDirectArena, "nDirectArena");
/*     */     
/* 288 */     ObjectUtil.checkPositiveOrZero(directMemoryCacheAlignment, "directMemoryCacheAlignment");
/* 289 */     if (directMemoryCacheAlignment > 0 && !isDirectMemoryCacheAlignmentSupported()) {
/* 290 */       throw new IllegalArgumentException("directMemoryCacheAlignment is not supported");
/*     */     }
/*     */     
/* 293 */     if ((directMemoryCacheAlignment & -directMemoryCacheAlignment) != directMemoryCacheAlignment) {
/* 294 */       throw new IllegalArgumentException("directMemoryCacheAlignment: " + directMemoryCacheAlignment + " (expected: power of two)");
/*     */     }
/*     */ 
/*     */     
/* 298 */     int pageShifts = validateAndCalculatePageShifts(pageSize, directMemoryCacheAlignment);
/*     */     
/* 300 */     if (nHeapArena > 0) {
/* 301 */       this.heapArenas = newArenaArray(nHeapArena);
/* 302 */       List<PoolArenaMetric> metrics = new ArrayList<PoolArenaMetric>(this.heapArenas.length);
/* 303 */       for (int i = 0; i < this.heapArenas.length; i++) {
/* 304 */         PoolArena.HeapArena arena = new PoolArena.HeapArena(this, pageSize, pageShifts, this.chunkSize);
/*     */         
/* 306 */         this.heapArenas[i] = arena;
/* 307 */         metrics.add(arena);
/*     */       } 
/* 309 */       this.heapArenaMetrics = Collections.unmodifiableList(metrics);
/*     */     } else {
/* 311 */       this.heapArenas = null;
/* 312 */       this.heapArenaMetrics = Collections.emptyList();
/*     */     } 
/*     */     
/* 315 */     if (nDirectArena > 0) {
/* 316 */       this.directArenas = newArenaArray(nDirectArena);
/* 317 */       List<PoolArenaMetric> metrics = new ArrayList<PoolArenaMetric>(this.directArenas.length);
/* 318 */       for (int i = 0; i < this.directArenas.length; i++) {
/* 319 */         PoolArena.DirectArena arena = new PoolArena.DirectArena(this, pageSize, pageShifts, this.chunkSize, directMemoryCacheAlignment);
/*     */         
/* 321 */         this.directArenas[i] = arena;
/* 322 */         metrics.add(arena);
/*     */       } 
/* 324 */       this.directArenaMetrics = Collections.unmodifiableList(metrics);
/*     */     } else {
/* 326 */       this.directArenas = null;
/* 327 */       this.directArenaMetrics = Collections.emptyList();
/*     */     } 
/* 329 */     this.metric = new PooledByteBufAllocatorMetric(this);
/*     */   }
/*     */ 
/*     */   
/*     */   private static <T> PoolArena<T>[] newArenaArray(int size) {
/* 334 */     return (PoolArena<T>[])new PoolArena[size];
/*     */   }
/*     */   
/*     */   private static int validateAndCalculatePageShifts(int pageSize, int alignment) {
/* 338 */     if (pageSize < 4096) {
/* 339 */       throw new IllegalArgumentException("pageSize: " + pageSize + " (expected: " + 'က' + ')');
/*     */     }
/*     */     
/* 342 */     if ((pageSize & pageSize - 1) != 0) {
/* 343 */       throw new IllegalArgumentException("pageSize: " + pageSize + " (expected: power of 2)");
/*     */     }
/*     */     
/* 346 */     if (pageSize < alignment) {
/* 347 */       throw new IllegalArgumentException("Alignment cannot be greater than page size. Alignment: " + alignment + ", page size: " + pageSize + '.');
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 352 */     return 31 - Integer.numberOfLeadingZeros(pageSize);
/*     */   }
/*     */   
/*     */   private static int validateAndCalculateChunkSize(int pageSize, int maxOrder) {
/* 356 */     if (maxOrder > 14) {
/* 357 */       throw new IllegalArgumentException("maxOrder: " + maxOrder + " (expected: 0-14)");
/*     */     }
/*     */ 
/*     */     
/* 361 */     int chunkSize = pageSize;
/* 362 */     for (int i = maxOrder; i > 0; i--) {
/* 363 */       if (chunkSize > 536870912)
/* 364 */         throw new IllegalArgumentException(String.format("pageSize (%d) << maxOrder (%d) must not exceed %d", new Object[] {
/* 365 */                 Integer.valueOf(pageSize), Integer.valueOf(maxOrder), Integer.valueOf(1073741824)
/*     */               })); 
/* 367 */       chunkSize <<= 1;
/*     */     } 
/* 369 */     return chunkSize;
/*     */   }
/*     */   
/*     */   protected ByteBuf newHeapBuffer(int initialCapacity, int maxCapacity) {
/*     */     ByteBuf buf;
/* 374 */     PoolThreadCache cache = (PoolThreadCache)this.threadCache.get();
/* 375 */     PoolArena<byte[]> heapArena = cache.heapArena;
/*     */ 
/*     */     
/* 378 */     if (heapArena != null) {
/* 379 */       buf = heapArena.allocate(cache, initialCapacity, maxCapacity);
/*     */     } else {
/* 381 */       buf = PlatformDependent.hasUnsafe() ? new UnpooledUnsafeHeapByteBuf(this, initialCapacity, maxCapacity) : new UnpooledHeapByteBuf(this, initialCapacity, maxCapacity);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 386 */     return toLeakAwareBuffer(buf);
/*     */   }
/*     */   
/*     */   protected ByteBuf newDirectBuffer(int initialCapacity, int maxCapacity) {
/*     */     ByteBuf buf;
/* 391 */     PoolThreadCache cache = (PoolThreadCache)this.threadCache.get();
/* 392 */     PoolArena<ByteBuffer> directArena = cache.directArena;
/*     */ 
/*     */     
/* 395 */     if (directArena != null) {
/* 396 */       buf = directArena.allocate(cache, initialCapacity, maxCapacity);
/*     */     } else {
/*     */       
/* 399 */       buf = PlatformDependent.hasUnsafe() ? UnsafeByteBufUtil.newUnsafeDirectByteBuf(this, initialCapacity, maxCapacity) : new UnpooledDirectByteBuf(this, initialCapacity, maxCapacity);
/*     */     } 
/*     */ 
/*     */     
/* 403 */     return toLeakAwareBuffer(buf);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int defaultNumHeapArena() {
/* 410 */     return DEFAULT_NUM_HEAP_ARENA;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int defaultNumDirectArena() {
/* 417 */     return DEFAULT_NUM_DIRECT_ARENA;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int defaultPageSize() {
/* 424 */     return DEFAULT_PAGE_SIZE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int defaultMaxOrder() {
/* 431 */     return DEFAULT_MAX_ORDER;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean defaultUseCacheForAllThreads() {
/* 438 */     return DEFAULT_USE_CACHE_FOR_ALL_THREADS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean defaultPreferDirect() {
/* 445 */     return PlatformDependent.directBufferPreferred();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static int defaultTinyCacheSize() {
/* 455 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int defaultSmallCacheSize() {
/* 462 */     return DEFAULT_SMALL_CACHE_SIZE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int defaultNormalCacheSize() {
/* 469 */     return DEFAULT_NORMAL_CACHE_SIZE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isDirectMemoryCacheAlignmentSupported() {
/* 476 */     return PlatformDependent.hasUnsafe();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isDirectBufferPooled() {
/* 481 */     return (this.directArenas != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public boolean hasThreadLocalCache() {
/* 491 */     return this.threadCache.isSet();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void freeThreadLocalCache() {
/* 500 */     this.threadCache.remove();
/*     */   }
/*     */   
/*     */   private final class PoolThreadLocalCache extends FastThreadLocal<PoolThreadCache> {
/*     */     private final boolean useCacheForAllThreads;
/*     */     
/*     */     PoolThreadLocalCache(boolean useCacheForAllThreads) {
/* 507 */       this.useCacheForAllThreads = useCacheForAllThreads;
/*     */     }
/*     */ 
/*     */     
/*     */     protected synchronized PoolThreadCache initialValue() {
/* 512 */       PoolArena<byte[]> heapArena = (PoolArena)leastUsedArena((PoolArena[])PooledByteBufAllocator.this.heapArenas);
/* 513 */       PoolArena<ByteBuffer> directArena = leastUsedArena(PooledByteBufAllocator.this.directArenas);
/*     */       
/* 515 */       Thread current = Thread.currentThread();
/* 516 */       EventExecutor executor = ThreadExecutorMap.currentExecutor();
/*     */       
/* 518 */       if (this.useCacheForAllThreads || current instanceof io.netty.util.concurrent.FastThreadLocalThread || executor != null) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 526 */         PoolThreadCache cache = new PoolThreadCache(heapArena, directArena, PooledByteBufAllocator.this.smallCacheSize, PooledByteBufAllocator.this.normalCacheSize, PooledByteBufAllocator.DEFAULT_MAX_CACHED_BUFFER_CAPACITY, PooledByteBufAllocator.DEFAULT_CACHE_TRIM_INTERVAL);
/*     */         
/* 528 */         if (PooledByteBufAllocator.DEFAULT_CACHE_TRIM_INTERVAL_MILLIS > 0L && 
/* 529 */           executor != null) {
/* 530 */           executor.scheduleAtFixedRate(PooledByteBufAllocator.this.trimTask, PooledByteBufAllocator.DEFAULT_CACHE_TRIM_INTERVAL_MILLIS, PooledByteBufAllocator
/* 531 */               .DEFAULT_CACHE_TRIM_INTERVAL_MILLIS, TimeUnit.MILLISECONDS);
/*     */         }
/*     */         
/* 534 */         return cache;
/*     */       } 
/*     */       
/* 537 */       return new PoolThreadCache(heapArena, directArena, 0, 0, 0, 0);
/*     */     }
/*     */ 
/*     */     
/*     */     protected void onRemoval(PoolThreadCache threadCache) {
/* 542 */       threadCache.free(false);
/*     */     }
/*     */     
/*     */     private <T> PoolArena<T> leastUsedArena(PoolArena<T>[] arenas) {
/* 546 */       if (arenas == null || arenas.length == 0) {
/* 547 */         return null;
/*     */       }
/*     */       
/* 550 */       PoolArena<T> minArena = arenas[0];
/*     */ 
/*     */       
/* 553 */       if (minArena.numThreadCaches.get() == 0) {
/* 554 */         return minArena;
/*     */       }
/* 556 */       for (int i = 1; i < arenas.length; i++) {
/* 557 */         PoolArena<T> arena = arenas[i];
/* 558 */         if (arena.numThreadCaches.get() < minArena.numThreadCaches.get()) {
/* 559 */           minArena = arena;
/*     */         }
/*     */       } 
/*     */       
/* 563 */       return minArena;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public PooledByteBufAllocatorMetric metric() {
/* 569 */     return this.metric;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public int numHeapArenas() {
/* 579 */     return this.heapArenaMetrics.size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public int numDirectArenas() {
/* 589 */     return this.directArenaMetrics.size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public List<PoolArenaMetric> heapArenas() {
/* 599 */     return this.heapArenaMetrics;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public List<PoolArenaMetric> directArenas() {
/* 609 */     return this.directArenaMetrics;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public int numThreadLocalCaches() {
/* 619 */     PoolArena<?>[] arenas = (this.heapArenas != null) ? (PoolArena<?>[])this.heapArenas : (PoolArena<?>[])this.directArenas;
/* 620 */     if (arenas == null) {
/* 621 */       return 0;
/*     */     }
/*     */     
/* 624 */     int total = 0;
/* 625 */     for (PoolArena<?> arena : arenas) {
/* 626 */       total += arena.numThreadCaches.get();
/*     */     }
/*     */     
/* 629 */     return total;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public int tinyCacheSize() {
/* 639 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public int smallCacheSize() {
/* 649 */     return this.smallCacheSize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public int normalCacheSize() {
/* 659 */     return this.normalCacheSize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public final int chunkSize() {
/* 669 */     return this.chunkSize;
/*     */   }
/*     */   
/*     */   final long usedHeapMemory() {
/* 673 */     return usedMemory((PoolArena<?>[])this.heapArenas);
/*     */   }
/*     */   
/*     */   final long usedDirectMemory() {
/* 677 */     return usedMemory((PoolArena<?>[])this.directArenas);
/*     */   }
/*     */   
/*     */   private static long usedMemory(PoolArena<?>[] arenas) {
/* 681 */     if (arenas == null) {
/* 682 */       return -1L;
/*     */     }
/* 684 */     long used = 0L;
/* 685 */     for (PoolArena<?> arena : arenas) {
/* 686 */       used += arena.numActiveBytes();
/* 687 */       if (used < 0L) {
/* 688 */         return Long.MAX_VALUE;
/*     */       }
/*     */     } 
/* 691 */     return used;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final long pinnedHeapMemory() {
/* 701 */     return pinnedMemory((PoolArena<?>[])this.heapArenas);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final long pinnedDirectMemory() {
/* 711 */     return pinnedMemory((PoolArena<?>[])this.directArenas);
/*     */   }
/*     */   
/*     */   private static long pinnedMemory(PoolArena<?>[] arenas) {
/* 715 */     if (arenas == null) {
/* 716 */       return -1L;
/*     */     }
/* 718 */     long used = 0L;
/* 719 */     for (PoolArena<?> arena : arenas) {
/* 720 */       used += arena.numPinnedBytes();
/* 721 */       if (used < 0L) {
/* 722 */         return Long.MAX_VALUE;
/*     */       }
/*     */     } 
/* 725 */     return used;
/*     */   }
/*     */   
/*     */   final PoolThreadCache threadCache() {
/* 729 */     PoolThreadCache cache = (PoolThreadCache)this.threadCache.get();
/* 730 */     assert cache != null;
/* 731 */     return cache;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean trimCurrentThreadCache() {
/* 741 */     PoolThreadCache cache = (PoolThreadCache)this.threadCache.getIfExists();
/* 742 */     if (cache != null) {
/* 743 */       cache.trim();
/* 744 */       return true;
/*     */     } 
/* 746 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String dumpStats() {
/* 754 */     int heapArenasLen = (this.heapArenas == null) ? 0 : this.heapArenas.length;
/*     */ 
/*     */ 
/*     */     
/* 758 */     StringBuilder buf = (new StringBuilder(512)).append(heapArenasLen).append(" heap arena(s):").append(StringUtil.NEWLINE);
/* 759 */     if (heapArenasLen > 0) {
/* 760 */       for (PoolArena<byte[]> a : this.heapArenas) {
/* 761 */         buf.append(a);
/*     */       }
/*     */     }
/*     */     
/* 765 */     int directArenasLen = (this.directArenas == null) ? 0 : this.directArenas.length;
/*     */     
/* 767 */     buf.append(directArenasLen)
/* 768 */       .append(" direct arena(s):")
/* 769 */       .append(StringUtil.NEWLINE);
/* 770 */     if (directArenasLen > 0) {
/* 771 */       for (PoolArena<ByteBuffer> a : this.directArenas) {
/* 772 */         buf.append(a);
/*     */       }
/*     */     }
/*     */     
/* 776 */     return buf.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-buffer-4.1.93.Final.jar!\io\netty\buffer\PooledByteBufAllocator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */