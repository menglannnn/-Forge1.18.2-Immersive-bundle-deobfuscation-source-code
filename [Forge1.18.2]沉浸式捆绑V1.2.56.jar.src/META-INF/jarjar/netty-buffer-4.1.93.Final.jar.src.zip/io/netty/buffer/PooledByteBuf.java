/*     */ package io.netty.buffer;
/*     */ 
/*     */ import io.netty.util.Recycler;
/*     */ import io.netty.util.internal.ObjectPool;
/*     */ import java.io.IOException;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.ByteOrder;
/*     */ import java.nio.channels.ClosedChannelException;
/*     */ import java.nio.channels.FileChannel;
/*     */ import java.nio.channels.GatheringByteChannel;
/*     */ import java.nio.channels.ScatteringByteChannel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class PooledByteBuf<T>
/*     */   extends AbstractReferenceCountedByteBuf
/*     */ {
/*     */   private final Recycler.EnhancedHandle<PooledByteBuf<T>> recyclerHandle;
/*     */   protected PoolChunk<T> chunk;
/*     */   protected long handle;
/*     */   protected T memory;
/*     */   protected int offset;
/*     */   protected int length;
/*     */   int maxLength;
/*     */   PoolThreadCache cache;
/*     */   ByteBuffer tmpNioBuf;
/*     */   private ByteBufAllocator allocator;
/*     */   
/*     */   protected PooledByteBuf(ObjectPool.Handle<? extends PooledByteBuf<T>> recyclerHandle, int maxCapacity) {
/*  46 */     super(maxCapacity);
/*  47 */     this.recyclerHandle = (Recycler.EnhancedHandle)recyclerHandle;
/*     */   }
/*     */ 
/*     */   
/*     */   void init(PoolChunk<T> chunk, ByteBuffer nioBuffer, long handle, int offset, int length, int maxLength, PoolThreadCache cache) {
/*  52 */     init0(chunk, nioBuffer, handle, offset, length, maxLength, cache);
/*     */   }
/*     */   
/*     */   void initUnpooled(PoolChunk<T> chunk, int length) {
/*  56 */     init0(chunk, (ByteBuffer)null, 0L, 0, length, length, (PoolThreadCache)null);
/*     */   }
/*     */ 
/*     */   
/*     */   private void init0(PoolChunk<T> chunk, ByteBuffer nioBuffer, long handle, int offset, int length, int maxLength, PoolThreadCache cache) {
/*  61 */     assert handle >= 0L;
/*  62 */     assert chunk != null;
/*  63 */     assert !PoolChunk.isSubpage(handle) || chunk.arena.size2SizeIdx(maxLength) <= chunk.arena.smallMaxSizeIdx : "Allocated small sub-page handle for a buffer size that isn't \"small.\"";
/*     */ 
/*     */     
/*  66 */     chunk.incrementPinnedMemory(maxLength);
/*  67 */     this.chunk = chunk;
/*  68 */     this.memory = chunk.memory;
/*  69 */     this.tmpNioBuf = nioBuffer;
/*  70 */     this.allocator = chunk.arena.parent;
/*  71 */     this.cache = cache;
/*  72 */     this.handle = handle;
/*  73 */     this.offset = offset;
/*  74 */     this.length = length;
/*  75 */     this.maxLength = maxLength;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final void reuse(int maxCapacity) {
/*  82 */     maxCapacity(maxCapacity);
/*  83 */     resetRefCnt();
/*  84 */     setIndex0(0, 0);
/*  85 */     discardMarks();
/*     */   }
/*     */ 
/*     */   
/*     */   public final int capacity() {
/*  90 */     return this.length;
/*     */   }
/*     */ 
/*     */   
/*     */   public int maxFastWritableBytes() {
/*  95 */     return Math.min(this.maxLength, maxCapacity()) - this.writerIndex;
/*     */   }
/*     */ 
/*     */   
/*     */   public final ByteBuf capacity(int newCapacity) {
/* 100 */     if (newCapacity == this.length) {
/* 101 */       ensureAccessible();
/* 102 */       return this;
/*     */     } 
/* 104 */     checkNewCapacity(newCapacity);
/* 105 */     if (!this.chunk.unpooled)
/*     */     {
/* 107 */       if (newCapacity > this.length) {
/* 108 */         if (newCapacity <= this.maxLength) {
/* 109 */           this.length = newCapacity;
/* 110 */           return this;
/*     */         } 
/* 112 */       } else if (newCapacity > this.maxLength >>> 1 && (this.maxLength > 512 || newCapacity > this.maxLength - 16)) {
/*     */ 
/*     */         
/* 115 */         this.length = newCapacity;
/* 116 */         trimIndicesToCapacity(newCapacity);
/* 117 */         return this;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 122 */     this.chunk.decrementPinnedMemory(this.maxLength);
/* 123 */     this.chunk.arena.reallocate(this, newCapacity, true);
/* 124 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public final ByteBufAllocator alloc() {
/* 129 */     return this.allocator;
/*     */   }
/*     */ 
/*     */   
/*     */   public final ByteOrder order() {
/* 134 */     return ByteOrder.BIG_ENDIAN;
/*     */   }
/*     */ 
/*     */   
/*     */   public final ByteBuf unwrap() {
/* 139 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public final ByteBuf retainedDuplicate() {
/* 144 */     return PooledDuplicatedByteBuf.newInstance(this, this, readerIndex(), writerIndex());
/*     */   }
/*     */ 
/*     */   
/*     */   public final ByteBuf retainedSlice() {
/* 149 */     int index = readerIndex();
/* 150 */     return retainedSlice(index, writerIndex() - index);
/*     */   }
/*     */ 
/*     */   
/*     */   public final ByteBuf retainedSlice(int index, int length) {
/* 155 */     return PooledSlicedByteBuf.newInstance(this, this, index, length);
/*     */   }
/*     */   
/*     */   protected final ByteBuffer internalNioBuffer() {
/* 159 */     ByteBuffer tmpNioBuf = this.tmpNioBuf;
/* 160 */     if (tmpNioBuf == null) {
/* 161 */       this.tmpNioBuf = tmpNioBuf = newInternalNioBuffer(this.memory);
/*     */     } else {
/* 163 */       tmpNioBuf.clear();
/*     */     } 
/* 165 */     return tmpNioBuf;
/*     */   }
/*     */ 
/*     */   
/*     */   protected abstract ByteBuffer newInternalNioBuffer(T paramT);
/*     */   
/*     */   protected final void deallocate() {
/* 172 */     if (this.handle >= 0L) {
/* 173 */       long handle = this.handle;
/* 174 */       this.handle = -1L;
/* 175 */       this.memory = null;
/* 176 */       this.chunk.decrementPinnedMemory(this.maxLength);
/* 177 */       this.chunk.arena.free(this.chunk, this.tmpNioBuf, handle, this.maxLength, this.cache);
/* 178 */       this.tmpNioBuf = null;
/* 179 */       this.chunk = null;
/* 180 */       this.cache = null;
/* 181 */       this.recyclerHandle.unguardedRecycle(this);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected final int idx(int index) {
/* 186 */     return this.offset + index;
/*     */   }
/*     */   
/*     */   final ByteBuffer _internalNioBuffer(int index, int length, boolean duplicate) {
/* 190 */     index = idx(index);
/* 191 */     ByteBuffer buffer = duplicate ? newInternalNioBuffer(this.memory) : internalNioBuffer();
/* 192 */     buffer.limit(index + length).position(index);
/* 193 */     return buffer;
/*     */   }
/*     */   
/*     */   ByteBuffer duplicateInternalNioBuffer(int index, int length) {
/* 197 */     checkIndex(index, length);
/* 198 */     return _internalNioBuffer(index, length, true);
/*     */   }
/*     */ 
/*     */   
/*     */   public final ByteBuffer internalNioBuffer(int index, int length) {
/* 203 */     checkIndex(index, length);
/* 204 */     return _internalNioBuffer(index, length, false);
/*     */   }
/*     */ 
/*     */   
/*     */   public final int nioBufferCount() {
/* 209 */     return 1;
/*     */   }
/*     */ 
/*     */   
/*     */   public final ByteBuffer nioBuffer(int index, int length) {
/* 214 */     return duplicateInternalNioBuffer(index, length).slice();
/*     */   }
/*     */ 
/*     */   
/*     */   public final ByteBuffer[] nioBuffers(int index, int length) {
/* 219 */     return new ByteBuffer[] { nioBuffer(index, length) };
/*     */   }
/*     */ 
/*     */   
/*     */   public final boolean isContiguous() {
/* 224 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public final int getBytes(int index, GatheringByteChannel out, int length) throws IOException {
/* 229 */     return out.write(duplicateInternalNioBuffer(index, length));
/*     */   }
/*     */ 
/*     */   
/*     */   public final int readBytes(GatheringByteChannel out, int length) throws IOException {
/* 234 */     checkReadableBytes(length);
/* 235 */     int readBytes = out.write(_internalNioBuffer(this.readerIndex, length, false));
/* 236 */     this.readerIndex += readBytes;
/* 237 */     return readBytes;
/*     */   }
/*     */ 
/*     */   
/*     */   public final int getBytes(int index, FileChannel out, long position, int length) throws IOException {
/* 242 */     return out.write(duplicateInternalNioBuffer(index, length), position);
/*     */   }
/*     */ 
/*     */   
/*     */   public final int readBytes(FileChannel out, long position, int length) throws IOException {
/* 247 */     checkReadableBytes(length);
/* 248 */     int readBytes = out.write(_internalNioBuffer(this.readerIndex, length, false), position);
/* 249 */     this.readerIndex += readBytes;
/* 250 */     return readBytes;
/*     */   }
/*     */ 
/*     */   
/*     */   public final int setBytes(int index, ScatteringByteChannel in, int length) throws IOException {
/*     */     try {
/* 256 */       return in.read(internalNioBuffer(index, length));
/* 257 */     } catch (ClosedChannelException ignored) {
/* 258 */       return -1;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public final int setBytes(int index, FileChannel in, long position, int length) throws IOException {
/*     */     try {
/* 265 */       return in.read(internalNioBuffer(index, length), position);
/* 266 */     } catch (ClosedChannelException ignored) {
/* 267 */       return -1;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-buffer-4.1.93.Final.jar!\io\netty\buffer\PooledByteBuf.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */