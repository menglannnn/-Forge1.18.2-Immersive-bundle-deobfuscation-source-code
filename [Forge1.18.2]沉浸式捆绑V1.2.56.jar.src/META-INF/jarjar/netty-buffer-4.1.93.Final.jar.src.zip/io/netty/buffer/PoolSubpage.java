/*     */ package io.netty.buffer;
/*     */ 
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class PoolSubpage<T>
/*     */   implements PoolSubpageMetric
/*     */ {
/*     */   final PoolChunk<T> chunk;
/*     */   final int elemSize;
/*     */   private final int pageShifts;
/*     */   private final int runOffset;
/*     */   private final int runSize;
/*     */   private final long[] bitmap;
/*     */   PoolSubpage<T> prev;
/*     */   PoolSubpage<T> next;
/*     */   boolean doNotDestroy;
/*     */   private int maxNumElems;
/*     */   private int bitmapLength;
/*     */   private int nextAvail;
/*     */   private int numAvail;
/*  45 */   private final ReentrantLock lock = new ReentrantLock();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   PoolSubpage() {
/*  52 */     this.chunk = null;
/*  53 */     this.pageShifts = -1;
/*  54 */     this.runOffset = -1;
/*  55 */     this.elemSize = -1;
/*  56 */     this.runSize = -1;
/*  57 */     this.bitmap = null;
/*     */   }
/*     */   
/*     */   PoolSubpage(PoolSubpage<T> head, PoolChunk<T> chunk, int pageShifts, int runOffset, int runSize, int elemSize) {
/*  61 */     this.chunk = chunk;
/*  62 */     this.pageShifts = pageShifts;
/*  63 */     this.runOffset = runOffset;
/*  64 */     this.runSize = runSize;
/*  65 */     this.elemSize = elemSize;
/*  66 */     this.bitmap = new long[runSize >>> 10];
/*     */     
/*  68 */     this.doNotDestroy = true;
/*  69 */     if (elemSize != 0) {
/*  70 */       this.maxNumElems = this.numAvail = runSize / elemSize;
/*  71 */       this.nextAvail = 0;
/*  72 */       this.bitmapLength = this.maxNumElems >>> 6;
/*  73 */       if ((this.maxNumElems & 0x3F) != 0) {
/*  74 */         this.bitmapLength++;
/*     */       }
/*     */     } 
/*  77 */     addToPool(head);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   long allocate() {
/*  84 */     if (this.numAvail == 0 || !this.doNotDestroy) {
/*  85 */       return -1L;
/*     */     }
/*     */     
/*  88 */     int bitmapIdx = getNextAvail();
/*  89 */     if (bitmapIdx < 0) {
/*  90 */       removeFromPool();
/*  91 */       throw new AssertionError("No next available bitmap index found (bitmapIdx = " + bitmapIdx + "), even though there are supposed to be (numAvail = " + this.numAvail + ") out of (maxNumElems = " + this.maxNumElems + ") available indexes.");
/*     */     } 
/*     */ 
/*     */     
/*  95 */     int q = bitmapIdx >>> 6;
/*  96 */     int r = bitmapIdx & 0x3F;
/*  97 */     assert (this.bitmap[q] >>> r & 0x1L) == 0L;
/*  98 */     this.bitmap[q] = this.bitmap[q] | 1L << r;
/*     */     
/* 100 */     if (--this.numAvail == 0) {
/* 101 */       removeFromPool();
/*     */     }
/*     */     
/* 104 */     return toHandle(bitmapIdx);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean free(PoolSubpage<T> head, int bitmapIdx) {
/* 112 */     if (this.elemSize == 0) {
/* 113 */       return true;
/*     */     }
/* 115 */     int q = bitmapIdx >>> 6;
/* 116 */     int r = bitmapIdx & 0x3F;
/* 117 */     assert (this.bitmap[q] >>> r & 0x1L) != 0L;
/* 118 */     this.bitmap[q] = this.bitmap[q] ^ 1L << r;
/*     */     
/* 120 */     setNextAvail(bitmapIdx);
/*     */     
/* 122 */     if (this.numAvail++ == 0) {
/* 123 */       addToPool(head);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 128 */       if (this.maxNumElems > 1) {
/* 129 */         return true;
/*     */       }
/*     */     } 
/*     */     
/* 133 */     if (this.numAvail != this.maxNumElems) {
/* 134 */       return true;
/*     */     }
/*     */     
/* 137 */     if (this.prev == this.next)
/*     */     {
/* 139 */       return true;
/*     */     }
/*     */ 
/*     */     
/* 143 */     this.doNotDestroy = false;
/* 144 */     removeFromPool();
/* 145 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   private void addToPool(PoolSubpage<T> head) {
/* 150 */     assert this.prev == null && this.next == null;
/* 151 */     this.prev = head;
/* 152 */     this.next = head.next;
/* 153 */     this.next.prev = this;
/* 154 */     head.next = this;
/*     */   }
/*     */   
/*     */   private void removeFromPool() {
/* 158 */     assert this.prev != null && this.next != null;
/* 159 */     this.prev.next = this.next;
/* 160 */     this.next.prev = this.prev;
/* 161 */     this.next = null;
/* 162 */     this.prev = null;
/*     */   }
/*     */   
/*     */   private void setNextAvail(int bitmapIdx) {
/* 166 */     this.nextAvail = bitmapIdx;
/*     */   }
/*     */   
/*     */   private int getNextAvail() {
/* 170 */     int nextAvail = this.nextAvail;
/* 171 */     if (nextAvail >= 0) {
/* 172 */       this.nextAvail = -1;
/* 173 */       return nextAvail;
/*     */     } 
/* 175 */     return findNextAvail();
/*     */   }
/*     */   
/*     */   private int findNextAvail() {
/* 179 */     long[] bitmap = this.bitmap;
/* 180 */     int bitmapLength = this.bitmapLength;
/* 181 */     for (int i = 0; i < bitmapLength; i++) {
/* 182 */       long bits = bitmap[i];
/* 183 */       if ((bits ^ 0xFFFFFFFFFFFFFFFFL) != 0L) {
/* 184 */         return findNextAvail0(i, bits);
/*     */       }
/*     */     } 
/* 187 */     return -1;
/*     */   }
/*     */   
/*     */   private int findNextAvail0(int i, long bits) {
/* 191 */     int maxNumElems = this.maxNumElems;
/* 192 */     int baseVal = i << 6;
/*     */     
/* 194 */     for (int j = 0; j < 64; j++) {
/* 195 */       if ((bits & 0x1L) == 0L) {
/* 196 */         int val = baseVal | j;
/* 197 */         if (val < maxNumElems) {
/* 198 */           return val;
/*     */         }
/*     */         
/*     */         break;
/*     */       } 
/* 203 */       bits >>>= 1L;
/*     */     } 
/* 205 */     return -1;
/*     */   }
/*     */   
/*     */   private long toHandle(int bitmapIdx) {
/* 209 */     int pages = this.runSize >> this.pageShifts;
/* 210 */     return this.runOffset << 49L | pages << 34L | 0x200000000L | 0x100000000L | bitmapIdx;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/*     */     boolean doNotDestroy;
/*     */     int maxNumElems;
/*     */     int numAvail;
/*     */     int elemSize;
/* 223 */     if (this.chunk == null) {
/*     */       
/* 225 */       doNotDestroy = true;
/* 226 */       maxNumElems = 0;
/* 227 */       numAvail = 0;
/* 228 */       elemSize = -1;
/*     */     } else {
/* 230 */       this.chunk.arena.lock();
/*     */       try {
/* 232 */         if (!this.doNotDestroy) {
/* 233 */           doNotDestroy = false;
/*     */           
/* 235 */           maxNumElems = numAvail = elemSize = -1;
/*     */         } else {
/* 237 */           doNotDestroy = true;
/* 238 */           maxNumElems = this.maxNumElems;
/* 239 */           numAvail = this.numAvail;
/* 240 */           elemSize = this.elemSize;
/*     */         } 
/*     */       } finally {
/* 243 */         this.chunk.arena.unlock();
/*     */       } 
/*     */     } 
/*     */     
/* 247 */     if (!doNotDestroy) {
/* 248 */       return "(" + this.runOffset + ": not in use)";
/*     */     }
/*     */     
/* 251 */     return "(" + this.runOffset + ": " + (maxNumElems - numAvail) + '/' + maxNumElems + ", offset: " + this.runOffset + ", length: " + this.runSize + ", elemSize: " + elemSize + ')';
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int maxNumElements() {
/* 257 */     if (this.chunk == null)
/*     */     {
/* 259 */       return 0;
/*     */     }
/* 261 */     this.chunk.arena.lock();
/*     */     try {
/* 263 */       return this.maxNumElems;
/*     */     } finally {
/* 265 */       this.chunk.arena.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int numAvailable() {
/* 271 */     if (this.chunk == null)
/*     */     {
/* 273 */       return 0;
/*     */     }
/*     */     
/* 276 */     this.chunk.arena.lock();
/*     */     try {
/* 278 */       return this.numAvail;
/*     */     } finally {
/* 280 */       this.chunk.arena.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int elementSize() {
/* 286 */     if (this.chunk == null)
/*     */     {
/* 288 */       return -1;
/*     */     }
/*     */     
/* 291 */     this.chunk.arena.lock();
/*     */     try {
/* 293 */       return this.elemSize;
/*     */     } finally {
/* 295 */       this.chunk.arena.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int pageSize() {
/* 301 */     return 1 << this.pageShifts;
/*     */   }
/*     */   
/*     */   void destroy() {
/* 305 */     if (this.chunk != null) {
/* 306 */       this.chunk.destroy();
/*     */     }
/*     */   }
/*     */   
/*     */   void lock() {
/* 311 */     this.lock.lock();
/*     */   }
/*     */   
/*     */   void unlock() {
/* 315 */     this.lock.unlock();
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-buffer-4.1.93.Final.jar!\io\netty\buffer\PoolSubpage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */