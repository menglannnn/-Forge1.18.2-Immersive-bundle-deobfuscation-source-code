package io.netty.buffer;

import java.util.List;

public interface PoolArenaMetric extends SizeClassesMetric {
  int numThreadCaches();
  
  @Deprecated
  int numTinySubpages();
  
  int numSmallSubpages();
  
  int numChunkLists();
  
  @Deprecated
  List<PoolSubpageMetric> tinySubpages();
  
  List<PoolSubpageMetric> smallSubpages();
  
  List<PoolChunkListMetric> chunkLists();
  
  long numAllocations();
  
  @Deprecated
  long numTinyAllocations();
  
  long numSmallAllocations();
  
  long numNormalAllocations();
  
  long numHugeAllocations();
  
  long numDeallocations();
  
  @Deprecated
  long numTinyDeallocations();
  
  long numSmallDeallocations();
  
  long numNormalDeallocations();
  
  long numHugeDeallocations();
  
  long numActiveAllocations();
  
  @Deprecated
  long numActiveTinyAllocations();
  
  long numActiveSmallAllocations();
  
  long numActiveNormalAllocations();
  
  long numActiveHugeAllocations();
  
  long numActiveBytes();
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-buffer-4.1.93.Final.jar!\io\netty\buffer\PoolArenaMetric.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */