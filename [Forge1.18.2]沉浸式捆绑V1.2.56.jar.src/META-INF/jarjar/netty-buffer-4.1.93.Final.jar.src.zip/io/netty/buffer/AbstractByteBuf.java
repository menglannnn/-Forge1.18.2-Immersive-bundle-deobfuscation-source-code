/*      */ package io.netty.buffer;
/*      */ 
/*      */ import io.netty.util.AsciiString;
/*      */ import io.netty.util.ByteProcessor;
/*      */ import io.netty.util.CharsetUtil;
/*      */ import io.netty.util.IllegalReferenceCountException;
/*      */ import io.netty.util.ResourceLeakDetector;
/*      */ import io.netty.util.ResourceLeakDetectorFactory;
/*      */ import io.netty.util.internal.MathUtil;
/*      */ import io.netty.util.internal.ObjectUtil;
/*      */ import io.netty.util.internal.PlatformDependent;
/*      */ import io.netty.util.internal.StringUtil;
/*      */ import io.netty.util.internal.SystemPropertyUtil;
/*      */ import io.netty.util.internal.logging.InternalLogger;
/*      */ import io.netty.util.internal.logging.InternalLoggerFactory;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.OutputStream;
/*      */ import java.nio.ByteBuffer;
/*      */ import java.nio.ByteOrder;
/*      */ import java.nio.channels.FileChannel;
/*      */ import java.nio.channels.GatheringByteChannel;
/*      */ import java.nio.channels.ScatteringByteChannel;
/*      */ import java.nio.charset.Charset;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class AbstractByteBuf
/*      */   extends ByteBuf
/*      */ {
/*   48 */   private static final InternalLogger logger = InternalLoggerFactory.getInstance(AbstractByteBuf.class);
/*      */   
/*      */   private static final String LEGACY_PROP_CHECK_ACCESSIBLE = "io.netty.buffer.bytebuf.checkAccessible";
/*      */   private static final String PROP_CHECK_ACCESSIBLE = "io.netty.buffer.checkAccessible";
/*      */   static final boolean checkAccessible;
/*      */   private static final String PROP_CHECK_BOUNDS = "io.netty.buffer.checkBounds";
/*      */   
/*      */   static {
/*   56 */     if (SystemPropertyUtil.contains("io.netty.buffer.checkAccessible")) {
/*   57 */       checkAccessible = SystemPropertyUtil.getBoolean("io.netty.buffer.checkAccessible", true);
/*      */     } else {
/*   59 */       checkAccessible = SystemPropertyUtil.getBoolean("io.netty.buffer.bytebuf.checkAccessible", true);
/*      */     } 
/*   61 */   } private static final boolean checkBounds = SystemPropertyUtil.getBoolean("io.netty.buffer.checkBounds", true); static {
/*   62 */     if (logger.isDebugEnabled()) {
/*   63 */       logger.debug("-D{}: {}", "io.netty.buffer.checkAccessible", Boolean.valueOf(checkAccessible));
/*   64 */       logger.debug("-D{}: {}", "io.netty.buffer.checkBounds", Boolean.valueOf(checkBounds));
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*   69 */   static final ResourceLeakDetector<ByteBuf> leakDetector = ResourceLeakDetectorFactory.instance().newResourceLeakDetector(ByteBuf.class);
/*      */   
/*      */   int readerIndex;
/*      */   int writerIndex;
/*      */   private int markedReaderIndex;
/*      */   private int markedWriterIndex;
/*      */   private int maxCapacity;
/*      */   
/*      */   protected AbstractByteBuf(int maxCapacity) {
/*   78 */     ObjectUtil.checkPositiveOrZero(maxCapacity, "maxCapacity");
/*   79 */     this.maxCapacity = maxCapacity;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isReadOnly() {
/*   84 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ByteBuf asReadOnly() {
/*   90 */     if (isReadOnly()) {
/*   91 */       return this;
/*      */     }
/*   93 */     return Unpooled.unmodifiableBuffer(this);
/*      */   }
/*      */ 
/*      */   
/*      */   public int maxCapacity() {
/*   98 */     return this.maxCapacity;
/*      */   }
/*      */   
/*      */   protected final void maxCapacity(int maxCapacity) {
/*  102 */     this.maxCapacity = maxCapacity;
/*      */   }
/*      */ 
/*      */   
/*      */   public int readerIndex() {
/*  107 */     return this.readerIndex;
/*      */   }
/*      */   
/*      */   private static void checkIndexBounds(int readerIndex, int writerIndex, int capacity) {
/*  111 */     if (readerIndex < 0 || readerIndex > writerIndex || writerIndex > capacity) {
/*  112 */       throw new IndexOutOfBoundsException(String.format("readerIndex: %d, writerIndex: %d (expected: 0 <= readerIndex <= writerIndex <= capacity(%d))", new Object[] {
/*      */               
/*  114 */               Integer.valueOf(readerIndex), Integer.valueOf(writerIndex), Integer.valueOf(capacity)
/*      */             }));
/*      */     }
/*      */   }
/*      */   
/*      */   public ByteBuf readerIndex(int readerIndex) {
/*  120 */     if (checkBounds) {
/*  121 */       checkIndexBounds(readerIndex, this.writerIndex, capacity());
/*      */     }
/*  123 */     this.readerIndex = readerIndex;
/*  124 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public int writerIndex() {
/*  129 */     return this.writerIndex;
/*      */   }
/*      */ 
/*      */   
/*      */   public ByteBuf writerIndex(int writerIndex) {
/*  134 */     if (checkBounds) {
/*  135 */       checkIndexBounds(this.readerIndex, writerIndex, capacity());
/*      */     }
/*  137 */     this.writerIndex = writerIndex;
/*  138 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public ByteBuf setIndex(int readerIndex, int writerIndex) {
/*  143 */     if (checkBounds) {
/*  144 */       checkIndexBounds(readerIndex, writerIndex, capacity());
/*      */     }
/*  146 */     setIndex0(readerIndex, writerIndex);
/*  147 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public ByteBuf clear() {
/*  152 */     this.readerIndex = this.writerIndex = 0;
/*  153 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isReadable() {
/*  158 */     return (this.writerIndex > this.readerIndex);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isReadable(int numBytes) {
/*  163 */     return (this.writerIndex - this.readerIndex >= numBytes);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isWritable() {
/*  168 */     return (capacity() > this.writerIndex);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isWritable(int numBytes) {
/*  173 */     return (capacity() - this.writerIndex >= numBytes);
/*      */   }
/*      */ 
/*      */   
/*      */   public int readableBytes() {
/*  178 */     return this.writerIndex - this.readerIndex;
/*      */   }
/*      */ 
/*      */   
/*      */   public int writableBytes() {
/*  183 */     return capacity() - this.writerIndex;
/*      */   }
/*      */ 
/*      */   
/*      */   public int maxWritableBytes() {
/*  188 */     return maxCapacity() - this.writerIndex;
/*      */   }
/*      */ 
/*      */   
/*      */   public ByteBuf markReaderIndex() {
/*  193 */     this.markedReaderIndex = this.readerIndex;
/*  194 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public ByteBuf resetReaderIndex() {
/*  199 */     readerIndex(this.markedReaderIndex);
/*  200 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public ByteBuf markWriterIndex() {
/*  205 */     this.markedWriterIndex = this.writerIndex;
/*  206 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public ByteBuf resetWriterIndex() {
/*  211 */     writerIndex(this.markedWriterIndex);
/*  212 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public ByteBuf discardReadBytes() {
/*  217 */     if (this.readerIndex == 0) {
/*  218 */       ensureAccessible();
/*  219 */       return this;
/*      */     } 
/*      */     
/*  222 */     if (this.readerIndex != this.writerIndex) {
/*  223 */       setBytes(0, this, this.readerIndex, this.writerIndex - this.readerIndex);
/*  224 */       this.writerIndex -= this.readerIndex;
/*  225 */       adjustMarkers(this.readerIndex);
/*  226 */       this.readerIndex = 0;
/*      */     } else {
/*  228 */       ensureAccessible();
/*  229 */       adjustMarkers(this.readerIndex);
/*  230 */       this.writerIndex = this.readerIndex = 0;
/*      */     } 
/*  232 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public ByteBuf discardSomeReadBytes() {
/*  237 */     if (this.readerIndex > 0) {
/*  238 */       if (this.readerIndex == this.writerIndex) {
/*  239 */         ensureAccessible();
/*  240 */         adjustMarkers(this.readerIndex);
/*  241 */         this.writerIndex = this.readerIndex = 0;
/*  242 */         return this;
/*      */       } 
/*      */       
/*  245 */       if (this.readerIndex >= capacity() >>> 1) {
/*  246 */         setBytes(0, this, this.readerIndex, this.writerIndex - this.readerIndex);
/*  247 */         this.writerIndex -= this.readerIndex;
/*  248 */         adjustMarkers(this.readerIndex);
/*  249 */         this.readerIndex = 0;
/*  250 */         return this;
/*      */       } 
/*      */     } 
/*  253 */     ensureAccessible();
/*  254 */     return this;
/*      */   }
/*      */   
/*      */   protected final void adjustMarkers(int decrement) {
/*  258 */     if (this.markedReaderIndex <= decrement) {
/*  259 */       this.markedReaderIndex = 0;
/*  260 */       if (this.markedWriterIndex <= decrement) {
/*  261 */         this.markedWriterIndex = 0;
/*      */       } else {
/*  263 */         this.markedWriterIndex -= decrement;
/*      */       } 
/*      */     } else {
/*  266 */       this.markedReaderIndex -= decrement;
/*  267 */       this.markedWriterIndex -= decrement;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected final void trimIndicesToCapacity(int newCapacity) {
/*  273 */     if (writerIndex() > newCapacity) {
/*  274 */       setIndex0(Math.min(readerIndex(), newCapacity), newCapacity);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public ByteBuf ensureWritable(int minWritableBytes) {
/*  280 */     ensureWritable0(ObjectUtil.checkPositiveOrZero(minWritableBytes, "minWritableBytes"));
/*  281 */     return this;
/*      */   }
/*      */   
/*      */   final void ensureWritable0(int minWritableBytes) {
/*  285 */     int writerIndex = writerIndex();
/*  286 */     int targetCapacity = writerIndex + minWritableBytes;
/*      */     
/*  288 */     if ((((targetCapacity >= 0) ? 1 : 0) & ((targetCapacity <= capacity()) ? 1 : 0)) != 0) {
/*  289 */       ensureAccessible();
/*      */       return;
/*      */     } 
/*  292 */     if (checkBounds && (targetCapacity < 0 || targetCapacity > this.maxCapacity)) {
/*  293 */       ensureAccessible();
/*  294 */       throw new IndexOutOfBoundsException(String.format("writerIndex(%d) + minWritableBytes(%d) exceeds maxCapacity(%d): %s", new Object[] {
/*      */               
/*  296 */               Integer.valueOf(writerIndex), Integer.valueOf(minWritableBytes), Integer.valueOf(this.maxCapacity), this
/*      */             }));
/*      */     } 
/*      */     
/*  300 */     int fastWritable = maxFastWritableBytes();
/*      */     
/*  302 */     int newCapacity = (fastWritable >= minWritableBytes) ? (writerIndex + fastWritable) : alloc().calculateNewCapacity(targetCapacity, this.maxCapacity);
/*      */ 
/*      */     
/*  305 */     capacity(newCapacity);
/*      */   }
/*      */ 
/*      */   
/*      */   public int ensureWritable(int minWritableBytes, boolean force) {
/*  310 */     ensureAccessible();
/*  311 */     ObjectUtil.checkPositiveOrZero(minWritableBytes, "minWritableBytes");
/*      */     
/*  313 */     if (minWritableBytes <= writableBytes()) {
/*  314 */       return 0;
/*      */     }
/*      */     
/*  317 */     int maxCapacity = maxCapacity();
/*  318 */     int writerIndex = writerIndex();
/*  319 */     if (minWritableBytes > maxCapacity - writerIndex) {
/*  320 */       if (!force || capacity() == maxCapacity) {
/*  321 */         return 1;
/*      */       }
/*      */       
/*  324 */       capacity(maxCapacity);
/*  325 */       return 3;
/*      */     } 
/*      */     
/*  328 */     int fastWritable = maxFastWritableBytes();
/*      */     
/*  330 */     int newCapacity = (fastWritable >= minWritableBytes) ? (writerIndex + fastWritable) : alloc().calculateNewCapacity(writerIndex + minWritableBytes, maxCapacity);
/*      */ 
/*      */     
/*  333 */     capacity(newCapacity);
/*  334 */     return 2;
/*      */   }
/*      */ 
/*      */   
/*      */   public ByteBuf order(ByteOrder endianness) {
/*  339 */     if (endianness == order()) {
/*  340 */       return this;
/*      */     }
/*  342 */     ObjectUtil.checkNotNull(endianness, "endianness");
/*  343 */     return newSwappedByteBuf();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected SwappedByteBuf newSwappedByteBuf() {
/*  350 */     return new SwappedByteBuf(this);
/*      */   }
/*      */ 
/*      */   
/*      */   public byte getByte(int index) {
/*  355 */     checkIndex(index);
/*  356 */     return _getByte(index);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getBoolean(int index) {
/*  363 */     return (getByte(index) != 0);
/*      */   }
/*      */ 
/*      */   
/*      */   public short getUnsignedByte(int index) {
/*  368 */     return (short)(getByte(index) & 0xFF);
/*      */   }
/*      */ 
/*      */   
/*      */   public short getShort(int index) {
/*  373 */     checkIndex(index, 2);
/*  374 */     return _getShort(index);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public short getShortLE(int index) {
/*  381 */     checkIndex(index, 2);
/*  382 */     return _getShortLE(index);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getUnsignedShort(int index) {
/*  389 */     return getShort(index) & 0xFFFF;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getUnsignedShortLE(int index) {
/*  394 */     return getShortLE(index) & 0xFFFF;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getUnsignedMedium(int index) {
/*  399 */     checkIndex(index, 3);
/*  400 */     return _getUnsignedMedium(index);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getUnsignedMediumLE(int index) {
/*  407 */     checkIndex(index, 3);
/*  408 */     return _getUnsignedMediumLE(index);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getMedium(int index) {
/*  415 */     int value = getUnsignedMedium(index);
/*  416 */     if ((value & 0x800000) != 0) {
/*  417 */       value |= 0xFF000000;
/*      */     }
/*  419 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getMediumLE(int index) {
/*  424 */     int value = getUnsignedMediumLE(index);
/*  425 */     if ((value & 0x800000) != 0) {
/*  426 */       value |= 0xFF000000;
/*      */     }
/*  428 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getInt(int index) {
/*  433 */     checkIndex(index, 4);
/*  434 */     return _getInt(index);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getIntLE(int index) {
/*  441 */     checkIndex(index, 4);
/*  442 */     return _getIntLE(index);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long getUnsignedInt(int index) {
/*  449 */     return getInt(index) & 0xFFFFFFFFL;
/*      */   }
/*      */ 
/*      */   
/*      */   public long getUnsignedIntLE(int index) {
/*  454 */     return getIntLE(index) & 0xFFFFFFFFL;
/*      */   }
/*      */ 
/*      */   
/*      */   public long getLong(int index) {
/*  459 */     checkIndex(index, 8);
/*  460 */     return _getLong(index);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long getLongLE(int index) {
/*  467 */     checkIndex(index, 8);
/*  468 */     return _getLongLE(index);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public char getChar(int index) {
/*  475 */     return (char)getShort(index);
/*      */   }
/*      */ 
/*      */   
/*      */   public float getFloat(int index) {
/*  480 */     return Float.intBitsToFloat(getInt(index));
/*      */   }
/*      */ 
/*      */   
/*      */   public double getDouble(int index) {
/*  485 */     return Double.longBitsToDouble(getLong(index));
/*      */   }
/*      */ 
/*      */   
/*      */   public ByteBuf getBytes(int index, byte[] dst) {
/*  490 */     getBytes(index, dst, 0, dst.length);
/*  491 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public ByteBuf getBytes(int index, ByteBuf dst) {
/*  496 */     getBytes(index, dst, dst.writableBytes());
/*  497 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public ByteBuf getBytes(int index, ByteBuf dst, int length) {
/*  502 */     getBytes(index, dst, dst.writerIndex(), length);
/*  503 */     dst.writerIndex(dst.writerIndex() + length);
/*  504 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public CharSequence getCharSequence(int index, int length, Charset charset) {
/*  509 */     if (CharsetUtil.US_ASCII.equals(charset) || CharsetUtil.ISO_8859_1.equals(charset))
/*      */     {
/*  511 */       return (CharSequence)new AsciiString(ByteBufUtil.getBytes(this, index, length, true), false);
/*      */     }
/*  513 */     return toString(index, length, charset);
/*      */   }
/*      */ 
/*      */   
/*      */   public CharSequence readCharSequence(int length, Charset charset) {
/*  518 */     CharSequence sequence = getCharSequence(this.readerIndex, length, charset);
/*  519 */     this.readerIndex += length;
/*  520 */     return sequence;
/*      */   }
/*      */ 
/*      */   
/*      */   public ByteBuf setByte(int index, int value) {
/*  525 */     checkIndex(index);
/*  526 */     _setByte(index, value);
/*  527 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ByteBuf setBoolean(int index, boolean value) {
/*  534 */     setByte(index, value ? 1 : 0);
/*  535 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public ByteBuf setShort(int index, int value) {
/*  540 */     checkIndex(index, 2);
/*  541 */     _setShort(index, value);
/*  542 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ByteBuf setShortLE(int index, int value) {
/*  549 */     checkIndex(index, 2);
/*  550 */     _setShortLE(index, value);
/*  551 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ByteBuf setChar(int index, int value) {
/*  558 */     setShort(index, value);
/*  559 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public ByteBuf setMedium(int index, int value) {
/*  564 */     checkIndex(index, 3);
/*  565 */     _setMedium(index, value);
/*  566 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ByteBuf setMediumLE(int index, int value) {
/*  573 */     checkIndex(index, 3);
/*  574 */     _setMediumLE(index, value);
/*  575 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ByteBuf setInt(int index, int value) {
/*  582 */     checkIndex(index, 4);
/*  583 */     _setInt(index, value);
/*  584 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ByteBuf setIntLE(int index, int value) {
/*  591 */     checkIndex(index, 4);
/*  592 */     _setIntLE(index, value);
/*  593 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ByteBuf setFloat(int index, float value) {
/*  600 */     setInt(index, Float.floatToRawIntBits(value));
/*  601 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public ByteBuf setLong(int index, long value) {
/*  606 */     checkIndex(index, 8);
/*  607 */     _setLong(index, value);
/*  608 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ByteBuf setLongLE(int index, long value) {
/*  615 */     checkIndex(index, 8);
/*  616 */     _setLongLE(index, value);
/*  617 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ByteBuf setDouble(int index, double value) {
/*  624 */     setLong(index, Double.doubleToRawLongBits(value));
/*  625 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public ByteBuf setBytes(int index, byte[] src) {
/*  630 */     setBytes(index, src, 0, src.length);
/*  631 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public ByteBuf setBytes(int index, ByteBuf src) {
/*  636 */     setBytes(index, src, src.readableBytes());
/*  637 */     return this;
/*      */   }
/*      */   
/*      */   private static void checkReadableBounds(ByteBuf src, int length) {
/*  641 */     if (length > src.readableBytes()) {
/*  642 */       throw new IndexOutOfBoundsException(String.format("length(%d) exceeds src.readableBytes(%d) where src is: %s", new Object[] {
/*  643 */               Integer.valueOf(length), Integer.valueOf(src.readableBytes()), src
/*      */             }));
/*      */     }
/*      */   }
/*      */   
/*      */   public ByteBuf setBytes(int index, ByteBuf src, int length) {
/*  649 */     checkIndex(index, length);
/*  650 */     ObjectUtil.checkNotNull(src, "src");
/*  651 */     if (checkBounds) {
/*  652 */       checkReadableBounds(src, length);
/*      */     }
/*      */     
/*  655 */     setBytes(index, src, src.readerIndex(), length);
/*  656 */     src.readerIndex(src.readerIndex() + length);
/*  657 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public ByteBuf setZero(int index, int length) {
/*  662 */     if (length == 0) {
/*  663 */       return this;
/*      */     }
/*      */     
/*  666 */     checkIndex(index, length);
/*      */     
/*  668 */     int nLong = length >>> 3;
/*  669 */     int nBytes = length & 0x7; int i;
/*  670 */     for (i = nLong; i > 0; i--) {
/*  671 */       _setLong(index, 0L);
/*  672 */       index += 8;
/*      */     } 
/*  674 */     if (nBytes == 4) {
/*  675 */       _setInt(index, 0);
/*      */     }
/*  677 */     else if (nBytes < 4) {
/*  678 */       for (i = nBytes; i > 0; i--) {
/*  679 */         _setByte(index, 0);
/*  680 */         index++;
/*      */       } 
/*      */     } else {
/*  683 */       _setInt(index, 0);
/*  684 */       index += 4;
/*  685 */       for (i = nBytes - 4; i > 0; i--) {
/*  686 */         _setByte(index, 0);
/*  687 */         index++;
/*      */       } 
/*      */     } 
/*  690 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public int setCharSequence(int index, CharSequence sequence, Charset charset) {
/*  695 */     return setCharSequence0(index, sequence, charset, false);
/*      */   }
/*      */   
/*      */   private int setCharSequence0(int index, CharSequence sequence, Charset charset, boolean expand) {
/*  699 */     if (charset.equals(CharsetUtil.UTF_8)) {
/*  700 */       int length = ByteBufUtil.utf8MaxBytes(sequence);
/*  701 */       if (expand) {
/*  702 */         ensureWritable0(length);
/*  703 */         checkIndex0(index, length);
/*      */       } else {
/*  705 */         checkIndex(index, length);
/*      */       } 
/*  707 */       return ByteBufUtil.writeUtf8(this, index, length, sequence, sequence.length());
/*      */     } 
/*  709 */     if (charset.equals(CharsetUtil.US_ASCII) || charset.equals(CharsetUtil.ISO_8859_1)) {
/*  710 */       int length = sequence.length();
/*  711 */       if (expand) {
/*  712 */         ensureWritable0(length);
/*  713 */         checkIndex0(index, length);
/*      */       } else {
/*  715 */         checkIndex(index, length);
/*      */       } 
/*  717 */       return ByteBufUtil.writeAscii(this, index, sequence, length);
/*      */     } 
/*  719 */     byte[] bytes = sequence.toString().getBytes(charset);
/*  720 */     if (expand) {
/*  721 */       ensureWritable0(bytes.length);
/*      */     }
/*      */     
/*  724 */     setBytes(index, bytes);
/*  725 */     return bytes.length;
/*      */   }
/*      */ 
/*      */   
/*      */   public byte readByte() {
/*  730 */     checkReadableBytes0(1);
/*  731 */     int i = this.readerIndex;
/*  732 */     byte b = _getByte(i);
/*  733 */     this.readerIndex = i + 1;
/*  734 */     return b;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean readBoolean() {
/*  739 */     return (readByte() != 0);
/*      */   }
/*      */ 
/*      */   
/*      */   public short readUnsignedByte() {
/*  744 */     return (short)(readByte() & 0xFF);
/*      */   }
/*      */ 
/*      */   
/*      */   public short readShort() {
/*  749 */     checkReadableBytes0(2);
/*  750 */     short v = _getShort(this.readerIndex);
/*  751 */     this.readerIndex += 2;
/*  752 */     return v;
/*      */   }
/*      */ 
/*      */   
/*      */   public short readShortLE() {
/*  757 */     checkReadableBytes0(2);
/*  758 */     short v = _getShortLE(this.readerIndex);
/*  759 */     this.readerIndex += 2;
/*  760 */     return v;
/*      */   }
/*      */ 
/*      */   
/*      */   public int readUnsignedShort() {
/*  765 */     return readShort() & 0xFFFF;
/*      */   }
/*      */ 
/*      */   
/*      */   public int readUnsignedShortLE() {
/*  770 */     return readShortLE() & 0xFFFF;
/*      */   }
/*      */ 
/*      */   
/*      */   public int readMedium() {
/*  775 */     int value = readUnsignedMedium();
/*  776 */     if ((value & 0x800000) != 0) {
/*  777 */       value |= 0xFF000000;
/*      */     }
/*  779 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public int readMediumLE() {
/*  784 */     int value = readUnsignedMediumLE();
/*  785 */     if ((value & 0x800000) != 0) {
/*  786 */       value |= 0xFF000000;
/*      */     }
/*  788 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public int readUnsignedMedium() {
/*  793 */     checkReadableBytes0(3);
/*  794 */     int v = _getUnsignedMedium(this.readerIndex);
/*  795 */     this.readerIndex += 3;
/*  796 */     return v;
/*      */   }
/*      */ 
/*      */   
/*      */   public int readUnsignedMediumLE() {
/*  801 */     checkReadableBytes0(3);
/*  802 */     int v = _getUnsignedMediumLE(this.readerIndex);
/*  803 */     this.readerIndex += 3;
/*  804 */     return v;
/*      */   }
/*      */ 
/*      */   
/*      */   public int readInt() {
/*  809 */     checkReadableBytes0(4);
/*  810 */     int v = _getInt(this.readerIndex);
/*  811 */     this.readerIndex += 4;
/*  812 */     return v;
/*      */   }
/*      */ 
/*      */   
/*      */   public int readIntLE() {
/*  817 */     checkReadableBytes0(4);
/*  818 */     int v = _getIntLE(this.readerIndex);
/*  819 */     this.readerIndex += 4;
/*  820 */     return v;
/*      */   }
/*      */ 
/*      */   
/*      */   public long readUnsignedInt() {
/*  825 */     return readInt() & 0xFFFFFFFFL;
/*      */   }
/*      */ 
/*      */   
/*      */   public long readUnsignedIntLE() {
/*  830 */     return readIntLE() & 0xFFFFFFFFL;
/*      */   }
/*      */ 
/*      */   
/*      */   public long readLong() {
/*  835 */     checkReadableBytes0(8);
/*  836 */     long v = _getLong(this.readerIndex);
/*  837 */     this.readerIndex += 8;
/*  838 */     return v;
/*      */   }
/*      */ 
/*      */   
/*      */   public long readLongLE() {
/*  843 */     checkReadableBytes0(8);
/*  844 */     long v = _getLongLE(this.readerIndex);
/*  845 */     this.readerIndex += 8;
/*  846 */     return v;
/*      */   }
/*      */ 
/*      */   
/*      */   public char readChar() {
/*  851 */     return (char)readShort();
/*      */   }
/*      */ 
/*      */   
/*      */   public float readFloat() {
/*  856 */     return Float.intBitsToFloat(readInt());
/*      */   }
/*      */ 
/*      */   
/*      */   public double readDouble() {
/*  861 */     return Double.longBitsToDouble(readLong());
/*      */   }
/*      */ 
/*      */   
/*      */   public ByteBuf readBytes(int length) {
/*  866 */     checkReadableBytes(length);
/*  867 */     if (length == 0) {
/*  868 */       return Unpooled.EMPTY_BUFFER;
/*      */     }
/*      */     
/*  871 */     ByteBuf buf = alloc().buffer(length, this.maxCapacity);
/*  872 */     buf.writeBytes(this, this.readerIndex, length);
/*  873 */     this.readerIndex += length;
/*  874 */     return buf;
/*      */   }
/*      */ 
/*      */   
/*      */   public ByteBuf readSlice(int length) {
/*  879 */     checkReadableBytes(length);
/*  880 */     ByteBuf slice = slice(this.readerIndex, length);
/*  881 */     this.readerIndex += length;
/*  882 */     return slice;
/*      */   }
/*      */ 
/*      */   
/*      */   public ByteBuf readRetainedSlice(int length) {
/*  887 */     checkReadableBytes(length);
/*  888 */     ByteBuf slice = retainedSlice(this.readerIndex, length);
/*  889 */     this.readerIndex += length;
/*  890 */     return slice;
/*      */   }
/*      */ 
/*      */   
/*      */   public ByteBuf readBytes(byte[] dst, int dstIndex, int length) {
/*  895 */     checkReadableBytes(length);
/*  896 */     getBytes(this.readerIndex, dst, dstIndex, length);
/*  897 */     this.readerIndex += length;
/*  898 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public ByteBuf readBytes(byte[] dst) {
/*  903 */     readBytes(dst, 0, dst.length);
/*  904 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public ByteBuf readBytes(ByteBuf dst) {
/*  909 */     readBytes(dst, dst.writableBytes());
/*  910 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public ByteBuf readBytes(ByteBuf dst, int length) {
/*  915 */     if (checkBounds && 
/*  916 */       length > dst.writableBytes()) {
/*  917 */       throw new IndexOutOfBoundsException(String.format("length(%d) exceeds dst.writableBytes(%d) where dst is: %s", new Object[] {
/*  918 */               Integer.valueOf(length), Integer.valueOf(dst.writableBytes()), dst
/*      */             }));
/*      */     }
/*  921 */     readBytes(dst, dst.writerIndex(), length);
/*  922 */     dst.writerIndex(dst.writerIndex() + length);
/*  923 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public ByteBuf readBytes(ByteBuf dst, int dstIndex, int length) {
/*  928 */     checkReadableBytes(length);
/*  929 */     getBytes(this.readerIndex, dst, dstIndex, length);
/*  930 */     this.readerIndex += length;
/*  931 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public ByteBuf readBytes(ByteBuffer dst) {
/*  936 */     int length = dst.remaining();
/*  937 */     checkReadableBytes(length);
/*  938 */     getBytes(this.readerIndex, dst);
/*  939 */     this.readerIndex += length;
/*  940 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int readBytes(GatheringByteChannel out, int length) throws IOException {
/*  946 */     checkReadableBytes(length);
/*  947 */     int readBytes = getBytes(this.readerIndex, out, length);
/*  948 */     this.readerIndex += readBytes;
/*  949 */     return readBytes;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int readBytes(FileChannel out, long position, int length) throws IOException {
/*  955 */     checkReadableBytes(length);
/*  956 */     int readBytes = getBytes(this.readerIndex, out, position, length);
/*  957 */     this.readerIndex += readBytes;
/*  958 */     return readBytes;
/*      */   }
/*      */ 
/*      */   
/*      */   public ByteBuf readBytes(OutputStream out, int length) throws IOException {
/*  963 */     checkReadableBytes(length);
/*  964 */     getBytes(this.readerIndex, out, length);
/*  965 */     this.readerIndex += length;
/*  966 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public ByteBuf skipBytes(int length) {
/*  971 */     checkReadableBytes(length);
/*  972 */     this.readerIndex += length;
/*  973 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public ByteBuf writeBoolean(boolean value) {
/*  978 */     writeByte(value ? 1 : 0);
/*  979 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public ByteBuf writeByte(int value) {
/*  984 */     ensureWritable0(1);
/*  985 */     _setByte(this.writerIndex++, value);
/*  986 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public ByteBuf writeShort(int value) {
/*  991 */     ensureWritable0(2);
/*  992 */     _setShort(this.writerIndex, value);
/*  993 */     this.writerIndex += 2;
/*  994 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public ByteBuf writeShortLE(int value) {
/*  999 */     ensureWritable0(2);
/* 1000 */     _setShortLE(this.writerIndex, value);
/* 1001 */     this.writerIndex += 2;
/* 1002 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public ByteBuf writeMedium(int value) {
/* 1007 */     ensureWritable0(3);
/* 1008 */     _setMedium(this.writerIndex, value);
/* 1009 */     this.writerIndex += 3;
/* 1010 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public ByteBuf writeMediumLE(int value) {
/* 1015 */     ensureWritable0(3);
/* 1016 */     _setMediumLE(this.writerIndex, value);
/* 1017 */     this.writerIndex += 3;
/* 1018 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public ByteBuf writeInt(int value) {
/* 1023 */     ensureWritable0(4);
/* 1024 */     _setInt(this.writerIndex, value);
/* 1025 */     this.writerIndex += 4;
/* 1026 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public ByteBuf writeIntLE(int value) {
/* 1031 */     ensureWritable0(4);
/* 1032 */     _setIntLE(this.writerIndex, value);
/* 1033 */     this.writerIndex += 4;
/* 1034 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public ByteBuf writeLong(long value) {
/* 1039 */     ensureWritable0(8);
/* 1040 */     _setLong(this.writerIndex, value);
/* 1041 */     this.writerIndex += 8;
/* 1042 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public ByteBuf writeLongLE(long value) {
/* 1047 */     ensureWritable0(8);
/* 1048 */     _setLongLE(this.writerIndex, value);
/* 1049 */     this.writerIndex += 8;
/* 1050 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public ByteBuf writeChar(int value) {
/* 1055 */     writeShort(value);
/* 1056 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public ByteBuf writeFloat(float value) {
/* 1061 */     writeInt(Float.floatToRawIntBits(value));
/* 1062 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public ByteBuf writeDouble(double value) {
/* 1067 */     writeLong(Double.doubleToRawLongBits(value));
/* 1068 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public ByteBuf writeBytes(byte[] src, int srcIndex, int length) {
/* 1073 */     ensureWritable(length);
/* 1074 */     setBytes(this.writerIndex, src, srcIndex, length);
/* 1075 */     this.writerIndex += length;
/* 1076 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public ByteBuf writeBytes(byte[] src) {
/* 1081 */     writeBytes(src, 0, src.length);
/* 1082 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public ByteBuf writeBytes(ByteBuf src) {
/* 1087 */     writeBytes(src, src.readableBytes());
/* 1088 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public ByteBuf writeBytes(ByteBuf src, int length) {
/* 1093 */     if (checkBounds) {
/* 1094 */       checkReadableBounds(src, length);
/*      */     }
/* 1096 */     writeBytes(src, src.readerIndex(), length);
/* 1097 */     src.readerIndex(src.readerIndex() + length);
/* 1098 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public ByteBuf writeBytes(ByteBuf src, int srcIndex, int length) {
/* 1103 */     ensureWritable(length);
/* 1104 */     setBytes(this.writerIndex, src, srcIndex, length);
/* 1105 */     this.writerIndex += length;
/* 1106 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public ByteBuf writeBytes(ByteBuffer src) {
/* 1111 */     int length = src.remaining();
/* 1112 */     ensureWritable0(length);
/* 1113 */     setBytes(this.writerIndex, src);
/* 1114 */     this.writerIndex += length;
/* 1115 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int writeBytes(InputStream in, int length) throws IOException {
/* 1121 */     ensureWritable(length);
/* 1122 */     int writtenBytes = setBytes(this.writerIndex, in, length);
/* 1123 */     if (writtenBytes > 0) {
/* 1124 */       this.writerIndex += writtenBytes;
/*      */     }
/* 1126 */     return writtenBytes;
/*      */   }
/*      */ 
/*      */   
/*      */   public int writeBytes(ScatteringByteChannel in, int length) throws IOException {
/* 1131 */     ensureWritable(length);
/* 1132 */     int writtenBytes = setBytes(this.writerIndex, in, length);
/* 1133 */     if (writtenBytes > 0) {
/* 1134 */       this.writerIndex += writtenBytes;
/*      */     }
/* 1136 */     return writtenBytes;
/*      */   }
/*      */ 
/*      */   
/*      */   public int writeBytes(FileChannel in, long position, int length) throws IOException {
/* 1141 */     ensureWritable(length);
/* 1142 */     int writtenBytes = setBytes(this.writerIndex, in, position, length);
/* 1143 */     if (writtenBytes > 0) {
/* 1144 */       this.writerIndex += writtenBytes;
/*      */     }
/* 1146 */     return writtenBytes;
/*      */   }
/*      */ 
/*      */   
/*      */   public ByteBuf writeZero(int length) {
/* 1151 */     if (length == 0) {
/* 1152 */       return this;
/*      */     }
/*      */     
/* 1155 */     ensureWritable(length);
/* 1156 */     int wIndex = this.writerIndex;
/* 1157 */     checkIndex0(wIndex, length);
/*      */     
/* 1159 */     int nLong = length >>> 3;
/* 1160 */     int nBytes = length & 0x7; int i;
/* 1161 */     for (i = nLong; i > 0; i--) {
/* 1162 */       _setLong(wIndex, 0L);
/* 1163 */       wIndex += 8;
/*      */     } 
/* 1165 */     if (nBytes == 4) {
/* 1166 */       _setInt(wIndex, 0);
/* 1167 */       wIndex += 4;
/* 1168 */     } else if (nBytes < 4) {
/* 1169 */       for (i = nBytes; i > 0; i--) {
/* 1170 */         _setByte(wIndex, 0);
/* 1171 */         wIndex++;
/*      */       } 
/*      */     } else {
/* 1174 */       _setInt(wIndex, 0);
/* 1175 */       wIndex += 4;
/* 1176 */       for (i = nBytes - 4; i > 0; i--) {
/* 1177 */         _setByte(wIndex, 0);
/* 1178 */         wIndex++;
/*      */       } 
/*      */     } 
/* 1181 */     this.writerIndex = wIndex;
/* 1182 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public int writeCharSequence(CharSequence sequence, Charset charset) {
/* 1187 */     int written = setCharSequence0(this.writerIndex, sequence, charset, true);
/* 1188 */     this.writerIndex += written;
/* 1189 */     return written;
/*      */   }
/*      */ 
/*      */   
/*      */   public ByteBuf copy() {
/* 1194 */     return copy(this.readerIndex, readableBytes());
/*      */   }
/*      */ 
/*      */   
/*      */   public ByteBuf duplicate() {
/* 1199 */     ensureAccessible();
/* 1200 */     return new UnpooledDuplicatedByteBuf(this);
/*      */   }
/*      */ 
/*      */   
/*      */   public ByteBuf retainedDuplicate() {
/* 1205 */     return duplicate().retain();
/*      */   }
/*      */ 
/*      */   
/*      */   public ByteBuf slice() {
/* 1210 */     return slice(this.readerIndex, readableBytes());
/*      */   }
/*      */ 
/*      */   
/*      */   public ByteBuf retainedSlice() {
/* 1215 */     return slice().retain();
/*      */   }
/*      */ 
/*      */   
/*      */   public ByteBuf slice(int index, int length) {
/* 1220 */     ensureAccessible();
/* 1221 */     return new UnpooledSlicedByteBuf(this, index, length);
/*      */   }
/*      */ 
/*      */   
/*      */   public ByteBuf retainedSlice(int index, int length) {
/* 1226 */     return slice(index, length).retain();
/*      */   }
/*      */ 
/*      */   
/*      */   public ByteBuffer nioBuffer() {
/* 1231 */     return nioBuffer(this.readerIndex, readableBytes());
/*      */   }
/*      */ 
/*      */   
/*      */   public ByteBuffer[] nioBuffers() {
/* 1236 */     return nioBuffers(this.readerIndex, readableBytes());
/*      */   }
/*      */ 
/*      */   
/*      */   public String toString(Charset charset) {
/* 1241 */     return toString(this.readerIndex, readableBytes(), charset);
/*      */   }
/*      */ 
/*      */   
/*      */   public String toString(int index, int length, Charset charset) {
/* 1246 */     return ByteBufUtil.decodeString(this, index, length, charset);
/*      */   }
/*      */ 
/*      */   
/*      */   public int indexOf(int fromIndex, int toIndex, byte value) {
/* 1251 */     if (fromIndex <= toIndex) {
/* 1252 */       return ByteBufUtil.firstIndexOf(this, fromIndex, toIndex, value);
/*      */     }
/* 1254 */     return ByteBufUtil.lastIndexOf(this, fromIndex, toIndex, value);
/*      */   }
/*      */ 
/*      */   
/*      */   public int bytesBefore(byte value) {
/* 1259 */     return bytesBefore(readerIndex(), readableBytes(), value);
/*      */   }
/*      */ 
/*      */   
/*      */   public int bytesBefore(int length, byte value) {
/* 1264 */     checkReadableBytes(length);
/* 1265 */     return bytesBefore(readerIndex(), length, value);
/*      */   }
/*      */ 
/*      */   
/*      */   public int bytesBefore(int index, int length, byte value) {
/* 1270 */     int endIndex = indexOf(index, index + length, value);
/* 1271 */     if (endIndex < 0) {
/* 1272 */       return -1;
/*      */     }
/* 1274 */     return endIndex - index;
/*      */   }
/*      */ 
/*      */   
/*      */   public int forEachByte(ByteProcessor processor) {
/* 1279 */     ensureAccessible();
/*      */     try {
/* 1281 */       return forEachByteAsc0(this.readerIndex, this.writerIndex, processor);
/* 1282 */     } catch (Exception e) {
/* 1283 */       PlatformDependent.throwException(e);
/* 1284 */       return -1;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public int forEachByte(int index, int length, ByteProcessor processor) {
/* 1290 */     checkIndex(index, length);
/*      */     try {
/* 1292 */       return forEachByteAsc0(index, index + length, processor);
/* 1293 */     } catch (Exception e) {
/* 1294 */       PlatformDependent.throwException(e);
/* 1295 */       return -1;
/*      */     } 
/*      */   }
/*      */   
/*      */   int forEachByteAsc0(int start, int end, ByteProcessor processor) throws Exception {
/* 1300 */     for (; start < end; start++) {
/* 1301 */       if (!processor.process(_getByte(start))) {
/* 1302 */         return start;
/*      */       }
/*      */     } 
/*      */     
/* 1306 */     return -1;
/*      */   }
/*      */ 
/*      */   
/*      */   public int forEachByteDesc(ByteProcessor processor) {
/* 1311 */     ensureAccessible();
/*      */     try {
/* 1313 */       return forEachByteDesc0(this.writerIndex - 1, this.readerIndex, processor);
/* 1314 */     } catch (Exception e) {
/* 1315 */       PlatformDependent.throwException(e);
/* 1316 */       return -1;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public int forEachByteDesc(int index, int length, ByteProcessor processor) {
/* 1322 */     checkIndex(index, length);
/*      */     try {
/* 1324 */       return forEachByteDesc0(index + length - 1, index, processor);
/* 1325 */     } catch (Exception e) {
/* 1326 */       PlatformDependent.throwException(e);
/* 1327 */       return -1;
/*      */     } 
/*      */   }
/*      */   
/*      */   int forEachByteDesc0(int rStart, int rEnd, ByteProcessor processor) throws Exception {
/* 1332 */     for (; rStart >= rEnd; rStart--) {
/* 1333 */       if (!processor.process(_getByte(rStart))) {
/* 1334 */         return rStart;
/*      */       }
/*      */     } 
/* 1337 */     return -1;
/*      */   }
/*      */ 
/*      */   
/*      */   public int hashCode() {
/* 1342 */     return ByteBufUtil.hashCode(this);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean equals(Object o) {
/* 1347 */     return (o instanceof ByteBuf && ByteBufUtil.equals(this, (ByteBuf)o));
/*      */   }
/*      */ 
/*      */   
/*      */   public int compareTo(ByteBuf that) {
/* 1352 */     return ByteBufUtil.compare(this, that);
/*      */   }
/*      */ 
/*      */   
/*      */   public String toString() {
/* 1357 */     if (refCnt() == 0) {
/* 1358 */       return StringUtil.simpleClassName(this) + "(freed)";
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1365 */     StringBuilder buf = (new StringBuilder()).append(StringUtil.simpleClassName(this)).append("(ridx: ").append(this.readerIndex).append(", widx: ").append(this.writerIndex).append(", cap: ").append(capacity());
/* 1366 */     if (this.maxCapacity != Integer.MAX_VALUE) {
/* 1367 */       buf.append('/').append(this.maxCapacity);
/*      */     }
/*      */     
/* 1370 */     ByteBuf unwrapped = unwrap();
/* 1371 */     if (unwrapped != null) {
/* 1372 */       buf.append(", unwrapped: ").append(unwrapped);
/*      */     }
/* 1374 */     buf.append(')');
/* 1375 */     return buf.toString();
/*      */   }
/*      */   
/*      */   protected final void checkIndex(int index) {
/* 1379 */     checkIndex(index, 1);
/*      */   }
/*      */   
/*      */   protected final void checkIndex(int index, int fieldLength) {
/* 1383 */     ensureAccessible();
/* 1384 */     checkIndex0(index, fieldLength);
/*      */   }
/*      */ 
/*      */   
/*      */   private static void checkRangeBounds(String indexName, int index, int fieldLength, int capacity) {
/* 1389 */     if (MathUtil.isOutOfBounds(index, fieldLength, capacity)) {
/* 1390 */       throw new IndexOutOfBoundsException(String.format("%s: %d, length: %d (expected: range(0, %d))", new Object[] { indexName, 
/* 1391 */               Integer.valueOf(index), Integer.valueOf(fieldLength), Integer.valueOf(capacity) }));
/*      */     }
/*      */   }
/*      */   
/*      */   final void checkIndex0(int index, int fieldLength) {
/* 1396 */     if (checkBounds) {
/* 1397 */       checkRangeBounds("index", index, fieldLength, capacity());
/*      */     }
/*      */   }
/*      */   
/*      */   protected final void checkSrcIndex(int index, int length, int srcIndex, int srcCapacity) {
/* 1402 */     checkIndex(index, length);
/* 1403 */     if (checkBounds) {
/* 1404 */       checkRangeBounds("srcIndex", srcIndex, length, srcCapacity);
/*      */     }
/*      */   }
/*      */   
/*      */   protected final void checkDstIndex(int index, int length, int dstIndex, int dstCapacity) {
/* 1409 */     checkIndex(index, length);
/* 1410 */     if (checkBounds) {
/* 1411 */       checkRangeBounds("dstIndex", dstIndex, length, dstCapacity);
/*      */     }
/*      */   }
/*      */   
/*      */   protected final void checkDstIndex(int length, int dstIndex, int dstCapacity) {
/* 1416 */     checkReadableBytes(length);
/* 1417 */     if (checkBounds) {
/* 1418 */       checkRangeBounds("dstIndex", dstIndex, length, dstCapacity);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void checkReadableBytes(int minimumReadableBytes) {
/* 1428 */     checkReadableBytes0(ObjectUtil.checkPositiveOrZero(minimumReadableBytes, "minimumReadableBytes"));
/*      */   }
/*      */   
/*      */   protected final void checkNewCapacity(int newCapacity) {
/* 1432 */     ensureAccessible();
/* 1433 */     if (checkBounds && (newCapacity < 0 || newCapacity > maxCapacity())) {
/* 1434 */       throw new IllegalArgumentException("newCapacity: " + newCapacity + " (expected: 0-" + 
/* 1435 */           maxCapacity() + ')');
/*      */     }
/*      */   }
/*      */   
/*      */   private void checkReadableBytes0(int minimumReadableBytes) {
/* 1440 */     ensureAccessible();
/* 1441 */     if (checkBounds && this.readerIndex > this.writerIndex - minimumReadableBytes) {
/* 1442 */       throw new IndexOutOfBoundsException(String.format("readerIndex(%d) + length(%d) exceeds writerIndex(%d): %s", new Object[] {
/*      */               
/* 1444 */               Integer.valueOf(this.readerIndex), Integer.valueOf(minimumReadableBytes), Integer.valueOf(this.writerIndex), this
/*      */             }));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void ensureAccessible() {
/* 1453 */     if (checkAccessible && !isAccessible()) {
/* 1454 */       throw new IllegalReferenceCountException(0);
/*      */     }
/*      */   }
/*      */   
/*      */   final void setIndex0(int readerIndex, int writerIndex) {
/* 1459 */     this.readerIndex = readerIndex;
/* 1460 */     this.writerIndex = writerIndex;
/*      */   }
/*      */   
/*      */   final void discardMarks() {
/* 1464 */     this.markedReaderIndex = this.markedWriterIndex = 0;
/*      */   }
/*      */   
/*      */   protected abstract byte _getByte(int paramInt);
/*      */   
/*      */   protected abstract short _getShort(int paramInt);
/*      */   
/*      */   protected abstract short _getShortLE(int paramInt);
/*      */   
/*      */   protected abstract int _getUnsignedMedium(int paramInt);
/*      */   
/*      */   protected abstract int _getUnsignedMediumLE(int paramInt);
/*      */   
/*      */   protected abstract int _getInt(int paramInt);
/*      */   
/*      */   protected abstract int _getIntLE(int paramInt);
/*      */   
/*      */   protected abstract long _getLong(int paramInt);
/*      */   
/*      */   protected abstract long _getLongLE(int paramInt);
/*      */   
/*      */   protected abstract void _setByte(int paramInt1, int paramInt2);
/*      */   
/*      */   protected abstract void _setShort(int paramInt1, int paramInt2);
/*      */   
/*      */   protected abstract void _setShortLE(int paramInt1, int paramInt2);
/*      */   
/*      */   protected abstract void _setMedium(int paramInt1, int paramInt2);
/*      */   
/*      */   protected abstract void _setMediumLE(int paramInt1, int paramInt2);
/*      */   
/*      */   protected abstract void _setInt(int paramInt1, int paramInt2);
/*      */   
/*      */   protected abstract void _setIntLE(int paramInt1, int paramInt2);
/*      */   
/*      */   protected abstract void _setLong(int paramInt, long paramLong);
/*      */   
/*      */   protected abstract void _setLongLE(int paramInt, long paramLong);
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-buffer-4.1.93.Final.jar!\io\netty\buffer\AbstractByteBuf.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */