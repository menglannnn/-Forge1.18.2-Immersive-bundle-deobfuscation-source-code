package io.netty.buffer;

public interface ByteBufAllocatorMetric {
  long usedHeapMemory();
  
  long usedDirectMemory();
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-buffer-4.1.93.Final.jar!\io\netty\buffer\ByteBufAllocatorMetric.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */