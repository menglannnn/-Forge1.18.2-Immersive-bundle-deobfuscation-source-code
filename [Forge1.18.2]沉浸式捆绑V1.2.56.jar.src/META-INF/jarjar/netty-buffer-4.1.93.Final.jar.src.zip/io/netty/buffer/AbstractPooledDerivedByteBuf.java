/*     */ package io.netty.buffer;
/*     */ 
/*     */ import io.netty.util.Recycler;
/*     */ import io.netty.util.internal.ObjectPool;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.ByteOrder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class AbstractPooledDerivedByteBuf
/*     */   extends AbstractReferenceCountedByteBuf
/*     */ {
/*     */   private final Recycler.EnhancedHandle<AbstractPooledDerivedByteBuf> recyclerHandle;
/*     */   private AbstractByteBuf rootParent;
/*     */   private ByteBuf parent;
/*     */   
/*     */   AbstractPooledDerivedByteBuf(ObjectPool.Handle<? extends AbstractPooledDerivedByteBuf> recyclerHandle) {
/*  42 */     super(0);
/*  43 */     this.recyclerHandle = (Recycler.EnhancedHandle)recyclerHandle;
/*     */   }
/*     */ 
/*     */   
/*     */   final void parent(ByteBuf newParent) {
/*  48 */     assert newParent instanceof SimpleLeakAwareByteBuf;
/*  49 */     this.parent = newParent;
/*     */   }
/*     */ 
/*     */   
/*     */   public final AbstractByteBuf unwrap() {
/*  54 */     return this.rootParent;
/*     */   }
/*     */ 
/*     */   
/*     */   final <U extends AbstractPooledDerivedByteBuf> U init(AbstractByteBuf unwrapped, ByteBuf wrapped, int readerIndex, int writerIndex, int maxCapacity) {
/*  59 */     wrapped.retain();
/*  60 */     this.parent = wrapped;
/*  61 */     this.rootParent = unwrapped;
/*     */     
/*     */     try {
/*  64 */       maxCapacity(maxCapacity);
/*  65 */       setIndex0(readerIndex, writerIndex);
/*  66 */       resetRefCnt();
/*     */ 
/*     */       
/*  69 */       AbstractPooledDerivedByteBuf abstractPooledDerivedByteBuf = this;
/*  70 */       wrapped = null;
/*  71 */       return (U)abstractPooledDerivedByteBuf;
/*     */     } finally {
/*  73 */       if (wrapped != null) {
/*  74 */         this.parent = this.rootParent = null;
/*  75 */         wrapped.release();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void deallocate() {
/*  85 */     ByteBuf parent = this.parent;
/*  86 */     this.recyclerHandle.unguardedRecycle(this);
/*  87 */     parent.release();
/*     */   }
/*     */ 
/*     */   
/*     */   public final ByteBufAllocator alloc() {
/*  92 */     return unwrap().alloc();
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public final ByteOrder order() {
/*  98 */     return unwrap().order();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isReadOnly() {
/* 103 */     return unwrap().isReadOnly();
/*     */   }
/*     */ 
/*     */   
/*     */   public final boolean isDirect() {
/* 108 */     return unwrap().isDirect();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasArray() {
/* 113 */     return unwrap().hasArray();
/*     */   }
/*     */ 
/*     */   
/*     */   public byte[] array() {
/* 118 */     return unwrap().array();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasMemoryAddress() {
/* 123 */     return unwrap().hasMemoryAddress();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isContiguous() {
/* 128 */     return unwrap().isContiguous();
/*     */   }
/*     */ 
/*     */   
/*     */   public final int nioBufferCount() {
/* 133 */     return unwrap().nioBufferCount();
/*     */   }
/*     */ 
/*     */   
/*     */   public final ByteBuffer internalNioBuffer(int index, int length) {
/* 138 */     return nioBuffer(index, length);
/*     */   }
/*     */ 
/*     */   
/*     */   public final ByteBuf retainedSlice() {
/* 143 */     int index = readerIndex();
/* 144 */     return retainedSlice(index, writerIndex() - index);
/*     */   }
/*     */ 
/*     */   
/*     */   public ByteBuf slice(int index, int length) {
/* 149 */     ensureAccessible();
/*     */     
/* 151 */     return new PooledNonRetainedSlicedByteBuf(this, unwrap(), index, length);
/*     */   }
/*     */   
/*     */   final ByteBuf duplicate0() {
/* 155 */     ensureAccessible();
/*     */     
/* 157 */     return new PooledNonRetainedDuplicateByteBuf(this, unwrap());
/*     */   }
/*     */   
/*     */   private static final class PooledNonRetainedDuplicateByteBuf extends UnpooledDuplicatedByteBuf {
/*     */     private final ByteBuf referenceCountDelegate;
/*     */     
/*     */     PooledNonRetainedDuplicateByteBuf(ByteBuf referenceCountDelegate, AbstractByteBuf buffer) {
/* 164 */       super(buffer);
/* 165 */       this.referenceCountDelegate = referenceCountDelegate;
/*     */     }
/*     */ 
/*     */     
/*     */     boolean isAccessible0() {
/* 170 */       return this.referenceCountDelegate.isAccessible();
/*     */     }
/*     */ 
/*     */     
/*     */     int refCnt0() {
/* 175 */       return this.referenceCountDelegate.refCnt();
/*     */     }
/*     */ 
/*     */     
/*     */     ByteBuf retain0() {
/* 180 */       this.referenceCountDelegate.retain();
/* 181 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     ByteBuf retain0(int increment) {
/* 186 */       this.referenceCountDelegate.retain(increment);
/* 187 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     ByteBuf touch0() {
/* 192 */       this.referenceCountDelegate.touch();
/* 193 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     ByteBuf touch0(Object hint) {
/* 198 */       this.referenceCountDelegate.touch(hint);
/* 199 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     boolean release0() {
/* 204 */       return this.referenceCountDelegate.release();
/*     */     }
/*     */ 
/*     */     
/*     */     boolean release0(int decrement) {
/* 209 */       return this.referenceCountDelegate.release(decrement);
/*     */     }
/*     */ 
/*     */     
/*     */     public ByteBuf duplicate() {
/* 214 */       ensureAccessible();
/* 215 */       return new PooledNonRetainedDuplicateByteBuf(this.referenceCountDelegate, this);
/*     */     }
/*     */ 
/*     */     
/*     */     public ByteBuf retainedDuplicate() {
/* 220 */       return PooledDuplicatedByteBuf.newInstance(unwrap(), this, readerIndex(), writerIndex());
/*     */     }
/*     */ 
/*     */     
/*     */     public ByteBuf slice(int index, int length) {
/* 225 */       checkIndex(index, length);
/* 226 */       return new AbstractPooledDerivedByteBuf.PooledNonRetainedSlicedByteBuf(this.referenceCountDelegate, unwrap(), index, length);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public ByteBuf retainedSlice() {
/* 232 */       return retainedSlice(readerIndex(), capacity());
/*     */     }
/*     */ 
/*     */     
/*     */     public ByteBuf retainedSlice(int index, int length) {
/* 237 */       return PooledSlicedByteBuf.newInstance(unwrap(), this, index, length);
/*     */     }
/*     */   }
/*     */   
/*     */   private static final class PooledNonRetainedSlicedByteBuf
/*     */     extends UnpooledSlicedByteBuf {
/*     */     private final ByteBuf referenceCountDelegate;
/*     */     
/*     */     PooledNonRetainedSlicedByteBuf(ByteBuf referenceCountDelegate, AbstractByteBuf buffer, int index, int length) {
/* 246 */       super(buffer, index, length);
/* 247 */       this.referenceCountDelegate = referenceCountDelegate;
/*     */     }
/*     */ 
/*     */     
/*     */     boolean isAccessible0() {
/* 252 */       return this.referenceCountDelegate.isAccessible();
/*     */     }
/*     */ 
/*     */     
/*     */     int refCnt0() {
/* 257 */       return this.referenceCountDelegate.refCnt();
/*     */     }
/*     */ 
/*     */     
/*     */     ByteBuf retain0() {
/* 262 */       this.referenceCountDelegate.retain();
/* 263 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     ByteBuf retain0(int increment) {
/* 268 */       this.referenceCountDelegate.retain(increment);
/* 269 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     ByteBuf touch0() {
/* 274 */       this.referenceCountDelegate.touch();
/* 275 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     ByteBuf touch0(Object hint) {
/* 280 */       this.referenceCountDelegate.touch(hint);
/* 281 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     boolean release0() {
/* 286 */       return this.referenceCountDelegate.release();
/*     */     }
/*     */ 
/*     */     
/*     */     boolean release0(int decrement) {
/* 291 */       return this.referenceCountDelegate.release(decrement);
/*     */     }
/*     */ 
/*     */     
/*     */     public ByteBuf duplicate() {
/* 296 */       ensureAccessible();
/* 297 */       return (new AbstractPooledDerivedByteBuf.PooledNonRetainedDuplicateByteBuf(this.referenceCountDelegate, unwrap()))
/* 298 */         .setIndex(idx(readerIndex()), idx(writerIndex()));
/*     */     }
/*     */ 
/*     */     
/*     */     public ByteBuf retainedDuplicate() {
/* 303 */       return PooledDuplicatedByteBuf.newInstance(unwrap(), this, idx(readerIndex()), idx(writerIndex()));
/*     */     }
/*     */ 
/*     */     
/*     */     public ByteBuf slice(int index, int length) {
/* 308 */       checkIndex(index, length);
/* 309 */       return new PooledNonRetainedSlicedByteBuf(this.referenceCountDelegate, unwrap(), idx(index), length);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public ByteBuf retainedSlice() {
/* 315 */       return retainedSlice(0, capacity());
/*     */     }
/*     */ 
/*     */     
/*     */     public ByteBuf retainedSlice(int index, int length) {
/* 320 */       return PooledSlicedByteBuf.newInstance(unwrap(), this, idx(index), length);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-buffer-4.1.93.Final.jar!\io\netty\buffer\AbstractPooledDerivedByteBuf.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */