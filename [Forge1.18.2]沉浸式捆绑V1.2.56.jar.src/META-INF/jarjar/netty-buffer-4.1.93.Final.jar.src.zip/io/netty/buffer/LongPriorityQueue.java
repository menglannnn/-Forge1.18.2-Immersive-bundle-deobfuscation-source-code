/*     */ package io.netty.buffer;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class LongPriorityQueue
/*     */ {
/*     */   public static final int NO_VALUE = -1;
/*  26 */   private long[] array = new long[9];
/*     */   private int size;
/*     */   
/*     */   public void offer(long handle) {
/*  30 */     if (handle == -1L) {
/*  31 */       throw new IllegalArgumentException("The NO_VALUE (-1) cannot be added to the queue.");
/*     */     }
/*  33 */     this.size++;
/*  34 */     if (this.size == this.array.length)
/*     */     {
/*  36 */       this.array = Arrays.copyOf(this.array, 1 + (this.array.length - 1) * 2);
/*     */     }
/*  38 */     this.array[this.size] = handle;
/*  39 */     lift(this.size);
/*     */   }
/*     */   
/*     */   public void remove(long value) {
/*  43 */     for (int i = 1; i <= this.size; i++) {
/*  44 */       if (this.array[i] == value) {
/*  45 */         this.array[i] = this.array[this.size--];
/*  46 */         lift(i);
/*  47 */         sink(i);
/*     */         return;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public long peek() {
/*  54 */     if (this.size == 0) {
/*  55 */       return -1L;
/*     */     }
/*  57 */     return this.array[1];
/*     */   }
/*     */   
/*     */   public long poll() {
/*  61 */     if (this.size == 0) {
/*  62 */       return -1L;
/*     */     }
/*  64 */     long val = this.array[1];
/*  65 */     this.array[1] = this.array[this.size];
/*  66 */     this.array[this.size] = 0L;
/*  67 */     this.size--;
/*  68 */     sink(1);
/*  69 */     return val;
/*     */   }
/*     */   
/*     */   public boolean isEmpty() {
/*  73 */     return (this.size == 0);
/*     */   }
/*     */   
/*     */   private void lift(int index) {
/*     */     int parentIndex;
/*  78 */     while (index > 1 && subord(parentIndex = index >> 1, index)) {
/*  79 */       swap(index, parentIndex);
/*  80 */       index = parentIndex;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void sink(int index) {
/*     */     int child;
/*  86 */     while ((child = index << 1) <= this.size) {
/*  87 */       if (child < this.size && subord(child, child + 1)) {
/*  88 */         child++;
/*     */       }
/*  90 */       if (!subord(index, child)) {
/*     */         break;
/*     */       }
/*  93 */       swap(index, child);
/*  94 */       index = child;
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean subord(int a, int b) {
/*  99 */     return (this.array[a] > this.array[b]);
/*     */   }
/*     */   
/*     */   private void swap(int a, int b) {
/* 103 */     long value = this.array[a];
/* 104 */     this.array[a] = this.array[b];
/* 105 */     this.array[b] = value;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-buffer-4.1.93.Final.jar!\io\netty\buffer\LongPriorityQueue.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */