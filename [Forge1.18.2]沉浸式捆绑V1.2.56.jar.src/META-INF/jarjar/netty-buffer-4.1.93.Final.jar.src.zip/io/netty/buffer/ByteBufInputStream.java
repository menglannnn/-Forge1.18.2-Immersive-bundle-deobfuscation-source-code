/*     */ package io.netty.buffer;
/*     */ 
/*     */ import io.netty.util.internal.ObjectUtil;
/*     */ import java.io.DataInput;
/*     */ import java.io.DataInputStream;
/*     */ import java.io.EOFException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ByteBufInputStream
/*     */   extends InputStream
/*     */   implements DataInput
/*     */ {
/*     */   private final ByteBuf buffer;
/*     */   private final int startIndex;
/*     */   private final int endIndex;
/*     */   private boolean closed;
/*     */   private final boolean releaseOnClose;
/*     */   private StringBuilder lineBuf;
/*     */   
/*     */   public ByteBufInputStream(ByteBuf buffer) {
/*  66 */     this(buffer, buffer.readableBytes());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ByteBufInputStream(ByteBuf buffer, int length) {
/*  80 */     this(buffer, length, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ByteBufInputStream(ByteBuf buffer, boolean releaseOnClose) {
/*  92 */     this(buffer, buffer.readableBytes(), releaseOnClose);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ByteBufInputStream(ByteBuf buffer, int length, boolean releaseOnClose) {
/* 108 */     ObjectUtil.checkNotNull(buffer, "buffer");
/* 109 */     if (length < 0) {
/* 110 */       if (releaseOnClose) {
/* 111 */         buffer.release();
/*     */       }
/* 113 */       ObjectUtil.checkPositiveOrZero(length, "length");
/*     */     } 
/* 115 */     if (length > buffer.readableBytes()) {
/* 116 */       if (releaseOnClose) {
/* 117 */         buffer.release();
/*     */       }
/* 119 */       throw new IndexOutOfBoundsException("Too many bytes to be read - Needs " + length + ", maximum is " + buffer
/* 120 */           .readableBytes());
/*     */     } 
/*     */     
/* 123 */     this.releaseOnClose = releaseOnClose;
/* 124 */     this.buffer = buffer;
/* 125 */     this.startIndex = buffer.readerIndex();
/* 126 */     this.endIndex = this.startIndex + length;
/* 127 */     buffer.markReaderIndex();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int readBytes() {
/* 134 */     return this.buffer.readerIndex() - this.startIndex;
/*     */   }
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/*     */     try {
/* 140 */       super.close();
/*     */     } finally {
/*     */       
/* 143 */       if (this.releaseOnClose && !this.closed) {
/* 144 */         this.closed = true;
/* 145 */         this.buffer.release();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int available() throws IOException {
/* 152 */     return this.endIndex - this.buffer.readerIndex();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void mark(int readlimit) {
/* 158 */     this.buffer.markReaderIndex();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean markSupported() {
/* 163 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public int read() throws IOException {
/* 168 */     int available = available();
/* 169 */     if (available == 0) {
/* 170 */       return -1;
/*     */     }
/* 172 */     return this.buffer.readByte() & 0xFF;
/*     */   }
/*     */ 
/*     */   
/*     */   public int read(byte[] b, int off, int len) throws IOException {
/* 177 */     int available = available();
/* 178 */     if (available == 0) {
/* 179 */       return -1;
/*     */     }
/*     */     
/* 182 */     len = Math.min(available, len);
/* 183 */     this.buffer.readBytes(b, off, len);
/* 184 */     return len;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void reset() throws IOException {
/* 190 */     this.buffer.resetReaderIndex();
/*     */   }
/*     */ 
/*     */   
/*     */   public long skip(long n) throws IOException {
/* 195 */     if (n > 2147483647L) {
/* 196 */       return skipBytes(2147483647);
/*     */     }
/* 198 */     return skipBytes((int)n);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean readBoolean() throws IOException {
/* 204 */     checkAvailable(1);
/* 205 */     return (read() != 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public byte readByte() throws IOException {
/* 210 */     int available = available();
/* 211 */     if (available == 0) {
/* 212 */       throw new EOFException();
/*     */     }
/* 214 */     return this.buffer.readByte();
/*     */   }
/*     */ 
/*     */   
/*     */   public char readChar() throws IOException {
/* 219 */     return (char)readShort();
/*     */   }
/*     */ 
/*     */   
/*     */   public double readDouble() throws IOException {
/* 224 */     return Double.longBitsToDouble(readLong());
/*     */   }
/*     */ 
/*     */   
/*     */   public float readFloat() throws IOException {
/* 229 */     return Float.intBitsToFloat(readInt());
/*     */   }
/*     */ 
/*     */   
/*     */   public void readFully(byte[] b) throws IOException {
/* 234 */     readFully(b, 0, b.length);
/*     */   }
/*     */ 
/*     */   
/*     */   public void readFully(byte[] b, int off, int len) throws IOException {
/* 239 */     checkAvailable(len);
/* 240 */     this.buffer.readBytes(b, off, len);
/*     */   }
/*     */ 
/*     */   
/*     */   public int readInt() throws IOException {
/* 245 */     checkAvailable(4);
/* 246 */     return this.buffer.readInt();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String readLine() throws IOException {
/* 253 */     int available = available();
/* 254 */     if (available == 0) {
/* 255 */       return null;
/*     */     }
/*     */     
/* 258 */     if (this.lineBuf != null) {
/* 259 */       this.lineBuf.setLength(0);
/*     */     }
/*     */     
/*     */     do {
/* 263 */       int c = this.buffer.readUnsignedByte();
/* 264 */       available--;
/* 265 */       switch (c) {
/*     */         case 10:
/*     */           break;
/*     */         
/*     */         case 13:
/* 270 */           if (available > 0 && (char)this.buffer.getUnsignedByte(this.buffer.readerIndex()) == '\n') {
/* 271 */             this.buffer.skipBytes(1);
/* 272 */             available--;
/*     */           } 
/*     */           break;
/*     */       } 
/*     */       
/* 277 */       if (this.lineBuf == null) {
/* 278 */         this.lineBuf = new StringBuilder();
/*     */       }
/* 280 */       this.lineBuf.append((char)c);
/*     */     }
/* 282 */     while (available > 0);
/*     */     
/* 284 */     return (this.lineBuf != null && this.lineBuf.length() > 0) ? this.lineBuf.toString() : "";
/*     */   }
/*     */ 
/*     */   
/*     */   public long readLong() throws IOException {
/* 289 */     checkAvailable(8);
/* 290 */     return this.buffer.readLong();
/*     */   }
/*     */ 
/*     */   
/*     */   public short readShort() throws IOException {
/* 295 */     checkAvailable(2);
/* 296 */     return this.buffer.readShort();
/*     */   }
/*     */ 
/*     */   
/*     */   public String readUTF() throws IOException {
/* 301 */     return DataInputStream.readUTF(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public int readUnsignedByte() throws IOException {
/* 306 */     return readByte() & 0xFF;
/*     */   }
/*     */ 
/*     */   
/*     */   public int readUnsignedShort() throws IOException {
/* 311 */     return readShort() & 0xFFFF;
/*     */   }
/*     */ 
/*     */   
/*     */   public int skipBytes(int n) throws IOException {
/* 316 */     int nBytes = Math.min(available(), n);
/* 317 */     this.buffer.skipBytes(nBytes);
/* 318 */     return nBytes;
/*     */   }
/*     */   
/*     */   private void checkAvailable(int fieldSize) throws IOException {
/* 322 */     if (fieldSize < 0) {
/* 323 */       throw new IndexOutOfBoundsException("fieldSize cannot be a negative number");
/*     */     }
/* 325 */     if (fieldSize > available())
/* 326 */       throw new EOFException("fieldSize is too long! Length is " + fieldSize + ", but maximum is " + 
/* 327 */           available()); 
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-buffer-4.1.93.Final.jar!\io\netty\buffer\ByteBufInputStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */