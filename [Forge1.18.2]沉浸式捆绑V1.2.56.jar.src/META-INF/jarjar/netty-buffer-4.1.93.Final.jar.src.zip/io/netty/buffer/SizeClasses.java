/*     */ package io.netty.buffer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class SizeClasses
/*     */   implements SizeClassesMetric
/*     */ {
/*     */   static final int LOG2_QUANTUM = 4;
/*     */   private static final int LOG2_SIZE_CLASS_GROUP = 2;
/*     */   private static final int LOG2_MAX_LOOKUP_SIZE = 12;
/*     */   private static final int INDEX_IDX = 0;
/*     */   private static final int LOG2GROUP_IDX = 1;
/*     */   private static final int LOG2DELTA_IDX = 2;
/*     */   private static final int NDELTA_IDX = 3;
/*     */   private static final int PAGESIZE_IDX = 4;
/*     */   private static final int SUBPAGE_IDX = 5;
/*     */   private static final int LOG2_DELTA_LOOKUP_IDX = 6;
/*     */   private static final byte no = 0;
/*     */   private static final byte yes = 1;
/*     */   protected final int pageSize;
/*     */   protected final int pageShifts;
/*     */   protected final int chunkSize;
/*     */   protected final int directMemoryCacheAlignment;
/*     */   final int nSizes;
/*     */   final int nSubpages;
/*     */   final int nPSizes;
/*     */   final int lookupMaxSize;
/*     */   final int smallMaxSizeIdx;
/*     */   private final int[] pageIdx2sizeTab;
/*     */   private final int[] sizeIdx2sizeTab;
/*     */   private final int[] size2idxTab;
/*     */   
/*     */   protected SizeClasses(int pageSize, int pageShifts, int chunkSize, int directMemoryCacheAlignment) {
/* 119 */     int group = PoolThreadCache.log2(chunkSize) - 4 - 2 + 1;
/*     */ 
/*     */ 
/*     */     
/* 123 */     short[][] sizeClasses = new short[group << 2][7];
/*     */     
/* 125 */     int normalMaxSize = -1;
/* 126 */     int nSizes = 0;
/* 127 */     int size = 0;
/*     */     
/* 129 */     int log2Group = 4;
/* 130 */     int log2Delta = 4;
/* 131 */     int ndeltaLimit = 4;
/*     */     
/*     */     int nDelta;
/*     */     
/* 135 */     for (nDelta = 0; nDelta < ndeltaLimit; nDelta++, nSizes++) {
/* 136 */       short[] sizeClass = newSizeClass(nSizes, log2Group, log2Delta, nDelta, pageShifts);
/* 137 */       sizeClasses[nSizes] = sizeClass;
/* 138 */       size = sizeOf(sizeClass, directMemoryCacheAlignment);
/*     */     } 
/*     */     
/* 141 */     log2Group += 2;
/*     */ 
/*     */     
/* 144 */     for (; size < chunkSize; log2Group++, log2Delta++) {
/* 145 */       for (nDelta = 1; nDelta <= ndeltaLimit && size < chunkSize; nDelta++, nSizes++) {
/* 146 */         short[] sizeClass = newSizeClass(nSizes, log2Group, log2Delta, nDelta, pageShifts);
/* 147 */         sizeClasses[nSizes] = sizeClass;
/* 148 */         size = normalMaxSize = sizeOf(sizeClass, directMemoryCacheAlignment);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 153 */     assert chunkSize == normalMaxSize;
/*     */     
/* 155 */     int smallMaxSizeIdx = 0;
/* 156 */     int lookupMaxSize = 0;
/* 157 */     int nPSizes = 0;
/* 158 */     int nSubpages = 0;
/* 159 */     for (int idx = 0; idx < nSizes; idx++) {
/* 160 */       short[] sz = sizeClasses[idx];
/* 161 */       if (sz[4] == 1) {
/* 162 */         nPSizes++;
/*     */       }
/* 164 */       if (sz[5] == 1) {
/* 165 */         nSubpages++;
/* 166 */         smallMaxSizeIdx = idx;
/*     */       } 
/* 168 */       if (sz[6] != 0) {
/* 169 */         lookupMaxSize = sizeOf(sz, directMemoryCacheAlignment);
/*     */       }
/*     */     } 
/* 172 */     this.smallMaxSizeIdx = smallMaxSizeIdx;
/* 173 */     this.lookupMaxSize = lookupMaxSize;
/* 174 */     this.nPSizes = nPSizes;
/* 175 */     this.nSubpages = nSubpages;
/* 176 */     this.nSizes = nSizes;
/*     */     
/* 178 */     this.pageSize = pageSize;
/* 179 */     this.pageShifts = pageShifts;
/* 180 */     this.chunkSize = chunkSize;
/* 181 */     this.directMemoryCacheAlignment = directMemoryCacheAlignment;
/*     */ 
/*     */     
/* 184 */     this.sizeIdx2sizeTab = newIdx2SizeTab(sizeClasses, nSizes, directMemoryCacheAlignment);
/* 185 */     this.pageIdx2sizeTab = newPageIdx2sizeTab(sizeClasses, nSizes, nPSizes, directMemoryCacheAlignment);
/* 186 */     this.size2idxTab = newSize2idxTab(lookupMaxSize, sizeClasses);
/*     */   }
/*     */ 
/*     */   
/*     */   private static short[] newSizeClass(int index, int log2Group, int log2Delta, int nDelta, int pageShifts) {
/*     */     short isMultiPageSize;
/* 192 */     if (log2Delta >= pageShifts) {
/* 193 */       isMultiPageSize = 1;
/*     */     } else {
/* 195 */       int pageSize = 1 << pageShifts;
/* 196 */       int size = calculateSize(log2Group, nDelta, log2Delta);
/*     */       
/* 198 */       isMultiPageSize = (size == size / pageSize * pageSize) ? 1 : 0;
/*     */     } 
/*     */     
/* 201 */     int log2Ndelta = (nDelta == 0) ? 0 : PoolThreadCache.log2(nDelta);
/*     */     
/* 203 */     byte remove = (1 << log2Ndelta < nDelta) ? 1 : 0;
/*     */     
/* 205 */     int log2Size = (log2Delta + log2Ndelta == log2Group) ? (log2Group + 1) : log2Group;
/* 206 */     if (log2Size == log2Group) {
/* 207 */       remove = 1;
/*     */     }
/*     */     
/* 210 */     short isSubpage = (log2Size < pageShifts + 2) ? 1 : 0;
/*     */     
/* 212 */     int log2DeltaLookup = (log2Size < 12 || (log2Size == 12 && remove == 0)) ? log2Delta : 0;
/*     */ 
/*     */ 
/*     */     
/* 216 */     return new short[] { (short)index, (short)log2Group, (short)log2Delta, (short)nDelta, isMultiPageSize, isSubpage, (short)log2DeltaLookup };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int[] newIdx2SizeTab(short[][] sizeClasses, int nSizes, int directMemoryCacheAlignment) {
/* 223 */     int[] sizeIdx2sizeTab = new int[nSizes];
/*     */     
/* 225 */     for (int i = 0; i < nSizes; i++) {
/* 226 */       short[] sizeClass = sizeClasses[i];
/* 227 */       sizeIdx2sizeTab[i] = sizeOf(sizeClass, directMemoryCacheAlignment);
/*     */     } 
/* 229 */     return sizeIdx2sizeTab;
/*     */   }
/*     */   
/*     */   private static int calculateSize(int log2Group, int nDelta, int log2Delta) {
/* 233 */     return (1 << log2Group) + (nDelta << log2Delta);
/*     */   }
/*     */   
/*     */   private static int sizeOf(short[] sizeClass, int directMemoryCacheAlignment) {
/* 237 */     int log2Group = sizeClass[1];
/* 238 */     int log2Delta = sizeClass[2];
/* 239 */     int nDelta = sizeClass[3];
/*     */     
/* 241 */     int size = calculateSize(log2Group, nDelta, log2Delta);
/*     */     
/* 243 */     return alignSizeIfNeeded(size, directMemoryCacheAlignment);
/*     */   }
/*     */ 
/*     */   
/*     */   private static int[] newPageIdx2sizeTab(short[][] sizeClasses, int nSizes, int nPSizes, int directMemoryCacheAlignment) {
/* 248 */     int[] pageIdx2sizeTab = new int[nPSizes];
/* 249 */     int pageIdx = 0;
/* 250 */     for (int i = 0; i < nSizes; i++) {
/* 251 */       short[] sizeClass = sizeClasses[i];
/* 252 */       if (sizeClass[4] == 1) {
/* 253 */         pageIdx2sizeTab[pageIdx++] = sizeOf(sizeClass, directMemoryCacheAlignment);
/*     */       }
/*     */     } 
/* 256 */     return pageIdx2sizeTab;
/*     */   }
/*     */   
/*     */   private static int[] newSize2idxTab(int lookupMaxSize, short[][] sizeClasses) {
/* 260 */     int[] size2idxTab = new int[lookupMaxSize >> 4];
/* 261 */     int idx = 0;
/* 262 */     int size = 0;
/*     */     
/* 264 */     for (int i = 0; size <= lookupMaxSize; i++) {
/* 265 */       int log2Delta = sizeClasses[i][2];
/* 266 */       int times = 1 << log2Delta - 4;
/*     */       
/* 268 */       while (size <= lookupMaxSize && times-- > 0) {
/* 269 */         size2idxTab[idx++] = i;
/* 270 */         size = idx + 1 << 4;
/*     */       } 
/*     */     } 
/* 273 */     return size2idxTab;
/*     */   }
/*     */ 
/*     */   
/*     */   public int sizeIdx2size(int sizeIdx) {
/* 278 */     return this.sizeIdx2sizeTab[sizeIdx];
/*     */   }
/*     */ 
/*     */   
/*     */   public int sizeIdx2sizeCompute(int sizeIdx) {
/* 283 */     int group = sizeIdx >> 2;
/* 284 */     int mod = sizeIdx & 0x3;
/*     */     
/* 286 */     int groupSize = (group == 0) ? 0 : (32 << group);
/*     */ 
/*     */     
/* 289 */     int shift = (group == 0) ? 1 : group;
/* 290 */     int lgDelta = shift + 4 - 1;
/* 291 */     int modSize = mod + 1 << lgDelta;
/*     */     
/* 293 */     return groupSize + modSize;
/*     */   }
/*     */ 
/*     */   
/*     */   public long pageIdx2size(int pageIdx) {
/* 298 */     return this.pageIdx2sizeTab[pageIdx];
/*     */   }
/*     */ 
/*     */   
/*     */   public long pageIdx2sizeCompute(int pageIdx) {
/* 303 */     int group = pageIdx >> 2;
/* 304 */     int mod = pageIdx & 0x3;
/*     */     
/* 306 */     long groupSize = (group == 0) ? 0L : (1L << this.pageShifts + 2 - 1 << group);
/*     */ 
/*     */     
/* 309 */     int shift = (group == 0) ? 1 : group;
/* 310 */     int log2Delta = shift + this.pageShifts - 1;
/* 311 */     int modSize = mod + 1 << log2Delta;
/*     */     
/* 313 */     return groupSize + modSize;
/*     */   }
/*     */ 
/*     */   
/*     */   public int size2SizeIdx(int size) {
/* 318 */     if (size == 0) {
/* 319 */       return 0;
/*     */     }
/* 321 */     if (size > this.chunkSize) {
/* 322 */       return this.nSizes;
/*     */     }
/*     */     
/* 325 */     size = alignSizeIfNeeded(size, this.directMemoryCacheAlignment);
/*     */     
/* 327 */     if (size <= this.lookupMaxSize)
/*     */     {
/* 329 */       return this.size2idxTab[size - 1 >> 4];
/*     */     }
/*     */     
/* 332 */     int x = PoolThreadCache.log2((size << 1) - 1);
/* 333 */     int shift = (x < 7) ? 0 : (x - 6);
/*     */ 
/*     */     
/* 336 */     int group = shift << 2;
/*     */     
/* 338 */     int log2Delta = (x < 7) ? 4 : (x - 2 - 1);
/*     */ 
/*     */     
/* 341 */     int mod = size - 1 >> log2Delta & 0x3;
/*     */     
/* 343 */     return group + mod;
/*     */   }
/*     */ 
/*     */   
/*     */   public int pages2pageIdx(int pages) {
/* 348 */     return pages2pageIdxCompute(pages, false);
/*     */   }
/*     */ 
/*     */   
/*     */   public int pages2pageIdxFloor(int pages) {
/* 353 */     return pages2pageIdxCompute(pages, true);
/*     */   }
/*     */   
/*     */   private int pages2pageIdxCompute(int pages, boolean floor) {
/* 357 */     int pageSize = pages << this.pageShifts;
/* 358 */     if (pageSize > this.chunkSize) {
/* 359 */       return this.nPSizes;
/*     */     }
/*     */     
/* 362 */     int x = PoolThreadCache.log2((pageSize << 1) - 1);
/*     */     
/* 364 */     int shift = (x < 2 + this.pageShifts) ? 0 : (x - 2 + this.pageShifts);
/*     */ 
/*     */     
/* 367 */     int group = shift << 2;
/*     */     
/* 369 */     int log2Delta = (x < 2 + this.pageShifts + 1) ? this.pageShifts : (x - 2 - 1);
/*     */ 
/*     */     
/* 372 */     int mod = pageSize - 1 >> log2Delta & 0x3;
/*     */     
/* 374 */     int pageIdx = group + mod;
/*     */     
/* 376 */     if (floor && this.pageIdx2sizeTab[pageIdx] > pages << this.pageShifts) {
/* 377 */       pageIdx--;
/*     */     }
/*     */     
/* 380 */     return pageIdx;
/*     */   }
/*     */ 
/*     */   
/*     */   private static int alignSizeIfNeeded(int size, int directMemoryCacheAlignment) {
/* 385 */     if (directMemoryCacheAlignment <= 0) {
/* 386 */       return size;
/*     */     }
/* 388 */     int delta = size & directMemoryCacheAlignment - 1;
/* 389 */     return (delta == 0) ? size : (size + directMemoryCacheAlignment - delta);
/*     */   }
/*     */ 
/*     */   
/*     */   public int normalizeSize(int size) {
/* 394 */     if (size == 0) {
/* 395 */       return this.sizeIdx2sizeTab[0];
/*     */     }
/* 397 */     size = alignSizeIfNeeded(size, this.directMemoryCacheAlignment);
/* 398 */     if (size <= this.lookupMaxSize) {
/* 399 */       int ret = this.sizeIdx2sizeTab[this.size2idxTab[size - 1 >> 4]];
/* 400 */       assert ret == normalizeSizeCompute(size);
/* 401 */       return ret;
/*     */     } 
/* 403 */     return normalizeSizeCompute(size);
/*     */   }
/*     */   
/*     */   private static int normalizeSizeCompute(int size) {
/* 407 */     int x = PoolThreadCache.log2((size << 1) - 1);
/* 408 */     int log2Delta = (x < 7) ? 4 : (x - 2 - 1);
/*     */     
/* 410 */     int delta = 1 << log2Delta;
/* 411 */     int delta_mask = delta - 1;
/* 412 */     return size + delta_mask & (delta_mask ^ 0xFFFFFFFF);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-buffer-4.1.93.Final.jar!\io\netty\buffer\SizeClasses.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */