/*     */ package io.netty.buffer;
/*     */ 
/*     */ import io.netty.util.internal.LongCounter;
/*     */ import io.netty.util.internal.PlatformDependent;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.ArrayDeque;
/*     */ import java.util.Deque;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class PoolChunk<T>
/*     */   implements PoolChunkMetric
/*     */ {
/*     */   private static final int SIZE_BIT_LENGTH = 15;
/*     */   private static final int INUSED_BIT_LENGTH = 1;
/*     */   private static final int SUBPAGE_BIT_LENGTH = 1;
/*     */   private static final int BITMAP_IDX_BIT_LENGTH = 32;
/*     */   static final int IS_SUBPAGE_SHIFT = 32;
/*     */   static final int IS_USED_SHIFT = 33;
/*     */   static final int SIZE_SHIFT = 34;
/*     */   static final int RUN_OFFSET_SHIFT = 49;
/*     */   final PoolArena<T> arena;
/*     */   final Object base;
/*     */   final T memory;
/*     */   final boolean unpooled;
/*     */   private final LongLongHashMap runsAvailMap;
/*     */   private final LongPriorityQueue[] runsAvail;
/*     */   private final ReentrantLock runsAvailLock;
/*     */   private final PoolSubpage<T>[] subpages;
/* 172 */   private final LongCounter pinnedBytes = PlatformDependent.newLongCounter();
/*     */ 
/*     */   
/*     */   private final int pageSize;
/*     */ 
/*     */   
/*     */   private final int pageShifts;
/*     */ 
/*     */   
/*     */   private final int chunkSize;
/*     */ 
/*     */   
/*     */   private final Deque<ByteBuffer> cachedNioBuffers;
/*     */   
/*     */   int freeBytes;
/*     */   
/*     */   PoolChunkList<T> parent;
/*     */   
/*     */   PoolChunk<T> prev;
/*     */   
/*     */   PoolChunk<T> next;
/*     */ 
/*     */   
/*     */   PoolChunk(PoolArena<T> arena, Object base, T memory, int pageSize, int pageShifts, int chunkSize, int maxPageIdx) {
/* 196 */     this.unpooled = false;
/* 197 */     this.arena = arena;
/* 198 */     this.base = base;
/* 199 */     this.memory = memory;
/* 200 */     this.pageSize = pageSize;
/* 201 */     this.pageShifts = pageShifts;
/* 202 */     this.chunkSize = chunkSize;
/* 203 */     this.freeBytes = chunkSize;
/*     */     
/* 205 */     this.runsAvail = newRunsAvailqueueArray(maxPageIdx);
/* 206 */     this.runsAvailLock = new ReentrantLock();
/* 207 */     this.runsAvailMap = new LongLongHashMap(-1L);
/* 208 */     this.subpages = (PoolSubpage<T>[])new PoolSubpage[chunkSize >> pageShifts];
/*     */ 
/*     */     
/* 211 */     int pages = chunkSize >> pageShifts;
/* 212 */     long initHandle = pages << 34L;
/* 213 */     insertAvailRun(0, pages, initHandle);
/*     */     
/* 215 */     this.cachedNioBuffers = new ArrayDeque<ByteBuffer>(8);
/*     */   }
/*     */ 
/*     */   
/*     */   PoolChunk(PoolArena<T> arena, Object base, T memory, int size) {
/* 220 */     this.unpooled = true;
/* 221 */     this.arena = arena;
/* 222 */     this.base = base;
/* 223 */     this.memory = memory;
/* 224 */     this.pageSize = 0;
/* 225 */     this.pageShifts = 0;
/* 226 */     this.runsAvailMap = null;
/* 227 */     this.runsAvail = null;
/* 228 */     this.runsAvailLock = null;
/* 229 */     this.subpages = null;
/* 230 */     this.chunkSize = size;
/* 231 */     this.cachedNioBuffers = null;
/*     */   }
/*     */   
/*     */   private static LongPriorityQueue[] newRunsAvailqueueArray(int size) {
/* 235 */     LongPriorityQueue[] queueArray = new LongPriorityQueue[size];
/* 236 */     for (int i = 0; i < queueArray.length; i++) {
/* 237 */       queueArray[i] = new LongPriorityQueue();
/*     */     }
/* 239 */     return queueArray;
/*     */   }
/*     */   
/*     */   private void insertAvailRun(int runOffset, int pages, long handle) {
/* 243 */     int pageIdxFloor = this.arena.pages2pageIdxFloor(pages);
/* 244 */     LongPriorityQueue queue = this.runsAvail[pageIdxFloor];
/* 245 */     queue.offer(handle);
/*     */ 
/*     */     
/* 248 */     insertAvailRun0(runOffset, handle);
/* 249 */     if (pages > 1)
/*     */     {
/* 251 */       insertAvailRun0(lastPage(runOffset, pages), handle);
/*     */     }
/*     */   }
/*     */   
/*     */   private void insertAvailRun0(int runOffset, long handle) {
/* 256 */     long pre = this.runsAvailMap.put(runOffset, handle);
/* 257 */     assert pre == -1L;
/*     */   }
/*     */   
/*     */   private void removeAvailRun(long handle) {
/* 261 */     int pageIdxFloor = this.arena.pages2pageIdxFloor(runPages(handle));
/* 262 */     this.runsAvail[pageIdxFloor].remove(handle);
/* 263 */     removeAvailRun0(handle);
/*     */   }
/*     */   
/*     */   private void removeAvailRun0(long handle) {
/* 267 */     int runOffset = runOffset(handle);
/* 268 */     int pages = runPages(handle);
/*     */     
/* 270 */     this.runsAvailMap.remove(runOffset);
/* 271 */     if (pages > 1)
/*     */     {
/* 273 */       this.runsAvailMap.remove(lastPage(runOffset, pages));
/*     */     }
/*     */   }
/*     */   
/*     */   private static int lastPage(int runOffset, int pages) {
/* 278 */     return runOffset + pages - 1;
/*     */   }
/*     */   
/*     */   private long getAvailRunByOffset(int runOffset) {
/* 282 */     return this.runsAvailMap.get(runOffset);
/*     */   }
/*     */ 
/*     */   
/*     */   public int usage() {
/*     */     int freeBytes;
/* 288 */     if (this.unpooled) {
/* 289 */       freeBytes = this.freeBytes;
/*     */     } else {
/* 291 */       this.runsAvailLock.lock();
/*     */       try {
/* 293 */         freeBytes = this.freeBytes;
/*     */       } finally {
/* 295 */         this.runsAvailLock.unlock();
/*     */       } 
/*     */     } 
/* 298 */     return usage(freeBytes);
/*     */   }
/*     */   
/*     */   private int usage(int freeBytes) {
/* 302 */     if (freeBytes == 0) {
/* 303 */       return 100;
/*     */     }
/*     */     
/* 306 */     int freePercentage = (int)(freeBytes * 100L / this.chunkSize);
/* 307 */     if (freePercentage == 0) {
/* 308 */       return 99;
/*     */     }
/* 310 */     return 100 - freePercentage;
/*     */   }
/*     */   
/*     */   boolean allocate(PooledByteBuf<T> buf, int reqCapacity, int sizeIdx, PoolThreadCache cache) {
/*     */     long handle;
/* 315 */     if (sizeIdx <= this.arena.smallMaxSizeIdx) {
/*     */       
/* 317 */       handle = allocateSubpage(sizeIdx);
/* 318 */       if (handle < 0L) {
/* 319 */         return false;
/*     */       }
/* 321 */       assert isSubpage(handle);
/*     */     }
/*     */     else {
/*     */       
/* 325 */       int runSize = this.arena.sizeIdx2size(sizeIdx);
/* 326 */       handle = allocateRun(runSize);
/* 327 */       if (handle < 0L) {
/* 328 */         return false;
/*     */       }
/* 330 */       assert !isSubpage(handle);
/*     */     } 
/*     */     
/* 333 */     ByteBuffer nioBuffer = (this.cachedNioBuffers != null) ? this.cachedNioBuffers.pollLast() : null;
/* 334 */     initBuf(buf, nioBuffer, handle, reqCapacity, cache);
/* 335 */     return true;
/*     */   }
/*     */   
/*     */   private long allocateRun(int runSize) {
/* 339 */     int pages = runSize >> this.pageShifts;
/* 340 */     int pageIdx = this.arena.pages2pageIdx(pages);
/*     */     
/* 342 */     this.runsAvailLock.lock();
/*     */     
/*     */     try {
/* 345 */       int queueIdx = runFirstBestFit(pageIdx);
/* 346 */       if (queueIdx == -1) {
/* 347 */         return -1L;
/*     */       }
/*     */ 
/*     */       
/* 351 */       LongPriorityQueue queue = this.runsAvail[queueIdx];
/* 352 */       long handle = queue.poll();
/*     */       
/* 354 */       assert handle != -1L && !isUsed(handle) : "invalid handle: " + handle;
/*     */       
/* 356 */       removeAvailRun0(handle);
/*     */       
/* 358 */       if (handle != -1L) {
/* 359 */         handle = splitLargeRun(handle, pages);
/*     */       }
/*     */       
/* 362 */       int pinnedSize = runSize(this.pageShifts, handle);
/* 363 */       this.freeBytes -= pinnedSize;
/* 364 */       return handle;
/*     */     } finally {
/* 366 */       this.runsAvailLock.unlock();
/*     */     } 
/*     */   }
/*     */   
/*     */   private int calculateRunSize(int sizeIdx) {
/* 371 */     int nElements, maxElements = 1 << this.pageShifts - 4;
/* 372 */     int runSize = 0;
/*     */ 
/*     */     
/* 375 */     int elemSize = this.arena.sizeIdx2size(sizeIdx);
/*     */ 
/*     */     
/*     */     do {
/* 379 */       runSize += this.pageSize;
/* 380 */       nElements = runSize / elemSize;
/* 381 */     } while (nElements < maxElements && runSize != nElements * elemSize);
/*     */     
/* 383 */     while (nElements > maxElements) {
/* 384 */       runSize -= this.pageSize;
/* 385 */       nElements = runSize / elemSize;
/*     */     } 
/*     */     
/* 388 */     assert nElements > 0;
/* 389 */     assert runSize <= this.chunkSize;
/* 390 */     assert runSize >= elemSize;
/*     */     
/* 392 */     return runSize;
/*     */   }
/*     */   
/*     */   private int runFirstBestFit(int pageIdx) {
/* 396 */     if (this.freeBytes == this.chunkSize) {
/* 397 */       return this.arena.nPSizes - 1;
/*     */     }
/* 399 */     for (int i = pageIdx; i < this.arena.nPSizes; i++) {
/* 400 */       LongPriorityQueue queue = this.runsAvail[i];
/* 401 */       if (queue != null && !queue.isEmpty()) {
/* 402 */         return i;
/*     */       }
/*     */     } 
/* 405 */     return -1;
/*     */   }
/*     */   
/*     */   private long splitLargeRun(long handle, int needPages) {
/* 409 */     assert needPages > 0;
/*     */     
/* 411 */     int totalPages = runPages(handle);
/* 412 */     assert needPages <= totalPages;
/*     */     
/* 414 */     int remPages = totalPages - needPages;
/*     */     
/* 416 */     if (remPages > 0) {
/* 417 */       int runOffset = runOffset(handle);
/*     */ 
/*     */       
/* 420 */       int availOffset = runOffset + needPages;
/* 421 */       long availRun = toRunHandle(availOffset, remPages, 0);
/* 422 */       insertAvailRun(availOffset, remPages, availRun);
/*     */ 
/*     */       
/* 425 */       return toRunHandle(runOffset, needPages, 1);
/*     */     } 
/*     */ 
/*     */     
/* 429 */     handle |= 0x200000000L;
/* 430 */     return handle;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private long allocateSubpage(int sizeIdx) {
/* 444 */     PoolSubpage<T> head = this.arena.findSubpagePoolHead(sizeIdx);
/* 445 */     head.lock();
/*     */     
/*     */     try {
/* 448 */       int runSize = calculateRunSize(sizeIdx);
/*     */       
/* 450 */       long runHandle = allocateRun(runSize);
/* 451 */       if (runHandle < 0L) {
/* 452 */         return -1L;
/*     */       }
/*     */       
/* 455 */       int runOffset = runOffset(runHandle);
/* 456 */       assert this.subpages[runOffset] == null;
/* 457 */       int elemSize = this.arena.sizeIdx2size(sizeIdx);
/*     */ 
/*     */       
/* 460 */       PoolSubpage<T> subpage = new PoolSubpage<T>(head, this, this.pageShifts, runOffset, runSize(this.pageShifts, runHandle), elemSize);
/*     */       
/* 462 */       this.subpages[runOffset] = subpage;
/* 463 */       return subpage.allocate();
/*     */     } finally {
/* 465 */       head.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void free(long handle, int normCapacity, ByteBuffer nioBuffer) {
/* 477 */     int runSize = runSize(this.pageShifts, handle);
/* 478 */     if (isSubpage(handle)) {
/* 479 */       int sizeIdx = this.arena.size2SizeIdx(normCapacity);
/* 480 */       PoolSubpage<T> head = this.arena.findSubpagePoolHead(sizeIdx);
/*     */       
/* 482 */       int sIdx = runOffset(handle);
/* 483 */       PoolSubpage<T> subpage = this.subpages[sIdx];
/*     */ 
/*     */ 
/*     */       
/* 487 */       head.lock();
/*     */       try {
/* 489 */         assert subpage != null && subpage.doNotDestroy;
/* 490 */         if (subpage.free(head, bitmapIdx(handle))) {
/*     */           return;
/*     */         }
/*     */         
/* 494 */         assert !subpage.doNotDestroy;
/*     */         
/* 496 */         this.subpages[sIdx] = null;
/*     */       } finally {
/* 498 */         head.unlock();
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 503 */     this.runsAvailLock.lock();
/*     */ 
/*     */     
/*     */     try {
/* 507 */       long finalRun = collapseRuns(handle);
/*     */ 
/*     */       
/* 510 */       finalRun &= 0xFFFFFFFDFFFFFFFFL;
/*     */       
/* 512 */       finalRun &= 0xFFFFFFFEFFFFFFFFL;
/*     */       
/* 514 */       insertAvailRun(runOffset(finalRun), runPages(finalRun), finalRun);
/* 515 */       this.freeBytes += runSize;
/*     */     } finally {
/* 517 */       this.runsAvailLock.unlock();
/*     */     } 
/*     */     
/* 520 */     if (nioBuffer != null && this.cachedNioBuffers != null && this.cachedNioBuffers
/* 521 */       .size() < PooledByteBufAllocator.DEFAULT_MAX_CACHED_BYTEBUFFERS_PER_CHUNK) {
/* 522 */       this.cachedNioBuffers.offer(nioBuffer);
/*     */     }
/*     */   }
/*     */   
/*     */   private long collapseRuns(long handle) {
/* 527 */     return collapseNext(collapsePast(handle));
/*     */   }
/*     */   
/*     */   private long collapsePast(long handle) {
/*     */     while (true) {
/* 532 */       int runOffset = runOffset(handle);
/* 533 */       int runPages = runPages(handle);
/*     */       
/* 535 */       long pastRun = getAvailRunByOffset(runOffset - 1);
/* 536 */       if (pastRun == -1L) {
/* 537 */         return handle;
/*     */       }
/*     */       
/* 540 */       int pastOffset = runOffset(pastRun);
/* 541 */       int pastPages = runPages(pastRun);
/*     */ 
/*     */       
/* 544 */       if (pastRun != handle && pastOffset + pastPages == runOffset) {
/*     */         
/* 546 */         removeAvailRun(pastRun);
/* 547 */         handle = toRunHandle(pastOffset, pastPages + runPages, 0); continue;
/*     */       }  break;
/* 549 */     }  return handle;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private long collapseNext(long handle) {
/*     */     while (true) {
/* 556 */       int runOffset = runOffset(handle);
/* 557 */       int runPages = runPages(handle);
/*     */       
/* 559 */       long nextRun = getAvailRunByOffset(runOffset + runPages);
/* 560 */       if (nextRun == -1L) {
/* 561 */         return handle;
/*     */       }
/*     */       
/* 564 */       int nextOffset = runOffset(nextRun);
/* 565 */       int nextPages = runPages(nextRun);
/*     */ 
/*     */       
/* 568 */       if (nextRun != handle && runOffset + runPages == nextOffset) {
/*     */         
/* 570 */         removeAvailRun(nextRun);
/* 571 */         handle = toRunHandle(runOffset, runPages + nextPages, 0); continue;
/*     */       }  break;
/* 573 */     }  return handle;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static long toRunHandle(int runOffset, int runPages, int inUsed) {
/* 579 */     return runOffset << 49L | runPages << 34L | inUsed << 33L;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void initBuf(PooledByteBuf<T> buf, ByteBuffer nioBuffer, long handle, int reqCapacity, PoolThreadCache threadCache) {
/* 586 */     if (isSubpage(handle)) {
/* 587 */       initBufWithSubpage(buf, nioBuffer, handle, reqCapacity, threadCache);
/*     */     } else {
/* 589 */       int maxLength = runSize(this.pageShifts, handle);
/* 590 */       buf.init(this, nioBuffer, handle, runOffset(handle) << this.pageShifts, reqCapacity, maxLength, this.arena.parent
/* 591 */           .threadCache());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   void initBufWithSubpage(PooledByteBuf<T> buf, ByteBuffer nioBuffer, long handle, int reqCapacity, PoolThreadCache threadCache) {
/* 597 */     int runOffset = runOffset(handle);
/* 598 */     int bitmapIdx = bitmapIdx(handle);
/*     */     
/* 600 */     PoolSubpage<T> s = this.subpages[runOffset];
/* 601 */     assert s.doNotDestroy;
/* 602 */     assert reqCapacity <= s.elemSize : reqCapacity + "<=" + s.elemSize;
/*     */     
/* 604 */     int offset = (runOffset << this.pageShifts) + bitmapIdx * s.elemSize;
/* 605 */     buf.init(this, nioBuffer, handle, offset, reqCapacity, s.elemSize, threadCache);
/*     */   }
/*     */   
/*     */   void incrementPinnedMemory(int delta) {
/* 609 */     assert delta > 0;
/* 610 */     this.pinnedBytes.add(delta);
/*     */   }
/*     */   
/*     */   void decrementPinnedMemory(int delta) {
/* 614 */     assert delta > 0;
/* 615 */     this.pinnedBytes.add(-delta);
/*     */   }
/*     */ 
/*     */   
/*     */   public int chunkSize() {
/* 620 */     return this.chunkSize;
/*     */   }
/*     */ 
/*     */   
/*     */   public int freeBytes() {
/* 625 */     if (this.unpooled) {
/* 626 */       return this.freeBytes;
/*     */     }
/* 628 */     this.runsAvailLock.lock();
/*     */     try {
/* 630 */       return this.freeBytes;
/*     */     } finally {
/* 632 */       this.runsAvailLock.unlock();
/*     */     } 
/*     */   }
/*     */   
/*     */   public int pinnedBytes() {
/* 637 */     return (int)this.pinnedBytes.value();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*     */     int freeBytes;
/* 643 */     if (this.unpooled) {
/* 644 */       freeBytes = this.freeBytes;
/*     */     } else {
/* 646 */       this.runsAvailLock.lock();
/*     */       try {
/* 648 */         freeBytes = this.freeBytes;
/*     */       } finally {
/* 650 */         this.runsAvailLock.unlock();
/*     */       } 
/*     */     } 
/*     */     
/* 654 */     return "Chunk(" + 
/*     */       
/* 656 */       Integer.toHexString(System.identityHashCode(this)) + ": " + 
/*     */       
/* 658 */       usage(freeBytes) + "%, " + (
/* 659 */       this.chunkSize - freeBytes) + 
/* 660 */       '/' + 
/* 661 */       this.chunkSize + 
/* 662 */       ')';
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void destroy() {
/* 668 */     this.arena.destroyChunk(this);
/*     */   }
/*     */   
/*     */   static int runOffset(long handle) {
/* 672 */     return (int)(handle >> 49L);
/*     */   }
/*     */   
/*     */   static int runSize(int pageShifts, long handle) {
/* 676 */     return runPages(handle) << pageShifts;
/*     */   }
/*     */   
/*     */   static int runPages(long handle) {
/* 680 */     return (int)(handle >> 34L & 0x7FFFL);
/*     */   }
/*     */   
/*     */   static boolean isUsed(long handle) {
/* 684 */     return ((handle >> 33L & 0x1L) == 1L);
/*     */   }
/*     */   
/*     */   static boolean isRun(long handle) {
/* 688 */     return !isSubpage(handle);
/*     */   }
/*     */   
/*     */   static boolean isSubpage(long handle) {
/* 692 */     return ((handle >> 32L & 0x1L) == 1L);
/*     */   }
/*     */   
/*     */   static int bitmapIdx(long handle) {
/* 696 */     return (int)handle;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-buffer-4.1.93.Final.jar!\io\netty\buffer\PoolChunk.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */