/*     */ package io.netty.buffer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class LongLongHashMap
/*     */ {
/*     */   private static final int MASK_TEMPLATE = -2;
/*     */   private int mask;
/*     */   private long[] array;
/*     */   private int maxProbe;
/*     */   private long zeroVal;
/*     */   private final long emptyVal;
/*     */   
/*     */   LongLongHashMap(long emptyVal) {
/*  31 */     this.emptyVal = emptyVal;
/*  32 */     this.zeroVal = emptyVal;
/*  33 */     int initialSize = 32;
/*  34 */     this.array = new long[initialSize];
/*  35 */     this.mask = initialSize - 1;
/*  36 */     computeMaskAndProbe();
/*     */   }
/*     */   
/*     */   public long put(long key, long value) {
/*  40 */     if (key == 0L) {
/*  41 */       long prev = this.zeroVal;
/*  42 */       this.zeroVal = value;
/*  43 */       return prev;
/*     */     } 
/*     */     
/*     */     while (true) {
/*  47 */       int index = index(key);
/*  48 */       for (int i = 0; i < this.maxProbe; i++) {
/*  49 */         long existing = this.array[index];
/*  50 */         if (existing == key || existing == 0L) {
/*  51 */           long prev = (existing == 0L) ? this.emptyVal : this.array[index + 1];
/*  52 */           this.array[index] = key;
/*  53 */           this.array[index + 1] = value;
/*  54 */           for (; i < this.maxProbe; i++) {
/*  55 */             index = index + 2 & this.mask;
/*  56 */             if (this.array[index] == key) {
/*  57 */               this.array[index] = 0L;
/*  58 */               prev = this.array[index + 1];
/*     */               break;
/*     */             } 
/*     */           } 
/*  62 */           return prev;
/*     */         } 
/*  64 */         index = index + 2 & this.mask;
/*     */       } 
/*  66 */       expand();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void remove(long key) {
/*  71 */     if (key == 0L) {
/*  72 */       this.zeroVal = this.emptyVal;
/*     */       return;
/*     */     } 
/*  75 */     int index = index(key);
/*  76 */     for (int i = 0; i < this.maxProbe; i++) {
/*  77 */       long existing = this.array[index];
/*  78 */       if (existing == key) {
/*  79 */         this.array[index] = 0L;
/*     */         break;
/*     */       } 
/*  82 */       index = index + 2 & this.mask;
/*     */     } 
/*     */   }
/*     */   
/*     */   public long get(long key) {
/*  87 */     if (key == 0L) {
/*  88 */       return this.zeroVal;
/*     */     }
/*  90 */     int index = index(key);
/*  91 */     for (int i = 0; i < this.maxProbe; i++) {
/*  92 */       long existing = this.array[index];
/*  93 */       if (existing == key) {
/*  94 */         return this.array[index + 1];
/*     */       }
/*  96 */       index = index + 2 & this.mask;
/*     */     } 
/*  98 */     return this.emptyVal;
/*     */   }
/*     */ 
/*     */   
/*     */   private int index(long key) {
/* 103 */     key ^= key >>> 33L;
/* 104 */     key *= -49064778989728563L;
/* 105 */     key ^= key >>> 33L;
/* 106 */     key *= -4265267296055464877L;
/* 107 */     key ^= key >>> 33L;
/* 108 */     return (int)key & this.mask;
/*     */   }
/*     */   
/*     */   private void expand() {
/* 112 */     long[] prev = this.array;
/* 113 */     this.array = new long[prev.length * 2];
/* 114 */     computeMaskAndProbe();
/* 115 */     for (int i = 0; i < prev.length; i += 2) {
/* 116 */       long key = prev[i];
/* 117 */       if (key != 0L) {
/* 118 */         long val = prev[i + 1];
/* 119 */         put(key, val);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void computeMaskAndProbe() {
/* 125 */     int length = this.array.length;
/* 126 */     this.mask = length - 1 & 0xFFFFFFFE;
/* 127 */     this.maxProbe = (int)Math.log(length);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-buffer-4.1.93.Final.jar!\io\netty\buffer\LongLongHashMap.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */