/*     */ package io.netty.buffer;
/*     */ 
/*     */ import io.netty.util.ResourceLeakDetector;
/*     */ import io.netty.util.ResourceLeakTracker;
/*     */ import io.netty.util.internal.MathUtil;
/*     */ import io.netty.util.internal.ObjectUtil;
/*     */ import io.netty.util.internal.PlatformDependent;
/*     */ import io.netty.util.internal.StringUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractByteBufAllocator
/*     */   implements ByteBufAllocator
/*     */ {
/*     */   static final int DEFAULT_INITIAL_CAPACITY = 256;
/*     */   static final int DEFAULT_MAX_CAPACITY = 2147483647;
/*     */   static final int DEFAULT_MAX_COMPONENTS = 16;
/*     */   static final int CALCULATE_THRESHOLD = 4194304;
/*     */   private final boolean directByDefault;
/*     */   private final ByteBuf emptyBuf;
/*     */   
/*     */   static {
/*  37 */     ResourceLeakDetector.addExclusions(AbstractByteBufAllocator.class, new String[] { "toLeakAwareBuffer" });
/*     */   }
/*     */   
/*     */   protected static ByteBuf toLeakAwareBuffer(ByteBuf buf) {
/*     */     ResourceLeakTracker<ByteBuf> leak;
/*  42 */     switch (ResourceLeakDetector.getLevel()) {
/*     */       case SIMPLE:
/*  44 */         leak = AbstractByteBuf.leakDetector.track(buf);
/*  45 */         if (leak != null) {
/*  46 */           buf = new SimpleLeakAwareByteBuf(buf, leak);
/*     */         }
/*     */         break;
/*     */       case ADVANCED:
/*     */       case PARANOID:
/*  51 */         leak = AbstractByteBuf.leakDetector.track(buf);
/*  52 */         if (leak != null) {
/*  53 */           buf = new AdvancedLeakAwareByteBuf(buf, leak);
/*     */         }
/*     */         break;
/*     */     } 
/*     */ 
/*     */     
/*  59 */     return buf;
/*     */   }
/*     */   
/*     */   protected static CompositeByteBuf toLeakAwareBuffer(CompositeByteBuf buf) {
/*     */     ResourceLeakTracker<ByteBuf> leak;
/*  64 */     switch (ResourceLeakDetector.getLevel()) {
/*     */       case SIMPLE:
/*  66 */         leak = AbstractByteBuf.leakDetector.track(buf);
/*  67 */         if (leak != null) {
/*  68 */           buf = new SimpleLeakAwareCompositeByteBuf(buf, leak);
/*     */         }
/*     */         break;
/*     */       case ADVANCED:
/*     */       case PARANOID:
/*  73 */         leak = AbstractByteBuf.leakDetector.track(buf);
/*  74 */         if (leak != null) {
/*  75 */           buf = new AdvancedLeakAwareCompositeByteBuf(buf, leak);
/*     */         }
/*     */         break;
/*     */     } 
/*     */ 
/*     */     
/*  81 */     return buf;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected AbstractByteBufAllocator() {
/*  91 */     this(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected AbstractByteBufAllocator(boolean preferDirect) {
/* 101 */     this.directByDefault = (preferDirect && PlatformDependent.hasUnsafe());
/* 102 */     this.emptyBuf = new EmptyByteBuf(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public ByteBuf buffer() {
/* 107 */     if (this.directByDefault) {
/* 108 */       return directBuffer();
/*     */     }
/* 110 */     return heapBuffer();
/*     */   }
/*     */ 
/*     */   
/*     */   public ByteBuf buffer(int initialCapacity) {
/* 115 */     if (this.directByDefault) {
/* 116 */       return directBuffer(initialCapacity);
/*     */     }
/* 118 */     return heapBuffer(initialCapacity);
/*     */   }
/*     */ 
/*     */   
/*     */   public ByteBuf buffer(int initialCapacity, int maxCapacity) {
/* 123 */     if (this.directByDefault) {
/* 124 */       return directBuffer(initialCapacity, maxCapacity);
/*     */     }
/* 126 */     return heapBuffer(initialCapacity, maxCapacity);
/*     */   }
/*     */ 
/*     */   
/*     */   public ByteBuf ioBuffer() {
/* 131 */     if (PlatformDependent.hasUnsafe() || isDirectBufferPooled()) {
/* 132 */       return directBuffer(256);
/*     */     }
/* 134 */     return heapBuffer(256);
/*     */   }
/*     */ 
/*     */   
/*     */   public ByteBuf ioBuffer(int initialCapacity) {
/* 139 */     if (PlatformDependent.hasUnsafe() || isDirectBufferPooled()) {
/* 140 */       return directBuffer(initialCapacity);
/*     */     }
/* 142 */     return heapBuffer(initialCapacity);
/*     */   }
/*     */ 
/*     */   
/*     */   public ByteBuf ioBuffer(int initialCapacity, int maxCapacity) {
/* 147 */     if (PlatformDependent.hasUnsafe() || isDirectBufferPooled()) {
/* 148 */       return directBuffer(initialCapacity, maxCapacity);
/*     */     }
/* 150 */     return heapBuffer(initialCapacity, maxCapacity);
/*     */   }
/*     */ 
/*     */   
/*     */   public ByteBuf heapBuffer() {
/* 155 */     return heapBuffer(256, 2147483647);
/*     */   }
/*     */ 
/*     */   
/*     */   public ByteBuf heapBuffer(int initialCapacity) {
/* 160 */     return heapBuffer(initialCapacity, 2147483647);
/*     */   }
/*     */ 
/*     */   
/*     */   public ByteBuf heapBuffer(int initialCapacity, int maxCapacity) {
/* 165 */     if (initialCapacity == 0 && maxCapacity == 0) {
/* 166 */       return this.emptyBuf;
/*     */     }
/* 168 */     validate(initialCapacity, maxCapacity);
/* 169 */     return newHeapBuffer(initialCapacity, maxCapacity);
/*     */   }
/*     */ 
/*     */   
/*     */   public ByteBuf directBuffer() {
/* 174 */     return directBuffer(256, 2147483647);
/*     */   }
/*     */ 
/*     */   
/*     */   public ByteBuf directBuffer(int initialCapacity) {
/* 179 */     return directBuffer(initialCapacity, 2147483647);
/*     */   }
/*     */ 
/*     */   
/*     */   public ByteBuf directBuffer(int initialCapacity, int maxCapacity) {
/* 184 */     if (initialCapacity == 0 && maxCapacity == 0) {
/* 185 */       return this.emptyBuf;
/*     */     }
/* 187 */     validate(initialCapacity, maxCapacity);
/* 188 */     return newDirectBuffer(initialCapacity, maxCapacity);
/*     */   }
/*     */ 
/*     */   
/*     */   public CompositeByteBuf compositeBuffer() {
/* 193 */     if (this.directByDefault) {
/* 194 */       return compositeDirectBuffer();
/*     */     }
/* 196 */     return compositeHeapBuffer();
/*     */   }
/*     */ 
/*     */   
/*     */   public CompositeByteBuf compositeBuffer(int maxNumComponents) {
/* 201 */     if (this.directByDefault) {
/* 202 */       return compositeDirectBuffer(maxNumComponents);
/*     */     }
/* 204 */     return compositeHeapBuffer(maxNumComponents);
/*     */   }
/*     */ 
/*     */   
/*     */   public CompositeByteBuf compositeHeapBuffer() {
/* 209 */     return compositeHeapBuffer(16);
/*     */   }
/*     */ 
/*     */   
/*     */   public CompositeByteBuf compositeHeapBuffer(int maxNumComponents) {
/* 214 */     return toLeakAwareBuffer(new CompositeByteBuf(this, false, maxNumComponents));
/*     */   }
/*     */ 
/*     */   
/*     */   public CompositeByteBuf compositeDirectBuffer() {
/* 219 */     return compositeDirectBuffer(16);
/*     */   }
/*     */ 
/*     */   
/*     */   public CompositeByteBuf compositeDirectBuffer(int maxNumComponents) {
/* 224 */     return toLeakAwareBuffer(new CompositeByteBuf(this, true, maxNumComponents));
/*     */   }
/*     */   
/*     */   private static void validate(int initialCapacity, int maxCapacity) {
/* 228 */     ObjectUtil.checkPositiveOrZero(initialCapacity, "initialCapacity");
/* 229 */     if (initialCapacity > maxCapacity) {
/* 230 */       throw new IllegalArgumentException(String.format("initialCapacity: %d (expected: not greater than maxCapacity(%d)", new Object[] {
/*     */               
/* 232 */               Integer.valueOf(initialCapacity), Integer.valueOf(maxCapacity)
/*     */             }));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 248 */     return StringUtil.simpleClassName(this) + "(directByDefault: " + this.directByDefault + ')';
/*     */   }
/*     */ 
/*     */   
/*     */   public int calculateNewCapacity(int minNewCapacity, int maxCapacity) {
/* 253 */     ObjectUtil.checkPositiveOrZero(minNewCapacity, "minNewCapacity");
/* 254 */     if (minNewCapacity > maxCapacity)
/* 255 */       throw new IllegalArgumentException(String.format("minNewCapacity: %d (expected: not greater than maxCapacity(%d)", new Object[] {
/*     */               
/* 257 */               Integer.valueOf(minNewCapacity), Integer.valueOf(maxCapacity)
/*     */             })); 
/* 259 */     int threshold = 4194304;
/*     */     
/* 261 */     if (minNewCapacity == 4194304) {
/* 262 */       return 4194304;
/*     */     }
/*     */ 
/*     */     
/* 266 */     if (minNewCapacity > 4194304) {
/* 267 */       int i = minNewCapacity / 4194304 * 4194304;
/* 268 */       if (i > maxCapacity - 4194304) {
/* 269 */         i = maxCapacity;
/*     */       } else {
/* 271 */         i += 4194304;
/*     */       } 
/* 273 */       return i;
/*     */     } 
/*     */ 
/*     */     
/* 277 */     int newCapacity = MathUtil.findNextPositivePowerOfTwo(Math.max(minNewCapacity, 64));
/* 278 */     return Math.min(newCapacity, maxCapacity);
/*     */   }
/*     */   
/*     */   protected abstract ByteBuf newHeapBuffer(int paramInt1, int paramInt2);
/*     */   
/*     */   protected abstract ByteBuf newDirectBuffer(int paramInt1, int paramInt2);
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-buffer-4.1.93.Final.jar!\io\netty\buffer\AbstractByteBufAllocator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */