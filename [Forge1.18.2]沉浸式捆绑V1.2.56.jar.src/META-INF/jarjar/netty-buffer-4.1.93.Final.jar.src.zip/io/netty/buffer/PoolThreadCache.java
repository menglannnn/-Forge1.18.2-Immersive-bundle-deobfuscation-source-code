/*     */ package io.netty.buffer;
/*     */ 
/*     */ import io.netty.util.Recycler;
/*     */ import io.netty.util.internal.MathUtil;
/*     */ import io.netty.util.internal.ObjectPool;
/*     */ import io.netty.util.internal.ObjectUtil;
/*     */ import io.netty.util.internal.PlatformDependent;
/*     */ import io.netty.util.internal.logging.InternalLogger;
/*     */ import io.netty.util.internal.logging.InternalLoggerFactory;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Queue;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class PoolThreadCache
/*     */ {
/*  47 */   private static final InternalLogger logger = InternalLoggerFactory.getInstance(PoolThreadCache.class);
/*     */   
/*     */   private static final int INTEGER_SIZE_MINUS_ONE = 31;
/*     */   
/*     */   final PoolArena<byte[]> heapArena;
/*     */   
/*     */   final PoolArena<ByteBuffer> directArena;
/*     */   
/*     */   private final MemoryRegionCache<byte[]>[] smallSubPageHeapCaches;
/*     */   private final MemoryRegionCache<ByteBuffer>[] smallSubPageDirectCaches;
/*     */   private final MemoryRegionCache<byte[]>[] normalHeapCaches;
/*     */   private final MemoryRegionCache<ByteBuffer>[] normalDirectCaches;
/*     */   private final int freeSweepAllocationThreshold;
/*  60 */   private final AtomicBoolean freed = new AtomicBoolean();
/*     */ 
/*     */ 
/*     */   
/*     */   private int allocations;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   PoolThreadCache(PoolArena<byte[]> heapArena, PoolArena<ByteBuffer> directArena, int smallCacheSize, int normalCacheSize, int maxCachedBufferCapacity, int freeSweepAllocationThreshold) {
/*  70 */     ObjectUtil.checkPositiveOrZero(maxCachedBufferCapacity, "maxCachedBufferCapacity");
/*  71 */     this.freeSweepAllocationThreshold = freeSweepAllocationThreshold;
/*  72 */     this.heapArena = heapArena;
/*  73 */     this.directArena = directArena;
/*  74 */     if (directArena != null) {
/*  75 */       this.smallSubPageDirectCaches = createSubPageCaches(smallCacheSize, directArena.numSmallSubpagePools);
/*     */ 
/*     */       
/*  78 */       this.normalDirectCaches = createNormalCaches(normalCacheSize, maxCachedBufferCapacity, directArena);
/*     */ 
/*     */       
/*  81 */       directArena.numThreadCaches.getAndIncrement();
/*     */     } else {
/*     */       
/*  84 */       this.smallSubPageDirectCaches = null;
/*  85 */       this.normalDirectCaches = null;
/*     */     } 
/*  87 */     if (heapArena != null) {
/*     */       
/*  89 */       this.smallSubPageHeapCaches = createSubPageCaches(smallCacheSize, heapArena.numSmallSubpagePools);
/*     */ 
/*     */       
/*  92 */       this.normalHeapCaches = createNormalCaches(normalCacheSize, maxCachedBufferCapacity, (PoolArena)heapArena);
/*     */ 
/*     */       
/*  95 */       heapArena.numThreadCaches.getAndIncrement();
/*     */     } else {
/*     */       
/*  98 */       this.smallSubPageHeapCaches = null;
/*  99 */       this.normalHeapCaches = null;
/*     */     } 
/*     */ 
/*     */     
/* 103 */     if ((this.smallSubPageDirectCaches != null || this.normalDirectCaches != null || this.smallSubPageHeapCaches != null || this.normalHeapCaches != null) && freeSweepAllocationThreshold < 1)
/*     */     {
/*     */       
/* 106 */       throw new IllegalArgumentException("freeSweepAllocationThreshold: " + freeSweepAllocationThreshold + " (expected: > 0)");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static <T> MemoryRegionCache<T>[] createSubPageCaches(int cacheSize, int numCaches) {
/* 113 */     if (cacheSize > 0 && numCaches > 0) {
/*     */       
/* 115 */       MemoryRegionCache[] arrayOfMemoryRegionCache = new MemoryRegionCache[numCaches];
/* 116 */       for (int i = 0; i < arrayOfMemoryRegionCache.length; i++)
/*     */       {
/* 118 */         arrayOfMemoryRegionCache[i] = new SubPageMemoryRegionCache(cacheSize);
/*     */       }
/* 120 */       return (MemoryRegionCache<T>[])arrayOfMemoryRegionCache;
/*     */     } 
/* 122 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static <T> MemoryRegionCache<T>[] createNormalCaches(int cacheSize, int maxCachedBufferCapacity, PoolArena<T> area) {
/* 129 */     if (cacheSize > 0 && maxCachedBufferCapacity > 0) {
/* 130 */       int max = Math.min(area.chunkSize, maxCachedBufferCapacity);
/*     */ 
/*     */       
/* 133 */       List<MemoryRegionCache<T>> cache = new ArrayList<MemoryRegionCache<T>>();
/* 134 */       for (int idx = area.numSmallSubpagePools; idx < area.nSizes && area.sizeIdx2size(idx) <= max; idx++) {
/* 135 */         cache.add(new NormalMemoryRegionCache<T>(cacheSize));
/*     */       }
/* 137 */       return cache.<MemoryRegionCache<T>>toArray((MemoryRegionCache<T>[])new MemoryRegionCache[0]);
/*     */     } 
/* 139 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static int log2(int val) {
/* 145 */     return 31 - Integer.numberOfLeadingZeros(val);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean allocateSmall(PoolArena<?> area, PooledByteBuf<?> buf, int reqCapacity, int sizeIdx) {
/* 152 */     return allocate(cacheForSmall(area, sizeIdx), buf, reqCapacity);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean allocateNormal(PoolArena<?> area, PooledByteBuf<?> buf, int reqCapacity, int sizeIdx) {
/* 159 */     return allocate(cacheForNormal(area, sizeIdx), buf, reqCapacity);
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean allocate(MemoryRegionCache<?> cache, PooledByteBuf<?> buf, int reqCapacity) {
/* 164 */     if (cache == null)
/*     */     {
/* 166 */       return false;
/*     */     }
/* 168 */     boolean allocated = cache.allocate(buf, reqCapacity, this);
/* 169 */     if (++this.allocations >= this.freeSweepAllocationThreshold) {
/* 170 */       this.allocations = 0;
/* 171 */       trim();
/*     */     } 
/* 173 */     return allocated;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean add(PoolArena<?> area, PoolChunk<?> chunk, ByteBuffer nioBuffer, long handle, int normCapacity, PoolArena.SizeClass sizeClass) {
/* 183 */     int sizeIdx = area.size2SizeIdx(normCapacity);
/* 184 */     MemoryRegionCache<?> cache = cache(area, sizeIdx, sizeClass);
/* 185 */     if (cache == null) {
/* 186 */       return false;
/*     */     }
/* 188 */     if (this.freed.get()) {
/* 189 */       return false;
/*     */     }
/* 191 */     return cache.add(chunk, nioBuffer, handle, normCapacity);
/*     */   }
/*     */   
/*     */   private MemoryRegionCache<?> cache(PoolArena<?> area, int sizeIdx, PoolArena.SizeClass sizeClass) {
/* 195 */     switch (sizeClass) {
/*     */       case Normal:
/* 197 */         return cacheForNormal(area, sizeIdx);
/*     */       case Small:
/* 199 */         return cacheForSmall(area, sizeIdx);
/*     */     } 
/* 201 */     throw new Error();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void finalize() throws Throwable {
/*     */     try {
/* 209 */       super.finalize();
/*     */     } finally {
/* 211 */       free(true);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void free(boolean finalizer) {
/* 221 */     if (this.freed.compareAndSet(false, true)) {
/*     */ 
/*     */ 
/*     */       
/* 225 */       int numFreed = free((MemoryRegionCache<?>[])this.smallSubPageDirectCaches, finalizer) + free((MemoryRegionCache<?>[])this.normalDirectCaches, finalizer) + free((MemoryRegionCache<?>[])this.smallSubPageHeapCaches, finalizer) + free((MemoryRegionCache<?>[])this.normalHeapCaches, finalizer);
/*     */       
/* 227 */       if (numFreed > 0 && logger.isDebugEnabled()) {
/* 228 */         logger.debug("Freed {} thread-local buffer(s) from thread: {}", Integer.valueOf(numFreed), 
/* 229 */             Thread.currentThread().getName());
/*     */       }
/*     */       
/* 232 */       if (this.directArena != null) {
/* 233 */         this.directArena.numThreadCaches.getAndDecrement();
/*     */       }
/*     */       
/* 236 */       if (this.heapArena != null) {
/* 237 */         this.heapArena.numThreadCaches.getAndDecrement();
/*     */       }
/*     */     } else {
/*     */       
/* 241 */       checkCacheMayLeak((MemoryRegionCache<?>[])this.smallSubPageDirectCaches, "SmallSubPageDirectCaches");
/* 242 */       checkCacheMayLeak((MemoryRegionCache<?>[])this.normalDirectCaches, "NormalDirectCaches");
/* 243 */       checkCacheMayLeak((MemoryRegionCache<?>[])this.smallSubPageHeapCaches, "SmallSubPageHeapCaches");
/* 244 */       checkCacheMayLeak((MemoryRegionCache<?>[])this.normalHeapCaches, "NormalHeapCaches");
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void checkCacheMayLeak(MemoryRegionCache<?>[] caches, String type) {
/* 249 */     for (MemoryRegionCache<?> cache : caches) {
/* 250 */       if (!cache.queue.isEmpty()) {
/* 251 */         logger.debug("{} memory may leak.", type);
/*     */         return;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private static int free(MemoryRegionCache<?>[] caches, boolean finalizer) {
/* 258 */     if (caches == null) {
/* 259 */       return 0;
/*     */     }
/*     */     
/* 262 */     int numFreed = 0;
/* 263 */     for (MemoryRegionCache<?> c : caches) {
/* 264 */       numFreed += free(c, finalizer);
/*     */     }
/* 266 */     return numFreed;
/*     */   }
/*     */   
/*     */   private static int free(MemoryRegionCache<?> cache, boolean finalizer) {
/* 270 */     if (cache == null) {
/* 271 */       return 0;
/*     */     }
/* 273 */     return cache.free(finalizer);
/*     */   }
/*     */   
/*     */   void trim() {
/* 277 */     trim((MemoryRegionCache<?>[])this.smallSubPageDirectCaches);
/* 278 */     trim((MemoryRegionCache<?>[])this.normalDirectCaches);
/* 279 */     trim((MemoryRegionCache<?>[])this.smallSubPageHeapCaches);
/* 280 */     trim((MemoryRegionCache<?>[])this.normalHeapCaches);
/*     */   }
/*     */   
/*     */   private static void trim(MemoryRegionCache<?>[] caches) {
/* 284 */     if (caches == null) {
/*     */       return;
/*     */     }
/* 287 */     for (MemoryRegionCache<?> c : caches) {
/* 288 */       trim(c);
/*     */     }
/*     */   }
/*     */   
/*     */   private static void trim(MemoryRegionCache<?> cache) {
/* 293 */     if (cache == null) {
/*     */       return;
/*     */     }
/* 296 */     cache.trim();
/*     */   }
/*     */   
/*     */   private MemoryRegionCache<?> cacheForSmall(PoolArena<?> area, int sizeIdx) {
/* 300 */     if (area.isDirect()) {
/* 301 */       return cache((MemoryRegionCache<?>[])this.smallSubPageDirectCaches, sizeIdx);
/*     */     }
/* 303 */     return cache((MemoryRegionCache<?>[])this.smallSubPageHeapCaches, sizeIdx);
/*     */   }
/*     */ 
/*     */   
/*     */   private MemoryRegionCache<?> cacheForNormal(PoolArena<?> area, int sizeIdx) {
/* 308 */     int idx = sizeIdx - area.numSmallSubpagePools;
/* 309 */     if (area.isDirect()) {
/* 310 */       return cache((MemoryRegionCache<?>[])this.normalDirectCaches, idx);
/*     */     }
/* 312 */     return cache((MemoryRegionCache<?>[])this.normalHeapCaches, idx);
/*     */   }
/*     */   
/*     */   private static <T> MemoryRegionCache<T> cache(MemoryRegionCache<T>[] cache, int sizeIdx) {
/* 316 */     if (cache == null || sizeIdx > cache.length - 1) {
/* 317 */       return null;
/*     */     }
/* 319 */     return cache[sizeIdx];
/*     */   }
/*     */ 
/*     */   
/*     */   private static final class SubPageMemoryRegionCache<T>
/*     */     extends MemoryRegionCache<T>
/*     */   {
/*     */     SubPageMemoryRegionCache(int size) {
/* 327 */       super(size, PoolArena.SizeClass.Small);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected void initBuf(PoolChunk<T> chunk, ByteBuffer nioBuffer, long handle, PooledByteBuf<T> buf, int reqCapacity, PoolThreadCache threadCache) {
/* 334 */       chunk.initBufWithSubpage(buf, nioBuffer, handle, reqCapacity, threadCache);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static final class NormalMemoryRegionCache<T>
/*     */     extends MemoryRegionCache<T>
/*     */   {
/*     */     NormalMemoryRegionCache(int size) {
/* 343 */       super(size, PoolArena.SizeClass.Normal);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected void initBuf(PoolChunk<T> chunk, ByteBuffer nioBuffer, long handle, PooledByteBuf<T> buf, int reqCapacity, PoolThreadCache threadCache) {
/* 350 */       chunk.initBuf(buf, nioBuffer, handle, reqCapacity, threadCache);
/*     */     }
/*     */   }
/*     */   
/*     */   private static abstract class MemoryRegionCache<T> {
/*     */     private final int size;
/*     */     private final Queue<Entry<T>> queue;
/*     */     private final PoolArena.SizeClass sizeClass;
/*     */     private int allocations;
/*     */     
/*     */     MemoryRegionCache(int size, PoolArena.SizeClass sizeClass) {
/* 361 */       this.size = MathUtil.safeFindNextPositivePowerOfTwo(size);
/* 362 */       this.queue = PlatformDependent.newFixedMpscQueue(this.size);
/* 363 */       this.sizeClass = sizeClass;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final boolean add(PoolChunk<T> chunk, ByteBuffer nioBuffer, long handle, int normCapacity) {
/* 377 */       Entry<T> entry = newEntry(chunk, nioBuffer, handle, normCapacity);
/* 378 */       boolean queued = this.queue.offer(entry);
/* 379 */       if (!queued)
/*     */       {
/* 381 */         entry.unguardedRecycle();
/*     */       }
/*     */       
/* 384 */       return queued;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final boolean allocate(PooledByteBuf<T> buf, int reqCapacity, PoolThreadCache threadCache) {
/* 391 */       Entry<T> entry = this.queue.poll();
/* 392 */       if (entry == null) {
/* 393 */         return false;
/*     */       }
/* 395 */       initBuf(entry.chunk, entry.nioBuffer, entry.handle, buf, reqCapacity, threadCache);
/* 396 */       entry.unguardedRecycle();
/*     */ 
/*     */       
/* 399 */       this.allocations++;
/* 400 */       return true;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final int free(boolean finalizer) {
/* 407 */       return free(2147483647, finalizer);
/*     */     }
/*     */     
/*     */     private int free(int max, boolean finalizer) {
/* 411 */       int numFreed = 0;
/* 412 */       for (; numFreed < max; numFreed++) {
/* 413 */         Entry<T> entry = this.queue.poll();
/* 414 */         if (entry != null) {
/* 415 */           freeEntry(entry, finalizer);
/*     */         } else {
/*     */           
/* 418 */           return numFreed;
/*     */         } 
/*     */       } 
/* 421 */       return numFreed;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final void trim() {
/* 428 */       int free = this.size - this.allocations;
/* 429 */       this.allocations = 0;
/*     */ 
/*     */       
/* 432 */       if (free > 0) {
/* 433 */         free(free, false);
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private void freeEntry(Entry entry, boolean finalizer) {
/* 440 */       PoolChunk chunk = entry.chunk;
/* 441 */       long handle = entry.handle;
/* 442 */       ByteBuffer nioBuffer = entry.nioBuffer;
/* 443 */       int normCapacity = entry.normCapacity;
/*     */       
/* 445 */       if (!finalizer)
/*     */       {
/*     */         
/* 448 */         entry.recycle();
/*     */       }
/*     */       
/* 451 */       chunk.arena.freeChunk(chunk, handle, normCapacity, this.sizeClass, nioBuffer, finalizer);
/*     */     }
/*     */     
/*     */     static final class Entry<T> {
/*     */       final Recycler.EnhancedHandle<Entry<?>> recyclerHandle;
/*     */       PoolChunk<T> chunk;
/*     */       ByteBuffer nioBuffer;
/* 458 */       long handle = -1L;
/*     */       int normCapacity;
/*     */       
/*     */       Entry(ObjectPool.Handle<Entry<?>> recyclerHandle) {
/* 462 */         this.recyclerHandle = (Recycler.EnhancedHandle<Entry<?>>)recyclerHandle;
/*     */       }
/*     */       
/*     */       void recycle() {
/* 466 */         this.chunk = null;
/* 467 */         this.nioBuffer = null;
/* 468 */         this.handle = -1L;
/* 469 */         this.recyclerHandle.recycle(this);
/*     */       }
/*     */       
/*     */       void unguardedRecycle() {
/* 473 */         this.chunk = null;
/* 474 */         this.nioBuffer = null;
/* 475 */         this.handle = -1L;
/* 476 */         this.recyclerHandle.unguardedRecycle(this);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     private static Entry newEntry(PoolChunk<?> chunk, ByteBuffer nioBuffer, long handle, int normCapacity) {
/* 482 */       Entry entry = (Entry)RECYCLER.get();
/* 483 */       entry.chunk = chunk;
/* 484 */       entry.nioBuffer = nioBuffer;
/* 485 */       entry.handle = handle;
/* 486 */       entry.normCapacity = normCapacity;
/* 487 */       return entry;
/*     */     }
/*     */ 
/*     */     
/* 491 */     private static final ObjectPool<Entry> RECYCLER = ObjectPool.newPool(new ObjectPool.ObjectCreator<Entry>()
/*     */         {
/*     */           public PoolThreadCache.MemoryRegionCache.Entry newObject(ObjectPool.Handle<PoolThreadCache.MemoryRegionCache.Entry> handle)
/*     */           {
/* 495 */             return new PoolThreadCache.MemoryRegionCache.Entry((ObjectPool.Handle)handle);
/*     */           }
/*     */         });
/*     */     
/*     */     protected abstract void initBuf(PoolChunk<T> param1PoolChunk, ByteBuffer param1ByteBuffer, long param1Long, PooledByteBuf<T> param1PooledByteBuf, int param1Int, PoolThreadCache param1PoolThreadCache);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-buffer-4.1.93.Final.jar!\io\netty\buffer\PoolThreadCache.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */