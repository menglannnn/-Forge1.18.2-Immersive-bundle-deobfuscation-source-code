/*     */ package io.netty.bootstrap;
/*     */ 
/*     */ import io.netty.channel.Channel;
/*     */ import io.netty.channel.ChannelConfig;
/*     */ import io.netty.channel.ChannelFuture;
/*     */ import io.netty.channel.ChannelFutureListener;
/*     */ import io.netty.channel.ChannelHandler;
/*     */ import io.netty.channel.ChannelHandlerContext;
/*     */ import io.netty.channel.ChannelInboundHandlerAdapter;
/*     */ import io.netty.channel.ChannelInitializer;
/*     */ import io.netty.channel.ChannelOption;
/*     */ import io.netty.channel.ChannelPipeline;
/*     */ import io.netty.channel.EventLoopGroup;
/*     */ import io.netty.channel.ServerChannel;
/*     */ import io.netty.util.AttributeKey;
/*     */ import io.netty.util.concurrent.Future;
/*     */ import io.netty.util.concurrent.GenericFutureListener;
/*     */ import io.netty.util.internal.ObjectUtil;
/*     */ import io.netty.util.internal.logging.InternalLogger;
/*     */ import io.netty.util.internal.logging.InternalLoggerFactory;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServerBootstrap
/*     */   extends AbstractBootstrap<ServerBootstrap, ServerChannel>
/*     */ {
/*  47 */   private static final InternalLogger logger = InternalLoggerFactory.getInstance(ServerBootstrap.class);
/*     */ 
/*     */ 
/*     */   
/*  51 */   private final Map<ChannelOption<?>, Object> childOptions = new LinkedHashMap<ChannelOption<?>, Object>();
/*  52 */   private final Map<AttributeKey<?>, Object> childAttrs = new ConcurrentHashMap<AttributeKey<?>, Object>();
/*  53 */   private final ServerBootstrapConfig config = new ServerBootstrapConfig(this);
/*     */   
/*     */   private volatile EventLoopGroup childGroup;
/*     */   
/*     */   private volatile ChannelHandler childHandler;
/*     */   
/*     */   private ServerBootstrap(ServerBootstrap bootstrap) {
/*  60 */     super(bootstrap);
/*  61 */     this.childGroup = bootstrap.childGroup;
/*  62 */     this.childHandler = bootstrap.childHandler;
/*  63 */     synchronized (bootstrap.childOptions) {
/*  64 */       this.childOptions.putAll(bootstrap.childOptions);
/*     */     } 
/*  66 */     this.childAttrs.putAll(bootstrap.childAttrs);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ServerBootstrap group(EventLoopGroup group) {
/*  74 */     return group(group, group);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ServerBootstrap group(EventLoopGroup parentGroup, EventLoopGroup childGroup) {
/*  83 */     super.group(parentGroup);
/*  84 */     if (this.childGroup != null) {
/*  85 */       throw new IllegalStateException("childGroup set already");
/*     */     }
/*  87 */     this.childGroup = (EventLoopGroup)ObjectUtil.checkNotNull(childGroup, "childGroup");
/*  88 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> ServerBootstrap childOption(ChannelOption<T> childOption, T value) {
/*  97 */     ObjectUtil.checkNotNull(childOption, "childOption");
/*  98 */     synchronized (this.childOptions) {
/*  99 */       if (value == null) {
/* 100 */         this.childOptions.remove(childOption);
/*     */       } else {
/* 102 */         this.childOptions.put(childOption, value);
/*     */       } 
/*     */     } 
/* 105 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> ServerBootstrap childAttr(AttributeKey<T> childKey, T value) {
/* 113 */     ObjectUtil.checkNotNull(childKey, "childKey");
/* 114 */     if (value == null) {
/* 115 */       this.childAttrs.remove(childKey);
/*     */     } else {
/* 117 */       this.childAttrs.put(childKey, value);
/*     */     } 
/* 119 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ServerBootstrap childHandler(ChannelHandler childHandler) {
/* 126 */     this.childHandler = (ChannelHandler)ObjectUtil.checkNotNull(childHandler, "childHandler");
/* 127 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   void init(Channel channel) {
/* 132 */     setChannelOptions(channel, newOptionsArray(), logger);
/* 133 */     setAttributes(channel, newAttributesArray());
/*     */     
/* 135 */     ChannelPipeline p = channel.pipeline();
/*     */     
/* 137 */     final EventLoopGroup currentChildGroup = this.childGroup;
/* 138 */     final ChannelHandler currentChildHandler = this.childHandler;
/* 139 */     final Map.Entry[] currentChildOptions = (Map.Entry[])newOptionsArray(this.childOptions);
/* 140 */     final Map.Entry[] currentChildAttrs = (Map.Entry[])newAttributesArray(this.childAttrs);
/*     */     
/* 142 */     p.addLast(new ChannelHandler[] { (ChannelHandler)new ChannelInitializer<Channel>()
/*     */           {
/*     */             public void initChannel(final Channel ch) {
/* 145 */               final ChannelPipeline pipeline = ch.pipeline();
/* 146 */               ChannelHandler handler = ServerBootstrap.this.config.handler();
/* 147 */               if (handler != null) {
/* 148 */                 pipeline.addLast(new ChannelHandler[] { handler });
/*     */               }
/*     */               
/* 151 */               ch.eventLoop().execute(new Runnable()
/*     */                   {
/*     */                     public void run() {
/* 154 */                       pipeline.addLast(new ChannelHandler[] { (ChannelHandler)new ServerBootstrap.ServerBootstrapAcceptor(this.val$ch, this.this$1.val$currentChildGroup, this.this$1.val$currentChildHandler, (Map.Entry<ChannelOption<?>, Object>[])this.this$1.val$currentChildOptions, (Map.Entry<AttributeKey<?>, Object>[])this.this$1.val$currentChildAttrs) });
/*     */                     }
/*     */                   });
/*     */             }
/*     */           } });
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ServerBootstrap validate() {
/* 164 */     super.validate();
/* 165 */     if (this.childHandler == null) {
/* 166 */       throw new IllegalStateException("childHandler not set");
/*     */     }
/* 168 */     if (this.childGroup == null) {
/* 169 */       logger.warn("childGroup is not set. Using parentGroup instead.");
/* 170 */       this.childGroup = this.config.group();
/*     */     } 
/* 172 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   private static class ServerBootstrapAcceptor
/*     */     extends ChannelInboundHandlerAdapter
/*     */   {
/*     */     private final EventLoopGroup childGroup;
/*     */     private final ChannelHandler childHandler;
/*     */     private final Map.Entry<ChannelOption<?>, Object>[] childOptions;
/*     */     private final Map.Entry<AttributeKey<?>, Object>[] childAttrs;
/*     */     private final Runnable enableAutoReadTask;
/*     */     
/*     */     ServerBootstrapAcceptor(final Channel channel, EventLoopGroup childGroup, ChannelHandler childHandler, Map.Entry<ChannelOption<?>, Object>[] childOptions, Map.Entry<AttributeKey<?>, Object>[] childAttrs) {
/* 186 */       this.childGroup = childGroup;
/* 187 */       this.childHandler = childHandler;
/* 188 */       this.childOptions = childOptions;
/* 189 */       this.childAttrs = childAttrs;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 196 */       this.enableAutoReadTask = new Runnable()
/*     */         {
/*     */           public void run() {
/* 199 */             channel.config().setAutoRead(true);
/*     */           }
/*     */         };
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void channelRead(ChannelHandlerContext ctx, Object msg) {
/* 207 */       final Channel child = (Channel)msg;
/*     */       
/* 209 */       child.pipeline().addLast(new ChannelHandler[] { this.childHandler });
/*     */       
/* 211 */       AbstractBootstrap.setChannelOptions(child, this.childOptions, ServerBootstrap.logger);
/* 212 */       AbstractBootstrap.setAttributes(child, this.childAttrs);
/*     */       
/*     */       try {
/* 215 */         this.childGroup.register(child).addListener((GenericFutureListener)new ChannelFutureListener()
/*     */             {
/*     */               public void operationComplete(ChannelFuture future) throws Exception {
/* 218 */                 if (!future.isSuccess()) {
/* 219 */                   ServerBootstrap.ServerBootstrapAcceptor.forceClose(child, future.cause());
/*     */                 }
/*     */               }
/*     */             });
/* 223 */       } catch (Throwable t) {
/* 224 */         forceClose(child, t);
/*     */       } 
/*     */     }
/*     */     
/*     */     private static void forceClose(Channel child, Throwable t) {
/* 229 */       child.unsafe().closeForcibly();
/* 230 */       ServerBootstrap.logger.warn("Failed to register an accepted channel: {}", child, t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {
/* 235 */       ChannelConfig config = ctx.channel().config();
/* 236 */       if (config.isAutoRead()) {
/*     */ 
/*     */         
/* 239 */         config.setAutoRead(false);
/* 240 */         ctx.channel().eventLoop().schedule(this.enableAutoReadTask, 1L, TimeUnit.SECONDS);
/*     */       } 
/*     */ 
/*     */       
/* 244 */       ctx.fireExceptionCaught(cause);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ServerBootstrap clone() {
/* 251 */     return new ServerBootstrap(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public EventLoopGroup childGroup() {
/* 262 */     return this.childGroup;
/*     */   }
/*     */   
/*     */   final ChannelHandler childHandler() {
/* 266 */     return this.childHandler;
/*     */   }
/*     */   
/*     */   final Map<ChannelOption<?>, Object> childOptions() {
/* 270 */     synchronized (this.childOptions) {
/* 271 */       return copiedMap(this.childOptions);
/*     */     } 
/*     */   }
/*     */   
/*     */   final Map<AttributeKey<?>, Object> childAttrs() {
/* 276 */     return copiedMap(this.childAttrs);
/*     */   }
/*     */ 
/*     */   
/*     */   public final ServerBootstrapConfig config() {
/* 281 */     return this.config;
/*     */   }
/*     */   
/*     */   public ServerBootstrap() {}
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-transport-4.1.93.Final.jar!\io\netty\bootstrap\ServerBootstrap.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */