/*     */ package io.netty.bootstrap;
/*     */ 
/*     */ import io.netty.channel.Channel;
/*     */ import io.netty.channel.ChannelFuture;
/*     */ import io.netty.channel.ChannelFutureListener;
/*     */ import io.netty.channel.ChannelHandler;
/*     */ import io.netty.channel.ChannelPipeline;
/*     */ import io.netty.channel.ChannelPromise;
/*     */ import io.netty.channel.EventLoop;
/*     */ import io.netty.channel.EventLoopGroup;
/*     */ import io.netty.resolver.AddressResolver;
/*     */ import io.netty.resolver.AddressResolverGroup;
/*     */ import io.netty.resolver.DefaultAddressResolverGroup;
/*     */ import io.netty.util.concurrent.EventExecutor;
/*     */ import io.netty.util.concurrent.Future;
/*     */ import io.netty.util.concurrent.FutureListener;
/*     */ import io.netty.util.concurrent.GenericFutureListener;
/*     */ import io.netty.util.internal.ObjectUtil;
/*     */ import io.netty.util.internal.logging.InternalLogger;
/*     */ import io.netty.util.internal.logging.InternalLoggerFactory;
/*     */ import java.net.InetAddress;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.SocketAddress;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Bootstrap
/*     */   extends AbstractBootstrap<Bootstrap, Channel>
/*     */ {
/*  48 */   private static final InternalLogger logger = InternalLoggerFactory.getInstance(Bootstrap.class);
/*     */   
/*  50 */   private static final AddressResolverGroup<?> DEFAULT_RESOLVER = (AddressResolverGroup<?>)DefaultAddressResolverGroup.INSTANCE;
/*     */   
/*  52 */   private final BootstrapConfig config = new BootstrapConfig(this);
/*     */   
/*  54 */   private volatile AddressResolverGroup<SocketAddress> resolver = (AddressResolverGroup)DEFAULT_RESOLVER;
/*     */ 
/*     */   
/*     */   private volatile SocketAddress remoteAddress;
/*     */ 
/*     */ 
/*     */   
/*     */   private Bootstrap(Bootstrap bootstrap) {
/*  62 */     super(bootstrap);
/*  63 */     this.resolver = bootstrap.resolver;
/*  64 */     this.remoteAddress = bootstrap.remoteAddress;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Bootstrap resolver(AddressResolverGroup<?> resolver) {
/*  77 */     this.resolver = (resolver == null) ? (AddressResolverGroup)DEFAULT_RESOLVER : (AddressResolverGroup)resolver;
/*  78 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Bootstrap remoteAddress(SocketAddress remoteAddress) {
/*  86 */     this.remoteAddress = remoteAddress;
/*  87 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Bootstrap remoteAddress(String inetHost, int inetPort) {
/*  94 */     this.remoteAddress = InetSocketAddress.createUnresolved(inetHost, inetPort);
/*  95 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Bootstrap remoteAddress(InetAddress inetHost, int inetPort) {
/* 102 */     this.remoteAddress = new InetSocketAddress(inetHost, inetPort);
/* 103 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ChannelFuture connect() {
/* 110 */     validate();
/* 111 */     SocketAddress remoteAddress = this.remoteAddress;
/* 112 */     if (remoteAddress == null) {
/* 113 */       throw new IllegalStateException("remoteAddress not set");
/*     */     }
/*     */     
/* 116 */     return doResolveAndConnect(remoteAddress, this.config.localAddress());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ChannelFuture connect(String inetHost, int inetPort) {
/* 123 */     return connect(InetSocketAddress.createUnresolved(inetHost, inetPort));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ChannelFuture connect(InetAddress inetHost, int inetPort) {
/* 130 */     return connect(new InetSocketAddress(inetHost, inetPort));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ChannelFuture connect(SocketAddress remoteAddress) {
/* 137 */     ObjectUtil.checkNotNull(remoteAddress, "remoteAddress");
/* 138 */     validate();
/* 139 */     return doResolveAndConnect(remoteAddress, this.config.localAddress());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ChannelFuture connect(SocketAddress remoteAddress, SocketAddress localAddress) {
/* 146 */     ObjectUtil.checkNotNull(remoteAddress, "remoteAddress");
/* 147 */     validate();
/* 148 */     return doResolveAndConnect(remoteAddress, localAddress);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ChannelFuture doResolveAndConnect(final SocketAddress remoteAddress, final SocketAddress localAddress) {
/* 155 */     ChannelFuture regFuture = initAndRegister();
/* 156 */     final Channel channel = regFuture.channel();
/*     */     
/* 158 */     if (regFuture.isDone()) {
/* 159 */       if (!regFuture.isSuccess()) {
/* 160 */         return regFuture;
/*     */       }
/* 162 */       return doResolveAndConnect0(channel, remoteAddress, localAddress, channel.newPromise());
/*     */     } 
/*     */     
/* 165 */     final AbstractBootstrap.PendingRegistrationPromise promise = new AbstractBootstrap.PendingRegistrationPromise(channel);
/* 166 */     regFuture.addListener((GenericFutureListener)new ChannelFutureListener()
/*     */         {
/*     */           
/*     */           public void operationComplete(ChannelFuture future) throws Exception
/*     */           {
/* 171 */             Throwable cause = future.cause();
/* 172 */             if (cause != null) {
/*     */ 
/*     */               
/* 175 */               promise.setFailure(cause);
/*     */             }
/*     */             else {
/*     */               
/* 179 */               promise.registered();
/* 180 */               Bootstrap.this.doResolveAndConnect0(channel, remoteAddress, localAddress, (ChannelPromise)promise);
/*     */             } 
/*     */           }
/*     */         });
/* 184 */     return (ChannelFuture)promise;
/*     */   }
/*     */ 
/*     */   
/*     */   private ChannelFuture doResolveAndConnect0(final Channel channel, SocketAddress remoteAddress, final SocketAddress localAddress, final ChannelPromise promise) {
/*     */     try {
/*     */       AddressResolver<SocketAddress> resolver;
/* 191 */       EventLoop eventLoop = channel.eventLoop();
/*     */       
/*     */       try {
/* 194 */         resolver = this.resolver.getResolver((EventExecutor)eventLoop);
/* 195 */       } catch (Throwable cause) {
/* 196 */         channel.close();
/* 197 */         return (ChannelFuture)promise.setFailure(cause);
/*     */       } 
/*     */       
/* 200 */       if (!resolver.isSupported(remoteAddress) || resolver.isResolved(remoteAddress)) {
/*     */         
/* 202 */         doConnect(remoteAddress, localAddress, promise);
/* 203 */         return (ChannelFuture)promise;
/*     */       } 
/*     */       
/* 206 */       Future<SocketAddress> resolveFuture = resolver.resolve(remoteAddress);
/*     */       
/* 208 */       if (resolveFuture.isDone()) {
/* 209 */         Throwable resolveFailureCause = resolveFuture.cause();
/*     */         
/* 211 */         if (resolveFailureCause != null) {
/*     */           
/* 213 */           channel.close();
/* 214 */           promise.setFailure(resolveFailureCause);
/*     */         } else {
/*     */           
/* 217 */           doConnect((SocketAddress)resolveFuture.getNow(), localAddress, promise);
/*     */         } 
/* 219 */         return (ChannelFuture)promise;
/*     */       } 
/*     */ 
/*     */       
/* 223 */       resolveFuture.addListener((GenericFutureListener)new FutureListener<SocketAddress>()
/*     */           {
/*     */             public void operationComplete(Future<SocketAddress> future) throws Exception {
/* 226 */               if (future.cause() != null) {
/* 227 */                 channel.close();
/* 228 */                 promise.setFailure(future.cause());
/*     */               } else {
/* 230 */                 Bootstrap.doConnect((SocketAddress)future.getNow(), localAddress, promise);
/*     */               } 
/*     */             }
/*     */           });
/* 234 */     } catch (Throwable cause) {
/* 235 */       promise.tryFailure(cause);
/*     */     } 
/* 237 */     return (ChannelFuture)promise;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void doConnect(final SocketAddress remoteAddress, final SocketAddress localAddress, final ChannelPromise connectPromise) {
/* 245 */     final Channel channel = connectPromise.channel();
/* 246 */     channel.eventLoop().execute(new Runnable()
/*     */         {
/*     */           public void run() {
/* 249 */             if (localAddress == null) {
/* 250 */               channel.connect(remoteAddress, connectPromise);
/*     */             } else {
/* 252 */               channel.connect(remoteAddress, localAddress, connectPromise);
/*     */             } 
/* 254 */             connectPromise.addListener((GenericFutureListener)ChannelFutureListener.CLOSE_ON_FAILURE);
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   void init(Channel channel) {
/* 261 */     ChannelPipeline p = channel.pipeline();
/* 262 */     p.addLast(new ChannelHandler[] { this.config.handler() });
/*     */     
/* 264 */     setChannelOptions(channel, newOptionsArray(), logger);
/* 265 */     setAttributes(channel, newAttributesArray());
/*     */   }
/*     */ 
/*     */   
/*     */   public Bootstrap validate() {
/* 270 */     super.validate();
/* 271 */     if (this.config.handler() == null) {
/* 272 */       throw new IllegalStateException("handler not set");
/*     */     }
/* 274 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Bootstrap clone() {
/* 280 */     return new Bootstrap(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Bootstrap clone(EventLoopGroup group) {
/* 289 */     Bootstrap bs = new Bootstrap(this);
/* 290 */     bs.group = group;
/* 291 */     return bs;
/*     */   }
/*     */ 
/*     */   
/*     */   public final BootstrapConfig config() {
/* 296 */     return this.config;
/*     */   }
/*     */   
/*     */   final SocketAddress remoteAddress() {
/* 300 */     return this.remoteAddress;
/*     */   }
/*     */   
/*     */   final AddressResolverGroup<?> resolver() {
/* 304 */     return this.resolver;
/*     */   }
/*     */   
/*     */   public Bootstrap() {}
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-transport-4.1.93.Final.jar!\io\netty\bootstrap\Bootstrap.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */