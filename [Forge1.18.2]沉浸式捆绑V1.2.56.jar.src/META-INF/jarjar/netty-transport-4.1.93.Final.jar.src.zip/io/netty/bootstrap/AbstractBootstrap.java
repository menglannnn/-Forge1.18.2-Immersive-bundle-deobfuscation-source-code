/*     */ package io.netty.bootstrap;
/*     */ 
/*     */ import io.netty.channel.Channel;
/*     */ import io.netty.channel.ChannelFactory;
/*     */ import io.netty.channel.ChannelFuture;
/*     */ import io.netty.channel.ChannelFutureListener;
/*     */ import io.netty.channel.ChannelHandler;
/*     */ import io.netty.channel.ChannelOption;
/*     */ import io.netty.channel.ChannelPromise;
/*     */ import io.netty.channel.DefaultChannelPromise;
/*     */ import io.netty.channel.EventLoopGroup;
/*     */ import io.netty.channel.ReflectiveChannelFactory;
/*     */ import io.netty.util.AttributeKey;
/*     */ import io.netty.util.concurrent.EventExecutor;
/*     */ import io.netty.util.concurrent.Future;
/*     */ import io.netty.util.concurrent.GenericFutureListener;
/*     */ import io.netty.util.concurrent.GlobalEventExecutor;
/*     */ import io.netty.util.internal.ObjectUtil;
/*     */ import io.netty.util.internal.SocketUtils;
/*     */ import io.netty.util.internal.StringUtil;
/*     */ import io.netty.util.internal.logging.InternalLogger;
/*     */ import java.net.InetAddress;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.SocketAddress;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractBootstrap<B extends AbstractBootstrap<B, C>, C extends Channel>
/*     */   implements Cloneable
/*     */ {
/*  55 */   private static final Map.Entry<ChannelOption<?>, Object>[] EMPTY_OPTION_ARRAY = (Map.Entry<ChannelOption<?>, Object>[])new Map.Entry[0];
/*     */   
/*  57 */   private static final Map.Entry<AttributeKey<?>, Object>[] EMPTY_ATTRIBUTE_ARRAY = (Map.Entry<AttributeKey<?>, Object>[])new Map.Entry[0];
/*     */ 
/*     */   
/*     */   volatile EventLoopGroup group;
/*     */   
/*     */   private volatile ChannelFactory<? extends C> channelFactory;
/*     */   
/*     */   private volatile SocketAddress localAddress;
/*     */   
/*  66 */   private final Map<ChannelOption<?>, Object> options = new LinkedHashMap<ChannelOption<?>, Object>();
/*  67 */   private final Map<AttributeKey<?>, Object> attrs = new ConcurrentHashMap<AttributeKey<?>, Object>();
/*     */ 
/*     */   
/*     */   private volatile ChannelHandler handler;
/*     */ 
/*     */ 
/*     */   
/*     */   AbstractBootstrap(AbstractBootstrap<B, C> bootstrap) {
/*  75 */     this.group = bootstrap.group;
/*  76 */     this.channelFactory = bootstrap.channelFactory;
/*  77 */     this.handler = bootstrap.handler;
/*  78 */     this.localAddress = bootstrap.localAddress;
/*  79 */     synchronized (bootstrap.options) {
/*  80 */       this.options.putAll(bootstrap.options);
/*     */     } 
/*  82 */     this.attrs.putAll(bootstrap.attrs);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B group(EventLoopGroup group) {
/*  90 */     ObjectUtil.checkNotNull(group, "group");
/*  91 */     if (this.group != null) {
/*  92 */       throw new IllegalStateException("group set already");
/*     */     }
/*  94 */     this.group = group;
/*  95 */     return self();
/*     */   }
/*     */ 
/*     */   
/*     */   private B self() {
/* 100 */     return (B)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B channel(Class<? extends C> channelClass) {
/* 109 */     return channelFactory((ChannelFactory<? extends C>)new ReflectiveChannelFactory(
/* 110 */           (Class)ObjectUtil.checkNotNull(channelClass, "channelClass")));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public B channelFactory(ChannelFactory<? extends C> channelFactory) {
/* 119 */     ObjectUtil.checkNotNull(channelFactory, "channelFactory");
/* 120 */     if (this.channelFactory != null) {
/* 121 */       throw new IllegalStateException("channelFactory set already");
/*     */     }
/*     */     
/* 124 */     this.channelFactory = channelFactory;
/* 125 */     return self();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B channelFactory(ChannelFactory<? extends C> channelFactory) {
/* 137 */     return channelFactory((ChannelFactory<? extends C>)channelFactory);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B localAddress(SocketAddress localAddress) {
/* 144 */     this.localAddress = localAddress;
/* 145 */     return self();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B localAddress(int inetPort) {
/* 152 */     return localAddress(new InetSocketAddress(inetPort));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B localAddress(String inetHost, int inetPort) {
/* 159 */     return localAddress(SocketUtils.socketAddress(inetHost, inetPort));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B localAddress(InetAddress inetHost, int inetPort) {
/* 166 */     return localAddress(new InetSocketAddress(inetHost, inetPort));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> B option(ChannelOption<T> option, T value) {
/* 174 */     ObjectUtil.checkNotNull(option, "option");
/* 175 */     synchronized (this.options) {
/* 176 */       if (value == null) {
/* 177 */         this.options.remove(option);
/*     */       } else {
/* 179 */         this.options.put(option, value);
/*     */       } 
/*     */     } 
/* 182 */     return self();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> B attr(AttributeKey<T> key, T value) {
/* 190 */     ObjectUtil.checkNotNull(key, "key");
/* 191 */     if (value == null) {
/* 192 */       this.attrs.remove(key);
/*     */     } else {
/* 194 */       this.attrs.put(key, value);
/*     */     } 
/* 196 */     return self();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B validate() {
/* 204 */     if (this.group == null) {
/* 205 */       throw new IllegalStateException("group not set");
/*     */     }
/* 207 */     if (this.channelFactory == null) {
/* 208 */       throw new IllegalStateException("channel or channelFactory not set");
/*     */     }
/* 210 */     return self();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ChannelFuture register() {
/* 226 */     validate();
/* 227 */     return initAndRegister();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ChannelFuture bind() {
/* 234 */     validate();
/* 235 */     SocketAddress localAddress = this.localAddress;
/* 236 */     if (localAddress == null) {
/* 237 */       throw new IllegalStateException("localAddress not set");
/*     */     }
/* 239 */     return doBind(localAddress);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ChannelFuture bind(int inetPort) {
/* 246 */     return bind(new InetSocketAddress(inetPort));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ChannelFuture bind(String inetHost, int inetPort) {
/* 253 */     return bind(SocketUtils.socketAddress(inetHost, inetPort));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ChannelFuture bind(InetAddress inetHost, int inetPort) {
/* 260 */     return bind(new InetSocketAddress(inetHost, inetPort));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ChannelFuture bind(SocketAddress localAddress) {
/* 267 */     validate();
/* 268 */     return doBind((SocketAddress)ObjectUtil.checkNotNull(localAddress, "localAddress"));
/*     */   }
/*     */   
/*     */   private ChannelFuture doBind(final SocketAddress localAddress) {
/* 272 */     final ChannelFuture regFuture = initAndRegister();
/* 273 */     final Channel channel = regFuture.channel();
/* 274 */     if (regFuture.cause() != null) {
/* 275 */       return regFuture;
/*     */     }
/*     */     
/* 278 */     if (regFuture.isDone()) {
/*     */       
/* 280 */       ChannelPromise channelPromise = channel.newPromise();
/* 281 */       doBind0(regFuture, channel, localAddress, channelPromise);
/* 282 */       return (ChannelFuture)channelPromise;
/*     */     } 
/*     */     
/* 285 */     final PendingRegistrationPromise promise = new PendingRegistrationPromise(channel);
/* 286 */     regFuture.addListener((GenericFutureListener)new ChannelFutureListener()
/*     */         {
/*     */           public void operationComplete(ChannelFuture future) throws Exception {
/* 289 */             Throwable cause = future.cause();
/* 290 */             if (cause != null) {
/*     */ 
/*     */               
/* 293 */               promise.setFailure(cause);
/*     */             }
/*     */             else {
/*     */               
/* 297 */               promise.registered();
/*     */               
/* 299 */               AbstractBootstrap.doBind0(regFuture, channel, localAddress, (ChannelPromise)promise);
/*     */             } 
/*     */           }
/*     */         });
/* 303 */     return (ChannelFuture)promise;
/*     */   }
/*     */ 
/*     */   
/*     */   final ChannelFuture initAndRegister() {
/* 308 */     Channel channel = null;
/*     */     try {
/* 310 */       channel = (Channel)this.channelFactory.newChannel();
/* 311 */       init(channel);
/* 312 */     } catch (Throwable t) {
/* 313 */       if (channel != null) {
/*     */         
/* 315 */         channel.unsafe().closeForcibly();
/*     */         
/* 317 */         return (ChannelFuture)(new DefaultChannelPromise(channel, (EventExecutor)GlobalEventExecutor.INSTANCE)).setFailure(t);
/*     */       } 
/*     */       
/* 320 */       return (ChannelFuture)(new DefaultChannelPromise((Channel)new FailedChannel(), (EventExecutor)GlobalEventExecutor.INSTANCE)).setFailure(t);
/*     */     } 
/*     */     
/* 323 */     ChannelFuture regFuture = config().group().register(channel);
/* 324 */     if (regFuture.cause() != null) {
/* 325 */       if (channel.isRegistered()) {
/* 326 */         channel.close();
/*     */       } else {
/* 328 */         channel.unsafe().closeForcibly();
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 341 */     return regFuture;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void doBind0(final ChannelFuture regFuture, final Channel channel, final SocketAddress localAddress, final ChannelPromise promise) {
/* 352 */     channel.eventLoop().execute(new Runnable()
/*     */         {
/*     */           public void run() {
/* 355 */             if (regFuture.isSuccess()) {
/* 356 */               channel.bind(localAddress, promise).addListener((GenericFutureListener)ChannelFutureListener.CLOSE_ON_FAILURE);
/*     */             } else {
/* 358 */               promise.setFailure(regFuture.cause());
/*     */             } 
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B handler(ChannelHandler handler) {
/* 368 */     this.handler = (ChannelHandler)ObjectUtil.checkNotNull(handler, "handler");
/* 369 */     return self();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public final EventLoopGroup group() {
/* 379 */     return this.group;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final Map.Entry<ChannelOption<?>, Object>[] newOptionsArray() {
/* 389 */     return newOptionsArray(this.options);
/*     */   }
/*     */   
/*     */   static Map.Entry<ChannelOption<?>, Object>[] newOptionsArray(Map<ChannelOption<?>, Object> options) {
/* 393 */     synchronized (options) {
/* 394 */       return (Map.Entry<ChannelOption<?>, Object>[])(new LinkedHashMap<Object, Object>(options)).entrySet().toArray((Object[])EMPTY_OPTION_ARRAY);
/*     */     } 
/*     */   }
/*     */   
/*     */   final Map.Entry<AttributeKey<?>, Object>[] newAttributesArray() {
/* 399 */     return newAttributesArray(attrs0());
/*     */   }
/*     */   
/*     */   static Map.Entry<AttributeKey<?>, Object>[] newAttributesArray(Map<AttributeKey<?>, Object> attributes) {
/* 403 */     return (Map.Entry<AttributeKey<?>, Object>[])attributes.entrySet().toArray((Object[])EMPTY_ATTRIBUTE_ARRAY);
/*     */   }
/*     */   
/*     */   final Map<ChannelOption<?>, Object> options0() {
/* 407 */     return this.options;
/*     */   }
/*     */   
/*     */   final Map<AttributeKey<?>, Object> attrs0() {
/* 411 */     return this.attrs;
/*     */   }
/*     */   
/*     */   final SocketAddress localAddress() {
/* 415 */     return this.localAddress;
/*     */   }
/*     */ 
/*     */   
/*     */   final ChannelFactory<? extends C> channelFactory() {
/* 420 */     return this.channelFactory;
/*     */   }
/*     */   
/*     */   final ChannelHandler handler() {
/* 424 */     return this.handler;
/*     */   }
/*     */   
/*     */   final Map<ChannelOption<?>, Object> options() {
/* 428 */     synchronized (this.options) {
/* 429 */       return copiedMap(this.options);
/*     */     } 
/*     */   }
/*     */   
/*     */   final Map<AttributeKey<?>, Object> attrs() {
/* 434 */     return copiedMap(this.attrs);
/*     */   }
/*     */   
/*     */   static <K, V> Map<K, V> copiedMap(Map<K, V> map) {
/* 438 */     if (map.isEmpty()) {
/* 439 */       return Collections.emptyMap();
/*     */     }
/* 441 */     return Collections.unmodifiableMap(new HashMap<K, V>(map));
/*     */   }
/*     */   
/*     */   static void setAttributes(Channel channel, Map.Entry<AttributeKey<?>, Object>[] attrs) {
/* 445 */     for (Map.Entry<AttributeKey<?>, Object> e : attrs) {
/*     */       
/* 447 */       AttributeKey<Object> key = (AttributeKey<Object>)e.getKey();
/* 448 */       channel.attr(key).set(e.getValue());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   static void setChannelOptions(Channel channel, Map.Entry<ChannelOption<?>, Object>[] options, InternalLogger logger) {
/* 454 */     for (Map.Entry<ChannelOption<?>, Object> e : options) {
/* 455 */       setChannelOption(channel, e.getKey(), e.getValue(), logger);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static void setChannelOption(Channel channel, ChannelOption<?> option, Object value, InternalLogger logger) {
/*     */     try {
/* 463 */       if (!channel.config().setOption(option, value)) {
/* 464 */         logger.warn("Unknown channel option '{}' for channel '{}'", option, channel);
/*     */       }
/* 466 */     } catch (Throwable t) {
/* 467 */       logger.warn("Failed to set channel option '{}' with value '{}' for channel '{}'", new Object[] { option, value, channel, t });
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 476 */     StringBuilder buf = (new StringBuilder()).append(StringUtil.simpleClassName(this)).append('(').append(config()).append(')');
/* 477 */     return buf.toString();
/*     */   }
/*     */   AbstractBootstrap() {}
/*     */   public abstract B clone();
/*     */   
/*     */   abstract void init(Channel paramChannel) throws Exception;
/*     */   
/*     */   public abstract AbstractBootstrapConfig<B, C> config();
/*     */   
/*     */   static final class PendingRegistrationPromise extends DefaultChannelPromise { PendingRegistrationPromise(Channel channel) {
/* 487 */       super(channel);
/*     */     }
/*     */     private volatile boolean registered;
/*     */     void registered() {
/* 491 */       this.registered = true;
/*     */     }
/*     */ 
/*     */     
/*     */     protected EventExecutor executor() {
/* 496 */       if (this.registered)
/*     */       {
/*     */ 
/*     */         
/* 500 */         return super.executor();
/*     */       }
/*     */       
/* 503 */       return (EventExecutor)GlobalEventExecutor.INSTANCE;
/*     */     } }
/*     */ 
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-transport-4.1.93.Final.jar!\io\netty\bootstrap\AbstractBootstrap.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */