/*     */ package io.netty.channel;
/*     */ 
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import io.netty.buffer.ByteBufAllocator;
/*     */ import io.netty.buffer.CompositeByteBuf;
/*     */ import io.netty.util.ReferenceCountUtil;
/*     */ import io.netty.util.internal.ObjectUtil;
/*     */ import io.netty.util.internal.PlatformDependent;
/*     */ import io.netty.util.internal.logging.InternalLogger;
/*     */ import io.netty.util.internal.logging.InternalLoggerFactory;
/*     */ import java.util.ArrayDeque;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractCoalescingBufferQueue
/*     */ {
/*  33 */   private static final InternalLogger logger = InternalLoggerFactory.getInstance(AbstractCoalescingBufferQueue.class);
/*     */ 
/*     */   
/*     */   private final ArrayDeque<Object> bufAndListenerPairs;
/*     */ 
/*     */   
/*     */   private final PendingBytesTracker tracker;
/*     */ 
/*     */   
/*     */   private int readableBytes;
/*     */ 
/*     */   
/*     */   protected AbstractCoalescingBufferQueue(Channel channel, int initSize) {
/*  46 */     this.bufAndListenerPairs = new ArrayDeque(initSize);
/*  47 */     this.tracker = (channel == null) ? null : PendingBytesTracker.newTracker(channel);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void addFirst(ByteBuf buf, ChannelPromise promise) {
/*  57 */     addFirst(buf, toChannelFutureListener(promise));
/*     */   }
/*     */   
/*     */   private void addFirst(ByteBuf buf, ChannelFutureListener listener) {
/*  61 */     if (listener != null) {
/*  62 */       this.bufAndListenerPairs.addFirst(listener);
/*     */     }
/*  64 */     this.bufAndListenerPairs.addFirst(buf);
/*  65 */     incrementReadableBytes(buf.readableBytes());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void add(ByteBuf buf) {
/*  72 */     add(buf, (ChannelFutureListener)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void add(ByteBuf buf, ChannelPromise promise) {
/*  84 */     add(buf, toChannelFutureListener(promise));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void add(ByteBuf buf, ChannelFutureListener listener) {
/*  96 */     this.bufAndListenerPairs.add(buf);
/*  97 */     if (listener != null) {
/*  98 */       this.bufAndListenerPairs.add(listener);
/*     */     }
/* 100 */     incrementReadableBytes(buf.readableBytes());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ByteBuf removeFirst(ChannelPromise aggregatePromise) {
/* 109 */     Object entry = this.bufAndListenerPairs.poll();
/* 110 */     if (entry == null) {
/* 111 */       return null;
/*     */     }
/* 113 */     assert entry instanceof ByteBuf;
/* 114 */     ByteBuf result = (ByteBuf)entry;
/*     */     
/* 116 */     decrementReadableBytes(result.readableBytes());
/*     */     
/* 118 */     entry = this.bufAndListenerPairs.peek();
/* 119 */     if (entry instanceof ChannelFutureListener) {
/* 120 */       aggregatePromise.addListener((ChannelFutureListener)entry);
/* 121 */       this.bufAndListenerPairs.poll();
/*     */     } 
/* 123 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ByteBuf remove(ByteBufAllocator alloc, int bytes, ChannelPromise aggregatePromise) {
/* 138 */     ObjectUtil.checkPositiveOrZero(bytes, "bytes");
/* 139 */     ObjectUtil.checkNotNull(aggregatePromise, "aggregatePromise");
/*     */ 
/*     */     
/* 142 */     if (this.bufAndListenerPairs.isEmpty()) {
/* 143 */       assert this.readableBytes == 0;
/* 144 */       return removeEmptyValue();
/*     */     } 
/* 146 */     bytes = Math.min(bytes, this.readableBytes);
/*     */     
/* 148 */     ByteBuf toReturn = null;
/* 149 */     ByteBuf entryBuffer = null;
/* 150 */     int originalBytes = bytes;
/*     */     try {
/*     */       while (true) {
/* 153 */         Object entry = this.bufAndListenerPairs.poll();
/* 154 */         if (entry == null) {
/*     */           break;
/*     */         }
/* 157 */         if (entry instanceof ChannelFutureListener) {
/* 158 */           aggregatePromise.addListener((ChannelFutureListener)entry);
/*     */           continue;
/*     */         } 
/* 161 */         entryBuffer = (ByteBuf)entry;
/* 162 */         if (entryBuffer.readableBytes() > bytes) {
/*     */           
/* 164 */           this.bufAndListenerPairs.addFirst(entryBuffer);
/* 165 */           if (bytes > 0) {
/*     */             
/* 167 */             entryBuffer = entryBuffer.readRetainedSlice(bytes);
/*     */             
/* 169 */             toReturn = (toReturn == null) ? composeFirst(alloc, entryBuffer) : compose(alloc, toReturn, entryBuffer);
/* 170 */             bytes = 0;
/*     */           } 
/*     */           break;
/*     */         } 
/* 174 */         bytes -= entryBuffer.readableBytes();
/*     */         
/* 176 */         toReturn = (toReturn == null) ? composeFirst(alloc, entryBuffer) : compose(alloc, toReturn, entryBuffer);
/*     */         
/* 178 */         entryBuffer = null;
/*     */       } 
/* 180 */     } catch (Throwable cause) {
/* 181 */       ReferenceCountUtil.safeRelease(entryBuffer);
/* 182 */       ReferenceCountUtil.safeRelease(toReturn);
/* 183 */       aggregatePromise.setFailure(cause);
/* 184 */       PlatformDependent.throwException(cause);
/*     */     } 
/* 186 */     decrementReadableBytes(originalBytes - bytes);
/* 187 */     return toReturn;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int readableBytes() {
/* 194 */     return this.readableBytes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isEmpty() {
/* 201 */     return this.bufAndListenerPairs.isEmpty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void releaseAndFailAll(ChannelOutboundInvoker invoker, Throwable cause) {
/* 208 */     releaseAndCompleteAll(invoker.newFailedFuture(cause));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void copyTo(AbstractCoalescingBufferQueue dest) {
/* 216 */     dest.bufAndListenerPairs.addAll(this.bufAndListenerPairs);
/* 217 */     dest.incrementReadableBytes(this.readableBytes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void writeAndRemoveAll(ChannelHandlerContext ctx) {
/* 225 */     Throwable pending = null;
/* 226 */     ByteBuf previousBuf = null;
/*     */     while (true) {
/* 228 */       Object entry = this.bufAndListenerPairs.poll();
/*     */       try {
/* 230 */         if (entry == null) {
/* 231 */           if (previousBuf != null) {
/* 232 */             decrementReadableBytes(previousBuf.readableBytes());
/* 233 */             ctx.write(previousBuf, ctx.voidPromise());
/*     */           } 
/*     */           
/*     */           break;
/*     */         } 
/* 238 */         if (entry instanceof ByteBuf) {
/* 239 */           if (previousBuf != null) {
/* 240 */             decrementReadableBytes(previousBuf.readableBytes());
/* 241 */             ctx.write(previousBuf, ctx.voidPromise());
/*     */           } 
/* 243 */           previousBuf = (ByteBuf)entry; continue;
/* 244 */         }  if (entry instanceof ChannelPromise) {
/* 245 */           decrementReadableBytes(previousBuf.readableBytes());
/* 246 */           ctx.write(previousBuf, (ChannelPromise)entry);
/* 247 */           previousBuf = null; continue;
/*     */         } 
/* 249 */         decrementReadableBytes(previousBuf.readableBytes());
/* 250 */         ctx.write(previousBuf).addListener((ChannelFutureListener)entry);
/* 251 */         previousBuf = null;
/*     */       }
/* 253 */       catch (Throwable t) {
/* 254 */         if (pending == null) {
/* 255 */           pending = t; continue;
/*     */         } 
/* 257 */         logger.info("Throwable being suppressed because Throwable {} is already pending", pending, t);
/*     */       } 
/*     */     } 
/*     */     
/* 261 */     if (pending != null) {
/* 262 */       throw new IllegalStateException(pending);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 268 */     return "bytes: " + this.readableBytes + " buffers: " + (size() >> 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract ByteBuf compose(ByteBufAllocator paramByteBufAllocator, ByteBuf paramByteBuf1, ByteBuf paramByteBuf2);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final ByteBuf composeIntoComposite(ByteBufAllocator alloc, ByteBuf cumulation, ByteBuf next) {
/* 282 */     CompositeByteBuf composite = alloc.compositeBuffer(size() + 2);
/*     */     try {
/* 284 */       composite.addComponent(true, cumulation);
/* 285 */       composite.addComponent(true, next);
/* 286 */     } catch (Throwable cause) {
/* 287 */       composite.release();
/* 288 */       ReferenceCountUtil.safeRelease(next);
/* 289 */       PlatformDependent.throwException(cause);
/*     */     } 
/* 291 */     return (ByteBuf)composite;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final ByteBuf copyAndCompose(ByteBufAllocator alloc, ByteBuf cumulation, ByteBuf next) {
/* 302 */     ByteBuf newCumulation = alloc.ioBuffer(cumulation.readableBytes() + next.readableBytes());
/*     */     try {
/* 304 */       newCumulation.writeBytes(cumulation).writeBytes(next);
/* 305 */     } catch (Throwable cause) {
/* 306 */       newCumulation.release();
/* 307 */       ReferenceCountUtil.safeRelease(next);
/* 308 */       PlatformDependent.throwException(cause);
/*     */     } 
/* 310 */     cumulation.release();
/* 311 */     next.release();
/* 312 */     return newCumulation;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ByteBuf composeFirst(ByteBufAllocator allocator, ByteBuf first) {
/* 320 */     return first;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract ByteBuf removeEmptyValue();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final int size() {
/* 334 */     return this.bufAndListenerPairs.size();
/*     */   }
/*     */   
/*     */   private void releaseAndCompleteAll(ChannelFuture future) {
/* 338 */     Throwable pending = null;
/*     */     while (true) {
/* 340 */       Object entry = this.bufAndListenerPairs.poll();
/* 341 */       if (entry == null) {
/*     */         break;
/*     */       }
/*     */       try {
/* 345 */         if (entry instanceof ByteBuf) {
/* 346 */           ByteBuf buffer = (ByteBuf)entry;
/* 347 */           decrementReadableBytes(buffer.readableBytes());
/* 348 */           ReferenceCountUtil.safeRelease(buffer); continue;
/*     */         } 
/* 350 */         ((ChannelFutureListener)entry).operationComplete(future);
/*     */       }
/* 352 */       catch (Throwable t) {
/* 353 */         if (pending == null) {
/* 354 */           pending = t; continue;
/*     */         } 
/* 356 */         logger.info("Throwable being suppressed because Throwable {} is already pending", pending, t);
/*     */       } 
/*     */     } 
/*     */     
/* 360 */     if (pending != null) {
/* 361 */       throw new IllegalStateException(pending);
/*     */     }
/*     */   }
/*     */   
/*     */   private void incrementReadableBytes(int increment) {
/* 366 */     int nextReadableBytes = this.readableBytes + increment;
/* 367 */     if (nextReadableBytes < this.readableBytes) {
/* 368 */       throw new IllegalStateException("buffer queue length overflow: " + this.readableBytes + " + " + increment);
/*     */     }
/* 370 */     this.readableBytes = nextReadableBytes;
/* 371 */     if (this.tracker != null) {
/* 372 */       this.tracker.incrementPendingOutboundBytes(increment);
/*     */     }
/*     */   }
/*     */   
/*     */   private void decrementReadableBytes(int decrement) {
/* 377 */     this.readableBytes -= decrement;
/* 378 */     assert this.readableBytes >= 0;
/* 379 */     if (this.tracker != null) {
/* 380 */       this.tracker.decrementPendingOutboundBytes(decrement);
/*     */     }
/*     */   }
/*     */   
/*     */   private static ChannelFutureListener toChannelFutureListener(ChannelPromise promise) {
/* 385 */     return promise.isVoid() ? null : new DelegatingChannelPromiseNotifier(promise);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-transport-4.1.93.Final.jar!\io\netty\channel\AbstractCoalescingBufferQueue.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */