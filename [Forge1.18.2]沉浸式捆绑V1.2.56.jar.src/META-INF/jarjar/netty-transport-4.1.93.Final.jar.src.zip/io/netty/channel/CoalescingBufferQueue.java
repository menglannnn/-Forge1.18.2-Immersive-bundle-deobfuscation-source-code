/*    */ package io.netty.channel;
/*    */ 
/*    */ import io.netty.buffer.ByteBuf;
/*    */ import io.netty.buffer.ByteBufAllocator;
/*    */ import io.netty.buffer.CompositeByteBuf;
/*    */ import io.netty.buffer.Unpooled;
/*    */ import io.netty.util.internal.ObjectUtil;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class CoalescingBufferQueue
/*    */   extends AbstractCoalescingBufferQueue
/*    */ {
/*    */   private final Channel channel;
/*    */   
/*    */   public CoalescingBufferQueue(Channel channel) {
/* 39 */     this(channel, 4);
/*    */   }
/*    */   
/*    */   public CoalescingBufferQueue(Channel channel, int initSize) {
/* 43 */     this(channel, initSize, false);
/*    */   }
/*    */   
/*    */   public CoalescingBufferQueue(Channel channel, int initSize, boolean updateWritability) {
/* 47 */     super(updateWritability ? channel : null, initSize);
/* 48 */     this.channel = (Channel)ObjectUtil.checkNotNull(channel, "channel");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ByteBuf remove(int bytes, ChannelPromise aggregatePromise) {
/* 62 */     return remove(this.channel.alloc(), bytes, aggregatePromise);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void releaseAndFailAll(Throwable cause) {
/* 69 */     releaseAndFailAll(this.channel, cause);
/*    */   }
/*    */ 
/*    */   
/*    */   protected ByteBuf compose(ByteBufAllocator alloc, ByteBuf cumulation, ByteBuf next) {
/* 74 */     if (cumulation instanceof CompositeByteBuf) {
/* 75 */       CompositeByteBuf composite = (CompositeByteBuf)cumulation;
/* 76 */       composite.addComponent(true, next);
/* 77 */       return (ByteBuf)composite;
/*    */     } 
/* 79 */     return composeIntoComposite(alloc, cumulation, next);
/*    */   }
/*    */ 
/*    */   
/*    */   protected ByteBuf removeEmptyValue() {
/* 84 */     return Unpooled.EMPTY_BUFFER;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-transport-4.1.93.Final.jar!\io\netty\channel\CoalescingBufferQueue.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */