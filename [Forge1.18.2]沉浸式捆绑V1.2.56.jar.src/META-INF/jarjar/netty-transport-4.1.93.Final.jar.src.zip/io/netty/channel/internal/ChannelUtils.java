package io.netty.channel.internal;

public final class ChannelUtils {
  public static final int MAX_BYTES_PER_GATHERING_WRITE_ATTEMPTED_LOW_THRESHOLD = 4096;
  
  public static final int WRITE_STATUS_SNDBUF_FULL = 2147483647;
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-transport-4.1.93.Final.jar!\io\netty\channel\internal\ChannelUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */