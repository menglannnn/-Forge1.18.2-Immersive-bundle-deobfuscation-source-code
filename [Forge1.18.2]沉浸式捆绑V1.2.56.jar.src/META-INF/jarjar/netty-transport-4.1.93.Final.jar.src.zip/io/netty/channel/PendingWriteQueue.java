/*     */ package io.netty.channel;
/*     */ 
/*     */ import io.netty.util.ReferenceCountUtil;
/*     */ import io.netty.util.concurrent.EventExecutor;
/*     */ import io.netty.util.concurrent.PromiseCombiner;
/*     */ import io.netty.util.internal.ObjectPool;
/*     */ import io.netty.util.internal.ObjectUtil;
/*     */ import io.netty.util.internal.SystemPropertyUtil;
/*     */ import io.netty.util.internal.logging.InternalLogger;
/*     */ import io.netty.util.internal.logging.InternalLoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class PendingWriteQueue
/*     */ {
/*  34 */   private static final InternalLogger logger = InternalLoggerFactory.getInstance(PendingWriteQueue.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  40 */   private static final int PENDING_WRITE_OVERHEAD = SystemPropertyUtil.getInt("io.netty.transport.pendingWriteSizeOverhead", 64);
/*     */   
/*     */   private final ChannelOutboundInvoker invoker;
/*     */   
/*     */   private final EventExecutor executor;
/*     */   
/*     */   private final PendingBytesTracker tracker;
/*     */   private PendingWrite head;
/*     */   private PendingWrite tail;
/*     */   private int size;
/*     */   private long bytes;
/*     */   
/*     */   public PendingWriteQueue(ChannelHandlerContext ctx) {
/*  53 */     this.tracker = PendingBytesTracker.newTracker(ctx.channel());
/*  54 */     this.invoker = ctx;
/*  55 */     this.executor = ctx.executor();
/*     */   }
/*     */   
/*     */   public PendingWriteQueue(Channel channel) {
/*  59 */     this.tracker = PendingBytesTracker.newTracker(channel);
/*  60 */     this.invoker = channel;
/*  61 */     this.executor = (EventExecutor)channel.eventLoop();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/*  68 */     assert this.executor.inEventLoop();
/*  69 */     return (this.head == null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int size() {
/*  76 */     assert this.executor.inEventLoop();
/*  77 */     return this.size;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long bytes() {
/*  85 */     assert this.executor.inEventLoop();
/*  86 */     return this.bytes;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private int size(Object msg) {
/*  92 */     int messageSize = this.tracker.size(msg);
/*  93 */     if (messageSize < 0)
/*     */     {
/*  95 */       messageSize = 0;
/*     */     }
/*  97 */     return messageSize + PENDING_WRITE_OVERHEAD;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void add(Object msg, ChannelPromise promise) {
/* 104 */     assert this.executor.inEventLoop();
/* 105 */     ObjectUtil.checkNotNull(msg, "msg");
/* 106 */     ObjectUtil.checkNotNull(promise, "promise");
/*     */ 
/*     */     
/* 109 */     int messageSize = size(msg);
/*     */     
/* 111 */     PendingWrite write = PendingWrite.newInstance(msg, messageSize, promise);
/* 112 */     PendingWrite currentTail = this.tail;
/* 113 */     if (currentTail == null) {
/* 114 */       this.tail = this.head = write;
/*     */     } else {
/* 116 */       currentTail.next = write;
/* 117 */       this.tail = write;
/*     */     } 
/* 119 */     this.size++;
/* 120 */     this.bytes += messageSize;
/* 121 */     this.tracker.incrementPendingOutboundBytes(write.size);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ChannelFuture removeAndWriteAll() {
/* 132 */     assert this.executor.inEventLoop();
/*     */     
/* 134 */     if (isEmpty()) {
/* 135 */       return null;
/*     */     }
/*     */     
/* 138 */     ChannelPromise p = this.invoker.newPromise();
/* 139 */     PromiseCombiner combiner = new PromiseCombiner(this.executor);
/*     */ 
/*     */     
/*     */     try {
/* 143 */       for (PendingWrite write = this.head; write != null; write = this.head) {
/* 144 */         this.head = this.tail = null;
/* 145 */         this.size = 0;
/* 146 */         this.bytes = 0L;
/*     */         
/* 148 */         while (write != null) {
/* 149 */           PendingWrite next = write.next;
/* 150 */           Object msg = write.msg;
/* 151 */           ChannelPromise promise = write.promise;
/* 152 */           recycle(write, false);
/* 153 */           if (!(promise instanceof VoidChannelPromise)) {
/* 154 */             combiner.add(promise);
/*     */           }
/* 156 */           this.invoker.write(msg, promise);
/* 157 */           write = next;
/*     */         } 
/*     */       } 
/* 160 */       combiner.finish(p);
/* 161 */     } catch (Throwable cause) {
/* 162 */       p.setFailure(cause);
/*     */     } 
/* 164 */     assertEmpty();
/* 165 */     return p;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeAndFailAll(Throwable cause) {
/* 173 */     assert this.executor.inEventLoop();
/* 174 */     ObjectUtil.checkNotNull(cause, "cause");
/*     */ 
/*     */     
/* 177 */     for (PendingWrite write = this.head; write != null; write = this.head) {
/* 178 */       this.head = this.tail = null;
/* 179 */       this.size = 0;
/* 180 */       this.bytes = 0L;
/* 181 */       while (write != null) {
/* 182 */         PendingWrite next = write.next;
/* 183 */         ReferenceCountUtil.safeRelease(write.msg);
/* 184 */         ChannelPromise promise = write.promise;
/* 185 */         recycle(write, false);
/* 186 */         safeFail(promise, cause);
/* 187 */         write = next;
/*     */       } 
/*     */     } 
/* 190 */     assertEmpty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeAndFail(Throwable cause) {
/* 198 */     assert this.executor.inEventLoop();
/* 199 */     ObjectUtil.checkNotNull(cause, "cause");
/*     */     
/* 201 */     PendingWrite write = this.head;
/* 202 */     if (write == null) {
/*     */       return;
/*     */     }
/* 205 */     ReferenceCountUtil.safeRelease(write.msg);
/* 206 */     ChannelPromise promise = write.promise;
/* 207 */     safeFail(promise, cause);
/* 208 */     recycle(write, true);
/*     */   }
/*     */   
/*     */   private void assertEmpty() {
/* 212 */     assert this.tail == null && this.head == null && this.size == 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ChannelFuture removeAndWrite() {
/* 223 */     assert this.executor.inEventLoop();
/* 224 */     PendingWrite write = this.head;
/* 225 */     if (write == null) {
/* 226 */       return null;
/*     */     }
/* 228 */     Object msg = write.msg;
/* 229 */     ChannelPromise promise = write.promise;
/* 230 */     recycle(write, true);
/* 231 */     return this.invoker.write(msg, promise);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ChannelPromise remove() {
/* 241 */     assert this.executor.inEventLoop();
/* 242 */     PendingWrite write = this.head;
/* 243 */     if (write == null) {
/* 244 */       return null;
/*     */     }
/* 246 */     ChannelPromise promise = write.promise;
/* 247 */     ReferenceCountUtil.safeRelease(write.msg);
/* 248 */     recycle(write, true);
/* 249 */     return promise;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object current() {
/* 256 */     assert this.executor.inEventLoop();
/* 257 */     PendingWrite write = this.head;
/* 258 */     if (write == null) {
/* 259 */       return null;
/*     */     }
/* 261 */     return write.msg;
/*     */   }
/*     */   
/*     */   private void recycle(PendingWrite write, boolean update) {
/* 265 */     PendingWrite next = write.next;
/* 266 */     long writeSize = write.size;
/*     */     
/* 268 */     if (update) {
/* 269 */       if (next == null) {
/*     */ 
/*     */         
/* 272 */         this.head = this.tail = null;
/* 273 */         this.size = 0;
/* 274 */         this.bytes = 0L;
/*     */       } else {
/* 276 */         this.head = next;
/* 277 */         this.size--;
/* 278 */         this.bytes -= writeSize;
/* 279 */         assert this.size > 0 && this.bytes >= 0L;
/*     */       } 
/*     */     }
/*     */     
/* 283 */     write.recycle();
/* 284 */     this.tracker.decrementPendingOutboundBytes(writeSize);
/*     */   }
/*     */   
/*     */   private static void safeFail(ChannelPromise promise, Throwable cause) {
/* 288 */     if (!(promise instanceof VoidChannelPromise) && !promise.tryFailure(cause)) {
/* 289 */       logger.warn("Failed to mark a promise as failure because it's done already: {}", promise, cause);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static final class PendingWrite
/*     */   {
/* 297 */     private static final ObjectPool<PendingWrite> RECYCLER = ObjectPool.newPool(new ObjectPool.ObjectCreator<PendingWrite>()
/*     */         {
/*     */           public PendingWriteQueue.PendingWrite newObject(ObjectPool.Handle<PendingWriteQueue.PendingWrite> handle) {
/* 300 */             return new PendingWriteQueue.PendingWrite(handle);
/*     */           }
/*     */         });
/*     */     
/*     */     private final ObjectPool.Handle<PendingWrite> handle;
/*     */     private PendingWrite next;
/*     */     private long size;
/*     */     private ChannelPromise promise;
/*     */     private Object msg;
/*     */     
/*     */     private PendingWrite(ObjectPool.Handle<PendingWrite> handle) {
/* 311 */       this.handle = handle;
/*     */     }
/*     */     
/*     */     static PendingWrite newInstance(Object msg, int size, ChannelPromise promise) {
/* 315 */       PendingWrite write = (PendingWrite)RECYCLER.get();
/* 316 */       write.size = size;
/* 317 */       write.msg = msg;
/* 318 */       write.promise = promise;
/* 319 */       return write;
/*     */     }
/*     */     
/*     */     private void recycle() {
/* 323 */       this.size = 0L;
/* 324 */       this.next = null;
/* 325 */       this.msg = null;
/* 326 */       this.promise = null;
/* 327 */       this.handle.recycle(this);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-transport-4.1.93.Final.jar!\io\netty\channel\PendingWriteQueue.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */