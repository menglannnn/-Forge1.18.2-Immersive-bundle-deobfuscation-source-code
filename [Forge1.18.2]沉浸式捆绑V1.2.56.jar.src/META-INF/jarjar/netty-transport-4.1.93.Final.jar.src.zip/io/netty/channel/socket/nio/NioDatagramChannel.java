/*     */ package io.netty.channel.socket.nio;
/*     */ 
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import io.netty.channel.AddressedEnvelope;
/*     */ import io.netty.channel.ChannelConfig;
/*     */ import io.netty.channel.ChannelException;
/*     */ import io.netty.channel.ChannelFuture;
/*     */ import io.netty.channel.ChannelMetadata;
/*     */ import io.netty.channel.ChannelOption;
/*     */ import io.netty.channel.ChannelOutboundBuffer;
/*     */ import io.netty.channel.ChannelPromise;
/*     */ import io.netty.channel.DefaultAddressedEnvelope;
/*     */ import io.netty.channel.RecvByteBufAllocator;
/*     */ import io.netty.channel.nio.AbstractNioMessageChannel;
/*     */ import io.netty.channel.socket.DatagramChannel;
/*     */ import io.netty.channel.socket.DatagramChannelConfig;
/*     */ import io.netty.channel.socket.DatagramPacket;
/*     */ import io.netty.channel.socket.InternetProtocolFamily;
/*     */ import io.netty.util.ReferenceCounted;
/*     */ import io.netty.util.UncheckedBooleanSupplier;
/*     */ import io.netty.util.internal.ObjectUtil;
/*     */ import io.netty.util.internal.PlatformDependent;
/*     */ import io.netty.util.internal.SocketUtils;
/*     */ import io.netty.util.internal.StringUtil;
/*     */ import io.netty.util.internal.SuppressJava6Requirement;
/*     */ import java.io.IOException;
/*     */ import java.net.InetAddress;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.NetworkInterface;
/*     */ import java.net.SocketAddress;
/*     */ import java.net.SocketException;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.channels.DatagramChannel;
/*     */ import java.nio.channels.MembershipKey;
/*     */ import java.nio.channels.SelectableChannel;
/*     */ import java.nio.channels.UnresolvedAddressException;
/*     */ import java.nio.channels.spi.SelectorProvider;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class NioDatagramChannel
/*     */   extends AbstractNioMessageChannel
/*     */   implements DatagramChannel
/*     */ {
/*  68 */   private static final ChannelMetadata METADATA = new ChannelMetadata(true);
/*  69 */   private static final SelectorProvider DEFAULT_SELECTOR_PROVIDER = SelectorProvider.provider();
/*  70 */   private static final String EXPECTED_TYPES = " (expected: " + 
/*  71 */     StringUtil.simpleClassName(DatagramPacket.class) + ", " + 
/*  72 */     StringUtil.simpleClassName(AddressedEnvelope.class) + '<' + 
/*  73 */     StringUtil.simpleClassName(ByteBuf.class) + ", " + 
/*  74 */     StringUtil.simpleClassName(SocketAddress.class) + ">, " + 
/*  75 */     StringUtil.simpleClassName(ByteBuf.class) + ')';
/*     */ 
/*     */ 
/*     */   
/*     */   private final DatagramChannelConfig config;
/*     */ 
/*     */ 
/*     */   
/*     */   private Map<InetAddress, List<MembershipKey>> memberships;
/*     */ 
/*     */ 
/*     */   
/*     */   private static DatagramChannel newSocket(SelectorProvider provider) {
/*     */     try {
/*  89 */       return provider.openDatagramChannel();
/*  90 */     } catch (IOException e) {
/*  91 */       throw new ChannelException("Failed to open a socket.", e);
/*     */     } 
/*     */   }
/*     */   
/*     */   @SuppressJava6Requirement(reason = "Usage guarded by java version check")
/*     */   private static DatagramChannel newSocket(SelectorProvider provider, InternetProtocolFamily ipFamily) {
/*  97 */     if (ipFamily == null) {
/*  98 */       return newSocket(provider);
/*     */     }
/*     */     
/* 101 */     checkJavaVersion();
/*     */     
/*     */     try {
/* 104 */       return provider.openDatagramChannel(ProtocolFamilyConverter.convert(ipFamily));
/* 105 */     } catch (IOException e) {
/* 106 */       throw new ChannelException("Failed to open a socket.", e);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void checkJavaVersion() {
/* 111 */     if (PlatformDependent.javaVersion() < 7) {
/* 112 */       throw new UnsupportedOperationException("Only supported on java 7+.");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NioDatagramChannel() {
/* 120 */     this(newSocket(DEFAULT_SELECTOR_PROVIDER));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NioDatagramChannel(SelectorProvider provider) {
/* 128 */     this(newSocket(provider));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NioDatagramChannel(InternetProtocolFamily ipFamily) {
/* 136 */     this(newSocket(DEFAULT_SELECTOR_PROVIDER, ipFamily));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NioDatagramChannel(SelectorProvider provider, InternetProtocolFamily ipFamily) {
/* 145 */     this(newSocket(provider, ipFamily));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NioDatagramChannel(DatagramChannel socket) {
/* 152 */     super(null, socket, 1);
/* 153 */     this.config = (DatagramChannelConfig)new NioDatagramChannelConfig(this, socket);
/*     */   }
/*     */ 
/*     */   
/*     */   public ChannelMetadata metadata() {
/* 158 */     return METADATA;
/*     */   }
/*     */ 
/*     */   
/*     */   public DatagramChannelConfig config() {
/* 163 */     return this.config;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isActive() {
/* 169 */     DatagramChannel ch = javaChannel();
/* 170 */     return (ch.isOpen() && ((((Boolean)this.config
/* 171 */       .getOption(ChannelOption.DATAGRAM_CHANNEL_ACTIVE_ON_REGISTRATION)).booleanValue() && isRegistered()) || ch
/* 172 */       .socket().isBound()));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isConnected() {
/* 177 */     return javaChannel().isConnected();
/*     */   }
/*     */ 
/*     */   
/*     */   protected DatagramChannel javaChannel() {
/* 182 */     return (DatagramChannel)super.javaChannel();
/*     */   }
/*     */ 
/*     */   
/*     */   protected SocketAddress localAddress0() {
/* 187 */     return javaChannel().socket().getLocalSocketAddress();
/*     */   }
/*     */ 
/*     */   
/*     */   protected SocketAddress remoteAddress0() {
/* 192 */     return javaChannel().socket().getRemoteSocketAddress();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void doBind(SocketAddress localAddress) throws Exception {
/* 197 */     doBind0(localAddress);
/*     */   }
/*     */   
/*     */   private void doBind0(SocketAddress localAddress) throws Exception {
/* 201 */     if (PlatformDependent.javaVersion() >= 7) {
/* 202 */       SocketUtils.bind(javaChannel(), localAddress);
/*     */     } else {
/* 204 */       javaChannel().socket().bind(localAddress);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean doConnect(SocketAddress remoteAddress, SocketAddress localAddress) throws Exception {
/* 211 */     if (localAddress != null) {
/* 212 */       doBind0(localAddress);
/*     */     }
/*     */     
/* 215 */     boolean success = false;
/*     */     try {
/* 217 */       javaChannel().connect(remoteAddress);
/* 218 */       success = true;
/* 219 */       return true;
/*     */     } finally {
/* 221 */       if (!success) {
/* 222 */         doClose();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void doFinishConnect() throws Exception {
/* 229 */     throw new Error();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void doDisconnect() throws Exception {
/* 234 */     javaChannel().disconnect();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void doClose() throws Exception {
/* 239 */     javaChannel().close();
/*     */   }
/*     */ 
/*     */   
/*     */   protected int doReadMessages(List<Object> buf) throws Exception {
/* 244 */     DatagramChannel ch = javaChannel();
/* 245 */     DatagramChannelConfig config = config();
/* 246 */     RecvByteBufAllocator.Handle allocHandle = unsafe().recvBufAllocHandle();
/*     */     
/* 248 */     ByteBuf data = allocHandle.allocate(config.getAllocator());
/* 249 */     allocHandle.attemptedBytesRead(data.writableBytes());
/* 250 */     boolean free = true;
/*     */     try {
/* 252 */       ByteBuffer nioData = data.internalNioBuffer(data.writerIndex(), data.writableBytes());
/* 253 */       int pos = nioData.position();
/* 254 */       InetSocketAddress remoteAddress = (InetSocketAddress)ch.receive(nioData);
/* 255 */       if (remoteAddress == null) {
/* 256 */         return 0;
/*     */       }
/*     */       
/* 259 */       allocHandle.lastBytesRead(nioData.position() - pos);
/* 260 */       buf.add(new DatagramPacket(data.writerIndex(data.writerIndex() + allocHandle.lastBytesRead()), 
/* 261 */             localAddress(), remoteAddress));
/* 262 */       free = false;
/* 263 */       return 1;
/* 264 */     } catch (Throwable cause) {
/* 265 */       PlatformDependent.throwException(cause);
/* 266 */       return -1;
/*     */     } finally {
/* 268 */       if (free) {
/* 269 */         data.release();
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   protected boolean doWriteMessage(Object msg, ChannelOutboundBuffer in) throws Exception {
/*     */     SocketAddress remoteAddress;
/*     */     ByteBuf data;
/*     */     int writtenBytes;
/* 278 */     if (msg instanceof AddressedEnvelope) {
/*     */       
/* 280 */       AddressedEnvelope<ByteBuf, SocketAddress> envelope = (AddressedEnvelope<ByteBuf, SocketAddress>)msg;
/* 281 */       remoteAddress = envelope.recipient();
/* 282 */       data = (ByteBuf)envelope.content();
/*     */     } else {
/* 284 */       data = (ByteBuf)msg;
/* 285 */       remoteAddress = null;
/*     */     } 
/*     */     
/* 288 */     int dataLen = data.readableBytes();
/* 289 */     if (dataLen == 0) {
/* 290 */       return true;
/*     */     }
/*     */ 
/*     */     
/* 294 */     ByteBuffer nioData = (data.nioBufferCount() == 1) ? data.internalNioBuffer(data.readerIndex(), dataLen) : data.nioBuffer(data.readerIndex(), dataLen);
/*     */     
/* 296 */     if (remoteAddress != null) {
/* 297 */       writtenBytes = javaChannel().send(nioData, remoteAddress);
/*     */     } else {
/* 299 */       writtenBytes = javaChannel().write(nioData);
/*     */     } 
/* 301 */     return (writtenBytes > 0);
/*     */   }
/*     */   
/*     */   private static void checkUnresolved(AddressedEnvelope<?, ?> envelope) {
/* 305 */     if (envelope.recipient() instanceof InetSocketAddress && ((InetSocketAddress)envelope
/* 306 */       .recipient()).isUnresolved()) {
/* 307 */       throw new UnresolvedAddressException();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected Object filterOutboundMessage(Object msg) {
/* 313 */     if (msg instanceof DatagramPacket) {
/* 314 */       DatagramPacket p = (DatagramPacket)msg;
/* 315 */       checkUnresolved((AddressedEnvelope<?, ?>)p);
/* 316 */       ByteBuf content = (ByteBuf)p.content();
/* 317 */       if (isSingleDirectBuffer(content)) {
/* 318 */         return p;
/*     */       }
/* 320 */       return new DatagramPacket(newDirectBuffer((ReferenceCounted)p, content), (InetSocketAddress)p.recipient());
/*     */     } 
/*     */     
/* 323 */     if (msg instanceof ByteBuf) {
/* 324 */       ByteBuf buf = (ByteBuf)msg;
/* 325 */       if (isSingleDirectBuffer(buf)) {
/* 326 */         return buf;
/*     */       }
/* 328 */       return newDirectBuffer(buf);
/*     */     } 
/*     */     
/* 331 */     if (msg instanceof AddressedEnvelope) {
/*     */       
/* 333 */       AddressedEnvelope<Object, SocketAddress> e = (AddressedEnvelope<Object, SocketAddress>)msg;
/* 334 */       checkUnresolved(e);
/* 335 */       if (e.content() instanceof ByteBuf) {
/* 336 */         ByteBuf content = (ByteBuf)e.content();
/* 337 */         if (isSingleDirectBuffer(content)) {
/* 338 */           return e;
/*     */         }
/* 340 */         return new DefaultAddressedEnvelope(newDirectBuffer((ReferenceCounted)e, content), e.recipient());
/*     */       } 
/*     */     } 
/*     */     
/* 344 */     throw new UnsupportedOperationException("unsupported message type: " + 
/* 345 */         StringUtil.simpleClassName(msg) + EXPECTED_TYPES);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isSingleDirectBuffer(ByteBuf buf) {
/* 353 */     return (buf.isDirect() && buf.nioBufferCount() == 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean continueOnWriteError() {
/* 361 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public InetSocketAddress localAddress() {
/* 366 */     return (InetSocketAddress)super.localAddress();
/*     */   }
/*     */ 
/*     */   
/*     */   public InetSocketAddress remoteAddress() {
/* 371 */     return (InetSocketAddress)super.remoteAddress();
/*     */   }
/*     */ 
/*     */   
/*     */   public ChannelFuture joinGroup(InetAddress multicastAddress) {
/* 376 */     return joinGroup(multicastAddress, newPromise());
/*     */   }
/*     */ 
/*     */   
/*     */   public ChannelFuture joinGroup(InetAddress multicastAddress, ChannelPromise promise) {
/*     */     try {
/* 382 */       NetworkInterface iface = this.config.getNetworkInterface();
/* 383 */       if (iface == null) {
/* 384 */         iface = NetworkInterface.getByInetAddress(localAddress().getAddress());
/*     */       }
/* 386 */       return joinGroup(multicastAddress, iface, (InetAddress)null, promise);
/*     */     }
/* 388 */     catch (SocketException e) {
/* 389 */       promise.setFailure(e);
/*     */       
/* 391 */       return (ChannelFuture)promise;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public ChannelFuture joinGroup(InetSocketAddress multicastAddress, NetworkInterface networkInterface) {
/* 397 */     return joinGroup(multicastAddress, networkInterface, newPromise());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ChannelFuture joinGroup(InetSocketAddress multicastAddress, NetworkInterface networkInterface, ChannelPromise promise) {
/* 404 */     return joinGroup(multicastAddress.getAddress(), networkInterface, (InetAddress)null, promise);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ChannelFuture joinGroup(InetAddress multicastAddress, NetworkInterface networkInterface, InetAddress source) {
/* 410 */     return joinGroup(multicastAddress, networkInterface, source, newPromise());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SuppressJava6Requirement(reason = "Usage guarded by java version check")
/*     */   public ChannelFuture joinGroup(InetAddress multicastAddress, NetworkInterface networkInterface, InetAddress source, ChannelPromise promise) {
/* 419 */     checkJavaVersion();
/*     */     
/* 421 */     ObjectUtil.checkNotNull(multicastAddress, "multicastAddress");
/* 422 */     ObjectUtil.checkNotNull(networkInterface, "networkInterface");
/*     */     
/*     */     try {
/*     */       MembershipKey key;
/* 426 */       if (source == null) {
/* 427 */         key = javaChannel().join(multicastAddress, networkInterface);
/*     */       } else {
/* 429 */         key = javaChannel().join(multicastAddress, networkInterface, source);
/*     */       } 
/*     */       
/* 432 */       synchronized (this) {
/* 433 */         List<MembershipKey> keys = null;
/* 434 */         if (this.memberships == null) {
/* 435 */           this.memberships = new HashMap<InetAddress, List<MembershipKey>>();
/*     */         } else {
/* 437 */           keys = this.memberships.get(multicastAddress);
/*     */         } 
/* 439 */         if (keys == null) {
/* 440 */           keys = new ArrayList<MembershipKey>();
/* 441 */           this.memberships.put(multicastAddress, keys);
/*     */         } 
/* 443 */         keys.add(key);
/*     */       } 
/*     */       
/* 446 */       promise.setSuccess();
/* 447 */     } catch (Throwable e) {
/* 448 */       promise.setFailure(e);
/*     */     } 
/*     */     
/* 451 */     return (ChannelFuture)promise;
/*     */   }
/*     */ 
/*     */   
/*     */   public ChannelFuture leaveGroup(InetAddress multicastAddress) {
/* 456 */     return leaveGroup(multicastAddress, newPromise());
/*     */   }
/*     */ 
/*     */   
/*     */   public ChannelFuture leaveGroup(InetAddress multicastAddress, ChannelPromise promise) {
/*     */     try {
/* 462 */       return leaveGroup(multicastAddress, 
/* 463 */           NetworkInterface.getByInetAddress(localAddress().getAddress()), (InetAddress)null, promise);
/* 464 */     } catch (SocketException e) {
/* 465 */       promise.setFailure(e);
/*     */       
/* 467 */       return (ChannelFuture)promise;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public ChannelFuture leaveGroup(InetSocketAddress multicastAddress, NetworkInterface networkInterface) {
/* 473 */     return leaveGroup(multicastAddress, networkInterface, newPromise());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ChannelFuture leaveGroup(InetSocketAddress multicastAddress, NetworkInterface networkInterface, ChannelPromise promise) {
/* 480 */     return leaveGroup(multicastAddress.getAddress(), networkInterface, (InetAddress)null, promise);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ChannelFuture leaveGroup(InetAddress multicastAddress, NetworkInterface networkInterface, InetAddress source) {
/* 486 */     return leaveGroup(multicastAddress, networkInterface, source, newPromise());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SuppressJava6Requirement(reason = "Usage guarded by java version check")
/*     */   public ChannelFuture leaveGroup(InetAddress multicastAddress, NetworkInterface networkInterface, InetAddress source, ChannelPromise promise) {
/* 494 */     checkJavaVersion();
/*     */     
/* 496 */     ObjectUtil.checkNotNull(multicastAddress, "multicastAddress");
/* 497 */     ObjectUtil.checkNotNull(networkInterface, "networkInterface");
/*     */     
/* 499 */     synchronized (this) {
/* 500 */       if (this.memberships != null) {
/* 501 */         List<MembershipKey> keys = this.memberships.get(multicastAddress);
/* 502 */         if (keys != null) {
/* 503 */           Iterator<MembershipKey> keyIt = keys.iterator();
/*     */           
/* 505 */           while (keyIt.hasNext()) {
/* 506 */             MembershipKey key = keyIt.next();
/* 507 */             if (networkInterface.equals(key.networkInterface()) && ((
/* 508 */               source == null && key.sourceAddress() == null) || (source != null && source
/* 509 */               .equals(key.sourceAddress())))) {
/* 510 */               key.drop();
/* 511 */               keyIt.remove();
/*     */             } 
/*     */           } 
/*     */           
/* 515 */           if (keys.isEmpty()) {
/* 516 */             this.memberships.remove(multicastAddress);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 522 */     promise.setSuccess();
/* 523 */     return (ChannelFuture)promise;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ChannelFuture block(InetAddress multicastAddress, NetworkInterface networkInterface, InetAddress sourceToBlock) {
/* 533 */     return block(multicastAddress, networkInterface, sourceToBlock, newPromise());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SuppressJava6Requirement(reason = "Usage guarded by java version check")
/*     */   public ChannelFuture block(InetAddress multicastAddress, NetworkInterface networkInterface, InetAddress sourceToBlock, ChannelPromise promise) {
/* 544 */     checkJavaVersion();
/*     */     
/* 546 */     ObjectUtil.checkNotNull(multicastAddress, "multicastAddress");
/* 547 */     ObjectUtil.checkNotNull(sourceToBlock, "sourceToBlock");
/* 548 */     ObjectUtil.checkNotNull(networkInterface, "networkInterface");
/*     */     
/* 550 */     synchronized (this) {
/* 551 */       if (this.memberships != null) {
/* 552 */         List<MembershipKey> keys = this.memberships.get(multicastAddress);
/* 553 */         for (MembershipKey key : keys) {
/* 554 */           if (networkInterface.equals(key.networkInterface())) {
/*     */             try {
/* 556 */               key.block(sourceToBlock);
/* 557 */             } catch (IOException e) {
/* 558 */               promise.setFailure(e);
/*     */             } 
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/* 564 */     promise.setSuccess();
/* 565 */     return (ChannelFuture)promise;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ChannelFuture block(InetAddress multicastAddress, InetAddress sourceToBlock) {
/* 574 */     return block(multicastAddress, sourceToBlock, newPromise());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ChannelFuture block(InetAddress multicastAddress, InetAddress sourceToBlock, ChannelPromise promise) {
/*     */     try {
/* 585 */       return block(multicastAddress, 
/*     */           
/* 587 */           NetworkInterface.getByInetAddress(localAddress().getAddress()), sourceToBlock, promise);
/*     */     }
/* 589 */     catch (SocketException e) {
/* 590 */       promise.setFailure(e);
/*     */       
/* 592 */       return (ChannelFuture)promise;
/*     */     } 
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   protected void setReadPending(boolean readPending) {
/* 598 */     super.setReadPending(readPending);
/*     */   }
/*     */   
/*     */   void clearReadPending0() {
/* 602 */     clearReadPending();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean closeOnReadError(Throwable cause) {
/* 609 */     if (cause instanceof SocketException) {
/* 610 */       return false;
/*     */     }
/* 612 */     return super.closeOnReadError(cause);
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean continueReading(RecvByteBufAllocator.Handle allocHandle) {
/* 617 */     if (allocHandle instanceof RecvByteBufAllocator.ExtendedHandle)
/*     */     {
/*     */       
/* 620 */       return ((RecvByteBufAllocator.ExtendedHandle)allocHandle)
/* 621 */         .continueReading(UncheckedBooleanSupplier.TRUE_SUPPLIER);
/*     */     }
/* 623 */     return allocHandle.continueReading();
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-transport-4.1.93.Final.jar!\io\netty\channel\socket\nio\NioDatagramChannel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */