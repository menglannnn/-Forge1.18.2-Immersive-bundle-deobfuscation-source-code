/*    */ package io.netty.channel.socket;
/*    */ 
/*    */ import io.netty.util.NetUtil;
/*    */ import java.net.Inet4Address;
/*    */ import java.net.Inet6Address;
/*    */ import java.net.InetAddress;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum InternetProtocolFamily
/*    */ {
/* 28 */   IPv4((Class)Inet4Address.class, 1),
/* 29 */   IPv6((Class)Inet6Address.class, 2);
/*    */   
/*    */   private final Class<? extends InetAddress> addressType;
/*    */   private final int addressNumber;
/*    */   
/*    */   InternetProtocolFamily(Class<? extends InetAddress> addressType, int addressNumber) {
/* 35 */     this.addressType = addressType;
/* 36 */     this.addressNumber = addressNumber;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Class<? extends InetAddress> addressType() {
/* 43 */     return this.addressType;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int addressNumber() {
/* 52 */     return this.addressNumber;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public InetAddress localhost() {
/* 59 */     switch (this) {
/*    */       case IPv4:
/* 61 */         return NetUtil.LOCALHOST4;
/*    */       case IPv6:
/* 63 */         return NetUtil.LOCALHOST6;
/*    */     } 
/* 65 */     throw new IllegalStateException("Unsupported family " + this);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static InternetProtocolFamily of(InetAddress address) {
/* 73 */     if (address instanceof Inet4Address) {
/* 74 */       return IPv4;
/*    */     }
/* 76 */     if (address instanceof Inet6Address) {
/* 77 */       return IPv6;
/*    */     }
/* 79 */     throw new IllegalArgumentException("address " + address + " not supported");
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-transport-4.1.93.Final.jar!\io\netty\channel\socket\InternetProtocolFamily.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */