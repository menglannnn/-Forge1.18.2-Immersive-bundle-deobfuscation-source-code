/*    */ package io.netty.channel.socket.nio;
/*    */ 
/*    */ import io.netty.channel.socket.InternetProtocolFamily;
/*    */ import io.netty.util.internal.PlatformDependent;
/*    */ import io.netty.util.internal.SuppressJava6Requirement;
/*    */ import io.netty.util.internal.logging.InternalLogger;
/*    */ import io.netty.util.internal.logging.InternalLoggerFactory;
/*    */ import java.io.IOException;
/*    */ import java.lang.reflect.InvocationTargetException;
/*    */ import java.lang.reflect.Method;
/*    */ import java.net.ProtocolFamily;
/*    */ import java.nio.channels.spi.SelectorProvider;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class SelectorProviderUtil
/*    */ {
/* 33 */   private static final InternalLogger logger = InternalLoggerFactory.getInstance(SelectorProviderUtil.class);
/*    */   
/*    */   @SuppressJava6Requirement(reason = "Usage guarded by java version check")
/*    */   static Method findOpenMethod(String methodName) {
/* 37 */     if (PlatformDependent.javaVersion() >= 15) {
/*    */       try {
/* 39 */         return SelectorProvider.class.getMethod(methodName, new Class[] { ProtocolFamily.class });
/* 40 */       } catch (Throwable e) {
/* 41 */         logger.debug("SelectorProvider.{}(ProtocolFamily) not available, will use default", methodName, e);
/*    */       } 
/*    */     }
/* 44 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @SuppressJava6Requirement(reason = "Usage guarded by java version check")
/*    */   static <C extends java.nio.channels.Channel> C newChannel(Method method, SelectorProvider provider, InternetProtocolFamily family) throws IOException {
/* 56 */     if (family != null && method != null) {
/*    */       
/*    */       try {
/* 59 */         return (C)method.invoke(provider, new Object[] {
/* 60 */               ProtocolFamilyConverter.convert(family)
/*    */             });
/* 62 */       } catch (InvocationTargetException e) {
/* 63 */         throw new IOException(e);
/* 64 */       } catch (IllegalAccessException e) {
/* 65 */         throw new IOException(e);
/*    */       } 
/*    */     }
/* 68 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-transport-4.1.93.Final.jar!\io\netty\channel\socket\nio\SelectorProviderUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */