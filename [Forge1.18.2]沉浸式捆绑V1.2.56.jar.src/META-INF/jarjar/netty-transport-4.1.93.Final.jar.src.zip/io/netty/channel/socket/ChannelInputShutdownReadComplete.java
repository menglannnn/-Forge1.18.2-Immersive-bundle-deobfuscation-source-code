/*    */ package io.netty.channel.socket;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ChannelInputShutdownReadComplete
/*    */ {
/* 23 */   public static final ChannelInputShutdownReadComplete INSTANCE = new ChannelInputShutdownReadComplete();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-transport-4.1.93.Final.jar!\io\netty\channel\socket\ChannelInputShutdownReadComplete.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */