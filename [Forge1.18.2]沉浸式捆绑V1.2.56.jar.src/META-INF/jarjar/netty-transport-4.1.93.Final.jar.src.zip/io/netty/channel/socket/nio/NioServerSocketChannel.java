/*     */ package io.netty.channel.socket.nio;
/*     */ 
/*     */ import io.netty.channel.Channel;
/*     */ import io.netty.channel.ChannelConfig;
/*     */ import io.netty.channel.ChannelException;
/*     */ import io.netty.channel.ChannelMetadata;
/*     */ import io.netty.channel.ChannelOption;
/*     */ import io.netty.channel.ChannelOutboundBuffer;
/*     */ import io.netty.channel.nio.AbstractNioMessageChannel;
/*     */ import io.netty.channel.socket.DefaultServerSocketChannelConfig;
/*     */ import io.netty.channel.socket.InternetProtocolFamily;
/*     */ import io.netty.channel.socket.ServerSocketChannel;
/*     */ import io.netty.channel.socket.ServerSocketChannelConfig;
/*     */ import io.netty.util.internal.PlatformDependent;
/*     */ import io.netty.util.internal.SocketUtils;
/*     */ import io.netty.util.internal.SuppressJava6Requirement;
/*     */ import io.netty.util.internal.logging.InternalLogger;
/*     */ import io.netty.util.internal.logging.InternalLoggerFactory;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.ServerSocket;
/*     */ import java.net.SocketAddress;
/*     */ import java.nio.channels.SelectableChannel;
/*     */ import java.nio.channels.ServerSocketChannel;
/*     */ import java.nio.channels.SocketChannel;
/*     */ import java.nio.channels.spi.SelectorProvider;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NioServerSocketChannel
/*     */   extends AbstractNioMessageChannel
/*     */   implements ServerSocketChannel
/*     */ {
/*  51 */   private static final ChannelMetadata METADATA = new ChannelMetadata(false, 16);
/*  52 */   private static final SelectorProvider DEFAULT_SELECTOR_PROVIDER = SelectorProvider.provider();
/*     */   
/*  54 */   private static final InternalLogger logger = InternalLoggerFactory.getInstance(NioServerSocketChannel.class);
/*     */ 
/*     */   
/*  57 */   private static final Method OPEN_SERVER_SOCKET_CHANNEL_WITH_FAMILY = SelectorProviderUtil.findOpenMethod("openServerSocketChannel");
/*     */   private final ServerSocketChannelConfig config;
/*     */   
/*     */   private static ServerSocketChannel newChannel(SelectorProvider provider, InternetProtocolFamily family) {
/*     */     try {
/*  62 */       ServerSocketChannel channel = SelectorProviderUtil.<ServerSocketChannel>newChannel(OPEN_SERVER_SOCKET_CHANNEL_WITH_FAMILY, provider, family);
/*  63 */       return (channel == null) ? provider.openServerSocketChannel() : channel;
/*  64 */     } catch (IOException e) {
/*  65 */       throw new ChannelException("Failed to open a socket.", e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NioServerSocketChannel() {
/*  75 */     this(DEFAULT_SELECTOR_PROVIDER);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NioServerSocketChannel(SelectorProvider provider) {
/*  82 */     this(provider, (InternetProtocolFamily)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NioServerSocketChannel(SelectorProvider provider, InternetProtocolFamily family) {
/*  89 */     this(newChannel(provider, family));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NioServerSocketChannel(ServerSocketChannel channel) {
/*  96 */     super(null, channel, 16);
/*  97 */     this.config = (ServerSocketChannelConfig)new NioServerSocketChannelConfig(this, javaChannel().socket());
/*     */   }
/*     */ 
/*     */   
/*     */   public InetSocketAddress localAddress() {
/* 102 */     return (InetSocketAddress)super.localAddress();
/*     */   }
/*     */ 
/*     */   
/*     */   public ChannelMetadata metadata() {
/* 107 */     return METADATA;
/*     */   }
/*     */ 
/*     */   
/*     */   public ServerSocketChannelConfig config() {
/* 112 */     return this.config;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isActive() {
/* 119 */     return (isOpen() && javaChannel().socket().isBound());
/*     */   }
/*     */ 
/*     */   
/*     */   public InetSocketAddress remoteAddress() {
/* 124 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   protected ServerSocketChannel javaChannel() {
/* 129 */     return (ServerSocketChannel)super.javaChannel();
/*     */   }
/*     */ 
/*     */   
/*     */   protected SocketAddress localAddress0() {
/* 134 */     return SocketUtils.localSocketAddress(javaChannel().socket());
/*     */   }
/*     */ 
/*     */   
/*     */   @SuppressJava6Requirement(reason = "Usage guarded by java version check")
/*     */   protected void doBind(SocketAddress localAddress) throws Exception {
/* 140 */     if (PlatformDependent.javaVersion() >= 7) {
/* 141 */       javaChannel().bind(localAddress, this.config.getBacklog());
/*     */     } else {
/* 143 */       javaChannel().socket().bind(localAddress, this.config.getBacklog());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void doClose() throws Exception {
/* 149 */     javaChannel().close();
/*     */   }
/*     */ 
/*     */   
/*     */   protected int doReadMessages(List<Object> buf) throws Exception {
/* 154 */     SocketChannel ch = SocketUtils.accept(javaChannel());
/*     */     
/*     */     try {
/* 157 */       if (ch != null) {
/* 158 */         buf.add(new NioSocketChannel((Channel)this, ch));
/* 159 */         return 1;
/*     */       } 
/* 161 */     } catch (Throwable t) {
/* 162 */       logger.warn("Failed to create a new channel from an accepted socket.", t);
/*     */       
/*     */       try {
/* 165 */         ch.close();
/* 166 */       } catch (Throwable t2) {
/* 167 */         logger.warn("Failed to close a socket.", t2);
/*     */       } 
/*     */     } 
/*     */     
/* 171 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean doConnect(SocketAddress remoteAddress, SocketAddress localAddress) throws Exception {
/* 178 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void doFinishConnect() throws Exception {
/* 183 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   protected SocketAddress remoteAddress0() {
/* 188 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void doDisconnect() throws Exception {
/* 193 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean doWriteMessage(Object msg, ChannelOutboundBuffer in) throws Exception {
/* 198 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   protected final Object filterOutboundMessage(Object msg) throws Exception {
/* 203 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   private final class NioServerSocketChannelConfig extends DefaultServerSocketChannelConfig {
/*     */     private NioServerSocketChannelConfig(NioServerSocketChannel channel, ServerSocket javaSocket) {
/* 208 */       super(channel, javaSocket);
/*     */     }
/*     */ 
/*     */     
/*     */     protected void autoReadCleared() {
/* 213 */       NioServerSocketChannel.this.clearReadPending();
/*     */     }
/*     */ 
/*     */     
/*     */     public <T> boolean setOption(ChannelOption<T> option, T value) {
/* 218 */       if (PlatformDependent.javaVersion() >= 7 && option instanceof NioChannelOption) {
/* 219 */         return NioChannelOption.setOption(jdkChannel(), (NioChannelOption<T>)option, value);
/*     */       }
/* 221 */       return super.setOption(option, value);
/*     */     }
/*     */ 
/*     */     
/*     */     public <T> T getOption(ChannelOption<T> option) {
/* 226 */       if (PlatformDependent.javaVersion() >= 7 && option instanceof NioChannelOption) {
/* 227 */         return NioChannelOption.getOption(jdkChannel(), (NioChannelOption<T>)option);
/*     */       }
/* 229 */       return (T)super.getOption(option);
/*     */     }
/*     */ 
/*     */     
/*     */     public Map<ChannelOption<?>, Object> getOptions() {
/* 234 */       if (PlatformDependent.javaVersion() >= 7) {
/* 235 */         return getOptions(super.getOptions(), NioChannelOption.getOptions(jdkChannel()));
/*     */       }
/* 237 */       return super.getOptions();
/*     */     }
/*     */     
/*     */     private ServerSocketChannel jdkChannel() {
/* 241 */       return ((NioServerSocketChannel)this.channel).javaChannel();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean closeOnReadError(Throwable cause) {
/* 248 */     return super.closeOnReadError(cause);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-transport-4.1.93.Final.jar!\io\netty\channel\socket\nio\NioServerSocketChannel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */