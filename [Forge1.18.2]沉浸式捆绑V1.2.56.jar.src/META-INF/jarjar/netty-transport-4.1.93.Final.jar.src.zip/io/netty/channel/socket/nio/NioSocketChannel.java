/*     */ package io.netty.channel.socket.nio;
/*     */ 
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import io.netty.channel.AbstractChannel;
/*     */ import io.netty.channel.Channel;
/*     */ import io.netty.channel.ChannelConfig;
/*     */ import io.netty.channel.ChannelException;
/*     */ import io.netty.channel.ChannelFuture;
/*     */ import io.netty.channel.ChannelFutureListener;
/*     */ import io.netty.channel.ChannelOption;
/*     */ import io.netty.channel.ChannelOutboundBuffer;
/*     */ import io.netty.channel.ChannelPromise;
/*     */ import io.netty.channel.FileRegion;
/*     */ import io.netty.channel.RecvByteBufAllocator;
/*     */ import io.netty.channel.nio.AbstractNioByteChannel;
/*     */ import io.netty.channel.nio.AbstractNioChannel;
/*     */ import io.netty.channel.nio.NioEventLoop;
/*     */ import io.netty.channel.socket.DefaultSocketChannelConfig;
/*     */ import io.netty.channel.socket.InternetProtocolFamily;
/*     */ import io.netty.channel.socket.ServerSocketChannel;
/*     */ import io.netty.channel.socket.SocketChannel;
/*     */ import io.netty.channel.socket.SocketChannelConfig;
/*     */ import io.netty.util.concurrent.Future;
/*     */ import io.netty.util.concurrent.GenericFutureListener;
/*     */ import io.netty.util.concurrent.GlobalEventExecutor;
/*     */ import io.netty.util.internal.PlatformDependent;
/*     */ import io.netty.util.internal.SocketUtils;
/*     */ import io.netty.util.internal.SuppressJava6Requirement;
/*     */ import io.netty.util.internal.logging.InternalLogger;
/*     */ import io.netty.util.internal.logging.InternalLoggerFactory;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.Socket;
/*     */ import java.net.SocketAddress;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.channels.SelectableChannel;
/*     */ import java.nio.channels.SocketChannel;
/*     */ import java.nio.channels.spi.SelectorProvider;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.Executor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NioSocketChannel
/*     */   extends AbstractNioByteChannel
/*     */   implements SocketChannel
/*     */ {
/*  60 */   private static final InternalLogger logger = InternalLoggerFactory.getInstance(NioSocketChannel.class);
/*  61 */   private static final SelectorProvider DEFAULT_SELECTOR_PROVIDER = SelectorProvider.provider();
/*     */ 
/*     */   
/*  64 */   private static final Method OPEN_SOCKET_CHANNEL_WITH_FAMILY = SelectorProviderUtil.findOpenMethod("openSocketChannel");
/*     */   
/*     */   private final SocketChannelConfig config;
/*     */   
/*     */   private static SocketChannel newChannel(SelectorProvider provider, InternetProtocolFamily family) {
/*     */     try {
/*  70 */       SocketChannel channel = SelectorProviderUtil.<SocketChannel>newChannel(OPEN_SOCKET_CHANNEL_WITH_FAMILY, provider, family);
/*  71 */       return (channel == null) ? provider.openSocketChannel() : channel;
/*  72 */     } catch (IOException e) {
/*  73 */       throw new ChannelException("Failed to open a socket.", e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NioSocketChannel() {
/*  81 */     this(DEFAULT_SELECTOR_PROVIDER);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NioSocketChannel(SelectorProvider provider) {
/*  88 */     this(provider, (InternetProtocolFamily)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NioSocketChannel(SelectorProvider provider, InternetProtocolFamily family) {
/*  95 */     this(newChannel(provider, family));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NioSocketChannel(SocketChannel socket) {
/* 102 */     this((Channel)null, socket);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NioSocketChannel(Channel parent, SocketChannel socket) {
/* 112 */     super(parent, socket);
/* 113 */     this.config = (SocketChannelConfig)new NioSocketChannelConfig(this, socket.socket());
/*     */   }
/*     */ 
/*     */   
/*     */   public ServerSocketChannel parent() {
/* 118 */     return (ServerSocketChannel)super.parent();
/*     */   }
/*     */ 
/*     */   
/*     */   public SocketChannelConfig config() {
/* 123 */     return this.config;
/*     */   }
/*     */ 
/*     */   
/*     */   protected SocketChannel javaChannel() {
/* 128 */     return (SocketChannel)super.javaChannel();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isActive() {
/* 133 */     SocketChannel ch = javaChannel();
/* 134 */     return (ch.isOpen() && ch.isConnected());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isOutputShutdown() {
/* 139 */     return (javaChannel().socket().isOutputShutdown() || !isActive());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isInputShutdown() {
/* 144 */     return (javaChannel().socket().isInputShutdown() || !isActive());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isShutdown() {
/* 149 */     Socket socket = javaChannel().socket();
/* 150 */     return ((socket.isInputShutdown() && socket.isOutputShutdown()) || !isActive());
/*     */   }
/*     */ 
/*     */   
/*     */   public InetSocketAddress localAddress() {
/* 155 */     return (InetSocketAddress)super.localAddress();
/*     */   }
/*     */ 
/*     */   
/*     */   public InetSocketAddress remoteAddress() {
/* 160 */     return (InetSocketAddress)super.remoteAddress();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SuppressJava6Requirement(reason = "Usage guarded by java version check")
/*     */   protected final void doShutdownOutput() throws Exception {
/* 167 */     if (PlatformDependent.javaVersion() >= 7) {
/* 168 */       javaChannel().shutdownOutput();
/*     */     } else {
/* 170 */       javaChannel().socket().shutdownOutput();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public ChannelFuture shutdownOutput() {
/* 176 */     return shutdownOutput(newPromise());
/*     */   }
/*     */ 
/*     */   
/*     */   public ChannelFuture shutdownOutput(final ChannelPromise promise) {
/* 181 */     NioEventLoop nioEventLoop = eventLoop();
/* 182 */     if (nioEventLoop.inEventLoop()) {
/* 183 */       ((AbstractChannel.AbstractUnsafe)unsafe()).shutdownOutput(promise);
/*     */     } else {
/* 185 */       nioEventLoop.execute(new Runnable()
/*     */           {
/*     */             public void run() {
/* 188 */               ((AbstractChannel.AbstractUnsafe)NioSocketChannel.this.unsafe()).shutdownOutput(promise);
/*     */             }
/*     */           });
/*     */     } 
/* 192 */     return (ChannelFuture)promise;
/*     */   }
/*     */ 
/*     */   
/*     */   public ChannelFuture shutdownInput() {
/* 197 */     return shutdownInput(newPromise());
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isInputShutdown0() {
/* 202 */     return isInputShutdown();
/*     */   }
/*     */ 
/*     */   
/*     */   public ChannelFuture shutdownInput(final ChannelPromise promise) {
/* 207 */     NioEventLoop nioEventLoop = eventLoop();
/* 208 */     if (nioEventLoop.inEventLoop()) {
/* 209 */       shutdownInput0(promise);
/*     */     } else {
/* 211 */       nioEventLoop.execute(new Runnable()
/*     */           {
/*     */             public void run() {
/* 214 */               NioSocketChannel.this.shutdownInput0(promise);
/*     */             }
/*     */           });
/*     */     } 
/* 218 */     return (ChannelFuture)promise;
/*     */   }
/*     */ 
/*     */   
/*     */   public ChannelFuture shutdown() {
/* 223 */     return shutdown(newPromise());
/*     */   }
/*     */ 
/*     */   
/*     */   public ChannelFuture shutdown(final ChannelPromise promise) {
/* 228 */     ChannelFuture shutdownOutputFuture = shutdownOutput();
/* 229 */     if (shutdownOutputFuture.isDone()) {
/* 230 */       shutdownOutputDone(shutdownOutputFuture, promise);
/*     */     } else {
/* 232 */       shutdownOutputFuture.addListener((GenericFutureListener)new ChannelFutureListener()
/*     */           {
/*     */             public void operationComplete(ChannelFuture shutdownOutputFuture) throws Exception {
/* 235 */               NioSocketChannel.this.shutdownOutputDone(shutdownOutputFuture, promise);
/*     */             }
/*     */           });
/*     */     } 
/* 239 */     return (ChannelFuture)promise;
/*     */   }
/*     */   
/*     */   private void shutdownOutputDone(final ChannelFuture shutdownOutputFuture, final ChannelPromise promise) {
/* 243 */     ChannelFuture shutdownInputFuture = shutdownInput();
/* 244 */     if (shutdownInputFuture.isDone()) {
/* 245 */       shutdownDone(shutdownOutputFuture, shutdownInputFuture, promise);
/*     */     } else {
/* 247 */       shutdownInputFuture.addListener((GenericFutureListener)new ChannelFutureListener()
/*     */           {
/*     */             public void operationComplete(ChannelFuture shutdownInputFuture) throws Exception {
/* 250 */               NioSocketChannel.shutdownDone(shutdownOutputFuture, shutdownInputFuture, promise);
/*     */             }
/*     */           });
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static void shutdownDone(ChannelFuture shutdownOutputFuture, ChannelFuture shutdownInputFuture, ChannelPromise promise) {
/* 259 */     Throwable shutdownOutputCause = shutdownOutputFuture.cause();
/* 260 */     Throwable shutdownInputCause = shutdownInputFuture.cause();
/* 261 */     if (shutdownOutputCause != null) {
/* 262 */       if (shutdownInputCause != null) {
/* 263 */         logger.debug("Exception suppressed because a previous exception occurred.", shutdownInputCause);
/*     */       }
/*     */       
/* 266 */       promise.setFailure(shutdownOutputCause);
/* 267 */     } else if (shutdownInputCause != null) {
/* 268 */       promise.setFailure(shutdownInputCause);
/*     */     } else {
/* 270 */       promise.setSuccess();
/*     */     } 
/*     */   }
/*     */   private void shutdownInput0(ChannelPromise promise) {
/*     */     try {
/* 275 */       shutdownInput0();
/* 276 */       promise.setSuccess();
/* 277 */     } catch (Throwable t) {
/* 278 */       promise.setFailure(t);
/*     */     } 
/*     */   }
/*     */   
/*     */   @SuppressJava6Requirement(reason = "Usage guarded by java version check")
/*     */   private void shutdownInput0() throws Exception {
/* 284 */     if (PlatformDependent.javaVersion() >= 7) {
/* 285 */       javaChannel().shutdownInput();
/*     */     } else {
/* 287 */       javaChannel().socket().shutdownInput();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected SocketAddress localAddress0() {
/* 293 */     return javaChannel().socket().getLocalSocketAddress();
/*     */   }
/*     */ 
/*     */   
/*     */   protected SocketAddress remoteAddress0() {
/* 298 */     return javaChannel().socket().getRemoteSocketAddress();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void doBind(SocketAddress localAddress) throws Exception {
/* 303 */     doBind0(localAddress);
/*     */   }
/*     */   
/*     */   private void doBind0(SocketAddress localAddress) throws Exception {
/* 307 */     if (PlatformDependent.javaVersion() >= 7) {
/* 308 */       SocketUtils.bind(javaChannel(), localAddress);
/*     */     } else {
/* 310 */       SocketUtils.bind(javaChannel().socket(), localAddress);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean doConnect(SocketAddress remoteAddress, SocketAddress localAddress) throws Exception {
/* 316 */     if (localAddress != null) {
/* 317 */       doBind0(localAddress);
/*     */     }
/*     */     
/* 320 */     boolean success = false;
/*     */     try {
/* 322 */       boolean connected = SocketUtils.connect(javaChannel(), remoteAddress);
/* 323 */       if (!connected) {
/* 324 */         selectionKey().interestOps(8);
/*     */       }
/* 326 */       success = true;
/* 327 */       return connected;
/*     */     } finally {
/* 329 */       if (!success) {
/* 330 */         doClose();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void doFinishConnect() throws Exception {
/* 337 */     if (!javaChannel().finishConnect()) {
/* 338 */       throw new Error();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected void doDisconnect() throws Exception {
/* 344 */     doClose();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void doClose() throws Exception {
/* 349 */     super.doClose();
/* 350 */     javaChannel().close();
/*     */   }
/*     */ 
/*     */   
/*     */   protected int doReadBytes(ByteBuf byteBuf) throws Exception {
/* 355 */     RecvByteBufAllocator.Handle allocHandle = unsafe().recvBufAllocHandle();
/* 356 */     allocHandle.attemptedBytesRead(byteBuf.writableBytes());
/* 357 */     return byteBuf.writeBytes(javaChannel(), allocHandle.attemptedBytesRead());
/*     */   }
/*     */ 
/*     */   
/*     */   protected int doWriteBytes(ByteBuf buf) throws Exception {
/* 362 */     int expectedWrittenBytes = buf.readableBytes();
/* 363 */     return buf.readBytes(javaChannel(), expectedWrittenBytes);
/*     */   }
/*     */ 
/*     */   
/*     */   protected long doWriteFileRegion(FileRegion region) throws Exception {
/* 368 */     long position = region.transferred();
/* 369 */     return region.transferTo(javaChannel(), position);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void adjustMaxBytesPerGatheringWrite(int attempted, int written, int oldMaxBytesPerGatheringWrite) {
/* 376 */     if (attempted == written) {
/* 377 */       if (attempted << 1 > oldMaxBytesPerGatheringWrite) {
/* 378 */         ((NioSocketChannelConfig)this.config).setMaxBytesPerGatheringWrite(attempted << 1);
/*     */       }
/* 380 */     } else if (attempted > 4096 && written < attempted >>> 1) {
/* 381 */       ((NioSocketChannelConfig)this.config).setMaxBytesPerGatheringWrite(attempted >>> 1);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void doWrite(ChannelOutboundBuffer in) throws Exception {
/* 387 */     SocketChannel ch = javaChannel();
/* 388 */     int writeSpinCount = config().getWriteSpinCount(); do {
/*     */       ByteBuffer buffer; long attemptedBytes; int i, j; long localWrittenBytes;
/* 390 */       if (in.isEmpty()) {
/*     */         
/* 392 */         clearOpWrite();
/*     */ 
/*     */         
/*     */         return;
/*     */       } 
/*     */       
/* 398 */       int maxBytesPerGatheringWrite = ((NioSocketChannelConfig)this.config).getMaxBytesPerGatheringWrite();
/* 399 */       ByteBuffer[] nioBuffers = in.nioBuffers(1024, maxBytesPerGatheringWrite);
/* 400 */       int nioBufferCnt = in.nioBufferCount();
/*     */ 
/*     */ 
/*     */       
/* 404 */       switch (nioBufferCnt) {
/*     */         
/*     */         case 0:
/* 407 */           writeSpinCount -= doWrite0(in);
/*     */           break;
/*     */ 
/*     */ 
/*     */         
/*     */         case 1:
/* 413 */           buffer = nioBuffers[0];
/* 414 */           i = buffer.remaining();
/* 415 */           j = ch.write(buffer);
/* 416 */           if (j <= 0) {
/* 417 */             incompleteWrite(true);
/*     */             return;
/*     */           } 
/* 420 */           adjustMaxBytesPerGatheringWrite(i, j, maxBytesPerGatheringWrite);
/* 421 */           in.removeBytes(j);
/* 422 */           writeSpinCount--;
/*     */           break;
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         default:
/* 429 */           attemptedBytes = in.nioBufferSize();
/* 430 */           localWrittenBytes = ch.write(nioBuffers, 0, nioBufferCnt);
/* 431 */           if (localWrittenBytes <= 0L) {
/* 432 */             incompleteWrite(true);
/*     */             
/*     */             return;
/*     */           } 
/* 436 */           adjustMaxBytesPerGatheringWrite((int)attemptedBytes, (int)localWrittenBytes, maxBytesPerGatheringWrite);
/*     */           
/* 438 */           in.removeBytes(localWrittenBytes);
/* 439 */           writeSpinCount--;
/*     */           break;
/*     */       } 
/*     */     
/* 443 */     } while (writeSpinCount > 0);
/*     */     
/* 445 */     incompleteWrite((writeSpinCount < 0));
/*     */   }
/*     */ 
/*     */   
/*     */   protected AbstractNioChannel.AbstractNioUnsafe newUnsafe() {
/* 450 */     return (AbstractNioChannel.AbstractNioUnsafe)new NioSocketChannelUnsafe();
/*     */   }
/*     */   private final class NioSocketChannelUnsafe extends AbstractNioByteChannel.NioByteUnsafe { private NioSocketChannelUnsafe() {
/* 453 */       super(NioSocketChannel.this);
/*     */     }
/*     */     protected Executor prepareToClose() {
/*     */       try {
/* 457 */         if (NioSocketChannel.this.javaChannel().isOpen() && NioSocketChannel.this.config().getSoLinger() > 0) {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 462 */           NioSocketChannel.this.doDeregister();
/* 463 */           return (Executor)GlobalEventExecutor.INSTANCE;
/*     */         } 
/* 465 */       } catch (Throwable throwable) {}
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 470 */       return null;
/*     */     } }
/*     */ 
/*     */   
/*     */   private final class NioSocketChannelConfig extends DefaultSocketChannelConfig {
/* 475 */     private volatile int maxBytesPerGatheringWrite = Integer.MAX_VALUE;
/*     */     private NioSocketChannelConfig(NioSocketChannel channel, Socket javaSocket) {
/* 477 */       super(channel, javaSocket);
/* 478 */       calculateMaxBytesPerGatheringWrite();
/*     */     }
/*     */ 
/*     */     
/*     */     protected void autoReadCleared() {
/* 483 */       NioSocketChannel.this.clearReadPending();
/*     */     }
/*     */ 
/*     */     
/*     */     public NioSocketChannelConfig setSendBufferSize(int sendBufferSize) {
/* 488 */       super.setSendBufferSize(sendBufferSize);
/* 489 */       calculateMaxBytesPerGatheringWrite();
/* 490 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public <T> boolean setOption(ChannelOption<T> option, T value) {
/* 495 */       if (PlatformDependent.javaVersion() >= 7 && option instanceof NioChannelOption) {
/* 496 */         return NioChannelOption.setOption(jdkChannel(), (NioChannelOption<T>)option, value);
/*     */       }
/* 498 */       return super.setOption(option, value);
/*     */     }
/*     */ 
/*     */     
/*     */     public <T> T getOption(ChannelOption<T> option) {
/* 503 */       if (PlatformDependent.javaVersion() >= 7 && option instanceof NioChannelOption) {
/* 504 */         return NioChannelOption.getOption(jdkChannel(), (NioChannelOption<T>)option);
/*     */       }
/* 506 */       return (T)super.getOption(option);
/*     */     }
/*     */ 
/*     */     
/*     */     public Map<ChannelOption<?>, Object> getOptions() {
/* 511 */       if (PlatformDependent.javaVersion() >= 7) {
/* 512 */         return getOptions(super.getOptions(), NioChannelOption.getOptions(jdkChannel()));
/*     */       }
/* 514 */       return super.getOptions();
/*     */     }
/*     */     
/*     */     void setMaxBytesPerGatheringWrite(int maxBytesPerGatheringWrite) {
/* 518 */       this.maxBytesPerGatheringWrite = maxBytesPerGatheringWrite;
/*     */     }
/*     */     
/*     */     int getMaxBytesPerGatheringWrite() {
/* 522 */       return this.maxBytesPerGatheringWrite;
/*     */     }
/*     */ 
/*     */     
/*     */     private void calculateMaxBytesPerGatheringWrite() {
/* 527 */       int newSendBufferSize = getSendBufferSize() << 1;
/* 528 */       if (newSendBufferSize > 0) {
/* 529 */         setMaxBytesPerGatheringWrite(newSendBufferSize);
/*     */       }
/*     */     }
/*     */     
/*     */     private SocketChannel jdkChannel() {
/* 534 */       return ((NioSocketChannel)this.channel).javaChannel();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-transport-4.1.93.Final.jar!\io\netty\channel\socket\nio\NioSocketChannel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */