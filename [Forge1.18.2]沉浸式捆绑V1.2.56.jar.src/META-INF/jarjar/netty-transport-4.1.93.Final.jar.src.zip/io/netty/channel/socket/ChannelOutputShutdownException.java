/*    */ package io.netty.channel.socket;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ChannelOutputShutdownException
/*    */   extends IOException
/*    */ {
/*    */   private static final long serialVersionUID = 6712549938359321378L;
/*    */   
/*    */   public ChannelOutputShutdownException(String msg) {
/* 32 */     super(msg);
/*    */   }
/*    */   
/*    */   public ChannelOutputShutdownException(String msg, Throwable cause) {
/* 36 */     super(msg, cause);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-transport-4.1.93.Final.jar!\io\netty\channel\socket\ChannelOutputShutdownException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */