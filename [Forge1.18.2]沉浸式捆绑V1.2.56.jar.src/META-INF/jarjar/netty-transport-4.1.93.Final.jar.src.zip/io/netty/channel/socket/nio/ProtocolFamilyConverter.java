/*    */ package io.netty.channel.socket.nio;
/*    */ 
/*    */ import io.netty.channel.socket.InternetProtocolFamily;
/*    */ import io.netty.util.internal.SuppressJava6Requirement;
/*    */ import java.net.ProtocolFamily;
/*    */ import java.net.StandardProtocolFamily;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class ProtocolFamilyConverter
/*    */ {
/*    */   @SuppressJava6Requirement(reason = "Usage guarded by java version check")
/*    */   public static ProtocolFamily convert(InternetProtocolFamily family) {
/* 38 */     switch (family) {
/*    */       case IPv4:
/* 40 */         return StandardProtocolFamily.INET;
/*    */       case IPv6:
/* 42 */         return StandardProtocolFamily.INET6;
/*    */     } 
/* 44 */     throw new IllegalArgumentException();
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-transport-4.1.93.Final.jar!\io\netty\channel\socket\nio\ProtocolFamilyConverter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */