/*     */ package io.netty.channel.oio;
/*     */ 
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import io.netty.buffer.ByteBufAllocator;
/*     */ import io.netty.channel.Channel;
/*     */ import io.netty.channel.ChannelConfig;
/*     */ import io.netty.channel.ChannelFuture;
/*     */ import io.netty.channel.ChannelMetadata;
/*     */ import io.netty.channel.ChannelOption;
/*     */ import io.netty.channel.ChannelOutboundBuffer;
/*     */ import io.netty.channel.ChannelPipeline;
/*     */ import io.netty.channel.FileRegion;
/*     */ import io.netty.channel.RecvByteBufAllocator;
/*     */ import io.netty.channel.socket.ChannelInputShutdownEvent;
/*     */ import io.netty.channel.socket.ChannelInputShutdownReadComplete;
/*     */ import io.netty.util.internal.StringUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractOioByteChannel
/*     */   extends AbstractOioChannel
/*     */ {
/*  42 */   private static final ChannelMetadata METADATA = new ChannelMetadata(false);
/*  43 */   private static final String EXPECTED_TYPES = " (expected: " + 
/*  44 */     StringUtil.simpleClassName(ByteBuf.class) + ", " + 
/*  45 */     StringUtil.simpleClassName(FileRegion.class) + ')';
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected AbstractOioByteChannel(Channel parent) {
/*  51 */     super(parent);
/*     */   }
/*     */ 
/*     */   
/*     */   public ChannelMetadata metadata() {
/*  56 */     return METADATA;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract boolean isInputShutdown();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract ChannelFuture shutdownInput();
/*     */ 
/*     */ 
/*     */   
/*     */   private void closeOnRead(ChannelPipeline pipeline) {
/*  72 */     if (isOpen()) {
/*  73 */       if (Boolean.TRUE.equals(config().getOption(ChannelOption.ALLOW_HALF_CLOSURE))) {
/*  74 */         shutdownInput();
/*  75 */         pipeline.fireUserEventTriggered(ChannelInputShutdownEvent.INSTANCE);
/*     */       } else {
/*  77 */         unsafe().close(unsafe().voidPromise());
/*     */       } 
/*  79 */       pipeline.fireUserEventTriggered(ChannelInputShutdownReadComplete.INSTANCE);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void handleReadException(ChannelPipeline pipeline, ByteBuf byteBuf, Throwable cause, boolean close, RecvByteBufAllocator.Handle allocHandle) {
/*  85 */     if (byteBuf != null) {
/*  86 */       if (byteBuf.isReadable()) {
/*  87 */         this.readPending = false;
/*  88 */         pipeline.fireChannelRead(byteBuf);
/*     */       } else {
/*  90 */         byteBuf.release();
/*     */       } 
/*     */     }
/*  93 */     allocHandle.readComplete();
/*  94 */     pipeline.fireChannelReadComplete();
/*  95 */     pipeline.fireExceptionCaught(cause);
/*     */ 
/*     */ 
/*     */     
/*  99 */     if (close || cause instanceof OutOfMemoryError || cause instanceof java.io.IOException) {
/* 100 */       closeOnRead(pipeline);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected void doRead() {
/* 106 */     ChannelConfig config = config();
/* 107 */     if (isInputShutdown() || !this.readPending) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 114 */     this.readPending = false;
/*     */     
/* 116 */     ChannelPipeline pipeline = pipeline();
/* 117 */     ByteBufAllocator allocator = config.getAllocator();
/* 118 */     RecvByteBufAllocator.Handle allocHandle = unsafe().recvBufAllocHandle();
/* 119 */     allocHandle.reset(config);
/*     */     
/* 121 */     ByteBuf byteBuf = null;
/* 122 */     boolean close = false;
/* 123 */     boolean readData = false;
/*     */     try {
/* 125 */       byteBuf = allocHandle.allocate(allocator);
/*     */       do {
/* 127 */         allocHandle.lastBytesRead(doReadBytes(byteBuf));
/* 128 */         if (allocHandle.lastBytesRead() <= 0) {
/* 129 */           if (!byteBuf.isReadable()) {
/* 130 */             byteBuf.release();
/* 131 */             byteBuf = null;
/* 132 */             close = (allocHandle.lastBytesRead() < 0);
/* 133 */             if (close)
/*     */             {
/* 135 */               this.readPending = false;
/*     */             }
/*     */           } 
/*     */           break;
/*     */         } 
/* 140 */         readData = true;
/*     */ 
/*     */         
/* 143 */         int available = available();
/* 144 */         if (available <= 0) {
/*     */           break;
/*     */         }
/*     */ 
/*     */         
/* 149 */         if (byteBuf.isWritable())
/* 150 */           continue;  int capacity = byteBuf.capacity();
/* 151 */         int maxCapacity = byteBuf.maxCapacity();
/* 152 */         if (capacity == maxCapacity) {
/* 153 */           allocHandle.incMessagesRead(1);
/* 154 */           this.readPending = false;
/* 155 */           pipeline.fireChannelRead(byteBuf);
/* 156 */           byteBuf = allocHandle.allocate(allocator);
/*     */         } else {
/* 158 */           int writerIndex = byteBuf.writerIndex();
/* 159 */           if (writerIndex + available > maxCapacity) {
/* 160 */             byteBuf.capacity(maxCapacity);
/*     */           } else {
/* 162 */             byteBuf.ensureWritable(available);
/*     */           }
/*     */         
/*     */         } 
/* 166 */       } while (allocHandle.continueReading());
/*     */       
/* 168 */       if (byteBuf != null) {
/*     */ 
/*     */         
/* 171 */         if (byteBuf.isReadable()) {
/* 172 */           this.readPending = false;
/* 173 */           pipeline.fireChannelRead(byteBuf);
/*     */         } else {
/* 175 */           byteBuf.release();
/*     */         } 
/* 177 */         byteBuf = null;
/*     */       } 
/*     */       
/* 180 */       if (readData) {
/* 181 */         allocHandle.readComplete();
/* 182 */         pipeline.fireChannelReadComplete();
/*     */       } 
/*     */       
/* 185 */       if (close) {
/* 186 */         closeOnRead(pipeline);
/*     */       }
/* 188 */     } catch (Throwable t) {
/* 189 */       handleReadException(pipeline, byteBuf, t, close, allocHandle);
/*     */     } finally {
/* 191 */       if (this.readPending || config.isAutoRead() || (!readData && isActive()))
/*     */       {
/*     */         
/* 194 */         read();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void doWrite(ChannelOutboundBuffer in) throws Exception {
/*     */     while (true) {
/* 202 */       Object msg = in.current();
/* 203 */       if (msg == null) {
/*     */         break;
/*     */       }
/*     */       
/* 207 */       if (msg instanceof ByteBuf) {
/* 208 */         ByteBuf buf = (ByteBuf)msg;
/* 209 */         int readableBytes = buf.readableBytes();
/* 210 */         while (readableBytes > 0) {
/* 211 */           doWriteBytes(buf);
/* 212 */           int newReadableBytes = buf.readableBytes();
/* 213 */           in.progress((readableBytes - newReadableBytes));
/* 214 */           readableBytes = newReadableBytes;
/*     */         } 
/* 216 */         in.remove(); continue;
/* 217 */       }  if (msg instanceof FileRegion) {
/* 218 */         FileRegion region = (FileRegion)msg;
/* 219 */         long transferred = region.transferred();
/* 220 */         doWriteFileRegion(region);
/* 221 */         in.progress(region.transferred() - transferred);
/* 222 */         in.remove(); continue;
/*     */       } 
/* 224 */       in.remove(new UnsupportedOperationException("unsupported message type: " + 
/* 225 */             StringUtil.simpleClassName(msg)));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected final Object filterOutboundMessage(Object msg) throws Exception {
/* 232 */     if (msg instanceof ByteBuf || msg instanceof FileRegion) {
/* 233 */       return msg;
/*     */     }
/*     */     
/* 236 */     throw new UnsupportedOperationException("unsupported message type: " + 
/* 237 */         StringUtil.simpleClassName(msg) + EXPECTED_TYPES);
/*     */   }
/*     */   
/*     */   protected abstract int available();
/*     */   
/*     */   protected abstract int doReadBytes(ByteBuf paramByteBuf) throws Exception;
/*     */   
/*     */   protected abstract void doWriteBytes(ByteBuf paramByteBuf) throws Exception;
/*     */   
/*     */   protected abstract void doWriteFileRegion(FileRegion paramFileRegion) throws Exception;
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-transport-4.1.93.Final.jar!\io\netty\channel\oio\AbstractOioByteChannel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */