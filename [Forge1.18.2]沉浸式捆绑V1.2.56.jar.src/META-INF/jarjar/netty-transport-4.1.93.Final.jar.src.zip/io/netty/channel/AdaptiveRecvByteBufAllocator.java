/*     */ package io.netty.channel;
/*     */ 
/*     */ import io.netty.util.internal.ObjectUtil;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AdaptiveRecvByteBufAllocator
/*     */   extends DefaultMaxMessagesRecvByteBufAllocator
/*     */ {
/*     */   static final int DEFAULT_MINIMUM = 64;
/*     */   static final int DEFAULT_INITIAL = 2048;
/*     */   static final int DEFAULT_MAXIMUM = 65536;
/*     */   private static final int INDEX_INCREMENT = 4;
/*     */   private static final int INDEX_DECREMENT = 1;
/*     */   private static final int[] SIZE_TABLE;
/*     */   
/*     */   static {
/*  48 */     List<Integer> sizeTable = new ArrayList<Integer>(); int i;
/*  49 */     for (i = 16; i < 512; i += 16) {
/*  50 */       sizeTable.add(Integer.valueOf(i));
/*     */     }
/*     */ 
/*     */     
/*  54 */     for (i = 512; i > 0; i <<= 1) {
/*  55 */       sizeTable.add(Integer.valueOf(i));
/*     */     }
/*     */     
/*  58 */     SIZE_TABLE = new int[sizeTable.size()];
/*  59 */     for (i = 0; i < SIZE_TABLE.length; i++) {
/*  60 */       SIZE_TABLE[i] = ((Integer)sizeTable.get(i)).intValue();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*  68 */   public static final AdaptiveRecvByteBufAllocator DEFAULT = new AdaptiveRecvByteBufAllocator(); private final int minIndex; private final int maxIndex; private final int initial;
/*     */   
/*     */   private static int getSizeTableIndex(int size) {
/*  71 */     int mid, a, low = 0, high = SIZE_TABLE.length - 1; while (true) {
/*  72 */       if (high < low) {
/*  73 */         return low;
/*     */       }
/*  75 */       if (high == low) {
/*  76 */         return high;
/*     */       }
/*     */       
/*  79 */       mid = low + high >>> 1;
/*  80 */       a = SIZE_TABLE[mid];
/*  81 */       int b = SIZE_TABLE[mid + 1];
/*  82 */       if (size > b) {
/*  83 */         low = mid + 1; continue;
/*  84 */       }  if (size < a)
/*  85 */       { high = mid - 1; continue; }  break;
/*  86 */     }  if (size == a) {
/*  87 */       return mid;
/*     */     }
/*  89 */     return mid + 1;
/*     */   }
/*     */   
/*     */   private final class HandleImpl
/*     */     extends DefaultMaxMessagesRecvByteBufAllocator.MaxMessageHandle
/*     */   {
/*     */     private final int minIndex;
/*     */     private final int maxIndex;
/*     */     private int index;
/*     */     private int nextReceiveBufferSize;
/*     */     private boolean decreaseNow;
/*     */     
/*     */     HandleImpl(int minIndex, int maxIndex, int initial) {
/* 102 */       this.minIndex = minIndex;
/* 103 */       this.maxIndex = maxIndex;
/*     */       
/* 105 */       this.index = AdaptiveRecvByteBufAllocator.getSizeTableIndex(initial);
/* 106 */       this.nextReceiveBufferSize = AdaptiveRecvByteBufAllocator.SIZE_TABLE[this.index];
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void lastBytesRead(int bytes) {
/* 115 */       if (bytes == attemptedBytesRead()) {
/* 116 */         record(bytes);
/*     */       }
/* 118 */       super.lastBytesRead(bytes);
/*     */     }
/*     */ 
/*     */     
/*     */     public int guess() {
/* 123 */       return this.nextReceiveBufferSize;
/*     */     }
/*     */     
/*     */     private void record(int actualReadBytes) {
/* 127 */       if (actualReadBytes <= AdaptiveRecvByteBufAllocator.SIZE_TABLE[Math.max(0, this.index - 1)]) {
/* 128 */         if (this.decreaseNow) {
/* 129 */           this.index = Math.max(this.index - 1, this.minIndex);
/* 130 */           this.nextReceiveBufferSize = AdaptiveRecvByteBufAllocator.SIZE_TABLE[this.index];
/* 131 */           this.decreaseNow = false;
/*     */         } else {
/* 133 */           this.decreaseNow = true;
/*     */         } 
/* 135 */       } else if (actualReadBytes >= this.nextReceiveBufferSize) {
/* 136 */         this.index = Math.min(this.index + 4, this.maxIndex);
/* 137 */         this.nextReceiveBufferSize = AdaptiveRecvByteBufAllocator.SIZE_TABLE[this.index];
/* 138 */         this.decreaseNow = false;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void readComplete() {
/* 144 */       record(totalBytesRead());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AdaptiveRecvByteBufAllocator() {
/* 158 */     this(64, 2048, 65536);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AdaptiveRecvByteBufAllocator(int minimum, int initial, int maximum) {
/* 169 */     ObjectUtil.checkPositive(minimum, "minimum");
/* 170 */     if (initial < minimum) {
/* 171 */       throw new IllegalArgumentException("initial: " + initial);
/*     */     }
/* 173 */     if (maximum < initial) {
/* 174 */       throw new IllegalArgumentException("maximum: " + maximum);
/*     */     }
/*     */     
/* 177 */     int minIndex = getSizeTableIndex(minimum);
/* 178 */     if (SIZE_TABLE[minIndex] < minimum) {
/* 179 */       this.minIndex = minIndex + 1;
/*     */     } else {
/* 181 */       this.minIndex = minIndex;
/*     */     } 
/*     */     
/* 184 */     int maxIndex = getSizeTableIndex(maximum);
/* 185 */     if (SIZE_TABLE[maxIndex] > maximum) {
/* 186 */       this.maxIndex = maxIndex - 1;
/*     */     } else {
/* 188 */       this.maxIndex = maxIndex;
/*     */     } 
/*     */     
/* 191 */     this.initial = initial;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public RecvByteBufAllocator.Handle newHandle() {
/* 197 */     return new HandleImpl(this.minIndex, this.maxIndex, this.initial);
/*     */   }
/*     */ 
/*     */   
/*     */   public AdaptiveRecvByteBufAllocator respectMaybeMoreData(boolean respectMaybeMoreData) {
/* 202 */     super.respectMaybeMoreData(respectMaybeMoreData);
/* 203 */     return this;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-transport-4.1.93.Final.jar!\io\netty\channel\AdaptiveRecvByteBufAllocator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */