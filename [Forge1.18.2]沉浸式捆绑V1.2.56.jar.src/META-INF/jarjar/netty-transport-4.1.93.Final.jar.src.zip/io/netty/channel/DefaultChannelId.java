/*     */ package io.netty.channel;
/*     */ 
/*     */ import io.netty.buffer.ByteBufUtil;
/*     */ import io.netty.util.internal.EmptyArrays;
/*     */ import io.netty.util.internal.MacAddressUtil;
/*     */ import io.netty.util.internal.PlatformDependent;
/*     */ import io.netty.util.internal.SystemPropertyUtil;
/*     */ import io.netty.util.internal.logging.InternalLogger;
/*     */ import io.netty.util.internal.logging.InternalLoggerFactory;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Arrays;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DefaultChannelId
/*     */   implements ChannelId
/*     */ {
/*     */   private static final long serialVersionUID = 3884076183504074063L;
/*  41 */   private static final InternalLogger logger = InternalLoggerFactory.getInstance(DefaultChannelId.class);
/*     */   
/*     */   private static final byte[] MACHINE_ID;
/*     */   private static final int PROCESS_ID_LEN = 4;
/*     */   private static final int PROCESS_ID;
/*     */   private static final int SEQUENCE_LEN = 4;
/*     */   private static final int TIMESTAMP_LEN = 8;
/*     */   private static final int RANDOM_LEN = 4;
/*  49 */   private static final AtomicInteger nextSequence = new AtomicInteger();
/*     */   
/*     */   private final byte[] data;
/*     */   private final int hashCode;
/*     */   
/*     */   public static DefaultChannelId newInstance() {
/*  55 */     return new DefaultChannelId();
/*     */   }
/*     */   private transient String shortValue; private transient String longValue;
/*     */   static {
/*  59 */     int processId = -1;
/*  60 */     String customProcessId = SystemPropertyUtil.get("io.netty.processId");
/*  61 */     if (customProcessId != null) {
/*     */       try {
/*  63 */         processId = Integer.parseInt(customProcessId);
/*  64 */       } catch (NumberFormatException numberFormatException) {}
/*     */ 
/*     */ 
/*     */       
/*  68 */       if (processId < 0) {
/*  69 */         processId = -1;
/*  70 */         logger.warn("-Dio.netty.processId: {} (malformed)", customProcessId);
/*  71 */       } else if (logger.isDebugEnabled()) {
/*  72 */         logger.debug("-Dio.netty.processId: {} (user-set)", Integer.valueOf(processId));
/*     */       } 
/*     */     } 
/*     */     
/*  76 */     if (processId < 0) {
/*  77 */       processId = defaultProcessId();
/*  78 */       if (logger.isDebugEnabled()) {
/*  79 */         logger.debug("-Dio.netty.processId: {} (auto-detected)", Integer.valueOf(processId));
/*     */       }
/*     */     } 
/*     */     
/*  83 */     PROCESS_ID = processId;
/*     */     
/*  85 */     byte[] machineId = null;
/*  86 */     String customMachineId = SystemPropertyUtil.get("io.netty.machineId");
/*  87 */     if (customMachineId != null) {
/*     */       try {
/*  89 */         machineId = MacAddressUtil.parseMAC(customMachineId);
/*  90 */       } catch (Exception e) {
/*  91 */         logger.warn("-Dio.netty.machineId: {} (malformed)", customMachineId, e);
/*     */       } 
/*  93 */       if (machineId != null) {
/*  94 */         logger.debug("-Dio.netty.machineId: {} (user-set)", customMachineId);
/*     */       }
/*     */     } 
/*     */     
/*  98 */     if (machineId == null) {
/*  99 */       machineId = MacAddressUtil.defaultMachineId();
/* 100 */       if (logger.isDebugEnabled()) {
/* 101 */         logger.debug("-Dio.netty.machineId: {} (auto-detected)", MacAddressUtil.formatAddress(machineId));
/*     */       }
/*     */     } 
/*     */     
/* 105 */     MACHINE_ID = machineId;
/*     */   }
/*     */ 
/*     */   
/*     */   static int processHandlePid(ClassLoader loader) {
/* 110 */     int nilValue = -1;
/* 111 */     if (PlatformDependent.javaVersion() >= 9) {
/*     */       Long pid;
/*     */       try {
/* 114 */         Class<?> processHandleImplType = Class.forName("java.lang.ProcessHandle", true, loader);
/* 115 */         Method processHandleCurrent = processHandleImplType.getMethod("current", new Class[0]);
/* 116 */         Object processHandleInstance = processHandleCurrent.invoke(null, new Object[0]);
/* 117 */         Method processHandlePid = processHandleImplType.getMethod("pid", new Class[0]);
/* 118 */         pid = (Long)processHandlePid.invoke(processHandleInstance, new Object[0]);
/* 119 */       } catch (Exception e) {
/* 120 */         logger.debug("Could not invoke ProcessHandle.current().pid();", e);
/* 121 */         return nilValue;
/*     */       } 
/* 123 */       if (pid.longValue() > 2147483647L || pid.longValue() < -2147483648L) {
/* 124 */         throw new IllegalStateException("Current process ID exceeds int range: " + pid);
/*     */       }
/* 126 */       return pid.intValue();
/*     */     } 
/* 128 */     return nilValue;
/*     */   }
/*     */   
/*     */   static int jmxPid(ClassLoader loader) {
/*     */     String value;
/*     */     int pid;
/*     */     try {
/* 135 */       Class<?> mgmtFactoryType = Class.forName("java.lang.management.ManagementFactory", true, loader);
/* 136 */       Class<?> runtimeMxBeanType = Class.forName("java.lang.management.RuntimeMXBean", true, loader);
/*     */       
/* 138 */       Method getRuntimeMXBean = mgmtFactoryType.getMethod("getRuntimeMXBean", EmptyArrays.EMPTY_CLASSES);
/* 139 */       Object bean = getRuntimeMXBean.invoke(null, EmptyArrays.EMPTY_OBJECTS);
/* 140 */       Method getName = runtimeMxBeanType.getMethod("getName", EmptyArrays.EMPTY_CLASSES);
/* 141 */       value = (String)getName.invoke(bean, EmptyArrays.EMPTY_OBJECTS);
/* 142 */     } catch (Throwable t) {
/* 143 */       logger.debug("Could not invoke ManagementFactory.getRuntimeMXBean().getName(); Android?", t);
/*     */       
/*     */       try {
/* 146 */         Class<?> processType = Class.forName("android.os.Process", true, loader);
/* 147 */         Method myPid = processType.getMethod("myPid", EmptyArrays.EMPTY_CLASSES);
/* 148 */         value = myPid.invoke(null, EmptyArrays.EMPTY_OBJECTS).toString();
/* 149 */       } catch (Throwable t2) {
/* 150 */         logger.debug("Could not invoke Process.myPid(); not Android?", t2);
/* 151 */         value = "";
/*     */       } 
/*     */     } 
/*     */     
/* 155 */     int atIndex = value.indexOf('@');
/* 156 */     if (atIndex >= 0) {
/* 157 */       value = value.substring(0, atIndex);
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/* 162 */       pid = Integer.parseInt(value);
/* 163 */     } catch (NumberFormatException e) {
/*     */       
/* 165 */       pid = -1;
/*     */     } 
/*     */     
/* 168 */     if (pid < 0) {
/* 169 */       pid = PlatformDependent.threadLocalRandom().nextInt();
/* 170 */       logger.warn("Failed to find the current process ID from '{}'; using a random value: {}", value, Integer.valueOf(pid));
/*     */     } 
/*     */     
/* 173 */     return pid;
/*     */   }
/*     */   
/*     */   static int defaultProcessId() {
/* 177 */     ClassLoader loader = PlatformDependent.getClassLoader(DefaultChannelId.class);
/* 178 */     int processId = processHandlePid(loader);
/* 179 */     if (processId != -1) {
/* 180 */       return processId;
/*     */     }
/* 182 */     return jmxPid(loader);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private DefaultChannelId() {
/* 192 */     this.data = new byte[MACHINE_ID.length + 4 + 4 + 8 + 4];
/* 193 */     int i = 0;
/*     */ 
/*     */     
/* 196 */     System.arraycopy(MACHINE_ID, 0, this.data, i, MACHINE_ID.length);
/* 197 */     i += MACHINE_ID.length;
/*     */ 
/*     */     
/* 200 */     i = writeInt(i, PROCESS_ID);
/*     */ 
/*     */     
/* 203 */     i = writeInt(i, nextSequence.getAndIncrement());
/*     */ 
/*     */     
/* 206 */     i = writeLong(i, Long.reverse(System.nanoTime()) ^ System.currentTimeMillis());
/*     */ 
/*     */     
/* 209 */     int random = PlatformDependent.threadLocalRandom().nextInt();
/* 210 */     i = writeInt(i, random);
/* 211 */     assert i == this.data.length;
/*     */     
/* 213 */     this.hashCode = Arrays.hashCode(this.data);
/*     */   }
/*     */   
/*     */   private int writeInt(int i, int value) {
/* 217 */     this.data[i++] = (byte)(value >>> 24);
/* 218 */     this.data[i++] = (byte)(value >>> 16);
/* 219 */     this.data[i++] = (byte)(value >>> 8);
/* 220 */     this.data[i++] = (byte)value;
/* 221 */     return i;
/*     */   }
/*     */   
/*     */   private int writeLong(int i, long value) {
/* 225 */     this.data[i++] = (byte)(int)(value >>> 56L);
/* 226 */     this.data[i++] = (byte)(int)(value >>> 48L);
/* 227 */     this.data[i++] = (byte)(int)(value >>> 40L);
/* 228 */     this.data[i++] = (byte)(int)(value >>> 32L);
/* 229 */     this.data[i++] = (byte)(int)(value >>> 24L);
/* 230 */     this.data[i++] = (byte)(int)(value >>> 16L);
/* 231 */     this.data[i++] = (byte)(int)(value >>> 8L);
/* 232 */     this.data[i++] = (byte)(int)value;
/* 233 */     return i;
/*     */   }
/*     */ 
/*     */   
/*     */   public String asShortText() {
/* 238 */     String shortValue = this.shortValue;
/* 239 */     if (shortValue == null) {
/* 240 */       this.shortValue = shortValue = ByteBufUtil.hexDump(this.data, this.data.length - 4, 4);
/*     */     }
/* 242 */     return shortValue;
/*     */   }
/*     */ 
/*     */   
/*     */   public String asLongText() {
/* 247 */     String longValue = this.longValue;
/* 248 */     if (longValue == null) {
/* 249 */       this.longValue = longValue = newLongValue();
/*     */     }
/* 251 */     return longValue;
/*     */   }
/*     */   
/*     */   private String newLongValue() {
/* 255 */     StringBuilder buf = new StringBuilder(2 * this.data.length + 5);
/* 256 */     int i = 0;
/* 257 */     i = appendHexDumpField(buf, i, MACHINE_ID.length);
/* 258 */     i = appendHexDumpField(buf, i, 4);
/* 259 */     i = appendHexDumpField(buf, i, 4);
/* 260 */     i = appendHexDumpField(buf, i, 8);
/* 261 */     i = appendHexDumpField(buf, i, 4);
/* 262 */     assert i == this.data.length;
/* 263 */     return buf.substring(0, buf.length() - 1);
/*     */   }
/*     */   
/*     */   private int appendHexDumpField(StringBuilder buf, int i, int length) {
/* 267 */     buf.append(ByteBufUtil.hexDump(this.data, i, length));
/* 268 */     buf.append('-');
/* 269 */     i += length;
/* 270 */     return i;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 275 */     return this.hashCode;
/*     */   }
/*     */ 
/*     */   
/*     */   public int compareTo(ChannelId o) {
/* 280 */     if (this == o)
/*     */     {
/* 282 */       return 0;
/*     */     }
/* 284 */     if (o instanceof DefaultChannelId) {
/*     */       
/* 286 */       byte[] otherData = ((DefaultChannelId)o).data;
/* 287 */       int len1 = this.data.length;
/* 288 */       int len2 = otherData.length;
/* 289 */       int len = Math.min(len1, len2);
/*     */       
/* 291 */       for (int k = 0; k < len; k++) {
/* 292 */         byte x = this.data[k];
/* 293 */         byte y = otherData[k];
/* 294 */         if (x != y)
/*     */         {
/* 296 */           return (x & 0xFF) - (y & 0xFF);
/*     */         }
/*     */       } 
/* 299 */       return len1 - len2;
/*     */     } 
/*     */     
/* 302 */     return asLongText().compareTo(o.asLongText());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 307 */     if (this == obj) {
/* 308 */       return true;
/*     */     }
/* 310 */     if (!(obj instanceof DefaultChannelId)) {
/* 311 */       return false;
/*     */     }
/* 313 */     DefaultChannelId other = (DefaultChannelId)obj;
/* 314 */     return (this.hashCode == other.hashCode && Arrays.equals(this.data, other.data));
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 319 */     return asShortText();
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-transport-4.1.93.Final.jar!\io\netty\channel\DefaultChannelId.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */