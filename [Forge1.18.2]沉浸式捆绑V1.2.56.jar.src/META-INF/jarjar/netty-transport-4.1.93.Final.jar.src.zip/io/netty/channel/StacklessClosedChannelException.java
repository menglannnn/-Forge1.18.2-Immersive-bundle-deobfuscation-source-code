/*    */ package io.netty.channel;
/*    */ 
/*    */ import io.netty.util.internal.ThrowableUtil;
/*    */ import java.nio.channels.ClosedChannelException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class StacklessClosedChannelException
/*    */   extends ClosedChannelException
/*    */ {
/*    */   private static final long serialVersionUID = -2214806025529435136L;
/*    */   
/*    */   public Throwable fillInStackTrace() {
/* 34 */     return this;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static StacklessClosedChannelException newInstance(Class<?> clazz, String method) {
/* 41 */     return (StacklessClosedChannelException)ThrowableUtil.unknownStackTrace(new StacklessClosedChannelException(), clazz, method);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-transport-4.1.93.Final.jar!\io\netty\channel\StacklessClosedChannelException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */