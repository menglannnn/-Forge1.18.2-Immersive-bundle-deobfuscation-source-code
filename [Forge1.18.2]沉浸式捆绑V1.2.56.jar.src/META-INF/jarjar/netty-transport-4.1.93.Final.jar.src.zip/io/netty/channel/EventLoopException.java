/*    */ package io.netty.channel;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EventLoopException
/*    */   extends ChannelException
/*    */ {
/*    */   private static final long serialVersionUID = -8969100344583703616L;
/*    */   
/*    */   public EventLoopException() {}
/*    */   
/*    */   public EventLoopException(String message, Throwable cause) {
/* 30 */     super(message, cause);
/*    */   }
/*    */   
/*    */   public EventLoopException(String message) {
/* 34 */     super(message);
/*    */   }
/*    */   
/*    */   public EventLoopException(Throwable cause) {
/* 38 */     super(cause);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-transport-4.1.93.Final.jar!\io\netty\channel\EventLoopException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */