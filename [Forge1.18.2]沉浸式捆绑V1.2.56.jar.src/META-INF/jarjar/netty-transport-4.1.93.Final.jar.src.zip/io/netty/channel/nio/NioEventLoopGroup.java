/*     */ package io.netty.channel.nio;
/*     */ 
/*     */ import io.netty.channel.DefaultSelectStrategyFactory;
/*     */ import io.netty.channel.EventLoop;
/*     */ import io.netty.channel.EventLoopTaskQueueFactory;
/*     */ import io.netty.channel.MultithreadEventLoopGroup;
/*     */ import io.netty.channel.SelectStrategyFactory;
/*     */ import io.netty.util.concurrent.EventExecutor;
/*     */ import io.netty.util.concurrent.EventExecutorChooserFactory;
/*     */ import io.netty.util.concurrent.RejectedExecutionHandler;
/*     */ import io.netty.util.concurrent.RejectedExecutionHandlers;
/*     */ import java.nio.channels.spi.SelectorProvider;
/*     */ import java.util.concurrent.Executor;
/*     */ import java.util.concurrent.ThreadFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NioEventLoopGroup
/*     */   extends MultithreadEventLoopGroup
/*     */ {
/*     */   public NioEventLoopGroup() {
/*  45 */     this(0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NioEventLoopGroup(int nThreads) {
/*  53 */     this(nThreads, (Executor)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NioEventLoopGroup(ThreadFactory threadFactory) {
/*  61 */     this(0, threadFactory, SelectorProvider.provider());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NioEventLoopGroup(int nThreads, ThreadFactory threadFactory) {
/*  69 */     this(nThreads, threadFactory, SelectorProvider.provider());
/*     */   }
/*     */   
/*     */   public NioEventLoopGroup(int nThreads, Executor executor) {
/*  73 */     this(nThreads, executor, SelectorProvider.provider());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NioEventLoopGroup(int nThreads, ThreadFactory threadFactory, SelectorProvider selectorProvider) {
/*  82 */     this(nThreads, threadFactory, selectorProvider, DefaultSelectStrategyFactory.INSTANCE);
/*     */   }
/*     */ 
/*     */   
/*     */   public NioEventLoopGroup(int nThreads, ThreadFactory threadFactory, SelectorProvider selectorProvider, SelectStrategyFactory selectStrategyFactory) {
/*  87 */     super(nThreads, threadFactory, new Object[] { selectorProvider, selectStrategyFactory, RejectedExecutionHandlers.reject() });
/*     */   }
/*     */ 
/*     */   
/*     */   public NioEventLoopGroup(int nThreads, Executor executor, SelectorProvider selectorProvider) {
/*  92 */     this(nThreads, executor, selectorProvider, DefaultSelectStrategyFactory.INSTANCE);
/*     */   }
/*     */ 
/*     */   
/*     */   public NioEventLoopGroup(int nThreads, Executor executor, SelectorProvider selectorProvider, SelectStrategyFactory selectStrategyFactory) {
/*  97 */     super(nThreads, executor, new Object[] { selectorProvider, selectStrategyFactory, RejectedExecutionHandlers.reject() });
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public NioEventLoopGroup(int nThreads, Executor executor, EventExecutorChooserFactory chooserFactory, SelectorProvider selectorProvider, SelectStrategyFactory selectStrategyFactory) {
/* 103 */     super(nThreads, executor, chooserFactory, new Object[] { selectorProvider, selectStrategyFactory, 
/* 104 */           RejectedExecutionHandlers.reject() });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NioEventLoopGroup(int nThreads, Executor executor, EventExecutorChooserFactory chooserFactory, SelectorProvider selectorProvider, SelectStrategyFactory selectStrategyFactory, RejectedExecutionHandler rejectedExecutionHandler) {
/* 111 */     super(nThreads, executor, chooserFactory, new Object[] { selectorProvider, selectStrategyFactory, rejectedExecutionHandler });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NioEventLoopGroup(int nThreads, Executor executor, EventExecutorChooserFactory chooserFactory, SelectorProvider selectorProvider, SelectStrategyFactory selectStrategyFactory, RejectedExecutionHandler rejectedExecutionHandler, EventLoopTaskQueueFactory taskQueueFactory) {
/* 119 */     super(nThreads, executor, chooserFactory, new Object[] { selectorProvider, selectStrategyFactory, rejectedExecutionHandler, taskQueueFactory });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NioEventLoopGroup(int nThreads, Executor executor, EventExecutorChooserFactory chooserFactory, SelectorProvider selectorProvider, SelectStrategyFactory selectStrategyFactory, RejectedExecutionHandler rejectedExecutionHandler, EventLoopTaskQueueFactory taskQueueFactory, EventLoopTaskQueueFactory tailTaskQueueFactory) {
/* 143 */     super(nThreads, executor, chooserFactory, new Object[] { selectorProvider, selectStrategyFactory, rejectedExecutionHandler, taskQueueFactory, tailTaskQueueFactory });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setIoRatio(int ioRatio) {
/* 152 */     for (EventExecutor e : this) {
/* 153 */       ((NioEventLoop)e).setIoRatio(ioRatio);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void rebuildSelectors() {
/* 162 */     for (EventExecutor e : this) {
/* 163 */       ((NioEventLoop)e).rebuildSelector();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected EventLoop newChild(Executor executor, Object... args) throws Exception {
/* 169 */     SelectorProvider selectorProvider = (SelectorProvider)args[0];
/* 170 */     SelectStrategyFactory selectStrategyFactory = (SelectStrategyFactory)args[1];
/* 171 */     RejectedExecutionHandler rejectedExecutionHandler = (RejectedExecutionHandler)args[2];
/* 172 */     EventLoopTaskQueueFactory taskQueueFactory = null;
/* 173 */     EventLoopTaskQueueFactory tailTaskQueueFactory = null;
/*     */     
/* 175 */     int argsLength = args.length;
/* 176 */     if (argsLength > 3) {
/* 177 */       taskQueueFactory = (EventLoopTaskQueueFactory)args[3];
/*     */     }
/* 179 */     if (argsLength > 4) {
/* 180 */       tailTaskQueueFactory = (EventLoopTaskQueueFactory)args[4];
/*     */     }
/* 182 */     return (EventLoop)new NioEventLoop(this, executor, selectorProvider, selectStrategyFactory
/* 183 */         .newSelectStrategy(), rejectedExecutionHandler, taskQueueFactory, tailTaskQueueFactory);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-transport-4.1.93.Final.jar!\io\netty\channel\nio\NioEventLoopGroup.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */