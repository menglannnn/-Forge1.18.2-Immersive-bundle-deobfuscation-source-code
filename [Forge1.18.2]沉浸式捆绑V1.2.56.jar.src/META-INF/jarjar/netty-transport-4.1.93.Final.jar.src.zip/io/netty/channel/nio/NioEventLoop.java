/*     */ package io.netty.channel.nio;
/*     */ 
/*     */ import io.netty.channel.Channel;
/*     */ import io.netty.channel.ChannelException;
/*     */ import io.netty.channel.EventLoop;
/*     */ import io.netty.channel.EventLoopException;
/*     */ import io.netty.channel.EventLoopGroup;
/*     */ import io.netty.channel.EventLoopTaskQueueFactory;
/*     */ import io.netty.channel.SelectStrategy;
/*     */ import io.netty.channel.SingleThreadEventLoop;
/*     */ import io.netty.util.IntSupplier;
/*     */ import io.netty.util.concurrent.RejectedExecutionHandler;
/*     */ import io.netty.util.internal.ObjectUtil;
/*     */ import io.netty.util.internal.PlatformDependent;
/*     */ import io.netty.util.internal.ReflectionUtil;
/*     */ import io.netty.util.internal.SystemPropertyUtil;
/*     */ import io.netty.util.internal.logging.InternalLogger;
/*     */ import io.netty.util.internal.logging.InternalLoggerFactory;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Field;
/*     */ import java.nio.channels.CancelledKeyException;
/*     */ import java.nio.channels.SelectableChannel;
/*     */ import java.nio.channels.SelectionKey;
/*     */ import java.nio.channels.Selector;
/*     */ import java.nio.channels.spi.SelectorProvider;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.Queue;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.Executor;
/*     */ import java.util.concurrent.atomic.AtomicLong;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class NioEventLoop
/*     */   extends SingleThreadEventLoop
/*     */ {
/*  60 */   private static final InternalLogger logger = InternalLoggerFactory.getInstance(NioEventLoop.class);
/*     */ 
/*     */   
/*     */   private static final int CLEANUP_INTERVAL = 256;
/*     */   
/*  65 */   private static final boolean DISABLE_KEY_SET_OPTIMIZATION = SystemPropertyUtil.getBoolean("io.netty.noKeySetOptimization", false);
/*     */   
/*     */   private static final int MIN_PREMATURE_SELECTOR_RETURNS = 3;
/*     */   private static final int SELECTOR_AUTO_REBUILD_THRESHOLD;
/*     */   
/*  70 */   private final IntSupplier selectNowSupplier = new IntSupplier()
/*     */     {
/*     */       public int get() throws Exception {
/*  73 */         return NioEventLoop.this.selectNow();
/*     */       }
/*     */     };
/*     */ 
/*     */   
/*     */   private Selector selector;
/*     */   
/*     */   private Selector unwrappedSelector;
/*     */   private SelectedSelectionKeySet selectedKeys;
/*     */   
/*     */   static {
/*  84 */     if (PlatformDependent.javaVersion() < 7) {
/*  85 */       String key = "sun.nio.ch.bugLevel";
/*  86 */       String bugLevel = SystemPropertyUtil.get("sun.nio.ch.bugLevel");
/*  87 */       if (bugLevel == null) {
/*     */         try {
/*  89 */           AccessController.doPrivileged(new PrivilegedAction<Void>()
/*     */               {
/*     */                 public Void run() {
/*  92 */                   System.setProperty("sun.nio.ch.bugLevel", "");
/*  93 */                   return null;
/*     */                 }
/*     */               });
/*  96 */         } catch (SecurityException e) {
/*  97 */           logger.debug("Unable to get/set System Property: sun.nio.ch.bugLevel", e);
/*     */         } 
/*     */       }
/*     */     } 
/*     */     
/* 102 */     int selectorAutoRebuildThreshold = SystemPropertyUtil.getInt("io.netty.selectorAutoRebuildThreshold", 512);
/* 103 */     if (selectorAutoRebuildThreshold < 3) {
/* 104 */       selectorAutoRebuildThreshold = 0;
/*     */     }
/*     */     
/* 107 */     SELECTOR_AUTO_REBUILD_THRESHOLD = selectorAutoRebuildThreshold;
/*     */     
/* 109 */     if (logger.isDebugEnabled()) {
/* 110 */       logger.debug("-Dio.netty.noKeySetOptimization: {}", Boolean.valueOf(DISABLE_KEY_SET_OPTIMIZATION));
/* 111 */       logger.debug("-Dio.netty.selectorAutoRebuildThreshold: {}", Integer.valueOf(SELECTOR_AUTO_REBUILD_THRESHOLD));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final SelectorProvider provider;
/*     */ 
/*     */ 
/*     */   
/*     */   private static final long AWAKE = -1L;
/*     */ 
/*     */ 
/*     */   
/*     */   private static final long NONE = 9223372036854775807L;
/*     */ 
/*     */ 
/*     */   
/* 131 */   private final AtomicLong nextWakeupNanos = new AtomicLong(-1L);
/*     */   
/*     */   private final SelectStrategy selectStrategy;
/*     */   
/* 135 */   private volatile int ioRatio = 50;
/*     */   
/*     */   private int cancelledKeys;
/*     */   
/*     */   private boolean needsToSelectAgain;
/*     */   
/*     */   NioEventLoop(NioEventLoopGroup parent, Executor executor, SelectorProvider selectorProvider, SelectStrategy strategy, RejectedExecutionHandler rejectedExecutionHandler, EventLoopTaskQueueFactory taskQueueFactory, EventLoopTaskQueueFactory tailTaskQueueFactory) {
/* 142 */     super((EventLoopGroup)parent, executor, false, newTaskQueue(taskQueueFactory), newTaskQueue(tailTaskQueueFactory), rejectedExecutionHandler);
/*     */     
/* 144 */     this.provider = (SelectorProvider)ObjectUtil.checkNotNull(selectorProvider, "selectorProvider");
/* 145 */     this.selectStrategy = (SelectStrategy)ObjectUtil.checkNotNull(strategy, "selectStrategy");
/* 146 */     SelectorTuple selectorTuple = openSelector();
/* 147 */     this.selector = selectorTuple.selector;
/* 148 */     this.unwrappedSelector = selectorTuple.unwrappedSelector;
/*     */   }
/*     */ 
/*     */   
/*     */   private static Queue<Runnable> newTaskQueue(EventLoopTaskQueueFactory queueFactory) {
/* 153 */     if (queueFactory == null) {
/* 154 */       return newTaskQueue0(DEFAULT_MAX_PENDING_TASKS);
/*     */     }
/* 156 */     return queueFactory.newTaskQueue(DEFAULT_MAX_PENDING_TASKS);
/*     */   }
/*     */   
/*     */   private static final class SelectorTuple {
/*     */     final Selector unwrappedSelector;
/*     */     final Selector selector;
/*     */     
/*     */     SelectorTuple(Selector unwrappedSelector) {
/* 164 */       this.unwrappedSelector = unwrappedSelector;
/* 165 */       this.selector = unwrappedSelector;
/*     */     }
/*     */     
/*     */     SelectorTuple(Selector unwrappedSelector, Selector selector) {
/* 169 */       this.unwrappedSelector = unwrappedSelector;
/* 170 */       this.selector = selector;
/*     */     }
/*     */   }
/*     */   
/*     */   private SelectorTuple openSelector() {
/*     */     final Selector unwrappedSelector;
/*     */     try {
/* 177 */       unwrappedSelector = this.provider.openSelector();
/* 178 */     } catch (IOException e) {
/* 179 */       throw new ChannelException("failed to open a new selector", e);
/*     */     } 
/*     */     
/* 182 */     if (DISABLE_KEY_SET_OPTIMIZATION) {
/* 183 */       return new SelectorTuple(unwrappedSelector);
/*     */     }
/*     */     
/* 186 */     Object maybeSelectorImplClass = AccessController.doPrivileged(new PrivilegedAction()
/*     */         {
/*     */           public Object run() {
/*     */             try {
/* 190 */               return Class.forName("sun.nio.ch.SelectorImpl", false, 
/*     */ 
/*     */                   
/* 193 */                   PlatformDependent.getSystemClassLoader());
/* 194 */             } catch (Throwable cause) {
/* 195 */               return cause;
/*     */             } 
/*     */           }
/*     */         });
/*     */     
/* 200 */     if (!(maybeSelectorImplClass instanceof Class) || 
/*     */       
/* 202 */       !((Class)maybeSelectorImplClass).isAssignableFrom(unwrappedSelector.getClass())) {
/* 203 */       if (maybeSelectorImplClass instanceof Throwable) {
/* 204 */         Throwable t = (Throwable)maybeSelectorImplClass;
/* 205 */         logger.trace("failed to instrument a special java.util.Set into: {}", unwrappedSelector, t);
/*     */       } 
/* 207 */       return new SelectorTuple(unwrappedSelector);
/*     */     } 
/*     */     
/* 210 */     final Class<?> selectorImplClass = (Class)maybeSelectorImplClass;
/* 211 */     final SelectedSelectionKeySet selectedKeySet = new SelectedSelectionKeySet();
/*     */     
/* 213 */     Object maybeException = AccessController.doPrivileged(new PrivilegedAction()
/*     */         {
/*     */           public Object run() {
/*     */             try {
/* 217 */               Field selectedKeysField = selectorImplClass.getDeclaredField("selectedKeys");
/* 218 */               Field publicSelectedKeysField = selectorImplClass.getDeclaredField("publicSelectedKeys");
/*     */               
/* 220 */               if (PlatformDependent.javaVersion() >= 9 && PlatformDependent.hasUnsafe()) {
/*     */ 
/*     */                 
/* 223 */                 long selectedKeysFieldOffset = PlatformDependent.objectFieldOffset(selectedKeysField);
/*     */                 
/* 225 */                 long publicSelectedKeysFieldOffset = PlatformDependent.objectFieldOffset(publicSelectedKeysField);
/*     */                 
/* 227 */                 if (selectedKeysFieldOffset != -1L && publicSelectedKeysFieldOffset != -1L) {
/* 228 */                   PlatformDependent.putObject(unwrappedSelector, selectedKeysFieldOffset, selectedKeySet);
/*     */                   
/* 230 */                   PlatformDependent.putObject(unwrappedSelector, publicSelectedKeysFieldOffset, selectedKeySet);
/*     */                   
/* 232 */                   return null;
/*     */                 } 
/*     */               } 
/*     */ 
/*     */               
/* 237 */               Throwable cause = ReflectionUtil.trySetAccessible(selectedKeysField, true);
/* 238 */               if (cause != null) {
/* 239 */                 return cause;
/*     */               }
/* 241 */               cause = ReflectionUtil.trySetAccessible(publicSelectedKeysField, true);
/* 242 */               if (cause != null) {
/* 243 */                 return cause;
/*     */               }
/*     */               
/* 246 */               selectedKeysField.set(unwrappedSelector, selectedKeySet);
/* 247 */               publicSelectedKeysField.set(unwrappedSelector, selectedKeySet);
/* 248 */               return null;
/* 249 */             } catch (NoSuchFieldException e) {
/* 250 */               return e;
/* 251 */             } catch (IllegalAccessException e) {
/* 252 */               return e;
/*     */             } 
/*     */           }
/*     */         });
/*     */     
/* 257 */     if (maybeException instanceof Exception) {
/* 258 */       this.selectedKeys = null;
/* 259 */       Exception e = (Exception)maybeException;
/* 260 */       logger.trace("failed to instrument a special java.util.Set into: {}", unwrappedSelector, e);
/* 261 */       return new SelectorTuple(unwrappedSelector);
/*     */     } 
/* 263 */     this.selectedKeys = selectedKeySet;
/* 264 */     logger.trace("instrumented a special java.util.Set into: {}", unwrappedSelector);
/* 265 */     return new SelectorTuple(unwrappedSelector, new SelectedSelectionKeySetSelector(unwrappedSelector, selectedKeySet));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SelectorProvider selectorProvider() {
/* 273 */     return this.provider;
/*     */   }
/*     */ 
/*     */   
/*     */   protected Queue<Runnable> newTaskQueue(int maxPendingTasks) {
/* 278 */     return newTaskQueue0(maxPendingTasks);
/*     */   }
/*     */ 
/*     */   
/*     */   private static Queue<Runnable> newTaskQueue0(int maxPendingTasks) {
/* 283 */     return (maxPendingTasks == Integer.MAX_VALUE) ? PlatformDependent.newMpscQueue() : 
/* 284 */       PlatformDependent.newMpscQueue(maxPendingTasks);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void register(final SelectableChannel ch, final int interestOps, final NioTask<?> task) {
/* 293 */     ObjectUtil.checkNotNull(ch, "ch");
/* 294 */     if (interestOps == 0) {
/* 295 */       throw new IllegalArgumentException("interestOps must be non-zero.");
/*     */     }
/* 297 */     if ((interestOps & (ch.validOps() ^ 0xFFFFFFFF)) != 0) {
/* 298 */       throw new IllegalArgumentException("invalid interestOps: " + interestOps + "(validOps: " + ch
/* 299 */           .validOps() + ')');
/*     */     }
/* 301 */     ObjectUtil.checkNotNull(task, "task");
/*     */     
/* 303 */     if (isShutdown()) {
/* 304 */       throw new IllegalStateException("event loop shut down");
/*     */     }
/*     */     
/* 307 */     if (inEventLoop()) {
/* 308 */       register0(ch, interestOps, task);
/*     */     } else {
/*     */ 
/*     */       
/*     */       try {
/* 313 */         submit(new Runnable()
/*     */             {
/*     */               public void run() {
/* 316 */                 NioEventLoop.this.register0(ch, interestOps, task);
/*     */               }
/* 318 */             }).sync();
/* 319 */       } catch (InterruptedException ignore) {
/*     */         
/* 321 */         Thread.currentThread().interrupt();
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void register0(SelectableChannel ch, int interestOps, NioTask<?> task) {
/*     */     try {
/* 328 */       ch.register(this.unwrappedSelector, interestOps, task);
/* 329 */     } catch (Exception e) {
/* 330 */       throw new EventLoopException("failed to register a channel", e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getIoRatio() {
/* 338 */     return this.ioRatio;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setIoRatio(int ioRatio) {
/* 348 */     if (ioRatio <= 0 || ioRatio > 100) {
/* 349 */       throw new IllegalArgumentException("ioRatio: " + ioRatio + " (expected: 0 < ioRatio <= 100)");
/*     */     }
/* 351 */     this.ioRatio = ioRatio;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void rebuildSelector() {
/* 359 */     if (!inEventLoop()) {
/* 360 */       execute(new Runnable()
/*     */           {
/*     */             public void run() {
/* 363 */               NioEventLoop.this.rebuildSelector0();
/*     */             }
/*     */           });
/*     */       return;
/*     */     } 
/* 368 */     rebuildSelector0();
/*     */   }
/*     */ 
/*     */   
/*     */   public int registeredChannels() {
/* 373 */     return this.selector.keys().size() - this.cancelledKeys;
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterator<Channel> registeredChannelsIterator() {
/* 378 */     assert inEventLoop();
/* 379 */     final Set<SelectionKey> keys = this.selector.keys();
/* 380 */     if (keys.isEmpty()) {
/* 381 */       return SingleThreadEventLoop.ChannelsReadOnlyIterator.empty();
/*     */     }
/* 383 */     return new Iterator<Channel>()
/*     */       {
/* 385 */         final Iterator<SelectionKey> selectionKeyIterator = ((Set<SelectionKey>)ObjectUtil.checkNotNull(keys, "selectionKeys"))
/* 386 */           .iterator();
/*     */         
/*     */         Channel next;
/*     */         boolean isDone;
/*     */         
/*     */         public boolean hasNext() {
/* 392 */           if (this.isDone) {
/* 393 */             return false;
/*     */           }
/* 395 */           Channel cur = this.next;
/* 396 */           if (cur == null) {
/* 397 */             cur = this.next = nextOrDone();
/* 398 */             return (cur != null);
/*     */           } 
/* 400 */           return true;
/*     */         }
/*     */ 
/*     */         
/*     */         public Channel next() {
/* 405 */           if (this.isDone) {
/* 406 */             throw new NoSuchElementException();
/*     */           }
/* 408 */           Channel cur = this.next;
/* 409 */           if (cur == null) {
/* 410 */             cur = nextOrDone();
/* 411 */             if (cur == null) {
/* 412 */               throw new NoSuchElementException();
/*     */             }
/*     */           } 
/* 415 */           this.next = nextOrDone();
/* 416 */           return cur;
/*     */         }
/*     */ 
/*     */         
/*     */         public void remove() {
/* 421 */           throw new UnsupportedOperationException("remove");
/*     */         }
/*     */         
/*     */         private Channel nextOrDone() {
/* 425 */           Iterator<SelectionKey> it = this.selectionKeyIterator;
/* 426 */           while (it.hasNext()) {
/* 427 */             SelectionKey key = it.next();
/* 428 */             if (key.isValid()) {
/* 429 */               Object attachment = key.attachment();
/* 430 */               if (attachment instanceof AbstractNioChannel) {
/* 431 */                 return (Channel)attachment;
/*     */               }
/*     */             } 
/*     */           } 
/* 435 */           this.isDone = true;
/* 436 */           return null;
/*     */         }
/*     */       };
/*     */   }
/*     */   private void rebuildSelector0() {
/*     */     SelectorTuple newSelectorTuple;
/* 442 */     Selector oldSelector = this.selector;
/*     */ 
/*     */     
/* 445 */     if (oldSelector == null) {
/*     */       return;
/*     */     }
/*     */     
/*     */     try {
/* 450 */       newSelectorTuple = openSelector();
/* 451 */     } catch (Exception e) {
/* 452 */       logger.warn("Failed to create a new Selector.", e);
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 457 */     int nChannels = 0;
/* 458 */     for (SelectionKey key : oldSelector.keys()) {
/* 459 */       Object a = key.attachment();
/*     */       try {
/* 461 */         if (!key.isValid() || key.channel().keyFor(newSelectorTuple.unwrappedSelector) != null) {
/*     */           continue;
/*     */         }
/*     */         
/* 465 */         int interestOps = key.interestOps();
/* 466 */         key.cancel();
/* 467 */         SelectionKey newKey = key.channel().register(newSelectorTuple.unwrappedSelector, interestOps, a);
/* 468 */         if (a instanceof AbstractNioChannel)
/*     */         {
/* 470 */           ((AbstractNioChannel)a).selectionKey = newKey;
/*     */         }
/* 472 */         nChannels++;
/* 473 */       } catch (Exception e) {
/* 474 */         logger.warn("Failed to re-register a Channel to the new Selector.", e);
/* 475 */         if (a instanceof AbstractNioChannel) {
/* 476 */           AbstractNioChannel ch = (AbstractNioChannel)a;
/* 477 */           ch.unsafe().close(ch.unsafe().voidPromise());
/*     */           continue;
/*     */         } 
/* 480 */         NioTask<SelectableChannel> task = (NioTask<SelectableChannel>)a;
/* 481 */         invokeChannelUnregistered(task, key, e);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 486 */     this.selector = newSelectorTuple.selector;
/* 487 */     this.unwrappedSelector = newSelectorTuple.unwrappedSelector;
/*     */ 
/*     */     
/*     */     try {
/* 491 */       oldSelector.close();
/* 492 */     } catch (Throwable t) {
/* 493 */       if (logger.isWarnEnabled()) {
/* 494 */         logger.warn("Failed to close the old Selector.", t);
/*     */       }
/*     */     } 
/*     */     
/* 498 */     if (logger.isInfoEnabled()) {
/* 499 */       logger.info("Migrated " + nChannels + " channel(s) to the new Selector.");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void run() {
/*     */     // Byte code:
/*     */     //   0: iconst_0
/*     */     //   1: istore_1
/*     */     //   2: aload_0
/*     */     //   3: getfield selectStrategy : Lio/netty/channel/SelectStrategy;
/*     */     //   6: aload_0
/*     */     //   7: getfield selectNowSupplier : Lio/netty/util/IntSupplier;
/*     */     //   10: aload_0
/*     */     //   11: invokevirtual hasTasks : ()Z
/*     */     //   14: invokeinterface calculateStrategy : (Lio/netty/util/IntSupplier;Z)I
/*     */     //   19: istore_2
/*     */     //   20: iload_2
/*     */     //   21: tableswitch default -> 147, -3 -> 81, -2 -> 48, -1 -> 81
/*     */     //   48: aload_0
/*     */     //   49: invokevirtual isShuttingDown : ()Z
/*     */     //   52: ifeq -> 67
/*     */     //   55: aload_0
/*     */     //   56: invokespecial closeAll : ()V
/*     */     //   59: aload_0
/*     */     //   60: invokevirtual confirmShutdown : ()Z
/*     */     //   63: ifeq -> 67
/*     */     //   66: return
/*     */     //   67: goto -> 2
/*     */     //   70: astore_3
/*     */     //   71: aload_3
/*     */     //   72: athrow
/*     */     //   73: astore_3
/*     */     //   74: aload_3
/*     */     //   75: invokestatic handleLoopException : (Ljava/lang/Throwable;)V
/*     */     //   78: goto -> 2
/*     */     //   81: aload_0
/*     */     //   82: invokevirtual nextScheduledTaskDeadlineNanos : ()J
/*     */     //   85: lstore_3
/*     */     //   86: lload_3
/*     */     //   87: ldc2_w -1
/*     */     //   90: lcmp
/*     */     //   91: ifne -> 98
/*     */     //   94: ldc2_w 9223372036854775807
/*     */     //   97: lstore_3
/*     */     //   98: aload_0
/*     */     //   99: getfield nextWakeupNanos : Ljava/util/concurrent/atomic/AtomicLong;
/*     */     //   102: lload_3
/*     */     //   103: invokevirtual set : (J)V
/*     */     //   106: aload_0
/*     */     //   107: invokevirtual hasTasks : ()Z
/*     */     //   110: ifne -> 119
/*     */     //   113: aload_0
/*     */     //   114: lload_3
/*     */     //   115: invokespecial select : (J)I
/*     */     //   118: istore_2
/*     */     //   119: aload_0
/*     */     //   120: getfield nextWakeupNanos : Ljava/util/concurrent/atomic/AtomicLong;
/*     */     //   123: ldc2_w -1
/*     */     //   126: invokevirtual lazySet : (J)V
/*     */     //   129: goto -> 147
/*     */     //   132: astore #5
/*     */     //   134: aload_0
/*     */     //   135: getfield nextWakeupNanos : Ljava/util/concurrent/atomic/AtomicLong;
/*     */     //   138: ldc2_w -1
/*     */     //   141: invokevirtual lazySet : (J)V
/*     */     //   144: aload #5
/*     */     //   146: athrow
/*     */     //   147: goto -> 198
/*     */     //   150: astore_3
/*     */     //   151: aload_0
/*     */     //   152: invokespecial rebuildSelector0 : ()V
/*     */     //   155: iconst_0
/*     */     //   156: istore_1
/*     */     //   157: aload_3
/*     */     //   158: invokestatic handleLoopException : (Ljava/lang/Throwable;)V
/*     */     //   161: aload_0
/*     */     //   162: invokevirtual isShuttingDown : ()Z
/*     */     //   165: ifeq -> 180
/*     */     //   168: aload_0
/*     */     //   169: invokespecial closeAll : ()V
/*     */     //   172: aload_0
/*     */     //   173: invokevirtual confirmShutdown : ()Z
/*     */     //   176: ifeq -> 180
/*     */     //   179: return
/*     */     //   180: goto -> 2
/*     */     //   183: astore #4
/*     */     //   185: aload #4
/*     */     //   187: athrow
/*     */     //   188: astore #4
/*     */     //   190: aload #4
/*     */     //   192: invokestatic handleLoopException : (Ljava/lang/Throwable;)V
/*     */     //   195: goto -> 2
/*     */     //   198: iinc #1, 1
/*     */     //   201: aload_0
/*     */     //   202: iconst_0
/*     */     //   203: putfield cancelledKeys : I
/*     */     //   206: aload_0
/*     */     //   207: iconst_0
/*     */     //   208: putfield needsToSelectAgain : Z
/*     */     //   211: aload_0
/*     */     //   212: getfield ioRatio : I
/*     */     //   215: istore_3
/*     */     //   216: iload_3
/*     */     //   217: bipush #100
/*     */     //   219: if_icmpne -> 253
/*     */     //   222: iload_2
/*     */     //   223: ifle -> 230
/*     */     //   226: aload_0
/*     */     //   227: invokespecial processSelectedKeys : ()V
/*     */     //   230: aload_0
/*     */     //   231: invokevirtual runAllTasks : ()Z
/*     */     //   234: istore #4
/*     */     //   236: goto -> 250
/*     */     //   239: astore #6
/*     */     //   241: aload_0
/*     */     //   242: invokevirtual runAllTasks : ()Z
/*     */     //   245: istore #4
/*     */     //   247: aload #6
/*     */     //   249: athrow
/*     */     //   250: goto -> 334
/*     */     //   253: iload_2
/*     */     //   254: ifle -> 327
/*     */     //   257: invokestatic nanoTime : ()J
/*     */     //   260: lstore #5
/*     */     //   262: aload_0
/*     */     //   263: invokespecial processSelectedKeys : ()V
/*     */     //   266: invokestatic nanoTime : ()J
/*     */     //   269: lload #5
/*     */     //   271: lsub
/*     */     //   272: lstore #7
/*     */     //   274: aload_0
/*     */     //   275: lload #7
/*     */     //   277: bipush #100
/*     */     //   279: iload_3
/*     */     //   280: isub
/*     */     //   281: i2l
/*     */     //   282: lmul
/*     */     //   283: iload_3
/*     */     //   284: i2l
/*     */     //   285: ldiv
/*     */     //   286: invokevirtual runAllTasks : (J)Z
/*     */     //   289: istore #4
/*     */     //   291: goto -> 324
/*     */     //   294: astore #9
/*     */     //   296: invokestatic nanoTime : ()J
/*     */     //   299: lload #5
/*     */     //   301: lsub
/*     */     //   302: lstore #10
/*     */     //   304: aload_0
/*     */     //   305: lload #10
/*     */     //   307: bipush #100
/*     */     //   309: iload_3
/*     */     //   310: isub
/*     */     //   311: i2l
/*     */     //   312: lmul
/*     */     //   313: iload_3
/*     */     //   314: i2l
/*     */     //   315: ldiv
/*     */     //   316: invokevirtual runAllTasks : (J)Z
/*     */     //   319: istore #4
/*     */     //   321: aload #9
/*     */     //   323: athrow
/*     */     //   324: goto -> 334
/*     */     //   327: aload_0
/*     */     //   328: lconst_0
/*     */     //   329: invokevirtual runAllTasks : (J)Z
/*     */     //   332: istore #4
/*     */     //   334: iload #4
/*     */     //   336: ifne -> 343
/*     */     //   339: iload_2
/*     */     //   340: ifle -> 384
/*     */     //   343: iload_1
/*     */     //   344: iconst_3
/*     */     //   345: if_icmple -> 379
/*     */     //   348: getstatic io/netty/channel/nio/NioEventLoop.logger : Lio/netty/util/internal/logging/InternalLogger;
/*     */     //   351: invokeinterface isDebugEnabled : ()Z
/*     */     //   356: ifeq -> 379
/*     */     //   359: getstatic io/netty/channel/nio/NioEventLoop.logger : Lio/netty/util/internal/logging/InternalLogger;
/*     */     //   362: ldc 'Selector.select() returned prematurely {} times in a row for Selector {}.'
/*     */     //   364: iload_1
/*     */     //   365: iconst_1
/*     */     //   366: isub
/*     */     //   367: invokestatic valueOf : (I)Ljava/lang/Integer;
/*     */     //   370: aload_0
/*     */     //   371: getfield selector : Ljava/nio/channels/Selector;
/*     */     //   374: invokeinterface debug : (Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;)V
/*     */     //   379: iconst_0
/*     */     //   380: istore_1
/*     */     //   381: goto -> 394
/*     */     //   384: aload_0
/*     */     //   385: iload_1
/*     */     //   386: invokespecial unexpectedSelectorWakeup : (I)Z
/*     */     //   389: ifeq -> 394
/*     */     //   392: iconst_0
/*     */     //   393: istore_1
/*     */     //   394: aload_0
/*     */     //   395: invokevirtual isShuttingDown : ()Z
/*     */     //   398: ifeq -> 413
/*     */     //   401: aload_0
/*     */     //   402: invokespecial closeAll : ()V
/*     */     //   405: aload_0
/*     */     //   406: invokevirtual confirmShutdown : ()Z
/*     */     //   409: ifeq -> 413
/*     */     //   412: return
/*     */     //   413: goto -> 588
/*     */     //   416: astore_2
/*     */     //   417: aload_2
/*     */     //   418: athrow
/*     */     //   419: astore_2
/*     */     //   420: aload_2
/*     */     //   421: invokestatic handleLoopException : (Ljava/lang/Throwable;)V
/*     */     //   424: goto -> 588
/*     */     //   427: astore_2
/*     */     //   428: getstatic io/netty/channel/nio/NioEventLoop.logger : Lio/netty/util/internal/logging/InternalLogger;
/*     */     //   431: invokeinterface isDebugEnabled : ()Z
/*     */     //   436: ifeq -> 475
/*     */     //   439: getstatic io/netty/channel/nio/NioEventLoop.logger : Lio/netty/util/internal/logging/InternalLogger;
/*     */     //   442: new java/lang/StringBuilder
/*     */     //   445: dup
/*     */     //   446: invokespecial <init> : ()V
/*     */     //   449: ldc java/nio/channels/CancelledKeyException
/*     */     //   451: invokevirtual getSimpleName : ()Ljava/lang/String;
/*     */     //   454: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   457: ldc ' raised by a Selector {} - JDK bug?'
/*     */     //   459: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   462: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   465: aload_0
/*     */     //   466: getfield selector : Ljava/nio/channels/Selector;
/*     */     //   469: aload_2
/*     */     //   470: invokeinterface debug : (Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;)V
/*     */     //   475: aload_0
/*     */     //   476: invokevirtual isShuttingDown : ()Z
/*     */     //   479: ifeq -> 494
/*     */     //   482: aload_0
/*     */     //   483: invokespecial closeAll : ()V
/*     */     //   486: aload_0
/*     */     //   487: invokevirtual confirmShutdown : ()Z
/*     */     //   490: ifeq -> 494
/*     */     //   493: return
/*     */     //   494: goto -> 588
/*     */     //   497: astore_2
/*     */     //   498: aload_2
/*     */     //   499: athrow
/*     */     //   500: astore_2
/*     */     //   501: aload_2
/*     */     //   502: invokestatic handleLoopException : (Ljava/lang/Throwable;)V
/*     */     //   505: goto -> 588
/*     */     //   508: astore_2
/*     */     //   509: aload_2
/*     */     //   510: athrow
/*     */     //   511: astore_2
/*     */     //   512: aload_2
/*     */     //   513: invokestatic handleLoopException : (Ljava/lang/Throwable;)V
/*     */     //   516: aload_0
/*     */     //   517: invokevirtual isShuttingDown : ()Z
/*     */     //   520: ifeq -> 535
/*     */     //   523: aload_0
/*     */     //   524: invokespecial closeAll : ()V
/*     */     //   527: aload_0
/*     */     //   528: invokevirtual confirmShutdown : ()Z
/*     */     //   531: ifeq -> 535
/*     */     //   534: return
/*     */     //   535: goto -> 588
/*     */     //   538: astore_2
/*     */     //   539: aload_2
/*     */     //   540: athrow
/*     */     //   541: astore_2
/*     */     //   542: aload_2
/*     */     //   543: invokestatic handleLoopException : (Ljava/lang/Throwable;)V
/*     */     //   546: goto -> 588
/*     */     //   549: astore #12
/*     */     //   551: aload_0
/*     */     //   552: invokevirtual isShuttingDown : ()Z
/*     */     //   555: ifeq -> 570
/*     */     //   558: aload_0
/*     */     //   559: invokespecial closeAll : ()V
/*     */     //   562: aload_0
/*     */     //   563: invokevirtual confirmShutdown : ()Z
/*     */     //   566: ifeq -> 570
/*     */     //   569: return
/*     */     //   570: goto -> 585
/*     */     //   573: astore #13
/*     */     //   575: aload #13
/*     */     //   577: athrow
/*     */     //   578: astore #13
/*     */     //   580: aload #13
/*     */     //   582: invokestatic handleLoopException : (Ljava/lang/Throwable;)V
/*     */     //   585: aload #12
/*     */     //   587: athrow
/*     */     //   588: goto -> 2
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #505	-> 0
/*     */     //   #510	-> 2
/*     */     //   #511	-> 20
/*     */     //   #594	-> 48
/*     */     //   #595	-> 55
/*     */     //   #596	-> 59
/*     */     //   #597	-> 66
/*     */     //   #604	-> 67
/*     */     //   #600	-> 70
/*     */     //   #601	-> 71
/*     */     //   #602	-> 73
/*     */     //   #603	-> 74
/*     */     //   #604	-> 78
/*     */     //   #519	-> 81
/*     */     //   #520	-> 86
/*     */     //   #521	-> 94
/*     */     //   #523	-> 98
/*     */     //   #525	-> 106
/*     */     //   #526	-> 113
/*     */     //   #531	-> 119
/*     */     //   #532	-> 129
/*     */     //   #531	-> 132
/*     */     //   #532	-> 144
/*     */     //   #543	-> 147
/*     */     //   #536	-> 150
/*     */     //   #539	-> 151
/*     */     //   #540	-> 155
/*     */     //   #541	-> 157
/*     */     //   #594	-> 161
/*     */     //   #595	-> 168
/*     */     //   #596	-> 172
/*     */     //   #597	-> 179
/*     */     //   #604	-> 180
/*     */     //   #600	-> 183
/*     */     //   #601	-> 185
/*     */     //   #602	-> 188
/*     */     //   #603	-> 190
/*     */     //   #604	-> 195
/*     */     //   #545	-> 198
/*     */     //   #546	-> 201
/*     */     //   #547	-> 206
/*     */     //   #548	-> 211
/*     */     //   #550	-> 216
/*     */     //   #552	-> 222
/*     */     //   #553	-> 226
/*     */     //   #557	-> 230
/*     */     //   #558	-> 236
/*     */     //   #557	-> 239
/*     */     //   #558	-> 247
/*     */     //   #559	-> 253
/*     */     //   #560	-> 257
/*     */     //   #562	-> 262
/*     */     //   #565	-> 266
/*     */     //   #566	-> 274
/*     */     //   #567	-> 291
/*     */     //   #565	-> 294
/*     */     //   #566	-> 304
/*     */     //   #567	-> 321
/*     */     //   #568	-> 324
/*     */     //   #569	-> 327
/*     */     //   #572	-> 334
/*     */     //   #573	-> 343
/*     */     //   #574	-> 359
/*     */     //   #575	-> 367
/*     */     //   #574	-> 374
/*     */     //   #577	-> 379
/*     */     //   #578	-> 384
/*     */     //   #579	-> 392
/*     */     //   #594	-> 394
/*     */     //   #595	-> 401
/*     */     //   #596	-> 405
/*     */     //   #597	-> 412
/*     */     //   #604	-> 413
/*     */     //   #600	-> 416
/*     */     //   #601	-> 417
/*     */     //   #602	-> 419
/*     */     //   #603	-> 420
/*     */     //   #605	-> 424
/*     */     //   #581	-> 427
/*     */     //   #583	-> 428
/*     */     //   #584	-> 439
/*     */     //   #594	-> 475
/*     */     //   #595	-> 482
/*     */     //   #596	-> 486
/*     */     //   #597	-> 493
/*     */     //   #604	-> 494
/*     */     //   #600	-> 497
/*     */     //   #601	-> 498
/*     */     //   #602	-> 500
/*     */     //   #603	-> 501
/*     */     //   #605	-> 505
/*     */     //   #587	-> 508
/*     */     //   #588	-> 509
/*     */     //   #589	-> 511
/*     */     //   #590	-> 512
/*     */     //   #594	-> 516
/*     */     //   #595	-> 523
/*     */     //   #596	-> 527
/*     */     //   #597	-> 534
/*     */     //   #604	-> 535
/*     */     //   #600	-> 538
/*     */     //   #601	-> 539
/*     */     //   #602	-> 541
/*     */     //   #603	-> 542
/*     */     //   #605	-> 546
/*     */     //   #593	-> 549
/*     */     //   #594	-> 551
/*     */     //   #595	-> 558
/*     */     //   #596	-> 562
/*     */     //   #597	-> 569
/*     */     //   #604	-> 570
/*     */     //   #600	-> 573
/*     */     //   #601	-> 575
/*     */     //   #602	-> 578
/*     */     //   #603	-> 580
/*     */     //   #605	-> 585
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   71	2	3	e	Ljava/lang/Error;
/*     */     //   74	4	3	t	Ljava/lang/Throwable;
/*     */     //   86	61	3	curDeadlineNanos	J
/*     */     //   20	130	2	strategy	I
/*     */     //   185	3	4	e	Ljava/lang/Error;
/*     */     //   190	5	4	t	Ljava/lang/Throwable;
/*     */     //   151	47	3	e	Ljava/io/IOException;
/*     */     //   236	3	4	ranTasks	Z
/*     */     //   247	6	4	ranTasks	Z
/*     */     //   274	17	7	ioTime	J
/*     */     //   291	3	4	ranTasks	Z
/*     */     //   304	17	10	ioTime	J
/*     */     //   262	62	5	ioStartTime	J
/*     */     //   321	6	4	ranTasks	Z
/*     */     //   198	196	2	strategy	I
/*     */     //   216	178	3	ioRatio	I
/*     */     //   334	60	4	ranTasks	Z
/*     */     //   417	2	2	e	Ljava/lang/Error;
/*     */     //   420	4	2	t	Ljava/lang/Throwable;
/*     */     //   428	47	2	e	Ljava/nio/channels/CancelledKeyException;
/*     */     //   498	2	2	e	Ljava/lang/Error;
/*     */     //   501	4	2	t	Ljava/lang/Throwable;
/*     */     //   509	2	2	e	Ljava/lang/Error;
/*     */     //   512	4	2	t	Ljava/lang/Throwable;
/*     */     //   539	2	2	e	Ljava/lang/Error;
/*     */     //   542	4	2	t	Ljava/lang/Throwable;
/*     */     //   575	3	13	e	Ljava/lang/Error;
/*     */     //   580	5	13	t	Ljava/lang/Throwable;
/*     */     //   0	591	0	this	Lio/netty/channel/nio/NioEventLoop;
/*     */     //   2	589	1	selectCnt	I
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   2	48	150	java/io/IOException
/*     */     //   2	48	427	java/nio/channels/CancelledKeyException
/*     */     //   2	48	508	java/lang/Error
/*     */     //   2	48	511	java/lang/Throwable
/*     */     //   2	48	549	finally
/*     */     //   48	66	70	java/lang/Error
/*     */     //   48	66	73	java/lang/Throwable
/*     */     //   81	147	150	java/io/IOException
/*     */     //   81	161	427	java/nio/channels/CancelledKeyException
/*     */     //   81	161	508	java/lang/Error
/*     */     //   81	161	511	java/lang/Throwable
/*     */     //   81	161	549	finally
/*     */     //   106	119	132	finally
/*     */     //   132	134	132	finally
/*     */     //   161	179	183	java/lang/Error
/*     */     //   161	179	188	java/lang/Throwable
/*     */     //   198	394	427	java/nio/channels/CancelledKeyException
/*     */     //   198	394	508	java/lang/Error
/*     */     //   198	394	511	java/lang/Throwable
/*     */     //   198	394	549	finally
/*     */     //   222	230	239	finally
/*     */     //   239	241	239	finally
/*     */     //   262	266	294	finally
/*     */     //   294	296	294	finally
/*     */     //   394	412	416	java/lang/Error
/*     */     //   394	412	419	java/lang/Throwable
/*     */     //   427	475	549	finally
/*     */     //   475	493	497	java/lang/Error
/*     */     //   475	493	500	java/lang/Throwable
/*     */     //   508	516	549	finally
/*     */     //   516	534	538	java/lang/Error
/*     */     //   516	534	541	java/lang/Throwable
/*     */     //   549	551	549	finally
/*     */     //   551	569	573	java/lang/Error
/*     */     //   551	569	578	java/lang/Throwable
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean unexpectedSelectorWakeup(int selectCnt) {
/* 611 */     if (Thread.interrupted()) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 617 */       if (logger.isDebugEnabled()) {
/* 618 */         logger.debug("Selector.select() returned prematurely because Thread.currentThread().interrupt() was called. Use NioEventLoop.shutdownGracefully() to shutdown the NioEventLoop.");
/*     */       }
/*     */ 
/*     */       
/* 622 */       return true;
/*     */     } 
/* 624 */     if (SELECTOR_AUTO_REBUILD_THRESHOLD > 0 && selectCnt >= SELECTOR_AUTO_REBUILD_THRESHOLD) {
/*     */ 
/*     */ 
/*     */       
/* 628 */       logger.warn("Selector.select() returned prematurely {} times in a row; rebuilding Selector {}.", 
/* 629 */           Integer.valueOf(selectCnt), this.selector);
/* 630 */       rebuildSelector();
/* 631 */       return true;
/*     */     } 
/* 633 */     return false;
/*     */   }
/*     */   
/*     */   private static void handleLoopException(Throwable t) {
/* 637 */     logger.warn("Unexpected exception in the selector loop.", t);
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 642 */       Thread.sleep(1000L);
/* 643 */     } catch (InterruptedException interruptedException) {}
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void processSelectedKeys() {
/* 649 */     if (this.selectedKeys != null) {
/* 650 */       processSelectedKeysOptimized();
/*     */     } else {
/* 652 */       processSelectedKeysPlain(this.selector.selectedKeys());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void cleanup() {
/*     */     try {
/* 659 */       this.selector.close();
/* 660 */     } catch (IOException e) {
/* 661 */       logger.warn("Failed to close a selector.", e);
/*     */     } 
/*     */   }
/*     */   
/*     */   void cancel(SelectionKey key) {
/* 666 */     key.cancel();
/* 667 */     this.cancelledKeys++;
/* 668 */     if (this.cancelledKeys >= 256) {
/* 669 */       this.cancelledKeys = 0;
/* 670 */       this.needsToSelectAgain = true;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void processSelectedKeysPlain(Set<SelectionKey> selectedKeys) {
/* 678 */     if (selectedKeys.isEmpty()) {
/*     */       return;
/*     */     }
/*     */     
/* 682 */     Iterator<SelectionKey> i = selectedKeys.iterator();
/*     */     while (true) {
/* 684 */       SelectionKey k = i.next();
/* 685 */       Object a = k.attachment();
/* 686 */       i.remove();
/*     */       
/* 688 */       if (a instanceof AbstractNioChannel) {
/* 689 */         processSelectedKey(k, (AbstractNioChannel)a);
/*     */       } else {
/*     */         
/* 692 */         NioTask<SelectableChannel> task = (NioTask<SelectableChannel>)a;
/* 693 */         processSelectedKey(k, task);
/*     */       } 
/*     */       
/* 696 */       if (!i.hasNext()) {
/*     */         break;
/*     */       }
/*     */       
/* 700 */       if (this.needsToSelectAgain) {
/* 701 */         selectAgain();
/* 702 */         selectedKeys = this.selector.selectedKeys();
/*     */ 
/*     */         
/* 705 */         if (selectedKeys.isEmpty()) {
/*     */           break;
/*     */         }
/* 708 */         i = selectedKeys.iterator();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void processSelectedKeysOptimized() {
/* 715 */     for (int i = 0; i < this.selectedKeys.size; i++) {
/* 716 */       SelectionKey k = this.selectedKeys.keys[i];
/*     */ 
/*     */       
/* 719 */       this.selectedKeys.keys[i] = null;
/*     */       
/* 721 */       Object a = k.attachment();
/*     */       
/* 723 */       if (a instanceof AbstractNioChannel) {
/* 724 */         processSelectedKey(k, (AbstractNioChannel)a);
/*     */       } else {
/*     */         
/* 727 */         NioTask<SelectableChannel> task = (NioTask<SelectableChannel>)a;
/* 728 */         processSelectedKey(k, task);
/*     */       } 
/*     */       
/* 731 */       if (this.needsToSelectAgain) {
/*     */ 
/*     */         
/* 734 */         this.selectedKeys.reset(i + 1);
/*     */         
/* 736 */         selectAgain();
/* 737 */         i = -1;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void processSelectedKey(SelectionKey k, AbstractNioChannel ch) {
/* 743 */     AbstractNioChannel.NioUnsafe unsafe = ch.unsafe();
/* 744 */     if (!k.isValid()) {
/*     */       NioEventLoop nioEventLoop;
/*     */       try {
/* 747 */         nioEventLoop = ch.eventLoop();
/* 748 */       } catch (Throwable ignored) {
/*     */         return;
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 758 */       if (nioEventLoop == this)
/*     */       {
/* 760 */         unsafe.close(unsafe.voidPromise());
/*     */       }
/*     */       
/*     */       return;
/*     */     } 
/*     */     try {
/* 766 */       int readyOps = k.readyOps();
/*     */ 
/*     */       
/* 769 */       if ((readyOps & 0x8) != 0) {
/*     */ 
/*     */         
/* 772 */         int ops = k.interestOps();
/* 773 */         ops &= 0xFFFFFFF7;
/* 774 */         k.interestOps(ops);
/*     */         
/* 776 */         unsafe.finishConnect();
/*     */       } 
/*     */ 
/*     */       
/* 780 */       if ((readyOps & 0x4) != 0)
/*     */       {
/* 782 */         unsafe.forceFlush();
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 787 */       if ((readyOps & 0x11) != 0 || readyOps == 0) {
/* 788 */         unsafe.read();
/*     */       }
/* 790 */     } catch (CancelledKeyException ignored) {
/* 791 */       EventLoop eventLoop; unsafe.close(unsafe.voidPromise());
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void processSelectedKey(SelectionKey k, NioTask<SelectableChannel> task) {
/* 796 */     int state = 0;
/*     */     try {
/* 798 */       task.channelReady(k.channel(), k);
/* 799 */       state = 1;
/* 800 */     } catch (Exception e) {
/* 801 */       k.cancel();
/* 802 */       invokeChannelUnregistered(task, k, e);
/* 803 */       state = 2;
/*     */     } finally {
/* 805 */       switch (state) {
/*     */         case 0:
/* 807 */           k.cancel();
/* 808 */           invokeChannelUnregistered(task, k, (Throwable)null);
/*     */           break;
/*     */         case 1:
/* 811 */           if (!k.isValid()) {
/* 812 */             invokeChannelUnregistered(task, k, (Throwable)null);
/*     */           }
/*     */           break;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void closeAll() {
/* 822 */     selectAgain();
/* 823 */     Set<SelectionKey> keys = this.selector.keys();
/* 824 */     Collection<AbstractNioChannel> channels = new ArrayList<AbstractNioChannel>(keys.size());
/* 825 */     for (SelectionKey k : keys) {
/* 826 */       Object a = k.attachment();
/* 827 */       if (a instanceof AbstractNioChannel) {
/* 828 */         channels.add((AbstractNioChannel)a); continue;
/*     */       } 
/* 830 */       k.cancel();
/*     */       
/* 832 */       NioTask<SelectableChannel> task = (NioTask<SelectableChannel>)a;
/* 833 */       invokeChannelUnregistered(task, k, (Throwable)null);
/*     */     } 
/*     */ 
/*     */     
/* 837 */     for (AbstractNioChannel ch : channels) {
/* 838 */       ch.unsafe().close(ch.unsafe().voidPromise());
/*     */     }
/*     */   }
/*     */   
/*     */   private static void invokeChannelUnregistered(NioTask<SelectableChannel> task, SelectionKey k, Throwable cause) {
/*     */     try {
/* 844 */       task.channelUnregistered(k.channel(), cause);
/* 845 */     } catch (Exception e) {
/* 846 */       logger.warn("Unexpected exception while running NioTask.channelUnregistered()", e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void wakeup(boolean inEventLoop) {
/* 852 */     if (!inEventLoop && this.nextWakeupNanos.getAndSet(-1L) != -1L) {
/* 853 */       this.selector.wakeup();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean beforeScheduledTaskSubmitted(long deadlineNanos) {
/* 860 */     return (deadlineNanos < this.nextWakeupNanos.get());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean afterScheduledTaskSubmitted(long deadlineNanos) {
/* 866 */     return (deadlineNanos < this.nextWakeupNanos.get());
/*     */   }
/*     */   
/*     */   Selector unwrappedSelector() {
/* 870 */     return this.unwrappedSelector;
/*     */   }
/*     */   
/*     */   int selectNow() throws IOException {
/* 874 */     return this.selector.selectNow();
/*     */   }
/*     */   
/*     */   private int select(long deadlineNanos) throws IOException {
/* 878 */     if (deadlineNanos == Long.MAX_VALUE) {
/* 879 */       return this.selector.select();
/*     */     }
/*     */     
/* 882 */     long timeoutMillis = deadlineToDelayNanos(deadlineNanos + 995000L) / 1000000L;
/* 883 */     return (timeoutMillis <= 0L) ? this.selector.selectNow() : this.selector.select(timeoutMillis);
/*     */   }
/*     */   
/*     */   private void selectAgain() {
/* 887 */     this.needsToSelectAgain = false;
/*     */     try {
/* 889 */       this.selector.selectNow();
/* 890 */     } catch (Throwable t) {
/* 891 */       logger.warn("Failed to update SelectionKeys.", t);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-transport-4.1.93.Final.jar!\io\netty\channel\nio\NioEventLoop.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */