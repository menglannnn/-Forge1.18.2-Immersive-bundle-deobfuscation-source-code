/*     */ package io.netty.channel.nio;
/*     */ 
/*     */ import io.netty.channel.AbstractChannel;
/*     */ import io.netty.channel.Channel;
/*     */ import io.netty.channel.ChannelConfig;
/*     */ import io.netty.channel.ChannelOutboundBuffer;
/*     */ import io.netty.channel.ChannelPipeline;
/*     */ import io.netty.channel.RecvByteBufAllocator;
/*     */ import java.nio.channels.SelectableChannel;
/*     */ import java.nio.channels.SelectionKey;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractNioMessageChannel
/*     */   extends AbstractNioChannel
/*     */ {
/*     */   boolean inputShutdown;
/*     */   
/*     */   protected AbstractNioMessageChannel(Channel parent, SelectableChannel ch, int readInterestOp) {
/*  42 */     super(parent, ch, readInterestOp);
/*     */   }
/*     */ 
/*     */   
/*     */   protected AbstractNioChannel.AbstractNioUnsafe newUnsafe() {
/*  47 */     return new NioMessageUnsafe();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void doBeginRead() throws Exception {
/*  52 */     if (this.inputShutdown) {
/*     */       return;
/*     */     }
/*  55 */     super.doBeginRead();
/*     */   }
/*     */   
/*     */   protected boolean continueReading(RecvByteBufAllocator.Handle allocHandle) {
/*  59 */     return allocHandle.continueReading();
/*     */   }
/*     */   
/*     */   private final class NioMessageUnsafe extends AbstractNioChannel.AbstractNioUnsafe {
/*     */     private NioMessageUnsafe() {
/*  64 */       this.readBuf = new ArrayList();
/*     */     }
/*     */     private final List<Object> readBuf;
/*     */     public void read() {
/*  68 */       assert AbstractNioMessageChannel.this.eventLoop().inEventLoop();
/*  69 */       ChannelConfig config = AbstractNioMessageChannel.this.config();
/*  70 */       ChannelPipeline pipeline = AbstractNioMessageChannel.this.pipeline();
/*  71 */       RecvByteBufAllocator.Handle allocHandle = AbstractNioMessageChannel.this.unsafe().recvBufAllocHandle();
/*  72 */       allocHandle.reset(config);
/*     */       
/*  74 */       boolean closed = false;
/*  75 */       Throwable exception = null;
/*     */       try {
/*     */         while (true) {
/*     */           
/*  79 */           try { int localRead = AbstractNioMessageChannel.this.doReadMessages(this.readBuf);
/*  80 */             if (localRead == 0) {
/*     */               break;
/*     */             }
/*  83 */             if (localRead < 0) {
/*  84 */               closed = true;
/*     */               
/*     */               break;
/*     */             } 
/*  88 */             allocHandle.incMessagesRead(localRead);
/*  89 */             if (!AbstractNioMessageChannel.this.continueReading(allocHandle))
/*  90 */               break;  } catch (Throwable t)
/*  91 */           { exception = t; break; }
/*     */         
/*     */         } 
/*  94 */         int size = this.readBuf.size();
/*  95 */         for (int i = 0; i < size; i++) {
/*  96 */           AbstractNioMessageChannel.this.readPending = false;
/*  97 */           pipeline.fireChannelRead(this.readBuf.get(i));
/*     */         } 
/*  99 */         this.readBuf.clear();
/* 100 */         allocHandle.readComplete();
/* 101 */         pipeline.fireChannelReadComplete();
/*     */         
/* 103 */         if (exception != null) {
/* 104 */           closed = AbstractNioMessageChannel.this.closeOnReadError(exception);
/*     */           
/* 106 */           pipeline.fireExceptionCaught(exception);
/*     */         } 
/*     */         
/* 109 */         if (closed) {
/* 110 */           AbstractNioMessageChannel.this.inputShutdown = true;
/* 111 */           if (AbstractNioMessageChannel.this.isOpen()) {
/* 112 */             close(voidPromise());
/*     */           
/*     */           }
/*     */         
/*     */         }
/*     */ 
/*     */       
/*     */       }
/*     */       finally {
/*     */         
/* 122 */         if (!AbstractNioMessageChannel.this.readPending && !config.isAutoRead()) {
/* 123 */           removeReadOp();
/*     */         }
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected void doWrite(ChannelOutboundBuffer in) throws Exception {
/* 131 */     SelectionKey key = selectionKey();
/* 132 */     int interestOps = key.interestOps();
/*     */     
/* 134 */     int maxMessagesPerWrite = maxMessagesPerWrite();
/* 135 */     while (maxMessagesPerWrite > 0) {
/* 136 */       Object msg = in.current();
/* 137 */       if (msg == null) {
/*     */         break;
/*     */       }
/*     */       try {
/* 141 */         boolean done = false;
/* 142 */         for (int i = config().getWriteSpinCount() - 1; i >= 0; i--) {
/* 143 */           if (doWriteMessage(msg, in)) {
/* 144 */             done = true;
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/* 149 */         if (done) {
/* 150 */           maxMessagesPerWrite--;
/* 151 */           in.remove();
/*     */         }
/*     */       
/*     */       }
/* 155 */       catch (Exception e) {
/* 156 */         if (continueOnWriteError()) {
/* 157 */           maxMessagesPerWrite--;
/* 158 */           in.remove(e); continue;
/*     */         } 
/* 160 */         throw e;
/*     */       } 
/*     */     } 
/*     */     
/* 164 */     if (in.isEmpty()) {
/*     */       
/* 166 */       if ((interestOps & 0x4) != 0) {
/* 167 */         key.interestOps(interestOps & 0xFFFFFFFB);
/*     */       
/*     */       }
/*     */     }
/* 171 */     else if ((interestOps & 0x4) == 0) {
/* 172 */       key.interestOps(interestOps | 0x4);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean continueOnWriteError() {
/* 181 */     return false;
/*     */   }
/*     */   
/*     */   protected boolean closeOnReadError(Throwable cause) {
/* 185 */     if (!isActive())
/*     */     {
/* 187 */       return true;
/*     */     }
/* 189 */     if (cause instanceof java.net.PortUnreachableException) {
/* 190 */       return false;
/*     */     }
/* 192 */     if (cause instanceof java.io.IOException)
/*     */     {
/*     */       
/* 195 */       return !(this instanceof io.netty.channel.ServerChannel);
/*     */     }
/* 197 */     return true;
/*     */   }
/*     */   
/*     */   protected abstract int doReadMessages(List<Object> paramList) throws Exception;
/*     */   
/*     */   protected abstract boolean doWriteMessage(Object paramObject, ChannelOutboundBuffer paramChannelOutboundBuffer) throws Exception;
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-transport-4.1.93.Final.jar!\io\netty\channel\nio\AbstractNioMessageChannel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */