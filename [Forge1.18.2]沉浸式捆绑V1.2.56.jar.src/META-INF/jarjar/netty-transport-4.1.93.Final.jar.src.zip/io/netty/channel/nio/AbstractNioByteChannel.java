/*     */ package io.netty.channel.nio;
/*     */ 
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import io.netty.buffer.ByteBufAllocator;
/*     */ import io.netty.channel.AbstractChannel;
/*     */ import io.netty.channel.Channel;
/*     */ import io.netty.channel.ChannelConfig;
/*     */ import io.netty.channel.ChannelFuture;
/*     */ import io.netty.channel.ChannelMetadata;
/*     */ import io.netty.channel.ChannelOutboundBuffer;
/*     */ import io.netty.channel.ChannelPipeline;
/*     */ import io.netty.channel.FileRegion;
/*     */ import io.netty.channel.RecvByteBufAllocator;
/*     */ import io.netty.channel.socket.ChannelInputShutdownEvent;
/*     */ import io.netty.channel.socket.ChannelInputShutdownReadComplete;
/*     */ import io.netty.channel.socket.SocketChannelConfig;
/*     */ import io.netty.util.internal.StringUtil;
/*     */ import java.nio.channels.SelectableChannel;
/*     */ import java.nio.channels.SelectionKey;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractNioByteChannel
/*     */   extends AbstractNioChannel
/*     */ {
/*  44 */   private static final ChannelMetadata METADATA = new ChannelMetadata(false, 16);
/*  45 */   private static final String EXPECTED_TYPES = " (expected: " + 
/*  46 */     StringUtil.simpleClassName(ByteBuf.class) + ", " + 
/*  47 */     StringUtil.simpleClassName(FileRegion.class) + ')';
/*     */   
/*  49 */   private final Runnable flushTask = new Runnable()
/*     */     {
/*     */       
/*     */       public void run()
/*     */       {
/*  54 */         ((AbstractNioChannel.AbstractNioUnsafe)AbstractNioByteChannel.this.unsafe()).flush0();
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean inputClosedSeenErrorOnRead;
/*     */ 
/*     */ 
/*     */   
/*     */   protected AbstractNioByteChannel(Channel parent, SelectableChannel ch) {
/*  66 */     super(parent, ch, 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isInputShutdown0() {
/*  75 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   protected AbstractNioChannel.AbstractNioUnsafe newUnsafe() {
/*  80 */     return new NioByteUnsafe();
/*     */   }
/*     */ 
/*     */   
/*     */   public ChannelMetadata metadata() {
/*  85 */     return METADATA;
/*     */   }
/*     */   
/*     */   final boolean shouldBreakReadReady(ChannelConfig config) {
/*  89 */     return (isInputShutdown0() && (this.inputClosedSeenErrorOnRead || !isAllowHalfClosure(config)));
/*     */   }
/*     */   
/*     */   private static boolean isAllowHalfClosure(ChannelConfig config) {
/*  93 */     return (config instanceof SocketChannelConfig && ((SocketChannelConfig)config)
/*  94 */       .isAllowHalfClosure());
/*     */   }
/*     */   
/*     */   protected class NioByteUnsafe
/*     */     extends AbstractNioChannel.AbstractNioUnsafe {
/*     */     private void closeOnRead(ChannelPipeline pipeline) {
/* 100 */       if (!AbstractNioByteChannel.this.isInputShutdown0()) {
/* 101 */         if (AbstractNioByteChannel.isAllowHalfClosure(AbstractNioByteChannel.this.config())) {
/* 102 */           AbstractNioByteChannel.this.shutdownInput();
/* 103 */           pipeline.fireUserEventTriggered(ChannelInputShutdownEvent.INSTANCE);
/*     */         } else {
/* 105 */           close(voidPromise());
/*     */         } 
/* 107 */       } else if (!AbstractNioByteChannel.this.inputClosedSeenErrorOnRead) {
/* 108 */         AbstractNioByteChannel.this.inputClosedSeenErrorOnRead = true;
/* 109 */         pipeline.fireUserEventTriggered(ChannelInputShutdownReadComplete.INSTANCE);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     private void handleReadException(ChannelPipeline pipeline, ByteBuf byteBuf, Throwable cause, boolean close, RecvByteBufAllocator.Handle allocHandle) {
/* 115 */       if (byteBuf != null) {
/* 116 */         if (byteBuf.isReadable()) {
/* 117 */           AbstractNioByteChannel.this.readPending = false;
/* 118 */           pipeline.fireChannelRead(byteBuf);
/*     */         } else {
/* 120 */           byteBuf.release();
/*     */         } 
/*     */       }
/* 123 */       allocHandle.readComplete();
/* 124 */       pipeline.fireChannelReadComplete();
/* 125 */       pipeline.fireExceptionCaught(cause);
/*     */ 
/*     */ 
/*     */       
/* 129 */       if (close || cause instanceof OutOfMemoryError || cause instanceof java.io.IOException) {
/* 130 */         closeOnRead(pipeline);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public final void read() {
/* 136 */       ChannelConfig config = AbstractNioByteChannel.this.config();
/* 137 */       if (AbstractNioByteChannel.this.shouldBreakReadReady(config)) {
/* 138 */         AbstractNioByteChannel.this.clearReadPending();
/*     */         return;
/*     */       } 
/* 141 */       ChannelPipeline pipeline = AbstractNioByteChannel.this.pipeline();
/* 142 */       ByteBufAllocator allocator = config.getAllocator();
/* 143 */       RecvByteBufAllocator.Handle allocHandle = recvBufAllocHandle();
/* 144 */       allocHandle.reset(config);
/*     */       
/* 146 */       ByteBuf byteBuf = null;
/* 147 */       boolean close = false;
/*     */       try {
/*     */         do {
/* 150 */           byteBuf = allocHandle.allocate(allocator);
/* 151 */           allocHandle.lastBytesRead(AbstractNioByteChannel.this.doReadBytes(byteBuf));
/* 152 */           if (allocHandle.lastBytesRead() <= 0) {
/*     */             
/* 154 */             byteBuf.release();
/* 155 */             byteBuf = null;
/* 156 */             close = (allocHandle.lastBytesRead() < 0);
/* 157 */             if (close)
/*     */             {
/* 159 */               AbstractNioByteChannel.this.readPending = false;
/*     */             }
/*     */             
/*     */             break;
/*     */           } 
/* 164 */           allocHandle.incMessagesRead(1);
/* 165 */           AbstractNioByteChannel.this.readPending = false;
/* 166 */           pipeline.fireChannelRead(byteBuf);
/* 167 */           byteBuf = null;
/* 168 */         } while (allocHandle.continueReading());
/*     */         
/* 170 */         allocHandle.readComplete();
/* 171 */         pipeline.fireChannelReadComplete();
/*     */         
/* 173 */         if (close) {
/* 174 */           closeOnRead(pipeline);
/*     */         }
/* 176 */       } catch (Throwable t) {
/* 177 */         handleReadException(pipeline, byteBuf, t, close, allocHandle);
/*     */ 
/*     */       
/*     */       }
/*     */       finally {
/*     */ 
/*     */ 
/*     */         
/* 185 */         if (!AbstractNioByteChannel.this.readPending && !config.isAutoRead()) {
/* 186 */           removeReadOp();
/*     */         }
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final int doWrite0(ChannelOutboundBuffer in) throws Exception {
/* 207 */     Object msg = in.current();
/* 208 */     if (msg == null)
/*     */     {
/* 210 */       return 0;
/*     */     }
/* 212 */     return doWriteInternal(in, in.current());
/*     */   }
/*     */   
/*     */   private int doWriteInternal(ChannelOutboundBuffer in, Object msg) throws Exception {
/* 216 */     if (msg instanceof ByteBuf) {
/* 217 */       ByteBuf buf = (ByteBuf)msg;
/* 218 */       if (!buf.isReadable()) {
/* 219 */         in.remove();
/* 220 */         return 0;
/*     */       } 
/*     */       
/* 223 */       int localFlushedAmount = doWriteBytes(buf);
/* 224 */       if (localFlushedAmount > 0) {
/* 225 */         in.progress(localFlushedAmount);
/* 226 */         if (!buf.isReadable()) {
/* 227 */           in.remove();
/*     */         }
/* 229 */         return 1;
/*     */       } 
/* 231 */     } else if (msg instanceof FileRegion) {
/* 232 */       FileRegion region = (FileRegion)msg;
/* 233 */       if (region.transferred() >= region.count()) {
/* 234 */         in.remove();
/* 235 */         return 0;
/*     */       } 
/*     */       
/* 238 */       long localFlushedAmount = doWriteFileRegion(region);
/* 239 */       if (localFlushedAmount > 0L) {
/* 240 */         in.progress(localFlushedAmount);
/* 241 */         if (region.transferred() >= region.count()) {
/* 242 */           in.remove();
/*     */         }
/* 244 */         return 1;
/*     */       } 
/*     */     } else {
/*     */       
/* 248 */       throw new Error();
/*     */     } 
/* 250 */     return Integer.MAX_VALUE;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void doWrite(ChannelOutboundBuffer in) throws Exception {
/* 255 */     int writeSpinCount = config().getWriteSpinCount();
/*     */     do {
/* 257 */       Object msg = in.current();
/* 258 */       if (msg == null) {
/*     */         
/* 260 */         clearOpWrite();
/*     */         
/*     */         return;
/*     */       } 
/* 264 */       writeSpinCount -= doWriteInternal(in, msg);
/* 265 */     } while (writeSpinCount > 0);
/*     */     
/* 267 */     incompleteWrite((writeSpinCount < 0));
/*     */   }
/*     */ 
/*     */   
/*     */   protected final Object filterOutboundMessage(Object msg) {
/* 272 */     if (msg instanceof ByteBuf) {
/* 273 */       ByteBuf buf = (ByteBuf)msg;
/* 274 */       if (buf.isDirect()) {
/* 275 */         return msg;
/*     */       }
/*     */       
/* 278 */       return newDirectBuffer(buf);
/*     */     } 
/*     */     
/* 281 */     if (msg instanceof FileRegion) {
/* 282 */       return msg;
/*     */     }
/*     */     
/* 285 */     throw new UnsupportedOperationException("unsupported message type: " + 
/* 286 */         StringUtil.simpleClassName(msg) + EXPECTED_TYPES);
/*     */   }
/*     */ 
/*     */   
/*     */   protected final void incompleteWrite(boolean setOpWrite) {
/* 291 */     if (setOpWrite) {
/* 292 */       setOpWrite();
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/* 298 */       clearOpWrite();
/*     */ 
/*     */       
/* 301 */       eventLoop().execute(this.flushTask);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void setOpWrite() {
/* 326 */     SelectionKey key = selectionKey();
/*     */ 
/*     */ 
/*     */     
/* 330 */     if (!key.isValid()) {
/*     */       return;
/*     */     }
/* 333 */     int interestOps = key.interestOps();
/* 334 */     if ((interestOps & 0x4) == 0) {
/* 335 */       key.interestOps(interestOps | 0x4);
/*     */     }
/*     */   }
/*     */   
/*     */   protected final void clearOpWrite() {
/* 340 */     SelectionKey key = selectionKey();
/*     */ 
/*     */ 
/*     */     
/* 344 */     if (!key.isValid()) {
/*     */       return;
/*     */     }
/* 347 */     int interestOps = key.interestOps();
/* 348 */     if ((interestOps & 0x4) != 0)
/* 349 */       key.interestOps(interestOps & 0xFFFFFFFB); 
/*     */   }
/*     */   
/*     */   protected abstract ChannelFuture shutdownInput();
/*     */   
/*     */   protected abstract long doWriteFileRegion(FileRegion paramFileRegion) throws Exception;
/*     */   
/*     */   protected abstract int doReadBytes(ByteBuf paramByteBuf) throws Exception;
/*     */   
/*     */   protected abstract int doWriteBytes(ByteBuf paramByteBuf) throws Exception;
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-transport-4.1.93.Final.jar!\io\netty\channel\nio\AbstractNioByteChannel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */