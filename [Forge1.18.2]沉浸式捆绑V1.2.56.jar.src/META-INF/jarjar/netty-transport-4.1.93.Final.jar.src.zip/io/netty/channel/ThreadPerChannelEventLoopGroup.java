/*     */ package io.netty.channel;
/*     */ 
/*     */ import io.netty.util.concurrent.AbstractEventExecutorGroup;
/*     */ import io.netty.util.concurrent.DefaultPromise;
/*     */ import io.netty.util.concurrent.DefaultThreadFactory;
/*     */ import io.netty.util.concurrent.EventExecutor;
/*     */ import io.netty.util.concurrent.Future;
/*     */ import io.netty.util.concurrent.FutureListener;
/*     */ import io.netty.util.concurrent.GenericFutureListener;
/*     */ import io.netty.util.concurrent.GlobalEventExecutor;
/*     */ import io.netty.util.concurrent.Promise;
/*     */ import io.netty.util.concurrent.ThreadPerTaskExecutor;
/*     */ import io.netty.util.internal.EmptyArrays;
/*     */ import io.netty.util.internal.ObjectUtil;
/*     */ import io.netty.util.internal.PlatformDependent;
/*     */ import io.netty.util.internal.ReadOnlyIterator;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.Queue;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentLinkedQueue;
/*     */ import java.util.concurrent.Executor;
/*     */ import java.util.concurrent.RejectedExecutionException;
/*     */ import java.util.concurrent.ThreadFactory;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class ThreadPerChannelEventLoopGroup
/*     */   extends AbstractEventExecutorGroup
/*     */   implements EventLoopGroup
/*     */ {
/*     */   private final Object[] childArgs;
/*     */   private final int maxChannels;
/*     */   final Executor executor;
/*     */   final Set<EventLoop> activeChildren;
/*     */   final Queue<EventLoop> idleChildren;
/*     */   private final ChannelException tooManyChannels;
/*     */   private volatile boolean shuttingDown;
/*     */   private final Promise<?> terminationFuture;
/*     */   private final FutureListener<Object> childTerminationListener;
/*     */   
/*     */   protected ThreadPerChannelEventLoopGroup() {
/*  75 */     this(0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ThreadPerChannelEventLoopGroup(int maxChannels) {
/*  88 */     this(maxChannels, (ThreadFactory)null, new Object[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ThreadPerChannelEventLoopGroup(int maxChannels, ThreadFactory threadFactory, Object... args) {
/* 104 */     this(maxChannels, (threadFactory == null) ? null : (Executor)new ThreadPerTaskExecutor(threadFactory), args);
/*     */   }
/*     */   
/*     */   protected ThreadPerChannelEventLoopGroup(int maxChannels, Executor executor, Object... args) {
/*     */     ThreadPerTaskExecutor threadPerTaskExecutor;
/*     */     this.activeChildren = Collections.newSetFromMap(PlatformDependent.newConcurrentHashMap());
/*     */     this.idleChildren = new ConcurrentLinkedQueue<EventLoop>();
/*     */     this.terminationFuture = (Promise<?>)new DefaultPromise((EventExecutor)GlobalEventExecutor.INSTANCE);
/*     */     this.childTerminationListener = new FutureListener<Object>()
/*     */       {
/*     */         public void operationComplete(Future<Object> future) throws Exception {
/*     */           if (ThreadPerChannelEventLoopGroup.this.isTerminated()) {
/*     */             ThreadPerChannelEventLoopGroup.this.terminationFuture.trySuccess(null);
/*     */           }
/*     */         }
/*     */       };
/* 120 */     ObjectUtil.checkPositiveOrZero(maxChannels, "maxChannels");
/* 121 */     if (executor == null) {
/* 122 */       threadPerTaskExecutor = new ThreadPerTaskExecutor((ThreadFactory)new DefaultThreadFactory(getClass()));
/*     */     }
/*     */     
/* 125 */     if (args == null) {
/* 126 */       this.childArgs = EmptyArrays.EMPTY_OBJECTS;
/*     */     } else {
/* 128 */       this.childArgs = (Object[])args.clone();
/*     */     } 
/*     */     
/* 131 */     this.maxChannels = maxChannels;
/* 132 */     this.executor = (Executor)threadPerTaskExecutor;
/*     */     
/* 134 */     this
/* 135 */       .tooManyChannels = ChannelException.newStatic("too many channels (max: " + maxChannels + ')', ThreadPerChannelEventLoopGroup.class, "nextChild()");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected EventLoop newChild(Object... args) throws Exception {
/* 143 */     return new ThreadPerChannelEventLoop(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterator<EventExecutor> iterator() {
/* 148 */     return (Iterator<EventExecutor>)new ReadOnlyIterator(this.activeChildren.iterator());
/*     */   }
/*     */ 
/*     */   
/*     */   public EventLoop next() {
/* 153 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public Future<?> shutdownGracefully(long quietPeriod, long timeout, TimeUnit unit) {
/* 158 */     this.shuttingDown = true;
/*     */     
/* 160 */     for (EventLoop l : this.activeChildren) {
/* 161 */       l.shutdownGracefully(quietPeriod, timeout, unit);
/*     */     }
/* 163 */     for (EventLoop l : this.idleChildren) {
/* 164 */       l.shutdownGracefully(quietPeriod, timeout, unit);
/*     */     }
/*     */ 
/*     */     
/* 168 */     if (isTerminated()) {
/* 169 */       this.terminationFuture.trySuccess(null);
/*     */     }
/*     */     
/* 172 */     return terminationFuture();
/*     */   }
/*     */ 
/*     */   
/*     */   public Future<?> terminationFuture() {
/* 177 */     return (Future<?>)this.terminationFuture;
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void shutdown() {
/* 183 */     this.shuttingDown = true;
/*     */     
/* 185 */     for (EventLoop l : this.activeChildren) {
/* 186 */       l.shutdown();
/*     */     }
/* 188 */     for (EventLoop l : this.idleChildren) {
/* 189 */       l.shutdown();
/*     */     }
/*     */ 
/*     */     
/* 193 */     if (isTerminated()) {
/* 194 */       this.terminationFuture.trySuccess(null);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isShuttingDown() {
/* 200 */     for (EventLoop l : this.activeChildren) {
/* 201 */       if (!l.isShuttingDown()) {
/* 202 */         return false;
/*     */       }
/*     */     } 
/* 205 */     for (EventLoop l : this.idleChildren) {
/* 206 */       if (!l.isShuttingDown()) {
/* 207 */         return false;
/*     */       }
/*     */     } 
/* 210 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isShutdown() {
/* 215 */     for (EventLoop l : this.activeChildren) {
/* 216 */       if (!l.isShutdown()) {
/* 217 */         return false;
/*     */       }
/*     */     } 
/* 220 */     for (EventLoop l : this.idleChildren) {
/* 221 */       if (!l.isShutdown()) {
/* 222 */         return false;
/*     */       }
/*     */     } 
/* 225 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isTerminated() {
/* 230 */     for (EventLoop l : this.activeChildren) {
/* 231 */       if (!l.isTerminated()) {
/* 232 */         return false;
/*     */       }
/*     */     } 
/* 235 */     for (EventLoop l : this.idleChildren) {
/* 236 */       if (!l.isTerminated()) {
/* 237 */         return false;
/*     */       }
/*     */     } 
/* 240 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean awaitTermination(long timeout, TimeUnit unit) throws InterruptedException {
/* 246 */     long deadline = System.nanoTime() + unit.toNanos(timeout);
/* 247 */     label26: for (EventLoop l : this.activeChildren) {
/*     */       while (true) {
/* 249 */         long timeLeft = deadline - System.nanoTime();
/* 250 */         if (timeLeft <= 0L) {
/* 251 */           return isTerminated();
/*     */         }
/* 253 */         if (l.awaitTermination(timeLeft, TimeUnit.NANOSECONDS)) {
/*     */           continue label26;
/*     */         }
/*     */       } 
/*     */     } 
/* 258 */     label27: for (EventLoop l : this.idleChildren) {
/*     */       while (true) {
/* 260 */         long timeLeft = deadline - System.nanoTime();
/* 261 */         if (timeLeft <= 0L) {
/* 262 */           return isTerminated();
/*     */         }
/* 264 */         if (l.awaitTermination(timeLeft, TimeUnit.NANOSECONDS)) {
/*     */           continue label27;
/*     */         }
/*     */       } 
/*     */     } 
/* 269 */     return isTerminated();
/*     */   }
/*     */ 
/*     */   
/*     */   public ChannelFuture register(Channel channel) {
/* 274 */     ObjectUtil.checkNotNull(channel, "channel");
/*     */     try {
/* 276 */       EventLoop l = nextChild();
/* 277 */       return l.register(new DefaultChannelPromise(channel, (EventExecutor)l));
/* 278 */     } catch (Throwable t) {
/* 279 */       return new FailedChannelFuture(channel, (EventExecutor)GlobalEventExecutor.INSTANCE, t);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public ChannelFuture register(ChannelPromise promise) {
/*     */     try {
/* 286 */       return nextChild().register(promise);
/* 287 */     } catch (Throwable t) {
/* 288 */       promise.setFailure(t);
/* 289 */       return promise;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public ChannelFuture register(Channel channel, ChannelPromise promise) {
/* 296 */     ObjectUtil.checkNotNull(channel, "channel");
/*     */     try {
/* 298 */       return nextChild().register(channel, promise);
/* 299 */     } catch (Throwable t) {
/* 300 */       promise.setFailure(t);
/* 301 */       return promise;
/*     */     } 
/*     */   }
/*     */   
/*     */   private EventLoop nextChild() throws Exception {
/* 306 */     if (this.shuttingDown) {
/* 307 */       throw new RejectedExecutionException("shutting down");
/*     */     }
/*     */     
/* 310 */     EventLoop loop = this.idleChildren.poll();
/* 311 */     if (loop == null) {
/* 312 */       if (this.maxChannels > 0 && this.activeChildren.size() >= this.maxChannels) {
/* 313 */         throw this.tooManyChannels;
/*     */       }
/* 315 */       loop = newChild(this.childArgs);
/* 316 */       loop.terminationFuture().addListener((GenericFutureListener)this.childTerminationListener);
/*     */     } 
/* 318 */     this.activeChildren.add(loop);
/* 319 */     return loop;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-transport-4.1.93.Final.jar!\io\netty\channel\ThreadPerChannelEventLoopGroup.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */