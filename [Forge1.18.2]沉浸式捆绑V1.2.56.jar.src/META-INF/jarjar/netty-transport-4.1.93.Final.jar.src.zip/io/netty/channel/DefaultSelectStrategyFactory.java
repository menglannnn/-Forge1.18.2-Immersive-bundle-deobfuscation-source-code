/*    */ package io.netty.channel;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class DefaultSelectStrategyFactory
/*    */   implements SelectStrategyFactory
/*    */ {
/* 22 */   public static final SelectStrategyFactory INSTANCE = new DefaultSelectStrategyFactory();
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public SelectStrategy newSelectStrategy() {
/* 28 */     return DefaultSelectStrategy.INSTANCE;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-transport-4.1.93.Final.jar!\io\netty\channel\DefaultSelectStrategyFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */