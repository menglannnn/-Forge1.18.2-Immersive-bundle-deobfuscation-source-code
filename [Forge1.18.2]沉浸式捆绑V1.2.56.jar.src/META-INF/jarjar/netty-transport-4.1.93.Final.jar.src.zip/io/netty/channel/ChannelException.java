/*    */ package io.netty.channel;
/*    */ 
/*    */ import io.netty.util.internal.PlatformDependent;
/*    */ import io.netty.util.internal.SuppressJava6Requirement;
/*    */ import io.netty.util.internal.ThrowableUtil;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ChannelException
/*    */   extends RuntimeException
/*    */ {
/*    */   private static final long serialVersionUID = 2908618315971075004L;
/*    */   
/*    */   public ChannelException() {}
/*    */   
/*    */   public ChannelException(String message, Throwable cause) {
/* 40 */     super(message, cause);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ChannelException(String message) {
/* 47 */     super(message);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ChannelException(Throwable cause) {
/* 54 */     super(cause);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   @SuppressJava6Requirement(reason = "uses Java 7+ RuntimeException.<init>(String, Throwable, boolean, boolean) but is guarded by version checks")
/*    */   protected ChannelException(String message, Throwable cause, boolean shared) {
/* 61 */     super(message, cause, false, true);
/* 62 */     assert shared;
/*    */   }
/*    */   
/*    */   static ChannelException newStatic(String message, Class<?> clazz, String method) {
/*    */     ChannelException exception;
/* 67 */     if (PlatformDependent.javaVersion() >= 7) {
/* 68 */       exception = new StacklessChannelException(message, null, true);
/*    */     } else {
/* 70 */       exception = new StacklessChannelException(message, null);
/*    */     } 
/* 72 */     return (ChannelException)ThrowableUtil.unknownStackTrace(exception, clazz, method);
/*    */   }
/*    */   
/*    */   private static final class StacklessChannelException extends ChannelException {
/*    */     private static final long serialVersionUID = -6384642137753538579L;
/*    */     
/*    */     StacklessChannelException(String message, Throwable cause) {
/* 79 */       super(message, cause);
/*    */     }
/*    */     
/*    */     StacklessChannelException(String message, Throwable cause, boolean shared) {
/* 83 */       super(message, cause, shared);
/*    */     }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/*    */     public Throwable fillInStackTrace() {
/* 91 */       return this;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-transport-4.1.93.Final.jar!\io\netty\channel\ChannelException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */