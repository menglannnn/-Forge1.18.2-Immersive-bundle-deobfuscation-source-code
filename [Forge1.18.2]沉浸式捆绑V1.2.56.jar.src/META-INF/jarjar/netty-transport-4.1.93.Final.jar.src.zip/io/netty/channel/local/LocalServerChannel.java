/*     */ package io.netty.channel.local;
/*     */ 
/*     */ import io.netty.buffer.ByteBufAllocator;
/*     */ import io.netty.channel.AbstractServerChannel;
/*     */ import io.netty.channel.Channel;
/*     */ import io.netty.channel.ChannelConfig;
/*     */ import io.netty.channel.ChannelPipeline;
/*     */ import io.netty.channel.DefaultChannelConfig;
/*     */ import io.netty.channel.EventLoop;
/*     */ import io.netty.channel.PreferHeapByteBufAllocator;
/*     */ import io.netty.channel.RecvByteBufAllocator;
/*     */ import io.netty.channel.ServerChannelRecvByteBufAllocator;
/*     */ import io.netty.util.concurrent.SingleThreadEventExecutor;
/*     */ import java.net.SocketAddress;
/*     */ import java.util.ArrayDeque;
/*     */ import java.util.Queue;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LocalServerChannel
/*     */   extends AbstractServerChannel
/*     */ {
/*  39 */   private final ChannelConfig config = (ChannelConfig)new DefaultChannelConfig((Channel)this, (RecvByteBufAllocator)new ServerChannelRecvByteBufAllocator()) {  }
/*     */   ;
/*  41 */   private final Queue<Object> inboundBuffer = new ArrayDeque();
/*  42 */   private final Runnable shutdownHook = new Runnable()
/*     */     {
/*     */       public void run() {
/*  45 */         LocalServerChannel.this.unsafe().close(LocalServerChannel.this.unsafe().voidPromise());
/*     */       }
/*     */     };
/*     */   
/*     */   private volatile int state;
/*     */   private volatile LocalAddress localAddress;
/*     */   private volatile boolean acceptInProgress;
/*     */   
/*     */   public LocalServerChannel() {
/*  54 */     config().setAllocator((ByteBufAllocator)new PreferHeapByteBufAllocator(this.config.getAllocator()));
/*     */   }
/*     */ 
/*     */   
/*     */   public ChannelConfig config() {
/*  59 */     return this.config;
/*     */   }
/*     */ 
/*     */   
/*     */   public LocalAddress localAddress() {
/*  64 */     return (LocalAddress)super.localAddress();
/*     */   }
/*     */ 
/*     */   
/*     */   public LocalAddress remoteAddress() {
/*  69 */     return (LocalAddress)super.remoteAddress();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isOpen() {
/*  74 */     return (this.state < 2);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isActive() {
/*  79 */     return (this.state == 1);
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isCompatible(EventLoop loop) {
/*  84 */     return loop instanceof io.netty.channel.SingleThreadEventLoop;
/*     */   }
/*     */ 
/*     */   
/*     */   protected SocketAddress localAddress0() {
/*  89 */     return this.localAddress;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void doRegister() throws Exception {
/*  94 */     ((SingleThreadEventExecutor)eventLoop()).addShutdownHook(this.shutdownHook);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void doBind(SocketAddress localAddress) throws Exception {
/*  99 */     this.localAddress = LocalChannelRegistry.register((Channel)this, this.localAddress, localAddress);
/* 100 */     this.state = 1;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void doClose() throws Exception {
/* 105 */     if (this.state <= 1) {
/*     */       
/* 107 */       if (this.localAddress != null) {
/* 108 */         LocalChannelRegistry.unregister(this.localAddress);
/* 109 */         this.localAddress = null;
/*     */       } 
/* 111 */       this.state = 2;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void doDeregister() throws Exception {
/* 117 */     ((SingleThreadEventExecutor)eventLoop()).removeShutdownHook(this.shutdownHook);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void doBeginRead() throws Exception {
/* 122 */     if (this.acceptInProgress) {
/*     */       return;
/*     */     }
/*     */     
/* 126 */     Queue<Object> inboundBuffer = this.inboundBuffer;
/* 127 */     if (inboundBuffer.isEmpty()) {
/* 128 */       this.acceptInProgress = true;
/*     */       
/*     */       return;
/*     */     } 
/* 132 */     readInbound();
/*     */   }
/*     */   
/*     */   LocalChannel serve(LocalChannel peer) {
/* 136 */     final LocalChannel child = newLocalChannel(peer);
/* 137 */     if (eventLoop().inEventLoop()) {
/* 138 */       serve0(child);
/*     */     } else {
/* 140 */       eventLoop().execute(new Runnable()
/*     */           {
/*     */             public void run() {
/* 143 */               LocalServerChannel.this.serve0(child);
/*     */             }
/*     */           });
/*     */     } 
/* 147 */     return child;
/*     */   }
/*     */   
/*     */   private void readInbound() {
/* 151 */     RecvByteBufAllocator.Handle handle = unsafe().recvBufAllocHandle();
/* 152 */     handle.reset(config());
/* 153 */     ChannelPipeline pipeline = pipeline();
/*     */     do {
/* 155 */       Object m = this.inboundBuffer.poll();
/* 156 */       if (m == null) {
/*     */         break;
/*     */       }
/* 159 */       pipeline.fireChannelRead(m);
/* 160 */     } while (handle.continueReading());
/* 161 */     handle.readComplete();
/* 162 */     pipeline.fireChannelReadComplete();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected LocalChannel newLocalChannel(LocalChannel peer) {
/* 170 */     return new LocalChannel(this, peer);
/*     */   }
/*     */   
/*     */   private void serve0(LocalChannel child) {
/* 174 */     this.inboundBuffer.add(child);
/* 175 */     if (this.acceptInProgress) {
/* 176 */       this.acceptInProgress = false;
/*     */       
/* 178 */       readInbound();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-transport-4.1.93.Final.jar!\io\netty\channel\local\LocalServerChannel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */