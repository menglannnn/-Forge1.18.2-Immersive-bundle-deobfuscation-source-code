/*     */ package io.netty.channel;
/*     */ 
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import io.netty.buffer.ByteBufHolder;
/*     */ import io.netty.buffer.Unpooled;
/*     */ import io.netty.util.Recycler;
/*     */ import io.netty.util.ReferenceCountUtil;
/*     */ import io.netty.util.concurrent.FastThreadLocal;
/*     */ import io.netty.util.internal.InternalThreadLocalMap;
/*     */ import io.netty.util.internal.ObjectPool;
/*     */ import io.netty.util.internal.ObjectUtil;
/*     */ import io.netty.util.internal.PromiseNotificationUtil;
/*     */ import io.netty.util.internal.SystemPropertyUtil;
/*     */ import io.netty.util.internal.logging.InternalLogger;
/*     */ import io.netty.util.internal.logging.InternalLoggerFactory;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.channels.ClosedChannelException;
/*     */ import java.util.Arrays;
/*     */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*     */ import java.util.concurrent.atomic.AtomicLongFieldUpdater;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ChannelOutboundBuffer
/*     */ {
/*  65 */   static final int CHANNEL_OUTBOUND_BUFFER_ENTRY_OVERHEAD = SystemPropertyUtil.getInt("io.netty.transport.outboundBufferEntrySizeOverhead", 96);
/*     */   
/*  67 */   private static final InternalLogger logger = InternalLoggerFactory.getInstance(ChannelOutboundBuffer.class);
/*     */   
/*  69 */   private static final FastThreadLocal<ByteBuffer[]> NIO_BUFFERS = new FastThreadLocal<ByteBuffer[]>()
/*     */     {
/*     */       protected ByteBuffer[] initialValue() throws Exception {
/*  72 */         return new ByteBuffer[1024];
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */   
/*     */   private final Channel channel;
/*     */ 
/*     */   
/*     */   private Entry flushedEntry;
/*     */   
/*     */   private Entry unflushedEntry;
/*     */   
/*     */   private Entry tailEntry;
/*     */   
/*     */   private int flushed;
/*     */   
/*     */   private int nioBufferCount;
/*     */   
/*     */   private long nioBufferSize;
/*     */   
/*     */   private boolean inFail;
/*     */   
/*  95 */   private static final AtomicLongFieldUpdater<ChannelOutboundBuffer> TOTAL_PENDING_SIZE_UPDATER = AtomicLongFieldUpdater.newUpdater(ChannelOutboundBuffer.class, "totalPendingSize");
/*     */ 
/*     */   
/*     */   private volatile long totalPendingSize;
/*     */ 
/*     */   
/* 101 */   private static final AtomicIntegerFieldUpdater<ChannelOutboundBuffer> UNWRITABLE_UPDATER = AtomicIntegerFieldUpdater.newUpdater(ChannelOutboundBuffer.class, "unwritable");
/*     */   
/*     */   private volatile int unwritable;
/*     */   
/*     */   private volatile Runnable fireChannelWritabilityChangedTask;
/*     */ 
/*     */   
/*     */   ChannelOutboundBuffer(AbstractChannel channel) {
/* 109 */     this.channel = channel;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addMessage(Object msg, int size, ChannelPromise promise) {
/* 117 */     Entry entry = Entry.newInstance(msg, size, total(msg), promise);
/* 118 */     if (this.tailEntry == null) {
/* 119 */       this.flushedEntry = null;
/*     */     } else {
/* 121 */       Entry tail = this.tailEntry;
/* 122 */       tail.next = entry;
/*     */     } 
/* 124 */     this.tailEntry = entry;
/* 125 */     if (this.unflushedEntry == null) {
/* 126 */       this.unflushedEntry = entry;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 131 */     incrementPendingOutboundBytes(entry.pendingSize, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addFlush() {
/* 143 */     Entry entry = this.unflushedEntry;
/* 144 */     if (entry != null) {
/* 145 */       if (this.flushedEntry == null)
/*     */       {
/* 147 */         this.flushedEntry = entry;
/*     */       }
/*     */       do {
/* 150 */         this.flushed++;
/* 151 */         if (!entry.promise.setUncancellable()) {
/*     */           
/* 153 */           int pending = entry.cancel();
/* 154 */           decrementPendingOutboundBytes(pending, false, true);
/*     */         } 
/* 156 */         entry = entry.next;
/* 157 */       } while (entry != null);
/*     */ 
/*     */       
/* 160 */       this.unflushedEntry = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void incrementPendingOutboundBytes(long size) {
/* 169 */     incrementPendingOutboundBytes(size, true);
/*     */   }
/*     */   
/*     */   private void incrementPendingOutboundBytes(long size, boolean invokeLater) {
/* 173 */     if (size == 0L) {
/*     */       return;
/*     */     }
/*     */     
/* 177 */     long newWriteBufferSize = TOTAL_PENDING_SIZE_UPDATER.addAndGet(this, size);
/* 178 */     if (newWriteBufferSize > this.channel.config().getWriteBufferHighWaterMark()) {
/* 179 */       setUnwritable(invokeLater);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void decrementPendingOutboundBytes(long size) {
/* 188 */     decrementPendingOutboundBytes(size, true, true);
/*     */   }
/*     */   
/*     */   private void decrementPendingOutboundBytes(long size, boolean invokeLater, boolean notifyWritability) {
/* 192 */     if (size == 0L) {
/*     */       return;
/*     */     }
/*     */     
/* 196 */     long newWriteBufferSize = TOTAL_PENDING_SIZE_UPDATER.addAndGet(this, -size);
/* 197 */     if (notifyWritability && newWriteBufferSize < this.channel.config().getWriteBufferLowWaterMark()) {
/* 198 */       setWritable(invokeLater);
/*     */     }
/*     */   }
/*     */   
/*     */   private static long total(Object msg) {
/* 203 */     if (msg instanceof ByteBuf) {
/* 204 */       return ((ByteBuf)msg).readableBytes();
/*     */     }
/* 206 */     if (msg instanceof FileRegion) {
/* 207 */       return ((FileRegion)msg).count();
/*     */     }
/* 209 */     if (msg instanceof ByteBufHolder) {
/* 210 */       return ((ByteBufHolder)msg).content().readableBytes();
/*     */     }
/* 212 */     return -1L;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object current() {
/* 219 */     Entry entry = this.flushedEntry;
/* 220 */     if (entry == null) {
/* 221 */       return null;
/*     */     }
/*     */     
/* 224 */     return entry.msg;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long currentProgress() {
/* 232 */     Entry entry = this.flushedEntry;
/* 233 */     if (entry == null) {
/* 234 */       return 0L;
/*     */     }
/* 236 */     return entry.progress;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void progress(long amount) {
/* 243 */     Entry e = this.flushedEntry;
/* 244 */     assert e != null;
/* 245 */     ChannelPromise p = e.promise;
/* 246 */     long progress = e.progress + amount;
/* 247 */     e.progress = progress;
/* 248 */     assert p != null;
/* 249 */     Class<?> promiseClass = p.getClass();
/*     */     
/* 251 */     if (promiseClass == VoidChannelPromise.class || promiseClass == DefaultChannelPromise.class) {
/*     */       return;
/*     */     }
/*     */     
/* 255 */     if (p instanceof DefaultChannelProgressivePromise) {
/* 256 */       ((DefaultChannelProgressivePromise)p).tryProgress(progress, e.total);
/* 257 */     } else if (p instanceof ChannelProgressivePromise) {
/* 258 */       ((ChannelProgressivePromise)p).tryProgress(progress, e.total);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean remove() {
/* 268 */     Entry e = this.flushedEntry;
/* 269 */     if (e == null) {
/* 270 */       clearNioBuffers();
/* 271 */       return false;
/*     */     } 
/* 273 */     Object msg = e.msg;
/*     */     
/* 275 */     ChannelPromise promise = e.promise;
/* 276 */     int size = e.pendingSize;
/*     */     
/* 278 */     removeEntry(e);
/*     */     
/* 280 */     if (!e.cancelled) {
/*     */       
/* 282 */       ReferenceCountUtil.safeRelease(msg);
/* 283 */       safeSuccess(promise);
/* 284 */       decrementPendingOutboundBytes(size, false, true);
/*     */     } 
/*     */ 
/*     */     
/* 288 */     e.unguardedRecycle();
/*     */     
/* 290 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean remove(Throwable cause) {
/* 299 */     return remove0(cause, true);
/*     */   }
/*     */   
/*     */   private boolean remove0(Throwable cause, boolean notifyWritability) {
/* 303 */     Entry e = this.flushedEntry;
/* 304 */     if (e == null) {
/* 305 */       clearNioBuffers();
/* 306 */       return false;
/*     */     } 
/* 308 */     Object msg = e.msg;
/*     */     
/* 310 */     ChannelPromise promise = e.promise;
/* 311 */     int size = e.pendingSize;
/*     */     
/* 313 */     removeEntry(e);
/*     */     
/* 315 */     if (!e.cancelled) {
/*     */       
/* 317 */       ReferenceCountUtil.safeRelease(msg);
/*     */       
/* 319 */       safeFail(promise, cause);
/* 320 */       decrementPendingOutboundBytes(size, false, notifyWritability);
/*     */     } 
/*     */ 
/*     */     
/* 324 */     e.unguardedRecycle();
/*     */     
/* 326 */     return true;
/*     */   }
/*     */   
/*     */   private void removeEntry(Entry e) {
/* 330 */     if (--this.flushed == 0) {
/*     */       
/* 332 */       this.flushedEntry = null;
/* 333 */       if (e == this.tailEntry) {
/* 334 */         this.tailEntry = null;
/* 335 */         this.unflushedEntry = null;
/*     */       } 
/*     */     } else {
/* 338 */       this.flushedEntry = e.next;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeBytes(long writtenBytes) {
/*     */     while (true) {
/* 348 */       Object msg = current();
/* 349 */       if (!(msg instanceof ByteBuf)) {
/* 350 */         assert writtenBytes == 0L;
/*     */         
/*     */         break;
/*     */       } 
/* 354 */       ByteBuf buf = (ByteBuf)msg;
/* 355 */       int readerIndex = buf.readerIndex();
/* 356 */       int readableBytes = buf.writerIndex() - readerIndex;
/*     */       
/* 358 */       if (readableBytes <= writtenBytes) {
/* 359 */         if (writtenBytes != 0L) {
/* 360 */           progress(readableBytes);
/* 361 */           writtenBytes -= readableBytes;
/*     */         } 
/* 363 */         remove(); continue;
/*     */       } 
/* 365 */       if (writtenBytes != 0L) {
/* 366 */         buf.readerIndex(readerIndex + (int)writtenBytes);
/* 367 */         progress(writtenBytes);
/*     */       } 
/*     */       
/*     */       break;
/*     */     } 
/* 372 */     clearNioBuffers();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void clearNioBuffers() {
/* 378 */     int count = this.nioBufferCount;
/* 379 */     if (count > 0) {
/* 380 */       this.nioBufferCount = 0;
/* 381 */       Arrays.fill((Object[])NIO_BUFFERS.get(), 0, count, (Object)null);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ByteBuffer[] nioBuffers() {
/* 396 */     return nioBuffers(2147483647, 2147483647L);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ByteBuffer[] nioBuffers(int maxCount, long maxBytes) {
/* 414 */     assert maxCount > 0;
/* 415 */     assert maxBytes > 0L;
/* 416 */     long nioBufferSize = 0L;
/* 417 */     int nioBufferCount = 0;
/* 418 */     InternalThreadLocalMap threadLocalMap = InternalThreadLocalMap.get();
/* 419 */     ByteBuffer[] nioBuffers = (ByteBuffer[])NIO_BUFFERS.get(threadLocalMap);
/* 420 */     Entry entry = this.flushedEntry;
/* 421 */     while (isFlushedEntry(entry) && entry.msg instanceof ByteBuf) {
/* 422 */       if (!entry.cancelled) {
/* 423 */         ByteBuf buf = (ByteBuf)entry.msg;
/* 424 */         int readerIndex = buf.readerIndex();
/* 425 */         int readableBytes = buf.writerIndex() - readerIndex;
/*     */         
/* 427 */         if (readableBytes > 0) {
/* 428 */           if (maxBytes - readableBytes < nioBufferSize && nioBufferCount != 0) {
/*     */             break;
/*     */           }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 442 */           nioBufferSize += readableBytes;
/* 443 */           int count = entry.count;
/* 444 */           if (count == -1)
/*     */           {
/* 446 */             entry.count = count = buf.nioBufferCount();
/*     */           }
/* 448 */           int neededSpace = Math.min(maxCount, nioBufferCount + count);
/* 449 */           if (neededSpace > nioBuffers.length) {
/* 450 */             nioBuffers = expandNioBufferArray(nioBuffers, neededSpace, nioBufferCount);
/* 451 */             NIO_BUFFERS.set(threadLocalMap, nioBuffers);
/*     */           } 
/* 453 */           if (count == 1) {
/* 454 */             ByteBuffer nioBuf = entry.buf;
/* 455 */             if (nioBuf == null)
/*     */             {
/*     */               
/* 458 */               entry.buf = nioBuf = buf.internalNioBuffer(readerIndex, readableBytes);
/*     */             }
/* 460 */             nioBuffers[nioBufferCount++] = nioBuf;
/*     */           }
/*     */           else {
/*     */             
/* 464 */             nioBufferCount = nioBuffers(entry, buf, nioBuffers, nioBufferCount, maxCount);
/*     */           } 
/* 466 */           if (nioBufferCount >= maxCount) {
/*     */             break;
/*     */           }
/*     */         } 
/*     */       } 
/* 471 */       entry = entry.next;
/*     */     } 
/* 473 */     this.nioBufferCount = nioBufferCount;
/* 474 */     this.nioBufferSize = nioBufferSize;
/*     */     
/* 476 */     return nioBuffers;
/*     */   }
/*     */   
/*     */   private static int nioBuffers(Entry entry, ByteBuf buf, ByteBuffer[] nioBuffers, int nioBufferCount, int maxCount) {
/* 480 */     ByteBuffer[] nioBufs = entry.bufs;
/* 481 */     if (nioBufs == null)
/*     */     {
/*     */       
/* 484 */       entry.bufs = nioBufs = buf.nioBuffers();
/*     */     }
/* 486 */     for (int i = 0; i < nioBufs.length && nioBufferCount < maxCount; i++) {
/* 487 */       ByteBuffer nioBuf = nioBufs[i];
/* 488 */       if (nioBuf == null)
/*     */         break; 
/* 490 */       if (nioBuf.hasRemaining())
/*     */       {
/*     */         
/* 493 */         nioBuffers[nioBufferCount++] = nioBuf; } 
/*     */     } 
/* 495 */     return nioBufferCount;
/*     */   }
/*     */   
/*     */   private static ByteBuffer[] expandNioBufferArray(ByteBuffer[] array, int neededSpace, int size) {
/* 499 */     int newCapacity = array.length;
/*     */ 
/*     */     
/*     */     do {
/* 503 */       newCapacity <<= 1;
/*     */       
/* 505 */       if (newCapacity < 0) {
/* 506 */         throw new IllegalStateException();
/*     */       }
/*     */     }
/* 509 */     while (neededSpace > newCapacity);
/*     */     
/* 511 */     ByteBuffer[] newArray = new ByteBuffer[newCapacity];
/* 512 */     System.arraycopy(array, 0, newArray, 0, size);
/*     */     
/* 514 */     return newArray;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int nioBufferCount() {
/* 523 */     return this.nioBufferCount;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long nioBufferSize() {
/* 532 */     return this.nioBufferSize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isWritable() {
/* 542 */     return (this.unwritable == 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getUserDefinedWritability(int index) {
/* 550 */     return ((this.unwritable & writabilityMask(index)) == 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUserDefinedWritability(int index, boolean writable) {
/* 557 */     if (writable) {
/* 558 */       setUserDefinedWritability(index);
/*     */     } else {
/* 560 */       clearUserDefinedWritability(index);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void setUserDefinedWritability(int index) {
/* 565 */     int mask = writabilityMask(index) ^ 0xFFFFFFFF;
/*     */     while (true) {
/* 567 */       int oldValue = this.unwritable;
/* 568 */       int newValue = oldValue & mask;
/* 569 */       if (UNWRITABLE_UPDATER.compareAndSet(this, oldValue, newValue)) {
/* 570 */         if (oldValue != 0 && newValue == 0) {
/* 571 */           fireChannelWritabilityChanged(true);
/*     */         }
/*     */         return;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void clearUserDefinedWritability(int index) {
/* 579 */     int mask = writabilityMask(index);
/*     */     while (true) {
/* 581 */       int oldValue = this.unwritable;
/* 582 */       int newValue = oldValue | mask;
/* 583 */       if (UNWRITABLE_UPDATER.compareAndSet(this, oldValue, newValue)) {
/* 584 */         if (oldValue == 0 && newValue != 0) {
/* 585 */           fireChannelWritabilityChanged(true);
/*     */         }
/*     */         return;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private static int writabilityMask(int index) {
/* 593 */     if (index < 1 || index > 31) {
/* 594 */       throw new IllegalArgumentException("index: " + index + " (expected: 1~31)");
/*     */     }
/* 596 */     return 1 << index;
/*     */   }
/*     */   
/*     */   private void setWritable(boolean invokeLater) {
/*     */     while (true) {
/* 601 */       int oldValue = this.unwritable;
/* 602 */       int newValue = oldValue & 0xFFFFFFFE;
/* 603 */       if (UNWRITABLE_UPDATER.compareAndSet(this, oldValue, newValue)) {
/* 604 */         if (oldValue != 0 && newValue == 0) {
/* 605 */           fireChannelWritabilityChanged(invokeLater);
/*     */         }
/*     */         return;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void setUnwritable(boolean invokeLater) {
/*     */     while (true) {
/* 614 */       int oldValue = this.unwritable;
/* 615 */       int newValue = oldValue | 0x1;
/* 616 */       if (UNWRITABLE_UPDATER.compareAndSet(this, oldValue, newValue)) {
/* 617 */         if (oldValue == 0) {
/* 618 */           fireChannelWritabilityChanged(invokeLater);
/*     */         }
/*     */         return;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void fireChannelWritabilityChanged(boolean invokeLater) {
/* 626 */     final ChannelPipeline pipeline = this.channel.pipeline();
/* 627 */     if (invokeLater) {
/* 628 */       Runnable task = this.fireChannelWritabilityChangedTask;
/* 629 */       if (task == null) {
/* 630 */         this.fireChannelWritabilityChangedTask = task = new Runnable()
/*     */           {
/*     */             public void run() {
/* 633 */               pipeline.fireChannelWritabilityChanged();
/*     */             }
/*     */           };
/*     */       }
/* 637 */       this.channel.eventLoop().execute(task);
/*     */     } else {
/* 639 */       pipeline.fireChannelWritabilityChanged();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int size() {
/* 647 */     return this.flushed;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 655 */     return (this.flushed == 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void failFlushed(Throwable cause, boolean notify) {
/* 664 */     if (this.inFail) {
/*     */       return;
/*     */     }
/*     */     
/*     */     try {
/* 669 */       this.inFail = true; do {
/*     */       
/* 671 */       } while (remove0(cause, notify));
/*     */     
/*     */     }
/*     */     finally {
/*     */       
/* 676 */       this.inFail = false;
/*     */     } 
/*     */   }
/*     */   
/*     */   void close(final Throwable cause, final boolean allowChannelOpen) {
/* 681 */     if (this.inFail) {
/* 682 */       this.channel.eventLoop().execute(new Runnable()
/*     */           {
/*     */             public void run() {
/* 685 */               ChannelOutboundBuffer.this.close(cause, allowChannelOpen);
/*     */             }
/*     */           });
/*     */       
/*     */       return;
/*     */     } 
/* 691 */     this.inFail = true;
/*     */     
/* 693 */     if (!allowChannelOpen && this.channel.isOpen()) {
/* 694 */       throw new IllegalStateException("close() must be invoked after the channel is closed.");
/*     */     }
/*     */     
/* 697 */     if (!isEmpty()) {
/* 698 */       throw new IllegalStateException("close() must be invoked after all flushed writes are handled.");
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/* 703 */       Entry e = this.unflushedEntry;
/* 704 */       while (e != null) {
/*     */         
/* 706 */         int size = e.pendingSize;
/* 707 */         TOTAL_PENDING_SIZE_UPDATER.addAndGet(this, -size);
/*     */         
/* 709 */         if (!e.cancelled) {
/* 710 */           ReferenceCountUtil.safeRelease(e.msg);
/* 711 */           safeFail(e.promise, cause);
/*     */         } 
/* 713 */         e = e.unguardedRecycleAndGetNext();
/*     */       } 
/*     */     } finally {
/* 716 */       this.inFail = false;
/*     */     } 
/* 718 */     clearNioBuffers();
/*     */   }
/*     */   
/*     */   void close(ClosedChannelException cause) {
/* 722 */     close(cause, false);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static void safeSuccess(ChannelPromise promise) {
/* 728 */     PromiseNotificationUtil.trySuccess(promise, null, (promise instanceof VoidChannelPromise) ? null : logger);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static void safeFail(ChannelPromise promise, Throwable cause) {
/* 734 */     PromiseNotificationUtil.tryFailure(promise, cause, (promise instanceof VoidChannelPromise) ? null : logger);
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void recycle() {}
/*     */ 
/*     */   
/*     */   public long totalPendingWriteBytes() {
/* 743 */     return this.totalPendingSize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long bytesBeforeUnwritable() {
/* 752 */     long bytes = this.channel.config().getWriteBufferHighWaterMark() - this.totalPendingSize + 1L;
/*     */ 
/*     */ 
/*     */     
/* 756 */     return (bytes > 0L && isWritable()) ? bytes : 0L;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long bytesBeforeWritable() {
/* 765 */     long bytes = this.totalPendingSize - this.channel.config().getWriteBufferLowWaterMark() + 1L;
/*     */ 
/*     */ 
/*     */     
/* 769 */     return (bytes <= 0L || isWritable()) ? 0L : bytes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void forEachFlushedMessage(MessageProcessor processor) throws Exception {
/* 778 */     ObjectUtil.checkNotNull(processor, "processor");
/*     */     
/* 780 */     Entry entry = this.flushedEntry;
/* 781 */     if (entry == null) {
/*     */       return;
/*     */     }
/*     */     
/*     */     do {
/* 786 */       if (!entry.cancelled && 
/* 787 */         !processor.processMessage(entry.msg)) {
/*     */         return;
/*     */       }
/*     */       
/* 791 */       entry = entry.next;
/* 792 */     } while (isFlushedEntry(entry));
/*     */   }
/*     */   
/*     */   private boolean isFlushedEntry(Entry e) {
/* 796 */     return (e != null && e != this.unflushedEntry);
/*     */   }
/*     */ 
/*     */   
/*     */   public static interface MessageProcessor
/*     */   {
/*     */     boolean processMessage(Object param1Object) throws Exception;
/*     */   }
/*     */ 
/*     */   
/*     */   static final class Entry
/*     */   {
/* 808 */     private static final ObjectPool<Entry> RECYCLER = ObjectPool.newPool(new ObjectPool.ObjectCreator<Entry>()
/*     */         {
/*     */           public ChannelOutboundBuffer.Entry newObject(ObjectPool.Handle<ChannelOutboundBuffer.Entry> handle) {
/* 811 */             return new ChannelOutboundBuffer.Entry(handle);
/*     */           }
/*     */         });
/*     */     
/*     */     private final Recycler.EnhancedHandle<Entry> handle;
/*     */     Entry next;
/*     */     Object msg;
/*     */     ByteBuffer[] bufs;
/*     */     ByteBuffer buf;
/*     */     ChannelPromise promise;
/*     */     long progress;
/*     */     long total;
/*     */     int pendingSize;
/* 824 */     int count = -1;
/*     */     boolean cancelled;
/*     */     
/*     */     private Entry(ObjectPool.Handle<Entry> handle) {
/* 828 */       this.handle = (Recycler.EnhancedHandle<Entry>)handle;
/*     */     }
/*     */     
/*     */     static Entry newInstance(Object msg, int size, long total, ChannelPromise promise) {
/* 832 */       Entry entry = (Entry)RECYCLER.get();
/* 833 */       entry.msg = msg;
/* 834 */       entry.pendingSize = size + ChannelOutboundBuffer.CHANNEL_OUTBOUND_BUFFER_ENTRY_OVERHEAD;
/* 835 */       entry.total = total;
/* 836 */       entry.promise = promise;
/* 837 */       return entry;
/*     */     }
/*     */     
/*     */     int cancel() {
/* 841 */       if (!this.cancelled) {
/* 842 */         this.cancelled = true;
/* 843 */         int pSize = this.pendingSize;
/*     */ 
/*     */         
/* 846 */         ReferenceCountUtil.safeRelease(this.msg);
/* 847 */         this.msg = Unpooled.EMPTY_BUFFER;
/*     */         
/* 849 */         this.pendingSize = 0;
/* 850 */         this.total = 0L;
/* 851 */         this.progress = 0L;
/* 852 */         this.bufs = null;
/* 853 */         this.buf = null;
/* 854 */         return pSize;
/*     */       } 
/* 856 */       return 0;
/*     */     }
/*     */     
/*     */     void unguardedRecycle() {
/* 860 */       this.next = null;
/* 861 */       this.bufs = null;
/* 862 */       this.buf = null;
/* 863 */       this.msg = null;
/* 864 */       this.promise = null;
/* 865 */       this.progress = 0L;
/* 866 */       this.total = 0L;
/* 867 */       this.pendingSize = 0;
/* 868 */       this.count = -1;
/* 869 */       this.cancelled = false;
/* 870 */       this.handle.unguardedRecycle(this);
/*     */     }
/*     */     
/*     */     Entry unguardedRecycleAndGetNext() {
/* 874 */       Entry next = this.next;
/* 875 */       unguardedRecycle();
/* 876 */       return next;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-transport-4.1.93.Final.jar!\io\netty\channel\ChannelOutboundBuffer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */