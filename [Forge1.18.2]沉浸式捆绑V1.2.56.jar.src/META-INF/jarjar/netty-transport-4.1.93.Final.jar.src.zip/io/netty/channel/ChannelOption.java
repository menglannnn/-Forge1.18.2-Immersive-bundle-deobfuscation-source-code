/*     */ package io.netty.channel;
/*     */ 
/*     */ import io.netty.buffer.ByteBufAllocator;
/*     */ import io.netty.util.AbstractConstant;
/*     */ import io.netty.util.Constant;
/*     */ import io.netty.util.ConstantPool;
/*     */ import io.netty.util.internal.ObjectUtil;
/*     */ import java.net.InetAddress;
/*     */ import java.net.NetworkInterface;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ChannelOption<T>
/*     */   extends AbstractConstant<ChannelOption<T>>
/*     */ {
/*  36 */   private static final ConstantPool<ChannelOption<Object>> pool = new ConstantPool<ChannelOption<Object>>()
/*     */     {
/*     */       protected ChannelOption<Object> newConstant(int id, String name) {
/*  39 */         return new ChannelOption(id, name);
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> ChannelOption<T> valueOf(String name) {
/*  48 */     return (ChannelOption<T>)pool.valueOf(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> ChannelOption<T> valueOf(Class<?> firstNameComponent, String secondNameComponent) {
/*  56 */     return (ChannelOption<T>)pool.valueOf(firstNameComponent, secondNameComponent);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean exists(String name) {
/*  63 */     return pool.exists(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static <T> ChannelOption<T> newInstance(String name) {
/*  75 */     return (ChannelOption<T>)pool.newInstance(name);
/*     */   }
/*     */   
/*  78 */   public static final ChannelOption<ByteBufAllocator> ALLOCATOR = valueOf("ALLOCATOR");
/*  79 */   public static final ChannelOption<RecvByteBufAllocator> RCVBUF_ALLOCATOR = valueOf("RCVBUF_ALLOCATOR");
/*  80 */   public static final ChannelOption<MessageSizeEstimator> MESSAGE_SIZE_ESTIMATOR = valueOf("MESSAGE_SIZE_ESTIMATOR");
/*     */   
/*  82 */   public static final ChannelOption<Integer> CONNECT_TIMEOUT_MILLIS = valueOf("CONNECT_TIMEOUT_MILLIS");
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*  88 */   public static final ChannelOption<Integer> MAX_MESSAGES_PER_READ = valueOf("MAX_MESSAGES_PER_READ");
/*  89 */   public static final ChannelOption<Integer> MAX_MESSAGES_PER_WRITE = valueOf("MAX_MESSAGES_PER_WRITE");
/*     */   
/*  91 */   public static final ChannelOption<Integer> WRITE_SPIN_COUNT = valueOf("WRITE_SPIN_COUNT");
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*  96 */   public static final ChannelOption<Integer> WRITE_BUFFER_HIGH_WATER_MARK = valueOf("WRITE_BUFFER_HIGH_WATER_MARK");
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/* 101 */   public static final ChannelOption<Integer> WRITE_BUFFER_LOW_WATER_MARK = valueOf("WRITE_BUFFER_LOW_WATER_MARK");
/*     */   
/* 103 */   public static final ChannelOption<WriteBufferWaterMark> WRITE_BUFFER_WATER_MARK = valueOf("WRITE_BUFFER_WATER_MARK");
/*     */   
/* 105 */   public static final ChannelOption<Boolean> ALLOW_HALF_CLOSURE = valueOf("ALLOW_HALF_CLOSURE");
/* 106 */   public static final ChannelOption<Boolean> AUTO_READ = valueOf("AUTO_READ");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 112 */   public static final ChannelOption<Boolean> AUTO_CLOSE = valueOf("AUTO_CLOSE");
/*     */   
/* 114 */   public static final ChannelOption<Boolean> SO_BROADCAST = valueOf("SO_BROADCAST");
/* 115 */   public static final ChannelOption<Boolean> SO_KEEPALIVE = valueOf("SO_KEEPALIVE");
/* 116 */   public static final ChannelOption<Integer> SO_SNDBUF = valueOf("SO_SNDBUF");
/* 117 */   public static final ChannelOption<Integer> SO_RCVBUF = valueOf("SO_RCVBUF");
/* 118 */   public static final ChannelOption<Boolean> SO_REUSEADDR = valueOf("SO_REUSEADDR");
/* 119 */   public static final ChannelOption<Integer> SO_LINGER = valueOf("SO_LINGER");
/* 120 */   public static final ChannelOption<Integer> SO_BACKLOG = valueOf("SO_BACKLOG");
/* 121 */   public static final ChannelOption<Integer> SO_TIMEOUT = valueOf("SO_TIMEOUT");
/*     */   
/* 123 */   public static final ChannelOption<Integer> IP_TOS = valueOf("IP_TOS");
/* 124 */   public static final ChannelOption<InetAddress> IP_MULTICAST_ADDR = valueOf("IP_MULTICAST_ADDR");
/* 125 */   public static final ChannelOption<NetworkInterface> IP_MULTICAST_IF = valueOf("IP_MULTICAST_IF");
/* 126 */   public static final ChannelOption<Integer> IP_MULTICAST_TTL = valueOf("IP_MULTICAST_TTL");
/* 127 */   public static final ChannelOption<Boolean> IP_MULTICAST_LOOP_DISABLED = valueOf("IP_MULTICAST_LOOP_DISABLED");
/*     */   
/* 129 */   public static final ChannelOption<Boolean> TCP_NODELAY = valueOf("TCP_NODELAY");
/*     */ 
/*     */ 
/*     */   
/* 133 */   public static final ChannelOption<Boolean> TCP_FASTOPEN_CONNECT = valueOf("TCP_FASTOPEN_CONNECT");
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 138 */   public static final ChannelOption<Integer> TCP_FASTOPEN = valueOf(ChannelOption.class, "TCP_FASTOPEN");
/*     */ 
/*     */   
/*     */   @Deprecated
/* 142 */   public static final ChannelOption<Boolean> DATAGRAM_CHANNEL_ACTIVE_ON_REGISTRATION = valueOf("DATAGRAM_CHANNEL_ACTIVE_ON_REGISTRATION");
/*     */ 
/*     */   
/* 145 */   public static final ChannelOption<Boolean> SINGLE_EVENTEXECUTOR_PER_GROUP = valueOf("SINGLE_EVENTEXECUTOR_PER_GROUP");
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ChannelOption(int id, String name) {
/* 151 */     super(id, name);
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   protected ChannelOption(String name) {
/* 156 */     this(pool.nextId(), name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void validate(T value) {
/* 164 */     ObjectUtil.checkNotNull(value, "value");
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-transport-4.1.93.Final.jar!\io\netty\channel\ChannelOption.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */