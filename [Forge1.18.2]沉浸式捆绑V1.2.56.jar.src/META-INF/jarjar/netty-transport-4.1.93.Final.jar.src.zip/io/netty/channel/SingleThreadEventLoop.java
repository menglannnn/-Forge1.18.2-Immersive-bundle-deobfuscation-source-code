/*     */ package io.netty.channel;
/*     */ 
/*     */ import io.netty.util.concurrent.EventExecutor;
/*     */ import io.netty.util.concurrent.EventExecutorGroup;
/*     */ import io.netty.util.concurrent.RejectedExecutionHandler;
/*     */ import io.netty.util.concurrent.RejectedExecutionHandlers;
/*     */ import io.netty.util.concurrent.SingleThreadEventExecutor;
/*     */ import io.netty.util.internal.ObjectUtil;
/*     */ import io.netty.util.internal.SystemPropertyUtil;
/*     */ import java.util.Iterator;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.Queue;
/*     */ import java.util.concurrent.Executor;
/*     */ import java.util.concurrent.ThreadFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class SingleThreadEventLoop
/*     */   extends SingleThreadEventExecutor
/*     */   implements EventLoop
/*     */ {
/*  37 */   protected static final int DEFAULT_MAX_PENDING_TASKS = Math.max(16, 
/*  38 */       SystemPropertyUtil.getInt("io.netty.eventLoop.maxPendingTasks", 2147483647));
/*     */   
/*     */   private final Queue<Runnable> tailTasks;
/*     */   
/*     */   protected SingleThreadEventLoop(EventLoopGroup parent, ThreadFactory threadFactory, boolean addTaskWakesUp) {
/*  43 */     this(parent, threadFactory, addTaskWakesUp, DEFAULT_MAX_PENDING_TASKS, RejectedExecutionHandlers.reject());
/*     */   }
/*     */   
/*     */   protected SingleThreadEventLoop(EventLoopGroup parent, Executor executor, boolean addTaskWakesUp) {
/*  47 */     this(parent, executor, addTaskWakesUp, DEFAULT_MAX_PENDING_TASKS, RejectedExecutionHandlers.reject());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected SingleThreadEventLoop(EventLoopGroup parent, ThreadFactory threadFactory, boolean addTaskWakesUp, int maxPendingTasks, RejectedExecutionHandler rejectedExecutionHandler) {
/*  53 */     super(parent, threadFactory, addTaskWakesUp, maxPendingTasks, rejectedExecutionHandler);
/*  54 */     this.tailTasks = newTaskQueue(maxPendingTasks);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected SingleThreadEventLoop(EventLoopGroup parent, Executor executor, boolean addTaskWakesUp, int maxPendingTasks, RejectedExecutionHandler rejectedExecutionHandler) {
/*  60 */     super(parent, executor, addTaskWakesUp, maxPendingTasks, rejectedExecutionHandler);
/*  61 */     this.tailTasks = newTaskQueue(maxPendingTasks);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected SingleThreadEventLoop(EventLoopGroup parent, Executor executor, boolean addTaskWakesUp, Queue<Runnable> taskQueue, Queue<Runnable> tailTaskQueue, RejectedExecutionHandler rejectedExecutionHandler) {
/*  67 */     super(parent, executor, addTaskWakesUp, taskQueue, rejectedExecutionHandler);
/*  68 */     this.tailTasks = (Queue<Runnable>)ObjectUtil.checkNotNull(tailTaskQueue, "tailTaskQueue");
/*     */   }
/*     */ 
/*     */   
/*     */   public EventLoopGroup parent() {
/*  73 */     return (EventLoopGroup)super.parent();
/*     */   }
/*     */ 
/*     */   
/*     */   public EventLoop next() {
/*  78 */     return (EventLoop)super.next();
/*     */   }
/*     */ 
/*     */   
/*     */   public ChannelFuture register(Channel channel) {
/*  83 */     return register(new DefaultChannelPromise(channel, (EventExecutor)this));
/*     */   }
/*     */ 
/*     */   
/*     */   public ChannelFuture register(ChannelPromise promise) {
/*  88 */     ObjectUtil.checkNotNull(promise, "promise");
/*  89 */     promise.channel().unsafe().register(this, promise);
/*  90 */     return promise;
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public ChannelFuture register(Channel channel, ChannelPromise promise) {
/*  96 */     ObjectUtil.checkNotNull(promise, "promise");
/*  97 */     ObjectUtil.checkNotNull(channel, "channel");
/*  98 */     channel.unsafe().register(this, promise);
/*  99 */     return promise;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void executeAfterEventLoopIteration(Runnable task) {
/* 109 */     ObjectUtil.checkNotNull(task, "task");
/* 110 */     if (isShutdown()) {
/* 111 */       reject();
/*     */     }
/*     */     
/* 114 */     if (!this.tailTasks.offer(task)) {
/* 115 */       reject(task);
/*     */     }
/*     */     
/* 118 */     if (wakesUpForTask(task)) {
/* 119 */       wakeup(inEventLoop());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean removeAfterEventLoopIterationTask(Runnable task) {
/* 132 */     return this.tailTasks.remove(ObjectUtil.checkNotNull(task, "task"));
/*     */   }
/*     */ 
/*     */   
/*     */   protected void afterRunningAllTasks() {
/* 137 */     runAllTasksFrom(this.tailTasks);
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean hasTasks() {
/* 142 */     return (super.hasTasks() || !this.tailTasks.isEmpty());
/*     */   }
/*     */ 
/*     */   
/*     */   public int pendingTasks() {
/* 147 */     return super.pendingTasks() + this.tailTasks.size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int registeredChannels() {
/* 157 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Iterator<Channel> registeredChannelsIterator() {
/* 169 */     throw new UnsupportedOperationException("registeredChannelsIterator");
/*     */   }
/*     */   
/*     */   protected static final class ChannelsReadOnlyIterator<T extends Channel> implements Iterator<Channel> {
/*     */     private final Iterator<T> channelIterator;
/*     */     
/*     */     public ChannelsReadOnlyIterator(Iterable<T> channelIterable) {
/* 176 */       this
/* 177 */         .channelIterator = ((Iterable<T>)ObjectUtil.checkNotNull(channelIterable, "channelIterable")).iterator();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean hasNext() {
/* 182 */       return this.channelIterator.hasNext();
/*     */     }
/*     */ 
/*     */     
/*     */     public Channel next() {
/* 187 */       return (Channel)this.channelIterator.next();
/*     */     }
/*     */ 
/*     */     
/*     */     public void remove() {
/* 192 */       throw new UnsupportedOperationException("remove");
/*     */     }
/*     */ 
/*     */     
/*     */     public static <T> Iterator<T> empty() {
/* 197 */       return (Iterator)EMPTY;
/*     */     }
/*     */     
/* 200 */     private static final Iterator<Object> EMPTY = new Iterator()
/*     */       {
/*     */         public boolean hasNext() {
/* 203 */           return false;
/*     */         }
/*     */ 
/*     */         
/*     */         public Object next() {
/* 208 */           throw new NoSuchElementException();
/*     */         }
/*     */ 
/*     */         
/*     */         public void remove() {
/* 213 */           throw new UnsupportedOperationException("remove");
/*     */         }
/*     */       };
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-transport-4.1.93.Final.jar!\io\netty\channel\SingleThreadEventLoop.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */