/*      */ package io.netty.channel;
/*      */ 
/*      */ import io.netty.buffer.ByteBufAllocator;
/*      */ import io.netty.util.Attribute;
/*      */ import io.netty.util.AttributeKey;
/*      */ import io.netty.util.ReferenceCountUtil;
/*      */ import io.netty.util.ResourceLeakHint;
/*      */ import io.netty.util.concurrent.AbstractEventExecutor;
/*      */ import io.netty.util.concurrent.EventExecutor;
/*      */ import io.netty.util.internal.ObjectPool;
/*      */ import io.netty.util.internal.ObjectUtil;
/*      */ import io.netty.util.internal.PromiseNotificationUtil;
/*      */ import io.netty.util.internal.StringUtil;
/*      */ import io.netty.util.internal.SystemPropertyUtil;
/*      */ import io.netty.util.internal.ThrowableUtil;
/*      */ import io.netty.util.internal.logging.InternalLogger;
/*      */ import io.netty.util.internal.logging.InternalLoggerFactory;
/*      */ import java.net.SocketAddress;
/*      */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ abstract class AbstractChannelHandlerContext
/*      */   implements ChannelHandlerContext, ResourceLeakHint
/*      */ {
/*   63 */   private static final InternalLogger logger = InternalLoggerFactory.getInstance(AbstractChannelHandlerContext.class);
/*      */   
/*      */   volatile AbstractChannelHandlerContext next;
/*      */   
/*      */   volatile AbstractChannelHandlerContext prev;
/*   68 */   private static final AtomicIntegerFieldUpdater<AbstractChannelHandlerContext> HANDLER_STATE_UPDATER = AtomicIntegerFieldUpdater.newUpdater(AbstractChannelHandlerContext.class, "handlerState");
/*      */ 
/*      */   
/*      */   private static final int ADD_PENDING = 1;
/*      */ 
/*      */   
/*      */   private static final int ADD_COMPLETE = 2;
/*      */ 
/*      */   
/*      */   private static final int REMOVE_COMPLETE = 3;
/*      */ 
/*      */   
/*      */   private static final int INIT = 0;
/*      */ 
/*      */   
/*      */   private final DefaultChannelPipeline pipeline;
/*      */ 
/*      */   
/*      */   private final String name;
/*      */ 
/*      */   
/*      */   private final boolean ordered;
/*      */ 
/*      */   
/*      */   private final int executionMask;
/*      */ 
/*      */   
/*      */   final EventExecutor executor;
/*      */ 
/*      */   
/*      */   private ChannelFuture succeededFuture;
/*      */   
/*      */   private Tasks invokeTasks;
/*      */   
/*  102 */   private volatile int handlerState = 0;
/*      */ 
/*      */   
/*      */   AbstractChannelHandlerContext(DefaultChannelPipeline pipeline, EventExecutor executor, String name, Class<? extends ChannelHandler> handlerClass) {
/*  106 */     this.name = (String)ObjectUtil.checkNotNull(name, "name");
/*  107 */     this.pipeline = pipeline;
/*  108 */     this.executor = executor;
/*  109 */     this.executionMask = ChannelHandlerMask.mask(handlerClass);
/*      */     
/*  111 */     this.ordered = (executor == null || executor instanceof io.netty.util.concurrent.OrderedEventExecutor);
/*      */   }
/*      */ 
/*      */   
/*      */   public Channel channel() {
/*  116 */     return this.pipeline.channel();
/*      */   }
/*      */ 
/*      */   
/*      */   public ChannelPipeline pipeline() {
/*  121 */     return this.pipeline;
/*      */   }
/*      */ 
/*      */   
/*      */   public ByteBufAllocator alloc() {
/*  126 */     return channel().config().getAllocator();
/*      */   }
/*      */ 
/*      */   
/*      */   public EventExecutor executor() {
/*  131 */     if (this.executor == null) {
/*  132 */       return (EventExecutor)channel().eventLoop();
/*      */     }
/*  134 */     return this.executor;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String name() {
/*  140 */     return this.name;
/*      */   }
/*      */ 
/*      */   
/*      */   public ChannelHandlerContext fireChannelRegistered() {
/*  145 */     invokeChannelRegistered(findContextInbound(2));
/*  146 */     return this;
/*      */   }
/*      */   
/*      */   static void invokeChannelRegistered(final AbstractChannelHandlerContext next) {
/*  150 */     EventExecutor executor = next.executor();
/*  151 */     if (executor.inEventLoop()) {
/*  152 */       next.invokeChannelRegistered();
/*      */     } else {
/*  154 */       executor.execute(new Runnable()
/*      */           {
/*      */             public void run() {
/*  157 */               next.invokeChannelRegistered();
/*      */             }
/*      */           });
/*      */     } 
/*      */   }
/*      */   
/*      */   private void invokeChannelRegistered() {
/*  164 */     if (invokeHandler()) {
/*      */ 
/*      */       
/*      */       try {
/*      */         
/*  169 */         ChannelHandler handler = handler();
/*  170 */         DefaultChannelPipeline.HeadContext headContext = this.pipeline.head;
/*  171 */         if (handler == headContext) {
/*  172 */           headContext.channelRegistered(this);
/*  173 */         } else if (handler instanceof ChannelDuplexHandler) {
/*  174 */           ((ChannelDuplexHandler)handler).channelRegistered(this);
/*      */         } else {
/*  176 */           ((ChannelInboundHandler)handler).channelRegistered(this);
/*      */         } 
/*  178 */       } catch (Throwable t) {
/*  179 */         invokeExceptionCaught(t);
/*      */       } 
/*      */     } else {
/*  182 */       fireChannelRegistered();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public ChannelHandlerContext fireChannelUnregistered() {
/*  188 */     invokeChannelUnregistered(findContextInbound(4));
/*  189 */     return this;
/*      */   }
/*      */   
/*      */   static void invokeChannelUnregistered(final AbstractChannelHandlerContext next) {
/*  193 */     EventExecutor executor = next.executor();
/*  194 */     if (executor.inEventLoop()) {
/*  195 */       next.invokeChannelUnregistered();
/*      */     } else {
/*  197 */       executor.execute(new Runnable()
/*      */           {
/*      */             public void run() {
/*  200 */               next.invokeChannelUnregistered();
/*      */             }
/*      */           });
/*      */     } 
/*      */   }
/*      */   
/*      */   private void invokeChannelUnregistered() {
/*  207 */     if (invokeHandler()) {
/*      */ 
/*      */       
/*      */       try {
/*      */         
/*  212 */         ChannelHandler handler = handler();
/*  213 */         DefaultChannelPipeline.HeadContext headContext = this.pipeline.head;
/*  214 */         if (handler == headContext) {
/*  215 */           headContext.channelUnregistered(this);
/*  216 */         } else if (handler instanceof ChannelDuplexHandler) {
/*  217 */           ((ChannelDuplexHandler)handler).channelUnregistered(this);
/*      */         } else {
/*  219 */           ((ChannelInboundHandler)handler).channelUnregistered(this);
/*      */         } 
/*  221 */       } catch (Throwable t) {
/*  222 */         invokeExceptionCaught(t);
/*      */       } 
/*      */     } else {
/*  225 */       fireChannelUnregistered();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public ChannelHandlerContext fireChannelActive() {
/*  231 */     invokeChannelActive(findContextInbound(8));
/*  232 */     return this;
/*      */   }
/*      */   
/*      */   static void invokeChannelActive(final AbstractChannelHandlerContext next) {
/*  236 */     EventExecutor executor = next.executor();
/*  237 */     if (executor.inEventLoop()) {
/*  238 */       next.invokeChannelActive();
/*      */     } else {
/*  240 */       executor.execute(new Runnable()
/*      */           {
/*      */             public void run() {
/*  243 */               next.invokeChannelActive();
/*      */             }
/*      */           });
/*      */     } 
/*      */   }
/*      */   
/*      */   private void invokeChannelActive() {
/*  250 */     if (invokeHandler()) {
/*      */ 
/*      */       
/*      */       try {
/*      */         
/*  255 */         ChannelHandler handler = handler();
/*  256 */         DefaultChannelPipeline.HeadContext headContext = this.pipeline.head;
/*  257 */         if (handler == headContext) {
/*  258 */           headContext.channelActive(this);
/*  259 */         } else if (handler instanceof ChannelDuplexHandler) {
/*  260 */           ((ChannelDuplexHandler)handler).channelActive(this);
/*      */         } else {
/*  262 */           ((ChannelInboundHandler)handler).channelActive(this);
/*      */         } 
/*  264 */       } catch (Throwable t) {
/*  265 */         invokeExceptionCaught(t);
/*      */       } 
/*      */     } else {
/*  268 */       fireChannelActive();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public ChannelHandlerContext fireChannelInactive() {
/*  274 */     invokeChannelInactive(findContextInbound(16));
/*  275 */     return this;
/*      */   }
/*      */   
/*      */   static void invokeChannelInactive(final AbstractChannelHandlerContext next) {
/*  279 */     EventExecutor executor = next.executor();
/*  280 */     if (executor.inEventLoop()) {
/*  281 */       next.invokeChannelInactive();
/*      */     } else {
/*  283 */       executor.execute(new Runnable()
/*      */           {
/*      */             public void run() {
/*  286 */               next.invokeChannelInactive();
/*      */             }
/*      */           });
/*      */     } 
/*      */   }
/*      */   
/*      */   private void invokeChannelInactive() {
/*  293 */     if (invokeHandler()) {
/*      */ 
/*      */       
/*      */       try {
/*      */         
/*  298 */         ChannelHandler handler = handler();
/*  299 */         DefaultChannelPipeline.HeadContext headContext = this.pipeline.head;
/*  300 */         if (handler == headContext) {
/*  301 */           headContext.channelInactive(this);
/*  302 */         } else if (handler instanceof ChannelDuplexHandler) {
/*  303 */           ((ChannelDuplexHandler)handler).channelInactive(this);
/*      */         } else {
/*  305 */           ((ChannelInboundHandler)handler).channelInactive(this);
/*      */         } 
/*  307 */       } catch (Throwable t) {
/*  308 */         invokeExceptionCaught(t);
/*      */       } 
/*      */     } else {
/*  311 */       fireChannelInactive();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public ChannelHandlerContext fireExceptionCaught(Throwable cause) {
/*  317 */     invokeExceptionCaught(findContextInbound(1), cause);
/*  318 */     return this;
/*      */   }
/*      */   
/*      */   static void invokeExceptionCaught(final AbstractChannelHandlerContext next, final Throwable cause) {
/*  322 */     ObjectUtil.checkNotNull(cause, "cause");
/*  323 */     EventExecutor executor = next.executor();
/*  324 */     if (executor.inEventLoop()) {
/*  325 */       next.invokeExceptionCaught(cause);
/*      */     } else {
/*      */       try {
/*  328 */         executor.execute(new Runnable()
/*      */             {
/*      */               public void run() {
/*  331 */                 next.invokeExceptionCaught(cause);
/*      */               }
/*      */             });
/*  334 */       } catch (Throwable t) {
/*  335 */         if (logger.isWarnEnabled()) {
/*  336 */           logger.warn("Failed to submit an exceptionCaught() event.", t);
/*  337 */           logger.warn("The exceptionCaught() event that was failed to submit was:", cause);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   private void invokeExceptionCaught(Throwable cause) {
/*  344 */     if (invokeHandler()) {
/*      */       try {
/*  346 */         handler().exceptionCaught(this, cause);
/*  347 */       } catch (Throwable error) {
/*  348 */         if (logger.isDebugEnabled()) {
/*  349 */           logger.debug("An exception {}was thrown by a user handler's exceptionCaught() method while handling the following exception:", 
/*      */ 
/*      */ 
/*      */               
/*  353 */               ThrowableUtil.stackTraceToString(error), cause);
/*  354 */         } else if (logger.isWarnEnabled()) {
/*  355 */           logger.warn("An exception '{}' [enable DEBUG level for full stacktrace] was thrown by a user handler's exceptionCaught() method while handling the following exception:", error, cause);
/*      */         }
/*      */       
/*      */       }
/*      */     
/*      */     } else {
/*      */       
/*  362 */       fireExceptionCaught(cause);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public ChannelHandlerContext fireUserEventTriggered(Object event) {
/*  368 */     invokeUserEventTriggered(findContextInbound(128), event);
/*  369 */     return this;
/*      */   }
/*      */   
/*      */   static void invokeUserEventTriggered(final AbstractChannelHandlerContext next, final Object event) {
/*  373 */     ObjectUtil.checkNotNull(event, "event");
/*  374 */     EventExecutor executor = next.executor();
/*  375 */     if (executor.inEventLoop()) {
/*  376 */       next.invokeUserEventTriggered(event);
/*      */     } else {
/*  378 */       executor.execute(new Runnable()
/*      */           {
/*      */             public void run() {
/*  381 */               next.invokeUserEventTriggered(event);
/*      */             }
/*      */           });
/*      */     } 
/*      */   }
/*      */   
/*      */   private void invokeUserEventTriggered(Object event) {
/*  388 */     if (invokeHandler()) {
/*      */ 
/*      */       
/*      */       try {
/*      */         
/*  393 */         ChannelHandler handler = handler();
/*  394 */         DefaultChannelPipeline.HeadContext headContext = this.pipeline.head;
/*  395 */         if (handler == headContext) {
/*  396 */           headContext.userEventTriggered(this, event);
/*  397 */         } else if (handler instanceof ChannelDuplexHandler) {
/*  398 */           ((ChannelDuplexHandler)handler).userEventTriggered(this, event);
/*      */         } else {
/*  400 */           ((ChannelInboundHandler)handler).userEventTriggered(this, event);
/*      */         } 
/*  402 */       } catch (Throwable t) {
/*  403 */         invokeExceptionCaught(t);
/*      */       } 
/*      */     } else {
/*  406 */       fireUserEventTriggered(event);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public ChannelHandlerContext fireChannelRead(Object msg) {
/*  412 */     invokeChannelRead(findContextInbound(32), msg);
/*  413 */     return this;
/*      */   }
/*      */   
/*      */   static void invokeChannelRead(final AbstractChannelHandlerContext next, Object msg) {
/*  417 */     final Object m = next.pipeline.touch(ObjectUtil.checkNotNull(msg, "msg"), next);
/*  418 */     EventExecutor executor = next.executor();
/*  419 */     if (executor.inEventLoop()) {
/*  420 */       next.invokeChannelRead(m);
/*      */     } else {
/*  422 */       executor.execute(new Runnable()
/*      */           {
/*      */             public void run() {
/*  425 */               next.invokeChannelRead(m);
/*      */             }
/*      */           });
/*      */     } 
/*      */   }
/*      */   
/*      */   private void invokeChannelRead(Object msg) {
/*  432 */     if (invokeHandler()) {
/*      */ 
/*      */       
/*      */       try {
/*      */         
/*  437 */         ChannelHandler handler = handler();
/*  438 */         DefaultChannelPipeline.HeadContext headContext = this.pipeline.head;
/*  439 */         if (handler == headContext) {
/*  440 */           headContext.channelRead(this, msg);
/*  441 */         } else if (handler instanceof ChannelDuplexHandler) {
/*  442 */           ((ChannelDuplexHandler)handler).channelRead(this, msg);
/*      */         } else {
/*  444 */           ((ChannelInboundHandler)handler).channelRead(this, msg);
/*      */         } 
/*  446 */       } catch (Throwable t) {
/*  447 */         invokeExceptionCaught(t);
/*      */       } 
/*      */     } else {
/*  450 */       fireChannelRead(msg);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public ChannelHandlerContext fireChannelReadComplete() {
/*  456 */     invokeChannelReadComplete(findContextInbound(64));
/*  457 */     return this;
/*      */   }
/*      */   
/*      */   static void invokeChannelReadComplete(AbstractChannelHandlerContext next) {
/*  461 */     EventExecutor executor = next.executor();
/*  462 */     if (executor.inEventLoop()) {
/*  463 */       next.invokeChannelReadComplete();
/*      */     } else {
/*  465 */       Tasks tasks = next.invokeTasks;
/*  466 */       if (tasks == null) {
/*  467 */         next.invokeTasks = tasks = new Tasks(next);
/*      */       }
/*  469 */       executor.execute(tasks.invokeChannelReadCompleteTask);
/*      */     } 
/*      */   }
/*      */   
/*      */   private void invokeChannelReadComplete() {
/*  474 */     if (invokeHandler()) {
/*      */ 
/*      */       
/*      */       try {
/*      */         
/*  479 */         ChannelHandler handler = handler();
/*  480 */         DefaultChannelPipeline.HeadContext headContext = this.pipeline.head;
/*  481 */         if (handler == headContext) {
/*  482 */           headContext.channelReadComplete(this);
/*  483 */         } else if (handler instanceof ChannelDuplexHandler) {
/*  484 */           ((ChannelDuplexHandler)handler).channelReadComplete(this);
/*      */         } else {
/*  486 */           ((ChannelInboundHandler)handler).channelReadComplete(this);
/*      */         } 
/*  488 */       } catch (Throwable t) {
/*  489 */         invokeExceptionCaught(t);
/*      */       } 
/*      */     } else {
/*  492 */       fireChannelReadComplete();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public ChannelHandlerContext fireChannelWritabilityChanged() {
/*  498 */     invokeChannelWritabilityChanged(findContextInbound(256));
/*  499 */     return this;
/*      */   }
/*      */   
/*      */   static void invokeChannelWritabilityChanged(AbstractChannelHandlerContext next) {
/*  503 */     EventExecutor executor = next.executor();
/*  504 */     if (executor.inEventLoop()) {
/*  505 */       next.invokeChannelWritabilityChanged();
/*      */     } else {
/*  507 */       Tasks tasks = next.invokeTasks;
/*  508 */       if (tasks == null) {
/*  509 */         next.invokeTasks = tasks = new Tasks(next);
/*      */       }
/*  511 */       executor.execute(tasks.invokeChannelWritableStateChangedTask);
/*      */     } 
/*      */   }
/*      */   
/*      */   private void invokeChannelWritabilityChanged() {
/*  516 */     if (invokeHandler()) {
/*      */ 
/*      */       
/*      */       try {
/*      */         
/*  521 */         ChannelHandler handler = handler();
/*  522 */         DefaultChannelPipeline.HeadContext headContext = this.pipeline.head;
/*  523 */         if (handler == headContext) {
/*  524 */           headContext.channelWritabilityChanged(this);
/*  525 */         } else if (handler instanceof ChannelDuplexHandler) {
/*  526 */           ((ChannelDuplexHandler)handler).channelWritabilityChanged(this);
/*      */         } else {
/*  528 */           ((ChannelInboundHandler)handler).channelWritabilityChanged(this);
/*      */         } 
/*  530 */       } catch (Throwable t) {
/*  531 */         invokeExceptionCaught(t);
/*      */       } 
/*      */     } else {
/*  534 */       fireChannelWritabilityChanged();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public ChannelFuture bind(SocketAddress localAddress) {
/*  540 */     return bind(localAddress, newPromise());
/*      */   }
/*      */ 
/*      */   
/*      */   public ChannelFuture connect(SocketAddress remoteAddress) {
/*  545 */     return connect(remoteAddress, newPromise());
/*      */   }
/*      */ 
/*      */   
/*      */   public ChannelFuture connect(SocketAddress remoteAddress, SocketAddress localAddress) {
/*  550 */     return connect(remoteAddress, localAddress, newPromise());
/*      */   }
/*      */ 
/*      */   
/*      */   public ChannelFuture disconnect() {
/*  555 */     return disconnect(newPromise());
/*      */   }
/*      */ 
/*      */   
/*      */   public ChannelFuture close() {
/*  560 */     return close(newPromise());
/*      */   }
/*      */ 
/*      */   
/*      */   public ChannelFuture deregister() {
/*  565 */     return deregister(newPromise());
/*      */   }
/*      */ 
/*      */   
/*      */   public ChannelFuture bind(final SocketAddress localAddress, final ChannelPromise promise) {
/*  570 */     ObjectUtil.checkNotNull(localAddress, "localAddress");
/*  571 */     if (isNotValidPromise(promise, false))
/*      */     {
/*  573 */       return promise;
/*      */     }
/*      */     
/*  576 */     final AbstractChannelHandlerContext next = findContextOutbound(512);
/*  577 */     EventExecutor executor = next.executor();
/*  578 */     if (executor.inEventLoop()) {
/*  579 */       next.invokeBind(localAddress, promise);
/*      */     } else {
/*  581 */       safeExecute(executor, new Runnable()
/*      */           {
/*      */             public void run() {
/*  584 */               next.invokeBind(localAddress, promise);
/*      */             }
/*      */           }promise, null, false);
/*      */     } 
/*  588 */     return promise;
/*      */   }
/*      */   
/*      */   private void invokeBind(SocketAddress localAddress, ChannelPromise promise) {
/*  592 */     if (invokeHandler()) {
/*      */ 
/*      */       
/*      */       try {
/*      */         
/*  597 */         ChannelHandler handler = handler();
/*  598 */         DefaultChannelPipeline.HeadContext headContext = this.pipeline.head;
/*  599 */         if (handler == headContext) {
/*  600 */           headContext.bind(this, localAddress, promise);
/*  601 */         } else if (handler instanceof ChannelDuplexHandler) {
/*  602 */           ((ChannelDuplexHandler)handler).bind(this, localAddress, promise);
/*      */         } else {
/*  604 */           ((ChannelOutboundHandler)handler).bind(this, localAddress, promise);
/*      */         } 
/*  606 */       } catch (Throwable t) {
/*  607 */         notifyOutboundHandlerException(t, promise);
/*      */       } 
/*      */     } else {
/*  610 */       bind(localAddress, promise);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public ChannelFuture connect(SocketAddress remoteAddress, ChannelPromise promise) {
/*  616 */     return connect(remoteAddress, null, promise);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ChannelFuture connect(final SocketAddress remoteAddress, final SocketAddress localAddress, final ChannelPromise promise) {
/*  622 */     ObjectUtil.checkNotNull(remoteAddress, "remoteAddress");
/*      */     
/*  624 */     if (isNotValidPromise(promise, false))
/*      */     {
/*  626 */       return promise;
/*      */     }
/*      */     
/*  629 */     final AbstractChannelHandlerContext next = findContextOutbound(1024);
/*  630 */     EventExecutor executor = next.executor();
/*  631 */     if (executor.inEventLoop()) {
/*  632 */       next.invokeConnect(remoteAddress, localAddress, promise);
/*      */     } else {
/*  634 */       safeExecute(executor, new Runnable()
/*      */           {
/*      */             public void run() {
/*  637 */               next.invokeConnect(remoteAddress, localAddress, promise);
/*      */             }
/*      */           }promise, null, false);
/*      */     } 
/*  641 */     return promise;
/*      */   }
/*      */   
/*      */   private void invokeConnect(SocketAddress remoteAddress, SocketAddress localAddress, ChannelPromise promise) {
/*  645 */     if (invokeHandler()) {
/*      */ 
/*      */       
/*      */       try {
/*      */         
/*  650 */         ChannelHandler handler = handler();
/*  651 */         DefaultChannelPipeline.HeadContext headContext = this.pipeline.head;
/*  652 */         if (handler == headContext) {
/*  653 */           headContext.connect(this, remoteAddress, localAddress, promise);
/*  654 */         } else if (handler instanceof ChannelDuplexHandler) {
/*  655 */           ((ChannelDuplexHandler)handler).connect(this, remoteAddress, localAddress, promise);
/*      */         } else {
/*  657 */           ((ChannelOutboundHandler)handler).connect(this, remoteAddress, localAddress, promise);
/*      */         } 
/*  659 */       } catch (Throwable t) {
/*  660 */         notifyOutboundHandlerException(t, promise);
/*      */       } 
/*      */     } else {
/*  663 */       connect(remoteAddress, localAddress, promise);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public ChannelFuture disconnect(final ChannelPromise promise) {
/*  669 */     if (!channel().metadata().hasDisconnect())
/*      */     {
/*      */       
/*  672 */       return close(promise);
/*      */     }
/*  674 */     if (isNotValidPromise(promise, false))
/*      */     {
/*  676 */       return promise;
/*      */     }
/*      */     
/*  679 */     final AbstractChannelHandlerContext next = findContextOutbound(2048);
/*  680 */     EventExecutor executor = next.executor();
/*  681 */     if (executor.inEventLoop()) {
/*  682 */       next.invokeDisconnect(promise);
/*      */     } else {
/*  684 */       safeExecute(executor, new Runnable()
/*      */           {
/*      */             public void run() {
/*  687 */               next.invokeDisconnect(promise);
/*      */             }
/*      */           },  promise, null, false);
/*      */     } 
/*  691 */     return promise;
/*      */   }
/*      */   
/*      */   private void invokeDisconnect(ChannelPromise promise) {
/*  695 */     if (invokeHandler()) {
/*      */ 
/*      */       
/*      */       try {
/*      */         
/*  700 */         ChannelHandler handler = handler();
/*  701 */         DefaultChannelPipeline.HeadContext headContext = this.pipeline.head;
/*  702 */         if (handler == headContext) {
/*  703 */           headContext.disconnect(this, promise);
/*  704 */         } else if (handler instanceof ChannelDuplexHandler) {
/*  705 */           ((ChannelDuplexHandler)handler).disconnect(this, promise);
/*      */         } else {
/*  707 */           ((ChannelOutboundHandler)handler).disconnect(this, promise);
/*      */         } 
/*  709 */       } catch (Throwable t) {
/*  710 */         notifyOutboundHandlerException(t, promise);
/*      */       } 
/*      */     } else {
/*  713 */       disconnect(promise);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public ChannelFuture close(final ChannelPromise promise) {
/*  719 */     if (isNotValidPromise(promise, false))
/*      */     {
/*  721 */       return promise;
/*      */     }
/*      */     
/*  724 */     final AbstractChannelHandlerContext next = findContextOutbound(4096);
/*  725 */     EventExecutor executor = next.executor();
/*  726 */     if (executor.inEventLoop()) {
/*  727 */       next.invokeClose(promise);
/*      */     } else {
/*  729 */       safeExecute(executor, new Runnable()
/*      */           {
/*      */             public void run() {
/*  732 */               next.invokeClose(promise);
/*      */             }
/*      */           },  promise, null, false);
/*      */     } 
/*      */     
/*  737 */     return promise;
/*      */   }
/*      */   
/*      */   private void invokeClose(ChannelPromise promise) {
/*  741 */     if (invokeHandler()) {
/*      */ 
/*      */       
/*      */       try {
/*      */         
/*  746 */         ChannelHandler handler = handler();
/*  747 */         DefaultChannelPipeline.HeadContext headContext = this.pipeline.head;
/*  748 */         if (handler == headContext) {
/*  749 */           headContext.close(this, promise);
/*  750 */         } else if (handler instanceof ChannelDuplexHandler) {
/*  751 */           ((ChannelDuplexHandler)handler).close(this, promise);
/*      */         } else {
/*  753 */           ((ChannelOutboundHandler)handler).close(this, promise);
/*      */         } 
/*  755 */       } catch (Throwable t) {
/*  756 */         notifyOutboundHandlerException(t, promise);
/*      */       } 
/*      */     } else {
/*  759 */       close(promise);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public ChannelFuture deregister(final ChannelPromise promise) {
/*  765 */     if (isNotValidPromise(promise, false))
/*      */     {
/*  767 */       return promise;
/*      */     }
/*      */     
/*  770 */     final AbstractChannelHandlerContext next = findContextOutbound(8192);
/*  771 */     EventExecutor executor = next.executor();
/*  772 */     if (executor.inEventLoop()) {
/*  773 */       next.invokeDeregister(promise);
/*      */     } else {
/*  775 */       safeExecute(executor, new Runnable()
/*      */           {
/*      */             public void run() {
/*  778 */               next.invokeDeregister(promise);
/*      */             }
/*      */           },  promise, null, false);
/*      */     } 
/*      */     
/*  783 */     return promise;
/*      */   }
/*      */   
/*      */   private void invokeDeregister(ChannelPromise promise) {
/*  787 */     if (invokeHandler()) {
/*      */ 
/*      */       
/*      */       try {
/*      */         
/*  792 */         ChannelHandler handler = handler();
/*  793 */         DefaultChannelPipeline.HeadContext headContext = this.pipeline.head;
/*  794 */         if (handler == headContext) {
/*  795 */           headContext.deregister(this, promise);
/*  796 */         } else if (handler instanceof ChannelDuplexHandler) {
/*  797 */           ((ChannelDuplexHandler)handler).deregister(this, promise);
/*      */         } else {
/*  799 */           ((ChannelOutboundHandler)handler).deregister(this, promise);
/*      */         } 
/*  801 */       } catch (Throwable t) {
/*  802 */         notifyOutboundHandlerException(t, promise);
/*      */       } 
/*      */     } else {
/*  805 */       deregister(promise);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public ChannelHandlerContext read() {
/*  811 */     AbstractChannelHandlerContext next = findContextOutbound(16384);
/*  812 */     EventExecutor executor = next.executor();
/*  813 */     if (executor.inEventLoop()) {
/*  814 */       next.invokeRead();
/*      */     } else {
/*  816 */       Tasks tasks = next.invokeTasks;
/*  817 */       if (tasks == null) {
/*  818 */         next.invokeTasks = tasks = new Tasks(next);
/*      */       }
/*  820 */       executor.execute(tasks.invokeReadTask);
/*      */     } 
/*      */     
/*  823 */     return this;
/*      */   }
/*      */   
/*      */   private void invokeRead() {
/*  827 */     if (invokeHandler()) {
/*      */ 
/*      */       
/*      */       try {
/*      */         
/*  832 */         ChannelHandler handler = handler();
/*  833 */         DefaultChannelPipeline.HeadContext headContext = this.pipeline.head;
/*  834 */         if (handler == headContext) {
/*  835 */           headContext.read(this);
/*  836 */         } else if (handler instanceof ChannelDuplexHandler) {
/*  837 */           ((ChannelDuplexHandler)handler).read(this);
/*      */         } else {
/*  839 */           ((ChannelOutboundHandler)handler).read(this);
/*      */         } 
/*  841 */       } catch (Throwable t) {
/*  842 */         invokeExceptionCaught(t);
/*      */       } 
/*      */     } else {
/*  845 */       read();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public ChannelFuture write(Object msg) {
/*  851 */     return write(msg, newPromise());
/*      */   }
/*      */ 
/*      */   
/*      */   public ChannelFuture write(Object msg, ChannelPromise promise) {
/*  856 */     write(msg, false, promise);
/*      */     
/*  858 */     return promise;
/*      */   }
/*      */   
/*      */   void invokeWrite(Object msg, ChannelPromise promise) {
/*  862 */     if (invokeHandler()) {
/*  863 */       invokeWrite0(msg, promise);
/*      */     } else {
/*  865 */       write(msg, promise);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void invokeWrite0(Object msg, ChannelPromise promise) {
/*      */     try {
/*  874 */       ChannelHandler handler = handler();
/*  875 */       DefaultChannelPipeline.HeadContext headContext = this.pipeline.head;
/*  876 */       if (handler == headContext) {
/*  877 */         headContext.write(this, msg, promise);
/*  878 */       } else if (handler instanceof ChannelDuplexHandler) {
/*  879 */         ((ChannelDuplexHandler)handler).write(this, msg, promise);
/*      */       } else {
/*  881 */         ((ChannelOutboundHandler)handler).write(this, msg, promise);
/*      */       } 
/*  883 */     } catch (Throwable t) {
/*  884 */       notifyOutboundHandlerException(t, promise);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public ChannelHandlerContext flush() {
/*  890 */     AbstractChannelHandlerContext next = findContextOutbound(65536);
/*  891 */     EventExecutor executor = next.executor();
/*  892 */     if (executor.inEventLoop()) {
/*  893 */       next.invokeFlush();
/*      */     } else {
/*  895 */       Tasks tasks = next.invokeTasks;
/*  896 */       if (tasks == null) {
/*  897 */         next.invokeTasks = tasks = new Tasks(next);
/*      */       }
/*  899 */       safeExecute(executor, tasks.invokeFlushTask, channel().voidPromise(), null, false);
/*      */     } 
/*      */     
/*  902 */     return this;
/*      */   }
/*      */   
/*      */   private void invokeFlush() {
/*  906 */     if (invokeHandler()) {
/*  907 */       invokeFlush0();
/*      */     } else {
/*  909 */       flush();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void invokeFlush0() {
/*      */     try {
/*  918 */       ChannelHandler handler = handler();
/*  919 */       DefaultChannelPipeline.HeadContext headContext = this.pipeline.head;
/*  920 */       if (handler == headContext) {
/*  921 */         headContext.flush(this);
/*  922 */       } else if (handler instanceof ChannelDuplexHandler) {
/*  923 */         ((ChannelDuplexHandler)handler).flush(this);
/*      */       } else {
/*  925 */         ((ChannelOutboundHandler)handler).flush(this);
/*      */       } 
/*  927 */     } catch (Throwable t) {
/*  928 */       invokeExceptionCaught(t);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public ChannelFuture writeAndFlush(Object msg, ChannelPromise promise) {
/*  934 */     write(msg, true, promise);
/*  935 */     return promise;
/*      */   }
/*      */   
/*      */   void invokeWriteAndFlush(Object msg, ChannelPromise promise) {
/*  939 */     if (invokeHandler()) {
/*  940 */       invokeWrite0(msg, promise);
/*  941 */       invokeFlush0();
/*      */     } else {
/*  943 */       writeAndFlush(msg, promise);
/*      */     } 
/*      */   }
/*      */   
/*      */   private void write(Object msg, boolean flush, ChannelPromise promise) {
/*  948 */     ObjectUtil.checkNotNull(msg, "msg");
/*      */     try {
/*  950 */       if (isNotValidPromise(promise, true)) {
/*  951 */         ReferenceCountUtil.release(msg);
/*      */         
/*      */         return;
/*      */       } 
/*  955 */     } catch (RuntimeException e) {
/*  956 */       ReferenceCountUtil.release(msg);
/*  957 */       throw e;
/*      */     } 
/*      */     
/*  960 */     AbstractChannelHandlerContext next = findContextOutbound(flush ? 98304 : 32768);
/*      */     
/*  962 */     Object m = this.pipeline.touch(msg, next);
/*  963 */     EventExecutor executor = next.executor();
/*  964 */     if (executor.inEventLoop()) {
/*  965 */       if (flush) {
/*  966 */         next.invokeWriteAndFlush(m, promise);
/*      */       } else {
/*  968 */         next.invokeWrite(m, promise);
/*      */       } 
/*      */     } else {
/*  971 */       WriteTask task = WriteTask.newInstance(next, m, promise, flush);
/*  972 */       if (!safeExecute(executor, task, promise, m, !flush))
/*      */       {
/*      */ 
/*      */ 
/*      */         
/*  977 */         task.cancel();
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public ChannelFuture writeAndFlush(Object msg) {
/*  984 */     return writeAndFlush(msg, newPromise());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static void notifyOutboundHandlerException(Throwable cause, ChannelPromise promise) {
/*  990 */     PromiseNotificationUtil.tryFailure(promise, cause, (promise instanceof VoidChannelPromise) ? null : logger);
/*      */   }
/*      */ 
/*      */   
/*      */   public ChannelPromise newPromise() {
/*  995 */     return new DefaultChannelPromise(channel(), executor());
/*      */   }
/*      */ 
/*      */   
/*      */   public ChannelProgressivePromise newProgressivePromise() {
/* 1000 */     return new DefaultChannelProgressivePromise(channel(), executor());
/*      */   }
/*      */ 
/*      */   
/*      */   public ChannelFuture newSucceededFuture() {
/* 1005 */     ChannelFuture succeededFuture = this.succeededFuture;
/* 1006 */     if (succeededFuture == null) {
/* 1007 */       this.succeededFuture = succeededFuture = new SucceededChannelFuture(channel(), executor());
/*      */     }
/* 1009 */     return succeededFuture;
/*      */   }
/*      */ 
/*      */   
/*      */   public ChannelFuture newFailedFuture(Throwable cause) {
/* 1014 */     return new FailedChannelFuture(channel(), executor(), cause);
/*      */   }
/*      */   
/*      */   private boolean isNotValidPromise(ChannelPromise promise, boolean allowVoidPromise) {
/* 1018 */     ObjectUtil.checkNotNull(promise, "promise");
/*      */     
/* 1020 */     if (promise.isDone()) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1025 */       if (promise.isCancelled()) {
/* 1026 */         return true;
/*      */       }
/* 1028 */       throw new IllegalArgumentException("promise already done: " + promise);
/*      */     } 
/*      */     
/* 1031 */     if (promise.channel() != channel()) {
/* 1032 */       throw new IllegalArgumentException(String.format("promise.channel does not match: %s (expected: %s)", new Object[] { promise
/* 1033 */               .channel(), channel() }));
/*      */     }
/*      */     
/* 1036 */     if (promise.getClass() == DefaultChannelPromise.class) {
/* 1037 */       return false;
/*      */     }
/*      */     
/* 1040 */     if (!allowVoidPromise && promise instanceof VoidChannelPromise) {
/* 1041 */       throw new IllegalArgumentException(
/* 1042 */           StringUtil.simpleClassName(VoidChannelPromise.class) + " not allowed for this operation");
/*      */     }
/*      */     
/* 1045 */     if (promise instanceof AbstractChannel.CloseFuture) {
/* 1046 */       throw new IllegalArgumentException(
/* 1047 */           StringUtil.simpleClassName(AbstractChannel.CloseFuture.class) + " not allowed in a pipeline");
/*      */     }
/* 1049 */     return false;
/*      */   }
/*      */   
/*      */   private AbstractChannelHandlerContext findContextInbound(int mask) {
/* 1053 */     AbstractChannelHandlerContext ctx = this;
/* 1054 */     EventExecutor currentExecutor = executor();
/*      */     while (true) {
/* 1056 */       ctx = ctx.next;
/* 1057 */       if (!skipContext(ctx, currentExecutor, mask, 510))
/* 1058 */         return ctx; 
/*      */     } 
/*      */   }
/*      */   private AbstractChannelHandlerContext findContextOutbound(int mask) {
/* 1062 */     AbstractChannelHandlerContext ctx = this;
/* 1063 */     EventExecutor currentExecutor = executor();
/*      */     while (true) {
/* 1065 */       ctx = ctx.prev;
/* 1066 */       if (!skipContext(ctx, currentExecutor, mask, 130560)) {
/* 1067 */         return ctx;
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   private static boolean skipContext(AbstractChannelHandlerContext ctx, EventExecutor currentExecutor, int mask, int onlyMask) {
/* 1073 */     return ((ctx.executionMask & (onlyMask | mask)) == 0 || (ctx
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1078 */       .executor() == currentExecutor && (ctx.executionMask & mask) == 0));
/*      */   }
/*      */ 
/*      */   
/*      */   public ChannelPromise voidPromise() {
/* 1083 */     return channel().voidPromise();
/*      */   }
/*      */   
/*      */   final void setRemoved() {
/* 1087 */     this.handlerState = 3;
/*      */   }
/*      */   
/*      */   final boolean setAddComplete() {
/*      */     while (true) {
/* 1092 */       int oldState = this.handlerState;
/* 1093 */       if (oldState == 3) {
/* 1094 */         return false;
/*      */       }
/*      */ 
/*      */ 
/*      */       
/* 1099 */       if (HANDLER_STATE_UPDATER.compareAndSet(this, oldState, 2)) {
/* 1100 */         return true;
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   final void setAddPending() {
/* 1106 */     boolean updated = HANDLER_STATE_UPDATER.compareAndSet(this, 0, 1);
/* 1107 */     assert updated;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   final void callHandlerAdded() throws Exception {
/* 1113 */     if (setAddComplete()) {
/* 1114 */       handler().handlerAdded(this);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   final void callHandlerRemoved() throws Exception {
/*      */     try {
/* 1121 */       if (this.handlerState == 2) {
/* 1122 */         handler().handlerRemoved(this);
/*      */       }
/*      */     } finally {
/*      */       
/* 1126 */       setRemoved();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean invokeHandler() {
/* 1140 */     int handlerState = this.handlerState;
/* 1141 */     return (handlerState == 2 || (!this.ordered && handlerState == 1));
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isRemoved() {
/* 1146 */     return (this.handlerState == 3);
/*      */   }
/*      */ 
/*      */   
/*      */   public <T> Attribute<T> attr(AttributeKey<T> key) {
/* 1151 */     return channel().attr(key);
/*      */   }
/*      */ 
/*      */   
/*      */   public <T> boolean hasAttr(AttributeKey<T> key) {
/* 1156 */     return channel().hasAttr(key);
/*      */   }
/*      */ 
/*      */   
/*      */   private static boolean safeExecute(EventExecutor executor, Runnable runnable, ChannelPromise promise, Object msg, boolean lazy) {
/*      */     try {
/* 1162 */       if (lazy && executor instanceof AbstractEventExecutor) {
/* 1163 */         ((AbstractEventExecutor)executor).lazyExecute(runnable);
/*      */       } else {
/* 1165 */         executor.execute(runnable);
/*      */       } 
/* 1167 */       return true;
/* 1168 */     } catch (Throwable cause) {
/*      */       try {
/* 1170 */         if (msg != null) {
/* 1171 */           ReferenceCountUtil.release(msg);
/*      */         }
/*      */       } finally {
/* 1174 */         promise.setFailure(cause);
/*      */       } 
/* 1176 */       return false;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public String toHintString() {
/* 1182 */     return '\'' + this.name + "' will handle the message from this point.";
/*      */   }
/*      */ 
/*      */   
/*      */   public String toString() {
/* 1187 */     return StringUtil.simpleClassName(ChannelHandlerContext.class) + '(' + this.name + ", " + channel() + ')';
/*      */   }
/*      */   
/*      */   static final class WriteTask implements Runnable {
/* 1191 */     private static final ObjectPool<WriteTask> RECYCLER = ObjectPool.newPool(new ObjectPool.ObjectCreator<WriteTask>()
/*      */         {
/*      */           public AbstractChannelHandlerContext.WriteTask newObject(ObjectPool.Handle<AbstractChannelHandlerContext.WriteTask> handle) {
/* 1194 */             return new AbstractChannelHandlerContext.WriteTask(handle);
/*      */           }
/*      */         });
/*      */ 
/*      */     
/*      */     static WriteTask newInstance(AbstractChannelHandlerContext ctx, Object msg, ChannelPromise promise, boolean flush) {
/* 1200 */       WriteTask task = (WriteTask)RECYCLER.get();
/* 1201 */       init(task, ctx, msg, promise, flush);
/* 1202 */       return task;
/*      */     }
/*      */ 
/*      */     
/* 1206 */     private static final boolean ESTIMATE_TASK_SIZE_ON_SUBMIT = SystemPropertyUtil.getBoolean("io.netty.transport.estimateSizeOnSubmit", true);
/*      */ 
/*      */ 
/*      */     
/* 1210 */     private static final int WRITE_TASK_OVERHEAD = SystemPropertyUtil.getInt("io.netty.transport.writeTaskSizeOverhead", 32);
/*      */     
/*      */     private final ObjectPool.Handle<WriteTask> handle;
/*      */     
/*      */     private AbstractChannelHandlerContext ctx;
/*      */     private Object msg;
/*      */     private ChannelPromise promise;
/*      */     private int size;
/*      */     
/*      */     private WriteTask(ObjectPool.Handle<? extends WriteTask> handle) {
/* 1220 */       this.handle = (ObjectPool.Handle)handle;
/*      */     }
/*      */ 
/*      */     
/*      */     protected static void init(WriteTask task, AbstractChannelHandlerContext ctx, Object msg, ChannelPromise promise, boolean flush) {
/* 1225 */       task.ctx = ctx;
/* 1226 */       task.msg = msg;
/* 1227 */       task.promise = promise;
/*      */       
/* 1229 */       if (ESTIMATE_TASK_SIZE_ON_SUBMIT) {
/* 1230 */         task.size = ctx.pipeline.estimatorHandle().size(msg) + WRITE_TASK_OVERHEAD;
/* 1231 */         ctx.pipeline.incrementPendingOutboundBytes(task.size);
/*      */       } else {
/* 1233 */         task.size = 0;
/*      */       } 
/* 1235 */       if (flush) {
/* 1236 */         task.size |= Integer.MIN_VALUE;
/*      */       }
/*      */     }
/*      */ 
/*      */     
/*      */     public void run() {
/*      */       try {
/* 1243 */         decrementPendingOutboundBytes();
/* 1244 */         if (this.size >= 0) {
/* 1245 */           this.ctx.invokeWrite(this.msg, this.promise);
/*      */         } else {
/* 1247 */           this.ctx.invokeWriteAndFlush(this.msg, this.promise);
/*      */         } 
/*      */       } finally {
/* 1250 */         recycle();
/*      */       } 
/*      */     }
/*      */     
/*      */     void cancel() {
/*      */       try {
/* 1256 */         decrementPendingOutboundBytes();
/*      */       } finally {
/* 1258 */         recycle();
/*      */       } 
/*      */     }
/*      */     
/*      */     private void decrementPendingOutboundBytes() {
/* 1263 */       if (ESTIMATE_TASK_SIZE_ON_SUBMIT) {
/* 1264 */         this.ctx.pipeline.decrementPendingOutboundBytes((this.size & Integer.MAX_VALUE));
/*      */       }
/*      */     }
/*      */ 
/*      */     
/*      */     private void recycle() {
/* 1270 */       this.ctx = null;
/* 1271 */       this.msg = null;
/* 1272 */       this.promise = null;
/* 1273 */       this.handle.recycle(this);
/*      */     } }
/*      */   
/*      */   private static final class Tasks {
/*      */     private final AbstractChannelHandlerContext next;
/*      */     
/* 1279 */     private final Runnable invokeChannelReadCompleteTask = new Runnable()
/*      */       {
/*      */         public void run() {
/* 1282 */           AbstractChannelHandlerContext.Tasks.this.next.invokeChannelReadComplete();
/*      */         }
/*      */       };
/* 1285 */     private final Runnable invokeReadTask = new Runnable()
/*      */       {
/*      */         public void run() {
/* 1288 */           AbstractChannelHandlerContext.Tasks.this.next.invokeRead();
/*      */         }
/*      */       };
/* 1291 */     private final Runnable invokeChannelWritableStateChangedTask = new Runnable()
/*      */       {
/*      */         public void run() {
/* 1294 */           AbstractChannelHandlerContext.Tasks.this.next.invokeChannelWritabilityChanged();
/*      */         }
/*      */       };
/* 1297 */     private final Runnable invokeFlushTask = new Runnable()
/*      */       {
/*      */         public void run() {
/* 1300 */           AbstractChannelHandlerContext.Tasks.this.next.invokeFlush();
/*      */         }
/*      */       };
/*      */     
/*      */     Tasks(AbstractChannelHandlerContext next) {
/* 1305 */       this.next = next;
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-transport-4.1.93.Final.jar!\io\netty\channel\AbstractChannelHandlerContext.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */