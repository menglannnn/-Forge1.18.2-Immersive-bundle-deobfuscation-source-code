/*    */ package io.netty.channel;
/*    */ 
/*    */ import io.netty.util.concurrent.EventExecutor;
/*    */ import io.netty.util.concurrent.Future;
/*    */ import io.netty.util.internal.ObjectUtil;
/*    */ import io.netty.util.internal.PlatformDependent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class FailedChannelFuture
/*    */   extends CompleteChannelFuture
/*    */ {
/*    */   private final Throwable cause;
/*    */   
/*    */   FailedChannelFuture(Channel channel, EventExecutor executor, Throwable cause) {
/* 38 */     super(channel, executor);
/* 39 */     this.cause = (Throwable)ObjectUtil.checkNotNull(cause, "cause");
/*    */   }
/*    */ 
/*    */   
/*    */   public Throwable cause() {
/* 44 */     return this.cause;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isSuccess() {
/* 49 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public ChannelFuture sync() {
/* 54 */     PlatformDependent.throwException(this.cause);
/* 55 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public ChannelFuture syncUninterruptibly() {
/* 60 */     PlatformDependent.throwException(this.cause);
/* 61 */     return this;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-transport-4.1.93.Final.jar!\io\netty\channel\FailedChannelFuture.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */