/*      */ package io.netty.channel;
/*      */ 
/*      */ import io.netty.buffer.ByteBufAllocator;
/*      */ import io.netty.channel.socket.ChannelOutputShutdownEvent;
/*      */ import io.netty.channel.socket.ChannelOutputShutdownException;
/*      */ import io.netty.util.DefaultAttributeMap;
/*      */ import io.netty.util.ReferenceCountUtil;
/*      */ import io.netty.util.concurrent.Future;
/*      */ import io.netty.util.concurrent.Promise;
/*      */ import io.netty.util.internal.ObjectUtil;
/*      */ import io.netty.util.internal.PlatformDependent;
/*      */ import io.netty.util.internal.logging.InternalLogger;
/*      */ import io.netty.util.internal.logging.InternalLoggerFactory;
/*      */ import java.io.IOException;
/*      */ import java.net.ConnectException;
/*      */ import java.net.InetSocketAddress;
/*      */ import java.net.NoRouteToHostException;
/*      */ import java.net.SocketAddress;
/*      */ import java.net.SocketException;
/*      */ import java.nio.channels.ClosedChannelException;
/*      */ import java.nio.channels.NotYetConnectedException;
/*      */ import java.util.concurrent.Executor;
/*      */ import java.util.concurrent.RejectedExecutionException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class AbstractChannel
/*      */   extends DefaultAttributeMap
/*      */   implements Channel
/*      */ {
/*   45 */   private static final InternalLogger logger = InternalLoggerFactory.getInstance(AbstractChannel.class);
/*      */   
/*      */   private final Channel parent;
/*      */   private final ChannelId id;
/*      */   private final Channel.Unsafe unsafe;
/*      */   private final DefaultChannelPipeline pipeline;
/*   51 */   private final VoidChannelPromise unsafeVoidPromise = new VoidChannelPromise(this, false);
/*   52 */   private final CloseFuture closeFuture = new CloseFuture(this);
/*      */   
/*      */   private volatile SocketAddress localAddress;
/*      */   
/*      */   private volatile SocketAddress remoteAddress;
/*      */   
/*      */   private volatile EventLoop eventLoop;
/*      */   
/*      */   private volatile boolean registered;
/*      */   
/*      */   private boolean closeInitiated;
/*      */   
/*      */   private Throwable initialCloseCause;
/*      */   
/*      */   private boolean strValActive;
/*      */   
/*      */   private String strVal;
/*      */ 
/*      */   
/*      */   protected AbstractChannel(Channel parent) {
/*   72 */     this.parent = parent;
/*   73 */     this.id = newId();
/*   74 */     this.unsafe = newUnsafe();
/*   75 */     this.pipeline = newChannelPipeline();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected AbstractChannel(Channel parent, ChannelId id) {
/*   85 */     this.parent = parent;
/*   86 */     this.id = id;
/*   87 */     this.unsafe = newUnsafe();
/*   88 */     this.pipeline = newChannelPipeline();
/*      */   }
/*      */   
/*      */   protected final int maxMessagesPerWrite() {
/*   92 */     ChannelConfig config = config();
/*   93 */     if (config instanceof DefaultChannelConfig) {
/*   94 */       return ((DefaultChannelConfig)config).getMaxMessagesPerWrite();
/*      */     }
/*   96 */     Integer value = config.<Integer>getOption(ChannelOption.MAX_MESSAGES_PER_WRITE);
/*   97 */     if (value == null) {
/*   98 */       return Integer.MAX_VALUE;
/*      */     }
/*  100 */     return value.intValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public final ChannelId id() {
/*  105 */     return this.id;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ChannelId newId() {
/*  113 */     return DefaultChannelId.newInstance();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected DefaultChannelPipeline newChannelPipeline() {
/*  120 */     return new DefaultChannelPipeline(this);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isWritable() {
/*  125 */     ChannelOutboundBuffer buf = this.unsafe.outboundBuffer();
/*  126 */     return (buf != null && buf.isWritable());
/*      */   }
/*      */ 
/*      */   
/*      */   public long bytesBeforeUnwritable() {
/*  131 */     ChannelOutboundBuffer buf = this.unsafe.outboundBuffer();
/*      */ 
/*      */     
/*  134 */     return (buf != null) ? buf.bytesBeforeUnwritable() : 0L;
/*      */   }
/*      */ 
/*      */   
/*      */   public long bytesBeforeWritable() {
/*  139 */     ChannelOutboundBuffer buf = this.unsafe.outboundBuffer();
/*      */ 
/*      */     
/*  142 */     return (buf != null) ? buf.bytesBeforeWritable() : Long.MAX_VALUE;
/*      */   }
/*      */ 
/*      */   
/*      */   public Channel parent() {
/*  147 */     return this.parent;
/*      */   }
/*      */ 
/*      */   
/*      */   public ChannelPipeline pipeline() {
/*  152 */     return this.pipeline;
/*      */   }
/*      */ 
/*      */   
/*      */   public ByteBufAllocator alloc() {
/*  157 */     return config().getAllocator();
/*      */   }
/*      */ 
/*      */   
/*      */   public EventLoop eventLoop() {
/*  162 */     EventLoop eventLoop = this.eventLoop;
/*  163 */     if (eventLoop == null) {
/*  164 */       throw new IllegalStateException("channel not registered to an event loop");
/*      */     }
/*  166 */     return eventLoop;
/*      */   }
/*      */ 
/*      */   
/*      */   public SocketAddress localAddress() {
/*  171 */     SocketAddress localAddress = this.localAddress;
/*  172 */     if (localAddress == null) {
/*      */       try {
/*  174 */         this.localAddress = localAddress = unsafe().localAddress();
/*  175 */       } catch (Error e) {
/*  176 */         throw e;
/*  177 */       } catch (Throwable t) {
/*      */         
/*  179 */         return null;
/*      */       } 
/*      */     }
/*  182 */     return localAddress;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   protected void invalidateLocalAddress() {
/*  190 */     this.localAddress = null;
/*      */   }
/*      */ 
/*      */   
/*      */   public SocketAddress remoteAddress() {
/*  195 */     SocketAddress remoteAddress = this.remoteAddress;
/*  196 */     if (remoteAddress == null) {
/*      */       try {
/*  198 */         this.remoteAddress = remoteAddress = unsafe().remoteAddress();
/*  199 */       } catch (Error e) {
/*  200 */         throw e;
/*  201 */       } catch (Throwable t) {
/*      */         
/*  203 */         return null;
/*      */       } 
/*      */     }
/*  206 */     return remoteAddress;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   protected void invalidateRemoteAddress() {
/*  214 */     this.remoteAddress = null;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isRegistered() {
/*  219 */     return this.registered;
/*      */   }
/*      */ 
/*      */   
/*      */   public ChannelFuture bind(SocketAddress localAddress) {
/*  224 */     return this.pipeline.bind(localAddress);
/*      */   }
/*      */ 
/*      */   
/*      */   public ChannelFuture connect(SocketAddress remoteAddress) {
/*  229 */     return this.pipeline.connect(remoteAddress);
/*      */   }
/*      */ 
/*      */   
/*      */   public ChannelFuture connect(SocketAddress remoteAddress, SocketAddress localAddress) {
/*  234 */     return this.pipeline.connect(remoteAddress, localAddress);
/*      */   }
/*      */ 
/*      */   
/*      */   public ChannelFuture disconnect() {
/*  239 */     return this.pipeline.disconnect();
/*      */   }
/*      */ 
/*      */   
/*      */   public ChannelFuture close() {
/*  244 */     return this.pipeline.close();
/*      */   }
/*      */ 
/*      */   
/*      */   public ChannelFuture deregister() {
/*  249 */     return this.pipeline.deregister();
/*      */   }
/*      */ 
/*      */   
/*      */   public Channel flush() {
/*  254 */     this.pipeline.flush();
/*  255 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public ChannelFuture bind(SocketAddress localAddress, ChannelPromise promise) {
/*  260 */     return this.pipeline.bind(localAddress, promise);
/*      */   }
/*      */ 
/*      */   
/*      */   public ChannelFuture connect(SocketAddress remoteAddress, ChannelPromise promise) {
/*  265 */     return this.pipeline.connect(remoteAddress, promise);
/*      */   }
/*      */ 
/*      */   
/*      */   public ChannelFuture connect(SocketAddress remoteAddress, SocketAddress localAddress, ChannelPromise promise) {
/*  270 */     return this.pipeline.connect(remoteAddress, localAddress, promise);
/*      */   }
/*      */ 
/*      */   
/*      */   public ChannelFuture disconnect(ChannelPromise promise) {
/*  275 */     return this.pipeline.disconnect(promise);
/*      */   }
/*      */ 
/*      */   
/*      */   public ChannelFuture close(ChannelPromise promise) {
/*  280 */     return this.pipeline.close(promise);
/*      */   }
/*      */ 
/*      */   
/*      */   public ChannelFuture deregister(ChannelPromise promise) {
/*  285 */     return this.pipeline.deregister(promise);
/*      */   }
/*      */ 
/*      */   
/*      */   public Channel read() {
/*  290 */     this.pipeline.read();
/*  291 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public ChannelFuture write(Object msg) {
/*  296 */     return this.pipeline.write(msg);
/*      */   }
/*      */ 
/*      */   
/*      */   public ChannelFuture write(Object msg, ChannelPromise promise) {
/*  301 */     return this.pipeline.write(msg, promise);
/*      */   }
/*      */ 
/*      */   
/*      */   public ChannelFuture writeAndFlush(Object msg) {
/*  306 */     return this.pipeline.writeAndFlush(msg);
/*      */   }
/*      */ 
/*      */   
/*      */   public ChannelFuture writeAndFlush(Object msg, ChannelPromise promise) {
/*  311 */     return this.pipeline.writeAndFlush(msg, promise);
/*      */   }
/*      */ 
/*      */   
/*      */   public ChannelPromise newPromise() {
/*  316 */     return this.pipeline.newPromise();
/*      */   }
/*      */ 
/*      */   
/*      */   public ChannelProgressivePromise newProgressivePromise() {
/*  321 */     return this.pipeline.newProgressivePromise();
/*      */   }
/*      */ 
/*      */   
/*      */   public ChannelFuture newSucceededFuture() {
/*  326 */     return this.pipeline.newSucceededFuture();
/*      */   }
/*      */ 
/*      */   
/*      */   public ChannelFuture newFailedFuture(Throwable cause) {
/*  331 */     return this.pipeline.newFailedFuture(cause);
/*      */   }
/*      */ 
/*      */   
/*      */   public ChannelFuture closeFuture() {
/*  336 */     return this.closeFuture;
/*      */   }
/*      */ 
/*      */   
/*      */   public Channel.Unsafe unsafe() {
/*  341 */     return this.unsafe;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int hashCode() {
/*  354 */     return this.id.hashCode();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean equals(Object o) {
/*  363 */     return (this == o);
/*      */   }
/*      */ 
/*      */   
/*      */   public final int compareTo(Channel o) {
/*  368 */     if (this == o) {
/*  369 */       return 0;
/*      */     }
/*      */     
/*  372 */     return id().compareTo(o.id());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/*  383 */     boolean active = isActive();
/*  384 */     if (this.strValActive == active && this.strVal != null) {
/*  385 */       return this.strVal;
/*      */     }
/*      */     
/*  388 */     SocketAddress remoteAddr = remoteAddress();
/*  389 */     SocketAddress localAddr = localAddress();
/*  390 */     if (remoteAddr != null) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  399 */       StringBuilder buf = (new StringBuilder(96)).append("[id: 0x").append(this.id.asShortText()).append(", L:").append(localAddr).append(active ? " - " : " ! ").append("R:").append(remoteAddr).append(']');
/*  400 */       this.strVal = buf.toString();
/*  401 */     } else if (localAddr != null) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  407 */       StringBuilder buf = (new StringBuilder(64)).append("[id: 0x").append(this.id.asShortText()).append(", L:").append(localAddr).append(']');
/*  408 */       this.strVal = buf.toString();
/*      */     
/*      */     }
/*      */     else {
/*      */       
/*  413 */       StringBuilder buf = (new StringBuilder(16)).append("[id: 0x").append(this.id.asShortText()).append(']');
/*  414 */       this.strVal = buf.toString();
/*      */     } 
/*      */     
/*  417 */     this.strValActive = active;
/*  418 */     return this.strVal;
/*      */   }
/*      */ 
/*      */   
/*      */   public final ChannelPromise voidPromise() {
/*  423 */     return this.pipeline.voidPromise();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected abstract class AbstractUnsafe
/*      */     implements Channel.Unsafe
/*      */   {
/*  431 */     private volatile ChannelOutboundBuffer outboundBuffer = new ChannelOutboundBuffer(AbstractChannel.this);
/*      */     
/*      */     private RecvByteBufAllocator.Handle recvHandle;
/*      */     private boolean inFlush0;
/*      */     private boolean neverRegistered = true;
/*      */     
/*      */     private void assertEventLoop() {
/*  438 */       assert !AbstractChannel.this.registered || AbstractChannel.this.eventLoop.inEventLoop();
/*      */     }
/*      */ 
/*      */     
/*      */     public RecvByteBufAllocator.Handle recvBufAllocHandle() {
/*  443 */       if (this.recvHandle == null) {
/*  444 */         this.recvHandle = AbstractChannel.this.config().<RecvByteBufAllocator>getRecvByteBufAllocator().newHandle();
/*      */       }
/*  446 */       return this.recvHandle;
/*      */     }
/*      */ 
/*      */     
/*      */     public final ChannelOutboundBuffer outboundBuffer() {
/*  451 */       return this.outboundBuffer;
/*      */     }
/*      */ 
/*      */     
/*      */     public final SocketAddress localAddress() {
/*  456 */       return AbstractChannel.this.localAddress0();
/*      */     }
/*      */ 
/*      */     
/*      */     public final SocketAddress remoteAddress() {
/*  461 */       return AbstractChannel.this.remoteAddress0();
/*      */     }
/*      */ 
/*      */     
/*      */     public final void register(EventLoop eventLoop, final ChannelPromise promise) {
/*  466 */       ObjectUtil.checkNotNull(eventLoop, "eventLoop");
/*  467 */       if (AbstractChannel.this.isRegistered()) {
/*  468 */         promise.setFailure(new IllegalStateException("registered to an event loop already"));
/*      */         return;
/*      */       } 
/*  471 */       if (!AbstractChannel.this.isCompatible(eventLoop)) {
/*  472 */         promise.setFailure(new IllegalStateException("incompatible event loop type: " + eventLoop
/*  473 */               .getClass().getName()));
/*      */         
/*      */         return;
/*      */       } 
/*  477 */       AbstractChannel.this.eventLoop = eventLoop;
/*      */       
/*  479 */       if (eventLoop.inEventLoop()) {
/*  480 */         register0(promise);
/*      */       } else {
/*      */         try {
/*  483 */           eventLoop.execute(new Runnable()
/*      */               {
/*      */                 public void run() {
/*  486 */                   AbstractChannel.AbstractUnsafe.this.register0(promise);
/*      */                 }
/*      */               });
/*  489 */         } catch (Throwable t) {
/*  490 */           AbstractChannel.logger.warn("Force-closing a channel whose registration task was not accepted by an event loop: {}", AbstractChannel.this, t);
/*      */ 
/*      */           
/*  493 */           closeForcibly();
/*  494 */           AbstractChannel.this.closeFuture.setClosed();
/*  495 */           safeSetFailure(promise, t);
/*      */         } 
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     private void register0(ChannelPromise promise) {
/*      */       try {
/*  504 */         if (!promise.setUncancellable() || !ensureOpen(promise)) {
/*      */           return;
/*      */         }
/*  507 */         boolean firstRegistration = this.neverRegistered;
/*  508 */         AbstractChannel.this.doRegister();
/*  509 */         this.neverRegistered = false;
/*  510 */         AbstractChannel.this.registered = true;
/*      */ 
/*      */ 
/*      */         
/*  514 */         AbstractChannel.this.pipeline.invokeHandlerAddedIfNeeded();
/*      */         
/*  516 */         safeSetSuccess(promise);
/*  517 */         AbstractChannel.this.pipeline.fireChannelRegistered();
/*      */ 
/*      */         
/*  520 */         if (AbstractChannel.this.isActive()) {
/*  521 */           if (firstRegistration) {
/*  522 */             AbstractChannel.this.pipeline.fireChannelActive();
/*  523 */           } else if (AbstractChannel.this.config().isAutoRead()) {
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  528 */             beginRead();
/*      */           } 
/*      */         }
/*  531 */       } catch (Throwable t) {
/*      */         
/*  533 */         closeForcibly();
/*  534 */         AbstractChannel.this.closeFuture.setClosed();
/*  535 */         safeSetFailure(promise, t);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public final void bind(SocketAddress localAddress, ChannelPromise promise) {
/*  541 */       assertEventLoop();
/*      */       
/*  543 */       if (!promise.setUncancellable() || !ensureOpen(promise)) {
/*      */         return;
/*      */       }
/*      */ 
/*      */       
/*  548 */       if (Boolean.TRUE.equals(AbstractChannel.this.config().getOption(ChannelOption.SO_BROADCAST)) && localAddress instanceof InetSocketAddress && 
/*      */         
/*  550 */         !((InetSocketAddress)localAddress).getAddress().isAnyLocalAddress() && 
/*  551 */         !PlatformDependent.isWindows() && !PlatformDependent.maybeSuperUser())
/*      */       {
/*      */         
/*  554 */         AbstractChannel.logger.warn("A non-root user can't receive a broadcast packet if the socket is not bound to a wildcard address; binding to a non-wildcard address (" + localAddress + ") anyway as requested.");
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  560 */       boolean wasActive = AbstractChannel.this.isActive();
/*      */       try {
/*  562 */         AbstractChannel.this.doBind(localAddress);
/*  563 */       } catch (Throwable t) {
/*  564 */         safeSetFailure(promise, t);
/*  565 */         closeIfClosed();
/*      */         
/*      */         return;
/*      */       } 
/*  569 */       if (!wasActive && AbstractChannel.this.isActive()) {
/*  570 */         invokeLater(new Runnable()
/*      */             {
/*      */               public void run() {
/*  573 */                 AbstractChannel.this.pipeline.fireChannelActive();
/*      */               }
/*      */             });
/*      */       }
/*      */       
/*  578 */       safeSetSuccess(promise);
/*      */     }
/*      */ 
/*      */     
/*      */     public final void disconnect(ChannelPromise promise) {
/*  583 */       assertEventLoop();
/*      */       
/*  585 */       if (!promise.setUncancellable()) {
/*      */         return;
/*      */       }
/*      */       
/*  589 */       boolean wasActive = AbstractChannel.this.isActive();
/*      */       try {
/*  591 */         AbstractChannel.this.doDisconnect();
/*      */         
/*  593 */         AbstractChannel.this.remoteAddress = null;
/*  594 */         AbstractChannel.this.localAddress = null;
/*  595 */       } catch (Throwable t) {
/*  596 */         safeSetFailure(promise, t);
/*  597 */         closeIfClosed();
/*      */         
/*      */         return;
/*      */       } 
/*  601 */       if (wasActive && !AbstractChannel.this.isActive()) {
/*  602 */         invokeLater(new Runnable()
/*      */             {
/*      */               public void run() {
/*  605 */                 AbstractChannel.this.pipeline.fireChannelInactive();
/*      */               }
/*      */             });
/*      */       }
/*      */       
/*  610 */       safeSetSuccess(promise);
/*  611 */       closeIfClosed();
/*      */     }
/*      */ 
/*      */     
/*      */     public void close(ChannelPromise promise) {
/*  616 */       assertEventLoop();
/*      */ 
/*      */       
/*  619 */       ClosedChannelException closedChannelException = StacklessClosedChannelException.newInstance(AbstractChannel.class, "close(ChannelPromise)");
/*  620 */       close(promise, closedChannelException, closedChannelException, false);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final void shutdownOutput(ChannelPromise promise) {
/*  629 */       assertEventLoop();
/*  630 */       shutdownOutput(promise, null);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void shutdownOutput(ChannelPromise promise, Throwable cause) {
/*  639 */       if (!promise.setUncancellable()) {
/*      */         return;
/*      */       }
/*      */       
/*  643 */       ChannelOutboundBuffer outboundBuffer = this.outboundBuffer;
/*  644 */       if (outboundBuffer == null) {
/*  645 */         promise.setFailure(new ClosedChannelException());
/*      */         return;
/*      */       } 
/*  648 */       this.outboundBuffer = null;
/*      */       
/*  650 */       ChannelOutputShutdownException channelOutputShutdownException = (cause == null) ? new ChannelOutputShutdownException("Channel output shutdown") : new ChannelOutputShutdownException("Channel output shutdown", cause);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       try {
/*  661 */         AbstractChannel.this.doShutdownOutput();
/*  662 */         promise.setSuccess();
/*  663 */       } catch (Throwable err) {
/*  664 */         promise.setFailure(err);
/*      */       } finally {
/*  666 */         closeOutboundBufferForShutdown(AbstractChannel.this.pipeline, outboundBuffer, (Throwable)channelOutputShutdownException);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     private void closeOutboundBufferForShutdown(ChannelPipeline pipeline, ChannelOutboundBuffer buffer, Throwable cause) {
/*  672 */       buffer.failFlushed(cause, false);
/*  673 */       buffer.close(cause, true);
/*  674 */       pipeline.fireUserEventTriggered(ChannelOutputShutdownEvent.INSTANCE);
/*      */     }
/*      */ 
/*      */     
/*      */     private void close(final ChannelPromise promise, final Throwable cause, final ClosedChannelException closeCause, final boolean notify) {
/*  679 */       if (!promise.setUncancellable()) {
/*      */         return;
/*      */       }
/*      */       
/*  683 */       if (AbstractChannel.this.closeInitiated) {
/*  684 */         if (AbstractChannel.this.closeFuture.isDone()) {
/*      */           
/*  686 */           safeSetSuccess(promise);
/*  687 */         } else if (!(promise instanceof VoidChannelPromise)) {
/*      */           
/*  689 */           AbstractChannel.this.closeFuture.addListener(new ChannelFutureListener()
/*      */               {
/*      */                 public void operationComplete(ChannelFuture future) throws Exception {
/*  692 */                   promise.setSuccess();
/*      */                 }
/*      */               });
/*      */         } 
/*      */         
/*      */         return;
/*      */       } 
/*  699 */       AbstractChannel.this.closeInitiated = true;
/*      */       
/*  701 */       final boolean wasActive = AbstractChannel.this.isActive();
/*  702 */       final ChannelOutboundBuffer outboundBuffer = this.outboundBuffer;
/*  703 */       this.outboundBuffer = null;
/*  704 */       Executor closeExecutor = prepareToClose();
/*  705 */       if (closeExecutor != null) {
/*  706 */         closeExecutor.execute(new Runnable()
/*      */             {
/*      */               public void run()
/*      */               {
/*      */                 try {
/*  711 */                   AbstractChannel.AbstractUnsafe.this.doClose0(promise);
/*      */                 } finally {
/*      */                   
/*  714 */                   AbstractChannel.AbstractUnsafe.this.invokeLater(new Runnable()
/*      */                       {
/*      */                         public void run() {
/*  717 */                           if (outboundBuffer != null) {
/*      */                             
/*  719 */                             outboundBuffer.failFlushed(cause, notify);
/*  720 */                             outboundBuffer.close(closeCause);
/*      */                           } 
/*  722 */                           AbstractChannel.AbstractUnsafe.this.fireChannelInactiveAndDeregister(wasActive);
/*      */                         }
/*      */                       });
/*      */                 } 
/*      */               }
/*      */             });
/*      */       } else {
/*      */         
/*      */         try {
/*  731 */           doClose0(promise);
/*      */         } finally {
/*  733 */           if (outboundBuffer != null) {
/*      */             
/*  735 */             outboundBuffer.failFlushed(cause, notify);
/*  736 */             outboundBuffer.close(closeCause);
/*      */           } 
/*      */         } 
/*  739 */         if (this.inFlush0) {
/*  740 */           invokeLater(new Runnable()
/*      */               {
/*      */                 public void run() {
/*  743 */                   AbstractChannel.AbstractUnsafe.this.fireChannelInactiveAndDeregister(wasActive);
/*      */                 }
/*      */               });
/*      */         } else {
/*  747 */           fireChannelInactiveAndDeregister(wasActive);
/*      */         } 
/*      */       } 
/*      */     }
/*      */     
/*      */     private void doClose0(ChannelPromise promise) {
/*      */       try {
/*  754 */         AbstractChannel.this.doClose();
/*  755 */         AbstractChannel.this.closeFuture.setClosed();
/*  756 */         safeSetSuccess(promise);
/*  757 */       } catch (Throwable t) {
/*  758 */         AbstractChannel.this.closeFuture.setClosed();
/*  759 */         safeSetFailure(promise, t);
/*      */       } 
/*      */     }
/*      */     
/*      */     private void fireChannelInactiveAndDeregister(boolean wasActive) {
/*  764 */       deregister(voidPromise(), (wasActive && !AbstractChannel.this.isActive()));
/*      */     }
/*      */ 
/*      */     
/*      */     public final void closeForcibly() {
/*  769 */       assertEventLoop();
/*      */       
/*      */       try {
/*  772 */         AbstractChannel.this.doClose();
/*  773 */       } catch (Exception e) {
/*  774 */         AbstractChannel.logger.warn("Failed to close a channel.", e);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public final void deregister(ChannelPromise promise) {
/*  780 */       assertEventLoop();
/*      */       
/*  782 */       deregister(promise, false);
/*      */     }
/*      */     
/*      */     private void deregister(final ChannelPromise promise, final boolean fireChannelInactive) {
/*  786 */       if (!promise.setUncancellable()) {
/*      */         return;
/*      */       }
/*      */       
/*  790 */       if (!AbstractChannel.this.registered) {
/*  791 */         safeSetSuccess(promise);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         return;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  804 */       invokeLater(new Runnable()
/*      */           {
/*      */             public void run() {
/*      */               try {
/*  808 */                 AbstractChannel.this.doDeregister();
/*  809 */               } catch (Throwable t) {
/*  810 */                 AbstractChannel.logger.warn("Unexpected exception occurred while deregistering a channel.", t);
/*      */               } finally {
/*  812 */                 if (fireChannelInactive) {
/*  813 */                   AbstractChannel.this.pipeline.fireChannelInactive();
/*      */                 }
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/*  819 */                 if (AbstractChannel.this.registered) {
/*  820 */                   AbstractChannel.this.registered = false;
/*  821 */                   AbstractChannel.this.pipeline.fireChannelUnregistered();
/*      */                 } 
/*  823 */                 AbstractChannel.AbstractUnsafe.this.safeSetSuccess(promise);
/*      */               } 
/*      */             }
/*      */           });
/*      */     }
/*      */ 
/*      */     
/*      */     public final void beginRead() {
/*  831 */       assertEventLoop();
/*      */       
/*      */       try {
/*  834 */         AbstractChannel.this.doBeginRead();
/*  835 */       } catch (Exception e) {
/*  836 */         invokeLater(new Runnable()
/*      */             {
/*      */               public void run() {
/*  839 */                 AbstractChannel.this.pipeline.fireExceptionCaught(e);
/*      */               }
/*      */             });
/*  842 */         close(voidPromise());
/*      */       } 
/*      */     }
/*      */     
/*      */     public final void write(Object msg, ChannelPromise promise) {
/*      */       int size;
/*  848 */       assertEventLoop();
/*      */       
/*  850 */       ChannelOutboundBuffer outboundBuffer = this.outboundBuffer;
/*  851 */       if (outboundBuffer == null) {
/*      */         
/*      */         try {
/*  854 */           ReferenceCountUtil.release(msg);
/*      */         
/*      */         }
/*      */         finally {
/*      */ 
/*      */           
/*  860 */           safeSetFailure(promise, 
/*  861 */               newClosedChannelException(AbstractChannel.this.initialCloseCause, "write(Object, ChannelPromise)"));
/*      */         } 
/*      */         
/*      */         return;
/*      */       } 
/*      */       
/*      */       try {
/*  868 */         msg = AbstractChannel.this.filterOutboundMessage(msg);
/*  869 */         size = AbstractChannel.this.pipeline.estimatorHandle().size(msg);
/*  870 */         if (size < 0) {
/*  871 */           size = 0;
/*      */         }
/*  873 */       } catch (Throwable t) {
/*      */         try {
/*  875 */           ReferenceCountUtil.release(msg);
/*      */         } finally {
/*  877 */           safeSetFailure(promise, t);
/*      */         } 
/*      */         
/*      */         return;
/*      */       } 
/*  882 */       outboundBuffer.addMessage(msg, size, promise);
/*      */     }
/*      */ 
/*      */     
/*      */     public final void flush() {
/*  887 */       assertEventLoop();
/*      */       
/*  889 */       ChannelOutboundBuffer outboundBuffer = this.outboundBuffer;
/*  890 */       if (outboundBuffer == null) {
/*      */         return;
/*      */       }
/*      */       
/*  894 */       outboundBuffer.addFlush();
/*  895 */       flush0();
/*      */     }
/*      */ 
/*      */     
/*      */     protected void flush0() {
/*  900 */       if (this.inFlush0) {
/*      */         return;
/*      */       }
/*      */ 
/*      */       
/*  905 */       ChannelOutboundBuffer outboundBuffer = this.outboundBuffer;
/*  906 */       if (outboundBuffer == null || outboundBuffer.isEmpty()) {
/*      */         return;
/*      */       }
/*      */       
/*  910 */       this.inFlush0 = true;
/*      */ 
/*      */       
/*  913 */       if (!AbstractChannel.this.isActive()) {
/*      */         
/*      */         try {
/*  916 */           if (!outboundBuffer.isEmpty()) {
/*  917 */             if (AbstractChannel.this.isOpen()) {
/*  918 */               outboundBuffer.failFlushed(new NotYetConnectedException(), true);
/*      */             } else {
/*      */               
/*  921 */               outboundBuffer.failFlushed(newClosedChannelException(AbstractChannel.this.initialCloseCause, "flush0()"), false);
/*      */             } 
/*      */           }
/*      */         } finally {
/*  925 */           this.inFlush0 = false;
/*      */         } 
/*      */         
/*      */         return;
/*      */       } 
/*      */       try {
/*  931 */         AbstractChannel.this.doWrite(outboundBuffer);
/*  932 */       } catch (Throwable t) {
/*  933 */         handleWriteError(t);
/*      */       } finally {
/*  935 */         this.inFlush0 = false;
/*      */       } 
/*      */     }
/*      */     
/*      */     protected final void handleWriteError(Throwable t) {
/*  940 */       if (t instanceof IOException && AbstractChannel.this.config().isAutoClose()) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  949 */         AbstractChannel.this.initialCloseCause = t;
/*  950 */         close(voidPromise(), t, newClosedChannelException(t, "flush0()"), false);
/*      */       } else {
/*      */         try {
/*  953 */           shutdownOutput(voidPromise(), t);
/*  954 */         } catch (Throwable t2) {
/*  955 */           AbstractChannel.this.initialCloseCause = t;
/*  956 */           close(voidPromise(), t2, newClosedChannelException(t, "flush0()"), false);
/*      */         } 
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     private ClosedChannelException newClosedChannelException(Throwable cause, String method) {
/*  963 */       ClosedChannelException exception = StacklessClosedChannelException.newInstance(AbstractUnsafe.class, method);
/*  964 */       if (cause != null) {
/*  965 */         exception.initCause(cause);
/*      */       }
/*  967 */       return exception;
/*      */     }
/*      */ 
/*      */     
/*      */     public final ChannelPromise voidPromise() {
/*  972 */       assertEventLoop();
/*      */       
/*  974 */       return AbstractChannel.this.unsafeVoidPromise;
/*      */     }
/*      */     
/*      */     protected final boolean ensureOpen(ChannelPromise promise) {
/*  978 */       if (AbstractChannel.this.isOpen()) {
/*  979 */         return true;
/*      */       }
/*      */       
/*  982 */       safeSetFailure(promise, newClosedChannelException(AbstractChannel.this.initialCloseCause, "ensureOpen(ChannelPromise)"));
/*  983 */       return false;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected final void safeSetSuccess(ChannelPromise promise) {
/*  990 */       if (!(promise instanceof VoidChannelPromise) && !promise.trySuccess()) {
/*  991 */         AbstractChannel.logger.warn("Failed to mark a promise as success because it is done already: {}", promise);
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected final void safeSetFailure(ChannelPromise promise, Throwable cause) {
/*  999 */       if (!(promise instanceof VoidChannelPromise) && !promise.tryFailure(cause)) {
/* 1000 */         AbstractChannel.logger.warn("Failed to mark a promise as failure because it's done already: {}", promise, cause);
/*      */       }
/*      */     }
/*      */     
/*      */     protected final void closeIfClosed() {
/* 1005 */       if (AbstractChannel.this.isOpen()) {
/*      */         return;
/*      */       }
/* 1008 */       close(voidPromise());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void invokeLater(Runnable task) {
/*      */       try {
/* 1024 */         AbstractChannel.this.eventLoop().execute(task);
/* 1025 */       } catch (RejectedExecutionException e) {
/* 1026 */         AbstractChannel.logger.warn("Can't invoke task later as EventLoop rejected it", e);
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected final Throwable annotateConnectException(Throwable cause, SocketAddress remoteAddress) {
/* 1034 */       if (cause instanceof ConnectException) {
/* 1035 */         return new AbstractChannel.AnnotatedConnectException((ConnectException)cause, remoteAddress);
/*      */       }
/* 1037 */       if (cause instanceof NoRouteToHostException) {
/* 1038 */         return new AbstractChannel.AnnotatedNoRouteToHostException((NoRouteToHostException)cause, remoteAddress);
/*      */       }
/* 1040 */       if (cause instanceof SocketException) {
/* 1041 */         return new AbstractChannel.AnnotatedSocketException((SocketException)cause, remoteAddress);
/*      */       }
/*      */       
/* 1044 */       return cause;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected Executor prepareToClose() {
/* 1054 */       return null;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void doRegister() throws Exception {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void doShutdownOutput() throws Exception {
/* 1103 */     doClose();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void doDeregister() throws Exception {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object filterOutboundMessage(Object msg) throws Exception {
/* 1130 */     return msg;
/*      */   } protected abstract AbstractUnsafe newUnsafe(); protected abstract boolean isCompatible(EventLoop paramEventLoop); protected abstract SocketAddress localAddress0(); protected abstract SocketAddress remoteAddress0();
/*      */   protected abstract void doBind(SocketAddress paramSocketAddress) throws Exception;
/*      */   protected void validateFileRegion(DefaultFileRegion region, long position) throws IOException {
/* 1134 */     DefaultFileRegion.validate(region, position);
/*      */   } protected abstract void doDisconnect() throws Exception;
/*      */   protected abstract void doClose() throws Exception;
/*      */   protected abstract void doBeginRead() throws Exception;
/*      */   protected abstract void doWrite(ChannelOutboundBuffer paramChannelOutboundBuffer) throws Exception;
/*      */   static final class CloseFuture extends DefaultChannelPromise { CloseFuture(AbstractChannel ch) {
/* 1140 */       super(ch);
/*      */     }
/*      */ 
/*      */     
/*      */     public ChannelPromise setSuccess() {
/* 1145 */       throw new IllegalStateException();
/*      */     }
/*      */ 
/*      */     
/*      */     public ChannelPromise setFailure(Throwable cause) {
/* 1150 */       throw new IllegalStateException();
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean trySuccess() {
/* 1155 */       throw new IllegalStateException();
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean tryFailure(Throwable cause) {
/* 1160 */       throw new IllegalStateException();
/*      */     }
/*      */     
/*      */     boolean setClosed() {
/* 1164 */       return super.trySuccess();
/*      */     } }
/*      */ 
/*      */   
/*      */   private static final class AnnotatedConnectException
/*      */     extends ConnectException {
/*      */     private static final long serialVersionUID = 3901958112696433556L;
/*      */     
/*      */     AnnotatedConnectException(ConnectException exception, SocketAddress remoteAddress) {
/* 1173 */       super(exception.getMessage() + ": " + remoteAddress);
/* 1174 */       initCause(exception);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public Throwable fillInStackTrace() {
/* 1180 */       return this;
/*      */     }
/*      */   }
/*      */   
/*      */   private static final class AnnotatedNoRouteToHostException
/*      */     extends NoRouteToHostException {
/*      */     private static final long serialVersionUID = -6801433937592080623L;
/*      */     
/*      */     AnnotatedNoRouteToHostException(NoRouteToHostException exception, SocketAddress remoteAddress) {
/* 1189 */       super(exception.getMessage() + ": " + remoteAddress);
/* 1190 */       initCause(exception);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public Throwable fillInStackTrace() {
/* 1196 */       return this;
/*      */     }
/*      */   }
/*      */   
/*      */   private static final class AnnotatedSocketException
/*      */     extends SocketException {
/*      */     private static final long serialVersionUID = 3896743275010454039L;
/*      */     
/*      */     AnnotatedSocketException(SocketException exception, SocketAddress remoteAddress) {
/* 1205 */       super(exception.getMessage() + ": " + remoteAddress);
/* 1206 */       initCause(exception);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public Throwable fillInStackTrace() {
/* 1212 */       return this;
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-transport-4.1.93.Final.jar!\io\netty\channel\AbstractChannel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */