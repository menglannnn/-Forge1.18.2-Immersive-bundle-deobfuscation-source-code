/*     */ package io.netty.channel.embedded;
/*     */ 
/*     */ import io.netty.channel.Channel;
/*     */ import io.netty.channel.ChannelFuture;
/*     */ import io.netty.channel.ChannelPromise;
/*     */ import io.netty.channel.DefaultChannelPromise;
/*     */ import io.netty.channel.EventLoop;
/*     */ import io.netty.channel.EventLoopGroup;
/*     */ import io.netty.util.concurrent.AbstractScheduledEventExecutor;
/*     */ import io.netty.util.concurrent.EventExecutor;
/*     */ import io.netty.util.concurrent.EventExecutorGroup;
/*     */ import io.netty.util.concurrent.Future;
/*     */ import io.netty.util.internal.ObjectUtil;
/*     */ import java.util.ArrayDeque;
/*     */ import java.util.Queue;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class EmbeddedEventLoop
/*     */   extends AbstractScheduledEventExecutor
/*     */   implements EventLoop
/*     */ {
/*  40 */   private long startTime = initialNanoTime();
/*     */ 
/*     */ 
/*     */   
/*     */   private long frozenTimestamp;
/*     */ 
/*     */   
/*     */   private boolean timeFrozen;
/*     */ 
/*     */   
/*  50 */   private final Queue<Runnable> tasks = new ArrayDeque<Runnable>(2);
/*     */ 
/*     */   
/*     */   public EventLoopGroup parent() {
/*  54 */     return (EventLoopGroup)super.parent();
/*     */   }
/*     */ 
/*     */   
/*     */   public EventLoop next() {
/*  59 */     return (EventLoop)super.next();
/*     */   }
/*     */ 
/*     */   
/*     */   public void execute(Runnable command) {
/*  64 */     this.tasks.add(ObjectUtil.checkNotNull(command, "command"));
/*     */   }
/*     */   
/*     */   void runTasks() {
/*     */     while (true) {
/*  69 */       Runnable task = this.tasks.poll();
/*  70 */       if (task == null) {
/*     */         break;
/*     */       }
/*     */       
/*  74 */       task.run();
/*     */     } 
/*     */   }
/*     */   
/*     */   boolean hasPendingNormalTasks() {
/*  79 */     return !this.tasks.isEmpty();
/*     */   }
/*     */   
/*     */   long runScheduledTasks() {
/*  83 */     long time = getCurrentTimeNanos();
/*     */     while (true) {
/*  85 */       Runnable task = pollScheduledTask(time);
/*  86 */       if (task == null) {
/*  87 */         return nextScheduledTaskNano();
/*     */       }
/*     */       
/*  90 */       task.run();
/*     */     } 
/*     */   }
/*     */   
/*     */   long nextScheduledTask() {
/*  95 */     return nextScheduledTaskNano();
/*     */   }
/*     */ 
/*     */   
/*     */   protected long getCurrentTimeNanos() {
/* 100 */     if (this.timeFrozen) {
/* 101 */       return this.frozenTimestamp;
/*     */     }
/* 103 */     return System.nanoTime() - this.startTime;
/*     */   }
/*     */   
/*     */   void advanceTimeBy(long nanos) {
/* 107 */     if (this.timeFrozen) {
/* 108 */       this.frozenTimestamp += nanos;
/*     */     } else {
/*     */       
/* 111 */       this.startTime -= nanos;
/*     */     } 
/*     */   }
/*     */   
/*     */   void freezeTime() {
/* 116 */     if (!this.timeFrozen) {
/* 117 */       this.frozenTimestamp = getCurrentTimeNanos();
/* 118 */       this.timeFrozen = true;
/*     */     } 
/*     */   }
/*     */   
/*     */   void unfreezeTime() {
/* 123 */     if (this.timeFrozen) {
/*     */ 
/*     */ 
/*     */       
/* 127 */       this.startTime = System.nanoTime() - this.frozenTimestamp;
/* 128 */       this.timeFrozen = false;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void cancelScheduledTasks() {
/* 134 */     super.cancelScheduledTasks();
/*     */   }
/*     */ 
/*     */   
/*     */   public Future<?> shutdownGracefully(long quietPeriod, long timeout, TimeUnit unit) {
/* 139 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public Future<?> terminationFuture() {
/* 144 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void shutdown() {
/* 150 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isShuttingDown() {
/* 155 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isShutdown() {
/* 160 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isTerminated() {
/* 165 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean awaitTermination(long timeout, TimeUnit unit) {
/* 170 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public ChannelFuture register(Channel channel) {
/* 175 */     return register((ChannelPromise)new DefaultChannelPromise(channel, (EventExecutor)this));
/*     */   }
/*     */ 
/*     */   
/*     */   public ChannelFuture register(ChannelPromise promise) {
/* 180 */     ObjectUtil.checkNotNull(promise, "promise");
/* 181 */     promise.channel().unsafe().register(this, promise);
/* 182 */     return (ChannelFuture)promise;
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public ChannelFuture register(Channel channel, ChannelPromise promise) {
/* 188 */     channel.unsafe().register(this, promise);
/* 189 */     return (ChannelFuture)promise;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean inEventLoop() {
/* 194 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean inEventLoop(Thread thread) {
/* 199 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-transport-4.1.93.Final.jar!\io\netty\channel\embedded\EmbeddedEventLoop.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */