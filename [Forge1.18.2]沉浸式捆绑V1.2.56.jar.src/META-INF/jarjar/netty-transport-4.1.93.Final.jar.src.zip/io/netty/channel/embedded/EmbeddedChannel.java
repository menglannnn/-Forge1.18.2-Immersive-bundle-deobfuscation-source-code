/*     */ package io.netty.channel.embedded;
/*     */ 
/*     */ import io.netty.channel.AbstractChannel;
/*     */ import io.netty.channel.Channel;
/*     */ import io.netty.channel.ChannelConfig;
/*     */ import io.netty.channel.ChannelFuture;
/*     */ import io.netty.channel.ChannelFutureListener;
/*     */ import io.netty.channel.ChannelHandler;
/*     */ import io.netty.channel.ChannelHandlerContext;
/*     */ import io.netty.channel.ChannelId;
/*     */ import io.netty.channel.ChannelInitializer;
/*     */ import io.netty.channel.ChannelMetadata;
/*     */ import io.netty.channel.ChannelOutboundBuffer;
/*     */ import io.netty.channel.ChannelPipeline;
/*     */ import io.netty.channel.ChannelPromise;
/*     */ import io.netty.channel.DefaultChannelConfig;
/*     */ import io.netty.channel.DefaultChannelPipeline;
/*     */ import io.netty.channel.EventLoop;
/*     */ import io.netty.channel.RecvByteBufAllocator;
/*     */ import io.netty.util.ReferenceCountUtil;
/*     */ import io.netty.util.concurrent.Future;
/*     */ import io.netty.util.concurrent.GenericFutureListener;
/*     */ import io.netty.util.internal.ObjectUtil;
/*     */ import io.netty.util.internal.PlatformDependent;
/*     */ import io.netty.util.internal.RecyclableArrayList;
/*     */ import io.netty.util.internal.logging.InternalLogger;
/*     */ import io.netty.util.internal.logging.InternalLoggerFactory;
/*     */ import java.net.SocketAddress;
/*     */ import java.nio.channels.ClosedChannelException;
/*     */ import java.util.ArrayDeque;
/*     */ import java.util.Queue;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EmbeddedChannel
/*     */   extends AbstractChannel
/*     */ {
/*  53 */   private static final SocketAddress LOCAL_ADDRESS = new EmbeddedSocketAddress();
/*  54 */   private static final SocketAddress REMOTE_ADDRESS = new EmbeddedSocketAddress();
/*     */   
/*  56 */   private static final ChannelHandler[] EMPTY_HANDLERS = new ChannelHandler[0];
/*  57 */   private enum State { OPEN, ACTIVE, CLOSED; }
/*     */   
/*  59 */   private static final InternalLogger logger = InternalLoggerFactory.getInstance(EmbeddedChannel.class);
/*     */   
/*  61 */   private static final ChannelMetadata METADATA_NO_DISCONNECT = new ChannelMetadata(false);
/*  62 */   private static final ChannelMetadata METADATA_DISCONNECT = new ChannelMetadata(true);
/*     */   
/*  64 */   private final EmbeddedEventLoop loop = new EmbeddedEventLoop();
/*  65 */   private final ChannelFutureListener recordExceptionListener = new ChannelFutureListener()
/*     */     {
/*     */       public void operationComplete(ChannelFuture future) throws Exception {
/*  68 */         EmbeddedChannel.this.recordException(future);
/*     */       }
/*     */     };
/*     */ 
/*     */   
/*     */   private final ChannelMetadata metadata;
/*     */   
/*     */   private final ChannelConfig config;
/*     */   
/*     */   private Queue<Object> inboundMessages;
/*     */   
/*     */   private Queue<Object> outboundMessages;
/*     */   private Throwable lastException;
/*     */   private State state;
/*     */   
/*     */   public EmbeddedChannel() {
/*  84 */     this(EMPTY_HANDLERS);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EmbeddedChannel(ChannelId channelId) {
/*  93 */     this(channelId, EMPTY_HANDLERS);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EmbeddedChannel(ChannelHandler... handlers) {
/* 102 */     this(EmbeddedChannelId.INSTANCE, handlers);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EmbeddedChannel(boolean hasDisconnect, ChannelHandler... handlers) {
/* 113 */     this(EmbeddedChannelId.INSTANCE, hasDisconnect, handlers);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EmbeddedChannel(boolean register, boolean hasDisconnect, ChannelHandler... handlers) {
/* 126 */     this(EmbeddedChannelId.INSTANCE, register, hasDisconnect, handlers);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EmbeddedChannel(ChannelId channelId, ChannelHandler... handlers) {
/* 137 */     this(channelId, false, handlers);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EmbeddedChannel(ChannelId channelId, boolean hasDisconnect, ChannelHandler... handlers) {
/* 150 */     this(channelId, true, hasDisconnect, handlers);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EmbeddedChannel(ChannelId channelId, boolean register, boolean hasDisconnect, ChannelHandler... handlers) {
/* 166 */     this((Channel)null, channelId, register, hasDisconnect, handlers);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EmbeddedChannel(Channel parent, ChannelId channelId, boolean register, boolean hasDisconnect, ChannelHandler... handlers) {
/* 183 */     super(parent, channelId);
/* 184 */     this.metadata = metadata(hasDisconnect);
/* 185 */     this.config = (ChannelConfig)new DefaultChannelConfig((Channel)this);
/* 186 */     setup(register, handlers);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EmbeddedChannel(ChannelId channelId, boolean hasDisconnect, ChannelConfig config, ChannelHandler... handlers) {
/* 201 */     super(null, channelId);
/* 202 */     this.metadata = metadata(hasDisconnect);
/* 203 */     this.config = (ChannelConfig)ObjectUtil.checkNotNull(config, "config");
/* 204 */     setup(true, handlers);
/*     */   }
/*     */   
/*     */   private static ChannelMetadata metadata(boolean hasDisconnect) {
/* 208 */     return hasDisconnect ? METADATA_DISCONNECT : METADATA_NO_DISCONNECT;
/*     */   }
/*     */   
/*     */   private void setup(boolean register, ChannelHandler... handlers) {
/* 212 */     ObjectUtil.checkNotNull(handlers, "handlers");
/* 213 */     ChannelPipeline p = pipeline();
/* 214 */     p.addLast(new ChannelHandler[] { (ChannelHandler)new ChannelInitializer<Channel>()
/*     */           {
/*     */             protected void initChannel(Channel ch) throws Exception {
/* 217 */               ChannelPipeline pipeline = ch.pipeline();
/* 218 */               for (ChannelHandler h : handlers) {
/* 219 */                 if (h == null) {
/*     */                   break;
/*     */                 }
/* 222 */                 pipeline.addLast(new ChannelHandler[] { h });
/*     */               } 
/*     */             }
/*     */           } });
/* 226 */     if (register) {
/* 227 */       ChannelFuture future = this.loop.register((Channel)this);
/* 228 */       assert future.isDone();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void register() throws Exception {
/* 236 */     ChannelFuture future = this.loop.register((Channel)this);
/* 237 */     assert future.isDone();
/* 238 */     Throwable cause = future.cause();
/* 239 */     if (cause != null) {
/* 240 */       PlatformDependent.throwException(cause);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected final DefaultChannelPipeline newChannelPipeline() {
/* 246 */     return new EmbeddedChannelPipeline(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public ChannelMetadata metadata() {
/* 251 */     return this.metadata;
/*     */   }
/*     */ 
/*     */   
/*     */   public ChannelConfig config() {
/* 256 */     return this.config;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isOpen() {
/* 261 */     return (this.state != State.CLOSED);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isActive() {
/* 266 */     return (this.state == State.ACTIVE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Queue<Object> inboundMessages() {
/* 273 */     if (this.inboundMessages == null) {
/* 274 */       this.inboundMessages = new ArrayDeque();
/*     */     }
/* 276 */     return this.inboundMessages;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public Queue<Object> lastInboundBuffer() {
/* 284 */     return inboundMessages();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Queue<Object> outboundMessages() {
/* 291 */     if (this.outboundMessages == null) {
/* 292 */       this.outboundMessages = new ArrayDeque();
/*     */     }
/* 294 */     return this.outboundMessages;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public Queue<Object> lastOutboundBuffer() {
/* 302 */     return outboundMessages();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T readInbound() {
/* 310 */     T message = (T)poll(this.inboundMessages);
/* 311 */     if (message != null) {
/* 312 */       ReferenceCountUtil.touch(message, "Caller of readInbound() will handle the message from this point");
/*     */     }
/* 314 */     return message;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T readOutbound() {
/* 322 */     T message = (T)poll(this.outboundMessages);
/* 323 */     if (message != null) {
/* 324 */       ReferenceCountUtil.touch(message, "Caller of readOutbound() will handle the message from this point.");
/*     */     }
/* 326 */     return message;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean writeInbound(Object... msgs) {
/* 337 */     ensureOpen();
/* 338 */     if (msgs.length == 0) {
/* 339 */       return isNotEmpty(this.inboundMessages);
/*     */     }
/*     */     
/* 342 */     ChannelPipeline p = pipeline();
/* 343 */     for (Object m : msgs) {
/* 344 */       p.fireChannelRead(m);
/*     */     }
/*     */     
/* 347 */     flushInbound(false, voidPromise());
/* 348 */     return isNotEmpty(this.inboundMessages);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ChannelFuture writeOneInbound(Object msg) {
/* 358 */     return writeOneInbound(msg, newPromise());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ChannelFuture writeOneInbound(Object msg, ChannelPromise promise) {
/* 368 */     if (checkOpen(true)) {
/* 369 */       pipeline().fireChannelRead(msg);
/*     */     }
/* 371 */     return checkException(promise);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EmbeddedChannel flushInbound() {
/* 380 */     flushInbound(true, voidPromise());
/* 381 */     return this;
/*     */   }
/*     */   
/*     */   private ChannelFuture flushInbound(boolean recordException, ChannelPromise promise) {
/* 385 */     if (checkOpen(recordException)) {
/* 386 */       pipeline().fireChannelReadComplete();
/* 387 */       runPendingTasks();
/*     */     } 
/*     */     
/* 390 */     return checkException(promise);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean writeOutbound(Object... msgs) {
/* 400 */     ensureOpen();
/* 401 */     if (msgs.length == 0) {
/* 402 */       return isNotEmpty(this.outboundMessages);
/*     */     }
/*     */     
/* 405 */     RecyclableArrayList futures = RecyclableArrayList.newInstance(msgs.length);
/*     */     try {
/* 407 */       for (Object m : msgs) {
/* 408 */         if (m == null) {
/*     */           break;
/*     */         }
/* 411 */         futures.add(write(m));
/*     */       } 
/*     */       
/* 414 */       flushOutbound0();
/*     */       
/* 416 */       int size = futures.size();
/* 417 */       for (int i = 0; i < size; i++) {
/* 418 */         ChannelFuture future = (ChannelFuture)futures.get(i);
/* 419 */         if (future.isDone()) {
/* 420 */           recordException(future);
/*     */         } else {
/*     */           
/* 423 */           future.addListener((GenericFutureListener)this.recordExceptionListener);
/*     */         } 
/*     */       } 
/*     */       
/* 427 */       checkException();
/* 428 */       return isNotEmpty(this.outboundMessages);
/*     */     } finally {
/* 430 */       futures.recycle();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ChannelFuture writeOneOutbound(Object msg) {
/* 441 */     return writeOneOutbound(msg, newPromise());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ChannelFuture writeOneOutbound(Object msg, ChannelPromise promise) {
/* 451 */     if (checkOpen(true)) {
/* 452 */       return write(msg, promise);
/*     */     }
/* 454 */     return checkException(promise);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EmbeddedChannel flushOutbound() {
/* 463 */     if (checkOpen(true)) {
/* 464 */       flushOutbound0();
/*     */     }
/* 466 */     checkException(voidPromise());
/* 467 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void flushOutbound0() {
/* 473 */     runPendingTasks();
/*     */     
/* 475 */     flush();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean finish() {
/* 484 */     return finish(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean finishAndReleaseAll() {
/* 494 */     return finish(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean finish(boolean releaseAll) {
/* 504 */     close();
/*     */     try {
/* 506 */       checkException();
/* 507 */       return (isNotEmpty(this.inboundMessages) || isNotEmpty(this.outboundMessages));
/*     */     } finally {
/* 509 */       if (releaseAll) {
/* 510 */         releaseAll(this.inboundMessages);
/* 511 */         releaseAll(this.outboundMessages);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean releaseInbound() {
/* 521 */     return releaseAll(this.inboundMessages);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean releaseOutbound() {
/* 529 */     return releaseAll(this.outboundMessages);
/*     */   }
/*     */   
/*     */   private static boolean releaseAll(Queue<Object> queue) {
/* 533 */     if (isNotEmpty(queue)) {
/*     */       while (true) {
/* 535 */         Object msg = queue.poll();
/* 536 */         if (msg == null) {
/*     */           break;
/*     */         }
/* 539 */         ReferenceCountUtil.release(msg);
/*     */       } 
/* 541 */       return true;
/*     */     } 
/* 543 */     return false;
/*     */   }
/*     */   
/*     */   private void finishPendingTasks(boolean cancel) {
/* 547 */     runPendingTasks();
/* 548 */     if (cancel)
/*     */     {
/* 550 */       embeddedEventLoop().cancelScheduledTasks();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public final ChannelFuture close() {
/* 556 */     return close(newPromise());
/*     */   }
/*     */ 
/*     */   
/*     */   public final ChannelFuture disconnect() {
/* 561 */     return disconnect(newPromise());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ChannelFuture close(ChannelPromise promise) {
/* 568 */     runPendingTasks();
/* 569 */     ChannelFuture future = super.close(promise);
/*     */ 
/*     */     
/* 572 */     finishPendingTasks(true);
/* 573 */     return future;
/*     */   }
/*     */ 
/*     */   
/*     */   public final ChannelFuture disconnect(ChannelPromise promise) {
/* 578 */     ChannelFuture future = super.disconnect(promise);
/* 579 */     finishPendingTasks(!this.metadata.hasDisconnect());
/* 580 */     return future;
/*     */   }
/*     */   
/*     */   private static boolean isNotEmpty(Queue<Object> queue) {
/* 584 */     return (queue != null && !queue.isEmpty());
/*     */   }
/*     */   
/*     */   private static Object poll(Queue<Object> queue) {
/* 588 */     return (queue != null) ? queue.poll() : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void runPendingTasks() {
/*     */     try {
/* 597 */       embeddedEventLoop().runTasks();
/* 598 */     } catch (Exception e) {
/* 599 */       recordException(e);
/*     */     } 
/*     */     
/*     */     try {
/* 603 */       embeddedEventLoop().runScheduledTasks();
/* 604 */     } catch (Exception e) {
/* 605 */       recordException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasPendingTasks() {
/* 617 */     return (embeddedEventLoop().hasPendingNormalTasks() || 
/* 618 */       embeddedEventLoop().nextScheduledTask() == 0L);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long runScheduledPendingTasks() {
/*     */     try {
/* 628 */       return embeddedEventLoop().runScheduledTasks();
/* 629 */     } catch (Exception e) {
/* 630 */       recordException(e);
/* 631 */       return embeddedEventLoop().nextScheduledTask();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void recordException(ChannelFuture future) {
/* 636 */     if (!future.isSuccess()) {
/* 637 */       recordException(future.cause());
/*     */     }
/*     */   }
/*     */   
/*     */   private void recordException(Throwable cause) {
/* 642 */     if (this.lastException == null) {
/* 643 */       this.lastException = cause;
/*     */     } else {
/* 645 */       logger.warn("More than one exception was raised. Will report only the first one and log others.", cause);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void advanceTimeBy(long duration, TimeUnit unit) {
/* 656 */     embeddedEventLoop().advanceTimeBy(unit.toNanos(duration));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void freezeTime() {
/* 665 */     embeddedEventLoop().freezeTime();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unfreezeTime() {
/* 676 */     embeddedEventLoop().unfreezeTime();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ChannelFuture checkException(ChannelPromise promise) {
/* 683 */     Throwable t = this.lastException;
/* 684 */     if (t != null) {
/* 685 */       this.lastException = null;
/*     */       
/* 687 */       if (promise.isVoid()) {
/* 688 */         PlatformDependent.throwException(t);
/*     */       }
/*     */       
/* 691 */       return (ChannelFuture)promise.setFailure(t);
/*     */     } 
/*     */     
/* 694 */     return (ChannelFuture)promise.setSuccess();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void checkException() {
/* 701 */     checkException(voidPromise());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean checkOpen(boolean recordException) {
/* 709 */     if (!isOpen()) {
/* 710 */       if (recordException) {
/* 711 */         recordException(new ClosedChannelException());
/*     */       }
/* 713 */       return false;
/*     */     } 
/*     */     
/* 716 */     return true;
/*     */   }
/*     */   
/*     */   private EmbeddedEventLoop embeddedEventLoop() {
/* 720 */     if (isRegistered()) {
/* 721 */       return (EmbeddedEventLoop)eventLoop();
/*     */     }
/*     */     
/* 724 */     return this.loop;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void ensureOpen() {
/* 731 */     if (!checkOpen(true)) {
/* 732 */       checkException();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isCompatible(EventLoop loop) {
/* 738 */     return loop instanceof EmbeddedEventLoop;
/*     */   }
/*     */ 
/*     */   
/*     */   protected SocketAddress localAddress0() {
/* 743 */     return isActive() ? LOCAL_ADDRESS : null;
/*     */   }
/*     */ 
/*     */   
/*     */   protected SocketAddress remoteAddress0() {
/* 748 */     return isActive() ? REMOTE_ADDRESS : null;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void doRegister() throws Exception {
/* 753 */     this.state = State.ACTIVE;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void doBind(SocketAddress localAddress) throws Exception {}
/*     */ 
/*     */ 
/*     */   
/*     */   protected void doDisconnect() throws Exception {
/* 763 */     if (!this.metadata.hasDisconnect()) {
/* 764 */       doClose();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected void doClose() throws Exception {
/* 770 */     this.state = State.CLOSED;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void doBeginRead() throws Exception {}
/*     */ 
/*     */ 
/*     */   
/*     */   protected AbstractChannel.AbstractUnsafe newUnsafe() {
/* 780 */     return new EmbeddedUnsafe();
/*     */   }
/*     */ 
/*     */   
/*     */   public Channel.Unsafe unsafe() {
/* 785 */     return ((EmbeddedUnsafe)super.unsafe()).wrapped;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void doWrite(ChannelOutboundBuffer in) throws Exception {
/*     */     while (true) {
/* 791 */       Object msg = in.current();
/* 792 */       if (msg == null) {
/*     */         break;
/*     */       }
/*     */       
/* 796 */       ReferenceCountUtil.retain(msg);
/* 797 */       handleOutboundMessage(msg);
/* 798 */       in.remove();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void handleOutboundMessage(Object msg) {
/* 808 */     outboundMessages().add(msg);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void handleInboundMessage(Object msg) {
/* 815 */     inboundMessages().add(msg);
/*     */   }
/*     */   private final class EmbeddedUnsafe extends AbstractChannel.AbstractUnsafe { private EmbeddedUnsafe() {
/* 818 */       super(EmbeddedChannel.this);
/*     */ 
/*     */ 
/*     */       
/* 822 */       this.wrapped = new Channel.Unsafe()
/*     */         {
/*     */           public RecvByteBufAllocator.Handle recvBufAllocHandle() {
/* 825 */             return EmbeddedChannel.EmbeddedUnsafe.this.recvBufAllocHandle();
/*     */           }
/*     */ 
/*     */           
/*     */           public SocketAddress localAddress() {
/* 830 */             return EmbeddedChannel.EmbeddedUnsafe.this.localAddress();
/*     */           }
/*     */ 
/*     */           
/*     */           public SocketAddress remoteAddress() {
/* 835 */             return EmbeddedChannel.EmbeddedUnsafe.this.remoteAddress();
/*     */           }
/*     */ 
/*     */           
/*     */           public void register(EventLoop eventLoop, ChannelPromise promise) {
/* 840 */             EmbeddedChannel.EmbeddedUnsafe.this.register(eventLoop, promise);
/* 841 */             EmbeddedChannel.this.runPendingTasks();
/*     */           }
/*     */ 
/*     */           
/*     */           public void bind(SocketAddress localAddress, ChannelPromise promise) {
/* 846 */             EmbeddedChannel.EmbeddedUnsafe.this.bind(localAddress, promise);
/* 847 */             EmbeddedChannel.this.runPendingTasks();
/*     */           }
/*     */ 
/*     */           
/*     */           public void connect(SocketAddress remoteAddress, SocketAddress localAddress, ChannelPromise promise) {
/* 852 */             EmbeddedChannel.EmbeddedUnsafe.this.connect(remoteAddress, localAddress, promise);
/* 853 */             EmbeddedChannel.this.runPendingTasks();
/*     */           }
/*     */ 
/*     */           
/*     */           public void disconnect(ChannelPromise promise) {
/* 858 */             EmbeddedChannel.EmbeddedUnsafe.this.disconnect(promise);
/* 859 */             EmbeddedChannel.this.runPendingTasks();
/*     */           }
/*     */ 
/*     */           
/*     */           public void close(ChannelPromise promise) {
/* 864 */             EmbeddedChannel.EmbeddedUnsafe.this.close(promise);
/* 865 */             EmbeddedChannel.this.runPendingTasks();
/*     */           }
/*     */ 
/*     */           
/*     */           public void closeForcibly() {
/* 870 */             EmbeddedChannel.EmbeddedUnsafe.this.closeForcibly();
/* 871 */             EmbeddedChannel.this.runPendingTasks();
/*     */           }
/*     */ 
/*     */           
/*     */           public void deregister(ChannelPromise promise) {
/* 876 */             EmbeddedChannel.EmbeddedUnsafe.this.deregister(promise);
/* 877 */             EmbeddedChannel.this.runPendingTasks();
/*     */           }
/*     */ 
/*     */           
/*     */           public void beginRead() {
/* 882 */             EmbeddedChannel.EmbeddedUnsafe.this.beginRead();
/* 883 */             EmbeddedChannel.this.runPendingTasks();
/*     */           }
/*     */ 
/*     */           
/*     */           public void write(Object msg, ChannelPromise promise) {
/* 888 */             EmbeddedChannel.EmbeddedUnsafe.this.write(msg, promise);
/* 889 */             EmbeddedChannel.this.runPendingTasks();
/*     */           }
/*     */ 
/*     */           
/*     */           public void flush() {
/* 894 */             EmbeddedChannel.EmbeddedUnsafe.this.flush();
/* 895 */             EmbeddedChannel.this.runPendingTasks();
/*     */           }
/*     */ 
/*     */           
/*     */           public ChannelPromise voidPromise() {
/* 900 */             return EmbeddedChannel.EmbeddedUnsafe.this.voidPromise();
/*     */           }
/*     */ 
/*     */           
/*     */           public ChannelOutboundBuffer outboundBuffer() {
/* 905 */             return EmbeddedChannel.EmbeddedUnsafe.this.outboundBuffer();
/*     */           }
/*     */         };
/*     */     }
/*     */     final Channel.Unsafe wrapped;
/*     */     public void connect(SocketAddress remoteAddress, SocketAddress localAddress, ChannelPromise promise) {
/* 911 */       safeSetSuccess(promise);
/*     */     } }
/*     */ 
/*     */   
/*     */   private final class EmbeddedChannelPipeline extends DefaultChannelPipeline {
/*     */     EmbeddedChannelPipeline(EmbeddedChannel channel) {
/* 917 */       super((Channel)channel);
/*     */     }
/*     */ 
/*     */     
/*     */     protected void onUnhandledInboundException(Throwable cause) {
/* 922 */       EmbeddedChannel.this.recordException(cause);
/*     */     }
/*     */ 
/*     */     
/*     */     protected void onUnhandledInboundMessage(ChannelHandlerContext ctx, Object msg) {
/* 927 */       EmbeddedChannel.this.handleInboundMessage(msg);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-transport-4.1.93.Final.jar!\io\netty\channel\embedded\EmbeddedChannel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */