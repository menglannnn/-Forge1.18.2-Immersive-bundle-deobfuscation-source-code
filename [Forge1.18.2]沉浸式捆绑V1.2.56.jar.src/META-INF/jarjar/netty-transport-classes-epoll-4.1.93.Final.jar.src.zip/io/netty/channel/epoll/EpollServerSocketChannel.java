/*     */ package io.netty.channel.epoll;
/*     */ 
/*     */ import io.netty.channel.Channel;
/*     */ import io.netty.channel.ChannelConfig;
/*     */ import io.netty.channel.EventLoop;
/*     */ import io.netty.channel.socket.InternetProtocolFamily;
/*     */ import io.netty.channel.socket.ServerSocketChannel;
/*     */ import io.netty.channel.socket.ServerSocketChannelConfig;
/*     */ import io.netty.channel.unix.NativeInetAddress;
/*     */ import java.io.IOException;
/*     */ import java.net.InetAddress;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.SocketAddress;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class EpollServerSocketChannel
/*     */   extends AbstractEpollServerChannel
/*     */   implements ServerSocketChannel
/*     */ {
/*     */   private final EpollServerSocketChannelConfig config;
/*  42 */   private volatile Collection<InetAddress> tcpMd5SigAddresses = Collections.emptyList();
/*     */   
/*     */   public EpollServerSocketChannel() {
/*  45 */     this((InternetProtocolFamily)null);
/*     */   }
/*     */   
/*     */   public EpollServerSocketChannel(InternetProtocolFamily protocol) {
/*  49 */     super(LinuxSocket.newSocketStream(protocol), false);
/*  50 */     this.config = new EpollServerSocketChannelConfig(this);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public EpollServerSocketChannel(int fd) {
/*  56 */     this(new LinuxSocket(fd));
/*     */   }
/*     */   
/*     */   EpollServerSocketChannel(LinuxSocket fd) {
/*  60 */     super(fd);
/*  61 */     this.config = new EpollServerSocketChannelConfig(this);
/*     */   }
/*     */   
/*     */   EpollServerSocketChannel(LinuxSocket fd, boolean active) {
/*  65 */     super(fd, active);
/*  66 */     this.config = new EpollServerSocketChannelConfig(this);
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isCompatible(EventLoop loop) {
/*  71 */     return loop instanceof EpollEventLoop;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void doBind(SocketAddress localAddress) throws Exception {
/*  76 */     super.doBind(localAddress);
/*     */     int tcpFastopen;
/*  78 */     if (Native.IS_SUPPORTING_TCP_FASTOPEN_SERVER && (tcpFastopen = this.config.getTcpFastopen()) > 0) {
/*  79 */       this.socket.setTcpFastOpen(tcpFastopen);
/*     */     }
/*  81 */     this.socket.listen(this.config.getBacklog());
/*  82 */     this.active = true;
/*     */   }
/*     */ 
/*     */   
/*     */   public InetSocketAddress remoteAddress() {
/*  87 */     return (InetSocketAddress)super.remoteAddress();
/*     */   }
/*     */ 
/*     */   
/*     */   public InetSocketAddress localAddress() {
/*  92 */     return (InetSocketAddress)super.localAddress();
/*     */   }
/*     */ 
/*     */   
/*     */   public EpollServerSocketChannelConfig config() {
/*  97 */     return this.config;
/*     */   }
/*     */ 
/*     */   
/*     */   protected Channel newChildChannel(int fd, byte[] address, int offset, int len) throws Exception {
/* 102 */     return (Channel)new EpollSocketChannel((Channel)this, new LinuxSocket(fd), NativeInetAddress.address(address, offset, len));
/*     */   }
/*     */   
/*     */   Collection<InetAddress> tcpMd5SigAddresses() {
/* 106 */     return this.tcpMd5SigAddresses;
/*     */   }
/*     */ 
/*     */   
/*     */   void setTcpMd5Sig(Map<InetAddress, byte[]> keys) throws IOException {
/* 111 */     synchronized (this) {
/* 112 */       this.tcpMd5SigAddresses = TcpMd5Util.newTcpMd5Sigs(this, this.tcpMd5SigAddresses, keys);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-transport-classes-epoll-4.1.93.Final.jar!\io\netty\channel\epoll\EpollServerSocketChannel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */