/*     */ package io.netty.channel.epoll;
/*     */ 
/*     */ import io.netty.channel.ChannelException;
/*     */ import io.netty.channel.DefaultFileRegion;
/*     */ import io.netty.channel.socket.InternetProtocolFamily;
/*     */ import io.netty.channel.unix.Errors;
/*     */ import io.netty.channel.unix.NativeInetAddress;
/*     */ import io.netty.channel.unix.PeerCredentials;
/*     */ import io.netty.channel.unix.Socket;
/*     */ import io.netty.util.internal.PlatformDependent;
/*     */ import io.netty.util.internal.SocketUtils;
/*     */ import java.io.IOException;
/*     */ import java.net.InetAddress;
/*     */ import java.net.NetworkInterface;
/*     */ import java.net.UnknownHostException;
/*     */ import java.util.Enumeration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class LinuxSocket
/*     */   extends Socket
/*     */ {
/*  42 */   static final InetAddress INET6_ANY = unsafeInetAddrByName("::");
/*  43 */   private static final InetAddress INET_ANY = unsafeInetAddrByName("0.0.0.0");
/*     */   private static final long MAX_UINT32_T = 4294967295L;
/*     */   
/*     */   LinuxSocket(int fd) {
/*  47 */     super(fd);
/*     */   }
/*     */   
/*     */   InternetProtocolFamily family() {
/*  51 */     return this.ipv6 ? InternetProtocolFamily.IPv6 : InternetProtocolFamily.IPv4;
/*     */   }
/*     */ 
/*     */   
/*     */   int sendmmsg(NativeDatagramPacketArray.NativeDatagramPacket[] msgs, int offset, int len) throws IOException {
/*  56 */     return Native.sendmmsg(intValue(), this.ipv6, msgs, offset, len);
/*     */   }
/*     */ 
/*     */   
/*     */   int recvmmsg(NativeDatagramPacketArray.NativeDatagramPacket[] msgs, int offset, int len) throws IOException {
/*  61 */     return Native.recvmmsg(intValue(), this.ipv6, msgs, offset, len);
/*     */   }
/*     */   
/*     */   int recvmsg(NativeDatagramPacketArray.NativeDatagramPacket msg) throws IOException {
/*  65 */     return Native.recvmsg(intValue(), this.ipv6, msg);
/*     */   }
/*     */   
/*     */   void setTimeToLive(int ttl) throws IOException {
/*  69 */     setTimeToLive(intValue(), ttl);
/*     */   }
/*     */   
/*     */   void setInterface(InetAddress address) throws IOException {
/*  73 */     NativeInetAddress a = NativeInetAddress.newInstance(address);
/*  74 */     setInterface(intValue(), this.ipv6, a.address(), a.scopeId(), interfaceIndex(address));
/*     */   }
/*     */   
/*     */   void setNetworkInterface(NetworkInterface netInterface) throws IOException {
/*  78 */     InetAddress address = deriveInetAddress(netInterface, (family() == InternetProtocolFamily.IPv6));
/*  79 */     if (address.equals((family() == InternetProtocolFamily.IPv4) ? INET_ANY : INET6_ANY)) {
/*  80 */       throw new IOException("NetworkInterface does not support " + family());
/*     */     }
/*  82 */     NativeInetAddress nativeAddress = NativeInetAddress.newInstance(address);
/*  83 */     setInterface(intValue(), this.ipv6, nativeAddress.address(), nativeAddress.scopeId(), interfaceIndex(netInterface));
/*     */   }
/*     */   
/*     */   InetAddress getInterface() throws IOException {
/*  87 */     NetworkInterface inf = getNetworkInterface();
/*  88 */     if (inf != null) {
/*  89 */       Enumeration<InetAddress> addresses = SocketUtils.addressesFromNetworkInterface(inf);
/*  90 */       if (addresses.hasMoreElements()) {
/*  91 */         return addresses.nextElement();
/*     */       }
/*     */     } 
/*  94 */     return null;
/*     */   }
/*     */   
/*     */   NetworkInterface getNetworkInterface() throws IOException {
/*  98 */     int ret = getInterface(intValue(), this.ipv6);
/*  99 */     if (this.ipv6) {
/* 100 */       return (PlatformDependent.javaVersion() >= 7) ? NetworkInterface.getByIndex(ret) : null;
/*     */     }
/* 102 */     InetAddress address = inetAddress(ret);
/* 103 */     return (address != null) ? NetworkInterface.getByInetAddress(address) : null;
/*     */   }
/*     */   
/*     */   private static InetAddress inetAddress(int value) {
/* 107 */     byte[] var1 = { (byte)(value >>> 24 & 0xFF), (byte)(value >>> 16 & 0xFF), (byte)(value >>> 8 & 0xFF), (byte)(value & 0xFF) };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 115 */       return InetAddress.getByAddress(var1);
/* 116 */     } catch (UnknownHostException ignore) {
/* 117 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   void joinGroup(InetAddress group, NetworkInterface netInterface, InetAddress source) throws IOException {
/* 122 */     NativeInetAddress g = NativeInetAddress.newInstance(group);
/* 123 */     boolean isIpv6 = group instanceof java.net.Inet6Address;
/* 124 */     NativeInetAddress i = NativeInetAddress.newInstance(deriveInetAddress(netInterface, isIpv6));
/* 125 */     if (source != null) {
/* 126 */       if (source.getClass() != group.getClass()) {
/* 127 */         throw new IllegalArgumentException("Source address is different type to group");
/*     */       }
/* 129 */       NativeInetAddress s = NativeInetAddress.newInstance(source);
/* 130 */       joinSsmGroup(intValue(), (this.ipv6 && isIpv6), g.address(), i.address(), g
/* 131 */           .scopeId(), interfaceIndex(netInterface), s.address());
/*     */     } else {
/* 133 */       joinGroup(intValue(), (this.ipv6 && isIpv6), g.address(), i.address(), g.scopeId(), interfaceIndex(netInterface));
/*     */     } 
/*     */   }
/*     */   
/*     */   void leaveGroup(InetAddress group, NetworkInterface netInterface, InetAddress source) throws IOException {
/* 138 */     NativeInetAddress g = NativeInetAddress.newInstance(group);
/* 139 */     boolean isIpv6 = group instanceof java.net.Inet6Address;
/* 140 */     NativeInetAddress i = NativeInetAddress.newInstance(deriveInetAddress(netInterface, isIpv6));
/* 141 */     if (source != null) {
/* 142 */       if (source.getClass() != group.getClass()) {
/* 143 */         throw new IllegalArgumentException("Source address is different type to group");
/*     */       }
/* 145 */       NativeInetAddress s = NativeInetAddress.newInstance(source);
/* 146 */       leaveSsmGroup(intValue(), (this.ipv6 && isIpv6), g.address(), i.address(), g
/* 147 */           .scopeId(), interfaceIndex(netInterface), s.address());
/*     */     } else {
/* 149 */       leaveGroup(intValue(), (this.ipv6 && isIpv6), g.address(), i.address(), g.scopeId(), interfaceIndex(netInterface));
/*     */     } 
/*     */   }
/*     */   
/*     */   private static int interfaceIndex(NetworkInterface networkInterface) {
/* 154 */     return (PlatformDependent.javaVersion() >= 7) ? networkInterface.getIndex() : -1;
/*     */   }
/*     */   
/*     */   private static int interfaceIndex(InetAddress address) throws IOException {
/* 158 */     if (PlatformDependent.javaVersion() >= 7) {
/* 159 */       NetworkInterface iface = NetworkInterface.getByInetAddress(address);
/* 160 */       if (iface != null) {
/* 161 */         return iface.getIndex();
/*     */       }
/*     */     } 
/* 164 */     return -1;
/*     */   }
/*     */   
/*     */   void setTcpDeferAccept(int deferAccept) throws IOException {
/* 168 */     setTcpDeferAccept(intValue(), deferAccept);
/*     */   }
/*     */   
/*     */   void setTcpQuickAck(boolean quickAck) throws IOException {
/* 172 */     setTcpQuickAck(intValue(), quickAck ? 1 : 0);
/*     */   }
/*     */   
/*     */   void setTcpCork(boolean tcpCork) throws IOException {
/* 176 */     setTcpCork(intValue(), tcpCork ? 1 : 0);
/*     */   }
/*     */   
/*     */   void setSoBusyPoll(int loopMicros) throws IOException {
/* 180 */     setSoBusyPoll(intValue(), loopMicros);
/*     */   }
/*     */   
/*     */   void setTcpNotSentLowAt(long tcpNotSentLowAt) throws IOException {
/* 184 */     if (tcpNotSentLowAt < 0L || tcpNotSentLowAt > 4294967295L) {
/* 185 */       throw new IllegalArgumentException("tcpNotSentLowAt must be a uint32_t");
/*     */     }
/* 187 */     setTcpNotSentLowAt(intValue(), (int)tcpNotSentLowAt);
/*     */   }
/*     */   
/*     */   void setTcpFastOpen(int tcpFastopenBacklog) throws IOException {
/* 191 */     setTcpFastOpen(intValue(), tcpFastopenBacklog);
/*     */   }
/*     */   
/*     */   void setTcpKeepIdle(int seconds) throws IOException {
/* 195 */     setTcpKeepIdle(intValue(), seconds);
/*     */   }
/*     */   
/*     */   void setTcpKeepIntvl(int seconds) throws IOException {
/* 199 */     setTcpKeepIntvl(intValue(), seconds);
/*     */   }
/*     */   
/*     */   void setTcpKeepCnt(int probes) throws IOException {
/* 203 */     setTcpKeepCnt(intValue(), probes);
/*     */   }
/*     */   
/*     */   void setTcpUserTimeout(int milliseconds) throws IOException {
/* 207 */     setTcpUserTimeout(intValue(), milliseconds);
/*     */   }
/*     */   
/*     */   void setIpFreeBind(boolean enabled) throws IOException {
/* 211 */     setIpFreeBind(intValue(), enabled ? 1 : 0);
/*     */   }
/*     */   
/*     */   void setIpTransparent(boolean enabled) throws IOException {
/* 215 */     setIpTransparent(intValue(), enabled ? 1 : 0);
/*     */   }
/*     */   
/*     */   void setIpRecvOrigDestAddr(boolean enabled) throws IOException {
/* 219 */     setIpRecvOrigDestAddr(intValue(), enabled ? 1 : 0);
/*     */   }
/*     */   
/*     */   int getTimeToLive() throws IOException {
/* 223 */     return getTimeToLive(intValue());
/*     */   }
/*     */   
/*     */   void getTcpInfo(EpollTcpInfo info) throws IOException {
/* 227 */     getTcpInfo(intValue(), info.info);
/*     */   }
/*     */   
/*     */   void setTcpMd5Sig(InetAddress address, byte[] key) throws IOException {
/* 231 */     NativeInetAddress a = NativeInetAddress.newInstance(address);
/* 232 */     setTcpMd5Sig(intValue(), this.ipv6, a.address(), a.scopeId(), key);
/*     */   }
/*     */   
/*     */   boolean isTcpCork() throws IOException {
/* 236 */     return (isTcpCork(intValue()) != 0);
/*     */   }
/*     */   
/*     */   int getSoBusyPoll() throws IOException {
/* 240 */     return getSoBusyPoll(intValue());
/*     */   }
/*     */   
/*     */   int getTcpDeferAccept() throws IOException {
/* 244 */     return getTcpDeferAccept(intValue());
/*     */   }
/*     */   
/*     */   boolean isTcpQuickAck() throws IOException {
/* 248 */     return (isTcpQuickAck(intValue()) != 0);
/*     */   }
/*     */   
/*     */   long getTcpNotSentLowAt() throws IOException {
/* 252 */     return getTcpNotSentLowAt(intValue()) & 0xFFFFFFFFL;
/*     */   }
/*     */   
/*     */   int getTcpKeepIdle() throws IOException {
/* 256 */     return getTcpKeepIdle(intValue());
/*     */   }
/*     */   
/*     */   int getTcpKeepIntvl() throws IOException {
/* 260 */     return getTcpKeepIntvl(intValue());
/*     */   }
/*     */   
/*     */   int getTcpKeepCnt() throws IOException {
/* 264 */     return getTcpKeepCnt(intValue());
/*     */   }
/*     */   
/*     */   int getTcpUserTimeout() throws IOException {
/* 268 */     return getTcpUserTimeout(intValue());
/*     */   }
/*     */   
/*     */   boolean isIpFreeBind() throws IOException {
/* 272 */     return (isIpFreeBind(intValue()) != 0);
/*     */   }
/*     */   
/*     */   boolean isIpTransparent() throws IOException {
/* 276 */     return (isIpTransparent(intValue()) != 0);
/*     */   }
/*     */   
/*     */   boolean isIpRecvOrigDestAddr() throws IOException {
/* 280 */     return (isIpRecvOrigDestAddr(intValue()) != 0);
/*     */   }
/*     */   
/*     */   PeerCredentials getPeerCredentials() throws IOException {
/* 284 */     return getPeerCredentials(intValue());
/*     */   }
/*     */   
/*     */   boolean isLoopbackModeDisabled() throws IOException {
/* 288 */     return (getIpMulticastLoop(intValue(), this.ipv6) == 0);
/*     */   }
/*     */   
/*     */   void setLoopbackModeDisabled(boolean loopbackModeDisabled) throws IOException {
/* 292 */     setIpMulticastLoop(intValue(), this.ipv6, loopbackModeDisabled ? 0 : 1);
/*     */   }
/*     */   
/*     */   boolean isUdpGro() throws IOException {
/* 296 */     return (isUdpGro(intValue()) != 0);
/*     */   }
/*     */   
/*     */   void setUdpGro(boolean gro) throws IOException {
/* 300 */     setUdpGro(intValue(), gro ? 1 : 0);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   long sendFile(DefaultFileRegion src, long baseOffset, long offset, long length) throws IOException {
/* 306 */     src.open();
/*     */     
/* 308 */     long res = sendFile(intValue(), src, baseOffset, offset, length);
/* 309 */     if (res >= 0L) {
/* 310 */       return res;
/*     */     }
/* 312 */     return Errors.ioResult("sendfile", (int)res);
/*     */   }
/*     */   
/*     */   private static InetAddress deriveInetAddress(NetworkInterface netInterface, boolean ipv6) {
/* 316 */     InetAddress ipAny = ipv6 ? INET6_ANY : INET_ANY;
/* 317 */     if (netInterface != null) {
/* 318 */       Enumeration<InetAddress> ias = netInterface.getInetAddresses();
/* 319 */       while (ias.hasMoreElements()) {
/* 320 */         InetAddress ia = ias.nextElement();
/* 321 */         boolean isV6 = ia instanceof java.net.Inet6Address;
/* 322 */         if (isV6 == ipv6) {
/* 323 */           return ia;
/*     */         }
/*     */       } 
/*     */     } 
/* 327 */     return ipAny;
/*     */   }
/*     */   
/*     */   public static LinuxSocket newSocketStream(boolean ipv6) {
/* 331 */     return new LinuxSocket(newSocketStream0(ipv6));
/*     */   }
/*     */   
/*     */   public static LinuxSocket newSocketStream(InternetProtocolFamily protocol) {
/* 335 */     return new LinuxSocket(newSocketStream0(protocol));
/*     */   }
/*     */   
/*     */   public static LinuxSocket newSocketStream() {
/* 339 */     return newSocketStream(isIPv6Preferred());
/*     */   }
/*     */   
/*     */   public static LinuxSocket newSocketDgram(boolean ipv6) {
/* 343 */     return new LinuxSocket(newSocketDgram0(ipv6));
/*     */   }
/*     */   
/*     */   public static LinuxSocket newSocketDgram(InternetProtocolFamily family) {
/* 347 */     return new LinuxSocket(newSocketDgram0(family));
/*     */   }
/*     */   
/*     */   public static LinuxSocket newSocketDgram() {
/* 351 */     return newSocketDgram(isIPv6Preferred());
/*     */   }
/*     */   
/*     */   public static LinuxSocket newSocketDomain() {
/* 355 */     return new LinuxSocket(newSocketDomain0());
/*     */   }
/*     */   
/*     */   public static LinuxSocket newSocketDomainDgram() {
/* 359 */     return new LinuxSocket(newSocketDomainDgram0());
/*     */   }
/*     */   
/*     */   private static InetAddress unsafeInetAddrByName(String inetName) {
/*     */     try {
/* 364 */       return InetAddress.getByName(inetName);
/* 365 */     } catch (UnknownHostException uhe) {
/* 366 */       throw new ChannelException(uhe);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static native void joinGroup(int paramInt1, boolean paramBoolean, byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, int paramInt2, int paramInt3) throws IOException;
/*     */   
/*     */   private static native void joinSsmGroup(int paramInt1, boolean paramBoolean, byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, int paramInt2, int paramInt3, byte[] paramArrayOfbyte3) throws IOException;
/*     */   
/*     */   private static native void leaveGroup(int paramInt1, boolean paramBoolean, byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, int paramInt2, int paramInt3) throws IOException;
/*     */   
/*     */   private static native void leaveSsmGroup(int paramInt1, boolean paramBoolean, byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, int paramInt2, int paramInt3, byte[] paramArrayOfbyte3) throws IOException;
/*     */   
/*     */   private static native long sendFile(int paramInt, DefaultFileRegion paramDefaultFileRegion, long paramLong1, long paramLong2, long paramLong3) throws IOException;
/*     */   
/*     */   private static native int getTcpDeferAccept(int paramInt) throws IOException;
/*     */   
/*     */   private static native int isTcpQuickAck(int paramInt) throws IOException;
/*     */   
/*     */   private static native int isTcpCork(int paramInt) throws IOException;
/*     */   
/*     */   private static native int getSoBusyPoll(int paramInt) throws IOException;
/*     */   
/*     */   private static native int getTcpNotSentLowAt(int paramInt) throws IOException;
/*     */   
/*     */   private static native int getTcpKeepIdle(int paramInt) throws IOException;
/*     */   
/*     */   private static native int getTcpKeepIntvl(int paramInt) throws IOException;
/*     */   
/*     */   private static native int getTcpKeepCnt(int paramInt) throws IOException;
/*     */   
/*     */   private static native int getTcpUserTimeout(int paramInt) throws IOException;
/*     */   
/*     */   private static native int getTimeToLive(int paramInt) throws IOException;
/*     */   
/*     */   private static native int isIpFreeBind(int paramInt) throws IOException;
/*     */   
/*     */   private static native int isIpTransparent(int paramInt) throws IOException;
/*     */   
/*     */   private static native int isIpRecvOrigDestAddr(int paramInt) throws IOException;
/*     */   
/*     */   private static native void getTcpInfo(int paramInt, long[] paramArrayOflong) throws IOException;
/*     */   
/*     */   private static native PeerCredentials getPeerCredentials(int paramInt) throws IOException;
/*     */   
/*     */   private static native void setTcpDeferAccept(int paramInt1, int paramInt2) throws IOException;
/*     */   
/*     */   private static native void setTcpQuickAck(int paramInt1, int paramInt2) throws IOException;
/*     */   
/*     */   private static native void setTcpCork(int paramInt1, int paramInt2) throws IOException;
/*     */   
/*     */   private static native void setSoBusyPoll(int paramInt1, int paramInt2) throws IOException;
/*     */   
/*     */   private static native void setTcpNotSentLowAt(int paramInt1, int paramInt2) throws IOException;
/*     */   
/*     */   private static native void setTcpFastOpen(int paramInt1, int paramInt2) throws IOException;
/*     */   
/*     */   private static native void setTcpKeepIdle(int paramInt1, int paramInt2) throws IOException;
/*     */   
/*     */   private static native void setTcpKeepIntvl(int paramInt1, int paramInt2) throws IOException;
/*     */   
/*     */   private static native void setTcpKeepCnt(int paramInt1, int paramInt2) throws IOException;
/*     */   
/*     */   private static native void setTcpUserTimeout(int paramInt1, int paramInt2) throws IOException;
/*     */   
/*     */   private static native void setIpFreeBind(int paramInt1, int paramInt2) throws IOException;
/*     */   
/*     */   private static native void setIpTransparent(int paramInt1, int paramInt2) throws IOException;
/*     */   
/*     */   private static native void setIpRecvOrigDestAddr(int paramInt1, int paramInt2) throws IOException;
/*     */   
/*     */   private static native void setTcpMd5Sig(int paramInt1, boolean paramBoolean, byte[] paramArrayOfbyte1, int paramInt2, byte[] paramArrayOfbyte2) throws IOException;
/*     */   
/*     */   private static native void setInterface(int paramInt1, boolean paramBoolean, byte[] paramArrayOfbyte, int paramInt2, int paramInt3) throws IOException;
/*     */   
/*     */   private static native int getInterface(int paramInt, boolean paramBoolean);
/*     */   
/*     */   private static native int getIpMulticastLoop(int paramInt, boolean paramBoolean) throws IOException;
/*     */   
/*     */   private static native void setIpMulticastLoop(int paramInt1, boolean paramBoolean, int paramInt2) throws IOException;
/*     */   
/*     */   private static native void setTimeToLive(int paramInt1, int paramInt2) throws IOException;
/*     */   
/*     */   private static native int isUdpGro(int paramInt) throws IOException;
/*     */   
/*     */   private static native void setUdpGro(int paramInt1, int paramInt2) throws IOException;
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-transport-classes-epoll-4.1.93.Final.jar!\io\netty\channel\epoll\LinuxSocket.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */