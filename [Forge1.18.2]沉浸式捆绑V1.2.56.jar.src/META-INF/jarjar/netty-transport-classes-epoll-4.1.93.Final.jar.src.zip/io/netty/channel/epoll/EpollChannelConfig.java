/*     */ package io.netty.channel.epoll;
/*     */ 
/*     */ import io.netty.buffer.ByteBufAllocator;
/*     */ import io.netty.channel.Channel;
/*     */ import io.netty.channel.ChannelConfig;
/*     */ import io.netty.channel.ChannelException;
/*     */ import io.netty.channel.ChannelOption;
/*     */ import io.netty.channel.DefaultChannelConfig;
/*     */ import io.netty.channel.MessageSizeEstimator;
/*     */ import io.netty.channel.RecvByteBufAllocator;
/*     */ import io.netty.channel.WriteBufferWaterMark;
/*     */ import io.netty.channel.unix.IntegerUnixChannelOption;
/*     */ import io.netty.channel.unix.Limits;
/*     */ import io.netty.channel.unix.RawUnixChannelOption;
/*     */ import io.netty.util.internal.ObjectUtil;
/*     */ import java.io.IOException;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EpollChannelConfig
/*     */   extends DefaultChannelConfig
/*     */ {
/*  36 */   private volatile long maxBytesPerGatheringWrite = Limits.SSIZE_MAX;
/*     */   
/*     */   EpollChannelConfig(AbstractEpollChannel channel) {
/*  39 */     super((Channel)channel);
/*     */   }
/*     */   
/*     */   EpollChannelConfig(AbstractEpollChannel channel, RecvByteBufAllocator recvByteBufAllocator) {
/*  43 */     super((Channel)channel, recvByteBufAllocator);
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<ChannelOption<?>, Object> getOptions() {
/*  48 */     return getOptions(super.getOptions(), new ChannelOption[] { EpollChannelOption.EPOLL_MODE });
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T getOption(ChannelOption<T> option) {
/*  54 */     if (option == EpollChannelOption.EPOLL_MODE) {
/*  55 */       return (T)getEpollMode();
/*     */     }
/*     */     try {
/*  58 */       if (option instanceof IntegerUnixChannelOption) {
/*  59 */         IntegerUnixChannelOption opt = (IntegerUnixChannelOption)option;
/*  60 */         return (T)Integer.valueOf(((AbstractEpollChannel)this.channel).socket.getIntOpt(opt
/*  61 */               .level(), opt.optname()));
/*     */       } 
/*  63 */       if (option instanceof RawUnixChannelOption) {
/*  64 */         RawUnixChannelOption opt = (RawUnixChannelOption)option;
/*  65 */         ByteBuffer out = ByteBuffer.allocate(opt.length());
/*  66 */         ((AbstractEpollChannel)this.channel).socket.getRawOpt(opt.level(), opt.optname(), out);
/*  67 */         return (T)out.flip();
/*     */       } 
/*  69 */     } catch (IOException e) {
/*  70 */       throw new ChannelException(e);
/*     */     } 
/*  72 */     return (T)super.getOption(option);
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> boolean setOption(ChannelOption<T> option, T value) {
/*  77 */     validate(option, value);
/*  78 */     if (option == EpollChannelOption.EPOLL_MODE) {
/*  79 */       setEpollMode((EpollMode)value);
/*     */     } else {
/*     */       try {
/*  82 */         if (option instanceof IntegerUnixChannelOption) {
/*  83 */           IntegerUnixChannelOption opt = (IntegerUnixChannelOption)option;
/*  84 */           ((AbstractEpollChannel)this.channel).socket.setIntOpt(opt.level(), opt.optname(), ((Integer)value).intValue());
/*  85 */           return true;
/*  86 */         }  if (option instanceof RawUnixChannelOption) {
/*  87 */           RawUnixChannelOption opt = (RawUnixChannelOption)option;
/*  88 */           ((AbstractEpollChannel)this.channel).socket.setRawOpt(opt.level(), opt.optname(), (ByteBuffer)value);
/*  89 */           return true;
/*     */         } 
/*  91 */       } catch (IOException e) {
/*  92 */         throw new ChannelException(e);
/*     */       } 
/*  94 */       return super.setOption(option, value);
/*     */     } 
/*  96 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public EpollChannelConfig setConnectTimeoutMillis(int connectTimeoutMillis) {
/* 101 */     super.setConnectTimeoutMillis(connectTimeoutMillis);
/* 102 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public EpollChannelConfig setMaxMessagesPerRead(int maxMessagesPerRead) {
/* 108 */     super.setMaxMessagesPerRead(maxMessagesPerRead);
/* 109 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public EpollChannelConfig setWriteSpinCount(int writeSpinCount) {
/* 114 */     super.setWriteSpinCount(writeSpinCount);
/* 115 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public EpollChannelConfig setAllocator(ByteBufAllocator allocator) {
/* 120 */     super.setAllocator(allocator);
/* 121 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public EpollChannelConfig setRecvByteBufAllocator(RecvByteBufAllocator allocator) {
/* 126 */     if (!(allocator.newHandle() instanceof RecvByteBufAllocator.ExtendedHandle)) {
/* 127 */       throw new IllegalArgumentException("allocator.newHandle() must return an object of type: " + RecvByteBufAllocator.ExtendedHandle.class);
/*     */     }
/*     */     
/* 130 */     super.setRecvByteBufAllocator(allocator);
/* 131 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public EpollChannelConfig setAutoRead(boolean autoRead) {
/* 136 */     super.setAutoRead(autoRead);
/* 137 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public EpollChannelConfig setWriteBufferHighWaterMark(int writeBufferHighWaterMark) {
/* 143 */     super.setWriteBufferHighWaterMark(writeBufferHighWaterMark);
/* 144 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public EpollChannelConfig setWriteBufferLowWaterMark(int writeBufferLowWaterMark) {
/* 150 */     super.setWriteBufferLowWaterMark(writeBufferLowWaterMark);
/* 151 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public EpollChannelConfig setWriteBufferWaterMark(WriteBufferWaterMark writeBufferWaterMark) {
/* 156 */     super.setWriteBufferWaterMark(writeBufferWaterMark);
/* 157 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public EpollChannelConfig setMessageSizeEstimator(MessageSizeEstimator estimator) {
/* 162 */     super.setMessageSizeEstimator(estimator);
/* 163 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EpollMode getEpollMode() {
/* 173 */     return ((AbstractEpollChannel)this.channel).isFlagSet(Native.EPOLLET) ? EpollMode.EDGE_TRIGGERED : EpollMode.LEVEL_TRIGGERED;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EpollChannelConfig setEpollMode(EpollMode mode) {
/* 186 */     ObjectUtil.checkNotNull(mode, "mode");
/*     */     
/*     */     try {
/* 189 */       switch (mode) {
/*     */         case EDGE_TRIGGERED:
/* 191 */           checkChannelNotRegistered();
/* 192 */           ((AbstractEpollChannel)this.channel).setFlag(Native.EPOLLET);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 204 */           return this;case LEVEL_TRIGGERED: checkChannelNotRegistered(); ((AbstractEpollChannel)this.channel).clearFlag(Native.EPOLLET); return this;
/*     */       }  throw new Error();
/*     */     } catch (IOException e) {
/*     */       throw new ChannelException(e);
/* 208 */     }  } private void checkChannelNotRegistered() { if (this.channel.isRegistered()) {
/* 209 */       throw new IllegalStateException("EpollMode can only be changed before channel is registered");
/*     */     } }
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void autoReadCleared() {
/* 215 */     ((AbstractEpollChannel)this.channel).clearEpollIn();
/*     */   }
/*     */   
/*     */   final void setMaxBytesPerGatheringWrite(long maxBytesPerGatheringWrite) {
/* 219 */     this.maxBytesPerGatheringWrite = maxBytesPerGatheringWrite;
/*     */   }
/*     */   
/*     */   final long getMaxBytesPerGatheringWrite() {
/* 223 */     return this.maxBytesPerGatheringWrite;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-transport-classes-epoll-4.1.93.Final.jar!\io\netty\channel\epoll\EpollChannelConfig.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */