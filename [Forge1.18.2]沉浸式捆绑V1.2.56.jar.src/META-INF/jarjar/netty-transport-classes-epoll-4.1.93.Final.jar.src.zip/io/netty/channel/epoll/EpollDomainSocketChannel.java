/*     */ package io.netty.channel.epoll;
/*     */ 
/*     */ import io.netty.channel.AbstractChannel;
/*     */ import io.netty.channel.Channel;
/*     */ import io.netty.channel.ChannelConfig;
/*     */ import io.netty.channel.ChannelOutboundBuffer;
/*     */ import io.netty.channel.ChannelPipeline;
/*     */ import io.netty.channel.unix.DomainSocketAddress;
/*     */ import io.netty.channel.unix.DomainSocketChannel;
/*     */ import io.netty.channel.unix.DomainSocketChannelConfig;
/*     */ import io.netty.channel.unix.DomainSocketReadMode;
/*     */ import io.netty.channel.unix.FileDescriptor;
/*     */ import io.netty.channel.unix.PeerCredentials;
/*     */ import java.io.IOException;
/*     */ import java.net.SocketAddress;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class EpollDomainSocketChannel
/*     */   extends AbstractEpollStreamChannel
/*     */   implements DomainSocketChannel
/*     */ {
/*  34 */   private final EpollDomainSocketChannelConfig config = new EpollDomainSocketChannelConfig(this);
/*     */   
/*     */   private volatile DomainSocketAddress local;
/*     */   private volatile DomainSocketAddress remote;
/*     */   
/*     */   public EpollDomainSocketChannel() {
/*  40 */     super(LinuxSocket.newSocketDomain(), false);
/*     */   }
/*     */   
/*     */   EpollDomainSocketChannel(Channel parent, FileDescriptor fd) {
/*  44 */     this(parent, new LinuxSocket(fd.intValue()));
/*     */   }
/*     */   
/*     */   public EpollDomainSocketChannel(int fd) {
/*  48 */     super(fd);
/*     */   }
/*     */   
/*     */   public EpollDomainSocketChannel(Channel parent, LinuxSocket fd) {
/*  52 */     super(parent, fd);
/*  53 */     this.local = fd.localDomainSocketAddress();
/*  54 */     this.remote = fd.remoteDomainSocketAddress();
/*     */   }
/*     */   
/*     */   public EpollDomainSocketChannel(int fd, boolean active) {
/*  58 */     super(new LinuxSocket(fd), active);
/*     */   }
/*     */ 
/*     */   
/*     */   protected AbstractEpollChannel.AbstractEpollUnsafe newUnsafe() {
/*  63 */     return new EpollDomainUnsafe();
/*     */   }
/*     */ 
/*     */   
/*     */   protected DomainSocketAddress localAddress0() {
/*  68 */     return this.local;
/*     */   }
/*     */ 
/*     */   
/*     */   protected DomainSocketAddress remoteAddress0() {
/*  73 */     return this.remote;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void doBind(SocketAddress localAddress) throws Exception {
/*  78 */     this.socket.bind(localAddress);
/*  79 */     this.local = (DomainSocketAddress)localAddress;
/*     */   }
/*     */ 
/*     */   
/*     */   public EpollDomainSocketChannelConfig config() {
/*  84 */     return this.config;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean doConnect(SocketAddress remoteAddress, SocketAddress localAddress) throws Exception {
/*  89 */     if (super.doConnect(remoteAddress, localAddress)) {
/*  90 */       this.local = (DomainSocketAddress)localAddress;
/*  91 */       this.remote = (DomainSocketAddress)remoteAddress;
/*  92 */       return true;
/*     */     } 
/*  94 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public DomainSocketAddress remoteAddress() {
/*  99 */     return (DomainSocketAddress)super.remoteAddress();
/*     */   }
/*     */ 
/*     */   
/*     */   public DomainSocketAddress localAddress() {
/* 104 */     return (DomainSocketAddress)super.localAddress();
/*     */   }
/*     */ 
/*     */   
/*     */   protected int doWriteSingle(ChannelOutboundBuffer in) throws Exception {
/* 109 */     Object msg = in.current();
/* 110 */     if (msg instanceof FileDescriptor && this.socket.sendFd(((FileDescriptor)msg).intValue()) > 0) {
/*     */       
/* 112 */       in.remove();
/* 113 */       return 1;
/*     */     } 
/* 115 */     return super.doWriteSingle(in);
/*     */   }
/*     */ 
/*     */   
/*     */   protected Object filterOutboundMessage(Object msg) {
/* 120 */     if (msg instanceof FileDescriptor) {
/* 121 */       return msg;
/*     */     }
/* 123 */     return super.filterOutboundMessage(msg);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PeerCredentials peerCredentials() throws IOException {
/* 132 */     return this.socket.getPeerCredentials();
/*     */   }
/*     */   
/*     */   private final class EpollDomainUnsafe
/*     */     extends AbstractEpollStreamChannel.EpollStreamUnsafe {
/*     */     void epollInReady() {
/* 138 */       switch (EpollDomainSocketChannel.this.config().getReadMode()) {
/*     */         case BYTES:
/* 140 */           super.epollInReady();
/*     */           return;
/*     */         case FILE_DESCRIPTORS:
/* 143 */           epollInReadFd();
/*     */           return;
/*     */       } 
/* 146 */       throw new Error();
/*     */     }
/*     */     private EpollDomainUnsafe() {}
/*     */     
/*     */     private void epollInReadFd() {
/* 151 */       if (EpollDomainSocketChannel.this.socket.isInputShutdown()) {
/* 152 */         clearEpollIn0();
/*     */         return;
/*     */       } 
/* 155 */       EpollDomainSocketChannelConfig epollDomainSocketChannelConfig = EpollDomainSocketChannel.this.config();
/* 156 */       EpollRecvByteAllocatorHandle allocHandle = recvBufAllocHandle();
/* 157 */       allocHandle.edgeTriggered(EpollDomainSocketChannel.this.isFlagSet(Native.EPOLLET));
/*     */       
/* 159 */       ChannelPipeline pipeline = EpollDomainSocketChannel.this.pipeline();
/* 160 */       allocHandle.reset((ChannelConfig)epollDomainSocketChannelConfig);
/* 161 */       epollInBefore();
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/*     */         do {
/* 168 */           allocHandle.lastBytesRead(EpollDomainSocketChannel.this.socket.recvFd());
/* 169 */           switch (allocHandle.lastBytesRead()) {
/*     */             case 0:
/*     */               break;
/*     */             case -1:
/* 173 */               close(voidPromise());
/*     */               return;
/*     */           } 
/* 176 */           allocHandle.incMessagesRead(1);
/* 177 */           this.readPending = false;
/* 178 */           pipeline.fireChannelRead(new FileDescriptor(allocHandle.lastBytesRead()));
/*     */         
/*     */         }
/* 181 */         while (allocHandle.continueReading());
/*     */         
/* 183 */         allocHandle.readComplete();
/* 184 */         pipeline.fireChannelReadComplete();
/* 185 */       } catch (Throwable t) {
/* 186 */         allocHandle.readComplete();
/* 187 */         pipeline.fireChannelReadComplete();
/* 188 */         pipeline.fireExceptionCaught(t);
/*     */       } finally {
/* 190 */         epollInFinally((ChannelConfig)epollDomainSocketChannelConfig);
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-transport-classes-epoll-4.1.93.Final.jar!\io\netty\channel\epoll\EpollDomainSocketChannel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */