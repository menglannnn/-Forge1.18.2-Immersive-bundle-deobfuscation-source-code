/*     */ package io.netty.channel.epoll;
/*     */ 
/*     */ import io.netty.buffer.ByteBufAllocator;
/*     */ import io.netty.channel.ChannelConfig;
/*     */ import io.netty.channel.ChannelOption;
/*     */ import io.netty.channel.MessageSizeEstimator;
/*     */ import io.netty.channel.RecvByteBufAllocator;
/*     */ import io.netty.channel.WriteBufferWaterMark;
/*     */ import io.netty.channel.socket.DuplexChannelConfig;
/*     */ import io.netty.channel.unix.DomainSocketChannelConfig;
/*     */ import io.netty.channel.unix.DomainSocketReadMode;
/*     */ import io.netty.channel.unix.UnixChannelOption;
/*     */ import io.netty.util.internal.ObjectUtil;
/*     */ import java.io.IOException;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class EpollDomainSocketChannelConfig
/*     */   extends EpollChannelConfig
/*     */   implements DomainSocketChannelConfig, DuplexChannelConfig
/*     */ {
/*  38 */   private volatile DomainSocketReadMode mode = DomainSocketReadMode.BYTES;
/*     */   private volatile boolean allowHalfClosure;
/*     */   
/*     */   EpollDomainSocketChannelConfig(AbstractEpollChannel channel) {
/*  42 */     super(channel);
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<ChannelOption<?>, Object> getOptions() {
/*  47 */     return getOptions(super.getOptions(), new ChannelOption[] { UnixChannelOption.DOMAIN_SOCKET_READ_MODE, ChannelOption.ALLOW_HALF_CLOSURE, ChannelOption.SO_SNDBUF, ChannelOption.SO_RCVBUF });
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T getOption(ChannelOption<T> option) {
/*  53 */     if (option == UnixChannelOption.DOMAIN_SOCKET_READ_MODE) {
/*  54 */       return (T)getReadMode();
/*     */     }
/*  56 */     if (option == ChannelOption.ALLOW_HALF_CLOSURE) {
/*  57 */       return (T)Boolean.valueOf(isAllowHalfClosure());
/*     */     }
/*  59 */     if (option == ChannelOption.SO_SNDBUF) {
/*  60 */       return (T)Integer.valueOf(getSendBufferSize());
/*     */     }
/*  62 */     if (option == ChannelOption.SO_RCVBUF) {
/*  63 */       return (T)Integer.valueOf(getReceiveBufferSize());
/*     */     }
/*  65 */     return super.getOption(option);
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> boolean setOption(ChannelOption<T> option, T value) {
/*  70 */     validate(option, value);
/*     */     
/*  72 */     if (option == UnixChannelOption.DOMAIN_SOCKET_READ_MODE) {
/*  73 */       setReadMode((DomainSocketReadMode)value);
/*  74 */     } else if (option == ChannelOption.ALLOW_HALF_CLOSURE) {
/*  75 */       setAllowHalfClosure(((Boolean)value).booleanValue());
/*  76 */     } else if (option == ChannelOption.SO_SNDBUF) {
/*  77 */       setSendBufferSize(((Integer)value).intValue());
/*  78 */     } else if (option == ChannelOption.SO_RCVBUF) {
/*  79 */       setReceiveBufferSize(((Integer)value).intValue());
/*     */     } else {
/*  81 */       return super.setOption(option, value);
/*     */     } 
/*     */     
/*  84 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public EpollDomainSocketChannelConfig setMaxMessagesPerRead(int maxMessagesPerRead) {
/*  90 */     super.setMaxMessagesPerRead(maxMessagesPerRead);
/*  91 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public EpollDomainSocketChannelConfig setConnectTimeoutMillis(int connectTimeoutMillis) {
/*  96 */     super.setConnectTimeoutMillis(connectTimeoutMillis);
/*  97 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public EpollDomainSocketChannelConfig setWriteSpinCount(int writeSpinCount) {
/* 102 */     super.setWriteSpinCount(writeSpinCount);
/* 103 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public EpollDomainSocketChannelConfig setRecvByteBufAllocator(RecvByteBufAllocator allocator) {
/* 108 */     super.setRecvByteBufAllocator(allocator);
/* 109 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public EpollDomainSocketChannelConfig setAllocator(ByteBufAllocator allocator) {
/* 114 */     super.setAllocator(allocator);
/* 115 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public EpollDomainSocketChannelConfig setAutoClose(boolean autoClose) {
/* 120 */     super.setAutoClose(autoClose);
/* 121 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public EpollDomainSocketChannelConfig setMessageSizeEstimator(MessageSizeEstimator estimator) {
/* 126 */     super.setMessageSizeEstimator(estimator);
/* 127 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public EpollDomainSocketChannelConfig setWriteBufferLowWaterMark(int writeBufferLowWaterMark) {
/* 133 */     super.setWriteBufferLowWaterMark(writeBufferLowWaterMark);
/* 134 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public EpollDomainSocketChannelConfig setWriteBufferHighWaterMark(int writeBufferHighWaterMark) {
/* 140 */     super.setWriteBufferHighWaterMark(writeBufferHighWaterMark);
/* 141 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public EpollDomainSocketChannelConfig setWriteBufferWaterMark(WriteBufferWaterMark writeBufferWaterMark) {
/* 146 */     super.setWriteBufferWaterMark(writeBufferWaterMark);
/* 147 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public EpollDomainSocketChannelConfig setAutoRead(boolean autoRead) {
/* 152 */     super.setAutoRead(autoRead);
/* 153 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public EpollDomainSocketChannelConfig setEpollMode(EpollMode mode) {
/* 158 */     super.setEpollMode(mode);
/* 159 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public EpollDomainSocketChannelConfig setReadMode(DomainSocketReadMode mode) {
/* 164 */     this.mode = (DomainSocketReadMode)ObjectUtil.checkNotNull(mode, "mode");
/* 165 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public DomainSocketReadMode getReadMode() {
/* 170 */     return this.mode;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isAllowHalfClosure() {
/* 175 */     return this.allowHalfClosure;
/*     */   }
/*     */ 
/*     */   
/*     */   public EpollDomainSocketChannelConfig setAllowHalfClosure(boolean allowHalfClosure) {
/* 180 */     this.allowHalfClosure = allowHalfClosure;
/* 181 */     return this;
/*     */   }
/*     */   
/*     */   public int getSendBufferSize() {
/*     */     try {
/* 186 */       return ((EpollDomainSocketChannel)this.channel).socket.getSendBufferSize();
/* 187 */     } catch (IOException e) {
/* 188 */       throw new RuntimeException(e);
/*     */     } 
/*     */   }
/*     */   
/*     */   public EpollDomainSocketChannelConfig setSendBufferSize(int sendBufferSize) {
/*     */     try {
/* 194 */       ((EpollDomainSocketChannel)this.channel).socket.setSendBufferSize(sendBufferSize);
/* 195 */       return this;
/* 196 */     } catch (IOException e) {
/* 197 */       throw new RuntimeException(e);
/*     */     } 
/*     */   }
/*     */   
/*     */   public int getReceiveBufferSize() {
/*     */     try {
/* 203 */       return ((EpollDomainSocketChannel)this.channel).socket.getReceiveBufferSize();
/* 204 */     } catch (IOException e) {
/* 205 */       throw new RuntimeException(e);
/*     */     } 
/*     */   }
/*     */   
/*     */   public EpollDomainSocketChannelConfig setReceiveBufferSize(int receiveBufferSize) {
/*     */     try {
/* 211 */       ((EpollDomainSocketChannel)this.channel).socket.setReceiveBufferSize(receiveBufferSize);
/* 212 */       return this;
/* 213 */     } catch (IOException e) {
/* 214 */       throw new RuntimeException(e);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-transport-classes-epoll-4.1.93.Final.jar!\io\netty\channel\epoll\EpollDomainSocketChannelConfig.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */