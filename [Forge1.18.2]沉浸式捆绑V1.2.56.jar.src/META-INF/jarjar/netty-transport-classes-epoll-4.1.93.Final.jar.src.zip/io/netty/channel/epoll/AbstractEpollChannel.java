/*     */ package io.netty.channel.epoll;
/*     */ 
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import io.netty.buffer.ByteBufAllocator;
/*     */ import io.netty.buffer.ByteBufUtil;
/*     */ import io.netty.buffer.Unpooled;
/*     */ import io.netty.channel.AbstractChannel;
/*     */ import io.netty.channel.Channel;
/*     */ import io.netty.channel.ChannelConfig;
/*     */ import io.netty.channel.ChannelException;
/*     */ import io.netty.channel.ChannelFuture;
/*     */ import io.netty.channel.ChannelFutureListener;
/*     */ import io.netty.channel.ChannelMetadata;
/*     */ import io.netty.channel.ChannelOutboundBuffer;
/*     */ import io.netty.channel.ChannelPromise;
/*     */ import io.netty.channel.ConnectTimeoutException;
/*     */ import io.netty.channel.EventLoop;
/*     */ import io.netty.channel.RecvByteBufAllocator;
/*     */ import io.netty.channel.socket.ChannelInputShutdownEvent;
/*     */ import io.netty.channel.socket.ChannelInputShutdownReadComplete;
/*     */ import io.netty.channel.socket.SocketChannelConfig;
/*     */ import io.netty.channel.unix.FileDescriptor;
/*     */ import io.netty.channel.unix.IovArray;
/*     */ import io.netty.channel.unix.Socket;
/*     */ import io.netty.channel.unix.UnixChannel;
/*     */ import io.netty.channel.unix.UnixChannelUtil;
/*     */ import io.netty.util.ReferenceCountUtil;
/*     */ import io.netty.util.concurrent.Future;
/*     */ import io.netty.util.concurrent.GenericFutureListener;
/*     */ import io.netty.util.internal.ObjectUtil;
/*     */ import java.io.IOException;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.SocketAddress;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.channels.AlreadyConnectedException;
/*     */ import java.nio.channels.ClosedChannelException;
/*     */ import java.nio.channels.ConnectionPendingException;
/*     */ import java.nio.channels.NotYetConnectedException;
/*     */ import java.nio.channels.UnresolvedAddressException;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class AbstractEpollChannel
/*     */   extends AbstractChannel
/*     */   implements UnixChannel
/*     */ {
/*  60 */   private static final ChannelMetadata METADATA = new ChannelMetadata(false);
/*     */   
/*     */   final LinuxSocket socket;
/*     */   
/*     */   private ChannelPromise connectPromise;
/*     */   
/*     */   private Future<?> connectTimeoutFuture;
/*     */   
/*     */   private SocketAddress requestedRemoteAddress;
/*     */   
/*     */   private volatile SocketAddress local;
/*     */   
/*     */   private volatile SocketAddress remote;
/*  73 */   protected int flags = Native.EPOLLET;
/*     */   
/*     */   boolean inputClosedSeenErrorOnRead;
/*     */   boolean epollInReadyRunnablePending;
/*     */   protected volatile boolean active;
/*     */   
/*     */   AbstractEpollChannel(LinuxSocket fd) {
/*  80 */     this((Channel)null, fd, false);
/*     */   }
/*     */   
/*     */   AbstractEpollChannel(Channel parent, LinuxSocket fd, boolean active) {
/*  84 */     super(parent);
/*  85 */     this.socket = (LinuxSocket)ObjectUtil.checkNotNull(fd, "fd");
/*  86 */     this.active = active;
/*  87 */     if (active) {
/*     */ 
/*     */       
/*  90 */       this.local = fd.localAddress();
/*  91 */       this.remote = fd.remoteAddress();
/*     */     } 
/*     */   }
/*     */   
/*     */   AbstractEpollChannel(Channel parent, LinuxSocket fd, SocketAddress remote) {
/*  96 */     super(parent);
/*  97 */     this.socket = (LinuxSocket)ObjectUtil.checkNotNull(fd, "fd");
/*  98 */     this.active = true;
/*     */ 
/*     */     
/* 101 */     this.remote = remote;
/* 102 */     this.local = fd.localAddress();
/*     */   }
/*     */   
/*     */   static boolean isSoErrorZero(Socket fd) {
/*     */     try {
/* 107 */       return (fd.getSoError() == 0);
/* 108 */     } catch (IOException e) {
/* 109 */       throw new ChannelException(e);
/*     */     } 
/*     */   }
/*     */   
/*     */   void setFlag(int flag) throws IOException {
/* 114 */     if (!isFlagSet(flag)) {
/* 115 */       this.flags |= flag;
/* 116 */       modifyEvents();
/*     */     } 
/*     */   }
/*     */   
/*     */   void clearFlag(int flag) throws IOException {
/* 121 */     if (isFlagSet(flag)) {
/* 122 */       this.flags &= flag ^ 0xFFFFFFFF;
/* 123 */       modifyEvents();
/*     */     } 
/*     */   }
/*     */   
/*     */   boolean isFlagSet(int flag) {
/* 128 */     return ((this.flags & flag) != 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public final FileDescriptor fd() {
/* 133 */     return (FileDescriptor)this.socket;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isActive() {
/* 141 */     return this.active;
/*     */   }
/*     */ 
/*     */   
/*     */   public ChannelMetadata metadata() {
/* 146 */     return METADATA;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void doClose() throws Exception {
/* 151 */     this.active = false;
/*     */ 
/*     */     
/* 154 */     this.inputClosedSeenErrorOnRead = true;
/*     */     try {
/* 156 */       ChannelPromise promise = this.connectPromise;
/* 157 */       if (promise != null) {
/*     */         
/* 159 */         promise.tryFailure(new ClosedChannelException());
/* 160 */         this.connectPromise = null;
/*     */       } 
/*     */       
/* 163 */       Future<?> future = this.connectTimeoutFuture;
/* 164 */       if (future != null) {
/* 165 */         future.cancel(false);
/* 166 */         this.connectTimeoutFuture = null;
/*     */       } 
/*     */       
/* 169 */       if (isRegistered()) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 174 */         EventLoop loop = eventLoop();
/* 175 */         if (loop.inEventLoop()) {
/* 176 */           doDeregister();
/*     */         } else {
/* 178 */           loop.execute(new Runnable()
/*     */               {
/*     */                 public void run() {
/*     */                   try {
/* 182 */                     AbstractEpollChannel.this.doDeregister();
/* 183 */                   } catch (Throwable cause) {
/* 184 */                     AbstractEpollChannel.this.pipeline().fireExceptionCaught(cause);
/*     */                   } 
/*     */                 }
/*     */               });
/*     */         } 
/*     */       } 
/*     */     } finally {
/* 191 */       this.socket.close();
/*     */     } 
/*     */   }
/*     */   
/*     */   void resetCachedAddresses() {
/* 196 */     this.local = this.socket.localAddress();
/* 197 */     this.remote = this.socket.remoteAddress();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void doDisconnect() throws Exception {
/* 202 */     doClose();
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isCompatible(EventLoop loop) {
/* 207 */     return loop instanceof EpollEventLoop;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isOpen() {
/* 212 */     return this.socket.isOpen();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void doDeregister() throws Exception {
/* 217 */     ((EpollEventLoop)eventLoop()).remove(this);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void doBeginRead() throws Exception {
/* 223 */     AbstractEpollUnsafe unsafe = (AbstractEpollUnsafe)unsafe();
/* 224 */     unsafe.readPending = true;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 229 */     setFlag(Native.EPOLLIN);
/*     */ 
/*     */ 
/*     */     
/* 233 */     if (unsafe.maybeMoreDataToRead) {
/* 234 */       unsafe.executeEpollInReadyRunnable((ChannelConfig)config());
/*     */     }
/*     */   }
/*     */   
/*     */   final boolean shouldBreakEpollInReady(ChannelConfig config) {
/* 239 */     return (this.socket.isInputShutdown() && (this.inputClosedSeenErrorOnRead || !isAllowHalfClosure(config)));
/*     */   }
/*     */   
/*     */   private static boolean isAllowHalfClosure(ChannelConfig config) {
/* 243 */     if (config instanceof EpollDomainSocketChannelConfig) {
/* 244 */       return ((EpollDomainSocketChannelConfig)config).isAllowHalfClosure();
/*     */     }
/* 246 */     return (config instanceof SocketChannelConfig && ((SocketChannelConfig)config)
/* 247 */       .isAllowHalfClosure());
/*     */   }
/*     */ 
/*     */   
/*     */   final void clearEpollIn() {
/* 252 */     if (isRegistered()) {
/* 253 */       EventLoop loop = eventLoop();
/* 254 */       final AbstractEpollUnsafe unsafe = (AbstractEpollUnsafe)unsafe();
/* 255 */       if (loop.inEventLoop()) {
/* 256 */         unsafe.clearEpollIn0();
/*     */       } else {
/*     */         
/* 259 */         loop.execute(new Runnable()
/*     */             {
/*     */               public void run() {
/* 262 */                 if (!unsafe.readPending && !AbstractEpollChannel.this.config().isAutoRead())
/*     */                 {
/* 264 */                   unsafe.clearEpollIn0();
/*     */                 }
/*     */               }
/*     */             });
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/* 272 */       this.flags &= Native.EPOLLIN ^ 0xFFFFFFFF;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void modifyEvents() throws IOException {
/* 277 */     if (isOpen() && isRegistered()) {
/* 278 */       ((EpollEventLoop)eventLoop()).modify(this);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void doRegister() throws Exception {
/* 287 */     this.epollInReadyRunnablePending = false;
/* 288 */     ((EpollEventLoop)eventLoop()).add(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final ByteBuf newDirectBuffer(ByteBuf buf) {
/* 298 */     return newDirectBuffer(buf, buf);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final ByteBuf newDirectBuffer(Object holder, ByteBuf buf) {
/* 307 */     int readableBytes = buf.readableBytes();
/* 308 */     if (readableBytes == 0) {
/* 309 */       ReferenceCountUtil.release(holder);
/* 310 */       return Unpooled.EMPTY_BUFFER;
/*     */     } 
/*     */     
/* 313 */     ByteBufAllocator alloc = alloc();
/* 314 */     if (alloc.isDirectBufferPooled()) {
/* 315 */       return newDirectBuffer0(holder, buf, alloc, readableBytes);
/*     */     }
/*     */     
/* 318 */     ByteBuf directBuf = ByteBufUtil.threadLocalDirectBuffer();
/* 319 */     if (directBuf == null) {
/* 320 */       return newDirectBuffer0(holder, buf, alloc, readableBytes);
/*     */     }
/*     */     
/* 323 */     directBuf.writeBytes(buf, buf.readerIndex(), readableBytes);
/* 324 */     ReferenceCountUtil.safeRelease(holder);
/* 325 */     return directBuf;
/*     */   }
/*     */   
/*     */   private static ByteBuf newDirectBuffer0(Object holder, ByteBuf buf, ByteBufAllocator alloc, int capacity) {
/* 329 */     ByteBuf directBuf = alloc.directBuffer(capacity);
/* 330 */     directBuf.writeBytes(buf, buf.readerIndex(), capacity);
/* 331 */     ReferenceCountUtil.safeRelease(holder);
/* 332 */     return directBuf;
/*     */   }
/*     */   
/*     */   protected static void checkResolvable(InetSocketAddress addr) {
/* 336 */     if (addr.isUnresolved()) {
/* 337 */       throw new UnresolvedAddressException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final int doReadBytes(ByteBuf byteBuf) throws Exception {
/* 345 */     int localReadAmount, writerIndex = byteBuf.writerIndex();
/*     */     
/* 347 */     unsafe().recvBufAllocHandle().attemptedBytesRead(byteBuf.writableBytes());
/* 348 */     if (byteBuf.hasMemoryAddress()) {
/* 349 */       localReadAmount = this.socket.recvAddress(byteBuf.memoryAddress(), writerIndex, byteBuf.capacity());
/*     */     } else {
/* 351 */       ByteBuffer buf = byteBuf.internalNioBuffer(writerIndex, byteBuf.writableBytes());
/* 352 */       localReadAmount = this.socket.recv(buf, buf.position(), buf.limit());
/*     */     } 
/* 354 */     if (localReadAmount > 0) {
/* 355 */       byteBuf.writerIndex(writerIndex + localReadAmount);
/*     */     }
/* 357 */     return localReadAmount;
/*     */   }
/*     */   
/*     */   protected final int doWriteBytes(ChannelOutboundBuffer in, ByteBuf buf) throws Exception {
/* 361 */     if (buf.hasMemoryAddress()) {
/* 362 */       int localFlushedAmount = this.socket.sendAddress(buf.memoryAddress(), buf.readerIndex(), buf.writerIndex());
/* 363 */       if (localFlushedAmount > 0) {
/* 364 */         in.removeBytes(localFlushedAmount);
/* 365 */         return 1;
/*     */       } 
/*     */     } else {
/*     */       
/* 369 */       ByteBuffer nioBuf = (buf.nioBufferCount() == 1) ? buf.internalNioBuffer(buf.readerIndex(), buf.readableBytes()) : buf.nioBuffer();
/* 370 */       int localFlushedAmount = this.socket.send(nioBuf, nioBuf.position(), nioBuf.limit());
/* 371 */       if (localFlushedAmount > 0) {
/* 372 */         nioBuf.position(nioBuf.position() + localFlushedAmount);
/* 373 */         in.removeBytes(localFlushedAmount);
/* 374 */         return 1;
/*     */       } 
/*     */     } 
/* 377 */     return Integer.MAX_VALUE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final long doWriteOrSendBytes(ByteBuf data, InetSocketAddress remoteAddress, boolean fastOpen) throws IOException {
/* 386 */     assert !fastOpen || remoteAddress != null : "fastOpen requires a remote address";
/* 387 */     if (data.hasMemoryAddress()) {
/* 388 */       long memoryAddress = data.memoryAddress();
/* 389 */       if (remoteAddress == null) {
/* 390 */         return this.socket.sendAddress(memoryAddress, data.readerIndex(), data.writerIndex());
/*     */       }
/* 392 */       return this.socket.sendToAddress(memoryAddress, data.readerIndex(), data.writerIndex(), remoteAddress
/* 393 */           .getAddress(), remoteAddress.getPort(), fastOpen);
/*     */     } 
/*     */     
/* 396 */     if (data.nioBufferCount() > 1) {
/* 397 */       IovArray array = ((EpollEventLoop)eventLoop()).cleanIovArray();
/* 398 */       array.add(data, data.readerIndex(), data.readableBytes());
/* 399 */       int cnt = array.count();
/* 400 */       assert cnt != 0;
/*     */       
/* 402 */       if (remoteAddress == null) {
/* 403 */         return this.socket.writevAddresses(array.memoryAddress(0), cnt);
/*     */       }
/* 405 */       return this.socket.sendToAddresses(array.memoryAddress(0), cnt, remoteAddress
/* 406 */           .getAddress(), remoteAddress.getPort(), fastOpen);
/*     */     } 
/*     */     
/* 409 */     ByteBuffer nioData = data.internalNioBuffer(data.readerIndex(), data.readableBytes());
/* 410 */     if (remoteAddress == null) {
/* 411 */       return this.socket.send(nioData, nioData.position(), nioData.limit());
/*     */     }
/* 413 */     return this.socket.sendTo(nioData, nioData.position(), nioData.limit(), remoteAddress
/* 414 */         .getAddress(), remoteAddress.getPort(), fastOpen);
/*     */   }
/*     */   protected abstract class AbstractEpollUnsafe extends AbstractChannel.AbstractUnsafe { protected AbstractEpollUnsafe() {
/* 417 */       super(AbstractEpollChannel.this);
/*     */ 
/*     */ 
/*     */       
/* 421 */       this.epollInReadyRunnable = new Runnable()
/*     */         {
/*     */           public void run() {
/* 424 */             AbstractEpollChannel.this.epollInReadyRunnablePending = false;
/* 425 */             AbstractEpollChannel.AbstractEpollUnsafe.this.epollInReady();
/*     */           }
/*     */         };
/*     */     }
/*     */     boolean readPending;
/*     */     boolean maybeMoreDataToRead;
/*     */     private EpollRecvByteAllocatorHandle allocHandle;
/*     */     private final Runnable epollInReadyRunnable;
/*     */     
/*     */     final void epollInBefore() {
/* 435 */       this.maybeMoreDataToRead = false;
/*     */     }
/*     */     
/*     */     final void epollInFinally(ChannelConfig config) {
/* 439 */       this.maybeMoreDataToRead = this.allocHandle.maybeMoreDataToRead();
/*     */       
/* 441 */       if (this.allocHandle.isReceivedRdHup() || (this.readPending && this.maybeMoreDataToRead)) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 449 */         executeEpollInReadyRunnable(config);
/* 450 */       } else if (!this.readPending && !config.isAutoRead()) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 457 */         AbstractEpollChannel.this.clearEpollIn();
/*     */       } 
/*     */     }
/*     */     
/*     */     final void executeEpollInReadyRunnable(ChannelConfig config) {
/* 462 */       if (AbstractEpollChannel.this.epollInReadyRunnablePending || !AbstractEpollChannel.this.isActive() || AbstractEpollChannel.this.shouldBreakEpollInReady(config)) {
/*     */         return;
/*     */       }
/* 465 */       AbstractEpollChannel.this.epollInReadyRunnablePending = true;
/* 466 */       AbstractEpollChannel.this.eventLoop().execute(this.epollInReadyRunnable);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     final void epollRdHupReady() {
/* 474 */       recvBufAllocHandle().receivedRdHup();
/*     */       
/* 476 */       if (AbstractEpollChannel.this.isActive()) {
/*     */ 
/*     */ 
/*     */         
/* 480 */         epollInReady();
/*     */       } else {
/*     */         
/* 483 */         shutdownInput(true);
/*     */       } 
/*     */ 
/*     */       
/* 487 */       clearEpollRdHup();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private void clearEpollRdHup() {
/*     */       try {
/* 495 */         AbstractEpollChannel.this.clearFlag(Native.EPOLLRDHUP);
/* 496 */       } catch (IOException e) {
/* 497 */         AbstractEpollChannel.this.pipeline().fireExceptionCaught(e);
/* 498 */         close(voidPromise());
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void shutdownInput(boolean rdHup) {
/* 506 */       if (!AbstractEpollChannel.this.socket.isInputShutdown()) {
/* 507 */         if (AbstractEpollChannel.isAllowHalfClosure((ChannelConfig)AbstractEpollChannel.this.config())) {
/*     */           try {
/* 509 */             AbstractEpollChannel.this.socket.shutdown(true, false);
/* 510 */           } catch (IOException ignored) {
/*     */ 
/*     */             
/* 513 */             fireEventAndClose(ChannelInputShutdownEvent.INSTANCE);
/*     */             return;
/* 515 */           } catch (NotYetConnectedException notYetConnectedException) {}
/*     */ 
/*     */ 
/*     */           
/* 519 */           clearEpollIn0();
/* 520 */           AbstractEpollChannel.this.pipeline().fireUserEventTriggered(ChannelInputShutdownEvent.INSTANCE);
/*     */         } else {
/* 522 */           close(voidPromise());
/*     */         } 
/* 524 */       } else if (!rdHup && !AbstractEpollChannel.this.inputClosedSeenErrorOnRead) {
/* 525 */         AbstractEpollChannel.this.inputClosedSeenErrorOnRead = true;
/* 526 */         AbstractEpollChannel.this.pipeline().fireUserEventTriggered(ChannelInputShutdownReadComplete.INSTANCE);
/*     */       } 
/*     */     }
/*     */     
/*     */     private void fireEventAndClose(Object evt) {
/* 531 */       AbstractEpollChannel.this.pipeline().fireUserEventTriggered(evt);
/* 532 */       close(voidPromise());
/*     */     }
/*     */ 
/*     */     
/*     */     public EpollRecvByteAllocatorHandle recvBufAllocHandle() {
/* 537 */       if (this.allocHandle == null) {
/* 538 */         this.allocHandle = newEpollHandle((RecvByteBufAllocator.ExtendedHandle)super.recvBufAllocHandle());
/*     */       }
/* 540 */       return this.allocHandle;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     EpollRecvByteAllocatorHandle newEpollHandle(RecvByteBufAllocator.ExtendedHandle handle) {
/* 548 */       return new EpollRecvByteAllocatorHandle(handle);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected final void flush0() {
/* 556 */       if (!AbstractEpollChannel.this.isFlagSet(Native.EPOLLOUT)) {
/* 557 */         super.flush0();
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     final void epollOutReady() {
/* 565 */       if (AbstractEpollChannel.this.connectPromise != null) {
/*     */         
/* 567 */         finishConnect();
/* 568 */       } else if (!AbstractEpollChannel.this.socket.isOutputShutdown()) {
/*     */         
/* 570 */         super.flush0();
/*     */       } 
/*     */     }
/*     */     
/*     */     protected final void clearEpollIn0() {
/* 575 */       assert AbstractEpollChannel.this.eventLoop().inEventLoop();
/*     */       try {
/* 577 */         this.readPending = false;
/* 578 */         AbstractEpollChannel.this.clearFlag(Native.EPOLLIN);
/* 579 */       } catch (IOException e) {
/*     */ 
/*     */         
/* 582 */         AbstractEpollChannel.this.pipeline().fireExceptionCaught(e);
/* 583 */         AbstractEpollChannel.this.unsafe().close(AbstractEpollChannel.this.unsafe().voidPromise());
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void connect(final SocketAddress remoteAddress, SocketAddress localAddress, ChannelPromise promise) {
/* 590 */       if (!promise.setUncancellable() || !ensureOpen(promise)) {
/*     */         return;
/*     */       }
/*     */       
/*     */       try {
/* 595 */         if (AbstractEpollChannel.this.connectPromise != null) {
/* 596 */           throw new ConnectionPendingException();
/*     */         }
/*     */         
/* 599 */         boolean wasActive = AbstractEpollChannel.this.isActive();
/* 600 */         if (AbstractEpollChannel.this.doConnect(remoteAddress, localAddress)) {
/* 601 */           fulfillConnectPromise(promise, wasActive);
/*     */         } else {
/* 603 */           AbstractEpollChannel.this.connectPromise = promise;
/* 604 */           AbstractEpollChannel.this.requestedRemoteAddress = remoteAddress;
/*     */ 
/*     */           
/* 607 */           int connectTimeoutMillis = AbstractEpollChannel.this.config().getConnectTimeoutMillis();
/* 608 */           if (connectTimeoutMillis > 0) {
/* 609 */             AbstractEpollChannel.this.connectTimeoutFuture = (Future<?>)AbstractEpollChannel.this.eventLoop().schedule(new Runnable()
/*     */                 {
/*     */                   public void run() {
/* 612 */                     ChannelPromise connectPromise = AbstractEpollChannel.this.connectPromise;
/* 613 */                     if (connectPromise != null && !connectPromise.isDone() && connectPromise
/* 614 */                       .tryFailure((Throwable)new ConnectTimeoutException("connection timed out: " + remoteAddress)))
/*     */                     {
/* 616 */                       AbstractEpollChannel.AbstractEpollUnsafe.this.close(AbstractEpollChannel.AbstractEpollUnsafe.this.voidPromise());
/*     */                     }
/*     */                   }
/*     */                 },  connectTimeoutMillis, TimeUnit.MILLISECONDS);
/*     */           }
/*     */           
/* 622 */           promise.addListener((GenericFutureListener)new ChannelFutureListener()
/*     */               {
/*     */                 public void operationComplete(ChannelFuture future) throws Exception {
/* 625 */                   if (future.isCancelled()) {
/* 626 */                     if (AbstractEpollChannel.this.connectTimeoutFuture != null) {
/* 627 */                       AbstractEpollChannel.this.connectTimeoutFuture.cancel(false);
/*     */                     }
/* 629 */                     AbstractEpollChannel.this.connectPromise = null;
/* 630 */                     AbstractEpollChannel.AbstractEpollUnsafe.this.close(AbstractEpollChannel.AbstractEpollUnsafe.this.voidPromise());
/*     */                   } 
/*     */                 }
/*     */               });
/*     */         } 
/* 635 */       } catch (Throwable t) {
/* 636 */         closeIfClosed();
/* 637 */         promise.tryFailure(annotateConnectException(t, remoteAddress));
/*     */       } 
/*     */     }
/*     */     
/*     */     private void fulfillConnectPromise(ChannelPromise promise, boolean wasActive) {
/* 642 */       if (promise == null) {
/*     */         return;
/*     */       }
/*     */       
/* 646 */       AbstractEpollChannel.this.active = true;
/*     */ 
/*     */ 
/*     */       
/* 650 */       boolean active = AbstractEpollChannel.this.isActive();
/*     */ 
/*     */       
/* 653 */       boolean promiseSet = promise.trySuccess();
/*     */ 
/*     */ 
/*     */       
/* 657 */       if (!wasActive && active) {
/* 658 */         AbstractEpollChannel.this.pipeline().fireChannelActive();
/*     */       }
/*     */ 
/*     */       
/* 662 */       if (!promiseSet) {
/* 663 */         close(voidPromise());
/*     */       }
/*     */     }
/*     */     
/*     */     private void fulfillConnectPromise(ChannelPromise promise, Throwable cause) {
/* 668 */       if (promise == null) {
/*     */         return;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 674 */       promise.tryFailure(cause);
/* 675 */       closeIfClosed();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private void finishConnect() {
/* 682 */       assert AbstractEpollChannel.this.eventLoop().inEventLoop();
/*     */       
/* 684 */       boolean connectStillInProgress = false;
/*     */       try {
/* 686 */         boolean wasActive = AbstractEpollChannel.this.isActive();
/* 687 */         if (!doFinishConnect()) {
/* 688 */           connectStillInProgress = true;
/*     */           return;
/*     */         } 
/* 691 */         fulfillConnectPromise(AbstractEpollChannel.this.connectPromise, wasActive);
/* 692 */       } catch (Throwable t) {
/* 693 */         fulfillConnectPromise(AbstractEpollChannel.this.connectPromise, annotateConnectException(t, AbstractEpollChannel.this.requestedRemoteAddress));
/*     */       } finally {
/* 695 */         if (!connectStillInProgress) {
/*     */ 
/*     */           
/* 698 */           if (AbstractEpollChannel.this.connectTimeoutFuture != null) {
/* 699 */             AbstractEpollChannel.this.connectTimeoutFuture.cancel(false);
/*     */           }
/* 701 */           AbstractEpollChannel.this.connectPromise = null;
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private boolean doFinishConnect() throws Exception {
/* 710 */       if (AbstractEpollChannel.this.socket.finishConnect()) {
/* 711 */         AbstractEpollChannel.this.clearFlag(Native.EPOLLOUT);
/* 712 */         if (AbstractEpollChannel.this.requestedRemoteAddress instanceof InetSocketAddress) {
/* 713 */           AbstractEpollChannel.this.remote = UnixChannelUtil.computeRemoteAddr((InetSocketAddress)AbstractEpollChannel.this.requestedRemoteAddress, AbstractEpollChannel.this.socket.remoteAddress());
/*     */         }
/* 715 */         AbstractEpollChannel.this.requestedRemoteAddress = null;
/*     */         
/* 717 */         return true;
/*     */       } 
/* 719 */       AbstractEpollChannel.this.setFlag(Native.EPOLLOUT);
/* 720 */       return false;
/*     */     }
/*     */     
/*     */     abstract void epollInReady(); }
/*     */   
/*     */   protected void doBind(SocketAddress local) throws Exception {
/* 726 */     if (local instanceof InetSocketAddress) {
/* 727 */       checkResolvable((InetSocketAddress)local);
/*     */     }
/* 729 */     this.socket.bind(local);
/* 730 */     this.local = this.socket.localAddress();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean doConnect(SocketAddress remoteAddress, SocketAddress localAddress) throws Exception {
/* 737 */     if (localAddress instanceof InetSocketAddress) {
/* 738 */       checkResolvable((InetSocketAddress)localAddress);
/*     */     }
/*     */     
/* 741 */     InetSocketAddress remoteSocketAddr = (remoteAddress instanceof InetSocketAddress) ? (InetSocketAddress)remoteAddress : null;
/*     */     
/* 743 */     if (remoteSocketAddr != null) {
/* 744 */       checkResolvable(remoteSocketAddr);
/*     */     }
/*     */     
/* 747 */     if (this.remote != null)
/*     */     {
/*     */ 
/*     */       
/* 751 */       throw new AlreadyConnectedException();
/*     */     }
/*     */     
/* 754 */     if (localAddress != null) {
/* 755 */       this.socket.bind(localAddress);
/*     */     }
/*     */     
/* 758 */     boolean connected = doConnect0(remoteAddress);
/* 759 */     if (connected) {
/* 760 */       this
/* 761 */         .remote = (remoteSocketAddr == null) ? remoteAddress : UnixChannelUtil.computeRemoteAddr(remoteSocketAddr, this.socket.remoteAddress());
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 766 */     this.local = this.socket.localAddress();
/* 767 */     return connected;
/*     */   }
/*     */   
/*     */   boolean doConnect0(SocketAddress remote) throws Exception {
/* 771 */     boolean success = false;
/*     */     try {
/* 773 */       boolean connected = this.socket.connect(remote);
/* 774 */       if (!connected) {
/* 775 */         setFlag(Native.EPOLLOUT);
/*     */       }
/* 777 */       success = true;
/* 778 */       return connected;
/*     */     } finally {
/* 780 */       if (!success) {
/* 781 */         doClose();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected SocketAddress localAddress0() {
/* 788 */     return this.local;
/*     */   }
/*     */ 
/*     */   
/*     */   protected SocketAddress remoteAddress0() {
/* 793 */     return this.remote;
/*     */   }
/*     */   
/*     */   public abstract EpollChannelConfig config();
/*     */   
/*     */   protected abstract AbstractEpollUnsafe newUnsafe();
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-transport-classes-epoll-4.1.93.Final.jar!\io\netty\channel\epoll\AbstractEpollChannel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */