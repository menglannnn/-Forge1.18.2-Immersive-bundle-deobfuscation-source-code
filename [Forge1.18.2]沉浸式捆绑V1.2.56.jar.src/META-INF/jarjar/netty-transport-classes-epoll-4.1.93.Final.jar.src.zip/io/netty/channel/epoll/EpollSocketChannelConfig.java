/*     */ package io.netty.channel.epoll;
/*     */ 
/*     */ import io.netty.buffer.ByteBufAllocator;
/*     */ import io.netty.channel.ChannelConfig;
/*     */ import io.netty.channel.ChannelException;
/*     */ import io.netty.channel.ChannelOption;
/*     */ import io.netty.channel.MessageSizeEstimator;
/*     */ import io.netty.channel.RecvByteBufAllocator;
/*     */ import io.netty.channel.WriteBufferWaterMark;
/*     */ import io.netty.channel.socket.DuplexChannelConfig;
/*     */ import io.netty.channel.socket.SocketChannelConfig;
/*     */ import io.netty.util.internal.PlatformDependent;
/*     */ import java.io.IOException;
/*     */ import java.net.InetAddress;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class EpollSocketChannelConfig
/*     */   extends EpollChannelConfig
/*     */   implements SocketChannelConfig
/*     */ {
/*     */   private volatile boolean allowHalfClosure;
/*     */   private volatile boolean tcpFastopen;
/*     */   
/*     */   EpollSocketChannelConfig(EpollSocketChannel channel) {
/*  48 */     super(channel);
/*     */     
/*  50 */     if (PlatformDependent.canEnableTcpNoDelayByDefault()) {
/*  51 */       setTcpNoDelay(true);
/*     */     }
/*  53 */     calculateMaxBytesPerGatheringWrite();
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<ChannelOption<?>, Object> getOptions() {
/*  58 */     return getOptions(super
/*  59 */         .getOptions(), new ChannelOption[] { ChannelOption.SO_RCVBUF, ChannelOption.SO_SNDBUF, ChannelOption.TCP_NODELAY, ChannelOption.SO_KEEPALIVE, ChannelOption.SO_REUSEADDR, ChannelOption.SO_LINGER, ChannelOption.IP_TOS, ChannelOption.ALLOW_HALF_CLOSURE, EpollChannelOption.TCP_CORK, EpollChannelOption.TCP_NOTSENT_LOWAT, EpollChannelOption.TCP_KEEPCNT, EpollChannelOption.TCP_KEEPIDLE, EpollChannelOption.TCP_KEEPINTVL, EpollChannelOption.TCP_MD5SIG, EpollChannelOption.TCP_QUICKACK, EpollChannelOption.IP_TRANSPARENT, ChannelOption.TCP_FASTOPEN_CONNECT, EpollChannelOption.SO_BUSY_POLL });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T getOption(ChannelOption<T> option) {
/*  70 */     if (option == ChannelOption.SO_RCVBUF) {
/*  71 */       return (T)Integer.valueOf(getReceiveBufferSize());
/*     */     }
/*  73 */     if (option == ChannelOption.SO_SNDBUF) {
/*  74 */       return (T)Integer.valueOf(getSendBufferSize());
/*     */     }
/*  76 */     if (option == ChannelOption.TCP_NODELAY) {
/*  77 */       return (T)Boolean.valueOf(isTcpNoDelay());
/*     */     }
/*  79 */     if (option == ChannelOption.SO_KEEPALIVE) {
/*  80 */       return (T)Boolean.valueOf(isKeepAlive());
/*     */     }
/*  82 */     if (option == ChannelOption.SO_REUSEADDR) {
/*  83 */       return (T)Boolean.valueOf(isReuseAddress());
/*     */     }
/*  85 */     if (option == ChannelOption.SO_LINGER) {
/*  86 */       return (T)Integer.valueOf(getSoLinger());
/*     */     }
/*  88 */     if (option == ChannelOption.IP_TOS) {
/*  89 */       return (T)Integer.valueOf(getTrafficClass());
/*     */     }
/*  91 */     if (option == ChannelOption.ALLOW_HALF_CLOSURE) {
/*  92 */       return (T)Boolean.valueOf(isAllowHalfClosure());
/*     */     }
/*  94 */     if (option == EpollChannelOption.TCP_CORK) {
/*  95 */       return (T)Boolean.valueOf(isTcpCork());
/*     */     }
/*  97 */     if (option == EpollChannelOption.TCP_NOTSENT_LOWAT) {
/*  98 */       return (T)Long.valueOf(getTcpNotSentLowAt());
/*     */     }
/* 100 */     if (option == EpollChannelOption.TCP_KEEPIDLE) {
/* 101 */       return (T)Integer.valueOf(getTcpKeepIdle());
/*     */     }
/* 103 */     if (option == EpollChannelOption.TCP_KEEPINTVL) {
/* 104 */       return (T)Integer.valueOf(getTcpKeepIntvl());
/*     */     }
/* 106 */     if (option == EpollChannelOption.TCP_KEEPCNT) {
/* 107 */       return (T)Integer.valueOf(getTcpKeepCnt());
/*     */     }
/* 109 */     if (option == EpollChannelOption.TCP_USER_TIMEOUT) {
/* 110 */       return (T)Integer.valueOf(getTcpUserTimeout());
/*     */     }
/* 112 */     if (option == EpollChannelOption.TCP_QUICKACK) {
/* 113 */       return (T)Boolean.valueOf(isTcpQuickAck());
/*     */     }
/* 115 */     if (option == EpollChannelOption.IP_TRANSPARENT) {
/* 116 */       return (T)Boolean.valueOf(isIpTransparent());
/*     */     }
/* 118 */     if (option == ChannelOption.TCP_FASTOPEN_CONNECT) {
/* 119 */       return (T)Boolean.valueOf(isTcpFastOpenConnect());
/*     */     }
/* 121 */     if (option == EpollChannelOption.SO_BUSY_POLL) {
/* 122 */       return (T)Integer.valueOf(getSoBusyPoll());
/*     */     }
/* 124 */     return super.getOption(option);
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> boolean setOption(ChannelOption<T> option, T value) {
/* 129 */     validate(option, value);
/*     */     
/* 131 */     if (option == ChannelOption.SO_RCVBUF) {
/* 132 */       setReceiveBufferSize(((Integer)value).intValue());
/* 133 */     } else if (option == ChannelOption.SO_SNDBUF) {
/* 134 */       setSendBufferSize(((Integer)value).intValue());
/* 135 */     } else if (option == ChannelOption.TCP_NODELAY) {
/* 136 */       setTcpNoDelay(((Boolean)value).booleanValue());
/* 137 */     } else if (option == ChannelOption.SO_KEEPALIVE) {
/* 138 */       setKeepAlive(((Boolean)value).booleanValue());
/* 139 */     } else if (option == ChannelOption.SO_REUSEADDR) {
/* 140 */       setReuseAddress(((Boolean)value).booleanValue());
/* 141 */     } else if (option == ChannelOption.SO_LINGER) {
/* 142 */       setSoLinger(((Integer)value).intValue());
/* 143 */     } else if (option == ChannelOption.IP_TOS) {
/* 144 */       setTrafficClass(((Integer)value).intValue());
/* 145 */     } else if (option == ChannelOption.ALLOW_HALF_CLOSURE) {
/* 146 */       setAllowHalfClosure(((Boolean)value).booleanValue());
/* 147 */     } else if (option == EpollChannelOption.TCP_CORK) {
/* 148 */       setTcpCork(((Boolean)value).booleanValue());
/* 149 */     } else if (option == EpollChannelOption.TCP_NOTSENT_LOWAT) {
/* 150 */       setTcpNotSentLowAt(((Long)value).longValue());
/* 151 */     } else if (option == EpollChannelOption.TCP_KEEPIDLE) {
/* 152 */       setTcpKeepIdle(((Integer)value).intValue());
/* 153 */     } else if (option == EpollChannelOption.TCP_KEEPCNT) {
/* 154 */       setTcpKeepCnt(((Integer)value).intValue());
/* 155 */     } else if (option == EpollChannelOption.TCP_KEEPINTVL) {
/* 156 */       setTcpKeepIntvl(((Integer)value).intValue());
/* 157 */     } else if (option == EpollChannelOption.TCP_USER_TIMEOUT) {
/* 158 */       setTcpUserTimeout(((Integer)value).intValue());
/* 159 */     } else if (option == EpollChannelOption.IP_TRANSPARENT) {
/* 160 */       setIpTransparent(((Boolean)value).booleanValue());
/* 161 */     } else if (option == EpollChannelOption.TCP_MD5SIG) {
/*     */       
/* 163 */       Map<InetAddress, byte[]> m = (Map<InetAddress, byte[]>)value;
/* 164 */       setTcpMd5Sig(m);
/* 165 */     } else if (option == EpollChannelOption.TCP_QUICKACK) {
/* 166 */       setTcpQuickAck(((Boolean)value).booleanValue());
/* 167 */     } else if (option == ChannelOption.TCP_FASTOPEN_CONNECT) {
/* 168 */       setTcpFastOpenConnect(((Boolean)value).booleanValue());
/* 169 */     } else if (option == EpollChannelOption.SO_BUSY_POLL) {
/* 170 */       setSoBusyPoll(((Integer)value).intValue());
/*     */     } else {
/* 172 */       return super.setOption(option, value);
/*     */     } 
/*     */     
/* 175 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getReceiveBufferSize() {
/*     */     try {
/* 181 */       return ((EpollSocketChannel)this.channel).socket.getReceiveBufferSize();
/* 182 */     } catch (IOException e) {
/* 183 */       throw new ChannelException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int getSendBufferSize() {
/*     */     try {
/* 190 */       return ((EpollSocketChannel)this.channel).socket.getSendBufferSize();
/* 191 */     } catch (IOException e) {
/* 192 */       throw new ChannelException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int getSoLinger() {
/*     */     try {
/* 199 */       return ((EpollSocketChannel)this.channel).socket.getSoLinger();
/* 200 */     } catch (IOException e) {
/* 201 */       throw new ChannelException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int getTrafficClass() {
/*     */     try {
/* 208 */       return ((EpollSocketChannel)this.channel).socket.getTrafficClass();
/* 209 */     } catch (IOException e) {
/* 210 */       throw new ChannelException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isKeepAlive() {
/*     */     try {
/* 217 */       return ((EpollSocketChannel)this.channel).socket.isKeepAlive();
/* 218 */     } catch (IOException e) {
/* 219 */       throw new ChannelException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isReuseAddress() {
/*     */     try {
/* 226 */       return ((EpollSocketChannel)this.channel).socket.isReuseAddress();
/* 227 */     } catch (IOException e) {
/* 228 */       throw new ChannelException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isTcpNoDelay() {
/*     */     try {
/* 235 */       return ((EpollSocketChannel)this.channel).socket.isTcpNoDelay();
/* 236 */     } catch (IOException e) {
/* 237 */       throw new ChannelException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isTcpCork() {
/*     */     try {
/* 246 */       return ((EpollSocketChannel)this.channel).socket.isTcpCork();
/* 247 */     } catch (IOException e) {
/* 248 */       throw new ChannelException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSoBusyPoll() {
/*     */     try {
/* 257 */       return ((EpollSocketChannel)this.channel).socket.getSoBusyPoll();
/* 258 */     } catch (IOException e) {
/* 259 */       throw new ChannelException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getTcpNotSentLowAt() {
/*     */     try {
/* 269 */       return ((EpollSocketChannel)this.channel).socket.getTcpNotSentLowAt();
/* 270 */     } catch (IOException e) {
/* 271 */       throw new ChannelException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getTcpKeepIdle() {
/*     */     try {
/* 280 */       return ((EpollSocketChannel)this.channel).socket.getTcpKeepIdle();
/* 281 */     } catch (IOException e) {
/* 282 */       throw new ChannelException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getTcpKeepIntvl() {
/*     */     try {
/* 291 */       return ((EpollSocketChannel)this.channel).socket.getTcpKeepIntvl();
/* 292 */     } catch (IOException e) {
/* 293 */       throw new ChannelException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getTcpKeepCnt() {
/*     */     try {
/* 302 */       return ((EpollSocketChannel)this.channel).socket.getTcpKeepCnt();
/* 303 */     } catch (IOException e) {
/* 304 */       throw new ChannelException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getTcpUserTimeout() {
/*     */     try {
/* 313 */       return ((EpollSocketChannel)this.channel).socket.getTcpUserTimeout();
/* 314 */     } catch (IOException e) {
/* 315 */       throw new ChannelException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public EpollSocketChannelConfig setKeepAlive(boolean keepAlive) {
/*     */     try {
/* 322 */       ((EpollSocketChannel)this.channel).socket.setKeepAlive(keepAlive);
/* 323 */       return this;
/* 324 */     } catch (IOException e) {
/* 325 */       throw new ChannelException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public EpollSocketChannelConfig setPerformancePreferences(int connectionTime, int latency, int bandwidth) {
/* 332 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public EpollSocketChannelConfig setReceiveBufferSize(int receiveBufferSize) {
/*     */     try {
/* 338 */       ((EpollSocketChannel)this.channel).socket.setReceiveBufferSize(receiveBufferSize);
/* 339 */       return this;
/* 340 */     } catch (IOException e) {
/* 341 */       throw new ChannelException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public EpollSocketChannelConfig setReuseAddress(boolean reuseAddress) {
/*     */     try {
/* 348 */       ((EpollSocketChannel)this.channel).socket.setReuseAddress(reuseAddress);
/* 349 */       return this;
/* 350 */     } catch (IOException e) {
/* 351 */       throw new ChannelException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public EpollSocketChannelConfig setSendBufferSize(int sendBufferSize) {
/*     */     try {
/* 358 */       ((EpollSocketChannel)this.channel).socket.setSendBufferSize(sendBufferSize);
/* 359 */       calculateMaxBytesPerGatheringWrite();
/* 360 */       return this;
/* 361 */     } catch (IOException e) {
/* 362 */       throw new ChannelException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public EpollSocketChannelConfig setSoLinger(int soLinger) {
/*     */     try {
/* 369 */       ((EpollSocketChannel)this.channel).socket.setSoLinger(soLinger);
/* 370 */       return this;
/* 371 */     } catch (IOException e) {
/* 372 */       throw new ChannelException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public EpollSocketChannelConfig setTcpNoDelay(boolean tcpNoDelay) {
/*     */     try {
/* 379 */       ((EpollSocketChannel)this.channel).socket.setTcpNoDelay(tcpNoDelay);
/* 380 */       return this;
/* 381 */     } catch (IOException e) {
/* 382 */       throw new ChannelException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EpollSocketChannelConfig setTcpCork(boolean tcpCork) {
/*     */     try {
/* 391 */       ((EpollSocketChannel)this.channel).socket.setTcpCork(tcpCork);
/* 392 */       return this;
/* 393 */     } catch (IOException e) {
/* 394 */       throw new ChannelException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EpollSocketChannelConfig setSoBusyPoll(int loopMicros) {
/*     */     try {
/* 403 */       ((EpollSocketChannel)this.channel).socket.setSoBusyPoll(loopMicros);
/* 404 */       return this;
/* 405 */     } catch (IOException e) {
/* 406 */       throw new ChannelException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EpollSocketChannelConfig setTcpNotSentLowAt(long tcpNotSentLowAt) {
/*     */     try {
/* 416 */       ((EpollSocketChannel)this.channel).socket.setTcpNotSentLowAt(tcpNotSentLowAt);
/* 417 */       return this;
/* 418 */     } catch (IOException e) {
/* 419 */       throw new ChannelException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public EpollSocketChannelConfig setTrafficClass(int trafficClass) {
/*     */     try {
/* 426 */       ((EpollSocketChannel)this.channel).socket.setTrafficClass(trafficClass);
/* 427 */       return this;
/* 428 */     } catch (IOException e) {
/* 429 */       throw new ChannelException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EpollSocketChannelConfig setTcpKeepIdle(int seconds) {
/*     */     try {
/* 438 */       ((EpollSocketChannel)this.channel).socket.setTcpKeepIdle(seconds);
/* 439 */       return this;
/* 440 */     } catch (IOException e) {
/* 441 */       throw new ChannelException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EpollSocketChannelConfig setTcpKeepIntvl(int seconds) {
/*     */     try {
/* 450 */       ((EpollSocketChannel)this.channel).socket.setTcpKeepIntvl(seconds);
/* 451 */       return this;
/* 452 */     } catch (IOException e) {
/* 453 */       throw new ChannelException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public EpollSocketChannelConfig setTcpKeepCntl(int probes) {
/* 462 */     return setTcpKeepCnt(probes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EpollSocketChannelConfig setTcpKeepCnt(int probes) {
/*     */     try {
/* 470 */       ((EpollSocketChannel)this.channel).socket.setTcpKeepCnt(probes);
/* 471 */       return this;
/* 472 */     } catch (IOException e) {
/* 473 */       throw new ChannelException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EpollSocketChannelConfig setTcpUserTimeout(int milliseconds) {
/*     */     try {
/* 482 */       ((EpollSocketChannel)this.channel).socket.setTcpUserTimeout(milliseconds);
/* 483 */       return this;
/* 484 */     } catch (IOException e) {
/* 485 */       throw new ChannelException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isIpTransparent() {
/*     */     try {
/* 495 */       return ((EpollSocketChannel)this.channel).socket.isIpTransparent();
/* 496 */     } catch (IOException e) {
/* 497 */       throw new ChannelException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EpollSocketChannelConfig setIpTransparent(boolean transparent) {
/*     */     try {
/* 507 */       ((EpollSocketChannel)this.channel).socket.setIpTransparent(transparent);
/* 508 */       return this;
/* 509 */     } catch (IOException e) {
/* 510 */       throw new ChannelException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EpollSocketChannelConfig setTcpMd5Sig(Map<InetAddress, byte[]> keys) {
/*     */     try {
/* 521 */       ((EpollSocketChannel)this.channel).setTcpMd5Sig(keys);
/* 522 */       return this;
/* 523 */     } catch (IOException e) {
/* 524 */       throw new ChannelException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EpollSocketChannelConfig setTcpQuickAck(boolean quickAck) {
/*     */     try {
/* 535 */       ((EpollSocketChannel)this.channel).socket.setTcpQuickAck(quickAck);
/* 536 */       return this;
/* 537 */     } catch (IOException e) {
/* 538 */       throw new ChannelException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isTcpQuickAck() {
/*     */     try {
/* 548 */       return ((EpollSocketChannel)this.channel).socket.isTcpQuickAck();
/* 549 */     } catch (IOException e) {
/* 550 */       throw new ChannelException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EpollSocketChannelConfig setTcpFastOpenConnect(boolean fastOpenConnect) {
/* 561 */     this.tcpFastopen = fastOpenConnect;
/* 562 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isTcpFastOpenConnect() {
/* 569 */     return this.tcpFastopen;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isAllowHalfClosure() {
/* 574 */     return this.allowHalfClosure;
/*     */   }
/*     */ 
/*     */   
/*     */   public EpollSocketChannelConfig setAllowHalfClosure(boolean allowHalfClosure) {
/* 579 */     this.allowHalfClosure = allowHalfClosure;
/* 580 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public EpollSocketChannelConfig setConnectTimeoutMillis(int connectTimeoutMillis) {
/* 585 */     super.setConnectTimeoutMillis(connectTimeoutMillis);
/* 586 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public EpollSocketChannelConfig setMaxMessagesPerRead(int maxMessagesPerRead) {
/* 592 */     super.setMaxMessagesPerRead(maxMessagesPerRead);
/* 593 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public EpollSocketChannelConfig setWriteSpinCount(int writeSpinCount) {
/* 598 */     super.setWriteSpinCount(writeSpinCount);
/* 599 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public EpollSocketChannelConfig setAllocator(ByteBufAllocator allocator) {
/* 604 */     super.setAllocator(allocator);
/* 605 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public EpollSocketChannelConfig setRecvByteBufAllocator(RecvByteBufAllocator allocator) {
/* 610 */     super.setRecvByteBufAllocator(allocator);
/* 611 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public EpollSocketChannelConfig setAutoRead(boolean autoRead) {
/* 616 */     super.setAutoRead(autoRead);
/* 617 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public EpollSocketChannelConfig setAutoClose(boolean autoClose) {
/* 622 */     super.setAutoClose(autoClose);
/* 623 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public EpollSocketChannelConfig setWriteBufferHighWaterMark(int writeBufferHighWaterMark) {
/* 629 */     super.setWriteBufferHighWaterMark(writeBufferHighWaterMark);
/* 630 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public EpollSocketChannelConfig setWriteBufferLowWaterMark(int writeBufferLowWaterMark) {
/* 636 */     super.setWriteBufferLowWaterMark(writeBufferLowWaterMark);
/* 637 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public EpollSocketChannelConfig setWriteBufferWaterMark(WriteBufferWaterMark writeBufferWaterMark) {
/* 642 */     super.setWriteBufferWaterMark(writeBufferWaterMark);
/* 643 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public EpollSocketChannelConfig setMessageSizeEstimator(MessageSizeEstimator estimator) {
/* 648 */     super.setMessageSizeEstimator(estimator);
/* 649 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public EpollSocketChannelConfig setEpollMode(EpollMode mode) {
/* 654 */     super.setEpollMode(mode);
/* 655 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   private void calculateMaxBytesPerGatheringWrite() {
/* 660 */     int newSendBufferSize = getSendBufferSize() << 1;
/* 661 */     if (newSendBufferSize > 0)
/* 662 */       setMaxBytesPerGatheringWrite((getSendBufferSize() << 1)); 
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-transport-classes-epoll-4.1.93.Final.jar!\io\netty\channel\epoll\EpollSocketChannelConfig.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */