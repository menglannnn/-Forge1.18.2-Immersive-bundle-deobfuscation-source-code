/*     */ package io.netty.channel.epoll;
/*     */ 
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import io.netty.buffer.ByteBufAllocator;
/*     */ import io.netty.channel.AbstractChannel;
/*     */ import io.netty.channel.AddressedEnvelope;
/*     */ import io.netty.channel.Channel;
/*     */ import io.netty.channel.ChannelConfig;
/*     */ import io.netty.channel.ChannelMetadata;
/*     */ import io.netty.channel.ChannelOutboundBuffer;
/*     */ import io.netty.channel.ChannelPipeline;
/*     */ import io.netty.channel.DefaultAddressedEnvelope;
/*     */ import io.netty.channel.unix.DomainDatagramChannel;
/*     */ import io.netty.channel.unix.DomainDatagramChannelConfig;
/*     */ import io.netty.channel.unix.DomainDatagramPacket;
/*     */ import io.netty.channel.unix.DomainDatagramSocketAddress;
/*     */ import io.netty.channel.unix.DomainSocketAddress;
/*     */ import io.netty.channel.unix.IovArray;
/*     */ import io.netty.channel.unix.PeerCredentials;
/*     */ import io.netty.channel.unix.UnixChannelUtil;
/*     */ import io.netty.util.CharsetUtil;
/*     */ import io.netty.util.UncheckedBooleanSupplier;
/*     */ import io.netty.util.internal.StringUtil;
/*     */ import java.io.IOException;
/*     */ import java.net.SocketAddress;
/*     */ import java.nio.ByteBuffer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class EpollDomainDatagramChannel
/*     */   extends AbstractEpollChannel
/*     */   implements DomainDatagramChannel
/*     */ {
/*  47 */   private static final ChannelMetadata METADATA = new ChannelMetadata(true);
/*     */   
/*  49 */   private static final String EXPECTED_TYPES = " (expected: " + 
/*     */     
/*  51 */     StringUtil.simpleClassName(DomainDatagramPacket.class) + ", " + 
/*  52 */     StringUtil.simpleClassName(AddressedEnvelope.class) + '<' + 
/*  53 */     StringUtil.simpleClassName(ByteBuf.class) + ", " + 
/*  54 */     StringUtil.simpleClassName(DomainSocketAddress.class) + ">, " + 
/*  55 */     StringUtil.simpleClassName(ByteBuf.class) + ')';
/*     */   
/*     */   private volatile boolean connected;
/*     */   
/*     */   private volatile DomainSocketAddress local;
/*     */   private volatile DomainSocketAddress remote;
/*     */   private final EpollDomainDatagramChannelConfig config;
/*     */   
/*     */   public EpollDomainDatagramChannel() {
/*  64 */     this(LinuxSocket.newSocketDomainDgram(), false);
/*     */   }
/*     */   
/*     */   public EpollDomainDatagramChannel(int fd) {
/*  68 */     this(new LinuxSocket(fd), true);
/*     */   }
/*     */   
/*     */   private EpollDomainDatagramChannel(LinuxSocket socket, boolean active) {
/*  72 */     super((Channel)null, socket, active);
/*  73 */     this.config = new EpollDomainDatagramChannelConfig(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public EpollDomainDatagramChannelConfig config() {
/*  78 */     return this.config;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void doBind(SocketAddress localAddress) throws Exception {
/*  83 */     super.doBind(localAddress);
/*  84 */     this.local = (DomainSocketAddress)localAddress;
/*  85 */     this.active = true;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void doClose() throws Exception {
/*  90 */     super.doClose();
/*  91 */     this.connected = this.active = false;
/*  92 */     this.local = null;
/*  93 */     this.remote = null;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean doConnect(SocketAddress remoteAddress, SocketAddress localAddress) throws Exception {
/*  98 */     if (super.doConnect(remoteAddress, localAddress)) {
/*  99 */       if (localAddress != null) {
/* 100 */         this.local = (DomainSocketAddress)localAddress;
/*     */       }
/* 102 */       this.remote = (DomainSocketAddress)remoteAddress;
/* 103 */       this.connected = true;
/* 104 */       return true;
/*     */     } 
/* 106 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void doDisconnect() throws Exception {
/* 111 */     doClose();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void doWrite(ChannelOutboundBuffer in) throws Exception {
/* 116 */     int maxMessagesPerWrite = maxMessagesPerWrite();
/* 117 */     while (maxMessagesPerWrite > 0) {
/* 118 */       Object msg = in.current();
/* 119 */       if (msg == null) {
/*     */         break;
/*     */       }
/*     */       
/*     */       try {
/* 124 */         boolean done = false;
/* 125 */         for (int i = config().getWriteSpinCount(); i > 0; i--) {
/* 126 */           if (doWriteMessage(msg)) {
/* 127 */             done = true;
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/* 132 */         if (done) {
/* 133 */           in.remove();
/* 134 */           maxMessagesPerWrite--;
/*     */           continue;
/*     */         } 
/*     */         break;
/* 138 */       } catch (IOException e) {
/* 139 */         maxMessagesPerWrite--;
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 144 */         in.remove(e);
/*     */       } 
/*     */     } 
/*     */     
/* 148 */     if (in.isEmpty()) {
/*     */       
/* 150 */       clearFlag(Native.EPOLLOUT);
/*     */     } else {
/*     */       
/* 153 */       setFlag(Native.EPOLLOUT);
/*     */     } 
/*     */   }
/*     */   private boolean doWriteMessage(Object msg) throws Exception {
/*     */     ByteBuf data;
/*     */     DomainSocketAddress remoteAddress;
/*     */     long writtenBytes;
/* 160 */     if (msg instanceof AddressedEnvelope) {
/*     */       
/* 162 */       AddressedEnvelope<ByteBuf, DomainSocketAddress> envelope = (AddressedEnvelope<ByteBuf, DomainSocketAddress>)msg;
/*     */       
/* 164 */       data = (ByteBuf)envelope.content();
/* 165 */       remoteAddress = (DomainSocketAddress)envelope.recipient();
/*     */     } else {
/* 167 */       data = (ByteBuf)msg;
/* 168 */       remoteAddress = null;
/*     */     } 
/*     */     
/* 171 */     int dataLen = data.readableBytes();
/* 172 */     if (dataLen == 0) {
/* 173 */       return true;
/*     */     }
/*     */ 
/*     */     
/* 177 */     if (data.hasMemoryAddress()) {
/* 178 */       long memoryAddress = data.memoryAddress();
/* 179 */       if (remoteAddress == null) {
/* 180 */         writtenBytes = this.socket.sendAddress(memoryAddress, data.readerIndex(), data.writerIndex());
/*     */       } else {
/* 182 */         writtenBytes = this.socket.sendToAddressDomainSocket(memoryAddress, data.readerIndex(), data.writerIndex(), remoteAddress
/* 183 */             .path().getBytes(CharsetUtil.UTF_8));
/*     */       } 
/* 185 */     } else if (data.nioBufferCount() > 1) {
/* 186 */       IovArray array = ((EpollEventLoop)eventLoop()).cleanIovArray();
/* 187 */       array.add(data, data.readerIndex(), data.readableBytes());
/* 188 */       int cnt = array.count();
/* 189 */       assert cnt != 0;
/*     */       
/* 191 */       if (remoteAddress == null) {
/* 192 */         writtenBytes = this.socket.writevAddresses(array.memoryAddress(0), cnt);
/*     */       } else {
/* 194 */         writtenBytes = this.socket.sendToAddressesDomainSocket(array.memoryAddress(0), cnt, remoteAddress
/* 195 */             .path().getBytes(CharsetUtil.UTF_8));
/*     */       } 
/*     */     } else {
/* 198 */       ByteBuffer nioData = data.internalNioBuffer(data.readerIndex(), data.readableBytes());
/* 199 */       if (remoteAddress == null) {
/* 200 */         writtenBytes = this.socket.send(nioData, nioData.position(), nioData.limit());
/*     */       } else {
/* 202 */         writtenBytes = this.socket.sendToDomainSocket(nioData, nioData.position(), nioData.limit(), remoteAddress
/* 203 */             .path().getBytes(CharsetUtil.UTF_8));
/*     */       } 
/*     */     } 
/*     */     
/* 207 */     return (writtenBytes > 0L);
/*     */   }
/*     */ 
/*     */   
/*     */   protected Object filterOutboundMessage(Object msg) {
/* 212 */     if (msg instanceof DomainDatagramPacket) {
/* 213 */       DomainDatagramPacket packet = (DomainDatagramPacket)msg;
/* 214 */       ByteBuf content = (ByteBuf)packet.content();
/* 215 */       return UnixChannelUtil.isBufferCopyNeededForWrite(content) ? new DomainDatagramPacket(
/* 216 */           newDirectBuffer(packet, content), (DomainSocketAddress)packet.recipient()) : msg;
/*     */     } 
/*     */     
/* 219 */     if (msg instanceof ByteBuf) {
/* 220 */       ByteBuf buf = (ByteBuf)msg;
/* 221 */       return UnixChannelUtil.isBufferCopyNeededForWrite(buf) ? newDirectBuffer(buf) : buf;
/*     */     } 
/*     */     
/* 224 */     if (msg instanceof AddressedEnvelope) {
/*     */       
/* 226 */       AddressedEnvelope<Object, SocketAddress> e = (AddressedEnvelope<Object, SocketAddress>)msg;
/* 227 */       if (e.content() instanceof ByteBuf && (e
/* 228 */         .recipient() == null || e.recipient() instanceof DomainSocketAddress)) {
/*     */         
/* 230 */         ByteBuf content = (ByteBuf)e.content();
/* 231 */         return UnixChannelUtil.isBufferCopyNeededForWrite(content) ? new DefaultAddressedEnvelope(
/*     */             
/* 233 */             newDirectBuffer(e, content), e.recipient()) : e;
/*     */       } 
/*     */     } 
/*     */     
/* 237 */     throw new UnsupportedOperationException("unsupported message type: " + 
/* 238 */         StringUtil.simpleClassName(msg) + EXPECTED_TYPES);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isActive() {
/* 243 */     return (this.socket.isOpen() && ((this.config.getActiveOnOpen() && isRegistered()) || this.active));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isConnected() {
/* 248 */     return this.connected;
/*     */   }
/*     */ 
/*     */   
/*     */   public DomainSocketAddress localAddress() {
/* 253 */     return (DomainSocketAddress)super.localAddress();
/*     */   }
/*     */ 
/*     */   
/*     */   protected DomainSocketAddress localAddress0() {
/* 258 */     return this.local;
/*     */   }
/*     */ 
/*     */   
/*     */   public ChannelMetadata metadata() {
/* 263 */     return METADATA;
/*     */   }
/*     */ 
/*     */   
/*     */   protected AbstractEpollChannel.AbstractEpollUnsafe newUnsafe() {
/* 268 */     return new EpollDomainDatagramChannelUnsafe();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PeerCredentials peerCredentials() throws IOException {
/* 276 */     return this.socket.getPeerCredentials();
/*     */   }
/*     */ 
/*     */   
/*     */   public DomainSocketAddress remoteAddress() {
/* 281 */     return (DomainSocketAddress)super.remoteAddress();
/*     */   }
/*     */ 
/*     */   
/*     */   protected DomainSocketAddress remoteAddress0() {
/* 286 */     return this.remote;
/*     */   }
/*     */   
/*     */   final class EpollDomainDatagramChannelUnsafe
/*     */     extends AbstractEpollChannel.AbstractEpollUnsafe
/*     */   {
/*     */     void epollInReady() {
/* 293 */       assert EpollDomainDatagramChannel.this.eventLoop().inEventLoop();
/* 294 */       DomainDatagramChannelConfig config = EpollDomainDatagramChannel.this.config();
/* 295 */       if (EpollDomainDatagramChannel.this.shouldBreakEpollInReady((ChannelConfig)config)) {
/* 296 */         clearEpollIn0();
/*     */         return;
/*     */       } 
/* 299 */       EpollRecvByteAllocatorHandle allocHandle = recvBufAllocHandle();
/* 300 */       allocHandle.edgeTriggered(EpollDomainDatagramChannel.this.isFlagSet(Native.EPOLLET));
/*     */       
/* 302 */       ChannelPipeline pipeline = EpollDomainDatagramChannel.this.pipeline();
/* 303 */       ByteBufAllocator allocator = config.getAllocator();
/* 304 */       allocHandle.reset((ChannelConfig)config);
/* 305 */       epollInBefore();
/*     */       
/* 307 */       Throwable exception = null;
/*     */       try {
/* 309 */         ByteBuf byteBuf = null;
/*     */         try {
/* 311 */           boolean connected = EpollDomainDatagramChannel.this.isConnected(); do {
/*     */             DomainDatagramPacket packet;
/* 313 */             byteBuf = allocHandle.allocate(allocator);
/* 314 */             allocHandle.attemptedBytesRead(byteBuf.writableBytes());
/*     */ 
/*     */             
/* 317 */             if (connected) {
/* 318 */               allocHandle.lastBytesRead(EpollDomainDatagramChannel.this.doReadBytes(byteBuf));
/* 319 */               if (allocHandle.lastBytesRead() <= 0) {
/*     */                 
/* 321 */                 byteBuf.release();
/*     */                 
/*     */                 break;
/*     */               } 
/* 325 */               packet = new DomainDatagramPacket(byteBuf, (DomainSocketAddress)localAddress(), (DomainSocketAddress)remoteAddress());
/*     */             } else {
/*     */               DomainDatagramSocketAddress remoteAddress; DomainSocketAddress domainSocketAddress;
/* 328 */               if (byteBuf.hasMemoryAddress()) {
/*     */                 
/* 330 */                 remoteAddress = EpollDomainDatagramChannel.this.socket.recvFromAddressDomainSocket(byteBuf.memoryAddress(), byteBuf
/* 331 */                     .writerIndex(), byteBuf.capacity());
/*     */               } else {
/* 333 */                 ByteBuffer nioData = byteBuf.internalNioBuffer(byteBuf
/* 334 */                     .writerIndex(), byteBuf.writableBytes());
/*     */                 
/* 336 */                 remoteAddress = EpollDomainDatagramChannel.this.socket.recvFromDomainSocket(nioData, nioData.position(), nioData.limit());
/*     */               } 
/*     */               
/* 339 */               if (remoteAddress == null) {
/* 340 */                 allocHandle.lastBytesRead(-1);
/* 341 */                 byteBuf.release();
/*     */                 break;
/*     */               } 
/* 344 */               DomainDatagramSocketAddress domainDatagramSocketAddress1 = remoteAddress.localAddress();
/* 345 */               if (domainDatagramSocketAddress1 == null) {
/* 346 */                 domainSocketAddress = (DomainSocketAddress)localAddress();
/*     */               }
/* 348 */               allocHandle.lastBytesRead(remoteAddress.receivedAmount());
/* 349 */               byteBuf.writerIndex(byteBuf.writerIndex() + allocHandle.lastBytesRead());
/*     */               
/* 351 */               packet = new DomainDatagramPacket(byteBuf, domainSocketAddress, (DomainSocketAddress)remoteAddress);
/*     */             } 
/*     */             
/* 354 */             allocHandle.incMessagesRead(1);
/*     */             
/* 356 */             this.readPending = false;
/* 357 */             pipeline.fireChannelRead(packet);
/*     */             
/* 359 */             byteBuf = null;
/*     */ 
/*     */           
/*     */           }
/* 363 */           while (allocHandle.continueReading(UncheckedBooleanSupplier.TRUE_SUPPLIER));
/* 364 */         } catch (Throwable t) {
/* 365 */           if (byteBuf != null) {
/* 366 */             byteBuf.release();
/*     */           }
/* 368 */           exception = t;
/*     */         } 
/*     */         
/* 371 */         allocHandle.readComplete();
/* 372 */         pipeline.fireChannelReadComplete();
/*     */         
/* 374 */         if (exception != null) {
/* 375 */           pipeline.fireExceptionCaught(exception);
/*     */         }
/*     */       } finally {
/* 378 */         epollInFinally((ChannelConfig)config);
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-transport-classes-epoll-4.1.93.Final.jar!\io\netty\channel\epoll\EpollDomainDatagramChannel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */