/*      */ package io.netty.channel.epoll;
/*      */ 
/*      */ import io.netty.buffer.ByteBuf;
/*      */ import io.netty.buffer.ByteBufAllocator;
/*      */ import io.netty.channel.AbstractChannel;
/*      */ import io.netty.channel.Channel;
/*      */ import io.netty.channel.ChannelConfig;
/*      */ import io.netty.channel.ChannelFuture;
/*      */ import io.netty.channel.ChannelFutureListener;
/*      */ import io.netty.channel.ChannelMetadata;
/*      */ import io.netty.channel.ChannelOutboundBuffer;
/*      */ import io.netty.channel.ChannelPipeline;
/*      */ import io.netty.channel.ChannelPromise;
/*      */ import io.netty.channel.DefaultFileRegion;
/*      */ import io.netty.channel.EventLoop;
/*      */ import io.netty.channel.FileRegion;
/*      */ import io.netty.channel.RecvByteBufAllocator;
/*      */ import io.netty.channel.socket.DuplexChannel;
/*      */ import io.netty.channel.unix.FileDescriptor;
/*      */ import io.netty.channel.unix.IovArray;
/*      */ import io.netty.channel.unix.SocketWritableByteChannel;
/*      */ import io.netty.channel.unix.UnixChannelUtil;
/*      */ import io.netty.util.concurrent.Future;
/*      */ import io.netty.util.concurrent.GenericFutureListener;
/*      */ import io.netty.util.internal.ObjectUtil;
/*      */ import io.netty.util.internal.PlatformDependent;
/*      */ import io.netty.util.internal.StringUtil;
/*      */ import io.netty.util.internal.logging.InternalLogger;
/*      */ import io.netty.util.internal.logging.InternalLoggerFactory;
/*      */ import java.io.IOException;
/*      */ import java.net.SocketAddress;
/*      */ import java.nio.ByteBuffer;
/*      */ import java.nio.channels.ClosedChannelException;
/*      */ import java.nio.channels.WritableByteChannel;
/*      */ import java.util.Queue;
/*      */ import java.util.concurrent.Executor;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class AbstractEpollStreamChannel
/*      */   extends AbstractEpollChannel
/*      */   implements DuplexChannel
/*      */ {
/*   59 */   private static final ChannelMetadata METADATA = new ChannelMetadata(false, 16);
/*   60 */   private static final String EXPECTED_TYPES = " (expected: " + 
/*   61 */     StringUtil.simpleClassName(ByteBuf.class) + ", " + 
/*   62 */     StringUtil.simpleClassName(DefaultFileRegion.class) + ')';
/*   63 */   private static final InternalLogger logger = InternalLoggerFactory.getInstance(AbstractEpollStreamChannel.class);
/*      */   
/*   65 */   private final Runnable flushTask = new Runnable()
/*      */     {
/*      */       
/*      */       public void run()
/*      */       {
/*   70 */         ((AbstractEpollChannel.AbstractEpollUnsafe)AbstractEpollStreamChannel.this.unsafe()).flush0();
/*      */       }
/*      */     };
/*      */ 
/*      */   
/*      */   private volatile Queue<SpliceInTask> spliceQueue;
/*      */   
/*      */   private FileDescriptor pipeIn;
/*      */   private FileDescriptor pipeOut;
/*      */   private WritableByteChannel byteChannel;
/*      */   
/*      */   protected AbstractEpollStreamChannel(Channel parent, int fd) {
/*   82 */     this(parent, new LinuxSocket(fd));
/*      */   }
/*      */   
/*      */   protected AbstractEpollStreamChannel(int fd) {
/*   86 */     this(new LinuxSocket(fd));
/*      */   }
/*      */   
/*      */   AbstractEpollStreamChannel(LinuxSocket fd) {
/*   90 */     this(fd, isSoErrorZero(fd));
/*      */   }
/*      */   
/*      */   AbstractEpollStreamChannel(Channel parent, LinuxSocket fd) {
/*   94 */     super(parent, fd, true);
/*      */     
/*   96 */     this.flags |= Native.EPOLLRDHUP;
/*      */   }
/*      */   
/*      */   AbstractEpollStreamChannel(Channel parent, LinuxSocket fd, SocketAddress remote) {
/*  100 */     super(parent, fd, remote);
/*      */     
/*  102 */     this.flags |= Native.EPOLLRDHUP;
/*      */   }
/*      */   
/*      */   protected AbstractEpollStreamChannel(LinuxSocket fd, boolean active) {
/*  106 */     super((Channel)null, fd, active);
/*      */     
/*  108 */     this.flags |= Native.EPOLLRDHUP;
/*      */   }
/*      */ 
/*      */   
/*      */   protected AbstractEpollChannel.AbstractEpollUnsafe newUnsafe() {
/*  113 */     return new EpollStreamUnsafe();
/*      */   }
/*      */ 
/*      */   
/*      */   public ChannelMetadata metadata() {
/*  118 */     return METADATA;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ChannelFuture spliceTo(AbstractEpollStreamChannel ch, int len) {
/*  136 */     return spliceTo(ch, len, newPromise());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ChannelFuture spliceTo(AbstractEpollStreamChannel ch, int len, ChannelPromise promise) {
/*  155 */     if (ch.eventLoop() != eventLoop()) {
/*  156 */       throw new IllegalArgumentException("EventLoops are not the same.");
/*      */     }
/*  158 */     ObjectUtil.checkPositiveOrZero(len, "len");
/*  159 */     if (ch.config().getEpollMode() != EpollMode.LEVEL_TRIGGERED || 
/*  160 */       config().getEpollMode() != EpollMode.LEVEL_TRIGGERED) {
/*  161 */       throw new IllegalStateException("spliceTo() supported only when using " + EpollMode.LEVEL_TRIGGERED);
/*      */     }
/*  163 */     ObjectUtil.checkNotNull(promise, "promise");
/*  164 */     if (!isOpen()) {
/*  165 */       promise.tryFailure(new ClosedChannelException());
/*      */     } else {
/*  167 */       addToSpliceQueue(new SpliceInChannelTask(ch, len, promise));
/*  168 */       failSpliceIfClosed(promise);
/*      */     } 
/*  170 */     return (ChannelFuture)promise;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ChannelFuture spliceTo(FileDescriptor ch, int offset, int len) {
/*  188 */     return spliceTo(ch, offset, len, newPromise());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ChannelFuture spliceTo(FileDescriptor ch, int offset, int len, ChannelPromise promise) {
/*  207 */     ObjectUtil.checkPositiveOrZero(len, "len");
/*  208 */     ObjectUtil.checkPositiveOrZero(offset, "offset");
/*  209 */     if (config().getEpollMode() != EpollMode.LEVEL_TRIGGERED) {
/*  210 */       throw new IllegalStateException("spliceTo() supported only when using " + EpollMode.LEVEL_TRIGGERED);
/*      */     }
/*  212 */     ObjectUtil.checkNotNull(promise, "promise");
/*  213 */     if (!isOpen()) {
/*  214 */       promise.tryFailure(new ClosedChannelException());
/*      */     } else {
/*  216 */       addToSpliceQueue(new SpliceFdTask(ch, offset, len, promise));
/*  217 */       failSpliceIfClosed(promise);
/*      */     } 
/*  219 */     return (ChannelFuture)promise;
/*      */   }
/*      */   
/*      */   private void failSpliceIfClosed(ChannelPromise promise) {
/*  223 */     if (!isOpen())
/*      */     {
/*      */       
/*  226 */       if (promise.tryFailure(new ClosedChannelException())) {
/*  227 */         eventLoop().execute(new Runnable()
/*      */             {
/*      */               public void run()
/*      */               {
/*  231 */                 AbstractEpollStreamChannel.this.clearSpliceQueue();
/*      */               }
/*      */             });
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int writeBytes(ChannelOutboundBuffer in, ByteBuf buf) throws Exception {
/*  253 */     int readableBytes = buf.readableBytes();
/*  254 */     if (readableBytes == 0) {
/*  255 */       in.remove();
/*  256 */       return 0;
/*      */     } 
/*      */     
/*  259 */     if (buf.hasMemoryAddress() || buf.nioBufferCount() == 1) {
/*  260 */       return doWriteBytes(in, buf);
/*      */     }
/*  262 */     ByteBuffer[] nioBuffers = buf.nioBuffers();
/*  263 */     return writeBytesMultiple(in, nioBuffers, nioBuffers.length, readableBytes, 
/*  264 */         config().getMaxBytesPerGatheringWrite());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void adjustMaxBytesPerGatheringWrite(long attempted, long written, long oldMaxBytesPerGatheringWrite) {
/*  272 */     if (attempted == written) {
/*  273 */       if (attempted << 1L > oldMaxBytesPerGatheringWrite) {
/*  274 */         config().setMaxBytesPerGatheringWrite(attempted << 1L);
/*      */       }
/*  276 */     } else if (attempted > 4096L && written < attempted >>> 1L) {
/*  277 */       config().setMaxBytesPerGatheringWrite(attempted >>> 1L);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int writeBytesMultiple(ChannelOutboundBuffer in, IovArray array) throws IOException {
/*  297 */     long expectedWrittenBytes = array.size();
/*  298 */     assert expectedWrittenBytes != 0L;
/*  299 */     int cnt = array.count();
/*  300 */     assert cnt != 0;
/*      */     
/*  302 */     long localWrittenBytes = this.socket.writevAddresses(array.memoryAddress(0), cnt);
/*  303 */     if (localWrittenBytes > 0L) {
/*  304 */       adjustMaxBytesPerGatheringWrite(expectedWrittenBytes, localWrittenBytes, array.maxBytes());
/*  305 */       in.removeBytes(localWrittenBytes);
/*  306 */       return 1;
/*      */     } 
/*  308 */     return Integer.MAX_VALUE;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int writeBytesMultiple(ChannelOutboundBuffer in, ByteBuffer[] nioBuffers, int nioBufferCnt, long expectedWrittenBytes, long maxBytesPerGatheringWrite) throws IOException {
/*  332 */     assert expectedWrittenBytes != 0L;
/*  333 */     if (expectedWrittenBytes > maxBytesPerGatheringWrite) {
/*  334 */       expectedWrittenBytes = maxBytesPerGatheringWrite;
/*      */     }
/*      */     
/*  337 */     long localWrittenBytes = this.socket.writev(nioBuffers, 0, nioBufferCnt, expectedWrittenBytes);
/*  338 */     if (localWrittenBytes > 0L) {
/*  339 */       adjustMaxBytesPerGatheringWrite(expectedWrittenBytes, localWrittenBytes, maxBytesPerGatheringWrite);
/*  340 */       in.removeBytes(localWrittenBytes);
/*  341 */       return 1;
/*      */     } 
/*  343 */     return Integer.MAX_VALUE;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int writeDefaultFileRegion(ChannelOutboundBuffer in, DefaultFileRegion region) throws Exception {
/*  361 */     long offset = region.transferred();
/*  362 */     long regionCount = region.count();
/*  363 */     if (offset >= regionCount) {
/*  364 */       in.remove();
/*  365 */       return 0;
/*      */     } 
/*      */     
/*  368 */     long flushedAmount = this.socket.sendFile(region, region.position(), offset, regionCount - offset);
/*  369 */     if (flushedAmount > 0L) {
/*  370 */       in.progress(flushedAmount);
/*  371 */       if (region.transferred() >= regionCount) {
/*  372 */         in.remove();
/*      */       }
/*  374 */       return 1;
/*  375 */     }  if (flushedAmount == 0L) {
/*  376 */       validateFileRegion(region, offset);
/*      */     }
/*  378 */     return Integer.MAX_VALUE;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int writeFileRegion(ChannelOutboundBuffer in, FileRegion region) throws Exception {
/*  396 */     if (region.transferred() >= region.count()) {
/*  397 */       in.remove();
/*  398 */       return 0;
/*      */     } 
/*      */     
/*  401 */     if (this.byteChannel == null) {
/*  402 */       this.byteChannel = (WritableByteChannel)new EpollSocketWritableByteChannel();
/*      */     }
/*  404 */     long flushedAmount = region.transferTo(this.byteChannel, region.transferred());
/*  405 */     if (flushedAmount > 0L) {
/*  406 */       in.progress(flushedAmount);
/*  407 */       if (region.transferred() >= region.count()) {
/*  408 */         in.remove();
/*      */       }
/*  410 */       return 1;
/*      */     } 
/*  412 */     return Integer.MAX_VALUE;
/*      */   }
/*      */ 
/*      */   
/*      */   protected void doWrite(ChannelOutboundBuffer in) throws Exception {
/*  417 */     int writeSpinCount = config().getWriteSpinCount();
/*      */     do {
/*  419 */       int msgCount = in.size();
/*      */       
/*  421 */       if (msgCount > 1 && in.current() instanceof ByteBuf)
/*  422 */       { writeSpinCount -= doWriteMultiple(in); }
/*  423 */       else { if (msgCount == 0) {
/*      */           
/*  425 */           clearFlag(Native.EPOLLOUT);
/*      */           
/*      */           return;
/*      */         } 
/*  429 */         writeSpinCount -= doWriteSingle(in);
/*      */          }
/*      */ 
/*      */ 
/*      */     
/*      */     }
/*  435 */     while (writeSpinCount > 0);
/*      */     
/*  437 */     if (writeSpinCount == 0) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  442 */       clearFlag(Native.EPOLLOUT);
/*      */ 
/*      */       
/*  445 */       eventLoop().execute(this.flushTask);
/*      */     }
/*      */     else {
/*      */       
/*  449 */       setFlag(Native.EPOLLOUT);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int doWriteSingle(ChannelOutboundBuffer in) throws Exception {
/*  469 */     Object msg = in.current();
/*  470 */     if (msg instanceof ByteBuf)
/*  471 */       return writeBytes(in, (ByteBuf)msg); 
/*  472 */     if (msg instanceof DefaultFileRegion)
/*  473 */       return writeDefaultFileRegion(in, (DefaultFileRegion)msg); 
/*  474 */     if (msg instanceof FileRegion)
/*  475 */       return writeFileRegion(in, (FileRegion)msg); 
/*  476 */     if (msg instanceof SpliceOutTask) {
/*  477 */       if (!((SpliceOutTask)msg).spliceOut()) {
/*  478 */         return Integer.MAX_VALUE;
/*      */       }
/*  480 */       in.remove();
/*  481 */       return 1;
/*      */     } 
/*      */     
/*  484 */     throw new Error();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int doWriteMultiple(ChannelOutboundBuffer in) throws Exception {
/*  503 */     long maxBytesPerGatheringWrite = config().getMaxBytesPerGatheringWrite();
/*  504 */     IovArray array = ((EpollEventLoop)eventLoop()).cleanIovArray();
/*  505 */     array.maxBytes(maxBytesPerGatheringWrite);
/*  506 */     in.forEachFlushedMessage((ChannelOutboundBuffer.MessageProcessor)array);
/*      */     
/*  508 */     if (array.count() >= 1)
/*      */     {
/*  510 */       return writeBytesMultiple(in, array);
/*      */     }
/*      */     
/*  513 */     in.removeBytes(0L);
/*  514 */     return 0;
/*      */   }
/*      */ 
/*      */   
/*      */   protected Object filterOutboundMessage(Object msg) {
/*  519 */     if (msg instanceof ByteBuf) {
/*  520 */       ByteBuf buf = (ByteBuf)msg;
/*  521 */       return UnixChannelUtil.isBufferCopyNeededForWrite(buf) ? newDirectBuffer(buf) : buf;
/*      */     } 
/*      */     
/*  524 */     if (msg instanceof FileRegion || msg instanceof SpliceOutTask) {
/*  525 */       return msg;
/*      */     }
/*      */     
/*  528 */     throw new UnsupportedOperationException("unsupported message type: " + 
/*  529 */         StringUtil.simpleClassName(msg) + EXPECTED_TYPES);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void doShutdownOutput() throws Exception {
/*  535 */     this.socket.shutdown(false, true);
/*      */   }
/*      */   
/*      */   private void shutdownInput0(ChannelPromise promise) {
/*      */     try {
/*  540 */       this.socket.shutdown(true, false);
/*  541 */       promise.setSuccess();
/*  542 */     } catch (Throwable cause) {
/*  543 */       promise.setFailure(cause);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isOutputShutdown() {
/*  549 */     return this.socket.isOutputShutdown();
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isInputShutdown() {
/*  554 */     return this.socket.isInputShutdown();
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isShutdown() {
/*  559 */     return this.socket.isShutdown();
/*      */   }
/*      */ 
/*      */   
/*      */   public ChannelFuture shutdownOutput() {
/*  564 */     return shutdownOutput(newPromise());
/*      */   }
/*      */ 
/*      */   
/*      */   public ChannelFuture shutdownOutput(final ChannelPromise promise) {
/*  569 */     EventLoop loop = eventLoop();
/*  570 */     if (loop.inEventLoop()) {
/*  571 */       ((AbstractChannel.AbstractUnsafe)unsafe()).shutdownOutput(promise);
/*      */     } else {
/*  573 */       loop.execute(new Runnable()
/*      */           {
/*      */             public void run() {
/*  576 */               ((AbstractChannel.AbstractUnsafe)AbstractEpollStreamChannel.this.unsafe()).shutdownOutput(promise);
/*      */             }
/*      */           });
/*      */     } 
/*      */     
/*  581 */     return (ChannelFuture)promise;
/*      */   }
/*      */ 
/*      */   
/*      */   public ChannelFuture shutdownInput() {
/*  586 */     return shutdownInput(newPromise());
/*      */   }
/*      */ 
/*      */   
/*      */   public ChannelFuture shutdownInput(final ChannelPromise promise) {
/*  591 */     Executor closeExecutor = ((EpollStreamUnsafe)unsafe()).prepareToClose();
/*  592 */     if (closeExecutor != null) {
/*  593 */       closeExecutor.execute(new Runnable()
/*      */           {
/*      */             public void run() {
/*  596 */               AbstractEpollStreamChannel.this.shutdownInput0(promise);
/*      */             }
/*      */           });
/*      */     } else {
/*  600 */       EventLoop loop = eventLoop();
/*  601 */       if (loop.inEventLoop()) {
/*  602 */         shutdownInput0(promise);
/*      */       } else {
/*  604 */         loop.execute(new Runnable()
/*      */             {
/*      */               public void run() {
/*  607 */                 AbstractEpollStreamChannel.this.shutdownInput0(promise);
/*      */               }
/*      */             });
/*      */       } 
/*      */     } 
/*  612 */     return (ChannelFuture)promise;
/*      */   }
/*      */ 
/*      */   
/*      */   public ChannelFuture shutdown() {
/*  617 */     return shutdown(newPromise());
/*      */   }
/*      */ 
/*      */   
/*      */   public ChannelFuture shutdown(final ChannelPromise promise) {
/*  622 */     ChannelFuture shutdownOutputFuture = shutdownOutput();
/*  623 */     if (shutdownOutputFuture.isDone()) {
/*  624 */       shutdownOutputDone(shutdownOutputFuture, promise);
/*      */     } else {
/*  626 */       shutdownOutputFuture.addListener((GenericFutureListener)new ChannelFutureListener()
/*      */           {
/*      */             public void operationComplete(ChannelFuture shutdownOutputFuture) throws Exception {
/*  629 */               AbstractEpollStreamChannel.this.shutdownOutputDone(shutdownOutputFuture, promise);
/*      */             }
/*      */           });
/*      */     } 
/*  633 */     return (ChannelFuture)promise;
/*      */   }
/*      */   
/*      */   private void shutdownOutputDone(final ChannelFuture shutdownOutputFuture, final ChannelPromise promise) {
/*  637 */     ChannelFuture shutdownInputFuture = shutdownInput();
/*  638 */     if (shutdownInputFuture.isDone()) {
/*  639 */       shutdownDone(shutdownOutputFuture, shutdownInputFuture, promise);
/*      */     } else {
/*  641 */       shutdownInputFuture.addListener((GenericFutureListener)new ChannelFutureListener()
/*      */           {
/*      */             public void operationComplete(ChannelFuture shutdownInputFuture) throws Exception {
/*  644 */               AbstractEpollStreamChannel.shutdownDone(shutdownOutputFuture, shutdownInputFuture, promise);
/*      */             }
/*      */           });
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static void shutdownDone(ChannelFuture shutdownOutputFuture, ChannelFuture shutdownInputFuture, ChannelPromise promise) {
/*  653 */     Throwable shutdownOutputCause = shutdownOutputFuture.cause();
/*  654 */     Throwable shutdownInputCause = shutdownInputFuture.cause();
/*  655 */     if (shutdownOutputCause != null) {
/*  656 */       if (shutdownInputCause != null) {
/*  657 */         logger.debug("Exception suppressed because a previous exception occurred.", shutdownInputCause);
/*      */       }
/*      */       
/*  660 */       promise.setFailure(shutdownOutputCause);
/*  661 */     } else if (shutdownInputCause != null) {
/*  662 */       promise.setFailure(shutdownInputCause);
/*      */     } else {
/*  664 */       promise.setSuccess();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void doClose() throws Exception {
/*      */     try {
/*  672 */       super.doClose();
/*      */     } finally {
/*  674 */       safeClosePipe(this.pipeIn);
/*  675 */       safeClosePipe(this.pipeOut);
/*  676 */       clearSpliceQueue();
/*      */     } 
/*      */   }
/*      */   
/*      */   private void clearSpliceQueue() {
/*  681 */     Queue<SpliceInTask> sQueue = this.spliceQueue;
/*  682 */     if (sQueue == null) {
/*      */       return;
/*      */     }
/*  685 */     ClosedChannelException exception = null;
/*      */     
/*      */     while (true) {
/*  688 */       SpliceInTask task = sQueue.poll();
/*  689 */       if (task == null) {
/*      */         break;
/*      */       }
/*  692 */       if (exception == null) {
/*  693 */         exception = new ClosedChannelException();
/*      */       }
/*  695 */       task.promise.tryFailure(exception);
/*      */     } 
/*      */   }
/*      */   
/*      */   private static void safeClosePipe(FileDescriptor fd) {
/*  700 */     if (fd != null) {
/*      */       try {
/*  702 */         fd.close();
/*  703 */       } catch (IOException e) {
/*  704 */         logger.warn("Error while closing a pipe", e);
/*      */       } 
/*      */     }
/*      */   }
/*      */   
/*      */   class EpollStreamUnsafe
/*      */     extends AbstractEpollChannel.AbstractEpollUnsafe
/*      */   {
/*      */     protected Executor prepareToClose() {
/*  713 */       return super.prepareToClose();
/*      */     }
/*      */ 
/*      */     
/*      */     private void handleReadException(ChannelPipeline pipeline, ByteBuf byteBuf, Throwable cause, boolean close, EpollRecvByteAllocatorHandle allocHandle) {
/*  718 */       if (byteBuf != null) {
/*  719 */         if (byteBuf.isReadable()) {
/*  720 */           this.readPending = false;
/*  721 */           pipeline.fireChannelRead(byteBuf);
/*      */         } else {
/*  723 */           byteBuf.release();
/*      */         } 
/*      */       }
/*  726 */       allocHandle.readComplete();
/*  727 */       pipeline.fireChannelReadComplete();
/*  728 */       pipeline.fireExceptionCaught(cause);
/*      */ 
/*      */ 
/*      */       
/*  732 */       if (close || cause instanceof OutOfMemoryError || cause instanceof IOException) {
/*  733 */         shutdownInput(false);
/*      */       }
/*      */     }
/*      */ 
/*      */     
/*      */     EpollRecvByteAllocatorHandle newEpollHandle(RecvByteBufAllocator.ExtendedHandle handle) {
/*  739 */       return new EpollRecvByteAllocatorStreamingHandle(handle);
/*      */     }
/*      */ 
/*      */     
/*      */     void epollInReady() {
/*  744 */       EpollChannelConfig epollChannelConfig = AbstractEpollStreamChannel.this.config();
/*  745 */       if (AbstractEpollStreamChannel.this.shouldBreakEpollInReady((ChannelConfig)epollChannelConfig)) {
/*  746 */         clearEpollIn0();
/*      */         return;
/*      */       } 
/*  749 */       EpollRecvByteAllocatorHandle allocHandle = recvBufAllocHandle();
/*  750 */       allocHandle.edgeTriggered(AbstractEpollStreamChannel.this.isFlagSet(Native.EPOLLET));
/*      */       
/*  752 */       ChannelPipeline pipeline = AbstractEpollStreamChannel.this.pipeline();
/*  753 */       ByteBufAllocator allocator = epollChannelConfig.getAllocator();
/*  754 */       allocHandle.reset((ChannelConfig)epollChannelConfig);
/*  755 */       epollInBefore();
/*      */       
/*  757 */       ByteBuf byteBuf = null;
/*  758 */       boolean close = false;
/*  759 */       Queue<AbstractEpollStreamChannel.SpliceInTask> sQueue = null;
/*      */       try {
/*      */         label57: do {
/*  762 */           if (sQueue != null || (sQueue = AbstractEpollStreamChannel.this.spliceQueue) != null) {
/*  763 */             AbstractEpollStreamChannel.SpliceInTask spliceTask = sQueue.peek();
/*  764 */             if (spliceTask != null) {
/*  765 */               boolean spliceInResult = spliceTask.spliceIn((RecvByteBufAllocator.Handle)allocHandle);
/*      */               
/*  767 */               if (allocHandle.isReceivedRdHup()) {
/*  768 */                 shutdownInput(true);
/*      */               }
/*  770 */               if (spliceInResult) {
/*      */ 
/*      */                 
/*  773 */                 if (AbstractEpollStreamChannel.this.isActive()) {
/*  774 */                   sQueue.remove();
/*      */                 }
/*      */               } else {
/*      */                 break label57;
/*      */               } 
/*      */ 
/*      */               
/*      */               continue;
/*      */             } 
/*      */           } 
/*      */           
/*  785 */           byteBuf = allocHandle.allocate(allocator);
/*  786 */           allocHandle.lastBytesRead(AbstractEpollStreamChannel.this.doReadBytes(byteBuf));
/*  787 */           if (allocHandle.lastBytesRead() <= 0) {
/*      */             
/*  789 */             byteBuf.release();
/*  790 */             byteBuf = null;
/*  791 */             close = (allocHandle.lastBytesRead() < 0);
/*  792 */             if (close)
/*      */             {
/*  794 */               this.readPending = false;
/*      */             }
/*      */             break label57;
/*      */           } 
/*  798 */           allocHandle.incMessagesRead(1);
/*  799 */           this.readPending = false;
/*  800 */           pipeline.fireChannelRead(byteBuf);
/*  801 */           byteBuf = null;
/*      */           
/*  803 */           if (AbstractEpollStreamChannel.this.shouldBreakEpollInReady((ChannelConfig)epollChannelConfig))
/*      */           {
/*      */             break label57;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         }
/*  817 */         while (allocHandle.continueReading());
/*      */         
/*  819 */         allocHandle.readComplete();
/*  820 */         pipeline.fireChannelReadComplete();
/*      */         
/*  822 */         if (close) {
/*  823 */           shutdownInput(false);
/*      */         }
/*  825 */       } catch (Throwable t) {
/*  826 */         handleReadException(pipeline, byteBuf, t, close, allocHandle);
/*      */       } finally {
/*  828 */         if (sQueue == null) {
/*  829 */           epollInFinally((ChannelConfig)epollChannelConfig);
/*      */         }
/*  831 */         else if (!epollChannelConfig.isAutoRead()) {
/*  832 */           AbstractEpollStreamChannel.this.clearEpollIn();
/*      */         } 
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private void addToSpliceQueue(SpliceInTask task) {
/*  840 */     Queue<SpliceInTask> sQueue = this.spliceQueue;
/*  841 */     if (sQueue == null) {
/*  842 */       synchronized (this) {
/*  843 */         sQueue = this.spliceQueue;
/*  844 */         if (sQueue == null) {
/*  845 */           this.spliceQueue = sQueue = PlatformDependent.newMpscQueue();
/*      */         }
/*      */       } 
/*      */     }
/*  849 */     sQueue.add(task);
/*      */   }
/*      */   
/*      */   protected abstract class SpliceInTask {
/*      */     final ChannelPromise promise;
/*      */     int len;
/*      */     
/*      */     protected SpliceInTask(int len, ChannelPromise promise) {
/*  857 */       this.promise = promise;
/*  858 */       this.len = len;
/*      */     }
/*      */ 
/*      */     
/*      */     abstract boolean spliceIn(RecvByteBufAllocator.Handle param1Handle);
/*      */     
/*      */     protected final int spliceIn(FileDescriptor pipeOut, RecvByteBufAllocator.Handle handle) throws IOException {
/*  865 */       int length = Math.min(handle.guess(), this.len);
/*  866 */       int splicedIn = 0;
/*      */       
/*      */       while (true) {
/*  869 */         int localSplicedIn = Native.splice(AbstractEpollStreamChannel.this.socket.intValue(), -1L, pipeOut.intValue(), -1L, length);
/*  870 */         handle.lastBytesRead(localSplicedIn);
/*  871 */         if (localSplicedIn == 0) {
/*      */           break;
/*      */         }
/*  874 */         splicedIn += localSplicedIn;
/*  875 */         length -= localSplicedIn;
/*      */       } 
/*      */       
/*  878 */       return splicedIn;
/*      */     }
/*      */   }
/*      */   
/*      */   private final class SpliceInChannelTask
/*      */     extends SpliceInTask implements ChannelFutureListener {
/*      */     private final AbstractEpollStreamChannel ch;
/*      */     
/*      */     SpliceInChannelTask(AbstractEpollStreamChannel ch, int len, ChannelPromise promise) {
/*  887 */       super(len, promise);
/*  888 */       this.ch = ch;
/*      */     }
/*      */ 
/*      */     
/*      */     public void operationComplete(ChannelFuture future) throws Exception {
/*  893 */       if (!future.isSuccess()) {
/*  894 */         this.promise.setFailure(future.cause());
/*      */       }
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean spliceIn(RecvByteBufAllocator.Handle handle) {
/*  900 */       assert this.ch.eventLoop().inEventLoop();
/*  901 */       if (this.len == 0) {
/*  902 */         this.promise.setSuccess();
/*  903 */         return true;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*      */       try {
/*  909 */         FileDescriptor pipeOut = this.ch.pipeOut;
/*  910 */         if (pipeOut == null) {
/*      */           
/*  912 */           FileDescriptor[] pipe = FileDescriptor.pipe();
/*  913 */           this.ch.pipeIn = pipe[0];
/*  914 */           pipeOut = this.ch.pipeOut = pipe[1];
/*      */         } 
/*      */         
/*  917 */         int splicedIn = spliceIn(pipeOut, handle);
/*  918 */         if (splicedIn > 0) {
/*      */           ChannelPromise splicePromise;
/*  920 */           if (this.len != Integer.MAX_VALUE) {
/*  921 */             this.len -= splicedIn;
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  927 */           if (this.len == 0) {
/*  928 */             splicePromise = this.promise;
/*      */           } else {
/*  930 */             splicePromise = this.ch.newPromise().addListener((GenericFutureListener)this);
/*      */           } 
/*      */           
/*  933 */           boolean autoRead = AbstractEpollStreamChannel.this.config().isAutoRead();
/*      */ 
/*      */ 
/*      */           
/*  937 */           this.ch.unsafe().write(new AbstractEpollStreamChannel.SpliceOutTask(this.ch, splicedIn, autoRead), splicePromise);
/*  938 */           this.ch.unsafe().flush();
/*  939 */           if (autoRead && !splicePromise.isDone())
/*      */           {
/*      */ 
/*      */ 
/*      */             
/*  944 */             AbstractEpollStreamChannel.this.config().setAutoRead(false);
/*      */           }
/*      */         } 
/*      */         
/*  948 */         return (this.len == 0);
/*  949 */       } catch (Throwable cause) {
/*  950 */         this.promise.setFailure(cause);
/*  951 */         return true;
/*      */       } 
/*      */     }
/*      */   }
/*      */   
/*      */   private final class SpliceOutTask {
/*      */     private final AbstractEpollStreamChannel ch;
/*      */     private final boolean autoRead;
/*      */     private int len;
/*      */     
/*      */     SpliceOutTask(AbstractEpollStreamChannel ch, int len, boolean autoRead) {
/*  962 */       this.ch = ch;
/*  963 */       this.len = len;
/*  964 */       this.autoRead = autoRead;
/*      */     }
/*      */     
/*      */     public boolean spliceOut() throws Exception {
/*  968 */       assert this.ch.eventLoop().inEventLoop();
/*      */       try {
/*  970 */         int splicedOut = Native.splice(this.ch.pipeIn.intValue(), -1L, this.ch.socket.intValue(), -1L, this.len);
/*  971 */         this.len -= splicedOut;
/*  972 */         if (this.len == 0) {
/*  973 */           if (this.autoRead)
/*      */           {
/*  975 */             AbstractEpollStreamChannel.this.config().setAutoRead(true);
/*      */           }
/*  977 */           return true;
/*      */         } 
/*  979 */         return false;
/*  980 */       } catch (IOException e) {
/*  981 */         if (this.autoRead)
/*      */         {
/*  983 */           AbstractEpollStreamChannel.this.config().setAutoRead(true);
/*      */         }
/*  985 */         throw e;
/*      */       } 
/*      */     }
/*      */   }
/*      */   
/*      */   private final class SpliceFdTask extends SpliceInTask {
/*      */     private final FileDescriptor fd;
/*      */     private final ChannelPromise promise;
/*      */     private int offset;
/*      */     
/*      */     SpliceFdTask(FileDescriptor fd, int offset, int len, ChannelPromise promise) {
/*  996 */       super(len, promise);
/*  997 */       this.fd = fd;
/*  998 */       this.promise = promise;
/*  999 */       this.offset = offset;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean spliceIn(RecvByteBufAllocator.Handle handle) {
/* 1004 */       assert AbstractEpollStreamChannel.this.eventLoop().inEventLoop();
/* 1005 */       if (this.len == 0) {
/* 1006 */         this.promise.setSuccess();
/* 1007 */         return true;
/*      */       } 
/*      */       
/*      */       try {
/* 1011 */         FileDescriptor[] pipe = FileDescriptor.pipe();
/* 1012 */         FileDescriptor pipeIn = pipe[0];
/* 1013 */         FileDescriptor pipeOut = pipe[1];
/*      */         try {
/* 1015 */           int splicedIn = spliceIn(pipeOut, handle);
/* 1016 */           if (splicedIn > 0) {
/*      */             
/* 1018 */             if (this.len != Integer.MAX_VALUE) {
/* 1019 */               this.len -= splicedIn;
/*      */             }
/*      */             while (true) {
/* 1022 */               int splicedOut = Native.splice(pipeIn.intValue(), -1L, this.fd.intValue(), this.offset, splicedIn);
/* 1023 */               this.offset += splicedOut;
/* 1024 */               splicedIn -= splicedOut;
/* 1025 */               if (splicedIn <= 0) {
/* 1026 */                 if (this.len == 0)
/* 1027 */                 { this.promise.setSuccess();
/* 1028 */                   splicedOut = 1; return splicedOut; }  break;
/*      */               } 
/*      */             } 
/* 1031 */           }  return false;
/*      */         } finally {
/* 1033 */           AbstractEpollStreamChannel.safeClosePipe(pipeIn);
/* 1034 */           AbstractEpollStreamChannel.safeClosePipe(pipeOut);
/*      */         } 
/* 1036 */       } catch (Throwable cause) {
/* 1037 */         this.promise.setFailure(cause);
/* 1038 */         return true;
/*      */       } 
/*      */     }
/*      */   }
/*      */   
/*      */   private final class EpollSocketWritableByteChannel extends SocketWritableByteChannel {
/*      */     EpollSocketWritableByteChannel() {
/* 1045 */       super((FileDescriptor)AbstractEpollStreamChannel.this.socket);
/* 1046 */       assert this.fd == AbstractEpollStreamChannel.this.socket;
/*      */     }
/*      */ 
/*      */     
/*      */     protected int write(ByteBuffer buf, int pos, int limit) throws IOException {
/* 1051 */       return AbstractEpollStreamChannel.this.socket.send(buf, pos, limit);
/*      */     }
/*      */ 
/*      */     
/*      */     protected ByteBufAllocator alloc() {
/* 1056 */       return AbstractEpollStreamChannel.this.alloc();
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-transport-classes-epoll-4.1.93.Final.jar!\io\netty\channel\epoll\AbstractEpollStreamChannel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */