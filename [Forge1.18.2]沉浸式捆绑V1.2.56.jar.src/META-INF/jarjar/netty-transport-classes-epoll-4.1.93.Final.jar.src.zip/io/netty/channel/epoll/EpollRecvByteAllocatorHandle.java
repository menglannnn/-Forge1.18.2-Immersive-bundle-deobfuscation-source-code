/*    */ package io.netty.channel.epoll;
/*    */ 
/*    */ import io.netty.buffer.ByteBuf;
/*    */ import io.netty.buffer.ByteBufAllocator;
/*    */ import io.netty.channel.RecvByteBufAllocator;
/*    */ import io.netty.channel.unix.PreferredDirectByteBufAllocator;
/*    */ import io.netty.util.UncheckedBooleanSupplier;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class EpollRecvByteAllocatorHandle
/*    */   extends RecvByteBufAllocator.DelegatingHandle
/*    */   implements RecvByteBufAllocator.ExtendedHandle
/*    */ {
/* 26 */   private final PreferredDirectByteBufAllocator preferredDirectByteBufAllocator = new PreferredDirectByteBufAllocator();
/*    */   
/* 28 */   private final UncheckedBooleanSupplier defaultMaybeMoreDataSupplier = new UncheckedBooleanSupplier()
/*    */     {
/*    */       public boolean get() {
/* 31 */         return EpollRecvByteAllocatorHandle.this.maybeMoreDataToRead();
/*    */       }
/*    */     };
/*    */   
/*    */   private boolean isEdgeTriggered;
/*    */   
/*    */   EpollRecvByteAllocatorHandle(RecvByteBufAllocator.ExtendedHandle handle) {
/* 38 */     super((RecvByteBufAllocator.Handle)handle);
/*    */   }
/*    */   private boolean receivedRdHup;
/*    */   final void receivedRdHup() {
/* 42 */     this.receivedRdHup = true;
/*    */   }
/*    */   
/*    */   final boolean isReceivedRdHup() {
/* 46 */     return this.receivedRdHup;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   boolean maybeMoreDataToRead() {
/* 59 */     return ((this.isEdgeTriggered && lastBytesRead() > 0) || (!this.isEdgeTriggered && 
/* 60 */       lastBytesRead() == attemptedBytesRead()));
/*    */   }
/*    */   
/*    */   final void edgeTriggered(boolean edgeTriggered) {
/* 64 */     this.isEdgeTriggered = edgeTriggered;
/*    */   }
/*    */   
/*    */   final boolean isEdgeTriggered() {
/* 68 */     return this.isEdgeTriggered;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public final ByteBuf allocate(ByteBufAllocator alloc) {
/* 74 */     this.preferredDirectByteBufAllocator.updateAllocator(alloc);
/* 75 */     return delegate().allocate((ByteBufAllocator)this.preferredDirectByteBufAllocator);
/*    */   }
/*    */ 
/*    */   
/*    */   public final boolean continueReading(UncheckedBooleanSupplier maybeMoreDataSupplier) {
/* 80 */     return ((RecvByteBufAllocator.ExtendedHandle)delegate()).continueReading(maybeMoreDataSupplier);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public final boolean continueReading() {
/* 86 */     return continueReading(this.defaultMaybeMoreDataSupplier);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-transport-classes-epoll-4.1.93.Final.jar!\io\netty\channel\epoll\EpollRecvByteAllocatorHandle.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */