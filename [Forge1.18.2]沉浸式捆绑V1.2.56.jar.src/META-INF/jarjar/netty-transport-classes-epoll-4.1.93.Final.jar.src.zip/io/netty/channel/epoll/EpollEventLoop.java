/*     */ package io.netty.channel.epoll;
/*     */ 
/*     */ import io.netty.channel.Channel;
/*     */ import io.netty.channel.EventLoopGroup;
/*     */ import io.netty.channel.EventLoopTaskQueueFactory;
/*     */ import io.netty.channel.SelectStrategy;
/*     */ import io.netty.channel.SingleThreadEventLoop;
/*     */ import io.netty.channel.unix.FileDescriptor;
/*     */ import io.netty.channel.unix.IovArray;
/*     */ import io.netty.util.IntSupplier;
/*     */ import io.netty.util.collection.IntObjectHashMap;
/*     */ import io.netty.util.collection.IntObjectMap;
/*     */ import io.netty.util.concurrent.RejectedExecutionHandler;
/*     */ import io.netty.util.internal.ObjectUtil;
/*     */ import io.netty.util.internal.PlatformDependent;
/*     */ import io.netty.util.internal.SystemPropertyUtil;
/*     */ import io.netty.util.internal.logging.InternalLogger;
/*     */ import io.netty.util.internal.logging.InternalLoggerFactory;
/*     */ import java.io.IOException;
/*     */ import java.util.Iterator;
/*     */ import java.util.Queue;
/*     */ import java.util.concurrent.Executor;
/*     */ import java.util.concurrent.atomic.AtomicLong;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class EpollEventLoop
/*     */   extends SingleThreadEventLoop
/*     */ {
/*  49 */   private static final InternalLogger logger = InternalLoggerFactory.getInstance(EpollEventLoop.class);
/*     */   
/*  51 */   private static final long EPOLL_WAIT_MILLIS_THRESHOLD = SystemPropertyUtil.getLong("io.netty.channel.epoll.epollWaitThreshold", 10L); private final FileDescriptor epollFd;
/*     */   private final FileDescriptor eventFd;
/*     */   private final FileDescriptor timerFd;
/*     */   
/*     */   static {
/*  56 */     Epoll.ensureAvailability();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  62 */   private final IntObjectMap<AbstractEpollChannel> channels = (IntObjectMap<AbstractEpollChannel>)new IntObjectHashMap(4096);
/*     */   
/*     */   private final boolean allowGrowing;
/*     */   
/*     */   private final EpollEventArray events;
/*     */   private IovArray iovArray;
/*     */   private NativeDatagramPacketArray datagramPacketArray;
/*     */   private final SelectStrategy selectStrategy;
/*     */   
/*  71 */   private final IntSupplier selectNowSupplier = new IntSupplier()
/*     */     {
/*     */       public int get() throws Exception {
/*  74 */         return EpollEventLoop.this.epollWaitNow();
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */   
/*     */   private static final long AWAKE = -1L;
/*     */ 
/*     */   
/*     */   private static final long NONE = 9223372036854775807L;
/*     */   
/*  85 */   private final AtomicLong nextWakeupNanos = new AtomicLong(-1L);
/*     */   private boolean pendingWakeup;
/*  87 */   private volatile int ioRatio = 50;
/*     */ 
/*     */   
/*     */   private static final long MAX_SCHEDULED_TIMERFD_NS = 999999999L;
/*     */ 
/*     */ 
/*     */   
/*     */   EpollEventLoop(EventLoopGroup parent, Executor executor, int maxEvents, SelectStrategy strategy, RejectedExecutionHandler rejectedExecutionHandler, EventLoopTaskQueueFactory taskQueueFactory, EventLoopTaskQueueFactory tailTaskQueueFactory) {
/*  95 */     super(parent, executor, false, newTaskQueue(taskQueueFactory), newTaskQueue(tailTaskQueueFactory), rejectedExecutionHandler);
/*     */     
/*  97 */     this.selectStrategy = (SelectStrategy)ObjectUtil.checkNotNull(strategy, "strategy");
/*  98 */     if (maxEvents == 0) {
/*  99 */       this.allowGrowing = true;
/* 100 */       this.events = new EpollEventArray(4096);
/*     */     } else {
/* 102 */       this.allowGrowing = false;
/* 103 */       this.events = new EpollEventArray(maxEvents);
/*     */     } 
/* 105 */     boolean success = false;
/* 106 */     FileDescriptor epollFd = null;
/* 107 */     FileDescriptor eventFd = null;
/* 108 */     FileDescriptor timerFd = null;
/*     */     try {
/* 110 */       this.epollFd = epollFd = Native.newEpollCreate();
/* 111 */       this.eventFd = eventFd = Native.newEventFd();
/*     */ 
/*     */       
/*     */       try {
/* 115 */         Native.epollCtlAdd(epollFd.intValue(), eventFd.intValue(), Native.EPOLLIN | Native.EPOLLET);
/* 116 */       } catch (IOException e) {
/* 117 */         throw new IllegalStateException("Unable to add eventFd filedescriptor to epoll", e);
/*     */       } 
/* 119 */       this.timerFd = timerFd = Native.newTimerFd();
/*     */ 
/*     */       
/*     */       try {
/* 123 */         Native.epollCtlAdd(epollFd.intValue(), timerFd.intValue(), Native.EPOLLIN | Native.EPOLLET);
/* 124 */       } catch (IOException e) {
/* 125 */         throw new IllegalStateException("Unable to add timerFd filedescriptor to epoll", e);
/*     */       } 
/* 127 */       success = true;
/*     */     } finally {
/* 129 */       if (!success) {
/* 130 */         if (epollFd != null) {
/*     */           try {
/* 132 */             epollFd.close();
/* 133 */           } catch (Exception exception) {}
/*     */         }
/*     */ 
/*     */         
/* 137 */         if (eventFd != null) {
/*     */           try {
/* 139 */             eventFd.close();
/* 140 */           } catch (Exception exception) {}
/*     */         }
/*     */ 
/*     */         
/* 144 */         if (timerFd != null) {
/*     */           try {
/* 146 */             timerFd.close();
/* 147 */           } catch (Exception exception) {}
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Queue<Runnable> newTaskQueue(EventLoopTaskQueueFactory queueFactory) {
/* 157 */     if (queueFactory == null) {
/* 158 */       return newTaskQueue0(DEFAULT_MAX_PENDING_TASKS);
/*     */     }
/* 160 */     return queueFactory.newTaskQueue(DEFAULT_MAX_PENDING_TASKS);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   IovArray cleanIovArray() {
/* 167 */     if (this.iovArray == null) {
/* 168 */       this.iovArray = new IovArray();
/*     */     } else {
/* 170 */       this.iovArray.clear();
/*     */     } 
/* 172 */     return this.iovArray;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   NativeDatagramPacketArray cleanDatagramPacketArray() {
/* 179 */     if (this.datagramPacketArray == null) {
/* 180 */       this.datagramPacketArray = new NativeDatagramPacketArray();
/*     */     } else {
/* 182 */       this.datagramPacketArray.clear();
/*     */     } 
/* 184 */     return this.datagramPacketArray;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void wakeup(boolean inEventLoop) {
/* 189 */     if (!inEventLoop && this.nextWakeupNanos.getAndSet(-1L) != -1L)
/*     */     {
/* 191 */       Native.eventFdWrite(this.eventFd.intValue(), 1L);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean beforeScheduledTaskSubmitted(long deadlineNanos) {
/* 198 */     return (deadlineNanos < this.nextWakeupNanos.get());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean afterScheduledTaskSubmitted(long deadlineNanos) {
/* 204 */     return (deadlineNanos < this.nextWakeupNanos.get());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void add(AbstractEpollChannel ch) throws IOException {
/* 211 */     assert inEventLoop();
/* 212 */     int fd = ch.socket.intValue();
/* 213 */     Native.epollCtlAdd(this.epollFd.intValue(), fd, ch.flags);
/* 214 */     AbstractEpollChannel old = (AbstractEpollChannel)this.channels.put(fd, ch);
/*     */ 
/*     */ 
/*     */     
/* 218 */     assert old == null || !old.isOpen();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void modify(AbstractEpollChannel ch) throws IOException {
/* 225 */     assert inEventLoop();
/* 226 */     Native.epollCtlMod(this.epollFd.intValue(), ch.socket.intValue(), ch.flags);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void remove(AbstractEpollChannel ch) throws IOException {
/* 233 */     assert inEventLoop();
/* 234 */     int fd = ch.socket.intValue();
/*     */     
/* 236 */     AbstractEpollChannel old = (AbstractEpollChannel)this.channels.remove(fd);
/* 237 */     if (old != null && old != ch) {
/*     */       
/* 239 */       this.channels.put(fd, old);
/*     */ 
/*     */       
/* 242 */       assert !ch.isOpen();
/* 243 */     } else if (ch.isOpen()) {
/*     */ 
/*     */       
/* 246 */       Native.epollCtlDel(this.epollFd.intValue(), fd);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected Queue<Runnable> newTaskQueue(int maxPendingTasks) {
/* 252 */     return newTaskQueue0(maxPendingTasks);
/*     */   }
/*     */ 
/*     */   
/*     */   private static Queue<Runnable> newTaskQueue0(int maxPendingTasks) {
/* 257 */     return (maxPendingTasks == Integer.MAX_VALUE) ? PlatformDependent.newMpscQueue() : 
/* 258 */       PlatformDependent.newMpscQueue(maxPendingTasks);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getIoRatio() {
/* 265 */     return this.ioRatio;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setIoRatio(int ioRatio) {
/* 273 */     if (ioRatio <= 0 || ioRatio > 100) {
/* 274 */       throw new IllegalArgumentException("ioRatio: " + ioRatio + " (expected: 0 < ioRatio <= 100)");
/*     */     }
/* 276 */     this.ioRatio = ioRatio;
/*     */   }
/*     */ 
/*     */   
/*     */   public int registeredChannels() {
/* 281 */     return this.channels.size();
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterator<Channel> registeredChannelsIterator() {
/* 286 */     assert inEventLoop();
/* 287 */     IntObjectMap<AbstractEpollChannel> ch = this.channels;
/* 288 */     if (ch.isEmpty()) {
/* 289 */       return SingleThreadEventLoop.ChannelsReadOnlyIterator.empty();
/*     */     }
/* 291 */     return (Iterator<Channel>)new SingleThreadEventLoop.ChannelsReadOnlyIterator(ch.values());
/*     */   }
/*     */   
/*     */   private long epollWait(long deadlineNanos) throws IOException {
/* 295 */     if (deadlineNanos == Long.MAX_VALUE) {
/* 296 */       return Native.epollWait(this.epollFd, this.events, this.timerFd, 2147483647, 0, EPOLL_WAIT_MILLIS_THRESHOLD);
/*     */     }
/*     */     
/* 299 */     long totalDelay = deadlineToDelayNanos(deadlineNanos);
/* 300 */     int delaySeconds = (int)Math.min(totalDelay / 1000000000L, 2147483647L);
/* 301 */     int delayNanos = (int)Math.min(totalDelay - delaySeconds * 1000000000L, 999999999L);
/* 302 */     return Native.epollWait(this.epollFd, this.events, this.timerFd, delaySeconds, delayNanos, EPOLL_WAIT_MILLIS_THRESHOLD);
/*     */   }
/*     */   
/*     */   private int epollWaitNoTimerChange() throws IOException {
/* 306 */     return Native.epollWait(this.epollFd, this.events, false);
/*     */   }
/*     */   
/*     */   private int epollWaitNow() throws IOException {
/* 310 */     return Native.epollWait(this.epollFd, this.events, true);
/*     */   }
/*     */   
/*     */   private int epollBusyWait() throws IOException {
/* 314 */     return Native.epollBusyWait(this.epollFd, this.events);
/*     */   }
/*     */ 
/*     */   
/*     */   private int epollWaitTimeboxed() throws IOException {
/* 319 */     return Native.epollWait(this.epollFd, this.events, 1000);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void run() {
/* 324 */     long prevDeadlineNanos = Long.MAX_VALUE; while (true) {
/*     */       
/*     */       try { long curDeadlineNanos;
/* 327 */         int strategy = this.selectStrategy.calculateStrategy(this.selectNowSupplier, hasTasks());
/* 328 */         switch (strategy)
/*     */         
/*     */         { case -2:
/*     */ 
/*     */             
/*     */             try { 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */               
/* 419 */               if (isShuttingDown()) {
/* 420 */                 closeAll();
/* 421 */                 if (confirmShutdown()) {
/*     */                   break;
/*     */                 }
/*     */               }  }
/* 425 */             catch (Error e)
/* 426 */             { throw e; }
/* 427 */             catch (Throwable t)
/* 428 */             { handleLoopException(t); }  continue;case -3: strategy = epollBusyWait(); break;case -1: if (this.pendingWakeup) { strategy = epollWaitTimeboxed(); if (strategy != 0) break;  logger.warn("Missed eventfd write (not seen after > 1 second)"); this.pendingWakeup = false; if (hasTasks()) break;  }  curDeadlineNanos = nextScheduledTaskDeadlineNanos(); if (curDeadlineNanos == -1L) curDeadlineNanos = Long.MAX_VALUE;  this.nextWakeupNanos.set(curDeadlineNanos); try { if (!hasTasks()) if (curDeadlineNanos == prevDeadlineNanos) { strategy = epollWaitNoTimerChange(); } else { long result = epollWait(curDeadlineNanos); strategy = Native.epollReady(result); prevDeadlineNanos = Native.epollTimerWasUsed(result) ? curDeadlineNanos : Long.MAX_VALUE; }   } finally { if (this.nextWakeupNanos.get() == -1L || this.nextWakeupNanos.getAndSet(-1L) == -1L) this.pendingWakeup = true;  }  break; }  int ioRatio = this.ioRatio; if (ioRatio == 100) { try { if (strategy > 0 && processReady(this.events, strategy)) prevDeadlineNanos = Long.MAX_VALUE;  } finally { runAllTasks(); }  } else if (strategy > 0) { long ioStartTime = System.nanoTime(); try { if (processReady(this.events, strategy)) prevDeadlineNanos = Long.MAX_VALUE;  } finally { long ioTime = System.nanoTime() - ioStartTime; runAllTasks(ioTime * (100 - ioRatio) / ioRatio); }  } else { runAllTasks(0L); }  if (this.allowGrowing && strategy == this.events.length()) this.events.increase();  } catch (Error e) { throw e; } catch (Throwable t) { handleLoopException(t); } finally { try { if (isShuttingDown()) { closeAll(); if (confirmShutdown()) return;  }  } catch (Error e) { throw e; } catch (Throwable t) { handleLoopException(t); }
/*     */          }
/*     */     
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void handleLoopException(Throwable t) {
/* 438 */     logger.warn("Unexpected exception in the selector loop.", t);
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 443 */       Thread.sleep(1000L);
/* 444 */     } catch (InterruptedException interruptedException) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void closeAll() {
/* 452 */     AbstractEpollChannel[] localChannels = (AbstractEpollChannel[])this.channels.values().toArray((Object[])new AbstractEpollChannel[0]);
/*     */     
/* 454 */     for (AbstractEpollChannel ch : localChannels) {
/* 455 */       ch.unsafe().close(ch.unsafe().voidPromise());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean processReady(EpollEventArray events, int ready) {
/* 461 */     boolean timerFired = false;
/* 462 */     for (int i = 0; i < ready; i++) {
/* 463 */       int fd = events.fd(i);
/* 464 */       if (fd == this.eventFd.intValue()) {
/* 465 */         this.pendingWakeup = false;
/* 466 */       } else if (fd == this.timerFd.intValue()) {
/* 467 */         timerFired = true;
/*     */       } else {
/* 469 */         long ev = events.events(i);
/*     */         
/* 471 */         AbstractEpollChannel ch = (AbstractEpollChannel)this.channels.get(fd);
/* 472 */         if (ch != null) {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 477 */           AbstractEpollChannel.AbstractEpollUnsafe unsafe = (AbstractEpollChannel.AbstractEpollUnsafe)ch.unsafe();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 487 */           if ((ev & (Native.EPOLLERR | Native.EPOLLOUT)) != 0L)
/*     */           {
/* 489 */             unsafe.epollOutReady();
/*     */           }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 497 */           if ((ev & (Native.EPOLLERR | Native.EPOLLIN)) != 0L)
/*     */           {
/* 499 */             unsafe.epollInReady();
/*     */           }
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 505 */           if ((ev & Native.EPOLLRDHUP) != 0L) {
/* 506 */             unsafe.epollRdHupReady();
/*     */           }
/*     */         } else {
/*     */           
/*     */           try {
/* 511 */             Native.epollCtlDel(this.epollFd.intValue(), fd);
/* 512 */           } catch (IOException iOException) {}
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 521 */     return timerFired;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void cleanup() {
/*     */     try {
/* 528 */       while (this.pendingWakeup) {
/*     */         try {
/* 530 */           int count = epollWaitTimeboxed();
/* 531 */           if (count == 0) {
/*     */             break;
/*     */           }
/*     */           
/* 535 */           for (int i = 0; i < count; i++) {
/* 536 */             if (this.events.fd(i) == this.eventFd.intValue()) {
/* 537 */               this.pendingWakeup = false;
/*     */               break;
/*     */             } 
/*     */           } 
/* 541 */         } catch (IOException iOException) {}
/*     */       } 
/*     */ 
/*     */       
/*     */       try {
/* 546 */         this.eventFd.close();
/* 547 */       } catch (IOException e) {
/* 548 */         logger.warn("Failed to close the event fd.", e);
/*     */       } 
/*     */       try {
/* 551 */         this.timerFd.close();
/* 552 */       } catch (IOException e) {
/* 553 */         logger.warn("Failed to close the timer fd.", e);
/*     */       } 
/*     */       
/*     */       try {
/* 557 */         this.epollFd.close();
/* 558 */       } catch (IOException e) {
/* 559 */         logger.warn("Failed to close the epoll fd.", e);
/*     */       } 
/*     */     } finally {
/*     */       
/* 563 */       if (this.iovArray != null) {
/* 564 */         this.iovArray.release();
/* 565 */         this.iovArray = null;
/*     */       } 
/* 567 */       if (this.datagramPacketArray != null) {
/* 568 */         this.datagramPacketArray.release();
/* 569 */         this.datagramPacketArray = null;
/*     */       } 
/* 571 */       this.events.free();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-transport-classes-epoll-4.1.93.Final.jar!\io\netty\channel\epoll\EpollEventLoop.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */