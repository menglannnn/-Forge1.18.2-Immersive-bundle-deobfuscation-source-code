/*    */ package io.netty.channel.epoll;
/*    */ 
/*    */ import io.netty.channel.RecvByteBufAllocator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class EpollRecvByteAllocatorStreamingHandle
/*    */   extends EpollRecvByteAllocatorHandle
/*    */ {
/*    */   EpollRecvByteAllocatorStreamingHandle(RecvByteBufAllocator.ExtendedHandle handle) {
/* 22 */     super(handle);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   boolean maybeMoreDataToRead() {
/* 33 */     return (lastBytesRead() == attemptedBytesRead() || isReceivedRdHup());
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-transport-classes-epoll-4.1.93.Final.jar!\io\netty\channel\epoll\EpollRecvByteAllocatorStreamingHandle.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */