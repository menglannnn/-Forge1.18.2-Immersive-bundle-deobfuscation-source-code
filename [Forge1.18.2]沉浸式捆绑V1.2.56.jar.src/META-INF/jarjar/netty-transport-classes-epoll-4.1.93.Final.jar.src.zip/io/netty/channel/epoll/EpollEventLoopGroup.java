/*     */ package io.netty.channel.epoll;
/*     */ 
/*     */ import io.netty.channel.DefaultSelectStrategyFactory;
/*     */ import io.netty.channel.EventLoop;
/*     */ import io.netty.channel.EventLoopGroup;
/*     */ import io.netty.channel.EventLoopTaskQueueFactory;
/*     */ import io.netty.channel.MultithreadEventLoopGroup;
/*     */ import io.netty.channel.SelectStrategyFactory;
/*     */ import io.netty.util.concurrent.EventExecutor;
/*     */ import io.netty.util.concurrent.EventExecutorChooserFactory;
/*     */ import io.netty.util.concurrent.RejectedExecutionHandler;
/*     */ import io.netty.util.concurrent.RejectedExecutionHandlers;
/*     */ import java.util.concurrent.Executor;
/*     */ import java.util.concurrent.ThreadFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class EpollEventLoopGroup
/*     */   extends MultithreadEventLoopGroup
/*     */ {
/*     */   public EpollEventLoopGroup() {
/*  47 */     this(0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EpollEventLoopGroup(int nThreads) {
/*  54 */     this(nThreads, (ThreadFactory)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EpollEventLoopGroup(ThreadFactory threadFactory) {
/*  62 */     this(0, threadFactory, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EpollEventLoopGroup(int nThreads, SelectStrategyFactory selectStrategyFactory) {
/*  70 */     this(nThreads, (ThreadFactory)null, selectStrategyFactory);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EpollEventLoopGroup(int nThreads, ThreadFactory threadFactory) {
/*  78 */     this(nThreads, threadFactory, 0);
/*     */   }
/*     */   
/*     */   public EpollEventLoopGroup(int nThreads, Executor executor) {
/*  82 */     this(nThreads, executor, DefaultSelectStrategyFactory.INSTANCE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EpollEventLoopGroup(int nThreads, ThreadFactory threadFactory, SelectStrategyFactory selectStrategyFactory) {
/*  90 */     this(nThreads, threadFactory, 0, selectStrategyFactory);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public EpollEventLoopGroup(int nThreads, ThreadFactory threadFactory, int maxEventsAtOnce) {
/* 101 */     this(nThreads, threadFactory, maxEventsAtOnce, DefaultSelectStrategyFactory.INSTANCE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public EpollEventLoopGroup(int nThreads, ThreadFactory threadFactory, int maxEventsAtOnce, SelectStrategyFactory selectStrategyFactory) {
/* 114 */     super(nThreads, threadFactory, new Object[] { Integer.valueOf(maxEventsAtOnce), selectStrategyFactory, RejectedExecutionHandlers.reject() });
/*     */     Epoll.ensureAvailability();
/*     */   }
/*     */   public EpollEventLoopGroup(int nThreads, Executor executor, SelectStrategyFactory selectStrategyFactory) {
/* 118 */     super(nThreads, executor, new Object[] { Integer.valueOf(0), selectStrategyFactory, RejectedExecutionHandlers.reject() });
/*     */     Epoll.ensureAvailability();
/*     */   }
/*     */   
/*     */   public EpollEventLoopGroup(int nThreads, Executor executor, EventExecutorChooserFactory chooserFactory, SelectStrategyFactory selectStrategyFactory) {
/* 123 */     super(nThreads, executor, chooserFactory, new Object[] { Integer.valueOf(0), selectStrategyFactory, RejectedExecutionHandlers.reject() });
/*     */     Epoll.ensureAvailability();
/*     */   }
/*     */ 
/*     */   
/*     */   public EpollEventLoopGroup(int nThreads, Executor executor, EventExecutorChooserFactory chooserFactory, SelectStrategyFactory selectStrategyFactory, RejectedExecutionHandler rejectedExecutionHandler) {
/* 129 */     super(nThreads, executor, chooserFactory, new Object[] { Integer.valueOf(0), selectStrategyFactory, rejectedExecutionHandler });
/*     */     Epoll.ensureAvailability();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public EpollEventLoopGroup(int nThreads, Executor executor, EventExecutorChooserFactory chooserFactory, SelectStrategyFactory selectStrategyFactory, RejectedExecutionHandler rejectedExecutionHandler, EventLoopTaskQueueFactory queueFactory) {
/* 136 */     super(nThreads, executor, chooserFactory, new Object[] { Integer.valueOf(0), selectStrategyFactory, rejectedExecutionHandler, queueFactory });
/*     */     Epoll.ensureAvailability();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EpollEventLoopGroup(int nThreads, Executor executor, EventExecutorChooserFactory chooserFactory, SelectStrategyFactory selectStrategyFactory, RejectedExecutionHandler rejectedExecutionHandler, EventLoopTaskQueueFactory taskQueueFactory, EventLoopTaskQueueFactory tailTaskQueueFactory) {
/* 157 */     super(nThreads, executor, chooserFactory, new Object[] { Integer.valueOf(0), selectStrategyFactory, rejectedExecutionHandler, taskQueueFactory, tailTaskQueueFactory });
/*     */     Epoll.ensureAvailability();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setIoRatio(int ioRatio) {
/* 166 */     for (EventExecutor e : this) {
/* 167 */       ((EpollEventLoop)e).setIoRatio(ioRatio);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected EventLoop newChild(Executor executor, Object... args) throws Exception {
/* 173 */     Integer maxEvents = (Integer)args[0];
/* 174 */     SelectStrategyFactory selectStrategyFactory = (SelectStrategyFactory)args[1];
/* 175 */     RejectedExecutionHandler rejectedExecutionHandler = (RejectedExecutionHandler)args[2];
/* 176 */     EventLoopTaskQueueFactory taskQueueFactory = null;
/* 177 */     EventLoopTaskQueueFactory tailTaskQueueFactory = null;
/*     */     
/* 179 */     int argsLength = args.length;
/* 180 */     if (argsLength > 3) {
/* 181 */       taskQueueFactory = (EventLoopTaskQueueFactory)args[3];
/*     */     }
/* 183 */     if (argsLength > 4) {
/* 184 */       tailTaskQueueFactory = (EventLoopTaskQueueFactory)args[4];
/*     */     }
/* 186 */     return (EventLoop)new EpollEventLoop((EventLoopGroup)this, executor, maxEvents.intValue(), selectStrategyFactory
/* 187 */         .newSelectStrategy(), rejectedExecutionHandler, taskQueueFactory, tailTaskQueueFactory);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-transport-classes-epoll-4.1.93.Final.jar!\io\netty\channel\epoll\EpollEventLoopGroup.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */