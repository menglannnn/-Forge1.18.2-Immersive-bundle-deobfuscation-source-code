/*     */ package io.netty.channel.epoll;
/*     */ 
/*     */ import io.netty.channel.unix.Buffer;
/*     */ import io.netty.util.internal.PlatformDependent;
/*     */ import java.nio.ByteBuffer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class EpollEventArray
/*     */ {
/*  45 */   private static final int EPOLL_EVENT_SIZE = Native.sizeofEpollEvent();
/*     */   
/*  47 */   private static final int EPOLL_DATA_OFFSET = Native.offsetofEpollData();
/*     */   
/*     */   private ByteBuffer memory;
/*     */   private long memoryAddress;
/*     */   private int length;
/*     */   
/*     */   EpollEventArray(int length) {
/*  54 */     if (length < 1) {
/*  55 */       throw new IllegalArgumentException("length must be >= 1 but was " + length);
/*     */     }
/*  57 */     this.length = length;
/*  58 */     this.memory = Buffer.allocateDirectWithNativeOrder(calculateBufferCapacity(length));
/*  59 */     this.memoryAddress = Buffer.memoryAddress(this.memory);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   long memoryAddress() {
/*  66 */     return this.memoryAddress;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int length() {
/*  74 */     return this.length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void increase() {
/*  82 */     this.length <<= 1;
/*     */     
/*  84 */     ByteBuffer buffer = Buffer.allocateDirectWithNativeOrder(calculateBufferCapacity(this.length));
/*  85 */     Buffer.free(this.memory);
/*  86 */     this.memory = buffer;
/*  87 */     this.memoryAddress = Buffer.memoryAddress(buffer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void free() {
/*  94 */     Buffer.free(this.memory);
/*  95 */     this.memoryAddress = 0L;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int events(int index) {
/* 102 */     return getInt(index, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int fd(int index) {
/* 109 */     return getInt(index, EPOLL_DATA_OFFSET);
/*     */   }
/*     */   
/*     */   private int getInt(int index, int offset) {
/* 113 */     if (PlatformDependent.hasUnsafe()) {
/* 114 */       long n = index * EPOLL_EVENT_SIZE;
/* 115 */       return PlatformDependent.getInt(this.memoryAddress + n + offset);
/*     */     } 
/* 117 */     return this.memory.getInt(index * EPOLL_EVENT_SIZE + offset);
/*     */   }
/*     */   
/*     */   private static int calculateBufferCapacity(int capacity) {
/* 121 */     return capacity * EPOLL_EVENT_SIZE;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-transport-classes-epoll-4.1.93.Final.jar!\io\netty\channel\epoll\EpollEventArray.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */