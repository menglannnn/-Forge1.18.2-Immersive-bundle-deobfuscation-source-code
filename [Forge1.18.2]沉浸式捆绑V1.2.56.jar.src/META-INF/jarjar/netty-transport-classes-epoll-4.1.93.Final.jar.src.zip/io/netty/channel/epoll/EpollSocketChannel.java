/*     */ package io.netty.channel.epoll;
/*     */ 
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import io.netty.channel.AbstractChannel;
/*     */ import io.netty.channel.Channel;
/*     */ import io.netty.channel.ChannelConfig;
/*     */ import io.netty.channel.ChannelException;
/*     */ import io.netty.channel.ChannelOutboundBuffer;
/*     */ import io.netty.channel.socket.InternetProtocolFamily;
/*     */ import io.netty.channel.socket.ServerSocketChannel;
/*     */ import io.netty.channel.socket.SocketChannel;
/*     */ import io.netty.channel.socket.SocketChannelConfig;
/*     */ import io.netty.util.concurrent.GlobalEventExecutor;
/*     */ import java.io.IOException;
/*     */ import java.net.InetAddress;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.SocketAddress;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.Executor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class EpollSocketChannel
/*     */   extends AbstractEpollStreamChannel
/*     */   implements SocketChannel
/*     */ {
/*     */   private final EpollSocketChannelConfig config;
/*  47 */   private volatile Collection<InetAddress> tcpMd5SigAddresses = Collections.emptyList();
/*     */   
/*     */   public EpollSocketChannel() {
/*  50 */     super(LinuxSocket.newSocketStream(), false);
/*  51 */     this.config = new EpollSocketChannelConfig(this);
/*     */   }
/*     */   
/*     */   public EpollSocketChannel(InternetProtocolFamily protocol) {
/*  55 */     super(LinuxSocket.newSocketStream(protocol), false);
/*  56 */     this.config = new EpollSocketChannelConfig(this);
/*     */   }
/*     */   
/*     */   public EpollSocketChannel(int fd) {
/*  60 */     super(fd);
/*  61 */     this.config = new EpollSocketChannelConfig(this);
/*     */   }
/*     */   
/*     */   EpollSocketChannel(LinuxSocket fd, boolean active) {
/*  65 */     super(fd, active);
/*  66 */     this.config = new EpollSocketChannelConfig(this);
/*     */   }
/*     */   
/*     */   EpollSocketChannel(Channel parent, LinuxSocket fd, InetSocketAddress remoteAddress) {
/*  70 */     super(parent, fd, remoteAddress);
/*  71 */     this.config = new EpollSocketChannelConfig(this);
/*     */     
/*  73 */     if (parent instanceof EpollServerSocketChannel) {
/*  74 */       this.tcpMd5SigAddresses = ((EpollServerSocketChannel)parent).tcpMd5SigAddresses();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EpollTcpInfo tcpInfo() {
/*  83 */     return tcpInfo(new EpollTcpInfo());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EpollTcpInfo tcpInfo(EpollTcpInfo info) {
/*     */     try {
/*  92 */       this.socket.getTcpInfo(info);
/*  93 */       return info;
/*  94 */     } catch (IOException e) {
/*  95 */       throw new ChannelException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public InetSocketAddress remoteAddress() {
/* 101 */     return (InetSocketAddress)super.remoteAddress();
/*     */   }
/*     */ 
/*     */   
/*     */   public InetSocketAddress localAddress() {
/* 106 */     return (InetSocketAddress)super.localAddress();
/*     */   }
/*     */ 
/*     */   
/*     */   public EpollSocketChannelConfig config() {
/* 111 */     return this.config;
/*     */   }
/*     */ 
/*     */   
/*     */   public ServerSocketChannel parent() {
/* 116 */     return (ServerSocketChannel)super.parent();
/*     */   }
/*     */ 
/*     */   
/*     */   protected AbstractEpollChannel.AbstractEpollUnsafe newUnsafe() {
/* 121 */     return new EpollSocketChannelUnsafe();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   boolean doConnect0(SocketAddress remote) throws Exception {
/* 127 */     ChannelOutboundBuffer outbound = unsafe().outboundBuffer();
/* 128 */     outbound.addFlush();
/*     */     Object curr;
/* 130 */     if (Native.IS_SUPPORTING_TCP_FASTOPEN_CLIENT && this.config.isTcpFastOpenConnect() && curr = outbound.current() instanceof ByteBuf) {
/* 131 */       ByteBuf initialData = (ByteBuf)curr;
/*     */ 
/*     */       
/* 134 */       long localFlushedAmount = doWriteOrSendBytes(initialData, (InetSocketAddress)remote, true);
/*     */       
/* 136 */       if (localFlushedAmount > 0L) {
/*     */ 
/*     */         
/* 139 */         outbound.removeBytes(localFlushedAmount);
/* 140 */         return true;
/*     */       } 
/*     */     } 
/*     */     
/* 144 */     return super.doConnect0(remote);
/*     */   }
/*     */   
/*     */   private final class EpollSocketChannelUnsafe
/*     */     extends AbstractEpollStreamChannel.EpollStreamUnsafe {
/*     */     private EpollSocketChannelUnsafe() {}
/*     */     
/*     */     protected Executor prepareToClose() {
/*     */       try {
/* 153 */         if (EpollSocketChannel.this.isOpen() && EpollSocketChannel.this.config().getSoLinger() > 0) {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 158 */           ((EpollEventLoop)EpollSocketChannel.this.eventLoop()).remove(EpollSocketChannel.this);
/* 159 */           return (Executor)GlobalEventExecutor.INSTANCE;
/*     */         } 
/* 161 */       } catch (Throwable throwable) {}
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 166 */       return null;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   void setTcpMd5Sig(Map<InetAddress, byte[]> keys) throws IOException {
/* 172 */     synchronized (this) {
/* 173 */       this.tcpMd5SigAddresses = TcpMd5Util.newTcpMd5Sigs(this, this.tcpMd5SigAddresses, keys);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-transport-classes-epoll-4.1.93.Final.jar!\io\netty\channel\epoll\EpollSocketChannel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */