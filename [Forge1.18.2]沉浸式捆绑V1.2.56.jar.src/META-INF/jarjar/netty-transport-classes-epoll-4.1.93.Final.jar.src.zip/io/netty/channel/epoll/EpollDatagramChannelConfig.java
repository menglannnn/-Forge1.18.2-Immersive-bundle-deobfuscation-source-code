/*     */ package io.netty.channel.epoll;
/*     */ 
/*     */ import io.netty.buffer.ByteBufAllocator;
/*     */ import io.netty.channel.ChannelConfig;
/*     */ import io.netty.channel.ChannelException;
/*     */ import io.netty.channel.ChannelOption;
/*     */ import io.netty.channel.FixedRecvByteBufAllocator;
/*     */ import io.netty.channel.MessageSizeEstimator;
/*     */ import io.netty.channel.RecvByteBufAllocator;
/*     */ import io.netty.channel.WriteBufferWaterMark;
/*     */ import io.netty.channel.socket.DatagramChannelConfig;
/*     */ import io.netty.util.internal.ObjectUtil;
/*     */ import java.io.IOException;
/*     */ import java.net.InetAddress;
/*     */ import java.net.NetworkInterface;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class EpollDatagramChannelConfig
/*     */   extends EpollChannelConfig
/*     */   implements DatagramChannelConfig
/*     */ {
/*     */   private boolean activeOnOpen;
/*     */   private volatile int maxDatagramSize;
/*     */   private volatile boolean gro;
/*     */   
/*     */   EpollDatagramChannelConfig(EpollDatagramChannel channel) {
/*  39 */     super(channel);
/*  40 */     setRecvByteBufAllocator((RecvByteBufAllocator)new FixedRecvByteBufAllocator(2048));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<ChannelOption<?>, Object> getOptions() {
/*  46 */     return getOptions(super
/*  47 */         .getOptions(), new ChannelOption[] { ChannelOption.SO_BROADCAST, ChannelOption.SO_RCVBUF, ChannelOption.SO_SNDBUF, ChannelOption.SO_REUSEADDR, ChannelOption.IP_MULTICAST_LOOP_DISABLED, ChannelOption.IP_MULTICAST_ADDR, ChannelOption.IP_MULTICAST_IF, ChannelOption.IP_MULTICAST_TTL, ChannelOption.IP_TOS, ChannelOption.DATAGRAM_CHANNEL_ACTIVE_ON_REGISTRATION, EpollChannelOption.SO_REUSEPORT, EpollChannelOption.IP_FREEBIND, EpollChannelOption.IP_TRANSPARENT, EpollChannelOption.IP_RECVORIGDSTADDR, EpollChannelOption.MAX_DATAGRAM_PAYLOAD_SIZE, EpollChannelOption.UDP_GRO });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T getOption(ChannelOption<T> option) {
/*  60 */     if (option == ChannelOption.SO_BROADCAST) {
/*  61 */       return (T)Boolean.valueOf(isBroadcast());
/*     */     }
/*  63 */     if (option == ChannelOption.SO_RCVBUF) {
/*  64 */       return (T)Integer.valueOf(getReceiveBufferSize());
/*     */     }
/*  66 */     if (option == ChannelOption.SO_SNDBUF) {
/*  67 */       return (T)Integer.valueOf(getSendBufferSize());
/*     */     }
/*  69 */     if (option == ChannelOption.SO_REUSEADDR) {
/*  70 */       return (T)Boolean.valueOf(isReuseAddress());
/*     */     }
/*  72 */     if (option == ChannelOption.IP_MULTICAST_LOOP_DISABLED) {
/*  73 */       return (T)Boolean.valueOf(isLoopbackModeDisabled());
/*     */     }
/*  75 */     if (option == ChannelOption.IP_MULTICAST_ADDR) {
/*  76 */       return (T)getInterface();
/*     */     }
/*  78 */     if (option == ChannelOption.IP_MULTICAST_IF) {
/*  79 */       return (T)getNetworkInterface();
/*     */     }
/*  81 */     if (option == ChannelOption.IP_MULTICAST_TTL) {
/*  82 */       return (T)Integer.valueOf(getTimeToLive());
/*     */     }
/*  84 */     if (option == ChannelOption.IP_TOS) {
/*  85 */       return (T)Integer.valueOf(getTrafficClass());
/*     */     }
/*  87 */     if (option == ChannelOption.DATAGRAM_CHANNEL_ACTIVE_ON_REGISTRATION) {
/*  88 */       return (T)Boolean.valueOf(this.activeOnOpen);
/*     */     }
/*  90 */     if (option == EpollChannelOption.SO_REUSEPORT) {
/*  91 */       return (T)Boolean.valueOf(isReusePort());
/*     */     }
/*  93 */     if (option == EpollChannelOption.IP_TRANSPARENT) {
/*  94 */       return (T)Boolean.valueOf(isIpTransparent());
/*     */     }
/*  96 */     if (option == EpollChannelOption.IP_FREEBIND) {
/*  97 */       return (T)Boolean.valueOf(isFreeBind());
/*     */     }
/*  99 */     if (option == EpollChannelOption.IP_RECVORIGDSTADDR) {
/* 100 */       return (T)Boolean.valueOf(isIpRecvOrigDestAddr());
/*     */     }
/* 102 */     if (option == EpollChannelOption.MAX_DATAGRAM_PAYLOAD_SIZE) {
/* 103 */       return (T)Integer.valueOf(getMaxDatagramPayloadSize());
/*     */     }
/* 105 */     if (option == EpollChannelOption.UDP_GRO) {
/* 106 */       return (T)Boolean.valueOf(isUdpGro());
/*     */     }
/* 108 */     return super.getOption(option);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> boolean setOption(ChannelOption<T> option, T value) {
/* 114 */     validate(option, value);
/*     */     
/* 116 */     if (option == ChannelOption.SO_BROADCAST) {
/* 117 */       setBroadcast(((Boolean)value).booleanValue());
/* 118 */     } else if (option == ChannelOption.SO_RCVBUF) {
/* 119 */       setReceiveBufferSize(((Integer)value).intValue());
/* 120 */     } else if (option == ChannelOption.SO_SNDBUF) {
/* 121 */       setSendBufferSize(((Integer)value).intValue());
/* 122 */     } else if (option == ChannelOption.SO_REUSEADDR) {
/* 123 */       setReuseAddress(((Boolean)value).booleanValue());
/* 124 */     } else if (option == ChannelOption.IP_MULTICAST_LOOP_DISABLED) {
/* 125 */       setLoopbackModeDisabled(((Boolean)value).booleanValue());
/* 126 */     } else if (option == ChannelOption.IP_MULTICAST_ADDR) {
/* 127 */       setInterface((InetAddress)value);
/* 128 */     } else if (option == ChannelOption.IP_MULTICAST_IF) {
/* 129 */       setNetworkInterface((NetworkInterface)value);
/* 130 */     } else if (option == ChannelOption.IP_MULTICAST_TTL) {
/* 131 */       setTimeToLive(((Integer)value).intValue());
/* 132 */     } else if (option == ChannelOption.IP_TOS) {
/* 133 */       setTrafficClass(((Integer)value).intValue());
/* 134 */     } else if (option == ChannelOption.DATAGRAM_CHANNEL_ACTIVE_ON_REGISTRATION) {
/* 135 */       setActiveOnOpen(((Boolean)value).booleanValue());
/* 136 */     } else if (option == EpollChannelOption.SO_REUSEPORT) {
/* 137 */       setReusePort(((Boolean)value).booleanValue());
/* 138 */     } else if (option == EpollChannelOption.IP_FREEBIND) {
/* 139 */       setFreeBind(((Boolean)value).booleanValue());
/* 140 */     } else if (option == EpollChannelOption.IP_TRANSPARENT) {
/* 141 */       setIpTransparent(((Boolean)value).booleanValue());
/* 142 */     } else if (option == EpollChannelOption.IP_RECVORIGDSTADDR) {
/* 143 */       setIpRecvOrigDestAddr(((Boolean)value).booleanValue());
/* 144 */     } else if (option == EpollChannelOption.MAX_DATAGRAM_PAYLOAD_SIZE) {
/* 145 */       setMaxDatagramPayloadSize(((Integer)value).intValue());
/* 146 */     } else if (option == EpollChannelOption.UDP_GRO) {
/* 147 */       setUdpGro(((Boolean)value).booleanValue());
/*     */     } else {
/* 149 */       return super.setOption(option, value);
/*     */     } 
/*     */     
/* 152 */     return true;
/*     */   }
/*     */   
/*     */   private void setActiveOnOpen(boolean activeOnOpen) {
/* 156 */     if (this.channel.isRegistered()) {
/* 157 */       throw new IllegalStateException("Can only changed before channel was registered");
/*     */     }
/* 159 */     this.activeOnOpen = activeOnOpen;
/*     */   }
/*     */   
/*     */   boolean getActiveOnOpen() {
/* 163 */     return this.activeOnOpen;
/*     */   }
/*     */ 
/*     */   
/*     */   public EpollDatagramChannelConfig setMessageSizeEstimator(MessageSizeEstimator estimator) {
/* 168 */     super.setMessageSizeEstimator(estimator);
/* 169 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public EpollDatagramChannelConfig setWriteBufferLowWaterMark(int writeBufferLowWaterMark) {
/* 175 */     super.setWriteBufferLowWaterMark(writeBufferLowWaterMark);
/* 176 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public EpollDatagramChannelConfig setWriteBufferHighWaterMark(int writeBufferHighWaterMark) {
/* 182 */     super.setWriteBufferHighWaterMark(writeBufferHighWaterMark);
/* 183 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public EpollDatagramChannelConfig setWriteBufferWaterMark(WriteBufferWaterMark writeBufferWaterMark) {
/* 188 */     super.setWriteBufferWaterMark(writeBufferWaterMark);
/* 189 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public EpollDatagramChannelConfig setAutoClose(boolean autoClose) {
/* 194 */     super.setAutoClose(autoClose);
/* 195 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public EpollDatagramChannelConfig setAutoRead(boolean autoRead) {
/* 200 */     super.setAutoRead(autoRead);
/* 201 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public EpollDatagramChannelConfig setRecvByteBufAllocator(RecvByteBufAllocator allocator) {
/* 206 */     super.setRecvByteBufAllocator(allocator);
/* 207 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public EpollDatagramChannelConfig setWriteSpinCount(int writeSpinCount) {
/* 212 */     super.setWriteSpinCount(writeSpinCount);
/* 213 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public EpollDatagramChannelConfig setAllocator(ByteBufAllocator allocator) {
/* 218 */     super.setAllocator(allocator);
/* 219 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public EpollDatagramChannelConfig setConnectTimeoutMillis(int connectTimeoutMillis) {
/* 224 */     super.setConnectTimeoutMillis(connectTimeoutMillis);
/* 225 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public EpollDatagramChannelConfig setMaxMessagesPerRead(int maxMessagesPerRead) {
/* 231 */     super.setMaxMessagesPerRead(maxMessagesPerRead);
/* 232 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getSendBufferSize() {
/*     */     try {
/* 238 */       return ((EpollDatagramChannel)this.channel).socket.getSendBufferSize();
/* 239 */     } catch (IOException e) {
/* 240 */       throw new ChannelException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public EpollDatagramChannelConfig setSendBufferSize(int sendBufferSize) {
/*     */     try {
/* 247 */       ((EpollDatagramChannel)this.channel).socket.setSendBufferSize(sendBufferSize);
/* 248 */       return this;
/* 249 */     } catch (IOException e) {
/* 250 */       throw new ChannelException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int getReceiveBufferSize() {
/*     */     try {
/* 257 */       return ((EpollDatagramChannel)this.channel).socket.getReceiveBufferSize();
/* 258 */     } catch (IOException e) {
/* 259 */       throw new ChannelException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public EpollDatagramChannelConfig setReceiveBufferSize(int receiveBufferSize) {
/*     */     try {
/* 266 */       ((EpollDatagramChannel)this.channel).socket.setReceiveBufferSize(receiveBufferSize);
/* 267 */       return this;
/* 268 */     } catch (IOException e) {
/* 269 */       throw new ChannelException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int getTrafficClass() {
/*     */     try {
/* 276 */       return ((EpollDatagramChannel)this.channel).socket.getTrafficClass();
/* 277 */     } catch (IOException e) {
/* 278 */       throw new ChannelException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public EpollDatagramChannelConfig setTrafficClass(int trafficClass) {
/*     */     try {
/* 285 */       ((EpollDatagramChannel)this.channel).socket.setTrafficClass(trafficClass);
/* 286 */       return this;
/* 287 */     } catch (IOException e) {
/* 288 */       throw new ChannelException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isReuseAddress() {
/*     */     try {
/* 295 */       return ((EpollDatagramChannel)this.channel).socket.isReuseAddress();
/* 296 */     } catch (IOException e) {
/* 297 */       throw new ChannelException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public EpollDatagramChannelConfig setReuseAddress(boolean reuseAddress) {
/*     */     try {
/* 304 */       ((EpollDatagramChannel)this.channel).socket.setReuseAddress(reuseAddress);
/* 305 */       return this;
/* 306 */     } catch (IOException e) {
/* 307 */       throw new ChannelException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isBroadcast() {
/*     */     try {
/* 314 */       return ((EpollDatagramChannel)this.channel).socket.isBroadcast();
/* 315 */     } catch (IOException e) {
/* 316 */       throw new ChannelException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public EpollDatagramChannelConfig setBroadcast(boolean broadcast) {
/*     */     try {
/* 323 */       ((EpollDatagramChannel)this.channel).socket.setBroadcast(broadcast);
/* 324 */       return this;
/* 325 */     } catch (IOException e) {
/* 326 */       throw new ChannelException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isLoopbackModeDisabled() {
/*     */     try {
/* 333 */       return ((EpollDatagramChannel)this.channel).socket.isLoopbackModeDisabled();
/* 334 */     } catch (IOException e) {
/* 335 */       throw new ChannelException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public DatagramChannelConfig setLoopbackModeDisabled(boolean loopbackModeDisabled) {
/*     */     try {
/* 342 */       ((EpollDatagramChannel)this.channel).socket.setLoopbackModeDisabled(loopbackModeDisabled);
/* 343 */       return this;
/* 344 */     } catch (IOException e) {
/* 345 */       throw new ChannelException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int getTimeToLive() {
/*     */     try {
/* 352 */       return ((EpollDatagramChannel)this.channel).socket.getTimeToLive();
/* 353 */     } catch (IOException e) {
/* 354 */       throw new ChannelException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public EpollDatagramChannelConfig setTimeToLive(int ttl) {
/*     */     try {
/* 361 */       ((EpollDatagramChannel)this.channel).socket.setTimeToLive(ttl);
/* 362 */       return this;
/* 363 */     } catch (IOException e) {
/* 364 */       throw new ChannelException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public InetAddress getInterface() {
/*     */     try {
/* 371 */       return ((EpollDatagramChannel)this.channel).socket.getInterface();
/* 372 */     } catch (IOException e) {
/* 373 */       throw new ChannelException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public EpollDatagramChannelConfig setInterface(InetAddress interfaceAddress) {
/*     */     try {
/* 380 */       ((EpollDatagramChannel)this.channel).socket.setInterface(interfaceAddress);
/* 381 */       return this;
/* 382 */     } catch (IOException e) {
/* 383 */       throw new ChannelException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public NetworkInterface getNetworkInterface() {
/*     */     try {
/* 390 */       return ((EpollDatagramChannel)this.channel).socket.getNetworkInterface();
/* 391 */     } catch (IOException e) {
/* 392 */       throw new ChannelException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public EpollDatagramChannelConfig setNetworkInterface(NetworkInterface networkInterface) {
/*     */     try {
/* 399 */       EpollDatagramChannel datagramChannel = (EpollDatagramChannel)this.channel;
/* 400 */       datagramChannel.socket.setNetworkInterface(networkInterface);
/* 401 */       return this;
/* 402 */     } catch (IOException e) {
/* 403 */       throw new ChannelException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public EpollDatagramChannelConfig setEpollMode(EpollMode mode) {
/* 409 */     super.setEpollMode(mode);
/* 410 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isReusePort() {
/*     */     try {
/* 418 */       return ((EpollDatagramChannel)this.channel).socket.isReusePort();
/* 419 */     } catch (IOException e) {
/* 420 */       throw new ChannelException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EpollDatagramChannelConfig setReusePort(boolean reusePort) {
/*     */     try {
/* 433 */       ((EpollDatagramChannel)this.channel).socket.setReusePort(reusePort);
/* 434 */       return this;
/* 435 */     } catch (IOException e) {
/* 436 */       throw new ChannelException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isIpTransparent() {
/*     */     try {
/* 446 */       return ((EpollDatagramChannel)this.channel).socket.isIpTransparent();
/* 447 */     } catch (IOException e) {
/* 448 */       throw new ChannelException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EpollDatagramChannelConfig setIpTransparent(boolean ipTransparent) {
/*     */     try {
/* 458 */       ((EpollDatagramChannel)this.channel).socket.setIpTransparent(ipTransparent);
/* 459 */       return this;
/* 460 */     } catch (IOException e) {
/* 461 */       throw new ChannelException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isFreeBind() {
/*     */     try {
/* 471 */       return ((EpollDatagramChannel)this.channel).socket.isIpFreeBind();
/* 472 */     } catch (IOException e) {
/* 473 */       throw new ChannelException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EpollDatagramChannelConfig setFreeBind(boolean freeBind) {
/*     */     try {
/* 483 */       ((EpollDatagramChannel)this.channel).socket.setIpFreeBind(freeBind);
/* 484 */       return this;
/* 485 */     } catch (IOException e) {
/* 486 */       throw new ChannelException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isIpRecvOrigDestAddr() {
/*     */     try {
/* 496 */       return ((EpollDatagramChannel)this.channel).socket.isIpRecvOrigDestAddr();
/* 497 */     } catch (IOException e) {
/* 498 */       throw new ChannelException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EpollDatagramChannelConfig setIpRecvOrigDestAddr(boolean ipTransparent) {
/*     */     try {
/* 508 */       ((EpollDatagramChannel)this.channel).socket.setIpRecvOrigDestAddr(ipTransparent);
/* 509 */       return this;
/* 510 */     } catch (IOException e) {
/* 511 */       throw new ChannelException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EpollDatagramChannelConfig setMaxDatagramPayloadSize(int maxDatagramSize) {
/* 524 */     this.maxDatagramSize = ObjectUtil.checkPositiveOrZero(maxDatagramSize, "maxDatagramSize");
/* 525 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMaxDatagramPayloadSize() {
/* 532 */     return this.maxDatagramSize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EpollDatagramChannelConfig setUdpGro(boolean gro) {
/*     */     try {
/* 544 */       ((EpollDatagramChannel)this.channel).socket.setUdpGro(gro);
/* 545 */     } catch (IOException e) {
/* 546 */       throw new ChannelException(e);
/*     */     } 
/* 548 */     this.gro = gro;
/* 549 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isUdpGro() {
/* 559 */     return this.gro;
/*     */   }
/*     */ 
/*     */   
/*     */   public EpollDatagramChannelConfig setMaxMessagesPerWrite(int maxMessagesPerWrite) {
/* 564 */     super.setMaxMessagesPerWrite(maxMessagesPerWrite);
/* 565 */     return this;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-transport-classes-epoll-4.1.93.Final.jar!\io\netty\channel\epoll\EpollDatagramChannelConfig.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */