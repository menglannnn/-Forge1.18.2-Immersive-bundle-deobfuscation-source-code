/*     */ package io.netty.channel.epoll;
/*     */ 
/*     */ import io.netty.buffer.ByteBufAllocator;
/*     */ import io.netty.channel.ChannelConfig;
/*     */ import io.netty.channel.ChannelException;
/*     */ import io.netty.channel.ChannelOption;
/*     */ import io.netty.channel.FixedRecvByteBufAllocator;
/*     */ import io.netty.channel.MessageSizeEstimator;
/*     */ import io.netty.channel.RecvByteBufAllocator;
/*     */ import io.netty.channel.WriteBufferWaterMark;
/*     */ import io.netty.channel.unix.DomainDatagramChannelConfig;
/*     */ import java.io.IOException;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class EpollDomainDatagramChannelConfig
/*     */   extends EpollChannelConfig
/*     */   implements DomainDatagramChannelConfig
/*     */ {
/*     */   private boolean activeOnOpen;
/*     */   
/*     */   EpollDomainDatagramChannelConfig(EpollDomainDatagramChannel channel) {
/*  40 */     super(channel);
/*  41 */     setRecvByteBufAllocator((RecvByteBufAllocator)new FixedRecvByteBufAllocator(2048));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<ChannelOption<?>, Object> getOptions() {
/*  47 */     return getOptions(super
/*  48 */         .getOptions(), new ChannelOption[] { ChannelOption.DATAGRAM_CHANNEL_ACTIVE_ON_REGISTRATION, ChannelOption.SO_SNDBUF });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T getOption(ChannelOption<T> option) {
/*  55 */     if (option == ChannelOption.DATAGRAM_CHANNEL_ACTIVE_ON_REGISTRATION) {
/*  56 */       return (T)Boolean.valueOf(this.activeOnOpen);
/*     */     }
/*  58 */     if (option == ChannelOption.SO_SNDBUF) {
/*  59 */       return (T)Integer.valueOf(getSendBufferSize());
/*     */     }
/*  61 */     return super.getOption(option);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> boolean setOption(ChannelOption<T> option, T value) {
/*  67 */     validate(option, value);
/*     */     
/*  69 */     if (option == ChannelOption.DATAGRAM_CHANNEL_ACTIVE_ON_REGISTRATION) {
/*  70 */       setActiveOnOpen(((Boolean)value).booleanValue());
/*  71 */     } else if (option == ChannelOption.SO_SNDBUF) {
/*  72 */       setSendBufferSize(((Integer)value).intValue());
/*     */     } else {
/*  74 */       return super.setOption(option, value);
/*     */     } 
/*     */     
/*  77 */     return true;
/*     */   }
/*     */   
/*     */   private void setActiveOnOpen(boolean activeOnOpen) {
/*  81 */     if (this.channel.isRegistered()) {
/*  82 */       throw new IllegalStateException("Can only changed before channel was registered");
/*     */     }
/*  84 */     this.activeOnOpen = activeOnOpen;
/*     */   }
/*     */   
/*     */   boolean getActiveOnOpen() {
/*  88 */     return this.activeOnOpen;
/*     */   }
/*     */ 
/*     */   
/*     */   public EpollDomainDatagramChannelConfig setAllocator(ByteBufAllocator allocator) {
/*  93 */     super.setAllocator(allocator);
/*  94 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public EpollDomainDatagramChannelConfig setAutoClose(boolean autoClose) {
/*  99 */     super.setAutoClose(autoClose);
/* 100 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public EpollDomainDatagramChannelConfig setAutoRead(boolean autoRead) {
/* 105 */     super.setAutoRead(autoRead);
/* 106 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public EpollDomainDatagramChannelConfig setConnectTimeoutMillis(int connectTimeoutMillis) {
/* 111 */     super.setConnectTimeoutMillis(connectTimeoutMillis);
/* 112 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public EpollDomainDatagramChannelConfig setEpollMode(EpollMode mode) {
/* 117 */     super.setEpollMode(mode);
/* 118 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public EpollDomainDatagramChannelConfig setMaxMessagesPerRead(int maxMessagesPerRead) {
/* 124 */     super.setMaxMessagesPerRead(maxMessagesPerRead);
/* 125 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public EpollDomainDatagramChannelConfig setMaxMessagesPerWrite(int maxMessagesPerWrite) {
/* 130 */     super.setMaxMessagesPerWrite(maxMessagesPerWrite);
/* 131 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public EpollDomainDatagramChannelConfig setMessageSizeEstimator(MessageSizeEstimator estimator) {
/* 136 */     super.setMessageSizeEstimator(estimator);
/* 137 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public EpollDomainDatagramChannelConfig setRecvByteBufAllocator(RecvByteBufAllocator allocator) {
/* 142 */     super.setRecvByteBufAllocator(allocator);
/* 143 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public EpollDomainDatagramChannelConfig setSendBufferSize(int sendBufferSize) {
/*     */     try {
/* 149 */       ((EpollDomainDatagramChannel)this.channel).socket.setSendBufferSize(sendBufferSize);
/* 150 */       return this;
/* 151 */     } catch (IOException e) {
/* 152 */       throw new ChannelException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int getSendBufferSize() {
/*     */     try {
/* 159 */       return ((EpollDomainDatagramChannel)this.channel).socket.getSendBufferSize();
/* 160 */     } catch (IOException e) {
/* 161 */       throw new ChannelException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public EpollDomainDatagramChannelConfig setWriteBufferWaterMark(WriteBufferWaterMark writeBufferWaterMark) {
/* 167 */     super.setWriteBufferWaterMark(writeBufferWaterMark);
/* 168 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public EpollDomainDatagramChannelConfig setWriteSpinCount(int writeSpinCount) {
/* 173 */     super.setWriteSpinCount(writeSpinCount);
/* 174 */     return this;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-transport-classes-epoll-4.1.93.Final.jar!\io\netty\channel\epoll\EpollDomainDatagramChannelConfig.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */