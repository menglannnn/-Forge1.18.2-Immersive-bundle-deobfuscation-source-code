/*     */ package io.netty.channel.epoll;
/*     */ 
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import io.netty.buffer.ByteBufAllocator;
/*     */ import io.netty.buffer.Unpooled;
/*     */ import io.netty.channel.AbstractChannel;
/*     */ import io.netty.channel.AddressedEnvelope;
/*     */ import io.netty.channel.Channel;
/*     */ import io.netty.channel.ChannelConfig;
/*     */ import io.netty.channel.ChannelFuture;
/*     */ import io.netty.channel.ChannelMetadata;
/*     */ import io.netty.channel.ChannelOutboundBuffer;
/*     */ import io.netty.channel.ChannelPipeline;
/*     */ import io.netty.channel.ChannelPromise;
/*     */ import io.netty.channel.DefaultAddressedEnvelope;
/*     */ import io.netty.channel.socket.DatagramChannel;
/*     */ import io.netty.channel.socket.DatagramChannelConfig;
/*     */ import io.netty.channel.socket.DatagramPacket;
/*     */ import io.netty.channel.socket.InternetProtocolFamily;
/*     */ import io.netty.channel.unix.Errors;
/*     */ import io.netty.channel.unix.SegmentedDatagramPacket;
/*     */ import io.netty.channel.unix.UnixChannelUtil;
/*     */ import io.netty.util.ReferenceCountUtil;
/*     */ import io.netty.util.UncheckedBooleanSupplier;
/*     */ import io.netty.util.internal.ObjectUtil;
/*     */ import io.netty.util.internal.RecyclableArrayList;
/*     */ import io.netty.util.internal.StringUtil;
/*     */ import java.io.IOException;
/*     */ import java.net.InetAddress;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.NetworkInterface;
/*     */ import java.net.PortUnreachableException;
/*     */ import java.net.SocketAddress;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.channels.UnresolvedAddressException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class EpollDatagramChannel
/*     */   extends AbstractEpollChannel
/*     */   implements DatagramChannel
/*     */ {
/*  57 */   private static final ChannelMetadata METADATA = new ChannelMetadata(true);
/*  58 */   private static final String EXPECTED_TYPES = " (expected: " + 
/*  59 */     StringUtil.simpleClassName(DatagramPacket.class) + ", " + 
/*  60 */     StringUtil.simpleClassName(AddressedEnvelope.class) + '<' + 
/*  61 */     StringUtil.simpleClassName(ByteBuf.class) + ", " + 
/*  62 */     StringUtil.simpleClassName(InetSocketAddress.class) + ">, " + 
/*  63 */     StringUtil.simpleClassName(ByteBuf.class) + ')';
/*     */ 
/*     */   
/*     */   private final EpollDatagramChannelConfig config;
/*     */ 
/*     */   
/*     */   private volatile boolean connected;
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isSegmentedDatagramPacketSupported() {
/*  74 */     return (Epoll.isAvailable() && Native.IS_SUPPORTING_SENDMMSG && Native.IS_SUPPORTING_UDP_SEGMENT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EpollDatagramChannel() {
/*  84 */     this((InternetProtocolFamily)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EpollDatagramChannel(InternetProtocolFamily family) {
/*  92 */     this(LinuxSocket.newSocketDgram(family), false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EpollDatagramChannel(int fd) {
/* 100 */     this(new LinuxSocket(fd), true);
/*     */   }
/*     */   
/*     */   private EpollDatagramChannel(LinuxSocket fd, boolean active) {
/* 104 */     super((Channel)null, fd, active);
/* 105 */     this.config = new EpollDatagramChannelConfig(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public InetSocketAddress remoteAddress() {
/* 110 */     return (InetSocketAddress)super.remoteAddress();
/*     */   }
/*     */ 
/*     */   
/*     */   public InetSocketAddress localAddress() {
/* 115 */     return (InetSocketAddress)super.localAddress();
/*     */   }
/*     */ 
/*     */   
/*     */   public ChannelMetadata metadata() {
/* 120 */     return METADATA;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isActive() {
/* 125 */     return (this.socket.isOpen() && ((this.config.getActiveOnOpen() && isRegistered()) || this.active));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isConnected() {
/* 130 */     return this.connected;
/*     */   }
/*     */ 
/*     */   
/*     */   public ChannelFuture joinGroup(InetAddress multicastAddress) {
/* 135 */     return joinGroup(multicastAddress, newPromise());
/*     */   }
/*     */ 
/*     */   
/*     */   public ChannelFuture joinGroup(InetAddress multicastAddress, ChannelPromise promise) {
/*     */     try {
/* 141 */       NetworkInterface iface = config().getNetworkInterface();
/* 142 */       if (iface == null) {
/* 143 */         iface = NetworkInterface.getByInetAddress(localAddress().getAddress());
/*     */       }
/* 145 */       return joinGroup(multicastAddress, iface, (InetAddress)null, promise);
/* 146 */     } catch (IOException e) {
/* 147 */       promise.setFailure(e);
/*     */       
/* 149 */       return (ChannelFuture)promise;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public ChannelFuture joinGroup(InetSocketAddress multicastAddress, NetworkInterface networkInterface) {
/* 155 */     return joinGroup(multicastAddress, networkInterface, newPromise());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ChannelFuture joinGroup(InetSocketAddress multicastAddress, NetworkInterface networkInterface, ChannelPromise promise) {
/* 162 */     return joinGroup(multicastAddress.getAddress(), networkInterface, (InetAddress)null, promise);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ChannelFuture joinGroup(InetAddress multicastAddress, NetworkInterface networkInterface, InetAddress source) {
/* 168 */     return joinGroup(multicastAddress, networkInterface, source, newPromise());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ChannelFuture joinGroup(final InetAddress multicastAddress, final NetworkInterface networkInterface, final InetAddress source, final ChannelPromise promise) {
/* 176 */     ObjectUtil.checkNotNull(multicastAddress, "multicastAddress");
/* 177 */     ObjectUtil.checkNotNull(networkInterface, "networkInterface");
/*     */     
/* 179 */     if (eventLoop().inEventLoop()) {
/* 180 */       joinGroup0(multicastAddress, networkInterface, source, promise);
/*     */     } else {
/* 182 */       eventLoop().execute(new Runnable()
/*     */           {
/*     */             public void run() {
/* 185 */               EpollDatagramChannel.this.joinGroup0(multicastAddress, networkInterface, source, promise);
/*     */             }
/*     */           });
/*     */     } 
/* 189 */     return (ChannelFuture)promise;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void joinGroup0(InetAddress multicastAddress, NetworkInterface networkInterface, InetAddress source, ChannelPromise promise) {
/* 195 */     assert eventLoop().inEventLoop();
/*     */     
/*     */     try {
/* 198 */       this.socket.joinGroup(multicastAddress, networkInterface, source);
/* 199 */       promise.setSuccess();
/* 200 */     } catch (IOException e) {
/* 201 */       promise.setFailure(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public ChannelFuture leaveGroup(InetAddress multicastAddress) {
/* 207 */     return leaveGroup(multicastAddress, newPromise());
/*     */   }
/*     */ 
/*     */   
/*     */   public ChannelFuture leaveGroup(InetAddress multicastAddress, ChannelPromise promise) {
/*     */     try {
/* 213 */       return leaveGroup(multicastAddress, 
/* 214 */           NetworkInterface.getByInetAddress(localAddress().getAddress()), (InetAddress)null, promise);
/* 215 */     } catch (IOException e) {
/* 216 */       promise.setFailure(e);
/*     */       
/* 218 */       return (ChannelFuture)promise;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public ChannelFuture leaveGroup(InetSocketAddress multicastAddress, NetworkInterface networkInterface) {
/* 224 */     return leaveGroup(multicastAddress, networkInterface, newPromise());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ChannelFuture leaveGroup(InetSocketAddress multicastAddress, NetworkInterface networkInterface, ChannelPromise promise) {
/* 231 */     return leaveGroup(multicastAddress.getAddress(), networkInterface, (InetAddress)null, promise);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ChannelFuture leaveGroup(InetAddress multicastAddress, NetworkInterface networkInterface, InetAddress source) {
/* 237 */     return leaveGroup(multicastAddress, networkInterface, source, newPromise());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ChannelFuture leaveGroup(final InetAddress multicastAddress, final NetworkInterface networkInterface, final InetAddress source, final ChannelPromise promise) {
/* 244 */     ObjectUtil.checkNotNull(multicastAddress, "multicastAddress");
/* 245 */     ObjectUtil.checkNotNull(networkInterface, "networkInterface");
/*     */     
/* 247 */     if (eventLoop().inEventLoop()) {
/* 248 */       leaveGroup0(multicastAddress, networkInterface, source, promise);
/*     */     } else {
/* 250 */       eventLoop().execute(new Runnable()
/*     */           {
/*     */             public void run() {
/* 253 */               EpollDatagramChannel.this.leaveGroup0(multicastAddress, networkInterface, source, promise);
/*     */             }
/*     */           });
/*     */     } 
/* 257 */     return (ChannelFuture)promise;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void leaveGroup0(InetAddress multicastAddress, NetworkInterface networkInterface, InetAddress source, ChannelPromise promise) {
/* 263 */     assert eventLoop().inEventLoop();
/*     */     
/*     */     try {
/* 266 */       this.socket.leaveGroup(multicastAddress, networkInterface, source);
/* 267 */       promise.setSuccess();
/* 268 */     } catch (IOException e) {
/* 269 */       promise.setFailure(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ChannelFuture block(InetAddress multicastAddress, NetworkInterface networkInterface, InetAddress sourceToBlock) {
/* 277 */     return block(multicastAddress, networkInterface, sourceToBlock, newPromise());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ChannelFuture block(InetAddress multicastAddress, NetworkInterface networkInterface, InetAddress sourceToBlock, ChannelPromise promise) {
/* 284 */     ObjectUtil.checkNotNull(multicastAddress, "multicastAddress");
/* 285 */     ObjectUtil.checkNotNull(sourceToBlock, "sourceToBlock");
/* 286 */     ObjectUtil.checkNotNull(networkInterface, "networkInterface");
/*     */     
/* 288 */     promise.setFailure(new UnsupportedOperationException("Multicast block not supported"));
/* 289 */     return (ChannelFuture)promise;
/*     */   }
/*     */ 
/*     */   
/*     */   public ChannelFuture block(InetAddress multicastAddress, InetAddress sourceToBlock) {
/* 294 */     return block(multicastAddress, sourceToBlock, newPromise());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ChannelFuture block(InetAddress multicastAddress, InetAddress sourceToBlock, ChannelPromise promise) {
/*     */     try {
/* 301 */       return block(multicastAddress, 
/*     */           
/* 303 */           NetworkInterface.getByInetAddress(localAddress().getAddress()), sourceToBlock, promise);
/*     */     }
/* 305 */     catch (Throwable e) {
/* 306 */       promise.setFailure(e);
/*     */       
/* 308 */       return (ChannelFuture)promise;
/*     */     } 
/*     */   }
/*     */   
/*     */   protected AbstractEpollChannel.AbstractEpollUnsafe newUnsafe() {
/* 313 */     return new EpollDatagramChannelUnsafe();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void doBind(SocketAddress localAddress) throws Exception {
/* 318 */     if (localAddress instanceof InetSocketAddress) {
/* 319 */       InetSocketAddress socketAddress = (InetSocketAddress)localAddress;
/* 320 */       if (socketAddress.getAddress().isAnyLocalAddress() && socketAddress
/* 321 */         .getAddress() instanceof java.net.Inet4Address && 
/* 322 */         this.socket.family() == InternetProtocolFamily.IPv6) {
/* 323 */         localAddress = new InetSocketAddress(LinuxSocket.INET6_ANY, socketAddress.getPort());
/*     */       }
/*     */     } 
/*     */     
/* 327 */     super.doBind(localAddress);
/* 328 */     this.active = true;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void doWrite(ChannelOutboundBuffer in) throws Exception {
/* 333 */     int maxMessagesPerWrite = maxMessagesPerWrite();
/* 334 */     while (maxMessagesPerWrite > 0) {
/* 335 */       Object msg = in.current();
/* 336 */       if (msg == null) {
/*     */         break;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 343 */         if ((Native.IS_SUPPORTING_SENDMMSG && in.size() > 1) || in
/*     */           
/* 345 */           .current() instanceof SegmentedDatagramPacket) {
/* 346 */           NativeDatagramPacketArray array = cleanDatagramPacketArray();
/* 347 */           array.add(in, isConnected(), maxMessagesPerWrite);
/* 348 */           int cnt = array.count();
/*     */           
/* 350 */           if (cnt >= 1) {
/*     */             
/* 352 */             int offset = 0;
/* 353 */             NativeDatagramPacketArray.NativeDatagramPacket[] packets = array.packets();
/*     */             
/* 355 */             int send = this.socket.sendmmsg(packets, offset, cnt);
/* 356 */             if (send == 0) {
/*     */               break;
/*     */             }
/*     */             
/* 360 */             for (int j = 0; j < send; j++) {
/* 361 */               in.remove();
/*     */             }
/* 363 */             maxMessagesPerWrite -= send;
/*     */             continue;
/*     */           } 
/*     */         } 
/* 367 */         boolean done = false;
/* 368 */         for (int i = config().getWriteSpinCount(); i > 0; i--) {
/* 369 */           if (doWriteMessage(msg)) {
/* 370 */             done = true;
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/* 375 */         if (done) {
/* 376 */           in.remove();
/* 377 */           maxMessagesPerWrite--;
/*     */           continue;
/*     */         } 
/*     */         break;
/* 381 */       } catch (IOException e) {
/* 382 */         maxMessagesPerWrite--;
/*     */ 
/*     */ 
/*     */         
/* 386 */         in.remove(e);
/*     */       } 
/*     */     } 
/*     */     
/* 390 */     if (in.isEmpty()) {
/*     */       
/* 392 */       clearFlag(Native.EPOLLOUT);
/*     */     } else {
/*     */       
/* 395 */       setFlag(Native.EPOLLOUT);
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean doWriteMessage(Object msg) throws Exception {
/*     */     ByteBuf data;
/*     */     InetSocketAddress remoteAddress;
/* 402 */     if (msg instanceof AddressedEnvelope) {
/*     */       
/* 404 */       AddressedEnvelope<ByteBuf, InetSocketAddress> envelope = (AddressedEnvelope<ByteBuf, InetSocketAddress>)msg;
/*     */       
/* 406 */       data = (ByteBuf)envelope.content();
/* 407 */       remoteAddress = (InetSocketAddress)envelope.recipient();
/*     */     } else {
/* 409 */       data = (ByteBuf)msg;
/* 410 */       remoteAddress = null;
/*     */     } 
/*     */     
/* 413 */     int dataLen = data.readableBytes();
/* 414 */     if (dataLen == 0) {
/* 415 */       return true;
/*     */     }
/*     */     
/* 418 */     return (doWriteOrSendBytes(data, remoteAddress, false) > 0L);
/*     */   }
/*     */   
/*     */   private static void checkUnresolved(AddressedEnvelope<?, ?> envelope) {
/* 422 */     if (envelope.recipient() instanceof InetSocketAddress && ((InetSocketAddress)envelope
/* 423 */       .recipient()).isUnresolved()) {
/* 424 */       throw new UnresolvedAddressException();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected Object filterOutboundMessage(Object msg) {
/* 430 */     if (msg instanceof SegmentedDatagramPacket) {
/* 431 */       if (!Native.IS_SUPPORTING_UDP_SEGMENT) {
/* 432 */         throw new UnsupportedOperationException("unsupported message type: " + 
/* 433 */             StringUtil.simpleClassName(msg) + EXPECTED_TYPES);
/*     */       }
/* 435 */       SegmentedDatagramPacket packet = (SegmentedDatagramPacket)msg;
/* 436 */       checkUnresolved((AddressedEnvelope<?, ?>)packet);
/*     */       
/* 438 */       ByteBuf content = (ByteBuf)packet.content();
/* 439 */       return UnixChannelUtil.isBufferCopyNeededForWrite(content) ? packet
/* 440 */         .replace(newDirectBuffer(packet, content)) : msg;
/*     */     } 
/* 442 */     if (msg instanceof DatagramPacket) {
/* 443 */       DatagramPacket packet = (DatagramPacket)msg;
/* 444 */       checkUnresolved((AddressedEnvelope<?, ?>)packet);
/*     */       
/* 446 */       ByteBuf content = (ByteBuf)packet.content();
/* 447 */       return UnixChannelUtil.isBufferCopyNeededForWrite(content) ? new DatagramPacket(
/* 448 */           newDirectBuffer(packet, content), (InetSocketAddress)packet.recipient()) : msg;
/*     */     } 
/*     */     
/* 451 */     if (msg instanceof ByteBuf) {
/* 452 */       ByteBuf buf = (ByteBuf)msg;
/* 453 */       return UnixChannelUtil.isBufferCopyNeededForWrite(buf) ? newDirectBuffer(buf) : buf;
/*     */     } 
/*     */     
/* 456 */     if (msg instanceof AddressedEnvelope) {
/*     */       
/* 458 */       AddressedEnvelope<Object, SocketAddress> e = (AddressedEnvelope<Object, SocketAddress>)msg;
/* 459 */       checkUnresolved(e);
/*     */       
/* 461 */       if (e.content() instanceof ByteBuf && (e
/* 462 */         .recipient() == null || e.recipient() instanceof InetSocketAddress)) {
/*     */         
/* 464 */         ByteBuf content = (ByteBuf)e.content();
/* 465 */         return UnixChannelUtil.isBufferCopyNeededForWrite(content) ? new DefaultAddressedEnvelope(
/*     */             
/* 467 */             newDirectBuffer(e, content), e.recipient()) : e;
/*     */       } 
/*     */     } 
/*     */     
/* 471 */     throw new UnsupportedOperationException("unsupported message type: " + 
/* 472 */         StringUtil.simpleClassName(msg) + EXPECTED_TYPES);
/*     */   }
/*     */ 
/*     */   
/*     */   public EpollDatagramChannelConfig config() {
/* 477 */     return this.config;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void doDisconnect() throws Exception {
/* 482 */     this.socket.disconnect();
/* 483 */     this.connected = this.active = false;
/* 484 */     resetCachedAddresses();
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean doConnect(SocketAddress remoteAddress, SocketAddress localAddress) throws Exception {
/* 489 */     if (super.doConnect(remoteAddress, localAddress)) {
/* 490 */       this.connected = true;
/* 491 */       return true;
/*     */     } 
/* 493 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void doClose() throws Exception {
/* 498 */     super.doClose();
/* 499 */     this.connected = false;
/*     */   }
/*     */   
/*     */   final class EpollDatagramChannelUnsafe
/*     */     extends AbstractEpollChannel.AbstractEpollUnsafe
/*     */   {
/*     */     void epollInReady() {
/* 506 */       assert EpollDatagramChannel.this.eventLoop().inEventLoop();
/* 507 */       EpollDatagramChannelConfig config = EpollDatagramChannel.this.config();
/* 508 */       if (EpollDatagramChannel.this.shouldBreakEpollInReady((ChannelConfig)config)) {
/* 509 */         clearEpollIn0();
/*     */         return;
/*     */       } 
/* 512 */       EpollRecvByteAllocatorHandle allocHandle = recvBufAllocHandle();
/* 513 */       allocHandle.edgeTriggered(EpollDatagramChannel.this.isFlagSet(Native.EPOLLET));
/*     */       
/* 515 */       ChannelPipeline pipeline = EpollDatagramChannel.this.pipeline();
/* 516 */       ByteBufAllocator allocator = config.getAllocator();
/* 517 */       allocHandle.reset((ChannelConfig)config);
/* 518 */       epollInBefore();
/*     */       
/* 520 */       Throwable exception = null;
/*     */       try {
/*     */         
/* 523 */         try { boolean connected = EpollDatagramChannel.this.isConnected();
/*     */           while (true)
/*     */           { boolean read;
/* 526 */             int datagramSize = EpollDatagramChannel.this.config().getMaxDatagramPayloadSize();
/*     */             
/* 528 */             ByteBuf byteBuf = allocHandle.allocate(allocator);
/*     */ 
/*     */             
/* 531 */             int numDatagram = Native.IS_SUPPORTING_RECVMMSG ? ((datagramSize == 0) ? 1 : (byteBuf.writableBytes() / datagramSize)) : 0;
/*     */             
/*     */             try {
/* 534 */               if (numDatagram <= 1) {
/* 535 */                 if (!connected || config.isUdpGro()) {
/* 536 */                   read = EpollDatagramChannel.this.recvmsg(allocHandle, EpollDatagramChannel.this.cleanDatagramPacketArray(), byteBuf);
/*     */                 } else {
/* 538 */                   read = EpollDatagramChannel.this.connectedRead(allocHandle, byteBuf, datagramSize);
/*     */                 } 
/*     */               } else {
/*     */                 
/* 542 */                 read = EpollDatagramChannel.this.scatteringRead(allocHandle, EpollDatagramChannel.this.cleanDatagramPacketArray(), byteBuf, datagramSize, numDatagram);
/*     */               }
/*     */             
/* 545 */             } catch (io.netty.channel.unix.Errors.NativeIoException e) {
/* 546 */               if (connected) {
/* 547 */                 throw EpollDatagramChannel.this.translateForConnected(e);
/*     */               }
/* 549 */               throw e;
/*     */             } 
/*     */             
/* 552 */             if (read)
/* 553 */             { this.readPending = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */               
/* 559 */               if (!allocHandle.continueReading(UncheckedBooleanSupplier.TRUE_SUPPLIER))
/* 560 */                 break;  continue; }  break; }  } catch (Throwable t)
/* 561 */         { exception = t; }
/*     */ 
/*     */         
/* 564 */         allocHandle.readComplete();
/* 565 */         pipeline.fireChannelReadComplete();
/*     */         
/* 567 */         if (exception != null) {
/* 568 */           pipeline.fireExceptionCaught(exception);
/*     */         }
/*     */       } finally {
/* 571 */         epollInFinally((ChannelConfig)config);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean connectedRead(EpollRecvByteAllocatorHandle allocHandle, ByteBuf byteBuf, int maxDatagramPacketSize) throws Exception {
/*     */     try {
/* 580 */       int localReadAmount, writable = (maxDatagramPacketSize != 0) ? Math.min(byteBuf.writableBytes(), maxDatagramPacketSize) : byteBuf.writableBytes();
/* 581 */       allocHandle.attemptedBytesRead(writable);
/*     */       
/* 583 */       int writerIndex = byteBuf.writerIndex();
/*     */       
/* 585 */       if (byteBuf.hasMemoryAddress()) {
/* 586 */         localReadAmount = this.socket.recvAddress(byteBuf.memoryAddress(), writerIndex, writerIndex + writable);
/*     */       } else {
/* 588 */         ByteBuffer buf = byteBuf.internalNioBuffer(writerIndex, writable);
/* 589 */         localReadAmount = this.socket.recv(buf, buf.position(), buf.limit());
/*     */       } 
/*     */       
/* 592 */       if (localReadAmount <= 0) {
/* 593 */         allocHandle.lastBytesRead(localReadAmount);
/*     */ 
/*     */         
/* 596 */         return false;
/*     */       } 
/* 598 */       byteBuf.writerIndex(writerIndex + localReadAmount);
/*     */       
/* 600 */       allocHandle.lastBytesRead((maxDatagramPacketSize <= 0) ? localReadAmount : writable);
/*     */ 
/*     */       
/* 603 */       DatagramPacket packet = new DatagramPacket(byteBuf, localAddress(), remoteAddress());
/* 604 */       allocHandle.incMessagesRead(1);
/*     */       
/* 606 */       pipeline().fireChannelRead(packet);
/* 607 */       byteBuf = null;
/* 608 */       return true;
/*     */     } finally {
/* 610 */       if (byteBuf != null) {
/* 611 */         byteBuf.release();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private IOException translateForConnected(Errors.NativeIoException e) {
/* 618 */     if (e.expectedErr() == Errors.ERROR_ECONNREFUSED_NEGATIVE) {
/* 619 */       PortUnreachableException error = new PortUnreachableException(e.getMessage());
/* 620 */       error.initCause((Throwable)e);
/* 621 */       return error;
/*     */     } 
/* 623 */     return (IOException)e;
/*     */   }
/*     */ 
/*     */   
/*     */   private static void addDatagramPacketToOut(DatagramPacket packet, RecyclableArrayList out) {
/* 628 */     if (packet instanceof SegmentedDatagramPacket) {
/* 629 */       SegmentedDatagramPacket segmentedDatagramPacket = (SegmentedDatagramPacket)packet;
/*     */       
/* 631 */       ByteBuf content = (ByteBuf)segmentedDatagramPacket.content();
/* 632 */       InetSocketAddress recipient = (InetSocketAddress)segmentedDatagramPacket.recipient();
/* 633 */       InetSocketAddress sender = (InetSocketAddress)segmentedDatagramPacket.sender();
/* 634 */       int segmentSize = segmentedDatagramPacket.segmentSize();
/*     */       do {
/* 636 */         out.add(new DatagramPacket(content.readRetainedSlice(Math.min(content.readableBytes(), segmentSize)), recipient, sender));
/*     */       }
/* 638 */       while (content.isReadable());
/*     */       
/* 640 */       segmentedDatagramPacket.release();
/*     */     } else {
/* 642 */       out.add(packet);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void releaseAndRecycle(ByteBuf byteBuf, RecyclableArrayList packetList) {
/* 647 */     if (byteBuf != null) {
/* 648 */       byteBuf.release();
/*     */     }
/* 650 */     if (packetList != null) {
/* 651 */       for (int i = 0; i < packetList.size(); i++) {
/* 652 */         ReferenceCountUtil.release(packetList.get(i));
/*     */       }
/* 654 */       packetList.recycle();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static void processPacket(ChannelPipeline pipeline, EpollRecvByteAllocatorHandle handle, int bytesRead, DatagramPacket packet) {
/* 660 */     handle.lastBytesRead(Math.max(1, bytesRead));
/* 661 */     handle.incMessagesRead(1);
/* 662 */     pipeline.fireChannelRead(packet);
/*     */   }
/*     */ 
/*     */   
/*     */   private static void processPacketList(ChannelPipeline pipeline, EpollRecvByteAllocatorHandle handle, int bytesRead, RecyclableArrayList packetList) {
/* 667 */     int messagesRead = packetList.size();
/* 668 */     handle.lastBytesRead(Math.max(1, bytesRead));
/* 669 */     handle.incMessagesRead(messagesRead);
/* 670 */     for (int i = 0; i < messagesRead; i++) {
/* 671 */       pipeline.fireChannelRead(packetList.set(i, Unpooled.EMPTY_BUFFER));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean recvmsg(EpollRecvByteAllocatorHandle allocHandle, NativeDatagramPacketArray array, ByteBuf byteBuf) throws IOException {
/* 677 */     RecyclableArrayList datagramPackets = null;
/*     */     try {
/* 679 */       int writable = byteBuf.writableBytes();
/*     */       
/* 681 */       boolean added = array.addWritable(byteBuf, byteBuf.writerIndex(), writable);
/* 682 */       assert added;
/*     */       
/* 684 */       allocHandle.attemptedBytesRead(writable);
/*     */       
/* 686 */       NativeDatagramPacketArray.NativeDatagramPacket msg = array.packets()[0];
/*     */       
/* 688 */       int bytesReceived = this.socket.recvmsg(msg);
/* 689 */       if (!msg.hasSender()) {
/* 690 */         allocHandle.lastBytesRead(-1);
/* 691 */         return false;
/*     */       } 
/* 693 */       byteBuf.writerIndex(bytesReceived);
/* 694 */       InetSocketAddress local = localAddress();
/* 695 */       DatagramPacket packet = msg.newDatagramPacket(byteBuf, local);
/* 696 */       if (!(packet instanceof SegmentedDatagramPacket)) {
/* 697 */         processPacket(pipeline(), allocHandle, bytesReceived, packet);
/*     */       
/*     */       }
/*     */       else {
/*     */         
/* 702 */         datagramPackets = RecyclableArrayList.newInstance();
/* 703 */         addDatagramPacketToOut(packet, datagramPackets);
/*     */         
/* 705 */         processPacketList(pipeline(), allocHandle, bytesReceived, datagramPackets);
/* 706 */         datagramPackets.recycle();
/* 707 */         datagramPackets = null;
/*     */       } 
/*     */       
/* 710 */       return true;
/*     */     } finally {
/* 712 */       releaseAndRecycle(byteBuf, datagramPackets);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean scatteringRead(EpollRecvByteAllocatorHandle allocHandle, NativeDatagramPacketArray array, ByteBuf byteBuf, int datagramSize, int numDatagram) throws IOException {
/* 718 */     RecyclableArrayList datagramPackets = null;
/*     */     try {
/* 720 */       int offset = byteBuf.writerIndex();
/* 721 */       for (int i = 0; i < numDatagram && 
/* 722 */         array.addWritable(byteBuf, offset, datagramSize); ) {
/*     */         i++;
/*     */         
/*     */         offset += datagramSize;
/*     */       } 
/* 727 */       allocHandle.attemptedBytesRead(offset - byteBuf.writerIndex());
/*     */       
/* 729 */       NativeDatagramPacketArray.NativeDatagramPacket[] packets = array.packets();
/*     */       
/* 731 */       int received = this.socket.recvmmsg(packets, 0, array.count());
/* 732 */       if (received == 0) {
/* 733 */         allocHandle.lastBytesRead(-1);
/* 734 */         return false;
/*     */       } 
/*     */       
/* 737 */       InetSocketAddress local = localAddress();
/*     */ 
/*     */       
/* 740 */       int bytesReceived = received * datagramSize;
/* 741 */       byteBuf.writerIndex(byteBuf.writerIndex() + bytesReceived);
/*     */       
/* 743 */       if (received == 1) {
/*     */         
/* 745 */         DatagramPacket packet = packets[0].newDatagramPacket(byteBuf, local);
/* 746 */         if (!(packet instanceof SegmentedDatagramPacket)) {
/* 747 */           processPacket(pipeline(), allocHandle, datagramSize, packet);
/* 748 */           return true;
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 754 */       datagramPackets = RecyclableArrayList.newInstance(); int j;
/* 755 */       for (j = 0; j < received; j++) {
/* 756 */         DatagramPacket packet = packets[j].newDatagramPacket(byteBuf, local);
/*     */ 
/*     */ 
/*     */         
/* 760 */         byteBuf.skipBytes(datagramSize);
/* 761 */         addDatagramPacketToOut(packet, datagramPackets);
/*     */       } 
/*     */       
/* 764 */       byteBuf.release();
/* 765 */       byteBuf = null;
/*     */       
/* 767 */       processPacketList(pipeline(), allocHandle, bytesReceived, datagramPackets);
/* 768 */       datagramPackets.recycle();
/* 769 */       datagramPackets = null;
/* 770 */       j = 1; return j;
/*     */     } finally {
/* 772 */       releaseAndRecycle(byteBuf, datagramPackets);
/*     */     } 
/*     */   }
/*     */   
/*     */   private NativeDatagramPacketArray cleanDatagramPacketArray() {
/* 777 */     return ((EpollEventLoop)eventLoop()).cleanDatagramPacketArray();
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-transport-classes-epoll-4.1.93.Final.jar!\io\netty\channel\epoll\EpollDatagramChannel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */