/*     */ package io.netty.channel.epoll;
/*     */ 
/*     */ import io.netty.channel.unix.FileDescriptor;
/*     */ import io.netty.util.internal.SystemPropertyUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Epoll
/*     */ {
/*     */   private static final Throwable UNAVAILABILITY_CAUSE;
/*     */   
/*     */   static {
/*  31 */     Throwable cause = null;
/*     */     
/*  33 */     if (SystemPropertyUtil.getBoolean("io.netty.transport.noNative", false)) {
/*  34 */       cause = new UnsupportedOperationException("Native transport was explicit disabled with -Dio.netty.transport.noNative=true");
/*     */     } else {
/*     */       
/*  37 */       FileDescriptor epollFd = null;
/*  38 */       FileDescriptor eventFd = null;
/*     */       try {
/*  40 */         epollFd = Native.newEpollCreate();
/*  41 */         eventFd = Native.newEventFd();
/*  42 */       } catch (Throwable t) {
/*  43 */         cause = t;
/*     */       } finally {
/*  45 */         if (epollFd != null) {
/*     */           try {
/*  47 */             epollFd.close();
/*  48 */           } catch (Exception exception) {}
/*     */         }
/*     */ 
/*     */         
/*  52 */         if (eventFd != null) {
/*     */           try {
/*  54 */             eventFd.close();
/*  55 */           } catch (Exception exception) {}
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*  62 */     UNAVAILABILITY_CAUSE = cause;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isAvailable() {
/*  70 */     return (UNAVAILABILITY_CAUSE == null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void ensureAvailability() {
/*  80 */     if (UNAVAILABILITY_CAUSE != null) {
/*  81 */       throw (Error)(new UnsatisfiedLinkError("failed to load the required native library"))
/*  82 */         .initCause(UNAVAILABILITY_CAUSE);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Throwable unavailabilityCause() {
/*  93 */     return UNAVAILABILITY_CAUSE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isTcpFastOpenClientSideAvailable() {
/* 103 */     return (isAvailable() && Native.IS_SUPPORTING_TCP_FASTOPEN_CLIENT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isTcpFastOpenServerSideAvailable() {
/* 113 */     return (isAvailable() && Native.IS_SUPPORTING_TCP_FASTOPEN_SERVER);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-transport-classes-epoll-4.1.93.Final.jar!\io\netty\channel\epoll\Epoll.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */