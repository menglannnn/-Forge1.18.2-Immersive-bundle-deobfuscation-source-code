/*     */ package io.netty.channel.epoll;
/*     */ 
/*     */ import io.netty.channel.DefaultFileRegion;
/*     */ import io.netty.channel.unix.Errors;
/*     */ import io.netty.channel.unix.FileDescriptor;
/*     */ import io.netty.channel.unix.PeerCredentials;
/*     */ import io.netty.channel.unix.Socket;
/*     */ import io.netty.channel.unix.Unix;
/*     */ import io.netty.util.internal.ClassInitializerUtil;
/*     */ import io.netty.util.internal.NativeLibraryLoader;
/*     */ import io.netty.util.internal.PlatformDependent;
/*     */ import io.netty.util.internal.ThrowableUtil;
/*     */ import io.netty.util.internal.logging.InternalLogger;
/*     */ import io.netty.util.internal.logging.InternalLoggerFactory;
/*     */ import java.io.FileDescriptor;
/*     */ import java.io.IOException;
/*     */ import java.nio.channels.FileChannel;
/*     */ import java.nio.channels.Selector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Native
/*     */ {
/*  53 */   private static final InternalLogger logger = InternalLoggerFactory.getInstance(Native.class);
/*     */   
/*     */   static {
/*  56 */     Selector selector = null;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/*  62 */       selector = Selector.open();
/*  63 */     } catch (IOException iOException) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  72 */     ClassInitializerUtil.tryLoadClasses(Native.class, new Class[] { PeerCredentials.class, DefaultFileRegion.class, FileChannel.class, FileDescriptor.class, NativeDatagramPacketArray.NativeDatagramPacket.class });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/*  82 */       offsetofEpollData();
/*  83 */     } catch (UnsatisfiedLinkError ignore) {
/*     */       
/*  85 */       loadNativeLibrary();
/*     */     } finally {
/*     */       try {
/*  88 */         if (selector != null) {
/*  89 */           selector.close();
/*     */         }
/*  91 */       } catch (IOException iOException) {}
/*     */     } 
/*     */ 
/*     */     
/*  95 */     Unix.registerInternal(new Runnable()
/*     */         {
/*     */           public void run() {
/*  98 */             Native.registerUnix();
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 106 */   public static final int EPOLLIN = NativeStaticallyReferencedJniMethods.epollin();
/* 107 */   public static final int EPOLLOUT = NativeStaticallyReferencedJniMethods.epollout();
/* 108 */   public static final int EPOLLRDHUP = NativeStaticallyReferencedJniMethods.epollrdhup();
/* 109 */   public static final int EPOLLET = NativeStaticallyReferencedJniMethods.epollet();
/* 110 */   public static final int EPOLLERR = NativeStaticallyReferencedJniMethods.epollerr();
/*     */   
/* 112 */   public static final boolean IS_SUPPORTING_SENDMMSG = NativeStaticallyReferencedJniMethods.isSupportingSendmmsg();
/* 113 */   static final boolean IS_SUPPORTING_RECVMMSG = NativeStaticallyReferencedJniMethods.isSupportingRecvmmsg();
/* 114 */   static final boolean IS_SUPPORTING_UDP_SEGMENT = isSupportingUdpSegment();
/*     */   private static final int TFO_ENABLED_CLIENT_MASK = 1;
/*     */   private static final int TFO_ENABLED_SERVER_MASK = 2;
/* 117 */   private static final int TCP_FASTOPEN_MODE = NativeStaticallyReferencedJniMethods.tcpFastopenMode();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 122 */   static final boolean IS_SUPPORTING_TCP_FASTOPEN_CLIENT = ((TCP_FASTOPEN_MODE & 0x1) == 1);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 128 */   static final boolean IS_SUPPORTING_TCP_FASTOPEN_SERVER = ((TCP_FASTOPEN_MODE & 0x2) == 2);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/* 135 */   public static final boolean IS_SUPPORTING_TCP_FASTOPEN = (IS_SUPPORTING_TCP_FASTOPEN_CLIENT || IS_SUPPORTING_TCP_FASTOPEN_SERVER);
/*     */   
/* 137 */   public static final int TCP_MD5SIG_MAXKEYLEN = NativeStaticallyReferencedJniMethods.tcpMd5SigMaxKeyLen();
/* 138 */   public static final String KERNEL_VERSION = NativeStaticallyReferencedJniMethods.kernelVersion();
/*     */   
/*     */   public static FileDescriptor newEventFd() {
/* 141 */     return new FileDescriptor(eventFd());
/*     */   }
/*     */   
/*     */   public static FileDescriptor newTimerFd() {
/* 145 */     return new FileDescriptor(timerFd());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static FileDescriptor newEpollCreate() {
/* 155 */     return new FileDescriptor(epollCreate());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static int epollWait(FileDescriptor epollFd, EpollEventArray events, FileDescriptor timerFd, int timeoutSec, int timeoutNs) throws IOException {
/* 166 */     long result = epollWait(epollFd, events, timerFd, timeoutSec, timeoutNs, -1L);
/* 167 */     return epollReady(result);
/*     */   }
/*     */ 
/*     */   
/*     */   static long epollWait(FileDescriptor epollFd, EpollEventArray events, FileDescriptor timerFd, int timeoutSec, int timeoutNs, long millisThreshold) throws IOException {
/* 172 */     if (timeoutSec == 0 && timeoutNs == 0)
/*     */     {
/*     */       
/* 175 */       return epollWait(epollFd, events, 0) << 32L;
/*     */     }
/* 177 */     if (timeoutSec == Integer.MAX_VALUE) {
/*     */       
/* 179 */       timeoutSec = 0;
/* 180 */       timeoutNs = 0;
/*     */     } 
/* 182 */     long result = epollWait0(epollFd.intValue(), events.memoryAddress(), events.length(), timerFd.intValue(), timeoutSec, timeoutNs, millisThreshold);
/*     */     
/* 184 */     int ready = epollReady(result);
/* 185 */     if (ready < 0) {
/* 186 */       throw Errors.newIOException("epoll_wait", ready);
/*     */     }
/* 188 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   static int epollReady(long result) {
/* 193 */     return (int)(result >> 32L);
/*     */   }
/*     */ 
/*     */   
/*     */   static boolean epollTimerWasUsed(long result) {
/* 198 */     return ((result & 0xFFL) != 0L);
/*     */   }
/*     */   
/*     */   static int epollWait(FileDescriptor epollFd, EpollEventArray events, boolean immediatePoll) throws IOException {
/* 202 */     return epollWait(epollFd, events, immediatePoll ? 0 : -1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static int epollWait(FileDescriptor epollFd, EpollEventArray events, int timeoutMillis) throws IOException {
/* 209 */     int ready = epollWait(epollFd.intValue(), events.memoryAddress(), events.length(), timeoutMillis);
/* 210 */     if (ready < 0) {
/* 211 */       throw Errors.newIOException("epoll_wait", ready);
/*     */     }
/* 213 */     return ready;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int epollBusyWait(FileDescriptor epollFd, EpollEventArray events) throws IOException {
/* 222 */     int ready = epollBusyWait0(epollFd.intValue(), events.memoryAddress(), events.length());
/* 223 */     if (ready < 0) {
/* 224 */       throw Errors.newIOException("epoll_wait", ready);
/*     */     }
/* 226 */     return ready;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void epollCtlAdd(int efd, int fd, int flags) throws IOException {
/* 235 */     int res = epollCtlAdd0(efd, fd, flags);
/* 236 */     if (res < 0) {
/* 237 */       throw Errors.newIOException("epoll_ctl", res);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static void epollCtlMod(int efd, int fd, int flags) throws IOException {
/* 243 */     int res = epollCtlMod0(efd, fd, flags);
/* 244 */     if (res < 0) {
/* 245 */       throw Errors.newIOException("epoll_ctl", res);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static void epollCtlDel(int efd, int fd) throws IOException {
/* 251 */     int res = epollCtlDel0(efd, fd);
/* 252 */     if (res < 0) {
/* 253 */       throw Errors.newIOException("epoll_ctl", res);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static int splice(int fd, long offIn, int fdOut, long offOut, long len) throws IOException {
/* 260 */     int res = splice0(fd, offIn, fdOut, offOut, len);
/* 261 */     if (res >= 0) {
/* 262 */       return res;
/*     */     }
/* 264 */     return Errors.ioResult("splice", res);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static int sendmmsg(int fd, NativeDatagramPacketArray.NativeDatagramPacket[] msgs, int offset, int len) throws IOException {
/* 272 */     return sendmmsg(fd, Socket.isIPv6Preferred(), msgs, offset, len);
/*     */   }
/*     */ 
/*     */   
/*     */   static int sendmmsg(int fd, boolean ipv6, NativeDatagramPacketArray.NativeDatagramPacket[] msgs, int offset, int len) throws IOException {
/* 277 */     int res = sendmmsg0(fd, ipv6, msgs, offset, len);
/* 278 */     if (res >= 0) {
/* 279 */       return res;
/*     */     }
/* 281 */     return Errors.ioResult("sendmmsg", res);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static int recvmmsg(int fd, boolean ipv6, NativeDatagramPacketArray.NativeDatagramPacket[] msgs, int offset, int len) throws IOException {
/* 289 */     int res = recvmmsg0(fd, ipv6, msgs, offset, len);
/* 290 */     if (res >= 0) {
/* 291 */       return res;
/*     */     }
/* 293 */     return Errors.ioResult("recvmmsg", res);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static int recvmsg(int fd, boolean ipv6, NativeDatagramPacketArray.NativeDatagramPacket packet) throws IOException {
/* 300 */     int res = recvmsg0(fd, ipv6, packet);
/* 301 */     if (res >= 0) {
/* 302 */       return res;
/*     */     }
/* 304 */     return Errors.ioResult("recvmsg", res);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void loadNativeLibrary() {
/* 315 */     String name = PlatformDependent.normalizedOs();
/* 316 */     if (!"linux".equals(name)) {
/* 317 */       throw new IllegalStateException("Only supported on Linux");
/*     */     }
/* 319 */     String staticLibName = "netty_transport_native_epoll";
/* 320 */     String sharedLibName = staticLibName + '_' + PlatformDependent.normalizedArch();
/* 321 */     ClassLoader cl = PlatformDependent.getClassLoader(Native.class);
/*     */     try {
/* 323 */       NativeLibraryLoader.load(sharedLibName, cl);
/* 324 */     } catch (UnsatisfiedLinkError e1) {
/*     */       try {
/* 326 */         NativeLibraryLoader.load(staticLibName, cl);
/* 327 */         logger.debug("Failed to load {}", sharedLibName, e1);
/* 328 */       } catch (UnsatisfiedLinkError e2) {
/* 329 */         ThrowableUtil.addSuppressed(e1, e2);
/* 330 */         throw e1;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private static native int registerUnix();
/*     */   
/*     */   private static native boolean isSupportingUdpSegment();
/*     */   
/*     */   private static native int eventFd();
/*     */   
/*     */   private static native int timerFd();
/*     */   
/*     */   public static native void eventFdWrite(int paramInt, long paramLong);
/*     */   
/*     */   public static native void eventFdRead(int paramInt);
/*     */   
/*     */   private static native int epollCreate();
/*     */   
/*     */   private static native long epollWait0(int paramInt1, long paramLong1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, long paramLong2);
/*     */   
/*     */   private static native int epollWait(int paramInt1, long paramLong, int paramInt2, int paramInt3);
/*     */   
/*     */   private static native int epollBusyWait0(int paramInt1, long paramLong, int paramInt2);
/*     */   
/*     */   private static native int epollCtlAdd0(int paramInt1, int paramInt2, int paramInt3);
/*     */   
/*     */   private static native int epollCtlMod0(int paramInt1, int paramInt2, int paramInt3);
/*     */   
/*     */   private static native int epollCtlDel0(int paramInt1, int paramInt2);
/*     */   
/*     */   private static native int splice0(int paramInt1, long paramLong1, int paramInt2, long paramLong2, long paramLong3);
/*     */   
/*     */   private static native int sendmmsg0(int paramInt1, boolean paramBoolean, NativeDatagramPacketArray.NativeDatagramPacket[] paramArrayOfNativeDatagramPacket, int paramInt2, int paramInt3);
/*     */   
/*     */   private static native int recvmmsg0(int paramInt1, boolean paramBoolean, NativeDatagramPacketArray.NativeDatagramPacket[] paramArrayOfNativeDatagramPacket, int paramInt2, int paramInt3);
/*     */   
/*     */   private static native int recvmsg0(int paramInt, boolean paramBoolean, NativeDatagramPacketArray.NativeDatagramPacket paramNativeDatagramPacket);
/*     */   
/*     */   public static native int sizeofEpollEvent();
/*     */   
/*     */   public static native int offsetofEpollData();
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-transport-classes-epoll-4.1.93.Final.jar!\io\netty\channel\epoll\Native.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */