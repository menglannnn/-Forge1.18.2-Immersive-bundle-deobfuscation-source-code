module com.fasterxml.jackson.annotation {
  requires java.base;
  
  exports com.fasterxml.jackson.annotation;
  
  opens com.fasterxml.jackson.annotation;
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-annotations-2.12.7.jar!\module-info.class
 * Java compiler version: 9 (53.0)
 * JD-Core Version:       1.1.3
 */