/*     */ package org.checkerframework.checker.i18nformatter.qual;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Date;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import java.util.StringJoiner;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum I18nConversionCategory
/*     */ {
/*  36 */   UNUSED(null, null),
/*     */ 
/*     */   
/*  39 */   GENERAL(null, null),
/*     */ 
/*     */   
/*  42 */   DATE(new Class[] { Date.class, Number.class }, new String[] { "date", "time"
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     }),
/*  53 */   NUMBER(new Class[] { Number.class }, new String[] { "number", "choice" });
/*     */   
/*     */   public final Class<?>[] types;
/*     */   
/*     */   public final String[] strings;
/*     */   
/*     */   static I18nConversionCategory[] namedCategories;
/*     */   
/*     */   I18nConversionCategory(Class<?>[] types, String[] strings) {
/*  62 */     this.types = types;
/*  63 */     this.strings = strings;
/*     */   }
/*     */   
/*     */   static {
/*  67 */     namedCategories = new I18nConversionCategory[] { DATE, NUMBER };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static I18nConversionCategory stringToI18nConversionCategory(String string) {
/*  81 */     string = string.toLowerCase();
/*  82 */     for (I18nConversionCategory v : namedCategories) {
/*  83 */       for (String s : v.strings) {
/*  84 */         if (s.equals(string)) {
/*  85 */           return v;
/*     */         }
/*     */       } 
/*     */     } 
/*  89 */     throw new IllegalArgumentException("Invalid format type " + string);
/*     */   }
/*     */   
/*     */   private static <E> Set<E> arrayToSet(E[] a) {
/*  93 */     return new HashSet<>(Arrays.asList(a));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isSubsetOf(I18nConversionCategory a, I18nConversionCategory b) {
/* 102 */     return (intersect(a, b) == a);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static I18nConversionCategory intersect(I18nConversionCategory a, I18nConversionCategory b) {
/* 118 */     if (a == UNUSED) {
/* 119 */       return b;
/*     */     }
/* 121 */     if (b == UNUSED) {
/* 122 */       return a;
/*     */     }
/* 124 */     if (a == GENERAL) {
/* 125 */       return b;
/*     */     }
/* 127 */     if (b == GENERAL) {
/* 128 */       return a;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 134 */     Set<Class<?>> as = arrayToSet(a.types);
/*     */ 
/*     */ 
/*     */     
/* 138 */     Set<Class<?>> bs = arrayToSet(b.types);
/* 139 */     as.retainAll(bs);
/* 140 */     for (I18nConversionCategory v : new I18nConversionCategory[] { DATE, NUMBER }) {
/*     */ 
/*     */ 
/*     */       
/* 144 */       Set<Class<?>> vs = arrayToSet(v.types);
/* 145 */       if (vs.equals(as)) {
/* 146 */         return v;
/*     */       }
/*     */     } 
/* 149 */     throw new RuntimeException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static I18nConversionCategory union(I18nConversionCategory a, I18nConversionCategory b) {
/* 160 */     if (a == UNUSED || b == UNUSED) {
/* 161 */       return UNUSED;
/*     */     }
/* 163 */     if (a == GENERAL || b == GENERAL) {
/* 164 */       return GENERAL;
/*     */     }
/* 166 */     if (a == DATE || b == DATE) {
/* 167 */       return DATE;
/*     */     }
/* 169 */     return NUMBER;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 175 */     StringBuilder sb = new StringBuilder(name());
/* 176 */     if (this.types == null) {
/* 177 */       sb.append(" conversion category (all types)");
/*     */     } else {
/* 179 */       StringJoiner sj = new StringJoiner(", ", " conversion category (one of: ", ")");
/* 180 */       for (Class<?> cls : this.types) {
/* 181 */         sj.add(cls.getCanonicalName());
/*     */       }
/* 183 */       sb.append(sj);
/*     */     } 
/* 185 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\checker-qual-3.8.0.jar!\org\checkerframework\checker\i18nformatter\qual\I18nConversionCategory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */