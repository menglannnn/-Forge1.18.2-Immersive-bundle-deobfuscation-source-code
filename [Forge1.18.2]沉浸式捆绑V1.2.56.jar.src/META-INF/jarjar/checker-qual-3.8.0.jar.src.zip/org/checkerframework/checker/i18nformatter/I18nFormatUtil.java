/*     */ package org.checkerframework.checker.i18nformatter;
/*     */ 
/*     */ import java.text.ChoiceFormat;
/*     */ import java.text.DecimalFormat;
/*     */ import java.text.DecimalFormatSymbols;
/*     */ import java.text.MessageFormat;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.IllegalFormatException;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import org.checkerframework.checker.i18nformatter.qual.I18nChecksFormat;
/*     */ import org.checkerframework.checker.i18nformatter.qual.I18nConversionCategory;
/*     */ import org.checkerframework.checker.i18nformatter.qual.I18nValidFormat;
/*     */ import org.checkerframework.checker.nullness.qual.EnsuresNonNull;
/*     */ import org.checkerframework.checker.nullness.qual.RequiresNonNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class I18nFormatUtil
/*     */ {
/*     */   public static void tryFormatSatisfiability(String format) throws IllegalFormatException {
/*  41 */     MessageFormat.format(format, (Object[])null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static I18nConversionCategory[] formatParameterCategories(String format) throws IllegalFormatException {
/*  52 */     tryFormatSatisfiability(format);
/*  53 */     I18nConversion[] cs = MessageFormatParser.parse(format);
/*     */     
/*  55 */     int maxIndex = -1;
/*  56 */     Map<Integer, I18nConversionCategory> conv = new HashMap<>();
/*     */     
/*  58 */     for (I18nConversion c : cs) {
/*  59 */       int index = c.index;
/*  60 */       Integer indexKey = Integer.valueOf(index);
/*  61 */       conv.put(indexKey, 
/*     */           
/*  63 */           I18nConversionCategory.intersect(c.category, 
/*     */             
/*  65 */             conv.containsKey(indexKey) ? 
/*  66 */             conv.get(indexKey) : 
/*  67 */             I18nConversionCategory.UNUSED));
/*  68 */       maxIndex = Math.max(maxIndex, index);
/*     */     } 
/*     */     
/*  71 */     I18nConversionCategory[] res = new I18nConversionCategory[maxIndex + 1];
/*  72 */     for (int i = 0; i <= maxIndex; i++) {
/*  73 */       Integer indexKey = Integer.valueOf(i);
/*  74 */       res[i] = 
/*  75 */         conv.containsKey(indexKey) ? conv.get(indexKey) : I18nConversionCategory.UNUSED;
/*     */     } 
/*  77 */     return res;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @I18nChecksFormat
/*     */   public static boolean hasFormat(String format, I18nConversionCategory... cc) {
/*  91 */     I18nConversionCategory[] fcc = formatParameterCategories(format);
/*  92 */     if (fcc.length != cc.length) {
/*  93 */       return false;
/*     */     }
/*     */     
/*  96 */     for (int i = 0; i < cc.length; i++) {
/*  97 */       if (!I18nConversionCategory.isSubsetOf(cc[i], fcc[i])) {
/*  98 */         return false;
/*     */       }
/*     */     } 
/* 101 */     return true;
/*     */   }
/*     */   
/*     */   @I18nValidFormat
/*     */   public static boolean isFormat(String format) {
/*     */     try {
/* 107 */       formatParameterCategories(format);
/* 108 */     } catch (Exception e) {
/* 109 */       return false;
/*     */     } 
/* 111 */     return true;
/*     */   }
/*     */   
/*     */   private static class I18nConversion {
/*     */     public int index;
/*     */     public I18nConversionCategory category;
/*     */     
/*     */     public I18nConversion(int index, I18nConversionCategory category) {
/* 119 */       this.index = index;
/* 120 */       this.category = category;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 125 */       return this.category.toString() + "(index: " + this.index + ")";
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class MessageFormatParser
/*     */   {
/*     */     public static int maxOffset;
/*     */ 
/*     */     
/*     */     private static Locale locale;
/*     */ 
/*     */     
/*     */     private static List<I18nConversionCategory> categories;
/*     */ 
/*     */     
/*     */     private static List<Integer> argumentIndices;
/*     */ 
/*     */     
/*     */     private static int numFormat;
/*     */     
/*     */     private static final int SEG_RAW = 0;
/*     */     
/*     */     private static final int SEG_INDEX = 1;
/*     */     
/*     */     private static final int SEG_TYPE = 2;
/*     */     
/*     */     private static final int SEG_MODIFIER = 3;
/*     */     
/*     */     private static final int TYPE_NULL = 0;
/*     */     
/*     */     private static final int TYPE_NUMBER = 1;
/*     */     
/*     */     private static final int TYPE_DATE = 2;
/*     */     
/*     */     private static final int TYPE_TIME = 3;
/*     */     
/*     */     private static final int TYPE_CHOICE = 4;
/*     */     
/* 165 */     private static final String[] TYPE_KEYWORDS = new String[] { "", "number", "date", "time", "choice" };
/*     */     
/*     */     private static final int MODIFIER_DEFAULT = 0;
/*     */     
/*     */     private static final int MODIFIER_CURRENCY = 1;
/*     */     
/*     */     private static final int MODIFIER_PERCENT = 2;
/*     */     private static final int MODIFIER_INTEGER = 3;
/* 173 */     private static final String[] NUMBER_MODIFIER_KEYWORDS = new String[] { "", "currency", "percent", "integer" };
/*     */ 
/*     */ 
/*     */     
/* 177 */     private static final String[] DATE_TIME_MODIFIER_KEYWORDS = new String[] { "", "short", "medium", "long", "full" };
/*     */ 
/*     */ 
/*     */     
/*     */     @EnsuresNonNull({"categories", "argumentIndices", "locale"})
/*     */     public static I18nFormatUtil.I18nConversion[] parse(String pattern) {
/* 183 */       categories = new ArrayList<>();
/* 184 */       argumentIndices = new ArrayList<>();
/* 185 */       locale = Locale.getDefault(Locale.Category.FORMAT);
/* 186 */       applyPattern(pattern);
/*     */       
/* 188 */       I18nFormatUtil.I18nConversion[] ret = new I18nFormatUtil.I18nConversion[numFormat];
/* 189 */       for (int i = 0; i < numFormat; i++) {
/* 190 */         ret[i] = new I18nFormatUtil.I18nConversion(((Integer)argumentIndices.get(i)).intValue(), categories.get(i));
/*     */       }
/* 192 */       return ret;
/*     */     }
/*     */ 
/*     */     
/*     */     @RequiresNonNull({"argumentIndices", "categories", "locale"})
/*     */     private static void applyPattern(String pattern) {
/* 198 */       StringBuilder[] segments = new StringBuilder[4];
/*     */ 
/*     */       
/* 201 */       segments[0] = new StringBuilder();
/*     */       
/* 203 */       int part = 0;
/* 204 */       numFormat = 0;
/* 205 */       boolean inQuote = false;
/* 206 */       int braceStack = 0;
/* 207 */       maxOffset = -1;
/* 208 */       for (int i = 0; i < pattern.length(); i++) {
/* 209 */         char ch = pattern.charAt(i);
/* 210 */         if (part == 0) {
/* 211 */           if (ch == '\'') {
/* 212 */             if (i + 1 < pattern.length() && pattern.charAt(i + 1) == '\'') {
/* 213 */               segments[part].append(ch);
/* 214 */               i++;
/*     */             } else {
/* 216 */               inQuote = !inQuote;
/*     */             } 
/* 218 */           } else if (ch == '{' && !inQuote) {
/* 219 */             part = 1;
/* 220 */             if (segments[1] == null) {
/* 221 */               segments[1] = new StringBuilder();
/*     */             }
/*     */           } else {
/* 224 */             segments[part].append(ch);
/*     */           }
/*     */         
/* 227 */         } else if (inQuote) {
/* 228 */           segments[part].append(ch);
/* 229 */           if (ch == '\'') {
/* 230 */             inQuote = false;
/*     */           }
/*     */         } else {
/* 233 */           switch (ch) {
/*     */             case ',':
/* 235 */               if (part < 3) {
/* 236 */                 if (segments[++part] == null)
/* 237 */                   segments[part] = new StringBuilder(); 
/*     */                 break;
/*     */               } 
/* 240 */               segments[part].append(ch);
/*     */               break;
/*     */             
/*     */             case '{':
/* 244 */               braceStack++;
/* 245 */               segments[part].append(ch);
/*     */               break;
/*     */             case '}':
/* 248 */               if (braceStack == 0) {
/* 249 */                 part = 0;
/* 250 */                 makeFormat(numFormat, segments);
/* 251 */                 numFormat++;
/*     */                 
/* 253 */                 segments[1] = null;
/* 254 */                 segments[2] = null;
/* 255 */                 segments[3] = null; break;
/*     */               } 
/* 257 */               braceStack--;
/* 258 */               segments[part].append(ch);
/*     */               break;
/*     */ 
/*     */             
/*     */             case ' ':
/* 263 */               if (part != 2 || segments[2].length() > 0) {
/* 264 */                 segments[part].append(ch);
/*     */               }
/*     */               break;
/*     */             case '\'':
/* 268 */               inQuote = true;
/* 269 */               segments[part].append(ch);
/*     */               break;
/*     */             default:
/* 272 */               segments[part].append(ch);
/*     */               break;
/*     */           } 
/*     */         
/*     */         } 
/*     */       } 
/* 278 */       if (braceStack == 0 && part != 0) {
/* 279 */         maxOffset = -1;
/* 280 */         throw new IllegalArgumentException("Unmatched braces in the pattern");
/*     */       } 
/*     */     }
/*     */     
/*     */     @RequiresNonNull({"argumentIndices", "categories", "locale"})
/*     */     private static void makeFormat(int offsetNumber, StringBuilder[] textSegments) {
/*     */       int argumentNumber;
/* 287 */       String[] segments = new String[textSegments.length];
/* 288 */       for (int i = 0; i < textSegments.length; i++) {
/* 289 */         StringBuilder oneseg = textSegments[i];
/* 290 */         segments[i] = (oneseg != null) ? oneseg.toString() : "";
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 296 */         argumentNumber = Integer.parseInt(segments[1]);
/*     */       }
/* 298 */       catch (NumberFormatException e) {
/* 299 */         throw new IllegalArgumentException("can't parse argument number: " + segments[1], e);
/*     */       } 
/*     */       
/* 302 */       if (argumentNumber < 0) {
/* 303 */         throw new IllegalArgumentException("negative argument number: " + argumentNumber);
/*     */       }
/*     */       
/* 306 */       int oldMaxOffset = maxOffset;
/* 307 */       maxOffset = offsetNumber;
/* 308 */       argumentIndices.add(Integer.valueOf(argumentNumber));
/*     */ 
/*     */       
/* 311 */       I18nConversionCategory category = null;
/* 312 */       if (segments[2].length() != 0) {
/* 313 */         int mod, type = findKeyword(segments[2], TYPE_KEYWORDS);
/* 314 */         switch (type) {
/*     */           case 0:
/* 316 */             category = I18nConversionCategory.GENERAL;
/*     */             break;
/*     */           case 1:
/* 319 */             switch (findKeyword(segments[3], NUMBER_MODIFIER_KEYWORDS)) {
/*     */               case 0:
/*     */               case 1:
/*     */               case 2:
/*     */               case 3:
/*     */                 break;
/*     */               default:
/*     */                 try {
/* 327 */                   new DecimalFormat(segments[3], 
/*     */                       
/* 329 */                       DecimalFormatSymbols.getInstance(locale));
/* 330 */                 } catch (IllegalArgumentException e) {
/* 331 */                   maxOffset = oldMaxOffset;
/*     */                   
/* 333 */                   throw e;
/*     */                 } 
/*     */                 break;
/*     */             } 
/* 337 */             category = I18nConversionCategory.NUMBER;
/*     */             break;
/*     */           case 2:
/*     */           case 3:
/* 341 */             mod = findKeyword(segments[3], DATE_TIME_MODIFIER_KEYWORDS);
/* 342 */             if (mod < 0 || mod >= DATE_TIME_MODIFIER_KEYWORDS.length) {
/*     */               
/*     */               try {
/*     */ 
/*     */                 
/* 347 */                 new SimpleDateFormat(segments[3], locale);
/* 348 */               } catch (IllegalArgumentException e) {
/* 349 */                 maxOffset = oldMaxOffset;
/*     */                 
/* 351 */                 throw e;
/*     */               } 
/*     */             }
/* 354 */             category = I18nConversionCategory.DATE;
/*     */             break;
/*     */           case 4:
/* 357 */             if (segments[3].length() == 0) {
/* 358 */               throw new IllegalArgumentException("Choice Pattern requires Subformat Pattern: " + segments[3]);
/*     */             }
/*     */ 
/*     */ 
/*     */             
/*     */             try {
/* 364 */               new ChoiceFormat(segments[3]);
/* 365 */             } catch (Exception e) {
/* 366 */               maxOffset = oldMaxOffset;
/*     */               
/* 368 */               throw new IllegalArgumentException("Choice Pattern incorrect: " + segments[3], e);
/*     */             } 
/*     */             
/* 371 */             category = I18nConversionCategory.NUMBER;
/*     */             break;
/*     */           default:
/* 374 */             maxOffset = oldMaxOffset;
/* 375 */             throw new IllegalArgumentException("unknown format type: " + segments[2]);
/*     */         } 
/*     */       
/*     */       } else {
/* 379 */         category = I18nConversionCategory.GENERAL;
/*     */       } 
/* 381 */       categories.add(category);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private static final int findKeyword(String s, String[] list) {
/* 389 */       for (int i = 0; i < list.length; i++) {
/* 390 */         if (s.equals(list[i])) {
/* 391 */           return i;
/*     */         }
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 397 */       String ls = s.trim().toLowerCase(Locale.ROOT);
/* 398 */       if (ls != s) {
/* 399 */         for (int j = 0; j < list.length; j++) {
/* 400 */           if (ls.equals(list[j])) {
/* 401 */             return j;
/*     */           }
/*     */         } 
/*     */       }
/* 405 */       return -1;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\checker-qual-3.8.0.jar!\org\checkerframework\checker\i18nformatter\I18nFormatUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */