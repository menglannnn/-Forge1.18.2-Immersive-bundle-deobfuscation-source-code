/*     */ package org.checkerframework.checker.regex;
/*     */ 
/*     */ import java.util.regex.Pattern;
/*     */ import java.util.regex.PatternSyntaxException;
/*     */ import org.checkerframework.checker.regex.qual.Regex;
/*     */ import org.checkerframework.dataflow.qual.Pure;
/*     */ import org.checkerframework.dataflow.qual.SideEffectFree;
/*     */ import org.checkerframework.framework.qual.EnsuresQualifierIf;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class RegexUtil
/*     */ {
/*     */   private RegexUtil() {
/*  33 */     throw new Error("do not instantiate");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class CheckedPatternSyntaxException
/*     */     extends Exception
/*     */   {
/*     */     private static final long serialVersionUID = 6266881831979001480L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final PatternSyntaxException pse;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public CheckedPatternSyntaxException(PatternSyntaxException pse) {
/*  80 */       this.pse = pse;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public CheckedPatternSyntaxException(String desc, String regex, int index) {
/*  92 */       this(new PatternSyntaxException(desc, regex, index));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getDescription() {
/* 101 */       return this.pse.getDescription();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int getIndex() {
/* 111 */       return this.pse.getIndex();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Pure
/*     */     public String getMessage() {
/* 124 */       return this.pse.getMessage();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getPattern() {
/* 133 */       return this.pse.getPattern();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Pure
/*     */   @EnsuresQualifierIf(result = true, expression = {"#1"}, qualifier = Regex.class)
/*     */   public static boolean isRegex(String s) {
/* 146 */     return isRegex(s, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Pure
/*     */   @EnsuresQualifierIf(result = true, expression = {"#1"}, qualifier = Regex.class)
/*     */   public static boolean isRegex(String s, int groups) {
/*     */     Pattern p;
/*     */     try {
/* 165 */       p = Pattern.compile(s);
/* 166 */     } catch (PatternSyntaxException e) {
/* 167 */       return false;
/*     */     } 
/* 169 */     return (getGroupCount(p) >= groups);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Pure
/*     */   @EnsuresQualifierIf(result = true, expression = {"#1"}, qualifier = Regex.class)
/*     */   public static boolean isRegex(char c) {
/* 186 */     return isRegex(Character.toString(c));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SideEffectFree
/*     */   public static String regexError(String s) {
/* 198 */     return regexError(s, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SideEffectFree
/*     */   public static String regexError(String s, int groups) {
/*     */     try {
/* 214 */       Pattern p = Pattern.compile(s);
/* 215 */       int actualGroups = getGroupCount(p);
/* 216 */       if (actualGroups < groups) {
/* 217 */         return regexErrorMessage(s, groups, actualGroups);
/*     */       }
/* 219 */     } catch (PatternSyntaxException e) {
/* 220 */       return e.getMessage();
/*     */     } 
/* 222 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SideEffectFree
/*     */   public static PatternSyntaxException regexException(String s) {
/* 234 */     return regexException(s, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SideEffectFree
/*     */   public static PatternSyntaxException regexException(String s, int groups) {
/*     */     try {
/* 250 */       Pattern p = Pattern.compile(s);
/* 251 */       int actualGroups = getGroupCount(p);
/* 252 */       if (actualGroups < groups) {
/* 253 */         return new PatternSyntaxException(
/* 254 */             regexErrorMessage(s, groups, actualGroups), s, -1);
/*     */       }
/* 256 */     } catch (PatternSyntaxException pse) {
/* 257 */       return pse;
/*     */     } 
/* 259 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SideEffectFree
/*     */   public static String asRegex(String s) {
/* 274 */     return asRegex(s, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SideEffectFree
/*     */   public static String asRegex(String s, int groups) {
/*     */     try {
/* 293 */       Pattern p = Pattern.compile(s);
/* 294 */       int actualGroups = getGroupCount(p);
/* 295 */       if (actualGroups < groups) {
/* 296 */         throw new Error(regexErrorMessage(s, groups, actualGroups));
/*     */       }
/* 298 */       return s;
/* 299 */     } catch (PatternSyntaxException e) {
/* 300 */       throw new Error(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SideEffectFree
/*     */   private static String regexErrorMessage(String s, int expectedGroups, int actualGroups) {
/* 315 */     return "regex \"" + s + "\" has " + actualGroups + " groups, but " + expectedGroups + " groups are needed.";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Pure
/*     */   private static int getGroupCount(Pattern p) {
/* 333 */     return p.matcher("").groupCount();
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\checker-qual-3.8.0.jar!\org\checkerframework\checker\regex\RegexUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */