/*     */ package org.checkerframework.checker.nullness;
/*     */ 
/*     */ import org.checkerframework.checker.nullness.qual.EnsuresNonNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class NullnessUtil
/*     */ {
/*     */   private NullnessUtil() {
/*  31 */     throw new AssertionError("shouldn't be instantiated");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @EnsuresNonNull({"#1"})
/*     */   public static <T> T castNonNull(T ref) {
/*  71 */     assert ref != null : "Misuse of castNonNull: called with a null argument";
/*  72 */     return ref;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @EnsuresNonNull({"#1"})
/*     */   public static <T> T castNonNull(T ref, String message) {
/*  87 */     assert ref != null : "Misuse of castNonNull: called with a null argument: " + message;
/*  88 */     return ref;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @EnsuresNonNull({"#1"})
/*     */   public static <T> T[] castNonNullDeep(T[] arr) {
/* 104 */     return castNonNullArray(arr, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @EnsuresNonNull({"#1"})
/*     */   public static <T> T[] castNonNullDeep(T[] arr, String message) {
/* 121 */     return castNonNullArray(arr, message);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @EnsuresNonNull({"#1"})
/*     */   public static <T> T[][] castNonNullDeep(T[][] arr) {
/* 137 */     return (T[][])castNonNullArray((Object[][])arr, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @EnsuresNonNull({"#1"})
/*     */   public static <T> T[][] castNonNullDeep(T[][] arr, String message) {
/* 154 */     return (T[][])castNonNullArray((Object[][])arr, message);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @EnsuresNonNull({"#1"})
/*     */   public static <T> T[][][] castNonNullDeep(T[][][] arr) {
/* 170 */     return (T[][][])castNonNullArray((Object[][][])arr, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @EnsuresNonNull({"#1"})
/*     */   public static <T> T[][][] castNonNullDeep(T[][][] arr, String message) {
/* 188 */     return (T[][][])castNonNullArray((Object[][][])arr, message);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @EnsuresNonNull({"#1"})
/*     */   public static <T> T[][][][] castNonNullDeep(T[][][][] arr) {
/* 205 */     return (T[][][][])castNonNullArray((Object[][][][])arr, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @EnsuresNonNull({"#1"})
/*     */   public static <T> T[][][][] castNonNullDeep(T[][][][] arr, String message) {
/* 223 */     return (T[][][][])castNonNullArray((Object[][][][])arr, message);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @EnsuresNonNull({"#1"})
/*     */   public static <T> T[][][][][] castNonNullDeep(T[][][][][] arr) {
/* 240 */     return (T[][][][][])castNonNullArray((Object[][][][][])arr, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @EnsuresNonNull({"#1"})
/*     */   public static <T> T[][][][][] castNonNullDeep(T[][][][][] arr, String message) {
/* 259 */     return (T[][][][][])castNonNullArray((Object[][][][][])arr, message);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static <T> T[] castNonNullArray(T[] arr, String message) {
/* 274 */     assert arr != null : "Misuse of castNonNullArray: called with a null array argument" + (
/*     */       
/* 276 */       (message == null) ? "" : (": " + message));
/* 277 */     for (int i = 0; i < arr.length; i++) {
/* 278 */       assert arr[i] != null : "Misuse of castNonNull: called with a null array element" + (
/*     */         
/* 280 */         (message == null) ? "" : (": " + message));
/* 281 */       checkIfArray(arr[i], message);
/*     */     } 
/* 283 */     return arr;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void checkIfArray(Object ref, String message) {
/* 295 */     assert ref != null : "Misuse of checkIfArray: called with a null argument" + (
/*     */       
/* 297 */       (message == null) ? "" : (": " + message));
/* 298 */     Class<?> comp = ref.getClass().getComponentType();
/* 299 */     if (comp != null)
/*     */     {
/* 301 */       if (!comp.isPrimitive())
/*     */       {
/*     */ 
/*     */         
/* 305 */         castNonNullArray((Object[])ref, message);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\checker-qual-3.8.0.jar!\org\checkerframework\checker\nullness\NullnessUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */