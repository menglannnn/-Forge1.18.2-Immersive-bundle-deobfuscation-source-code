package org.checkerframework.checker.units.qual;

import java.lang.annotation.Annotation;
import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

@Documented
@Retention(RetentionPolicy.RUNTIME)
public @interface UnitsMultiple {
  Class<? extends Annotation> quantity();
  
  Prefix prefix() default Prefix.one;
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\checker-qual-3.8.0.jar!\org\checkerframework\checke\\units\qual\UnitsMultiple.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */