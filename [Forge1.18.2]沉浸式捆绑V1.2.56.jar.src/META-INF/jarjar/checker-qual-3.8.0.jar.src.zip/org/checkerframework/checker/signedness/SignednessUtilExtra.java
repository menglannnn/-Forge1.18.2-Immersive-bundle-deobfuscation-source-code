/*    */ package org.checkerframework.checker.signedness;
/*    */ 
/*    */ import java.awt.Dimension;
/*    */ import java.awt.image.BufferedImage;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SignednessUtilExtra
/*    */ {
/*    */   private SignednessUtilExtra() {
/* 18 */     throw new Error("Do not instantiate");
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public static int dimensionUnsignedWidth(Dimension dim) {
/* 24 */     return dim.width;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public static int dimensionUnsignedHeight(Dimension dim) {
/* 30 */     return dim.height;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void setUnsignedRGB(BufferedImage b, int startX, int startY, int w, int h, int[] rgbArray, int offset, int scansize) {
/* 48 */     b.setRGB(startX, startY, w, h, rgbArray, offset, scansize);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static int[] getUnsignedRGB(BufferedImage b, int startX, int startY, int w, int h, int[] rgbArray, int offset, int scansize) {
/* 66 */     return b.getRGB(startX, startY, w, h, rgbArray, offset, scansize);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\checker-qual-3.8.0.jar!\org\checkerframework\checker\signedness\SignednessUtilExtra.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */