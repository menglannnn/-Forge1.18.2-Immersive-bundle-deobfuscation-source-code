/*     */ package org.checkerframework.checker.signedness;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.RandomAccessFile;
/*     */ import java.math.BigInteger;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.IntBuffer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SignednessUtil
/*     */ {
/*     */   private SignednessUtil() {
/*  23 */     throw new Error("Do not instantiate");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ByteBuffer wrapUnsigned(byte[] array) {
/*  33 */     return ByteBuffer.wrap(array);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ByteBuffer wrapUnsigned(byte[] array, int offset, int length) {
/*  43 */     return ByteBuffer.wrap(array, offset, length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getUnsignedInt(ByteBuffer b) {
/*  53 */     return b.getInt();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static short getUnsignedShort(ByteBuffer b) {
/*  63 */     return b.getShort();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte getUnsigned(ByteBuffer b) {
/*  73 */     return b.get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte getUnsigned(ByteBuffer b, int i) {
/*  83 */     return b.get(i);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ByteBuffer getUnsigned(ByteBuffer b, byte[] bs, int i, int l) {
/*  93 */     return b.get(bs, i, l);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ByteBuffer putUnsigned(ByteBuffer b, byte ubyte) {
/* 103 */     return b.put(ubyte);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ByteBuffer putUnsigned(ByteBuffer b, int i, byte ubyte) {
/* 113 */     return b.put(i, ubyte);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IntBuffer putUnsigned(IntBuffer b, int uint) {
/* 123 */     return b.put(uint);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IntBuffer putUnsigned(IntBuffer b, int i, int uint) {
/* 133 */     return b.put(i, uint);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IntBuffer putUnsigned(IntBuffer b, int[] uints) {
/* 143 */     return b.put(uints);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IntBuffer putUnsigned(IntBuffer b, int[] uints, int i, int l) {
/* 153 */     return b.put(uints, i, l);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getUnsigned(IntBuffer b, int i) {
/* 163 */     return b.get(i);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ByteBuffer putUnsignedShort(ByteBuffer b, short ushort) {
/* 173 */     return b.putShort(ushort);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ByteBuffer putUnsignedShort(ByteBuffer b, int i, short ushort) {
/* 183 */     return b.putShort(i, ushort);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ByteBuffer putUnsignedInt(ByteBuffer b, int uint) {
/* 193 */     return b.putInt(uint);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ByteBuffer putUnsignedInt(ByteBuffer b, int i, int uint) {
/* 203 */     return b.putInt(i, uint);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ByteBuffer putUnsignedLong(ByteBuffer b, int i, long ulong) {
/* 213 */     return b.putLong(i, ulong);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static char readUnsignedChar(RandomAccessFile f) throws IOException {
/* 223 */     return f.readChar();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int readUnsignedInt(RandomAccessFile f) throws IOException {
/* 233 */     return f.readInt();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static long readUnsignedLong(RandomAccessFile f) throws IOException {
/* 243 */     return f.readLong();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int readUnsigned(RandomAccessFile f, byte[] b, int off, int len) throws IOException {
/* 254 */     return f.read(b, off, len);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void readFullyUnsigned(RandomAccessFile f, byte[] b) throws IOException {
/* 265 */     f.readFully(b);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void writeUnsigned(RandomAccessFile f, byte[] bs, int off, int len) throws IOException {
/* 276 */     f.write(bs, off, len);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void writeUnsignedByte(RandomAccessFile f, byte b) throws IOException {
/* 286 */     f.writeByte(Byte.toUnsignedInt(b));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void writeUnsignedChar(RandomAccessFile f, char c) throws IOException {
/* 296 */     f.writeChar(toUnsignedInt(c));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void writeUnsignedShort(RandomAccessFile f, short s) throws IOException {
/* 307 */     f.writeShort(Short.toUnsignedInt(s));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void writeUnsignedInt(RandomAccessFile f, int i) throws IOException {
/* 317 */     f.writeInt(i);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void writeUnsignedLong(RandomAccessFile f, long l) throws IOException {
/* 327 */     f.writeLong(l);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void getUnsigned(ByteBuffer b, byte[] bs) {
/* 337 */     b.get(bs);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int compareUnsigned(short x, short y) {
/* 348 */     return Integer.compareUnsigned(Short.toUnsignedInt(x), Short.toUnsignedInt(y));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int compareUnsigned(byte x, byte y) {
/* 359 */     return Integer.compareUnsigned(Byte.toUnsignedInt(x), Byte.toUnsignedInt(y));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toUnsignedString(short s) {
/* 365 */     return Long.toString(Short.toUnsignedLong(s));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toUnsignedString(short s, int radix) {
/* 371 */     return Integer.toUnsignedString(Short.toUnsignedInt(s), radix);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toUnsignedString(byte b) {
/* 377 */     return Integer.toUnsignedString(Byte.toUnsignedInt(b));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toUnsignedString(byte b, int radix) {
/* 383 */     return Integer.toUnsignedString(Byte.toUnsignedInt(b), radix);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static BigInteger toUnsignedBigInteger(long l) {
/* 395 */     if (l >= 0L) {
/* 396 */       return BigInteger.valueOf(l);
/*     */     }
/* 398 */     int upper = (int)(l >>> 32L);
/* 399 */     int lower = (int)l;
/*     */ 
/*     */     
/* 402 */     return BigInteger.valueOf(Integer.toUnsignedLong(upper))
/* 403 */       .shiftLeft(32)
/* 404 */       .add(BigInteger.valueOf(Integer.toUnsignedLong(lower)));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static short toUnsignedShort(byte b) {
/* 410 */     return (short)(b & 0xFF);
/*     */   }
/*     */ 
/*     */   
/*     */   public static long toUnsignedLong(char c) {
/* 415 */     return c & 0xFFL;
/*     */   }
/*     */ 
/*     */   
/*     */   public static int toUnsignedInt(char c) {
/* 420 */     return c & 0xFF;
/*     */   }
/*     */ 
/*     */   
/*     */   public static short toUnsignedShort(char c) {
/* 425 */     return (short)(c & 0xFF);
/*     */   }
/*     */ 
/*     */   
/*     */   public static float toFloat(byte b) {
/* 430 */     return toUnsignedBigInteger(Byte.toUnsignedLong(b)).floatValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public static float toFloat(short s) {
/* 435 */     return toUnsignedBigInteger(Short.toUnsignedLong(s)).floatValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public static float toFloat(int i) {
/* 440 */     return toUnsignedBigInteger(Integer.toUnsignedLong(i)).floatValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public static float toFloat(long l) {
/* 445 */     return toUnsignedBigInteger(l).floatValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public static double toDouble(byte b) {
/* 450 */     return toUnsignedBigInteger(Byte.toUnsignedLong(b)).doubleValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public static double toDouble(short s) {
/* 455 */     return toUnsignedBigInteger(Short.toUnsignedLong(s)).doubleValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public static double toDouble(int i) {
/* 460 */     return toUnsignedBigInteger(Integer.toUnsignedLong(i)).doubleValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public static double toDouble(long l) {
/* 465 */     return toUnsignedBigInteger(l).doubleValue();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte byteFromFloat(float f) {
/* 471 */     assert f >= 0.0F;
/* 472 */     return (byte)(int)f;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static short shortFromFloat(float f) {
/* 478 */     assert f >= 0.0F;
/* 479 */     return (short)(int)f;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static int intFromFloat(float f) {
/* 485 */     assert f >= 0.0F;
/* 486 */     return (int)f;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static long longFromFloat(float f) {
/* 492 */     assert f >= 0.0F;
/* 493 */     return (long)f;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte byteFromDouble(double d) {
/* 499 */     assert d >= 0.0D;
/* 500 */     return (byte)(int)d;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static short shortFromDouble(double d) {
/* 506 */     assert d >= 0.0D;
/* 507 */     return (short)(int)d;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static int intFromDouble(double d) {
/* 513 */     assert d >= 0.0D;
/* 514 */     return (int)d;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static long longFromDouble(double d) {
/* 520 */     assert d >= 0.0D;
/* 521 */     return (long)d;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\checker-qual-3.8.0.jar!\org\checkerframework\checker\signedness\SignednessUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */