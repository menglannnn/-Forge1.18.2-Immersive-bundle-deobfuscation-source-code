/*     */ package org.checkerframework.checker.formatter;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.IllegalFormatConversionException;
/*     */ import java.util.IllegalFormatException;
/*     */ import java.util.Map;
/*     */ import java.util.MissingFormatArgumentException;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.checkerframework.checker.formatter.qual.ConversionCategory;
/*     */ import org.checkerframework.checker.formatter.qual.ReturnsFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FormatUtil
/*     */ {
/*     */   private static final String formatSpecifier = "%(\\d+\\$)?([-#+ 0,(\\<]*)?(\\d+)?(\\.\\d+)?([tT])?([a-zA-Z%])";
/*     */   private static final int formatSpecifierT = 5;
/*     */   private static final int formatSpecifierConversion = 6;
/*     */   
/*     */   private static class Conversion
/*     */   {
/*     */     private final int index;
/*     */     private final ConversionCategory cath;
/*     */     
/*     */     public Conversion(char c, int index) {
/*  37 */       this.index = index;
/*  38 */       this.cath = ConversionCategory.fromConversionChar(c);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     int index() {
/*  47 */       return this.index;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     ConversionCategory category() {
/*  56 */       return this.cath;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @ReturnsFormat
/*     */   public static String asFormat(String format, ConversionCategory... cc) throws IllegalFormatException {
/*  74 */     ConversionCategory[] fcc = formatParameterCategories(format);
/*  75 */     if (fcc.length != cc.length) {
/*  76 */       throw new ExcessiveOrMissingFormatArgumentException(cc.length, fcc.length);
/*     */     }
/*     */     
/*  79 */     for (int i = 0; i < cc.length; i++) {
/*  80 */       if (cc[i] != fcc[i]) {
/*  81 */         throw new IllegalFormatConversionCategoryException(cc[i], fcc[i]);
/*     */       }
/*     */     } 
/*     */     
/*  85 */     return format;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void tryFormatSatisfiability(String format) throws IllegalFormatException {
/* 100 */     String unused = String.format(format, (Object[])null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ConversionCategory[] formatParameterCategories(String format) throws IllegalFormatException {
/* 110 */     tryFormatSatisfiability(format);
/*     */     
/* 112 */     int last = -1;
/* 113 */     int lasto = -1;
/* 114 */     int maxindex = -1;
/*     */     
/* 116 */     Conversion[] cs = parse(format);
/* 117 */     Map<Integer, ConversionCategory> conv = new HashMap<>();
/*     */     
/* 119 */     for (Conversion c : cs) {
/* 120 */       int index = c.index();
/* 121 */       switch (index) {
/*     */         case -1:
/*     */           break;
/*     */         
/*     */         case 0:
/* 126 */           last = ++lasto;
/*     */           break;
/*     */         default:
/* 129 */           last = index - 1;
/*     */           break;
/*     */       } 
/* 132 */       maxindex = Math.max(maxindex, last);
/* 133 */       Integer lastKey = Integer.valueOf(last);
/* 134 */       conv.put(
/* 135 */           Integer.valueOf(last), 
/* 136 */           ConversionCategory.intersect(
/* 137 */             conv.containsKey(lastKey) ? 
/* 138 */             conv.get(lastKey) : 
/* 139 */             ConversionCategory.UNUSED, c
/* 140 */             .category()));
/*     */     } 
/*     */     
/* 143 */     ConversionCategory[] res = new ConversionCategory[maxindex + 1];
/* 144 */     for (int i = 0; i <= maxindex; i++) {
/* 145 */       Integer key = Integer.valueOf(i);
/* 146 */       res[i] = conv.containsKey(key) ? conv.get(key) : ConversionCategory.UNUSED;
/*     */     } 
/* 148 */     return res;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 179 */   private static Pattern fsPattern = Pattern.compile("%(\\d+\\$)?([-#+ 0,(\\<]*)?(\\d+)?(\\.\\d+)?([tT])?([a-zA-Z%])");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int indexFromFormat(Matcher m) {
/*     */     int index;
/* 190 */     String s = m.group(1);
/* 191 */     if (s != null) {
/* 192 */       index = Integer.parseInt(s.substring(0, s.length() - 1));
/*     */     } else {
/* 194 */       String group2 = m.group(2);
/* 195 */       if (group2 != null && group2.contains(String.valueOf('<'))) {
/* 196 */         index = -1;
/*     */       } else {
/* 198 */         index = 0;
/*     */       } 
/*     */     } 
/* 201 */     return index;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static char conversionCharFromFormat(Matcher m) {
/* 213 */     String tGroup = m.group(5);
/* 214 */     if (tGroup != null) {
/* 215 */       return tGroup.charAt(0);
/*     */     }
/* 217 */     return m.group(6).charAt(0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static char conversionCharFromFormat(String formatSpecifier) {
/* 233 */     Matcher m = fsPattern.matcher(formatSpecifier);
/* 234 */     assert m.find();
/* 235 */     return conversionCharFromFormat(m);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Conversion[] parse(String format) {
/* 245 */     ArrayList<Conversion> cs = new ArrayList<>();
/* 246 */     Matcher m = fsPattern.matcher(format);
/* 247 */     while (m.find()) {
/* 248 */       char c = conversionCharFromFormat(m);
/* 249 */       switch (c) {
/*     */         case '%':
/*     */         case 'n':
/*     */           continue;
/*     */       } 
/* 254 */       cs.add(new Conversion(c, indexFromFormat(m)));
/*     */     } 
/*     */     
/* 257 */     return cs.<Conversion>toArray(new Conversion[cs.size()]);
/*     */   }
/*     */ 
/*     */   
/*     */   public static class ExcessiveOrMissingFormatArgumentException
/*     */     extends MissingFormatArgumentException
/*     */   {
/*     */     private static final long serialVersionUID = 17000126L;
/*     */     
/*     */     private final int expected;
/*     */     
/*     */     private final int found;
/*     */ 
/*     */     
/*     */     public ExcessiveOrMissingFormatArgumentException(int expected, int found) {
/* 272 */       super("-");
/* 273 */       this.expected = expected;
/* 274 */       this.found = found;
/*     */     }
/*     */     
/*     */     public int getExpected() {
/* 278 */       return this.expected;
/*     */     }
/*     */     
/*     */     public int getFound() {
/* 282 */       return this.found;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getMessage() {
/* 287 */       return String.format("Expected %d arguments but found %d.", new Object[] { Integer.valueOf(this.expected), Integer.valueOf(this.found) });
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static class IllegalFormatConversionCategoryException
/*     */     extends IllegalFormatConversionException
/*     */   {
/*     */     private static final long serialVersionUID = 17000126L;
/*     */     
/*     */     private final ConversionCategory expected;
/*     */     
/*     */     private final ConversionCategory found;
/*     */ 
/*     */     
/*     */     public IllegalFormatConversionCategoryException(ConversionCategory expected, ConversionCategory found) {
/* 303 */       super((
/* 304 */           expected.chars == null || expected.chars.length() == 0) ? 
/* 305 */           45 : 
/* 306 */           expected.chars.charAt(0), 
/* 307 */           (found.types == null) ? Object.class : found.types[0]);
/* 308 */       this.expected = expected;
/* 309 */       this.found = found;
/*     */     }
/*     */     
/*     */     public ConversionCategory getExpected() {
/* 313 */       return this.expected;
/*     */     }
/*     */     
/*     */     public ConversionCategory getFound() {
/* 317 */       return this.found;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getMessage() {
/* 322 */       return String.format("Expected category %s but found %s.", new Object[] { this.expected, this.found });
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\checker-qual-3.8.0.jar!\org\checkerframework\checker\formatter\FormatUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */