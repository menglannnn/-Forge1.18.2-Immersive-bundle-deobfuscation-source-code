/*     */ package org.checkerframework.checker.formatter.qual;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ import java.util.Arrays;
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import java.util.StringJoiner;
/*     */ import org.checkerframework.dataflow.qual.Pure;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum ConversionCategory
/*     */ {
/*  37 */   GENERAL(null, "bBhHsS"),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  44 */   CHAR(new Class[] { Character.class, Byte.class, Short.class, Integer.class }, "cC"),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  50 */   INT(new Class[] { Byte.class, Short.class, Integer.class, Long.class, BigInteger.class }, "doxX"),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  58 */   FLOAT(new Class[] { Float.class, Double.class, BigDecimal.class }, "eEfgGaA"),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  64 */   TIME(new Class[] { Long.class, Calendar.class, Date.class }, "tT"),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  85 */   CHAR_AND_INT(new Class[] { Byte.class, Short.class, Integer.class }, null),
/*     */   
/*  87 */   INT_AND_TIME(new Class[] { Long.class }, null),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  99 */   NULL(new Class[0], null),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 112 */   UNUSED(null, null);
/*     */   public final Class<?>[] types;
/*     */   
/*     */   ConversionCategory(Class<?>[] types, String chars) {
/* 116 */     this.types = types;
/* 117 */     this.chars = chars;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String chars;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ConversionCategory fromConversionChar(char c) {
/* 139 */     for (ConversionCategory v : new ConversionCategory[] { GENERAL, CHAR, INT, FLOAT, TIME }) {
/* 140 */       if (v.chars.contains(String.valueOf(c))) {
/* 141 */         return v;
/*     */       }
/*     */     } 
/* 144 */     throw new IllegalArgumentException("Bad conversion character " + c);
/*     */   }
/*     */   
/*     */   private static <E> Set<E> arrayToSet(E[] a) {
/* 148 */     return new HashSet<>(Arrays.asList(a));
/*     */   }
/*     */   
/*     */   public static boolean isSubsetOf(ConversionCategory a, ConversionCategory b) {
/* 152 */     return (intersect(a, b) == a);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ConversionCategory intersect(ConversionCategory a, ConversionCategory b) {
/* 171 */     if (a == UNUSED) {
/* 172 */       return b;
/*     */     }
/* 174 */     if (b == UNUSED) {
/* 175 */       return a;
/*     */     }
/* 177 */     if (a == GENERAL) {
/* 178 */       return b;
/*     */     }
/* 180 */     if (b == GENERAL) {
/* 181 */       return a;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 187 */     Set<Class<?>> as = arrayToSet(a.types);
/*     */ 
/*     */ 
/*     */     
/* 191 */     Set<Class<?>> bs = arrayToSet(b.types);
/* 192 */     as.retainAll(bs);
/*     */     
/* 194 */     for (ConversionCategory v : new ConversionCategory[] { CHAR, INT, FLOAT, TIME, CHAR_AND_INT, INT_AND_TIME, NULL }) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 200 */       Set<Class<?>> vs = arrayToSet(v.types);
/* 201 */       if (vs.equals(as)) {
/* 202 */         return v;
/*     */       }
/*     */     } 
/* 205 */     throw new RuntimeException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ConversionCategory union(ConversionCategory a, ConversionCategory b) {
/* 224 */     if (a == UNUSED || b == UNUSED) {
/* 225 */       return UNUSED;
/*     */     }
/* 227 */     if (a == GENERAL || b == GENERAL) {
/* 228 */       return GENERAL;
/*     */     }
/* 230 */     if ((a == CHAR_AND_INT && b == INT_AND_TIME) || (a == INT_AND_TIME && b == CHAR_AND_INT))
/*     */     {
/*     */ 
/*     */       
/* 234 */       return INT;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 240 */     Set<Class<?>> as = arrayToSet(a.types);
/*     */ 
/*     */ 
/*     */     
/* 244 */     Set<Class<?>> bs = arrayToSet(b.types);
/* 245 */     as.addAll(bs);
/*     */     
/* 247 */     for (ConversionCategory v : new ConversionCategory[] { NULL, CHAR_AND_INT, INT_AND_TIME, CHAR, INT, FLOAT, TIME }) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 253 */       Set<Class<?>> vs = arrayToSet(v.types);
/* 254 */       if (vs.equals(as)) {
/* 255 */         return v;
/*     */       }
/*     */     } 
/*     */     
/* 259 */     return GENERAL;
/*     */   }
/*     */   
/*     */   private String className(Class<?> cls) {
/* 263 */     if (cls == Boolean.class) {
/* 264 */       return "boolean";
/*     */     }
/* 266 */     if (cls == Character.class) {
/* 267 */       return "char";
/*     */     }
/* 269 */     if (cls == Byte.class) {
/* 270 */       return "byte";
/*     */     }
/* 272 */     if (cls == Short.class) {
/* 273 */       return "short";
/*     */     }
/* 275 */     if (cls == Integer.class) {
/* 276 */       return "int";
/*     */     }
/* 278 */     if (cls == Long.class) {
/* 279 */       return "long";
/*     */     }
/* 281 */     if (cls == Float.class) {
/* 282 */       return "float";
/*     */     }
/* 284 */     if (cls == Double.class) {
/* 285 */       return "double";
/*     */     }
/* 287 */     return cls.getSimpleName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Pure
/*     */   public String toString() {
/* 297 */     StringBuilder sb = new StringBuilder(name());
/* 298 */     if (this != UNUSED && this != GENERAL) {
/* 299 */       StringJoiner sj = new StringJoiner(", ", " conversion category (one of: ", ")");
/* 300 */       for (Class<?> cls : this.types) {
/* 301 */         sj.add(className(cls));
/*     */       }
/* 303 */       sb.append(sj);
/*     */     } 
/* 305 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\checker-qual-3.8.0.jar!\org\checkerframework\checker\formatter\qual\ConversionCategory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */