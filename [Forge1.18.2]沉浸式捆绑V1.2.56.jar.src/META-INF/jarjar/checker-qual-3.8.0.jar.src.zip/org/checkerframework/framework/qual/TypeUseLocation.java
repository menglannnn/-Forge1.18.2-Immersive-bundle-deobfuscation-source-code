/*    */ package org.checkerframework.framework.qual;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum TypeUseLocation
/*    */ {
/* 15 */   FIELD,
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 23 */   LOCAL_VARIABLE,
/*    */ 
/*    */   
/* 26 */   RESOURCE_VARIABLE,
/*    */ 
/*    */   
/* 29 */   EXCEPTION_PARAMETER,
/*    */ 
/*    */   
/* 32 */   RECEIVER,
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 38 */   PARAMETER,
/*    */ 
/*    */   
/* 41 */   RETURN,
/*    */ 
/*    */   
/* 44 */   CONSTRUCTOR_RESULT,
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 51 */   LOWER_BOUND,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 56 */   EXPLICIT_LOWER_BOUND,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 61 */   IMPLICIT_LOWER_BOUND,
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 71 */   UPPER_BOUND,
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 77 */   EXPLICIT_UPPER_BOUND,
/*    */ 
/*    */   
/* 80 */   IMPLICIT_UPPER_BOUND,
/*    */ 
/*    */   
/* 83 */   OTHERWISE,
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 89 */   ALL;
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\checker-qual-3.8.0.jar!\org\checkerframework\framework\qual\TypeUseLocation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */