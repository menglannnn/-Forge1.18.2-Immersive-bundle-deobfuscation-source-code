/*    */ package org.checkerframework.framework.qual;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum TypeKind
/*    */ {
/* 14 */   BOOLEAN,
/*    */ 
/*    */   
/* 17 */   BYTE,
/*    */ 
/*    */   
/* 20 */   SHORT,
/*    */ 
/*    */   
/* 23 */   INT,
/*    */ 
/*    */   
/* 26 */   LONG,
/*    */ 
/*    */   
/* 29 */   CHAR,
/*    */ 
/*    */   
/* 32 */   FLOAT,
/*    */ 
/*    */   
/* 35 */   DOUBLE,
/*    */ 
/*    */   
/* 38 */   VOID,
/*    */ 
/*    */   
/* 41 */   NONE,
/*    */ 
/*    */   
/* 44 */   NULL,
/*    */ 
/*    */   
/* 47 */   ARRAY,
/*    */ 
/*    */   
/* 50 */   DECLARED,
/*    */ 
/*    */   
/* 53 */   ERROR,
/*    */ 
/*    */   
/* 56 */   TYPEVAR,
/*    */ 
/*    */   
/* 59 */   WILDCARD,
/*    */ 
/*    */   
/* 62 */   PACKAGE,
/*    */ 
/*    */   
/* 65 */   EXECUTABLE,
/*    */ 
/*    */   
/* 68 */   OTHER,
/*    */ 
/*    */   
/* 71 */   UNION,
/*    */ 
/*    */   
/* 74 */   INTERSECTION;
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\checker-qual-3.8.0.jar!\org\checkerframework\framework\qual\TypeKind.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */