/*    */ package io.netty.handler.codec.serialization;
/*    */ 
/*    */ import io.netty.buffer.ByteBuf;
/*    */ import io.netty.buffer.ByteBufOutputStream;
/*    */ import io.netty.channel.ChannelHandlerContext;
/*    */ import io.netty.handler.codec.MessageToByteEncoder;
/*    */ import io.netty.util.internal.ObjectUtil;
/*    */ import java.io.ObjectOutputStream;
/*    */ import java.io.OutputStream;
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public class CompatibleObjectEncoder
/*    */   extends MessageToByteEncoder<Serializable>
/*    */ {
/*    */   private final int resetInterval;
/*    */   private int writtenObjects;
/*    */   
/*    */   public CompatibleObjectEncoder() {
/* 56 */     this(16);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public CompatibleObjectEncoder(int resetInterval) {
/* 69 */     this.resetInterval = ObjectUtil.checkPositiveOrZero(resetInterval, "resetInterval");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected ObjectOutputStream newObjectOutputStream(OutputStream out) throws Exception {
/* 78 */     return new ObjectOutputStream(out);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected void encode(ChannelHandlerContext ctx, Serializable msg, ByteBuf out) throws Exception {
/* 84 */     ObjectOutputStream oos = newObjectOutputStream((OutputStream)new ByteBufOutputStream(out));
/*    */     
/*    */     try {
/* 87 */       if (this.resetInterval != 0) {
/*    */         
/* 89 */         this.writtenObjects++;
/* 90 */         if (this.writtenObjects % this.resetInterval == 0) {
/* 91 */           oos.reset();
/*    */         }
/*    */       } 
/*    */       
/* 95 */       oos.writeObject(msg);
/* 96 */       oos.flush();
/*    */     } finally {
/* 98 */       oos.close();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-4.1.93.Final.jar!\io\netty\handler\codec\serialization\CompatibleObjectEncoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */