/*    */ package io.netty.handler.codec.compression;
/*    */ 
/*    */ import io.netty.util.internal.ObjectUtil;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ZstdOptions
/*    */   implements CompressionOptions
/*    */ {
/*    */   private final int blockSize;
/*    */   private final int compressionLevel;
/*    */   private final int maxEncodeSize;
/* 40 */   static final ZstdOptions DEFAULT = new ZstdOptions(3, 65536, 33554432);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   ZstdOptions(int compressionLevel, int blockSize, int maxEncodeSize) {
/* 53 */     if (!Zstd.isAvailable()) {
/* 54 */       throw new IllegalStateException("zstd-jni is not available", Zstd.cause());
/*    */     }
/*    */     
/* 57 */     this.compressionLevel = ObjectUtil.checkInRange(compressionLevel, 0, 22, "compressionLevel");
/* 58 */     this.blockSize = ObjectUtil.checkPositive(blockSize, "blockSize");
/* 59 */     this.maxEncodeSize = ObjectUtil.checkPositive(maxEncodeSize, "maxEncodeSize");
/*    */   }
/*    */   
/*    */   public int compressionLevel() {
/* 63 */     return this.compressionLevel;
/*    */   }
/*    */   
/*    */   public int blockSize() {
/* 67 */     return this.blockSize;
/*    */   }
/*    */   
/*    */   public int maxEncodeSize() {
/* 71 */     return this.maxEncodeSize;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-4.1.93.Final.jar!\io\netty\handler\codec\compression\ZstdOptions.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */