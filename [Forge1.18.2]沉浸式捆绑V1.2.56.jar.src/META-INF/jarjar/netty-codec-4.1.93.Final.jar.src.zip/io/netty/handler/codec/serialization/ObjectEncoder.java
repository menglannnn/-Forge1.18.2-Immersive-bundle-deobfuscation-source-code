/*    */ package io.netty.handler.codec.serialization;
/*    */ 
/*    */ import io.netty.buffer.ByteBuf;
/*    */ import io.netty.buffer.ByteBufOutputStream;
/*    */ import io.netty.channel.ChannelHandler.Sharable;
/*    */ import io.netty.channel.ChannelHandlerContext;
/*    */ import io.netty.handler.codec.MessageToByteEncoder;
/*    */ import java.io.ObjectOutputStream;
/*    */ import java.io.OutputStream;
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ @Sharable
/*    */ public class ObjectEncoder
/*    */   extends MessageToByteEncoder<Serializable>
/*    */ {
/* 49 */   private static final byte[] LENGTH_PLACEHOLDER = new byte[4];
/*    */ 
/*    */   
/*    */   protected void encode(ChannelHandlerContext ctx, Serializable msg, ByteBuf out) throws Exception {
/* 53 */     int startIdx = out.writerIndex();
/*    */     
/* 55 */     ByteBufOutputStream bout = new ByteBufOutputStream(out);
/* 56 */     ObjectOutputStream oout = null;
/*    */     try {
/* 58 */       bout.write(LENGTH_PLACEHOLDER);
/* 59 */       oout = new CompactObjectOutputStream((OutputStream)bout);
/* 60 */       oout.writeObject(msg);
/* 61 */       oout.flush();
/*    */     } finally {
/* 63 */       if (oout != null) {
/* 64 */         oout.close();
/*    */       } else {
/* 66 */         bout.close();
/*    */       } 
/*    */     } 
/*    */     
/* 70 */     int endIdx = out.writerIndex();
/*    */     
/* 72 */     out.setInt(startIdx, endIdx - startIdx - 4);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-4.1.93.Final.jar!\io\netty\handler\codec\serialization\ObjectEncoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */