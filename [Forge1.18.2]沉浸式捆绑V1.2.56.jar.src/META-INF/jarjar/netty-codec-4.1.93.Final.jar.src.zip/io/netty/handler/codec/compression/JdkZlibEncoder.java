/*     */ package io.netty.handler.codec.compression;
/*     */ 
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import io.netty.channel.ChannelFuture;
/*     */ import io.netty.channel.ChannelHandlerContext;
/*     */ import io.netty.channel.ChannelPromise;
/*     */ import io.netty.util.concurrent.EventExecutor;
/*     */ import io.netty.util.concurrent.Future;
/*     */ import io.netty.util.concurrent.Promise;
/*     */ import io.netty.util.concurrent.PromiseNotifier;
/*     */ import io.netty.util.internal.EmptyArrays;
/*     */ import io.netty.util.internal.ObjectUtil;
/*     */ import io.netty.util.internal.PlatformDependent;
/*     */ import io.netty.util.internal.SuppressJava6Requirement;
/*     */ import io.netty.util.internal.SystemPropertyUtil;
/*     */ import io.netty.util.internal.logging.InternalLogger;
/*     */ import io.netty.util.internal.logging.InternalLoggerFactory;
/*     */ import java.util.zip.CRC32;
/*     */ import java.util.zip.Deflater;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JdkZlibEncoder
/*     */   extends ZlibEncoder
/*     */ {
/*  40 */   private static final InternalLogger logger = InternalLoggerFactory.getInstance(JdkZlibEncoder.class);
/*     */ 
/*     */   
/*     */   private static final int MAX_INITIAL_OUTPUT_BUFFER_SIZE;
/*     */ 
/*     */   
/*     */   private static final int MAX_INPUT_BUFFER_SIZE;
/*     */ 
/*     */   
/*     */   private final ZlibWrapper wrapper;
/*     */ 
/*     */   
/*     */   private final Deflater deflater;
/*     */ 
/*     */   
/*     */   private volatile boolean finished;
/*     */ 
/*     */   
/*     */   private volatile ChannelHandlerContext ctx;
/*     */   
/*  60 */   private final CRC32 crc = new CRC32();
/*  61 */   private static final byte[] gzipHeader = new byte[] { 31, -117, 8, 0, 0, 0, 0, 0, 0, 0 };
/*     */   private boolean writeHeader = true;
/*     */   
/*     */   static {
/*  65 */     MAX_INITIAL_OUTPUT_BUFFER_SIZE = SystemPropertyUtil.getInt("io.netty.jdkzlib.encoder.maxInitialOutputBufferSize", 65536);
/*     */ 
/*     */     
/*  68 */     MAX_INPUT_BUFFER_SIZE = SystemPropertyUtil.getInt("io.netty.jdkzlib.encoder.maxInputBufferSize", 65536);
/*     */ 
/*     */ 
/*     */     
/*  72 */     if (logger.isDebugEnabled()) {
/*  73 */       logger.debug("-Dio.netty.jdkzlib.encoder.maxInitialOutputBufferSize={}", Integer.valueOf(MAX_INITIAL_OUTPUT_BUFFER_SIZE));
/*  74 */       logger.debug("-Dio.netty.jdkzlib.encoder.maxInputBufferSize={}", Integer.valueOf(MAX_INPUT_BUFFER_SIZE));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JdkZlibEncoder() {
/*  85 */     this(6);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JdkZlibEncoder(int compressionLevel) {
/* 100 */     this(ZlibWrapper.ZLIB, compressionLevel);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JdkZlibEncoder(ZlibWrapper wrapper) {
/* 110 */     this(wrapper, 6);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JdkZlibEncoder(ZlibWrapper wrapper, int compressionLevel) {
/* 125 */     ObjectUtil.checkInRange(compressionLevel, 0, 9, "compressionLevel");
/* 126 */     ObjectUtil.checkNotNull(wrapper, "wrapper");
/*     */     
/* 128 */     if (wrapper == ZlibWrapper.ZLIB_OR_NONE) {
/* 129 */       throw new IllegalArgumentException("wrapper '" + ZlibWrapper.ZLIB_OR_NONE + "' is not allowed for compression.");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 134 */     this.wrapper = wrapper;
/* 135 */     this.deflater = new Deflater(compressionLevel, (wrapper != ZlibWrapper.ZLIB));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JdkZlibEncoder(byte[] dictionary) {
/* 149 */     this(6, dictionary);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JdkZlibEncoder(int compressionLevel, byte[] dictionary) {
/* 167 */     ObjectUtil.checkInRange(compressionLevel, 0, 9, "compressionLevel");
/* 168 */     ObjectUtil.checkNotNull(dictionary, "dictionary");
/*     */     
/* 170 */     this.wrapper = ZlibWrapper.ZLIB;
/* 171 */     this.deflater = new Deflater(compressionLevel);
/* 172 */     this.deflater.setDictionary(dictionary);
/*     */   }
/*     */ 
/*     */   
/*     */   public ChannelFuture close() {
/* 177 */     return close(ctx().newPromise());
/*     */   }
/*     */ 
/*     */   
/*     */   public ChannelFuture close(final ChannelPromise promise) {
/* 182 */     ChannelHandlerContext ctx = ctx();
/* 183 */     EventExecutor executor = ctx.executor();
/* 184 */     if (executor.inEventLoop()) {
/* 185 */       return finishEncode(ctx, promise);
/*     */     }
/* 187 */     final ChannelPromise p = ctx.newPromise();
/* 188 */     executor.execute(new Runnable()
/*     */         {
/*     */           public void run() {
/* 191 */             ChannelFuture f = JdkZlibEncoder.this.finishEncode(JdkZlibEncoder.this.ctx(), p);
/* 192 */             PromiseNotifier.cascade((Future)f, (Promise)promise);
/*     */           }
/*     */         });
/* 195 */     return (ChannelFuture)p;
/*     */   }
/*     */ 
/*     */   
/*     */   private ChannelHandlerContext ctx() {
/* 200 */     ChannelHandlerContext ctx = this.ctx;
/* 201 */     if (ctx == null) {
/* 202 */       throw new IllegalStateException("not added to a pipeline");
/*     */     }
/* 204 */     return ctx;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isClosed() {
/* 209 */     return this.finished;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void encode(ChannelHandlerContext ctx, ByteBuf uncompressed, ByteBuf out) throws Exception {
/* 214 */     if (this.finished) {
/* 215 */       out.writeBytes(uncompressed);
/*     */       
/*     */       return;
/*     */     } 
/* 219 */     int len = uncompressed.readableBytes();
/* 220 */     if (len == 0) {
/*     */       return;
/*     */     }
/*     */     
/* 224 */     if (uncompressed.hasArray()) {
/*     */       
/* 226 */       encodeSome(uncompressed, out);
/*     */     } else {
/* 228 */       int heapBufferSize = Math.min(len, MAX_INPUT_BUFFER_SIZE);
/* 229 */       ByteBuf heapBuf = ctx.alloc().heapBuffer(heapBufferSize, heapBufferSize);
/*     */       try {
/* 231 */         while (uncompressed.isReadable()) {
/* 232 */           uncompressed.readBytes(heapBuf, Math.min(heapBuf.writableBytes(), uncompressed.readableBytes()));
/* 233 */           encodeSome(heapBuf, out);
/* 234 */           heapBuf.clear();
/*     */         } 
/*     */       } finally {
/* 237 */         heapBuf.release();
/*     */       } 
/*     */     } 
/*     */     
/* 241 */     this.deflater.setInput(EmptyArrays.EMPTY_BYTES);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void encodeSome(ByteBuf in, ByteBuf out) {
/* 247 */     byte[] inAry = in.array();
/* 248 */     int offset = in.arrayOffset() + in.readerIndex();
/*     */     
/* 250 */     if (this.writeHeader) {
/* 251 */       this.writeHeader = false;
/* 252 */       if (this.wrapper == ZlibWrapper.GZIP) {
/* 253 */         out.writeBytes(gzipHeader);
/*     */       }
/*     */     } 
/*     */     
/* 257 */     int len = in.readableBytes();
/* 258 */     if (this.wrapper == ZlibWrapper.GZIP) {
/* 259 */       this.crc.update(inAry, offset, len);
/*     */     }
/*     */     
/* 262 */     this.deflater.setInput(inAry, offset, len);
/*     */     while (true) {
/* 264 */       deflate(out);
/* 265 */       if (!out.isWritable()) {
/*     */ 
/*     */         
/* 268 */         out.ensureWritable(out.writerIndex()); continue;
/* 269 */       }  if (this.deflater.needsInput()) {
/*     */         break;
/*     */       }
/*     */     } 
/*     */     
/* 274 */     in.skipBytes(len);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected final ByteBuf allocateBuffer(ChannelHandlerContext ctx, ByteBuf msg, boolean preferDirect) throws Exception {
/* 280 */     int sizeEstimate = (int)Math.ceil(msg.readableBytes() * 1.001D) + 12;
/* 281 */     if (this.writeHeader) {
/* 282 */       switch (this.wrapper) {
/*     */         case GZIP:
/* 284 */           sizeEstimate += gzipHeader.length;
/*     */           break;
/*     */         case ZLIB:
/* 287 */           sizeEstimate += 2;
/*     */           break;
/*     */       } 
/*     */ 
/*     */ 
/*     */     
/*     */     }
/* 294 */     if (sizeEstimate < 0 || sizeEstimate > MAX_INITIAL_OUTPUT_BUFFER_SIZE)
/*     */     {
/* 296 */       return ctx.alloc().heapBuffer(MAX_INITIAL_OUTPUT_BUFFER_SIZE);
/*     */     }
/* 298 */     return ctx.alloc().heapBuffer(sizeEstimate);
/*     */   }
/*     */ 
/*     */   
/*     */   public void close(ChannelHandlerContext ctx, ChannelPromise promise) throws Exception {
/* 303 */     ChannelFuture f = finishEncode(ctx, ctx.newPromise());
/* 304 */     EncoderUtil.closeAfterFinishEncode(ctx, f, promise);
/*     */   }
/*     */   
/*     */   private ChannelFuture finishEncode(ChannelHandlerContext ctx, ChannelPromise promise) {
/* 308 */     if (this.finished) {
/* 309 */       promise.setSuccess();
/* 310 */       return (ChannelFuture)promise;
/*     */     } 
/*     */     
/* 313 */     this.finished = true;
/* 314 */     ByteBuf footer = ctx.alloc().heapBuffer();
/* 315 */     if (this.writeHeader && this.wrapper == ZlibWrapper.GZIP) {
/*     */       
/* 317 */       this.writeHeader = false;
/* 318 */       footer.writeBytes(gzipHeader);
/*     */     } 
/*     */     
/* 321 */     this.deflater.finish();
/*     */     
/* 323 */     while (!this.deflater.finished()) {
/* 324 */       deflate(footer);
/* 325 */       if (!footer.isWritable()) {
/*     */         
/* 327 */         ctx.write(footer);
/* 328 */         footer = ctx.alloc().heapBuffer();
/*     */       } 
/*     */     } 
/* 331 */     if (this.wrapper == ZlibWrapper.GZIP) {
/* 332 */       int crcValue = (int)this.crc.getValue();
/* 333 */       int uncBytes = this.deflater.getTotalIn();
/* 334 */       footer.writeByte(crcValue);
/* 335 */       footer.writeByte(crcValue >>> 8);
/* 336 */       footer.writeByte(crcValue >>> 16);
/* 337 */       footer.writeByte(crcValue >>> 24);
/* 338 */       footer.writeByte(uncBytes);
/* 339 */       footer.writeByte(uncBytes >>> 8);
/* 340 */       footer.writeByte(uncBytes >>> 16);
/* 341 */       footer.writeByte(uncBytes >>> 24);
/*     */     } 
/* 343 */     this.deflater.end();
/* 344 */     return ctx.writeAndFlush(footer, promise);
/*     */   }
/*     */   @SuppressJava6Requirement(reason = "Usage guarded by java version check")
/*     */   private void deflate(ByteBuf out) {
/*     */     int numBytes;
/* 349 */     if (PlatformDependent.javaVersion() < 7) {
/* 350 */       deflateJdk6(out);
/*     */     }
/*     */     
/*     */     do {
/* 354 */       int writerIndex = out.writerIndex();
/* 355 */       numBytes = this.deflater.deflate(out
/* 356 */           .array(), out.arrayOffset() + writerIndex, out.writableBytes(), 2);
/* 357 */       out.writerIndex(writerIndex + numBytes);
/* 358 */     } while (numBytes > 0);
/*     */   }
/*     */   
/*     */   private void deflateJdk6(ByteBuf out) {
/*     */     int numBytes;
/*     */     do {
/* 364 */       int writerIndex = out.writerIndex();
/* 365 */       numBytes = this.deflater.deflate(out
/* 366 */           .array(), out.arrayOffset() + writerIndex, out.writableBytes());
/* 367 */       out.writerIndex(writerIndex + numBytes);
/* 368 */     } while (numBytes > 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public void handlerAdded(ChannelHandlerContext ctx) throws Exception {
/* 373 */     this.ctx = ctx;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-4.1.93.Final.jar!\io\netty\handler\codec\compression\JdkZlibEncoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */