/*     */ package io.netty.handler.codec.compression;
/*     */ 
/*     */ import io.netty.buffer.ByteBuf;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Snappy
/*     */ {
/*     */   private static final int MAX_HT_SIZE = 16384;
/*     */   private static final int MIN_COMPRESSIBLE_BYTES = 15;
/*     */   private static final int PREAMBLE_NOT_FULL = -1;
/*     */   private static final int NOT_ENOUGH_INPUT = -1;
/*     */   private static final int LITERAL = 0;
/*     */   private static final int COPY_1_BYTE_OFFSET = 1;
/*     */   private static final int COPY_2_BYTE_OFFSET = 2;
/*     */   private static final int COPY_4_BYTE_OFFSET = 3;
/*  41 */   private State state = State.READING_PREAMBLE;
/*     */   private byte tag;
/*     */   private int written;
/*     */   
/*     */   private enum State {
/*  46 */     READING_PREAMBLE,
/*  47 */     READING_TAG,
/*  48 */     READING_LITERAL,
/*  49 */     READING_COPY;
/*     */   }
/*     */   
/*     */   public void reset() {
/*  53 */     this.state = State.READING_PREAMBLE;
/*  54 */     this.tag = 0;
/*  55 */     this.written = 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public void encode(ByteBuf in, ByteBuf out, int length) {
/*  60 */     for (int i = 0;; i++) {
/*  61 */       int b = length >>> i * 7;
/*  62 */       if ((b & 0xFFFFFF80) != 0) {
/*  63 */         out.writeByte(b & 0x7F | 0x80);
/*     */       } else {
/*  65 */         out.writeByte(b);
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/*  70 */     int inIndex = in.readerIndex();
/*  71 */     int baseIndex = inIndex;
/*     */     
/*  73 */     short[] table = getHashTable(length);
/*  74 */     int shift = Integer.numberOfLeadingZeros(table.length) + 1;
/*     */     
/*  76 */     int nextEmit = inIndex;
/*     */     
/*  78 */     if (length - inIndex >= 15) {
/*  79 */       int nextHash = hash(in, ++inIndex, shift);
/*     */       while (true) {
/*  81 */         int skip = 32;
/*     */ 
/*     */         
/*  84 */         int nextIndex = inIndex;
/*     */         while (true) {
/*  86 */           inIndex = nextIndex;
/*  87 */           int hash = nextHash;
/*  88 */           int bytesBetweenHashLookups = skip++ >> 5;
/*  89 */           nextIndex = inIndex + bytesBetweenHashLookups;
/*     */ 
/*     */           
/*  92 */           if (nextIndex > length - 4) {
/*     */             break;
/*     */           }
/*     */           
/*  96 */           nextHash = hash(in, nextIndex, shift);
/*     */           
/*  98 */           int candidate = baseIndex + table[hash];
/*     */           
/* 100 */           table[hash] = (short)(inIndex - baseIndex);
/*     */           
/* 102 */           if (in.getInt(inIndex) == in.getInt(candidate)) {
/*     */             
/* 104 */             encodeLiteral(in, out, inIndex - nextEmit);
/*     */ 
/*     */             
/*     */             while (true) {
/* 108 */               int base = inIndex;
/* 109 */               int matched = 4 + findMatchingLength(in, candidate + 4, inIndex + 4, length);
/* 110 */               inIndex += matched;
/* 111 */               int offset = base - candidate;
/* 112 */               encodeCopy(out, offset, matched);
/* 113 */               in.readerIndex(in.readerIndex() + matched);
/* 114 */               int insertTail = inIndex - 1;
/* 115 */               nextEmit = inIndex;
/* 116 */               if (inIndex >= length - 4) {
/*     */                 break;
/*     */               }
/*     */               
/* 120 */               int prevHash = hash(in, insertTail, shift);
/* 121 */               table[prevHash] = (short)(inIndex - baseIndex - 1);
/* 122 */               int currentHash = hash(in, insertTail + 1, shift);
/* 123 */               candidate = baseIndex + table[currentHash];
/* 124 */               table[currentHash] = (short)(inIndex - baseIndex);
/*     */               
/* 126 */               if (in.getInt(insertTail + 1) != in.getInt(candidate))
/*     */               
/* 128 */               { nextHash = hash(in, insertTail + 2, shift);
/* 129 */                 inIndex++; } 
/*     */             }  break;
/*     */           } 
/*     */         }  break;
/*     */       } 
/* 134 */     }  if (nextEmit < length) {
/* 135 */       encodeLiteral(in, out, length - nextEmit);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int hash(ByteBuf in, int index, int shift) {
/* 150 */     return in.getInt(index) * 506832829 >>> shift;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static short[] getHashTable(int inputSize) {
/* 160 */     int htSize = 256;
/* 161 */     while (htSize < 16384 && htSize < inputSize) {
/* 162 */       htSize <<= 1;
/*     */     }
/* 164 */     return new short[htSize];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int findMatchingLength(ByteBuf in, int minIndex, int inIndex, int maxIndex) {
/* 179 */     int matched = 0;
/*     */     
/* 181 */     while (inIndex <= maxIndex - 4 && in
/* 182 */       .getInt(inIndex) == in.getInt(minIndex + matched)) {
/* 183 */       inIndex += 4;
/* 184 */       matched += 4;
/*     */     } 
/*     */     
/* 187 */     while (inIndex < maxIndex && in.getByte(minIndex + matched) == in.getByte(inIndex)) {
/* 188 */       inIndex++;
/* 189 */       matched++;
/*     */     } 
/*     */     
/* 192 */     return matched;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int bitsToEncode(int value) {
/* 204 */     int highestOneBit = Integer.highestOneBit(value);
/* 205 */     int bitLength = 0;
/* 206 */     while ((highestOneBit >>= 1) != 0) {
/* 207 */       bitLength++;
/*     */     }
/*     */     
/* 210 */     return bitLength;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void encodeLiteral(ByteBuf in, ByteBuf out, int length) {
/* 223 */     if (length < 61) {
/* 224 */       out.writeByte(length - 1 << 2);
/*     */     } else {
/* 226 */       int bitLength = bitsToEncode(length - 1);
/* 227 */       int bytesToEncode = 1 + bitLength / 8;
/* 228 */       out.writeByte(59 + bytesToEncode << 2);
/* 229 */       for (int i = 0; i < bytesToEncode; i++) {
/* 230 */         out.writeByte(length - 1 >> i * 8 & 0xFF);
/*     */       }
/*     */     } 
/*     */     
/* 234 */     out.writeBytes(in, length);
/*     */   }
/*     */   
/*     */   private static void encodeCopyWithOffset(ByteBuf out, int offset, int length) {
/* 238 */     if (length < 12 && offset < 2048) {
/* 239 */       out.writeByte(0x1 | length - 4 << 2 | offset >> 8 << 5);
/* 240 */       out.writeByte(offset & 0xFF);
/*     */     } else {
/* 242 */       out.writeByte(0x2 | length - 1 << 2);
/* 243 */       out.writeByte(offset & 0xFF);
/* 244 */       out.writeByte(offset >> 8 & 0xFF);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void encodeCopy(ByteBuf out, int offset, int length) {
/* 256 */     while (length >= 68) {
/* 257 */       encodeCopyWithOffset(out, offset, 64);
/* 258 */       length -= 64;
/*     */     } 
/*     */     
/* 261 */     if (length > 64) {
/* 262 */       encodeCopyWithOffset(out, offset, 60);
/* 263 */       length -= 60;
/*     */     } 
/*     */     
/* 266 */     encodeCopyWithOffset(out, offset, length);
/*     */   }
/*     */   
/*     */   public void decode(ByteBuf in, ByteBuf out) {
/* 270 */     while (in.isReadable()) {
/* 271 */       int uncompressedLength; int literalWritten; int decodeWritten; switch (this.state) {
/*     */         case READING_PREAMBLE:
/* 273 */           uncompressedLength = readPreamble(in);
/* 274 */           if (uncompressedLength == -1) {
/*     */             return;
/*     */           }
/*     */           
/* 278 */           if (uncompressedLength == 0) {
/*     */             return;
/*     */           }
/*     */           
/* 282 */           out.ensureWritable(uncompressedLength);
/* 283 */           this.state = State.READING_TAG;
/*     */         
/*     */         case READING_TAG:
/* 286 */           if (!in.isReadable()) {
/*     */             return;
/*     */           }
/* 289 */           this.tag = in.readByte();
/* 290 */           switch (this.tag & 0x3) {
/*     */             case 0:
/* 292 */               this.state = State.READING_LITERAL;
/*     */             
/*     */             case 1:
/*     */             case 2:
/*     */             case 3:
/* 297 */               this.state = State.READING_COPY;
/*     */           } 
/*     */         
/*     */         
/*     */         case READING_LITERAL:
/* 302 */           literalWritten = decodeLiteral(this.tag, in, out);
/* 303 */           if (literalWritten != -1) {
/* 304 */             this.state = State.READING_TAG;
/* 305 */             this.written += literalWritten;
/*     */             continue;
/*     */           } 
/*     */           return;
/*     */ 
/*     */ 
/*     */         
/*     */         case READING_COPY:
/* 313 */           switch (this.tag & 0x3) {
/*     */             case 1:
/* 315 */               decodeWritten = decodeCopyWith1ByteOffset(this.tag, in, out, this.written);
/* 316 */               if (decodeWritten != -1) {
/* 317 */                 this.state = State.READING_TAG;
/* 318 */                 this.written += decodeWritten;
/*     */                 continue;
/*     */               } 
/*     */               return;
/*     */ 
/*     */             
/*     */             case 2:
/* 325 */               decodeWritten = decodeCopyWith2ByteOffset(this.tag, in, out, this.written);
/* 326 */               if (decodeWritten != -1) {
/* 327 */                 this.state = State.READING_TAG;
/* 328 */                 this.written += decodeWritten;
/*     */                 continue;
/*     */               } 
/*     */               return;
/*     */ 
/*     */             
/*     */             case 3:
/* 335 */               decodeWritten = decodeCopyWith4ByteOffset(this.tag, in, out, this.written);
/* 336 */               if (decodeWritten != -1) {
/* 337 */                 this.state = State.READING_TAG;
/* 338 */                 this.written += decodeWritten;
/*     */                 continue;
/*     */               } 
/*     */               return;
/*     */           } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int readPreamble(ByteBuf in) {
/* 359 */     int length = 0;
/* 360 */     int byteIndex = 0;
/* 361 */     while (in.isReadable()) {
/* 362 */       int current = in.readUnsignedByte();
/* 363 */       length |= (current & 0x7F) << byteIndex++ * 7;
/* 364 */       if ((current & 0x80) == 0) {
/* 365 */         return length;
/*     */       }
/*     */       
/* 368 */       if (byteIndex >= 4) {
/* 369 */         throw new DecompressionException("Preamble is greater than 4 bytes");
/*     */       }
/*     */     } 
/*     */     
/* 373 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int getPreamble(ByteBuf in) {
/* 386 */     if (this.state == State.READING_PREAMBLE) {
/* 387 */       int readerIndex = in.readerIndex();
/*     */       try {
/* 389 */         return readPreamble(in);
/*     */       } finally {
/* 391 */         in.readerIndex(readerIndex);
/*     */       } 
/*     */     } 
/* 394 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static int decodeLiteral(byte tag, ByteBuf in, ByteBuf out) {
/*     */     int length;
/* 409 */     in.markReaderIndex();
/*     */     
/* 411 */     switch (tag >> 2 & 0x3F) {
/*     */       case 60:
/* 413 */         if (!in.isReadable()) {
/* 414 */           return -1;
/*     */         }
/* 416 */         length = in.readUnsignedByte();
/*     */         break;
/*     */       case 61:
/* 419 */         if (in.readableBytes() < 2) {
/* 420 */           return -1;
/*     */         }
/* 422 */         length = in.readUnsignedShortLE();
/*     */         break;
/*     */       case 62:
/* 425 */         if (in.readableBytes() < 3) {
/* 426 */           return -1;
/*     */         }
/* 428 */         length = in.readUnsignedMediumLE();
/*     */         break;
/*     */       case 63:
/* 431 */         if (in.readableBytes() < 4) {
/* 432 */           return -1;
/*     */         }
/* 434 */         length = in.readIntLE();
/*     */         break;
/*     */       default:
/* 437 */         length = tag >> 2 & 0x3F; break;
/*     */     } 
/* 439 */     length++;
/*     */     
/* 441 */     if (in.readableBytes() < length) {
/* 442 */       in.resetReaderIndex();
/* 443 */       return -1;
/*     */     } 
/*     */     
/* 446 */     out.writeBytes(in, length);
/* 447 */     return length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int decodeCopyWith1ByteOffset(byte tag, ByteBuf in, ByteBuf out, int writtenSoFar) {
/* 464 */     if (!in.isReadable()) {
/* 465 */       return -1;
/*     */     }
/*     */     
/* 468 */     int initialIndex = out.writerIndex();
/* 469 */     int length = 4 + ((tag & 0x1C) >> 2);
/* 470 */     int offset = (tag & 0xE0) << 8 >> 5 | in.readUnsignedByte();
/*     */     
/* 472 */     validateOffset(offset, writtenSoFar);
/*     */     
/* 474 */     out.markReaderIndex();
/* 475 */     if (offset < length) {
/* 476 */       int copies = length / offset;
/* 477 */       for (; copies > 0; copies--) {
/* 478 */         out.readerIndex(initialIndex - offset);
/* 479 */         out.readBytes(out, offset);
/*     */       } 
/* 481 */       if (length % offset != 0) {
/* 482 */         out.readerIndex(initialIndex - offset);
/* 483 */         out.readBytes(out, length % offset);
/*     */       } 
/*     */     } else {
/* 486 */       out.readerIndex(initialIndex - offset);
/* 487 */       out.readBytes(out, length);
/*     */     } 
/* 489 */     out.resetReaderIndex();
/*     */     
/* 491 */     return length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int decodeCopyWith2ByteOffset(byte tag, ByteBuf in, ByteBuf out, int writtenSoFar) {
/* 508 */     if (in.readableBytes() < 2) {
/* 509 */       return -1;
/*     */     }
/*     */     
/* 512 */     int initialIndex = out.writerIndex();
/* 513 */     int length = 1 + (tag >> 2 & 0x3F);
/* 514 */     int offset = in.readUnsignedShortLE();
/*     */     
/* 516 */     validateOffset(offset, writtenSoFar);
/*     */     
/* 518 */     out.markReaderIndex();
/* 519 */     if (offset < length) {
/* 520 */       int copies = length / offset;
/* 521 */       for (; copies > 0; copies--) {
/* 522 */         out.readerIndex(initialIndex - offset);
/* 523 */         out.readBytes(out, offset);
/*     */       } 
/* 525 */       if (length % offset != 0) {
/* 526 */         out.readerIndex(initialIndex - offset);
/* 527 */         out.readBytes(out, length % offset);
/*     */       } 
/*     */     } else {
/* 530 */       out.readerIndex(initialIndex - offset);
/* 531 */       out.readBytes(out, length);
/*     */     } 
/* 533 */     out.resetReaderIndex();
/*     */     
/* 535 */     return length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int decodeCopyWith4ByteOffset(byte tag, ByteBuf in, ByteBuf out, int writtenSoFar) {
/* 552 */     if (in.readableBytes() < 4) {
/* 553 */       return -1;
/*     */     }
/*     */     
/* 556 */     int initialIndex = out.writerIndex();
/* 557 */     int length = 1 + (tag >> 2 & 0x3F);
/* 558 */     int offset = in.readIntLE();
/*     */     
/* 560 */     validateOffset(offset, writtenSoFar);
/*     */     
/* 562 */     out.markReaderIndex();
/* 563 */     if (offset < length) {
/* 564 */       int copies = length / offset;
/* 565 */       for (; copies > 0; copies--) {
/* 566 */         out.readerIndex(initialIndex - offset);
/* 567 */         out.readBytes(out, offset);
/*     */       } 
/* 569 */       if (length % offset != 0) {
/* 570 */         out.readerIndex(initialIndex - offset);
/* 571 */         out.readBytes(out, length % offset);
/*     */       } 
/*     */     } else {
/* 574 */       out.readerIndex(initialIndex - offset);
/* 575 */       out.readBytes(out, length);
/*     */     } 
/* 577 */     out.resetReaderIndex();
/*     */     
/* 579 */     return length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void validateOffset(int offset, int chunkSizeSoFar) {
/* 592 */     if (offset == 0) {
/* 593 */       throw new DecompressionException("Offset is less than minimum permissible value");
/*     */     }
/*     */     
/* 596 */     if (offset < 0)
/*     */     {
/* 598 */       throw new DecompressionException("Offset is greater than maximum value supported by this implementation");
/*     */     }
/*     */     
/* 601 */     if (offset > chunkSizeSoFar) {
/* 602 */       throw new DecompressionException("Offset exceeds size of chunk");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static int calculateChecksum(ByteBuf data) {
/* 613 */     return calculateChecksum(data, data.readerIndex(), data.readableBytes());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static int calculateChecksum(ByteBuf data, int offset, int length) {
/* 623 */     Crc32c crc32 = new Crc32c();
/*     */     try {
/* 625 */       crc32.update(data, offset, length);
/* 626 */       return maskChecksum(crc32.getValue());
/*     */     } finally {
/* 628 */       crc32.reset();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void validateChecksum(int expectedChecksum, ByteBuf data) {
/* 642 */     validateChecksum(expectedChecksum, data, data.readerIndex(), data.readableBytes());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void validateChecksum(int expectedChecksum, ByteBuf data, int offset, int length) {
/* 655 */     int actualChecksum = calculateChecksum(data, offset, length);
/* 656 */     if (actualChecksum != expectedChecksum) {
/* 657 */       throw new DecompressionException("mismatching checksum: " + 
/* 658 */           Integer.toHexString(actualChecksum) + " (expected: " + 
/* 659 */           Integer.toHexString(expectedChecksum) + ')');
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static int maskChecksum(long checksum) {
/* 675 */     return (int)((checksum >> 15L | checksum << 17L) + -1568478504L);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-4.1.93.Final.jar!\io\netty\handler\codec\compression\Snappy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */