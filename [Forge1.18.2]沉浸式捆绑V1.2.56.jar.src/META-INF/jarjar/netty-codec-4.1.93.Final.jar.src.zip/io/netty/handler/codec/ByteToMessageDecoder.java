/*     */ package io.netty.handler.codec;
/*     */ 
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import io.netty.buffer.ByteBufAllocator;
/*     */ import io.netty.buffer.CompositeByteBuf;
/*     */ import io.netty.buffer.Unpooled;
/*     */ import io.netty.channel.ChannelHandlerContext;
/*     */ import io.netty.channel.ChannelInboundHandlerAdapter;
/*     */ import io.netty.util.IllegalReferenceCountException;
/*     */ import io.netty.util.internal.ObjectUtil;
/*     */ import io.netty.util.internal.StringUtil;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ByteToMessageDecoder
/*     */   extends ChannelInboundHandlerAdapter
/*     */ {
/*  81 */   public static final Cumulator MERGE_CUMULATOR = new Cumulator()
/*     */     {
/*     */       public ByteBuf cumulate(ByteBufAllocator alloc, ByteBuf cumulation, ByteBuf in) {
/*  84 */         if (cumulation == in) {
/*     */           
/*  86 */           in.release();
/*  87 */           return cumulation;
/*     */         } 
/*  89 */         if (!cumulation.isReadable() && in.isContiguous()) {
/*     */           
/*  91 */           cumulation.release();
/*  92 */           return in;
/*     */         } 
/*     */         try {
/*  95 */           int required = in.readableBytes();
/*  96 */           if (required > cumulation.maxWritableBytes() || (required > cumulation
/*  97 */             .maxFastWritableBytes() && cumulation.refCnt() > 1) || cumulation
/*  98 */             .isReadOnly())
/*     */           {
/*     */ 
/*     */ 
/*     */             
/* 103 */             return ByteToMessageDecoder.expandCumulation(alloc, cumulation, in);
/*     */           }
/* 105 */           cumulation.writeBytes(in, in.readerIndex(), required);
/* 106 */           in.readerIndex(in.writerIndex());
/* 107 */           return cumulation;
/*     */         }
/*     */         finally {
/*     */           
/* 111 */           in.release();
/*     */         } 
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 121 */   public static final Cumulator COMPOSITE_CUMULATOR = new Cumulator()
/*     */     {
/*     */       public ByteBuf cumulate(ByteBufAllocator alloc, ByteBuf cumulation, ByteBuf in) {
/* 124 */         if (cumulation == in) {
/*     */           
/* 126 */           in.release();
/* 127 */           return cumulation;
/*     */         } 
/* 129 */         if (!cumulation.isReadable()) {
/* 130 */           cumulation.release();
/* 131 */           return in;
/*     */         } 
/* 133 */         CompositeByteBuf composite = null;
/*     */         try {
/* 135 */           if (cumulation instanceof CompositeByteBuf && cumulation.refCnt() == 1) {
/* 136 */             composite = (CompositeByteBuf)cumulation;
/*     */ 
/*     */             
/* 139 */             if (composite.writerIndex() != composite.capacity()) {
/* 140 */               composite.capacity(composite.writerIndex());
/*     */             }
/*     */           } else {
/* 143 */             composite = alloc.compositeBuffer(2147483647).addFlattenedComponents(true, cumulation);
/*     */           } 
/* 145 */           composite.addFlattenedComponents(true, in);
/* 146 */           in = null;
/* 147 */           return (ByteBuf)composite;
/*     */         } finally {
/* 149 */           if (in != null) {
/*     */             
/* 151 */             in.release();
/*     */             
/* 153 */             if (composite != null && composite != cumulation) {
/* 154 */               composite.release();
/*     */             }
/*     */           } 
/*     */         } 
/*     */       }
/*     */     };
/*     */ 
/*     */   
/*     */   private static final byte STATE_INIT = 0;
/*     */   private static final byte STATE_CALLING_CHILD_DECODE = 1;
/*     */   private static final byte STATE_HANDLER_REMOVED_PENDING = 2;
/*     */   ByteBuf cumulation;
/* 166 */   private Cumulator cumulator = MERGE_CUMULATOR;
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean singleDecode;
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean first;
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean firedChannelRead;
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean selfFiredChannelRead;
/*     */ 
/*     */ 
/*     */   
/* 186 */   private byte decodeState = 0;
/* 187 */   private int discardAfterReads = 16;
/*     */   private int numReads;
/*     */   
/*     */   protected ByteToMessageDecoder() {
/* 191 */     ensureNotSharable();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSingleDecode(boolean singleDecode) {
/* 201 */     this.singleDecode = singleDecode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSingleDecode() {
/* 211 */     return this.singleDecode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCumulator(Cumulator cumulator) {
/* 218 */     this.cumulator = (Cumulator)ObjectUtil.checkNotNull(cumulator, "cumulator");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDiscardAfterReads(int discardAfterReads) {
/* 226 */     ObjectUtil.checkPositive(discardAfterReads, "discardAfterReads");
/* 227 */     this.discardAfterReads = discardAfterReads;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int actualReadableBytes() {
/* 237 */     return internalBuffer().readableBytes();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ByteBuf internalBuffer() {
/* 246 */     if (this.cumulation != null) {
/* 247 */       return this.cumulation;
/*     */     }
/* 249 */     return Unpooled.EMPTY_BUFFER;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final void handlerRemoved(ChannelHandlerContext ctx) throws Exception {
/* 255 */     if (this.decodeState == 1) {
/* 256 */       this.decodeState = 2;
/*     */       return;
/*     */     } 
/* 259 */     ByteBuf buf = this.cumulation;
/* 260 */     if (buf != null) {
/*     */       
/* 262 */       this.cumulation = null;
/* 263 */       this.numReads = 0;
/* 264 */       int readable = buf.readableBytes();
/* 265 */       if (readable > 0) {
/* 266 */         ctx.fireChannelRead(buf);
/* 267 */         ctx.fireChannelReadComplete();
/*     */       } else {
/* 269 */         buf.release();
/*     */       } 
/*     */     } 
/* 272 */     handlerRemoved0(ctx);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void handlerRemoved0(ChannelHandlerContext ctx) throws Exception {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void channelRead(ChannelHandlerContext ctx, Object msg) throws Exception {
/* 283 */     if (msg instanceof ByteBuf) {
/* 284 */       this.selfFiredChannelRead = true;
/* 285 */       CodecOutputList out = CodecOutputList.newInstance();
/*     */       try {
/* 287 */         this.first = (this.cumulation == null);
/* 288 */         this.cumulation = this.cumulator.cumulate(ctx.alloc(), this.first ? Unpooled.EMPTY_BUFFER : this.cumulation, (ByteBuf)msg);
/*     */         
/* 290 */         callDecode(ctx, this.cumulation, out);
/* 291 */       } catch (DecoderException e) {
/* 292 */         throw e;
/* 293 */       } catch (Exception e) {
/* 294 */         throw new DecoderException(e);
/*     */       } finally {
/*     */         try {
/* 297 */           if (this.cumulation != null && !this.cumulation.isReadable()) {
/* 298 */             this.numReads = 0;
/*     */             try {
/* 300 */               this.cumulation.release();
/* 301 */             } catch (IllegalReferenceCountException e) {
/*     */               
/* 303 */               throw new IllegalReferenceCountException(
/* 304 */                   getClass().getSimpleName() + "#decode() might have released its input buffer, or passed it down the pipeline without a retain() call, which is not allowed.", e);
/*     */             } 
/*     */ 
/*     */             
/* 308 */             this.cumulation = null;
/* 309 */           } else if (++this.numReads >= this.discardAfterReads) {
/*     */ 
/*     */             
/* 312 */             this.numReads = 0;
/* 313 */             discardSomeReadBytes();
/*     */           } 
/*     */           
/* 316 */           int size = out.size();
/* 317 */           this.firedChannelRead |= out.insertSinceRecycled();
/* 318 */           fireChannelRead(ctx, out, size);
/*     */         } finally {
/* 320 */           out.recycle();
/*     */         } 
/*     */       } 
/*     */     } else {
/* 324 */       ctx.fireChannelRead(msg);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void fireChannelRead(ChannelHandlerContext ctx, List<Object> msgs, int numElements) {
/* 332 */     if (msgs instanceof CodecOutputList) {
/* 333 */       fireChannelRead(ctx, (CodecOutputList)msgs, numElements);
/*     */     } else {
/* 335 */       for (int i = 0; i < numElements; i++) {
/* 336 */         ctx.fireChannelRead(msgs.get(i));
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void fireChannelRead(ChannelHandlerContext ctx, CodecOutputList msgs, int numElements) {
/* 345 */     for (int i = 0; i < numElements; i++) {
/* 346 */       ctx.fireChannelRead(msgs.getUnsafe(i));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void channelReadComplete(ChannelHandlerContext ctx) throws Exception {
/* 352 */     this.numReads = 0;
/* 353 */     discardSomeReadBytes();
/* 354 */     if (this.selfFiredChannelRead && !this.firedChannelRead && !ctx.channel().config().isAutoRead()) {
/* 355 */       ctx.read();
/*     */     }
/* 357 */     this.firedChannelRead = false;
/* 358 */     ctx.fireChannelReadComplete();
/*     */   }
/*     */   
/*     */   protected final void discardSomeReadBytes() {
/* 362 */     if (this.cumulation != null && !this.first && this.cumulation.refCnt() == 1)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 370 */       this.cumulation.discardSomeReadBytes();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void channelInactive(ChannelHandlerContext ctx) throws Exception {
/* 376 */     channelInputClosed(ctx, true);
/*     */   }
/*     */ 
/*     */   
/*     */   public void userEventTriggered(ChannelHandlerContext ctx, Object evt) throws Exception {
/* 381 */     if (evt instanceof io.netty.channel.socket.ChannelInputShutdownEvent)
/*     */     {
/*     */ 
/*     */       
/* 385 */       channelInputClosed(ctx, false);
/*     */     }
/* 387 */     super.userEventTriggered(ctx, evt);
/*     */   }
/*     */   
/*     */   private void channelInputClosed(ChannelHandlerContext ctx, boolean callChannelInactive) {
/* 391 */     CodecOutputList out = CodecOutputList.newInstance();
/*     */     try {
/* 393 */       channelInputClosed(ctx, out);
/* 394 */     } catch (DecoderException e) {
/* 395 */       throw e;
/* 396 */     } catch (Exception e) {
/* 397 */       throw new DecoderException(e);
/*     */     } finally {
/*     */       try {
/* 400 */         if (this.cumulation != null) {
/* 401 */           this.cumulation.release();
/* 402 */           this.cumulation = null;
/*     */         } 
/* 404 */         int size = out.size();
/* 405 */         fireChannelRead(ctx, out, size);
/* 406 */         if (size > 0)
/*     */         {
/* 408 */           ctx.fireChannelReadComplete();
/*     */         }
/* 410 */         if (callChannelInactive) {
/* 411 */           ctx.fireChannelInactive();
/*     */         }
/*     */       } finally {
/*     */         
/* 415 */         out.recycle();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void channelInputClosed(ChannelHandlerContext ctx, List<Object> out) throws Exception {
/* 425 */     if (this.cumulation != null) {
/* 426 */       callDecode(ctx, this.cumulation, out);
/*     */ 
/*     */       
/* 429 */       if (!ctx.isRemoved()) {
/*     */ 
/*     */         
/* 432 */         ByteBuf buffer = (this.cumulation == null) ? Unpooled.EMPTY_BUFFER : this.cumulation;
/* 433 */         decodeLast(ctx, buffer, out);
/*     */       } 
/*     */     } else {
/* 436 */       decodeLast(ctx, Unpooled.EMPTY_BUFFER, out);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void callDecode(ChannelHandlerContext ctx, ByteBuf in, List<Object> out) {
/*     */     try {
/* 450 */       while (in.isReadable()) {
/* 451 */         int outSize = out.size();
/*     */         
/* 453 */         if (outSize > 0) {
/* 454 */           fireChannelRead(ctx, out, outSize);
/* 455 */           out.clear();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 462 */           if (ctx.isRemoved()) {
/*     */             break;
/*     */           }
/*     */         } 
/*     */         
/* 467 */         int oldInputLength = in.readableBytes();
/* 468 */         decodeRemovalReentryProtection(ctx, in, out);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 474 */         if (ctx.isRemoved()) {
/*     */           break;
/*     */         }
/*     */         
/* 478 */         if (out.isEmpty()) {
/* 479 */           if (oldInputLength == in.readableBytes()) {
/*     */             break;
/*     */           }
/*     */           
/*     */           continue;
/*     */         } 
/*     */         
/* 486 */         if (oldInputLength == in.readableBytes()) {
/* 487 */           throw new DecoderException(
/* 488 */               StringUtil.simpleClassName(getClass()) + ".decode() did not read anything but decoded a message.");
/*     */         }
/*     */ 
/*     */         
/* 492 */         if (isSingleDecode()) {
/*     */           break;
/*     */         }
/*     */       } 
/* 496 */     } catch (DecoderException e) {
/* 497 */       throw e;
/* 498 */     } catch (Exception cause) {
/* 499 */       throw new DecoderException(cause);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract void decode(ChannelHandlerContext paramChannelHandlerContext, ByteBuf paramByteBuf, List<Object> paramList) throws Exception;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final void decodeRemovalReentryProtection(ChannelHandlerContext ctx, ByteBuf in, List<Object> out) throws Exception {
/* 527 */     this.decodeState = 1;
/*     */     try {
/* 529 */       decode(ctx, in, out);
/*     */     } finally {
/* 531 */       boolean removePending = (this.decodeState == 2);
/* 532 */       this.decodeState = 0;
/* 533 */       if (removePending) {
/* 534 */         fireChannelRead(ctx, out, out.size());
/* 535 */         out.clear();
/* 536 */         handlerRemoved(ctx);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void decodeLast(ChannelHandlerContext ctx, ByteBuf in, List<Object> out) throws Exception {
/* 549 */     if (in.isReadable())
/*     */     {
/*     */       
/* 552 */       decodeRemovalReentryProtection(ctx, in, out);
/*     */     }
/*     */   }
/*     */   
/*     */   static ByteBuf expandCumulation(ByteBufAllocator alloc, ByteBuf oldCumulation, ByteBuf in) {
/* 557 */     int oldBytes = oldCumulation.readableBytes();
/* 558 */     int newBytes = in.readableBytes();
/* 559 */     int totalBytes = oldBytes + newBytes;
/* 560 */     ByteBuf newCumulation = alloc.buffer(alloc.calculateNewCapacity(totalBytes, 2147483647));
/* 561 */     ByteBuf toRelease = newCumulation;
/*     */     
/*     */     try {
/* 564 */       newCumulation.setBytes(0, oldCumulation, oldCumulation.readerIndex(), oldBytes)
/* 565 */         .setBytes(oldBytes, in, in.readerIndex(), newBytes)
/* 566 */         .writerIndex(totalBytes);
/* 567 */       in.readerIndex(in.writerIndex());
/* 568 */       toRelease = oldCumulation;
/* 569 */       return newCumulation;
/*     */     } finally {
/* 571 */       toRelease.release();
/*     */     } 
/*     */   }
/*     */   
/*     */   public static interface Cumulator {
/*     */     ByteBuf cumulate(ByteBufAllocator param1ByteBufAllocator, ByteBuf param1ByteBuf1, ByteBuf param1ByteBuf2);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-4.1.93.Final.jar!\io\netty\handler\codec\ByteToMessageDecoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */