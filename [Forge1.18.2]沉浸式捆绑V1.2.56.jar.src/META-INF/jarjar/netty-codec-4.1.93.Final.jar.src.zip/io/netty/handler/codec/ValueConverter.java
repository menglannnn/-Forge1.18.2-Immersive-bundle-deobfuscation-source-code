package io.netty.handler.codec;

public interface ValueConverter<T> {
  T convertObject(Object paramObject);
  
  T convertBoolean(boolean paramBoolean);
  
  boolean convertToBoolean(T paramT);
  
  T convertByte(byte paramByte);
  
  byte convertToByte(T paramT);
  
  T convertChar(char paramChar);
  
  char convertToChar(T paramT);
  
  T convertShort(short paramShort);
  
  short convertToShort(T paramT);
  
  T convertInt(int paramInt);
  
  int convertToInt(T paramT);
  
  T convertLong(long paramLong);
  
  long convertToLong(T paramT);
  
  T convertTimeMillis(long paramLong);
  
  long convertToTimeMillis(T paramT);
  
  T convertFloat(float paramFloat);
  
  float convertToFloat(T paramT);
  
  T convertDouble(double paramDouble);
  
  double convertToDouble(T paramT);
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-4.1.93.Final.jar!\io\netty\handler\codec\ValueConverter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */