/*     */ package io.netty.handler.codec.compression;
/*     */ 
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import io.netty.channel.ChannelFuture;
/*     */ import io.netty.channel.ChannelHandlerContext;
/*     */ import io.netty.channel.ChannelPromise;
/*     */ import io.netty.handler.codec.MessageToByteEncoder;
/*     */ import io.netty.util.concurrent.EventExecutor;
/*     */ import io.netty.util.concurrent.Future;
/*     */ import io.netty.util.concurrent.Promise;
/*     */ import io.netty.util.concurrent.PromiseNotifier;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Bzip2Encoder
/*     */   extends MessageToByteEncoder<ByteBuf>
/*     */ {
/*     */   private enum State
/*     */   {
/*  44 */     INIT,
/*  45 */     INIT_BLOCK,
/*  46 */     WRITE_DATA,
/*  47 */     CLOSE_BLOCK;
/*     */   }
/*     */   
/*  50 */   private State currentState = State.INIT;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  55 */   private final Bzip2BitWriter writer = new Bzip2BitWriter();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final int streamBlockSize;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int streamCRC;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Bzip2BlockCompressor blockCompressor;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private volatile boolean finished;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private volatile ChannelHandlerContext ctx;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Bzip2Encoder() {
/*  86 */     this(9);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Bzip2Encoder(int blockSizeMultiplier) {
/*  97 */     if (blockSizeMultiplier < 1 || blockSizeMultiplier > 9) {
/*  98 */       throw new IllegalArgumentException("blockSizeMultiplier: " + blockSizeMultiplier + " (expected: 1-9)");
/*     */     }
/*     */     
/* 101 */     this.streamBlockSize = blockSizeMultiplier * 100000;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void encode(ChannelHandlerContext ctx, ByteBuf in, ByteBuf out) throws Exception {
/* 106 */     if (this.finished) {
/* 107 */       out.writeBytes(in); return;
/*     */     }  while (true) {
/*     */       Bzip2BlockCompressor blockCompressor;
/*     */       int length;
/*     */       int bytesWritten;
/* 112 */       switch (this.currentState) {
/*     */         case INIT:
/* 114 */           out.ensureWritable(4);
/* 115 */           out.writeMedium(4348520);
/* 116 */           out.writeByte(48 + this.streamBlockSize / 100000);
/* 117 */           this.currentState = State.INIT_BLOCK;
/*     */         
/*     */         case INIT_BLOCK:
/* 120 */           this.blockCompressor = new Bzip2BlockCompressor(this.writer, this.streamBlockSize);
/* 121 */           this.currentState = State.WRITE_DATA;
/*     */         
/*     */         case WRITE_DATA:
/* 124 */           if (!in.isReadable()) {
/*     */             return;
/*     */           }
/* 127 */           blockCompressor = this.blockCompressor;
/* 128 */           length = Math.min(in.readableBytes(), blockCompressor.availableSize());
/* 129 */           bytesWritten = blockCompressor.write(in, in.readerIndex(), length);
/* 130 */           in.skipBytes(bytesWritten);
/* 131 */           if (!blockCompressor.isFull()) {
/* 132 */             if (in.isReadable()) {
/*     */               continue;
/*     */             }
/*     */             
/*     */             return;
/*     */           } 
/* 138 */           this.currentState = State.CLOSE_BLOCK;
/*     */         
/*     */         case CLOSE_BLOCK:
/* 141 */           closeBlock(out);
/* 142 */           this.currentState = State.INIT_BLOCK; continue;
/*     */       }  break;
/*     */     } 
/* 145 */     throw new IllegalStateException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void closeBlock(ByteBuf out) {
/* 154 */     Bzip2BlockCompressor blockCompressor = this.blockCompressor;
/* 155 */     if (!blockCompressor.isEmpty()) {
/* 156 */       blockCompressor.close(out);
/* 157 */       int blockCRC = blockCompressor.crc();
/* 158 */       this.streamCRC = (this.streamCRC << 1 | this.streamCRC >>> 31) ^ blockCRC;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isClosed() {
/* 166 */     return this.finished;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ChannelFuture close() {
/* 175 */     return close(ctx().newPromise());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ChannelFuture close(final ChannelPromise promise) {
/* 184 */     ChannelHandlerContext ctx = ctx();
/* 185 */     EventExecutor executor = ctx.executor();
/* 186 */     if (executor.inEventLoop()) {
/* 187 */       return finishEncode(ctx, promise);
/*     */     }
/* 189 */     executor.execute(new Runnable()
/*     */         {
/*     */           public void run() {
/* 192 */             ChannelFuture f = Bzip2Encoder.this.finishEncode(Bzip2Encoder.this.ctx(), promise);
/* 193 */             PromiseNotifier.cascade((Future)f, (Promise)promise);
/*     */           }
/*     */         });
/* 196 */     return (ChannelFuture)promise;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void close(ChannelHandlerContext ctx, ChannelPromise promise) throws Exception {
/* 202 */     ChannelFuture f = finishEncode(ctx, ctx.newPromise());
/* 203 */     EncoderUtil.closeAfterFinishEncode(ctx, f, promise);
/*     */   }
/*     */   
/*     */   private ChannelFuture finishEncode(ChannelHandlerContext ctx, ChannelPromise promise) {
/* 207 */     if (this.finished) {
/* 208 */       promise.setSuccess();
/* 209 */       return (ChannelFuture)promise;
/*     */     } 
/* 211 */     this.finished = true;
/*     */     
/* 213 */     ByteBuf footer = ctx.alloc().buffer();
/* 214 */     closeBlock(footer);
/*     */     
/* 216 */     int streamCRC = this.streamCRC;
/* 217 */     Bzip2BitWriter writer = this.writer;
/*     */     try {
/* 219 */       writer.writeBits(footer, 24, 1536581L);
/* 220 */       writer.writeBits(footer, 24, 3690640L);
/* 221 */       writer.writeInt(footer, streamCRC);
/* 222 */       writer.flush(footer);
/*     */     } finally {
/* 224 */       this.blockCompressor = null;
/*     */     } 
/* 226 */     return ctx.writeAndFlush(footer, promise);
/*     */   }
/*     */   
/*     */   private ChannelHandlerContext ctx() {
/* 230 */     ChannelHandlerContext ctx = this.ctx;
/* 231 */     if (ctx == null) {
/* 232 */       throw new IllegalStateException("not added to a pipeline");
/*     */     }
/* 234 */     return ctx;
/*     */   }
/*     */ 
/*     */   
/*     */   public void handlerAdded(ChannelHandlerContext ctx) throws Exception {
/* 239 */     this.ctx = ctx;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-4.1.93.Final.jar!\io\netty\handler\codec\compression\Bzip2Encoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */