package io.netty.handler.codec.compression;

final class ZstdConstants {
  static final int DEFAULT_COMPRESSION_LEVEL = 3;
  
  static final int MAX_COMPRESSION_LEVEL = 22;
  
  static final int MAX_BLOCK_SIZE = 33554432;
  
  static final int DEFAULT_BLOCK_SIZE = 65536;
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-4.1.93.Final.jar!\io\netty\handler\codec\compression\ZstdConstants.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */