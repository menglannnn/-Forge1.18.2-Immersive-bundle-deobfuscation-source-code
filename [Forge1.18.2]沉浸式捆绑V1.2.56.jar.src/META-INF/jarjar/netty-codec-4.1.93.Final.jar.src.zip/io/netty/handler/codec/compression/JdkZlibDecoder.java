/*     */ package io.netty.handler.codec.compression;
/*     */ 
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import io.netty.channel.ChannelHandlerContext;
/*     */ import io.netty.util.internal.ObjectUtil;
/*     */ import java.util.List;
/*     */ import java.util.zip.CRC32;
/*     */ import java.util.zip.DataFormatException;
/*     */ import java.util.zip.Inflater;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JdkZlibDecoder
/*     */   extends ZlibDecoder
/*     */ {
/*     */   private static final int FHCRC = 2;
/*     */   private static final int FEXTRA = 4;
/*     */   private static final int FNAME = 8;
/*     */   private static final int FCOMMENT = 16;
/*     */   private static final int FRESERVED = 224;
/*     */   private Inflater inflater;
/*     */   private final byte[] dictionary;
/*     */   private final ByteBufChecksum crc;
/*     */   private final boolean decompressConcatenated;
/*     */   
/*     */   private enum GzipState
/*     */   {
/*  47 */     HEADER_START,
/*  48 */     HEADER_END,
/*  49 */     FLG_READ,
/*  50 */     XLEN_READ,
/*  51 */     SKIP_FNAME,
/*  52 */     SKIP_COMMENT,
/*  53 */     PROCESS_FHCRC,
/*  54 */     FOOTER_START;
/*     */   }
/*     */   
/*  57 */   private GzipState gzipState = GzipState.HEADER_START;
/*  58 */   private int flags = -1;
/*  59 */   private int xlen = -1;
/*     */ 
/*     */   
/*     */   private volatile boolean finished;
/*     */ 
/*     */   
/*     */   private boolean decideZlibOrNone;
/*     */ 
/*     */   
/*     */   public JdkZlibDecoder() {
/*  69 */     this(ZlibWrapper.ZLIB, null, false, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JdkZlibDecoder(int maxAllocation) {
/*  81 */     this(ZlibWrapper.ZLIB, null, false, maxAllocation);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JdkZlibDecoder(byte[] dictionary) {
/*  90 */     this(ZlibWrapper.ZLIB, dictionary, false, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JdkZlibDecoder(byte[] dictionary, int maxAllocation) {
/* 103 */     this(ZlibWrapper.ZLIB, dictionary, false, maxAllocation);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JdkZlibDecoder(ZlibWrapper wrapper) {
/* 112 */     this(wrapper, null, false, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JdkZlibDecoder(ZlibWrapper wrapper, int maxAllocation) {
/* 125 */     this(wrapper, null, false, maxAllocation);
/*     */   }
/*     */   
/*     */   public JdkZlibDecoder(ZlibWrapper wrapper, boolean decompressConcatenated) {
/* 129 */     this(wrapper, null, decompressConcatenated, 0);
/*     */   }
/*     */   
/*     */   public JdkZlibDecoder(ZlibWrapper wrapper, boolean decompressConcatenated, int maxAllocation) {
/* 133 */     this(wrapper, null, decompressConcatenated, maxAllocation);
/*     */   }
/*     */   
/*     */   public JdkZlibDecoder(boolean decompressConcatenated) {
/* 137 */     this(ZlibWrapper.GZIP, null, decompressConcatenated, 0);
/*     */   }
/*     */   
/*     */   public JdkZlibDecoder(boolean decompressConcatenated, int maxAllocation) {
/* 141 */     this(ZlibWrapper.GZIP, null, decompressConcatenated, maxAllocation);
/*     */   }
/*     */   
/*     */   private JdkZlibDecoder(ZlibWrapper wrapper, byte[] dictionary, boolean decompressConcatenated, int maxAllocation) {
/* 145 */     super(maxAllocation);
/*     */     
/* 147 */     ObjectUtil.checkNotNull(wrapper, "wrapper");
/*     */     
/* 149 */     this.decompressConcatenated = decompressConcatenated;
/* 150 */     switch (wrapper) {
/*     */       case HEADER_START:
/* 152 */         this.inflater = new Inflater(true);
/* 153 */         this.crc = ByteBufChecksum.wrapChecksum(new CRC32());
/*     */         break;
/*     */       case FLG_READ:
/* 156 */         this.inflater = new Inflater(true);
/* 157 */         this.crc = null;
/*     */         break;
/*     */       case XLEN_READ:
/* 160 */         this.inflater = new Inflater();
/* 161 */         this.crc = null;
/*     */         break;
/*     */       
/*     */       case SKIP_FNAME:
/* 165 */         this.decideZlibOrNone = true;
/* 166 */         this.crc = null;
/*     */         break;
/*     */       default:
/* 169 */         throw new IllegalArgumentException("Only GZIP or ZLIB is supported, but you used " + wrapper);
/*     */     } 
/* 171 */     this.dictionary = dictionary;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isClosed() {
/* 176 */     return this.finished;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void decode(ChannelHandlerContext ctx, ByteBuf in, List<Object> out) throws Exception {
/* 181 */     if (this.finished) {
/*     */       
/* 183 */       in.skipBytes(in.readableBytes());
/*     */       
/*     */       return;
/*     */     } 
/* 187 */     int readableBytes = in.readableBytes();
/* 188 */     if (readableBytes == 0) {
/*     */       return;
/*     */     }
/*     */     
/* 192 */     if (this.decideZlibOrNone) {
/*     */       
/* 194 */       if (readableBytes < 2) {
/*     */         return;
/*     */       }
/*     */       
/* 198 */       boolean nowrap = !looksLikeZlib(in.getShort(in.readerIndex()));
/* 199 */       this.inflater = new Inflater(nowrap);
/* 200 */       this.decideZlibOrNone = false;
/*     */     } 
/*     */     
/* 203 */     if (this.crc != null && 
/* 204 */       this.gzipState != GzipState.HEADER_END) {
/* 205 */       if (this.gzipState == GzipState.FOOTER_START) {
/* 206 */         if (!handleGzipFooter(in)) {
/*     */           return;
/*     */         }
/*     */ 
/*     */         
/* 211 */         assert this.gzipState == GzipState.HEADER_START;
/*     */       } 
/* 213 */       if (!readGZIPHeader(in)) {
/*     */         return;
/*     */       }
/*     */ 
/*     */       
/* 218 */       readableBytes = in.readableBytes();
/* 219 */       if (readableBytes == 0) {
/*     */         return;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 225 */     if (this.inflater.needsInput()) {
/* 226 */       if (in.hasArray()) {
/* 227 */         this.inflater.setInput(in.array(), in.arrayOffset() + in.readerIndex(), readableBytes);
/*     */       } else {
/* 229 */         byte[] array = new byte[readableBytes];
/* 230 */         in.getBytes(in.readerIndex(), array);
/* 231 */         this.inflater.setInput(array);
/*     */       } 
/*     */     }
/*     */     
/* 235 */     ByteBuf decompressed = prepareDecompressBuffer(ctx, (ByteBuf)null, this.inflater.getRemaining() << 1);
/*     */     try {
/* 237 */       boolean readFooter = false;
/* 238 */       while (!this.inflater.needsInput()) {
/* 239 */         byte[] outArray = decompressed.array();
/* 240 */         int writerIndex = decompressed.writerIndex();
/* 241 */         int outIndex = decompressed.arrayOffset() + writerIndex;
/* 242 */         int writable = decompressed.writableBytes();
/* 243 */         int outputLength = this.inflater.inflate(outArray, outIndex, writable);
/* 244 */         if (outputLength > 0) {
/* 245 */           decompressed.writerIndex(writerIndex + outputLength);
/* 246 */           if (this.crc != null) {
/* 247 */             this.crc.update(outArray, outIndex, outputLength);
/*     */           }
/* 249 */         } else if (this.inflater.needsDictionary()) {
/* 250 */           if (this.dictionary == null) {
/* 251 */             throw new DecompressionException("decompression failure, unable to set dictionary as non was specified");
/*     */           }
/*     */           
/* 254 */           this.inflater.setDictionary(this.dictionary);
/*     */         } 
/*     */         
/* 257 */         if (this.inflater.finished()) {
/* 258 */           if (this.crc == null) {
/* 259 */             this.finished = true; break;
/*     */           } 
/* 261 */           readFooter = true;
/*     */           
/*     */           break;
/*     */         } 
/* 265 */         decompressed = prepareDecompressBuffer(ctx, decompressed, this.inflater.getRemaining() << 1);
/*     */       } 
/*     */ 
/*     */       
/* 269 */       in.skipBytes(readableBytes - this.inflater.getRemaining());
/*     */       
/* 271 */       if (readFooter) {
/* 272 */         this.gzipState = GzipState.FOOTER_START;
/* 273 */         handleGzipFooter(in);
/*     */       } 
/* 275 */     } catch (DataFormatException e) {
/* 276 */       throw new DecompressionException("decompression failure", e);
/*     */     } finally {
/* 278 */       if (decompressed.isReadable()) {
/* 279 */         out.add(decompressed);
/*     */       } else {
/* 281 */         decompressed.release();
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean handleGzipFooter(ByteBuf in) {
/* 287 */     if (readGZIPFooter(in)) {
/* 288 */       this.finished = !this.decompressConcatenated;
/*     */       
/* 290 */       if (!this.finished) {
/* 291 */         this.inflater.reset();
/* 292 */         this.crc.reset();
/* 293 */         this.gzipState = GzipState.HEADER_START;
/* 294 */         return true;
/*     */       } 
/*     */     } 
/* 297 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void decompressionBufferExhausted(ByteBuf buffer) {
/* 302 */     this.finished = true;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void handlerRemoved0(ChannelHandlerContext ctx) throws Exception {
/* 307 */     super.handlerRemoved0(ctx);
/* 308 */     if (this.inflater != null)
/* 309 */       this.inflater.end(); 
/*     */   } private boolean readGZIPHeader(ByteBuf in) {
/*     */     int magic0;
/*     */     int magic1;
/*     */     int method;
/* 314 */     switch (this.gzipState) {
/*     */       case HEADER_START:
/* 316 */         if (in.readableBytes() < 10) {
/* 317 */           return false;
/*     */         }
/*     */         
/* 320 */         magic0 = in.readByte();
/* 321 */         magic1 = in.readByte();
/*     */         
/* 323 */         if (magic0 != 31) {
/* 324 */           throw new DecompressionException("Input is not in the GZIP format");
/*     */         }
/* 326 */         this.crc.update(magic0);
/* 327 */         this.crc.update(magic1);
/*     */         
/* 329 */         method = in.readUnsignedByte();
/* 330 */         if (method != 8) {
/* 331 */           throw new DecompressionException("Unsupported compression method " + method + " in the GZIP header");
/*     */         }
/*     */         
/* 334 */         this.crc.update(method);
/*     */         
/* 336 */         this.flags = in.readUnsignedByte();
/* 337 */         this.crc.update(this.flags);
/*     */         
/* 339 */         if ((this.flags & 0xE0) != 0) {
/* 340 */           throw new DecompressionException("Reserved flags are set in the GZIP header");
/*     */         }
/*     */ 
/*     */ 
/*     */         
/* 345 */         this.crc.update(in, in.readerIndex(), 4);
/* 346 */         in.skipBytes(4);
/*     */         
/* 348 */         this.crc.update(in.readUnsignedByte());
/* 349 */         this.crc.update(in.readUnsignedByte());
/*     */         
/* 351 */         this.gzipState = GzipState.FLG_READ;
/*     */       
/*     */       case FLG_READ:
/* 354 */         if ((this.flags & 0x4) != 0) {
/* 355 */           if (in.readableBytes() < 2) {
/* 356 */             return false;
/*     */           }
/* 358 */           int xlen1 = in.readUnsignedByte();
/* 359 */           int xlen2 = in.readUnsignedByte();
/* 360 */           this.crc.update(xlen1);
/* 361 */           this.crc.update(xlen2);
/*     */           
/* 363 */           this.xlen |= xlen1 << 8 | xlen2;
/*     */         } 
/* 365 */         this.gzipState = GzipState.XLEN_READ;
/*     */       
/*     */       case XLEN_READ:
/* 368 */         if (this.xlen != -1) {
/* 369 */           if (in.readableBytes() < this.xlen) {
/* 370 */             return false;
/*     */           }
/* 372 */           this.crc.update(in, in.readerIndex(), this.xlen);
/* 373 */           in.skipBytes(this.xlen);
/*     */         } 
/* 375 */         this.gzipState = GzipState.SKIP_FNAME;
/*     */       
/*     */       case SKIP_FNAME:
/* 378 */         if (!skipIfNeeded(in, 8)) {
/* 379 */           return false;
/*     */         }
/* 381 */         this.gzipState = GzipState.SKIP_COMMENT;
/*     */       
/*     */       case SKIP_COMMENT:
/* 384 */         if (!skipIfNeeded(in, 16)) {
/* 385 */           return false;
/*     */         }
/* 387 */         this.gzipState = GzipState.PROCESS_FHCRC;
/*     */       
/*     */       case PROCESS_FHCRC:
/* 390 */         if ((this.flags & 0x2) != 0 && 
/* 391 */           !verifyCrc16(in)) {
/* 392 */           return false;
/*     */         }
/*     */         
/* 395 */         this.crc.reset();
/* 396 */         this.gzipState = GzipState.HEADER_END;
/*     */       
/*     */       case HEADER_END:
/* 399 */         return true;
/*     */     } 
/* 401 */     throw new IllegalStateException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean skipIfNeeded(ByteBuf in, int flagMask) {
/* 413 */     if ((this.flags & flagMask) != 0) {
/*     */       int b; do {
/* 415 */         if (!in.isReadable())
/*     */         {
/* 417 */           return false;
/*     */         }
/* 419 */         b = in.readUnsignedByte();
/* 420 */         this.crc.update(b);
/* 421 */       } while (b != 0);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 427 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean readGZIPFooter(ByteBuf in) {
/* 438 */     if (in.readableBytes() < 8) {
/* 439 */       return false;
/*     */     }
/*     */     
/* 442 */     boolean enoughData = verifyCrc(in);
/* 443 */     assert enoughData;
/*     */ 
/*     */     
/* 446 */     int dataLength = 0;
/* 447 */     for (int i = 0; i < 4; i++) {
/* 448 */       dataLength |= in.readUnsignedByte() << i * 8;
/*     */     }
/* 450 */     int readLength = this.inflater.getTotalOut();
/* 451 */     if (dataLength != readLength) {
/* 452 */       throw new DecompressionException("Number of bytes mismatch. Expected: " + dataLength + ", Got: " + readLength);
/*     */     }
/*     */     
/* 455 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean verifyCrc(ByteBuf in) {
/* 466 */     if (in.readableBytes() < 4) {
/* 467 */       return false;
/*     */     }
/* 469 */     long crcValue = 0L;
/* 470 */     for (int i = 0; i < 4; i++) {
/* 471 */       crcValue |= in.readUnsignedByte() << i * 8;
/*     */     }
/* 473 */     long readCrc = this.crc.getValue();
/* 474 */     if (crcValue != readCrc) {
/* 475 */       throw new DecompressionException("CRC value mismatch. Expected: " + crcValue + ", Got: " + readCrc);
/*     */     }
/*     */     
/* 478 */     return true;
/*     */   }
/*     */   
/*     */   private boolean verifyCrc16(ByteBuf in) {
/* 482 */     if (in.readableBytes() < 2) {
/* 483 */       return false;
/*     */     }
/* 485 */     long readCrc32 = this.crc.getValue();
/* 486 */     long crc16Value = 0L;
/* 487 */     long readCrc16 = 0L;
/* 488 */     for (int i = 0; i < 2; i++) {
/* 489 */       crc16Value |= in.readUnsignedByte() << i * 8;
/* 490 */       readCrc16 |= (readCrc32 >> i * 8 & 0xFFL) << i * 8;
/*     */     } 
/*     */     
/* 493 */     if (crc16Value != readCrc16) {
/* 494 */       throw new DecompressionException("CRC16 value mismatch. Expected: " + crc16Value + ", Got: " + readCrc16);
/*     */     }
/*     */     
/* 497 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean looksLikeZlib(short cmf_flg) {
/* 508 */     return ((cmf_flg & 0x7800) == 30720 && cmf_flg % 31 == 0);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-4.1.93.Final.jar!\io\netty\handler\codec\compression\JdkZlibDecoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */