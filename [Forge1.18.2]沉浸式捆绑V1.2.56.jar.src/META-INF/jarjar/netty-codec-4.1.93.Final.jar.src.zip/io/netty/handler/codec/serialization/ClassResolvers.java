/*     */ package io.netty.handler.codec.serialization;
/*     */ 
/*     */ import io.netty.util.internal.PlatformDependent;
/*     */ import java.lang.ref.Reference;
/*     */ import java.util.HashMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public final class ClassResolvers
/*     */ {
/*     */   public static ClassResolver cacheDisabled(ClassLoader classLoader) {
/*  45 */     return new ClassLoaderClassResolver(defaultClassLoader(classLoader));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ClassResolver weakCachingResolver(ClassLoader classLoader) {
/*  56 */     return new CachingClassResolver(new ClassLoaderClassResolver(
/*  57 */           defaultClassLoader(classLoader)), new WeakReferenceMap<String, Class<?>>(new HashMap<String, Reference<Class<?>>>()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ClassResolver softCachingResolver(ClassLoader classLoader) {
/*  69 */     return new CachingClassResolver(new ClassLoaderClassResolver(
/*  70 */           defaultClassLoader(classLoader)), new SoftReferenceMap<String, Class<?>>(new HashMap<String, Reference<Class<?>>>()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ClassResolver weakCachingConcurrentResolver(ClassLoader classLoader) {
/*  82 */     return new CachingClassResolver(new ClassLoaderClassResolver(
/*  83 */           defaultClassLoader(classLoader)), new WeakReferenceMap<String, Class<?>>(
/*     */           
/*  85 */           PlatformDependent.newConcurrentHashMap()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ClassResolver softCachingConcurrentResolver(ClassLoader classLoader) {
/*  96 */     return new CachingClassResolver(new ClassLoaderClassResolver(
/*  97 */           defaultClassLoader(classLoader)), new SoftReferenceMap<String, Class<?>>(
/*     */           
/*  99 */           PlatformDependent.newConcurrentHashMap()));
/*     */   }
/*     */   
/*     */   static ClassLoader defaultClassLoader(ClassLoader classLoader) {
/* 103 */     if (classLoader != null) {
/* 104 */       return classLoader;
/*     */     }
/*     */     
/* 107 */     ClassLoader contextClassLoader = PlatformDependent.getContextClassLoader();
/* 108 */     if (contextClassLoader != null) {
/* 109 */       return contextClassLoader;
/*     */     }
/*     */     
/* 112 */     return PlatformDependent.getClassLoader(ClassResolvers.class);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-4.1.93.Final.jar!\io\netty\handler\codec\serialization\ClassResolvers.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */