/*    */ package io.netty.handler.codec.compression;
/*    */ 
/*    */ import io.netty.util.internal.PlatformDependent;
/*    */ import io.netty.util.internal.logging.InternalLogger;
/*    */ import io.netty.util.internal.logging.InternalLoggerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Zstd
/*    */ {
/* 25 */   private static final InternalLogger logger = InternalLoggerFactory.getInstance(Zstd.class);
/*    */   private static final Throwable cause;
/*    */   
/*    */   static {
/* 29 */     Throwable t = null;
/*    */     
/*    */     try {
/* 32 */       Class.forName("com.github.luben.zstd.Zstd", false, 
/* 33 */           PlatformDependent.getClassLoader(Zstd.class));
/* 34 */     } catch (ClassNotFoundException e) {
/* 35 */       t = e;
/* 36 */       logger.debug("zstd-jni not in the classpath; Zstd support will be unavailable.");
/*    */     }
/* 38 */     catch (Throwable e) {
/* 39 */       t = e;
/* 40 */       logger.debug("Failed to load zstd-jni; Zstd support will be unavailable.", t);
/*    */     } 
/*    */     
/* 43 */     cause = t;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static boolean isAvailable() {
/* 52 */     return (cause == null);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void ensureAvailability() throws Throwable {
/* 61 */     if (cause != null) {
/* 62 */       throw cause;
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static Throwable cause() {
/* 70 */     return cause;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-4.1.93.Final.jar!\io\netty\handler\codec\compression\Zstd.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */