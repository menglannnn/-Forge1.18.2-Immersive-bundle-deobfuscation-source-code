/*    */ package io.netty.handler.codec.compression;
/*    */ 
/*    */ import com.aayushatharva.brotli4j.encoder.Encoder;
/*    */ import io.netty.util.internal.ObjectUtil;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class BrotliOptions
/*    */   implements CompressionOptions
/*    */ {
/*    */   private final Encoder.Parameters parameters;
/* 32 */   static final BrotliOptions DEFAULT = new BrotliOptions((new Encoder.Parameters())
/* 33 */       .setQuality(4).setMode(Encoder.Mode.TEXT));
/*    */ 
/*    */   
/*    */   BrotliOptions(Encoder.Parameters parameters) {
/* 37 */     if (!Brotli.isAvailable()) {
/* 38 */       throw new IllegalStateException("Brotli is not available", Brotli.cause());
/*    */     }
/*    */     
/* 41 */     this.parameters = (Encoder.Parameters)ObjectUtil.checkNotNull(parameters, "Parameters");
/*    */   }
/*    */   
/*    */   public Encoder.Parameters parameters() {
/* 45 */     return this.parameters;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-4.1.93.Final.jar!\io\netty\handler\codec\compression\BrotliOptions.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */