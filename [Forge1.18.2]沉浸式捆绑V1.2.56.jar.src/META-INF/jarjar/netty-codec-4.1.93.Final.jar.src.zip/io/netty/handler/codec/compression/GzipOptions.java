/*    */ package io.netty.handler.codec.compression;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class GzipOptions
/*    */   extends DeflateOptions
/*    */ {
/* 28 */   static final GzipOptions DEFAULT = new GzipOptions(6, 15, 8);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   GzipOptions(int compressionLevel, int windowBits, int memLevel) {
/* 36 */     super(compressionLevel, windowBits, memLevel);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-4.1.93.Final.jar!\io\netty\handler\codec\compression\GzipOptions.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */