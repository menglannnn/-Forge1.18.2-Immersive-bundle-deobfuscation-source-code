/*    */ package io.netty.handler.codec.compression;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum ZlibWrapper
/*    */ {
/* 26 */   ZLIB,
/*    */ 
/*    */ 
/*    */   
/* 30 */   GZIP,
/*    */ 
/*    */ 
/*    */   
/* 34 */   NONE,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 39 */   ZLIB_OR_NONE;
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-4.1.93.Final.jar!\io\netty\handler\codec\compression\ZlibWrapper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */