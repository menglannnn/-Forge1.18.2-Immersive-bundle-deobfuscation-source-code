/*     */ package io.netty.handler.codec.compression;
/*     */ 
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import io.netty.channel.ChannelHandlerContext;
/*     */ import io.netty.handler.codec.MessageToByteEncoder;
/*     */ import java.util.zip.Adler32;
/*     */ import java.util.zip.Checksum;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FastLzFrameEncoder
/*     */   extends MessageToByteEncoder<ByteBuf>
/*     */ {
/*     */   private final int level;
/*     */   private final ByteBufChecksum checksum;
/*     */   
/*     */   public FastLzFrameEncoder() {
/*  60 */     this(0, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FastLzFrameEncoder(int level) {
/*  72 */     this(level, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FastLzFrameEncoder(boolean validateChecksums) {
/*  86 */     this(0, validateChecksums ? new Adler32() : null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FastLzFrameEncoder(int level, Checksum checksum) {
/* 101 */     if (level != 0 && level != 1 && level != 2)
/* 102 */       throw new IllegalArgumentException(String.format("level: %d (expected: %d or %d or %d)", new Object[] {
/* 103 */               Integer.valueOf(level), Integer.valueOf(0), Integer.valueOf(1), Integer.valueOf(2)
/*     */             })); 
/* 105 */     this.level = level;
/* 106 */     this.checksum = (checksum == null) ? null : ByteBufChecksum.wrapChecksum(checksum);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void encode(ChannelHandlerContext ctx, ByteBuf in, ByteBuf out) throws Exception {
/* 111 */     ByteBufChecksum checksum = this.checksum; while (true) {
/*     */       byte blockType;
/*     */       int chunkLength;
/* 114 */       if (!in.isReadable()) {
/*     */         return;
/*     */       }
/* 117 */       int idx = in.readerIndex();
/* 118 */       int length = Math.min(in.readableBytes(), 65535);
/*     */       
/* 120 */       int outputIdx = out.writerIndex();
/* 121 */       out.setMedium(outputIdx, 4607066);
/* 122 */       int outputOffset = outputIdx + 4 + ((checksum != null) ? 4 : 0);
/*     */ 
/*     */ 
/*     */       
/* 126 */       if (length < 32) {
/* 127 */         blockType = 0;
/*     */         
/* 129 */         out.ensureWritable(outputOffset + 2 + length);
/* 130 */         int outputPtr = outputOffset + 2;
/*     */         
/* 132 */         if (checksum != null) {
/* 133 */           checksum.reset();
/* 134 */           checksum.update(in, idx, length);
/* 135 */           out.setInt(outputIdx + 4, (int)checksum.getValue());
/*     */         } 
/* 137 */         out.setBytes(outputPtr, in, idx, length);
/* 138 */         chunkLength = length;
/*     */       } else {
/*     */         
/* 141 */         if (checksum != null) {
/* 142 */           checksum.reset();
/* 143 */           checksum.update(in, idx, length);
/* 144 */           out.setInt(outputIdx + 4, (int)checksum.getValue());
/*     */         } 
/*     */         
/* 147 */         int maxOutputLength = FastLz.calculateOutputBufferLength(length);
/* 148 */         out.ensureWritable(outputOffset + 4 + maxOutputLength);
/* 149 */         int outputPtr = outputOffset + 4;
/* 150 */         int compressedLength = FastLz.compress(in, in.readerIndex(), length, out, outputPtr, this.level);
/*     */         
/* 152 */         if (compressedLength < length) {
/* 153 */           blockType = 1;
/* 154 */           chunkLength = compressedLength;
/*     */           
/* 156 */           out.setShort(outputOffset, chunkLength);
/* 157 */           outputOffset += 2;
/*     */         } else {
/* 159 */           blockType = 0;
/* 160 */           out.setBytes(outputOffset + 2, in, idx, length);
/* 161 */           chunkLength = length;
/*     */         } 
/*     */       } 
/* 164 */       out.setShort(outputOffset, length);
/*     */       
/* 166 */       out.setByte(outputIdx + 3, blockType | ((checksum != null) ? 16 : 0));
/*     */       
/* 168 */       out.writerIndex(outputOffset + 2 + chunkLength);
/* 169 */       in.skipBytes(length);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-4.1.93.Final.jar!\io\netty\handler\codec\compression\FastLzFrameEncoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */