/*     */ package io.netty.handler.codec.compression;
/*     */ 
/*     */ import com.aayushatharva.brotli4j.encoder.BrotliEncoderChannel;
/*     */ import com.aayushatharva.brotli4j.encoder.Encoder;
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import io.netty.buffer.Unpooled;
/*     */ import io.netty.channel.ChannelFuture;
/*     */ import io.netty.channel.ChannelHandler.Sharable;
/*     */ import io.netty.channel.ChannelHandlerContext;
/*     */ import io.netty.channel.ChannelPromise;
/*     */ import io.netty.handler.codec.MessageToByteEncoder;
/*     */ import io.netty.util.AttributeKey;
/*     */ import io.netty.util.ReferenceCountUtil;
/*     */ import io.netty.util.internal.ObjectUtil;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.channels.ClosedChannelException;
/*     */ import java.nio.channels.WritableByteChannel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Sharable
/*     */ public final class BrotliEncoder
/*     */   extends MessageToByteEncoder<ByteBuf>
/*     */ {
/*     */   static {
/*     */     Method method;
/*     */   }
/*     */   
/*  46 */   private static final AttributeKey<Writer> ATTR = AttributeKey.valueOf("BrotliEncoderWriter");
/*     */   
/*     */   private static final Method FLUSH_METHOD;
/*     */   
/*     */   private final Encoder.Parameters parameters;
/*     */   
/*     */   private final boolean isSharable;
/*     */   private Writer writer;
/*     */   
/*     */   static {
/*     */     try {
/*  57 */       method = Encoder.class.getDeclaredMethod("flush", new Class[0]);
/*  58 */       method.setAccessible(true);
/*  59 */     } catch (NoSuchMethodException e) {
/*  60 */       throw new IllegalStateException(e);
/*     */     } 
/*  62 */     FLUSH_METHOD = method;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BrotliEncoder() {
/*  74 */     this(BrotliOptions.DEFAULT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BrotliEncoder(BrotliOptions brotliOptions) {
/*  84 */     this(brotliOptions.parameters());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BrotliEncoder(Encoder.Parameters parameters) {
/*  94 */     this(parameters, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BrotliEncoder(Encoder.Parameters parameters, boolean isSharable) {
/* 114 */     this.parameters = (Encoder.Parameters)ObjectUtil.checkNotNull(parameters, "Parameters");
/* 115 */     this.isSharable = isSharable;
/*     */   }
/*     */ 
/*     */   
/*     */   public void handlerAdded(ChannelHandlerContext ctx) throws Exception {
/* 120 */     Writer writer = new Writer(this.parameters, ctx);
/* 121 */     if (this.isSharable) {
/* 122 */       ctx.channel().attr(ATTR).set(writer);
/*     */     } else {
/* 124 */       this.writer = writer;
/*     */     } 
/* 126 */     super.handlerAdded(ctx);
/*     */   }
/*     */ 
/*     */   
/*     */   public void handlerRemoved(ChannelHandlerContext ctx) throws Exception {
/* 131 */     finish(ctx);
/* 132 */     super.handlerRemoved(ctx);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void encode(ChannelHandlerContext ctx, ByteBuf msg, ByteBuf out) throws Exception {}
/*     */ 
/*     */   
/*     */   protected ByteBuf allocateBuffer(ChannelHandlerContext ctx, ByteBuf msg, boolean preferDirect) throws Exception {
/*     */     Writer writer;
/* 142 */     if (!msg.isReadable()) {
/* 143 */       return Unpooled.EMPTY_BUFFER;
/*     */     }
/*     */ 
/*     */     
/* 147 */     if (this.isSharable) {
/* 148 */       writer = (Writer)ctx.channel().attr(ATTR).get();
/*     */     } else {
/* 150 */       writer = this.writer;
/*     */     } 
/*     */ 
/*     */     
/* 154 */     if (writer == null) {
/* 155 */       return Unpooled.EMPTY_BUFFER;
/*     */     }
/* 157 */     writer.encode(msg, preferDirect);
/* 158 */     return writer.writableBuffer;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSharable() {
/* 164 */     return this.isSharable;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void finish(ChannelHandlerContext ctx) throws IOException {
/* 174 */     finishEncode(ctx, ctx.newPromise());
/*     */   }
/*     */ 
/*     */   
/*     */   private ChannelFuture finishEncode(ChannelHandlerContext ctx, ChannelPromise promise) throws IOException {
/*     */     Writer writer;
/* 180 */     if (this.isSharable) {
/* 181 */       writer = (Writer)ctx.channel().attr(ATTR).getAndSet(null);
/*     */     } else {
/* 183 */       writer = this.writer;
/*     */     } 
/*     */     
/* 186 */     if (writer != null) {
/* 187 */       writer.close();
/* 188 */       this.writer = null;
/*     */     } 
/* 190 */     return (ChannelFuture)promise;
/*     */   }
/*     */ 
/*     */   
/*     */   public void close(ChannelHandlerContext ctx, ChannelPromise promise) throws Exception {
/* 195 */     ChannelFuture f = finishEncode(ctx, ctx.newPromise());
/* 196 */     EncoderUtil.closeAfterFinishEncode(ctx, f, promise);
/*     */   }
/*     */ 
/*     */   
/*     */   private static final class Writer
/*     */     implements WritableByteChannel
/*     */   {
/*     */     private ByteBuf writableBuffer;
/*     */     
/*     */     private final BrotliEncoderChannel brotliEncoderChannel;
/*     */     
/*     */     private final ChannelHandlerContext ctx;
/*     */     private boolean isClosed;
/*     */     
/*     */     private Writer(Encoder.Parameters parameters, ChannelHandlerContext ctx) throws IOException {
/* 211 */       this.brotliEncoderChannel = new BrotliEncoderChannel(this, parameters);
/* 212 */       this.ctx = ctx;
/*     */     }
/*     */     
/*     */     private void encode(ByteBuf msg, boolean preferDirect) throws Exception {
/*     */       try {
/* 217 */         allocate(preferDirect);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 226 */         this.brotliEncoderChannel.write(msg.nioBuffer());
/* 227 */         BrotliEncoder.FLUSH_METHOD.invoke(this.brotliEncoderChannel, new Object[0]);
/*     */       }
/* 229 */       catch (Exception e) {
/* 230 */         ReferenceCountUtil.release(msg);
/* 231 */         throw e;
/*     */       } 
/*     */     }
/*     */     
/*     */     private void allocate(boolean preferDirect) {
/* 236 */       if (preferDirect) {
/* 237 */         this.writableBuffer = this.ctx.alloc().ioBuffer();
/*     */       } else {
/* 239 */         this.writableBuffer = this.ctx.alloc().buffer();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public int write(ByteBuffer src) throws IOException {
/* 245 */       if (!isOpen()) {
/* 246 */         throw new ClosedChannelException();
/*     */       }
/*     */       
/* 249 */       return this.writableBuffer.writeBytes(src).readableBytes();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isOpen() {
/* 254 */       return !this.isClosed;
/*     */     }
/*     */ 
/*     */     
/*     */     public void close() {
/* 259 */       final ChannelPromise promise = this.ctx.newPromise();
/*     */       
/* 261 */       this.ctx.executor().execute(new Runnable()
/*     */           {
/*     */             public void run() {
/*     */               try {
/* 265 */                 BrotliEncoder.Writer.this.finish(promise);
/* 266 */               } catch (IOException ex) {
/* 267 */                 promise.setFailure(new IllegalStateException("Failed to finish encoding", ex));
/*     */               } 
/*     */             }
/*     */           });
/*     */     }
/*     */     
/*     */     public void finish(ChannelPromise promise) throws IOException {
/* 274 */       if (!this.isClosed) {
/*     */         
/* 276 */         allocate(true);
/*     */         
/*     */         try {
/* 279 */           this.brotliEncoderChannel.close();
/* 280 */           this.isClosed = true;
/* 281 */         } catch (Exception ex) {
/* 282 */           promise.setFailure(ex);
/*     */ 
/*     */ 
/*     */           
/* 286 */           ReferenceCountUtil.release(this.writableBuffer);
/*     */           
/*     */           return;
/*     */         } 
/* 290 */         this.ctx.writeAndFlush(this.writableBuffer, promise);
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-4.1.93.Final.jar!\io\netty\handler\codec\compression\BrotliEncoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */