/*     */ package io.netty.handler.codec.compression;
/*     */ 
/*     */ import com.jcraft.jzlib.Inflater;
/*     */ import com.jcraft.jzlib.JZlib;
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import io.netty.channel.ChannelHandlerContext;
/*     */ import io.netty.util.internal.ObjectUtil;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JZlibDecoder
/*     */   extends ZlibDecoder
/*     */ {
/*  29 */   private final Inflater z = new Inflater();
/*     */ 
/*     */   
/*     */   private byte[] dictionary;
/*     */ 
/*     */   
/*     */   private volatile boolean finished;
/*     */ 
/*     */   
/*     */   public JZlibDecoder() {
/*  39 */     this(ZlibWrapper.ZLIB, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JZlibDecoder(int maxAllocation) {
/*  53 */     this(ZlibWrapper.ZLIB, maxAllocation);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JZlibDecoder(ZlibWrapper wrapper) {
/*  62 */     this(wrapper, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JZlibDecoder(ZlibWrapper wrapper, int maxAllocation) {
/*  75 */     super(maxAllocation);
/*     */     
/*  77 */     ObjectUtil.checkNotNull(wrapper, "wrapper");
/*     */     
/*  79 */     int resultCode = this.z.init(ZlibUtil.convertWrapperType(wrapper));
/*  80 */     if (resultCode != 0) {
/*  81 */       ZlibUtil.fail(this.z, "initialization failure", resultCode);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JZlibDecoder(byte[] dictionary) {
/*  93 */     this(dictionary, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JZlibDecoder(byte[] dictionary, int maxAllocation) {
/* 108 */     super(maxAllocation);
/* 109 */     this.dictionary = (byte[])ObjectUtil.checkNotNull(dictionary, "dictionary");
/*     */     
/* 111 */     int resultCode = this.z.inflateInit(JZlib.W_ZLIB);
/* 112 */     if (resultCode != 0) {
/* 113 */       ZlibUtil.fail(this.z, "initialization failure", resultCode);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isClosed() {
/* 123 */     return this.finished;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void decode(ChannelHandlerContext ctx, ByteBuf in, List<Object> out) throws Exception {
/* 128 */     if (this.finished) {
/*     */       
/* 130 */       in.skipBytes(in.readableBytes());
/*     */       
/*     */       return;
/*     */     } 
/* 134 */     int inputLength = in.readableBytes();
/* 135 */     if (inputLength == 0) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/* 141 */       this.z.avail_in = inputLength;
/* 142 */       if (in.hasArray()) {
/* 143 */         this.z.next_in = in.array();
/* 144 */         this.z.next_in_index = in.arrayOffset() + in.readerIndex();
/*     */       } else {
/* 146 */         byte[] array = new byte[inputLength];
/* 147 */         in.getBytes(in.readerIndex(), array);
/* 148 */         this.z.next_in = array;
/* 149 */         this.z.next_in_index = 0;
/*     */       } 
/* 151 */       int oldNextInIndex = this.z.next_in_index;
/*     */ 
/*     */       
/* 154 */       ByteBuf decompressed = prepareDecompressBuffer(ctx, null, inputLength << 1);
/*     */       
/*     */       try {
/*     */         while (true) {
/* 158 */           decompressed = prepareDecompressBuffer(ctx, decompressed, this.z.avail_in << 1);
/* 159 */           this.z.avail_out = decompressed.writableBytes();
/* 160 */           this.z.next_out = decompressed.array();
/* 161 */           this.z.next_out_index = decompressed.arrayOffset() + decompressed.writerIndex();
/* 162 */           int oldNextOutIndex = this.z.next_out_index;
/*     */ 
/*     */           
/* 165 */           int resultCode = this.z.inflate(2);
/* 166 */           int outputLength = this.z.next_out_index - oldNextOutIndex;
/* 167 */           if (outputLength > 0) {
/* 168 */             decompressed.writerIndex(decompressed.writerIndex() + outputLength);
/*     */           }
/*     */           
/* 171 */           switch (resultCode) {
/*     */             case 2:
/* 173 */               if (this.dictionary == null) {
/* 174 */                 ZlibUtil.fail(this.z, "decompression failure", resultCode); continue;
/*     */               } 
/* 176 */               resultCode = this.z.inflateSetDictionary(this.dictionary, this.dictionary.length);
/* 177 */               if (resultCode != 0) {
/* 178 */                 ZlibUtil.fail(this.z, "failed to set the dictionary", resultCode);
/*     */               }
/*     */               continue;
/*     */             
/*     */             case 1:
/* 183 */               this.finished = true;
/* 184 */               this.z.inflateEnd();
/*     */               break;
/*     */             case 0:
/*     */               continue;
/*     */             case -5:
/* 189 */               if (this.z.avail_in <= 0) {
/*     */                 break;
/*     */               }
/*     */               continue;
/*     */           } 
/* 194 */           ZlibUtil.fail(this.z, "decompression failure", resultCode);
/*     */         } 
/*     */       } finally {
/*     */         
/* 198 */         in.skipBytes(this.z.next_in_index - oldNextInIndex);
/* 199 */         if (decompressed.isReadable()) {
/* 200 */           out.add(decompressed);
/*     */         } else {
/* 202 */           decompressed.release();
/*     */         }
/*     */       
/*     */       }
/*     */     
/*     */     }
/*     */     finally {
/*     */       
/* 210 */       this.z.next_in = null;
/* 211 */       this.z.next_out = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void decompressionBufferExhausted(ByteBuf buffer) {
/* 217 */     this.finished = true;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-4.1.93.Final.jar!\io\netty\handler\codec\compression\JZlibDecoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */