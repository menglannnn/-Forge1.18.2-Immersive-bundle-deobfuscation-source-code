/*    */ package io.netty.handler.codec;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum ProtocolDetectionState
/*    */ {
/* 25 */   NEEDS_MORE_DATA,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 30 */   INVALID,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 35 */   DETECTED;
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-4.1.93.Final.jar!\io\netty\handler\codec\ProtocolDetectionState.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */