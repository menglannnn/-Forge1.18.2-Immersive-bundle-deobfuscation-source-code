/*     */ package io.netty.handler.codec.compression;
/*     */ 
/*     */ import com.github.luben.zstd.Zstd;
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import io.netty.buffer.Unpooled;
/*     */ import io.netty.channel.ChannelHandlerContext;
/*     */ import io.netty.handler.codec.EncoderException;
/*     */ import io.netty.handler.codec.MessageToByteEncoder;
/*     */ import io.netty.util.internal.ObjectUtil;
/*     */ import java.nio.ByteBuffer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ZstdEncoder
/*     */   extends MessageToByteEncoder<ByteBuf>
/*     */ {
/*     */   private final int blockSize;
/*     */   private final int compressionLevel;
/*     */   private final int maxEncodeSize;
/*     */   private ByteBuf buffer;
/*     */   
/*     */   public ZstdEncoder() {
/*  51 */     this(3, 65536, 33554432);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ZstdEncoder(int compressionLevel) {
/*  60 */     this(compressionLevel, 65536, 33554432);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ZstdEncoder(int blockSize, int maxEncodeSize) {
/*  71 */     this(3, blockSize, maxEncodeSize);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ZstdEncoder(int compressionLevel, int blockSize, int maxEncodeSize) {
/*  83 */     super(true);
/*  84 */     this.compressionLevel = ObjectUtil.checkInRange(compressionLevel, 0, 22, "compressionLevel");
/*  85 */     this.blockSize = ObjectUtil.checkPositive(blockSize, "blockSize");
/*  86 */     this.maxEncodeSize = ObjectUtil.checkPositive(maxEncodeSize, "maxEncodeSize");
/*     */   }
/*     */ 
/*     */   
/*     */   protected ByteBuf allocateBuffer(ChannelHandlerContext ctx, ByteBuf msg, boolean preferDirect) {
/*  91 */     if (this.buffer == null) {
/*  92 */       throw new IllegalStateException("not added to a pipeline,or has been removed,buffer is null");
/*     */     }
/*     */ 
/*     */     
/*  96 */     int remaining = msg.readableBytes() + this.buffer.readableBytes();
/*     */ 
/*     */     
/*  99 */     if (remaining < 0) {
/* 100 */       throw new EncoderException("too much data to allocate a buffer for compression");
/*     */     }
/*     */     
/* 103 */     long bufferSize = 0L;
/* 104 */     while (remaining > 0) {
/* 105 */       int curSize = Math.min(this.blockSize, remaining);
/* 106 */       remaining -= curSize;
/* 107 */       bufferSize += Zstd.compressBound(curSize);
/*     */     } 
/*     */     
/* 110 */     if (bufferSize > this.maxEncodeSize || 0L > bufferSize) {
/* 111 */       throw new EncoderException("requested encode buffer size (" + bufferSize + " bytes) exceeds the maximum allowable size (" + this.maxEncodeSize + " bytes)");
/*     */     }
/*     */ 
/*     */     
/* 115 */     return ctx.alloc().directBuffer((int)bufferSize);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void encode(ChannelHandlerContext ctx, ByteBuf in, ByteBuf out) {
/* 120 */     if (this.buffer == null) {
/* 121 */       throw new IllegalStateException("not added to a pipeline,or has been removed,buffer is null");
/*     */     }
/*     */ 
/*     */     
/* 125 */     ByteBuf buffer = this.buffer;
/*     */     int length;
/* 127 */     while ((length = in.readableBytes()) > 0) {
/* 128 */       int nextChunkSize = Math.min(length, buffer.writableBytes());
/* 129 */       in.readBytes(buffer, nextChunkSize);
/*     */       
/* 131 */       if (!buffer.isWritable()) {
/* 132 */         flushBufferedData(out);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private void flushBufferedData(ByteBuf out) {
/* 138 */     int compressedLength, flushableBytes = this.buffer.readableBytes();
/* 139 */     if (flushableBytes == 0) {
/*     */       return;
/*     */     }
/*     */     
/* 143 */     int bufSize = (int)Zstd.compressBound(flushableBytes);
/* 144 */     out.ensureWritable(bufSize);
/* 145 */     int idx = out.writerIndex();
/*     */     
/*     */     try {
/* 148 */       ByteBuffer outNioBuffer = out.internalNioBuffer(idx, out.writableBytes());
/* 149 */       compressedLength = Zstd.compress(outNioBuffer, this.buffer
/*     */           
/* 151 */           .internalNioBuffer(this.buffer.readerIndex(), flushableBytes), this.compressionLevel);
/*     */     }
/* 153 */     catch (Exception e) {
/* 154 */       throw new CompressionException(e);
/*     */     } 
/*     */     
/* 157 */     out.writerIndex(idx + compressedLength);
/* 158 */     this.buffer.clear();
/*     */   }
/*     */ 
/*     */   
/*     */   public void flush(ChannelHandlerContext ctx) {
/* 163 */     if (this.buffer != null && this.buffer.isReadable()) {
/* 164 */       ByteBuf buf = allocateBuffer(ctx, Unpooled.EMPTY_BUFFER, isPreferDirect());
/* 165 */       flushBufferedData(buf);
/* 166 */       ctx.write(buf);
/*     */     } 
/* 168 */     ctx.flush();
/*     */   }
/*     */ 
/*     */   
/*     */   public void handlerAdded(ChannelHandlerContext ctx) {
/* 173 */     this.buffer = ctx.alloc().directBuffer(this.blockSize);
/* 174 */     this.buffer.clear();
/*     */   }
/*     */ 
/*     */   
/*     */   public void handlerRemoved(ChannelHandlerContext ctx) throws Exception {
/* 179 */     super.handlerRemoved(ctx);
/* 180 */     if (this.buffer != null) {
/* 181 */       this.buffer.release();
/* 182 */       this.buffer = null;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-4.1.93.Final.jar!\io\netty\handler\codec\compression\ZstdEncoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */