/*     */ package io.netty.handler.codec.compression;
/*     */ 
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import io.netty.buffer.Unpooled;
/*     */ import io.netty.channel.ChannelFuture;
/*     */ import io.netty.channel.ChannelHandlerContext;
/*     */ import io.netty.channel.ChannelPromise;
/*     */ import io.netty.handler.codec.EncoderException;
/*     */ import io.netty.handler.codec.MessageToByteEncoder;
/*     */ import io.netty.util.concurrent.EventExecutor;
/*     */ import io.netty.util.concurrent.Future;
/*     */ import io.netty.util.concurrent.Promise;
/*     */ import io.netty.util.concurrent.PromiseNotifier;
/*     */ import io.netty.util.internal.ObjectUtil;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.zip.Checksum;
/*     */ import net.jpountz.lz4.LZ4Compressor;
/*     */ import net.jpountz.lz4.LZ4Exception;
/*     */ import net.jpountz.lz4.LZ4Factory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Lz4FrameEncoder
/*     */   extends MessageToByteEncoder<ByteBuf>
/*     */ {
/*     */   static final int DEFAULT_MAX_ENCODE_SIZE = 2147483647;
/*     */   private final int blockSize;
/*     */   private final LZ4Compressor compressor;
/*     */   private final ByteBufChecksum checksum;
/*     */   private final int compressionLevel;
/*     */   private ByteBuf buffer;
/*     */   private final int maxEncodeSize;
/*     */   private volatile boolean finished;
/*     */   private volatile ChannelHandlerContext ctx;
/*     */   
/*     */   public Lz4FrameEncoder() {
/* 113 */     this(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Lz4FrameEncoder(boolean highCompressor) {
/* 125 */     this(LZ4Factory.fastestInstance(), highCompressor, 65536, new Lz4XXHash32(-1756908916));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Lz4FrameEncoder(LZ4Factory factory, boolean highCompressor, int blockSize, Checksum checksum) {
/* 141 */     this(factory, highCompressor, blockSize, checksum, 2147483647);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Lz4FrameEncoder(LZ4Factory factory, boolean highCompressor, int blockSize, Checksum checksum, int maxEncodeSize) {
/* 159 */     ObjectUtil.checkNotNull(factory, "factory");
/* 160 */     ObjectUtil.checkNotNull(checksum, "checksum");
/*     */     
/* 162 */     this.compressor = highCompressor ? factory.highCompressor() : factory.fastCompressor();
/* 163 */     this.checksum = ByteBufChecksum.wrapChecksum(checksum);
/*     */     
/* 165 */     this.compressionLevel = compressionLevel(blockSize);
/* 166 */     this.blockSize = blockSize;
/* 167 */     this.maxEncodeSize = ObjectUtil.checkPositive(maxEncodeSize, "maxEncodeSize");
/* 168 */     this.finished = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int compressionLevel(int blockSize) {
/* 175 */     if (blockSize < 64 || blockSize > 33554432)
/* 176 */       throw new IllegalArgumentException(String.format("blockSize: %d (expected: %d-%d)", new Object[] {
/* 177 */               Integer.valueOf(blockSize), Integer.valueOf(64), Integer.valueOf(33554432)
/*     */             })); 
/* 179 */     int compressionLevel = 32 - Integer.numberOfLeadingZeros(blockSize - 1);
/* 180 */     compressionLevel = Math.max(0, compressionLevel - 10);
/* 181 */     return compressionLevel;
/*     */   }
/*     */ 
/*     */   
/*     */   protected ByteBuf allocateBuffer(ChannelHandlerContext ctx, ByteBuf msg, boolean preferDirect) {
/* 186 */     return allocateBuffer(ctx, msg, preferDirect, true);
/*     */   }
/*     */ 
/*     */   
/*     */   private ByteBuf allocateBuffer(ChannelHandlerContext ctx, ByteBuf msg, boolean preferDirect, boolean allowEmptyReturn) {
/* 191 */     int targetBufSize = 0;
/* 192 */     int remaining = msg.readableBytes() + this.buffer.readableBytes();
/*     */ 
/*     */     
/* 195 */     if (remaining < 0) {
/* 196 */       throw new EncoderException("too much data to allocate a buffer for compression");
/*     */     }
/*     */     
/* 199 */     while (remaining > 0) {
/* 200 */       int curSize = Math.min(this.blockSize, remaining);
/* 201 */       remaining -= curSize;
/*     */       
/* 203 */       targetBufSize += this.compressor.maxCompressedLength(curSize) + 21;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 209 */     if (targetBufSize > this.maxEncodeSize || 0 > targetBufSize) {
/* 210 */       throw new EncoderException(String.format("requested encode buffer size (%d bytes) exceeds the maximum allowable size (%d bytes)", new Object[] {
/* 211 */               Integer.valueOf(targetBufSize), Integer.valueOf(this.maxEncodeSize)
/*     */             }));
/*     */     }
/* 214 */     if (allowEmptyReturn && targetBufSize < this.blockSize) {
/* 215 */       return Unpooled.EMPTY_BUFFER;
/*     */     }
/*     */     
/* 218 */     if (preferDirect) {
/* 219 */       return ctx.alloc().ioBuffer(targetBufSize, targetBufSize);
/*     */     }
/* 221 */     return ctx.alloc().heapBuffer(targetBufSize, targetBufSize);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void encode(ChannelHandlerContext ctx, ByteBuf in, ByteBuf out) throws Exception {
/* 234 */     if (this.finished) {
/* 235 */       if (!out.isWritable(in.readableBytes()))
/*     */       {
/* 237 */         throw new IllegalStateException("encode finished and not enough space to write remaining data");
/*     */       }
/* 239 */       out.writeBytes(in);
/*     */       
/*     */       return;
/*     */     } 
/* 243 */     ByteBuf buffer = this.buffer;
/*     */     int length;
/* 245 */     while ((length = in.readableBytes()) > 0) {
/* 246 */       int nextChunkSize = Math.min(length, buffer.writableBytes());
/* 247 */       in.readBytes(buffer, nextChunkSize);
/*     */       
/* 249 */       if (!buffer.isWritable()) {
/* 250 */         flushBufferedData(out);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private void flushBufferedData(ByteBuf out) {
/* 256 */     int compressedLength, blockType, flushableBytes = this.buffer.readableBytes();
/* 257 */     if (flushableBytes == 0) {
/*     */       return;
/*     */     }
/* 260 */     this.checksum.reset();
/* 261 */     this.checksum.update(this.buffer, this.buffer.readerIndex(), flushableBytes);
/* 262 */     int check = (int)this.checksum.getValue();
/*     */     
/* 264 */     int bufSize = this.compressor.maxCompressedLength(flushableBytes) + 21;
/* 265 */     out.ensureWritable(bufSize);
/* 266 */     int idx = out.writerIndex();
/*     */     
/*     */     try {
/* 269 */       ByteBuffer outNioBuffer = out.internalNioBuffer(idx + 21, out.writableBytes() - 21);
/* 270 */       int pos = outNioBuffer.position();
/*     */       
/* 272 */       this.compressor.compress(this.buffer.internalNioBuffer(this.buffer.readerIndex(), flushableBytes), outNioBuffer);
/* 273 */       compressedLength = outNioBuffer.position() - pos;
/* 274 */     } catch (LZ4Exception e) {
/* 275 */       throw new CompressionException(e);
/*     */     } 
/*     */     
/* 278 */     if (compressedLength >= flushableBytes) {
/* 279 */       blockType = 16;
/* 280 */       compressedLength = flushableBytes;
/* 281 */       out.setBytes(idx + 21, this.buffer, this.buffer.readerIndex(), flushableBytes);
/*     */     } else {
/* 283 */       blockType = 32;
/*     */     } 
/*     */     
/* 286 */     out.setLong(idx, 5501767354678207339L);
/* 287 */     out.setByte(idx + 8, (byte)(blockType | this.compressionLevel));
/* 288 */     out.setIntLE(idx + 9, compressedLength);
/* 289 */     out.setIntLE(idx + 13, flushableBytes);
/* 290 */     out.setIntLE(idx + 17, check);
/* 291 */     out.writerIndex(idx + 21 + compressedLength);
/* 292 */     this.buffer.clear();
/*     */   }
/*     */ 
/*     */   
/*     */   public void flush(ChannelHandlerContext ctx) throws Exception {
/* 297 */     if (this.buffer != null && this.buffer.isReadable()) {
/* 298 */       ByteBuf buf = allocateBuffer(ctx, Unpooled.EMPTY_BUFFER, isPreferDirect(), false);
/* 299 */       flushBufferedData(buf);
/* 300 */       ctx.write(buf);
/*     */     } 
/* 302 */     ctx.flush();
/*     */   }
/*     */   
/*     */   private ChannelFuture finishEncode(ChannelHandlerContext ctx, ChannelPromise promise) {
/* 306 */     if (this.finished) {
/* 307 */       promise.setSuccess();
/* 308 */       return (ChannelFuture)promise;
/*     */     } 
/* 310 */     this.finished = true;
/*     */     
/* 312 */     ByteBuf footer = ctx.alloc().heapBuffer(this.compressor
/* 313 */         .maxCompressedLength(this.buffer.readableBytes()) + 21);
/* 314 */     flushBufferedData(footer);
/*     */     
/* 316 */     footer.ensureWritable(21);
/* 317 */     int idx = footer.writerIndex();
/* 318 */     footer.setLong(idx, 5501767354678207339L);
/* 319 */     footer.setByte(idx + 8, (byte)(0x10 | this.compressionLevel));
/* 320 */     footer.setInt(idx + 9, 0);
/* 321 */     footer.setInt(idx + 13, 0);
/* 322 */     footer.setInt(idx + 17, 0);
/*     */     
/* 324 */     footer.writerIndex(idx + 21);
/*     */     
/* 326 */     return ctx.writeAndFlush(footer, promise);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isClosed() {
/* 333 */     return this.finished;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ChannelFuture close() {
/* 342 */     return close(ctx().newPromise());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ChannelFuture close(final ChannelPromise promise) {
/* 351 */     ChannelHandlerContext ctx = ctx();
/* 352 */     EventExecutor executor = ctx.executor();
/* 353 */     if (executor.inEventLoop()) {
/* 354 */       return finishEncode(ctx, promise);
/*     */     }
/* 356 */     executor.execute(new Runnable()
/*     */         {
/*     */           public void run() {
/* 359 */             ChannelFuture f = Lz4FrameEncoder.this.finishEncode(Lz4FrameEncoder.this.ctx(), promise);
/* 360 */             PromiseNotifier.cascade((Future)f, (Promise)promise);
/*     */           }
/*     */         });
/* 363 */     return (ChannelFuture)promise;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void close(ChannelHandlerContext ctx, ChannelPromise promise) throws Exception {
/* 369 */     ChannelFuture f = finishEncode(ctx, ctx.newPromise());
/*     */     
/* 371 */     EncoderUtil.closeAfterFinishEncode(ctx, f, promise);
/*     */   }
/*     */   
/*     */   private ChannelHandlerContext ctx() {
/* 375 */     ChannelHandlerContext ctx = this.ctx;
/* 376 */     if (ctx == null) {
/* 377 */       throw new IllegalStateException("not added to a pipeline");
/*     */     }
/* 379 */     return ctx;
/*     */   }
/*     */ 
/*     */   
/*     */   public void handlerAdded(ChannelHandlerContext ctx) {
/* 384 */     this.ctx = ctx;
/*     */     
/* 386 */     this.buffer = Unpooled.wrappedBuffer(new byte[this.blockSize]);
/* 387 */     this.buffer.clear();
/*     */   }
/*     */ 
/*     */   
/*     */   public void handlerRemoved(ChannelHandlerContext ctx) throws Exception {
/* 392 */     super.handlerRemoved(ctx);
/* 393 */     if (this.buffer != null) {
/* 394 */       this.buffer.release();
/* 395 */       this.buffer = null;
/*     */     } 
/*     */   }
/*     */   
/*     */   final ByteBuf getBackingBuffer() {
/* 400 */     return this.buffer;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-4.1.93.Final.jar!\io\netty\handler\codec\compression\Lz4FrameEncoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */