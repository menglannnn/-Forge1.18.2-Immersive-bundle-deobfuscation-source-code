/*     */ package io.netty.handler.codec.compression;
/*     */ 
/*     */ import com.ning.compress.BufferRecycler;
/*     */ import com.ning.compress.lzf.ChunkEncoder;
/*     */ import com.ning.compress.lzf.LZFChunk;
/*     */ import com.ning.compress.lzf.LZFEncoder;
/*     */ import com.ning.compress.lzf.util.ChunkEncoderFactory;
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import io.netty.channel.ChannelHandlerContext;
/*     */ import io.netty.handler.codec.MessageToByteEncoder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LzfEncoder
/*     */   extends MessageToByteEncoder<ByteBuf>
/*     */ {
/*     */   private static final int MIN_BLOCK_TO_COMPRESS = 16;
/*     */   private final int compressThreshold;
/*     */   private final ChunkEncoder encoder;
/*     */   private final BufferRecycler recycler;
/*     */   
/*     */   public LzfEncoder() {
/*  69 */     this(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LzfEncoder(boolean safeInstance) {
/*  82 */     this(safeInstance, 65535);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LzfEncoder(boolean safeInstance, int totalLength) {
/*  97 */     this(safeInstance, totalLength, 16);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LzfEncoder(int totalLength) {
/* 109 */     this(false, totalLength);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LzfEncoder(boolean safeInstance, int totalLength, int compressThreshold) {
/* 127 */     super(false);
/* 128 */     if (totalLength < 16 || totalLength > 65535) {
/* 129 */       throw new IllegalArgumentException("totalLength: " + totalLength + " (expected: " + '\020' + '-' + Character.MAX_VALUE + ')');
/*     */     }
/*     */ 
/*     */     
/* 133 */     if (compressThreshold < 16)
/*     */     {
/* 135 */       throw new IllegalArgumentException("compressThreshold:" + compressThreshold + " expected >=" + '\020');
/*     */     }
/*     */     
/* 138 */     this.compressThreshold = compressThreshold;
/*     */     
/* 140 */     this
/*     */       
/* 142 */       .encoder = safeInstance ? ChunkEncoderFactory.safeNonAllocatingInstance(totalLength) : ChunkEncoderFactory.optimalNonAllocatingInstance(totalLength);
/*     */     
/* 144 */     this.recycler = BufferRecycler.instance();
/*     */   } protected void encode(ChannelHandlerContext ctx, ByteBuf in, ByteBuf out) throws Exception {
/*     */     byte[] input;
/*     */     int inputPtr;
/*     */     byte[] output;
/* 149 */     int outputPtr, outputLength, length = in.readableBytes();
/* 150 */     int idx = in.readerIndex();
/*     */ 
/*     */     
/* 153 */     if (in.hasArray()) {
/* 154 */       input = in.array();
/* 155 */       inputPtr = in.arrayOffset() + idx;
/*     */     } else {
/* 157 */       input = this.recycler.allocInputBuffer(length);
/* 158 */       in.getBytes(idx, input, 0, length);
/* 159 */       inputPtr = 0;
/*     */     } 
/*     */ 
/*     */     
/* 163 */     int maxOutputLength = LZFEncoder.estimateMaxWorkspaceSize(length) + 1;
/* 164 */     out.ensureWritable(maxOutputLength);
/*     */ 
/*     */     
/* 167 */     if (out.hasArray()) {
/* 168 */       output = out.array();
/* 169 */       outputPtr = out.arrayOffset() + out.writerIndex();
/*     */     } else {
/* 171 */       output = new byte[maxOutputLength];
/* 172 */       outputPtr = 0;
/*     */     } 
/*     */ 
/*     */     
/* 176 */     if (length >= this.compressThreshold) {
/*     */       
/* 178 */       outputLength = encodeCompress(input, inputPtr, length, output, outputPtr);
/*     */     } else {
/*     */       
/* 181 */       outputLength = encodeNonCompress(input, inputPtr, length, output, outputPtr);
/*     */     } 
/*     */     
/* 184 */     if (out.hasArray()) {
/* 185 */       out.writerIndex(out.writerIndex() + outputLength);
/*     */     } else {
/* 187 */       out.writeBytes(output, 0, outputLength);
/*     */     } 
/*     */     
/* 190 */     in.skipBytes(length);
/*     */     
/* 192 */     if (!in.hasArray()) {
/* 193 */       this.recycler.releaseInputBuffer(input);
/*     */     }
/*     */   }
/*     */   
/*     */   private int encodeCompress(byte[] input, int inputPtr, int length, byte[] output, int outputPtr) {
/* 198 */     return LZFEncoder.appendEncoded(this.encoder, input, inputPtr, length, output, outputPtr) - outputPtr;
/*     */   }
/*     */ 
/*     */   
/*     */   private static int lzfEncodeNonCompress(byte[] input, int inputPtr, int length, byte[] output, int outputPtr) {
/* 203 */     int left = length;
/* 204 */     int chunkLen = Math.min(65535, left);
/* 205 */     outputPtr = LZFChunk.appendNonCompressed(input, inputPtr, chunkLen, output, outputPtr);
/* 206 */     left -= chunkLen;
/* 207 */     if (left < 1) {
/* 208 */       return outputPtr;
/*     */     }
/* 210 */     inputPtr += chunkLen;
/*     */     while (true) {
/* 212 */       chunkLen = Math.min(left, 65535);
/* 213 */       outputPtr = LZFChunk.appendNonCompressed(input, inputPtr, chunkLen, output, outputPtr);
/* 214 */       inputPtr += chunkLen;
/* 215 */       left -= chunkLen;
/* 216 */       if (left <= 0) {
/* 217 */         return outputPtr;
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static int encodeNonCompress(byte[] input, int inputPtr, int length, byte[] output, int outputPtr) {
/* 224 */     return lzfEncodeNonCompress(input, inputPtr, length, output, outputPtr) - outputPtr;
/*     */   }
/*     */ 
/*     */   
/*     */   public void handlerRemoved(ChannelHandlerContext ctx) throws Exception {
/* 229 */     this.encoder.close();
/* 230 */     super.handlerRemoved(ctx);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-4.1.93.Final.jar!\io\netty\handler\codec\compression\LzfEncoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */