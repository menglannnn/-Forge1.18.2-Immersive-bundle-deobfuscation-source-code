/*     */ package io.netty.handler.codec.compression;
/*     */ 
/*     */ import com.aayushatharva.brotli4j.decoder.DecoderJNI;
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import io.netty.buffer.ByteBufAllocator;
/*     */ import io.netty.channel.ChannelHandlerContext;
/*     */ import io.netty.handler.codec.ByteToMessageDecoder;
/*     */ import io.netty.util.internal.ObjectUtil;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class BrotliDecoder
/*     */   extends ByteToMessageDecoder
/*     */ {
/*     */   private final int inputBufferSize;
/*     */   private DecoderJNI.Wrapper decoder;
/*     */   private boolean destroyed;
/*     */   
/*     */   private enum State
/*     */   {
/*  37 */     DONE, NEEDS_MORE_INPUT, ERROR;
/*     */   }
/*     */   
/*     */   static {
/*     */     try {
/*  42 */       Brotli.ensureAvailability();
/*  43 */     } catch (Throwable throwable) {
/*  44 */       throw new ExceptionInInitializerError(throwable);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BrotliDecoder() {
/*  56 */     this(8192);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BrotliDecoder(int inputBufferSize) {
/*  64 */     this.inputBufferSize = ObjectUtil.checkPositive(inputBufferSize, "inputBufferSize");
/*     */   }
/*     */   
/*     */   private ByteBuf pull(ByteBufAllocator alloc) {
/*  68 */     ByteBuffer nativeBuffer = this.decoder.pull();
/*     */     
/*  70 */     ByteBuf copy = alloc.buffer(nativeBuffer.remaining());
/*  71 */     copy.writeBytes(nativeBuffer);
/*  72 */     return copy;
/*     */   } private State decompress(ByteBuf input, List<Object> output, ByteBufAllocator alloc) {
/*     */     while (true) {
/*     */       ByteBuffer decoderInputBuffer;
/*     */       int readBytes;
/*  77 */       switch (this.decoder.getStatus()) {
/*     */         case DONE:
/*  79 */           return State.DONE;
/*     */         
/*     */         case OK:
/*  82 */           this.decoder.push(0);
/*     */           continue;
/*     */         
/*     */         case NEEDS_MORE_INPUT:
/*  86 */           if (this.decoder.hasOutput()) {
/*  87 */             output.add(pull(alloc));
/*     */           }
/*     */           
/*  90 */           if (!input.isReadable()) {
/*  91 */             return State.NEEDS_MORE_INPUT;
/*     */           }
/*     */           
/*  94 */           decoderInputBuffer = this.decoder.getInputBuffer();
/*  95 */           decoderInputBuffer.clear();
/*  96 */           readBytes = readBytes(input, decoderInputBuffer);
/*  97 */           this.decoder.push(readBytes);
/*     */           continue;
/*     */         
/*     */         case NEEDS_MORE_OUTPUT:
/* 101 */           output.add(pull(alloc)); continue;
/*     */       } 
/*     */       break;
/*     */     } 
/* 105 */     return State.ERROR;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static int readBytes(ByteBuf in, ByteBuffer dest) {
/* 111 */     int limit = Math.min(in.readableBytes(), dest.remaining());
/* 112 */     ByteBuffer slice = dest.slice();
/* 113 */     slice.limit(limit);
/* 114 */     in.readBytes(slice);
/* 115 */     dest.position(dest.position() + limit);
/* 116 */     return limit;
/*     */   }
/*     */ 
/*     */   
/*     */   public void handlerAdded(ChannelHandlerContext ctx) throws Exception {
/* 121 */     this.decoder = new DecoderJNI.Wrapper(this.inputBufferSize);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void decode(ChannelHandlerContext ctx, ByteBuf in, List<Object> out) throws Exception {
/* 126 */     if (this.destroyed) {
/*     */       
/* 128 */       in.skipBytes(in.readableBytes());
/*     */       
/*     */       return;
/*     */     } 
/* 132 */     if (!in.isReadable()) {
/*     */       return;
/*     */     }
/*     */     
/*     */     try {
/* 137 */       State state = decompress(in, out, ctx.alloc());
/* 138 */       if (state == State.DONE) {
/* 139 */         destroy();
/* 140 */       } else if (state == State.ERROR) {
/* 141 */         throw new DecompressionException("Brotli stream corrupted");
/*     */       } 
/* 143 */     } catch (Exception e) {
/* 144 */       destroy();
/* 145 */       throw e;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void destroy() {
/* 150 */     if (!this.destroyed) {
/* 151 */       this.destroyed = true;
/* 152 */       this.decoder.destroy();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void handlerRemoved0(ChannelHandlerContext ctx) throws Exception {
/*     */     try {
/* 159 */       destroy();
/*     */     } finally {
/* 161 */       super.handlerRemoved0(ctx);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void channelInactive(ChannelHandlerContext ctx) throws Exception {
/*     */     try {
/* 168 */       destroy();
/*     */     } finally {
/* 170 */       super.channelInactive(ctx);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-4.1.93.Final.jar!\io\netty\handler\codec\compression\BrotliDecoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */