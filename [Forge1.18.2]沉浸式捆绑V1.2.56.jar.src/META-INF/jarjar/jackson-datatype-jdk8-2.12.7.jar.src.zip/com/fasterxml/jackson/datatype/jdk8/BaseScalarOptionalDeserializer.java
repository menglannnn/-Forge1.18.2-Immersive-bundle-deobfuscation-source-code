/*    */ package com.fasterxml.jackson.datatype.jdk8;
/*    */ 
/*    */ import com.fasterxml.jackson.databind.DeserializationContext;
/*    */ import com.fasterxml.jackson.databind.deser.std.StdScalarDeserializer;
/*    */ 
/*    */ 
/*    */ public abstract class BaseScalarOptionalDeserializer<T>
/*    */   extends StdScalarDeserializer<T>
/*    */ {
/*    */   protected final T _empty;
/*    */   
/*    */   protected BaseScalarOptionalDeserializer(Class<T> cls, T empty) {
/* 13 */     super(cls);
/* 14 */     this._empty = empty;
/*    */   }
/*    */ 
/*    */   
/*    */   public T getNullValue(DeserializationContext ctxt) {
/* 19 */     return this._empty;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-datatype-jdk8-2.12.7.jar!\com\fasterxml\jackson\datatype\jdk8\BaseScalarOptionalDeserializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */