/*    */ package com.fasterxml.jackson.datatype.jdk8;
/*    */ 
/*    */ import com.fasterxml.jackson.core.Version;
/*    */ import com.fasterxml.jackson.databind.Module;
/*    */ import com.fasterxml.jackson.databind.deser.Deserializers;
/*    */ import com.fasterxml.jackson.databind.ser.Serializers;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Jdk8Module
/*    */   extends Module
/*    */ {
/*    */   protected boolean _cfgHandleAbsentAsNull = false;
/*    */   
/*    */   public void setupModule(Module.SetupContext context) {
/* 29 */     context.addSerializers((Serializers)new Jdk8Serializers());
/* 30 */     context.addDeserializers((Deserializers)new Jdk8Deserializers());
/*    */     
/* 32 */     context.addTypeModifier(new Jdk8TypeModifier());
/*    */ 
/*    */     
/* 35 */     if (this._cfgHandleAbsentAsNull) {
/* 36 */       context.addBeanSerializerModifier(new Jdk8BeanSerializerModifier());
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public Version version() {
/* 42 */     return PackageVersion.VERSION;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Jdk8Module configureAbsentsAsNulls(boolean state) {
/* 64 */     this._cfgHandleAbsentAsNull = state;
/* 65 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 70 */     return getClass().hashCode();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object o) {
/* 75 */     return (this == o);
/*    */   }
/*    */ 
/*    */   
/*    */   public String getModuleName() {
/* 80 */     return "Jdk8Module";
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-datatype-jdk8-2.12.7.jar!\com\fasterxml\jackson\datatype\jdk8\Jdk8Module.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */