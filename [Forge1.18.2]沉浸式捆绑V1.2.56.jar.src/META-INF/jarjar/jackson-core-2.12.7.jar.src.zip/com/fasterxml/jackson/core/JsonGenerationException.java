/*    */ package com.fasterxml.jackson.core;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JsonGenerationException
/*    */   extends JsonProcessingException
/*    */ {
/*    */   private static final long serialVersionUID = 123L;
/*    */   protected transient JsonGenerator _processor;
/*    */   
/*    */   @Deprecated
/*    */   public JsonGenerationException(Throwable rootCause) {
/* 23 */     super(rootCause);
/*    */   }
/*    */   
/*    */   @Deprecated
/*    */   public JsonGenerationException(String msg) {
/* 28 */     super(msg, (JsonLocation)null);
/*    */   }
/*    */   
/*    */   @Deprecated
/*    */   public JsonGenerationException(String msg, Throwable rootCause) {
/* 33 */     super(msg, null, rootCause);
/*    */   }
/*    */ 
/*    */   
/*    */   public JsonGenerationException(Throwable rootCause, JsonGenerator g) {
/* 38 */     super(rootCause);
/* 39 */     this._processor = g;
/*    */   }
/*    */ 
/*    */   
/*    */   public JsonGenerationException(String msg, JsonGenerator g) {
/* 44 */     super(msg, (JsonLocation)null);
/* 45 */     this._processor = g;
/*    */   }
/*    */ 
/*    */   
/*    */   public JsonGenerationException(String msg, Throwable rootCause, JsonGenerator g) {
/* 50 */     super(msg, null, rootCause);
/* 51 */     this._processor = g;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public JsonGenerationException withGenerator(JsonGenerator g) {
/* 65 */     this._processor = g;
/* 66 */     return this;
/*    */   }
/*    */   
/*    */   public JsonGenerator getProcessor() {
/* 70 */     return this._processor;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-core-2.12.7.jar!\com\fasterxml\jackson\core\JsonGenerationException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */