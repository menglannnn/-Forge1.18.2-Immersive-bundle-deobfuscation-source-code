/*     */ package com.fasterxml.jackson.core.format;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonFactory;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.Collection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DataFormatDetector
/*     */ {
/*     */   public static final int DEFAULT_MAX_INPUT_LOOKAHEAD = 64;
/*     */   protected final JsonFactory[] _detectors;
/*     */   protected final MatchStrength _optimalMatch;
/*     */   protected final MatchStrength _minimalMatch;
/*     */   protected final int _maxInputLookahead;
/*     */   
/*     */   public DataFormatDetector(JsonFactory... detectors) {
/*  58 */     this(detectors, MatchStrength.SOLID_MATCH, MatchStrength.WEAK_MATCH, 64);
/*     */   }
/*     */ 
/*     */   
/*     */   public DataFormatDetector(Collection<JsonFactory> detectors) {
/*  63 */     this(detectors.<JsonFactory>toArray(new JsonFactory[0]));
/*     */   }
/*     */ 
/*     */   
/*     */   private DataFormatDetector(JsonFactory[] detectors, MatchStrength optMatch, MatchStrength minMatch, int maxInputLookahead) {
/*  68 */     this._detectors = detectors;
/*  69 */     this._optimalMatch = optMatch;
/*  70 */     this._minimalMatch = minMatch;
/*  71 */     this._maxInputLookahead = maxInputLookahead;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DataFormatDetector withOptimalMatch(MatchStrength optMatch) {
/*  80 */     if (optMatch == this._optimalMatch) {
/*  81 */       return this;
/*     */     }
/*  83 */     return new DataFormatDetector(this._detectors, optMatch, this._minimalMatch, this._maxInputLookahead);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DataFormatDetector withMinimalMatch(MatchStrength minMatch) {
/*  91 */     if (minMatch == this._minimalMatch) {
/*  92 */       return this;
/*     */     }
/*  94 */     return new DataFormatDetector(this._detectors, this._optimalMatch, minMatch, this._maxInputLookahead);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DataFormatDetector withMaxInputLookahead(int lookaheadBytes) {
/* 102 */     if (lookaheadBytes == this._maxInputLookahead) {
/* 103 */       return this;
/*     */     }
/* 105 */     return new DataFormatDetector(this._detectors, this._optimalMatch, this._minimalMatch, lookaheadBytes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DataFormatMatcher findFormat(InputStream in) throws IOException {
/* 123 */     return _findFormat(new InputAccessor.Std(in, new byte[this._maxInputLookahead]));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DataFormatMatcher findFormat(byte[] fullInputData) throws IOException {
/* 134 */     return _findFormat(new InputAccessor.Std(fullInputData));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DataFormatMatcher findFormat(byte[] fullInputData, int offset, int len) throws IOException {
/* 147 */     return _findFormat(new InputAccessor.Std(fullInputData, offset, len));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 157 */     StringBuilder sb = new StringBuilder();
/* 158 */     sb.append('[');
/* 159 */     int len = this._detectors.length;
/* 160 */     if (len > 0) {
/* 161 */       sb.append(this._detectors[0].getFormatName());
/* 162 */       for (int i = 1; i < len; i++) {
/* 163 */         sb.append(", ");
/* 164 */         sb.append(this._detectors[i].getFormatName());
/*     */       } 
/*     */     } 
/* 167 */     sb.append(']');
/* 168 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private DataFormatMatcher _findFormat(InputAccessor.Std acc) throws IOException {
/* 178 */     JsonFactory bestMatch = null;
/* 179 */     MatchStrength bestMatchStrength = null;
/* 180 */     for (JsonFactory f : this._detectors) {
/* 181 */       acc.reset();
/* 182 */       MatchStrength strength = f.hasFormat(acc);
/*     */       
/* 184 */       if (strength != null && strength.ordinal() >= this._minimalMatch.ordinal())
/*     */       {
/*     */ 
/*     */         
/* 188 */         if (bestMatch == null || 
/* 189 */           bestMatchStrength.ordinal() < strength.ordinal()) {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 194 */           bestMatch = f;
/* 195 */           bestMatchStrength = strength;
/* 196 */           if (strength.ordinal() >= this._optimalMatch.ordinal())
/*     */             break; 
/*     */         }  } 
/*     */     } 
/* 200 */     return acc.createMatcher(bestMatch, bestMatchStrength);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-core-2.12.7.jar!\com\fasterxml\jackson\core\format\DataFormatDetector.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */