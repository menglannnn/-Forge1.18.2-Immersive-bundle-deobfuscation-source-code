/*      */ package com.fasterxml.jackson.core.json;
/*      */ 
/*      */ import com.fasterxml.jackson.core.Base64Variant;
/*      */ import com.fasterxml.jackson.core.JsonLocation;
/*      */ import com.fasterxml.jackson.core.JsonParseException;
/*      */ import com.fasterxml.jackson.core.JsonParser;
/*      */ import com.fasterxml.jackson.core.JsonToken;
/*      */ import com.fasterxml.jackson.core.ObjectCodec;
/*      */ import com.fasterxml.jackson.core.SerializableString;
/*      */ import com.fasterxml.jackson.core.StreamReadCapability;
/*      */ import com.fasterxml.jackson.core.base.ParserBase;
/*      */ import com.fasterxml.jackson.core.io.CharTypes;
/*      */ import com.fasterxml.jackson.core.io.IOContext;
/*      */ import com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer;
/*      */ import com.fasterxml.jackson.core.util.ByteArrayBuilder;
/*      */ import com.fasterxml.jackson.core.util.JacksonFeatureSet;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.OutputStream;
/*      */ import java.io.Writer;
/*      */ 
/*      */ public class UTF8StreamJsonParser extends ParserBase {
/*      */   static final byte BYTE_LF = 10;
/*   24 */   private static final int FEAT_MASK_TRAILING_COMMA = JsonParser.Feature.ALLOW_TRAILING_COMMA.getMask();
/*      */   
/*   26 */   private static final int FEAT_MASK_LEADING_ZEROS = JsonParser.Feature.ALLOW_NUMERIC_LEADING_ZEROS.getMask();
/*      */   
/*   28 */   private static final int FEAT_MASK_NON_NUM_NUMBERS = JsonParser.Feature.ALLOW_NON_NUMERIC_NUMBERS.getMask();
/*      */   
/*   30 */   private static final int FEAT_MASK_ALLOW_MISSING = JsonParser.Feature.ALLOW_MISSING_VALUES.getMask();
/*   31 */   private static final int FEAT_MASK_ALLOW_SINGLE_QUOTES = JsonParser.Feature.ALLOW_SINGLE_QUOTES.getMask();
/*   32 */   private static final int FEAT_MASK_ALLOW_UNQUOTED_NAMES = JsonParser.Feature.ALLOW_UNQUOTED_FIELD_NAMES.getMask();
/*   33 */   private static final int FEAT_MASK_ALLOW_JAVA_COMMENTS = JsonParser.Feature.ALLOW_COMMENTS.getMask();
/*   34 */   private static final int FEAT_MASK_ALLOW_YAML_COMMENTS = JsonParser.Feature.ALLOW_YAML_COMMENTS.getMask();
/*      */ 
/*      */   
/*   37 */   private static final int[] _icUTF8 = CharTypes.getInputCodeUtf8();
/*      */ 
/*      */ 
/*      */   
/*   41 */   protected static final int[] _icLatin1 = CharTypes.getInputCodeLatin1();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ObjectCodec _objectCodec;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final ByteQuadsCanonicalizer _symbols;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   70 */   protected int[] _quadBuffer = new int[16];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean _tokenIncomplete;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int _quad1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int _nameStartOffset;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int _nameStartRow;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int _nameStartCol;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected InputStream _inputStream;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected byte[] _inputBuffer;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean _bufferRecyclable;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public UTF8StreamJsonParser(IOContext ctxt, int features, InputStream in, ObjectCodec codec, ByteQuadsCanonicalizer sym, byte[] inputBuffer, int start, int end, boolean bufferRecyclable) {
/*  149 */     this(ctxt, features, in, codec, sym, inputBuffer, start, end, 0, bufferRecyclable);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public UTF8StreamJsonParser(IOContext ctxt, int features, InputStream in, ObjectCodec codec, ByteQuadsCanonicalizer sym, byte[] inputBuffer, int start, int end, int bytesPreProcessed, boolean bufferRecyclable) {
/*  158 */     super(ctxt, features);
/*  159 */     this._inputStream = in;
/*  160 */     this._objectCodec = codec;
/*  161 */     this._symbols = sym;
/*  162 */     this._inputBuffer = inputBuffer;
/*  163 */     this._inputPtr = start;
/*  164 */     this._inputEnd = end;
/*  165 */     this._currInputRowStart = start - bytesPreProcessed;
/*      */     
/*  167 */     this._currInputProcessed = (-start + bytesPreProcessed);
/*  168 */     this._bufferRecyclable = bufferRecyclable;
/*      */   }
/*      */ 
/*      */   
/*      */   public ObjectCodec getCodec() {
/*  173 */     return this._objectCodec;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setCodec(ObjectCodec c) {
/*  178 */     this._objectCodec = c;
/*      */   }
/*      */ 
/*      */   
/*      */   public JacksonFeatureSet<StreamReadCapability> getReadCapabilities() {
/*  183 */     return JSON_READ_CAPABILITIES;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int releaseBuffered(OutputStream out) throws IOException {
/*  195 */     int count = this._inputEnd - this._inputPtr;
/*  196 */     if (count < 1) {
/*  197 */       return 0;
/*      */     }
/*      */     
/*  200 */     int origPtr = this._inputPtr;
/*  201 */     this._inputPtr += count;
/*  202 */     out.write(this._inputBuffer, origPtr, count);
/*  203 */     return count;
/*      */   }
/*      */ 
/*      */   
/*      */   public Object getInputSource() {
/*  208 */     return this._inputStream;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final boolean _loadMore() throws IOException {
/*  219 */     if (this._inputStream != null) {
/*  220 */       int space = this._inputBuffer.length;
/*  221 */       if (space == 0) {
/*  222 */         return false;
/*      */       }
/*      */       
/*  225 */       int count = this._inputStream.read(this._inputBuffer, 0, space);
/*  226 */       if (count > 0) {
/*  227 */         int bufSize = this._inputEnd;
/*      */         
/*  229 */         this._currInputProcessed += bufSize;
/*  230 */         this._currInputRowStart -= bufSize;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  235 */         this._nameStartOffset -= bufSize;
/*      */         
/*  237 */         this._inputPtr = 0;
/*  238 */         this._inputEnd = count;
/*      */         
/*  240 */         return true;
/*      */       } 
/*      */       
/*  243 */       _closeInput();
/*      */       
/*  245 */       if (count == 0) {
/*  246 */         throw new IOException("InputStream.read() returned 0 characters when trying to read " + this._inputBuffer.length + " bytes");
/*      */       }
/*      */     } 
/*  249 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _closeInput() throws IOException {
/*  257 */     if (this._inputStream != null) {
/*  258 */       if (this._ioContext.isResourceManaged() || isEnabled(JsonParser.Feature.AUTO_CLOSE_SOURCE)) {
/*  259 */         this._inputStream.close();
/*      */       }
/*  261 */       this._inputStream = null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _releaseBuffers() throws IOException {
/*  274 */     super._releaseBuffers();
/*      */     
/*  276 */     this._symbols.release();
/*  277 */     if (this._bufferRecyclable) {
/*  278 */       byte[] buf = this._inputBuffer;
/*  279 */       if (buf != null)
/*      */       {
/*      */         
/*  282 */         if (buf != NO_BYTES) {
/*  283 */           this._inputBuffer = NO_BYTES;
/*  284 */           this._ioContext.releaseReadIOBuffer(buf);
/*      */         } 
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getText() throws IOException {
/*  299 */     if (this._currToken == JsonToken.VALUE_STRING) {
/*  300 */       if (this._tokenIncomplete) {
/*  301 */         this._tokenIncomplete = false;
/*  302 */         return _finishAndReturnString();
/*      */       } 
/*  304 */       return this._textBuffer.contentsAsString();
/*      */     } 
/*  306 */     return _getText2(this._currToken);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getText(Writer writer) throws IOException {
/*  312 */     JsonToken t = this._currToken;
/*  313 */     if (t == JsonToken.VALUE_STRING) {
/*  314 */       if (this._tokenIncomplete) {
/*  315 */         this._tokenIncomplete = false;
/*  316 */         _finishString();
/*      */       } 
/*  318 */       return this._textBuffer.contentsToWriter(writer);
/*      */     } 
/*  320 */     if (t == JsonToken.FIELD_NAME) {
/*  321 */       String n = this._parsingContext.getCurrentName();
/*  322 */       writer.write(n);
/*  323 */       return n.length();
/*      */     } 
/*  325 */     if (t != null) {
/*  326 */       if (t.isNumeric()) {
/*  327 */         return this._textBuffer.contentsToWriter(writer);
/*      */       }
/*  329 */       char[] ch = t.asCharArray();
/*  330 */       writer.write(ch);
/*  331 */       return ch.length;
/*      */     } 
/*  333 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getValueAsString() throws IOException {
/*  342 */     if (this._currToken == JsonToken.VALUE_STRING) {
/*  343 */       if (this._tokenIncomplete) {
/*  344 */         this._tokenIncomplete = false;
/*  345 */         return _finishAndReturnString();
/*      */       } 
/*  347 */       return this._textBuffer.contentsAsString();
/*      */     } 
/*  349 */     if (this._currToken == JsonToken.FIELD_NAME) {
/*  350 */       return getCurrentName();
/*      */     }
/*  352 */     return super.getValueAsString(null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getValueAsString(String defValue) throws IOException {
/*  359 */     if (this._currToken == JsonToken.VALUE_STRING) {
/*  360 */       if (this._tokenIncomplete) {
/*  361 */         this._tokenIncomplete = false;
/*  362 */         return _finishAndReturnString();
/*      */       } 
/*  364 */       return this._textBuffer.contentsAsString();
/*      */     } 
/*  366 */     if (this._currToken == JsonToken.FIELD_NAME) {
/*  367 */       return getCurrentName();
/*      */     }
/*  369 */     return super.getValueAsString(defValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getValueAsInt() throws IOException {
/*  376 */     JsonToken t = this._currToken;
/*  377 */     if (t == JsonToken.VALUE_NUMBER_INT || t == JsonToken.VALUE_NUMBER_FLOAT) {
/*      */       
/*  379 */       if ((this._numTypesValid & 0x1) == 0) {
/*  380 */         if (this._numTypesValid == 0) {
/*  381 */           return _parseIntValue();
/*      */         }
/*  383 */         if ((this._numTypesValid & 0x1) == 0) {
/*  384 */           convertNumberToInt();
/*      */         }
/*      */       } 
/*  387 */       return this._numberInt;
/*      */     } 
/*  389 */     return super.getValueAsInt(0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getValueAsInt(int defValue) throws IOException {
/*  396 */     JsonToken t = this._currToken;
/*  397 */     if (t == JsonToken.VALUE_NUMBER_INT || t == JsonToken.VALUE_NUMBER_FLOAT) {
/*      */       
/*  399 */       if ((this._numTypesValid & 0x1) == 0) {
/*  400 */         if (this._numTypesValid == 0) {
/*  401 */           return _parseIntValue();
/*      */         }
/*  403 */         if ((this._numTypesValid & 0x1) == 0) {
/*  404 */           convertNumberToInt();
/*      */         }
/*      */       } 
/*  407 */       return this._numberInt;
/*      */     } 
/*  409 */     return super.getValueAsInt(defValue);
/*      */   }
/*      */ 
/*      */   
/*      */   protected final String _getText2(JsonToken t) {
/*  414 */     if (t == null) {
/*  415 */       return null;
/*      */     }
/*  417 */     switch (t.id()) {
/*      */       case 5:
/*  419 */         return this._parsingContext.getCurrentName();
/*      */ 
/*      */       
/*      */       case 6:
/*      */       case 7:
/*      */       case 8:
/*  425 */         return this._textBuffer.contentsAsString();
/*      */     } 
/*  427 */     return t.asString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public char[] getTextCharacters() throws IOException {
/*  434 */     if (this._currToken != null) {
/*  435 */       switch (this._currToken.id()) {
/*      */         
/*      */         case 5:
/*  438 */           if (!this._nameCopied) {
/*  439 */             String name = this._parsingContext.getCurrentName();
/*  440 */             int nameLen = name.length();
/*  441 */             if (this._nameCopyBuffer == null) {
/*  442 */               this._nameCopyBuffer = this._ioContext.allocNameCopyBuffer(nameLen);
/*  443 */             } else if (this._nameCopyBuffer.length < nameLen) {
/*  444 */               this._nameCopyBuffer = new char[nameLen];
/*      */             } 
/*  446 */             name.getChars(0, nameLen, this._nameCopyBuffer, 0);
/*  447 */             this._nameCopied = true;
/*      */           } 
/*  449 */           return this._nameCopyBuffer;
/*      */         
/*      */         case 6:
/*  452 */           if (this._tokenIncomplete) {
/*  453 */             this._tokenIncomplete = false;
/*  454 */             _finishString();
/*      */           } 
/*      */         
/*      */         case 7:
/*      */         case 8:
/*  459 */           return this._textBuffer.getTextBuffer();
/*      */       } 
/*      */       
/*  462 */       return this._currToken.asCharArray();
/*      */     } 
/*      */     
/*  465 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getTextLength() throws IOException {
/*  471 */     if (this._currToken != null) {
/*  472 */       switch (this._currToken.id()) {
/*      */         
/*      */         case 5:
/*  475 */           return this._parsingContext.getCurrentName().length();
/*      */         case 6:
/*  477 */           if (this._tokenIncomplete) {
/*  478 */             this._tokenIncomplete = false;
/*  479 */             _finishString();
/*      */           } 
/*      */         
/*      */         case 7:
/*      */         case 8:
/*  484 */           return this._textBuffer.size();
/*      */       } 
/*      */       
/*  487 */       return (this._currToken.asCharArray()).length;
/*      */     } 
/*      */     
/*  490 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getTextOffset() throws IOException {
/*  497 */     if (this._currToken != null) {
/*  498 */       switch (this._currToken.id()) {
/*      */         case 5:
/*  500 */           return 0;
/*      */         case 6:
/*  502 */           if (this._tokenIncomplete) {
/*  503 */             this._tokenIncomplete = false;
/*  504 */             _finishString();
/*      */           } 
/*      */         
/*      */         case 7:
/*      */         case 8:
/*  509 */           return this._textBuffer.getTextOffset();
/*      */       } 
/*      */     
/*      */     }
/*  513 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] getBinaryValue(Base64Variant b64variant) throws IOException {
/*  519 */     if (this._currToken != JsonToken.VALUE_STRING && (this._currToken != JsonToken.VALUE_EMBEDDED_OBJECT || this._binaryValue == null))
/*      */     {
/*  521 */       _reportError("Current token (" + this._currToken + ") not VALUE_STRING or VALUE_EMBEDDED_OBJECT, can not access as binary");
/*      */     }
/*      */     
/*  524 */     if (this._tokenIncomplete) {
/*      */       try {
/*  526 */         this._binaryValue = _decodeBase64(b64variant);
/*  527 */       } catch (IllegalArgumentException iae) {
/*  528 */         throw _constructError("Failed to decode VALUE_STRING as base64 (" + b64variant + "): " + iae.getMessage());
/*      */       } 
/*      */       
/*  531 */       this._tokenIncomplete = false;
/*      */     }
/*  533 */     else if (this._binaryValue == null) {
/*      */       
/*  535 */       ByteArrayBuilder builder = _getByteArrayBuilder();
/*  536 */       _decodeBase64(getText(), builder, b64variant);
/*  537 */       this._binaryValue = builder.toByteArray();
/*      */     } 
/*      */     
/*  540 */     return this._binaryValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int readBinaryValue(Base64Variant b64variant, OutputStream out) throws IOException {
/*  547 */     if (!this._tokenIncomplete || this._currToken != JsonToken.VALUE_STRING) {
/*  548 */       byte[] b = getBinaryValue(b64variant);
/*  549 */       out.write(b);
/*  550 */       return b.length;
/*      */     } 
/*      */     
/*  553 */     byte[] buf = this._ioContext.allocBase64Buffer();
/*      */     try {
/*  555 */       return _readBinary(b64variant, out, buf);
/*      */     } finally {
/*  557 */       this._ioContext.releaseBase64Buffer(buf);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected int _readBinary(Base64Variant b64variant, OutputStream out, byte[] buffer) throws IOException {
/*  564 */     int outputPtr = 0;
/*  565 */     int outputEnd = buffer.length - 3;
/*  566 */     int outputCount = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     while (true) {
/*  572 */       if (this._inputPtr >= this._inputEnd) {
/*  573 */         _loadMoreGuaranteed();
/*      */       }
/*  575 */       int ch = this._inputBuffer[this._inputPtr++] & 0xFF;
/*  576 */       if (ch > 32) {
/*  577 */         int bits = b64variant.decodeBase64Char(ch);
/*  578 */         if (bits < 0) {
/*  579 */           if (ch == 34) {
/*      */             break;
/*      */           }
/*  582 */           bits = _decodeBase64Escape(b64variant, ch, 0);
/*  583 */           if (bits < 0) {
/*      */             continue;
/*      */           }
/*      */         } 
/*      */ 
/*      */         
/*  589 */         if (outputPtr > outputEnd) {
/*  590 */           outputCount += outputPtr;
/*  591 */           out.write(buffer, 0, outputPtr);
/*  592 */           outputPtr = 0;
/*      */         } 
/*      */         
/*  595 */         int decodedData = bits;
/*      */ 
/*      */ 
/*      */         
/*  599 */         if (this._inputPtr >= this._inputEnd) {
/*  600 */           _loadMoreGuaranteed();
/*      */         }
/*  602 */         ch = this._inputBuffer[this._inputPtr++] & 0xFF;
/*  603 */         bits = b64variant.decodeBase64Char(ch);
/*  604 */         if (bits < 0) {
/*  605 */           bits = _decodeBase64Escape(b64variant, ch, 1);
/*      */         }
/*  607 */         decodedData = decodedData << 6 | bits;
/*      */ 
/*      */         
/*  610 */         if (this._inputPtr >= this._inputEnd) {
/*  611 */           _loadMoreGuaranteed();
/*      */         }
/*  613 */         ch = this._inputBuffer[this._inputPtr++] & 0xFF;
/*  614 */         bits = b64variant.decodeBase64Char(ch);
/*      */ 
/*      */         
/*  617 */         if (bits < 0) {
/*  618 */           if (bits != -2) {
/*      */             
/*  620 */             if (ch == 34) {
/*  621 */               decodedData >>= 4;
/*  622 */               buffer[outputPtr++] = (byte)decodedData;
/*  623 */               if (b64variant.usesPadding()) {
/*  624 */                 this._inputPtr--;
/*  625 */                 _handleBase64MissingPadding(b64variant);
/*      */               } 
/*      */               break;
/*      */             } 
/*  629 */             bits = _decodeBase64Escape(b64variant, ch, 2);
/*      */           } 
/*  631 */           if (bits == -2) {
/*      */             
/*  633 */             if (this._inputPtr >= this._inputEnd) {
/*  634 */               _loadMoreGuaranteed();
/*      */             }
/*  636 */             ch = this._inputBuffer[this._inputPtr++] & 0xFF;
/*  637 */             if (!b64variant.usesPaddingChar(ch) && 
/*  638 */               _decodeBase64Escape(b64variant, ch, 3) != -2) {
/*  639 */               throw reportInvalidBase64Char(b64variant, ch, 3, "expected padding character '" + b64variant.getPaddingChar() + "'");
/*      */             }
/*      */ 
/*      */             
/*  643 */             decodedData >>= 4;
/*  644 */             buffer[outputPtr++] = (byte)decodedData;
/*      */             
/*      */             continue;
/*      */           } 
/*      */         } 
/*  649 */         decodedData = decodedData << 6 | bits;
/*      */         
/*  651 */         if (this._inputPtr >= this._inputEnd) {
/*  652 */           _loadMoreGuaranteed();
/*      */         }
/*  654 */         ch = this._inputBuffer[this._inputPtr++] & 0xFF;
/*  655 */         bits = b64variant.decodeBase64Char(ch);
/*  656 */         if (bits < 0) {
/*  657 */           if (bits != -2) {
/*      */             
/*  659 */             if (ch == 34) {
/*  660 */               decodedData >>= 2;
/*  661 */               buffer[outputPtr++] = (byte)(decodedData >> 8);
/*  662 */               buffer[outputPtr++] = (byte)decodedData;
/*  663 */               if (b64variant.usesPadding()) {
/*  664 */                 this._inputPtr--;
/*  665 */                 _handleBase64MissingPadding(b64variant);
/*      */               } 
/*      */               break;
/*      */             } 
/*  669 */             bits = _decodeBase64Escape(b64variant, ch, 3);
/*      */           } 
/*  671 */           if (bits == -2) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  678 */             decodedData >>= 2;
/*  679 */             buffer[outputPtr++] = (byte)(decodedData >> 8);
/*  680 */             buffer[outputPtr++] = (byte)decodedData;
/*      */             
/*      */             continue;
/*      */           } 
/*      */         } 
/*  685 */         decodedData = decodedData << 6 | bits;
/*  686 */         buffer[outputPtr++] = (byte)(decodedData >> 16);
/*  687 */         buffer[outputPtr++] = (byte)(decodedData >> 8);
/*  688 */         buffer[outputPtr++] = (byte)decodedData;
/*      */       } 
/*  690 */     }  this._tokenIncomplete = false;
/*  691 */     if (outputPtr > 0) {
/*  692 */       outputCount += outputPtr;
/*  693 */       out.write(buffer, 0, outputPtr);
/*      */     } 
/*  695 */     return outputCount;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonToken nextToken() throws IOException {
/*  715 */     if (this._currToken == JsonToken.FIELD_NAME) {
/*  716 */       return _nextAfterName();
/*      */     }
/*      */ 
/*      */     
/*  720 */     this._numTypesValid = 0;
/*  721 */     if (this._tokenIncomplete) {
/*  722 */       _skipString();
/*      */     }
/*  724 */     int i = _skipWSOrEnd();
/*  725 */     if (i < 0) {
/*      */       
/*  727 */       close();
/*  728 */       return this._currToken = null;
/*      */     } 
/*      */     
/*  731 */     this._binaryValue = null;
/*      */ 
/*      */     
/*  734 */     if (i == 93) {
/*  735 */       _closeArrayScope();
/*  736 */       return this._currToken = JsonToken.END_ARRAY;
/*      */     } 
/*  738 */     if (i == 125) {
/*  739 */       _closeObjectScope();
/*  740 */       return this._currToken = JsonToken.END_OBJECT;
/*      */     } 
/*      */ 
/*      */     
/*  744 */     if (this._parsingContext.expectComma()) {
/*  745 */       if (i != 44) {
/*  746 */         _reportUnexpectedChar(i, "was expecting comma to separate " + this._parsingContext.typeDesc() + " entries");
/*      */       }
/*  748 */       i = _skipWS();
/*      */       
/*  750 */       if ((this._features & FEAT_MASK_TRAILING_COMMA) != 0 && (
/*  751 */         i == 93 || i == 125)) {
/*  752 */         return _closeScope(i);
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  760 */     if (!this._parsingContext.inObject()) {
/*  761 */       _updateLocation();
/*  762 */       return _nextTokenNotInObject(i);
/*      */     } 
/*      */     
/*  765 */     _updateNameLocation();
/*  766 */     String n = _parseName(i);
/*  767 */     this._parsingContext.setCurrentName(n);
/*  768 */     this._currToken = JsonToken.FIELD_NAME;
/*      */     
/*  770 */     i = _skipColon();
/*  771 */     _updateLocation();
/*      */ 
/*      */     
/*  774 */     if (i == 34) {
/*  775 */       this._tokenIncomplete = true;
/*  776 */       this._nextToken = JsonToken.VALUE_STRING;
/*  777 */       return this._currToken;
/*      */     } 
/*      */ 
/*      */     
/*  781 */     switch (i)
/*      */     { case 45:
/*  783 */         t = _parseNegNumber();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  825 */         this._nextToken = t;
/*  826 */         return this._currToken;case 46: t = _parseFloatThatStartsWithPeriod(); this._nextToken = t; return this._currToken;case 48: case 49: case 50: case 51: case 52: case 53: case 54: case 55: case 56: case 57: t = _parsePosNumber(i); this._nextToken = t; return this._currToken;case 102: _matchFalse(); t = JsonToken.VALUE_FALSE; this._nextToken = t; return this._currToken;case 110: _matchNull(); t = JsonToken.VALUE_NULL; this._nextToken = t; return this._currToken;case 116: _matchTrue(); t = JsonToken.VALUE_TRUE; this._nextToken = t; return this._currToken;case 91: t = JsonToken.START_ARRAY; this._nextToken = t; return this._currToken;case 123: t = JsonToken.START_OBJECT; this._nextToken = t; return this._currToken; }  JsonToken t = _handleUnexpectedValue(i); this._nextToken = t; return this._currToken;
/*      */   }
/*      */ 
/*      */   
/*      */   private final JsonToken _nextTokenNotInObject(int i) throws IOException {
/*  831 */     if (i == 34) {
/*  832 */       this._tokenIncomplete = true;
/*  833 */       return this._currToken = JsonToken.VALUE_STRING;
/*      */     } 
/*  835 */     switch (i) {
/*      */       case 91:
/*  837 */         this._parsingContext = this._parsingContext.createChildArrayContext(this._tokenInputRow, this._tokenInputCol);
/*  838 */         return this._currToken = JsonToken.START_ARRAY;
/*      */       case 123:
/*  840 */         this._parsingContext = this._parsingContext.createChildObjectContext(this._tokenInputRow, this._tokenInputCol);
/*  841 */         return this._currToken = JsonToken.START_OBJECT;
/*      */       case 116:
/*  843 */         _matchTrue();
/*  844 */         return this._currToken = JsonToken.VALUE_TRUE;
/*      */       case 102:
/*  846 */         _matchFalse();
/*  847 */         return this._currToken = JsonToken.VALUE_FALSE;
/*      */       case 110:
/*  849 */         _matchNull();
/*  850 */         return this._currToken = JsonToken.VALUE_NULL;
/*      */       case 45:
/*  852 */         return this._currToken = _parseNegNumber();
/*      */ 
/*      */ 
/*      */       
/*      */       case 46:
/*  857 */         return this._currToken = _parseFloatThatStartsWithPeriod();
/*      */       case 48:
/*      */       case 49:
/*      */       case 50:
/*      */       case 51:
/*      */       case 52:
/*      */       case 53:
/*      */       case 54:
/*      */       case 55:
/*      */       case 56:
/*      */       case 57:
/*  868 */         return this._currToken = _parsePosNumber(i);
/*      */     } 
/*  870 */     return this._currToken = _handleUnexpectedValue(i);
/*      */   }
/*      */ 
/*      */   
/*      */   private final JsonToken _nextAfterName() {
/*  875 */     this._nameCopied = false;
/*  876 */     JsonToken t = this._nextToken;
/*  877 */     this._nextToken = null;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  882 */     if (t == JsonToken.START_ARRAY) {
/*  883 */       this._parsingContext = this._parsingContext.createChildArrayContext(this._tokenInputRow, this._tokenInputCol);
/*  884 */     } else if (t == JsonToken.START_OBJECT) {
/*  885 */       this._parsingContext = this._parsingContext.createChildObjectContext(this._tokenInputRow, this._tokenInputCol);
/*      */     } 
/*  887 */     return this._currToken = t;
/*      */   }
/*      */ 
/*      */   
/*      */   public void finishToken() throws IOException {
/*  892 */     if (this._tokenIncomplete) {
/*  893 */       this._tokenIncomplete = false;
/*  894 */       _finishString();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean nextFieldName(SerializableString str) throws IOException {
/*  908 */     this._numTypesValid = 0;
/*  909 */     if (this._currToken == JsonToken.FIELD_NAME) {
/*  910 */       _nextAfterName();
/*  911 */       return false;
/*      */     } 
/*  913 */     if (this._tokenIncomplete) {
/*  914 */       _skipString();
/*      */     }
/*  916 */     int i = _skipWSOrEnd();
/*  917 */     if (i < 0) {
/*  918 */       close();
/*  919 */       this._currToken = null;
/*  920 */       return false;
/*      */     } 
/*  922 */     this._binaryValue = null;
/*      */ 
/*      */     
/*  925 */     if (i == 93) {
/*  926 */       _closeArrayScope();
/*  927 */       this._currToken = JsonToken.END_ARRAY;
/*  928 */       return false;
/*      */     } 
/*  930 */     if (i == 125) {
/*  931 */       _closeObjectScope();
/*  932 */       this._currToken = JsonToken.END_OBJECT;
/*  933 */       return false;
/*      */     } 
/*      */ 
/*      */     
/*  937 */     if (this._parsingContext.expectComma()) {
/*  938 */       if (i != 44) {
/*  939 */         _reportUnexpectedChar(i, "was expecting comma to separate " + this._parsingContext.typeDesc() + " entries");
/*      */       }
/*  941 */       i = _skipWS();
/*      */ 
/*      */       
/*  944 */       if ((this._features & FEAT_MASK_TRAILING_COMMA) != 0 && (
/*  945 */         i == 93 || i == 125)) {
/*  946 */         _closeScope(i);
/*  947 */         return false;
/*      */       } 
/*      */     } 
/*      */     
/*  951 */     if (!this._parsingContext.inObject()) {
/*  952 */       _updateLocation();
/*  953 */       _nextTokenNotInObject(i);
/*  954 */       return false;
/*      */     } 
/*      */ 
/*      */     
/*  958 */     _updateNameLocation();
/*  959 */     if (i == 34) {
/*      */       
/*  961 */       byte[] nameBytes = str.asQuotedUTF8();
/*  962 */       int len = nameBytes.length;
/*      */ 
/*      */       
/*  965 */       if (this._inputPtr + len + 4 < this._inputEnd) {
/*      */         
/*  967 */         int end = this._inputPtr + len;
/*  968 */         if (this._inputBuffer[end] == 34) {
/*  969 */           int offset = 0;
/*  970 */           int ptr = this._inputPtr;
/*      */           while (true) {
/*  972 */             if (ptr == end) {
/*  973 */               this._parsingContext.setCurrentName(str.getValue());
/*  974 */               i = _skipColonFast(ptr + 1);
/*  975 */               _isNextTokenNameYes(i);
/*  976 */               return true;
/*      */             } 
/*  978 */             if (nameBytes[offset] != this._inputBuffer[ptr]) {
/*      */               break;
/*      */             }
/*  981 */             offset++;
/*  982 */             ptr++;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*  987 */     return _isNextTokenNameMaybe(i, str);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String nextFieldName() throws IOException {
/*  994 */     this._numTypesValid = 0;
/*  995 */     if (this._currToken == JsonToken.FIELD_NAME) {
/*  996 */       _nextAfterName();
/*  997 */       return null;
/*      */     } 
/*  999 */     if (this._tokenIncomplete) {
/* 1000 */       _skipString();
/*      */     }
/* 1002 */     int i = _skipWSOrEnd();
/* 1003 */     if (i < 0) {
/* 1004 */       close();
/* 1005 */       this._currToken = null;
/* 1006 */       return null;
/*      */     } 
/* 1008 */     this._binaryValue = null;
/*      */     
/* 1010 */     if (i == 93) {
/* 1011 */       _closeArrayScope();
/* 1012 */       this._currToken = JsonToken.END_ARRAY;
/* 1013 */       return null;
/*      */     } 
/* 1015 */     if (i == 125) {
/* 1016 */       _closeObjectScope();
/* 1017 */       this._currToken = JsonToken.END_OBJECT;
/* 1018 */       return null;
/*      */     } 
/*      */ 
/*      */     
/* 1022 */     if (this._parsingContext.expectComma()) {
/* 1023 */       if (i != 44) {
/* 1024 */         _reportUnexpectedChar(i, "was expecting comma to separate " + this._parsingContext.typeDesc() + " entries");
/*      */       }
/* 1026 */       i = _skipWS();
/*      */       
/* 1028 */       if ((this._features & FEAT_MASK_TRAILING_COMMA) != 0 && (
/* 1029 */         i == 93 || i == 125)) {
/* 1030 */         _closeScope(i);
/* 1031 */         return null;
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1036 */     if (!this._parsingContext.inObject()) {
/* 1037 */       _updateLocation();
/* 1038 */       _nextTokenNotInObject(i);
/* 1039 */       return null;
/*      */     } 
/*      */     
/* 1042 */     _updateNameLocation();
/* 1043 */     String nameStr = _parseName(i);
/* 1044 */     this._parsingContext.setCurrentName(nameStr);
/* 1045 */     this._currToken = JsonToken.FIELD_NAME;
/*      */     
/* 1047 */     i = _skipColon();
/* 1048 */     _updateLocation();
/* 1049 */     if (i == 34) {
/* 1050 */       this._tokenIncomplete = true;
/* 1051 */       this._nextToken = JsonToken.VALUE_STRING;
/* 1052 */       return nameStr;
/*      */     } 
/*      */     
/* 1055 */     switch (i)
/*      */     { case 45:
/* 1057 */         t = _parseNegNumber();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1096 */         this._nextToken = t;
/* 1097 */         return nameStr;case 46: t = _parseFloatThatStartsWithPeriod(); this._nextToken = t; return nameStr;case 48: case 49: case 50: case 51: case 52: case 53: case 54: case 55: case 56: case 57: t = _parsePosNumber(i); this._nextToken = t; return nameStr;case 102: _matchFalse(); t = JsonToken.VALUE_FALSE; this._nextToken = t; return nameStr;case 110: _matchNull(); t = JsonToken.VALUE_NULL; this._nextToken = t; return nameStr;case 116: _matchTrue(); t = JsonToken.VALUE_TRUE; this._nextToken = t; return nameStr;case 91: t = JsonToken.START_ARRAY; this._nextToken = t; return nameStr;case 123: t = JsonToken.START_OBJECT; this._nextToken = t; return nameStr; }  JsonToken t = _handleUnexpectedValue(i); this._nextToken = t; return nameStr;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private final int _skipColonFast(int ptr) throws IOException {
/* 1103 */     int i = this._inputBuffer[ptr++];
/* 1104 */     if (i == 58) {
/* 1105 */       i = this._inputBuffer[ptr++];
/* 1106 */       if (i > 32) {
/* 1107 */         if (i != 47 && i != 35) {
/* 1108 */           this._inputPtr = ptr;
/* 1109 */           return i;
/*      */         } 
/* 1111 */       } else if (i == 32 || i == 9) {
/* 1112 */         i = this._inputBuffer[ptr++];
/* 1113 */         if (i > 32 && 
/* 1114 */           i != 47 && i != 35) {
/* 1115 */           this._inputPtr = ptr;
/* 1116 */           return i;
/*      */         } 
/*      */       } 
/*      */       
/* 1120 */       this._inputPtr = ptr - 1;
/* 1121 */       return _skipColon2(true);
/*      */     } 
/* 1123 */     if (i == 32 || i == 9) {
/* 1124 */       i = this._inputBuffer[ptr++];
/*      */     }
/* 1126 */     if (i == 58) {
/* 1127 */       i = this._inputBuffer[ptr++];
/* 1128 */       if (i > 32) {
/* 1129 */         if (i != 47 && i != 35) {
/* 1130 */           this._inputPtr = ptr;
/* 1131 */           return i;
/*      */         } 
/* 1133 */       } else if (i == 32 || i == 9) {
/* 1134 */         i = this._inputBuffer[ptr++];
/* 1135 */         if (i > 32 && 
/* 1136 */           i != 47 && i != 35) {
/* 1137 */           this._inputPtr = ptr;
/* 1138 */           return i;
/*      */         } 
/*      */       } 
/*      */       
/* 1142 */       this._inputPtr = ptr - 1;
/* 1143 */       return _skipColon2(true);
/*      */     } 
/* 1145 */     this._inputPtr = ptr - 1;
/* 1146 */     return _skipColon2(false);
/*      */   }
/*      */ 
/*      */   
/*      */   private final void _isNextTokenNameYes(int i) throws IOException {
/* 1151 */     this._currToken = JsonToken.FIELD_NAME;
/* 1152 */     _updateLocation();
/*      */     
/* 1154 */     switch (i) {
/*      */       case 34:
/* 1156 */         this._tokenIncomplete = true;
/* 1157 */         this._nextToken = JsonToken.VALUE_STRING;
/*      */         return;
/*      */       case 91:
/* 1160 */         this._nextToken = JsonToken.START_ARRAY;
/*      */         return;
/*      */       case 123:
/* 1163 */         this._nextToken = JsonToken.START_OBJECT;
/*      */         return;
/*      */       case 116:
/* 1166 */         _matchTrue();
/* 1167 */         this._nextToken = JsonToken.VALUE_TRUE;
/*      */         return;
/*      */       case 102:
/* 1170 */         _matchFalse();
/* 1171 */         this._nextToken = JsonToken.VALUE_FALSE;
/*      */         return;
/*      */       case 110:
/* 1174 */         _matchNull();
/* 1175 */         this._nextToken = JsonToken.VALUE_NULL;
/*      */         return;
/*      */       case 45:
/* 1178 */         this._nextToken = _parseNegNumber();
/*      */         return;
/*      */       case 46:
/* 1181 */         this._nextToken = _parseFloatThatStartsWithPeriod();
/*      */         return;
/*      */       case 48:
/*      */       case 49:
/*      */       case 50:
/*      */       case 51:
/*      */       case 52:
/*      */       case 53:
/*      */       case 54:
/*      */       case 55:
/*      */       case 56:
/*      */       case 57:
/* 1193 */         this._nextToken = _parsePosNumber(i);
/*      */         return;
/*      */     } 
/* 1196 */     this._nextToken = _handleUnexpectedValue(i);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final boolean _isNextTokenNameMaybe(int i, SerializableString str) throws IOException {
/* 1203 */     String n = _parseName(i);
/* 1204 */     this._parsingContext.setCurrentName(n);
/* 1205 */     boolean match = n.equals(str.getValue());
/* 1206 */     this._currToken = JsonToken.FIELD_NAME;
/* 1207 */     i = _skipColon();
/* 1208 */     _updateLocation();
/*      */ 
/*      */     
/* 1211 */     if (i == 34) {
/* 1212 */       this._tokenIncomplete = true;
/* 1213 */       this._nextToken = JsonToken.VALUE_STRING;
/* 1214 */       return match;
/*      */     } 
/*      */ 
/*      */     
/* 1218 */     switch (i)
/*      */     { case 91:
/* 1220 */         t = JsonToken.START_ARRAY;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1258 */         this._nextToken = t;
/* 1259 */         return match;case 123: t = JsonToken.START_OBJECT; this._nextToken = t; return match;case 116: _matchTrue(); t = JsonToken.VALUE_TRUE; this._nextToken = t; return match;case 102: _matchFalse(); t = JsonToken.VALUE_FALSE; this._nextToken = t; return match;case 110: _matchNull(); t = JsonToken.VALUE_NULL; this._nextToken = t; return match;case 45: t = _parseNegNumber(); this._nextToken = t; return match;case 46: t = _parseFloatThatStartsWithPeriod(); this._nextToken = t; return match;case 48: case 49: case 50: case 51: case 52: case 53: case 54: case 55: case 56: case 57: t = _parsePosNumber(i); this._nextToken = t; return match; }  JsonToken t = _handleUnexpectedValue(i); this._nextToken = t; return match;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String nextTextValue() throws IOException {
/* 1266 */     if (this._currToken == JsonToken.FIELD_NAME) {
/* 1267 */       this._nameCopied = false;
/* 1268 */       JsonToken t = this._nextToken;
/* 1269 */       this._nextToken = null;
/* 1270 */       this._currToken = t;
/* 1271 */       if (t == JsonToken.VALUE_STRING) {
/* 1272 */         if (this._tokenIncomplete) {
/* 1273 */           this._tokenIncomplete = false;
/* 1274 */           return _finishAndReturnString();
/*      */         } 
/* 1276 */         return this._textBuffer.contentsAsString();
/*      */       } 
/* 1278 */       if (t == JsonToken.START_ARRAY) {
/* 1279 */         this._parsingContext = this._parsingContext.createChildArrayContext(this._tokenInputRow, this._tokenInputCol);
/* 1280 */       } else if (t == JsonToken.START_OBJECT) {
/* 1281 */         this._parsingContext = this._parsingContext.createChildObjectContext(this._tokenInputRow, this._tokenInputCol);
/*      */       } 
/* 1283 */       return null;
/*      */     } 
/*      */     
/* 1286 */     return (nextToken() == JsonToken.VALUE_STRING) ? getText() : null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int nextIntValue(int defaultValue) throws IOException {
/* 1293 */     if (this._currToken == JsonToken.FIELD_NAME) {
/* 1294 */       this._nameCopied = false;
/* 1295 */       JsonToken t = this._nextToken;
/* 1296 */       this._nextToken = null;
/* 1297 */       this._currToken = t;
/* 1298 */       if (t == JsonToken.VALUE_NUMBER_INT) {
/* 1299 */         return getIntValue();
/*      */       }
/* 1301 */       if (t == JsonToken.START_ARRAY) {
/* 1302 */         this._parsingContext = this._parsingContext.createChildArrayContext(this._tokenInputRow, this._tokenInputCol);
/* 1303 */       } else if (t == JsonToken.START_OBJECT) {
/* 1304 */         this._parsingContext = this._parsingContext.createChildObjectContext(this._tokenInputRow, this._tokenInputCol);
/*      */       } 
/* 1306 */       return defaultValue;
/*      */     } 
/*      */     
/* 1309 */     return (nextToken() == JsonToken.VALUE_NUMBER_INT) ? getIntValue() : defaultValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long nextLongValue(long defaultValue) throws IOException {
/* 1316 */     if (this._currToken == JsonToken.FIELD_NAME) {
/* 1317 */       this._nameCopied = false;
/* 1318 */       JsonToken t = this._nextToken;
/* 1319 */       this._nextToken = null;
/* 1320 */       this._currToken = t;
/* 1321 */       if (t == JsonToken.VALUE_NUMBER_INT) {
/* 1322 */         return getLongValue();
/*      */       }
/* 1324 */       if (t == JsonToken.START_ARRAY) {
/* 1325 */         this._parsingContext = this._parsingContext.createChildArrayContext(this._tokenInputRow, this._tokenInputCol);
/* 1326 */       } else if (t == JsonToken.START_OBJECT) {
/* 1327 */         this._parsingContext = this._parsingContext.createChildObjectContext(this._tokenInputRow, this._tokenInputCol);
/*      */       } 
/* 1329 */       return defaultValue;
/*      */     } 
/*      */     
/* 1332 */     return (nextToken() == JsonToken.VALUE_NUMBER_INT) ? getLongValue() : defaultValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Boolean nextBooleanValue() throws IOException {
/* 1339 */     if (this._currToken == JsonToken.FIELD_NAME) {
/* 1340 */       this._nameCopied = false;
/* 1341 */       JsonToken jsonToken = this._nextToken;
/* 1342 */       this._nextToken = null;
/* 1343 */       this._currToken = jsonToken;
/* 1344 */       if (jsonToken == JsonToken.VALUE_TRUE) {
/* 1345 */         return Boolean.TRUE;
/*      */       }
/* 1347 */       if (jsonToken == JsonToken.VALUE_FALSE) {
/* 1348 */         return Boolean.FALSE;
/*      */       }
/* 1350 */       if (jsonToken == JsonToken.START_ARRAY) {
/* 1351 */         this._parsingContext = this._parsingContext.createChildArrayContext(this._tokenInputRow, this._tokenInputCol);
/* 1352 */       } else if (jsonToken == JsonToken.START_OBJECT) {
/* 1353 */         this._parsingContext = this._parsingContext.createChildObjectContext(this._tokenInputRow, this._tokenInputCol);
/*      */       } 
/* 1355 */       return null;
/*      */     } 
/*      */     
/* 1358 */     JsonToken t = nextToken();
/* 1359 */     if (t == JsonToken.VALUE_TRUE) {
/* 1360 */       return Boolean.TRUE;
/*      */     }
/* 1362 */     if (t == JsonToken.VALUE_FALSE) {
/* 1363 */       return Boolean.FALSE;
/*      */     }
/* 1365 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final JsonToken _parseFloatThatStartsWithPeriod() throws IOException {
/* 1378 */     if (!isEnabled(JsonReadFeature.ALLOW_LEADING_DECIMAL_POINT_FOR_NUMBERS.mappedFeature())) {
/* 1379 */       return _handleUnexpectedValue(46);
/*      */     }
/* 1381 */     return _parseFloat(this._textBuffer.emptyAndGetCurrentSegment(), 0, 46, false, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonToken _parsePosNumber(int c) throws IOException {
/* 1402 */     char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/*      */     
/* 1404 */     if (c == 48) {
/* 1405 */       c = _verifyNoLeadingZeroes();
/*      */     }
/*      */     
/* 1408 */     outBuf[0] = (char)c;
/* 1409 */     int intLen = 1;
/* 1410 */     int outPtr = 1;
/*      */ 
/*      */     
/* 1413 */     int end = Math.min(this._inputEnd, this._inputPtr + outBuf.length - 1);
/*      */     
/*      */     while (true) {
/* 1416 */       if (this._inputPtr >= end) {
/* 1417 */         return _parseNumber2(outBuf, outPtr, false, intLen);
/*      */       }
/* 1419 */       c = this._inputBuffer[this._inputPtr++] & 0xFF;
/* 1420 */       if (c < 48 || c > 57) {
/*      */         break;
/*      */       }
/* 1423 */       intLen++;
/* 1424 */       outBuf[outPtr++] = (char)c;
/*      */     } 
/* 1426 */     if (c == 46 || c == 101 || c == 69) {
/* 1427 */       return _parseFloat(outBuf, outPtr, c, false, intLen);
/*      */     }
/* 1429 */     this._inputPtr--;
/* 1430 */     this._textBuffer.setCurrentLength(outPtr);
/*      */     
/* 1432 */     if (this._parsingContext.inRoot()) {
/* 1433 */       _verifyRootSpace(c);
/*      */     }
/*      */     
/* 1436 */     return resetInt(false, intLen);
/*      */   }
/*      */ 
/*      */   
/*      */   protected JsonToken _parseNegNumber() throws IOException {
/* 1441 */     char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/* 1442 */     int outPtr = 0;
/*      */ 
/*      */     
/* 1445 */     outBuf[outPtr++] = '-';
/*      */     
/* 1447 */     if (this._inputPtr >= this._inputEnd) {
/* 1448 */       _loadMoreGuaranteed();
/*      */     }
/* 1450 */     int c = this._inputBuffer[this._inputPtr++] & 0xFF;
/*      */     
/* 1452 */     if (c <= 48) {
/*      */       
/* 1454 */       if (c != 48) {
/* 1455 */         return _handleInvalidNumberStart(c, true);
/*      */       }
/* 1457 */       c = _verifyNoLeadingZeroes();
/* 1458 */     } else if (c > 57) {
/* 1459 */       return _handleInvalidNumberStart(c, true);
/*      */     } 
/*      */ 
/*      */     
/* 1463 */     outBuf[outPtr++] = (char)c;
/* 1464 */     int intLen = 1;
/*      */ 
/*      */ 
/*      */     
/* 1468 */     int end = Math.min(this._inputEnd, this._inputPtr + outBuf.length - outPtr);
/*      */     
/*      */     while (true) {
/* 1471 */       if (this._inputPtr >= end)
/*      */       {
/* 1473 */         return _parseNumber2(outBuf, outPtr, true, intLen);
/*      */       }
/* 1475 */       c = this._inputBuffer[this._inputPtr++] & 0xFF;
/* 1476 */       if (c < 48 || c > 57) {
/*      */         break;
/*      */       }
/* 1479 */       intLen++;
/* 1480 */       outBuf[outPtr++] = (char)c;
/*      */     } 
/* 1482 */     if (c == 46 || c == 101 || c == 69) {
/* 1483 */       return _parseFloat(outBuf, outPtr, c, true, intLen);
/*      */     }
/*      */     
/* 1486 */     this._inputPtr--;
/* 1487 */     this._textBuffer.setCurrentLength(outPtr);
/*      */     
/* 1489 */     if (this._parsingContext.inRoot()) {
/* 1490 */       _verifyRootSpace(c);
/*      */     }
/*      */ 
/*      */     
/* 1494 */     return resetInt(true, intLen);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final JsonToken _parseNumber2(char[] outBuf, int outPtr, boolean negative, int intPartLength) throws IOException {
/*      */     while (true) {
/* 1506 */       if (this._inputPtr >= this._inputEnd && !_loadMore()) {
/* 1507 */         this._textBuffer.setCurrentLength(outPtr);
/* 1508 */         return resetInt(negative, intPartLength);
/*      */       } 
/* 1510 */       int c = this._inputBuffer[this._inputPtr++] & 0xFF;
/* 1511 */       if (c > 57 || c < 48) {
/* 1512 */         if (c == 46 || c == 101 || c == 69) {
/* 1513 */           return _parseFloat(outBuf, outPtr, c, negative, intPartLength);
/*      */         }
/*      */         break;
/*      */       } 
/* 1517 */       if (outPtr >= outBuf.length) {
/* 1518 */         outBuf = this._textBuffer.finishCurrentSegment();
/* 1519 */         outPtr = 0;
/*      */       } 
/* 1521 */       outBuf[outPtr++] = (char)c;
/* 1522 */       intPartLength++;
/*      */     } 
/* 1524 */     this._inputPtr--;
/* 1525 */     this._textBuffer.setCurrentLength(outPtr);
/*      */     
/* 1527 */     if (this._parsingContext.inRoot()) {
/* 1528 */       _verifyRootSpace(this._inputBuffer[this._inputPtr] & 0xFF);
/*      */     }
/*      */ 
/*      */     
/* 1532 */     return resetInt(negative, intPartLength);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final int _verifyNoLeadingZeroes() throws IOException {
/* 1543 */     if (this._inputPtr >= this._inputEnd && !_loadMore()) {
/* 1544 */       return 48;
/*      */     }
/* 1546 */     int ch = this._inputBuffer[this._inputPtr] & 0xFF;
/*      */     
/* 1548 */     if (ch < 48 || ch > 57) {
/* 1549 */       return 48;
/*      */     }
/*      */     
/* 1552 */     if ((this._features & FEAT_MASK_LEADING_ZEROS) == 0) {
/* 1553 */       reportInvalidNumber("Leading zeroes not allowed");
/*      */     }
/*      */     
/* 1556 */     this._inputPtr++;
/* 1557 */     if (ch == 48) {
/* 1558 */       while (this._inputPtr < this._inputEnd || _loadMore()) {
/* 1559 */         ch = this._inputBuffer[this._inputPtr] & 0xFF;
/* 1560 */         if (ch < 48 || ch > 57) {
/* 1561 */           return 48;
/*      */         }
/* 1563 */         this._inputPtr++;
/* 1564 */         if (ch != 48) {
/*      */           break;
/*      */         }
/*      */       } 
/*      */     }
/* 1569 */     return ch;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private final JsonToken _parseFloat(char[] outBuf, int outPtr, int c, boolean negative, int integerPartLength) throws IOException {
/* 1575 */     int fractLen = 0;
/* 1576 */     boolean eof = false;
/*      */ 
/*      */     
/* 1579 */     if (c == 46) {
/* 1580 */       if (outPtr >= outBuf.length) {
/* 1581 */         outBuf = this._textBuffer.finishCurrentSegment();
/* 1582 */         outPtr = 0;
/*      */       } 
/* 1584 */       outBuf[outPtr++] = (char)c;
/*      */ 
/*      */       
/*      */       while (true) {
/* 1588 */         if (this._inputPtr >= this._inputEnd && !_loadMore()) {
/* 1589 */           eof = true;
/*      */           break;
/*      */         } 
/* 1592 */         c = this._inputBuffer[this._inputPtr++] & 0xFF;
/* 1593 */         if (c < 48 || c > 57) {
/*      */           break;
/*      */         }
/* 1596 */         fractLen++;
/* 1597 */         if (outPtr >= outBuf.length) {
/* 1598 */           outBuf = this._textBuffer.finishCurrentSegment();
/* 1599 */           outPtr = 0;
/*      */         } 
/* 1601 */         outBuf[outPtr++] = (char)c;
/*      */       } 
/*      */       
/* 1604 */       if (fractLen == 0) {
/* 1605 */         reportUnexpectedNumberChar(c, "Decimal point not followed by a digit");
/*      */       }
/*      */     } 
/*      */     
/* 1609 */     int expLen = 0;
/* 1610 */     if (c == 101 || c == 69) {
/* 1611 */       if (outPtr >= outBuf.length) {
/* 1612 */         outBuf = this._textBuffer.finishCurrentSegment();
/* 1613 */         outPtr = 0;
/*      */       } 
/* 1615 */       outBuf[outPtr++] = (char)c;
/*      */       
/* 1617 */       if (this._inputPtr >= this._inputEnd) {
/* 1618 */         _loadMoreGuaranteed();
/*      */       }
/* 1620 */       c = this._inputBuffer[this._inputPtr++] & 0xFF;
/*      */       
/* 1622 */       if (c == 45 || c == 43) {
/* 1623 */         if (outPtr >= outBuf.length) {
/* 1624 */           outBuf = this._textBuffer.finishCurrentSegment();
/* 1625 */           outPtr = 0;
/*      */         } 
/* 1627 */         outBuf[outPtr++] = (char)c;
/*      */         
/* 1629 */         if (this._inputPtr >= this._inputEnd) {
/* 1630 */           _loadMoreGuaranteed();
/*      */         }
/* 1632 */         c = this._inputBuffer[this._inputPtr++] & 0xFF;
/*      */       } 
/*      */ 
/*      */       
/* 1636 */       while (c >= 48 && c <= 57) {
/* 1637 */         expLen++;
/* 1638 */         if (outPtr >= outBuf.length) {
/* 1639 */           outBuf = this._textBuffer.finishCurrentSegment();
/* 1640 */           outPtr = 0;
/*      */         } 
/* 1642 */         outBuf[outPtr++] = (char)c;
/* 1643 */         if (this._inputPtr >= this._inputEnd && !_loadMore()) {
/* 1644 */           eof = true;
/*      */           break;
/*      */         } 
/* 1647 */         c = this._inputBuffer[this._inputPtr++] & 0xFF;
/*      */       } 
/*      */       
/* 1650 */       if (expLen == 0) {
/* 1651 */         reportUnexpectedNumberChar(c, "Exponent indicator not followed by a digit");
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/* 1656 */     if (!eof) {
/* 1657 */       this._inputPtr--;
/*      */       
/* 1659 */       if (this._parsingContext.inRoot()) {
/* 1660 */         _verifyRootSpace(c);
/*      */       }
/*      */     } 
/* 1663 */     this._textBuffer.setCurrentLength(outPtr);
/*      */ 
/*      */     
/* 1666 */     return resetFloat(negative, integerPartLength, fractLen, expLen);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void _verifyRootSpace(int ch) throws IOException {
/* 1679 */     this._inputPtr++;
/*      */     
/* 1681 */     switch (ch) {
/*      */       case 9:
/*      */       case 32:
/*      */         return;
/*      */       case 13:
/* 1686 */         _skipCR();
/*      */         return;
/*      */       case 10:
/* 1689 */         this._currInputRow++;
/* 1690 */         this._currInputRowStart = this._inputPtr;
/*      */         return;
/*      */     } 
/* 1693 */     _reportMissingRootWS(ch);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final String _parseName(int i) throws IOException {
/* 1704 */     if (i != 34) {
/* 1705 */       return _handleOddName(i);
/*      */     }
/*      */     
/* 1708 */     if (this._inputPtr + 13 > this._inputEnd) {
/* 1709 */       return slowParseName();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1718 */     byte[] input = this._inputBuffer;
/* 1719 */     int[] codes = _icLatin1;
/*      */     
/* 1721 */     int q = input[this._inputPtr++] & 0xFF;
/*      */     
/* 1723 */     if (codes[q] == 0) {
/* 1724 */       i = input[this._inputPtr++] & 0xFF;
/* 1725 */       if (codes[i] == 0) {
/* 1726 */         q = q << 8 | i;
/* 1727 */         i = input[this._inputPtr++] & 0xFF;
/* 1728 */         if (codes[i] == 0) {
/* 1729 */           q = q << 8 | i;
/* 1730 */           i = input[this._inputPtr++] & 0xFF;
/* 1731 */           if (codes[i] == 0) {
/* 1732 */             q = q << 8 | i;
/* 1733 */             i = input[this._inputPtr++] & 0xFF;
/* 1734 */             if (codes[i] == 0) {
/* 1735 */               this._quad1 = q;
/* 1736 */               return parseMediumName(i);
/*      */             } 
/* 1738 */             if (i == 34) {
/* 1739 */               return findName(q, 4);
/*      */             }
/* 1741 */             return parseName(q, i, 4);
/*      */           } 
/* 1743 */           if (i == 34) {
/* 1744 */             return findName(q, 3);
/*      */           }
/* 1746 */           return parseName(q, i, 3);
/*      */         } 
/* 1748 */         if (i == 34) {
/* 1749 */           return findName(q, 2);
/*      */         }
/* 1751 */         return parseName(q, i, 2);
/*      */       } 
/* 1753 */       if (i == 34) {
/* 1754 */         return findName(q, 1);
/*      */       }
/* 1756 */       return parseName(q, i, 1);
/*      */     } 
/* 1758 */     if (q == 34) {
/* 1759 */       return "";
/*      */     }
/* 1761 */     return parseName(0, q, 0);
/*      */   }
/*      */ 
/*      */   
/*      */   protected final String parseMediumName(int q2) throws IOException {
/* 1766 */     byte[] input = this._inputBuffer;
/* 1767 */     int[] codes = _icLatin1;
/*      */ 
/*      */     
/* 1770 */     int i = input[this._inputPtr++] & 0xFF;
/* 1771 */     if (codes[i] != 0) {
/* 1772 */       if (i == 34) {
/* 1773 */         return findName(this._quad1, q2, 1);
/*      */       }
/* 1775 */       return parseName(this._quad1, q2, i, 1);
/*      */     } 
/* 1777 */     q2 = q2 << 8 | i;
/* 1778 */     i = input[this._inputPtr++] & 0xFF;
/* 1779 */     if (codes[i] != 0) {
/* 1780 */       if (i == 34) {
/* 1781 */         return findName(this._quad1, q2, 2);
/*      */       }
/* 1783 */       return parseName(this._quad1, q2, i, 2);
/*      */     } 
/* 1785 */     q2 = q2 << 8 | i;
/* 1786 */     i = input[this._inputPtr++] & 0xFF;
/* 1787 */     if (codes[i] != 0) {
/* 1788 */       if (i == 34) {
/* 1789 */         return findName(this._quad1, q2, 3);
/*      */       }
/* 1791 */       return parseName(this._quad1, q2, i, 3);
/*      */     } 
/* 1793 */     q2 = q2 << 8 | i;
/* 1794 */     i = input[this._inputPtr++] & 0xFF;
/* 1795 */     if (codes[i] != 0) {
/* 1796 */       if (i == 34) {
/* 1797 */         return findName(this._quad1, q2, 4);
/*      */       }
/* 1799 */       return parseName(this._quad1, q2, i, 4);
/*      */     } 
/* 1801 */     return parseMediumName2(i, q2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final String parseMediumName2(int q3, int q2) throws IOException {
/* 1809 */     byte[] input = this._inputBuffer;
/* 1810 */     int[] codes = _icLatin1;
/*      */ 
/*      */     
/* 1813 */     int i = input[this._inputPtr++] & 0xFF;
/* 1814 */     if (codes[i] != 0) {
/* 1815 */       if (i == 34) {
/* 1816 */         return findName(this._quad1, q2, q3, 1);
/*      */       }
/* 1818 */       return parseName(this._quad1, q2, q3, i, 1);
/*      */     } 
/* 1820 */     q3 = q3 << 8 | i;
/* 1821 */     i = input[this._inputPtr++] & 0xFF;
/* 1822 */     if (codes[i] != 0) {
/* 1823 */       if (i == 34) {
/* 1824 */         return findName(this._quad1, q2, q3, 2);
/*      */       }
/* 1826 */       return parseName(this._quad1, q2, q3, i, 2);
/*      */     } 
/* 1828 */     q3 = q3 << 8 | i;
/* 1829 */     i = input[this._inputPtr++] & 0xFF;
/* 1830 */     if (codes[i] != 0) {
/* 1831 */       if (i == 34) {
/* 1832 */         return findName(this._quad1, q2, q3, 3);
/*      */       }
/* 1834 */       return parseName(this._quad1, q2, q3, i, 3);
/*      */     } 
/* 1836 */     q3 = q3 << 8 | i;
/* 1837 */     i = input[this._inputPtr++] & 0xFF;
/* 1838 */     if (codes[i] != 0) {
/* 1839 */       if (i == 34) {
/* 1840 */         return findName(this._quad1, q2, q3, 4);
/*      */       }
/* 1842 */       return parseName(this._quad1, q2, q3, i, 4);
/*      */     } 
/* 1844 */     return parseLongName(i, q2, q3);
/*      */   }
/*      */ 
/*      */   
/*      */   protected final String parseLongName(int q, int q2, int q3) throws IOException {
/* 1849 */     this._quadBuffer[0] = this._quad1;
/* 1850 */     this._quadBuffer[1] = q2;
/* 1851 */     this._quadBuffer[2] = q3;
/*      */ 
/*      */     
/* 1854 */     byte[] input = this._inputBuffer;
/* 1855 */     int[] codes = _icLatin1;
/* 1856 */     int qlen = 3;
/*      */     
/* 1858 */     while (this._inputPtr + 4 <= this._inputEnd) {
/* 1859 */       int i = input[this._inputPtr++] & 0xFF;
/* 1860 */       if (codes[i] != 0) {
/* 1861 */         if (i == 34) {
/* 1862 */           return findName(this._quadBuffer, qlen, q, 1);
/*      */         }
/* 1864 */         return parseEscapedName(this._quadBuffer, qlen, q, i, 1);
/*      */       } 
/*      */       
/* 1867 */       q = q << 8 | i;
/* 1868 */       i = input[this._inputPtr++] & 0xFF;
/* 1869 */       if (codes[i] != 0) {
/* 1870 */         if (i == 34) {
/* 1871 */           return findName(this._quadBuffer, qlen, q, 2);
/*      */         }
/* 1873 */         return parseEscapedName(this._quadBuffer, qlen, q, i, 2);
/*      */       } 
/*      */       
/* 1876 */       q = q << 8 | i;
/* 1877 */       i = input[this._inputPtr++] & 0xFF;
/* 1878 */       if (codes[i] != 0) {
/* 1879 */         if (i == 34) {
/* 1880 */           return findName(this._quadBuffer, qlen, q, 3);
/*      */         }
/* 1882 */         return parseEscapedName(this._quadBuffer, qlen, q, i, 3);
/*      */       } 
/*      */       
/* 1885 */       q = q << 8 | i;
/* 1886 */       i = input[this._inputPtr++] & 0xFF;
/* 1887 */       if (codes[i] != 0) {
/* 1888 */         if (i == 34) {
/* 1889 */           return findName(this._quadBuffer, qlen, q, 4);
/*      */         }
/* 1891 */         return parseEscapedName(this._quadBuffer, qlen, q, i, 4);
/*      */       } 
/*      */ 
/*      */       
/* 1895 */       if (qlen >= this._quadBuffer.length) {
/* 1896 */         this._quadBuffer = growArrayBy(this._quadBuffer, qlen);
/*      */       }
/* 1898 */       this._quadBuffer[qlen++] = q;
/* 1899 */       q = i;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1906 */     return parseEscapedName(this._quadBuffer, qlen, 0, q, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String slowParseName() throws IOException {
/* 1916 */     if (this._inputPtr >= this._inputEnd && 
/* 1917 */       !_loadMore()) {
/* 1918 */       _reportInvalidEOF(": was expecting closing '\"' for name", JsonToken.FIELD_NAME);
/*      */     }
/*      */     
/* 1921 */     int i = this._inputBuffer[this._inputPtr++] & 0xFF;
/* 1922 */     if (i == 34) {
/* 1923 */       return "";
/*      */     }
/* 1925 */     return parseEscapedName(this._quadBuffer, 0, 0, i, 0);
/*      */   }
/*      */   
/*      */   private final String parseName(int q1, int ch, int lastQuadBytes) throws IOException {
/* 1929 */     return parseEscapedName(this._quadBuffer, 0, q1, ch, lastQuadBytes);
/*      */   }
/*      */   
/*      */   private final String parseName(int q1, int q2, int ch, int lastQuadBytes) throws IOException {
/* 1933 */     this._quadBuffer[0] = q1;
/* 1934 */     return parseEscapedName(this._quadBuffer, 1, q2, ch, lastQuadBytes);
/*      */   }
/*      */   
/*      */   private final String parseName(int q1, int q2, int q3, int ch, int lastQuadBytes) throws IOException {
/* 1938 */     this._quadBuffer[0] = q1;
/* 1939 */     this._quadBuffer[1] = q2;
/* 1940 */     return parseEscapedName(this._quadBuffer, 2, q3, ch, lastQuadBytes);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final String parseEscapedName(int[] quads, int qlen, int currQuad, int ch, int currQuadBytes) throws IOException {
/* 1955 */     int[] codes = _icLatin1;
/*      */     
/*      */     while (true) {
/* 1958 */       if (codes[ch] != 0) {
/* 1959 */         if (ch == 34) {
/*      */           break;
/*      */         }
/*      */         
/* 1963 */         if (ch != 92) {
/*      */           
/* 1965 */           _throwUnquotedSpace(ch, "name");
/*      */         } else {
/*      */           
/* 1968 */           ch = _decodeEscaped();
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/* 1973 */         if (ch > 127) {
/*      */           
/* 1975 */           if (currQuadBytes >= 4) {
/* 1976 */             if (qlen >= quads.length) {
/* 1977 */               this._quadBuffer = quads = growArrayBy(quads, quads.length);
/*      */             }
/* 1979 */             quads[qlen++] = currQuad;
/* 1980 */             currQuad = 0;
/* 1981 */             currQuadBytes = 0;
/*      */           } 
/* 1983 */           if (ch < 2048) {
/* 1984 */             currQuad = currQuad << 8 | 0xC0 | ch >> 6;
/* 1985 */             currQuadBytes++;
/*      */           } else {
/*      */             
/* 1988 */             currQuad = currQuad << 8 | 0xE0 | ch >> 12;
/* 1989 */             currQuadBytes++;
/*      */             
/* 1991 */             if (currQuadBytes >= 4) {
/* 1992 */               if (qlen >= quads.length) {
/* 1993 */                 this._quadBuffer = quads = growArrayBy(quads, quads.length);
/*      */               }
/* 1995 */               quads[qlen++] = currQuad;
/* 1996 */               currQuad = 0;
/* 1997 */               currQuadBytes = 0;
/*      */             } 
/* 1999 */             currQuad = currQuad << 8 | 0x80 | ch >> 6 & 0x3F;
/* 2000 */             currQuadBytes++;
/*      */           } 
/*      */           
/* 2003 */           ch = 0x80 | ch & 0x3F;
/*      */         } 
/*      */       } 
/*      */       
/* 2007 */       if (currQuadBytes < 4) {
/* 2008 */         currQuadBytes++;
/* 2009 */         currQuad = currQuad << 8 | ch;
/*      */       } else {
/* 2011 */         if (qlen >= quads.length) {
/* 2012 */           this._quadBuffer = quads = growArrayBy(quads, quads.length);
/*      */         }
/* 2014 */         quads[qlen++] = currQuad;
/* 2015 */         currQuad = ch;
/* 2016 */         currQuadBytes = 1;
/*      */       } 
/* 2018 */       if (this._inputPtr >= this._inputEnd && 
/* 2019 */         !_loadMore()) {
/* 2020 */         _reportInvalidEOF(" in field name", JsonToken.FIELD_NAME);
/*      */       }
/*      */       
/* 2023 */       ch = this._inputBuffer[this._inputPtr++] & 0xFF;
/*      */     } 
/*      */     
/* 2026 */     if (currQuadBytes > 0) {
/* 2027 */       if (qlen >= quads.length) {
/* 2028 */         this._quadBuffer = quads = growArrayBy(quads, quads.length);
/*      */       }
/* 2030 */       quads[qlen++] = _padLastQuad(currQuad, currQuadBytes);
/*      */     } 
/* 2032 */     String name = this._symbols.findName(quads, qlen);
/* 2033 */     if (name == null) {
/* 2034 */       name = addName(quads, qlen, currQuadBytes);
/*      */     }
/* 2036 */     return name;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String _handleOddName(int ch) throws IOException {
/* 2048 */     if (ch == 39 && (this._features & FEAT_MASK_ALLOW_SINGLE_QUOTES) != 0) {
/* 2049 */       return _parseAposName();
/*      */     }
/*      */     
/* 2052 */     if ((this._features & FEAT_MASK_ALLOW_UNQUOTED_NAMES) == 0) {
/* 2053 */       char c = (char)_decodeCharForError(ch);
/* 2054 */       _reportUnexpectedChar(c, "was expecting double-quote to start field name");
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2060 */     int[] codes = CharTypes.getInputCodeUtf8JsNames();
/*      */     
/* 2062 */     if (codes[ch] != 0) {
/* 2063 */       _reportUnexpectedChar(ch, "was expecting either valid name character (for unquoted name) or double-quote (for quoted) to start field name");
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2069 */     int[] quads = this._quadBuffer;
/* 2070 */     int qlen = 0;
/* 2071 */     int currQuad = 0;
/* 2072 */     int currQuadBytes = 0;
/*      */ 
/*      */     
/*      */     while (true) {
/* 2076 */       if (currQuadBytes < 4) {
/* 2077 */         currQuadBytes++;
/* 2078 */         currQuad = currQuad << 8 | ch;
/*      */       } else {
/* 2080 */         if (qlen >= quads.length) {
/* 2081 */           this._quadBuffer = quads = growArrayBy(quads, quads.length);
/*      */         }
/* 2083 */         quads[qlen++] = currQuad;
/* 2084 */         currQuad = ch;
/* 2085 */         currQuadBytes = 1;
/*      */       } 
/* 2087 */       if (this._inputPtr >= this._inputEnd && 
/* 2088 */         !_loadMore()) {
/* 2089 */         _reportInvalidEOF(" in field name", JsonToken.FIELD_NAME);
/*      */       }
/*      */       
/* 2092 */       ch = this._inputBuffer[this._inputPtr] & 0xFF;
/* 2093 */       if (codes[ch] != 0) {
/*      */         break;
/*      */       }
/* 2096 */       this._inputPtr++;
/*      */     } 
/*      */     
/* 2099 */     if (currQuadBytes > 0) {
/* 2100 */       if (qlen >= quads.length) {
/* 2101 */         this._quadBuffer = quads = growArrayBy(quads, quads.length);
/*      */       }
/* 2103 */       quads[qlen++] = currQuad;
/*      */     } 
/* 2105 */     String name = this._symbols.findName(quads, qlen);
/* 2106 */     if (name == null) {
/* 2107 */       name = addName(quads, qlen, currQuadBytes);
/*      */     }
/* 2109 */     return name;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String _parseAposName() throws IOException {
/* 2119 */     if (this._inputPtr >= this._inputEnd && 
/* 2120 */       !_loadMore()) {
/* 2121 */       _reportInvalidEOF(": was expecting closing ''' for field name", JsonToken.FIELD_NAME);
/*      */     }
/*      */     
/* 2124 */     int ch = this._inputBuffer[this._inputPtr++] & 0xFF;
/* 2125 */     if (ch == 39) {
/* 2126 */       return "";
/*      */     }
/* 2128 */     int[] quads = this._quadBuffer;
/* 2129 */     int qlen = 0;
/* 2130 */     int currQuad = 0;
/* 2131 */     int currQuadBytes = 0;
/*      */ 
/*      */ 
/*      */     
/* 2135 */     int[] codes = _icLatin1;
/*      */ 
/*      */     
/* 2138 */     while (ch != 39) {
/*      */ 
/*      */ 
/*      */       
/* 2142 */       if (codes[ch] != 0 && ch != 34) {
/* 2143 */         if (ch != 92) {
/*      */ 
/*      */           
/* 2146 */           _throwUnquotedSpace(ch, "name");
/*      */         } else {
/*      */           
/* 2149 */           ch = _decodeEscaped();
/*      */         } 
/*      */         
/* 2152 */         if (ch > 127) {
/*      */           
/* 2154 */           if (currQuadBytes >= 4) {
/* 2155 */             if (qlen >= quads.length) {
/* 2156 */               this._quadBuffer = quads = growArrayBy(quads, quads.length);
/*      */             }
/* 2158 */             quads[qlen++] = currQuad;
/* 2159 */             currQuad = 0;
/* 2160 */             currQuadBytes = 0;
/*      */           } 
/* 2162 */           if (ch < 2048) {
/* 2163 */             currQuad = currQuad << 8 | 0xC0 | ch >> 6;
/* 2164 */             currQuadBytes++;
/*      */           } else {
/*      */             
/* 2167 */             currQuad = currQuad << 8 | 0xE0 | ch >> 12;
/* 2168 */             currQuadBytes++;
/*      */             
/* 2170 */             if (currQuadBytes >= 4) {
/* 2171 */               if (qlen >= quads.length) {
/* 2172 */                 this._quadBuffer = quads = growArrayBy(quads, quads.length);
/*      */               }
/* 2174 */               quads[qlen++] = currQuad;
/* 2175 */               currQuad = 0;
/* 2176 */               currQuadBytes = 0;
/*      */             } 
/* 2178 */             currQuad = currQuad << 8 | 0x80 | ch >> 6 & 0x3F;
/* 2179 */             currQuadBytes++;
/*      */           } 
/*      */           
/* 2182 */           ch = 0x80 | ch & 0x3F;
/*      */         } 
/*      */       } 
/*      */       
/* 2186 */       if (currQuadBytes < 4) {
/* 2187 */         currQuadBytes++;
/* 2188 */         currQuad = currQuad << 8 | ch;
/*      */       } else {
/* 2190 */         if (qlen >= quads.length) {
/* 2191 */           this._quadBuffer = quads = growArrayBy(quads, quads.length);
/*      */         }
/* 2193 */         quads[qlen++] = currQuad;
/* 2194 */         currQuad = ch;
/* 2195 */         currQuadBytes = 1;
/*      */       } 
/* 2197 */       if (this._inputPtr >= this._inputEnd && 
/* 2198 */         !_loadMore()) {
/* 2199 */         _reportInvalidEOF(" in field name", JsonToken.FIELD_NAME);
/*      */       }
/*      */       
/* 2202 */       ch = this._inputBuffer[this._inputPtr++] & 0xFF;
/*      */     } 
/*      */     
/* 2205 */     if (currQuadBytes > 0) {
/* 2206 */       if (qlen >= quads.length) {
/* 2207 */         this._quadBuffer = quads = growArrayBy(quads, quads.length);
/*      */       }
/* 2209 */       quads[qlen++] = _padLastQuad(currQuad, currQuadBytes);
/*      */     } 
/* 2211 */     String name = this._symbols.findName(quads, qlen);
/* 2212 */     if (name == null) {
/* 2213 */       name = addName(quads, qlen, currQuadBytes);
/*      */     }
/* 2215 */     return name;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final String findName(int q1, int lastQuadBytes) throws JsonParseException {
/* 2226 */     q1 = _padLastQuad(q1, lastQuadBytes);
/*      */     
/* 2228 */     String name = this._symbols.findName(q1);
/* 2229 */     if (name != null) {
/* 2230 */       return name;
/*      */     }
/*      */     
/* 2233 */     this._quadBuffer[0] = q1;
/* 2234 */     return addName(this._quadBuffer, 1, lastQuadBytes);
/*      */   }
/*      */ 
/*      */   
/*      */   private final String findName(int q1, int q2, int lastQuadBytes) throws JsonParseException {
/* 2239 */     q2 = _padLastQuad(q2, lastQuadBytes);
/*      */     
/* 2241 */     String name = this._symbols.findName(q1, q2);
/* 2242 */     if (name != null) {
/* 2243 */       return name;
/*      */     }
/*      */     
/* 2246 */     this._quadBuffer[0] = q1;
/* 2247 */     this._quadBuffer[1] = q2;
/* 2248 */     return addName(this._quadBuffer, 2, lastQuadBytes);
/*      */   }
/*      */ 
/*      */   
/*      */   private final String findName(int q1, int q2, int q3, int lastQuadBytes) throws JsonParseException {
/* 2253 */     q3 = _padLastQuad(q3, lastQuadBytes);
/* 2254 */     String name = this._symbols.findName(q1, q2, q3);
/* 2255 */     if (name != null) {
/* 2256 */       return name;
/*      */     }
/* 2258 */     int[] quads = this._quadBuffer;
/* 2259 */     quads[0] = q1;
/* 2260 */     quads[1] = q2;
/* 2261 */     quads[2] = _padLastQuad(q3, lastQuadBytes);
/* 2262 */     return addName(quads, 3, lastQuadBytes);
/*      */   }
/*      */ 
/*      */   
/*      */   private final String findName(int[] quads, int qlen, int lastQuad, int lastQuadBytes) throws JsonParseException {
/* 2267 */     if (qlen >= quads.length) {
/* 2268 */       this._quadBuffer = quads = growArrayBy(quads, quads.length);
/*      */     }
/* 2270 */     quads[qlen++] = _padLastQuad(lastQuad, lastQuadBytes);
/* 2271 */     String name = this._symbols.findName(quads, qlen);
/* 2272 */     if (name == null) {
/* 2273 */       return addName(quads, qlen, lastQuadBytes);
/*      */     }
/* 2275 */     return name;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final String addName(int[] quads, int qlen, int lastQuadBytes) throws JsonParseException {
/* 2291 */     int lastQuad, byteLen = (qlen << 2) - 4 + lastQuadBytes;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2300 */     if (lastQuadBytes < 4) {
/* 2301 */       lastQuad = quads[qlen - 1];
/*      */       
/* 2303 */       quads[qlen - 1] = lastQuad << 4 - lastQuadBytes << 3;
/*      */     } else {
/* 2305 */       lastQuad = 0;
/*      */     } 
/*      */ 
/*      */     
/* 2309 */     char[] cbuf = this._textBuffer.emptyAndGetCurrentSegment();
/* 2310 */     int cix = 0;
/*      */     
/* 2312 */     for (int ix = 0; ix < byteLen; ) {
/* 2313 */       int ch = quads[ix >> 2];
/* 2314 */       int byteIx = ix & 0x3;
/* 2315 */       ch = ch >> 3 - byteIx << 3 & 0xFF;
/* 2316 */       ix++;
/*      */       
/* 2318 */       if (ch > 127) {
/*      */         int needed;
/* 2320 */         if ((ch & 0xE0) == 192) {
/* 2321 */           ch &= 0x1F;
/* 2322 */           needed = 1;
/* 2323 */         } else if ((ch & 0xF0) == 224) {
/* 2324 */           ch &= 0xF;
/* 2325 */           needed = 2;
/* 2326 */         } else if ((ch & 0xF8) == 240) {
/* 2327 */           ch &= 0x7;
/* 2328 */           needed = 3;
/*      */         } else {
/* 2330 */           _reportInvalidInitial(ch);
/* 2331 */           needed = ch = 1;
/*      */         } 
/* 2333 */         if (ix + needed > byteLen) {
/* 2334 */           _reportInvalidEOF(" in field name", JsonToken.FIELD_NAME);
/*      */         }
/*      */ 
/*      */         
/* 2338 */         int ch2 = quads[ix >> 2];
/* 2339 */         byteIx = ix & 0x3;
/* 2340 */         ch2 >>= 3 - byteIx << 3;
/* 2341 */         ix++;
/*      */         
/* 2343 */         if ((ch2 & 0xC0) != 128) {
/* 2344 */           _reportInvalidOther(ch2);
/*      */         }
/* 2346 */         ch = ch << 6 | ch2 & 0x3F;
/* 2347 */         if (needed > 1) {
/* 2348 */           ch2 = quads[ix >> 2];
/* 2349 */           byteIx = ix & 0x3;
/* 2350 */           ch2 >>= 3 - byteIx << 3;
/* 2351 */           ix++;
/*      */           
/* 2353 */           if ((ch2 & 0xC0) != 128) {
/* 2354 */             _reportInvalidOther(ch2);
/*      */           }
/* 2356 */           ch = ch << 6 | ch2 & 0x3F;
/* 2357 */           if (needed > 2) {
/* 2358 */             ch2 = quads[ix >> 2];
/* 2359 */             byteIx = ix & 0x3;
/* 2360 */             ch2 >>= 3 - byteIx << 3;
/* 2361 */             ix++;
/* 2362 */             if ((ch2 & 0xC0) != 128) {
/* 2363 */               _reportInvalidOther(ch2 & 0xFF);
/*      */             }
/* 2365 */             ch = ch << 6 | ch2 & 0x3F;
/*      */           } 
/*      */         } 
/* 2368 */         if (needed > 2) {
/* 2369 */           ch -= 65536;
/* 2370 */           if (cix >= cbuf.length) {
/* 2371 */             cbuf = this._textBuffer.expandCurrentSegment();
/*      */           }
/* 2373 */           cbuf[cix++] = (char)(55296 + (ch >> 10));
/* 2374 */           ch = 0xDC00 | ch & 0x3FF;
/*      */         } 
/*      */       } 
/* 2377 */       if (cix >= cbuf.length) {
/* 2378 */         cbuf = this._textBuffer.expandCurrentSegment();
/*      */       }
/* 2380 */       cbuf[cix++] = (char)ch;
/*      */     } 
/*      */ 
/*      */     
/* 2384 */     String baseName = new String(cbuf, 0, cix);
/*      */     
/* 2386 */     if (lastQuadBytes < 4) {
/* 2387 */       quads[qlen - 1] = lastQuad;
/*      */     }
/* 2389 */     return this._symbols.addName(baseName, quads, qlen);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int _padLastQuad(int q, int bytes) {
/* 2396 */     return (bytes == 4) ? q : (q | -1 << bytes << 3);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _loadMoreGuaranteed() throws IOException {
/* 2406 */     if (!_loadMore()) _reportInvalidEOF();
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _finishString() throws IOException {
/* 2413 */     int ptr = this._inputPtr;
/* 2414 */     if (ptr >= this._inputEnd) {
/* 2415 */       _loadMoreGuaranteed();
/* 2416 */       ptr = this._inputPtr;
/*      */     } 
/* 2418 */     int outPtr = 0;
/* 2419 */     char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/* 2420 */     int[] codes = _icUTF8;
/*      */     
/* 2422 */     int max = Math.min(this._inputEnd, ptr + outBuf.length);
/* 2423 */     byte[] inputBuffer = this._inputBuffer;
/* 2424 */     while (ptr < max) {
/* 2425 */       int c = inputBuffer[ptr] & 0xFF;
/* 2426 */       if (codes[c] != 0) {
/* 2427 */         if (c == 34) {
/* 2428 */           this._inputPtr = ptr + 1;
/* 2429 */           this._textBuffer.setCurrentLength(outPtr);
/*      */           return;
/*      */         } 
/*      */         break;
/*      */       } 
/* 2434 */       ptr++;
/* 2435 */       outBuf[outPtr++] = (char)c;
/*      */     } 
/* 2437 */     this._inputPtr = ptr;
/* 2438 */     _finishString2(outBuf, outPtr);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String _finishAndReturnString() throws IOException {
/* 2447 */     int ptr = this._inputPtr;
/* 2448 */     if (ptr >= this._inputEnd) {
/* 2449 */       _loadMoreGuaranteed();
/* 2450 */       ptr = this._inputPtr;
/*      */     } 
/* 2452 */     int outPtr = 0;
/* 2453 */     char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/* 2454 */     int[] codes = _icUTF8;
/*      */     
/* 2456 */     int max = Math.min(this._inputEnd, ptr + outBuf.length);
/* 2457 */     byte[] inputBuffer = this._inputBuffer;
/* 2458 */     while (ptr < max) {
/* 2459 */       int c = inputBuffer[ptr] & 0xFF;
/* 2460 */       if (codes[c] != 0) {
/* 2461 */         if (c == 34) {
/* 2462 */           this._inputPtr = ptr + 1;
/* 2463 */           return this._textBuffer.setCurrentAndReturn(outPtr);
/*      */         } 
/*      */         break;
/*      */       } 
/* 2467 */       ptr++;
/* 2468 */       outBuf[outPtr++] = (char)c;
/*      */     } 
/* 2470 */     this._inputPtr = ptr;
/* 2471 */     _finishString2(outBuf, outPtr);
/* 2472 */     return this._textBuffer.contentsAsString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void _finishString2(char[] outBuf, int outPtr) throws IOException {
/* 2481 */     int[] codes = _icUTF8;
/* 2482 */     byte[] inputBuffer = this._inputBuffer;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     while (true) {
/* 2489 */       int ptr = this._inputPtr;
/* 2490 */       if (ptr >= this._inputEnd) {
/* 2491 */         _loadMoreGuaranteed();
/* 2492 */         ptr = this._inputPtr;
/*      */       } 
/* 2494 */       if (outPtr >= outBuf.length) {
/* 2495 */         outBuf = this._textBuffer.finishCurrentSegment();
/* 2496 */         outPtr = 0;
/*      */       } 
/* 2498 */       int max = Math.min(this._inputEnd, ptr + outBuf.length - outPtr);
/* 2499 */       while (ptr < max) {
/* 2500 */         int c = inputBuffer[ptr++] & 0xFF;
/* 2501 */         if (codes[c] != 0) {
/* 2502 */           this._inputPtr = ptr;
/*      */         } else {
/*      */           
/* 2505 */           outBuf[outPtr++] = (char)c;
/*      */           
/*      */           continue;
/*      */         } 
/*      */         
/* 2510 */         if (c == 34) {
/*      */           break;
/*      */         }
/*      */         
/* 2514 */         switch (codes[c]) {
/*      */           case 1:
/* 2516 */             c = _decodeEscaped();
/*      */             break;
/*      */           case 2:
/* 2519 */             c = _decodeUtf8_2(c);
/*      */             break;
/*      */           case 3:
/* 2522 */             if (this._inputEnd - this._inputPtr >= 2) {
/* 2523 */               c = _decodeUtf8_3fast(c); break;
/*      */             } 
/* 2525 */             c = _decodeUtf8_3(c);
/*      */             break;
/*      */           
/*      */           case 4:
/* 2529 */             c = _decodeUtf8_4(c);
/*      */             
/* 2531 */             outBuf[outPtr++] = (char)(0xD800 | c >> 10);
/* 2532 */             if (outPtr >= outBuf.length) {
/* 2533 */               outBuf = this._textBuffer.finishCurrentSegment();
/* 2534 */               outPtr = 0;
/*      */             } 
/* 2536 */             c = 0xDC00 | c & 0x3FF;
/*      */             break;
/*      */           
/*      */           default:
/* 2540 */             if (c < 32) {
/*      */               
/* 2542 */               _throwUnquotedSpace(c, "string value");
/*      */               break;
/*      */             } 
/* 2545 */             _reportInvalidChar(c);
/*      */             break;
/*      */         } 
/*      */         
/* 2549 */         if (outPtr >= outBuf.length) {
/* 2550 */           outBuf = this._textBuffer.finishCurrentSegment();
/* 2551 */           outPtr = 0;
/*      */         } 
/*      */         
/* 2554 */         outBuf[outPtr++] = (char)c;
/*      */       }  this._inputPtr = ptr;
/* 2556 */     }  this._textBuffer.setCurrentLength(outPtr);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _skipString() throws IOException {
/* 2566 */     this._tokenIncomplete = false;
/*      */ 
/*      */     
/* 2569 */     int[] codes = _icUTF8;
/* 2570 */     byte[] inputBuffer = this._inputBuffer;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     while (true) {
/* 2578 */       int ptr = this._inputPtr;
/* 2579 */       int max = this._inputEnd;
/* 2580 */       if (ptr >= max) {
/* 2581 */         _loadMoreGuaranteed();
/* 2582 */         ptr = this._inputPtr;
/* 2583 */         max = this._inputEnd;
/*      */       } 
/* 2585 */       while (ptr < max) {
/* 2586 */         int c = inputBuffer[ptr++] & 0xFF;
/* 2587 */         if (codes[c] != 0) {
/* 2588 */           this._inputPtr = ptr;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 2595 */           if (c != 34) {
/*      */ 
/*      */ 
/*      */             
/* 2599 */             switch (codes[c]) {
/*      */               case 1:
/* 2601 */                 _decodeEscaped();
/*      */                 continue;
/*      */               case 2:
/* 2604 */                 _skipUtf8_2();
/*      */                 continue;
/*      */               case 3:
/* 2607 */                 _skipUtf8_3();
/*      */                 continue;
/*      */               case 4:
/* 2610 */                 _skipUtf8_4(c);
/*      */                 continue;
/*      */             } 
/* 2613 */             if (c < 32) {
/* 2614 */               _throwUnquotedSpace(c, "string value");
/*      */               continue;
/*      */             } 
/* 2617 */             _reportInvalidChar(c);
/*      */             continue;
/*      */           } 
/*      */           return;
/*      */         } 
/*      */       } 
/*      */       this._inputPtr = ptr;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonToken _handleUnexpectedValue(int c) throws IOException {
/* 2630 */     switch (c) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 93:
/* 2639 */         if (!this._parsingContext.inArray()) {
/*      */           break;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 44:
/* 2648 */         if (!this._parsingContext.inRoot() && (
/* 2649 */           this._features & FEAT_MASK_ALLOW_MISSING) != 0) {
/* 2650 */           this._inputPtr--;
/* 2651 */           return JsonToken.VALUE_NULL;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 125:
/* 2658 */         _reportUnexpectedChar(c, "expected a value");
/*      */       case 39:
/* 2660 */         if ((this._features & FEAT_MASK_ALLOW_SINGLE_QUOTES) != 0) {
/* 2661 */           return _handleApos();
/*      */         }
/*      */         break;
/*      */       case 78:
/* 2665 */         _matchToken("NaN", 1);
/* 2666 */         if ((this._features & FEAT_MASK_NON_NUM_NUMBERS) != 0) {
/* 2667 */           return resetAsNaN("NaN", Double.NaN);
/*      */         }
/* 2669 */         _reportError("Non-standard token 'NaN': enable JsonParser.Feature.ALLOW_NON_NUMERIC_NUMBERS to allow");
/*      */         break;
/*      */       case 73:
/* 2672 */         _matchToken("Infinity", 1);
/* 2673 */         if ((this._features & FEAT_MASK_NON_NUM_NUMBERS) != 0) {
/* 2674 */           return resetAsNaN("Infinity", Double.POSITIVE_INFINITY);
/*      */         }
/* 2676 */         _reportError("Non-standard token 'Infinity': enable JsonParser.Feature.ALLOW_NON_NUMERIC_NUMBERS to allow");
/*      */         break;
/*      */       case 43:
/* 2679 */         if (this._inputPtr >= this._inputEnd && 
/* 2680 */           !_loadMore()) {
/* 2681 */           _reportInvalidEOFInValue(JsonToken.VALUE_NUMBER_INT);
/*      */         }
/*      */         
/* 2684 */         return _handleInvalidNumberStart(this._inputBuffer[this._inputPtr++] & 0xFF, false);
/*      */     } 
/*      */     
/* 2687 */     if (Character.isJavaIdentifierStart(c)) {
/* 2688 */       _reportInvalidToken("" + (char)c, _validJsonTokenList());
/*      */     }
/*      */     
/* 2691 */     _reportUnexpectedChar(c, "expected a valid value " + _validJsonValueList());
/* 2692 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   protected JsonToken _handleApos() throws IOException {
/* 2697 */     int c = 0;
/*      */     
/* 2699 */     int outPtr = 0;
/* 2700 */     char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/*      */ 
/*      */     
/* 2703 */     int[] codes = _icUTF8;
/* 2704 */     byte[] inputBuffer = this._inputBuffer;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     while (true)
/* 2711 */     { if (this._inputPtr >= this._inputEnd) {
/* 2712 */         _loadMoreGuaranteed();
/*      */       }
/* 2714 */       if (outPtr >= outBuf.length) {
/* 2715 */         outBuf = this._textBuffer.finishCurrentSegment();
/* 2716 */         outPtr = 0;
/*      */       } 
/* 2718 */       int max = this._inputEnd;
/*      */       
/* 2720 */       int max2 = this._inputPtr + outBuf.length - outPtr;
/* 2721 */       if (max2 < max) {
/* 2722 */         max = max2;
/*      */       }
/*      */       
/* 2725 */       while (this._inputPtr < max)
/* 2726 */       { c = inputBuffer[this._inputPtr++] & 0xFF;
/* 2727 */         if (c != 39) {
/*      */ 
/*      */           
/* 2730 */           if (codes[c] != 0 && c != 34) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 2740 */             switch (codes[c]) {
/*      */               case 1:
/* 2742 */                 c = _decodeEscaped();
/*      */                 break;
/*      */               case 2:
/* 2745 */                 c = _decodeUtf8_2(c);
/*      */                 break;
/*      */               case 3:
/* 2748 */                 if (this._inputEnd - this._inputPtr >= 2) {
/* 2749 */                   c = _decodeUtf8_3fast(c); break;
/*      */                 } 
/* 2751 */                 c = _decodeUtf8_3(c);
/*      */                 break;
/*      */               
/*      */               case 4:
/* 2755 */                 c = _decodeUtf8_4(c);
/*      */                 
/* 2757 */                 outBuf[outPtr++] = (char)(0xD800 | c >> 10);
/* 2758 */                 if (outPtr >= outBuf.length) {
/* 2759 */                   outBuf = this._textBuffer.finishCurrentSegment();
/* 2760 */                   outPtr = 0;
/*      */                 } 
/* 2762 */                 c = 0xDC00 | c & 0x3FF;
/*      */                 break;
/*      */               
/*      */               default:
/* 2766 */                 if (c < 32) {
/* 2767 */                   _throwUnquotedSpace(c, "string value");
/*      */                 }
/*      */                 
/* 2770 */                 _reportInvalidChar(c);
/*      */                 break;
/*      */             } 
/* 2773 */             if (outPtr >= outBuf.length) {
/* 2774 */               outBuf = this._textBuffer.finishCurrentSegment();
/* 2775 */               outPtr = 0;
/*      */             } 
/*      */             
/* 2778 */             outBuf[outPtr++] = (char)c; continue;
/*      */           }  outBuf[outPtr++] = (char)c; continue;
/* 2780 */         }  this._textBuffer.setCurrentLength(outPtr);
/*      */         
/* 2782 */         return JsonToken.VALUE_STRING; }  }  this._textBuffer.setCurrentLength(outPtr); return JsonToken.VALUE_STRING;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonToken _handleInvalidNumberStart(int ch, boolean neg) throws IOException {
/* 2797 */     while (ch == 73) {
/* 2798 */       String match; if (this._inputPtr >= this._inputEnd && 
/* 2799 */         !_loadMore()) {
/* 2800 */         _reportInvalidEOFInValue(JsonToken.VALUE_NUMBER_FLOAT);
/*      */       }
/*      */       
/* 2803 */       ch = this._inputBuffer[this._inputPtr++];
/*      */       
/* 2805 */       if (ch == 78) {
/* 2806 */         match = neg ? "-INF" : "+INF";
/* 2807 */       } else if (ch == 110) {
/* 2808 */         match = neg ? "-Infinity" : "+Infinity";
/*      */       } else {
/*      */         break;
/*      */       } 
/* 2812 */       _matchToken(match, 3);
/* 2813 */       if ((this._features & FEAT_MASK_NON_NUM_NUMBERS) != 0) {
/* 2814 */         return resetAsNaN(match, neg ? Double.NEGATIVE_INFINITY : Double.POSITIVE_INFINITY);
/*      */       }
/* 2816 */       _reportError("Non-standard token '%s': enable JsonParser.Feature.ALLOW_NON_NUMERIC_NUMBERS to allow", match);
/*      */     } 
/*      */     
/* 2819 */     reportUnexpectedNumberChar(ch, "expected digit (0-9) to follow minus sign, for valid numeric value");
/* 2820 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void _matchTrue() throws IOException {
/* 2826 */     int ptr = this._inputPtr;
/* 2827 */     if (ptr + 3 < this._inputEnd) {
/* 2828 */       byte[] buf = this._inputBuffer;
/* 2829 */       if (buf[ptr++] == 114 && buf[ptr++] == 117 && buf[ptr++] == 101) {
/*      */ 
/*      */         
/* 2832 */         int ch = buf[ptr] & 0xFF;
/* 2833 */         if (ch < 48 || ch == 93 || ch == 125) {
/* 2834 */           this._inputPtr = ptr;
/*      */           return;
/*      */         } 
/*      */       } 
/*      */     } 
/* 2839 */     _matchToken2("true", 1);
/*      */   }
/*      */ 
/*      */   
/*      */   protected final void _matchFalse() throws IOException {
/* 2844 */     int ptr = this._inputPtr;
/* 2845 */     if (ptr + 4 < this._inputEnd) {
/* 2846 */       byte[] buf = this._inputBuffer;
/* 2847 */       if (buf[ptr++] == 97 && buf[ptr++] == 108 && buf[ptr++] == 115 && buf[ptr++] == 101) {
/*      */ 
/*      */ 
/*      */         
/* 2851 */         int ch = buf[ptr] & 0xFF;
/* 2852 */         if (ch < 48 || ch == 93 || ch == 125) {
/* 2853 */           this._inputPtr = ptr;
/*      */           return;
/*      */         } 
/*      */       } 
/*      */     } 
/* 2858 */     _matchToken2("false", 1);
/*      */   }
/*      */ 
/*      */   
/*      */   protected final void _matchNull() throws IOException {
/* 2863 */     int ptr = this._inputPtr;
/* 2864 */     if (ptr + 3 < this._inputEnd) {
/* 2865 */       byte[] buf = this._inputBuffer;
/* 2866 */       if (buf[ptr++] == 117 && buf[ptr++] == 108 && buf[ptr++] == 108) {
/*      */ 
/*      */         
/* 2869 */         int ch = buf[ptr] & 0xFF;
/* 2870 */         if (ch < 48 || ch == 93 || ch == 125) {
/* 2871 */           this._inputPtr = ptr;
/*      */           return;
/*      */         } 
/*      */       } 
/*      */     } 
/* 2876 */     _matchToken2("null", 1);
/*      */   }
/*      */ 
/*      */   
/*      */   protected final void _matchToken(String matchStr, int i) throws IOException {
/* 2881 */     int len = matchStr.length();
/* 2882 */     if (this._inputPtr + len >= this._inputEnd) {
/* 2883 */       _matchToken2(matchStr, i);
/*      */       return;
/*      */     } 
/*      */     do {
/* 2887 */       if (this._inputBuffer[this._inputPtr] != matchStr.charAt(i)) {
/* 2888 */         _reportInvalidToken(matchStr.substring(0, i));
/*      */       }
/* 2890 */       this._inputPtr++;
/* 2891 */     } while (++i < len);
/*      */     
/* 2893 */     int ch = this._inputBuffer[this._inputPtr] & 0xFF;
/* 2894 */     if (ch >= 48 && ch != 93 && ch != 125) {
/* 2895 */       _checkMatchEnd(matchStr, i, ch);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private final void _matchToken2(String matchStr, int i) throws IOException {
/* 2901 */     int len = matchStr.length();
/*      */     do {
/* 2903 */       if ((this._inputPtr >= this._inputEnd && !_loadMore()) || this._inputBuffer[this._inputPtr] != matchStr
/* 2904 */         .charAt(i)) {
/* 2905 */         _reportInvalidToken(matchStr.substring(0, i));
/*      */       }
/* 2907 */       this._inputPtr++;
/* 2908 */     } while (++i < len);
/*      */ 
/*      */     
/* 2911 */     if (this._inputPtr >= this._inputEnd && !_loadMore()) {
/*      */       return;
/*      */     }
/* 2914 */     int ch = this._inputBuffer[this._inputPtr] & 0xFF;
/* 2915 */     if (ch >= 48 && ch != 93 && ch != 125) {
/* 2916 */       _checkMatchEnd(matchStr, i, ch);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private final void _checkMatchEnd(String matchStr, int i, int ch) throws IOException {
/* 2922 */     char c = (char)_decodeCharForError(ch);
/* 2923 */     if (Character.isJavaIdentifierPart(c)) {
/* 2924 */       _reportInvalidToken(matchStr.substring(0, i));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final int _skipWS() throws IOException {
/* 2936 */     while (this._inputPtr < this._inputEnd) {
/* 2937 */       int i = this._inputBuffer[this._inputPtr++] & 0xFF;
/* 2938 */       if (i > 32) {
/* 2939 */         if (i == 47 || i == 35) {
/* 2940 */           this._inputPtr--;
/* 2941 */           return _skipWS2();
/*      */         } 
/* 2943 */         return i;
/*      */       } 
/* 2945 */       if (i != 32) {
/* 2946 */         if (i == 10) {
/* 2947 */           this._currInputRow++;
/* 2948 */           this._currInputRowStart = this._inputPtr; continue;
/* 2949 */         }  if (i == 13) {
/* 2950 */           _skipCR(); continue;
/* 2951 */         }  if (i != 9) {
/* 2952 */           _throwInvalidSpace(i);
/*      */         }
/*      */       } 
/*      */     } 
/* 2956 */     return _skipWS2();
/*      */   }
/*      */ 
/*      */   
/*      */   private final int _skipWS2() throws IOException {
/* 2961 */     while (this._inputPtr < this._inputEnd || _loadMore()) {
/* 2962 */       int i = this._inputBuffer[this._inputPtr++] & 0xFF;
/* 2963 */       if (i > 32) {
/* 2964 */         if (i == 47) {
/* 2965 */           _skipComment();
/*      */           continue;
/*      */         } 
/* 2968 */         if (i == 35 && 
/* 2969 */           _skipYAMLComment()) {
/*      */           continue;
/*      */         }
/*      */         
/* 2973 */         return i;
/*      */       } 
/* 2975 */       if (i != 32) {
/* 2976 */         if (i == 10) {
/* 2977 */           this._currInputRow++;
/* 2978 */           this._currInputRowStart = this._inputPtr; continue;
/* 2979 */         }  if (i == 13) {
/* 2980 */           _skipCR(); continue;
/* 2981 */         }  if (i != 9) {
/* 2982 */           _throwInvalidSpace(i);
/*      */         }
/*      */       } 
/*      */     } 
/* 2986 */     throw _constructError("Unexpected end-of-input within/between " + this._parsingContext.typeDesc() + " entries");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final int _skipWSOrEnd() throws IOException {
/* 2993 */     if (this._inputPtr >= this._inputEnd && 
/* 2994 */       !_loadMore()) {
/* 2995 */       return _eofAsNextChar();
/*      */     }
/*      */     
/* 2998 */     int i = this._inputBuffer[this._inputPtr++] & 0xFF;
/* 2999 */     if (i > 32) {
/* 3000 */       if (i == 47 || i == 35) {
/* 3001 */         this._inputPtr--;
/* 3002 */         return _skipWSOrEnd2();
/*      */       } 
/* 3004 */       return i;
/*      */     } 
/* 3006 */     if (i != 32) {
/* 3007 */       if (i == 10) {
/* 3008 */         this._currInputRow++;
/* 3009 */         this._currInputRowStart = this._inputPtr;
/* 3010 */       } else if (i == 13) {
/* 3011 */         _skipCR();
/* 3012 */       } else if (i != 9) {
/* 3013 */         _throwInvalidSpace(i);
/*      */       } 
/*      */     }
/*      */     
/* 3017 */     while (this._inputPtr < this._inputEnd) {
/* 3018 */       i = this._inputBuffer[this._inputPtr++] & 0xFF;
/* 3019 */       if (i > 32) {
/* 3020 */         if (i == 47 || i == 35) {
/* 3021 */           this._inputPtr--;
/* 3022 */           return _skipWSOrEnd2();
/*      */         } 
/* 3024 */         return i;
/*      */       } 
/* 3026 */       if (i != 32) {
/* 3027 */         if (i == 10) {
/* 3028 */           this._currInputRow++;
/* 3029 */           this._currInputRowStart = this._inputPtr; continue;
/* 3030 */         }  if (i == 13) {
/* 3031 */           _skipCR(); continue;
/* 3032 */         }  if (i != 9) {
/* 3033 */           _throwInvalidSpace(i);
/*      */         }
/*      */       } 
/*      */     } 
/* 3037 */     return _skipWSOrEnd2();
/*      */   }
/*      */ 
/*      */   
/*      */   private final int _skipWSOrEnd2() throws IOException {
/* 3042 */     while (this._inputPtr < this._inputEnd || _loadMore()) {
/* 3043 */       int i = this._inputBuffer[this._inputPtr++] & 0xFF;
/* 3044 */       if (i > 32) {
/* 3045 */         if (i == 47) {
/* 3046 */           _skipComment();
/*      */           continue;
/*      */         } 
/* 3049 */         if (i == 35 && 
/* 3050 */           _skipYAMLComment()) {
/*      */           continue;
/*      */         }
/*      */         
/* 3054 */         return i;
/* 3055 */       }  if (i != 32) {
/* 3056 */         if (i == 10) {
/* 3057 */           this._currInputRow++;
/* 3058 */           this._currInputRowStart = this._inputPtr; continue;
/* 3059 */         }  if (i == 13) {
/* 3060 */           _skipCR(); continue;
/* 3061 */         }  if (i != 9) {
/* 3062 */           _throwInvalidSpace(i);
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/* 3067 */     return _eofAsNextChar();
/*      */   }
/*      */ 
/*      */   
/*      */   private final int _skipColon() throws IOException {
/* 3072 */     if (this._inputPtr + 4 >= this._inputEnd) {
/* 3073 */       return _skipColon2(false);
/*      */     }
/*      */     
/* 3076 */     int i = this._inputBuffer[this._inputPtr];
/* 3077 */     if (i == 58) {
/* 3078 */       i = this._inputBuffer[++this._inputPtr];
/* 3079 */       if (i > 32) {
/* 3080 */         if (i == 47 || i == 35) {
/* 3081 */           return _skipColon2(true);
/*      */         }
/* 3083 */         this._inputPtr++;
/* 3084 */         return i;
/*      */       } 
/* 3086 */       if (i == 32 || i == 9) {
/* 3087 */         i = this._inputBuffer[++this._inputPtr];
/* 3088 */         if (i > 32) {
/* 3089 */           if (i == 47 || i == 35) {
/* 3090 */             return _skipColon2(true);
/*      */           }
/* 3092 */           this._inputPtr++;
/* 3093 */           return i;
/*      */         } 
/*      */       } 
/* 3096 */       return _skipColon2(true);
/*      */     } 
/* 3098 */     if (i == 32 || i == 9) {
/* 3099 */       i = this._inputBuffer[++this._inputPtr];
/*      */     }
/* 3101 */     if (i == 58) {
/* 3102 */       i = this._inputBuffer[++this._inputPtr];
/* 3103 */       if (i > 32) {
/* 3104 */         if (i == 47 || i == 35) {
/* 3105 */           return _skipColon2(true);
/*      */         }
/* 3107 */         this._inputPtr++;
/* 3108 */         return i;
/*      */       } 
/* 3110 */       if (i == 32 || i == 9) {
/* 3111 */         i = this._inputBuffer[++this._inputPtr];
/* 3112 */         if (i > 32) {
/* 3113 */           if (i == 47 || i == 35) {
/* 3114 */             return _skipColon2(true);
/*      */           }
/* 3116 */           this._inputPtr++;
/* 3117 */           return i;
/*      */         } 
/*      */       } 
/* 3120 */       return _skipColon2(true);
/*      */     } 
/* 3122 */     return _skipColon2(false);
/*      */   }
/*      */ 
/*      */   
/*      */   private final int _skipColon2(boolean gotColon) throws IOException {
/* 3127 */     while (this._inputPtr < this._inputEnd || _loadMore()) {
/* 3128 */       int i = this._inputBuffer[this._inputPtr++] & 0xFF;
/*      */       
/* 3130 */       if (i > 32) {
/* 3131 */         if (i == 47) {
/* 3132 */           _skipComment();
/*      */           continue;
/*      */         } 
/* 3135 */         if (i == 35 && 
/* 3136 */           _skipYAMLComment()) {
/*      */           continue;
/*      */         }
/*      */         
/* 3140 */         if (gotColon) {
/* 3141 */           return i;
/*      */         }
/* 3143 */         if (i != 58) {
/* 3144 */           _reportUnexpectedChar(i, "was expecting a colon to separate field name and value");
/*      */         }
/* 3146 */         gotColon = true; continue;
/* 3147 */       }  if (i != 32) {
/* 3148 */         if (i == 10) {
/* 3149 */           this._currInputRow++;
/* 3150 */           this._currInputRowStart = this._inputPtr; continue;
/* 3151 */         }  if (i == 13) {
/* 3152 */           _skipCR(); continue;
/* 3153 */         }  if (i != 9) {
/* 3154 */           _throwInvalidSpace(i);
/*      */         }
/*      */       } 
/*      */     } 
/* 3158 */     _reportInvalidEOF(" within/between " + this._parsingContext.typeDesc() + " entries", null);
/*      */     
/* 3160 */     return -1;
/*      */   }
/*      */ 
/*      */   
/*      */   private final void _skipComment() throws IOException {
/* 3165 */     if ((this._features & FEAT_MASK_ALLOW_JAVA_COMMENTS) == 0) {
/* 3166 */       _reportUnexpectedChar(47, "maybe a (non-standard) comment? (not recognized as one since Feature 'ALLOW_COMMENTS' not enabled for parser)");
/*      */     }
/*      */     
/* 3169 */     if (this._inputPtr >= this._inputEnd && !_loadMore()) {
/* 3170 */       _reportInvalidEOF(" in a comment", null);
/*      */     }
/* 3172 */     int c = this._inputBuffer[this._inputPtr++] & 0xFF;
/* 3173 */     if (c == 47) {
/* 3174 */       _skipLine();
/* 3175 */     } else if (c == 42) {
/* 3176 */       _skipCComment();
/*      */     } else {
/* 3178 */       _reportUnexpectedChar(c, "was expecting either '*' or '/' for a comment");
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private final void _skipCComment() throws IOException {
/* 3185 */     int[] codes = CharTypes.getInputCodeComment();
/*      */ 
/*      */ 
/*      */     
/* 3189 */     while (this._inputPtr < this._inputEnd || _loadMore()) {
/* 3190 */       int i = this._inputBuffer[this._inputPtr++] & 0xFF;
/* 3191 */       int code = codes[i];
/* 3192 */       if (code != 0) {
/* 3193 */         switch (code) {
/*      */           case 42:
/* 3195 */             if (this._inputPtr >= this._inputEnd && !_loadMore()) {
/*      */               break;
/*      */             }
/* 3198 */             if (this._inputBuffer[this._inputPtr] == 47) {
/* 3199 */               this._inputPtr++;
/*      */               return;
/*      */             } 
/*      */             continue;
/*      */           case 10:
/* 3204 */             this._currInputRow++;
/* 3205 */             this._currInputRowStart = this._inputPtr;
/*      */             continue;
/*      */           case 13:
/* 3208 */             _skipCR();
/*      */             continue;
/*      */           case 2:
/* 3211 */             _skipUtf8_2();
/*      */             continue;
/*      */           case 3:
/* 3214 */             _skipUtf8_3();
/*      */             continue;
/*      */           case 4:
/* 3217 */             _skipUtf8_4(i);
/*      */             continue;
/*      */         } 
/*      */         
/* 3221 */         _reportInvalidChar(i);
/*      */       } 
/*      */     } 
/*      */     
/* 3225 */     _reportInvalidEOF(" in a comment", null);
/*      */   }
/*      */ 
/*      */   
/*      */   private final boolean _skipYAMLComment() throws IOException {
/* 3230 */     if ((this._features & FEAT_MASK_ALLOW_YAML_COMMENTS) == 0) {
/* 3231 */       return false;
/*      */     }
/* 3233 */     _skipLine();
/* 3234 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void _skipLine() throws IOException {
/* 3244 */     int[] codes = CharTypes.getInputCodeComment();
/* 3245 */     while (this._inputPtr < this._inputEnd || _loadMore()) {
/* 3246 */       int i = this._inputBuffer[this._inputPtr++] & 0xFF;
/* 3247 */       int code = codes[i];
/* 3248 */       if (code != 0) {
/* 3249 */         switch (code) {
/*      */           case 10:
/* 3251 */             this._currInputRow++;
/* 3252 */             this._currInputRowStart = this._inputPtr;
/*      */             return;
/*      */           case 13:
/* 3255 */             _skipCR();
/*      */             return;
/*      */           case 42:
/*      */             continue;
/*      */           case 2:
/* 3260 */             _skipUtf8_2();
/*      */             continue;
/*      */           case 3:
/* 3263 */             _skipUtf8_3();
/*      */             continue;
/*      */           case 4:
/* 3266 */             _skipUtf8_4(i);
/*      */             continue;
/*      */         } 
/* 3269 */         if (code < 0)
/*      */         {
/* 3271 */           _reportInvalidChar(i);
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected char _decodeEscaped() throws IOException {
/* 3281 */     if (this._inputPtr >= this._inputEnd && 
/* 3282 */       !_loadMore()) {
/* 3283 */       _reportInvalidEOF(" in character escape sequence", JsonToken.VALUE_STRING);
/*      */     }
/*      */     
/* 3286 */     int c = this._inputBuffer[this._inputPtr++];
/*      */     
/* 3288 */     switch (c) {
/*      */       
/*      */       case 98:
/* 3291 */         return '\b';
/*      */       case 116:
/* 3293 */         return '\t';
/*      */       case 110:
/* 3295 */         return '\n';
/*      */       case 102:
/* 3297 */         return '\f';
/*      */       case 114:
/* 3299 */         return '\r';
/*      */ 
/*      */       
/*      */       case 34:
/*      */       case 47:
/*      */       case 92:
/* 3305 */         return (char)c;
/*      */       
/*      */       case 117:
/*      */         break;
/*      */       
/*      */       default:
/* 3311 */         return _handleUnrecognizedCharacterEscape((char)_decodeCharForError(c));
/*      */     } 
/*      */ 
/*      */     
/* 3315 */     int value = 0;
/* 3316 */     for (int i = 0; i < 4; i++) {
/* 3317 */       if (this._inputPtr >= this._inputEnd && 
/* 3318 */         !_loadMore()) {
/* 3319 */         _reportInvalidEOF(" in character escape sequence", JsonToken.VALUE_STRING);
/*      */       }
/*      */       
/* 3322 */       int ch = this._inputBuffer[this._inputPtr++];
/* 3323 */       int digit = CharTypes.charToHex(ch);
/* 3324 */       if (digit < 0) {
/* 3325 */         _reportUnexpectedChar(ch & 0xFF, "expected a hex-digit for character escape sequence");
/*      */       }
/* 3327 */       value = value << 4 | digit;
/*      */     } 
/* 3329 */     return (char)value;
/*      */   }
/*      */ 
/*      */   
/*      */   protected int _decodeCharForError(int firstByte) throws IOException {
/* 3334 */     int c = firstByte & 0xFF;
/* 3335 */     if (c > 127) {
/*      */       int needed;
/*      */ 
/*      */       
/* 3339 */       if ((c & 0xE0) == 192) {
/* 3340 */         c &= 0x1F;
/* 3341 */         needed = 1;
/* 3342 */       } else if ((c & 0xF0) == 224) {
/* 3343 */         c &= 0xF;
/* 3344 */         needed = 2;
/* 3345 */       } else if ((c & 0xF8) == 240) {
/*      */         
/* 3347 */         c &= 0x7;
/* 3348 */         needed = 3;
/*      */       } else {
/* 3350 */         _reportInvalidInitial(c & 0xFF);
/* 3351 */         needed = 1;
/*      */       } 
/*      */       
/* 3354 */       int d = nextByte();
/* 3355 */       if ((d & 0xC0) != 128) {
/* 3356 */         _reportInvalidOther(d & 0xFF);
/*      */       }
/* 3358 */       c = c << 6 | d & 0x3F;
/*      */       
/* 3360 */       if (needed > 1) {
/* 3361 */         d = nextByte();
/* 3362 */         if ((d & 0xC0) != 128) {
/* 3363 */           _reportInvalidOther(d & 0xFF);
/*      */         }
/* 3365 */         c = c << 6 | d & 0x3F;
/* 3366 */         if (needed > 2) {
/* 3367 */           d = nextByte();
/* 3368 */           if ((d & 0xC0) != 128) {
/* 3369 */             _reportInvalidOther(d & 0xFF);
/*      */           }
/* 3371 */           c = c << 6 | d & 0x3F;
/*      */         } 
/*      */       } 
/*      */     } 
/* 3375 */     return c;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final int _decodeUtf8_2(int c) throws IOException {
/* 3386 */     if (this._inputPtr >= this._inputEnd) {
/* 3387 */       _loadMoreGuaranteed();
/*      */     }
/* 3389 */     int d = this._inputBuffer[this._inputPtr++];
/* 3390 */     if ((d & 0xC0) != 128) {
/* 3391 */       _reportInvalidOther(d & 0xFF, this._inputPtr);
/*      */     }
/* 3393 */     return (c & 0x1F) << 6 | d & 0x3F;
/*      */   }
/*      */ 
/*      */   
/*      */   private final int _decodeUtf8_3(int c1) throws IOException {
/* 3398 */     if (this._inputPtr >= this._inputEnd) {
/* 3399 */       _loadMoreGuaranteed();
/*      */     }
/* 3401 */     c1 &= 0xF;
/* 3402 */     int d = this._inputBuffer[this._inputPtr++];
/* 3403 */     if ((d & 0xC0) != 128) {
/* 3404 */       _reportInvalidOther(d & 0xFF, this._inputPtr);
/*      */     }
/* 3406 */     int c = c1 << 6 | d & 0x3F;
/* 3407 */     if (this._inputPtr >= this._inputEnd) {
/* 3408 */       _loadMoreGuaranteed();
/*      */     }
/* 3410 */     d = this._inputBuffer[this._inputPtr++];
/* 3411 */     if ((d & 0xC0) != 128) {
/* 3412 */       _reportInvalidOther(d & 0xFF, this._inputPtr);
/*      */     }
/* 3414 */     c = c << 6 | d & 0x3F;
/* 3415 */     return c;
/*      */   }
/*      */ 
/*      */   
/*      */   private final int _decodeUtf8_3fast(int c1) throws IOException {
/* 3420 */     c1 &= 0xF;
/* 3421 */     int d = this._inputBuffer[this._inputPtr++];
/* 3422 */     if ((d & 0xC0) != 128) {
/* 3423 */       _reportInvalidOther(d & 0xFF, this._inputPtr);
/*      */     }
/* 3425 */     int c = c1 << 6 | d & 0x3F;
/* 3426 */     d = this._inputBuffer[this._inputPtr++];
/* 3427 */     if ((d & 0xC0) != 128) {
/* 3428 */       _reportInvalidOther(d & 0xFF, this._inputPtr);
/*      */     }
/* 3430 */     c = c << 6 | d & 0x3F;
/* 3431 */     return c;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final int _decodeUtf8_4(int c) throws IOException {
/* 3440 */     if (this._inputPtr >= this._inputEnd) {
/* 3441 */       _loadMoreGuaranteed();
/*      */     }
/* 3443 */     int d = this._inputBuffer[this._inputPtr++];
/* 3444 */     if ((d & 0xC0) != 128) {
/* 3445 */       _reportInvalidOther(d & 0xFF, this._inputPtr);
/*      */     }
/* 3447 */     c = (c & 0x7) << 6 | d & 0x3F;
/*      */     
/* 3449 */     if (this._inputPtr >= this._inputEnd) {
/* 3450 */       _loadMoreGuaranteed();
/*      */     }
/* 3452 */     d = this._inputBuffer[this._inputPtr++];
/* 3453 */     if ((d & 0xC0) != 128) {
/* 3454 */       _reportInvalidOther(d & 0xFF, this._inputPtr);
/*      */     }
/* 3456 */     c = c << 6 | d & 0x3F;
/* 3457 */     if (this._inputPtr >= this._inputEnd) {
/* 3458 */       _loadMoreGuaranteed();
/*      */     }
/* 3460 */     d = this._inputBuffer[this._inputPtr++];
/* 3461 */     if ((d & 0xC0) != 128) {
/* 3462 */       _reportInvalidOther(d & 0xFF, this._inputPtr);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3468 */     return (c << 6 | d & 0x3F) - 65536;
/*      */   }
/*      */ 
/*      */   
/*      */   private final void _skipUtf8_2() throws IOException {
/* 3473 */     if (this._inputPtr >= this._inputEnd) {
/* 3474 */       _loadMoreGuaranteed();
/*      */     }
/* 3476 */     int c = this._inputBuffer[this._inputPtr++];
/* 3477 */     if ((c & 0xC0) != 128) {
/* 3478 */       _reportInvalidOther(c & 0xFF, this._inputPtr);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void _skipUtf8_3() throws IOException {
/* 3487 */     if (this._inputPtr >= this._inputEnd) {
/* 3488 */       _loadMoreGuaranteed();
/*      */     }
/*      */     
/* 3491 */     int c = this._inputBuffer[this._inputPtr++];
/* 3492 */     if ((c & 0xC0) != 128) {
/* 3493 */       _reportInvalidOther(c & 0xFF, this._inputPtr);
/*      */     }
/* 3495 */     if (this._inputPtr >= this._inputEnd) {
/* 3496 */       _loadMoreGuaranteed();
/*      */     }
/* 3498 */     c = this._inputBuffer[this._inputPtr++];
/* 3499 */     if ((c & 0xC0) != 128) {
/* 3500 */       _reportInvalidOther(c & 0xFF, this._inputPtr);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private final void _skipUtf8_4(int c) throws IOException {
/* 3506 */     if (this._inputPtr >= this._inputEnd) {
/* 3507 */       _loadMoreGuaranteed();
/*      */     }
/* 3509 */     int d = this._inputBuffer[this._inputPtr++];
/* 3510 */     if ((d & 0xC0) != 128) {
/* 3511 */       _reportInvalidOther(d & 0xFF, this._inputPtr);
/*      */     }
/* 3513 */     if (this._inputPtr >= this._inputEnd) {
/* 3514 */       _loadMoreGuaranteed();
/*      */     }
/* 3516 */     d = this._inputBuffer[this._inputPtr++];
/* 3517 */     if ((d & 0xC0) != 128) {
/* 3518 */       _reportInvalidOther(d & 0xFF, this._inputPtr);
/*      */     }
/* 3520 */     if (this._inputPtr >= this._inputEnd) {
/* 3521 */       _loadMoreGuaranteed();
/*      */     }
/* 3523 */     d = this._inputBuffer[this._inputPtr++];
/* 3524 */     if ((d & 0xC0) != 128) {
/* 3525 */       _reportInvalidOther(d & 0xFF, this._inputPtr);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void _skipCR() throws IOException {
/* 3541 */     if ((this._inputPtr < this._inputEnd || _loadMore()) && 
/* 3542 */       this._inputBuffer[this._inputPtr] == 10) {
/* 3543 */       this._inputPtr++;
/*      */     }
/*      */     
/* 3546 */     this._currInputRow++;
/* 3547 */     this._currInputRowStart = this._inputPtr;
/*      */   }
/*      */ 
/*      */   
/*      */   private int nextByte() throws IOException {
/* 3552 */     if (this._inputPtr >= this._inputEnd) {
/* 3553 */       _loadMoreGuaranteed();
/*      */     }
/* 3555 */     return this._inputBuffer[this._inputPtr++] & 0xFF;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _reportInvalidToken(String matchedPart, int ptr) throws IOException {
/* 3565 */     this._inputPtr = ptr;
/* 3566 */     _reportInvalidToken(matchedPart, _validJsonTokenList());
/*      */   }
/*      */   
/*      */   protected void _reportInvalidToken(String matchedPart) throws IOException {
/* 3570 */     _reportInvalidToken(matchedPart, _validJsonTokenList());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _reportInvalidToken(String matchedPart, String msg) throws IOException {
/* 3579 */     StringBuilder sb = new StringBuilder(matchedPart);
/* 3580 */     while (this._inputPtr < this._inputEnd || _loadMore()) {
/* 3581 */       int i = this._inputBuffer[this._inputPtr++];
/* 3582 */       char c = (char)_decodeCharForError(i);
/* 3583 */       if (!Character.isJavaIdentifierPart(c)) {
/*      */         break;
/*      */       }
/*      */ 
/*      */       
/* 3588 */       sb.append(c);
/* 3589 */       if (sb.length() >= 256) {
/* 3590 */         sb.append("...");
/*      */         break;
/*      */       } 
/*      */     } 
/* 3594 */     _reportError("Unrecognized token '%s': was expecting %s", sb, msg);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _reportInvalidChar(int c) throws JsonParseException {
/* 3600 */     if (c < 32) {
/* 3601 */       _throwInvalidSpace(c);
/*      */     }
/* 3603 */     _reportInvalidInitial(c);
/*      */   }
/*      */   
/*      */   protected void _reportInvalidInitial(int mask) throws JsonParseException {
/* 3607 */     _reportError("Invalid UTF-8 start byte 0x" + Integer.toHexString(mask));
/*      */   }
/*      */   
/*      */   protected void _reportInvalidOther(int mask) throws JsonParseException {
/* 3611 */     _reportError("Invalid UTF-8 middle byte 0x" + Integer.toHexString(mask));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _reportInvalidOther(int mask, int ptr) throws JsonParseException {
/* 3617 */     this._inputPtr = ptr;
/* 3618 */     _reportInvalidOther(mask);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final byte[] _decodeBase64(Base64Variant b64variant) throws IOException {
/* 3634 */     ByteArrayBuilder builder = _getByteArrayBuilder();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     while (true) {
/* 3640 */       if (this._inputPtr >= this._inputEnd) {
/* 3641 */         _loadMoreGuaranteed();
/*      */       }
/* 3643 */       int ch = this._inputBuffer[this._inputPtr++] & 0xFF;
/* 3644 */       if (ch > 32) {
/* 3645 */         int bits = b64variant.decodeBase64Char(ch);
/* 3646 */         if (bits < 0) {
/* 3647 */           if (ch == 34) {
/* 3648 */             return builder.toByteArray();
/*      */           }
/* 3650 */           bits = _decodeBase64Escape(b64variant, ch, 0);
/* 3651 */           if (bits < 0) {
/*      */             continue;
/*      */           }
/*      */         } 
/* 3655 */         int decodedData = bits;
/*      */ 
/*      */ 
/*      */         
/* 3659 */         if (this._inputPtr >= this._inputEnd) {
/* 3660 */           _loadMoreGuaranteed();
/*      */         }
/* 3662 */         ch = this._inputBuffer[this._inputPtr++] & 0xFF;
/* 3663 */         bits = b64variant.decodeBase64Char(ch);
/* 3664 */         if (bits < 0) {
/* 3665 */           bits = _decodeBase64Escape(b64variant, ch, 1);
/*      */         }
/* 3667 */         decodedData = decodedData << 6 | bits;
/*      */ 
/*      */         
/* 3670 */         if (this._inputPtr >= this._inputEnd) {
/* 3671 */           _loadMoreGuaranteed();
/*      */         }
/* 3673 */         ch = this._inputBuffer[this._inputPtr++] & 0xFF;
/* 3674 */         bits = b64variant.decodeBase64Char(ch);
/*      */ 
/*      */         
/* 3677 */         if (bits < 0) {
/* 3678 */           if (bits != -2) {
/*      */             
/* 3680 */             if (ch == 34) {
/* 3681 */               decodedData >>= 4;
/* 3682 */               builder.append(decodedData);
/* 3683 */               if (b64variant.usesPadding()) {
/* 3684 */                 this._inputPtr--;
/* 3685 */                 _handleBase64MissingPadding(b64variant);
/*      */               } 
/* 3687 */               return builder.toByteArray();
/*      */             } 
/* 3689 */             bits = _decodeBase64Escape(b64variant, ch, 2);
/*      */           } 
/* 3691 */           if (bits == -2) {
/*      */             
/* 3693 */             if (this._inputPtr >= this._inputEnd) {
/* 3694 */               _loadMoreGuaranteed();
/*      */             }
/* 3696 */             ch = this._inputBuffer[this._inputPtr++] & 0xFF;
/* 3697 */             if (!b64variant.usesPaddingChar(ch) && 
/* 3698 */               _decodeBase64Escape(b64variant, ch, 3) != -2) {
/* 3699 */               throw reportInvalidBase64Char(b64variant, ch, 3, "expected padding character '" + b64variant.getPaddingChar() + "'");
/*      */             }
/*      */ 
/*      */             
/* 3703 */             decodedData >>= 4;
/* 3704 */             builder.append(decodedData);
/*      */             
/*      */             continue;
/*      */           } 
/*      */         } 
/* 3709 */         decodedData = decodedData << 6 | bits;
/*      */         
/* 3711 */         if (this._inputPtr >= this._inputEnd) {
/* 3712 */           _loadMoreGuaranteed();
/*      */         }
/* 3714 */         ch = this._inputBuffer[this._inputPtr++] & 0xFF;
/* 3715 */         bits = b64variant.decodeBase64Char(ch);
/* 3716 */         if (bits < 0) {
/* 3717 */           if (bits != -2) {
/*      */             
/* 3719 */             if (ch == 34) {
/* 3720 */               decodedData >>= 2;
/* 3721 */               builder.appendTwoBytes(decodedData);
/* 3722 */               if (b64variant.usesPadding()) {
/* 3723 */                 this._inputPtr--;
/* 3724 */                 _handleBase64MissingPadding(b64variant);
/*      */               } 
/* 3726 */               return builder.toByteArray();
/*      */             } 
/* 3728 */             bits = _decodeBase64Escape(b64variant, ch, 3);
/*      */           } 
/* 3730 */           if (bits == -2) {
/*      */ 
/*      */ 
/*      */             
/* 3734 */             decodedData >>= 2;
/* 3735 */             builder.appendTwoBytes(decodedData);
/*      */             
/*      */             continue;
/*      */           } 
/*      */         } 
/* 3740 */         decodedData = decodedData << 6 | bits;
/* 3741 */         builder.appendThreeBytes(decodedData);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonLocation getTokenLocation() {
/* 3755 */     if (this._currToken == JsonToken.FIELD_NAME) {
/* 3756 */       long total = this._currInputProcessed + (this._nameStartOffset - 1);
/* 3757 */       return new JsonLocation(_getSourceReference(), total, -1L, this._nameStartRow, this._nameStartCol);
/*      */     } 
/*      */     
/* 3760 */     return new JsonLocation(_getSourceReference(), this._tokenInputTotal - 1L, -1L, this._tokenInputRow, this._tokenInputCol);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonLocation getCurrentLocation() {
/* 3768 */     int col = this._inputPtr - this._currInputRowStart + 1;
/* 3769 */     return new JsonLocation(_getSourceReference(), this._currInputProcessed + this._inputPtr, -1L, this._currInputRow, col);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void _updateLocation() {
/* 3777 */     this._tokenInputRow = this._currInputRow;
/* 3778 */     int ptr = this._inputPtr;
/* 3779 */     this._tokenInputTotal = this._currInputProcessed + ptr;
/* 3780 */     this._tokenInputCol = ptr - this._currInputRowStart;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private final void _updateNameLocation() {
/* 3786 */     this._nameStartRow = this._currInputRow;
/* 3787 */     int ptr = this._inputPtr;
/* 3788 */     this._nameStartOffset = ptr;
/* 3789 */     this._nameStartCol = ptr - this._currInputRowStart;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final JsonToken _closeScope(int i) throws JsonParseException {
/* 3799 */     if (i == 125) {
/* 3800 */       _closeObjectScope();
/* 3801 */       return this._currToken = JsonToken.END_OBJECT;
/*      */     } 
/* 3803 */     _closeArrayScope();
/* 3804 */     return this._currToken = JsonToken.END_ARRAY;
/*      */   }
/*      */   
/*      */   private final void _closeArrayScope() throws JsonParseException {
/* 3808 */     _updateLocation();
/* 3809 */     if (!this._parsingContext.inArray()) {
/* 3810 */       _reportMismatchedEndMarker(93, '}');
/*      */     }
/* 3812 */     this._parsingContext = this._parsingContext.clearAndGetParent();
/*      */   }
/*      */   
/*      */   private final void _closeObjectScope() throws JsonParseException {
/* 3816 */     _updateLocation();
/* 3817 */     if (!this._parsingContext.inObject()) {
/* 3818 */       _reportMismatchedEndMarker(125, ']');
/*      */     }
/* 3820 */     this._parsingContext = this._parsingContext.clearAndGetParent();
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-core-2.12.7.jar!\com\fasterxml\jackson\core\json\UTF8StreamJsonParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */