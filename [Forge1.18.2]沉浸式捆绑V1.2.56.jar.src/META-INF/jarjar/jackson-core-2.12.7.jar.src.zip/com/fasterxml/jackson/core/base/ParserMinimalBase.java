/*     */ package com.fasterxml.jackson.core.base;
/*     */ 
/*     */ import com.fasterxml.jackson.core.Base64Variant;
/*     */ import com.fasterxml.jackson.core.JsonParseException;
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.JsonStreamContext;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.core.exc.InputCoercionException;
/*     */ import com.fasterxml.jackson.core.io.JsonEOFException;
/*     */ import com.fasterxml.jackson.core.io.NumberInput;
/*     */ import com.fasterxml.jackson.core.util.ByteArrayBuilder;
/*     */ import com.fasterxml.jackson.core.util.VersionUtil;
/*     */ import java.io.IOException;
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ParserMinimalBase
/*     */   extends JsonParser
/*     */ {
/*     */   protected static final int INT_TAB = 9;
/*     */   protected static final int INT_LF = 10;
/*     */   protected static final int INT_CR = 13;
/*     */   protected static final int INT_SPACE = 32;
/*     */   protected static final int INT_LBRACKET = 91;
/*     */   protected static final int INT_RBRACKET = 93;
/*     */   protected static final int INT_LCURLY = 123;
/*     */   protected static final int INT_RCURLY = 125;
/*     */   protected static final int INT_QUOTE = 34;
/*     */   protected static final int INT_APOS = 39;
/*     */   protected static final int INT_BACKSLASH = 92;
/*     */   protected static final int INT_SLASH = 47;
/*     */   protected static final int INT_ASTERISK = 42;
/*     */   protected static final int INT_COLON = 58;
/*     */   protected static final int INT_COMMA = 44;
/*     */   protected static final int INT_HASH = 35;
/*     */   protected static final int INT_0 = 48;
/*     */   protected static final int INT_9 = 57;
/*     */   protected static final int INT_MINUS = 45;
/*     */   protected static final int INT_PLUS = 43;
/*     */   protected static final int INT_PERIOD = 46;
/*     */   protected static final int INT_e = 101;
/*     */   protected static final int INT_E = 69;
/*     */   protected static final char CHAR_NULL = '\000';
/*  62 */   protected static final byte[] NO_BYTES = new byte[0];
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  67 */   protected static final int[] NO_INTS = new int[0];
/*     */ 
/*     */ 
/*     */   
/*     */   protected static final int NR_UNKNOWN = 0;
/*     */ 
/*     */ 
/*     */   
/*     */   protected static final int NR_INT = 1;
/*     */ 
/*     */ 
/*     */   
/*     */   protected static final int NR_LONG = 2;
/*     */ 
/*     */ 
/*     */   
/*     */   protected static final int NR_BIGINT = 4;
/*     */ 
/*     */ 
/*     */   
/*     */   protected static final int NR_DOUBLE = 8;
/*     */ 
/*     */ 
/*     */   
/*     */   protected static final int NR_BIGDECIMAL = 16;
/*     */ 
/*     */   
/*     */   protected static final int NR_FLOAT = 32;
/*     */ 
/*     */   
/*  97 */   protected static final BigInteger BI_MIN_INT = BigInteger.valueOf(-2147483648L);
/*  98 */   protected static final BigInteger BI_MAX_INT = BigInteger.valueOf(2147483647L);
/*     */   
/* 100 */   protected static final BigInteger BI_MIN_LONG = BigInteger.valueOf(Long.MIN_VALUE);
/* 101 */   protected static final BigInteger BI_MAX_LONG = BigInteger.valueOf(Long.MAX_VALUE);
/*     */   
/* 103 */   protected static final BigDecimal BD_MIN_LONG = new BigDecimal(BI_MIN_LONG);
/* 104 */   protected static final BigDecimal BD_MAX_LONG = new BigDecimal(BI_MAX_LONG);
/*     */   
/* 106 */   protected static final BigDecimal BD_MIN_INT = new BigDecimal(BI_MIN_INT);
/* 107 */   protected static final BigDecimal BD_MAX_INT = new BigDecimal(BI_MAX_INT);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static final long MIN_INT_L = -2147483648L;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static final long MAX_INT_L = 2147483647L;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static final double MIN_LONG_D = -9.223372036854776E18D;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static final double MAX_LONG_D = 9.223372036854776E18D;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static final double MIN_INT_D = -2.147483648E9D;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static final double MAX_INT_D = 2.147483647E9D;
/*     */ 
/*     */ 
/*     */   
/*     */   protected static final int MAX_ERROR_TOKEN_LENGTH = 256;
/*     */ 
/*     */ 
/*     */   
/*     */   protected JsonToken _currToken;
/*     */ 
/*     */ 
/*     */   
/*     */   protected JsonToken _lastClearedToken;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ParserMinimalBase() {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ParserMinimalBase(int features) {
/* 160 */     super(features);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract JsonToken nextToken() throws IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonToken currentToken() {
/* 186 */     return this._currToken;
/*     */   } public int currentTokenId() {
/* 188 */     JsonToken t = this._currToken;
/* 189 */     return (t == null) ? 0 : t.id();
/*     */   }
/*     */   public JsonToken getCurrentToken() {
/* 192 */     return this._currToken;
/*     */   }
/*     */   @Deprecated
/*     */   public int getCurrentTokenId() {
/* 196 */     JsonToken t = this._currToken;
/* 197 */     return (t == null) ? 0 : t.id();
/*     */   }
/*     */   public boolean hasCurrentToken() {
/* 200 */     return (this._currToken != null);
/*     */   } public boolean hasTokenId(int id) {
/* 202 */     JsonToken t = this._currToken;
/* 203 */     if (t == null) {
/* 204 */       return (0 == id);
/*     */     }
/* 206 */     return (t.id() == id);
/*     */   }
/*     */   
/*     */   public boolean hasToken(JsonToken t) {
/* 210 */     return (this._currToken == t);
/*     */   }
/*     */   
/* 213 */   public boolean isExpectedStartArrayToken() { return (this._currToken == JsonToken.START_ARRAY); }
/* 214 */   public boolean isExpectedStartObjectToken() { return (this._currToken == JsonToken.START_OBJECT); } public boolean isExpectedNumberIntToken() {
/* 215 */     return (this._currToken == JsonToken.VALUE_NUMBER_INT);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonToken nextValue() throws IOException {
/* 221 */     JsonToken t = nextToken();
/* 222 */     if (t == JsonToken.FIELD_NAME) {
/* 223 */       t = nextToken();
/*     */     }
/* 225 */     return t;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonParser skipChildren() throws IOException {
/* 231 */     if (this._currToken != JsonToken.START_OBJECT && this._currToken != JsonToken.START_ARRAY)
/*     */     {
/* 233 */       return this;
/*     */     }
/* 235 */     int open = 1;
/*     */ 
/*     */ 
/*     */     
/*     */     while (true) {
/* 240 */       JsonToken t = nextToken();
/* 241 */       if (t == null) {
/* 242 */         _handleEOF();
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 247 */         return this;
/*     */       } 
/* 249 */       if (t.isStructStart()) {
/* 250 */         open++; continue;
/* 251 */       }  if (t.isStructEnd()) {
/* 252 */         if (--open == 0)
/* 253 */           return this; 
/*     */         continue;
/*     */       } 
/* 256 */       if (t == JsonToken.NOT_AVAILABLE)
/*     */       {
/*     */         
/* 259 */         _reportError("Not enough content available for `skipChildren()`: non-blocking parser? (%s)", 
/* 260 */             getClass().getName());
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract void _handleEOF() throws JsonParseException;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract String getCurrentName() throws IOException;
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void close() throws IOException;
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract boolean isClosed();
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract JsonStreamContext getParsingContext();
/*     */ 
/*     */ 
/*     */   
/*     */   public void clearCurrentToken() {
/* 290 */     if (this._currToken != null) {
/* 291 */       this._lastClearedToken = this._currToken;
/* 292 */       this._currToken = null;
/*     */     } 
/*     */   }
/*     */   public JsonToken getLastClearedToken() {
/* 296 */     return this._lastClearedToken;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void overrideCurrentName(String paramString);
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract String getText() throws IOException;
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract char[] getTextCharacters() throws IOException;
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract boolean hasTextCharacters();
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract int getTextLength() throws IOException;
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract int getTextOffset() throws IOException;
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract byte[] getBinaryValue(Base64Variant paramBase64Variant) throws IOException;
/*     */ 
/*     */   
/*     */   public boolean getValueAsBoolean(boolean defaultValue) throws IOException {
/* 329 */     JsonToken t = this._currToken;
/* 330 */     if (t != null) {
/* 331 */       String str; Object value; switch (t.id()) {
/*     */         case 6:
/* 333 */           str = getText().trim();
/* 334 */           if ("true".equals(str)) {
/* 335 */             return true;
/*     */           }
/* 337 */           if ("false".equals(str)) {
/* 338 */             return false;
/*     */           }
/* 340 */           if (_hasTextualNull(str)) {
/* 341 */             return false;
/*     */           }
/*     */           break;
/*     */         case 7:
/* 345 */           return (getIntValue() != 0);
/*     */         case 9:
/* 347 */           return true;
/*     */         case 10:
/*     */         case 11:
/* 350 */           return false;
/*     */         case 12:
/* 352 */           value = getEmbeddedObject();
/* 353 */           if (value instanceof Boolean) {
/* 354 */             return ((Boolean)value).booleanValue();
/*     */           }
/*     */           break;
/*     */       } 
/*     */     
/*     */     } 
/* 360 */     return defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getValueAsInt() throws IOException {
/* 366 */     JsonToken t = this._currToken;
/* 367 */     if (t == JsonToken.VALUE_NUMBER_INT || t == JsonToken.VALUE_NUMBER_FLOAT) {
/* 368 */       return getIntValue();
/*     */     }
/* 370 */     return getValueAsInt(0);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getValueAsInt(int defaultValue) throws IOException {
/* 376 */     JsonToken t = this._currToken;
/* 377 */     if (t == JsonToken.VALUE_NUMBER_INT || t == JsonToken.VALUE_NUMBER_FLOAT) {
/* 378 */       return getIntValue();
/*     */     }
/* 380 */     if (t != null) {
/* 381 */       String str; Object value; switch (t.id()) {
/*     */         case 6:
/* 383 */           str = getText();
/* 384 */           if (_hasTextualNull(str)) {
/* 385 */             return 0;
/*     */           }
/* 387 */           return NumberInput.parseAsInt(str, defaultValue);
/*     */         case 9:
/* 389 */           return 1;
/*     */         case 10:
/* 391 */           return 0;
/*     */         case 11:
/* 393 */           return 0;
/*     */         case 12:
/* 395 */           value = getEmbeddedObject();
/* 396 */           if (value instanceof Number)
/* 397 */             return ((Number)value).intValue(); 
/*     */           break;
/*     */       } 
/*     */     } 
/* 401 */     return defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long getValueAsLong() throws IOException {
/* 407 */     JsonToken t = this._currToken;
/* 408 */     if (t == JsonToken.VALUE_NUMBER_INT || t == JsonToken.VALUE_NUMBER_FLOAT) {
/* 409 */       return getLongValue();
/*     */     }
/* 411 */     return getValueAsLong(0L);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long getValueAsLong(long defaultValue) throws IOException {
/* 417 */     JsonToken t = this._currToken;
/* 418 */     if (t == JsonToken.VALUE_NUMBER_INT || t == JsonToken.VALUE_NUMBER_FLOAT) {
/* 419 */       return getLongValue();
/*     */     }
/* 421 */     if (t != null) {
/* 422 */       String str; Object value; switch (t.id()) {
/*     */         case 6:
/* 424 */           str = getText();
/* 425 */           if (_hasTextualNull(str)) {
/* 426 */             return 0L;
/*     */           }
/* 428 */           return NumberInput.parseAsLong(str, defaultValue);
/*     */         case 9:
/* 430 */           return 1L;
/*     */         case 10:
/*     */         case 11:
/* 433 */           return 0L;
/*     */         case 12:
/* 435 */           value = getEmbeddedObject();
/* 436 */           if (value instanceof Number)
/* 437 */             return ((Number)value).longValue(); 
/*     */           break;
/*     */       } 
/*     */     } 
/* 441 */     return defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public double getValueAsDouble(double defaultValue) throws IOException {
/* 447 */     JsonToken t = this._currToken;
/* 448 */     if (t != null) {
/* 449 */       String str; Object value; switch (t.id()) {
/*     */         case 6:
/* 451 */           str = getText();
/* 452 */           if (_hasTextualNull(str)) {
/* 453 */             return 0.0D;
/*     */           }
/* 455 */           return NumberInput.parseAsDouble(str, defaultValue);
/*     */         case 7:
/*     */         case 8:
/* 458 */           return getDoubleValue();
/*     */         case 9:
/* 460 */           return 1.0D;
/*     */         case 10:
/*     */         case 11:
/* 463 */           return 0.0D;
/*     */         case 12:
/* 465 */           value = getEmbeddedObject();
/* 466 */           if (value instanceof Number)
/* 467 */             return ((Number)value).doubleValue(); 
/*     */           break;
/*     */       } 
/*     */     } 
/* 471 */     return defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getValueAsString() throws IOException {
/* 477 */     return getValueAsString((String)null);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getValueAsString(String defaultValue) throws IOException {
/* 482 */     if (this._currToken == JsonToken.VALUE_STRING) {
/* 483 */       return getText();
/*     */     }
/* 485 */     if (this._currToken == JsonToken.FIELD_NAME) {
/* 486 */       return getCurrentName();
/*     */     }
/* 488 */     if (this._currToken == null || this._currToken == JsonToken.VALUE_NULL || !this._currToken.isScalarValue()) {
/* 489 */       return defaultValue;
/*     */     }
/* 491 */     return getText();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void _decodeBase64(String str, ByteArrayBuilder builder, Base64Variant b64variant) throws IOException {
/*     */     try {
/* 507 */       b64variant.decode(str, builder);
/* 508 */     } catch (IllegalArgumentException e) {
/* 509 */       _reportError(e.getMessage());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean _hasTextualNull(String value) {
/* 526 */     return "null".equals(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void reportUnexpectedNumberChar(int ch, String comment) throws JsonParseException {
/* 535 */     String msg = String.format("Unexpected character (%s) in numeric value", new Object[] { _getCharDesc(ch) });
/* 536 */     if (comment != null) {
/* 537 */       msg = msg + ": " + comment;
/*     */     }
/* 539 */     _reportError(msg);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void reportInvalidNumber(String msg) throws JsonParseException {
/* 549 */     _reportError("Invalid numeric value: " + msg);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void reportOverflowInt() throws IOException {
/* 558 */     reportOverflowInt(getText());
/*     */   }
/*     */ 
/*     */   
/*     */   protected void reportOverflowInt(String numDesc) throws IOException {
/* 563 */     reportOverflowInt(numDesc, currentToken());
/*     */   }
/*     */ 
/*     */   
/*     */   protected void reportOverflowInt(String numDesc, JsonToken inputType) throws IOException {
/* 568 */     _reportInputCoercion(String.format("Numeric value (%s) out of range of int (%d - %s)", new Object[] {
/* 569 */             _longIntegerDesc(numDesc), Integer.valueOf(-2147483648), Integer.valueOf(2147483647)
/*     */           }), inputType, int.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void reportOverflowLong() throws IOException {
/* 579 */     reportOverflowLong(getText());
/*     */   }
/*     */ 
/*     */   
/*     */   protected void reportOverflowLong(String numDesc) throws IOException {
/* 584 */     reportOverflowLong(numDesc, currentToken());
/*     */   }
/*     */ 
/*     */   
/*     */   protected void reportOverflowLong(String numDesc, JsonToken inputType) throws IOException {
/* 589 */     _reportInputCoercion(String.format("Numeric value (%s) out of range of long (%d - %s)", new Object[] {
/* 590 */             _longIntegerDesc(numDesc), Long.valueOf(Long.MIN_VALUE), Long.valueOf(Long.MAX_VALUE)
/*     */           }), inputType, long.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void _reportInputCoercion(String msg, JsonToken inputType, Class<?> targetType) throws InputCoercionException {
/* 599 */     throw new InputCoercionException(this, msg, inputType, targetType);
/*     */   }
/*     */ 
/*     */   
/*     */   protected String _longIntegerDesc(String rawNum) {
/* 604 */     int rawLen = rawNum.length();
/* 605 */     if (rawLen < 1000) {
/* 606 */       return rawNum;
/*     */     }
/* 608 */     if (rawNum.startsWith("-")) {
/* 609 */       rawLen--;
/*     */     }
/* 611 */     return String.format("[Integer with %d digits]", new Object[] { Integer.valueOf(rawLen) });
/*     */   }
/*     */ 
/*     */   
/*     */   protected String _longNumberDesc(String rawNum) {
/* 616 */     int rawLen = rawNum.length();
/* 617 */     if (rawLen < 1000) {
/* 618 */       return rawNum;
/*     */     }
/* 620 */     if (rawNum.startsWith("-")) {
/* 621 */       rawLen--;
/*     */     }
/* 623 */     return String.format("[number with %d characters]", new Object[] { Integer.valueOf(rawLen) });
/*     */   }
/*     */ 
/*     */   
/*     */   protected void _reportUnexpectedChar(int ch, String comment) throws JsonParseException {
/* 628 */     if (ch < 0) {
/* 629 */       _reportInvalidEOF();
/*     */     }
/* 631 */     String msg = String.format("Unexpected character (%s)", new Object[] { _getCharDesc(ch) });
/* 632 */     if (comment != null) {
/* 633 */       msg = msg + ": " + comment;
/*     */     }
/* 635 */     _reportError(msg);
/*     */   }
/*     */   
/*     */   protected void _reportInvalidEOF() throws JsonParseException {
/* 639 */     _reportInvalidEOF(" in " + this._currToken, this._currToken);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void _reportInvalidEOFInValue(JsonToken type) throws JsonParseException {
/*     */     String msg;
/* 647 */     if (type == JsonToken.VALUE_STRING) {
/* 648 */       msg = " in a String value";
/* 649 */     } else if (type == JsonToken.VALUE_NUMBER_INT || type == JsonToken.VALUE_NUMBER_FLOAT) {
/*     */       
/* 651 */       msg = " in a Number value";
/*     */     } else {
/* 653 */       msg = " in a value";
/*     */     } 
/* 655 */     _reportInvalidEOF(msg, type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void _reportInvalidEOF(String msg, JsonToken currToken) throws JsonParseException {
/* 662 */     throw new JsonEOFException(this, currToken, "Unexpected end-of-input" + msg);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected void _reportInvalidEOFInValue() throws JsonParseException {
/* 670 */     _reportInvalidEOF(" in a value");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected void _reportInvalidEOF(String msg) throws JsonParseException {
/* 678 */     throw new JsonEOFException(this, null, "Unexpected end-of-input" + msg);
/*     */   }
/*     */   
/*     */   protected void _reportMissingRootWS(int ch) throws JsonParseException {
/* 682 */     _reportUnexpectedChar(ch, "Expected space separating root-level values");
/*     */   }
/*     */   
/*     */   protected void _throwInvalidSpace(int i) throws JsonParseException {
/* 686 */     char c = (char)i;
/* 687 */     String msg = "Illegal character (" + _getCharDesc(c) + "): only regular white space (\\r, \\n, \\t) is allowed between tokens";
/* 688 */     _reportError(msg);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static final String _getCharDesc(int ch) {
/* 699 */     char c = (char)ch;
/* 700 */     if (Character.isISOControl(c)) {
/* 701 */       return "(CTRL-CHAR, code " + ch + ")";
/*     */     }
/* 703 */     if (ch > 255) {
/* 704 */       return "'" + c + "' (code " + ch + " / 0x" + Integer.toHexString(ch) + ")";
/*     */     }
/* 706 */     return "'" + c + "' (code " + ch + ")";
/*     */   }
/*     */   
/*     */   protected final void _reportError(String msg) throws JsonParseException {
/* 710 */     throw _constructError(msg);
/*     */   }
/*     */ 
/*     */   
/*     */   protected final void _reportError(String msg, Object arg) throws JsonParseException {
/* 715 */     throw _constructError(String.format(msg, new Object[] { arg }));
/*     */   }
/*     */ 
/*     */   
/*     */   protected final void _reportError(String msg, Object arg1, Object arg2) throws JsonParseException {
/* 720 */     throw _constructError(String.format(msg, new Object[] { arg1, arg2 }));
/*     */   }
/*     */   
/*     */   protected final void _wrapError(String msg, Throwable t) throws JsonParseException {
/* 724 */     throw _constructError(msg, t);
/*     */   }
/*     */   
/*     */   protected final void _throwInternal() {
/* 728 */     VersionUtil.throwInternal();
/*     */   }
/*     */   
/*     */   protected final JsonParseException _constructError(String msg, Throwable t) {
/* 732 */     return new JsonParseException(this, msg, t);
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   protected static byte[] _asciiBytes(String str) {
/* 737 */     byte[] b = new byte[str.length()];
/* 738 */     for (int i = 0, len = str.length(); i < len; i++) {
/* 739 */       b[i] = (byte)str.charAt(i);
/*     */     }
/* 741 */     return b;
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   protected static String _ascii(byte[] b) {
/*     */     try {
/* 747 */       return new String(b, "US-ASCII");
/* 748 */     } catch (IOException e) {
/* 749 */       throw new RuntimeException(e);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-core-2.12.7.jar!\com\fasterxml\jackson\core\base\ParserMinimalBase.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */