/*     */ package com.fasterxml.jackson.core.util;
/*     */ 
/*     */ import com.fasterxml.jackson.core.Base64Variant;
/*     */ import com.fasterxml.jackson.core.FormatSchema;
/*     */ import com.fasterxml.jackson.core.JsonGenerator;
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.JsonStreamContext;
/*     */ import com.fasterxml.jackson.core.ObjectCodec;
/*     */ import com.fasterxml.jackson.core.PrettyPrinter;
/*     */ import com.fasterxml.jackson.core.SerializableString;
/*     */ import com.fasterxml.jackson.core.StreamWriteCapability;
/*     */ import com.fasterxml.jackson.core.TreeNode;
/*     */ import com.fasterxml.jackson.core.Version;
/*     */ import com.fasterxml.jackson.core.io.CharacterEscapes;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JsonGeneratorDelegate
/*     */   extends JsonGenerator
/*     */ {
/*     */   protected JsonGenerator delegate;
/*     */   protected boolean delegateCopyMethods;
/*     */   
/*     */   public JsonGeneratorDelegate(JsonGenerator d) {
/*  33 */     this(d, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonGeneratorDelegate(JsonGenerator d, boolean delegateCopyMethods) {
/*  43 */     this.delegate = d;
/*  44 */     this.delegateCopyMethods = delegateCopyMethods;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getCurrentValue() {
/*  49 */     return this.delegate.getCurrentValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setCurrentValue(Object v) {
/*  54 */     this.delegate.setCurrentValue(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ObjectCodec getCodec() {
/*  63 */     return this.delegate.getCodec();
/*     */   }
/*     */   public JsonGenerator setCodec(ObjectCodec oc) {
/*  66 */     this.delegate.setCodec(oc);
/*  67 */     return this;
/*     */   }
/*     */   
/*  70 */   public void setSchema(FormatSchema schema) { this.delegate.setSchema(schema); }
/*  71 */   public FormatSchema getSchema() { return this.delegate.getSchema(); }
/*  72 */   public Version version() { return this.delegate.version(); }
/*  73 */   public Object getOutputTarget() { return this.delegate.getOutputTarget(); } public int getOutputBuffered() {
/*  74 */     return this.delegate.getOutputBuffered();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canUseSchema(FormatSchema schema) {
/*  83 */     return this.delegate.canUseSchema(schema);
/*     */   }
/*     */   public boolean canWriteTypeId() {
/*  86 */     return this.delegate.canWriteTypeId();
/*     */   }
/*     */   public boolean canWriteObjectId() {
/*  89 */     return this.delegate.canWriteObjectId();
/*     */   }
/*     */   public boolean canWriteBinaryNatively() {
/*  92 */     return this.delegate.canWriteBinaryNatively();
/*     */   }
/*     */   public boolean canOmitFields() {
/*  95 */     return this.delegate.canOmitFields();
/*     */   }
/*     */   public boolean canWriteFormattedNumbers() {
/*  98 */     return this.delegate.canWriteFormattedNumbers();
/*     */   }
/*     */   
/*     */   public JacksonFeatureSet<StreamWriteCapability> getWriteCapabilities() {
/* 102 */     return this.delegate.getWriteCapabilities();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonGenerator enable(JsonGenerator.Feature f) {
/* 113 */     this.delegate.enable(f);
/* 114 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public JsonGenerator disable(JsonGenerator.Feature f) {
/* 119 */     this.delegate.disable(f);
/* 120 */     return this;
/*     */   }
/*     */   
/*     */   public boolean isEnabled(JsonGenerator.Feature f) {
/* 124 */     return this.delegate.isEnabled(f);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getFeatureMask() {
/* 130 */     return this.delegate.getFeatureMask();
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public JsonGenerator setFeatureMask(int mask) {
/* 135 */     this.delegate.setFeatureMask(mask);
/* 136 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public JsonGenerator overrideStdFeatures(int values, int mask) {
/* 141 */     this.delegate.overrideStdFeatures(values, mask);
/* 142 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public JsonGenerator overrideFormatFeatures(int values, int mask) {
/* 147 */     this.delegate.overrideFormatFeatures(values, mask);
/* 148 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonGenerator setPrettyPrinter(PrettyPrinter pp) {
/* 159 */     this.delegate.setPrettyPrinter(pp);
/* 160 */     return this;
/*     */   }
/*     */   
/*     */   public PrettyPrinter getPrettyPrinter() {
/* 164 */     return this.delegate.getPrettyPrinter();
/*     */   }
/*     */   public JsonGenerator useDefaultPrettyPrinter() {
/* 167 */     this.delegate.useDefaultPrettyPrinter();
/* 168 */     return this;
/*     */   }
/*     */   public JsonGenerator setHighestNonEscapedChar(int charCode) {
/* 171 */     this.delegate.setHighestNonEscapedChar(charCode);
/* 172 */     return this;
/*     */   }
/*     */   public int getHighestEscapedChar() {
/* 175 */     return this.delegate.getHighestEscapedChar();
/*     */   }
/*     */   public CharacterEscapes getCharacterEscapes() {
/* 178 */     return this.delegate.getCharacterEscapes();
/*     */   }
/*     */   public JsonGenerator setCharacterEscapes(CharacterEscapes esc) {
/* 181 */     this.delegate.setCharacterEscapes(esc);
/* 182 */     return this;
/*     */   }
/*     */   public JsonGenerator setRootValueSeparator(SerializableString sep) {
/* 185 */     this.delegate.setRootValueSeparator(sep);
/* 186 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeStartArray() throws IOException {
/* 195 */     this.delegate.writeStartArray();
/*     */   }
/*     */   
/*     */   public void writeStartArray(int size) throws IOException {
/* 199 */     this.delegate.writeStartArray(size);
/*     */   }
/*     */   public void writeStartArray(Object forValue) throws IOException {
/* 202 */     this.delegate.writeStartArray(forValue);
/*     */   }
/*     */   public void writeStartArray(Object forValue, int size) throws IOException {
/* 205 */     this.delegate.writeStartArray(forValue, size);
/*     */   }
/*     */   public void writeEndArray() throws IOException {
/* 208 */     this.delegate.writeEndArray();
/*     */   }
/*     */   public void writeStartObject() throws IOException {
/* 211 */     this.delegate.writeStartObject();
/*     */   }
/*     */   public void writeStartObject(Object forValue) throws IOException {
/* 214 */     this.delegate.writeStartObject(forValue);
/*     */   }
/*     */   
/*     */   public void writeStartObject(Object forValue, int size) throws IOException {
/* 218 */     this.delegate.writeStartObject(forValue, size);
/*     */   }
/*     */   
/*     */   public void writeEndObject() throws IOException {
/* 222 */     this.delegate.writeEndObject();
/*     */   }
/*     */   
/*     */   public void writeFieldName(String name) throws IOException {
/* 226 */     this.delegate.writeFieldName(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeFieldName(SerializableString name) throws IOException {
/* 231 */     this.delegate.writeFieldName(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeFieldId(long id) throws IOException {
/* 236 */     this.delegate.writeFieldId(id);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeArray(int[] array, int offset, int length) throws IOException {
/* 241 */     this.delegate.writeArray(array, offset, length);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeArray(long[] array, int offset, int length) throws IOException {
/* 246 */     this.delegate.writeArray(array, offset, length);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeArray(double[] array, int offset, int length) throws IOException {
/* 251 */     this.delegate.writeArray(array, offset, length);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeArray(String[] array, int offset, int length) throws IOException {
/* 256 */     this.delegate.writeArray(array, offset, length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeString(String text) throws IOException {
/* 266 */     this.delegate.writeString(text);
/*     */   }
/*     */   
/*     */   public void writeString(Reader reader, int len) throws IOException {
/* 270 */     this.delegate.writeString(reader, len);
/*     */   }
/*     */   
/*     */   public void writeString(char[] text, int offset, int len) throws IOException {
/* 274 */     this.delegate.writeString(text, offset, len);
/*     */   }
/*     */   public void writeString(SerializableString text) throws IOException {
/* 277 */     this.delegate.writeString(text);
/*     */   }
/*     */   public void writeRawUTF8String(byte[] text, int offset, int length) throws IOException {
/* 280 */     this.delegate.writeRawUTF8String(text, offset, length);
/*     */   }
/*     */   public void writeUTF8String(byte[] text, int offset, int length) throws IOException {
/* 283 */     this.delegate.writeUTF8String(text, offset, length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeRaw(String text) throws IOException {
/* 292 */     this.delegate.writeRaw(text);
/*     */   }
/*     */   public void writeRaw(String text, int offset, int len) throws IOException {
/* 295 */     this.delegate.writeRaw(text, offset, len);
/*     */   }
/*     */   public void writeRaw(SerializableString raw) throws IOException {
/* 298 */     this.delegate.writeRaw(raw);
/*     */   }
/*     */   public void writeRaw(char[] text, int offset, int len) throws IOException {
/* 301 */     this.delegate.writeRaw(text, offset, len);
/*     */   }
/*     */   public void writeRaw(char c) throws IOException {
/* 304 */     this.delegate.writeRaw(c);
/*     */   }
/*     */   public void writeRawValue(String text) throws IOException {
/* 307 */     this.delegate.writeRawValue(text);
/*     */   }
/*     */   public void writeRawValue(String text, int offset, int len) throws IOException {
/* 310 */     this.delegate.writeRawValue(text, offset, len);
/*     */   }
/*     */   public void writeRawValue(char[] text, int offset, int len) throws IOException {
/* 313 */     this.delegate.writeRawValue(text, offset, len);
/*     */   }
/*     */   public void writeBinary(Base64Variant b64variant, byte[] data, int offset, int len) throws IOException {
/* 316 */     this.delegate.writeBinary(b64variant, data, offset, len);
/*     */   }
/*     */   public int writeBinary(Base64Variant b64variant, InputStream data, int dataLength) throws IOException {
/* 319 */     return this.delegate.writeBinary(b64variant, data, dataLength);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeNumber(short v) throws IOException {
/* 328 */     this.delegate.writeNumber(v);
/*     */   }
/*     */   public void writeNumber(int v) throws IOException {
/* 331 */     this.delegate.writeNumber(v);
/*     */   }
/*     */   public void writeNumber(long v) throws IOException {
/* 334 */     this.delegate.writeNumber(v);
/*     */   }
/*     */   public void writeNumber(BigInteger v) throws IOException {
/* 337 */     this.delegate.writeNumber(v);
/*     */   }
/*     */   public void writeNumber(double v) throws IOException {
/* 340 */     this.delegate.writeNumber(v);
/*     */   }
/*     */   public void writeNumber(float v) throws IOException {
/* 343 */     this.delegate.writeNumber(v);
/*     */   }
/*     */   public void writeNumber(BigDecimal v) throws IOException {
/* 346 */     this.delegate.writeNumber(v);
/*     */   }
/*     */   public void writeNumber(String encodedValue) throws IOException, UnsupportedOperationException {
/* 349 */     this.delegate.writeNumber(encodedValue);
/*     */   }
/*     */   public void writeNumber(char[] encodedValueBuffer, int offset, int length) throws IOException, UnsupportedOperationException {
/* 352 */     this.delegate.writeNumber(encodedValueBuffer, offset, length);
/*     */   }
/*     */   public void writeBoolean(boolean state) throws IOException {
/* 355 */     this.delegate.writeBoolean(state);
/*     */   }
/*     */   public void writeNull() throws IOException {
/* 358 */     this.delegate.writeNull();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeOmittedField(String fieldName) throws IOException {
/* 383 */     this.delegate.writeOmittedField(fieldName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeObjectId(Object id) throws IOException {
/* 393 */     this.delegate.writeObjectId(id);
/*     */   }
/*     */   public void writeObjectRef(Object id) throws IOException {
/* 396 */     this.delegate.writeObjectRef(id);
/*     */   }
/*     */   public void writeTypeId(Object id) throws IOException {
/* 399 */     this.delegate.writeTypeId(id);
/*     */   }
/*     */   public void writeEmbeddedObject(Object object) throws IOException {
/* 402 */     this.delegate.writeEmbeddedObject(object);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeObject(Object pojo) throws IOException {
/* 412 */     if (this.delegateCopyMethods) {
/* 413 */       this.delegate.writeObject(pojo);
/*     */       return;
/*     */     } 
/* 416 */     if (pojo == null) {
/* 417 */       writeNull();
/*     */     } else {
/* 419 */       ObjectCodec c = getCodec();
/* 420 */       if (c != null) {
/* 421 */         c.writeValue(this, pojo);
/*     */         return;
/*     */       } 
/* 424 */       _writeSimpleObject(pojo);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeTree(TreeNode tree) throws IOException {
/* 430 */     if (this.delegateCopyMethods) {
/* 431 */       this.delegate.writeTree(tree);
/*     */       
/*     */       return;
/*     */     } 
/* 435 */     if (tree == null) {
/* 436 */       writeNull();
/*     */     } else {
/* 438 */       ObjectCodec c = getCodec();
/* 439 */       if (c == null) {
/* 440 */         throw new IllegalStateException("No ObjectCodec defined");
/*     */       }
/* 442 */       c.writeTree(this, tree);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void copyCurrentEvent(JsonParser p) throws IOException {
/* 462 */     if (this.delegateCopyMethods) { this.delegate.copyCurrentEvent(p); }
/* 463 */     else { super.copyCurrentEvent(p); }
/*     */   
/*     */   }
/*     */   
/*     */   public void copyCurrentStructure(JsonParser p) throws IOException {
/* 468 */     if (this.delegateCopyMethods) { this.delegate.copyCurrentStructure(p); }
/* 469 */     else { super.copyCurrentStructure(p); }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonStreamContext getOutputContext() {
/* 478 */     return this.delegate.getOutputContext();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void flush() throws IOException {
/* 486 */     this.delegate.flush(); } public void close() throws IOException {
/* 487 */     this.delegate.close();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isClosed() {
/* 495 */     return this.delegate.isClosed();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public JsonGenerator getDelegate() {
/* 504 */     return this.delegate;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonGenerator delegate() {
/* 511 */     return this.delegate;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-core-2.12.7.jar!\com\fasterxml\jackson\cor\\util\JsonGeneratorDelegate.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */