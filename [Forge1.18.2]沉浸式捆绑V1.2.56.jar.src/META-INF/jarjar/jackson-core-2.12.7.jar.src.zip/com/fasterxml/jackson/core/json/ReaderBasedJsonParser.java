/*      */ package com.fasterxml.jackson.core.json;
/*      */ import com.fasterxml.jackson.core.Base64Variant;
/*      */ import com.fasterxml.jackson.core.JsonLocation;
/*      */ import com.fasterxml.jackson.core.JsonParseException;
/*      */ import com.fasterxml.jackson.core.JsonParser;
/*      */ import com.fasterxml.jackson.core.JsonToken;
/*      */ import com.fasterxml.jackson.core.ObjectCodec;
/*      */ import com.fasterxml.jackson.core.SerializableString;
/*      */ import com.fasterxml.jackson.core.StreamReadCapability;
/*      */ import com.fasterxml.jackson.core.base.ParserBase;
/*      */ import com.fasterxml.jackson.core.io.CharTypes;
/*      */ import com.fasterxml.jackson.core.io.IOContext;
/*      */ import com.fasterxml.jackson.core.sym.CharsToNameCanonicalizer;
/*      */ import com.fasterxml.jackson.core.util.ByteArrayBuilder;
/*      */ import com.fasterxml.jackson.core.util.JacksonFeatureSet;
/*      */ import com.fasterxml.jackson.core.util.TextBuffer;
/*      */ import java.io.IOException;
/*      */ import java.io.OutputStream;
/*      */ import java.io.Reader;
/*      */ import java.io.Writer;
/*      */ 
/*      */ public class ReaderBasedJsonParser extends ParserBase {
/*   23 */   private static final int FEAT_MASK_TRAILING_COMMA = JsonParser.Feature.ALLOW_TRAILING_COMMA.getMask();
/*      */ 
/*      */   
/*   26 */   private static final int FEAT_MASK_LEADING_ZEROS = JsonParser.Feature.ALLOW_NUMERIC_LEADING_ZEROS.getMask();
/*      */ 
/*      */   
/*   29 */   private static final int FEAT_MASK_NON_NUM_NUMBERS = JsonParser.Feature.ALLOW_NON_NUMERIC_NUMBERS.getMask();
/*      */ 
/*      */   
/*   32 */   private static final int FEAT_MASK_ALLOW_MISSING = JsonParser.Feature.ALLOW_MISSING_VALUES.getMask();
/*   33 */   private static final int FEAT_MASK_ALLOW_SINGLE_QUOTES = JsonParser.Feature.ALLOW_SINGLE_QUOTES.getMask();
/*   34 */   private static final int FEAT_MASK_ALLOW_UNQUOTED_NAMES = JsonParser.Feature.ALLOW_UNQUOTED_FIELD_NAMES.getMask();
/*      */   
/*   36 */   private static final int FEAT_MASK_ALLOW_JAVA_COMMENTS = JsonParser.Feature.ALLOW_COMMENTS.getMask();
/*   37 */   private static final int FEAT_MASK_ALLOW_YAML_COMMENTS = JsonParser.Feature.ALLOW_YAML_COMMENTS.getMask();
/*      */ 
/*      */ 
/*      */   
/*   41 */   protected static final int[] _icLatin1 = CharTypes.getInputCodeLatin1();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Reader _reader;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected char[] _inputBuffer;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean _bufferRecyclable;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ObjectCodec _objectCodec;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final CharsToNameCanonicalizer _symbols;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final int _hashSeed;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean _tokenIncomplete;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected long _nameStartOffset;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int _nameStartRow;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int _nameStartCol;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ReaderBasedJsonParser(IOContext ctxt, int features, Reader r, ObjectCodec codec, CharsToNameCanonicalizer st, char[] inputBuffer, int start, int end, boolean bufferRecyclable) {
/*  133 */     super(ctxt, features);
/*  134 */     this._reader = r;
/*  135 */     this._inputBuffer = inputBuffer;
/*  136 */     this._inputPtr = start;
/*  137 */     this._inputEnd = end;
/*  138 */     this._objectCodec = codec;
/*  139 */     this._symbols = st;
/*  140 */     this._hashSeed = st.hashSeed();
/*  141 */     this._bufferRecyclable = bufferRecyclable;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ReaderBasedJsonParser(IOContext ctxt, int features, Reader r, ObjectCodec codec, CharsToNameCanonicalizer st) {
/*  151 */     super(ctxt, features);
/*  152 */     this._reader = r;
/*  153 */     this._inputBuffer = ctxt.allocTokenBuffer();
/*  154 */     this._inputPtr = 0;
/*  155 */     this._inputEnd = 0;
/*  156 */     this._objectCodec = codec;
/*  157 */     this._symbols = st;
/*  158 */     this._hashSeed = st.hashSeed();
/*  159 */     this._bufferRecyclable = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectCodec getCodec() {
/*  168 */     return this._objectCodec; } public void setCodec(ObjectCodec c) {
/*  169 */     this._objectCodec = c;
/*      */   }
/*      */   
/*      */   public JacksonFeatureSet<StreamReadCapability> getReadCapabilities() {
/*  173 */     return JSON_READ_CAPABILITIES;
/*      */   }
/*      */ 
/*      */   
/*      */   public int releaseBuffered(Writer w) throws IOException {
/*  178 */     int count = this._inputEnd - this._inputPtr;
/*  179 */     if (count < 1) return 0;
/*      */     
/*  181 */     int origPtr = this._inputPtr;
/*  182 */     this._inputPtr += count;
/*  183 */     w.write(this._inputBuffer, origPtr, count);
/*  184 */     return count;
/*      */   }
/*      */   public Object getInputSource() {
/*  187 */     return this._reader;
/*      */   }
/*      */   @Deprecated
/*      */   protected char getNextChar(String eofMsg) throws IOException {
/*  191 */     return getNextChar(eofMsg, (JsonToken)null);
/*      */   }
/*      */   
/*      */   protected char getNextChar(String eofMsg, JsonToken forToken) throws IOException {
/*  195 */     if (this._inputPtr >= this._inputEnd && 
/*  196 */       !_loadMore()) {
/*  197 */       _reportInvalidEOF(eofMsg, forToken);
/*      */     }
/*      */     
/*  200 */     return this._inputBuffer[this._inputPtr++];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _closeInput() throws IOException {
/*  212 */     if (this._reader != null) {
/*  213 */       if (this._ioContext.isResourceManaged() || isEnabled(JsonParser.Feature.AUTO_CLOSE_SOURCE)) {
/*  214 */         this._reader.close();
/*      */       }
/*  216 */       this._reader = null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _releaseBuffers() throws IOException {
/*  229 */     super._releaseBuffers();
/*      */     
/*  231 */     this._symbols.release();
/*      */     
/*  233 */     if (this._bufferRecyclable) {
/*  234 */       char[] buf = this._inputBuffer;
/*  235 */       if (buf != null) {
/*  236 */         this._inputBuffer = null;
/*  237 */         this._ioContext.releaseTokenBuffer(buf);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _loadMoreGuaranteed() throws IOException {
/*  249 */     if (!_loadMore()) _reportInvalidEOF();
/*      */   
/*      */   }
/*      */   
/*      */   protected boolean _loadMore() throws IOException {
/*  254 */     if (this._reader != null) {
/*  255 */       int count = this._reader.read(this._inputBuffer, 0, this._inputBuffer.length);
/*  256 */       if (count > 0) {
/*  257 */         int bufSize = this._inputEnd;
/*  258 */         this._currInputProcessed += bufSize;
/*  259 */         this._currInputRowStart -= bufSize;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  264 */         this._nameStartOffset -= bufSize;
/*      */         
/*  266 */         this._inputPtr = 0;
/*  267 */         this._inputEnd = count;
/*      */         
/*  269 */         return true;
/*      */       } 
/*      */       
/*  272 */       _closeInput();
/*      */       
/*  274 */       if (count == 0) {
/*  275 */         throw new IOException("Reader returned 0 characters when trying to read " + this._inputEnd);
/*      */       }
/*      */     } 
/*  278 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final String getText() throws IOException {
/*  296 */     if (this._currToken == JsonToken.VALUE_STRING) {
/*  297 */       if (this._tokenIncomplete) {
/*  298 */         this._tokenIncomplete = false;
/*  299 */         _finishString();
/*      */       } 
/*  301 */       return this._textBuffer.contentsAsString();
/*      */     } 
/*  303 */     return _getText2(this._currToken);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getText(Writer writer) throws IOException {
/*  309 */     JsonToken t = this._currToken;
/*  310 */     if (t == JsonToken.VALUE_STRING) {
/*  311 */       if (this._tokenIncomplete) {
/*  312 */         this._tokenIncomplete = false;
/*  313 */         _finishString();
/*      */       } 
/*  315 */       return this._textBuffer.contentsToWriter(writer);
/*      */     } 
/*  317 */     if (t == JsonToken.FIELD_NAME) {
/*  318 */       String n = this._parsingContext.getCurrentName();
/*  319 */       writer.write(n);
/*  320 */       return n.length();
/*      */     } 
/*  322 */     if (t != null) {
/*  323 */       if (t.isNumeric()) {
/*  324 */         return this._textBuffer.contentsToWriter(writer);
/*      */       }
/*  326 */       char[] ch = t.asCharArray();
/*  327 */       writer.write(ch);
/*  328 */       return ch.length;
/*      */     } 
/*  330 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final String getValueAsString() throws IOException {
/*  339 */     if (this._currToken == JsonToken.VALUE_STRING) {
/*  340 */       if (this._tokenIncomplete) {
/*  341 */         this._tokenIncomplete = false;
/*  342 */         _finishString();
/*      */       } 
/*  344 */       return this._textBuffer.contentsAsString();
/*      */     } 
/*  346 */     if (this._currToken == JsonToken.FIELD_NAME) {
/*  347 */       return getCurrentName();
/*      */     }
/*  349 */     return super.getValueAsString(null);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final String getValueAsString(String defValue) throws IOException {
/*  355 */     if (this._currToken == JsonToken.VALUE_STRING) {
/*  356 */       if (this._tokenIncomplete) {
/*  357 */         this._tokenIncomplete = false;
/*  358 */         _finishString();
/*      */       } 
/*  360 */       return this._textBuffer.contentsAsString();
/*      */     } 
/*  362 */     if (this._currToken == JsonToken.FIELD_NAME) {
/*  363 */       return getCurrentName();
/*      */     }
/*  365 */     return super.getValueAsString(defValue);
/*      */   }
/*      */   
/*      */   protected final String _getText2(JsonToken t) {
/*  369 */     if (t == null) {
/*  370 */       return null;
/*      */     }
/*  372 */     switch (t.id()) {
/*      */       case 5:
/*  374 */         return this._parsingContext.getCurrentName();
/*      */ 
/*      */       
/*      */       case 6:
/*      */       case 7:
/*      */       case 8:
/*  380 */         return this._textBuffer.contentsAsString();
/*      */     } 
/*  382 */     return t.asString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final char[] getTextCharacters() throws IOException {
/*  389 */     if (this._currToken != null) {
/*  390 */       switch (this._currToken.id()) {
/*      */         case 5:
/*  392 */           if (!this._nameCopied) {
/*  393 */             String name = this._parsingContext.getCurrentName();
/*  394 */             int nameLen = name.length();
/*  395 */             if (this._nameCopyBuffer == null) {
/*  396 */               this._nameCopyBuffer = this._ioContext.allocNameCopyBuffer(nameLen);
/*  397 */             } else if (this._nameCopyBuffer.length < nameLen) {
/*  398 */               this._nameCopyBuffer = new char[nameLen];
/*      */             } 
/*  400 */             name.getChars(0, nameLen, this._nameCopyBuffer, 0);
/*  401 */             this._nameCopied = true;
/*      */           } 
/*  403 */           return this._nameCopyBuffer;
/*      */         case 6:
/*  405 */           if (this._tokenIncomplete) {
/*  406 */             this._tokenIncomplete = false;
/*  407 */             _finishString();
/*      */           } 
/*      */         
/*      */         case 7:
/*      */         case 8:
/*  412 */           return this._textBuffer.getTextBuffer();
/*      */       } 
/*  414 */       return this._currToken.asCharArray();
/*      */     } 
/*      */     
/*  417 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final int getTextLength() throws IOException {
/*  423 */     if (this._currToken != null) {
/*  424 */       switch (this._currToken.id()) {
/*      */         case 5:
/*  426 */           return this._parsingContext.getCurrentName().length();
/*      */         case 6:
/*  428 */           if (this._tokenIncomplete) {
/*  429 */             this._tokenIncomplete = false;
/*  430 */             _finishString();
/*      */           } 
/*      */         
/*      */         case 7:
/*      */         case 8:
/*  435 */           return this._textBuffer.size();
/*      */       } 
/*  437 */       return (this._currToken.asCharArray()).length;
/*      */     } 
/*      */     
/*  440 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int getTextOffset() throws IOException {
/*  447 */     if (this._currToken != null) {
/*  448 */       switch (this._currToken.id()) {
/*      */         case 5:
/*  450 */           return 0;
/*      */         case 6:
/*  452 */           if (this._tokenIncomplete) {
/*  453 */             this._tokenIncomplete = false;
/*  454 */             _finishString();
/*      */           } 
/*      */         
/*      */         case 7:
/*      */         case 8:
/*  459 */           return this._textBuffer.getTextOffset();
/*      */       } 
/*      */     
/*      */     }
/*  463 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] getBinaryValue(Base64Variant b64variant) throws IOException {
/*  469 */     if (this._currToken == JsonToken.VALUE_EMBEDDED_OBJECT && this._binaryValue != null) {
/*  470 */       return this._binaryValue;
/*      */     }
/*  472 */     if (this._currToken != JsonToken.VALUE_STRING) {
/*  473 */       _reportError("Current token (" + this._currToken + ") not VALUE_STRING or VALUE_EMBEDDED_OBJECT, can not access as binary");
/*      */     }
/*      */     
/*  476 */     if (this._tokenIncomplete) {
/*      */       try {
/*  478 */         this._binaryValue = _decodeBase64(b64variant);
/*  479 */       } catch (IllegalArgumentException iae) {
/*  480 */         throw _constructError("Failed to decode VALUE_STRING as base64 (" + b64variant + "): " + iae.getMessage());
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  485 */       this._tokenIncomplete = false;
/*      */     }
/*  487 */     else if (this._binaryValue == null) {
/*      */       
/*  489 */       ByteArrayBuilder builder = _getByteArrayBuilder();
/*  490 */       _decodeBase64(getText(), builder, b64variant);
/*  491 */       this._binaryValue = builder.toByteArray();
/*      */     } 
/*      */     
/*  494 */     return this._binaryValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int readBinaryValue(Base64Variant b64variant, OutputStream out) throws IOException {
/*  501 */     if (!this._tokenIncomplete || this._currToken != JsonToken.VALUE_STRING) {
/*  502 */       byte[] b = getBinaryValue(b64variant);
/*  503 */       out.write(b);
/*  504 */       return b.length;
/*      */     } 
/*      */     
/*  507 */     byte[] buf = this._ioContext.allocBase64Buffer();
/*      */     try {
/*  509 */       return _readBinary(b64variant, out, buf);
/*      */     } finally {
/*  511 */       this._ioContext.releaseBase64Buffer(buf);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected int _readBinary(Base64Variant b64variant, OutputStream out, byte[] buffer) throws IOException {
/*  517 */     int outputPtr = 0;
/*  518 */     int outputEnd = buffer.length - 3;
/*  519 */     int outputCount = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     while (true) {
/*  525 */       if (this._inputPtr >= this._inputEnd) {
/*  526 */         _loadMoreGuaranteed();
/*      */       }
/*  528 */       char ch = this._inputBuffer[this._inputPtr++];
/*  529 */       if (ch > ' ') {
/*  530 */         int bits = b64variant.decodeBase64Char(ch);
/*  531 */         if (bits < 0) {
/*  532 */           if (ch == '"') {
/*      */             break;
/*      */           }
/*  535 */           bits = _decodeBase64Escape(b64variant, ch, 0);
/*  536 */           if (bits < 0) {
/*      */             continue;
/*      */           }
/*      */         } 
/*      */ 
/*      */         
/*  542 */         if (outputPtr > outputEnd) {
/*  543 */           outputCount += outputPtr;
/*  544 */           out.write(buffer, 0, outputPtr);
/*  545 */           outputPtr = 0;
/*      */         } 
/*      */         
/*  548 */         int decodedData = bits;
/*      */ 
/*      */ 
/*      */         
/*  552 */         if (this._inputPtr >= this._inputEnd) {
/*  553 */           _loadMoreGuaranteed();
/*      */         }
/*  555 */         ch = this._inputBuffer[this._inputPtr++];
/*  556 */         bits = b64variant.decodeBase64Char(ch);
/*  557 */         if (bits < 0) {
/*  558 */           bits = _decodeBase64Escape(b64variant, ch, 1);
/*      */         }
/*  560 */         decodedData = decodedData << 6 | bits;
/*      */ 
/*      */         
/*  563 */         if (this._inputPtr >= this._inputEnd) {
/*  564 */           _loadMoreGuaranteed();
/*      */         }
/*  566 */         ch = this._inputBuffer[this._inputPtr++];
/*  567 */         bits = b64variant.decodeBase64Char(ch);
/*      */ 
/*      */         
/*  570 */         if (bits < 0) {
/*  571 */           if (bits != -2) {
/*      */             
/*  573 */             if (ch == '"') {
/*  574 */               decodedData >>= 4;
/*  575 */               buffer[outputPtr++] = (byte)decodedData;
/*  576 */               if (b64variant.usesPadding()) {
/*  577 */                 this._inputPtr--;
/*  578 */                 _handleBase64MissingPadding(b64variant);
/*      */               } 
/*      */               break;
/*      */             } 
/*  582 */             bits = _decodeBase64Escape(b64variant, ch, 2);
/*      */           } 
/*  584 */           if (bits == -2) {
/*      */             
/*  586 */             if (this._inputPtr >= this._inputEnd) {
/*  587 */               _loadMoreGuaranteed();
/*      */             }
/*  589 */             ch = this._inputBuffer[this._inputPtr++];
/*  590 */             if (!b64variant.usesPaddingChar(ch) && 
/*  591 */               _decodeBase64Escape(b64variant, ch, 3) != -2) {
/*  592 */               throw reportInvalidBase64Char(b64variant, ch, 3, "expected padding character '" + b64variant.getPaddingChar() + "'");
/*      */             }
/*      */ 
/*      */             
/*  596 */             decodedData >>= 4;
/*  597 */             buffer[outputPtr++] = (byte)decodedData;
/*      */             
/*      */             continue;
/*      */           } 
/*      */         } 
/*  602 */         decodedData = decodedData << 6 | bits;
/*      */         
/*  604 */         if (this._inputPtr >= this._inputEnd) {
/*  605 */           _loadMoreGuaranteed();
/*      */         }
/*  607 */         ch = this._inputBuffer[this._inputPtr++];
/*  608 */         bits = b64variant.decodeBase64Char(ch);
/*  609 */         if (bits < 0) {
/*  610 */           if (bits != -2) {
/*      */             
/*  612 */             if (ch == '"') {
/*  613 */               decodedData >>= 2;
/*  614 */               buffer[outputPtr++] = (byte)(decodedData >> 8);
/*  615 */               buffer[outputPtr++] = (byte)decodedData;
/*  616 */               if (b64variant.usesPadding()) {
/*  617 */                 this._inputPtr--;
/*  618 */                 _handleBase64MissingPadding(b64variant);
/*      */               } 
/*      */               break;
/*      */             } 
/*  622 */             bits = _decodeBase64Escape(b64variant, ch, 3);
/*      */           } 
/*  624 */           if (bits == -2) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  631 */             decodedData >>= 2;
/*  632 */             buffer[outputPtr++] = (byte)(decodedData >> 8);
/*  633 */             buffer[outputPtr++] = (byte)decodedData;
/*      */             
/*      */             continue;
/*      */           } 
/*      */         } 
/*  638 */         decodedData = decodedData << 6 | bits;
/*  639 */         buffer[outputPtr++] = (byte)(decodedData >> 16);
/*  640 */         buffer[outputPtr++] = (byte)(decodedData >> 8);
/*  641 */         buffer[outputPtr++] = (byte)decodedData;
/*      */       } 
/*  643 */     }  this._tokenIncomplete = false;
/*  644 */     if (outputPtr > 0) {
/*  645 */       outputCount += outputPtr;
/*  646 */       out.write(buffer, 0, outputPtr);
/*      */     } 
/*  648 */     return outputCount;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final JsonToken nextToken() throws IOException {
/*      */     JsonToken t;
/*  668 */     if (this._currToken == JsonToken.FIELD_NAME) {
/*  669 */       return _nextAfterName();
/*      */     }
/*      */ 
/*      */     
/*  673 */     this._numTypesValid = 0;
/*  674 */     if (this._tokenIncomplete) {
/*  675 */       _skipString();
/*      */     }
/*  677 */     int i = _skipWSOrEnd();
/*  678 */     if (i < 0) {
/*      */ 
/*      */       
/*  681 */       close();
/*  682 */       return this._currToken = null;
/*      */     } 
/*      */     
/*  685 */     this._binaryValue = null;
/*      */ 
/*      */     
/*  688 */     if (i == 93 || i == 125) {
/*  689 */       _closeScope(i);
/*  690 */       return this._currToken;
/*      */     } 
/*      */ 
/*      */     
/*  694 */     if (this._parsingContext.expectComma()) {
/*  695 */       i = _skipComma(i);
/*      */ 
/*      */       
/*  698 */       if ((this._features & FEAT_MASK_TRAILING_COMMA) != 0 && (
/*  699 */         i == 93 || i == 125)) {
/*  700 */         _closeScope(i);
/*  701 */         return this._currToken;
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  709 */     boolean inObject = this._parsingContext.inObject();
/*  710 */     if (inObject) {
/*      */       
/*  712 */       _updateNameLocation();
/*  713 */       String name = (i == 34) ? _parseName() : _handleOddName(i);
/*  714 */       this._parsingContext.setCurrentName(name);
/*  715 */       this._currToken = JsonToken.FIELD_NAME;
/*  716 */       i = _skipColon();
/*      */     } 
/*  718 */     _updateLocation();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  724 */     switch (i) {
/*      */       case 34:
/*  726 */         this._tokenIncomplete = true;
/*  727 */         t = JsonToken.VALUE_STRING;
/*      */         break;
/*      */       case 91:
/*  730 */         if (!inObject) {
/*  731 */           this._parsingContext = this._parsingContext.createChildArrayContext(this._tokenInputRow, this._tokenInputCol);
/*      */         }
/*  733 */         t = JsonToken.START_ARRAY;
/*      */         break;
/*      */       case 123:
/*  736 */         if (!inObject) {
/*  737 */           this._parsingContext = this._parsingContext.createChildObjectContext(this._tokenInputRow, this._tokenInputCol);
/*      */         }
/*  739 */         t = JsonToken.START_OBJECT;
/*      */         break;
/*      */ 
/*      */       
/*      */       case 125:
/*  744 */         _reportUnexpectedChar(i, "expected a value");
/*      */       case 116:
/*  746 */         _matchTrue();
/*  747 */         t = JsonToken.VALUE_TRUE;
/*      */         break;
/*      */       case 102:
/*  750 */         _matchFalse();
/*  751 */         t = JsonToken.VALUE_FALSE;
/*      */         break;
/*      */       case 110:
/*  754 */         _matchNull();
/*  755 */         t = JsonToken.VALUE_NULL;
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 45:
/*  763 */         t = _parseNegNumber();
/*      */         break;
/*      */       case 46:
/*  766 */         t = _parseFloatThatStartsWithPeriod();
/*      */         break;
/*      */       case 48:
/*      */       case 49:
/*      */       case 50:
/*      */       case 51:
/*      */       case 52:
/*      */       case 53:
/*      */       case 54:
/*      */       case 55:
/*      */       case 56:
/*      */       case 57:
/*  778 */         t = _parsePosNumber(i);
/*      */         break;
/*      */       default:
/*  781 */         t = _handleOddValue(i);
/*      */         break;
/*      */     } 
/*      */     
/*  785 */     if (inObject) {
/*  786 */       this._nextToken = t;
/*  787 */       return this._currToken;
/*      */     } 
/*  789 */     this._currToken = t;
/*  790 */     return t;
/*      */   }
/*      */ 
/*      */   
/*      */   private final JsonToken _nextAfterName() {
/*  795 */     this._nameCopied = false;
/*  796 */     JsonToken t = this._nextToken;
/*  797 */     this._nextToken = null;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  802 */     if (t == JsonToken.START_ARRAY) {
/*  803 */       this._parsingContext = this._parsingContext.createChildArrayContext(this._tokenInputRow, this._tokenInputCol);
/*  804 */     } else if (t == JsonToken.START_OBJECT) {
/*  805 */       this._parsingContext = this._parsingContext.createChildObjectContext(this._tokenInputRow, this._tokenInputCol);
/*      */     } 
/*  807 */     return this._currToken = t;
/*      */   }
/*      */ 
/*      */   
/*      */   public void finishToken() throws IOException {
/*  812 */     if (this._tokenIncomplete) {
/*  813 */       this._tokenIncomplete = false;
/*  814 */       _finishString();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean nextFieldName(SerializableString sstr) throws IOException {
/*  830 */     this._numTypesValid = 0;
/*  831 */     if (this._currToken == JsonToken.FIELD_NAME) {
/*  832 */       _nextAfterName();
/*  833 */       return false;
/*      */     } 
/*  835 */     if (this._tokenIncomplete) {
/*  836 */       _skipString();
/*      */     }
/*  838 */     int i = _skipWSOrEnd();
/*  839 */     if (i < 0) {
/*  840 */       close();
/*  841 */       this._currToken = null;
/*  842 */       return false;
/*      */     } 
/*  844 */     this._binaryValue = null;
/*      */ 
/*      */     
/*  847 */     if (i == 93 || i == 125) {
/*  848 */       _closeScope(i);
/*  849 */       return false;
/*      */     } 
/*      */     
/*  852 */     if (this._parsingContext.expectComma()) {
/*  853 */       i = _skipComma(i);
/*      */ 
/*      */       
/*  856 */       if ((this._features & FEAT_MASK_TRAILING_COMMA) != 0 && (
/*  857 */         i == 93 || i == 125)) {
/*  858 */         _closeScope(i);
/*  859 */         return false;
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  864 */     if (!this._parsingContext.inObject()) {
/*  865 */       _updateLocation();
/*  866 */       _nextTokenNotInObject(i);
/*  867 */       return false;
/*      */     } 
/*      */     
/*  870 */     _updateNameLocation();
/*  871 */     if (i == 34) {
/*      */       
/*  873 */       char[] nameChars = sstr.asQuotedChars();
/*  874 */       int len = nameChars.length;
/*      */ 
/*      */       
/*  877 */       if (this._inputPtr + len + 4 < this._inputEnd) {
/*      */         
/*  879 */         int end = this._inputPtr + len;
/*  880 */         if (this._inputBuffer[end] == '"') {
/*  881 */           int offset = 0;
/*  882 */           int ptr = this._inputPtr;
/*      */           while (true) {
/*  884 */             if (ptr == end) {
/*  885 */               this._parsingContext.setCurrentName(sstr.getValue());
/*  886 */               _isNextTokenNameYes(_skipColonFast(ptr + 1));
/*  887 */               return true;
/*      */             } 
/*  889 */             if (nameChars[offset] != this._inputBuffer[ptr]) {
/*      */               break;
/*      */             }
/*  892 */             offset++;
/*  893 */             ptr++;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*  898 */     return _isNextTokenNameMaybe(i, sstr.getValue());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String nextFieldName() throws IOException {
/*  906 */     this._numTypesValid = 0;
/*  907 */     if (this._currToken == JsonToken.FIELD_NAME) {
/*  908 */       _nextAfterName();
/*  909 */       return null;
/*      */     } 
/*  911 */     if (this._tokenIncomplete) {
/*  912 */       _skipString();
/*      */     }
/*  914 */     int i = _skipWSOrEnd();
/*  915 */     if (i < 0) {
/*  916 */       close();
/*  917 */       this._currToken = null;
/*  918 */       return null;
/*      */     } 
/*  920 */     this._binaryValue = null;
/*  921 */     if (i == 93 || i == 125) {
/*  922 */       _closeScope(i);
/*  923 */       return null;
/*      */     } 
/*  925 */     if (this._parsingContext.expectComma()) {
/*  926 */       i = _skipComma(i);
/*  927 */       if ((this._features & FEAT_MASK_TRAILING_COMMA) != 0 && (
/*  928 */         i == 93 || i == 125)) {
/*  929 */         _closeScope(i);
/*  930 */         return null;
/*      */       } 
/*      */     } 
/*      */     
/*  934 */     if (!this._parsingContext.inObject()) {
/*  935 */       _updateLocation();
/*  936 */       _nextTokenNotInObject(i);
/*  937 */       return null;
/*      */     } 
/*      */     
/*  940 */     _updateNameLocation();
/*  941 */     String name = (i == 34) ? _parseName() : _handleOddName(i);
/*  942 */     this._parsingContext.setCurrentName(name);
/*  943 */     this._currToken = JsonToken.FIELD_NAME;
/*  944 */     i = _skipColon();
/*      */     
/*  946 */     _updateLocation();
/*  947 */     if (i == 34) {
/*  948 */       this._tokenIncomplete = true;
/*  949 */       this._nextToken = JsonToken.VALUE_STRING;
/*  950 */       return name;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  957 */     switch (i)
/*      */     { case 45:
/*  959 */         t = _parseNegNumber();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  998 */         this._nextToken = t;
/*  999 */         return name;case 46: t = _parseFloatThatStartsWithPeriod(); this._nextToken = t; return name;case 48: case 49: case 50: case 51: case 52: case 53: case 54: case 55: case 56: case 57: t = _parsePosNumber(i); this._nextToken = t; return name;case 102: _matchFalse(); t = JsonToken.VALUE_FALSE; this._nextToken = t; return name;case 110: _matchNull(); t = JsonToken.VALUE_NULL; this._nextToken = t; return name;case 116: _matchTrue(); t = JsonToken.VALUE_TRUE; this._nextToken = t; return name;case 91: t = JsonToken.START_ARRAY; this._nextToken = t; return name;case 123: t = JsonToken.START_OBJECT; this._nextToken = t; return name; }  JsonToken t = _handleOddValue(i); this._nextToken = t; return name;
/*      */   }
/*      */ 
/*      */   
/*      */   private final void _isNextTokenNameYes(int i) throws IOException {
/* 1004 */     this._currToken = JsonToken.FIELD_NAME;
/* 1005 */     _updateLocation();
/*      */     
/* 1007 */     switch (i) {
/*      */       case 34:
/* 1009 */         this._tokenIncomplete = true;
/* 1010 */         this._nextToken = JsonToken.VALUE_STRING;
/*      */         return;
/*      */       case 91:
/* 1013 */         this._nextToken = JsonToken.START_ARRAY;
/*      */         return;
/*      */       case 123:
/* 1016 */         this._nextToken = JsonToken.START_OBJECT;
/*      */         return;
/*      */       case 116:
/* 1019 */         _matchToken("true", 1);
/* 1020 */         this._nextToken = JsonToken.VALUE_TRUE;
/*      */         return;
/*      */       case 102:
/* 1023 */         _matchToken("false", 1);
/* 1024 */         this._nextToken = JsonToken.VALUE_FALSE;
/*      */         return;
/*      */       case 110:
/* 1027 */         _matchToken("null", 1);
/* 1028 */         this._nextToken = JsonToken.VALUE_NULL;
/*      */         return;
/*      */       case 45:
/* 1031 */         this._nextToken = _parseNegNumber();
/*      */         return;
/*      */       case 46:
/* 1034 */         this._nextToken = _parseFloatThatStartsWithPeriod();
/*      */         return;
/*      */       case 48:
/*      */       case 49:
/*      */       case 50:
/*      */       case 51:
/*      */       case 52:
/*      */       case 53:
/*      */       case 54:
/*      */       case 55:
/*      */       case 56:
/*      */       case 57:
/* 1046 */         this._nextToken = _parsePosNumber(i);
/*      */         return;
/*      */     } 
/* 1049 */     this._nextToken = _handleOddValue(i);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean _isNextTokenNameMaybe(int i, String nameToMatch) throws IOException {
/* 1055 */     String name = (i == 34) ? _parseName() : _handleOddName(i);
/* 1056 */     this._parsingContext.setCurrentName(name);
/* 1057 */     this._currToken = JsonToken.FIELD_NAME;
/* 1058 */     i = _skipColon();
/* 1059 */     _updateLocation();
/* 1060 */     if (i == 34) {
/* 1061 */       this._tokenIncomplete = true;
/* 1062 */       this._nextToken = JsonToken.VALUE_STRING;
/* 1063 */       return nameToMatch.equals(name);
/*      */     } 
/*      */ 
/*      */     
/* 1067 */     switch (i)
/*      */     { case 45:
/* 1069 */         t = _parseNegNumber();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1108 */         this._nextToken = t;
/* 1109 */         return nameToMatch.equals(name);case 46: t = _parseFloatThatStartsWithPeriod(); this._nextToken = t; return nameToMatch.equals(name);case 48: case 49: case 50: case 51: case 52: case 53: case 54: case 55: case 56: case 57: t = _parsePosNumber(i); this._nextToken = t; return nameToMatch.equals(name);case 102: _matchFalse(); t = JsonToken.VALUE_FALSE; this._nextToken = t; return nameToMatch.equals(name);case 110: _matchNull(); t = JsonToken.VALUE_NULL; this._nextToken = t; return nameToMatch.equals(name);case 116: _matchTrue(); t = JsonToken.VALUE_TRUE; this._nextToken = t; return nameToMatch.equals(name);case 91: t = JsonToken.START_ARRAY; this._nextToken = t; return nameToMatch.equals(name);case 123: t = JsonToken.START_OBJECT; this._nextToken = t; return nameToMatch.equals(name); }  JsonToken t = _handleOddValue(i); this._nextToken = t; return nameToMatch.equals(name);
/*      */   }
/*      */ 
/*      */   
/*      */   private final JsonToken _nextTokenNotInObject(int i) throws IOException {
/* 1114 */     if (i == 34) {
/* 1115 */       this._tokenIncomplete = true;
/* 1116 */       return this._currToken = JsonToken.VALUE_STRING;
/*      */     } 
/* 1118 */     switch (i) {
/*      */       case 91:
/* 1120 */         this._parsingContext = this._parsingContext.createChildArrayContext(this._tokenInputRow, this._tokenInputCol);
/* 1121 */         return this._currToken = JsonToken.START_ARRAY;
/*      */       case 123:
/* 1123 */         this._parsingContext = this._parsingContext.createChildObjectContext(this._tokenInputRow, this._tokenInputCol);
/* 1124 */         return this._currToken = JsonToken.START_OBJECT;
/*      */       case 116:
/* 1126 */         _matchToken("true", 1);
/* 1127 */         return this._currToken = JsonToken.VALUE_TRUE;
/*      */       case 102:
/* 1129 */         _matchToken("false", 1);
/* 1130 */         return this._currToken = JsonToken.VALUE_FALSE;
/*      */       case 110:
/* 1132 */         _matchToken("null", 1);
/* 1133 */         return this._currToken = JsonToken.VALUE_NULL;
/*      */       case 45:
/* 1135 */         return this._currToken = _parseNegNumber();
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 46:
/* 1141 */         return this._currToken = _parseFloatThatStartsWithPeriod();
/*      */       case 48:
/*      */       case 49:
/*      */       case 50:
/*      */       case 51:
/*      */       case 52:
/*      */       case 53:
/*      */       case 54:
/*      */       case 55:
/*      */       case 56:
/*      */       case 57:
/* 1152 */         return this._currToken = _parsePosNumber(i);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 44:
/* 1164 */         if (!this._parsingContext.inRoot() && (
/* 1165 */           this._features & FEAT_MASK_ALLOW_MISSING) != 0) {
/* 1166 */           this._inputPtr--;
/* 1167 */           return this._currToken = JsonToken.VALUE_NULL;
/*      */         } 
/*      */         break;
/*      */     } 
/* 1171 */     return this._currToken = _handleOddValue(i);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final String nextTextValue() throws IOException {
/* 1177 */     if (this._currToken == JsonToken.FIELD_NAME) {
/* 1178 */       this._nameCopied = false;
/* 1179 */       JsonToken t = this._nextToken;
/* 1180 */       this._nextToken = null;
/* 1181 */       this._currToken = t;
/* 1182 */       if (t == JsonToken.VALUE_STRING) {
/* 1183 */         if (this._tokenIncomplete) {
/* 1184 */           this._tokenIncomplete = false;
/* 1185 */           _finishString();
/*      */         } 
/* 1187 */         return this._textBuffer.contentsAsString();
/*      */       } 
/* 1189 */       if (t == JsonToken.START_ARRAY) {
/* 1190 */         this._parsingContext = this._parsingContext.createChildArrayContext(this._tokenInputRow, this._tokenInputCol);
/* 1191 */       } else if (t == JsonToken.START_OBJECT) {
/* 1192 */         this._parsingContext = this._parsingContext.createChildObjectContext(this._tokenInputRow, this._tokenInputCol);
/*      */       } 
/* 1194 */       return null;
/*      */     } 
/*      */     
/* 1197 */     return (nextToken() == JsonToken.VALUE_STRING) ? getText() : null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int nextIntValue(int defaultValue) throws IOException {
/* 1204 */     if (this._currToken == JsonToken.FIELD_NAME) {
/* 1205 */       this._nameCopied = false;
/* 1206 */       JsonToken t = this._nextToken;
/* 1207 */       this._nextToken = null;
/* 1208 */       this._currToken = t;
/* 1209 */       if (t == JsonToken.VALUE_NUMBER_INT) {
/* 1210 */         return getIntValue();
/*      */       }
/* 1212 */       if (t == JsonToken.START_ARRAY) {
/* 1213 */         this._parsingContext = this._parsingContext.createChildArrayContext(this._tokenInputRow, this._tokenInputCol);
/* 1214 */       } else if (t == JsonToken.START_OBJECT) {
/* 1215 */         this._parsingContext = this._parsingContext.createChildObjectContext(this._tokenInputRow, this._tokenInputCol);
/*      */       } 
/* 1217 */       return defaultValue;
/*      */     } 
/*      */     
/* 1220 */     return (nextToken() == JsonToken.VALUE_NUMBER_INT) ? getIntValue() : defaultValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final long nextLongValue(long defaultValue) throws IOException {
/* 1227 */     if (this._currToken == JsonToken.FIELD_NAME) {
/* 1228 */       this._nameCopied = false;
/* 1229 */       JsonToken t = this._nextToken;
/* 1230 */       this._nextToken = null;
/* 1231 */       this._currToken = t;
/* 1232 */       if (t == JsonToken.VALUE_NUMBER_INT) {
/* 1233 */         return getLongValue();
/*      */       }
/* 1235 */       if (t == JsonToken.START_ARRAY) {
/* 1236 */         this._parsingContext = this._parsingContext.createChildArrayContext(this._tokenInputRow, this._tokenInputCol);
/* 1237 */       } else if (t == JsonToken.START_OBJECT) {
/* 1238 */         this._parsingContext = this._parsingContext.createChildObjectContext(this._tokenInputRow, this._tokenInputCol);
/*      */       } 
/* 1240 */       return defaultValue;
/*      */     } 
/*      */     
/* 1243 */     return (nextToken() == JsonToken.VALUE_NUMBER_INT) ? getLongValue() : defaultValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Boolean nextBooleanValue() throws IOException {
/* 1250 */     if (this._currToken == JsonToken.FIELD_NAME) {
/* 1251 */       this._nameCopied = false;
/* 1252 */       JsonToken jsonToken = this._nextToken;
/* 1253 */       this._nextToken = null;
/* 1254 */       this._currToken = jsonToken;
/* 1255 */       if (jsonToken == JsonToken.VALUE_TRUE) {
/* 1256 */         return Boolean.TRUE;
/*      */       }
/* 1258 */       if (jsonToken == JsonToken.VALUE_FALSE) {
/* 1259 */         return Boolean.FALSE;
/*      */       }
/* 1261 */       if (jsonToken == JsonToken.START_ARRAY) {
/* 1262 */         this._parsingContext = this._parsingContext.createChildArrayContext(this._tokenInputRow, this._tokenInputCol);
/* 1263 */       } else if (jsonToken == JsonToken.START_OBJECT) {
/* 1264 */         this._parsingContext = this._parsingContext.createChildObjectContext(this._tokenInputRow, this._tokenInputCol);
/*      */       } 
/* 1266 */       return null;
/*      */     } 
/* 1268 */     JsonToken t = nextToken();
/* 1269 */     if (t != null) {
/* 1270 */       int id = t.id();
/* 1271 */       if (id == 9) return Boolean.TRUE; 
/* 1272 */       if (id == 10) return Boolean.FALSE; 
/*      */     } 
/* 1274 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final JsonToken _parseFloatThatStartsWithPeriod() throws IOException {
/* 1287 */     if (!isEnabled(JsonReadFeature.ALLOW_LEADING_DECIMAL_POINT_FOR_NUMBERS.mappedFeature())) {
/* 1288 */       return _handleOddValue(46);
/*      */     }
/* 1290 */     return _parseFloat(46, this._inputPtr - 1, this._inputPtr, false, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final JsonToken _parsePosNumber(int ch) throws IOException {
/* 1315 */     int ptr = this._inputPtr;
/* 1316 */     int startPtr = ptr - 1;
/* 1317 */     int inputLen = this._inputEnd;
/*      */ 
/*      */     
/* 1320 */     if (ch == 48) {
/* 1321 */       return _parseNumber2(false, startPtr);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1330 */     int intLen = 1;
/*      */ 
/*      */ 
/*      */     
/*      */     while (true) {
/* 1335 */       if (ptr >= inputLen) {
/* 1336 */         this._inputPtr = startPtr;
/* 1337 */         return _parseNumber2(false, startPtr);
/*      */       } 
/* 1339 */       ch = this._inputBuffer[ptr++];
/* 1340 */       if (ch < 48 || ch > 57) {
/*      */         break;
/*      */       }
/* 1343 */       intLen++;
/*      */     } 
/* 1345 */     if (ch == 46 || ch == 101 || ch == 69) {
/* 1346 */       this._inputPtr = ptr;
/* 1347 */       return _parseFloat(ch, startPtr, ptr, false, intLen);
/*      */     } 
/*      */ 
/*      */     
/* 1351 */     this._inputPtr = --ptr;
/*      */     
/* 1353 */     if (this._parsingContext.inRoot()) {
/* 1354 */       _verifyRootSpace(ch);
/*      */     }
/* 1356 */     int len = ptr - startPtr;
/* 1357 */     this._textBuffer.resetWithShared(this._inputBuffer, startPtr, len);
/* 1358 */     return resetInt(false, intLen);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private final JsonToken _parseFloat(int ch, int startPtr, int ptr, boolean neg, int intLen) throws IOException {
/* 1364 */     int inputLen = this._inputEnd;
/* 1365 */     int fractLen = 0;
/*      */ 
/*      */     
/* 1368 */     if (ch == 46) {
/*      */       
/*      */       while (true) {
/* 1371 */         if (ptr >= inputLen) {
/* 1372 */           return _parseNumber2(neg, startPtr);
/*      */         }
/* 1374 */         ch = this._inputBuffer[ptr++];
/* 1375 */         if (ch < 48 || ch > 57) {
/*      */           break;
/*      */         }
/* 1378 */         fractLen++;
/*      */       } 
/*      */       
/* 1381 */       if (fractLen == 0) {
/* 1382 */         reportUnexpectedNumberChar(ch, "Decimal point not followed by a digit");
/*      */       }
/*      */     } 
/* 1385 */     int expLen = 0;
/* 1386 */     if (ch == 101 || ch == 69) {
/* 1387 */       if (ptr >= inputLen) {
/* 1388 */         this._inputPtr = startPtr;
/* 1389 */         return _parseNumber2(neg, startPtr);
/*      */       } 
/*      */       
/* 1392 */       ch = this._inputBuffer[ptr++];
/* 1393 */       if (ch == 45 || ch == 43) {
/* 1394 */         if (ptr >= inputLen) {
/* 1395 */           this._inputPtr = startPtr;
/* 1396 */           return _parseNumber2(neg, startPtr);
/*      */         } 
/* 1398 */         ch = this._inputBuffer[ptr++];
/*      */       } 
/* 1400 */       while (ch <= 57 && ch >= 48) {
/* 1401 */         expLen++;
/* 1402 */         if (ptr >= inputLen) {
/* 1403 */           this._inputPtr = startPtr;
/* 1404 */           return _parseNumber2(neg, startPtr);
/*      */         } 
/* 1406 */         ch = this._inputBuffer[ptr++];
/*      */       } 
/*      */       
/* 1409 */       if (expLen == 0) {
/* 1410 */         reportUnexpectedNumberChar(ch, "Exponent indicator not followed by a digit");
/*      */       }
/*      */     } 
/*      */     
/* 1414 */     this._inputPtr = --ptr;
/*      */     
/* 1416 */     if (this._parsingContext.inRoot()) {
/* 1417 */       _verifyRootSpace(ch);
/*      */     }
/* 1419 */     int len = ptr - startPtr;
/* 1420 */     this._textBuffer.resetWithShared(this._inputBuffer, startPtr, len);
/*      */     
/* 1422 */     return resetFloat(neg, intLen, fractLen, expLen);
/*      */   }
/*      */ 
/*      */   
/*      */   protected final JsonToken _parseNegNumber() throws IOException {
/* 1427 */     int ptr = this._inputPtr;
/* 1428 */     int startPtr = ptr - 1;
/* 1429 */     int inputLen = this._inputEnd;
/*      */     
/* 1431 */     if (ptr >= inputLen) {
/* 1432 */       return _parseNumber2(true, startPtr);
/*      */     }
/* 1434 */     int ch = this._inputBuffer[ptr++];
/*      */     
/* 1436 */     if (ch > 57 || ch < 48) {
/* 1437 */       this._inputPtr = ptr;
/* 1438 */       return _handleInvalidNumberStart(ch, true);
/*      */     } 
/*      */     
/* 1441 */     if (ch == 48) {
/* 1442 */       return _parseNumber2(true, startPtr);
/*      */     }
/* 1444 */     int intLen = 1;
/*      */ 
/*      */ 
/*      */     
/*      */     while (true) {
/* 1449 */       if (ptr >= inputLen) {
/* 1450 */         return _parseNumber2(true, startPtr);
/*      */       }
/* 1452 */       ch = this._inputBuffer[ptr++];
/* 1453 */       if (ch < 48 || ch > 57) {
/*      */         break;
/*      */       }
/* 1456 */       intLen++;
/*      */     } 
/*      */     
/* 1459 */     if (ch == 46 || ch == 101 || ch == 69) {
/* 1460 */       this._inputPtr = ptr;
/* 1461 */       return _parseFloat(ch, startPtr, ptr, true, intLen);
/*      */     } 
/*      */     
/* 1464 */     this._inputPtr = --ptr;
/* 1465 */     if (this._parsingContext.inRoot()) {
/* 1466 */       _verifyRootSpace(ch);
/*      */     }
/* 1468 */     int len = ptr - startPtr;
/* 1469 */     this._textBuffer.resetWithShared(this._inputBuffer, startPtr, len);
/* 1470 */     return resetInt(true, intLen);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final JsonToken _parseNumber2(boolean neg, int startPtr) throws IOException {
/* 1482 */     this._inputPtr = neg ? (startPtr + 1) : startPtr;
/* 1483 */     char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/* 1484 */     int outPtr = 0;
/*      */ 
/*      */     
/* 1487 */     if (neg) {
/* 1488 */       outBuf[outPtr++] = '-';
/*      */     }
/*      */ 
/*      */     
/* 1492 */     int intLen = 0;
/*      */     
/* 1494 */     char c = (this._inputPtr < this._inputEnd) ? this._inputBuffer[this._inputPtr++] : getNextChar("No digit following minus sign", JsonToken.VALUE_NUMBER_INT);
/* 1495 */     if (c == '0') {
/* 1496 */       c = _verifyNoLeadingZeroes();
/*      */     }
/* 1498 */     boolean eof = false;
/*      */ 
/*      */ 
/*      */     
/* 1502 */     while (c >= '0' && c <= '9') {
/* 1503 */       intLen++;
/* 1504 */       if (outPtr >= outBuf.length) {
/* 1505 */         outBuf = this._textBuffer.finishCurrentSegment();
/* 1506 */         outPtr = 0;
/*      */       } 
/* 1508 */       outBuf[outPtr++] = c;
/* 1509 */       if (this._inputPtr >= this._inputEnd && !_loadMore()) {
/*      */         
/* 1511 */         c = Character.MIN_VALUE;
/* 1512 */         eof = true;
/*      */         break;
/*      */       } 
/* 1515 */       c = this._inputBuffer[this._inputPtr++];
/*      */     } 
/*      */     
/* 1518 */     if (intLen == 0) {
/* 1519 */       return _handleInvalidNumberStart(c, neg);
/*      */     }
/*      */     
/* 1522 */     int fractLen = 0;
/*      */     
/* 1524 */     if (c == '.') {
/* 1525 */       if (outPtr >= outBuf.length) {
/* 1526 */         outBuf = this._textBuffer.finishCurrentSegment();
/* 1527 */         outPtr = 0;
/*      */       } 
/* 1529 */       outBuf[outPtr++] = c;
/*      */ 
/*      */       
/*      */       while (true) {
/* 1533 */         if (this._inputPtr >= this._inputEnd && !_loadMore()) {
/* 1534 */           eof = true;
/*      */           break;
/*      */         } 
/* 1537 */         c = this._inputBuffer[this._inputPtr++];
/* 1538 */         if (c < '0' || c > '9') {
/*      */           break;
/*      */         }
/* 1541 */         fractLen++;
/* 1542 */         if (outPtr >= outBuf.length) {
/* 1543 */           outBuf = this._textBuffer.finishCurrentSegment();
/* 1544 */           outPtr = 0;
/*      */         } 
/* 1546 */         outBuf[outPtr++] = c;
/*      */       } 
/*      */       
/* 1549 */       if (fractLen == 0) {
/* 1550 */         reportUnexpectedNumberChar(c, "Decimal point not followed by a digit");
/*      */       }
/*      */     } 
/*      */     
/* 1554 */     int expLen = 0;
/* 1555 */     if (c == 'e' || c == 'E') {
/* 1556 */       if (outPtr >= outBuf.length) {
/* 1557 */         outBuf = this._textBuffer.finishCurrentSegment();
/* 1558 */         outPtr = 0;
/*      */       } 
/* 1560 */       outBuf[outPtr++] = c;
/*      */ 
/*      */       
/* 1563 */       c = (this._inputPtr < this._inputEnd) ? this._inputBuffer[this._inputPtr++] : getNextChar("expected a digit for number exponent");
/*      */       
/* 1565 */       if (c == '-' || c == '+') {
/* 1566 */         if (outPtr >= outBuf.length) {
/* 1567 */           outBuf = this._textBuffer.finishCurrentSegment();
/* 1568 */           outPtr = 0;
/*      */         } 
/* 1570 */         outBuf[outPtr++] = c;
/*      */ 
/*      */         
/* 1573 */         c = (this._inputPtr < this._inputEnd) ? this._inputBuffer[this._inputPtr++] : getNextChar("expected a digit for number exponent");
/*      */       } 
/*      */ 
/*      */       
/* 1577 */       while (c <= '9' && c >= '0') {
/* 1578 */         expLen++;
/* 1579 */         if (outPtr >= outBuf.length) {
/* 1580 */           outBuf = this._textBuffer.finishCurrentSegment();
/* 1581 */           outPtr = 0;
/*      */         } 
/* 1583 */         outBuf[outPtr++] = c;
/* 1584 */         if (this._inputPtr >= this._inputEnd && !_loadMore()) {
/* 1585 */           eof = true;
/*      */           break;
/*      */         } 
/* 1588 */         c = this._inputBuffer[this._inputPtr++];
/*      */       } 
/*      */       
/* 1591 */       if (expLen == 0) {
/* 1592 */         reportUnexpectedNumberChar(c, "Exponent indicator not followed by a digit");
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/* 1597 */     if (!eof) {
/* 1598 */       this._inputPtr--;
/* 1599 */       if (this._parsingContext.inRoot()) {
/* 1600 */         _verifyRootSpace(c);
/*      */       }
/*      */     } 
/* 1603 */     this._textBuffer.setCurrentLength(outPtr);
/*      */     
/* 1605 */     return reset(neg, intLen, fractLen, expLen);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final char _verifyNoLeadingZeroes() throws IOException {
/* 1615 */     if (this._inputPtr < this._inputEnd) {
/* 1616 */       char ch = this._inputBuffer[this._inputPtr];
/*      */       
/* 1618 */       if (ch < '0' || ch > '9') {
/* 1619 */         return '0';
/*      */       }
/*      */     } 
/*      */     
/* 1623 */     return _verifyNLZ2();
/*      */   }
/*      */ 
/*      */   
/*      */   private char _verifyNLZ2() throws IOException {
/* 1628 */     if (this._inputPtr >= this._inputEnd && !_loadMore()) {
/* 1629 */       return '0';
/*      */     }
/* 1631 */     char ch = this._inputBuffer[this._inputPtr];
/* 1632 */     if (ch < '0' || ch > '9') {
/* 1633 */       return '0';
/*      */     }
/* 1635 */     if ((this._features & FEAT_MASK_LEADING_ZEROS) == 0) {
/* 1636 */       reportInvalidNumber("Leading zeroes not allowed");
/*      */     }
/*      */     
/* 1639 */     this._inputPtr++;
/* 1640 */     if (ch == '0') {
/* 1641 */       while (this._inputPtr < this._inputEnd || _loadMore()) {
/* 1642 */         ch = this._inputBuffer[this._inputPtr];
/* 1643 */         if (ch < '0' || ch > '9') {
/* 1644 */           return '0';
/*      */         }
/* 1646 */         this._inputPtr++;
/* 1647 */         if (ch != '0') {
/*      */           break;
/*      */         }
/*      */       } 
/*      */     }
/* 1652 */     return ch;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonToken _handleInvalidNumberStart(int ch, boolean negative) throws IOException {
/* 1661 */     if (ch == 73) {
/* 1662 */       if (this._inputPtr >= this._inputEnd && 
/* 1663 */         !_loadMore()) {
/* 1664 */         _reportInvalidEOFInValue(JsonToken.VALUE_NUMBER_INT);
/*      */       }
/*      */       
/* 1667 */       ch = this._inputBuffer[this._inputPtr++];
/* 1668 */       if (ch == 78) {
/* 1669 */         String match = negative ? "-INF" : "+INF";
/* 1670 */         _matchToken(match, 3);
/* 1671 */         if ((this._features & FEAT_MASK_NON_NUM_NUMBERS) != 0) {
/* 1672 */           return resetAsNaN(match, negative ? Double.NEGATIVE_INFINITY : Double.POSITIVE_INFINITY);
/*      */         }
/* 1674 */         _reportError("Non-standard token '" + match + "': enable JsonParser.Feature.ALLOW_NON_NUMERIC_NUMBERS to allow");
/* 1675 */       } else if (ch == 110) {
/* 1676 */         String match = negative ? "-Infinity" : "+Infinity";
/* 1677 */         _matchToken(match, 3);
/* 1678 */         if ((this._features & FEAT_MASK_NON_NUM_NUMBERS) != 0) {
/* 1679 */           return resetAsNaN(match, negative ? Double.NEGATIVE_INFINITY : Double.POSITIVE_INFINITY);
/*      */         }
/* 1681 */         _reportError("Non-standard token '" + match + "': enable JsonParser.Feature.ALLOW_NON_NUMERIC_NUMBERS to allow");
/*      */       } 
/*      */     } 
/* 1684 */     reportUnexpectedNumberChar(ch, "expected digit (0-9) to follow minus sign, for valid numeric value");
/* 1685 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void _verifyRootSpace(int ch) throws IOException {
/* 1698 */     this._inputPtr++;
/* 1699 */     switch (ch) {
/*      */       case 9:
/*      */       case 32:
/*      */         return;
/*      */       case 13:
/* 1704 */         _skipCR();
/*      */         return;
/*      */       case 10:
/* 1707 */         this._currInputRow++;
/* 1708 */         this._currInputRowStart = this._inputPtr;
/*      */         return;
/*      */     } 
/* 1711 */     _reportMissingRootWS(ch);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final String _parseName() throws IOException {
/* 1724 */     int ptr = this._inputPtr;
/* 1725 */     int hash = this._hashSeed;
/* 1726 */     int[] codes = _icLatin1;
/*      */     
/* 1728 */     while (ptr < this._inputEnd) {
/* 1729 */       int ch = this._inputBuffer[ptr];
/* 1730 */       if (ch < codes.length && codes[ch] != 0) {
/* 1731 */         if (ch == 34) {
/* 1732 */           int i = this._inputPtr;
/* 1733 */           this._inputPtr = ptr + 1;
/* 1734 */           return this._symbols.findSymbol(this._inputBuffer, i, ptr - i, hash);
/*      */         } 
/*      */         break;
/*      */       } 
/* 1738 */       hash = hash * 33 + ch;
/* 1739 */       ptr++;
/*      */     } 
/* 1741 */     int start = this._inputPtr;
/* 1742 */     this._inputPtr = ptr;
/* 1743 */     return _parseName2(start, hash, 34);
/*      */   }
/*      */ 
/*      */   
/*      */   private String _parseName2(int startPtr, int hash, int endChar) throws IOException {
/* 1748 */     this._textBuffer.resetWithShared(this._inputBuffer, startPtr, this._inputPtr - startPtr);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1753 */     char[] outBuf = this._textBuffer.getCurrentSegment();
/* 1754 */     int outPtr = this._textBuffer.getCurrentSegmentSize();
/*      */     
/*      */     while (true) {
/* 1757 */       if (this._inputPtr >= this._inputEnd && 
/* 1758 */         !_loadMore()) {
/* 1759 */         _reportInvalidEOF(" in field name", JsonToken.FIELD_NAME);
/*      */       }
/*      */       
/* 1762 */       char c = this._inputBuffer[this._inputPtr++];
/* 1763 */       int i = c;
/* 1764 */       if (i <= 92) {
/* 1765 */         if (i == 92) {
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1770 */           c = _decodeEscaped();
/* 1771 */         } else if (i <= endChar) {
/* 1772 */           if (i == endChar) {
/*      */             break;
/*      */           }
/* 1775 */           if (i < 32) {
/* 1776 */             _throwUnquotedSpace(i, "name");
/*      */           }
/*      */         } 
/*      */       }
/* 1780 */       hash = hash * 33 + c;
/*      */       
/* 1782 */       outBuf[outPtr++] = c;
/*      */ 
/*      */       
/* 1785 */       if (outPtr >= outBuf.length) {
/* 1786 */         outBuf = this._textBuffer.finishCurrentSegment();
/* 1787 */         outPtr = 0;
/*      */       } 
/*      */     } 
/* 1790 */     this._textBuffer.setCurrentLength(outPtr);
/*      */     
/* 1792 */     TextBuffer tb = this._textBuffer;
/* 1793 */     char[] buf = tb.getTextBuffer();
/* 1794 */     int start = tb.getTextOffset();
/* 1795 */     int len = tb.size();
/* 1796 */     return this._symbols.findSymbol(buf, start, len, hash);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String _handleOddName(int i) throws IOException {
/*      */     boolean firstOk;
/* 1809 */     if (i == 39 && (this._features & FEAT_MASK_ALLOW_SINGLE_QUOTES) != 0) {
/* 1810 */       return _parseAposName();
/*      */     }
/*      */     
/* 1813 */     if ((this._features & FEAT_MASK_ALLOW_UNQUOTED_NAMES) == 0) {
/* 1814 */       _reportUnexpectedChar(i, "was expecting double-quote to start field name");
/*      */     }
/* 1816 */     int[] codes = CharTypes.getInputCodeLatin1JsNames();
/* 1817 */     int maxCode = codes.length;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1822 */     if (i < maxCode) {
/* 1823 */       firstOk = (codes[i] == 0);
/*      */     } else {
/* 1825 */       firstOk = Character.isJavaIdentifierPart((char)i);
/*      */     } 
/* 1827 */     if (!firstOk) {
/* 1828 */       _reportUnexpectedChar(i, "was expecting either valid name character (for unquoted name) or double-quote (for quoted) to start field name");
/*      */     }
/* 1830 */     int ptr = this._inputPtr;
/* 1831 */     int hash = this._hashSeed;
/* 1832 */     int inputLen = this._inputEnd;
/*      */     
/* 1834 */     if (ptr < inputLen) {
/*      */       do {
/* 1836 */         int ch = this._inputBuffer[ptr];
/* 1837 */         if (ch < maxCode) {
/* 1838 */           if (codes[ch] != 0) {
/* 1839 */             int j = this._inputPtr - 1;
/* 1840 */             this._inputPtr = ptr;
/* 1841 */             return this._symbols.findSymbol(this._inputBuffer, j, ptr - j, hash);
/*      */           } 
/* 1843 */         } else if (!Character.isJavaIdentifierPart((char)ch)) {
/* 1844 */           int j = this._inputPtr - 1;
/* 1845 */           this._inputPtr = ptr;
/* 1846 */           return this._symbols.findSymbol(this._inputBuffer, j, ptr - j, hash);
/*      */         } 
/* 1848 */         hash = hash * 33 + ch;
/* 1849 */         ++ptr;
/* 1850 */       } while (ptr < inputLen);
/*      */     }
/* 1852 */     int start = this._inputPtr - 1;
/* 1853 */     this._inputPtr = ptr;
/* 1854 */     return _handleOddName2(start, hash, codes);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected String _parseAposName() throws IOException {
/* 1860 */     int ptr = this._inputPtr;
/* 1861 */     int hash = this._hashSeed;
/* 1862 */     int inputLen = this._inputEnd;
/*      */     
/* 1864 */     if (ptr < inputLen) {
/* 1865 */       int[] codes = _icLatin1;
/* 1866 */       int maxCode = codes.length;
/*      */       
/*      */       do {
/* 1869 */         int ch = this._inputBuffer[ptr];
/* 1870 */         if (ch == 39) {
/* 1871 */           int i = this._inputPtr;
/* 1872 */           this._inputPtr = ptr + 1;
/* 1873 */           return this._symbols.findSymbol(this._inputBuffer, i, ptr - i, hash);
/*      */         } 
/* 1875 */         if (ch < maxCode && codes[ch] != 0) {
/*      */           break;
/*      */         }
/* 1878 */         hash = hash * 33 + ch;
/* 1879 */         ++ptr;
/* 1880 */       } while (ptr < inputLen);
/*      */     } 
/*      */     
/* 1883 */     int start = this._inputPtr;
/* 1884 */     this._inputPtr = ptr;
/*      */     
/* 1886 */     return _parseName2(start, hash, 39);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonToken _handleOddValue(int i) throws IOException {
/* 1896 */     switch (i) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 39:
/* 1903 */         if ((this._features & FEAT_MASK_ALLOW_SINGLE_QUOTES) != 0) {
/* 1904 */           return _handleApos();
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 93:
/* 1912 */         if (!this._parsingContext.inArray()) {
/*      */           break;
/*      */         }
/*      */ 
/*      */       
/*      */       case 44:
/* 1918 */         if (!this._parsingContext.inRoot() && (
/* 1919 */           this._features & FEAT_MASK_ALLOW_MISSING) != 0) {
/* 1920 */           this._inputPtr--;
/* 1921 */           return JsonToken.VALUE_NULL;
/*      */         } 
/*      */         break;
/*      */       
/*      */       case 78:
/* 1926 */         _matchToken("NaN", 1);
/* 1927 */         if ((this._features & FEAT_MASK_NON_NUM_NUMBERS) != 0) {
/* 1928 */           return resetAsNaN("NaN", Double.NaN);
/*      */         }
/* 1930 */         _reportError("Non-standard token 'NaN': enable JsonParser.Feature.ALLOW_NON_NUMERIC_NUMBERS to allow");
/*      */         break;
/*      */       case 73:
/* 1933 */         _matchToken("Infinity", 1);
/* 1934 */         if ((this._features & FEAT_MASK_NON_NUM_NUMBERS) != 0) {
/* 1935 */           return resetAsNaN("Infinity", Double.POSITIVE_INFINITY);
/*      */         }
/* 1937 */         _reportError("Non-standard token 'Infinity': enable JsonParser.Feature.ALLOW_NON_NUMERIC_NUMBERS to allow");
/*      */         break;
/*      */       case 43:
/* 1940 */         if (this._inputPtr >= this._inputEnd && 
/* 1941 */           !_loadMore()) {
/* 1942 */           _reportInvalidEOFInValue(JsonToken.VALUE_NUMBER_INT);
/*      */         }
/*      */         
/* 1945 */         return _handleInvalidNumberStart(this._inputBuffer[this._inputPtr++], false);
/*      */     } 
/*      */     
/* 1948 */     if (Character.isJavaIdentifierStart(i)) {
/* 1949 */       _reportInvalidToken("" + (char)i, _validJsonTokenList());
/*      */     }
/*      */     
/* 1952 */     _reportUnexpectedChar(i, "expected a valid value " + _validJsonValueList());
/* 1953 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   protected JsonToken _handleApos() throws IOException {
/* 1958 */     char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/* 1959 */     int outPtr = this._textBuffer.getCurrentSegmentSize();
/*      */     
/*      */     while (true) {
/* 1962 */       if (this._inputPtr >= this._inputEnd && 
/* 1963 */         !_loadMore()) {
/* 1964 */         _reportInvalidEOF(": was expecting closing quote for a string value", JsonToken.VALUE_STRING);
/*      */       }
/*      */ 
/*      */       
/* 1968 */       char c = this._inputBuffer[this._inputPtr++];
/* 1969 */       int i = c;
/* 1970 */       if (i <= 92) {
/* 1971 */         if (i == 92) {
/*      */ 
/*      */ 
/*      */           
/* 1975 */           c = _decodeEscaped();
/* 1976 */         } else if (i <= 39) {
/* 1977 */           if (i == 39) {
/*      */             break;
/*      */           }
/* 1980 */           if (i < 32) {
/* 1981 */             _throwUnquotedSpace(i, "string value");
/*      */           }
/*      */         } 
/*      */       }
/*      */       
/* 1986 */       if (outPtr >= outBuf.length) {
/* 1987 */         outBuf = this._textBuffer.finishCurrentSegment();
/* 1988 */         outPtr = 0;
/*      */       } 
/*      */       
/* 1991 */       outBuf[outPtr++] = c;
/*      */     } 
/* 1993 */     this._textBuffer.setCurrentLength(outPtr);
/* 1994 */     return JsonToken.VALUE_STRING;
/*      */   }
/*      */ 
/*      */   
/*      */   private String _handleOddName2(int startPtr, int hash, int[] codes) throws IOException {
/* 1999 */     this._textBuffer.resetWithShared(this._inputBuffer, startPtr, this._inputPtr - startPtr);
/* 2000 */     char[] outBuf = this._textBuffer.getCurrentSegment();
/* 2001 */     int outPtr = this._textBuffer.getCurrentSegmentSize();
/* 2002 */     int maxCode = codes.length;
/*      */ 
/*      */     
/* 2005 */     while (this._inputPtr < this._inputEnd || 
/* 2006 */       _loadMore()) {
/*      */ 
/*      */ 
/*      */       
/* 2010 */       char c = this._inputBuffer[this._inputPtr];
/* 2011 */       int i = c;
/* 2012 */       if ((i < maxCode) ? (
/* 2013 */         codes[i] != 0) : 
/*      */ 
/*      */         
/* 2016 */         !Character.isJavaIdentifierPart(c)) {
/*      */         break;
/*      */       }
/* 2019 */       this._inputPtr++;
/* 2020 */       hash = hash * 33 + i;
/*      */       
/* 2022 */       outBuf[outPtr++] = c;
/*      */ 
/*      */       
/* 2025 */       if (outPtr >= outBuf.length) {
/* 2026 */         outBuf = this._textBuffer.finishCurrentSegment();
/* 2027 */         outPtr = 0;
/*      */       } 
/*      */     } 
/* 2030 */     this._textBuffer.setCurrentLength(outPtr);
/*      */     
/* 2032 */     TextBuffer tb = this._textBuffer;
/* 2033 */     char[] buf = tb.getTextBuffer();
/* 2034 */     int start = tb.getTextOffset();
/* 2035 */     int len = tb.size();
/*      */     
/* 2037 */     return this._symbols.findSymbol(buf, start, len, hash);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void _finishString() throws IOException {
/* 2048 */     int ptr = this._inputPtr;
/* 2049 */     int inputLen = this._inputEnd;
/*      */     
/* 2051 */     if (ptr < inputLen) {
/* 2052 */       int[] codes = _icLatin1;
/* 2053 */       int maxCode = codes.length;
/*      */       
/*      */       do {
/* 2056 */         int ch = this._inputBuffer[ptr];
/* 2057 */         if (ch < maxCode && codes[ch] != 0) {
/* 2058 */           if (ch == 34) {
/* 2059 */             this._textBuffer.resetWithShared(this._inputBuffer, this._inputPtr, ptr - this._inputPtr);
/* 2060 */             this._inputPtr = ptr + 1;
/*      */             
/*      */             return;
/*      */           } 
/*      */           break;
/*      */         } 
/* 2066 */         ++ptr;
/* 2067 */       } while (ptr < inputLen);
/*      */     } 
/*      */ 
/*      */     
/* 2071 */     this._textBuffer.resetWithCopy(this._inputBuffer, this._inputPtr, ptr - this._inputPtr);
/* 2072 */     this._inputPtr = ptr;
/* 2073 */     _finishString2();
/*      */   }
/*      */ 
/*      */   
/*      */   protected void _finishString2() throws IOException {
/* 2078 */     char[] outBuf = this._textBuffer.getCurrentSegment();
/* 2079 */     int outPtr = this._textBuffer.getCurrentSegmentSize();
/* 2080 */     int[] codes = _icLatin1;
/* 2081 */     int maxCode = codes.length;
/*      */     
/*      */     while (true) {
/* 2084 */       if (this._inputPtr >= this._inputEnd && 
/* 2085 */         !_loadMore()) {
/* 2086 */         _reportInvalidEOF(": was expecting closing quote for a string value", JsonToken.VALUE_STRING);
/*      */       }
/*      */ 
/*      */       
/* 2090 */       char c = this._inputBuffer[this._inputPtr++];
/* 2091 */       int i = c;
/* 2092 */       if (i < maxCode && codes[i] != 0) {
/* 2093 */         if (i == 34)
/*      */           break; 
/* 2095 */         if (i == 92) {
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 2100 */           c = _decodeEscaped();
/* 2101 */         } else if (i < 32) {
/* 2102 */           _throwUnquotedSpace(i, "string value");
/*      */         } 
/*      */       } 
/*      */       
/* 2106 */       if (outPtr >= outBuf.length) {
/* 2107 */         outBuf = this._textBuffer.finishCurrentSegment();
/* 2108 */         outPtr = 0;
/*      */       } 
/*      */       
/* 2111 */       outBuf[outPtr++] = c;
/*      */     } 
/* 2113 */     this._textBuffer.setCurrentLength(outPtr);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void _skipString() throws IOException {
/* 2123 */     this._tokenIncomplete = false;
/*      */     
/* 2125 */     int inPtr = this._inputPtr;
/* 2126 */     int inLen = this._inputEnd;
/* 2127 */     char[] inBuf = this._inputBuffer;
/*      */     
/*      */     while (true) {
/* 2130 */       if (inPtr >= inLen) {
/* 2131 */         this._inputPtr = inPtr;
/* 2132 */         if (!_loadMore()) {
/* 2133 */           _reportInvalidEOF(": was expecting closing quote for a string value", JsonToken.VALUE_STRING);
/*      */         }
/*      */         
/* 2136 */         inPtr = this._inputPtr;
/* 2137 */         inLen = this._inputEnd;
/*      */       } 
/* 2139 */       char c = inBuf[inPtr++];
/* 2140 */       int i = c;
/* 2141 */       if (i <= 92) {
/* 2142 */         if (i == 92) {
/*      */ 
/*      */           
/* 2145 */           this._inputPtr = inPtr;
/* 2146 */           _decodeEscaped();
/* 2147 */           inPtr = this._inputPtr;
/* 2148 */           inLen = this._inputEnd; continue;
/* 2149 */         }  if (i <= 34) {
/* 2150 */           if (i == 34) {
/* 2151 */             this._inputPtr = inPtr;
/*      */             break;
/*      */           } 
/* 2154 */           if (i < 32) {
/* 2155 */             this._inputPtr = inPtr;
/* 2156 */             _throwUnquotedSpace(i, "string value");
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void _skipCR() throws IOException {
/* 2174 */     if ((this._inputPtr < this._inputEnd || _loadMore()) && 
/* 2175 */       this._inputBuffer[this._inputPtr] == '\n') {
/* 2176 */       this._inputPtr++;
/*      */     }
/*      */     
/* 2179 */     this._currInputRow++;
/* 2180 */     this._currInputRowStart = this._inputPtr;
/*      */   }
/*      */ 
/*      */   
/*      */   private final int _skipColon() throws IOException {
/* 2185 */     if (this._inputPtr + 4 >= this._inputEnd) {
/* 2186 */       return _skipColon2(false);
/*      */     }
/* 2188 */     char c = this._inputBuffer[this._inputPtr];
/* 2189 */     if (c == ':') {
/* 2190 */       int i = this._inputBuffer[++this._inputPtr];
/* 2191 */       if (i > 32) {
/* 2192 */         if (i == 47 || i == 35) {
/* 2193 */           return _skipColon2(true);
/*      */         }
/* 2195 */         this._inputPtr++;
/* 2196 */         return i;
/*      */       } 
/* 2198 */       if (i == 32 || i == 9) {
/* 2199 */         i = this._inputBuffer[++this._inputPtr];
/* 2200 */         if (i > 32) {
/* 2201 */           if (i == 47 || i == 35) {
/* 2202 */             return _skipColon2(true);
/*      */           }
/* 2204 */           this._inputPtr++;
/* 2205 */           return i;
/*      */         } 
/*      */       } 
/* 2208 */       return _skipColon2(true);
/*      */     } 
/* 2210 */     if (c == ' ' || c == '\t') {
/* 2211 */       c = this._inputBuffer[++this._inputPtr];
/*      */     }
/* 2213 */     if (c == ':') {
/* 2214 */       int i = this._inputBuffer[++this._inputPtr];
/* 2215 */       if (i > 32) {
/* 2216 */         if (i == 47 || i == 35) {
/* 2217 */           return _skipColon2(true);
/*      */         }
/* 2219 */         this._inputPtr++;
/* 2220 */         return i;
/*      */       } 
/* 2222 */       if (i == 32 || i == 9) {
/* 2223 */         i = this._inputBuffer[++this._inputPtr];
/* 2224 */         if (i > 32) {
/* 2225 */           if (i == 47 || i == 35) {
/* 2226 */             return _skipColon2(true);
/*      */           }
/* 2228 */           this._inputPtr++;
/* 2229 */           return i;
/*      */         } 
/*      */       } 
/* 2232 */       return _skipColon2(true);
/*      */     } 
/* 2234 */     return _skipColon2(false);
/*      */   }
/*      */ 
/*      */   
/*      */   private final int _skipColon2(boolean gotColon) throws IOException {
/* 2239 */     while (this._inputPtr < this._inputEnd || _loadMore()) {
/* 2240 */       int i = this._inputBuffer[this._inputPtr++];
/* 2241 */       if (i > 32) {
/* 2242 */         if (i == 47) {
/* 2243 */           _skipComment();
/*      */           continue;
/*      */         } 
/* 2246 */         if (i == 35 && 
/* 2247 */           _skipYAMLComment()) {
/*      */           continue;
/*      */         }
/*      */         
/* 2251 */         if (gotColon) {
/* 2252 */           return i;
/*      */         }
/* 2254 */         if (i != 58) {
/* 2255 */           _reportUnexpectedChar(i, "was expecting a colon to separate field name and value");
/*      */         }
/* 2257 */         gotColon = true;
/*      */         continue;
/*      */       } 
/* 2260 */       if (i < 32) {
/* 2261 */         if (i == 10) {
/* 2262 */           this._currInputRow++;
/* 2263 */           this._currInputRowStart = this._inputPtr; continue;
/* 2264 */         }  if (i == 13) {
/* 2265 */           _skipCR(); continue;
/* 2266 */         }  if (i != 9) {
/* 2267 */           _throwInvalidSpace(i);
/*      */         }
/*      */       } 
/*      */     } 
/* 2271 */     _reportInvalidEOF(" within/between " + this._parsingContext.typeDesc() + " entries", null);
/*      */     
/* 2273 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private final int _skipColonFast(int ptr) throws IOException {
/* 2279 */     int i = this._inputBuffer[ptr++];
/* 2280 */     if (i == 58) {
/* 2281 */       i = this._inputBuffer[ptr++];
/* 2282 */       if (i > 32) {
/* 2283 */         if (i != 47 && i != 35) {
/* 2284 */           this._inputPtr = ptr;
/* 2285 */           return i;
/*      */         } 
/* 2287 */       } else if (i == 32 || i == 9) {
/* 2288 */         i = this._inputBuffer[ptr++];
/* 2289 */         if (i > 32 && 
/* 2290 */           i != 47 && i != 35) {
/* 2291 */           this._inputPtr = ptr;
/* 2292 */           return i;
/*      */         } 
/*      */       } 
/*      */       
/* 2296 */       this._inputPtr = ptr - 1;
/* 2297 */       return _skipColon2(true);
/*      */     } 
/* 2299 */     if (i == 32 || i == 9) {
/* 2300 */       i = this._inputBuffer[ptr++];
/*      */     }
/* 2302 */     boolean gotColon = (i == 58);
/* 2303 */     if (gotColon) {
/* 2304 */       i = this._inputBuffer[ptr++];
/* 2305 */       if (i > 32) {
/* 2306 */         if (i != 47 && i != 35) {
/* 2307 */           this._inputPtr = ptr;
/* 2308 */           return i;
/*      */         } 
/* 2310 */       } else if (i == 32 || i == 9) {
/* 2311 */         i = this._inputBuffer[ptr++];
/* 2312 */         if (i > 32 && 
/* 2313 */           i != 47 && i != 35) {
/* 2314 */           this._inputPtr = ptr;
/* 2315 */           return i;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/* 2320 */     this._inputPtr = ptr - 1;
/* 2321 */     return _skipColon2(gotColon);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private final int _skipComma(int i) throws IOException {
/* 2327 */     if (i != 44) {
/* 2328 */       _reportUnexpectedChar(i, "was expecting comma to separate " + this._parsingContext.typeDesc() + " entries");
/*      */     }
/* 2330 */     while (this._inputPtr < this._inputEnd) {
/* 2331 */       i = this._inputBuffer[this._inputPtr++];
/* 2332 */       if (i > 32) {
/* 2333 */         if (i == 47 || i == 35) {
/* 2334 */           this._inputPtr--;
/* 2335 */           return _skipAfterComma2();
/*      */         } 
/* 2337 */         return i;
/*      */       } 
/* 2339 */       if (i < 32) {
/* 2340 */         if (i == 10) {
/* 2341 */           this._currInputRow++;
/* 2342 */           this._currInputRowStart = this._inputPtr; continue;
/* 2343 */         }  if (i == 13) {
/* 2344 */           _skipCR(); continue;
/* 2345 */         }  if (i != 9) {
/* 2346 */           _throwInvalidSpace(i);
/*      */         }
/*      */       } 
/*      */     } 
/* 2350 */     return _skipAfterComma2();
/*      */   }
/*      */ 
/*      */   
/*      */   private final int _skipAfterComma2() throws IOException {
/* 2355 */     while (this._inputPtr < this._inputEnd || _loadMore()) {
/* 2356 */       int i = this._inputBuffer[this._inputPtr++];
/* 2357 */       if (i > 32) {
/* 2358 */         if (i == 47) {
/* 2359 */           _skipComment();
/*      */           continue;
/*      */         } 
/* 2362 */         if (i == 35 && 
/* 2363 */           _skipYAMLComment()) {
/*      */           continue;
/*      */         }
/*      */         
/* 2367 */         return i;
/*      */       } 
/* 2369 */       if (i < 32) {
/* 2370 */         if (i == 10) {
/* 2371 */           this._currInputRow++;
/* 2372 */           this._currInputRowStart = this._inputPtr; continue;
/* 2373 */         }  if (i == 13) {
/* 2374 */           _skipCR(); continue;
/* 2375 */         }  if (i != 9) {
/* 2376 */           _throwInvalidSpace(i);
/*      */         }
/*      */       } 
/*      */     } 
/* 2380 */     throw _constructError("Unexpected end-of-input within/between " + this._parsingContext.typeDesc() + " entries");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final int _skipWSOrEnd() throws IOException {
/* 2387 */     if (this._inputPtr >= this._inputEnd && 
/* 2388 */       !_loadMore()) {
/* 2389 */       return _eofAsNextChar();
/*      */     }
/*      */     
/* 2392 */     int i = this._inputBuffer[this._inputPtr++];
/* 2393 */     if (i > 32) {
/* 2394 */       if (i == 47 || i == 35) {
/* 2395 */         this._inputPtr--;
/* 2396 */         return _skipWSOrEnd2();
/*      */       } 
/* 2398 */       return i;
/*      */     } 
/* 2400 */     if (i != 32) {
/* 2401 */       if (i == 10) {
/* 2402 */         this._currInputRow++;
/* 2403 */         this._currInputRowStart = this._inputPtr;
/* 2404 */       } else if (i == 13) {
/* 2405 */         _skipCR();
/* 2406 */       } else if (i != 9) {
/* 2407 */         _throwInvalidSpace(i);
/*      */       } 
/*      */     }
/*      */     
/* 2411 */     while (this._inputPtr < this._inputEnd) {
/* 2412 */       i = this._inputBuffer[this._inputPtr++];
/* 2413 */       if (i > 32) {
/* 2414 */         if (i == 47 || i == 35) {
/* 2415 */           this._inputPtr--;
/* 2416 */           return _skipWSOrEnd2();
/*      */         } 
/* 2418 */         return i;
/*      */       } 
/* 2420 */       if (i != 32) {
/* 2421 */         if (i == 10) {
/* 2422 */           this._currInputRow++;
/* 2423 */           this._currInputRowStart = this._inputPtr; continue;
/* 2424 */         }  if (i == 13) {
/* 2425 */           _skipCR(); continue;
/* 2426 */         }  if (i != 9) {
/* 2427 */           _throwInvalidSpace(i);
/*      */         }
/*      */       } 
/*      */     } 
/* 2431 */     return _skipWSOrEnd2();
/*      */   }
/*      */ 
/*      */   
/*      */   private int _skipWSOrEnd2() throws IOException {
/*      */     while (true) {
/* 2437 */       if (this._inputPtr >= this._inputEnd && 
/* 2438 */         !_loadMore()) {
/* 2439 */         return _eofAsNextChar();
/*      */       }
/*      */       
/* 2442 */       int i = this._inputBuffer[this._inputPtr++];
/* 2443 */       if (i > 32) {
/* 2444 */         if (i == 47) {
/* 2445 */           _skipComment();
/*      */           continue;
/*      */         } 
/* 2448 */         if (i == 35 && 
/* 2449 */           _skipYAMLComment()) {
/*      */           continue;
/*      */         }
/*      */         
/* 2453 */         return i;
/* 2454 */       }  if (i != 32) {
/* 2455 */         if (i == 10) {
/* 2456 */           this._currInputRow++;
/* 2457 */           this._currInputRowStart = this._inputPtr; continue;
/* 2458 */         }  if (i == 13) {
/* 2459 */           _skipCR(); continue;
/* 2460 */         }  if (i != 9) {
/* 2461 */           _throwInvalidSpace(i);
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void _skipComment() throws IOException {
/* 2469 */     if ((this._features & FEAT_MASK_ALLOW_JAVA_COMMENTS) == 0) {
/* 2470 */       _reportUnexpectedChar(47, "maybe a (non-standard) comment? (not recognized as one since Feature 'ALLOW_COMMENTS' not enabled for parser)");
/*      */     }
/*      */     
/* 2473 */     if (this._inputPtr >= this._inputEnd && !_loadMore()) {
/* 2474 */       _reportInvalidEOF(" in a comment", null);
/*      */     }
/* 2476 */     char c = this._inputBuffer[this._inputPtr++];
/* 2477 */     if (c == '/') {
/* 2478 */       _skipLine();
/* 2479 */     } else if (c == '*') {
/* 2480 */       _skipCComment();
/*      */     } else {
/* 2482 */       _reportUnexpectedChar(c, "was expecting either '*' or '/' for a comment");
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void _skipCComment() throws IOException {
/* 2489 */     while (this._inputPtr < this._inputEnd || _loadMore()) {
/* 2490 */       int i = this._inputBuffer[this._inputPtr++];
/* 2491 */       if (i <= 42) {
/* 2492 */         if (i == 42) {
/* 2493 */           if (this._inputPtr >= this._inputEnd && !_loadMore()) {
/*      */             break;
/*      */           }
/* 2496 */           if (this._inputBuffer[this._inputPtr] == '/') {
/* 2497 */             this._inputPtr++;
/*      */             return;
/*      */           } 
/*      */           continue;
/*      */         } 
/* 2502 */         if (i < 32) {
/* 2503 */           if (i == 10) {
/* 2504 */             this._currInputRow++;
/* 2505 */             this._currInputRowStart = this._inputPtr; continue;
/* 2506 */           }  if (i == 13) {
/* 2507 */             _skipCR(); continue;
/* 2508 */           }  if (i != 9) {
/* 2509 */             _throwInvalidSpace(i);
/*      */           }
/*      */         } 
/*      */       } 
/*      */     } 
/* 2514 */     _reportInvalidEOF(" in a comment", null);
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean _skipYAMLComment() throws IOException {
/* 2519 */     if ((this._features & FEAT_MASK_ALLOW_YAML_COMMENTS) == 0) {
/* 2520 */       return false;
/*      */     }
/* 2522 */     _skipLine();
/* 2523 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void _skipLine() throws IOException {
/* 2529 */     while (this._inputPtr < this._inputEnd || _loadMore()) {
/* 2530 */       int i = this._inputBuffer[this._inputPtr++];
/* 2531 */       if (i < 32) {
/* 2532 */         if (i == 10) {
/* 2533 */           this._currInputRow++;
/* 2534 */           this._currInputRowStart = this._inputPtr; break;
/*      */         } 
/* 2536 */         if (i == 13) {
/* 2537 */           _skipCR(); break;
/*      */         } 
/* 2539 */         if (i != 9) {
/* 2540 */           _throwInvalidSpace(i);
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected char _decodeEscaped() throws IOException {
/* 2549 */     if (this._inputPtr >= this._inputEnd && 
/* 2550 */       !_loadMore()) {
/* 2551 */       _reportInvalidEOF(" in character escape sequence", JsonToken.VALUE_STRING);
/*      */     }
/*      */     
/* 2554 */     char c = this._inputBuffer[this._inputPtr++];
/*      */     
/* 2556 */     switch (c) {
/*      */       
/*      */       case 'b':
/* 2559 */         return '\b';
/*      */       case 't':
/* 2561 */         return '\t';
/*      */       case 'n':
/* 2563 */         return '\n';
/*      */       case 'f':
/* 2565 */         return '\f';
/*      */       case 'r':
/* 2567 */         return '\r';
/*      */ 
/*      */       
/*      */       case '"':
/*      */       case '/':
/*      */       case '\\':
/* 2573 */         return c;
/*      */       
/*      */       case 'u':
/*      */         break;
/*      */       
/*      */       default:
/* 2579 */         return _handleUnrecognizedCharacterEscape(c);
/*      */     } 
/*      */ 
/*      */     
/* 2583 */     int value = 0;
/* 2584 */     for (int i = 0; i < 4; i++) {
/* 2585 */       if (this._inputPtr >= this._inputEnd && 
/* 2586 */         !_loadMore()) {
/* 2587 */         _reportInvalidEOF(" in character escape sequence", JsonToken.VALUE_STRING);
/*      */       }
/*      */       
/* 2590 */       int ch = this._inputBuffer[this._inputPtr++];
/* 2591 */       int digit = CharTypes.charToHex(ch);
/* 2592 */       if (digit < 0) {
/* 2593 */         _reportUnexpectedChar(ch, "expected a hex-digit for character escape sequence");
/*      */       }
/* 2595 */       value = value << 4 | digit;
/*      */     } 
/* 2597 */     return (char)value;
/*      */   }
/*      */   
/*      */   private final void _matchTrue() throws IOException {
/* 2601 */     int ptr = this._inputPtr;
/* 2602 */     if (ptr + 3 < this._inputEnd) {
/* 2603 */       char[] b = this._inputBuffer;
/* 2604 */       if (b[ptr] == 'r' && b[++ptr] == 'u' && b[++ptr] == 'e') {
/* 2605 */         char c = b[++ptr];
/* 2606 */         if (c < '0' || c == ']' || c == '}') {
/* 2607 */           this._inputPtr = ptr;
/*      */           
/*      */           return;
/*      */         } 
/*      */       } 
/*      */     } 
/* 2613 */     _matchToken("true", 1);
/*      */   }
/*      */   
/*      */   private final void _matchFalse() throws IOException {
/* 2617 */     int ptr = this._inputPtr;
/* 2618 */     if (ptr + 4 < this._inputEnd) {
/* 2619 */       char[] b = this._inputBuffer;
/* 2620 */       if (b[ptr] == 'a' && b[++ptr] == 'l' && b[++ptr] == 's' && b[++ptr] == 'e') {
/* 2621 */         char c = b[++ptr];
/* 2622 */         if (c < '0' || c == ']' || c == '}') {
/* 2623 */           this._inputPtr = ptr;
/*      */           
/*      */           return;
/*      */         } 
/*      */       } 
/*      */     } 
/* 2629 */     _matchToken("false", 1);
/*      */   }
/*      */   
/*      */   private final void _matchNull() throws IOException {
/* 2633 */     int ptr = this._inputPtr;
/* 2634 */     if (ptr + 3 < this._inputEnd) {
/* 2635 */       char[] b = this._inputBuffer;
/* 2636 */       if (b[ptr] == 'u' && b[++ptr] == 'l' && b[++ptr] == 'l') {
/* 2637 */         char c = b[++ptr];
/* 2638 */         if (c < '0' || c == ']' || c == '}') {
/* 2639 */           this._inputPtr = ptr;
/*      */           
/*      */           return;
/*      */         } 
/*      */       } 
/*      */     } 
/* 2645 */     _matchToken("null", 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void _matchToken(String matchStr, int i) throws IOException {
/* 2653 */     int len = matchStr.length();
/* 2654 */     if (this._inputPtr + len >= this._inputEnd) {
/* 2655 */       _matchToken2(matchStr, i);
/*      */       
/*      */       return;
/*      */     } 
/*      */     while (true) {
/* 2660 */       if (this._inputBuffer[this._inputPtr] != matchStr.charAt(i)) {
/* 2661 */         _reportInvalidToken(matchStr.substring(0, i));
/*      */       }
/* 2663 */       this._inputPtr++;
/* 2664 */       if (++i >= len) {
/* 2665 */         int ch = this._inputBuffer[this._inputPtr];
/* 2666 */         if (ch >= 48 && ch != 93 && ch != 125)
/* 2667 */           _checkMatchEnd(matchStr, i, ch); 
/*      */         return;
/*      */       } 
/*      */     } 
/*      */   }
/*      */   private final void _matchToken2(String matchStr, int i) throws IOException {
/* 2673 */     int len = matchStr.length();
/*      */     do {
/* 2675 */       if ((this._inputPtr >= this._inputEnd && !_loadMore()) || this._inputBuffer[this._inputPtr] != matchStr
/* 2676 */         .charAt(i)) {
/* 2677 */         _reportInvalidToken(matchStr.substring(0, i));
/*      */       }
/* 2679 */       this._inputPtr++;
/* 2680 */     } while (++i < len);
/*      */ 
/*      */     
/* 2683 */     if (this._inputPtr >= this._inputEnd && !_loadMore()) {
/*      */       return;
/*      */     }
/* 2686 */     int ch = this._inputBuffer[this._inputPtr];
/* 2687 */     if (ch >= 48 && ch != 93 && ch != 125) {
/* 2688 */       _checkMatchEnd(matchStr, i, ch);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private final void _checkMatchEnd(String matchStr, int i, int c) throws IOException {
/* 2694 */     char ch = (char)c;
/* 2695 */     if (Character.isJavaIdentifierPart(ch)) {
/* 2696 */       _reportInvalidToken(matchStr.substring(0, i));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected byte[] _decodeBase64(Base64Variant b64variant) throws IOException {
/* 2713 */     ByteArrayBuilder builder = _getByteArrayBuilder();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     while (true) {
/* 2720 */       if (this._inputPtr >= this._inputEnd) {
/* 2721 */         _loadMoreGuaranteed();
/*      */       }
/* 2723 */       char ch = this._inputBuffer[this._inputPtr++];
/* 2724 */       if (ch > ' ') {
/* 2725 */         int bits = b64variant.decodeBase64Char(ch);
/* 2726 */         if (bits < 0) {
/* 2727 */           if (ch == '"') {
/* 2728 */             return builder.toByteArray();
/*      */           }
/* 2730 */           bits = _decodeBase64Escape(b64variant, ch, 0);
/* 2731 */           if (bits < 0) {
/*      */             continue;
/*      */           }
/*      */         } 
/* 2735 */         int decodedData = bits;
/*      */ 
/*      */ 
/*      */         
/* 2739 */         if (this._inputPtr >= this._inputEnd) {
/* 2740 */           _loadMoreGuaranteed();
/*      */         }
/* 2742 */         ch = this._inputBuffer[this._inputPtr++];
/* 2743 */         bits = b64variant.decodeBase64Char(ch);
/* 2744 */         if (bits < 0) {
/* 2745 */           bits = _decodeBase64Escape(b64variant, ch, 1);
/*      */         }
/* 2747 */         decodedData = decodedData << 6 | bits;
/*      */ 
/*      */         
/* 2750 */         if (this._inputPtr >= this._inputEnd) {
/* 2751 */           _loadMoreGuaranteed();
/*      */         }
/* 2753 */         ch = this._inputBuffer[this._inputPtr++];
/* 2754 */         bits = b64variant.decodeBase64Char(ch);
/*      */ 
/*      */         
/* 2757 */         if (bits < 0) {
/* 2758 */           if (bits != -2) {
/*      */             
/* 2760 */             if (ch == '"') {
/* 2761 */               decodedData >>= 4;
/* 2762 */               builder.append(decodedData);
/* 2763 */               if (b64variant.usesPadding()) {
/* 2764 */                 this._inputPtr--;
/* 2765 */                 _handleBase64MissingPadding(b64variant);
/*      */               } 
/* 2767 */               return builder.toByteArray();
/*      */             } 
/* 2769 */             bits = _decodeBase64Escape(b64variant, ch, 2);
/*      */           } 
/* 2771 */           if (bits == -2) {
/*      */             
/* 2773 */             if (this._inputPtr >= this._inputEnd) {
/* 2774 */               _loadMoreGuaranteed();
/*      */             }
/* 2776 */             ch = this._inputBuffer[this._inputPtr++];
/* 2777 */             if (!b64variant.usesPaddingChar(ch) && 
/* 2778 */               _decodeBase64Escape(b64variant, ch, 3) != -2) {
/* 2779 */               throw reportInvalidBase64Char(b64variant, ch, 3, "expected padding character '" + b64variant.getPaddingChar() + "'");
/*      */             }
/*      */ 
/*      */             
/* 2783 */             decodedData >>= 4;
/* 2784 */             builder.append(decodedData);
/*      */             
/*      */             continue;
/*      */           } 
/*      */         } 
/*      */         
/* 2790 */         decodedData = decodedData << 6 | bits;
/*      */         
/* 2792 */         if (this._inputPtr >= this._inputEnd) {
/* 2793 */           _loadMoreGuaranteed();
/*      */         }
/* 2795 */         ch = this._inputBuffer[this._inputPtr++];
/* 2796 */         bits = b64variant.decodeBase64Char(ch);
/* 2797 */         if (bits < 0) {
/* 2798 */           if (bits != -2) {
/*      */             
/* 2800 */             if (ch == '"') {
/* 2801 */               decodedData >>= 2;
/* 2802 */               builder.appendTwoBytes(decodedData);
/* 2803 */               if (b64variant.usesPadding()) {
/* 2804 */                 this._inputPtr--;
/* 2805 */                 _handleBase64MissingPadding(b64variant);
/*      */               } 
/* 2807 */               return builder.toByteArray();
/*      */             } 
/* 2809 */             bits = _decodeBase64Escape(b64variant, ch, 3);
/*      */           } 
/* 2811 */           if (bits == -2) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 2817 */             decodedData >>= 2;
/* 2818 */             builder.appendTwoBytes(decodedData);
/*      */             
/*      */             continue;
/*      */           } 
/*      */         } 
/*      */         
/* 2824 */         decodedData = decodedData << 6 | bits;
/* 2825 */         builder.appendThreeBytes(decodedData);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonLocation getTokenLocation() {
/* 2838 */     if (this._currToken == JsonToken.FIELD_NAME) {
/* 2839 */       long total = this._currInputProcessed + this._nameStartOffset - 1L;
/* 2840 */       return new JsonLocation(_getSourceReference(), -1L, total, this._nameStartRow, this._nameStartCol);
/*      */     } 
/*      */     
/* 2843 */     return new JsonLocation(_getSourceReference(), -1L, this._tokenInputTotal - 1L, this._tokenInputRow, this._tokenInputCol);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonLocation getCurrentLocation() {
/* 2849 */     int col = this._inputPtr - this._currInputRowStart + 1;
/* 2850 */     return new JsonLocation(_getSourceReference(), -1L, this._currInputProcessed + this._inputPtr, this._currInputRow, col);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void _updateLocation() {
/* 2858 */     int ptr = this._inputPtr;
/* 2859 */     this._tokenInputTotal = this._currInputProcessed + ptr;
/* 2860 */     this._tokenInputRow = this._currInputRow;
/* 2861 */     this._tokenInputCol = ptr - this._currInputRowStart;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private final void _updateNameLocation() {
/* 2867 */     int ptr = this._inputPtr;
/* 2868 */     this._nameStartOffset = ptr;
/* 2869 */     this._nameStartRow = this._currInputRow;
/* 2870 */     this._nameStartCol = ptr - this._currInputRowStart;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _reportInvalidToken(String matchedPart) throws IOException {
/* 2880 */     _reportInvalidToken(matchedPart, _validJsonTokenList());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _reportInvalidToken(String matchedPart, String msg) throws IOException {
/* 2889 */     StringBuilder sb = new StringBuilder(matchedPart);
/* 2890 */     while (this._inputPtr < this._inputEnd || _loadMore()) {
/* 2891 */       char c = this._inputBuffer[this._inputPtr];
/* 2892 */       if (!Character.isJavaIdentifierPart(c)) {
/*      */         break;
/*      */       }
/* 2895 */       this._inputPtr++;
/* 2896 */       sb.append(c);
/* 2897 */       if (sb.length() >= 256) {
/* 2898 */         sb.append("...");
/*      */         break;
/*      */       } 
/*      */     } 
/* 2902 */     _reportError("Unrecognized token '%s': was expecting %s", sb, msg);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void _closeScope(int i) throws JsonParseException {
/* 2912 */     if (i == 93) {
/* 2913 */       _updateLocation();
/* 2914 */       if (!this._parsingContext.inArray()) {
/* 2915 */         _reportMismatchedEndMarker(i, '}');
/*      */       }
/* 2917 */       this._parsingContext = this._parsingContext.clearAndGetParent();
/* 2918 */       this._currToken = JsonToken.END_ARRAY;
/*      */     } 
/* 2920 */     if (i == 125) {
/* 2921 */       _updateLocation();
/* 2922 */       if (!this._parsingContext.inObject()) {
/* 2923 */         _reportMismatchedEndMarker(i, ']');
/*      */       }
/* 2925 */       this._parsingContext = this._parsingContext.clearAndGetParent();
/* 2926 */       this._currToken = JsonToken.END_OBJECT;
/*      */     } 
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-core-2.12.7.jar!\com\fasterxml\jackson\core\json\ReaderBasedJsonParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */