/*     */ package com.fasterxml.jackson.core.util;
/*     */ 
/*     */ import com.fasterxml.jackson.core.Base64Variant;
/*     */ import com.fasterxml.jackson.core.FormatSchema;
/*     */ import com.fasterxml.jackson.core.JsonLocation;
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.JsonStreamContext;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.core.ObjectCodec;
/*     */ import com.fasterxml.jackson.core.StreamReadCapability;
/*     */ import com.fasterxml.jackson.core.Version;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.io.Writer;
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JsonParserDelegate
/*     */   extends JsonParser
/*     */ {
/*     */   protected JsonParser delegate;
/*     */   
/*     */   public JsonParserDelegate(JsonParser d) {
/*  26 */     this.delegate = d;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getCurrentValue() {
/*  31 */     return this.delegate.getCurrentValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setCurrentValue(Object v) {
/*  36 */     this.delegate.setCurrentValue(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCodec(ObjectCodec c) {
/*  45 */     this.delegate.setCodec(c); } public ObjectCodec getCodec() {
/*  46 */     return this.delegate.getCodec();
/*     */   }
/*     */   
/*     */   public JsonParser enable(JsonParser.Feature f) {
/*  50 */     this.delegate.enable(f);
/*  51 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public JsonParser disable(JsonParser.Feature f) {
/*  56 */     this.delegate.disable(f);
/*  57 */     return this;
/*     */   }
/*     */   
/*  60 */   public boolean isEnabled(JsonParser.Feature f) { return this.delegate.isEnabled(f); } public int getFeatureMask() {
/*  61 */     return this.delegate.getFeatureMask();
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public JsonParser setFeatureMask(int mask) {
/*  66 */     this.delegate.setFeatureMask(mask);
/*  67 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public JsonParser overrideStdFeatures(int values, int mask) {
/*  72 */     this.delegate.overrideStdFeatures(values, mask);
/*  73 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public JsonParser overrideFormatFeatures(int values, int mask) {
/*  78 */     this.delegate.overrideFormatFeatures(values, mask);
/*  79 */     return this;
/*     */   }
/*     */   
/*  82 */   public FormatSchema getSchema() { return this.delegate.getSchema(); }
/*  83 */   public void setSchema(FormatSchema schema) { this.delegate.setSchema(schema); }
/*  84 */   public boolean canUseSchema(FormatSchema schema) { return this.delegate.canUseSchema(schema); }
/*  85 */   public Version version() { return this.delegate.version(); } public Object getInputSource() {
/*  86 */     return this.delegate.getInputSource();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean requiresCustomCodec() {
/*  94 */     return this.delegate.requiresCustomCodec();
/*     */   } public JacksonFeatureSet<StreamReadCapability> getReadCapabilities() {
/*  96 */     return this.delegate.getReadCapabilities();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/* 104 */     this.delegate.close(); } public boolean isClosed() {
/* 105 */     return this.delegate.isClosed();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonToken currentToken() {
/* 113 */     return this.delegate.currentToken(); } public int currentTokenId() {
/* 114 */     return this.delegate.currentTokenId();
/*     */   } public JsonToken getCurrentToken() {
/* 116 */     return this.delegate.getCurrentToken();
/*     */   } @Deprecated
/*     */   public int getCurrentTokenId() {
/* 119 */     return this.delegate.getCurrentTokenId();
/*     */   }
/* 121 */   public boolean hasCurrentToken() { return this.delegate.hasCurrentToken(); }
/* 122 */   public boolean hasTokenId(int id) { return this.delegate.hasTokenId(id); } public boolean hasToken(JsonToken t) {
/* 123 */     return this.delegate.hasToken(t);
/*     */   }
/* 125 */   public String getCurrentName() throws IOException { return this.delegate.getCurrentName(); }
/* 126 */   public JsonLocation getCurrentLocation() { return this.delegate.getCurrentLocation(); }
/* 127 */   public JsonStreamContext getParsingContext() { return this.delegate.getParsingContext(); }
/* 128 */   public boolean isExpectedStartArrayToken() { return this.delegate.isExpectedStartArrayToken(); }
/* 129 */   public boolean isExpectedStartObjectToken() { return this.delegate.isExpectedStartObjectToken(); } public boolean isExpectedNumberIntToken() {
/* 130 */     return this.delegate.isExpectedNumberIntToken();
/*     */   } public boolean isNaN() throws IOException {
/* 132 */     return this.delegate.isNaN();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clearCurrentToken() {
/* 140 */     this.delegate.clearCurrentToken();
/* 141 */   } public JsonToken getLastClearedToken() { return this.delegate.getLastClearedToken(); } public void overrideCurrentName(String name) {
/* 142 */     this.delegate.overrideCurrentName(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getText() throws IOException {
/* 150 */     return this.delegate.getText();
/* 151 */   } public boolean hasTextCharacters() { return this.delegate.hasTextCharacters(); }
/* 152 */   public char[] getTextCharacters() throws IOException { return this.delegate.getTextCharacters(); }
/* 153 */   public int getTextLength() throws IOException { return this.delegate.getTextLength(); }
/* 154 */   public int getTextOffset() throws IOException { return this.delegate.getTextOffset(); } public int getText(Writer writer) throws IOException, UnsupportedOperationException {
/* 155 */     return this.delegate.getText(writer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BigInteger getBigIntegerValue() throws IOException {
/* 164 */     return this.delegate.getBigIntegerValue();
/*     */   }
/*     */   public boolean getBooleanValue() throws IOException {
/* 167 */     return this.delegate.getBooleanValue();
/*     */   }
/*     */   public byte getByteValue() throws IOException {
/* 170 */     return this.delegate.getByteValue();
/*     */   }
/*     */   public short getShortValue() throws IOException {
/* 173 */     return this.delegate.getShortValue();
/*     */   }
/*     */   public BigDecimal getDecimalValue() throws IOException {
/* 176 */     return this.delegate.getDecimalValue();
/*     */   }
/*     */   public double getDoubleValue() throws IOException {
/* 179 */     return this.delegate.getDoubleValue();
/*     */   }
/*     */   public float getFloatValue() throws IOException {
/* 182 */     return this.delegate.getFloatValue();
/*     */   }
/*     */   public int getIntValue() throws IOException {
/* 185 */     return this.delegate.getIntValue();
/*     */   }
/*     */   public long getLongValue() throws IOException {
/* 188 */     return this.delegate.getLongValue();
/*     */   }
/*     */   public JsonParser.NumberType getNumberType() throws IOException {
/* 191 */     return this.delegate.getNumberType();
/*     */   }
/*     */   public Number getNumberValue() throws IOException {
/* 194 */     return this.delegate.getNumberValue();
/*     */   }
/*     */   public Number getNumberValueExact() throws IOException {
/* 197 */     return this.delegate.getNumberValueExact();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getValueAsInt() throws IOException {
/* 205 */     return this.delegate.getValueAsInt();
/* 206 */   } public int getValueAsInt(int defaultValue) throws IOException { return this.delegate.getValueAsInt(defaultValue); }
/* 207 */   public long getValueAsLong() throws IOException { return this.delegate.getValueAsLong(); }
/* 208 */   public long getValueAsLong(long defaultValue) throws IOException { return this.delegate.getValueAsLong(defaultValue); }
/* 209 */   public double getValueAsDouble() throws IOException { return this.delegate.getValueAsDouble(); }
/* 210 */   public double getValueAsDouble(double defaultValue) throws IOException { return this.delegate.getValueAsDouble(defaultValue); }
/* 211 */   public boolean getValueAsBoolean() throws IOException { return this.delegate.getValueAsBoolean(); }
/* 212 */   public boolean getValueAsBoolean(boolean defaultValue) throws IOException { return this.delegate.getValueAsBoolean(defaultValue); }
/* 213 */   public String getValueAsString() throws IOException { return this.delegate.getValueAsString(); } public String getValueAsString(String defaultValue) throws IOException {
/* 214 */     return this.delegate.getValueAsString(defaultValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getEmbeddedObject() throws IOException {
/* 222 */     return this.delegate.getEmbeddedObject();
/* 223 */   } public byte[] getBinaryValue(Base64Variant b64variant) throws IOException { return this.delegate.getBinaryValue(b64variant); }
/* 224 */   public int readBinaryValue(Base64Variant b64variant, OutputStream out) throws IOException { return this.delegate.readBinaryValue(b64variant, out); } public JsonLocation getTokenLocation() {
/* 225 */     return this.delegate.getTokenLocation();
/*     */   } public JsonToken nextToken() throws IOException {
/* 227 */     return this.delegate.nextToken();
/*     */   } public JsonToken nextValue() throws IOException {
/* 229 */     return this.delegate.nextValue();
/*     */   } public void finishToken() throws IOException {
/* 231 */     this.delegate.finishToken();
/*     */   }
/*     */   
/*     */   public JsonParser skipChildren() throws IOException {
/* 235 */     this.delegate.skipChildren();
/*     */     
/* 237 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canReadObjectId() {
/* 246 */     return this.delegate.canReadObjectId();
/* 247 */   } public boolean canReadTypeId() { return this.delegate.canReadTypeId(); }
/* 248 */   public Object getObjectId() throws IOException { return this.delegate.getObjectId(); } public Object getTypeId() throws IOException {
/* 249 */     return this.delegate.getTypeId();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonParser delegate() {
/* 264 */     return this.delegate;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-core-2.12.7.jar!\com\fasterxml\jackson\cor\\util\JsonParserDelegate.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */