/*     */ package com.fasterxml.jackson.core.io;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonEncoding;
/*     */ import com.fasterxml.jackson.core.util.BufferRecycler;
/*     */ import com.fasterxml.jackson.core.util.TextBuffer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IOContext
/*     */ {
/*     */   protected final Object _sourceRef;
/*     */   protected JsonEncoding _encoding;
/*     */   protected final boolean _managedResource;
/*     */   protected final BufferRecycler _bufferRecycler;
/*     */   protected byte[] _readIOBuffer;
/*     */   protected byte[] _writeEncodingBuffer;
/*     */   protected byte[] _base64Buffer;
/*     */   protected char[] _tokenCBuffer;
/*     */   protected char[] _concatCBuffer;
/*     */   protected char[] _nameCopyBuffer;
/*     */   
/*     */   public IOContext(BufferRecycler br, Object sourceRef, boolean managedResource) {
/* 103 */     this._bufferRecycler = br;
/* 104 */     this._sourceRef = sourceRef;
/* 105 */     this._managedResource = managedResource;
/*     */   }
/*     */   
/*     */   public void setEncoding(JsonEncoding enc) {
/* 109 */     this._encoding = enc;
/*     */   }
/*     */   
/*     */   public IOContext withEncoding(JsonEncoding enc) {
/* 113 */     this._encoding = enc;
/* 114 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getSourceReference() {
/* 123 */     return this._sourceRef;
/* 124 */   } public JsonEncoding getEncoding() { return this._encoding; } public boolean isResourceManaged() {
/* 125 */     return this._managedResource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TextBuffer constructTextBuffer() {
/* 134 */     return new TextBuffer(this._bufferRecycler);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] allocReadIOBuffer() {
/* 146 */     _verifyAlloc(this._readIOBuffer);
/* 147 */     return this._readIOBuffer = this._bufferRecycler.allocByteBuffer(0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] allocReadIOBuffer(int minSize) {
/* 161 */     _verifyAlloc(this._readIOBuffer);
/* 162 */     return this._readIOBuffer = this._bufferRecycler.allocByteBuffer(0, minSize);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] allocWriteEncodingBuffer() {
/* 174 */     _verifyAlloc(this._writeEncodingBuffer);
/* 175 */     return this._writeEncodingBuffer = this._bufferRecycler.allocByteBuffer(1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] allocWriteEncodingBuffer(int minSize) {
/* 189 */     _verifyAlloc(this._writeEncodingBuffer);
/* 190 */     return this._writeEncodingBuffer = this._bufferRecycler.allocByteBuffer(1, minSize);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] allocBase64Buffer() {
/* 202 */     _verifyAlloc(this._base64Buffer);
/* 203 */     return this._base64Buffer = this._bufferRecycler.allocByteBuffer(3);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] allocBase64Buffer(int minSize) {
/* 217 */     _verifyAlloc(this._base64Buffer);
/* 218 */     return this._base64Buffer = this._bufferRecycler.allocByteBuffer(3, minSize);
/*     */   }
/*     */   
/*     */   public char[] allocTokenBuffer() {
/* 222 */     _verifyAlloc(this._tokenCBuffer);
/* 223 */     return this._tokenCBuffer = this._bufferRecycler.allocCharBuffer(0);
/*     */   }
/*     */ 
/*     */   
/*     */   public char[] allocTokenBuffer(int minSize) {
/* 228 */     _verifyAlloc(this._tokenCBuffer);
/* 229 */     return this._tokenCBuffer = this._bufferRecycler.allocCharBuffer(0, minSize);
/*     */   }
/*     */   
/*     */   public char[] allocConcatBuffer() {
/* 233 */     _verifyAlloc(this._concatCBuffer);
/* 234 */     return this._concatCBuffer = this._bufferRecycler.allocCharBuffer(1);
/*     */   }
/*     */   
/*     */   public char[] allocNameCopyBuffer(int minSize) {
/* 238 */     _verifyAlloc(this._nameCopyBuffer);
/* 239 */     return this._nameCopyBuffer = this._bufferRecycler.allocCharBuffer(3, minSize);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void releaseReadIOBuffer(byte[] buf) {
/* 249 */     if (buf != null) {
/*     */ 
/*     */       
/* 252 */       _verifyRelease(buf, this._readIOBuffer);
/* 253 */       this._readIOBuffer = null;
/* 254 */       this._bufferRecycler.releaseByteBuffer(0, buf);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void releaseWriteEncodingBuffer(byte[] buf) {
/* 259 */     if (buf != null) {
/*     */ 
/*     */       
/* 262 */       _verifyRelease(buf, this._writeEncodingBuffer);
/* 263 */       this._writeEncodingBuffer = null;
/* 264 */       this._bufferRecycler.releaseByteBuffer(1, buf);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void releaseBase64Buffer(byte[] buf) {
/* 269 */     if (buf != null) {
/* 270 */       _verifyRelease(buf, this._base64Buffer);
/* 271 */       this._base64Buffer = null;
/* 272 */       this._bufferRecycler.releaseByteBuffer(3, buf);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void releaseTokenBuffer(char[] buf) {
/* 277 */     if (buf != null) {
/* 278 */       _verifyRelease(buf, this._tokenCBuffer);
/* 279 */       this._tokenCBuffer = null;
/* 280 */       this._bufferRecycler.releaseCharBuffer(0, buf);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void releaseConcatBuffer(char[] buf) {
/* 285 */     if (buf != null) {
/*     */       
/* 287 */       _verifyRelease(buf, this._concatCBuffer);
/* 288 */       this._concatCBuffer = null;
/* 289 */       this._bufferRecycler.releaseCharBuffer(1, buf);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void releaseNameCopyBuffer(char[] buf) {
/* 294 */     if (buf != null) {
/*     */       
/* 296 */       _verifyRelease(buf, this._nameCopyBuffer);
/* 297 */       this._nameCopyBuffer = null;
/* 298 */       this._bufferRecycler.releaseCharBuffer(3, buf);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void _verifyAlloc(Object buffer) {
/* 309 */     if (buffer != null) throw new IllegalStateException("Trying to call same allocXxx() method second time");
/*     */   
/*     */   }
/*     */   
/*     */   protected final void _verifyRelease(byte[] toRelease, byte[] src) {
/* 314 */     if (toRelease != src && toRelease.length < src.length) throw wrongBuf();
/*     */   
/*     */   }
/*     */   
/*     */   protected final void _verifyRelease(char[] toRelease, char[] src) {
/* 319 */     if (toRelease != src && toRelease.length < src.length) throw wrongBuf();
/*     */   
/*     */   }
/*     */   
/*     */   private IllegalArgumentException wrongBuf() {
/* 324 */     return new IllegalArgumentException("Trying to release buffer smaller than original");
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-core-2.12.7.jar!\com\fasterxml\jackson\core\io\IOContext.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */