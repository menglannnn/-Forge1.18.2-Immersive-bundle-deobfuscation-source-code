module com.fasterxml.jackson.core {
  requires java.base;
  
  exports com.fasterxml.jackson.core;
  exports com.fasterxml.jackson.core.async;
  exports com.fasterxml.jackson.core.base;
  exports com.fasterxml.jackson.core.exc;
  exports com.fasterxml.jackson.core.filter;
  exports com.fasterxml.jackson.core.format;
  exports com.fasterxml.jackson.core.io;
  exports com.fasterxml.jackson.core.json;
  exports com.fasterxml.jackson.core.json.async;
  exports com.fasterxml.jackson.core.sym;
  exports com.fasterxml.jackson.core.type;
  exports com.fasterxml.jackson.core.util;
  
  uses com.fasterxml.jackson.core.ObjectCodec;
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-core-2.12.7.jar!\module-info.class
 * Java compiler version: 9 (53.0)
 * JD-Core Version:       1.1.3
 */