/*    */ package discord4j.discordjson.json;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonProperty;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import java.util.List;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ 
/*    */ @JsonSerialize(as = ImmutableGuildMemberAddRequest.class)
/*    */ @JsonDeserialize(as = ImmutableGuildMemberAddRequest.class)
/*    */ @Immutable
/*    */ public interface GuildMemberAddRequest
/*    */ {
/*    */   static ImmutableGuildMemberAddRequest.Builder builder() {
/* 16 */     return ImmutableGuildMemberAddRequest.builder();
/*    */   }
/*    */   
/*    */   @JsonProperty("access_token")
/*    */   String accessToken();
/*    */   
/*    */   String nick();
/*    */   
/*    */   List<String> roles();
/*    */   
/*    */   boolean mute();
/*    */   
/*    */   boolean deaf();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\GuildMemberAddRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */