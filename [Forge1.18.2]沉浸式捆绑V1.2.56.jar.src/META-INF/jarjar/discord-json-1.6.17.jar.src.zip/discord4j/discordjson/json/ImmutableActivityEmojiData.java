/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.Id;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "ActivityEmojiData", generator = "Immutables")
/*     */ public final class ImmutableActivityEmojiData
/*     */   implements ActivityEmojiData
/*     */ {
/*     */   private final String name;
/*     */   private final long id_value;
/*     */   private final boolean id_absent;
/*     */   private final Boolean animated_value;
/*     */   private final boolean animated_absent;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   private volatile transient InitShim initShim;
/*     */   
/*     */   private ImmutableActivityEmojiData(String name, Possible<Id> id, Possible<Boolean> animated) {
/*  68 */     this.initShim = new InitShim(); this.name = Objects.<String>requireNonNull(name, "name"); Possible<Id> id$impl = id; Possible<Boolean> animated$impl = animated; this.id_value = ((Long)id$impl.toOptional().map(Id::asLong).orElse(Long.valueOf(0L))).longValue(); this.id_absent = id$impl.isAbsent(); this.animated_value = animated$impl.toOptional().orElse(null); this.animated_absent = animated$impl.isAbsent(); this.initShim = null; } private ImmutableActivityEmojiData(ImmutableActivityEmojiData original, String name, Possible<Id> id, Possible<Boolean> animated) { this.initShim = new InitShim(); this.name = name; Possible<Id> id$impl = id; Possible<Boolean> animated$impl = animated;
/*     */     this.id_value = ((Long)id$impl.toOptional().map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*     */     this.id_absent = id$impl.isAbsent();
/*     */     this.animated_value = animated$impl.toOptional().orElse(null);
/*     */     this.animated_absent = animated$impl.isAbsent();
/*  73 */     this.initShim = null; } @Generated(from = "ActivityEmojiData", generator = "Immutables") private final class InitShim { private InitShim() {} private String formatInitCycleMessage() { List<String> attributes = new ArrayList<>();
/*  74 */       return "Cannot build ActivityEmojiData, attribute initializers form cycle " + attributes; }
/*     */      }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("name")
/*     */   public String name() {
/*  84 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("id")
/*     */   public Possible<Id> id() {
/*  93 */     return this.id_absent ? Possible.absent() : 
/*  94 */       Possible.of(Id.of(this.id_value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("animated")
/*     */   public Possible<Boolean> animated() {
/* 103 */     return this.animated_absent ? Possible.absent() : Possible.of(this.animated_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableActivityEmojiData withName(String value) {
/* 113 */     String newValue = Objects.<String>requireNonNull(value, "name");
/* 114 */     if (this.name.equals(newValue)) return this; 
/* 115 */     return new ImmutableActivityEmojiData(this, newValue, id(), animated());
/*     */   }
/*     */   
/*     */   public ImmutableActivityEmojiData withId(Possible<Id> value) {
/* 119 */     Possible<Id> newValue = Objects.<Possible<Id>>requireNonNull(value);
/* 120 */     return new ImmutableActivityEmojiData(this, this.name, newValue, animated());
/*     */   }
/*     */   
/*     */   public ImmutableActivityEmojiData withId(long value) {
/* 124 */     Possible<Id> newValue = Possible.of(Id.of(value));
/* 125 */     return new ImmutableActivityEmojiData(this, this.name, newValue, animated());
/*     */   }
/*     */   
/*     */   public ImmutableActivityEmojiData withAnimated(Possible<Boolean> value) {
/* 129 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/* 130 */     return new ImmutableActivityEmojiData(this, this.name, id(), newValue);
/*     */   }
/*     */   
/*     */   public ImmutableActivityEmojiData withAnimated(Boolean value) {
/* 134 */     Possible<Boolean> newValue = Possible.of(value);
/* 135 */     return new ImmutableActivityEmojiData(this, this.name, id(), newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 144 */     if (this == another) return true; 
/* 145 */     return (another instanceof ImmutableActivityEmojiData && 
/* 146 */       equalTo(0, (ImmutableActivityEmojiData)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableActivityEmojiData another) {
/* 150 */     return (this.name.equals(another.name) && 
/* 151 */       id().equals(another.id()) && 
/* 152 */       animated().equals(another.animated()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 161 */     int h = 5381;
/* 162 */     h += (h << 5) + this.name.hashCode();
/* 163 */     h += (h << 5) + id().hashCode();
/* 164 */     h += (h << 5) + animated().hashCode();
/* 165 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 174 */     return "ActivityEmojiData{name=" + this.name + ", id=" + 
/*     */       
/* 176 */       id().toString() + ", animated=" + 
/* 177 */       animated().toString() + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "ActivityEmojiData", generator = "Immutables")
/*     */   static final class Json
/*     */     implements ActivityEmojiData
/*     */   {
/*     */     String name;
/*     */ 
/*     */     
/* 192 */     Possible<Id> id = Possible.absent();
/*     */ 
/*     */     
/* 195 */     Possible<Boolean> animated = Possible.absent();
/*     */     
/*     */     @JsonProperty("name")
/*     */     public void setName(String name) {
/* 199 */       this.name = name;
/*     */     }
/*     */     @JsonProperty("id")
/*     */     public void setId(Possible<Id> id) {
/* 203 */       this.id = id;
/*     */     }
/*     */     @JsonProperty("animated")
/*     */     public void setAnimated(Possible<Boolean> animated) {
/* 207 */       this.animated = animated;
/*     */     }
/*     */     public String name() {
/* 210 */       throw new UnsupportedOperationException();
/*     */     } public Possible<Id> id() {
/* 212 */       throw new UnsupportedOperationException();
/*     */     } public Possible<Boolean> animated() {
/* 214 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableActivityEmojiData fromJson(Json json) {
/* 225 */     Builder builder = builder();
/* 226 */     if (json.name != null) {
/* 227 */       builder.name(json.name);
/*     */     }
/* 229 */     if (json.id != null) {
/* 230 */       builder.id(json.id);
/*     */     }
/* 232 */     if (json.animated != null) {
/* 233 */       builder.animated(json.animated);
/*     */     }
/* 235 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableActivityEmojiData of(String name, Possible<Id> id, Possible<Boolean> animated) {
/* 246 */     return new ImmutableActivityEmojiData(name, id, animated);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableActivityEmojiData copyOf(ActivityEmojiData instance) {
/* 257 */     if (instance instanceof ImmutableActivityEmojiData) {
/* 258 */       return (ImmutableActivityEmojiData)instance;
/*     */     }
/* 260 */     return builder()
/* 261 */       .from(instance)
/* 262 */       .build();
/*     */   }
/*     */   
/*     */   public boolean isIdPresent() {
/* 266 */     return !this.id_absent;
/*     */   }
/*     */   
/*     */   public long idOrElse(long defaultValue) {
/* 270 */     return !this.id_absent ? this.id_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isAnimatedPresent() {
/* 274 */     return !this.animated_absent;
/*     */   }
/*     */   
/*     */   public Boolean animatedOrElse(Boolean defaultValue) {
/* 278 */     return !this.animated_absent ? this.animated_value : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 293 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "ActivityEmojiData", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_NAME = 1L;
/*     */ 
/*     */ 
/*     */     
/* 306 */     private long initBits = 1L;
/*     */     
/* 308 */     private Possible<Id> id_possible = Possible.absent();
/* 309 */     private Possible<Boolean> animated_possible = Possible.absent();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private String name;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(ActivityEmojiData instance) {
/* 323 */       Objects.requireNonNull(instance, "instance");
/* 324 */       name(instance.name());
/* 325 */       id(instance.id());
/* 326 */       animated(instance.animated());
/* 327 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("name")
/*     */     public final Builder name(String name) {
/* 337 */       this.name = Objects.<String>requireNonNull(name, "name");
/* 338 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 339 */       return this;
/*     */     }
/*     */     
/*     */     public Builder id(String value) {
/* 343 */       this.id_possible = Possible.of(Id.of(value));
/* 344 */       return this;
/*     */     }
/*     */     
/*     */     public Builder id(long value) {
/* 348 */       this.id_possible = Possible.of(Id.of(value));
/* 349 */       return this;
/*     */     }
/*     */     
/*     */     public Builder id(Id value) {
/* 353 */       this.id_possible = Possible.of(value);
/* 354 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("id")
/*     */     public Builder id(Possible<Id> value) {
/* 359 */       this.id_possible = value;
/* 360 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("animated")
/*     */     public Builder animated(Possible<Boolean> value) {
/* 365 */       this.animated_possible = value;
/* 366 */       return this;
/*     */     }
/*     */     
/*     */     public Builder animated(Boolean value) {
/* 370 */       this.animated_possible = Possible.of(value);
/* 371 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableActivityEmojiData build() {
/* 380 */       if (this.initBits != 0L) {
/* 381 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 383 */       return new ImmutableActivityEmojiData(null, this.name, id_build(), animated_build());
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 387 */       List<String> attributes = new ArrayList<>();
/* 388 */       if ((this.initBits & 0x1L) != 0L) attributes.add("name"); 
/* 389 */       return "Cannot build ActivityEmojiData, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Possible<Id> id_build() {
/* 393 */       return this.id_possible;
/*     */     }
/*     */     
/*     */     private Possible<Boolean> animated_build() {
/* 397 */       return this.animated_possible;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableActivityEmojiData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */