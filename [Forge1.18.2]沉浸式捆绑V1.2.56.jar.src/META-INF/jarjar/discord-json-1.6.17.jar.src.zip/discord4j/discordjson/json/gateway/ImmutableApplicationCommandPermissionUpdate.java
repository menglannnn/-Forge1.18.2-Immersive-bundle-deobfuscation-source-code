/*     */ package discord4j.discordjson.json.gateway;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.annotation.JsonUnwrapped;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.json.GuildApplicationCommandPermissionsData;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "ApplicationCommandPermissionUpdate", generator = "Immutables")
/*     */ public final class ImmutableApplicationCommandPermissionUpdate
/*     */   implements ApplicationCommandPermissionUpdate
/*     */ {
/*     */   private final GuildApplicationCommandPermissionsData data;
/*     */   
/*     */   private ImmutableApplicationCommandPermissionUpdate(GuildApplicationCommandPermissionsData data) {
/*  30 */     this.data = Objects.<GuildApplicationCommandPermissionsData>requireNonNull(data, "data");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private ImmutableApplicationCommandPermissionUpdate(ImmutableApplicationCommandPermissionUpdate original, GuildApplicationCommandPermissionsData data) {
/*  36 */     this.data = data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("data")
/*     */   @JsonUnwrapped
/*     */   public GuildApplicationCommandPermissionsData data() {
/*  46 */     return this.data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableApplicationCommandPermissionUpdate withData(GuildApplicationCommandPermissionsData value) {
/*  56 */     if (this.data == value) return this; 
/*  57 */     GuildApplicationCommandPermissionsData newValue = Objects.<GuildApplicationCommandPermissionsData>requireNonNull(value, "data");
/*  58 */     return new ImmutableApplicationCommandPermissionUpdate(this, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/*  67 */     if (this == another) return true; 
/*  68 */     return (another instanceof ImmutableApplicationCommandPermissionUpdate && 
/*  69 */       equalTo(0, (ImmutableApplicationCommandPermissionUpdate)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableApplicationCommandPermissionUpdate another) {
/*  73 */     return this.data.equals(another.data);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  82 */     int h = 5381;
/*  83 */     h += (h << 5) + this.data.hashCode();
/*  84 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/*  93 */     return "ApplicationCommandPermissionUpdate{data=" + this.data + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "ApplicationCommandPermissionUpdate", generator = "Immutables")
/*     */   static final class Json
/*     */     implements ApplicationCommandPermissionUpdate
/*     */   {
/*     */     GuildApplicationCommandPermissionsData data;
/*     */ 
/*     */     
/*     */     @JsonProperty("data")
/*     */     @JsonUnwrapped
/*     */     public void setData(GuildApplicationCommandPermissionsData data) {
/* 111 */       this.data = data;
/*     */     }
/*     */     public GuildApplicationCommandPermissionsData data() {
/* 114 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableApplicationCommandPermissionUpdate fromJson(Json json) {
/* 125 */     Builder builder = builder();
/* 126 */     if (json.data != null) {
/* 127 */       builder.data(json.data);
/*     */     }
/* 129 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableApplicationCommandPermissionUpdate of(GuildApplicationCommandPermissionsData data) {
/* 138 */     return new ImmutableApplicationCommandPermissionUpdate(data);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableApplicationCommandPermissionUpdate copyOf(ApplicationCommandPermissionUpdate instance) {
/* 149 */     if (instance instanceof ImmutableApplicationCommandPermissionUpdate) {
/* 150 */       return (ImmutableApplicationCommandPermissionUpdate)instance;
/*     */     }
/* 152 */     return builder()
/* 153 */       .from(instance)
/* 154 */       .build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 167 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "ApplicationCommandPermissionUpdate", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_DATA = 1L;
/*     */ 
/*     */ 
/*     */     
/* 180 */     private long initBits = 1L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private GuildApplicationCommandPermissionsData data;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(ApplicationCommandPermissionUpdate instance) {
/* 195 */       Objects.requireNonNull(instance, "instance");
/* 196 */       data(instance.data());
/* 197 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("data")
/*     */     @JsonUnwrapped
/*     */     public final Builder data(GuildApplicationCommandPermissionsData data) {
/* 208 */       this.data = Objects.<GuildApplicationCommandPermissionsData>requireNonNull(data, "data");
/* 209 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 210 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableApplicationCommandPermissionUpdate build() {
/* 219 */       if (this.initBits != 0L) {
/* 220 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 222 */       return new ImmutableApplicationCommandPermissionUpdate(null, this.data);
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 226 */       List<String> attributes = new ArrayList<>();
/* 227 */       if ((this.initBits & 0x1L) != 0L) attributes.add("data"); 
/* 228 */       return "Cannot build ApplicationCommandPermissionUpdate, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\gateway\ImmutableApplicationCommandPermissionUpdate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */