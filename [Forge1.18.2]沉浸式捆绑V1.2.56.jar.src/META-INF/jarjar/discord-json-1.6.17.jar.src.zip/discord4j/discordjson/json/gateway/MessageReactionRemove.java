/*    */ package discord4j.discordjson.json.gateway;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonProperty;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import discord4j.discordjson.Id;
/*    */ import discord4j.discordjson.json.EmojiData;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ @JsonSerialize(as = ImmutableMessageReactionRemove.class)
/*    */ @JsonDeserialize(as = ImmutableMessageReactionRemove.class)
/*    */ @Immutable
/*    */ public interface MessageReactionRemove
/*    */   extends Dispatch {
/*    */   static ImmutableMessageReactionRemove.Builder builder() {
/* 17 */     return ImmutableMessageReactionRemove.builder();
/*    */   }
/*    */   
/*    */   @JsonProperty("user_id")
/*    */   Id userId();
/*    */   
/*    */   @JsonProperty("channel_id")
/*    */   Id channelId();
/*    */   
/*    */   @JsonProperty("message_id")
/*    */   Id messageId();
/*    */   
/*    */   @JsonProperty("guild_id")
/*    */   Possible<Id> guildId();
/*    */   
/*    */   EmojiData emoji();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\gateway\MessageReactionRemove.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */