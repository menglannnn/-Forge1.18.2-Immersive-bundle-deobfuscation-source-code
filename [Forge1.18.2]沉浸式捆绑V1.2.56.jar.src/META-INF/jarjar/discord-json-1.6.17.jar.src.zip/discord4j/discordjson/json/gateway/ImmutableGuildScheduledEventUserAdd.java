/*     */ package discord4j.discordjson.json.gateway;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.Id;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "GuildScheduledEventUserAdd", generator = "Immutables")
/*     */ public final class ImmutableGuildScheduledEventUserAdd
/*     */   implements GuildScheduledEventUserAdd
/*     */ {
/*     */   private final long scheduledEventId_value;
/*     */   private final long userId_value;
/*     */   private final long guildId_value;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   
/*     */   private ImmutableGuildScheduledEventUserAdd(Id scheduledEventId, Id userId, Id guildId) {
/*  34 */     Id scheduledEventId$impl = scheduledEventId;
/*  35 */     Id userId$impl = userId;
/*  36 */     Id guildId$impl = guildId;
/*  37 */     this.scheduledEventId_value = scheduledEventId$impl.asLong();
/*  38 */     this.userId_value = userId$impl.asLong();
/*  39 */     this.guildId_value = guildId$impl.asLong();
/*  40 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ImmutableGuildScheduledEventUserAdd(ImmutableGuildScheduledEventUserAdd original, Id scheduledEventId, Id userId, Id guildId) {
/*  48 */     Id scheduledEventId$impl = scheduledEventId;
/*  49 */     Id userId$impl = userId;
/*  50 */     Id guildId$impl = guildId;
/*  51 */     this.scheduledEventId_value = scheduledEventId$impl.asLong();
/*  52 */     this.userId_value = userId$impl.asLong();
/*  53 */     this.guildId_value = guildId$impl.asLong();
/*  54 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  60 */   private volatile transient InitShim initShim = new InitShim();
/*     */   
/*     */   @Generated(from = "GuildScheduledEventUserAdd", generator = "Immutables")
/*     */   private final class InitShim {
/*     */     private String formatInitCycleMessage() {
/*  65 */       List<String> attributes = new ArrayList<>();
/*  66 */       return "Cannot build GuildScheduledEventUserAdd, attribute initializers form cycle " + attributes;
/*     */     }
/*     */ 
/*     */     
/*     */     private InitShim() {}
/*     */   }
/*     */ 
/*     */   
/*     */   @JsonProperty("guild_scheduled_event_id")
/*     */   public Id scheduledEventId() {
/*  76 */     return Id.of(this.scheduledEventId_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("user_id")
/*     */   public Id userId() {
/*  85 */     return Id.of(this.userId_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("guild_id")
/*     */   public Id guildId() {
/*  94 */     return Id.of(this.guildId_value);
/*     */   }
/*     */   
/*     */   public ImmutableGuildScheduledEventUserAdd withScheduledEventId(long value) {
/*  98 */     Id newValue = Id.of(value);
/*  99 */     return new ImmutableGuildScheduledEventUserAdd(this, newValue, userId(), guildId());
/*     */   }
/*     */   
/*     */   public ImmutableGuildScheduledEventUserAdd withScheduledEventId(String value) {
/* 103 */     Id newValue = Id.of(value);
/* 104 */     return new ImmutableGuildScheduledEventUserAdd(this, newValue, userId(), guildId());
/*     */   }
/*     */   
/*     */   public ImmutableGuildScheduledEventUserAdd withUserId(long value) {
/* 108 */     Id newValue = Id.of(value);
/* 109 */     return new ImmutableGuildScheduledEventUserAdd(this, scheduledEventId(), newValue, guildId());
/*     */   }
/*     */   
/*     */   public ImmutableGuildScheduledEventUserAdd withUserId(String value) {
/* 113 */     Id newValue = Id.of(value);
/* 114 */     return new ImmutableGuildScheduledEventUserAdd(this, scheduledEventId(), newValue, guildId());
/*     */   }
/*     */   
/*     */   public ImmutableGuildScheduledEventUserAdd withGuildId(long value) {
/* 118 */     Id newValue = Id.of(value);
/* 119 */     return new ImmutableGuildScheduledEventUserAdd(this, scheduledEventId(), userId(), newValue);
/*     */   }
/*     */   
/*     */   public ImmutableGuildScheduledEventUserAdd withGuildId(String value) {
/* 123 */     Id newValue = Id.of(value);
/* 124 */     return new ImmutableGuildScheduledEventUserAdd(this, scheduledEventId(), userId(), newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 133 */     if (this == another) return true; 
/* 134 */     return (another instanceof ImmutableGuildScheduledEventUserAdd && 
/* 135 */       equalTo(0, (ImmutableGuildScheduledEventUserAdd)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableGuildScheduledEventUserAdd another) {
/* 139 */     return (Objects.equals(Long.valueOf(this.scheduledEventId_value), Long.valueOf(another.scheduledEventId_value)) && 
/* 140 */       Objects.equals(Long.valueOf(this.userId_value), Long.valueOf(another.userId_value)) && 
/* 141 */       Objects.equals(Long.valueOf(this.guildId_value), Long.valueOf(another.guildId_value)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 150 */     int h = 5381;
/* 151 */     h += (h << 5) + Objects.hashCode(Long.valueOf(this.scheduledEventId_value));
/* 152 */     h += (h << 5) + Objects.hashCode(Long.valueOf(this.userId_value));
/* 153 */     h += (h << 5) + Objects.hashCode(Long.valueOf(this.guildId_value));
/* 154 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 163 */     return "GuildScheduledEventUserAdd{scheduledEventId=" + 
/* 164 */       Objects.toString(Long.valueOf(this.scheduledEventId_value)) + ", userId=" + 
/* 165 */       Objects.toString(Long.valueOf(this.userId_value)) + ", guildId=" + 
/* 166 */       Objects.toString(Long.valueOf(this.guildId_value)) + "}";
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "GuildScheduledEventUserAdd", generator = "Immutables")
/*     */   static final class Json
/*     */     implements GuildScheduledEventUserAdd
/*     */   {
/*     */     Id scheduledEventId;
/*     */     
/*     */     Id userId;
/*     */     Id guildId;
/*     */     
/*     */     @JsonProperty("guild_scheduled_event_id")
/*     */     public void setScheduledEventId(Id scheduledEventId) {
/* 184 */       this.scheduledEventId = scheduledEventId;
/*     */     }
/*     */     @JsonProperty("user_id")
/*     */     public void setUserId(Id userId) {
/* 188 */       this.userId = userId;
/*     */     }
/*     */     @JsonProperty("guild_id")
/*     */     public void setGuildId(Id guildId) {
/* 192 */       this.guildId = guildId;
/*     */     }
/*     */     public Id scheduledEventId() {
/* 195 */       throw new UnsupportedOperationException();
/*     */     } public Id userId() {
/* 197 */       throw new UnsupportedOperationException();
/*     */     } public Id guildId() {
/* 199 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableGuildScheduledEventUserAdd fromJson(Json json) {
/* 210 */     Builder builder = builder();
/* 211 */     if (json.scheduledEventId != null) {
/* 212 */       builder.scheduledEventId(json.scheduledEventId);
/*     */     }
/* 214 */     if (json.userId != null) {
/* 215 */       builder.userId(json.userId);
/*     */     }
/* 217 */     if (json.guildId != null) {
/* 218 */       builder.guildId(json.guildId);
/*     */     }
/* 220 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableGuildScheduledEventUserAdd of(Id scheduledEventId, Id userId, Id guildId) {
/* 231 */     return new ImmutableGuildScheduledEventUserAdd(scheduledEventId, userId, guildId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableGuildScheduledEventUserAdd copyOf(GuildScheduledEventUserAdd instance) {
/* 242 */     if (instance instanceof ImmutableGuildScheduledEventUserAdd) {
/* 243 */       return (ImmutableGuildScheduledEventUserAdd)instance;
/*     */     }
/* 245 */     return builder()
/* 246 */       .from(instance)
/* 247 */       .build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 262 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "GuildScheduledEventUserAdd", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/* 274 */     private Id scheduledEventId_id = null;
/* 275 */     private Id userId_id = null;
/* 276 */     private Id guildId_id = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(GuildScheduledEventUserAdd instance) {
/* 289 */       Objects.requireNonNull(instance, "instance");
/* 290 */       scheduledEventId(instance.scheduledEventId());
/* 291 */       userId(instance.userId());
/* 292 */       guildId(instance.guildId());
/* 293 */       return this;
/*     */     }
/*     */     
/*     */     public Builder scheduledEventId(String value) {
/* 297 */       this.scheduledEventId_id = Id.of(value);
/* 298 */       return this;
/*     */     }
/*     */     
/*     */     public Builder scheduledEventId(long value) {
/* 302 */       this.scheduledEventId_id = Id.of(value);
/* 303 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("guild_scheduled_event_id")
/*     */     public Builder scheduledEventId(Id value) {
/* 308 */       this.scheduledEventId_id = value;
/* 309 */       return this;
/*     */     }
/*     */     
/*     */     public Builder userId(String value) {
/* 313 */       this.userId_id = Id.of(value);
/* 314 */       return this;
/*     */     }
/*     */     
/*     */     public Builder userId(long value) {
/* 318 */       this.userId_id = Id.of(value);
/* 319 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("user_id")
/*     */     public Builder userId(Id value) {
/* 324 */       this.userId_id = value;
/* 325 */       return this;
/*     */     }
/*     */     
/*     */     public Builder guildId(String value) {
/* 329 */       this.guildId_id = Id.of(value);
/* 330 */       return this;
/*     */     }
/*     */     
/*     */     public Builder guildId(long value) {
/* 334 */       this.guildId_id = Id.of(value);
/* 335 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("guild_id")
/*     */     public Builder guildId(Id value) {
/* 340 */       this.guildId_id = value;
/* 341 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableGuildScheduledEventUserAdd build() {
/* 350 */       return new ImmutableGuildScheduledEventUserAdd(null, scheduledEventId_build(), userId_build(), guildId_build());
/*     */     }
/*     */     
/*     */     private Id scheduledEventId_build() {
/* 354 */       return this.scheduledEventId_id;
/*     */     }
/*     */     
/*     */     private Id userId_build() {
/* 358 */       return this.userId_id;
/*     */     }
/*     */     
/*     */     private Id guildId_build() {
/* 362 */       return this.guildId_id;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\gateway\ImmutableGuildScheduledEventUserAdd.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */