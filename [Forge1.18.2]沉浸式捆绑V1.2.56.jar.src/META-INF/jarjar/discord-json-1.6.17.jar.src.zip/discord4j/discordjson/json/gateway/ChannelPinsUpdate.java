/*    */ package discord4j.discordjson.json.gateway;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonProperty;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import discord4j.discordjson.Id;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import java.util.Optional;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ @JsonSerialize(as = ImmutableChannelPinsUpdate.class)
/*    */ @JsonDeserialize(as = ImmutableChannelPinsUpdate.class)
/*    */ @Immutable
/*    */ public interface ChannelPinsUpdate
/*    */   extends Dispatch
/*    */ {
/*    */   static ImmutableChannelPinsUpdate.Builder builder() {
/* 18 */     return ImmutableChannelPinsUpdate.builder();
/*    */   }
/*    */   
/*    */   @JsonProperty("guild_id")
/*    */   Possible<Id> guildId();
/*    */   
/*    */   @JsonProperty("channel_id")
/*    */   Id channelId();
/*    */   
/*    */   @JsonProperty("last_pin_timestamp")
/*    */   Possible<Optional<String>> lastPinTimestamp();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\gateway\ChannelPinsUpdate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */