/*    */ package discord4j.discordjson.json.gateway;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonProperty;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import discord4j.discordjson.Id;
/*    */ import discord4j.discordjson.json.ActivityData;
/*    */ import discord4j.discordjson.json.ClientStatusData;
/*    */ import discord4j.discordjson.json.PartialUserData;
/*    */ import java.util.List;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ 
/*    */ 
/*    */ @JsonSerialize(as = ImmutablePresenceUpdate.class)
/*    */ @JsonDeserialize(as = ImmutablePresenceUpdate.class)
/*    */ @Immutable
/*    */ public interface PresenceUpdate
/*    */   extends Dispatch
/*    */ {
/*    */   static ImmutablePresenceUpdate.Builder builder() {
/* 22 */     return ImmutablePresenceUpdate.builder();
/*    */   }
/*    */   
/*    */   PartialUserData user();
/*    */   
/*    */   @JsonProperty("guild_id")
/*    */   Id guildId();
/*    */   
/*    */   String status();
/*    */   
/*    */   List<ActivityData> activities();
/*    */   
/*    */   @JsonProperty("client_status")
/*    */   ClientStatusData clientStatus();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\gateway\PresenceUpdate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */