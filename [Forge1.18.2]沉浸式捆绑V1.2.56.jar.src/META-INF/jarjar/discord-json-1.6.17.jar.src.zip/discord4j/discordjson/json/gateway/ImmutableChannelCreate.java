/*     */ package discord4j.discordjson.json.gateway;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.annotation.JsonUnwrapped;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.json.ChannelData;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "ChannelCreate", generator = "Immutables")
/*     */ public final class ImmutableChannelCreate
/*     */   implements ChannelCreate
/*     */ {
/*     */   private final ChannelData channel;
/*     */   
/*     */   private ImmutableChannelCreate(ChannelData channel) {
/*  29 */     this.channel = Objects.<ChannelData>requireNonNull(channel, "channel");
/*     */   }
/*     */   
/*     */   private ImmutableChannelCreate(ImmutableChannelCreate original, ChannelData channel) {
/*  33 */     this.channel = channel;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("channel")
/*     */   @JsonUnwrapped
/*     */   public ChannelData channel() {
/*  43 */     return this.channel;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableChannelCreate withChannel(ChannelData value) {
/*  53 */     if (this.channel == value) return this; 
/*  54 */     ChannelData newValue = Objects.<ChannelData>requireNonNull(value, "channel");
/*  55 */     return new ImmutableChannelCreate(this, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/*  64 */     if (this == another) return true; 
/*  65 */     return (another instanceof ImmutableChannelCreate && 
/*  66 */       equalTo(0, (ImmutableChannelCreate)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableChannelCreate another) {
/*  70 */     return this.channel.equals(another.channel);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  79 */     int h = 5381;
/*  80 */     h += (h << 5) + this.channel.hashCode();
/*  81 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/*  90 */     return "ChannelCreate{channel=" + this.channel + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "ChannelCreate", generator = "Immutables")
/*     */   static final class Json
/*     */     implements ChannelCreate
/*     */   {
/*     */     ChannelData channel;
/*     */ 
/*     */     
/*     */     @JsonProperty("channel")
/*     */     @JsonUnwrapped
/*     */     public void setChannel(ChannelData channel) {
/* 108 */       this.channel = channel;
/*     */     }
/*     */     public ChannelData channel() {
/* 111 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableChannelCreate fromJson(Json json) {
/* 122 */     Builder builder = builder();
/* 123 */     if (json.channel != null) {
/* 124 */       builder.channel(json.channel);
/*     */     }
/* 126 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableChannelCreate of(ChannelData channel) {
/* 135 */     return new ImmutableChannelCreate(channel);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableChannelCreate copyOf(ChannelCreate instance) {
/* 146 */     if (instance instanceof ImmutableChannelCreate) {
/* 147 */       return (ImmutableChannelCreate)instance;
/*     */     }
/* 149 */     return builder()
/* 150 */       .from(instance)
/* 151 */       .build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 164 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "ChannelCreate", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_CHANNEL = 1L;
/*     */ 
/*     */ 
/*     */     
/* 177 */     private long initBits = 1L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private ChannelData channel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(ChannelCreate instance) {
/* 192 */       Objects.requireNonNull(instance, "instance");
/* 193 */       channel(instance.channel());
/* 194 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("channel")
/*     */     @JsonUnwrapped
/*     */     public final Builder channel(ChannelData channel) {
/* 205 */       this.channel = Objects.<ChannelData>requireNonNull(channel, "channel");
/* 206 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 207 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableChannelCreate build() {
/* 216 */       if (this.initBits != 0L) {
/* 217 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 219 */       return new ImmutableChannelCreate(null, this.channel);
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 223 */       List<String> attributes = new ArrayList<>();
/* 224 */       if ((this.initBits & 0x1L) != 0L) attributes.add("channel"); 
/* 225 */       return "Cannot build ChannelCreate, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\gateway\ImmutableChannelCreate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */