/*     */ package discord4j.discordjson.json.gateway;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.Id;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "VoiceStateUpdate", generator = "Immutables")
/*     */ public final class ImmutableVoiceStateUpdate
/*     */   implements VoiceStateUpdate
/*     */ {
/*     */   private final long guildId_value;
/*     */   private final long channelId_value;
/*     */   private final boolean channelId_present;
/*     */   private final boolean selfMute;
/*     */   private final boolean selfDeaf;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   
/*     */   private ImmutableVoiceStateUpdate(Id guildId, Optional<Id> channelId, boolean selfMute, boolean selfDeaf) {
/*  37 */     Id guildId$impl = guildId;
/*  38 */     Optional<Id> channelId$impl = channelId;
/*  39 */     this.selfMute = selfMute;
/*  40 */     this.selfDeaf = selfDeaf;
/*  41 */     this.guildId_value = guildId$impl.asLong();
/*  42 */     this
/*     */       
/*  44 */       .channelId_value = ((Long)channelId$impl.<Long>map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  45 */     this.channelId_present = channelId$impl.isPresent();
/*  46 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ImmutableVoiceStateUpdate(ImmutableVoiceStateUpdate original, Id guildId, Optional<Id> channelId, boolean selfMute, boolean selfDeaf) {
/*  55 */     Id guildId$impl = guildId;
/*  56 */     Optional<Id> channelId$impl = channelId;
/*  57 */     this.selfMute = selfMute;
/*  58 */     this.selfDeaf = selfDeaf;
/*  59 */     this.guildId_value = guildId$impl.asLong();
/*  60 */     this
/*     */       
/*  62 */       .channelId_value = ((Long)channelId$impl.<Long>map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  63 */     this.channelId_present = channelId$impl.isPresent();
/*  64 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  70 */   private volatile transient InitShim initShim = new InitShim();
/*     */   
/*     */   @Generated(from = "VoiceStateUpdate", generator = "Immutables")
/*     */   private final class InitShim {
/*     */     private String formatInitCycleMessage() {
/*  75 */       List<String> attributes = new ArrayList<>();
/*  76 */       return "Cannot build VoiceStateUpdate, attribute initializers form cycle " + attributes;
/*     */     }
/*     */ 
/*     */     
/*     */     private InitShim() {}
/*     */   }
/*     */ 
/*     */   
/*     */   @JsonProperty("guild_id")
/*     */   public Id guildId() {
/*  86 */     return Id.of(this.guildId_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("channel_id")
/*     */   public Optional<Id> channelId() {
/*  95 */     return this.channelId_present ? Optional.<Id>of(Id.of(this.channelId_value)) : Optional.<Id>empty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("self_mute")
/*     */   public boolean selfMute() {
/* 104 */     return this.selfMute;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("self_deaf")
/*     */   public boolean selfDeaf() {
/* 113 */     return this.selfDeaf;
/*     */   }
/*     */   
/*     */   public ImmutableVoiceStateUpdate withGuildId(long value) {
/* 117 */     Id newValue = Id.of(value);
/* 118 */     return new ImmutableVoiceStateUpdate(this, newValue, channelId(), this.selfMute, this.selfDeaf);
/*     */   }
/*     */   
/*     */   public ImmutableVoiceStateUpdate withGuildId(String value) {
/* 122 */     Id newValue = Id.of(value);
/* 123 */     return new ImmutableVoiceStateUpdate(this, newValue, channelId(), this.selfMute, this.selfDeaf);
/*     */   }
/*     */   
/*     */   public ImmutableVoiceStateUpdate withChannelId(Optional<Id> value) {
/* 127 */     Optional<Id> newValue = Objects.<Optional<Id>>requireNonNull(value);
/* 128 */     return new ImmutableVoiceStateUpdate(this, guildId(), newValue, this.selfMute, this.selfDeaf);
/*     */   }
/*     */   
/*     */   public ImmutableVoiceStateUpdate withChannelId(long value) {
/* 132 */     Optional<Id> newValue = Optional.of(Id.of(value));
/* 133 */     return new ImmutableVoiceStateUpdate(this, guildId(), newValue, this.selfMute, this.selfDeaf);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableVoiceStateUpdate withSelfMute(boolean value) {
/* 143 */     if (this.selfMute == value) return this; 
/* 144 */     return new ImmutableVoiceStateUpdate(this, guildId(), channelId(), value, this.selfDeaf);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableVoiceStateUpdate withSelfDeaf(boolean value) {
/* 154 */     if (this.selfDeaf == value) return this; 
/* 155 */     return new ImmutableVoiceStateUpdate(this, guildId(), channelId(), this.selfMute, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 164 */     if (this == another) return true; 
/* 165 */     return (another instanceof ImmutableVoiceStateUpdate && 
/* 166 */       equalTo(0, (ImmutableVoiceStateUpdate)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableVoiceStateUpdate another) {
/* 170 */     return (Objects.equals(Long.valueOf(this.guildId_value), Long.valueOf(another.guildId_value)) && 
/* 171 */       channelId().equals(another.channelId()) && this.selfMute == another.selfMute && this.selfDeaf == another.selfDeaf);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 182 */     int h = 5381;
/* 183 */     h += (h << 5) + Objects.hashCode(Long.valueOf(this.guildId_value));
/* 184 */     h += (h << 5) + channelId().hashCode();
/* 185 */     h += (h << 5) + Boolean.hashCode(this.selfMute);
/* 186 */     h += (h << 5) + Boolean.hashCode(this.selfDeaf);
/* 187 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 196 */     return "VoiceStateUpdate{guildId=" + 
/* 197 */       Objects.toString(Long.valueOf(this.guildId_value)) + ", channelId=" + 
/* 198 */       channelId().toString() + ", selfMute=" + this.selfMute + ", selfDeaf=" + this.selfDeaf + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "VoiceStateUpdate", generator = "Immutables")
/*     */   static final class Json
/*     */     implements VoiceStateUpdate
/*     */   {
/*     */     Id guildId;
/*     */ 
/*     */ 
/*     */     
/* 215 */     Optional<Id> channelId = Optional.empty();
/*     */     boolean selfMute;
/*     */     boolean selfMuteIsSet;
/*     */     boolean selfDeaf;
/*     */     boolean selfDeafIsSet;
/*     */     
/*     */     @JsonProperty("guild_id")
/*     */     public void setGuildId(Id guildId) {
/* 223 */       this.guildId = guildId;
/*     */     }
/*     */     @JsonProperty("channel_id")
/*     */     public void setChannelId(Optional<Id> channelId) {
/* 227 */       this.channelId = channelId;
/*     */     }
/*     */     @JsonProperty("self_mute")
/*     */     public void setSelfMute(boolean selfMute) {
/* 231 */       this.selfMute = selfMute;
/* 232 */       this.selfMuteIsSet = true;
/*     */     }
/*     */     @JsonProperty("self_deaf")
/*     */     public void setSelfDeaf(boolean selfDeaf) {
/* 236 */       this.selfDeaf = selfDeaf;
/* 237 */       this.selfDeafIsSet = true;
/*     */     }
/*     */     public Id guildId() {
/* 240 */       throw new UnsupportedOperationException();
/*     */     } public Optional<Id> channelId() {
/* 242 */       throw new UnsupportedOperationException();
/*     */     } public boolean selfMute() {
/* 244 */       throw new UnsupportedOperationException();
/*     */     } public boolean selfDeaf() {
/* 246 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableVoiceStateUpdate fromJson(Json json) {
/* 257 */     Builder builder = builder();
/* 258 */     if (json.guildId != null) {
/* 259 */       builder.guildId(json.guildId);
/*     */     }
/* 261 */     if (json.channelId != null) {
/* 262 */       builder.channelId(json.channelId);
/*     */     }
/* 264 */     if (json.selfMuteIsSet) {
/* 265 */       builder.selfMute(json.selfMute);
/*     */     }
/* 267 */     if (json.selfDeafIsSet) {
/* 268 */       builder.selfDeaf(json.selfDeaf);
/*     */     }
/* 270 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableVoiceStateUpdate of(Id guildId, Optional<Id> channelId, boolean selfMute, boolean selfDeaf) {
/* 282 */     return new ImmutableVoiceStateUpdate(guildId, channelId, selfMute, selfDeaf);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableVoiceStateUpdate copyOf(VoiceStateUpdate instance) {
/* 293 */     if (instance instanceof ImmutableVoiceStateUpdate) {
/* 294 */       return (ImmutableVoiceStateUpdate)instance;
/*     */     }
/* 296 */     return builder()
/* 297 */       .from(instance)
/* 298 */       .build();
/*     */   }
/*     */   
/*     */   public boolean isChannelIdPresent() {
/* 302 */     return this.channelId_present;
/*     */   }
/*     */   
/*     */   public long channelIdOrElse(long defaultValue) {
/* 306 */     return this.channelId_present ? this.channelId_value : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 322 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "VoiceStateUpdate", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_SELF_MUTE = 1L;
/*     */ 
/*     */     
/*     */     private static final long INIT_BIT_SELF_DEAF = 2L;
/*     */ 
/*     */     
/* 336 */     private long initBits = 3L;
/*     */     
/* 338 */     private Id guildId_id = null;
/* 339 */     private Optional<Id> channelId_optional = Optional.empty();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private boolean selfMute;
/*     */ 
/*     */ 
/*     */     
/*     */     private boolean selfDeaf;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(VoiceStateUpdate instance) {
/* 354 */       Objects.requireNonNull(instance, "instance");
/* 355 */       guildId(instance.guildId());
/* 356 */       channelId(instance.channelId());
/* 357 */       selfMute(instance.selfMute());
/* 358 */       selfDeaf(instance.selfDeaf());
/* 359 */       return this;
/*     */     }
/*     */     
/*     */     public Builder guildId(String value) {
/* 363 */       this.guildId_id = Id.of(value);
/* 364 */       return this;
/*     */     }
/*     */     
/*     */     public Builder guildId(long value) {
/* 368 */       this.guildId_id = Id.of(value);
/* 369 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("guild_id")
/*     */     public Builder guildId(Id value) {
/* 374 */       this.guildId_id = value;
/* 375 */       return this;
/*     */     }
/*     */     
/*     */     public Builder channelId(String value) {
/* 379 */       this.channelId_optional = Optional.of(Id.of(value));
/* 380 */       return this;
/*     */     }
/*     */     
/*     */     public Builder channelId(long value) {
/* 384 */       this.channelId_optional = Optional.of(Id.of(value));
/* 385 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("channel_id")
/*     */     public Builder channelId(Optional<Id> value) {
/* 390 */       this.channelId_optional = value;
/* 391 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("self_mute")
/*     */     public final Builder selfMute(boolean selfMute) {
/* 401 */       this.selfMute = selfMute;
/* 402 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 403 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("self_deaf")
/*     */     public final Builder selfDeaf(boolean selfDeaf) {
/* 413 */       this.selfDeaf = selfDeaf;
/* 414 */       this.initBits &= 0xFFFFFFFFFFFFFFFDL;
/* 415 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableVoiceStateUpdate build() {
/* 424 */       if (this.initBits != 0L) {
/* 425 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 427 */       return new ImmutableVoiceStateUpdate(null, guildId_build(), channelId_build(), this.selfMute, this.selfDeaf);
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 431 */       List<String> attributes = new ArrayList<>();
/* 432 */       if ((this.initBits & 0x1L) != 0L) attributes.add("selfMute"); 
/* 433 */       if ((this.initBits & 0x2L) != 0L) attributes.add("selfDeaf"); 
/* 434 */       return "Cannot build VoiceStateUpdate, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Id guildId_build() {
/* 438 */       return this.guildId_id;
/*     */     }
/*     */     
/*     */     private Optional<Id> channelId_build() {
/* 442 */       return this.channelId_optional;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\gateway\ImmutableVoiceStateUpdate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */