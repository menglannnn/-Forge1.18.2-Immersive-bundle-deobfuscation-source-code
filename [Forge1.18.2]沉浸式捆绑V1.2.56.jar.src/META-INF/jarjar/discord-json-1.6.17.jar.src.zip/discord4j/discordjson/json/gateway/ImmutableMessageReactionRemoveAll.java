/*     */ package discord4j.discordjson.json.gateway;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.Id;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "MessageReactionRemoveAll", generator = "Immutables")
/*     */ public final class ImmutableMessageReactionRemoveAll
/*     */   implements MessageReactionRemoveAll
/*     */ {
/*     */   private final long channelId_value;
/*     */   private final long messageId_value;
/*     */   private final long guildId_value;
/*     */   private final boolean guildId_absent;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   
/*     */   private ImmutableMessageReactionRemoveAll(Id channelId, Id messageId, Possible<Id> guildId) {
/*  36 */     Id channelId$impl = channelId;
/*  37 */     Id messageId$impl = messageId;
/*  38 */     Possible<Id> guildId$impl = guildId;
/*  39 */     this.channelId_value = channelId$impl.asLong();
/*  40 */     this.messageId_value = messageId$impl.asLong();
/*  41 */     this
/*     */       
/*  43 */       .guildId_value = ((Long)guildId$impl.toOptional().map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  44 */     this.guildId_absent = guildId$impl.isAbsent();
/*  45 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ImmutableMessageReactionRemoveAll(ImmutableMessageReactionRemoveAll original, Id channelId, Id messageId, Possible<Id> guildId) {
/*  53 */     Id channelId$impl = channelId;
/*  54 */     Id messageId$impl = messageId;
/*  55 */     Possible<Id> guildId$impl = guildId;
/*  56 */     this.channelId_value = channelId$impl.asLong();
/*  57 */     this.messageId_value = messageId$impl.asLong();
/*  58 */     this
/*     */       
/*  60 */       .guildId_value = ((Long)guildId$impl.toOptional().map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  61 */     this.guildId_absent = guildId$impl.isAbsent();
/*  62 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  68 */   private volatile transient InitShim initShim = new InitShim();
/*     */   
/*     */   @Generated(from = "MessageReactionRemoveAll", generator = "Immutables")
/*     */   private final class InitShim {
/*     */     private String formatInitCycleMessage() {
/*  73 */       List<String> attributes = new ArrayList<>();
/*  74 */       return "Cannot build MessageReactionRemoveAll, attribute initializers form cycle " + attributes;
/*     */     }
/*     */ 
/*     */     
/*     */     private InitShim() {}
/*     */   }
/*     */ 
/*     */   
/*     */   @JsonProperty("channel_id")
/*     */   public Id channelId() {
/*  84 */     return Id.of(this.channelId_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("message_id")
/*     */   public Id messageId() {
/*  93 */     return Id.of(this.messageId_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("guild_id")
/*     */   public Possible<Id> guildId() {
/* 102 */     return this.guildId_absent ? Possible.absent() : 
/* 103 */       Possible.of(Id.of(this.guildId_value));
/*     */   }
/*     */   
/*     */   public ImmutableMessageReactionRemoveAll withChannelId(long value) {
/* 107 */     Id newValue = Id.of(value);
/* 108 */     return new ImmutableMessageReactionRemoveAll(this, newValue, messageId(), guildId());
/*     */   }
/*     */   
/*     */   public ImmutableMessageReactionRemoveAll withChannelId(String value) {
/* 112 */     Id newValue = Id.of(value);
/* 113 */     return new ImmutableMessageReactionRemoveAll(this, newValue, messageId(), guildId());
/*     */   }
/*     */   
/*     */   public ImmutableMessageReactionRemoveAll withMessageId(long value) {
/* 117 */     Id newValue = Id.of(value);
/* 118 */     return new ImmutableMessageReactionRemoveAll(this, channelId(), newValue, guildId());
/*     */   }
/*     */   
/*     */   public ImmutableMessageReactionRemoveAll withMessageId(String value) {
/* 122 */     Id newValue = Id.of(value);
/* 123 */     return new ImmutableMessageReactionRemoveAll(this, channelId(), newValue, guildId());
/*     */   }
/*     */   
/*     */   public ImmutableMessageReactionRemoveAll withGuildId(Possible<Id> value) {
/* 127 */     Possible<Id> newValue = Objects.<Possible<Id>>requireNonNull(value);
/* 128 */     return new ImmutableMessageReactionRemoveAll(this, channelId(), messageId(), newValue);
/*     */   }
/*     */   
/*     */   public ImmutableMessageReactionRemoveAll withGuildId(long value) {
/* 132 */     Possible<Id> newValue = Possible.of(Id.of(value));
/* 133 */     return new ImmutableMessageReactionRemoveAll(this, channelId(), messageId(), newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 142 */     if (this == another) return true; 
/* 143 */     return (another instanceof ImmutableMessageReactionRemoveAll && 
/* 144 */       equalTo(0, (ImmutableMessageReactionRemoveAll)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableMessageReactionRemoveAll another) {
/* 148 */     return (Objects.equals(Long.valueOf(this.channelId_value), Long.valueOf(another.channelId_value)) && 
/* 149 */       Objects.equals(Long.valueOf(this.messageId_value), Long.valueOf(another.messageId_value)) && 
/* 150 */       guildId().equals(another.guildId()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 159 */     int h = 5381;
/* 160 */     h += (h << 5) + Objects.hashCode(Long.valueOf(this.channelId_value));
/* 161 */     h += (h << 5) + Objects.hashCode(Long.valueOf(this.messageId_value));
/* 162 */     h += (h << 5) + guildId().hashCode();
/* 163 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 172 */     return "MessageReactionRemoveAll{channelId=" + 
/* 173 */       Objects.toString(Long.valueOf(this.channelId_value)) + ", messageId=" + 
/* 174 */       Objects.toString(Long.valueOf(this.messageId_value)) + ", guildId=" + 
/* 175 */       guildId().toString() + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "MessageReactionRemoveAll", generator = "Immutables")
/*     */   static final class Json
/*     */     implements MessageReactionRemoveAll
/*     */   {
/*     */     Id channelId;
/*     */     
/*     */     Id messageId;
/*     */     
/* 191 */     Possible<Id> guildId = Possible.absent();
/*     */     
/*     */     @JsonProperty("channel_id")
/*     */     public void setChannelId(Id channelId) {
/* 195 */       this.channelId = channelId;
/*     */     }
/*     */     @JsonProperty("message_id")
/*     */     public void setMessageId(Id messageId) {
/* 199 */       this.messageId = messageId;
/*     */     }
/*     */     @JsonProperty("guild_id")
/*     */     public void setGuildId(Possible<Id> guildId) {
/* 203 */       this.guildId = guildId;
/*     */     }
/*     */     public Id channelId() {
/* 206 */       throw new UnsupportedOperationException();
/*     */     } public Id messageId() {
/* 208 */       throw new UnsupportedOperationException();
/*     */     } public Possible<Id> guildId() {
/* 210 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableMessageReactionRemoveAll fromJson(Json json) {
/* 221 */     Builder builder = builder();
/* 222 */     if (json.channelId != null) {
/* 223 */       builder.channelId(json.channelId);
/*     */     }
/* 225 */     if (json.messageId != null) {
/* 226 */       builder.messageId(json.messageId);
/*     */     }
/* 228 */     if (json.guildId != null) {
/* 229 */       builder.guildId(json.guildId);
/*     */     }
/* 231 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableMessageReactionRemoveAll of(Id channelId, Id messageId, Possible<Id> guildId) {
/* 242 */     return new ImmutableMessageReactionRemoveAll(channelId, messageId, guildId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableMessageReactionRemoveAll copyOf(MessageReactionRemoveAll instance) {
/* 253 */     if (instance instanceof ImmutableMessageReactionRemoveAll) {
/* 254 */       return (ImmutableMessageReactionRemoveAll)instance;
/*     */     }
/* 256 */     return builder()
/* 257 */       .from(instance)
/* 258 */       .build();
/*     */   }
/*     */   
/*     */   public boolean isGuildIdPresent() {
/* 262 */     return !this.guildId_absent;
/*     */   }
/*     */   
/*     */   public long guildIdOrElse(long defaultValue) {
/* 266 */     return !this.guildId_absent ? this.guildId_value : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 281 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "MessageReactionRemoveAll", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/* 293 */     private Id channelId_id = null;
/* 294 */     private Id messageId_id = null;
/* 295 */     private Possible<Id> guildId_possible = Possible.absent();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(MessageReactionRemoveAll instance) {
/* 308 */       Objects.requireNonNull(instance, "instance");
/* 309 */       channelId(instance.channelId());
/* 310 */       messageId(instance.messageId());
/* 311 */       guildId(instance.guildId());
/* 312 */       return this;
/*     */     }
/*     */     
/*     */     public Builder channelId(String value) {
/* 316 */       this.channelId_id = Id.of(value);
/* 317 */       return this;
/*     */     }
/*     */     
/*     */     public Builder channelId(long value) {
/* 321 */       this.channelId_id = Id.of(value);
/* 322 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("channel_id")
/*     */     public Builder channelId(Id value) {
/* 327 */       this.channelId_id = value;
/* 328 */       return this;
/*     */     }
/*     */     
/*     */     public Builder messageId(String value) {
/* 332 */       this.messageId_id = Id.of(value);
/* 333 */       return this;
/*     */     }
/*     */     
/*     */     public Builder messageId(long value) {
/* 337 */       this.messageId_id = Id.of(value);
/* 338 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("message_id")
/*     */     public Builder messageId(Id value) {
/* 343 */       this.messageId_id = value;
/* 344 */       return this;
/*     */     }
/*     */     
/*     */     public Builder guildId(String value) {
/* 348 */       this.guildId_possible = Possible.of(Id.of(value));
/* 349 */       return this;
/*     */     }
/*     */     
/*     */     public Builder guildId(long value) {
/* 353 */       this.guildId_possible = Possible.of(Id.of(value));
/* 354 */       return this;
/*     */     }
/*     */     
/*     */     public Builder guildId(Id value) {
/* 358 */       this.guildId_possible = Possible.of(value);
/* 359 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("guild_id")
/*     */     public Builder guildId(Possible<Id> value) {
/* 364 */       this.guildId_possible = value;
/* 365 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableMessageReactionRemoveAll build() {
/* 374 */       return new ImmutableMessageReactionRemoveAll(null, channelId_build(), messageId_build(), guildId_build());
/*     */     }
/*     */     
/*     */     private Id channelId_build() {
/* 378 */       return this.channelId_id;
/*     */     }
/*     */     
/*     */     private Id messageId_build() {
/* 382 */       return this.messageId_id;
/*     */     }
/*     */     
/*     */     private Possible<Id> guildId_build() {
/* 386 */       return this.guildId_possible;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\gateway\ImmutableMessageReactionRemoveAll.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */