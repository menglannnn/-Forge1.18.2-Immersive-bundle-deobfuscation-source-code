/*    */ package discord4j.discordjson.json.gateway;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonProperty;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import discord4j.discordjson.Id;
/*    */ import discord4j.discordjson.json.RoleData;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ @JsonSerialize(as = ImmutableGuildRoleUpdate.class)
/*    */ @JsonDeserialize(as = ImmutableGuildRoleUpdate.class)
/*    */ @Immutable
/*    */ public interface GuildRoleUpdate
/*    */   extends Dispatch {
/*    */   static ImmutableGuildRoleUpdate.Builder builder() {
/* 16 */     return ImmutableGuildRoleUpdate.builder();
/*    */   }
/*    */   
/*    */   @JsonProperty("guild_id")
/*    */   Id guildId();
/*    */   
/*    */   RoleData role();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\gateway\GuildRoleUpdate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */