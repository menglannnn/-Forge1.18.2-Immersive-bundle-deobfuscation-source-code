/*    */ package discord4j.discordjson.json.gateway;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonProperty;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import discord4j.discordjson.Id;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @JsonSerialize(as = ImmutableGuildScheduledEventUserAdd.class)
/*    */ @JsonDeserialize(as = ImmutableGuildScheduledEventUserAdd.class)
/*    */ @Immutable
/*    */ public interface GuildScheduledEventUserAdd
/*    */   extends Dispatch
/*    */ {
/*    */   static ImmutableGuildScheduledEventUserAdd.Builder builder() {
/* 19 */     return ImmutableGuildScheduledEventUserAdd.builder();
/*    */   }
/*    */   
/*    */   @JsonProperty("guild_scheduled_event_id")
/*    */   Id scheduledEventId();
/*    */   
/*    */   @JsonProperty("user_id")
/*    */   Id userId();
/*    */   
/*    */   @JsonProperty("guild_id")
/*    */   Id guildId();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\gateway\GuildScheduledEventUserAdd.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */