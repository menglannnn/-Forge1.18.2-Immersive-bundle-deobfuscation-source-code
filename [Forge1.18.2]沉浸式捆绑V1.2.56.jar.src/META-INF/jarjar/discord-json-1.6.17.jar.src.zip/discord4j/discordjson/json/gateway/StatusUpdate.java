/*    */ package discord4j.discordjson.json.gateway;
/*    */ 
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import discord4j.discordjson.json.ActivityUpdateRequest;
/*    */ import java.util.List;
/*    */ import java.util.Optional;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ @JsonSerialize(as = ImmutableStatusUpdate.class)
/*    */ @JsonDeserialize(as = ImmutableStatusUpdate.class)
/*    */ @Immutable
/*    */ public interface StatusUpdate
/*    */   extends PayloadData
/*    */ {
/*    */   static ImmutableStatusUpdate.Builder builder() {
/* 17 */     return ImmutableStatusUpdate.builder();
/*    */   }
/*    */   
/*    */   Optional<Long> since();
/*    */   
/*    */   List<ActivityUpdateRequest> activities();
/*    */   
/*    */   String status();
/*    */   
/*    */   boolean afk();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\gateway\StatusUpdate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */