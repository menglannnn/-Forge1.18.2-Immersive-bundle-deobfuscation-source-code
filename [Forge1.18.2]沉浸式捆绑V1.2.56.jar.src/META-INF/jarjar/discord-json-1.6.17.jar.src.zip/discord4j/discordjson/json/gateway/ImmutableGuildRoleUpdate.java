/*     */ package discord4j.discordjson.json.gateway;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.Id;
/*     */ import discord4j.discordjson.json.RoleData;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "GuildRoleUpdate", generator = "Immutables")
/*     */ public final class ImmutableGuildRoleUpdate
/*     */   implements GuildRoleUpdate
/*     */ {
/*     */   private final long guildId_value;
/*     */   private final RoleData role;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   
/*     */   private ImmutableGuildRoleUpdate(Id guildId, RoleData role) {
/*  30 */     Id guildId$impl = guildId;
/*  31 */     this.role = Objects.<RoleData>requireNonNull(role, "role");
/*  32 */     this.guildId_value = guildId$impl.asLong();
/*  33 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ImmutableGuildRoleUpdate(ImmutableGuildRoleUpdate original, Id guildId, RoleData role) {
/*  40 */     Id guildId$impl = guildId;
/*  41 */     this.role = role;
/*  42 */     this.guildId_value = guildId$impl.asLong();
/*  43 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  49 */   private volatile transient InitShim initShim = new InitShim();
/*     */   
/*     */   @Generated(from = "GuildRoleUpdate", generator = "Immutables")
/*     */   private final class InitShim {
/*     */     private String formatInitCycleMessage() {
/*  54 */       List<String> attributes = new ArrayList<>();
/*  55 */       return "Cannot build GuildRoleUpdate, attribute initializers form cycle " + attributes;
/*     */     }
/*     */ 
/*     */     
/*     */     private InitShim() {}
/*     */   }
/*     */ 
/*     */   
/*     */   @JsonProperty("guild_id")
/*     */   public Id guildId() {
/*  65 */     return Id.of(this.guildId_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("role")
/*     */   public RoleData role() {
/*  74 */     return this.role;
/*     */   }
/*     */   
/*     */   public ImmutableGuildRoleUpdate withGuildId(long value) {
/*  78 */     Id newValue = Id.of(value);
/*  79 */     return new ImmutableGuildRoleUpdate(this, newValue, this.role);
/*     */   }
/*     */   
/*     */   public ImmutableGuildRoleUpdate withGuildId(String value) {
/*  83 */     Id newValue = Id.of(value);
/*  84 */     return new ImmutableGuildRoleUpdate(this, newValue, this.role);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableGuildRoleUpdate withRole(RoleData value) {
/*  94 */     if (this.role == value) return this; 
/*  95 */     RoleData newValue = Objects.<RoleData>requireNonNull(value, "role");
/*  96 */     return new ImmutableGuildRoleUpdate(this, guildId(), newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 105 */     if (this == another) return true; 
/* 106 */     return (another instanceof ImmutableGuildRoleUpdate && 
/* 107 */       equalTo(0, (ImmutableGuildRoleUpdate)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableGuildRoleUpdate another) {
/* 111 */     return (Objects.equals(Long.valueOf(this.guildId_value), Long.valueOf(another.guildId_value)) && this.role
/* 112 */       .equals(another.role));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 121 */     int h = 5381;
/* 122 */     h += (h << 5) + Objects.hashCode(Long.valueOf(this.guildId_value));
/* 123 */     h += (h << 5) + this.role.hashCode();
/* 124 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 133 */     return "GuildRoleUpdate{guildId=" + 
/* 134 */       Objects.toString(Long.valueOf(this.guildId_value)) + ", role=" + this.role + "}";
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "GuildRoleUpdate", generator = "Immutables")
/*     */   static final class Json
/*     */     implements GuildRoleUpdate
/*     */   {
/*     */     Id guildId;
/*     */     
/*     */     RoleData role;
/*     */ 
/*     */     
/*     */     @JsonProperty("guild_id")
/*     */     public void setGuildId(Id guildId) {
/* 152 */       this.guildId = guildId;
/*     */     }
/*     */     @JsonProperty("role")
/*     */     public void setRole(RoleData role) {
/* 156 */       this.role = role;
/*     */     }
/*     */     public Id guildId() {
/* 159 */       throw new UnsupportedOperationException();
/*     */     } public RoleData role() {
/* 161 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableGuildRoleUpdate fromJson(Json json) {
/* 172 */     Builder builder = builder();
/* 173 */     if (json.guildId != null) {
/* 174 */       builder.guildId(json.guildId);
/*     */     }
/* 176 */     if (json.role != null) {
/* 177 */       builder.role(json.role);
/*     */     }
/* 179 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableGuildRoleUpdate of(Id guildId, RoleData role) {
/* 189 */     return new ImmutableGuildRoleUpdate(guildId, role);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableGuildRoleUpdate copyOf(GuildRoleUpdate instance) {
/* 200 */     if (instance instanceof ImmutableGuildRoleUpdate) {
/* 201 */       return (ImmutableGuildRoleUpdate)instance;
/*     */     }
/* 203 */     return builder()
/* 204 */       .from(instance)
/* 205 */       .build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 219 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "GuildRoleUpdate", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_ROLE = 1L;
/*     */ 
/*     */ 
/*     */     
/* 232 */     private long initBits = 1L;
/*     */     
/* 234 */     private Id guildId_id = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private RoleData role;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(GuildRoleUpdate instance) {
/* 248 */       Objects.requireNonNull(instance, "instance");
/* 249 */       guildId(instance.guildId());
/* 250 */       role(instance.role());
/* 251 */       return this;
/*     */     }
/*     */     
/*     */     public Builder guildId(String value) {
/* 255 */       this.guildId_id = Id.of(value);
/* 256 */       return this;
/*     */     }
/*     */     
/*     */     public Builder guildId(long value) {
/* 260 */       this.guildId_id = Id.of(value);
/* 261 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("guild_id")
/*     */     public Builder guildId(Id value) {
/* 266 */       this.guildId_id = value;
/* 267 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("role")
/*     */     public final Builder role(RoleData role) {
/* 277 */       this.role = Objects.<RoleData>requireNonNull(role, "role");
/* 278 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 279 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableGuildRoleUpdate build() {
/* 288 */       if (this.initBits != 0L) {
/* 289 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 291 */       return new ImmutableGuildRoleUpdate(null, guildId_build(), this.role);
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 295 */       List<String> attributes = new ArrayList<>();
/* 296 */       if ((this.initBits & 0x1L) != 0L) attributes.add("role"); 
/* 297 */       return "Cannot build GuildRoleUpdate, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Id guildId_build() {
/* 301 */       return this.guildId_id;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\gateway\ImmutableGuildRoleUpdate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */