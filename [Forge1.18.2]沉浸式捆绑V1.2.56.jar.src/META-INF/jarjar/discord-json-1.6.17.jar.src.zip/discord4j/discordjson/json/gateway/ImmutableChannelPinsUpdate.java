/*     */ package discord4j.discordjson.json.gateway;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.Id;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import org.immutables.value.Generated;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "ChannelPinsUpdate", generator = "Immutables")
/*     */ public final class ImmutableChannelPinsUpdate
/*     */   implements ChannelPinsUpdate
/*     */ {
/*     */   private final long guildId_value;
/*     */   private final boolean guildId_absent;
/*     */   private final long channelId_value;
/*     */   private final String lastPinTimestamp_value;
/*     */   private final boolean lastPinTimestamp_absent;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   
/*     */   private ImmutableChannelPinsUpdate(Possible<Id> guildId, Id channelId, Possible<Optional<String>> lastPinTimestamp) {
/*  38 */     Possible<Id> guildId$impl = guildId;
/*  39 */     Id channelId$impl = channelId;
/*  40 */     Possible<Optional<String>> lastPinTimestamp$impl = lastPinTimestamp;
/*  41 */     this
/*     */       
/*  43 */       .guildId_value = ((Long)guildId$impl.toOptional().map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  44 */     this.guildId_absent = guildId$impl.isAbsent();
/*  45 */     this.channelId_value = channelId$impl.asLong();
/*  46 */     this.lastPinTimestamp_value = Possible.flatOpt(lastPinTimestamp$impl).orElse(null);
/*  47 */     this.lastPinTimestamp_absent = lastPinTimestamp$impl.isAbsent();
/*  48 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ImmutableChannelPinsUpdate(ImmutableChannelPinsUpdate original, Possible<Id> guildId, Id channelId, Possible<Optional<String>> lastPinTimestamp) {
/*  56 */     Possible<Id> guildId$impl = guildId;
/*  57 */     Id channelId$impl = channelId;
/*  58 */     Possible<Optional<String>> lastPinTimestamp$impl = lastPinTimestamp;
/*  59 */     this
/*     */       
/*  61 */       .guildId_value = ((Long)guildId$impl.toOptional().map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  62 */     this.guildId_absent = guildId$impl.isAbsent();
/*  63 */     this.channelId_value = channelId$impl.asLong();
/*  64 */     this.lastPinTimestamp_value = Possible.flatOpt(lastPinTimestamp$impl).orElse(null);
/*  65 */     this.lastPinTimestamp_absent = lastPinTimestamp$impl.isAbsent();
/*  66 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  72 */   private volatile transient InitShim initShim = new InitShim();
/*     */   
/*     */   @Generated(from = "ChannelPinsUpdate", generator = "Immutables")
/*     */   private final class InitShim {
/*     */     private String formatInitCycleMessage() {
/*  77 */       List<String> attributes = new ArrayList<>();
/*  78 */       return "Cannot build ChannelPinsUpdate, attribute initializers form cycle " + attributes;
/*     */     }
/*     */ 
/*     */     
/*     */     private InitShim() {}
/*     */   }
/*     */ 
/*     */   
/*     */   @JsonProperty("guild_id")
/*     */   public Possible<Id> guildId() {
/*  88 */     return this.guildId_absent ? Possible.absent() : 
/*  89 */       Possible.of(Id.of(this.guildId_value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("channel_id")
/*     */   public Id channelId() {
/*  98 */     return Id.of(this.channelId_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("last_pin_timestamp")
/*     */   public Possible<Optional<String>> lastPinTimestamp() {
/* 107 */     return this.lastPinTimestamp_absent ? Possible.absent() : 
/* 108 */       Possible.of(Optional.ofNullable(this.lastPinTimestamp_value));
/*     */   }
/*     */   
/*     */   public ImmutableChannelPinsUpdate withGuildId(Possible<Id> value) {
/* 112 */     Possible<Id> newValue = Objects.<Possible<Id>>requireNonNull(value);
/* 113 */     return new ImmutableChannelPinsUpdate(this, newValue, channelId(), lastPinTimestamp());
/*     */   }
/*     */   
/*     */   public ImmutableChannelPinsUpdate withGuildId(long value) {
/* 117 */     Possible<Id> newValue = Possible.of(Id.of(value));
/* 118 */     return new ImmutableChannelPinsUpdate(this, newValue, channelId(), lastPinTimestamp());
/*     */   }
/*     */   
/*     */   public ImmutableChannelPinsUpdate withChannelId(long value) {
/* 122 */     Id newValue = Id.of(value);
/* 123 */     return new ImmutableChannelPinsUpdate(this, guildId(), newValue, lastPinTimestamp());
/*     */   }
/*     */   
/*     */   public ImmutableChannelPinsUpdate withChannelId(String value) {
/* 127 */     Id newValue = Id.of(value);
/* 128 */     return new ImmutableChannelPinsUpdate(this, guildId(), newValue, lastPinTimestamp());
/*     */   }
/*     */   
/*     */   public ImmutableChannelPinsUpdate withLastPinTimestamp(Possible<Optional<String>> value) {
/* 132 */     Possible<Optional<String>> newValue = Objects.<Possible<Optional<String>>>requireNonNull(value);
/* 133 */     return new ImmutableChannelPinsUpdate(this, guildId(), channelId(), newValue);
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public ImmutableChannelPinsUpdate withLastPinTimestamp(@Nullable String value) {
/* 138 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/* 139 */     return new ImmutableChannelPinsUpdate(this, guildId(), channelId(), newValue);
/*     */   }
/*     */   
/*     */   public ImmutableChannelPinsUpdate withLastPinTimestampOrNull(@Nullable String value) {
/* 143 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/* 144 */     return new ImmutableChannelPinsUpdate(this, guildId(), channelId(), newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 153 */     if (this == another) return true; 
/* 154 */     return (another instanceof ImmutableChannelPinsUpdate && 
/* 155 */       equalTo(0, (ImmutableChannelPinsUpdate)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableChannelPinsUpdate another) {
/* 159 */     return (guildId().equals(another.guildId()) && 
/* 160 */       Objects.equals(Long.valueOf(this.channelId_value), Long.valueOf(another.channelId_value)) && 
/* 161 */       lastPinTimestamp().equals(another.lastPinTimestamp()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 170 */     int h = 5381;
/* 171 */     h += (h << 5) + guildId().hashCode();
/* 172 */     h += (h << 5) + Objects.hashCode(Long.valueOf(this.channelId_value));
/* 173 */     h += (h << 5) + lastPinTimestamp().hashCode();
/* 174 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 183 */     return "ChannelPinsUpdate{guildId=" + 
/* 184 */       guildId().toString() + ", channelId=" + 
/* 185 */       Objects.toString(Long.valueOf(this.channelId_value)) + ", lastPinTimestamp=" + 
/* 186 */       lastPinTimestamp().toString() + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "ChannelPinsUpdate", generator = "Immutables")
/*     */   static final class Json
/*     */     implements ChannelPinsUpdate
/*     */   {
/* 200 */     Possible<Id> guildId = Possible.absent();
/*     */     
/*     */     Id channelId;
/*     */     
/* 204 */     Possible<Optional<String>> lastPinTimestamp = Possible.absent();
/*     */     
/*     */     @JsonProperty("guild_id")
/*     */     public void setGuildId(Possible<Id> guildId) {
/* 208 */       this.guildId = guildId;
/*     */     }
/*     */     @JsonProperty("channel_id")
/*     */     public void setChannelId(Id channelId) {
/* 212 */       this.channelId = channelId;
/*     */     }
/*     */     @JsonProperty("last_pin_timestamp")
/*     */     public void setLastPinTimestamp(Possible<Optional<String>> lastPinTimestamp) {
/* 216 */       this.lastPinTimestamp = lastPinTimestamp;
/*     */     }
/*     */     public Possible<Id> guildId() {
/* 219 */       throw new UnsupportedOperationException();
/*     */     } public Id channelId() {
/* 221 */       throw new UnsupportedOperationException();
/*     */     } public Possible<Optional<String>> lastPinTimestamp() {
/* 223 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableChannelPinsUpdate fromJson(Json json) {
/* 234 */     Builder builder = builder();
/* 235 */     if (json.guildId != null) {
/* 236 */       builder.guildId(json.guildId);
/*     */     }
/* 238 */     if (json.channelId != null) {
/* 239 */       builder.channelId(json.channelId);
/*     */     }
/* 241 */     if (json.lastPinTimestamp != null) {
/* 242 */       builder.lastPinTimestamp(json.lastPinTimestamp);
/*     */     }
/* 244 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableChannelPinsUpdate of(Possible<Id> guildId, Id channelId, Possible<Optional<String>> lastPinTimestamp) {
/* 255 */     return new ImmutableChannelPinsUpdate(guildId, channelId, lastPinTimestamp);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableChannelPinsUpdate copyOf(ChannelPinsUpdate instance) {
/* 266 */     if (instance instanceof ImmutableChannelPinsUpdate) {
/* 267 */       return (ImmutableChannelPinsUpdate)instance;
/*     */     }
/* 269 */     return builder()
/* 270 */       .from(instance)
/* 271 */       .build();
/*     */   }
/*     */   
/*     */   public boolean isGuildIdPresent() {
/* 275 */     return !this.guildId_absent;
/*     */   }
/*     */   
/*     */   public long guildIdOrElse(long defaultValue) {
/* 279 */     return !this.guildId_absent ? this.guildId_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isLastPinTimestampPresent() {
/* 283 */     return !this.lastPinTimestamp_absent;
/*     */   }
/*     */   
/*     */   public String lastPinTimestampOrElse(String defaultValue) {
/* 287 */     return !this.lastPinTimestamp_absent ? this.lastPinTimestamp_value : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 302 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "ChannelPinsUpdate", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/* 314 */     private Possible<Id> guildId_possible = Possible.absent();
/* 315 */     private Id channelId_id = null;
/* 316 */     private Possible<Optional<String>> lastPinTimestamp_possible = Possible.absent();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(ChannelPinsUpdate instance) {
/* 329 */       Objects.requireNonNull(instance, "instance");
/* 330 */       guildId(instance.guildId());
/* 331 */       channelId(instance.channelId());
/* 332 */       lastPinTimestamp(instance.lastPinTimestamp());
/* 333 */       return this;
/*     */     }
/*     */     
/*     */     public Builder guildId(String value) {
/* 337 */       this.guildId_possible = Possible.of(Id.of(value));
/* 338 */       return this;
/*     */     }
/*     */     
/*     */     public Builder guildId(long value) {
/* 342 */       this.guildId_possible = Possible.of(Id.of(value));
/* 343 */       return this;
/*     */     }
/*     */     
/*     */     public Builder guildId(Id value) {
/* 347 */       this.guildId_possible = Possible.of(value);
/* 348 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("guild_id")
/*     */     public Builder guildId(Possible<Id> value) {
/* 353 */       this.guildId_possible = value;
/* 354 */       return this;
/*     */     }
/*     */     
/*     */     public Builder channelId(String value) {
/* 358 */       this.channelId_id = Id.of(value);
/* 359 */       return this;
/*     */     }
/*     */     
/*     */     public Builder channelId(long value) {
/* 363 */       this.channelId_id = Id.of(value);
/* 364 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("channel_id")
/*     */     public Builder channelId(Id value) {
/* 369 */       this.channelId_id = value;
/* 370 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("last_pin_timestamp")
/*     */     public Builder lastPinTimestamp(Possible<Optional<String>> value) {
/* 375 */       this.lastPinTimestamp_possible = value;
/* 376 */       return this;
/*     */     }
/*     */     
/*     */     @Deprecated
/*     */     public Builder lastPinTimestamp(@Nullable String value) {
/* 381 */       this.lastPinTimestamp_possible = Possible.of(Optional.ofNullable(value));
/* 382 */       return this;
/*     */     }
/*     */     
/*     */     public Builder lastPinTimestampOrNull(@Nullable String value) {
/* 386 */       this.lastPinTimestamp_possible = Possible.of(Optional.ofNullable(value));
/* 387 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableChannelPinsUpdate build() {
/* 396 */       return new ImmutableChannelPinsUpdate(null, guildId_build(), channelId_build(), lastPinTimestamp_build());
/*     */     }
/*     */     
/*     */     private Possible<Id> guildId_build() {
/* 400 */       return this.guildId_possible;
/*     */     }
/*     */     
/*     */     private Id channelId_build() {
/* 404 */       return this.channelId_id;
/*     */     }
/*     */     
/*     */     private Possible<Optional<String>> lastPinTimestamp_build() {
/* 408 */       return this.lastPinTimestamp_possible;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\gateway\ImmutableChannelPinsUpdate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */