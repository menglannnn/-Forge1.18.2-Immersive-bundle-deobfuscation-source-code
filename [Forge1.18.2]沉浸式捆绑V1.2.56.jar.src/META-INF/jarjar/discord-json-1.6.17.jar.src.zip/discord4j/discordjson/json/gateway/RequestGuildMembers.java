/*    */ package discord4j.discordjson.json.gateway;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonProperty;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import java.util.List;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ @JsonSerialize(as = ImmutableRequestGuildMembers.class)
/*    */ @JsonDeserialize(as = ImmutableRequestGuildMembers.class)
/*    */ @Immutable
/*    */ public interface RequestGuildMembers
/*    */   extends PayloadData
/*    */ {
/*    */   static ImmutableRequestGuildMembers.Builder builder() {
/* 17 */     return ImmutableRequestGuildMembers.builder();
/*    */   }
/*    */   
/*    */   @JsonProperty("guild_id")
/*    */   String guildId();
/*    */   
/*    */   Possible<String> query();
/*    */   
/*    */   int limit();
/*    */   
/*    */   Possible<Boolean> presences();
/*    */   
/*    */   @JsonProperty("user_ids")
/*    */   Possible<List<String>> userIds();
/*    */   
/*    */   Possible<String> nonce();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\gateway\RequestGuildMembers.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */