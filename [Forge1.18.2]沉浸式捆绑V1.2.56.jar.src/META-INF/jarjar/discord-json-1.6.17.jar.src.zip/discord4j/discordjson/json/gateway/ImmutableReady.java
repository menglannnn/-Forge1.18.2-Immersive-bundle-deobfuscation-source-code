/*      */ package discord4j.discordjson.json.gateway;
/*      */ 
/*      */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*      */ import com.fasterxml.jackson.annotation.JsonCreator;
/*      */ import com.fasterxml.jackson.annotation.JsonProperty;
/*      */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*      */ import discord4j.discordjson.json.ChannelData;
/*      */ import discord4j.discordjson.json.PartialApplicationInfoData;
/*      */ import discord4j.discordjson.json.UnavailableGuildData;
/*      */ import discord4j.discordjson.json.UserData;
/*      */ import discord4j.discordjson.possible.Possible;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.List;
/*      */ import java.util.Objects;
/*      */ import org.immutables.value.Generated;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ @Generated(from = "Ready", generator = "Immutables")
/*      */ public final class ImmutableReady
/*      */   implements Ready
/*      */ {
/*      */   private final int v;
/*      */   private final UserData user;
/*      */   private final List<ChannelData> privateChannels;
/*      */   private final List<UnavailableGuildData> guilds;
/*      */   private final String sessionId;
/*      */   private final String resumeGatewayUrl;
/*      */   private final int[] shard_value;
/*      */   private final boolean shard_absent;
/*      */   private final List<String> trace;
/*      */   private final PartialApplicationInfoData application;
/*      */   private static final byte STAGE_INITIALIZING = -1;
/*      */   private static final byte STAGE_UNINITIALIZED = 0;
/*      */   private static final byte STAGE_INITIALIZED = 1;
/*      */   private volatile transient InitShim initShim;
/*      */   
/*      */   private ImmutableReady(int v, UserData user, Iterable<? extends ChannelData> privateChannels, Iterable<? extends UnavailableGuildData> guilds, String sessionId, String resumeGatewayUrl, Possible<int[]> shard, Iterable<String> trace, PartialApplicationInfoData application) {
/*   95 */     this.initShim = new InitShim(); this.v = v; this.user = Objects.<UserData>requireNonNull(user, "user"); this.privateChannels = createUnmodifiableList(false, createSafeList(privateChannels, true, false)); this.guilds = createUnmodifiableList(false, createSafeList(guilds, true, false)); this.sessionId = Objects.<String>requireNonNull(sessionId, "sessionId"); this.resumeGatewayUrl = Objects.<String>requireNonNull(resumeGatewayUrl, "resumeGatewayUrl"); Possible<int[]> shard$impl = shard; this.trace = createUnmodifiableList(false, createSafeList(trace, true, false)); this.application = Objects.<PartialApplicationInfoData>requireNonNull(application, "application"); this.shard_value = shard$impl.toOptional().orElse(null); this.shard_absent = shard$impl.isAbsent(); this.initShim = null; } private ImmutableReady(ImmutableReady original, int v, UserData user, List<ChannelData> privateChannels, List<UnavailableGuildData> guilds, String sessionId, String resumeGatewayUrl, Possible<int[]> shard, List<String> trace, PartialApplicationInfoData application) { this.initShim = new InitShim(); this.v = v; this.user = user; this.privateChannels = privateChannels; this.guilds = guilds; this.sessionId = sessionId; this.resumeGatewayUrl = resumeGatewayUrl; Possible<int[]> shard$impl = shard;
/*      */     this.trace = trace;
/*      */     this.application = application;
/*      */     this.shard_value = shard$impl.toOptional().orElse(null);
/*      */     this.shard_absent = shard$impl.isAbsent();
/*  100 */     this.initShim = null; } @Generated(from = "Ready", generator = "Immutables") private final class InitShim { private InitShim() {} private String formatInitCycleMessage() { List<String> attributes = new ArrayList<>();
/*  101 */       return "Cannot build Ready, attribute initializers form cycle " + attributes; }
/*      */      }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("v")
/*      */   public int v() {
/*  111 */     return this.v;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("user")
/*      */   public UserData user() {
/*  120 */     return this.user;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("private_channels")
/*      */   public List<ChannelData> privateChannels() {
/*  129 */     return this.privateChannels;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("guilds")
/*      */   public List<UnavailableGuildData> guilds() {
/*  138 */     return this.guilds;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("session_id")
/*      */   public String sessionId() {
/*  147 */     return this.sessionId;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("resume_gateway_url")
/*      */   public String resumeGatewayUrl() {
/*  156 */     return this.resumeGatewayUrl;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("shard")
/*      */   public Possible<int[]> shard() {
/*  165 */     return this.shard_absent ? Possible.absent() : Possible.of(this.shard_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("_trace")
/*      */   public List<String> trace() {
/*  174 */     return this.trace;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("application")
/*      */   public PartialApplicationInfoData application() {
/*  183 */     return this.application;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableReady withV(int value) {
/*  193 */     if (this.v == value) return this; 
/*  194 */     return new ImmutableReady(this, value, this.user, this.privateChannels, this.guilds, this.sessionId, this.resumeGatewayUrl, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  202 */         shard(), this.trace, this.application);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableReady withUser(UserData value) {
/*  214 */     if (this.user == value) return this; 
/*  215 */     UserData newValue = Objects.<UserData>requireNonNull(value, "user");
/*  216 */     return new ImmutableReady(this, this.v, newValue, this.privateChannels, this.guilds, this.sessionId, this.resumeGatewayUrl, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  224 */         shard(), this.trace, this.application);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableReady withPrivateChannels(ChannelData... elements) {
/*  235 */     List<ChannelData> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/*  236 */     return new ImmutableReady(this, this.v, this.user, newValue, this.guilds, this.sessionId, this.resumeGatewayUrl, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  244 */         shard(), this.trace, this.application);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableReady withPrivateChannels(Iterable<? extends ChannelData> elements) {
/*  256 */     if (this.privateChannels == elements) return this; 
/*  257 */     List<ChannelData> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/*  258 */     return new ImmutableReady(this, this.v, this.user, newValue, this.guilds, this.sessionId, this.resumeGatewayUrl, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  266 */         shard(), this.trace, this.application);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableReady withGuilds(UnavailableGuildData... elements) {
/*  277 */     List<UnavailableGuildData> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/*  278 */     return new ImmutableReady(this, this.v, this.user, this.privateChannels, newValue, this.sessionId, this.resumeGatewayUrl, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  286 */         shard(), this.trace, this.application);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableReady withGuilds(Iterable<? extends UnavailableGuildData> elements) {
/*  298 */     if (this.guilds == elements) return this; 
/*  299 */     List<UnavailableGuildData> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/*  300 */     return new ImmutableReady(this, this.v, this.user, this.privateChannels, newValue, this.sessionId, this.resumeGatewayUrl, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  308 */         shard(), this.trace, this.application);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableReady withSessionId(String value) {
/*  320 */     String newValue = Objects.<String>requireNonNull(value, "sessionId");
/*  321 */     if (this.sessionId.equals(newValue)) return this; 
/*  322 */     return new ImmutableReady(this, this.v, this.user, this.privateChannels, this.guilds, newValue, this.resumeGatewayUrl, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  330 */         shard(), this.trace, this.application);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableReady withResumeGatewayUrl(String value) {
/*  342 */     String newValue = Objects.<String>requireNonNull(value, "resumeGatewayUrl");
/*  343 */     if (this.resumeGatewayUrl.equals(newValue)) return this; 
/*  344 */     return new ImmutableReady(this, this.v, this.user, this.privateChannels, this.guilds, this.sessionId, newValue, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  352 */         shard(), this.trace, this.application);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutableReady withShard(Possible<int[]> value) {
/*  358 */     Possible<int[]> newValue = Objects.<Possible<int[]>>requireNonNull(value);
/*  359 */     return new ImmutableReady(this, this.v, this.user, this.privateChannels, this.guilds, this.sessionId, this.resumeGatewayUrl, newValue, this.trace, this.application);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutableReady withShard(int[] value) {
/*  373 */     Possible<int[]> newValue = Possible.of(value);
/*  374 */     return new ImmutableReady(this, this.v, this.user, this.privateChannels, this.guilds, this.sessionId, this.resumeGatewayUrl, newValue, this.trace, this.application);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableReady withTrace(String... elements) {
/*  393 */     List<String> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/*  394 */     return new ImmutableReady(this, this.v, this.user, this.privateChannels, this.guilds, this.sessionId, this.resumeGatewayUrl, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  402 */         shard(), newValue, this.application);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableReady withTrace(Iterable<String> elements) {
/*  414 */     if (this.trace == elements) return this; 
/*  415 */     List<String> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/*  416 */     return new ImmutableReady(this, this.v, this.user, this.privateChannels, this.guilds, this.sessionId, this.resumeGatewayUrl, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  424 */         shard(), newValue, this.application);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableReady withApplication(PartialApplicationInfoData value) {
/*  436 */     if (this.application == value) return this; 
/*  437 */     PartialApplicationInfoData newValue = Objects.<PartialApplicationInfoData>requireNonNull(value, "application");
/*  438 */     return new ImmutableReady(this, this.v, this.user, this.privateChannels, this.guilds, this.sessionId, this.resumeGatewayUrl, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  446 */         shard(), this.trace, newValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean equals(Object another) {
/*  457 */     if (this == another) return true; 
/*  458 */     return (another instanceof ImmutableReady && 
/*  459 */       equalTo(0, (ImmutableReady)another));
/*      */   }
/*      */   
/*      */   private boolean equalTo(int synthetic, ImmutableReady another) {
/*  463 */     return (this.v == another.v && this.user
/*  464 */       .equals(another.user) && this.privateChannels
/*  465 */       .equals(another.privateChannels) && this.guilds
/*  466 */       .equals(another.guilds) && this.sessionId
/*  467 */       .equals(another.sessionId) && this.resumeGatewayUrl
/*  468 */       .equals(another.resumeGatewayUrl) && 
/*  469 */       shard().equals(another.shard()) && this.trace
/*  470 */       .equals(another.trace) && this.application
/*  471 */       .equals(another.application));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int hashCode() {
/*  480 */     int h = 5381;
/*  481 */     h += (h << 5) + this.v;
/*  482 */     h += (h << 5) + this.user.hashCode();
/*  483 */     h += (h << 5) + this.privateChannels.hashCode();
/*  484 */     h += (h << 5) + this.guilds.hashCode();
/*  485 */     h += (h << 5) + this.sessionId.hashCode();
/*  486 */     h += (h << 5) + this.resumeGatewayUrl.hashCode();
/*  487 */     h += (h << 5) + shard().hashCode();
/*  488 */     h += (h << 5) + this.trace.hashCode();
/*  489 */     h += (h << 5) + this.application.hashCode();
/*  490 */     return h;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/*  499 */     return "Ready{v=" + this.v + ", user=" + this.user + ", privateChannels=" + this.privateChannels + ", guilds=" + this.guilds + ", sessionId=" + this.sessionId + ", resumeGatewayUrl=" + this.resumeGatewayUrl + ", shard=" + 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  506 */       shard().toString() + ", trace=" + this.trace + ", application=" + this.application + "}";
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonDeserialize
/*      */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*      */   @Generated(from = "Ready", generator = "Immutables")
/*      */   static final class Json
/*      */     implements Ready
/*      */   {
/*      */     int v;
/*      */     
/*      */     boolean vIsSet;
/*      */     
/*      */     UserData user;
/*      */     
/*  524 */     List<ChannelData> privateChannels = Collections.emptyList();
/*  525 */     List<UnavailableGuildData> guilds = Collections.emptyList();
/*      */     
/*      */     String sessionId;
/*      */     String resumeGatewayUrl;
/*  529 */     Possible<int[]> shard = Possible.absent();
/*      */     
/*  531 */     List<String> trace = Collections.emptyList(); PartialApplicationInfoData application;
/*      */     
/*      */     @JsonProperty("v")
/*      */     public void setV(int v) {
/*  535 */       this.v = v;
/*  536 */       this.vIsSet = true;
/*      */     }
/*      */     @JsonProperty("user")
/*      */     public void setUser(UserData user) {
/*  540 */       this.user = user;
/*      */     }
/*      */     @JsonProperty("private_channels")
/*      */     public void setPrivateChannels(List<ChannelData> privateChannels) {
/*  544 */       this.privateChannels = privateChannels;
/*      */     }
/*      */     @JsonProperty("guilds")
/*      */     public void setGuilds(List<UnavailableGuildData> guilds) {
/*  548 */       this.guilds = guilds;
/*      */     }
/*      */     @JsonProperty("session_id")
/*      */     public void setSessionId(String sessionId) {
/*  552 */       this.sessionId = sessionId;
/*      */     }
/*      */     @JsonProperty("resume_gateway_url")
/*      */     public void setResumeGatewayUrl(String resumeGatewayUrl) {
/*  556 */       this.resumeGatewayUrl = resumeGatewayUrl;
/*      */     }
/*      */     @JsonProperty("shard")
/*      */     public void setShard(Possible<int[]> shard) {
/*  560 */       this.shard = shard;
/*      */     }
/*      */     @JsonProperty("_trace")
/*      */     public void setTrace(List<String> trace) {
/*  564 */       this.trace = trace;
/*      */     }
/*      */     @JsonProperty("application")
/*      */     public void setApplication(PartialApplicationInfoData application) {
/*  568 */       this.application = application;
/*      */     }
/*      */     public int v() {
/*  571 */       throw new UnsupportedOperationException();
/*      */     } public UserData user() {
/*  573 */       throw new UnsupportedOperationException();
/*      */     } public List<ChannelData> privateChannels() {
/*  575 */       throw new UnsupportedOperationException();
/*      */     } public List<UnavailableGuildData> guilds() {
/*  577 */       throw new UnsupportedOperationException();
/*      */     } public String sessionId() {
/*  579 */       throw new UnsupportedOperationException();
/*      */     } public String resumeGatewayUrl() {
/*  581 */       throw new UnsupportedOperationException();
/*      */     } public Possible<int[]> shard() {
/*  583 */       throw new UnsupportedOperationException();
/*      */     } public List<String> trace() {
/*  585 */       throw new UnsupportedOperationException();
/*      */     } public PartialApplicationInfoData application() {
/*  587 */       throw new UnsupportedOperationException();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*      */   static ImmutableReady fromJson(Json json) {
/*  598 */     Builder builder = builder();
/*  599 */     if (json.vIsSet) {
/*  600 */       builder.v(json.v);
/*      */     }
/*  602 */     if (json.user != null) {
/*  603 */       builder.user(json.user);
/*      */     }
/*  605 */     if (json.privateChannels != null) {
/*  606 */       builder.addAllPrivateChannels(json.privateChannels);
/*      */     }
/*  608 */     if (json.guilds != null) {
/*  609 */       builder.addAllGuilds(json.guilds);
/*      */     }
/*  611 */     if (json.sessionId != null) {
/*  612 */       builder.sessionId(json.sessionId);
/*      */     }
/*  614 */     if (json.resumeGatewayUrl != null) {
/*  615 */       builder.resumeGatewayUrl(json.resumeGatewayUrl);
/*      */     }
/*  617 */     if (json.shard != null) {
/*  618 */       builder.shard(json.shard);
/*      */     }
/*  620 */     if (json.trace != null) {
/*  621 */       builder.addAllTrace(json.trace);
/*      */     }
/*  623 */     if (json.application != null) {
/*  624 */       builder.application(json.application);
/*      */     }
/*  626 */     return builder.build();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableReady of(int v, UserData user, List<ChannelData> privateChannels, List<UnavailableGuildData> guilds, String sessionId, String resumeGatewayUrl, Possible<int[]> shard, List<String> trace, PartialApplicationInfoData application) {
/*  643 */     return of(v, user, privateChannels, guilds, sessionId, resumeGatewayUrl, shard, trace, application);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableReady of(int v, UserData user, Iterable<? extends ChannelData> privateChannels, Iterable<? extends UnavailableGuildData> guilds, String sessionId, String resumeGatewayUrl, Possible<int[]> shard, Iterable<String> trace, PartialApplicationInfoData application) {
/*  660 */     return new ImmutableReady(v, user, privateChannels, guilds, sessionId, resumeGatewayUrl, shard, trace, application);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableReady copyOf(Ready instance) {
/*  671 */     if (instance instanceof ImmutableReady) {
/*  672 */       return (ImmutableReady)instance;
/*      */     }
/*  674 */     return builder()
/*  675 */       .from(instance)
/*  676 */       .build();
/*      */   }
/*      */   
/*      */   public boolean isShardPresent() {
/*  680 */     return !this.shard_absent;
/*      */   }
/*      */   
/*      */   public int[] shardOrElse(int[] defaultValue) {
/*  684 */     return !this.shard_absent ? this.shard_value : defaultValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Builder builder() {
/*  705 */     return new Builder();
/*      */   }
/*      */ 
/*      */   
/*      */   @Generated(from = "Ready", generator = "Immutables")
/*      */   public static final class Builder
/*      */   {
/*      */     private static final long INIT_BIT_V = 1L;
/*      */     
/*      */     private static final long INIT_BIT_USER = 2L;
/*      */     
/*      */     private static final long INIT_BIT_SESSION_ID = 4L;
/*      */     
/*      */     private static final long INIT_BIT_RESUME_GATEWAY_URL = 8L;
/*      */     
/*      */     private static final long INIT_BIT_APPLICATION = 16L;
/*      */     
/*  722 */     private long initBits = 31L;
/*      */     
/*  724 */     private Possible<int[]> shard_possible = Possible.absent();
/*      */     private int v;
/*      */     private UserData user;
/*  727 */     private List<ChannelData> privateChannels = new ArrayList<>();
/*  728 */     private List<UnavailableGuildData> guilds = new ArrayList<>();
/*      */     private String sessionId;
/*      */     private String resumeGatewayUrl;
/*  731 */     private List<String> trace = new ArrayList<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private PartialApplicationInfoData application;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder from(Ready instance) {
/*  746 */       Objects.requireNonNull(instance, "instance");
/*  747 */       v(instance.v());
/*  748 */       user(instance.user());
/*  749 */       addAllPrivateChannels(instance.privateChannels());
/*  750 */       addAllGuilds(instance.guilds());
/*  751 */       sessionId(instance.sessionId());
/*  752 */       resumeGatewayUrl(instance.resumeGatewayUrl());
/*  753 */       shard(instance.shard());
/*  754 */       addAllTrace(instance.trace());
/*  755 */       application(instance.application());
/*  756 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("v")
/*      */     public final Builder v(int v) {
/*  766 */       this.v = v;
/*  767 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/*  768 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("user")
/*      */     public final Builder user(UserData user) {
/*  778 */       this.user = Objects.<UserData>requireNonNull(user, "user");
/*  779 */       this.initBits &= 0xFFFFFFFFFFFFFFFDL;
/*  780 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addPrivateChannel(ChannelData element) {
/*  789 */       this.privateChannels.add(Objects.<ChannelData>requireNonNull(element, "privateChannels element"));
/*  790 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addPrivateChannels(ChannelData... elements) {
/*  799 */       for (ChannelData element : elements) {
/*  800 */         this.privateChannels.add(Objects.<ChannelData>requireNonNull(element, "privateChannels element"));
/*      */       }
/*  802 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("private_channels")
/*      */     public final Builder privateChannels(Iterable<? extends ChannelData> elements) {
/*  813 */       this.privateChannels.clear();
/*  814 */       return addAllPrivateChannels(elements);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addAllPrivateChannels(Iterable<? extends ChannelData> elements) {
/*  823 */       for (ChannelData element : elements) {
/*  824 */         this.privateChannels.add(Objects.<ChannelData>requireNonNull(element, "privateChannels element"));
/*      */       }
/*  826 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addGuild(UnavailableGuildData element) {
/*  835 */       this.guilds.add(Objects.<UnavailableGuildData>requireNonNull(element, "guilds element"));
/*  836 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addGuilds(UnavailableGuildData... elements) {
/*  845 */       for (UnavailableGuildData element : elements) {
/*  846 */         this.guilds.add(Objects.<UnavailableGuildData>requireNonNull(element, "guilds element"));
/*      */       }
/*  848 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("guilds")
/*      */     public final Builder guilds(Iterable<? extends UnavailableGuildData> elements) {
/*  859 */       this.guilds.clear();
/*  860 */       return addAllGuilds(elements);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addAllGuilds(Iterable<? extends UnavailableGuildData> elements) {
/*  869 */       for (UnavailableGuildData element : elements) {
/*  870 */         this.guilds.add(Objects.<UnavailableGuildData>requireNonNull(element, "guilds element"));
/*      */       }
/*  872 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("session_id")
/*      */     public final Builder sessionId(String sessionId) {
/*  882 */       this.sessionId = Objects.<String>requireNonNull(sessionId, "sessionId");
/*  883 */       this.initBits &= 0xFFFFFFFFFFFFFFFBL;
/*  884 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("resume_gateway_url")
/*      */     public final Builder resumeGatewayUrl(String resumeGatewayUrl) {
/*  894 */       this.resumeGatewayUrl = Objects.<String>requireNonNull(resumeGatewayUrl, "resumeGatewayUrl");
/*  895 */       this.initBits &= 0xFFFFFFFFFFFFFFF7L;
/*  896 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("shard")
/*      */     public Builder shard(Possible<int[]> value) {
/*  901 */       this.shard_possible = value;
/*  902 */       return this;
/*      */     }
/*      */     
/*      */     public Builder shard(int[] value) {
/*  906 */       this.shard_possible = Possible.of(value);
/*  907 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addTrace(String element) {
/*  916 */       this.trace.add(Objects.<String>requireNonNull(element, "trace element"));
/*  917 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addTrace(String... elements) {
/*  926 */       for (String element : elements) {
/*  927 */         this.trace.add(Objects.<String>requireNonNull(element, "trace element"));
/*      */       }
/*  929 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("_trace")
/*      */     public final Builder trace(Iterable<String> elements) {
/*  940 */       this.trace.clear();
/*  941 */       return addAllTrace(elements);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addAllTrace(Iterable<String> elements) {
/*  950 */       for (String element : elements) {
/*  951 */         this.trace.add(Objects.<String>requireNonNull(element, "trace element"));
/*      */       }
/*  953 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("application")
/*      */     public final Builder application(PartialApplicationInfoData application) {
/*  963 */       this.application = Objects.<PartialApplicationInfoData>requireNonNull(application, "application");
/*  964 */       this.initBits &= 0xFFFFFFFFFFFFFFEFL;
/*  965 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ImmutableReady build() {
/*  974 */       if (this.initBits != 0L) {
/*  975 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*      */       }
/*  977 */       return new ImmutableReady(null, this.v, this.user, ImmutableReady
/*      */ 
/*      */ 
/*      */           
/*  981 */           .createUnmodifiableList(true, (List)this.privateChannels), ImmutableReady
/*  982 */           .createUnmodifiableList(true, (List)this.guilds), this.sessionId, this.resumeGatewayUrl, 
/*      */ 
/*      */           
/*  985 */           shard_build(), ImmutableReady
/*  986 */           .createUnmodifiableList(true, (List)this.trace), this.application);
/*      */     }
/*      */ 
/*      */     
/*      */     private String formatRequiredAttributesMessage() {
/*  991 */       List<String> attributes = new ArrayList<>();
/*  992 */       if ((this.initBits & 0x1L) != 0L) attributes.add("v"); 
/*  993 */       if ((this.initBits & 0x2L) != 0L) attributes.add("user"); 
/*  994 */       if ((this.initBits & 0x4L) != 0L) attributes.add("sessionId"); 
/*  995 */       if ((this.initBits & 0x8L) != 0L) attributes.add("resumeGatewayUrl"); 
/*  996 */       if ((this.initBits & 0x10L) != 0L) attributes.add("application"); 
/*  997 */       return "Cannot build Ready, some of required attributes are not set " + attributes;
/*      */     }
/*      */     
/*      */     private Possible<int[]> shard_build() {
/* 1001 */       return this.shard_possible;
/*      */     }
/*      */     private Builder() {} }
/*      */   
/*      */   private static <T> List<T> createSafeList(Iterable<? extends T> iterable, boolean checkNulls, boolean skipNulls) {
/*      */     ArrayList<T> list;
/* 1007 */     if (iterable instanceof Collection) {
/* 1008 */       int size = ((Collection)iterable).size();
/* 1009 */       if (size == 0) return Collections.emptyList(); 
/* 1010 */       list = new ArrayList<>();
/*      */     } else {
/* 1012 */       list = new ArrayList<>();
/*      */     } 
/* 1014 */     for (T element : iterable) {
/* 1015 */       if (skipNulls && element == null)
/* 1016 */         continue;  if (checkNulls) Objects.requireNonNull(element, "element"); 
/* 1017 */       list.add(element);
/*      */     } 
/* 1019 */     return list;
/*      */   }
/*      */   
/*      */   private static <T> List<T> createUnmodifiableList(boolean clone, List<T> list) {
/* 1023 */     switch (list.size()) { case 0:
/* 1024 */         return Collections.emptyList();
/* 1025 */       case 1: return Collections.singletonList(list.get(0)); }
/*      */     
/* 1027 */     if (clone) {
/* 1028 */       return Collections.unmodifiableList(new ArrayList<>(list));
/*      */     }
/* 1030 */     if (list instanceof ArrayList) {
/* 1031 */       ((ArrayList)list).trimToSize();
/*      */     }
/* 1033 */     return Collections.unmodifiableList(list);
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\gateway\ImmutableReady.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */