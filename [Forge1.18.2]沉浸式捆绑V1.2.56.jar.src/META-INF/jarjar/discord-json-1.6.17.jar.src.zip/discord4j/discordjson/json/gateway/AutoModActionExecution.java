/*    */ package discord4j.discordjson.json.gateway;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonProperty;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import discord4j.discordjson.Id;
/*    */ import discord4j.discordjson.json.AutoModActionData;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import java.util.Optional;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ @JsonSerialize(as = ImmutableAutoModActionExecution.class)
/*    */ @JsonDeserialize(as = ImmutableAutoModActionExecution.class)
/*    */ @Immutable
/*    */ public interface AutoModActionExecution
/*    */   extends Dispatch {
/*    */   static ImmutableAutoModActionExecution.Builder builder() {
/* 18 */     return ImmutableAutoModActionExecution.builder();
/*    */   }
/*    */   
/*    */   @JsonProperty("guild_id")
/*    */   Id guildId();
/*    */   
/*    */   AutoModActionData action();
/*    */   
/*    */   @JsonProperty("rule_id")
/*    */   Id ruleId();
/*    */   
/*    */   @JsonProperty("rule_trigger_type")
/*    */   int ruleTriggerType();
/*    */   
/*    */   @JsonProperty("user_id")
/*    */   Id userId();
/*    */   
/*    */   @JsonProperty("channel_id")
/*    */   Possible<Id> channelId();
/*    */   
/*    */   @JsonProperty("message_id")
/*    */   Possible<Id> messageId();
/*    */   
/*    */   @JsonProperty("alert_system_message_id")
/*    */   Possible<Id> alertSystemMessageId();
/*    */   
/*    */   String content();
/*    */   
/*    */   @JsonProperty("matched_keyword")
/*    */   Optional<String> matchedKeyword();
/*    */   
/*    */   @JsonProperty("matched_content")
/*    */   Optional<String> matchedContent();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\gateway\AutoModActionExecution.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */