/*     */ package discord4j.discordjson.json.gateway;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.Id;
/*     */ import discord4j.discordjson.json.UserData;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "GuildMemberRemove", generator = "Immutables")
/*     */ public final class ImmutableGuildMemberRemove
/*     */   implements GuildMemberRemove
/*     */ {
/*     */   private final long guildId_value;
/*     */   private final UserData user;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   
/*     */   private ImmutableGuildMemberRemove(Id guildId, UserData user) {
/*  30 */     Id guildId$impl = guildId;
/*  31 */     this.user = Objects.<UserData>requireNonNull(user, "user");
/*  32 */     this.guildId_value = guildId$impl.asLong();
/*  33 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ImmutableGuildMemberRemove(ImmutableGuildMemberRemove original, Id guildId, UserData user) {
/*  40 */     Id guildId$impl = guildId;
/*  41 */     this.user = user;
/*  42 */     this.guildId_value = guildId$impl.asLong();
/*  43 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  49 */   private volatile transient InitShim initShim = new InitShim();
/*     */   
/*     */   @Generated(from = "GuildMemberRemove", generator = "Immutables")
/*     */   private final class InitShim {
/*     */     private String formatInitCycleMessage() {
/*  54 */       List<String> attributes = new ArrayList<>();
/*  55 */       return "Cannot build GuildMemberRemove, attribute initializers form cycle " + attributes;
/*     */     }
/*     */ 
/*     */     
/*     */     private InitShim() {}
/*     */   }
/*     */ 
/*     */   
/*     */   @JsonProperty("guild_id")
/*     */   public Id guildId() {
/*  65 */     return Id.of(this.guildId_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("user")
/*     */   public UserData user() {
/*  74 */     return this.user;
/*     */   }
/*     */   
/*     */   public ImmutableGuildMemberRemove withGuildId(long value) {
/*  78 */     Id newValue = Id.of(value);
/*  79 */     return new ImmutableGuildMemberRemove(this, newValue, this.user);
/*     */   }
/*     */   
/*     */   public ImmutableGuildMemberRemove withGuildId(String value) {
/*  83 */     Id newValue = Id.of(value);
/*  84 */     return new ImmutableGuildMemberRemove(this, newValue, this.user);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableGuildMemberRemove withUser(UserData value) {
/*  94 */     if (this.user == value) return this; 
/*  95 */     UserData newValue = Objects.<UserData>requireNonNull(value, "user");
/*  96 */     return new ImmutableGuildMemberRemove(this, guildId(), newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 105 */     if (this == another) return true; 
/* 106 */     return (another instanceof ImmutableGuildMemberRemove && 
/* 107 */       equalTo(0, (ImmutableGuildMemberRemove)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableGuildMemberRemove another) {
/* 111 */     return (Objects.equals(Long.valueOf(this.guildId_value), Long.valueOf(another.guildId_value)) && this.user
/* 112 */       .equals(another.user));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 121 */     int h = 5381;
/* 122 */     h += (h << 5) + Objects.hashCode(Long.valueOf(this.guildId_value));
/* 123 */     h += (h << 5) + this.user.hashCode();
/* 124 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 133 */     return "GuildMemberRemove{guildId=" + 
/* 134 */       Objects.toString(Long.valueOf(this.guildId_value)) + ", user=" + this.user + "}";
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "GuildMemberRemove", generator = "Immutables")
/*     */   static final class Json
/*     */     implements GuildMemberRemove
/*     */   {
/*     */     Id guildId;
/*     */     
/*     */     UserData user;
/*     */ 
/*     */     
/*     */     @JsonProperty("guild_id")
/*     */     public void setGuildId(Id guildId) {
/* 152 */       this.guildId = guildId;
/*     */     }
/*     */     @JsonProperty("user")
/*     */     public void setUser(UserData user) {
/* 156 */       this.user = user;
/*     */     }
/*     */     public Id guildId() {
/* 159 */       throw new UnsupportedOperationException();
/*     */     } public UserData user() {
/* 161 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableGuildMemberRemove fromJson(Json json) {
/* 172 */     Builder builder = builder();
/* 173 */     if (json.guildId != null) {
/* 174 */       builder.guildId(json.guildId);
/*     */     }
/* 176 */     if (json.user != null) {
/* 177 */       builder.user(json.user);
/*     */     }
/* 179 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableGuildMemberRemove of(Id guildId, UserData user) {
/* 189 */     return new ImmutableGuildMemberRemove(guildId, user);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableGuildMemberRemove copyOf(GuildMemberRemove instance) {
/* 200 */     if (instance instanceof ImmutableGuildMemberRemove) {
/* 201 */       return (ImmutableGuildMemberRemove)instance;
/*     */     }
/* 203 */     return builder()
/* 204 */       .from(instance)
/* 205 */       .build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 219 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "GuildMemberRemove", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_USER = 1L;
/*     */ 
/*     */ 
/*     */     
/* 232 */     private long initBits = 1L;
/*     */     
/* 234 */     private Id guildId_id = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private UserData user;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(GuildMemberRemove instance) {
/* 248 */       Objects.requireNonNull(instance, "instance");
/* 249 */       guildId(instance.guildId());
/* 250 */       user(instance.user());
/* 251 */       return this;
/*     */     }
/*     */     
/*     */     public Builder guildId(String value) {
/* 255 */       this.guildId_id = Id.of(value);
/* 256 */       return this;
/*     */     }
/*     */     
/*     */     public Builder guildId(long value) {
/* 260 */       this.guildId_id = Id.of(value);
/* 261 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("guild_id")
/*     */     public Builder guildId(Id value) {
/* 266 */       this.guildId_id = value;
/* 267 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("user")
/*     */     public final Builder user(UserData user) {
/* 277 */       this.user = Objects.<UserData>requireNonNull(user, "user");
/* 278 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 279 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableGuildMemberRemove build() {
/* 288 */       if (this.initBits != 0L) {
/* 289 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 291 */       return new ImmutableGuildMemberRemove(null, guildId_build(), this.user);
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 295 */       List<String> attributes = new ArrayList<>();
/* 296 */       if ((this.initBits & 0x1L) != 0L) attributes.add("user"); 
/* 297 */       return "Cannot build GuildMemberRemove, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Id guildId_build() {
/* 301 */       return this.guildId_id;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\gateway\ImmutableGuildMemberRemove.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */