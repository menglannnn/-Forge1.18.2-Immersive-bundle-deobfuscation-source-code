/*    */ package discord4j.discordjson.json.gateway;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonProperty;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import discord4j.discordjson.Id;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import java.util.List;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ @JsonSerialize(as = ImmutableMessageDeleteBulk.class)
/*    */ @JsonDeserialize(as = ImmutableMessageDeleteBulk.class)
/*    */ @Immutable
/*    */ public interface MessageDeleteBulk
/*    */   extends Dispatch
/*    */ {
/*    */   static ImmutableMessageDeleteBulk.Builder builder() {
/* 18 */     return ImmutableMessageDeleteBulk.builder();
/*    */   }
/*    */   
/*    */   List<Id> ids();
/*    */   
/*    */   @JsonProperty("channel_id")
/*    */   Id channelId();
/*    */   
/*    */   @JsonProperty("guild_id")
/*    */   Possible<Id> guildId();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\gateway\MessageDeleteBulk.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */