/*    */ package discord4j.discordjson.json.gateway;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonProperty;
/*    */ import com.fasterxml.jackson.annotation.JsonUnwrapped;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import discord4j.discordjson.json.IntegrationData;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ @JsonSerialize(as = ImmutableIntegrationCreate.class)
/*    */ @JsonDeserialize(as = ImmutableIntegrationCreate.class)
/*    */ @Immutable
/*    */ public interface IntegrationCreate
/*    */   extends Dispatch {
/*    */   static ImmutableIntegrationCreate.Builder builder() {
/* 16 */     return ImmutableIntegrationCreate.builder();
/*    */   }
/*    */   
/*    */   @JsonProperty("guild_id")
/*    */   String guildId();
/*    */   
/*    */   @JsonUnwrapped
/*    */   IntegrationData integration();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\gateway\IntegrationCreate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */