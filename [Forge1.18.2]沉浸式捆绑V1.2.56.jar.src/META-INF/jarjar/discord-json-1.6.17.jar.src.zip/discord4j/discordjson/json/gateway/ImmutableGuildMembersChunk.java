/*     */ package discord4j.discordjson.json.gateway;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.Id;
/*     */ import discord4j.discordjson.json.MemberData;
/*     */ import discord4j.discordjson.json.PresenceData;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.stream.StreamSupport;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "GuildMembersChunk", generator = "Immutables")
/*     */ public final class ImmutableGuildMembersChunk
/*     */   implements GuildMembersChunk
/*     */ {
/*     */   private final long guildId_value;
/*     */   private final List<MemberData> members;
/*     */   private final int chunkIndex;
/*     */   private final int chunkCount;
/*     */   private final List<String> notFound_value;
/*     */   private final boolean notFound_absent;
/*     */   private final List<PresenceData> presences_value;
/*     */   private final boolean presences_absent;
/*     */   private final String nonce_value;
/*     */   private final boolean nonce_absent;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   
/*     */   private ImmutableGuildMembersChunk(Id guildId, Iterable<? extends MemberData> members, int chunkIndex, int chunkCount, Possible<List<String>> notFound, Possible<List<PresenceData>> presences, Possible<String> nonce) {
/*  52 */     Id guildId$impl = guildId;
/*  53 */     this.members = createUnmodifiableList(false, createSafeList(members, true, false));
/*  54 */     this.chunkIndex = chunkIndex;
/*  55 */     this.chunkCount = chunkCount;
/*  56 */     Possible<List<String>> notFound$impl = notFound;
/*  57 */     Possible<List<PresenceData>> presences$impl = presences;
/*  58 */     Possible<String> nonce$impl = nonce;
/*  59 */     this.guildId_value = guildId$impl.asLong();
/*  60 */     this.notFound_value = notFound$impl.toOptional().orElse(null);
/*  61 */     this.notFound_absent = notFound$impl.isAbsent();
/*  62 */     this.presences_value = presences$impl.toOptional().orElse(null);
/*  63 */     this.presences_absent = presences$impl.isAbsent();
/*  64 */     this.nonce_value = nonce$impl.toOptional().orElse(null);
/*  65 */     this.nonce_absent = nonce$impl.isAbsent();
/*  66 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ImmutableGuildMembersChunk(ImmutableGuildMembersChunk original, Id guildId, List<MemberData> members, int chunkIndex, int chunkCount, Possible<List<String>> notFound, Possible<List<PresenceData>> presences, Possible<String> nonce) {
/*  78 */     Id guildId$impl = guildId;
/*  79 */     this.members = members;
/*  80 */     this.chunkIndex = chunkIndex;
/*  81 */     this.chunkCount = chunkCount;
/*  82 */     Possible<List<String>> notFound$impl = notFound;
/*  83 */     Possible<List<PresenceData>> presences$impl = presences;
/*  84 */     Possible<String> nonce$impl = nonce;
/*  85 */     this.guildId_value = guildId$impl.asLong();
/*  86 */     this.notFound_value = notFound$impl.toOptional().orElse(null);
/*  87 */     this.notFound_absent = notFound$impl.isAbsent();
/*  88 */     this.presences_value = presences$impl.toOptional().orElse(null);
/*  89 */     this.presences_absent = presences$impl.isAbsent();
/*  90 */     this.nonce_value = nonce$impl.toOptional().orElse(null);
/*  91 */     this.nonce_absent = nonce$impl.isAbsent();
/*  92 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  98 */   private volatile transient InitShim initShim = new InitShim();
/*     */   
/*     */   @Generated(from = "GuildMembersChunk", generator = "Immutables")
/*     */   private final class InitShim {
/*     */     private String formatInitCycleMessage() {
/* 103 */       List<String> attributes = new ArrayList<>();
/* 104 */       return "Cannot build GuildMembersChunk, attribute initializers form cycle " + attributes;
/*     */     }
/*     */ 
/*     */     
/*     */     private InitShim() {}
/*     */   }
/*     */ 
/*     */   
/*     */   @JsonProperty("guild_id")
/*     */   public Id guildId() {
/* 114 */     return Id.of(this.guildId_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("members")
/*     */   public List<MemberData> members() {
/* 123 */     return this.members;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("chunk_index")
/*     */   public int chunkIndex() {
/* 132 */     return this.chunkIndex;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("chunk_count")
/*     */   public int chunkCount() {
/* 141 */     return this.chunkCount;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("not_found")
/*     */   public Possible<List<String>> notFound() {
/* 150 */     return this.notFound_absent ? Possible.absent() : 
/* 151 */       Possible.of(this.notFound_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("presences")
/*     */   public Possible<List<PresenceData>> presences() {
/* 160 */     return this.presences_absent ? Possible.absent() : 
/* 161 */       Possible.of(this.presences_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("nonce")
/*     */   public Possible<String> nonce() {
/* 170 */     return this.nonce_absent ? Possible.absent() : Possible.of(this.nonce_value);
/*     */   }
/*     */   
/*     */   public ImmutableGuildMembersChunk withGuildId(long value) {
/* 174 */     Id newValue = Id.of(value);
/* 175 */     return new ImmutableGuildMembersChunk(this, newValue, this.members, this.chunkIndex, this.chunkCount, 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 181 */         notFound(), 
/* 182 */         presences(), 
/* 183 */         nonce());
/*     */   }
/*     */   
/*     */   public ImmutableGuildMembersChunk withGuildId(String value) {
/* 187 */     Id newValue = Id.of(value);
/* 188 */     return new ImmutableGuildMembersChunk(this, newValue, this.members, this.chunkIndex, this.chunkCount, 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 194 */         notFound(), 
/* 195 */         presences(), 
/* 196 */         nonce());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableGuildMembersChunk withMembers(MemberData... elements) {
/* 205 */     List<MemberData> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/* 206 */     return new ImmutableGuildMembersChunk(this, 
/*     */         
/* 208 */         guildId(), newValue, this.chunkIndex, this.chunkCount, 
/*     */ 
/*     */ 
/*     */         
/* 212 */         notFound(), 
/* 213 */         presences(), 
/* 214 */         nonce());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableGuildMembersChunk withMembers(Iterable<? extends MemberData> elements) {
/* 224 */     if (this.members == elements) return this; 
/* 225 */     List<MemberData> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/* 226 */     return new ImmutableGuildMembersChunk(this, 
/*     */         
/* 228 */         guildId(), newValue, this.chunkIndex, this.chunkCount, 
/*     */ 
/*     */ 
/*     */         
/* 232 */         notFound(), 
/* 233 */         presences(), 
/* 234 */         nonce());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableGuildMembersChunk withChunkIndex(int value) {
/* 244 */     if (this.chunkIndex == value) return this; 
/* 245 */     return new ImmutableGuildMembersChunk(this, 
/*     */         
/* 247 */         guildId(), this.members, value, this.chunkCount, 
/*     */ 
/*     */ 
/*     */         
/* 251 */         notFound(), 
/* 252 */         presences(), 
/* 253 */         nonce());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableGuildMembersChunk withChunkCount(int value) {
/* 263 */     if (this.chunkCount == value) return this; 
/* 264 */     return new ImmutableGuildMembersChunk(this, 
/*     */         
/* 266 */         guildId(), this.members, this.chunkIndex, value, 
/*     */ 
/*     */ 
/*     */         
/* 270 */         notFound(), 
/* 271 */         presences(), 
/* 272 */         nonce());
/*     */   }
/*     */   
/*     */   public ImmutableGuildMembersChunk withNotFound(Possible<List<String>> possible) {
/* 276 */     Possible<List<String>> newValue = Objects.<Possible<List<String>>>requireNonNull(possible);
/* 277 */     return new ImmutableGuildMembersChunk(this, 
/*     */         
/* 279 */         guildId(), this.members, this.chunkIndex, this.chunkCount, newValue, 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 284 */         presences(), 
/* 285 */         nonce());
/*     */   }
/*     */   
/*     */   public ImmutableGuildMembersChunk withNotFound(Iterable<String> elements) {
/* 289 */     Possible<List<String>> newValue = Possible.of(
/* 290 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/* 291 */     return new ImmutableGuildMembersChunk(this, 
/*     */         
/* 293 */         guildId(), this.members, this.chunkIndex, this.chunkCount, newValue, 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 298 */         presences(), 
/* 299 */         nonce());
/*     */   }
/*     */   
/*     */   @SafeVarargs
/*     */   public final ImmutableGuildMembersChunk withNotFound(String... elements) {
/* 304 */     Possible<List<String>> newValue = Possible.of(Arrays.asList(elements));
/* 305 */     return new ImmutableGuildMembersChunk(this, 
/*     */         
/* 307 */         guildId(), this.members, this.chunkIndex, this.chunkCount, newValue, 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 312 */         presences(), 
/* 313 */         nonce());
/*     */   }
/*     */   
/*     */   public ImmutableGuildMembersChunk withPresences(Possible<List<PresenceData>> possible) {
/* 317 */     Possible<List<PresenceData>> newValue = Objects.<Possible<List<PresenceData>>>requireNonNull(possible);
/* 318 */     return new ImmutableGuildMembersChunk(this, 
/*     */         
/* 320 */         guildId(), this.members, this.chunkIndex, this.chunkCount, 
/*     */ 
/*     */ 
/*     */         
/* 324 */         notFound(), newValue, 
/*     */         
/* 326 */         nonce());
/*     */   }
/*     */   
/*     */   public ImmutableGuildMembersChunk withPresences(Iterable<PresenceData> elements) {
/* 330 */     Possible<List<PresenceData>> newValue = Possible.of(
/* 331 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/* 332 */     return new ImmutableGuildMembersChunk(this, 
/*     */         
/* 334 */         guildId(), this.members, this.chunkIndex, this.chunkCount, 
/*     */ 
/*     */ 
/*     */         
/* 338 */         notFound(), newValue, 
/*     */         
/* 340 */         nonce());
/*     */   }
/*     */   
/*     */   @SafeVarargs
/*     */   public final ImmutableGuildMembersChunk withPresences(PresenceData... elements) {
/* 345 */     Possible<List<PresenceData>> newValue = Possible.of(Arrays.asList(elements));
/* 346 */     return new ImmutableGuildMembersChunk(this, 
/*     */         
/* 348 */         guildId(), this.members, this.chunkIndex, this.chunkCount, 
/*     */ 
/*     */ 
/*     */         
/* 352 */         notFound(), newValue, 
/*     */         
/* 354 */         nonce());
/*     */   }
/*     */   
/*     */   public ImmutableGuildMembersChunk withNonce(Possible<String> value) {
/* 358 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/* 359 */     return new ImmutableGuildMembersChunk(this, 
/*     */         
/* 361 */         guildId(), this.members, this.chunkIndex, this.chunkCount, 
/*     */ 
/*     */ 
/*     */         
/* 365 */         notFound(), 
/* 366 */         presences(), newValue);
/*     */   }
/*     */ 
/*     */   
/*     */   public ImmutableGuildMembersChunk withNonce(String value) {
/* 371 */     Possible<String> newValue = Possible.of(value);
/* 372 */     return new ImmutableGuildMembersChunk(this, 
/*     */         
/* 374 */         guildId(), this.members, this.chunkIndex, this.chunkCount, 
/*     */ 
/*     */ 
/*     */         
/* 378 */         notFound(), 
/* 379 */         presences(), newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 389 */     if (this == another) return true; 
/* 390 */     return (another instanceof ImmutableGuildMembersChunk && 
/* 391 */       equalTo(0, (ImmutableGuildMembersChunk)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableGuildMembersChunk another) {
/* 395 */     return (Objects.equals(Long.valueOf(this.guildId_value), Long.valueOf(another.guildId_value)) && this.members
/* 396 */       .equals(another.members) && this.chunkIndex == another.chunkIndex && this.chunkCount == another.chunkCount && 
/*     */ 
/*     */       
/* 399 */       Objects.equals(this.notFound_value, another.notFound_value) && 
/* 400 */       Objects.equals(this.presences_value, another.presences_value) && 
/* 401 */       nonce().equals(another.nonce()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 410 */     int h = 5381;
/* 411 */     h += (h << 5) + Objects.hashCode(Long.valueOf(this.guildId_value));
/* 412 */     h += (h << 5) + this.members.hashCode();
/* 413 */     h += (h << 5) + this.chunkIndex;
/* 414 */     h += (h << 5) + this.chunkCount;
/* 415 */     h += (h << 5) + Objects.hashCode(this.notFound_value);
/* 416 */     h += (h << 5) + Objects.hashCode(this.presences_value);
/* 417 */     h += (h << 5) + nonce().hashCode();
/* 418 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 427 */     return "GuildMembersChunk{guildId=" + 
/* 428 */       Objects.toString(Long.valueOf(this.guildId_value)) + ", members=" + this.members + ", chunkIndex=" + this.chunkIndex + ", chunkCount=" + this.chunkCount + ", notFound=" + 
/*     */ 
/*     */ 
/*     */       
/* 432 */       Objects.toString(this.notFound_value) + ", presences=" + 
/* 433 */       Objects.toString(this.presences_value) + ", nonce=" + 
/* 434 */       nonce().toString() + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "GuildMembersChunk", generator = "Immutables")
/*     */   static final class Json
/*     */     implements GuildMembersChunk
/*     */   {
/*     */     Id guildId;
/*     */     
/* 448 */     List<MemberData> members = Collections.emptyList();
/*     */     
/*     */     int chunkIndex;
/*     */     boolean chunkIndexIsSet;
/*     */     int chunkCount;
/*     */     boolean chunkCountIsSet;
/* 454 */     Possible<List<String>> notFound = Possible.absent();
/*     */ 
/*     */     
/* 457 */     Possible<List<PresenceData>> presences = Possible.absent();
/*     */ 
/*     */     
/* 460 */     Possible<String> nonce = Possible.absent();
/*     */     
/*     */     @JsonProperty("guild_id")
/*     */     public void setGuildId(Id guildId) {
/* 464 */       this.guildId = guildId;
/*     */     }
/*     */     @JsonProperty("members")
/*     */     public void setMembers(List<MemberData> members) {
/* 468 */       this.members = members;
/*     */     }
/*     */     @JsonProperty("chunk_index")
/*     */     public void setChunkIndex(int chunkIndex) {
/* 472 */       this.chunkIndex = chunkIndex;
/* 473 */       this.chunkIndexIsSet = true;
/*     */     }
/*     */     @JsonProperty("chunk_count")
/*     */     public void setChunkCount(int chunkCount) {
/* 477 */       this.chunkCount = chunkCount;
/* 478 */       this.chunkCountIsSet = true;
/*     */     }
/*     */     @JsonProperty("not_found")
/*     */     public void setNotFound(Possible<List<String>> notFound) {
/* 482 */       this.notFound = notFound;
/*     */     }
/*     */     @JsonProperty("presences")
/*     */     public void setPresences(Possible<List<PresenceData>> presences) {
/* 486 */       this.presences = presences;
/*     */     }
/*     */     @JsonProperty("nonce")
/*     */     public void setNonce(Possible<String> nonce) {
/* 490 */       this.nonce = nonce;
/*     */     }
/*     */     public Id guildId() {
/* 493 */       throw new UnsupportedOperationException();
/*     */     } public List<MemberData> members() {
/* 495 */       throw new UnsupportedOperationException();
/*     */     } public int chunkIndex() {
/* 497 */       throw new UnsupportedOperationException();
/*     */     } public int chunkCount() {
/* 499 */       throw new UnsupportedOperationException();
/*     */     } public Possible<List<String>> notFound() {
/* 501 */       throw new UnsupportedOperationException();
/*     */     } public Possible<List<PresenceData>> presences() {
/* 503 */       throw new UnsupportedOperationException();
/*     */     } public Possible<String> nonce() {
/* 505 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableGuildMembersChunk fromJson(Json json) {
/* 516 */     Builder builder = builder();
/* 517 */     if (json.guildId != null) {
/* 518 */       builder.guildId(json.guildId);
/*     */     }
/* 520 */     if (json.members != null) {
/* 521 */       builder.addAllMembers(json.members);
/*     */     }
/* 523 */     if (json.chunkIndexIsSet) {
/* 524 */       builder.chunkIndex(json.chunkIndex);
/*     */     }
/* 526 */     if (json.chunkCountIsSet) {
/* 527 */       builder.chunkCount(json.chunkCount);
/*     */     }
/* 529 */     if (json.notFound != null) {
/* 530 */       builder.notFound(json.notFound);
/*     */     }
/* 532 */     if (json.presences != null) {
/* 533 */       builder.presences(json.presences);
/*     */     }
/* 535 */     if (json.nonce != null) {
/* 536 */       builder.nonce(json.nonce);
/*     */     }
/* 538 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableGuildMembersChunk of(Id guildId, List<MemberData> members, int chunkIndex, int chunkCount, Possible<List<String>> notFound, Possible<List<PresenceData>> presences, Possible<String> nonce) {
/* 553 */     return of(guildId, members, chunkIndex, chunkCount, notFound, presences, nonce);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableGuildMembersChunk of(Id guildId, Iterable<? extends MemberData> members, int chunkIndex, int chunkCount, Possible<List<String>> notFound, Possible<List<PresenceData>> presences, Possible<String> nonce) {
/* 568 */     return new ImmutableGuildMembersChunk(guildId, members, chunkIndex, chunkCount, notFound, presences, nonce);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableGuildMembersChunk copyOf(GuildMembersChunk instance) {
/* 579 */     if (instance instanceof ImmutableGuildMembersChunk) {
/* 580 */       return (ImmutableGuildMembersChunk)instance;
/*     */     }
/* 582 */     return builder()
/* 583 */       .from(instance)
/* 584 */       .build();
/*     */   }
/*     */   
/*     */   public boolean isNotFoundPresent() {
/* 588 */     return !this.notFound_absent;
/*     */   }
/*     */   
/*     */   public List<String> notFoundOrElse(List<String> defaultValue) {
/* 592 */     return !this.notFound_absent ? this.notFound_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isPresencesPresent() {
/* 596 */     return !this.presences_absent;
/*     */   }
/*     */   
/*     */   public List<PresenceData> presencesOrElse(List<PresenceData> defaultValue) {
/* 600 */     return !this.presences_absent ? this.presences_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isNoncePresent() {
/* 604 */     return !this.nonce_absent;
/*     */   }
/*     */   
/*     */   public String nonceOrElse(String defaultValue) {
/* 608 */     return !this.nonce_absent ? this.nonce_value : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 627 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "GuildMembersChunk", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_CHUNK_INDEX = 1L;
/*     */ 
/*     */     
/*     */     private static final long INIT_BIT_CHUNK_COUNT = 2L;
/*     */ 
/*     */     
/* 641 */     private long initBits = 3L;
/*     */     
/* 643 */     private Id guildId_id = null;
/* 644 */     private List<String> notFound_list = null;
/* 645 */     private List<PresenceData> presences_list = null;
/* 646 */     private Possible<String> nonce_possible = Possible.absent();
/* 647 */     private List<MemberData> members = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private int chunkIndex;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private int chunkCount;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(GuildMembersChunk instance) {
/* 663 */       Objects.requireNonNull(instance, "instance");
/* 664 */       guildId(instance.guildId());
/* 665 */       addAllMembers(instance.members());
/* 666 */       chunkIndex(instance.chunkIndex());
/* 667 */       chunkCount(instance.chunkCount());
/* 668 */       notFound(instance.notFound());
/* 669 */       presences(instance.presences());
/* 670 */       nonce(instance.nonce());
/* 671 */       return this;
/*     */     }
/*     */     
/*     */     public Builder guildId(String value) {
/* 675 */       this.guildId_id = Id.of(value);
/* 676 */       return this;
/*     */     }
/*     */     
/*     */     public Builder guildId(long value) {
/* 680 */       this.guildId_id = Id.of(value);
/* 681 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("guild_id")
/*     */     public Builder guildId(Id value) {
/* 686 */       this.guildId_id = value;
/* 687 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder addMember(MemberData element) {
/* 696 */       this.members.add(Objects.<MemberData>requireNonNull(element, "members element"));
/* 697 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder addMembers(MemberData... elements) {
/* 706 */       for (MemberData element : elements) {
/* 707 */         this.members.add(Objects.<MemberData>requireNonNull(element, "members element"));
/*     */       }
/* 709 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("members")
/*     */     public final Builder members(Iterable<? extends MemberData> elements) {
/* 720 */       this.members.clear();
/* 721 */       return addAllMembers(elements);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder addAllMembers(Iterable<? extends MemberData> elements) {
/* 730 */       for (MemberData element : elements) {
/* 731 */         this.members.add(Objects.<MemberData>requireNonNull(element, "members element"));
/*     */       }
/* 733 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("chunk_index")
/*     */     public final Builder chunkIndex(int chunkIndex) {
/* 743 */       this.chunkIndex = chunkIndex;
/* 744 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 745 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("chunk_count")
/*     */     public final Builder chunkCount(int chunkCount) {
/* 755 */       this.chunkCount = chunkCount;
/* 756 */       this.initBits &= 0xFFFFFFFFFFFFFFFDL;
/* 757 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addNotFound(String element) {
/* 761 */       notFound_getOrCreate().add(element);
/* 762 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addAllNotFound(List<String> elements) {
/* 766 */       notFound_getOrCreate().addAll(elements);
/* 767 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("not_found")
/*     */     public Builder notFound(Possible<List<String>> elements) {
/* 772 */       this.notFound_list = null;
/* 773 */       elements.toOptional().ifPresent(e -> notFound_getOrCreate().addAll(e));
/* 774 */       return this;
/*     */     }
/*     */     
/*     */     public Builder notFound(List<String> elements) {
/* 778 */       this.notFound_list = new ArrayList<>(elements);
/* 779 */       return this;
/*     */     }
/*     */     
/*     */     public Builder notFound(Iterable<String> elements) {
/* 783 */       this.notFound_list = (List<String>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/* 784 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addPresence(PresenceData element) {
/* 788 */       presences_getOrCreate().add(element);
/* 789 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addAllPresences(List<PresenceData> elements) {
/* 793 */       presences_getOrCreate().addAll(elements);
/* 794 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("presences")
/*     */     public Builder presences(Possible<List<PresenceData>> elements) {
/* 799 */       this.presences_list = null;
/* 800 */       elements.toOptional().ifPresent(e -> presences_getOrCreate().addAll(e));
/* 801 */       return this;
/*     */     }
/*     */     
/*     */     public Builder presences(List<PresenceData> elements) {
/* 805 */       this.presences_list = new ArrayList<>(elements);
/* 806 */       return this;
/*     */     }
/*     */     
/*     */     public Builder presences(Iterable<PresenceData> elements) {
/* 810 */       this.presences_list = (List<PresenceData>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/* 811 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("nonce")
/*     */     public Builder nonce(Possible<String> value) {
/* 816 */       this.nonce_possible = value;
/* 817 */       return this;
/*     */     }
/*     */     
/*     */     public Builder nonce(String value) {
/* 821 */       this.nonce_possible = Possible.of(value);
/* 822 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableGuildMembersChunk build() {
/* 831 */       if (this.initBits != 0L) {
/* 832 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 834 */       return new ImmutableGuildMembersChunk(null, 
/*     */           
/* 836 */           guildId_build(), ImmutableGuildMembersChunk
/* 837 */           .createUnmodifiableList(true, (List)this.members), this.chunkIndex, this.chunkCount, 
/*     */ 
/*     */           
/* 840 */           notFound_build(), 
/* 841 */           presences_build(), 
/* 842 */           nonce_build());
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 846 */       List<String> attributes = new ArrayList<>();
/* 847 */       if ((this.initBits & 0x1L) != 0L) attributes.add("chunkIndex"); 
/* 848 */       if ((this.initBits & 0x2L) != 0L) attributes.add("chunkCount"); 
/* 849 */       return "Cannot build GuildMembersChunk, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Id guildId_build() {
/* 853 */       return this.guildId_id;
/*     */     }
/*     */     
/*     */     private Possible<List<String>> notFound_build() {
/* 857 */       return (this.notFound_list == null) ? Possible.absent() : 
/* 858 */         Possible.of(this.notFound_list);
/*     */     }
/*     */     
/*     */     private List<String> notFound_getOrCreate() {
/* 862 */       if (this.notFound_list == null) {
/* 863 */         this.notFound_list = new ArrayList<>();
/*     */       }
/* 865 */       return this.notFound_list;
/*     */     }
/*     */     
/*     */     private Possible<List<PresenceData>> presences_build() {
/* 869 */       return (this.presences_list == null) ? Possible.absent() : 
/* 870 */         Possible.of(this.presences_list);
/*     */     }
/*     */     
/*     */     private List<PresenceData> presences_getOrCreate() {
/* 874 */       if (this.presences_list == null) {
/* 875 */         this.presences_list = new ArrayList<>();
/*     */       }
/* 877 */       return this.presences_list;
/*     */     }
/*     */     
/*     */     private Possible<String> nonce_build() {
/* 881 */       return this.nonce_possible;
/*     */     }
/*     */     private Builder() {} }
/*     */   
/*     */   private static <T> List<T> createSafeList(Iterable<? extends T> iterable, boolean checkNulls, boolean skipNulls) {
/*     */     ArrayList<T> list;
/* 887 */     if (iterable instanceof Collection) {
/* 888 */       int size = ((Collection)iterable).size();
/* 889 */       if (size == 0) return Collections.emptyList(); 
/* 890 */       list = new ArrayList<>();
/*     */     } else {
/* 892 */       list = new ArrayList<>();
/*     */     } 
/* 894 */     for (T element : iterable) {
/* 895 */       if (skipNulls && element == null)
/* 896 */         continue;  if (checkNulls) Objects.requireNonNull(element, "element"); 
/* 897 */       list.add(element);
/*     */     } 
/* 899 */     return list;
/*     */   }
/*     */   
/*     */   private static <T> List<T> createUnmodifiableList(boolean clone, List<T> list) {
/* 903 */     switch (list.size()) { case 0:
/* 904 */         return Collections.emptyList();
/* 905 */       case 1: return Collections.singletonList(list.get(0)); }
/*     */     
/* 907 */     if (clone) {
/* 908 */       return Collections.unmodifiableList(new ArrayList<>(list));
/*     */     }
/* 910 */     if (list instanceof ArrayList) {
/* 911 */       ((ArrayList)list).trimToSize();
/*     */     }
/* 913 */     return Collections.unmodifiableList(list);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\gateway\ImmutableGuildMembersChunk.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */