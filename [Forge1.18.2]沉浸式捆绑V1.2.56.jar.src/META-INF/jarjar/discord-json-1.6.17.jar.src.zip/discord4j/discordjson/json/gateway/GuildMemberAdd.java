/*    */ package discord4j.discordjson.json.gateway;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonProperty;
/*    */ import com.fasterxml.jackson.annotation.JsonUnwrapped;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import discord4j.discordjson.Id;
/*    */ import discord4j.discordjson.json.MemberData;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ @JsonSerialize(as = ImmutableGuildMemberAdd.class)
/*    */ @JsonDeserialize(as = ImmutableGuildMemberAdd.class)
/*    */ @Immutable
/*    */ public interface GuildMemberAdd
/*    */   extends Dispatch {
/*    */   static ImmutableGuildMemberAdd.Builder builder() {
/* 17 */     return ImmutableGuildMemberAdd.builder();
/*    */   }
/*    */   
/*    */   @JsonProperty("guild_id")
/*    */   Id guildId();
/*    */   
/*    */   @JsonUnwrapped
/*    */   MemberData member();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\gateway\GuildMemberAdd.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */