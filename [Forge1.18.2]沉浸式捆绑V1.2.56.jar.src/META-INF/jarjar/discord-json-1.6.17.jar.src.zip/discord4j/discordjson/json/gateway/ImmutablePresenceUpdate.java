/*     */ package discord4j.discordjson.json.gateway;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.Id;
/*     */ import discord4j.discordjson.json.ActivityData;
/*     */ import discord4j.discordjson.json.ClientStatusData;
/*     */ import discord4j.discordjson.json.PartialUserData;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "PresenceUpdate", generator = "Immutables")
/*     */ public final class ImmutablePresenceUpdate
/*     */   implements PresenceUpdate
/*     */ {
/*     */   private final PartialUserData user;
/*     */   private final long guildId_value;
/*     */   private final String status;
/*     */   private final List<ActivityData> activities;
/*     */   private final ClientStatusData clientStatus;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   private volatile transient InitShim initShim;
/*     */   
/*     */   private ImmutablePresenceUpdate(PartialUserData user, Id guildId, String status, Iterable<? extends ActivityData> activities, ClientStatusData clientStatus) {
/*  71 */     this.initShim = new InitShim(); this.user = Objects.<PartialUserData>requireNonNull(user, "user"); Id guildId$impl = guildId; this.status = Objects.<String>requireNonNull(status, "status"); this.activities = createUnmodifiableList(false, createSafeList(activities, true, false)); this.clientStatus = Objects.<ClientStatusData>requireNonNull(clientStatus, "clientStatus"); this.guildId_value = guildId$impl.asLong(); this.initShim = null; } private ImmutablePresenceUpdate(ImmutablePresenceUpdate original, PartialUserData user, Id guildId, String status, List<ActivityData> activities, ClientStatusData clientStatus) { this.initShim = new InitShim(); this.user = user; Id guildId$impl = guildId;
/*     */     this.status = status;
/*     */     this.activities = activities;
/*     */     this.clientStatus = clientStatus;
/*     */     this.guildId_value = guildId$impl.asLong();
/*  76 */     this.initShim = null; } @Generated(from = "PresenceUpdate", generator = "Immutables") private final class InitShim { private InitShim() {} private String formatInitCycleMessage() { List<String> attributes = new ArrayList<>();
/*  77 */       return "Cannot build PresenceUpdate, attribute initializers form cycle " + attributes; }
/*     */      }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("user")
/*     */   public PartialUserData user() {
/*  87 */     return this.user;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("guild_id")
/*     */   public Id guildId() {
/*  96 */     return Id.of(this.guildId_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("status")
/*     */   public String status() {
/* 105 */     return this.status;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("activities")
/*     */   public List<ActivityData> activities() {
/* 114 */     return this.activities;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("client_status")
/*     */   public ClientStatusData clientStatus() {
/* 123 */     return this.clientStatus;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutablePresenceUpdate withUser(PartialUserData value) {
/* 133 */     if (this.user == value) return this; 
/* 134 */     PartialUserData newValue = Objects.<PartialUserData>requireNonNull(value, "user");
/* 135 */     return new ImmutablePresenceUpdate(this, newValue, guildId(), this.status, this.activities, this.clientStatus);
/*     */   }
/*     */   
/*     */   public ImmutablePresenceUpdate withGuildId(long value) {
/* 139 */     Id newValue = Id.of(value);
/* 140 */     return new ImmutablePresenceUpdate(this, this.user, newValue, this.status, this.activities, this.clientStatus);
/*     */   }
/*     */   
/*     */   public ImmutablePresenceUpdate withGuildId(String value) {
/* 144 */     Id newValue = Id.of(value);
/* 145 */     return new ImmutablePresenceUpdate(this, this.user, newValue, this.status, this.activities, this.clientStatus);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutablePresenceUpdate withStatus(String value) {
/* 155 */     String newValue = Objects.<String>requireNonNull(value, "status");
/* 156 */     if (this.status.equals(newValue)) return this; 
/* 157 */     return new ImmutablePresenceUpdate(this, this.user, guildId(), newValue, this.activities, this.clientStatus);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutablePresenceUpdate withActivities(ActivityData... elements) {
/* 166 */     List<ActivityData> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/* 167 */     return new ImmutablePresenceUpdate(this, this.user, guildId(), this.status, newValue, this.clientStatus);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutablePresenceUpdate withActivities(Iterable<? extends ActivityData> elements) {
/* 177 */     if (this.activities == elements) return this; 
/* 178 */     List<ActivityData> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/* 179 */     return new ImmutablePresenceUpdate(this, this.user, guildId(), this.status, newValue, this.clientStatus);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutablePresenceUpdate withClientStatus(ClientStatusData value) {
/* 189 */     if (this.clientStatus == value) return this; 
/* 190 */     ClientStatusData newValue = Objects.<ClientStatusData>requireNonNull(value, "clientStatus");
/* 191 */     return new ImmutablePresenceUpdate(this, this.user, guildId(), this.status, this.activities, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 200 */     if (this == another) return true; 
/* 201 */     return (another instanceof ImmutablePresenceUpdate && 
/* 202 */       equalTo(0, (ImmutablePresenceUpdate)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutablePresenceUpdate another) {
/* 206 */     return (this.user.equals(another.user) && 
/* 207 */       Objects.equals(Long.valueOf(this.guildId_value), Long.valueOf(another.guildId_value)) && this.status
/* 208 */       .equals(another.status) && this.activities
/* 209 */       .equals(another.activities) && this.clientStatus
/* 210 */       .equals(another.clientStatus));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 219 */     int h = 5381;
/* 220 */     h += (h << 5) + this.user.hashCode();
/* 221 */     h += (h << 5) + Objects.hashCode(Long.valueOf(this.guildId_value));
/* 222 */     h += (h << 5) + this.status.hashCode();
/* 223 */     h += (h << 5) + this.activities.hashCode();
/* 224 */     h += (h << 5) + this.clientStatus.hashCode();
/* 225 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 234 */     return "PresenceUpdate{user=" + this.user + ", guildId=" + 
/*     */       
/* 236 */       Objects.toString(Long.valueOf(this.guildId_value)) + ", status=" + this.status + ", activities=" + this.activities + ", clientStatus=" + this.clientStatus + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "PresenceUpdate", generator = "Immutables")
/*     */   static final class Json
/*     */     implements PresenceUpdate
/*     */   {
/*     */     PartialUserData user;
/*     */ 
/*     */     
/*     */     Id guildId;
/*     */     
/*     */     String status;
/*     */     
/* 255 */     List<ActivityData> activities = Collections.emptyList(); ClientStatusData clientStatus;
/*     */     
/*     */     @JsonProperty("user")
/*     */     public void setUser(PartialUserData user) {
/* 259 */       this.user = user;
/*     */     }
/*     */     @JsonProperty("guild_id")
/*     */     public void setGuildId(Id guildId) {
/* 263 */       this.guildId = guildId;
/*     */     }
/*     */     @JsonProperty("status")
/*     */     public void setStatus(String status) {
/* 267 */       this.status = status;
/*     */     }
/*     */     @JsonProperty("activities")
/*     */     public void setActivities(List<ActivityData> activities) {
/* 271 */       this.activities = activities;
/*     */     }
/*     */     @JsonProperty("client_status")
/*     */     public void setClientStatus(ClientStatusData clientStatus) {
/* 275 */       this.clientStatus = clientStatus;
/*     */     }
/*     */     public PartialUserData user() {
/* 278 */       throw new UnsupportedOperationException();
/*     */     } public Id guildId() {
/* 280 */       throw new UnsupportedOperationException();
/*     */     } public String status() {
/* 282 */       throw new UnsupportedOperationException();
/*     */     } public List<ActivityData> activities() {
/* 284 */       throw new UnsupportedOperationException();
/*     */     } public ClientStatusData clientStatus() {
/* 286 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutablePresenceUpdate fromJson(Json json) {
/* 297 */     Builder builder = builder();
/* 298 */     if (json.user != null) {
/* 299 */       builder.user(json.user);
/*     */     }
/* 301 */     if (json.guildId != null) {
/* 302 */       builder.guildId(json.guildId);
/*     */     }
/* 304 */     if (json.status != null) {
/* 305 */       builder.status(json.status);
/*     */     }
/* 307 */     if (json.activities != null) {
/* 308 */       builder.addAllActivities(json.activities);
/*     */     }
/* 310 */     if (json.clientStatus != null) {
/* 311 */       builder.clientStatus(json.clientStatus);
/*     */     }
/* 313 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutablePresenceUpdate of(PartialUserData user, Id guildId, String status, List<ActivityData> activities, ClientStatusData clientStatus) {
/* 326 */     return of(user, guildId, status, activities, clientStatus);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutablePresenceUpdate of(PartialUserData user, Id guildId, String status, Iterable<? extends ActivityData> activities, ClientStatusData clientStatus) {
/* 339 */     return new ImmutablePresenceUpdate(user, guildId, status, activities, clientStatus);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutablePresenceUpdate copyOf(PresenceUpdate instance) {
/* 350 */     if (instance instanceof ImmutablePresenceUpdate) {
/* 351 */       return (ImmutablePresenceUpdate)instance;
/*     */     }
/* 353 */     return builder()
/* 354 */       .from(instance)
/* 355 */       .build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 372 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "PresenceUpdate", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_USER = 1L;
/*     */ 
/*     */     
/*     */     private static final long INIT_BIT_STATUS = 2L;
/*     */     
/*     */     private static final long INIT_BIT_CLIENT_STATUS = 4L;
/*     */     
/* 387 */     private long initBits = 7L;
/*     */     
/* 389 */     private Id guildId_id = null;
/*     */     private PartialUserData user;
/*     */     private String status;
/* 392 */     private List<ActivityData> activities = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private ClientStatusData clientStatus;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(PresenceUpdate instance) {
/* 407 */       Objects.requireNonNull(instance, "instance");
/* 408 */       user(instance.user());
/* 409 */       guildId(instance.guildId());
/* 410 */       status(instance.status());
/* 411 */       addAllActivities(instance.activities());
/* 412 */       clientStatus(instance.clientStatus());
/* 413 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("user")
/*     */     public final Builder user(PartialUserData user) {
/* 423 */       this.user = Objects.<PartialUserData>requireNonNull(user, "user");
/* 424 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 425 */       return this;
/*     */     }
/*     */     
/*     */     public Builder guildId(String value) {
/* 429 */       this.guildId_id = Id.of(value);
/* 430 */       return this;
/*     */     }
/*     */     
/*     */     public Builder guildId(long value) {
/* 434 */       this.guildId_id = Id.of(value);
/* 435 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("guild_id")
/*     */     public Builder guildId(Id value) {
/* 440 */       this.guildId_id = value;
/* 441 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("status")
/*     */     public final Builder status(String status) {
/* 451 */       this.status = Objects.<String>requireNonNull(status, "status");
/* 452 */       this.initBits &= 0xFFFFFFFFFFFFFFFDL;
/* 453 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder addActivity(ActivityData element) {
/* 462 */       this.activities.add(Objects.<ActivityData>requireNonNull(element, "activities element"));
/* 463 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder addActivities(ActivityData... elements) {
/* 472 */       for (ActivityData element : elements) {
/* 473 */         this.activities.add(Objects.<ActivityData>requireNonNull(element, "activities element"));
/*     */       }
/* 475 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("activities")
/*     */     public final Builder activities(Iterable<? extends ActivityData> elements) {
/* 486 */       this.activities.clear();
/* 487 */       return addAllActivities(elements);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder addAllActivities(Iterable<? extends ActivityData> elements) {
/* 496 */       for (ActivityData element : elements) {
/* 497 */         this.activities.add(Objects.<ActivityData>requireNonNull(element, "activities element"));
/*     */       }
/* 499 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("client_status")
/*     */     public final Builder clientStatus(ClientStatusData clientStatus) {
/* 509 */       this.clientStatus = Objects.<ClientStatusData>requireNonNull(clientStatus, "clientStatus");
/* 510 */       this.initBits &= 0xFFFFFFFFFFFFFFFBL;
/* 511 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutablePresenceUpdate build() {
/* 520 */       if (this.initBits != 0L) {
/* 521 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 523 */       return new ImmutablePresenceUpdate(null, this.user, guildId_build(), this.status, ImmutablePresenceUpdate.createUnmodifiableList(true, (List)this.activities), this.clientStatus);
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 527 */       List<String> attributes = new ArrayList<>();
/* 528 */       if ((this.initBits & 0x1L) != 0L) attributes.add("user"); 
/* 529 */       if ((this.initBits & 0x2L) != 0L) attributes.add("status"); 
/* 530 */       if ((this.initBits & 0x4L) != 0L) attributes.add("clientStatus"); 
/* 531 */       return "Cannot build PresenceUpdate, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Id guildId_build() {
/* 535 */       return this.guildId_id;
/*     */     }
/*     */     private Builder() {} }
/*     */   
/*     */   private static <T> List<T> createSafeList(Iterable<? extends T> iterable, boolean checkNulls, boolean skipNulls) {
/*     */     ArrayList<T> list;
/* 541 */     if (iterable instanceof Collection) {
/* 542 */       int size = ((Collection)iterable).size();
/* 543 */       if (size == 0) return Collections.emptyList(); 
/* 544 */       list = new ArrayList<>();
/*     */     } else {
/* 546 */       list = new ArrayList<>();
/*     */     } 
/* 548 */     for (T element : iterable) {
/* 549 */       if (skipNulls && element == null)
/* 550 */         continue;  if (checkNulls) Objects.requireNonNull(element, "element"); 
/* 551 */       list.add(element);
/*     */     } 
/* 553 */     return list;
/*     */   }
/*     */   
/*     */   private static <T> List<T> createUnmodifiableList(boolean clone, List<T> list) {
/* 557 */     switch (list.size()) { case 0:
/* 558 */         return Collections.emptyList();
/* 559 */       case 1: return Collections.singletonList(list.get(0)); }
/*     */     
/* 561 */     if (clone) {
/* 562 */       return Collections.unmodifiableList(new ArrayList<>(list));
/*     */     }
/* 564 */     if (list instanceof ArrayList) {
/* 565 */       ((ArrayList)list).trimToSize();
/*     */     }
/* 567 */     return Collections.unmodifiableList(list);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\gateway\ImmutablePresenceUpdate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */