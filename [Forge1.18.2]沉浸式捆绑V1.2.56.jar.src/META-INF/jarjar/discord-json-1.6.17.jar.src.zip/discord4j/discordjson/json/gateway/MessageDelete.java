/*    */ package discord4j.discordjson.json.gateway;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonProperty;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import discord4j.discordjson.Id;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ @JsonSerialize(as = ImmutableMessageDelete.class)
/*    */ @JsonDeserialize(as = ImmutableMessageDelete.class)
/*    */ @Immutable
/*    */ public interface MessageDelete
/*    */   extends Dispatch {
/*    */   static ImmutableMessageDelete.Builder builder() {
/* 16 */     return ImmutableMessageDelete.builder();
/*    */   }
/*    */   
/*    */   Id id();
/*    */   
/*    */   @JsonProperty("channel_id")
/*    */   Id channelId();
/*    */   
/*    */   @JsonProperty("guild_id")
/*    */   Possible<Id> guildId();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\gateway\MessageDelete.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */