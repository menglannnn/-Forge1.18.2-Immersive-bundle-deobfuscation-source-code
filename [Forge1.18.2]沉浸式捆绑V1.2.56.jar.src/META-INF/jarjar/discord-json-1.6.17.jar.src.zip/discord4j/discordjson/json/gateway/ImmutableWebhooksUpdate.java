/*     */ package discord4j.discordjson.json.gateway;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.Id;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "WebhooksUpdate", generator = "Immutables")
/*     */ public final class ImmutableWebhooksUpdate
/*     */   implements WebhooksUpdate
/*     */ {
/*     */   private final long guildId_value;
/*     */   private final long channelId_value;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   
/*     */   private ImmutableWebhooksUpdate(Id guildId, Id channelId) {
/*  29 */     Id guildId$impl = guildId;
/*  30 */     Id channelId$impl = channelId;
/*  31 */     this.guildId_value = guildId$impl.asLong();
/*  32 */     this.channelId_value = channelId$impl.asLong();
/*  33 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ImmutableWebhooksUpdate(ImmutableWebhooksUpdate original, Id guildId, Id channelId) {
/*  40 */     Id guildId$impl = guildId;
/*  41 */     Id channelId$impl = channelId;
/*  42 */     this.guildId_value = guildId$impl.asLong();
/*  43 */     this.channelId_value = channelId$impl.asLong();
/*  44 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  50 */   private volatile transient InitShim initShim = new InitShim();
/*     */   
/*     */   @Generated(from = "WebhooksUpdate", generator = "Immutables")
/*     */   private final class InitShim {
/*     */     private String formatInitCycleMessage() {
/*  55 */       List<String> attributes = new ArrayList<>();
/*  56 */       return "Cannot build WebhooksUpdate, attribute initializers form cycle " + attributes;
/*     */     }
/*     */ 
/*     */     
/*     */     private InitShim() {}
/*     */   }
/*     */ 
/*     */   
/*     */   @JsonProperty("guild_id")
/*     */   public Id guildId() {
/*  66 */     return Id.of(this.guildId_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("channel_id")
/*     */   public Id channelId() {
/*  75 */     return Id.of(this.channelId_value);
/*     */   }
/*     */   
/*     */   public ImmutableWebhooksUpdate withGuildId(long value) {
/*  79 */     Id newValue = Id.of(value);
/*  80 */     return new ImmutableWebhooksUpdate(this, newValue, channelId());
/*     */   }
/*     */   
/*     */   public ImmutableWebhooksUpdate withGuildId(String value) {
/*  84 */     Id newValue = Id.of(value);
/*  85 */     return new ImmutableWebhooksUpdate(this, newValue, channelId());
/*     */   }
/*     */   
/*     */   public ImmutableWebhooksUpdate withChannelId(long value) {
/*  89 */     Id newValue = Id.of(value);
/*  90 */     return new ImmutableWebhooksUpdate(this, guildId(), newValue);
/*     */   }
/*     */   
/*     */   public ImmutableWebhooksUpdate withChannelId(String value) {
/*  94 */     Id newValue = Id.of(value);
/*  95 */     return new ImmutableWebhooksUpdate(this, guildId(), newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 104 */     if (this == another) return true; 
/* 105 */     return (another instanceof ImmutableWebhooksUpdate && 
/* 106 */       equalTo(0, (ImmutableWebhooksUpdate)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableWebhooksUpdate another) {
/* 110 */     return (Objects.equals(Long.valueOf(this.guildId_value), Long.valueOf(another.guildId_value)) && 
/* 111 */       Objects.equals(Long.valueOf(this.channelId_value), Long.valueOf(another.channelId_value)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 120 */     int h = 5381;
/* 121 */     h += (h << 5) + Objects.hashCode(Long.valueOf(this.guildId_value));
/* 122 */     h += (h << 5) + Objects.hashCode(Long.valueOf(this.channelId_value));
/* 123 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 132 */     return "WebhooksUpdate{guildId=" + 
/* 133 */       Objects.toString(Long.valueOf(this.guildId_value)) + ", channelId=" + 
/* 134 */       Objects.toString(Long.valueOf(this.channelId_value)) + "}";
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "WebhooksUpdate", generator = "Immutables")
/*     */   static final class Json
/*     */     implements WebhooksUpdate
/*     */   {
/*     */     Id guildId;
/*     */     
/*     */     Id channelId;
/*     */     
/*     */     @JsonProperty("guild_id")
/*     */     public void setGuildId(Id guildId) {
/* 151 */       this.guildId = guildId;
/*     */     }
/*     */     @JsonProperty("channel_id")
/*     */     public void setChannelId(Id channelId) {
/* 155 */       this.channelId = channelId;
/*     */     }
/*     */     public Id guildId() {
/* 158 */       throw new UnsupportedOperationException();
/*     */     } public Id channelId() {
/* 160 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableWebhooksUpdate fromJson(Json json) {
/* 171 */     Builder builder = builder();
/* 172 */     if (json.guildId != null) {
/* 173 */       builder.guildId(json.guildId);
/*     */     }
/* 175 */     if (json.channelId != null) {
/* 176 */       builder.channelId(json.channelId);
/*     */     }
/* 178 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableWebhooksUpdate of(Id guildId, Id channelId) {
/* 188 */     return new ImmutableWebhooksUpdate(guildId, channelId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableWebhooksUpdate copyOf(WebhooksUpdate instance) {
/* 199 */     if (instance instanceof ImmutableWebhooksUpdate) {
/* 200 */       return (ImmutableWebhooksUpdate)instance;
/*     */     }
/* 202 */     return builder()
/* 203 */       .from(instance)
/* 204 */       .build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 218 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "WebhooksUpdate", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/* 230 */     private Id guildId_id = null;
/* 231 */     private Id channelId_id = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(WebhooksUpdate instance) {
/* 244 */       Objects.requireNonNull(instance, "instance");
/* 245 */       guildId(instance.guildId());
/* 246 */       channelId(instance.channelId());
/* 247 */       return this;
/*     */     }
/*     */     
/*     */     public Builder guildId(String value) {
/* 251 */       this.guildId_id = Id.of(value);
/* 252 */       return this;
/*     */     }
/*     */     
/*     */     public Builder guildId(long value) {
/* 256 */       this.guildId_id = Id.of(value);
/* 257 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("guild_id")
/*     */     public Builder guildId(Id value) {
/* 262 */       this.guildId_id = value;
/* 263 */       return this;
/*     */     }
/*     */     
/*     */     public Builder channelId(String value) {
/* 267 */       this.channelId_id = Id.of(value);
/* 268 */       return this;
/*     */     }
/*     */     
/*     */     public Builder channelId(long value) {
/* 272 */       this.channelId_id = Id.of(value);
/* 273 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("channel_id")
/*     */     public Builder channelId(Id value) {
/* 278 */       this.channelId_id = value;
/* 279 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableWebhooksUpdate build() {
/* 288 */       return new ImmutableWebhooksUpdate(null, guildId_build(), channelId_build());
/*     */     }
/*     */     
/*     */     private Id guildId_build() {
/* 292 */       return this.guildId_id;
/*     */     }
/*     */     
/*     */     private Id channelId_build() {
/* 296 */       return this.channelId_id;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\gateway\ImmutableWebhooksUpdate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */