/*     */ package discord4j.discordjson.json.gateway;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.annotation.JsonUnwrapped;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.json.AutoModRuleData;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "AutoModRuleUpdate", generator = "Immutables")
/*     */ public final class ImmutableAutoModRuleUpdate
/*     */   implements AutoModRuleUpdate
/*     */ {
/*     */   private final AutoModRuleData automodrule;
/*     */   
/*     */   private ImmutableAutoModRuleUpdate(AutoModRuleData automodrule) {
/*  29 */     this.automodrule = Objects.<AutoModRuleData>requireNonNull(automodrule, "automodrule");
/*     */   }
/*     */   
/*     */   private ImmutableAutoModRuleUpdate(ImmutableAutoModRuleUpdate original, AutoModRuleData automodrule) {
/*  33 */     this.automodrule = automodrule;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("automodrule")
/*     */   @JsonUnwrapped
/*     */   public AutoModRuleData automodrule() {
/*  43 */     return this.automodrule;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableAutoModRuleUpdate withAutomodrule(AutoModRuleData value) {
/*  53 */     if (this.automodrule == value) return this; 
/*  54 */     AutoModRuleData newValue = Objects.<AutoModRuleData>requireNonNull(value, "automodrule");
/*  55 */     return new ImmutableAutoModRuleUpdate(this, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/*  64 */     if (this == another) return true; 
/*  65 */     return (another instanceof ImmutableAutoModRuleUpdate && 
/*  66 */       equalTo(0, (ImmutableAutoModRuleUpdate)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableAutoModRuleUpdate another) {
/*  70 */     return this.automodrule.equals(another.automodrule);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  79 */     int h = 5381;
/*  80 */     h += (h << 5) + this.automodrule.hashCode();
/*  81 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/*  90 */     return "AutoModRuleUpdate{automodrule=" + this.automodrule + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "AutoModRuleUpdate", generator = "Immutables")
/*     */   static final class Json
/*     */     implements AutoModRuleUpdate
/*     */   {
/*     */     AutoModRuleData automodrule;
/*     */ 
/*     */     
/*     */     @JsonProperty("automodrule")
/*     */     @JsonUnwrapped
/*     */     public void setAutomodrule(AutoModRuleData automodrule) {
/* 108 */       this.automodrule = automodrule;
/*     */     }
/*     */     public AutoModRuleData automodrule() {
/* 111 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableAutoModRuleUpdate fromJson(Json json) {
/* 122 */     Builder builder = builder();
/* 123 */     if (json.automodrule != null) {
/* 124 */       builder.automodrule(json.automodrule);
/*     */     }
/* 126 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableAutoModRuleUpdate of(AutoModRuleData automodrule) {
/* 135 */     return new ImmutableAutoModRuleUpdate(automodrule);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableAutoModRuleUpdate copyOf(AutoModRuleUpdate instance) {
/* 146 */     if (instance instanceof ImmutableAutoModRuleUpdate) {
/* 147 */       return (ImmutableAutoModRuleUpdate)instance;
/*     */     }
/* 149 */     return builder()
/* 150 */       .from(instance)
/* 151 */       .build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 164 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "AutoModRuleUpdate", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_AUTOMODRULE = 1L;
/*     */ 
/*     */ 
/*     */     
/* 177 */     private long initBits = 1L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private AutoModRuleData automodrule;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(AutoModRuleUpdate instance) {
/* 192 */       Objects.requireNonNull(instance, "instance");
/* 193 */       automodrule(instance.automodrule());
/* 194 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("automodrule")
/*     */     @JsonUnwrapped
/*     */     public final Builder automodrule(AutoModRuleData automodrule) {
/* 205 */       this.automodrule = Objects.<AutoModRuleData>requireNonNull(automodrule, "automodrule");
/* 206 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 207 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableAutoModRuleUpdate build() {
/* 216 */       if (this.initBits != 0L) {
/* 217 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 219 */       return new ImmutableAutoModRuleUpdate(null, this.automodrule);
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 223 */       List<String> attributes = new ArrayList<>();
/* 224 */       if ((this.initBits & 0x1L) != 0L) attributes.add("automodrule"); 
/* 225 */       return "Cannot build AutoModRuleUpdate, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\gateway\ImmutableAutoModRuleUpdate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */