package discord4j.discordjson.json.gateway;

import discord4j.discordjson.MetaEncodingEnabled;
import org.immutables.value.Value.Style;
import reactor.util.annotation.NonNullApi;



/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\gateway\package-info.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */