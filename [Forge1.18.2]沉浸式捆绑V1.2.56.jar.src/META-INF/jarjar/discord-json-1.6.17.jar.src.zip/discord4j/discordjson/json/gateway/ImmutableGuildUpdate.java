/*     */ package discord4j.discordjson.json.gateway;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.annotation.JsonUnwrapped;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.json.GuildUpdateData;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "GuildUpdate", generator = "Immutables")
/*     */ public final class ImmutableGuildUpdate
/*     */   implements GuildUpdate
/*     */ {
/*     */   private final GuildUpdateData guild;
/*     */   
/*     */   private ImmutableGuildUpdate(GuildUpdateData guild) {
/*  29 */     this.guild = Objects.<GuildUpdateData>requireNonNull(guild, "guild");
/*     */   }
/*     */   
/*     */   private ImmutableGuildUpdate(ImmutableGuildUpdate original, GuildUpdateData guild) {
/*  33 */     this.guild = guild;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("guild")
/*     */   @JsonUnwrapped
/*     */   public GuildUpdateData guild() {
/*  43 */     return this.guild;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableGuildUpdate withGuild(GuildUpdateData value) {
/*  53 */     if (this.guild == value) return this; 
/*  54 */     GuildUpdateData newValue = Objects.<GuildUpdateData>requireNonNull(value, "guild");
/*  55 */     return new ImmutableGuildUpdate(this, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/*  64 */     if (this == another) return true; 
/*  65 */     return (another instanceof ImmutableGuildUpdate && 
/*  66 */       equalTo(0, (ImmutableGuildUpdate)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableGuildUpdate another) {
/*  70 */     return this.guild.equals(another.guild);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  79 */     int h = 5381;
/*  80 */     h += (h << 5) + this.guild.hashCode();
/*  81 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/*  90 */     return "GuildUpdate{guild=" + this.guild + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "GuildUpdate", generator = "Immutables")
/*     */   static final class Json
/*     */     implements GuildUpdate
/*     */   {
/*     */     GuildUpdateData guild;
/*     */ 
/*     */     
/*     */     @JsonProperty("guild")
/*     */     @JsonUnwrapped
/*     */     public void setGuild(GuildUpdateData guild) {
/* 108 */       this.guild = guild;
/*     */     }
/*     */     public GuildUpdateData guild() {
/* 111 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableGuildUpdate fromJson(Json json) {
/* 122 */     Builder builder = builder();
/* 123 */     if (json.guild != null) {
/* 124 */       builder.guild(json.guild);
/*     */     }
/* 126 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableGuildUpdate of(GuildUpdateData guild) {
/* 135 */     return new ImmutableGuildUpdate(guild);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableGuildUpdate copyOf(GuildUpdate instance) {
/* 146 */     if (instance instanceof ImmutableGuildUpdate) {
/* 147 */       return (ImmutableGuildUpdate)instance;
/*     */     }
/* 149 */     return builder()
/* 150 */       .from(instance)
/* 151 */       .build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 164 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "GuildUpdate", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_GUILD = 1L;
/*     */ 
/*     */ 
/*     */     
/* 177 */     private long initBits = 1L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private GuildUpdateData guild;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(GuildUpdate instance) {
/* 192 */       Objects.requireNonNull(instance, "instance");
/* 193 */       guild(instance.guild());
/* 194 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("guild")
/*     */     @JsonUnwrapped
/*     */     public final Builder guild(GuildUpdateData guild) {
/* 205 */       this.guild = Objects.<GuildUpdateData>requireNonNull(guild, "guild");
/* 206 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 207 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableGuildUpdate build() {
/* 216 */       if (this.initBits != 0L) {
/* 217 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 219 */       return new ImmutableGuildUpdate(null, this.guild);
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 223 */       List<String> attributes = new ArrayList<>();
/* 224 */       if ((this.initBits & 0x1L) != 0L) attributes.add("guild"); 
/* 225 */       return "Cannot build GuildUpdate, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\gateway\ImmutableGuildUpdate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */