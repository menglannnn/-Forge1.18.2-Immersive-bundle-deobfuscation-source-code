/*     */ package discord4j.discordjson.json.gateway;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.Id;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "GuildRoleDelete", generator = "Immutables")
/*     */ public final class ImmutableGuildRoleDelete
/*     */   implements GuildRoleDelete
/*     */ {
/*     */   private final long guildId_value;
/*     */   private final long roleId_value;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   
/*     */   private ImmutableGuildRoleDelete(Id guildId, Id roleId) {
/*  29 */     Id guildId$impl = guildId;
/*  30 */     Id roleId$impl = roleId;
/*  31 */     this.guildId_value = guildId$impl.asLong();
/*  32 */     this.roleId_value = roleId$impl.asLong();
/*  33 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ImmutableGuildRoleDelete(ImmutableGuildRoleDelete original, Id guildId, Id roleId) {
/*  40 */     Id guildId$impl = guildId;
/*  41 */     Id roleId$impl = roleId;
/*  42 */     this.guildId_value = guildId$impl.asLong();
/*  43 */     this.roleId_value = roleId$impl.asLong();
/*  44 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  50 */   private volatile transient InitShim initShim = new InitShim();
/*     */   
/*     */   @Generated(from = "GuildRoleDelete", generator = "Immutables")
/*     */   private final class InitShim {
/*     */     private String formatInitCycleMessage() {
/*  55 */       List<String> attributes = new ArrayList<>();
/*  56 */       return "Cannot build GuildRoleDelete, attribute initializers form cycle " + attributes;
/*     */     }
/*     */ 
/*     */     
/*     */     private InitShim() {}
/*     */   }
/*     */ 
/*     */   
/*     */   @JsonProperty("guild_id")
/*     */   public Id guildId() {
/*  66 */     return Id.of(this.guildId_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("role_id")
/*     */   public Id roleId() {
/*  75 */     return Id.of(this.roleId_value);
/*     */   }
/*     */   
/*     */   public ImmutableGuildRoleDelete withGuildId(long value) {
/*  79 */     Id newValue = Id.of(value);
/*  80 */     return new ImmutableGuildRoleDelete(this, newValue, roleId());
/*     */   }
/*     */   
/*     */   public ImmutableGuildRoleDelete withGuildId(String value) {
/*  84 */     Id newValue = Id.of(value);
/*  85 */     return new ImmutableGuildRoleDelete(this, newValue, roleId());
/*     */   }
/*     */   
/*     */   public ImmutableGuildRoleDelete withRoleId(long value) {
/*  89 */     Id newValue = Id.of(value);
/*  90 */     return new ImmutableGuildRoleDelete(this, guildId(), newValue);
/*     */   }
/*     */   
/*     */   public ImmutableGuildRoleDelete withRoleId(String value) {
/*  94 */     Id newValue = Id.of(value);
/*  95 */     return new ImmutableGuildRoleDelete(this, guildId(), newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 104 */     if (this == another) return true; 
/* 105 */     return (another instanceof ImmutableGuildRoleDelete && 
/* 106 */       equalTo(0, (ImmutableGuildRoleDelete)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableGuildRoleDelete another) {
/* 110 */     return (Objects.equals(Long.valueOf(this.guildId_value), Long.valueOf(another.guildId_value)) && 
/* 111 */       Objects.equals(Long.valueOf(this.roleId_value), Long.valueOf(another.roleId_value)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 120 */     int h = 5381;
/* 121 */     h += (h << 5) + Objects.hashCode(Long.valueOf(this.guildId_value));
/* 122 */     h += (h << 5) + Objects.hashCode(Long.valueOf(this.roleId_value));
/* 123 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 132 */     return "GuildRoleDelete{guildId=" + 
/* 133 */       Objects.toString(Long.valueOf(this.guildId_value)) + ", roleId=" + 
/* 134 */       Objects.toString(Long.valueOf(this.roleId_value)) + "}";
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "GuildRoleDelete", generator = "Immutables")
/*     */   static final class Json
/*     */     implements GuildRoleDelete
/*     */   {
/*     */     Id guildId;
/*     */     
/*     */     Id roleId;
/*     */     
/*     */     @JsonProperty("guild_id")
/*     */     public void setGuildId(Id guildId) {
/* 151 */       this.guildId = guildId;
/*     */     }
/*     */     @JsonProperty("role_id")
/*     */     public void setRoleId(Id roleId) {
/* 155 */       this.roleId = roleId;
/*     */     }
/*     */     public Id guildId() {
/* 158 */       throw new UnsupportedOperationException();
/*     */     } public Id roleId() {
/* 160 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableGuildRoleDelete fromJson(Json json) {
/* 171 */     Builder builder = builder();
/* 172 */     if (json.guildId != null) {
/* 173 */       builder.guildId(json.guildId);
/*     */     }
/* 175 */     if (json.roleId != null) {
/* 176 */       builder.roleId(json.roleId);
/*     */     }
/* 178 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableGuildRoleDelete of(Id guildId, Id roleId) {
/* 188 */     return new ImmutableGuildRoleDelete(guildId, roleId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableGuildRoleDelete copyOf(GuildRoleDelete instance) {
/* 199 */     if (instance instanceof ImmutableGuildRoleDelete) {
/* 200 */       return (ImmutableGuildRoleDelete)instance;
/*     */     }
/* 202 */     return builder()
/* 203 */       .from(instance)
/* 204 */       .build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 218 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "GuildRoleDelete", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/* 230 */     private Id guildId_id = null;
/* 231 */     private Id roleId_id = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(GuildRoleDelete instance) {
/* 244 */       Objects.requireNonNull(instance, "instance");
/* 245 */       guildId(instance.guildId());
/* 246 */       roleId(instance.roleId());
/* 247 */       return this;
/*     */     }
/*     */     
/*     */     public Builder guildId(String value) {
/* 251 */       this.guildId_id = Id.of(value);
/* 252 */       return this;
/*     */     }
/*     */     
/*     */     public Builder guildId(long value) {
/* 256 */       this.guildId_id = Id.of(value);
/* 257 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("guild_id")
/*     */     public Builder guildId(Id value) {
/* 262 */       this.guildId_id = value;
/* 263 */       return this;
/*     */     }
/*     */     
/*     */     public Builder roleId(String value) {
/* 267 */       this.roleId_id = Id.of(value);
/* 268 */       return this;
/*     */     }
/*     */     
/*     */     public Builder roleId(long value) {
/* 272 */       this.roleId_id = Id.of(value);
/* 273 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("role_id")
/*     */     public Builder roleId(Id value) {
/* 278 */       this.roleId_id = value;
/* 279 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableGuildRoleDelete build() {
/* 288 */       return new ImmutableGuildRoleDelete(null, guildId_build(), roleId_build());
/*     */     }
/*     */     
/*     */     private Id guildId_build() {
/* 292 */       return this.guildId_id;
/*     */     }
/*     */     
/*     */     private Id roleId_build() {
/* 296 */       return this.roleId_id;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\gateway\ImmutableGuildRoleDelete.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */