/*     */ package discord4j.discordjson.json.gateway;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.annotation.JsonUnwrapped;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.json.GuildCreateData;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "GuildCreate", generator = "Immutables")
/*     */ public final class ImmutableGuildCreate
/*     */   implements GuildCreate
/*     */ {
/*     */   private final GuildCreateData guild;
/*     */   
/*     */   private ImmutableGuildCreate(GuildCreateData guild) {
/*  29 */     this.guild = Objects.<GuildCreateData>requireNonNull(guild, "guild");
/*     */   }
/*     */   
/*     */   private ImmutableGuildCreate(ImmutableGuildCreate original, GuildCreateData guild) {
/*  33 */     this.guild = guild;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("guild")
/*     */   @JsonUnwrapped
/*     */   public GuildCreateData guild() {
/*  43 */     return this.guild;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableGuildCreate withGuild(GuildCreateData value) {
/*  53 */     if (this.guild == value) return this; 
/*  54 */     GuildCreateData newValue = Objects.<GuildCreateData>requireNonNull(value, "guild");
/*  55 */     return new ImmutableGuildCreate(this, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/*  64 */     if (this == another) return true; 
/*  65 */     return (another instanceof ImmutableGuildCreate && 
/*  66 */       equalTo(0, (ImmutableGuildCreate)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableGuildCreate another) {
/*  70 */     return this.guild.equals(another.guild);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  79 */     int h = 5381;
/*  80 */     h += (h << 5) + this.guild.hashCode();
/*  81 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/*  90 */     return "GuildCreate{guild=" + this.guild + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "GuildCreate", generator = "Immutables")
/*     */   static final class Json
/*     */     implements GuildCreate
/*     */   {
/*     */     GuildCreateData guild;
/*     */ 
/*     */     
/*     */     @JsonProperty("guild")
/*     */     @JsonUnwrapped
/*     */     public void setGuild(GuildCreateData guild) {
/* 108 */       this.guild = guild;
/*     */     }
/*     */     public GuildCreateData guild() {
/* 111 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableGuildCreate fromJson(Json json) {
/* 122 */     Builder builder = builder();
/* 123 */     if (json.guild != null) {
/* 124 */       builder.guild(json.guild);
/*     */     }
/* 126 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableGuildCreate of(GuildCreateData guild) {
/* 135 */     return new ImmutableGuildCreate(guild);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableGuildCreate copyOf(GuildCreate instance) {
/* 146 */     if (instance instanceof ImmutableGuildCreate) {
/* 147 */       return (ImmutableGuildCreate)instance;
/*     */     }
/* 149 */     return builder()
/* 150 */       .from(instance)
/* 151 */       .build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 164 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "GuildCreate", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_GUILD = 1L;
/*     */ 
/*     */ 
/*     */     
/* 177 */     private long initBits = 1L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private GuildCreateData guild;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(GuildCreate instance) {
/* 192 */       Objects.requireNonNull(instance, "instance");
/* 193 */       guild(instance.guild());
/* 194 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("guild")
/*     */     @JsonUnwrapped
/*     */     public final Builder guild(GuildCreateData guild) {
/* 205 */       this.guild = Objects.<GuildCreateData>requireNonNull(guild, "guild");
/* 206 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 207 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableGuildCreate build() {
/* 216 */       if (this.initBits != 0L) {
/* 217 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 219 */       return new ImmutableGuildCreate(null, this.guild);
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 223 */       List<String> attributes = new ArrayList<>();
/* 224 */       if ((this.initBits & 0x1L) != 0L) attributes.add("guild"); 
/* 225 */       return "Cannot build GuildCreate, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\gateway\ImmutableGuildCreate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */