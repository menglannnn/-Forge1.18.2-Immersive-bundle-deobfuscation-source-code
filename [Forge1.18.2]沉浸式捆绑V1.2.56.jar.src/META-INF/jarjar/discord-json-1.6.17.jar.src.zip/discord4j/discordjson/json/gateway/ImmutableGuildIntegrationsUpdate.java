/*     */ package discord4j.discordjson.json.gateway;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.Id;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "GuildIntegrationsUpdate", generator = "Immutables")
/*     */ public final class ImmutableGuildIntegrationsUpdate
/*     */   implements GuildIntegrationsUpdate
/*     */ {
/*     */   private final long guildId_value;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   
/*     */   private ImmutableGuildIntegrationsUpdate(Id guildId) {
/*  29 */     Id guildId$impl = guildId;
/*  30 */     this.guildId_value = guildId$impl.asLong();
/*  31 */     this.initShim = null;
/*     */   }
/*     */   
/*     */   private ImmutableGuildIntegrationsUpdate(ImmutableGuildIntegrationsUpdate original, Id guildId) {
/*  35 */     Id guildId$impl = guildId;
/*  36 */     this.guildId_value = guildId$impl.asLong();
/*  37 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  43 */   private volatile transient InitShim initShim = new InitShim();
/*     */   
/*     */   @Generated(from = "GuildIntegrationsUpdate", generator = "Immutables")
/*     */   private final class InitShim {
/*     */     private String formatInitCycleMessage() {
/*  48 */       List<String> attributes = new ArrayList<>();
/*  49 */       return "Cannot build GuildIntegrationsUpdate, attribute initializers form cycle " + attributes;
/*     */     }
/*     */ 
/*     */     
/*     */     private InitShim() {}
/*     */   }
/*     */ 
/*     */   
/*     */   @JsonProperty("guild_id")
/*     */   public Id guildId() {
/*  59 */     return Id.of(this.guildId_value);
/*     */   }
/*     */   
/*     */   public ImmutableGuildIntegrationsUpdate withGuildId(long value) {
/*  63 */     Id newValue = Id.of(value);
/*  64 */     return new ImmutableGuildIntegrationsUpdate(this, newValue);
/*     */   }
/*     */   
/*     */   public ImmutableGuildIntegrationsUpdate withGuildId(String value) {
/*  68 */     Id newValue = Id.of(value);
/*  69 */     return new ImmutableGuildIntegrationsUpdate(this, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/*  78 */     if (this == another) return true; 
/*  79 */     return (another instanceof ImmutableGuildIntegrationsUpdate && 
/*  80 */       equalTo(0, (ImmutableGuildIntegrationsUpdate)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableGuildIntegrationsUpdate another) {
/*  84 */     return Objects.equals(Long.valueOf(this.guildId_value), Long.valueOf(another.guildId_value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  93 */     int h = 5381;
/*  94 */     h += (h << 5) + Objects.hashCode(Long.valueOf(this.guildId_value));
/*  95 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 104 */     return "GuildIntegrationsUpdate{guildId=" + 
/* 105 */       Objects.toString(Long.valueOf(this.guildId_value)) + "}";
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "GuildIntegrationsUpdate", generator = "Immutables")
/*     */   static final class Json
/*     */     implements GuildIntegrationsUpdate
/*     */   {
/*     */     Id guildId;
/*     */ 
/*     */     
/*     */     @JsonProperty("guild_id")
/*     */     public void setGuildId(Id guildId) {
/* 121 */       this.guildId = guildId;
/*     */     }
/*     */     public Id guildId() {
/* 124 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableGuildIntegrationsUpdate fromJson(Json json) {
/* 135 */     Builder builder = builder();
/* 136 */     if (json.guildId != null) {
/* 137 */       builder.guildId(json.guildId);
/*     */     }
/* 139 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableGuildIntegrationsUpdate of(Id guildId) {
/* 148 */     return new ImmutableGuildIntegrationsUpdate(guildId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableGuildIntegrationsUpdate copyOf(GuildIntegrationsUpdate instance) {
/* 159 */     if (instance instanceof ImmutableGuildIntegrationsUpdate) {
/* 160 */       return (ImmutableGuildIntegrationsUpdate)instance;
/*     */     }
/* 162 */     return builder()
/* 163 */       .from(instance)
/* 164 */       .build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 177 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "GuildIntegrationsUpdate", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/* 189 */     private Id guildId_id = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(GuildIntegrationsUpdate instance) {
/* 202 */       Objects.requireNonNull(instance, "instance");
/* 203 */       guildId(instance.guildId());
/* 204 */       return this;
/*     */     }
/*     */     
/*     */     public Builder guildId(String value) {
/* 208 */       this.guildId_id = Id.of(value);
/* 209 */       return this;
/*     */     }
/*     */     
/*     */     public Builder guildId(long value) {
/* 213 */       this.guildId_id = Id.of(value);
/* 214 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("guild_id")
/*     */     public Builder guildId(Id value) {
/* 219 */       this.guildId_id = value;
/* 220 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableGuildIntegrationsUpdate build() {
/* 229 */       return new ImmutableGuildIntegrationsUpdate(null, guildId_build());
/*     */     }
/*     */     
/*     */     private Id guildId_build() {
/* 233 */       return this.guildId_id;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\gateway\ImmutableGuildIntegrationsUpdate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */