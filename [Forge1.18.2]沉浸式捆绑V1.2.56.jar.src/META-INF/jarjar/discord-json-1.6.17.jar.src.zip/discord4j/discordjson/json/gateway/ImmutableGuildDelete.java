/*     */ package discord4j.discordjson.json.gateway;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.annotation.JsonUnwrapped;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.json.UnavailableGuildData;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "GuildDelete", generator = "Immutables")
/*     */ public final class ImmutableGuildDelete
/*     */   implements GuildDelete
/*     */ {
/*     */   private final UnavailableGuildData guild;
/*     */   
/*     */   private ImmutableGuildDelete(UnavailableGuildData guild) {
/*  29 */     this.guild = Objects.<UnavailableGuildData>requireNonNull(guild, "guild");
/*     */   }
/*     */   
/*     */   private ImmutableGuildDelete(ImmutableGuildDelete original, UnavailableGuildData guild) {
/*  33 */     this.guild = guild;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("guild")
/*     */   @JsonUnwrapped
/*     */   public UnavailableGuildData guild() {
/*  43 */     return this.guild;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableGuildDelete withGuild(UnavailableGuildData value) {
/*  53 */     if (this.guild == value) return this; 
/*  54 */     UnavailableGuildData newValue = Objects.<UnavailableGuildData>requireNonNull(value, "guild");
/*  55 */     return new ImmutableGuildDelete(this, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/*  64 */     if (this == another) return true; 
/*  65 */     return (another instanceof ImmutableGuildDelete && 
/*  66 */       equalTo(0, (ImmutableGuildDelete)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableGuildDelete another) {
/*  70 */     return this.guild.equals(another.guild);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  79 */     int h = 5381;
/*  80 */     h += (h << 5) + this.guild.hashCode();
/*  81 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/*  90 */     return "GuildDelete{guild=" + this.guild + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "GuildDelete", generator = "Immutables")
/*     */   static final class Json
/*     */     implements GuildDelete
/*     */   {
/*     */     UnavailableGuildData guild;
/*     */ 
/*     */     
/*     */     @JsonProperty("guild")
/*     */     @JsonUnwrapped
/*     */     public void setGuild(UnavailableGuildData guild) {
/* 108 */       this.guild = guild;
/*     */     }
/*     */     public UnavailableGuildData guild() {
/* 111 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableGuildDelete fromJson(Json json) {
/* 122 */     Builder builder = builder();
/* 123 */     if (json.guild != null) {
/* 124 */       builder.guild(json.guild);
/*     */     }
/* 126 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableGuildDelete of(UnavailableGuildData guild) {
/* 135 */     return new ImmutableGuildDelete(guild);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableGuildDelete copyOf(GuildDelete instance) {
/* 146 */     if (instance instanceof ImmutableGuildDelete) {
/* 147 */       return (ImmutableGuildDelete)instance;
/*     */     }
/* 149 */     return builder()
/* 150 */       .from(instance)
/* 151 */       .build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 164 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "GuildDelete", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_GUILD = 1L;
/*     */ 
/*     */ 
/*     */     
/* 177 */     private long initBits = 1L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private UnavailableGuildData guild;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(GuildDelete instance) {
/* 192 */       Objects.requireNonNull(instance, "instance");
/* 193 */       guild(instance.guild());
/* 194 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("guild")
/*     */     @JsonUnwrapped
/*     */     public final Builder guild(UnavailableGuildData guild) {
/* 205 */       this.guild = Objects.<UnavailableGuildData>requireNonNull(guild, "guild");
/* 206 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 207 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableGuildDelete build() {
/* 216 */       if (this.initBits != 0L) {
/* 217 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 219 */       return new ImmutableGuildDelete(null, this.guild);
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 223 */       List<String> attributes = new ArrayList<>();
/* 224 */       if ((this.initBits & 0x1L) != 0L) attributes.add("guild"); 
/* 225 */       return "Cannot build GuildDelete, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\gateway\ImmutableGuildDelete.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */