/*    */ package discord4j.discordjson.json.gateway;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonProperty;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import discord4j.discordjson.json.ChannelData;
/*    */ import discord4j.discordjson.json.PartialApplicationInfoData;
/*    */ import discord4j.discordjson.json.UnavailableGuildData;
/*    */ import discord4j.discordjson.json.UserData;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import java.util.List;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ @JsonSerialize(as = ImmutableReady.class)
/*    */ @JsonDeserialize(as = ImmutableReady.class)
/*    */ @Immutable
/*    */ public interface Ready
/*    */   extends Dispatch
/*    */ {
/*    */   static ImmutableReady.Builder builder() {
/* 21 */     return ImmutableReady.builder();
/*    */   }
/*    */   
/*    */   int v();
/*    */   
/*    */   UserData user();
/*    */   
/*    */   @JsonProperty("private_channels")
/*    */   List<ChannelData> privateChannels();
/*    */   
/*    */   List<UnavailableGuildData> guilds();
/*    */   
/*    */   @JsonProperty("session_id")
/*    */   String sessionId();
/*    */   
/*    */   @JsonProperty("resume_gateway_url")
/*    */   String resumeGatewayUrl();
/*    */   
/*    */   Possible<int[]> shard();
/*    */   
/*    */   @JsonProperty("_trace")
/*    */   List<String> trace();
/*    */   
/*    */   PartialApplicationInfoData application();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\gateway\Ready.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */