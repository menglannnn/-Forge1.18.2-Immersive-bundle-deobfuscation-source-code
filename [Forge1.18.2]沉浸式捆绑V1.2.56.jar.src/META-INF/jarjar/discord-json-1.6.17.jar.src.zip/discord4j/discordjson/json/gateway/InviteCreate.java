/*    */ package discord4j.discordjson.json.gateway;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonProperty;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import discord4j.discordjson.Id;
/*    */ import discord4j.discordjson.json.UserData;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ @JsonSerialize(as = ImmutableInviteCreate.class)
/*    */ @JsonDeserialize(as = ImmutableInviteCreate.class)
/*    */ @Immutable
/*    */ public interface InviteCreate
/*    */   extends Dispatch
/*    */ {
/*    */   static ImmutableInviteCreate.Builder builder() {
/* 18 */     return ImmutableInviteCreate.builder();
/*    */   }
/*    */   
/*    */   @JsonProperty("channel_id")
/*    */   Id channelId();
/*    */   
/*    */   String code();
/*    */   
/*    */   @JsonProperty("created_at")
/*    */   String createdAt();
/*    */   
/*    */   @JsonProperty("guild_id")
/*    */   Id guildId();
/*    */   
/*    */   Possible<UserData> inviter();
/*    */   
/*    */   @JsonProperty("max_age")
/*    */   int maxAge();
/*    */   
/*    */   @JsonProperty("max_uses")
/*    */   int maxUses();
/*    */   
/*    */   @JsonProperty("target_type")
/*    */   Possible<Integer> targetType();
/*    */   
/*    */   @JsonProperty("target_user")
/*    */   Possible<UserData> targetUser();
/*    */   
/*    */   boolean temporary();
/*    */   
/*    */   int uses();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\gateway\InviteCreate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */