/*     */ package discord4j.discordjson.json.gateway;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "Resumed", generator = "Immutables")
/*     */ public final class ImmutableResumed
/*     */   implements Resumed
/*     */ {
/*     */   private final List<String> trace;
/*     */   
/*     */   private ImmutableResumed(Iterable<String> trace) {
/*  30 */     this.trace = createUnmodifiableList(false, createSafeList(trace, true, false));
/*     */   }
/*     */   
/*     */   private ImmutableResumed(ImmutableResumed original, List<String> trace) {
/*  34 */     this.trace = trace;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("_trace")
/*     */   public List<String> trace() {
/*  43 */     return this.trace;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableResumed withTrace(String... elements) {
/*  52 */     List<String> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/*  53 */     return new ImmutableResumed(this, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableResumed withTrace(Iterable<String> elements) {
/*  63 */     if (this.trace == elements) return this; 
/*  64 */     List<String> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/*  65 */     return new ImmutableResumed(this, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/*  74 */     if (this == another) return true; 
/*  75 */     return (another instanceof ImmutableResumed && 
/*  76 */       equalTo(0, (ImmutableResumed)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableResumed another) {
/*  80 */     return this.trace.equals(another.trace);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  89 */     int h = 5381;
/*  90 */     h += (h << 5) + this.trace.hashCode();
/*  91 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 100 */     return "Resumed{trace=" + this.trace + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "Resumed", generator = "Immutables")
/*     */   static final class Json
/*     */     implements Resumed
/*     */   {
/* 114 */     List<String> trace = Collections.emptyList();
/*     */     @JsonProperty("_trace")
/*     */     public void setTrace(List<String> trace) {
/* 117 */       this.trace = trace;
/*     */     }
/*     */     public List<String> trace() {
/* 120 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableResumed fromJson(Json json) {
/* 131 */     Builder builder = builder();
/* 132 */     if (json.trace != null) {
/* 133 */       builder.addAllTrace(json.trace);
/*     */     }
/* 135 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableResumed of(List<String> trace) {
/* 144 */     return of(trace);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableResumed of(Iterable<String> trace) {
/* 153 */     return new ImmutableResumed(trace);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableResumed copyOf(Resumed instance) {
/* 164 */     if (instance instanceof ImmutableResumed) {
/* 165 */       return (ImmutableResumed)instance;
/*     */     }
/* 167 */     return builder()
/* 168 */       .from(instance)
/* 169 */       .build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 182 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "Resumed", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/* 194 */     private List<String> trace = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(Resumed instance) {
/* 208 */       Objects.requireNonNull(instance, "instance");
/* 209 */       addAllTrace(instance.trace());
/* 210 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder addTrace(String element) {
/* 219 */       this.trace.add(Objects.<String>requireNonNull(element, "trace element"));
/* 220 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder addTrace(String... elements) {
/* 229 */       for (String element : elements) {
/* 230 */         this.trace.add(Objects.<String>requireNonNull(element, "trace element"));
/*     */       }
/* 232 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("_trace")
/*     */     public final Builder trace(Iterable<String> elements) {
/* 243 */       this.trace.clear();
/* 244 */       return addAllTrace(elements);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder addAllTrace(Iterable<String> elements) {
/* 253 */       for (String element : elements) {
/* 254 */         this.trace.add(Objects.<String>requireNonNull(element, "trace element"));
/*     */       }
/* 256 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private Builder() {}
/*     */ 
/*     */     
/*     */     public ImmutableResumed build() {
/* 265 */       return new ImmutableResumed(null, ImmutableResumed.createUnmodifiableList(true, (List)this.trace));
/*     */     }
/*     */   }
/*     */   
/*     */   private static <T> List<T> createSafeList(Iterable<? extends T> iterable, boolean checkNulls, boolean skipNulls) {
/*     */     ArrayList<T> list;
/* 271 */     if (iterable instanceof Collection) {
/* 272 */       int size = ((Collection)iterable).size();
/* 273 */       if (size == 0) return Collections.emptyList(); 
/* 274 */       list = new ArrayList<>();
/*     */     } else {
/* 276 */       list = new ArrayList<>();
/*     */     } 
/* 278 */     for (T element : iterable) {
/* 279 */       if (skipNulls && element == null)
/* 280 */         continue;  if (checkNulls) Objects.requireNonNull(element, "element"); 
/* 281 */       list.add(element);
/*     */     } 
/* 283 */     return list;
/*     */   }
/*     */   
/*     */   private static <T> List<T> createUnmodifiableList(boolean clone, List<T> list) {
/* 287 */     switch (list.size()) { case 0:
/* 288 */         return Collections.emptyList();
/* 289 */       case 1: return Collections.singletonList(list.get(0)); }
/*     */     
/* 291 */     if (clone) {
/* 292 */       return Collections.unmodifiableList(new ArrayList<>(list));
/*     */     }
/* 294 */     if (list instanceof ArrayList) {
/* 295 */       ((ArrayList)list).trimToSize();
/*     */     }
/* 297 */     return Collections.unmodifiableList(list);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\gateway\ImmutableResumed.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */