/*    */ package discord4j.discordjson.json.gateway;
/*    */ 
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Opcode<T extends PayloadData>
/*    */ {
/* 23 */   public static final Opcode<Dispatch> DISPATCH = newOp(0, Dispatch.class);
/* 24 */   public static final Opcode<Heartbeat> HEARTBEAT = newOp(1, Heartbeat.class);
/* 25 */   public static final Opcode<Identify> IDENTIFY = newOp(2, Identify.class);
/* 26 */   public static final Opcode<StatusUpdate> STATUS_UPDATE = newOp(3, StatusUpdate.class);
/* 27 */   public static final Opcode<VoiceStateUpdate> VOICE_STATE_UPDATE = newOp(4, VoiceStateUpdate.class);
/* 28 */   public static final Opcode<?> VOICE_SERVER_PING = newOp(5, null);
/* 29 */   public static final Opcode<Resume> RESUME = newOp(6, Resume.class);
/* 30 */   public static final Opcode<?> RECONNECT = newOp(7, null);
/* 31 */   public static final Opcode<RequestGuildMembers> REQUEST_GUILD_MEMBERS = newOp(8, RequestGuildMembers.class);
/* 32 */   public static final Opcode<InvalidSession> INVALID_SESSION = newOp(9, InvalidSession.class);
/* 33 */   public static final Opcode<Hello> HELLO = newOp(10, Hello.class);
/* 34 */   public static final Opcode<?> HEARTBEAT_ACK = newOp(11, null);
/*    */   
/*    */   private final int rawOp;
/*    */   private final Class<T> payloadType;
/*    */   
/*    */   private Opcode(int rawOp, @Nullable Class<T> payloadType) {
/* 40 */     this.rawOp = rawOp;
/* 41 */     this.payloadType = payloadType;
/*    */   }
/*    */   
/*    */   @Nullable
/*    */   public static Opcode<?> forRaw(int rawOp) {
/* 46 */     switch (rawOp) { case 0:
/* 47 */         return DISPATCH;
/* 48 */       case 1: return HEARTBEAT;
/* 49 */       case 2: return IDENTIFY;
/* 50 */       case 3: return STATUS_UPDATE;
/* 51 */       case 4: return VOICE_STATE_UPDATE;
/* 52 */       case 5: return VOICE_SERVER_PING;
/* 53 */       case 6: return RESUME;
/* 54 */       case 7: return RECONNECT;
/* 55 */       case 8: return REQUEST_GUILD_MEMBERS;
/* 56 */       case 9: return INVALID_SESSION;
/* 57 */       case 10: return HELLO;
/* 58 */       case 11: return HEARTBEAT_ACK; }
/* 59 */      return null;
/*    */   }
/*    */ 
/*    */   
/*    */   private static <T extends PayloadData> Opcode<T> newOp(int rawOp, @Nullable Class<T> payloadType) {
/* 64 */     return new Opcode<>(rawOp, payloadType);
/*    */   }
/*    */   
/*    */   public int getRawOp() {
/* 68 */     return this.rawOp;
/*    */   }
/*    */   
/*    */   @Nullable
/*    */   public Class<T> getPayloadType() {
/* 73 */     return this.payloadType;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 78 */     return Integer.toString(getRawOp());
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\gateway\Opcode.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */