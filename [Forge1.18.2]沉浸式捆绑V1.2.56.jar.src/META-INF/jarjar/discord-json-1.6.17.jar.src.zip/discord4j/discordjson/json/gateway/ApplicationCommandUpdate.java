/*    */ package discord4j.discordjson.json.gateway;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonProperty;
/*    */ import com.fasterxml.jackson.annotation.JsonUnwrapped;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import discord4j.discordjson.Id;
/*    */ import discord4j.discordjson.json.ApplicationCommandData;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ @JsonSerialize(as = ImmutableApplicationCommandUpdate.class)
/*    */ @JsonDeserialize(as = ImmutableApplicationCommandUpdate.class)
/*    */ @Immutable
/*    */ public interface ApplicationCommandUpdate
/*    */   extends Dispatch {
/*    */   static ImmutableApplicationCommandUpdate.Builder builder() {
/* 17 */     return ImmutableApplicationCommandUpdate.builder();
/*    */   }
/*    */   
/*    */   @JsonProperty("guild_id")
/*    */   Id guildId();
/*    */   
/*    */   @JsonUnwrapped
/*    */   ApplicationCommandData command();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\gateway\ApplicationCommandUpdate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */