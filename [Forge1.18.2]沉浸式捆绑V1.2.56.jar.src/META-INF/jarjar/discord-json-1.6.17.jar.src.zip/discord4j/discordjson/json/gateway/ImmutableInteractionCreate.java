/*     */ package discord4j.discordjson.json.gateway;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.annotation.JsonUnwrapped;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.json.InteractionData;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "InteractionCreate", generator = "Immutables")
/*     */ public final class ImmutableInteractionCreate
/*     */   implements InteractionCreate
/*     */ {
/*     */   private final InteractionData interaction;
/*     */   
/*     */   private ImmutableInteractionCreate(InteractionData interaction) {
/*  29 */     this.interaction = Objects.<InteractionData>requireNonNull(interaction, "interaction");
/*     */   }
/*     */   
/*     */   private ImmutableInteractionCreate(ImmutableInteractionCreate original, InteractionData interaction) {
/*  33 */     this.interaction = interaction;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("interaction")
/*     */   @JsonUnwrapped
/*     */   public InteractionData interaction() {
/*  43 */     return this.interaction;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableInteractionCreate withInteraction(InteractionData value) {
/*  53 */     if (this.interaction == value) return this; 
/*  54 */     InteractionData newValue = Objects.<InteractionData>requireNonNull(value, "interaction");
/*  55 */     return new ImmutableInteractionCreate(this, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/*  64 */     if (this == another) return true; 
/*  65 */     return (another instanceof ImmutableInteractionCreate && 
/*  66 */       equalTo(0, (ImmutableInteractionCreate)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableInteractionCreate another) {
/*  70 */     return this.interaction.equals(another.interaction);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  79 */     int h = 5381;
/*  80 */     h += (h << 5) + this.interaction.hashCode();
/*  81 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/*  90 */     return "InteractionCreate{interaction=" + this.interaction + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "InteractionCreate", generator = "Immutables")
/*     */   static final class Json
/*     */     implements InteractionCreate
/*     */   {
/*     */     InteractionData interaction;
/*     */ 
/*     */     
/*     */     @JsonProperty("interaction")
/*     */     @JsonUnwrapped
/*     */     public void setInteraction(InteractionData interaction) {
/* 108 */       this.interaction = interaction;
/*     */     }
/*     */     public InteractionData interaction() {
/* 111 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableInteractionCreate fromJson(Json json) {
/* 122 */     Builder builder = builder();
/* 123 */     if (json.interaction != null) {
/* 124 */       builder.interaction(json.interaction);
/*     */     }
/* 126 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableInteractionCreate of(InteractionData interaction) {
/* 135 */     return new ImmutableInteractionCreate(interaction);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableInteractionCreate copyOf(InteractionCreate instance) {
/* 146 */     if (instance instanceof ImmutableInteractionCreate) {
/* 147 */       return (ImmutableInteractionCreate)instance;
/*     */     }
/* 149 */     return builder()
/* 150 */       .from(instance)
/* 151 */       .build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 164 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "InteractionCreate", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_INTERACTION = 1L;
/*     */ 
/*     */ 
/*     */     
/* 177 */     private long initBits = 1L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private InteractionData interaction;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(InteractionCreate instance) {
/* 192 */       Objects.requireNonNull(instance, "instance");
/* 193 */       interaction(instance.interaction());
/* 194 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("interaction")
/*     */     @JsonUnwrapped
/*     */     public final Builder interaction(InteractionData interaction) {
/* 205 */       this.interaction = Objects.<InteractionData>requireNonNull(interaction, "interaction");
/* 206 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 207 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableInteractionCreate build() {
/* 216 */       if (this.initBits != 0L) {
/* 217 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 219 */       return new ImmutableInteractionCreate(null, this.interaction);
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 223 */       List<String> attributes = new ArrayList<>();
/* 224 */       if ((this.initBits & 0x1L) != 0L) attributes.add("interaction"); 
/* 225 */       return "Cannot build InteractionCreate, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\gateway\ImmutableInteractionCreate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */