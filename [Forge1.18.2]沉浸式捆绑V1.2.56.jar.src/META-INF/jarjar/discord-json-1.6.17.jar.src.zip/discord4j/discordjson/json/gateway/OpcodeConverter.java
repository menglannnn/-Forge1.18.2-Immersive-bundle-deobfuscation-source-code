/*    */ package discord4j.discordjson.json.gateway;
/*    */ 
/*    */ import com.fasterxml.jackson.databind.util.StdConverter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OpcodeConverter
/*    */   extends StdConverter<Opcode<?>, Integer>
/*    */ {
/*    */   public Integer convert(Opcode<?> value) {
/* 25 */     return Integer.valueOf(value.getRawOp());
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\gateway\OpcodeConverter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */