/*     */ package discord4j.discordjson.json.gateway;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.Id;
/*     */ import discord4j.discordjson.json.EmojiData;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "GuildEmojisUpdate", generator = "Immutables")
/*     */ public final class ImmutableGuildEmojisUpdate
/*     */   implements GuildEmojisUpdate
/*     */ {
/*     */   private final long guildId_value;
/*     */   private final List<EmojiData> emojis;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   
/*     */   private ImmutableGuildEmojisUpdate(Id guildId, Iterable<? extends EmojiData> emojis) {
/*  33 */     Id guildId$impl = guildId;
/*  34 */     this.emojis = createUnmodifiableList(false, createSafeList(emojis, true, false));
/*  35 */     this.guildId_value = guildId$impl.asLong();
/*  36 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ImmutableGuildEmojisUpdate(ImmutableGuildEmojisUpdate original, Id guildId, List<EmojiData> emojis) {
/*  43 */     Id guildId$impl = guildId;
/*  44 */     this.emojis = emojis;
/*  45 */     this.guildId_value = guildId$impl.asLong();
/*  46 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  52 */   private volatile transient InitShim initShim = new InitShim();
/*     */   
/*     */   @Generated(from = "GuildEmojisUpdate", generator = "Immutables")
/*     */   private final class InitShim {
/*     */     private String formatInitCycleMessage() {
/*  57 */       List<String> attributes = new ArrayList<>();
/*  58 */       return "Cannot build GuildEmojisUpdate, attribute initializers form cycle " + attributes;
/*     */     }
/*     */ 
/*     */     
/*     */     private InitShim() {}
/*     */   }
/*     */ 
/*     */   
/*     */   @JsonProperty("guild_id")
/*     */   public Id guildId() {
/*  68 */     return Id.of(this.guildId_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("emojis")
/*     */   public List<EmojiData> emojis() {
/*  77 */     return this.emojis;
/*     */   }
/*     */   
/*     */   public ImmutableGuildEmojisUpdate withGuildId(long value) {
/*  81 */     Id newValue = Id.of(value);
/*  82 */     return new ImmutableGuildEmojisUpdate(this, newValue, this.emojis);
/*     */   }
/*     */   
/*     */   public ImmutableGuildEmojisUpdate withGuildId(String value) {
/*  86 */     Id newValue = Id.of(value);
/*  87 */     return new ImmutableGuildEmojisUpdate(this, newValue, this.emojis);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableGuildEmojisUpdate withEmojis(EmojiData... elements) {
/*  96 */     List<EmojiData> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/*  97 */     return new ImmutableGuildEmojisUpdate(this, guildId(), newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableGuildEmojisUpdate withEmojis(Iterable<? extends EmojiData> elements) {
/* 107 */     if (this.emojis == elements) return this; 
/* 108 */     List<EmojiData> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/* 109 */     return new ImmutableGuildEmojisUpdate(this, guildId(), newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 118 */     if (this == another) return true; 
/* 119 */     return (another instanceof ImmutableGuildEmojisUpdate && 
/* 120 */       equalTo(0, (ImmutableGuildEmojisUpdate)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableGuildEmojisUpdate another) {
/* 124 */     return (Objects.equals(Long.valueOf(this.guildId_value), Long.valueOf(another.guildId_value)) && this.emojis
/* 125 */       .equals(another.emojis));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 134 */     int h = 5381;
/* 135 */     h += (h << 5) + Objects.hashCode(Long.valueOf(this.guildId_value));
/* 136 */     h += (h << 5) + this.emojis.hashCode();
/* 137 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 146 */     return "GuildEmojisUpdate{guildId=" + 
/* 147 */       Objects.toString(Long.valueOf(this.guildId_value)) + ", emojis=" + this.emojis + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "GuildEmojisUpdate", generator = "Immutables")
/*     */   static final class Json
/*     */     implements GuildEmojisUpdate
/*     */   {
/*     */     Id guildId;
/*     */ 
/*     */     
/* 162 */     List<EmojiData> emojis = Collections.emptyList();
/*     */     @JsonProperty("guild_id")
/*     */     public void setGuildId(Id guildId) {
/* 165 */       this.guildId = guildId;
/*     */     }
/*     */     @JsonProperty("emojis")
/*     */     public void setEmojis(List<EmojiData> emojis) {
/* 169 */       this.emojis = emojis;
/*     */     }
/*     */     public Id guildId() {
/* 172 */       throw new UnsupportedOperationException();
/*     */     } public List<EmojiData> emojis() {
/* 174 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableGuildEmojisUpdate fromJson(Json json) {
/* 185 */     Builder builder = builder();
/* 186 */     if (json.guildId != null) {
/* 187 */       builder.guildId(json.guildId);
/*     */     }
/* 189 */     if (json.emojis != null) {
/* 190 */       builder.addAllEmojis(json.emojis);
/*     */     }
/* 192 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableGuildEmojisUpdate of(Id guildId, List<EmojiData> emojis) {
/* 202 */     return of(guildId, emojis);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableGuildEmojisUpdate of(Id guildId, Iterable<? extends EmojiData> emojis) {
/* 212 */     return new ImmutableGuildEmojisUpdate(guildId, emojis);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableGuildEmojisUpdate copyOf(GuildEmojisUpdate instance) {
/* 223 */     if (instance instanceof ImmutableGuildEmojisUpdate) {
/* 224 */       return (ImmutableGuildEmojisUpdate)instance;
/*     */     }
/* 226 */     return builder()
/* 227 */       .from(instance)
/* 228 */       .build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 242 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "GuildEmojisUpdate", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/* 254 */     private Id guildId_id = null;
/* 255 */     private List<EmojiData> emojis = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(GuildEmojisUpdate instance) {
/* 269 */       Objects.requireNonNull(instance, "instance");
/* 270 */       guildId(instance.guildId());
/* 271 */       addAllEmojis(instance.emojis());
/* 272 */       return this;
/*     */     }
/*     */     
/*     */     public Builder guildId(String value) {
/* 276 */       this.guildId_id = Id.of(value);
/* 277 */       return this;
/*     */     }
/*     */     
/*     */     public Builder guildId(long value) {
/* 281 */       this.guildId_id = Id.of(value);
/* 282 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("guild_id")
/*     */     public Builder guildId(Id value) {
/* 287 */       this.guildId_id = value;
/* 288 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder addEmoji(EmojiData element) {
/* 297 */       this.emojis.add(Objects.<EmojiData>requireNonNull(element, "emojis element"));
/* 298 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder addEmojis(EmojiData... elements) {
/* 307 */       for (EmojiData element : elements) {
/* 308 */         this.emojis.add(Objects.<EmojiData>requireNonNull(element, "emojis element"));
/*     */       }
/* 310 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("emojis")
/*     */     public final Builder emojis(Iterable<? extends EmojiData> elements) {
/* 321 */       this.emojis.clear();
/* 322 */       return addAllEmojis(elements);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder addAllEmojis(Iterable<? extends EmojiData> elements) {
/* 331 */       for (EmojiData element : elements) {
/* 332 */         this.emojis.add(Objects.<EmojiData>requireNonNull(element, "emojis element"));
/*     */       }
/* 334 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableGuildEmojisUpdate build() {
/* 343 */       return new ImmutableGuildEmojisUpdate(null, guildId_build(), ImmutableGuildEmojisUpdate.createUnmodifiableList(true, (List)this.emojis));
/*     */     }
/*     */     
/*     */     private Id guildId_build() {
/* 347 */       return this.guildId_id;
/*     */     }
/*     */     private Builder() {} }
/*     */   
/*     */   private static <T> List<T> createSafeList(Iterable<? extends T> iterable, boolean checkNulls, boolean skipNulls) {
/*     */     ArrayList<T> list;
/* 353 */     if (iterable instanceof Collection) {
/* 354 */       int size = ((Collection)iterable).size();
/* 355 */       if (size == 0) return Collections.emptyList(); 
/* 356 */       list = new ArrayList<>();
/*     */     } else {
/* 358 */       list = new ArrayList<>();
/*     */     } 
/* 360 */     for (T element : iterable) {
/* 361 */       if (skipNulls && element == null)
/* 362 */         continue;  if (checkNulls) Objects.requireNonNull(element, "element"); 
/* 363 */       list.add(element);
/*     */     } 
/* 365 */     return list;
/*     */   }
/*     */   
/*     */   private static <T> List<T> createUnmodifiableList(boolean clone, List<T> list) {
/* 369 */     switch (list.size()) { case 0:
/* 370 */         return Collections.emptyList();
/* 371 */       case 1: return Collections.singletonList(list.get(0)); }
/*     */     
/* 373 */     if (clone) {
/* 374 */       return Collections.unmodifiableList(new ArrayList<>(list));
/*     */     }
/* 376 */     if (list instanceof ArrayList) {
/* 377 */       ((ArrayList)list).trimToSize();
/*     */     }
/* 379 */     return Collections.unmodifiableList(list);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\gateway\ImmutableGuildEmojisUpdate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */