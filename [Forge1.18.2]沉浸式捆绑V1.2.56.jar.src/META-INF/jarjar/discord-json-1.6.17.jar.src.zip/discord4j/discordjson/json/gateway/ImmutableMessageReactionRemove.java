/*     */ package discord4j.discordjson.json.gateway;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.Id;
/*     */ import discord4j.discordjson.json.EmojiData;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "MessageReactionRemove", generator = "Immutables")
/*     */ public final class ImmutableMessageReactionRemove
/*     */   implements MessageReactionRemove
/*     */ {
/*     */   private final long userId_value;
/*     */   private final long channelId_value;
/*     */   private final long messageId_value;
/*     */   private final long guildId_value;
/*     */   private final boolean guildId_absent;
/*     */   private final EmojiData emoji;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   
/*     */   private ImmutableMessageReactionRemove(Id userId, Id channelId, Id messageId, Possible<Id> guildId, EmojiData emoji) {
/*  41 */     Id userId$impl = userId;
/*  42 */     Id channelId$impl = channelId;
/*  43 */     Id messageId$impl = messageId;
/*  44 */     Possible<Id> guildId$impl = guildId;
/*  45 */     this.emoji = Objects.<EmojiData>requireNonNull(emoji, "emoji");
/*  46 */     this.userId_value = userId$impl.asLong();
/*  47 */     this.channelId_value = channelId$impl.asLong();
/*  48 */     this.messageId_value = messageId$impl.asLong();
/*  49 */     this
/*     */       
/*  51 */       .guildId_value = ((Long)guildId$impl.toOptional().map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  52 */     this.guildId_absent = guildId$impl.isAbsent();
/*  53 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ImmutableMessageReactionRemove(ImmutableMessageReactionRemove original, Id userId, Id channelId, Id messageId, Possible<Id> guildId, EmojiData emoji) {
/*  63 */     Id userId$impl = userId;
/*  64 */     Id channelId$impl = channelId;
/*  65 */     Id messageId$impl = messageId;
/*  66 */     Possible<Id> guildId$impl = guildId;
/*  67 */     this.emoji = emoji;
/*  68 */     this.userId_value = userId$impl.asLong();
/*  69 */     this.channelId_value = channelId$impl.asLong();
/*  70 */     this.messageId_value = messageId$impl.asLong();
/*  71 */     this
/*     */       
/*  73 */       .guildId_value = ((Long)guildId$impl.toOptional().map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  74 */     this.guildId_absent = guildId$impl.isAbsent();
/*  75 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  81 */   private volatile transient InitShim initShim = new InitShim();
/*     */   
/*     */   @Generated(from = "MessageReactionRemove", generator = "Immutables")
/*     */   private final class InitShim {
/*     */     private String formatInitCycleMessage() {
/*  86 */       List<String> attributes = new ArrayList<>();
/*  87 */       return "Cannot build MessageReactionRemove, attribute initializers form cycle " + attributes;
/*     */     }
/*     */ 
/*     */     
/*     */     private InitShim() {}
/*     */   }
/*     */ 
/*     */   
/*     */   @JsonProperty("user_id")
/*     */   public Id userId() {
/*  97 */     return Id.of(this.userId_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("channel_id")
/*     */   public Id channelId() {
/* 106 */     return Id.of(this.channelId_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("message_id")
/*     */   public Id messageId() {
/* 115 */     return Id.of(this.messageId_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("guild_id")
/*     */   public Possible<Id> guildId() {
/* 124 */     return this.guildId_absent ? Possible.absent() : 
/* 125 */       Possible.of(Id.of(this.guildId_value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("emoji")
/*     */   public EmojiData emoji() {
/* 134 */     return this.emoji;
/*     */   }
/*     */   
/*     */   public ImmutableMessageReactionRemove withUserId(long value) {
/* 138 */     Id newValue = Id.of(value);
/* 139 */     return new ImmutableMessageReactionRemove(this, newValue, channelId(), messageId(), guildId(), this.emoji);
/*     */   }
/*     */   
/*     */   public ImmutableMessageReactionRemove withUserId(String value) {
/* 143 */     Id newValue = Id.of(value);
/* 144 */     return new ImmutableMessageReactionRemove(this, newValue, channelId(), messageId(), guildId(), this.emoji);
/*     */   }
/*     */   
/*     */   public ImmutableMessageReactionRemove withChannelId(long value) {
/* 148 */     Id newValue = Id.of(value);
/* 149 */     return new ImmutableMessageReactionRemove(this, userId(), newValue, messageId(), guildId(), this.emoji);
/*     */   }
/*     */   
/*     */   public ImmutableMessageReactionRemove withChannelId(String value) {
/* 153 */     Id newValue = Id.of(value);
/* 154 */     return new ImmutableMessageReactionRemove(this, userId(), newValue, messageId(), guildId(), this.emoji);
/*     */   }
/*     */   
/*     */   public ImmutableMessageReactionRemove withMessageId(long value) {
/* 158 */     Id newValue = Id.of(value);
/* 159 */     return new ImmutableMessageReactionRemove(this, userId(), channelId(), newValue, guildId(), this.emoji);
/*     */   }
/*     */   
/*     */   public ImmutableMessageReactionRemove withMessageId(String value) {
/* 163 */     Id newValue = Id.of(value);
/* 164 */     return new ImmutableMessageReactionRemove(this, userId(), channelId(), newValue, guildId(), this.emoji);
/*     */   }
/*     */   
/*     */   public ImmutableMessageReactionRemove withGuildId(Possible<Id> value) {
/* 168 */     Possible<Id> newValue = Objects.<Possible<Id>>requireNonNull(value);
/* 169 */     return new ImmutableMessageReactionRemove(this, userId(), channelId(), messageId(), newValue, this.emoji);
/*     */   }
/*     */   
/*     */   public ImmutableMessageReactionRemove withGuildId(long value) {
/* 173 */     Possible<Id> newValue = Possible.of(Id.of(value));
/* 174 */     return new ImmutableMessageReactionRemove(this, userId(), channelId(), messageId(), newValue, this.emoji);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableMessageReactionRemove withEmoji(EmojiData value) {
/* 184 */     if (this.emoji == value) return this; 
/* 185 */     EmojiData newValue = Objects.<EmojiData>requireNonNull(value, "emoji");
/* 186 */     return new ImmutableMessageReactionRemove(this, userId(), channelId(), messageId(), guildId(), newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 195 */     if (this == another) return true; 
/* 196 */     return (another instanceof ImmutableMessageReactionRemove && 
/* 197 */       equalTo(0, (ImmutableMessageReactionRemove)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableMessageReactionRemove another) {
/* 201 */     return (Objects.equals(Long.valueOf(this.userId_value), Long.valueOf(another.userId_value)) && 
/* 202 */       Objects.equals(Long.valueOf(this.channelId_value), Long.valueOf(another.channelId_value)) && 
/* 203 */       Objects.equals(Long.valueOf(this.messageId_value), Long.valueOf(another.messageId_value)) && 
/* 204 */       guildId().equals(another.guildId()) && this.emoji
/* 205 */       .equals(another.emoji));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 214 */     int h = 5381;
/* 215 */     h += (h << 5) + Objects.hashCode(Long.valueOf(this.userId_value));
/* 216 */     h += (h << 5) + Objects.hashCode(Long.valueOf(this.channelId_value));
/* 217 */     h += (h << 5) + Objects.hashCode(Long.valueOf(this.messageId_value));
/* 218 */     h += (h << 5) + guildId().hashCode();
/* 219 */     h += (h << 5) + this.emoji.hashCode();
/* 220 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 229 */     return "MessageReactionRemove{userId=" + 
/* 230 */       Objects.toString(Long.valueOf(this.userId_value)) + ", channelId=" + 
/* 231 */       Objects.toString(Long.valueOf(this.channelId_value)) + ", messageId=" + 
/* 232 */       Objects.toString(Long.valueOf(this.messageId_value)) + ", guildId=" + 
/* 233 */       guildId().toString() + ", emoji=" + this.emoji + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "MessageReactionRemove", generator = "Immutables")
/*     */   static final class Json
/*     */     implements MessageReactionRemove
/*     */   {
/*     */     Id userId;
/*     */     
/*     */     Id channelId;
/*     */     
/*     */     Id messageId;
/*     */     
/* 251 */     Possible<Id> guildId = Possible.absent();
/*     */     EmojiData emoji;
/*     */     
/*     */     @JsonProperty("user_id")
/*     */     public void setUserId(Id userId) {
/* 256 */       this.userId = userId;
/*     */     }
/*     */     @JsonProperty("channel_id")
/*     */     public void setChannelId(Id channelId) {
/* 260 */       this.channelId = channelId;
/*     */     }
/*     */     @JsonProperty("message_id")
/*     */     public void setMessageId(Id messageId) {
/* 264 */       this.messageId = messageId;
/*     */     }
/*     */     @JsonProperty("guild_id")
/*     */     public void setGuildId(Possible<Id> guildId) {
/* 268 */       this.guildId = guildId;
/*     */     }
/*     */     @JsonProperty("emoji")
/*     */     public void setEmoji(EmojiData emoji) {
/* 272 */       this.emoji = emoji;
/*     */     }
/*     */     public Id userId() {
/* 275 */       throw new UnsupportedOperationException();
/*     */     } public Id channelId() {
/* 277 */       throw new UnsupportedOperationException();
/*     */     } public Id messageId() {
/* 279 */       throw new UnsupportedOperationException();
/*     */     } public Possible<Id> guildId() {
/* 281 */       throw new UnsupportedOperationException();
/*     */     } public EmojiData emoji() {
/* 283 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableMessageReactionRemove fromJson(Json json) {
/* 294 */     Builder builder = builder();
/* 295 */     if (json.userId != null) {
/* 296 */       builder.userId(json.userId);
/*     */     }
/* 298 */     if (json.channelId != null) {
/* 299 */       builder.channelId(json.channelId);
/*     */     }
/* 301 */     if (json.messageId != null) {
/* 302 */       builder.messageId(json.messageId);
/*     */     }
/* 304 */     if (json.guildId != null) {
/* 305 */       builder.guildId(json.guildId);
/*     */     }
/* 307 */     if (json.emoji != null) {
/* 308 */       builder.emoji(json.emoji);
/*     */     }
/* 310 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableMessageReactionRemove of(Id userId, Id channelId, Id messageId, Possible<Id> guildId, EmojiData emoji) {
/* 323 */     return new ImmutableMessageReactionRemove(userId, channelId, messageId, guildId, emoji);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableMessageReactionRemove copyOf(MessageReactionRemove instance) {
/* 334 */     if (instance instanceof ImmutableMessageReactionRemove) {
/* 335 */       return (ImmutableMessageReactionRemove)instance;
/*     */     }
/* 337 */     return builder()
/* 338 */       .from(instance)
/* 339 */       .build();
/*     */   }
/*     */   
/*     */   public boolean isGuildIdPresent() {
/* 343 */     return !this.guildId_absent;
/*     */   }
/*     */   
/*     */   public long guildIdOrElse(long defaultValue) {
/* 347 */     return !this.guildId_absent ? this.guildId_value : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 364 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "MessageReactionRemove", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_EMOJI = 1L;
/*     */ 
/*     */ 
/*     */     
/* 377 */     private long initBits = 1L;
/*     */     
/* 379 */     private Id userId_id = null;
/* 380 */     private Id channelId_id = null;
/* 381 */     private Id messageId_id = null;
/* 382 */     private Possible<Id> guildId_possible = Possible.absent();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private EmojiData emoji;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(MessageReactionRemove instance) {
/* 396 */       Objects.requireNonNull(instance, "instance");
/* 397 */       userId(instance.userId());
/* 398 */       channelId(instance.channelId());
/* 399 */       messageId(instance.messageId());
/* 400 */       guildId(instance.guildId());
/* 401 */       emoji(instance.emoji());
/* 402 */       return this;
/*     */     }
/*     */     
/*     */     public Builder userId(String value) {
/* 406 */       this.userId_id = Id.of(value);
/* 407 */       return this;
/*     */     }
/*     */     
/*     */     public Builder userId(long value) {
/* 411 */       this.userId_id = Id.of(value);
/* 412 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("user_id")
/*     */     public Builder userId(Id value) {
/* 417 */       this.userId_id = value;
/* 418 */       return this;
/*     */     }
/*     */     
/*     */     public Builder channelId(String value) {
/* 422 */       this.channelId_id = Id.of(value);
/* 423 */       return this;
/*     */     }
/*     */     
/*     */     public Builder channelId(long value) {
/* 427 */       this.channelId_id = Id.of(value);
/* 428 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("channel_id")
/*     */     public Builder channelId(Id value) {
/* 433 */       this.channelId_id = value;
/* 434 */       return this;
/*     */     }
/*     */     
/*     */     public Builder messageId(String value) {
/* 438 */       this.messageId_id = Id.of(value);
/* 439 */       return this;
/*     */     }
/*     */     
/*     */     public Builder messageId(long value) {
/* 443 */       this.messageId_id = Id.of(value);
/* 444 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("message_id")
/*     */     public Builder messageId(Id value) {
/* 449 */       this.messageId_id = value;
/* 450 */       return this;
/*     */     }
/*     */     
/*     */     public Builder guildId(String value) {
/* 454 */       this.guildId_possible = Possible.of(Id.of(value));
/* 455 */       return this;
/*     */     }
/*     */     
/*     */     public Builder guildId(long value) {
/* 459 */       this.guildId_possible = Possible.of(Id.of(value));
/* 460 */       return this;
/*     */     }
/*     */     
/*     */     public Builder guildId(Id value) {
/* 464 */       this.guildId_possible = Possible.of(value);
/* 465 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("guild_id")
/*     */     public Builder guildId(Possible<Id> value) {
/* 470 */       this.guildId_possible = value;
/* 471 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("emoji")
/*     */     public final Builder emoji(EmojiData emoji) {
/* 481 */       this.emoji = Objects.<EmojiData>requireNonNull(emoji, "emoji");
/* 482 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 483 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableMessageReactionRemove build() {
/* 492 */       if (this.initBits != 0L) {
/* 493 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 495 */       return new ImmutableMessageReactionRemove(null, userId_build(), channelId_build(), messageId_build(), guildId_build(), this.emoji);
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 499 */       List<String> attributes = new ArrayList<>();
/* 500 */       if ((this.initBits & 0x1L) != 0L) attributes.add("emoji"); 
/* 501 */       return "Cannot build MessageReactionRemove, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Id userId_build() {
/* 505 */       return this.userId_id;
/*     */     }
/*     */     
/*     */     private Id channelId_build() {
/* 509 */       return this.channelId_id;
/*     */     }
/*     */     
/*     */     private Id messageId_build() {
/* 513 */       return this.messageId_id;
/*     */     }
/*     */     
/*     */     private Possible<Id> guildId_build() {
/* 517 */       return this.guildId_possible;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\gateway\ImmutableMessageReactionRemove.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */