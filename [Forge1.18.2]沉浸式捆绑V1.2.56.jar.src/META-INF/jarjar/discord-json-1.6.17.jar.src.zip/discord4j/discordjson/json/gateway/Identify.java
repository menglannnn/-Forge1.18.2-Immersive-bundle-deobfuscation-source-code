/*    */ package discord4j.discordjson.json.gateway;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonProperty;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ @JsonSerialize(as = ImmutableIdentify.class)
/*    */ @JsonDeserialize(as = ImmutableIdentify.class)
/*    */ @Immutable
/*    */ public interface Identify
/*    */   extends PayloadData {
/*    */   static ImmutableIdentify.Builder builder() {
/* 15 */     return ImmutableIdentify.builder();
/*    */   }
/*    */   
/*    */   String token();
/*    */   
/*    */   IdentifyProperties properties();
/*    */   
/*    */   Possible<Boolean> compress();
/*    */   
/*    */   @JsonProperty("large_threshold")
/*    */   int largeThreshold();
/*    */   
/*    */   Possible<int[]> shard();
/*    */   
/*    */   Possible<StatusUpdate> presence();
/*    */   
/*    */   Possible<Long> intents();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\gateway\Identify.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */