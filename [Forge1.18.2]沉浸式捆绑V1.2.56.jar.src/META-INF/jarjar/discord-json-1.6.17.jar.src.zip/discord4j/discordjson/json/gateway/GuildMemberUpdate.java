/*    */ package discord4j.discordjson.json.gateway;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonProperty;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import discord4j.discordjson.Id;
/*    */ import discord4j.discordjson.json.UserData;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import java.util.List;
/*    */ import java.util.Optional;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ @JsonSerialize(as = ImmutableGuildMemberUpdate.class)
/*    */ @JsonDeserialize(as = ImmutableGuildMemberUpdate.class)
/*    */ @Immutable
/*    */ public interface GuildMemberUpdate
/*    */   extends Dispatch
/*    */ {
/*    */   static ImmutableGuildMemberUpdate.Builder builder() {
/* 20 */     return ImmutableGuildMemberUpdate.builder();
/*    */   }
/*    */   
/*    */   @JsonProperty("guild_id")
/*    */   Id guildId();
/*    */   
/*    */   List<String> roles();
/*    */   
/*    */   UserData user();
/*    */   
/*    */   Possible<Optional<String>> nick();
/*    */   
/*    */   Optional<String> avatar();
/*    */   
/*    */   @JsonProperty("joined_at")
/*    */   Optional<String> joinedAt();
/*    */   
/*    */   @JsonProperty("premium_since")
/*    */   Possible<Optional<String>> premiumSince();
/*    */   
/*    */   Possible<Boolean> pending();
/*    */   
/*    */   @JsonProperty("communication_disabled_until")
/*    */   Possible<Optional<String>> communicationDisabledUntil();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\gateway\GuildMemberUpdate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */