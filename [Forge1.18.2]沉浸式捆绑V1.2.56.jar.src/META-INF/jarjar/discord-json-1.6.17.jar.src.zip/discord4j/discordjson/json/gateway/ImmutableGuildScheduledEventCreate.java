/*     */ package discord4j.discordjson.json.gateway;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.annotation.JsonUnwrapped;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.json.GuildScheduledEventData;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "GuildScheduledEventCreate", generator = "Immutables")
/*     */ public final class ImmutableGuildScheduledEventCreate
/*     */   implements GuildScheduledEventCreate
/*     */ {
/*     */   private final GuildScheduledEventData scheduledEvent;
/*     */   
/*     */   private ImmutableGuildScheduledEventCreate(GuildScheduledEventData scheduledEvent) {
/*  30 */     this.scheduledEvent = Objects.<GuildScheduledEventData>requireNonNull(scheduledEvent, "scheduledEvent");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private ImmutableGuildScheduledEventCreate(ImmutableGuildScheduledEventCreate original, GuildScheduledEventData scheduledEvent) {
/*  36 */     this.scheduledEvent = scheduledEvent;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("scheduledEvent")
/*     */   @JsonUnwrapped
/*     */   public GuildScheduledEventData scheduledEvent() {
/*  46 */     return this.scheduledEvent;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableGuildScheduledEventCreate withScheduledEvent(GuildScheduledEventData value) {
/*  56 */     if (this.scheduledEvent == value) return this; 
/*  57 */     GuildScheduledEventData newValue = Objects.<GuildScheduledEventData>requireNonNull(value, "scheduledEvent");
/*  58 */     return new ImmutableGuildScheduledEventCreate(this, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/*  67 */     if (this == another) return true; 
/*  68 */     return (another instanceof ImmutableGuildScheduledEventCreate && 
/*  69 */       equalTo(0, (ImmutableGuildScheduledEventCreate)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableGuildScheduledEventCreate another) {
/*  73 */     return this.scheduledEvent.equals(another.scheduledEvent);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  82 */     int h = 5381;
/*  83 */     h += (h << 5) + this.scheduledEvent.hashCode();
/*  84 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/*  93 */     return "GuildScheduledEventCreate{scheduledEvent=" + this.scheduledEvent + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "GuildScheduledEventCreate", generator = "Immutables")
/*     */   static final class Json
/*     */     implements GuildScheduledEventCreate
/*     */   {
/*     */     GuildScheduledEventData scheduledEvent;
/*     */ 
/*     */     
/*     */     @JsonProperty("scheduledEvent")
/*     */     @JsonUnwrapped
/*     */     public void setScheduledEvent(GuildScheduledEventData scheduledEvent) {
/* 111 */       this.scheduledEvent = scheduledEvent;
/*     */     }
/*     */     public GuildScheduledEventData scheduledEvent() {
/* 114 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableGuildScheduledEventCreate fromJson(Json json) {
/* 125 */     Builder builder = builder();
/* 126 */     if (json.scheduledEvent != null) {
/* 127 */       builder.scheduledEvent(json.scheduledEvent);
/*     */     }
/* 129 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableGuildScheduledEventCreate of(GuildScheduledEventData scheduledEvent) {
/* 138 */     return new ImmutableGuildScheduledEventCreate(scheduledEvent);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableGuildScheduledEventCreate copyOf(GuildScheduledEventCreate instance) {
/* 149 */     if (instance instanceof ImmutableGuildScheduledEventCreate) {
/* 150 */       return (ImmutableGuildScheduledEventCreate)instance;
/*     */     }
/* 152 */     return builder()
/* 153 */       .from(instance)
/* 154 */       .build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 167 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "GuildScheduledEventCreate", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_SCHEDULED_EVENT = 1L;
/*     */ 
/*     */ 
/*     */     
/* 180 */     private long initBits = 1L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private GuildScheduledEventData scheduledEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(GuildScheduledEventCreate instance) {
/* 195 */       Objects.requireNonNull(instance, "instance");
/* 196 */       scheduledEvent(instance.scheduledEvent());
/* 197 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("scheduledEvent")
/*     */     @JsonUnwrapped
/*     */     public final Builder scheduledEvent(GuildScheduledEventData scheduledEvent) {
/* 208 */       this.scheduledEvent = Objects.<GuildScheduledEventData>requireNonNull(scheduledEvent, "scheduledEvent");
/* 209 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 210 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableGuildScheduledEventCreate build() {
/* 219 */       if (this.initBits != 0L) {
/* 220 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 222 */       return new ImmutableGuildScheduledEventCreate(null, this.scheduledEvent);
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 226 */       List<String> attributes = new ArrayList<>();
/* 227 */       if ((this.initBits & 0x1L) != 0L) attributes.add("scheduledEvent"); 
/* 228 */       return "Cannot build GuildScheduledEventCreate, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\gateway\ImmutableGuildScheduledEventCreate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */