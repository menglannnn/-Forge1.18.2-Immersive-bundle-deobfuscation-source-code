/*     */ package discord4j.discordjson.json.gateway;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.Id;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.stream.LongStream;
/*     */ import java.util.stream.StreamSupport;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "MessageDeleteBulk", generator = "Immutables")
/*     */ public final class ImmutableMessageDeleteBulk
/*     */   implements MessageDeleteBulk
/*     */ {
/*     */   private final long[] ids_value;
/*     */   private final long channelId_value;
/*     */   private final long guildId_value;
/*     */   private final boolean guildId_absent;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   
/*     */   private ImmutableMessageDeleteBulk(List<Id> ids, Id channelId, Possible<Id> guildId) {
/*  38 */     List<Id> ids$impl = ids;
/*  39 */     Id channelId$impl = channelId;
/*  40 */     Possible<Id> guildId$impl = guildId;
/*  41 */     this
/*     */       
/*  43 */       .ids_value = ids$impl.stream().mapToLong(Id::asLong).toArray();
/*  44 */     this.channelId_value = channelId$impl.asLong();
/*  45 */     this
/*     */       
/*  47 */       .guildId_value = ((Long)guildId$impl.toOptional().map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  48 */     this.guildId_absent = guildId$impl.isAbsent();
/*  49 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ImmutableMessageDeleteBulk(ImmutableMessageDeleteBulk original, List<Id> ids, Id channelId, Possible<Id> guildId) {
/*  57 */     List<Id> ids$impl = ids;
/*  58 */     Id channelId$impl = channelId;
/*  59 */     Possible<Id> guildId$impl = guildId;
/*  60 */     this
/*     */       
/*  62 */       .ids_value = ids$impl.stream().mapToLong(Id::asLong).toArray();
/*  63 */     this.channelId_value = channelId$impl.asLong();
/*  64 */     this
/*     */       
/*  66 */       .guildId_value = ((Long)guildId$impl.toOptional().map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  67 */     this.guildId_absent = guildId$impl.isAbsent();
/*  68 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  74 */   private volatile transient InitShim initShim = new InitShim();
/*     */   
/*     */   @Generated(from = "MessageDeleteBulk", generator = "Immutables")
/*     */   private final class InitShim {
/*     */     private String formatInitCycleMessage() {
/*  79 */       List<String> attributes = new ArrayList<>();
/*  80 */       return "Cannot build MessageDeleteBulk, attribute initializers form cycle " + attributes;
/*     */     }
/*     */ 
/*     */     
/*     */     private InitShim() {}
/*     */   }
/*     */ 
/*     */   
/*     */   @JsonProperty("ids")
/*     */   public List<Id> ids() {
/*  90 */     return (List<Id>)LongStream.of(this.ids_value)
/*  91 */       .mapToObj(Id::of)
/*  92 */       .collect(Collectors.toList());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("channel_id")
/*     */   public Id channelId() {
/* 101 */     return Id.of(this.channelId_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("guild_id")
/*     */   public Possible<Id> guildId() {
/* 110 */     return this.guildId_absent ? Possible.absent() : 
/* 111 */       Possible.of(Id.of(this.guildId_value));
/*     */   }
/*     */   
/*     */   public ImmutableMessageDeleteBulk withIds(List<Id> value) {
/* 115 */     List<Id> newValue = value;
/* 116 */     return new ImmutableMessageDeleteBulk(this, newValue, channelId(), guildId());
/*     */   }
/*     */   
/*     */   public ImmutableMessageDeleteBulk withChannelId(long value) {
/* 120 */     Id newValue = Id.of(value);
/* 121 */     return new ImmutableMessageDeleteBulk(this, ids(), newValue, guildId());
/*     */   }
/*     */   
/*     */   public ImmutableMessageDeleteBulk withChannelId(String value) {
/* 125 */     Id newValue = Id.of(value);
/* 126 */     return new ImmutableMessageDeleteBulk(this, ids(), newValue, guildId());
/*     */   }
/*     */   
/*     */   public ImmutableMessageDeleteBulk withGuildId(Possible<Id> value) {
/* 130 */     Possible<Id> newValue = Objects.<Possible<Id>>requireNonNull(value);
/* 131 */     return new ImmutableMessageDeleteBulk(this, ids(), channelId(), newValue);
/*     */   }
/*     */   
/*     */   public ImmutableMessageDeleteBulk withGuildId(long value) {
/* 135 */     Possible<Id> newValue = Possible.of(Id.of(value));
/* 136 */     return new ImmutableMessageDeleteBulk(this, ids(), channelId(), newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 145 */     if (this == another) return true; 
/* 146 */     return (another instanceof ImmutableMessageDeleteBulk && 
/* 147 */       equalTo(0, (ImmutableMessageDeleteBulk)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableMessageDeleteBulk another) {
/* 151 */     return (Objects.equals(this.ids_value, another.ids_value) && 
/* 152 */       Objects.equals(Long.valueOf(this.channelId_value), Long.valueOf(another.channelId_value)) && 
/* 153 */       guildId().equals(another.guildId()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 162 */     int h = 5381;
/* 163 */     h += (h << 5) + Objects.hashCode(this.ids_value);
/* 164 */     h += (h << 5) + Objects.hashCode(Long.valueOf(this.channelId_value));
/* 165 */     h += (h << 5) + guildId().hashCode();
/* 166 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 175 */     return "MessageDeleteBulk{ids=" + 
/* 176 */       Objects.toString(this.ids_value) + ", channelId=" + 
/* 177 */       Objects.toString(Long.valueOf(this.channelId_value)) + ", guildId=" + 
/* 178 */       guildId().toString() + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "MessageDeleteBulk", generator = "Immutables")
/*     */   static final class Json
/*     */     implements MessageDeleteBulk
/*     */   {
/*     */     List<Id> ids;
/*     */     
/*     */     Id channelId;
/*     */     
/* 194 */     Possible<Id> guildId = Possible.absent();
/*     */     
/*     */     @JsonProperty("ids")
/*     */     public void setIds(List<Id> ids) {
/* 198 */       this.ids = ids;
/*     */     }
/*     */     @JsonProperty("channel_id")
/*     */     public void setChannelId(Id channelId) {
/* 202 */       this.channelId = channelId;
/*     */     }
/*     */     @JsonProperty("guild_id")
/*     */     public void setGuildId(Possible<Id> guildId) {
/* 206 */       this.guildId = guildId;
/*     */     }
/*     */     public List<Id> ids() {
/* 209 */       throw new UnsupportedOperationException();
/*     */     } public Id channelId() {
/* 211 */       throw new UnsupportedOperationException();
/*     */     } public Possible<Id> guildId() {
/* 213 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableMessageDeleteBulk fromJson(Json json) {
/* 224 */     Builder builder = builder();
/* 225 */     if (json.ids != null) {
/* 226 */       builder.ids(json.ids);
/*     */     }
/* 228 */     if (json.channelId != null) {
/* 229 */       builder.channelId(json.channelId);
/*     */     }
/* 231 */     if (json.guildId != null) {
/* 232 */       builder.guildId(json.guildId);
/*     */     }
/* 234 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableMessageDeleteBulk of(List<Id> ids, Id channelId, Possible<Id> guildId) {
/* 245 */     return new ImmutableMessageDeleteBulk(ids, channelId, guildId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableMessageDeleteBulk copyOf(MessageDeleteBulk instance) {
/* 256 */     if (instance instanceof ImmutableMessageDeleteBulk) {
/* 257 */       return (ImmutableMessageDeleteBulk)instance;
/*     */     }
/* 259 */     return builder()
/* 260 */       .from(instance)
/* 261 */       .build();
/*     */   }
/*     */   
/*     */   public boolean isGuildIdPresent() {
/* 265 */     return !this.guildId_absent;
/*     */   }
/*     */   
/*     */   public long guildIdOrElse(long defaultValue) {
/* 269 */     return !this.guildId_absent ? this.guildId_value : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 284 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "MessageDeleteBulk", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/* 296 */     private List<Long> ids_list = null;
/* 297 */     private Id channelId_id = null;
/* 298 */     private Possible<Id> guildId_possible = Possible.absent();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(MessageDeleteBulk instance) {
/* 311 */       Objects.requireNonNull(instance, "instance");
/* 312 */       ids(instance.ids());
/* 313 */       channelId(instance.channelId());
/* 314 */       guildId(instance.guildId());
/* 315 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addId(long element) {
/* 319 */       ids_getOrCreate().add(Long.valueOf(element));
/* 320 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addId(String element) {
/* 324 */       ids_getOrCreate().add(Long.valueOf(Id.of(element).asLong()));
/* 325 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addId(Id element) {
/* 329 */       ids_getOrCreate().add(Long.valueOf(element.asLong()));
/* 330 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addAllIds(List<Long> elements) {
/* 334 */       ids_getOrCreate().addAll(elements);
/* 335 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("ids")
/*     */     public Builder ids(List<Id> elements) {
/* 340 */       this.ids_list = (List<Long>)elements.stream().map(Id::asLong).collect(Collectors.toList());
/* 341 */       return this;
/*     */     }
/*     */     
/*     */     public Builder ids(Iterable<Id> elements) {
/* 345 */       this
/*     */         
/* 347 */         .ids_list = (List<Long>)StreamSupport.stream(elements.spliterator(), false).map(Id::asLong).collect(Collectors.toList());
/* 348 */       return this;
/*     */     }
/*     */     
/*     */     public Builder channelId(String value) {
/* 352 */       this.channelId_id = Id.of(value);
/* 353 */       return this;
/*     */     }
/*     */     
/*     */     public Builder channelId(long value) {
/* 357 */       this.channelId_id = Id.of(value);
/* 358 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("channel_id")
/*     */     public Builder channelId(Id value) {
/* 363 */       this.channelId_id = value;
/* 364 */       return this;
/*     */     }
/*     */     
/*     */     public Builder guildId(String value) {
/* 368 */       this.guildId_possible = Possible.of(Id.of(value));
/* 369 */       return this;
/*     */     }
/*     */     
/*     */     public Builder guildId(long value) {
/* 373 */       this.guildId_possible = Possible.of(Id.of(value));
/* 374 */       return this;
/*     */     }
/*     */     
/*     */     public Builder guildId(Id value) {
/* 378 */       this.guildId_possible = Possible.of(value);
/* 379 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("guild_id")
/*     */     public Builder guildId(Possible<Id> value) {
/* 384 */       this.guildId_possible = value;
/* 385 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableMessageDeleteBulk build() {
/* 394 */       return new ImmutableMessageDeleteBulk(null, ids_build(), channelId_build(), guildId_build());
/*     */     }
/*     */     
/*     */     private List<Id> ids_build() {
/* 398 */       return (List<Id>)ids_getOrCreate().stream().map(Id::of).collect(Collectors.toList());
/*     */     }
/*     */     
/*     */     private List<Long> ids_getOrCreate() {
/* 402 */       if (this.ids_list == null) {
/* 403 */         this.ids_list = new ArrayList<>();
/*     */       }
/* 405 */       return this.ids_list;
/*     */     }
/*     */     
/*     */     private Id channelId_build() {
/* 409 */       return this.channelId_id;
/*     */     }
/*     */     
/*     */     private Possible<Id> guildId_build() {
/* 413 */       return this.guildId_possible;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\gateway\ImmutableMessageDeleteBulk.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */