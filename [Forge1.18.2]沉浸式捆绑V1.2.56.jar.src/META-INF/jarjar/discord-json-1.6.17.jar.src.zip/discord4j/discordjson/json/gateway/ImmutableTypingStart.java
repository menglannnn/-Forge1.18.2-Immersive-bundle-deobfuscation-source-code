/*     */ package discord4j.discordjson.json.gateway;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.Id;
/*     */ import discord4j.discordjson.json.MemberData;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "TypingStart", generator = "Immutables")
/*     */ public final class ImmutableTypingStart
/*     */   implements TypingStart
/*     */ {
/*     */   private final long channelId_value;
/*     */   private final long guildId_value;
/*     */   private final boolean guildId_absent;
/*     */   private final long userId_value;
/*     */   private final long timestamp;
/*     */   private final MemberData member_value;
/*     */   private final boolean member_absent;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   
/*     */   private ImmutableTypingStart(Id channelId, Possible<Id> guildId, Id userId, long timestamp, Possible<MemberData> member) {
/*  41 */     Id channelId$impl = channelId;
/*  42 */     Possible<Id> guildId$impl = guildId;
/*  43 */     Id userId$impl = userId;
/*  44 */     this.timestamp = timestamp;
/*  45 */     Possible<MemberData> member$impl = member;
/*  46 */     this.channelId_value = channelId$impl.asLong();
/*  47 */     this
/*     */       
/*  49 */       .guildId_value = ((Long)guildId$impl.toOptional().map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  50 */     this.guildId_absent = guildId$impl.isAbsent();
/*  51 */     this.userId_value = userId$impl.asLong();
/*  52 */     this.member_value = member$impl.toOptional().orElse(null);
/*  53 */     this.member_absent = member$impl.isAbsent();
/*  54 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ImmutableTypingStart(ImmutableTypingStart original, Id channelId, Possible<Id> guildId, Id userId, long timestamp, Possible<MemberData> member) {
/*  64 */     Id channelId$impl = channelId;
/*  65 */     Possible<Id> guildId$impl = guildId;
/*  66 */     Id userId$impl = userId;
/*  67 */     this.timestamp = timestamp;
/*  68 */     Possible<MemberData> member$impl = member;
/*  69 */     this.channelId_value = channelId$impl.asLong();
/*  70 */     this
/*     */       
/*  72 */       .guildId_value = ((Long)guildId$impl.toOptional().map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  73 */     this.guildId_absent = guildId$impl.isAbsent();
/*  74 */     this.userId_value = userId$impl.asLong();
/*  75 */     this.member_value = member$impl.toOptional().orElse(null);
/*  76 */     this.member_absent = member$impl.isAbsent();
/*  77 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  83 */   private volatile transient InitShim initShim = new InitShim();
/*     */   
/*     */   @Generated(from = "TypingStart", generator = "Immutables")
/*     */   private final class InitShim {
/*     */     private String formatInitCycleMessage() {
/*  88 */       List<String> attributes = new ArrayList<>();
/*  89 */       return "Cannot build TypingStart, attribute initializers form cycle " + attributes;
/*     */     }
/*     */ 
/*     */     
/*     */     private InitShim() {}
/*     */   }
/*     */ 
/*     */   
/*     */   @JsonProperty("channel_id")
/*     */   public Id channelId() {
/*  99 */     return Id.of(this.channelId_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("guild_id")
/*     */   public Possible<Id> guildId() {
/* 108 */     return this.guildId_absent ? Possible.absent() : 
/* 109 */       Possible.of(Id.of(this.guildId_value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("user_id")
/*     */   public Id userId() {
/* 118 */     return Id.of(this.userId_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("timestamp")
/*     */   public long timestamp() {
/* 127 */     return this.timestamp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("member")
/*     */   public Possible<MemberData> member() {
/* 136 */     return this.member_absent ? Possible.absent() : Possible.of(this.member_value);
/*     */   }
/*     */   
/*     */   public ImmutableTypingStart withChannelId(long value) {
/* 140 */     Id newValue = Id.of(value);
/* 141 */     return new ImmutableTypingStart(this, newValue, guildId(), userId(), this.timestamp, member());
/*     */   }
/*     */   
/*     */   public ImmutableTypingStart withChannelId(String value) {
/* 145 */     Id newValue = Id.of(value);
/* 146 */     return new ImmutableTypingStart(this, newValue, guildId(), userId(), this.timestamp, member());
/*     */   }
/*     */   
/*     */   public ImmutableTypingStart withGuildId(Possible<Id> value) {
/* 150 */     Possible<Id> newValue = Objects.<Possible<Id>>requireNonNull(value);
/* 151 */     return new ImmutableTypingStart(this, channelId(), newValue, userId(), this.timestamp, member());
/*     */   }
/*     */   
/*     */   public ImmutableTypingStart withGuildId(long value) {
/* 155 */     Possible<Id> newValue = Possible.of(Id.of(value));
/* 156 */     return new ImmutableTypingStart(this, channelId(), newValue, userId(), this.timestamp, member());
/*     */   }
/*     */   
/*     */   public ImmutableTypingStart withUserId(long value) {
/* 160 */     Id newValue = Id.of(value);
/* 161 */     return new ImmutableTypingStart(this, channelId(), guildId(), newValue, this.timestamp, member());
/*     */   }
/*     */   
/*     */   public ImmutableTypingStart withUserId(String value) {
/* 165 */     Id newValue = Id.of(value);
/* 166 */     return new ImmutableTypingStart(this, channelId(), guildId(), newValue, this.timestamp, member());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableTypingStart withTimestamp(long value) {
/* 176 */     if (this.timestamp == value) return this; 
/* 177 */     return new ImmutableTypingStart(this, channelId(), guildId(), userId(), value, member());
/*     */   }
/*     */   
/*     */   public ImmutableTypingStart withMember(Possible<MemberData> value) {
/* 181 */     Possible<MemberData> newValue = Objects.<Possible<MemberData>>requireNonNull(value);
/* 182 */     return new ImmutableTypingStart(this, channelId(), guildId(), userId(), this.timestamp, newValue);
/*     */   }
/*     */   
/*     */   public ImmutableTypingStart withMember(MemberData value) {
/* 186 */     Possible<MemberData> newValue = Possible.of(value);
/* 187 */     return new ImmutableTypingStart(this, channelId(), guildId(), userId(), this.timestamp, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 196 */     if (this == another) return true; 
/* 197 */     return (another instanceof ImmutableTypingStart && 
/* 198 */       equalTo(0, (ImmutableTypingStart)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableTypingStart another) {
/* 202 */     return (Objects.equals(Long.valueOf(this.channelId_value), Long.valueOf(another.channelId_value)) && 
/* 203 */       guildId().equals(another.guildId()) && 
/* 204 */       Objects.equals(Long.valueOf(this.userId_value), Long.valueOf(another.userId_value)) && this.timestamp == another.timestamp && 
/*     */       
/* 206 */       member().equals(another.member()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 215 */     int h = 5381;
/* 216 */     h += (h << 5) + Objects.hashCode(Long.valueOf(this.channelId_value));
/* 217 */     h += (h << 5) + guildId().hashCode();
/* 218 */     h += (h << 5) + Objects.hashCode(Long.valueOf(this.userId_value));
/* 219 */     h += (h << 5) + Long.hashCode(this.timestamp);
/* 220 */     h += (h << 5) + member().hashCode();
/* 221 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 230 */     return "TypingStart{channelId=" + 
/* 231 */       Objects.toString(Long.valueOf(this.channelId_value)) + ", guildId=" + 
/* 232 */       guildId().toString() + ", userId=" + 
/* 233 */       Objects.toString(Long.valueOf(this.userId_value)) + ", timestamp=" + this.timestamp + ", member=" + 
/*     */       
/* 235 */       member().toString() + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "TypingStart", generator = "Immutables")
/*     */   static final class Json
/*     */     implements TypingStart
/*     */   {
/*     */     Id channelId;
/*     */ 
/*     */     
/* 250 */     Possible<Id> guildId = Possible.absent();
/*     */     
/*     */     Id userId;
/*     */     
/*     */     long timestamp;
/*     */     boolean timestampIsSet;
/* 256 */     Possible<MemberData> member = Possible.absent();
/*     */     
/*     */     @JsonProperty("channel_id")
/*     */     public void setChannelId(Id channelId) {
/* 260 */       this.channelId = channelId;
/*     */     }
/*     */     @JsonProperty("guild_id")
/*     */     public void setGuildId(Possible<Id> guildId) {
/* 264 */       this.guildId = guildId;
/*     */     }
/*     */     @JsonProperty("user_id")
/*     */     public void setUserId(Id userId) {
/* 268 */       this.userId = userId;
/*     */     }
/*     */     @JsonProperty("timestamp")
/*     */     public void setTimestamp(long timestamp) {
/* 272 */       this.timestamp = timestamp;
/* 273 */       this.timestampIsSet = true;
/*     */     }
/*     */     @JsonProperty("member")
/*     */     public void setMember(Possible<MemberData> member) {
/* 277 */       this.member = member;
/*     */     }
/*     */     public Id channelId() {
/* 280 */       throw new UnsupportedOperationException();
/*     */     } public Possible<Id> guildId() {
/* 282 */       throw new UnsupportedOperationException();
/*     */     } public Id userId() {
/* 284 */       throw new UnsupportedOperationException();
/*     */     } public long timestamp() {
/* 286 */       throw new UnsupportedOperationException();
/*     */     } public Possible<MemberData> member() {
/* 288 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableTypingStart fromJson(Json json) {
/* 299 */     Builder builder = builder();
/* 300 */     if (json.channelId != null) {
/* 301 */       builder.channelId(json.channelId);
/*     */     }
/* 303 */     if (json.guildId != null) {
/* 304 */       builder.guildId(json.guildId);
/*     */     }
/* 306 */     if (json.userId != null) {
/* 307 */       builder.userId(json.userId);
/*     */     }
/* 309 */     if (json.timestampIsSet) {
/* 310 */       builder.timestamp(json.timestamp);
/*     */     }
/* 312 */     if (json.member != null) {
/* 313 */       builder.member(json.member);
/*     */     }
/* 315 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableTypingStart of(Id channelId, Possible<Id> guildId, Id userId, long timestamp, Possible<MemberData> member) {
/* 328 */     return new ImmutableTypingStart(channelId, guildId, userId, timestamp, member);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableTypingStart copyOf(TypingStart instance) {
/* 339 */     if (instance instanceof ImmutableTypingStart) {
/* 340 */       return (ImmutableTypingStart)instance;
/*     */     }
/* 342 */     return builder()
/* 343 */       .from(instance)
/* 344 */       .build();
/*     */   }
/*     */   
/*     */   public boolean isGuildIdPresent() {
/* 348 */     return !this.guildId_absent;
/*     */   }
/*     */   
/*     */   public long guildIdOrElse(long defaultValue) {
/* 352 */     return !this.guildId_absent ? this.guildId_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isMemberPresent() {
/* 356 */     return !this.member_absent;
/*     */   }
/*     */   
/*     */   public MemberData memberOrElse(MemberData defaultValue) {
/* 360 */     return !this.member_absent ? this.member_value : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 377 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "TypingStart", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_TIMESTAMP = 1L;
/*     */ 
/*     */ 
/*     */     
/* 390 */     private long initBits = 1L;
/*     */     
/* 392 */     private Id channelId_id = null;
/* 393 */     private Possible<Id> guildId_possible = Possible.absent();
/* 394 */     private Id userId_id = null;
/* 395 */     private Possible<MemberData> member_possible = Possible.absent();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private long timestamp;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(TypingStart instance) {
/* 409 */       Objects.requireNonNull(instance, "instance");
/* 410 */       channelId(instance.channelId());
/* 411 */       guildId(instance.guildId());
/* 412 */       userId(instance.userId());
/* 413 */       timestamp(instance.timestamp());
/* 414 */       member(instance.member());
/* 415 */       return this;
/*     */     }
/*     */     
/*     */     public Builder channelId(String value) {
/* 419 */       this.channelId_id = Id.of(value);
/* 420 */       return this;
/*     */     }
/*     */     
/*     */     public Builder channelId(long value) {
/* 424 */       this.channelId_id = Id.of(value);
/* 425 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("channel_id")
/*     */     public Builder channelId(Id value) {
/* 430 */       this.channelId_id = value;
/* 431 */       return this;
/*     */     }
/*     */     
/*     */     public Builder guildId(String value) {
/* 435 */       this.guildId_possible = Possible.of(Id.of(value));
/* 436 */       return this;
/*     */     }
/*     */     
/*     */     public Builder guildId(long value) {
/* 440 */       this.guildId_possible = Possible.of(Id.of(value));
/* 441 */       return this;
/*     */     }
/*     */     
/*     */     public Builder guildId(Id value) {
/* 445 */       this.guildId_possible = Possible.of(value);
/* 446 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("guild_id")
/*     */     public Builder guildId(Possible<Id> value) {
/* 451 */       this.guildId_possible = value;
/* 452 */       return this;
/*     */     }
/*     */     
/*     */     public Builder userId(String value) {
/* 456 */       this.userId_id = Id.of(value);
/* 457 */       return this;
/*     */     }
/*     */     
/*     */     public Builder userId(long value) {
/* 461 */       this.userId_id = Id.of(value);
/* 462 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("user_id")
/*     */     public Builder userId(Id value) {
/* 467 */       this.userId_id = value;
/* 468 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("timestamp")
/*     */     public final Builder timestamp(long timestamp) {
/* 478 */       this.timestamp = timestamp;
/* 479 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 480 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("member")
/*     */     public Builder member(Possible<MemberData> value) {
/* 485 */       this.member_possible = value;
/* 486 */       return this;
/*     */     }
/*     */     
/*     */     public Builder member(MemberData value) {
/* 490 */       this.member_possible = Possible.of(value);
/* 491 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableTypingStart build() {
/* 500 */       if (this.initBits != 0L) {
/* 501 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 503 */       return new ImmutableTypingStart(null, channelId_build(), guildId_build(), userId_build(), this.timestamp, member_build());
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 507 */       List<String> attributes = new ArrayList<>();
/* 508 */       if ((this.initBits & 0x1L) != 0L) attributes.add("timestamp"); 
/* 509 */       return "Cannot build TypingStart, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Id channelId_build() {
/* 513 */       return this.channelId_id;
/*     */     }
/*     */     
/*     */     private Possible<Id> guildId_build() {
/* 517 */       return this.guildId_possible;
/*     */     }
/*     */     
/*     */     private Id userId_build() {
/* 521 */       return this.userId_id;
/*     */     }
/*     */     
/*     */     private Possible<MemberData> member_build() {
/* 525 */       return this.member_possible;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\gateway\ImmutableTypingStart.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */