/*     */ package discord4j.discordjson.json.gateway;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.Id;
/*     */ import discord4j.discordjson.json.StickerData;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "GuildStickersUpdate", generator = "Immutables")
/*     */ public final class ImmutableGuildStickersUpdate
/*     */   implements GuildStickersUpdate
/*     */ {
/*     */   private final long guildId_value;
/*     */   private final List<StickerData> stickers;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   
/*     */   private ImmutableGuildStickersUpdate(Id guildId, Iterable<? extends StickerData> stickers) {
/*  36 */     Id guildId$impl = guildId;
/*  37 */     this.stickers = createUnmodifiableList(false, createSafeList(stickers, true, false));
/*  38 */     this.guildId_value = guildId$impl.asLong();
/*  39 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ImmutableGuildStickersUpdate(ImmutableGuildStickersUpdate original, Id guildId, List<StickerData> stickers) {
/*  46 */     Id guildId$impl = guildId;
/*  47 */     this.stickers = stickers;
/*  48 */     this.guildId_value = guildId$impl.asLong();
/*  49 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  55 */   private volatile transient InitShim initShim = new InitShim();
/*     */   
/*     */   @Generated(from = "GuildStickersUpdate", generator = "Immutables")
/*     */   private final class InitShim {
/*     */     private String formatInitCycleMessage() {
/*  60 */       List<String> attributes = new ArrayList<>();
/*  61 */       return "Cannot build GuildStickersUpdate, attribute initializers form cycle " + attributes;
/*     */     }
/*     */ 
/*     */     
/*     */     private InitShim() {}
/*     */   }
/*     */ 
/*     */   
/*     */   @JsonProperty("guild_id")
/*     */   public Id guildId() {
/*  71 */     return Id.of(this.guildId_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("stickers")
/*     */   public List<StickerData> stickers() {
/*  80 */     return this.stickers;
/*     */   }
/*     */   
/*     */   public ImmutableGuildStickersUpdate withGuildId(long value) {
/*  84 */     Id newValue = Id.of(value);
/*  85 */     return new ImmutableGuildStickersUpdate(this, newValue, this.stickers);
/*     */   }
/*     */   
/*     */   public ImmutableGuildStickersUpdate withGuildId(String value) {
/*  89 */     Id newValue = Id.of(value);
/*  90 */     return new ImmutableGuildStickersUpdate(this, newValue, this.stickers);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableGuildStickersUpdate withStickers(StickerData... elements) {
/*  99 */     List<StickerData> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/* 100 */     return new ImmutableGuildStickersUpdate(this, guildId(), newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableGuildStickersUpdate withStickers(Iterable<? extends StickerData> elements) {
/* 110 */     if (this.stickers == elements) return this; 
/* 111 */     List<StickerData> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/* 112 */     return new ImmutableGuildStickersUpdate(this, guildId(), newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 121 */     if (this == another) return true; 
/* 122 */     return (another instanceof ImmutableGuildStickersUpdate && 
/* 123 */       equalTo(0, (ImmutableGuildStickersUpdate)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableGuildStickersUpdate another) {
/* 127 */     return (Objects.equals(Long.valueOf(this.guildId_value), Long.valueOf(another.guildId_value)) && this.stickers
/* 128 */       .equals(another.stickers));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 137 */     int h = 5381;
/* 138 */     h += (h << 5) + Objects.hashCode(Long.valueOf(this.guildId_value));
/* 139 */     h += (h << 5) + this.stickers.hashCode();
/* 140 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 149 */     return "GuildStickersUpdate{guildId=" + 
/* 150 */       Objects.toString(Long.valueOf(this.guildId_value)) + ", stickers=" + this.stickers + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "GuildStickersUpdate", generator = "Immutables")
/*     */   static final class Json
/*     */     implements GuildStickersUpdate
/*     */   {
/*     */     Id guildId;
/*     */ 
/*     */     
/* 165 */     List<StickerData> stickers = Collections.emptyList();
/*     */     @JsonProperty("guild_id")
/*     */     public void setGuildId(Id guildId) {
/* 168 */       this.guildId = guildId;
/*     */     }
/*     */     @JsonProperty("stickers")
/*     */     public void setStickers(List<StickerData> stickers) {
/* 172 */       this.stickers = stickers;
/*     */     }
/*     */     public Id guildId() {
/* 175 */       throw new UnsupportedOperationException();
/*     */     } public List<StickerData> stickers() {
/* 177 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableGuildStickersUpdate fromJson(Json json) {
/* 188 */     Builder builder = builder();
/* 189 */     if (json.guildId != null) {
/* 190 */       builder.guildId(json.guildId);
/*     */     }
/* 192 */     if (json.stickers != null) {
/* 193 */       builder.addAllStickers(json.stickers);
/*     */     }
/* 195 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableGuildStickersUpdate of(Id guildId, List<StickerData> stickers) {
/* 205 */     return of(guildId, stickers);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableGuildStickersUpdate of(Id guildId, Iterable<? extends StickerData> stickers) {
/* 215 */     return new ImmutableGuildStickersUpdate(guildId, stickers);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableGuildStickersUpdate copyOf(GuildStickersUpdate instance) {
/* 226 */     if (instance instanceof ImmutableGuildStickersUpdate) {
/* 227 */       return (ImmutableGuildStickersUpdate)instance;
/*     */     }
/* 229 */     return builder()
/* 230 */       .from(instance)
/* 231 */       .build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 245 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "GuildStickersUpdate", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/* 257 */     private Id guildId_id = null;
/* 258 */     private List<StickerData> stickers = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(GuildStickersUpdate instance) {
/* 272 */       Objects.requireNonNull(instance, "instance");
/* 273 */       guildId(instance.guildId());
/* 274 */       addAllStickers(instance.stickers());
/* 275 */       return this;
/*     */     }
/*     */     
/*     */     public Builder guildId(String value) {
/* 279 */       this.guildId_id = Id.of(value);
/* 280 */       return this;
/*     */     }
/*     */     
/*     */     public Builder guildId(long value) {
/* 284 */       this.guildId_id = Id.of(value);
/* 285 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("guild_id")
/*     */     public Builder guildId(Id value) {
/* 290 */       this.guildId_id = value;
/* 291 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder addSticker(StickerData element) {
/* 300 */       this.stickers.add(Objects.<StickerData>requireNonNull(element, "stickers element"));
/* 301 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder addStickers(StickerData... elements) {
/* 310 */       for (StickerData element : elements) {
/* 311 */         this.stickers.add(Objects.<StickerData>requireNonNull(element, "stickers element"));
/*     */       }
/* 313 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("stickers")
/*     */     public final Builder stickers(Iterable<? extends StickerData> elements) {
/* 324 */       this.stickers.clear();
/* 325 */       return addAllStickers(elements);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder addAllStickers(Iterable<? extends StickerData> elements) {
/* 334 */       for (StickerData element : elements) {
/* 335 */         this.stickers.add(Objects.<StickerData>requireNonNull(element, "stickers element"));
/*     */       }
/* 337 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableGuildStickersUpdate build() {
/* 346 */       return new ImmutableGuildStickersUpdate(null, guildId_build(), ImmutableGuildStickersUpdate.createUnmodifiableList(true, (List)this.stickers));
/*     */     }
/*     */     
/*     */     private Id guildId_build() {
/* 350 */       return this.guildId_id;
/*     */     }
/*     */     private Builder() {} }
/*     */   
/*     */   private static <T> List<T> createSafeList(Iterable<? extends T> iterable, boolean checkNulls, boolean skipNulls) {
/*     */     ArrayList<T> list;
/* 356 */     if (iterable instanceof Collection) {
/* 357 */       int size = ((Collection)iterable).size();
/* 358 */       if (size == 0) return Collections.emptyList(); 
/* 359 */       list = new ArrayList<>();
/*     */     } else {
/* 361 */       list = new ArrayList<>();
/*     */     } 
/* 363 */     for (T element : iterable) {
/* 364 */       if (skipNulls && element == null)
/* 365 */         continue;  if (checkNulls) Objects.requireNonNull(element, "element"); 
/* 366 */       list.add(element);
/*     */     } 
/* 368 */     return list;
/*     */   }
/*     */   
/*     */   private static <T> List<T> createUnmodifiableList(boolean clone, List<T> list) {
/* 372 */     switch (list.size()) { case 0:
/* 373 */         return Collections.emptyList();
/* 374 */       case 1: return Collections.singletonList(list.get(0)); }
/*     */     
/* 376 */     if (clone) {
/* 377 */       return Collections.unmodifiableList(new ArrayList<>(list));
/*     */     }
/* 379 */     if (list instanceof ArrayList) {
/* 380 */       ((ArrayList)list).trimToSize();
/*     */     }
/* 382 */     return Collections.unmodifiableList(list);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\gateway\ImmutableGuildStickersUpdate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */