/*      */ package discord4j.discordjson.json.gateway;
/*      */ 
/*      */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*      */ import com.fasterxml.jackson.annotation.JsonCreator;
/*      */ import com.fasterxml.jackson.annotation.JsonProperty;
/*      */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*      */ import discord4j.discordjson.Id;
/*      */ import discord4j.discordjson.json.UserData;
/*      */ import discord4j.discordjson.possible.Possible;
/*      */ import java.util.ArrayList;
/*      */ import java.util.List;
/*      */ import java.util.Objects;
/*      */ import org.immutables.value.Generated;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ @Generated(from = "InviteCreate", generator = "Immutables")
/*      */ public final class ImmutableInviteCreate
/*      */   implements InviteCreate
/*      */ {
/*      */   private final long channelId_value;
/*      */   private final String code;
/*      */   private final String createdAt;
/*      */   private final long guildId_value;
/*      */   private final UserData inviter_value;
/*      */   private final boolean inviter_absent;
/*      */   private final int maxAge;
/*      */   private final int maxUses;
/*      */   private final Integer targetType_value;
/*      */   private final boolean targetType_absent;
/*      */   private final UserData targetUser_value;
/*      */   private final boolean targetUser_absent;
/*      */   private final boolean temporary;
/*      */   private final int uses;
/*      */   private static final byte STAGE_INITIALIZING = -1;
/*      */   private static final byte STAGE_UNINITIALIZED = 0;
/*      */   private static final byte STAGE_INITIALIZED = 1;
/*      */   
/*      */   private ImmutableInviteCreate(Id channelId, String code, String createdAt, Id guildId, Possible<UserData> inviter, int maxAge, int maxUses, Possible<Integer> targetType, Possible<UserData> targetUser, boolean temporary, int uses) {
/*   54 */     Id channelId$impl = channelId;
/*   55 */     this.code = Objects.<String>requireNonNull(code, "code");
/*   56 */     this.createdAt = Objects.<String>requireNonNull(createdAt, "createdAt");
/*   57 */     Id guildId$impl = guildId;
/*   58 */     Possible<UserData> inviter$impl = inviter;
/*   59 */     this.maxAge = maxAge;
/*   60 */     this.maxUses = maxUses;
/*   61 */     Possible<Integer> targetType$impl = targetType;
/*   62 */     Possible<UserData> targetUser$impl = targetUser;
/*   63 */     this.temporary = temporary;
/*   64 */     this.uses = uses;
/*   65 */     this.channelId_value = channelId$impl.asLong();
/*   66 */     this.guildId_value = guildId$impl.asLong();
/*   67 */     this.inviter_value = inviter$impl.toOptional().orElse(null);
/*   68 */     this.inviter_absent = inviter$impl.isAbsent();
/*   69 */     this.targetType_value = targetType$impl.toOptional().orElse(null);
/*   70 */     this.targetType_absent = targetType$impl.isAbsent();
/*   71 */     this.targetUser_value = targetUser$impl.toOptional().orElse(null);
/*   72 */     this.targetUser_absent = targetUser$impl.isAbsent();
/*   73 */     this.initShim = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ImmutableInviteCreate(ImmutableInviteCreate original, Id channelId, String code, String createdAt, Id guildId, Possible<UserData> inviter, int maxAge, int maxUses, Possible<Integer> targetType, Possible<UserData> targetUser, boolean temporary, int uses) {
/*   89 */     Id channelId$impl = channelId;
/*   90 */     this.code = code;
/*   91 */     this.createdAt = createdAt;
/*   92 */     Id guildId$impl = guildId;
/*   93 */     Possible<UserData> inviter$impl = inviter;
/*   94 */     this.maxAge = maxAge;
/*   95 */     this.maxUses = maxUses;
/*   96 */     Possible<Integer> targetType$impl = targetType;
/*   97 */     Possible<UserData> targetUser$impl = targetUser;
/*   98 */     this.temporary = temporary;
/*   99 */     this.uses = uses;
/*  100 */     this.channelId_value = channelId$impl.asLong();
/*  101 */     this.guildId_value = guildId$impl.asLong();
/*  102 */     this.inviter_value = inviter$impl.toOptional().orElse(null);
/*  103 */     this.inviter_absent = inviter$impl.isAbsent();
/*  104 */     this.targetType_value = targetType$impl.toOptional().orElse(null);
/*  105 */     this.targetType_absent = targetType$impl.isAbsent();
/*  106 */     this.targetUser_value = targetUser$impl.toOptional().orElse(null);
/*  107 */     this.targetUser_absent = targetUser$impl.isAbsent();
/*  108 */     this.initShim = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  114 */   private volatile transient InitShim initShim = new InitShim();
/*      */   
/*      */   @Generated(from = "InviteCreate", generator = "Immutables")
/*      */   private final class InitShim {
/*      */     private String formatInitCycleMessage() {
/*  119 */       List<String> attributes = new ArrayList<>();
/*  120 */       return "Cannot build InviteCreate, attribute initializers form cycle " + attributes;
/*      */     }
/*      */ 
/*      */     
/*      */     private InitShim() {}
/*      */   }
/*      */ 
/*      */   
/*      */   @JsonProperty("channel_id")
/*      */   public Id channelId() {
/*  130 */     return Id.of(this.channelId_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("code")
/*      */   public String code() {
/*  139 */     return this.code;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("created_at")
/*      */   public String createdAt() {
/*  148 */     return this.createdAt;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("guild_id")
/*      */   public Id guildId() {
/*  157 */     return Id.of(this.guildId_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("inviter")
/*      */   public Possible<UserData> inviter() {
/*  166 */     return this.inviter_absent ? Possible.absent() : Possible.of(this.inviter_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("max_age")
/*      */   public int maxAge() {
/*  175 */     return this.maxAge;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("max_uses")
/*      */   public int maxUses() {
/*  184 */     return this.maxUses;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("target_type")
/*      */   public Possible<Integer> targetType() {
/*  193 */     return this.targetType_absent ? Possible.absent() : Possible.of(this.targetType_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("target_user")
/*      */   public Possible<UserData> targetUser() {
/*  202 */     return this.targetUser_absent ? Possible.absent() : Possible.of(this.targetUser_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("temporary")
/*      */   public boolean temporary() {
/*  211 */     return this.temporary;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("uses")
/*      */   public int uses() {
/*  220 */     return this.uses;
/*      */   }
/*      */   
/*      */   public ImmutableInviteCreate withChannelId(long value) {
/*  224 */     Id newValue = Id.of(value);
/*  225 */     return new ImmutableInviteCreate(this, newValue, this.code, this.createdAt, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  230 */         guildId(), 
/*  231 */         inviter(), this.maxAge, this.maxUses, 
/*      */ 
/*      */         
/*  234 */         targetType(), 
/*  235 */         targetUser(), this.temporary, this.uses);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutableInviteCreate withChannelId(String value) {
/*  241 */     Id newValue = Id.of(value);
/*  242 */     return new ImmutableInviteCreate(this, newValue, this.code, this.createdAt, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  247 */         guildId(), 
/*  248 */         inviter(), this.maxAge, this.maxUses, 
/*      */ 
/*      */         
/*  251 */         targetType(), 
/*  252 */         targetUser(), this.temporary, this.uses);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableInviteCreate withCode(String value) {
/*  264 */     String newValue = Objects.<String>requireNonNull(value, "code");
/*  265 */     if (this.code.equals(newValue)) return this; 
/*  266 */     return new ImmutableInviteCreate(this, 
/*      */         
/*  268 */         channelId(), newValue, this.createdAt, 
/*      */ 
/*      */         
/*  271 */         guildId(), 
/*  272 */         inviter(), this.maxAge, this.maxUses, 
/*      */ 
/*      */         
/*  275 */         targetType(), 
/*  276 */         targetUser(), this.temporary, this.uses);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableInviteCreate withCreatedAt(String value) {
/*  288 */     String newValue = Objects.<String>requireNonNull(value, "createdAt");
/*  289 */     if (this.createdAt.equals(newValue)) return this; 
/*  290 */     return new ImmutableInviteCreate(this, 
/*      */         
/*  292 */         channelId(), this.code, newValue, 
/*      */ 
/*      */         
/*  295 */         guildId(), 
/*  296 */         inviter(), this.maxAge, this.maxUses, 
/*      */ 
/*      */         
/*  299 */         targetType(), 
/*  300 */         targetUser(), this.temporary, this.uses);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutableInviteCreate withGuildId(long value) {
/*  306 */     Id newValue = Id.of(value);
/*  307 */     return new ImmutableInviteCreate(this, 
/*      */         
/*  309 */         channelId(), this.code, this.createdAt, newValue, 
/*      */ 
/*      */ 
/*      */         
/*  313 */         inviter(), this.maxAge, this.maxUses, 
/*      */ 
/*      */         
/*  316 */         targetType(), 
/*  317 */         targetUser(), this.temporary, this.uses);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutableInviteCreate withGuildId(String value) {
/*  323 */     Id newValue = Id.of(value);
/*  324 */     return new ImmutableInviteCreate(this, 
/*      */         
/*  326 */         channelId(), this.code, this.createdAt, newValue, 
/*      */ 
/*      */ 
/*      */         
/*  330 */         inviter(), this.maxAge, this.maxUses, 
/*      */ 
/*      */         
/*  333 */         targetType(), 
/*  334 */         targetUser(), this.temporary, this.uses);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutableInviteCreate withInviter(Possible<UserData> value) {
/*  340 */     Possible<UserData> newValue = Objects.<Possible<UserData>>requireNonNull(value);
/*  341 */     return new ImmutableInviteCreate(this, 
/*      */         
/*  343 */         channelId(), this.code, this.createdAt, 
/*      */ 
/*      */         
/*  346 */         guildId(), newValue, this.maxAge, this.maxUses, 
/*      */ 
/*      */ 
/*      */         
/*  350 */         targetType(), 
/*  351 */         targetUser(), this.temporary, this.uses);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutableInviteCreate withInviter(UserData value) {
/*  357 */     Possible<UserData> newValue = Possible.of(value);
/*  358 */     return new ImmutableInviteCreate(this, 
/*      */         
/*  360 */         channelId(), this.code, this.createdAt, 
/*      */ 
/*      */         
/*  363 */         guildId(), newValue, this.maxAge, this.maxUses, 
/*      */ 
/*      */ 
/*      */         
/*  367 */         targetType(), 
/*  368 */         targetUser(), this.temporary, this.uses);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableInviteCreate withMaxAge(int value) {
/*  380 */     if (this.maxAge == value) return this; 
/*  381 */     return new ImmutableInviteCreate(this, 
/*      */         
/*  383 */         channelId(), this.code, this.createdAt, 
/*      */ 
/*      */         
/*  386 */         guildId(), 
/*  387 */         inviter(), value, this.maxUses, 
/*      */ 
/*      */         
/*  390 */         targetType(), 
/*  391 */         targetUser(), this.temporary, this.uses);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableInviteCreate withMaxUses(int value) {
/*  403 */     if (this.maxUses == value) return this; 
/*  404 */     return new ImmutableInviteCreate(this, 
/*      */         
/*  406 */         channelId(), this.code, this.createdAt, 
/*      */ 
/*      */         
/*  409 */         guildId(), 
/*  410 */         inviter(), this.maxAge, value, 
/*      */ 
/*      */         
/*  413 */         targetType(), 
/*  414 */         targetUser(), this.temporary, this.uses);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutableInviteCreate withTargetType(Possible<Integer> value) {
/*  420 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/*  421 */     return new ImmutableInviteCreate(this, 
/*      */         
/*  423 */         channelId(), this.code, this.createdAt, 
/*      */ 
/*      */         
/*  426 */         guildId(), 
/*  427 */         inviter(), this.maxAge, this.maxUses, newValue, 
/*      */ 
/*      */ 
/*      */         
/*  431 */         targetUser(), this.temporary, this.uses);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutableInviteCreate withTargetType(Integer value) {
/*  437 */     Possible<Integer> newValue = Possible.of(value);
/*  438 */     return new ImmutableInviteCreate(this, 
/*      */         
/*  440 */         channelId(), this.code, this.createdAt, 
/*      */ 
/*      */         
/*  443 */         guildId(), 
/*  444 */         inviter(), this.maxAge, this.maxUses, newValue, 
/*      */ 
/*      */ 
/*      */         
/*  448 */         targetUser(), this.temporary, this.uses);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutableInviteCreate withTargetUser(Possible<UserData> value) {
/*  454 */     Possible<UserData> newValue = Objects.<Possible<UserData>>requireNonNull(value);
/*  455 */     return new ImmutableInviteCreate(this, 
/*      */         
/*  457 */         channelId(), this.code, this.createdAt, 
/*      */ 
/*      */         
/*  460 */         guildId(), 
/*  461 */         inviter(), this.maxAge, this.maxUses, 
/*      */ 
/*      */         
/*  464 */         targetType(), newValue, this.temporary, this.uses);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutableInviteCreate withTargetUser(UserData value) {
/*  471 */     Possible<UserData> newValue = Possible.of(value);
/*  472 */     return new ImmutableInviteCreate(this, 
/*      */         
/*  474 */         channelId(), this.code, this.createdAt, 
/*      */ 
/*      */         
/*  477 */         guildId(), 
/*  478 */         inviter(), this.maxAge, this.maxUses, 
/*      */ 
/*      */         
/*  481 */         targetType(), newValue, this.temporary, this.uses);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableInviteCreate withTemporary(boolean value) {
/*  494 */     if (this.temporary == value) return this; 
/*  495 */     return new ImmutableInviteCreate(this, 
/*      */         
/*  497 */         channelId(), this.code, this.createdAt, 
/*      */ 
/*      */         
/*  500 */         guildId(), 
/*  501 */         inviter(), this.maxAge, this.maxUses, 
/*      */ 
/*      */         
/*  504 */         targetType(), 
/*  505 */         targetUser(), value, this.uses);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableInviteCreate withUses(int value) {
/*  517 */     if (this.uses == value) return this; 
/*  518 */     return new ImmutableInviteCreate(this, 
/*      */         
/*  520 */         channelId(), this.code, this.createdAt, 
/*      */ 
/*      */         
/*  523 */         guildId(), 
/*  524 */         inviter(), this.maxAge, this.maxUses, 
/*      */ 
/*      */         
/*  527 */         targetType(), 
/*  528 */         targetUser(), this.temporary, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean equals(Object another) {
/*  539 */     if (this == another) return true; 
/*  540 */     return (another instanceof ImmutableInviteCreate && 
/*  541 */       equalTo(0, (ImmutableInviteCreate)another));
/*      */   }
/*      */   
/*      */   private boolean equalTo(int synthetic, ImmutableInviteCreate another) {
/*  545 */     return (Objects.equals(Long.valueOf(this.channelId_value), Long.valueOf(another.channelId_value)) && this.code
/*  546 */       .equals(another.code) && this.createdAt
/*  547 */       .equals(another.createdAt) && 
/*  548 */       Objects.equals(Long.valueOf(this.guildId_value), Long.valueOf(another.guildId_value)) && 
/*  549 */       inviter().equals(another.inviter()) && this.maxAge == another.maxAge && this.maxUses == another.maxUses && 
/*      */ 
/*      */       
/*  552 */       targetType().equals(another.targetType()) && 
/*  553 */       targetUser().equals(another.targetUser()) && this.temporary == another.temporary && this.uses == another.uses);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int hashCode() {
/*  564 */     int h = 5381;
/*  565 */     h += (h << 5) + Objects.hashCode(Long.valueOf(this.channelId_value));
/*  566 */     h += (h << 5) + this.code.hashCode();
/*  567 */     h += (h << 5) + this.createdAt.hashCode();
/*  568 */     h += (h << 5) + Objects.hashCode(Long.valueOf(this.guildId_value));
/*  569 */     h += (h << 5) + inviter().hashCode();
/*  570 */     h += (h << 5) + this.maxAge;
/*  571 */     h += (h << 5) + this.maxUses;
/*  572 */     h += (h << 5) + targetType().hashCode();
/*  573 */     h += (h << 5) + targetUser().hashCode();
/*  574 */     h += (h << 5) + Boolean.hashCode(this.temporary);
/*  575 */     h += (h << 5) + this.uses;
/*  576 */     return h;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/*  585 */     return "InviteCreate{channelId=" + 
/*  586 */       Objects.toString(Long.valueOf(this.channelId_value)) + ", code=" + this.code + ", createdAt=" + this.createdAt + ", guildId=" + 
/*      */ 
/*      */       
/*  589 */       Objects.toString(Long.valueOf(this.guildId_value)) + ", inviter=" + 
/*  590 */       inviter().toString() + ", maxAge=" + this.maxAge + ", maxUses=" + this.maxUses + ", targetType=" + 
/*      */ 
/*      */       
/*  593 */       targetType().toString() + ", targetUser=" + 
/*  594 */       targetUser().toString() + ", temporary=" + this.temporary + ", uses=" + this.uses + "}";
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonDeserialize
/*      */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*      */   @Generated(from = "InviteCreate", generator = "Immutables")
/*      */   static final class Json
/*      */     implements InviteCreate
/*      */   {
/*      */     Id channelId;
/*      */     
/*      */     String code;
/*      */     
/*      */     String createdAt;
/*      */     
/*      */     Id guildId;
/*      */     
/*  614 */     Possible<UserData> inviter = Possible.absent();
/*      */     
/*      */     int maxAge;
/*      */     
/*      */     boolean maxAgeIsSet;
/*      */     int maxUses;
/*      */     boolean maxUsesIsSet;
/*  621 */     Possible<Integer> targetType = Possible.absent();
/*      */ 
/*      */     
/*  624 */     Possible<UserData> targetUser = Possible.absent();
/*      */     boolean temporary;
/*      */     boolean temporaryIsSet;
/*      */     int uses;
/*      */     boolean usesIsSet;
/*      */     
/*      */     @JsonProperty("channel_id")
/*      */     public void setChannelId(Id channelId) {
/*  632 */       this.channelId = channelId;
/*      */     }
/*      */     @JsonProperty("code")
/*      */     public void setCode(String code) {
/*  636 */       this.code = code;
/*      */     }
/*      */     @JsonProperty("created_at")
/*      */     public void setCreatedAt(String createdAt) {
/*  640 */       this.createdAt = createdAt;
/*      */     }
/*      */     @JsonProperty("guild_id")
/*      */     public void setGuildId(Id guildId) {
/*  644 */       this.guildId = guildId;
/*      */     }
/*      */     @JsonProperty("inviter")
/*      */     public void setInviter(Possible<UserData> inviter) {
/*  648 */       this.inviter = inviter;
/*      */     }
/*      */     @JsonProperty("max_age")
/*      */     public void setMaxAge(int maxAge) {
/*  652 */       this.maxAge = maxAge;
/*  653 */       this.maxAgeIsSet = true;
/*      */     }
/*      */     @JsonProperty("max_uses")
/*      */     public void setMaxUses(int maxUses) {
/*  657 */       this.maxUses = maxUses;
/*  658 */       this.maxUsesIsSet = true;
/*      */     }
/*      */     @JsonProperty("target_type")
/*      */     public void setTargetType(Possible<Integer> targetType) {
/*  662 */       this.targetType = targetType;
/*      */     }
/*      */     @JsonProperty("target_user")
/*      */     public void setTargetUser(Possible<UserData> targetUser) {
/*  666 */       this.targetUser = targetUser;
/*      */     }
/*      */     @JsonProperty("temporary")
/*      */     public void setTemporary(boolean temporary) {
/*  670 */       this.temporary = temporary;
/*  671 */       this.temporaryIsSet = true;
/*      */     }
/*      */     @JsonProperty("uses")
/*      */     public void setUses(int uses) {
/*  675 */       this.uses = uses;
/*  676 */       this.usesIsSet = true;
/*      */     }
/*      */     public Id channelId() {
/*  679 */       throw new UnsupportedOperationException();
/*      */     } public String code() {
/*  681 */       throw new UnsupportedOperationException();
/*      */     } public String createdAt() {
/*  683 */       throw new UnsupportedOperationException();
/*      */     } public Id guildId() {
/*  685 */       throw new UnsupportedOperationException();
/*      */     } public Possible<UserData> inviter() {
/*  687 */       throw new UnsupportedOperationException();
/*      */     } public int maxAge() {
/*  689 */       throw new UnsupportedOperationException();
/*      */     } public int maxUses() {
/*  691 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Integer> targetType() {
/*  693 */       throw new UnsupportedOperationException();
/*      */     } public Possible<UserData> targetUser() {
/*  695 */       throw new UnsupportedOperationException();
/*      */     } public boolean temporary() {
/*  697 */       throw new UnsupportedOperationException();
/*      */     } public int uses() {
/*  699 */       throw new UnsupportedOperationException();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*      */   static ImmutableInviteCreate fromJson(Json json) {
/*  710 */     Builder builder = builder();
/*  711 */     if (json.channelId != null) {
/*  712 */       builder.channelId(json.channelId);
/*      */     }
/*  714 */     if (json.code != null) {
/*  715 */       builder.code(json.code);
/*      */     }
/*  717 */     if (json.createdAt != null) {
/*  718 */       builder.createdAt(json.createdAt);
/*      */     }
/*  720 */     if (json.guildId != null) {
/*  721 */       builder.guildId(json.guildId);
/*      */     }
/*  723 */     if (json.inviter != null) {
/*  724 */       builder.inviter(json.inviter);
/*      */     }
/*  726 */     if (json.maxAgeIsSet) {
/*  727 */       builder.maxAge(json.maxAge);
/*      */     }
/*  729 */     if (json.maxUsesIsSet) {
/*  730 */       builder.maxUses(json.maxUses);
/*      */     }
/*  732 */     if (json.targetType != null) {
/*  733 */       builder.targetType(json.targetType);
/*      */     }
/*  735 */     if (json.targetUser != null) {
/*  736 */       builder.targetUser(json.targetUser);
/*      */     }
/*  738 */     if (json.temporaryIsSet) {
/*  739 */       builder.temporary(json.temporary);
/*      */     }
/*  741 */     if (json.usesIsSet) {
/*  742 */       builder.uses(json.uses);
/*      */     }
/*  744 */     return builder.build();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableInviteCreate of(Id channelId, String code, String createdAt, Id guildId, Possible<UserData> inviter, int maxAge, int maxUses, Possible<Integer> targetType, Possible<UserData> targetUser, boolean temporary, int uses) {
/*  763 */     return new ImmutableInviteCreate(channelId, code, createdAt, guildId, inviter, maxAge, maxUses, targetType, targetUser, temporary, uses);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableInviteCreate copyOf(InviteCreate instance) {
/*  774 */     if (instance instanceof ImmutableInviteCreate) {
/*  775 */       return (ImmutableInviteCreate)instance;
/*      */     }
/*  777 */     return builder()
/*  778 */       .from(instance)
/*  779 */       .build();
/*      */   }
/*      */   
/*      */   public boolean isInviterPresent() {
/*  783 */     return !this.inviter_absent;
/*      */   }
/*      */   
/*      */   public UserData inviterOrElse(UserData defaultValue) {
/*  787 */     return !this.inviter_absent ? this.inviter_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isTargetTypePresent() {
/*  791 */     return !this.targetType_absent;
/*      */   }
/*      */   
/*      */   public Integer targetTypeOrElse(Integer defaultValue) {
/*  795 */     return !this.targetType_absent ? this.targetType_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isTargetUserPresent() {
/*  799 */     return !this.targetUser_absent;
/*      */   }
/*      */   
/*      */   public UserData targetUserOrElse(UserData defaultValue) {
/*  803 */     return !this.targetUser_absent ? this.targetUser_value : defaultValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Builder builder() {
/*  826 */     return new Builder();
/*      */   }
/*      */ 
/*      */   
/*      */   @Generated(from = "InviteCreate", generator = "Immutables")
/*      */   public static final class Builder
/*      */   {
/*      */     private static final long INIT_BIT_CODE = 1L;
/*      */     
/*      */     private static final long INIT_BIT_CREATED_AT = 2L;
/*      */     
/*      */     private static final long INIT_BIT_MAX_AGE = 4L;
/*      */     
/*      */     private static final long INIT_BIT_MAX_USES = 8L;
/*      */     
/*      */     private static final long INIT_BIT_TEMPORARY = 16L;
/*      */     
/*      */     private static final long INIT_BIT_USES = 32L;
/*  844 */     private long initBits = 63L;
/*      */     
/*  846 */     private Id channelId_id = null;
/*  847 */     private Id guildId_id = null;
/*  848 */     private Possible<UserData> inviter_possible = Possible.absent();
/*  849 */     private Possible<Integer> targetType_possible = Possible.absent();
/*  850 */     private Possible<UserData> targetUser_possible = Possible.absent();
/*      */ 
/*      */     
/*      */     private String code;
/*      */ 
/*      */     
/*      */     private String createdAt;
/*      */ 
/*      */     
/*      */     private int maxAge;
/*      */     
/*      */     private int maxUses;
/*      */     
/*      */     private boolean temporary;
/*      */     
/*      */     private int uses;
/*      */ 
/*      */     
/*      */     public final Builder from(InviteCreate instance) {
/*  869 */       Objects.requireNonNull(instance, "instance");
/*  870 */       channelId(instance.channelId());
/*  871 */       code(instance.code());
/*  872 */       createdAt(instance.createdAt());
/*  873 */       guildId(instance.guildId());
/*  874 */       inviter(instance.inviter());
/*  875 */       maxAge(instance.maxAge());
/*  876 */       maxUses(instance.maxUses());
/*  877 */       targetType(instance.targetType());
/*  878 */       targetUser(instance.targetUser());
/*  879 */       temporary(instance.temporary());
/*  880 */       uses(instance.uses());
/*  881 */       return this;
/*      */     }
/*      */     
/*      */     public Builder channelId(String value) {
/*  885 */       this.channelId_id = Id.of(value);
/*  886 */       return this;
/*      */     }
/*      */     
/*      */     public Builder channelId(long value) {
/*  890 */       this.channelId_id = Id.of(value);
/*  891 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("channel_id")
/*      */     public Builder channelId(Id value) {
/*  896 */       this.channelId_id = value;
/*  897 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("code")
/*      */     public final Builder code(String code) {
/*  907 */       this.code = Objects.<String>requireNonNull(code, "code");
/*  908 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/*  909 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("created_at")
/*      */     public final Builder createdAt(String createdAt) {
/*  919 */       this.createdAt = Objects.<String>requireNonNull(createdAt, "createdAt");
/*  920 */       this.initBits &= 0xFFFFFFFFFFFFFFFDL;
/*  921 */       return this;
/*      */     }
/*      */     
/*      */     public Builder guildId(String value) {
/*  925 */       this.guildId_id = Id.of(value);
/*  926 */       return this;
/*      */     }
/*      */     
/*      */     public Builder guildId(long value) {
/*  930 */       this.guildId_id = Id.of(value);
/*  931 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("guild_id")
/*      */     public Builder guildId(Id value) {
/*  936 */       this.guildId_id = value;
/*  937 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("inviter")
/*      */     public Builder inviter(Possible<UserData> value) {
/*  942 */       this.inviter_possible = value;
/*  943 */       return this;
/*      */     }
/*      */     
/*      */     public Builder inviter(UserData value) {
/*  947 */       this.inviter_possible = Possible.of(value);
/*  948 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("max_age")
/*      */     public final Builder maxAge(int maxAge) {
/*  958 */       this.maxAge = maxAge;
/*  959 */       this.initBits &= 0xFFFFFFFFFFFFFFFBL;
/*  960 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("max_uses")
/*      */     public final Builder maxUses(int maxUses) {
/*  970 */       this.maxUses = maxUses;
/*  971 */       this.initBits &= 0xFFFFFFFFFFFFFFF7L;
/*  972 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("target_type")
/*      */     public Builder targetType(Possible<Integer> value) {
/*  977 */       this.targetType_possible = value;
/*  978 */       return this;
/*      */     }
/*      */     
/*      */     public Builder targetType(Integer value) {
/*  982 */       this.targetType_possible = Possible.of(value);
/*  983 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("target_user")
/*      */     public Builder targetUser(Possible<UserData> value) {
/*  988 */       this.targetUser_possible = value;
/*  989 */       return this;
/*      */     }
/*      */     
/*      */     public Builder targetUser(UserData value) {
/*  993 */       this.targetUser_possible = Possible.of(value);
/*  994 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("temporary")
/*      */     public final Builder temporary(boolean temporary) {
/* 1004 */       this.temporary = temporary;
/* 1005 */       this.initBits &= 0xFFFFFFFFFFFFFFEFL;
/* 1006 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("uses")
/*      */     public final Builder uses(int uses) {
/* 1016 */       this.uses = uses;
/* 1017 */       this.initBits &= 0xFFFFFFFFFFFFFFDFL;
/* 1018 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ImmutableInviteCreate build() {
/* 1027 */       if (this.initBits != 0L) {
/* 1028 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*      */       }
/* 1030 */       return new ImmutableInviteCreate(null, 
/*      */           
/* 1032 */           channelId_build(), this.code, this.createdAt, 
/*      */ 
/*      */           
/* 1035 */           guildId_build(), 
/* 1036 */           inviter_build(), this.maxAge, this.maxUses, 
/*      */ 
/*      */           
/* 1039 */           targetType_build(), 
/* 1040 */           targetUser_build(), this.temporary, this.uses);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     private String formatRequiredAttributesMessage() {
/* 1046 */       List<String> attributes = new ArrayList<>();
/* 1047 */       if ((this.initBits & 0x1L) != 0L) attributes.add("code"); 
/* 1048 */       if ((this.initBits & 0x2L) != 0L) attributes.add("createdAt"); 
/* 1049 */       if ((this.initBits & 0x4L) != 0L) attributes.add("maxAge"); 
/* 1050 */       if ((this.initBits & 0x8L) != 0L) attributes.add("maxUses"); 
/* 1051 */       if ((this.initBits & 0x10L) != 0L) attributes.add("temporary"); 
/* 1052 */       if ((this.initBits & 0x20L) != 0L) attributes.add("uses"); 
/* 1053 */       return "Cannot build InviteCreate, some of required attributes are not set " + attributes;
/*      */     }
/*      */     
/*      */     private Id channelId_build() {
/* 1057 */       return this.channelId_id;
/*      */     }
/*      */     
/*      */     private Id guildId_build() {
/* 1061 */       return this.guildId_id;
/*      */     }
/*      */     
/*      */     private Possible<UserData> inviter_build() {
/* 1065 */       return this.inviter_possible;
/*      */     }
/*      */     
/*      */     private Possible<Integer> targetType_build() {
/* 1069 */       return this.targetType_possible;
/*      */     }
/*      */     
/*      */     private Possible<UserData> targetUser_build() {
/* 1073 */       return this.targetUser_possible;
/*      */     }
/*      */     
/*      */     private Builder() {}
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\gateway\ImmutableInviteCreate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */