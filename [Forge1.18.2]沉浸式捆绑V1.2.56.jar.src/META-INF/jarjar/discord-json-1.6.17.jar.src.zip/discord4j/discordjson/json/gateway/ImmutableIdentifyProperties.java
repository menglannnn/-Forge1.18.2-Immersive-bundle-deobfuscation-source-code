/*     */ package discord4j.discordjson.json.gateway;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "IdentifyProperties", generator = "Immutables")
/*     */ public final class ImmutableIdentifyProperties
/*     */   implements IdentifyProperties
/*     */ {
/*     */   private final String os;
/*     */   private final String browser;
/*     */   private final String device;
/*     */   
/*     */   private ImmutableIdentifyProperties(String os, String browser, String device) {
/*  30 */     this.os = Objects.<String>requireNonNull(os, "os");
/*  31 */     this.browser = Objects.<String>requireNonNull(browser, "browser");
/*  32 */     this.device = Objects.<String>requireNonNull(device, "device");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ImmutableIdentifyProperties(ImmutableIdentifyProperties original, String os, String browser, String device) {
/*  40 */     this.os = os;
/*  41 */     this.browser = browser;
/*  42 */     this.device = device;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("os")
/*     */   public String os() {
/*  51 */     return this.os;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("browser")
/*     */   public String browser() {
/*  60 */     return this.browser;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("device")
/*     */   public String device() {
/*  69 */     return this.device;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableIdentifyProperties withOs(String value) {
/*  79 */     String newValue = Objects.<String>requireNonNull(value, "os");
/*  80 */     if (this.os.equals(newValue)) return this; 
/*  81 */     return new ImmutableIdentifyProperties(this, newValue, this.browser, this.device);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableIdentifyProperties withBrowser(String value) {
/*  91 */     String newValue = Objects.<String>requireNonNull(value, "browser");
/*  92 */     if (this.browser.equals(newValue)) return this; 
/*  93 */     return new ImmutableIdentifyProperties(this, this.os, newValue, this.device);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableIdentifyProperties withDevice(String value) {
/* 103 */     String newValue = Objects.<String>requireNonNull(value, "device");
/* 104 */     if (this.device.equals(newValue)) return this; 
/* 105 */     return new ImmutableIdentifyProperties(this, this.os, this.browser, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 114 */     if (this == another) return true; 
/* 115 */     return (another instanceof ImmutableIdentifyProperties && 
/* 116 */       equalTo(0, (ImmutableIdentifyProperties)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableIdentifyProperties another) {
/* 120 */     return (this.os.equals(another.os) && this.browser
/* 121 */       .equals(another.browser) && this.device
/* 122 */       .equals(another.device));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 131 */     int h = 5381;
/* 132 */     h += (h << 5) + this.os.hashCode();
/* 133 */     h += (h << 5) + this.browser.hashCode();
/* 134 */     h += (h << 5) + this.device.hashCode();
/* 135 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 144 */     return "IdentifyProperties{os=" + this.os + ", browser=" + this.browser + ", device=" + this.device + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "IdentifyProperties", generator = "Immutables")
/*     */   static final class Json
/*     */     implements IdentifyProperties
/*     */   {
/*     */     String os;
/*     */     
/*     */     String browser;
/*     */     
/*     */     String device;
/*     */ 
/*     */     
/*     */     @JsonProperty("os")
/*     */     public void setOs(String os) {
/* 165 */       this.os = os;
/*     */     }
/*     */     @JsonProperty("browser")
/*     */     public void setBrowser(String browser) {
/* 169 */       this.browser = browser;
/*     */     }
/*     */     @JsonProperty("device")
/*     */     public void setDevice(String device) {
/* 173 */       this.device = device;
/*     */     }
/*     */     public String os() {
/* 176 */       throw new UnsupportedOperationException();
/*     */     } public String browser() {
/* 178 */       throw new UnsupportedOperationException();
/*     */     } public String device() {
/* 180 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableIdentifyProperties fromJson(Json json) {
/* 191 */     Builder builder = builder();
/* 192 */     if (json.os != null) {
/* 193 */       builder.os(json.os);
/*     */     }
/* 195 */     if (json.browser != null) {
/* 196 */       builder.browser(json.browser);
/*     */     }
/* 198 */     if (json.device != null) {
/* 199 */       builder.device(json.device);
/*     */     }
/* 201 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableIdentifyProperties of(String os, String browser, String device) {
/* 212 */     return new ImmutableIdentifyProperties(os, browser, device);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableIdentifyProperties copyOf(IdentifyProperties instance) {
/* 223 */     if (instance instanceof ImmutableIdentifyProperties) {
/* 224 */       return (ImmutableIdentifyProperties)instance;
/*     */     }
/* 226 */     return builder()
/* 227 */       .from(instance)
/* 228 */       .build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 243 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "IdentifyProperties", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_OS = 1L;
/*     */ 
/*     */     
/*     */     private static final long INIT_BIT_BROWSER = 2L;
/*     */     
/*     */     private static final long INIT_BIT_DEVICE = 4L;
/*     */     
/* 258 */     private long initBits = 7L;
/*     */ 
/*     */ 
/*     */     
/*     */     private String os;
/*     */ 
/*     */ 
/*     */     
/*     */     private String browser;
/*     */ 
/*     */ 
/*     */     
/*     */     private String device;
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(IdentifyProperties instance) {
/* 275 */       Objects.requireNonNull(instance, "instance");
/* 276 */       os(instance.os());
/* 277 */       browser(instance.browser());
/* 278 */       device(instance.device());
/* 279 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("os")
/*     */     public final Builder os(String os) {
/* 289 */       this.os = Objects.<String>requireNonNull(os, "os");
/* 290 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 291 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("browser")
/*     */     public final Builder browser(String browser) {
/* 301 */       this.browser = Objects.<String>requireNonNull(browser, "browser");
/* 302 */       this.initBits &= 0xFFFFFFFFFFFFFFFDL;
/* 303 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("device")
/*     */     public final Builder device(String device) {
/* 313 */       this.device = Objects.<String>requireNonNull(device, "device");
/* 314 */       this.initBits &= 0xFFFFFFFFFFFFFFFBL;
/* 315 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableIdentifyProperties build() {
/* 324 */       if (this.initBits != 0L) {
/* 325 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 327 */       return new ImmutableIdentifyProperties(null, this.os, this.browser, this.device);
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 331 */       List<String> attributes = new ArrayList<>();
/* 332 */       if ((this.initBits & 0x1L) != 0L) attributes.add("os"); 
/* 333 */       if ((this.initBits & 0x2L) != 0L) attributes.add("browser"); 
/* 334 */       if ((this.initBits & 0x4L) != 0L) attributes.add("device"); 
/* 335 */       return "Cannot build IdentifyProperties, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\gateway\ImmutableIdentifyProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */