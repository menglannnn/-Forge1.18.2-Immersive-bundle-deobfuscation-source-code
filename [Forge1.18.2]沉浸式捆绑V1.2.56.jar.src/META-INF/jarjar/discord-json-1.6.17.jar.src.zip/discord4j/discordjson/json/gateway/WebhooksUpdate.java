/*    */ package discord4j.discordjson.json.gateway;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonProperty;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import discord4j.discordjson.Id;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ @JsonSerialize(as = ImmutableWebhooksUpdate.class)
/*    */ @JsonDeserialize(as = ImmutableWebhooksUpdate.class)
/*    */ @Immutable
/*    */ public interface WebhooksUpdate
/*    */   extends Dispatch {
/*    */   static ImmutableWebhooksUpdate.Builder builder() {
/* 15 */     return ImmutableWebhooksUpdate.builder();
/*    */   }
/*    */   
/*    */   @JsonProperty("guild_id")
/*    */   Id guildId();
/*    */   
/*    */   @JsonProperty("channel_id")
/*    */   Id channelId();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\gateway\WebhooksUpdate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */