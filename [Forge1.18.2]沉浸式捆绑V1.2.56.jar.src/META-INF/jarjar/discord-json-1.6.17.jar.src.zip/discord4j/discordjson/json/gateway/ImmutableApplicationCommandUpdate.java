/*     */ package discord4j.discordjson.json.gateway;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.annotation.JsonUnwrapped;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.Id;
/*     */ import discord4j.discordjson.json.ApplicationCommandData;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "ApplicationCommandUpdate", generator = "Immutables")
/*     */ public final class ImmutableApplicationCommandUpdate
/*     */   implements ApplicationCommandUpdate
/*     */ {
/*     */   private final long guildId_value;
/*     */   private final ApplicationCommandData command;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   
/*     */   private ImmutableApplicationCommandUpdate(Id guildId, ApplicationCommandData command) {
/*  32 */     Id guildId$impl = guildId;
/*  33 */     this.command = Objects.<ApplicationCommandData>requireNonNull(command, "command");
/*  34 */     this.guildId_value = guildId$impl.asLong();
/*  35 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ImmutableApplicationCommandUpdate(ImmutableApplicationCommandUpdate original, Id guildId, ApplicationCommandData command) {
/*  42 */     Id guildId$impl = guildId;
/*  43 */     this.command = command;
/*  44 */     this.guildId_value = guildId$impl.asLong();
/*  45 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  51 */   private volatile transient InitShim initShim = new InitShim();
/*     */   
/*     */   @Generated(from = "ApplicationCommandUpdate", generator = "Immutables")
/*     */   private final class InitShim {
/*     */     private String formatInitCycleMessage() {
/*  56 */       List<String> attributes = new ArrayList<>();
/*  57 */       return "Cannot build ApplicationCommandUpdate, attribute initializers form cycle " + attributes;
/*     */     }
/*     */ 
/*     */     
/*     */     private InitShim() {}
/*     */   }
/*     */ 
/*     */   
/*     */   @JsonProperty("guild_id")
/*     */   public Id guildId() {
/*  67 */     return Id.of(this.guildId_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("command")
/*     */   @JsonUnwrapped
/*     */   public ApplicationCommandData command() {
/*  77 */     return this.command;
/*     */   }
/*     */   
/*     */   public ImmutableApplicationCommandUpdate withGuildId(long value) {
/*  81 */     Id newValue = Id.of(value);
/*  82 */     return new ImmutableApplicationCommandUpdate(this, newValue, this.command);
/*     */   }
/*     */   
/*     */   public ImmutableApplicationCommandUpdate withGuildId(String value) {
/*  86 */     Id newValue = Id.of(value);
/*  87 */     return new ImmutableApplicationCommandUpdate(this, newValue, this.command);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableApplicationCommandUpdate withCommand(ApplicationCommandData value) {
/*  97 */     if (this.command == value) return this; 
/*  98 */     ApplicationCommandData newValue = Objects.<ApplicationCommandData>requireNonNull(value, "command");
/*  99 */     return new ImmutableApplicationCommandUpdate(this, guildId(), newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 108 */     if (this == another) return true; 
/* 109 */     return (another instanceof ImmutableApplicationCommandUpdate && 
/* 110 */       equalTo(0, (ImmutableApplicationCommandUpdate)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableApplicationCommandUpdate another) {
/* 114 */     return (Objects.equals(Long.valueOf(this.guildId_value), Long.valueOf(another.guildId_value)) && this.command
/* 115 */       .equals(another.command));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 124 */     int h = 5381;
/* 125 */     h += (h << 5) + Objects.hashCode(Long.valueOf(this.guildId_value));
/* 126 */     h += (h << 5) + this.command.hashCode();
/* 127 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 136 */     return "ApplicationCommandUpdate{guildId=" + 
/* 137 */       Objects.toString(Long.valueOf(this.guildId_value)) + ", command=" + this.command + "}";
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "ApplicationCommandUpdate", generator = "Immutables")
/*     */   static final class Json
/*     */     implements ApplicationCommandUpdate
/*     */   {
/*     */     Id guildId;
/*     */     
/*     */     ApplicationCommandData command;
/*     */ 
/*     */     
/*     */     @JsonProperty("guild_id")
/*     */     public void setGuildId(Id guildId) {
/* 155 */       this.guildId = guildId;
/*     */     }
/*     */     @JsonProperty("command")
/*     */     @JsonUnwrapped
/*     */     public void setCommand(ApplicationCommandData command) {
/* 160 */       this.command = command;
/*     */     }
/*     */     public Id guildId() {
/* 163 */       throw new UnsupportedOperationException();
/*     */     } public ApplicationCommandData command() {
/* 165 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableApplicationCommandUpdate fromJson(Json json) {
/* 176 */     Builder builder = builder();
/* 177 */     if (json.guildId != null) {
/* 178 */       builder.guildId(json.guildId);
/*     */     }
/* 180 */     if (json.command != null) {
/* 181 */       builder.command(json.command);
/*     */     }
/* 183 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableApplicationCommandUpdate of(Id guildId, ApplicationCommandData command) {
/* 193 */     return new ImmutableApplicationCommandUpdate(guildId, command);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableApplicationCommandUpdate copyOf(ApplicationCommandUpdate instance) {
/* 204 */     if (instance instanceof ImmutableApplicationCommandUpdate) {
/* 205 */       return (ImmutableApplicationCommandUpdate)instance;
/*     */     }
/* 207 */     return builder()
/* 208 */       .from(instance)
/* 209 */       .build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 223 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "ApplicationCommandUpdate", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_COMMAND = 1L;
/*     */ 
/*     */ 
/*     */     
/* 236 */     private long initBits = 1L;
/*     */     
/* 238 */     private Id guildId_id = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private ApplicationCommandData command;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(ApplicationCommandUpdate instance) {
/* 252 */       Objects.requireNonNull(instance, "instance");
/* 253 */       guildId(instance.guildId());
/* 254 */       command(instance.command());
/* 255 */       return this;
/*     */     }
/*     */     
/*     */     public Builder guildId(String value) {
/* 259 */       this.guildId_id = Id.of(value);
/* 260 */       return this;
/*     */     }
/*     */     
/*     */     public Builder guildId(long value) {
/* 264 */       this.guildId_id = Id.of(value);
/* 265 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("guild_id")
/*     */     public Builder guildId(Id value) {
/* 270 */       this.guildId_id = value;
/* 271 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("command")
/*     */     @JsonUnwrapped
/*     */     public final Builder command(ApplicationCommandData command) {
/* 282 */       this.command = Objects.<ApplicationCommandData>requireNonNull(command, "command");
/* 283 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 284 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableApplicationCommandUpdate build() {
/* 293 */       if (this.initBits != 0L) {
/* 294 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 296 */       return new ImmutableApplicationCommandUpdate(null, guildId_build(), this.command);
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 300 */       List<String> attributes = new ArrayList<>();
/* 301 */       if ((this.initBits & 0x1L) != 0L) attributes.add("command"); 
/* 302 */       return "Cannot build ApplicationCommandUpdate, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Id guildId_build() {
/* 306 */       return this.guildId_id;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\gateway\ImmutableApplicationCommandUpdate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */