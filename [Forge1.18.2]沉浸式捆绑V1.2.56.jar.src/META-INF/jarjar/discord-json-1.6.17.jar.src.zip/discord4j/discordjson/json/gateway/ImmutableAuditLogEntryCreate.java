/*      */ package discord4j.discordjson.json.gateway;
/*      */ 
/*      */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*      */ import com.fasterxml.jackson.annotation.JsonCreator;
/*      */ import com.fasterxml.jackson.annotation.JsonProperty;
/*      */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*      */ import discord4j.discordjson.Id;
/*      */ import discord4j.discordjson.json.AuditEntryInfoData;
/*      */ import discord4j.discordjson.json.AuditLogChangeData;
/*      */ import discord4j.discordjson.json.AuditLogEntryData;
/*      */ import discord4j.discordjson.possible.Possible;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.List;
/*      */ import java.util.Objects;
/*      */ import java.util.Optional;
/*      */ import java.util.stream.Collectors;
/*      */ import java.util.stream.StreamSupport;
/*      */ import org.immutables.value.Generated;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ @Generated(from = "AuditLogEntryCreate", generator = "Immutables")
/*      */ public final class ImmutableAuditLogEntryCreate
/*      */   implements AuditLogEntryCreate
/*      */ {
/*      */   private final String targetId;
/*      */   private final List<AuditLogChangeData> changes_value;
/*      */   private final boolean changes_absent;
/*      */   private final long userId_value;
/*      */   private final boolean userId_present;
/*      */   private final long id_value;
/*      */   private final int actionType;
/*      */   private final AuditEntryInfoData options_value;
/*      */   private final boolean options_absent;
/*      */   private final String reason_value;
/*      */   private final boolean reason_absent;
/*      */   private final long guildId_value;
/*      */   private static final byte STAGE_INITIALIZING = -1;
/*      */   private static final byte STAGE_UNINITIALIZED = 0;
/*      */   private static final byte STAGE_INITIALIZED = 1;
/*      */   private volatile transient InitShim initShim;
/*      */   
/*      */   private ImmutableAuditLogEntryCreate(Optional<String> targetId, Possible<List<AuditLogChangeData>> changes, Optional<Id> userId, Id id, int actionType, Possible<AuditEntryInfoData> options, Possible<String> reason, Id guildId) {
/*  115 */     this.initShim = new InitShim(); this.targetId = targetId.orElse(null); Possible<List<AuditLogChangeData>> changes$impl = changes; Optional<Id> userId$impl = userId; Id id$impl = id; this.actionType = actionType; Possible<AuditEntryInfoData> options$impl = options; Possible<String> reason$impl = reason; Id guildId$impl = guildId; this.changes_value = changes$impl.toOptional().orElse(null); this.changes_absent = changes$impl.isAbsent(); this.userId_value = ((Long)userId$impl.<Long>map(Id::asLong).orElse(Long.valueOf(0L))).longValue(); this.userId_present = userId$impl.isPresent(); this.id_value = id$impl.asLong(); this.options_value = options$impl.toOptional().orElse(null); this.options_absent = options$impl.isAbsent(); this.reason_value = reason$impl.toOptional().orElse(null); this.reason_absent = reason$impl.isAbsent(); this.guildId_value = guildId$impl.asLong(); this.initShim = null; } private ImmutableAuditLogEntryCreate(ImmutableAuditLogEntryCreate original, String targetId, Possible<List<AuditLogChangeData>> changes, Optional<Id> userId, Id id, int actionType, Possible<AuditEntryInfoData> options, Possible<String> reason, Id guildId) { this.initShim = new InitShim(); this.targetId = targetId; Possible<List<AuditLogChangeData>> changes$impl = changes; Optional<Id> userId$impl = userId; Id id$impl = id; this.actionType = actionType; Possible<AuditEntryInfoData> options$impl = options; Possible<String> reason$impl = reason; Id guildId$impl = guildId; this.changes_value = changes$impl.toOptional().orElse(null); this.changes_absent = changes$impl.isAbsent(); this.userId_value = ((Long)userId$impl.<Long>map(Id::asLong).orElse(Long.valueOf(0L))).longValue(); this.userId_present = userId$impl.isPresent(); this.id_value = id$impl.asLong(); this.options_value = options$impl.toOptional().orElse(null);
/*      */     this.options_absent = options$impl.isAbsent();
/*      */     this.reason_value = reason$impl.toOptional().orElse(null);
/*      */     this.reason_absent = reason$impl.isAbsent();
/*      */     this.guildId_value = guildId$impl.asLong();
/*  120 */     this.initShim = null; } @Generated(from = "AuditLogEntryCreate", generator = "Immutables") private final class InitShim { private InitShim() {} private String formatInitCycleMessage() { List<String> attributes = new ArrayList<>();
/*  121 */       return "Cannot build AuditLogEntryCreate, attribute initializers form cycle " + attributes; }
/*      */      }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("target_id")
/*      */   public Optional<String> targetId() {
/*  131 */     return Optional.ofNullable(this.targetId);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("changes")
/*      */   public Possible<List<AuditLogChangeData>> changes() {
/*  140 */     return this.changes_absent ? Possible.absent() : 
/*  141 */       Possible.of(this.changes_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("user_id")
/*      */   public Optional<Id> userId() {
/*  150 */     return this.userId_present ? Optional.<Id>of(Id.of(this.userId_value)) : Optional.<Id>empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("id")
/*      */   public Id id() {
/*  159 */     return Id.of(this.id_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("action_type")
/*      */   public int actionType() {
/*  168 */     return this.actionType;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("options")
/*      */   public Possible<AuditEntryInfoData> options() {
/*  177 */     return this.options_absent ? Possible.absent() : Possible.of(this.options_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("reason")
/*      */   public Possible<String> reason() {
/*  186 */     return this.reason_absent ? Possible.absent() : Possible.of(this.reason_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("guild_id")
/*      */   public Id guildId() {
/*  195 */     return Id.of(this.guildId_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableAuditLogEntryCreate withTargetId(String value) {
/*  204 */     String newValue = Objects.<String>requireNonNull(value, "targetId");
/*  205 */     if (Objects.equals(this.targetId, newValue)) return this; 
/*  206 */     return new ImmutableAuditLogEntryCreate(this, newValue, 
/*      */ 
/*      */         
/*  209 */         changes(), 
/*  210 */         userId(), 
/*  211 */         id(), this.actionType, 
/*      */         
/*  213 */         options(), 
/*  214 */         reason(), 
/*  215 */         guildId());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableAuditLogEntryCreate withTargetId(Optional<String> optional) {
/*  225 */     String value = optional.orElse(null);
/*  226 */     if (Objects.equals(this.targetId, value)) return this; 
/*  227 */     return new ImmutableAuditLogEntryCreate(this, value, 
/*      */ 
/*      */         
/*  230 */         changes(), 
/*  231 */         userId(), 
/*  232 */         id(), this.actionType, 
/*      */         
/*  234 */         options(), 
/*  235 */         reason(), 
/*  236 */         guildId());
/*      */   }
/*      */   
/*      */   public ImmutableAuditLogEntryCreate withChanges(Possible<List<AuditLogChangeData>> possible) {
/*  240 */     Possible<List<AuditLogChangeData>> newValue = Objects.<Possible<List<AuditLogChangeData>>>requireNonNull(possible);
/*  241 */     return new ImmutableAuditLogEntryCreate(this, this.targetId, newValue, 
/*      */ 
/*      */ 
/*      */         
/*  245 */         userId(), 
/*  246 */         id(), this.actionType, 
/*      */         
/*  248 */         options(), 
/*  249 */         reason(), 
/*  250 */         guildId());
/*      */   }
/*      */   
/*      */   public ImmutableAuditLogEntryCreate withChanges(Iterable<AuditLogChangeData> elements) {
/*  254 */     Possible<List<AuditLogChangeData>> newValue = Possible.of(
/*  255 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/*  256 */     return new ImmutableAuditLogEntryCreate(this, this.targetId, newValue, 
/*      */ 
/*      */ 
/*      */         
/*  260 */         userId(), 
/*  261 */         id(), this.actionType, 
/*      */         
/*  263 */         options(), 
/*  264 */         reason(), 
/*  265 */         guildId());
/*      */   }
/*      */   
/*      */   @SafeVarargs
/*      */   public final ImmutableAuditLogEntryCreate withChanges(AuditLogChangeData... elements) {
/*  270 */     Possible<List<AuditLogChangeData>> newValue = Possible.of(Arrays.asList(elements));
/*  271 */     return new ImmutableAuditLogEntryCreate(this, this.targetId, newValue, 
/*      */ 
/*      */ 
/*      */         
/*  275 */         userId(), 
/*  276 */         id(), this.actionType, 
/*      */         
/*  278 */         options(), 
/*  279 */         reason(), 
/*  280 */         guildId());
/*      */   }
/*      */   
/*      */   public ImmutableAuditLogEntryCreate withUserId(Optional<Id> value) {
/*  284 */     Optional<Id> newValue = Objects.<Optional<Id>>requireNonNull(value);
/*  285 */     return new ImmutableAuditLogEntryCreate(this, this.targetId, 
/*      */ 
/*      */         
/*  288 */         changes(), newValue, 
/*      */         
/*  290 */         id(), this.actionType, 
/*      */         
/*  292 */         options(), 
/*  293 */         reason(), 
/*  294 */         guildId());
/*      */   }
/*      */   
/*      */   public ImmutableAuditLogEntryCreate withUserId(long value) {
/*  298 */     Optional<Id> newValue = Optional.of(Id.of(value));
/*  299 */     return new ImmutableAuditLogEntryCreate(this, this.targetId, 
/*      */ 
/*      */         
/*  302 */         changes(), newValue, 
/*      */         
/*  304 */         id(), this.actionType, 
/*      */         
/*  306 */         options(), 
/*  307 */         reason(), 
/*  308 */         guildId());
/*      */   }
/*      */   
/*      */   public ImmutableAuditLogEntryCreate withId(long value) {
/*  312 */     Id newValue = Id.of(value);
/*  313 */     return new ImmutableAuditLogEntryCreate(this, this.targetId, 
/*      */ 
/*      */         
/*  316 */         changes(), 
/*  317 */         userId(), newValue, this.actionType, 
/*      */ 
/*      */         
/*  320 */         options(), 
/*  321 */         reason(), 
/*  322 */         guildId());
/*      */   }
/*      */   
/*      */   public ImmutableAuditLogEntryCreate withId(String value) {
/*  326 */     Id newValue = Id.of(value);
/*  327 */     return new ImmutableAuditLogEntryCreate(this, this.targetId, 
/*      */ 
/*      */         
/*  330 */         changes(), 
/*  331 */         userId(), newValue, this.actionType, 
/*      */ 
/*      */         
/*  334 */         options(), 
/*  335 */         reason(), 
/*  336 */         guildId());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableAuditLogEntryCreate withActionType(int value) {
/*  346 */     if (this.actionType == value) return this; 
/*  347 */     return new ImmutableAuditLogEntryCreate(this, this.targetId, 
/*      */ 
/*      */         
/*  350 */         changes(), 
/*  351 */         userId(), 
/*  352 */         id(), value, 
/*      */         
/*  354 */         options(), 
/*  355 */         reason(), 
/*  356 */         guildId());
/*      */   }
/*      */   
/*      */   public ImmutableAuditLogEntryCreate withOptions(Possible<AuditEntryInfoData> value) {
/*  360 */     Possible<AuditEntryInfoData> newValue = Objects.<Possible<AuditEntryInfoData>>requireNonNull(value);
/*  361 */     return new ImmutableAuditLogEntryCreate(this, this.targetId, 
/*      */ 
/*      */         
/*  364 */         changes(), 
/*  365 */         userId(), 
/*  366 */         id(), this.actionType, newValue, 
/*      */ 
/*      */         
/*  369 */         reason(), 
/*  370 */         guildId());
/*      */   }
/*      */   
/*      */   public ImmutableAuditLogEntryCreate withOptions(AuditEntryInfoData value) {
/*  374 */     Possible<AuditEntryInfoData> newValue = Possible.of(value);
/*  375 */     return new ImmutableAuditLogEntryCreate(this, this.targetId, 
/*      */ 
/*      */         
/*  378 */         changes(), 
/*  379 */         userId(), 
/*  380 */         id(), this.actionType, newValue, 
/*      */ 
/*      */         
/*  383 */         reason(), 
/*  384 */         guildId());
/*      */   }
/*      */   
/*      */   public ImmutableAuditLogEntryCreate withReason(Possible<String> value) {
/*  388 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/*  389 */     return new ImmutableAuditLogEntryCreate(this, this.targetId, 
/*      */ 
/*      */         
/*  392 */         changes(), 
/*  393 */         userId(), 
/*  394 */         id(), this.actionType, 
/*      */         
/*  396 */         options(), newValue, 
/*      */         
/*  398 */         guildId());
/*      */   }
/*      */   
/*      */   public ImmutableAuditLogEntryCreate withReason(String value) {
/*  402 */     Possible<String> newValue = Possible.of(value);
/*  403 */     return new ImmutableAuditLogEntryCreate(this, this.targetId, 
/*      */ 
/*      */         
/*  406 */         changes(), 
/*  407 */         userId(), 
/*  408 */         id(), this.actionType, 
/*      */         
/*  410 */         options(), newValue, 
/*      */         
/*  412 */         guildId());
/*      */   }
/*      */   
/*      */   public ImmutableAuditLogEntryCreate withGuildId(long value) {
/*  416 */     Id newValue = Id.of(value);
/*  417 */     return new ImmutableAuditLogEntryCreate(this, this.targetId, 
/*      */ 
/*      */         
/*  420 */         changes(), 
/*  421 */         userId(), 
/*  422 */         id(), this.actionType, 
/*      */         
/*  424 */         options(), 
/*  425 */         reason(), newValue);
/*      */   }
/*      */ 
/*      */   
/*      */   public ImmutableAuditLogEntryCreate withGuildId(String value) {
/*  430 */     Id newValue = Id.of(value);
/*  431 */     return new ImmutableAuditLogEntryCreate(this, this.targetId, 
/*      */ 
/*      */         
/*  434 */         changes(), 
/*  435 */         userId(), 
/*  436 */         id(), this.actionType, 
/*      */         
/*  438 */         options(), 
/*  439 */         reason(), newValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean equals(Object another) {
/*  449 */     if (this == another) return true; 
/*  450 */     return (another instanceof ImmutableAuditLogEntryCreate && 
/*  451 */       equalTo(0, (ImmutableAuditLogEntryCreate)another));
/*      */   }
/*      */   
/*      */   private boolean equalTo(int synthetic, ImmutableAuditLogEntryCreate another) {
/*  455 */     return (Objects.equals(this.targetId, another.targetId) && 
/*  456 */       Objects.equals(this.changes_value, another.changes_value) && 
/*  457 */       userId().equals(another.userId()) && 
/*  458 */       Objects.equals(Long.valueOf(this.id_value), Long.valueOf(another.id_value)) && this.actionType == another.actionType && 
/*      */       
/*  460 */       options().equals(another.options()) && 
/*  461 */       reason().equals(another.reason()) && 
/*  462 */       Objects.equals(Long.valueOf(this.guildId_value), Long.valueOf(another.guildId_value)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int hashCode() {
/*  471 */     int h = 5381;
/*  472 */     h += (h << 5) + Objects.hashCode(this.targetId);
/*  473 */     h += (h << 5) + Objects.hashCode(this.changes_value);
/*  474 */     h += (h << 5) + userId().hashCode();
/*  475 */     h += (h << 5) + Objects.hashCode(Long.valueOf(this.id_value));
/*  476 */     h += (h << 5) + this.actionType;
/*  477 */     h += (h << 5) + options().hashCode();
/*  478 */     h += (h << 5) + reason().hashCode();
/*  479 */     h += (h << 5) + Objects.hashCode(Long.valueOf(this.guildId_value));
/*  480 */     return h;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/*  489 */     StringBuilder builder = new StringBuilder("AuditLogEntryCreate{");
/*  490 */     if (this.targetId != null) {
/*  491 */       builder.append("targetId=").append(this.targetId);
/*      */     }
/*  493 */     if (builder.length() > 20) builder.append(", "); 
/*  494 */     builder.append("changes=").append(Objects.toString(this.changes_value));
/*  495 */     builder.append(", ");
/*  496 */     builder.append("userId=").append(userId().toString());
/*  497 */     builder.append(", ");
/*  498 */     builder.append("id=").append(Objects.toString(Long.valueOf(this.id_value)));
/*  499 */     builder.append(", ");
/*  500 */     builder.append("actionType=").append(this.actionType);
/*  501 */     builder.append(", ");
/*  502 */     builder.append("options=").append(options().toString());
/*  503 */     builder.append(", ");
/*  504 */     builder.append("reason=").append(reason().toString());
/*  505 */     builder.append(", ");
/*  506 */     builder.append("guildId=").append(Objects.toString(Long.valueOf(this.guildId_value)));
/*  507 */     return builder.append("}").toString();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonDeserialize
/*      */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*      */   @Generated(from = "AuditLogEntryCreate", generator = "Immutables")
/*      */   static final class Json
/*      */     implements AuditLogEntryCreate
/*      */   {
/*  519 */     Optional<String> targetId = Optional.empty();
/*      */     
/*  521 */     Possible<List<AuditLogChangeData>> changes = Possible.absent();
/*      */ 
/*      */     
/*  524 */     Optional<Id> userId = Optional.empty();
/*      */     
/*      */     Id id;
/*      */     
/*      */     int actionType;
/*      */     boolean actionTypeIsSet;
/*  530 */     Possible<AuditEntryInfoData> options = Possible.absent();
/*      */ 
/*      */     
/*  533 */     Possible<String> reason = Possible.absent();
/*      */     Id guildId;
/*      */     
/*      */     @JsonProperty("target_id")
/*      */     public void setTargetId(Optional<String> targetId) {
/*  538 */       this.targetId = targetId;
/*      */     }
/*      */     @JsonProperty("changes")
/*      */     public void setChanges(Possible<List<AuditLogChangeData>> changes) {
/*  542 */       this.changes = changes;
/*      */     }
/*      */     @JsonProperty("user_id")
/*      */     public void setUserId(Optional<Id> userId) {
/*  546 */       this.userId = userId;
/*      */     }
/*      */     @JsonProperty("id")
/*      */     public void setId(Id id) {
/*  550 */       this.id = id;
/*      */     }
/*      */     @JsonProperty("action_type")
/*      */     public void setActionType(int actionType) {
/*  554 */       this.actionType = actionType;
/*  555 */       this.actionTypeIsSet = true;
/*      */     }
/*      */     @JsonProperty("options")
/*      */     public void setOptions(Possible<AuditEntryInfoData> options) {
/*  559 */       this.options = options;
/*      */     }
/*      */     @JsonProperty("reason")
/*      */     public void setReason(Possible<String> reason) {
/*  563 */       this.reason = reason;
/*      */     }
/*      */     @JsonProperty("guild_id")
/*      */     public void setGuildId(Id guildId) {
/*  567 */       this.guildId = guildId;
/*      */     }
/*      */     public Optional<String> targetId() {
/*  570 */       throw new UnsupportedOperationException();
/*      */     } public Possible<List<AuditLogChangeData>> changes() {
/*  572 */       throw new UnsupportedOperationException();
/*      */     } public Optional<Id> userId() {
/*  574 */       throw new UnsupportedOperationException();
/*      */     } public Id id() {
/*  576 */       throw new UnsupportedOperationException();
/*      */     } public int actionType() {
/*  578 */       throw new UnsupportedOperationException();
/*      */     } public Possible<AuditEntryInfoData> options() {
/*  580 */       throw new UnsupportedOperationException();
/*      */     } public Possible<String> reason() {
/*  582 */       throw new UnsupportedOperationException();
/*      */     } public Id guildId() {
/*  584 */       throw new UnsupportedOperationException();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*      */   static ImmutableAuditLogEntryCreate fromJson(Json json) {
/*  595 */     Builder builder = builder();
/*  596 */     if (json.targetId != null) {
/*  597 */       builder.targetId(json.targetId);
/*      */     }
/*  599 */     if (json.changes != null) {
/*  600 */       builder.changes(json.changes);
/*      */     }
/*  602 */     if (json.userId != null) {
/*  603 */       builder.userId(json.userId);
/*      */     }
/*  605 */     if (json.id != null) {
/*  606 */       builder.id(json.id);
/*      */     }
/*  608 */     if (json.actionTypeIsSet) {
/*  609 */       builder.actionType(json.actionType);
/*      */     }
/*  611 */     if (json.options != null) {
/*  612 */       builder.options(json.options);
/*      */     }
/*  614 */     if (json.reason != null) {
/*  615 */       builder.reason(json.reason);
/*      */     }
/*  617 */     if (json.guildId != null) {
/*  618 */       builder.guildId(json.guildId);
/*      */     }
/*  620 */     return builder.build();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableAuditLogEntryCreate of(Optional<String> targetId, Possible<List<AuditLogChangeData>> changes, Optional<Id> userId, Id id, int actionType, Possible<AuditEntryInfoData> options, Possible<String> reason, Id guildId) {
/*  636 */     return new ImmutableAuditLogEntryCreate(targetId, changes, userId, id, actionType, options, reason, guildId);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableAuditLogEntryCreate copyOf(AuditLogEntryCreate instance) {
/*  647 */     if (instance instanceof ImmutableAuditLogEntryCreate) {
/*  648 */       return (ImmutableAuditLogEntryCreate)instance;
/*      */     }
/*  650 */     return builder()
/*  651 */       .from(instance)
/*  652 */       .build();
/*      */   }
/*      */   
/*      */   public boolean isChangesPresent() {
/*  656 */     return !this.changes_absent;
/*      */   }
/*      */   
/*      */   public List<AuditLogChangeData> changesOrElse(List<AuditLogChangeData> defaultValue) {
/*  660 */     return !this.changes_absent ? this.changes_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isUserIdPresent() {
/*  664 */     return this.userId_present;
/*      */   }
/*      */   
/*      */   public long userIdOrElse(long defaultValue) {
/*  668 */     return this.userId_present ? this.userId_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isOptionsPresent() {
/*  672 */     return !this.options_absent;
/*      */   }
/*      */   
/*      */   public AuditEntryInfoData optionsOrElse(AuditEntryInfoData defaultValue) {
/*  676 */     return !this.options_absent ? this.options_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isReasonPresent() {
/*  680 */     return !this.reason_absent;
/*      */   }
/*      */   
/*      */   public String reasonOrElse(String defaultValue) {
/*  684 */     return !this.reason_absent ? this.reason_value : defaultValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Builder builder() {
/*  704 */     return new Builder();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Generated(from = "AuditLogEntryCreate", generator = "Immutables")
/*      */   public static final class Builder
/*      */   {
/*      */     private static final long INIT_BIT_ACTION_TYPE = 1L;
/*      */ 
/*      */ 
/*      */     
/*  717 */     private long initBits = 1L;
/*      */     
/*  719 */     private List<AuditLogChangeData> changes_list = null;
/*  720 */     private Optional<Id> userId_optional = Optional.empty();
/*  721 */     private Id id_id = null;
/*  722 */     private Possible<AuditEntryInfoData> options_possible = Possible.absent();
/*  723 */     private Possible<String> reason_possible = Possible.absent();
/*  724 */     private Id guildId_id = null;
/*      */ 
/*      */ 
/*      */     
/*      */     private String targetId;
/*      */ 
/*      */ 
/*      */     
/*      */     private int actionType;
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder from(AuditLogEntryCreate instance) {
/*  737 */       Objects.requireNonNull(instance, "instance");
/*  738 */       from(instance);
/*  739 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder from(AuditLogEntryData instance) {
/*  748 */       Objects.requireNonNull(instance, "instance");
/*  749 */       from(instance);
/*  750 */       return this;
/*      */     }
/*      */     
/*      */     private void from(Object object) {
/*  754 */       long bits = 0L;
/*  755 */       if (object instanceof AuditLogEntryCreate) {
/*  756 */         AuditLogEntryCreate instance = (AuditLogEntryCreate)object;
/*  757 */         if ((bits & 0x1L) == 0L) {
/*  758 */           actionType(instance.actionType());
/*  759 */           bits |= 0x1L;
/*      */         } 
/*  761 */         if ((bits & 0x2L) == 0L) {
/*  762 */           reason(instance.reason());
/*  763 */           bits |= 0x2L;
/*      */         } 
/*  765 */         if ((bits & 0x4L) == 0L) {
/*  766 */           Optional<String> targetIdOptional = instance.targetId();
/*  767 */           if (targetIdOptional.isPresent()) {
/*  768 */             targetId(targetIdOptional);
/*      */           }
/*  770 */           bits |= 0x4L;
/*      */         } 
/*  772 */         if ((bits & 0x8L) == 0L) {
/*  773 */           changes(instance.changes());
/*  774 */           bits |= 0x8L;
/*      */         } 
/*  776 */         if ((bits & 0x10L) == 0L) {
/*  777 */           options(instance.options());
/*  778 */           bits |= 0x10L;
/*      */         } 
/*  780 */         if ((bits & 0x20L) == 0L) {
/*  781 */           id(instance.id());
/*  782 */           bits |= 0x20L;
/*      */         } 
/*  784 */         if ((bits & 0x40L) == 0L) {
/*  785 */           userId(instance.userId());
/*  786 */           bits |= 0x40L;
/*      */         } 
/*  788 */         guildId(instance.guildId());
/*      */       } 
/*  790 */       if (object instanceof AuditLogEntryData) {
/*  791 */         AuditLogEntryData instance = (AuditLogEntryData)object;
/*  792 */         if ((bits & 0x1L) == 0L) {
/*  793 */           actionType(instance.actionType());
/*  794 */           bits |= 0x1L;
/*      */         } 
/*  796 */         if ((bits & 0x2L) == 0L) {
/*  797 */           reason(instance.reason());
/*  798 */           bits |= 0x2L;
/*      */         } 
/*  800 */         if ((bits & 0x4L) == 0L) {
/*  801 */           Optional<String> targetIdOptional = instance.targetId();
/*  802 */           if (targetIdOptional.isPresent()) {
/*  803 */             targetId(targetIdOptional);
/*      */           }
/*  805 */           bits |= 0x4L;
/*      */         } 
/*  807 */         if ((bits & 0x8L) == 0L) {
/*  808 */           changes(instance.changes());
/*  809 */           bits |= 0x8L;
/*      */         } 
/*  811 */         if ((bits & 0x10L) == 0L) {
/*  812 */           options(instance.options());
/*  813 */           bits |= 0x10L;
/*      */         } 
/*  815 */         if ((bits & 0x20L) == 0L) {
/*  816 */           id(instance.id());
/*  817 */           bits |= 0x20L;
/*      */         } 
/*  819 */         if ((bits & 0x40L) == 0L) {
/*  820 */           userId(instance.userId());
/*  821 */           bits |= 0x40L;
/*      */         } 
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder targetId(String targetId) {
/*  832 */       this.targetId = Objects.<String>requireNonNull(targetId, "targetId");
/*  833 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("target_id")
/*      */     public final Builder targetId(Optional<String> targetId) {
/*  843 */       this.targetId = targetId.orElse(null);
/*  844 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addChange(AuditLogChangeData element) {
/*  848 */       changes_getOrCreate().add(element);
/*  849 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addAllChanges(List<AuditLogChangeData> elements) {
/*  853 */       changes_getOrCreate().addAll(elements);
/*  854 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("changes")
/*      */     public Builder changes(Possible<List<AuditLogChangeData>> elements) {
/*  859 */       this.changes_list = null;
/*  860 */       elements.toOptional().ifPresent(e -> changes_getOrCreate().addAll(e));
/*  861 */       return this;
/*      */     }
/*      */     
/*      */     public Builder changes(List<AuditLogChangeData> elements) {
/*  865 */       this.changes_list = new ArrayList<>(elements);
/*  866 */       return this;
/*      */     }
/*      */     
/*      */     public Builder changes(Iterable<AuditLogChangeData> elements) {
/*  870 */       this.changes_list = (List<AuditLogChangeData>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/*  871 */       return this;
/*      */     }
/*      */     
/*      */     public Builder userId(String value) {
/*  875 */       this.userId_optional = Optional.of(Id.of(value));
/*  876 */       return this;
/*      */     }
/*      */     
/*      */     public Builder userId(long value) {
/*  880 */       this.userId_optional = Optional.of(Id.of(value));
/*  881 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("user_id")
/*      */     public Builder userId(Optional<Id> value) {
/*  886 */       this.userId_optional = value;
/*  887 */       return this;
/*      */     }
/*      */     
/*      */     public Builder id(String value) {
/*  891 */       this.id_id = Id.of(value);
/*  892 */       return this;
/*      */     }
/*      */     
/*      */     public Builder id(long value) {
/*  896 */       this.id_id = Id.of(value);
/*  897 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("id")
/*      */     public Builder id(Id value) {
/*  902 */       this.id_id = value;
/*  903 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("action_type")
/*      */     public final Builder actionType(int actionType) {
/*  913 */       this.actionType = actionType;
/*  914 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/*  915 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("options")
/*      */     public Builder options(Possible<AuditEntryInfoData> value) {
/*  920 */       this.options_possible = value;
/*  921 */       return this;
/*      */     }
/*      */     
/*      */     public Builder options(AuditEntryInfoData value) {
/*  925 */       this.options_possible = Possible.of(value);
/*  926 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("reason")
/*      */     public Builder reason(Possible<String> value) {
/*  931 */       this.reason_possible = value;
/*  932 */       return this;
/*      */     }
/*      */     
/*      */     public Builder reason(String value) {
/*  936 */       this.reason_possible = Possible.of(value);
/*  937 */       return this;
/*      */     }
/*      */     
/*      */     public Builder guildId(String value) {
/*  941 */       this.guildId_id = Id.of(value);
/*  942 */       return this;
/*      */     }
/*      */     
/*      */     public Builder guildId(long value) {
/*  946 */       this.guildId_id = Id.of(value);
/*  947 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("guild_id")
/*      */     public Builder guildId(Id value) {
/*  952 */       this.guildId_id = value;
/*  953 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ImmutableAuditLogEntryCreate build() {
/*  962 */       if (this.initBits != 0L) {
/*  963 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*      */       }
/*  965 */       return new ImmutableAuditLogEntryCreate(null, this.targetId, 
/*      */ 
/*      */           
/*  968 */           changes_build(), 
/*  969 */           userId_build(), 
/*  970 */           id_build(), this.actionType, 
/*      */           
/*  972 */           options_build(), 
/*  973 */           reason_build(), 
/*  974 */           guildId_build());
/*      */     }
/*      */     
/*      */     private String formatRequiredAttributesMessage() {
/*  978 */       List<String> attributes = new ArrayList<>();
/*  979 */       if ((this.initBits & 0x1L) != 0L) attributes.add("actionType"); 
/*  980 */       return "Cannot build AuditLogEntryCreate, some of required attributes are not set " + attributes;
/*      */     }
/*      */     
/*      */     private Possible<List<AuditLogChangeData>> changes_build() {
/*  984 */       return (this.changes_list == null) ? Possible.absent() : 
/*  985 */         Possible.of(this.changes_list);
/*      */     }
/*      */     
/*      */     private List<AuditLogChangeData> changes_getOrCreate() {
/*  989 */       if (this.changes_list == null) {
/*  990 */         this.changes_list = new ArrayList<>();
/*      */       }
/*  992 */       return this.changes_list;
/*      */     }
/*      */     
/*      */     private Optional<Id> userId_build() {
/*  996 */       return this.userId_optional;
/*      */     }
/*      */     
/*      */     private Id id_build() {
/* 1000 */       return this.id_id;
/*      */     }
/*      */     
/*      */     private Possible<AuditEntryInfoData> options_build() {
/* 1004 */       return this.options_possible;
/*      */     }
/*      */     
/*      */     private Possible<String> reason_build() {
/* 1008 */       return this.reason_possible;
/*      */     }
/*      */     
/*      */     private Id guildId_build() {
/* 1012 */       return this.guildId_id;
/*      */     }
/*      */     
/*      */     private Builder() {}
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\gateway\ImmutableAuditLogEntryCreate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */