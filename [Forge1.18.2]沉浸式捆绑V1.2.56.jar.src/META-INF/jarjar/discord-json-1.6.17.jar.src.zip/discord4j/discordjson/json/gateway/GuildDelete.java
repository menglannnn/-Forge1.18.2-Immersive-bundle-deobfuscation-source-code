/*    */ package discord4j.discordjson.json.gateway;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonUnwrapped;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import discord4j.discordjson.json.UnavailableGuildData;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ @JsonSerialize(as = ImmutableGuildDelete.class)
/*    */ @JsonDeserialize(as = ImmutableGuildDelete.class)
/*    */ @Immutable
/*    */ public interface GuildDelete
/*    */   extends Dispatch {
/*    */   static ImmutableGuildDelete.Builder builder() {
/* 15 */     return ImmutableGuildDelete.builder();
/*    */   }
/*    */   
/*    */   @JsonUnwrapped
/*    */   UnavailableGuildData guild();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\gateway\GuildDelete.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */