/*     */ package discord4j.discordjson.json.gateway;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.stream.StreamSupport;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "RequestGuildMembers", generator = "Immutables")
/*     */ public final class ImmutableRequestGuildMembers
/*     */   implements RequestGuildMembers
/*     */ {
/*     */   private final String guildId;
/*     */   private final String query_value;
/*     */   private final boolean query_absent;
/*     */   private final int limit;
/*     */   private final Boolean presences_value;
/*     */   private final boolean presences_absent;
/*     */   private final List<String> userIds_value;
/*     */   private final boolean userIds_absent;
/*     */   private final String nonce_value;
/*     */   private final boolean nonce_absent;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   private volatile transient InitShim initShim;
/*     */   
/*     */   private ImmutableRequestGuildMembers(String guildId, Possible<String> query, int limit, Possible<Boolean> presences, Possible<List<String>> userIds, Possible<String> nonce) {
/*  92 */     this.initShim = new InitShim(); this.guildId = Objects.<String>requireNonNull(guildId, "guildId"); Possible<String> query$impl = query; this.limit = limit; Possible<Boolean> presences$impl = presences; Possible<List<String>> userIds$impl = userIds; Possible<String> nonce$impl = nonce; this.query_value = query$impl.toOptional().orElse(null); this.query_absent = query$impl.isAbsent(); this.presences_value = presences$impl.toOptional().orElse(null); this.presences_absent = presences$impl.isAbsent(); this.userIds_value = userIds$impl.toOptional().orElse(null); this.userIds_absent = userIds$impl.isAbsent(); this.nonce_value = nonce$impl.toOptional().orElse(null); this.nonce_absent = nonce$impl.isAbsent(); this.initShim = null; } private ImmutableRequestGuildMembers(ImmutableRequestGuildMembers original, String guildId, Possible<String> query, int limit, Possible<Boolean> presences, Possible<List<String>> userIds, Possible<String> nonce) { this.initShim = new InitShim(); this.guildId = guildId; Possible<String> query$impl = query; this.limit = limit; Possible<Boolean> presences$impl = presences; Possible<List<String>> userIds$impl = userIds; Possible<String> nonce$impl = nonce; this.query_value = query$impl.toOptional().orElse(null); this.query_absent = query$impl.isAbsent(); this.presences_value = presences$impl.toOptional().orElse(null); this.presences_absent = presences$impl.isAbsent();
/*     */     this.userIds_value = userIds$impl.toOptional().orElse(null);
/*     */     this.userIds_absent = userIds$impl.isAbsent();
/*     */     this.nonce_value = nonce$impl.toOptional().orElse(null);
/*     */     this.nonce_absent = nonce$impl.isAbsent();
/*  97 */     this.initShim = null; } @Generated(from = "RequestGuildMembers", generator = "Immutables") private final class InitShim { private InitShim() {} private String formatInitCycleMessage() { List<String> attributes = new ArrayList<>();
/*  98 */       return "Cannot build RequestGuildMembers, attribute initializers form cycle " + attributes; }
/*     */      }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("guild_id")
/*     */   public String guildId() {
/* 108 */     return this.guildId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("query")
/*     */   public Possible<String> query() {
/* 117 */     return this.query_absent ? Possible.absent() : Possible.of(this.query_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("limit")
/*     */   public int limit() {
/* 126 */     return this.limit;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("presences")
/*     */   public Possible<Boolean> presences() {
/* 135 */     return this.presences_absent ? Possible.absent() : Possible.of(this.presences_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("user_ids")
/*     */   public Possible<List<String>> userIds() {
/* 144 */     return this.userIds_absent ? Possible.absent() : 
/* 145 */       Possible.of(this.userIds_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("nonce")
/*     */   public Possible<String> nonce() {
/* 154 */     return this.nonce_absent ? Possible.absent() : Possible.of(this.nonce_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableRequestGuildMembers withGuildId(String value) {
/* 164 */     String newValue = Objects.<String>requireNonNull(value, "guildId");
/* 165 */     if (this.guildId.equals(newValue)) return this; 
/* 166 */     return new ImmutableRequestGuildMembers(this, newValue, query(), this.limit, presences(), userIds(), nonce());
/*     */   }
/*     */   
/*     */   public ImmutableRequestGuildMembers withQuery(Possible<String> value) {
/* 170 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/* 171 */     return new ImmutableRequestGuildMembers(this, this.guildId, newValue, this.limit, presences(), userIds(), nonce());
/*     */   }
/*     */   
/*     */   public ImmutableRequestGuildMembers withQuery(String value) {
/* 175 */     Possible<String> newValue = Possible.of(value);
/* 176 */     return new ImmutableRequestGuildMembers(this, this.guildId, newValue, this.limit, presences(), userIds(), nonce());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableRequestGuildMembers withLimit(int value) {
/* 186 */     if (this.limit == value) return this; 
/* 187 */     return new ImmutableRequestGuildMembers(this, this.guildId, query(), value, presences(), userIds(), nonce());
/*     */   }
/*     */   
/*     */   public ImmutableRequestGuildMembers withPresences(Possible<Boolean> value) {
/* 191 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/* 192 */     return new ImmutableRequestGuildMembers(this, this.guildId, query(), this.limit, newValue, userIds(), nonce());
/*     */   }
/*     */   
/*     */   public ImmutableRequestGuildMembers withPresences(Boolean value) {
/* 196 */     Possible<Boolean> newValue = Possible.of(value);
/* 197 */     return new ImmutableRequestGuildMembers(this, this.guildId, query(), this.limit, newValue, userIds(), nonce());
/*     */   }
/*     */   
/*     */   public ImmutableRequestGuildMembers withUserIds(Possible<List<String>> possible) {
/* 201 */     Possible<List<String>> newValue = Objects.<Possible<List<String>>>requireNonNull(possible);
/* 202 */     return new ImmutableRequestGuildMembers(this, this.guildId, query(), this.limit, presences(), newValue, nonce());
/*     */   }
/*     */   
/*     */   public ImmutableRequestGuildMembers withUserIds(Iterable<String> elements) {
/* 206 */     Possible<List<String>> newValue = Possible.of(
/* 207 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/* 208 */     return new ImmutableRequestGuildMembers(this, this.guildId, query(), this.limit, presences(), newValue, nonce());
/*     */   }
/*     */   
/*     */   @SafeVarargs
/*     */   public final ImmutableRequestGuildMembers withUserIds(String... elements) {
/* 213 */     Possible<List<String>> newValue = Possible.of(Arrays.asList(elements));
/* 214 */     return new ImmutableRequestGuildMembers(this, this.guildId, query(), this.limit, presences(), newValue, nonce());
/*     */   }
/*     */   
/*     */   public ImmutableRequestGuildMembers withNonce(Possible<String> value) {
/* 218 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/* 219 */     return new ImmutableRequestGuildMembers(this, this.guildId, query(), this.limit, presences(), userIds(), newValue);
/*     */   }
/*     */   
/*     */   public ImmutableRequestGuildMembers withNonce(String value) {
/* 223 */     Possible<String> newValue = Possible.of(value);
/* 224 */     return new ImmutableRequestGuildMembers(this, this.guildId, query(), this.limit, presences(), userIds(), newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 233 */     if (this == another) return true; 
/* 234 */     return (another instanceof ImmutableRequestGuildMembers && 
/* 235 */       equalTo(0, (ImmutableRequestGuildMembers)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableRequestGuildMembers another) {
/* 239 */     return (this.guildId.equals(another.guildId) && 
/* 240 */       query().equals(another.query()) && this.limit == another.limit && 
/*     */       
/* 242 */       presences().equals(another.presences()) && 
/* 243 */       Objects.equals(this.userIds_value, another.userIds_value) && 
/* 244 */       nonce().equals(another.nonce()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 253 */     int h = 5381;
/* 254 */     h += (h << 5) + this.guildId.hashCode();
/* 255 */     h += (h << 5) + query().hashCode();
/* 256 */     h += (h << 5) + this.limit;
/* 257 */     h += (h << 5) + presences().hashCode();
/* 258 */     h += (h << 5) + Objects.hashCode(this.userIds_value);
/* 259 */     h += (h << 5) + nonce().hashCode();
/* 260 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 269 */     return "RequestGuildMembers{guildId=" + this.guildId + ", query=" + 
/*     */       
/* 271 */       query().toString() + ", limit=" + this.limit + ", presences=" + 
/*     */       
/* 273 */       presences().toString() + ", userIds=" + 
/* 274 */       Objects.toString(this.userIds_value) + ", nonce=" + 
/* 275 */       nonce().toString() + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "RequestGuildMembers", generator = "Immutables")
/*     */   static final class Json
/*     */     implements RequestGuildMembers
/*     */   {
/*     */     String guildId;
/*     */ 
/*     */     
/* 290 */     Possible<String> query = Possible.absent();
/*     */     
/*     */     int limit;
/*     */     
/*     */     boolean limitIsSet;
/* 295 */     Possible<Boolean> presences = Possible.absent();
/*     */ 
/*     */     
/* 298 */     Possible<List<String>> userIds = Possible.absent();
/*     */ 
/*     */     
/* 301 */     Possible<String> nonce = Possible.absent();
/*     */     
/*     */     @JsonProperty("guild_id")
/*     */     public void setGuildId(String guildId) {
/* 305 */       this.guildId = guildId;
/*     */     }
/*     */     @JsonProperty("query")
/*     */     public void setQuery(Possible<String> query) {
/* 309 */       this.query = query;
/*     */     }
/*     */     @JsonProperty("limit")
/*     */     public void setLimit(int limit) {
/* 313 */       this.limit = limit;
/* 314 */       this.limitIsSet = true;
/*     */     }
/*     */     @JsonProperty("presences")
/*     */     public void setPresences(Possible<Boolean> presences) {
/* 318 */       this.presences = presences;
/*     */     }
/*     */     @JsonProperty("user_ids")
/*     */     public void setUserIds(Possible<List<String>> userIds) {
/* 322 */       this.userIds = userIds;
/*     */     }
/*     */     @JsonProperty("nonce")
/*     */     public void setNonce(Possible<String> nonce) {
/* 326 */       this.nonce = nonce;
/*     */     }
/*     */     public String guildId() {
/* 329 */       throw new UnsupportedOperationException();
/*     */     } public Possible<String> query() {
/* 331 */       throw new UnsupportedOperationException();
/*     */     } public int limit() {
/* 333 */       throw new UnsupportedOperationException();
/*     */     } public Possible<Boolean> presences() {
/* 335 */       throw new UnsupportedOperationException();
/*     */     } public Possible<List<String>> userIds() {
/* 337 */       throw new UnsupportedOperationException();
/*     */     } public Possible<String> nonce() {
/* 339 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableRequestGuildMembers fromJson(Json json) {
/* 350 */     Builder builder = builder();
/* 351 */     if (json.guildId != null) {
/* 352 */       builder.guildId(json.guildId);
/*     */     }
/* 354 */     if (json.query != null) {
/* 355 */       builder.query(json.query);
/*     */     }
/* 357 */     if (json.limitIsSet) {
/* 358 */       builder.limit(json.limit);
/*     */     }
/* 360 */     if (json.presences != null) {
/* 361 */       builder.presences(json.presences);
/*     */     }
/* 363 */     if (json.userIds != null) {
/* 364 */       builder.userIds(json.userIds);
/*     */     }
/* 366 */     if (json.nonce != null) {
/* 367 */       builder.nonce(json.nonce);
/*     */     }
/* 369 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableRequestGuildMembers of(String guildId, Possible<String> query, int limit, Possible<Boolean> presences, Possible<List<String>> userIds, Possible<String> nonce) {
/* 383 */     return new ImmutableRequestGuildMembers(guildId, query, limit, presences, userIds, nonce);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableRequestGuildMembers copyOf(RequestGuildMembers instance) {
/* 394 */     if (instance instanceof ImmutableRequestGuildMembers) {
/* 395 */       return (ImmutableRequestGuildMembers)instance;
/*     */     }
/* 397 */     return builder()
/* 398 */       .from(instance)
/* 399 */       .build();
/*     */   }
/*     */   
/*     */   public boolean isQueryPresent() {
/* 403 */     return !this.query_absent;
/*     */   }
/*     */   
/*     */   public String queryOrElse(String defaultValue) {
/* 407 */     return !this.query_absent ? this.query_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isPresencesPresent() {
/* 411 */     return !this.presences_absent;
/*     */   }
/*     */   
/*     */   public Boolean presencesOrElse(Boolean defaultValue) {
/* 415 */     return !this.presences_absent ? this.presences_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isUserIdsPresent() {
/* 419 */     return !this.userIds_absent;
/*     */   }
/*     */   
/*     */   public List<String> userIdsOrElse(List<String> defaultValue) {
/* 423 */     return !this.userIds_absent ? this.userIds_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isNoncePresent() {
/* 427 */     return !this.nonce_absent;
/*     */   }
/*     */   
/*     */   public String nonceOrElse(String defaultValue) {
/* 431 */     return !this.nonce_absent ? this.nonce_value : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 449 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "RequestGuildMembers", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_GUILD_ID = 1L;
/*     */ 
/*     */     
/*     */     private static final long INIT_BIT_LIMIT = 2L;
/*     */ 
/*     */     
/* 463 */     private long initBits = 3L;
/*     */     
/* 465 */     private Possible<String> query_possible = Possible.absent();
/* 466 */     private Possible<Boolean> presences_possible = Possible.absent();
/* 467 */     private List<String> userIds_list = null;
/* 468 */     private Possible<String> nonce_possible = Possible.absent();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private String guildId;
/*     */ 
/*     */ 
/*     */     
/*     */     private int limit;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(RequestGuildMembers instance) {
/* 483 */       Objects.requireNonNull(instance, "instance");
/* 484 */       guildId(instance.guildId());
/* 485 */       query(instance.query());
/* 486 */       limit(instance.limit());
/* 487 */       presences(instance.presences());
/* 488 */       userIds(instance.userIds());
/* 489 */       nonce(instance.nonce());
/* 490 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("guild_id")
/*     */     public final Builder guildId(String guildId) {
/* 500 */       this.guildId = Objects.<String>requireNonNull(guildId, "guildId");
/* 501 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 502 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("query")
/*     */     public Builder query(Possible<String> value) {
/* 507 */       this.query_possible = value;
/* 508 */       return this;
/*     */     }
/*     */     
/*     */     public Builder query(String value) {
/* 512 */       this.query_possible = Possible.of(value);
/* 513 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("limit")
/*     */     public final Builder limit(int limit) {
/* 523 */       this.limit = limit;
/* 524 */       this.initBits &= 0xFFFFFFFFFFFFFFFDL;
/* 525 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("presences")
/*     */     public Builder presences(Possible<Boolean> value) {
/* 530 */       this.presences_possible = value;
/* 531 */       return this;
/*     */     }
/*     */     
/*     */     public Builder presences(Boolean value) {
/* 535 */       this.presences_possible = Possible.of(value);
/* 536 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addUserId(String element) {
/* 540 */       userIds_getOrCreate().add(element);
/* 541 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addAllUserIds(List<String> elements) {
/* 545 */       userIds_getOrCreate().addAll(elements);
/* 546 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("user_ids")
/*     */     public Builder userIds(Possible<List<String>> elements) {
/* 551 */       this.userIds_list = null;
/* 552 */       elements.toOptional().ifPresent(e -> userIds_getOrCreate().addAll(e));
/* 553 */       return this;
/*     */     }
/*     */     
/*     */     public Builder userIds(List<String> elements) {
/* 557 */       this.userIds_list = new ArrayList<>(elements);
/* 558 */       return this;
/*     */     }
/*     */     
/*     */     public Builder userIds(Iterable<String> elements) {
/* 562 */       this.userIds_list = (List<String>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/* 563 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("nonce")
/*     */     public Builder nonce(Possible<String> value) {
/* 568 */       this.nonce_possible = value;
/* 569 */       return this;
/*     */     }
/*     */     
/*     */     public Builder nonce(String value) {
/* 573 */       this.nonce_possible = Possible.of(value);
/* 574 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableRequestGuildMembers build() {
/* 583 */       if (this.initBits != 0L) {
/* 584 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 586 */       return new ImmutableRequestGuildMembers(null, this.guildId, query_build(), this.limit, presences_build(), userIds_build(), nonce_build());
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 590 */       List<String> attributes = new ArrayList<>();
/* 591 */       if ((this.initBits & 0x1L) != 0L) attributes.add("guildId"); 
/* 592 */       if ((this.initBits & 0x2L) != 0L) attributes.add("limit"); 
/* 593 */       return "Cannot build RequestGuildMembers, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Possible<String> query_build() {
/* 597 */       return this.query_possible;
/*     */     }
/*     */     
/*     */     private Possible<Boolean> presences_build() {
/* 601 */       return this.presences_possible;
/*     */     }
/*     */     
/*     */     private Possible<List<String>> userIds_build() {
/* 605 */       return (this.userIds_list == null) ? Possible.absent() : 
/* 606 */         Possible.of(this.userIds_list);
/*     */     }
/*     */     
/*     */     private List<String> userIds_getOrCreate() {
/* 610 */       if (this.userIds_list == null) {
/* 611 */         this.userIds_list = new ArrayList<>();
/*     */       }
/* 613 */       return this.userIds_list;
/*     */     }
/*     */     
/*     */     private Possible<String> nonce_build() {
/* 617 */       return this.nonce_possible;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\gateway\ImmutableRequestGuildMembers.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */