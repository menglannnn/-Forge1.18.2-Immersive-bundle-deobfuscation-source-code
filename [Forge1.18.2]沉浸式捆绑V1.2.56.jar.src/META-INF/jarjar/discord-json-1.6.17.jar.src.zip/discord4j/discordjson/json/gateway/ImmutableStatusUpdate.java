/*     */ package discord4j.discordjson.json.gateway;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.json.ActivityUpdateRequest;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "StatusUpdate", generator = "Immutables")
/*     */ public final class ImmutableStatusUpdate
/*     */   implements StatusUpdate
/*     */ {
/*     */   private final Long since;
/*     */   private final List<ActivityUpdateRequest> activities;
/*     */   private final String status;
/*     */   private final boolean afk;
/*     */   
/*     */   private ImmutableStatusUpdate(Optional<Long> since, Iterable<? extends ActivityUpdateRequest> activities, String status, boolean afk) {
/*  39 */     this.since = since.orElse(null);
/*  40 */     this.activities = createUnmodifiableList(false, createSafeList(activities, true, false));
/*  41 */     this.status = Objects.<String>requireNonNull(status, "status");
/*  42 */     this.afk = afk;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ImmutableStatusUpdate(ImmutableStatusUpdate original, Long since, List<ActivityUpdateRequest> activities, String status, boolean afk) {
/*  51 */     this.since = since;
/*  52 */     this.activities = activities;
/*  53 */     this.status = status;
/*  54 */     this.afk = afk;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("since")
/*     */   public Optional<Long> since() {
/*  63 */     return Optional.ofNullable(this.since);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("activities")
/*     */   public List<ActivityUpdateRequest> activities() {
/*  72 */     return this.activities;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("status")
/*     */   public String status() {
/*  81 */     return this.status;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("afk")
/*     */   public boolean afk() {
/*  90 */     return this.afk;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableStatusUpdate withSince(long value) {
/*  99 */     Long newValue = Long.valueOf(value);
/* 100 */     if (Objects.equals(this.since, newValue)) return this; 
/* 101 */     return new ImmutableStatusUpdate(this, newValue, this.activities, this.status, this.afk);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableStatusUpdate withSince(Optional<Long> optional) {
/* 111 */     Long value = optional.orElse(null);
/* 112 */     if (Objects.equals(this.since, value)) return this; 
/* 113 */     return new ImmutableStatusUpdate(this, value, this.activities, this.status, this.afk);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableStatusUpdate withActivities(ActivityUpdateRequest... elements) {
/* 122 */     List<ActivityUpdateRequest> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/* 123 */     return new ImmutableStatusUpdate(this, this.since, newValue, this.status, this.afk);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableStatusUpdate withActivities(Iterable<? extends ActivityUpdateRequest> elements) {
/* 133 */     if (this.activities == elements) return this; 
/* 134 */     List<ActivityUpdateRequest> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/* 135 */     return new ImmutableStatusUpdate(this, this.since, newValue, this.status, this.afk);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableStatusUpdate withStatus(String value) {
/* 145 */     String newValue = Objects.<String>requireNonNull(value, "status");
/* 146 */     if (this.status.equals(newValue)) return this; 
/* 147 */     return new ImmutableStatusUpdate(this, this.since, this.activities, newValue, this.afk);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableStatusUpdate withAfk(boolean value) {
/* 157 */     if (this.afk == value) return this; 
/* 158 */     return new ImmutableStatusUpdate(this, this.since, this.activities, this.status, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 167 */     if (this == another) return true; 
/* 168 */     return (another instanceof ImmutableStatusUpdate && 
/* 169 */       equalTo(0, (ImmutableStatusUpdate)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableStatusUpdate another) {
/* 173 */     return (Objects.equals(this.since, another.since) && this.activities
/* 174 */       .equals(another.activities) && this.status
/* 175 */       .equals(another.status) && this.afk == another.afk);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 185 */     int h = 5381;
/* 186 */     h += (h << 5) + Objects.hashCode(this.since);
/* 187 */     h += (h << 5) + this.activities.hashCode();
/* 188 */     h += (h << 5) + this.status.hashCode();
/* 189 */     h += (h << 5) + Boolean.hashCode(this.afk);
/* 190 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 199 */     StringBuilder builder = new StringBuilder("StatusUpdate{");
/* 200 */     if (this.since != null) {
/* 201 */       builder.append("since=").append(this.since);
/*     */     }
/* 203 */     if (builder.length() > 13) builder.append(", "); 
/* 204 */     builder.append("activities=").append(this.activities);
/* 205 */     builder.append(", ");
/* 206 */     builder.append("status=").append(this.status);
/* 207 */     builder.append(", ");
/* 208 */     builder.append("afk=").append(this.afk);
/* 209 */     return builder.append("}").toString();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "StatusUpdate", generator = "Immutables")
/*     */   static final class Json
/*     */     implements StatusUpdate
/*     */   {
/* 221 */     Optional<Long> since = Optional.empty();
/* 222 */     List<ActivityUpdateRequest> activities = Collections.emptyList(); String status;
/*     */     boolean afk;
/*     */     boolean afkIsSet;
/*     */     
/*     */     @JsonProperty("since")
/*     */     public void setSince(Optional<Long> since) {
/* 228 */       this.since = since;
/*     */     }
/*     */     @JsonProperty("activities")
/*     */     public void setActivities(List<ActivityUpdateRequest> activities) {
/* 232 */       this.activities = activities;
/*     */     }
/*     */     @JsonProperty("status")
/*     */     public void setStatus(String status) {
/* 236 */       this.status = status;
/*     */     }
/*     */     @JsonProperty("afk")
/*     */     public void setAfk(boolean afk) {
/* 240 */       this.afk = afk;
/* 241 */       this.afkIsSet = true;
/*     */     }
/*     */     public Optional<Long> since() {
/* 244 */       throw new UnsupportedOperationException();
/*     */     } public List<ActivityUpdateRequest> activities() {
/* 246 */       throw new UnsupportedOperationException();
/*     */     } public String status() {
/* 248 */       throw new UnsupportedOperationException();
/*     */     } public boolean afk() {
/* 250 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableStatusUpdate fromJson(Json json) {
/* 261 */     Builder builder = builder();
/* 262 */     if (json.since != null) {
/* 263 */       builder.since(json.since);
/*     */     }
/* 265 */     if (json.activities != null) {
/* 266 */       builder.addAllActivities(json.activities);
/*     */     }
/* 268 */     if (json.status != null) {
/* 269 */       builder.status(json.status);
/*     */     }
/* 271 */     if (json.afkIsSet) {
/* 272 */       builder.afk(json.afk);
/*     */     }
/* 274 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableStatusUpdate of(Optional<Long> since, List<ActivityUpdateRequest> activities, String status, boolean afk) {
/* 286 */     return of(since, activities, status, afk);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableStatusUpdate of(Optional<Long> since, Iterable<? extends ActivityUpdateRequest> activities, String status, boolean afk) {
/* 298 */     return new ImmutableStatusUpdate(since, activities, status, afk);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableStatusUpdate copyOf(StatusUpdate instance) {
/* 309 */     if (instance instanceof ImmutableStatusUpdate) {
/* 310 */       return (ImmutableStatusUpdate)instance;
/*     */     }
/* 312 */     return builder()
/* 313 */       .from(instance)
/* 314 */       .build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 330 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "StatusUpdate", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_STATUS = 1L;
/*     */ 
/*     */     
/*     */     private static final long INIT_BIT_AFK = 2L;
/*     */ 
/*     */     
/* 344 */     private long initBits = 3L;
/*     */     
/*     */     private Long since;
/* 347 */     private List<ActivityUpdateRequest> activities = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private String status;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private boolean afk;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(StatusUpdate instance) {
/* 363 */       Objects.requireNonNull(instance, "instance");
/* 364 */       Optional<Long> sinceOptional = instance.since();
/* 365 */       if (sinceOptional.isPresent()) {
/* 366 */         since(sinceOptional);
/*     */       }
/* 368 */       addAllActivities(instance.activities());
/* 369 */       status(instance.status());
/* 370 */       afk(instance.afk());
/* 371 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder since(long since) {
/* 380 */       this.since = Long.valueOf(since);
/* 381 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("since")
/*     */     public final Builder since(Optional<Long> since) {
/* 391 */       this.since = since.orElse(null);
/* 392 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder addActivity(ActivityUpdateRequest element) {
/* 401 */       this.activities.add(Objects.<ActivityUpdateRequest>requireNonNull(element, "activities element"));
/* 402 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder addActivities(ActivityUpdateRequest... elements) {
/* 411 */       for (ActivityUpdateRequest element : elements) {
/* 412 */         this.activities.add(Objects.<ActivityUpdateRequest>requireNonNull(element, "activities element"));
/*     */       }
/* 414 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("activities")
/*     */     public final Builder activities(Iterable<? extends ActivityUpdateRequest> elements) {
/* 425 */       this.activities.clear();
/* 426 */       return addAllActivities(elements);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder addAllActivities(Iterable<? extends ActivityUpdateRequest> elements) {
/* 435 */       for (ActivityUpdateRequest element : elements) {
/* 436 */         this.activities.add(Objects.<ActivityUpdateRequest>requireNonNull(element, "activities element"));
/*     */       }
/* 438 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("status")
/*     */     public final Builder status(String status) {
/* 448 */       this.status = Objects.<String>requireNonNull(status, "status");
/* 449 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 450 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("afk")
/*     */     public final Builder afk(boolean afk) {
/* 460 */       this.afk = afk;
/* 461 */       this.initBits &= 0xFFFFFFFFFFFFFFFDL;
/* 462 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableStatusUpdate build() {
/* 471 */       if (this.initBits != 0L) {
/* 472 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 474 */       return new ImmutableStatusUpdate(null, this.since, ImmutableStatusUpdate.createUnmodifiableList(true, (List)this.activities), this.status, this.afk);
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 478 */       List<String> attributes = new ArrayList<>();
/* 479 */       if ((this.initBits & 0x1L) != 0L) attributes.add("status"); 
/* 480 */       if ((this.initBits & 0x2L) != 0L) attributes.add("afk"); 
/* 481 */       return "Cannot build StatusUpdate, some of required attributes are not set " + attributes;
/*     */     }
/*     */     private Builder() {} }
/*     */   
/*     */   private static <T> List<T> createSafeList(Iterable<? extends T> iterable, boolean checkNulls, boolean skipNulls) {
/*     */     ArrayList<T> list;
/* 487 */     if (iterable instanceof Collection) {
/* 488 */       int size = ((Collection)iterable).size();
/* 489 */       if (size == 0) return Collections.emptyList(); 
/* 490 */       list = new ArrayList<>();
/*     */     } else {
/* 492 */       list = new ArrayList<>();
/*     */     } 
/* 494 */     for (T element : iterable) {
/* 495 */       if (skipNulls && element == null)
/* 496 */         continue;  if (checkNulls) Objects.requireNonNull(element, "element"); 
/* 497 */       list.add(element);
/*     */     } 
/* 499 */     return list;
/*     */   }
/*     */   
/*     */   private static <T> List<T> createUnmodifiableList(boolean clone, List<T> list) {
/* 503 */     switch (list.size()) { case 0:
/* 504 */         return Collections.emptyList();
/* 505 */       case 1: return Collections.singletonList(list.get(0)); }
/*     */     
/* 507 */     if (clone) {
/* 508 */       return Collections.unmodifiableList(new ArrayList<>(list));
/*     */     }
/* 510 */     if (list instanceof ArrayList) {
/* 511 */       ((ArrayList)list).trimToSize();
/*     */     }
/* 513 */     return Collections.unmodifiableList(list);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\gateway\ImmutableStatusUpdate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */