/*    */ package discord4j.discordjson.json.gateway;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonUnwrapped;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import discord4j.discordjson.json.GuildScheduledEventData;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ @JsonSerialize(as = ImmutableGuildScheduledEventDelete.class)
/*    */ @JsonDeserialize(as = ImmutableGuildScheduledEventDelete.class)
/*    */ @Immutable
/*    */ public interface GuildScheduledEventDelete
/*    */   extends Dispatch {
/*    */   static ImmutableGuildScheduledEventDelete.Builder builder() {
/* 15 */     return ImmutableGuildScheduledEventDelete.builder();
/*    */   }
/*    */   
/*    */   @JsonUnwrapped
/*    */   GuildScheduledEventData scheduledEvent();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\gateway\GuildScheduledEventDelete.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */