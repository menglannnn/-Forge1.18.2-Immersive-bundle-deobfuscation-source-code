/*    */ package discord4j.discordjson.json.gateway;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonProperty;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import discord4j.discordjson.Id;
/*    */ import java.util.Optional;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ @JsonSerialize(as = ImmutableVoiceStateUpdate.class)
/*    */ @JsonDeserialize(as = ImmutableVoiceStateUpdate.class)
/*    */ @Immutable
/*    */ public interface VoiceStateUpdate
/*    */   extends PayloadData
/*    */ {
/*    */   static ImmutableVoiceStateUpdate.Builder builder() {
/* 17 */     return ImmutableVoiceStateUpdate.builder();
/*    */   }
/*    */   
/*    */   @JsonProperty("guild_id")
/*    */   Id guildId();
/*    */   
/*    */   @JsonProperty("channel_id")
/*    */   Optional<Id> channelId();
/*    */   
/*    */   @JsonProperty("self_mute")
/*    */   boolean selfMute();
/*    */   
/*    */   @JsonProperty("self_deaf")
/*    */   boolean selfDeaf();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\gateway\VoiceStateUpdate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */