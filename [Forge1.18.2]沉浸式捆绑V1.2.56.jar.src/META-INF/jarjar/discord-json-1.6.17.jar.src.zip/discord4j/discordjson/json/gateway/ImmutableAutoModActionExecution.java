/*      */ package discord4j.discordjson.json.gateway;
/*      */ 
/*      */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*      */ import com.fasterxml.jackson.annotation.JsonCreator;
/*      */ import com.fasterxml.jackson.annotation.JsonProperty;
/*      */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*      */ import discord4j.discordjson.Id;
/*      */ import discord4j.discordjson.json.AutoModActionData;
/*      */ import discord4j.discordjson.possible.Possible;
/*      */ import java.util.ArrayList;
/*      */ import java.util.List;
/*      */ import java.util.Objects;
/*      */ import java.util.Optional;
/*      */ import org.immutables.value.Generated;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ @Generated(from = "AutoModActionExecution", generator = "Immutables")
/*      */ public final class ImmutableAutoModActionExecution
/*      */   implements AutoModActionExecution
/*      */ {
/*      */   private final long guildId_value;
/*      */   private final AutoModActionData action;
/*      */   private final long ruleId_value;
/*      */   private final int ruleTriggerType;
/*      */   private final long userId_value;
/*      */   private final long channelId_value;
/*      */   private final boolean channelId_absent;
/*      */   private final long messageId_value;
/*      */   private final boolean messageId_absent;
/*      */   private final long alertSystemMessageId_value;
/*      */   private final boolean alertSystemMessageId_absent;
/*      */   private final String content;
/*      */   private final String matchedKeyword;
/*      */   private final String matchedContent;
/*      */   private static final byte STAGE_INITIALIZING = -1;
/*      */   private static final byte STAGE_UNINITIALIZED = 0;
/*      */   private static final byte STAGE_INITIALIZED = 1;
/*      */   
/*      */   private ImmutableAutoModActionExecution(Id guildId, AutoModActionData action, Id ruleId, int ruleTriggerType, Id userId, Possible<Id> channelId, Possible<Id> messageId, Possible<Id> alertSystemMessageId, String content, Optional<String> matchedKeyword, Optional<String> matchedContent) {
/*   56 */     Id guildId$impl = guildId;
/*   57 */     this.action = Objects.<AutoModActionData>requireNonNull(action, "action");
/*   58 */     Id ruleId$impl = ruleId;
/*   59 */     this.ruleTriggerType = ruleTriggerType;
/*   60 */     Id userId$impl = userId;
/*   61 */     Possible<Id> channelId$impl = channelId;
/*   62 */     Possible<Id> messageId$impl = messageId;
/*   63 */     Possible<Id> alertSystemMessageId$impl = alertSystemMessageId;
/*   64 */     this.content = Objects.<String>requireNonNull(content, "content");
/*   65 */     this.matchedKeyword = matchedKeyword.orElse(null);
/*   66 */     this.matchedContent = matchedContent.orElse(null);
/*   67 */     this.guildId_value = guildId$impl.asLong();
/*   68 */     this.ruleId_value = ruleId$impl.asLong();
/*   69 */     this.userId_value = userId$impl.asLong();
/*   70 */     this
/*      */       
/*   72 */       .channelId_value = ((Long)channelId$impl.toOptional().map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*   73 */     this.channelId_absent = channelId$impl.isAbsent();
/*   74 */     this
/*      */       
/*   76 */       .messageId_value = ((Long)messageId$impl.toOptional().map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*   77 */     this.messageId_absent = messageId$impl.isAbsent();
/*   78 */     this
/*      */       
/*   80 */       .alertSystemMessageId_value = ((Long)alertSystemMessageId$impl.toOptional().map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*   81 */     this.alertSystemMessageId_absent = alertSystemMessageId$impl.isAbsent();
/*   82 */     this.initShim = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ImmutableAutoModActionExecution(ImmutableAutoModActionExecution original, Id guildId, AutoModActionData action, Id ruleId, int ruleTriggerType, Id userId, Possible<Id> channelId, Possible<Id> messageId, Possible<Id> alertSystemMessageId, String content, String matchedKeyword, String matchedContent) {
/*   98 */     Id guildId$impl = guildId;
/*   99 */     this.action = action;
/*  100 */     Id ruleId$impl = ruleId;
/*  101 */     this.ruleTriggerType = ruleTriggerType;
/*  102 */     Id userId$impl = userId;
/*  103 */     Possible<Id> channelId$impl = channelId;
/*  104 */     Possible<Id> messageId$impl = messageId;
/*  105 */     Possible<Id> alertSystemMessageId$impl = alertSystemMessageId;
/*  106 */     this.content = content;
/*  107 */     this.matchedKeyword = matchedKeyword;
/*  108 */     this.matchedContent = matchedContent;
/*  109 */     this.guildId_value = guildId$impl.asLong();
/*  110 */     this.ruleId_value = ruleId$impl.asLong();
/*  111 */     this.userId_value = userId$impl.asLong();
/*  112 */     this
/*      */       
/*  114 */       .channelId_value = ((Long)channelId$impl.toOptional().map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  115 */     this.channelId_absent = channelId$impl.isAbsent();
/*  116 */     this
/*      */       
/*  118 */       .messageId_value = ((Long)messageId$impl.toOptional().map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  119 */     this.messageId_absent = messageId$impl.isAbsent();
/*  120 */     this
/*      */       
/*  122 */       .alertSystemMessageId_value = ((Long)alertSystemMessageId$impl.toOptional().map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  123 */     this.alertSystemMessageId_absent = alertSystemMessageId$impl.isAbsent();
/*  124 */     this.initShim = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  130 */   private volatile transient InitShim initShim = new InitShim();
/*      */   
/*      */   @Generated(from = "AutoModActionExecution", generator = "Immutables")
/*      */   private final class InitShim {
/*      */     private String formatInitCycleMessage() {
/*  135 */       List<String> attributes = new ArrayList<>();
/*  136 */       return "Cannot build AutoModActionExecution, attribute initializers form cycle " + attributes;
/*      */     }
/*      */ 
/*      */     
/*      */     private InitShim() {}
/*      */   }
/*      */ 
/*      */   
/*      */   @JsonProperty("guild_id")
/*      */   public Id guildId() {
/*  146 */     return Id.of(this.guildId_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("action")
/*      */   public AutoModActionData action() {
/*  155 */     return this.action;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("rule_id")
/*      */   public Id ruleId() {
/*  164 */     return Id.of(this.ruleId_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("rule_trigger_type")
/*      */   public int ruleTriggerType() {
/*  173 */     return this.ruleTriggerType;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("user_id")
/*      */   public Id userId() {
/*  182 */     return Id.of(this.userId_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("channel_id")
/*      */   public Possible<Id> channelId() {
/*  191 */     return this.channelId_absent ? Possible.absent() : 
/*  192 */       Possible.of(Id.of(this.channelId_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("message_id")
/*      */   public Possible<Id> messageId() {
/*  201 */     return this.messageId_absent ? Possible.absent() : 
/*  202 */       Possible.of(Id.of(this.messageId_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("alert_system_message_id")
/*      */   public Possible<Id> alertSystemMessageId() {
/*  211 */     return this.alertSystemMessageId_absent ? Possible.absent() : 
/*  212 */       Possible.of(Id.of(this.alertSystemMessageId_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("content")
/*      */   public String content() {
/*  221 */     return this.content;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("matched_keyword")
/*      */   public Optional<String> matchedKeyword() {
/*  230 */     return Optional.ofNullable(this.matchedKeyword);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("matched_content")
/*      */   public Optional<String> matchedContent() {
/*  239 */     return Optional.ofNullable(this.matchedContent);
/*      */   }
/*      */   
/*      */   public ImmutableAutoModActionExecution withGuildId(long value) {
/*  243 */     Id newValue = Id.of(value);
/*  244 */     return new ImmutableAutoModActionExecution(this, newValue, this.action, 
/*      */ 
/*      */ 
/*      */         
/*  248 */         ruleId(), this.ruleTriggerType, 
/*      */         
/*  250 */         userId(), 
/*  251 */         channelId(), 
/*  252 */         messageId(), 
/*  253 */         alertSystemMessageId(), this.content, this.matchedKeyword, this.matchedContent);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutableAutoModActionExecution withGuildId(String value) {
/*  260 */     Id newValue = Id.of(value);
/*  261 */     return new ImmutableAutoModActionExecution(this, newValue, this.action, 
/*      */ 
/*      */ 
/*      */         
/*  265 */         ruleId(), this.ruleTriggerType, 
/*      */         
/*  267 */         userId(), 
/*  268 */         channelId(), 
/*  269 */         messageId(), 
/*  270 */         alertSystemMessageId(), this.content, this.matchedKeyword, this.matchedContent);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableAutoModActionExecution withAction(AutoModActionData value) {
/*  283 */     if (this.action == value) return this; 
/*  284 */     AutoModActionData newValue = Objects.<AutoModActionData>requireNonNull(value, "action");
/*  285 */     return new ImmutableAutoModActionExecution(this, 
/*      */         
/*  287 */         guildId(), newValue, 
/*      */         
/*  289 */         ruleId(), this.ruleTriggerType, 
/*      */         
/*  291 */         userId(), 
/*  292 */         channelId(), 
/*  293 */         messageId(), 
/*  294 */         alertSystemMessageId(), this.content, this.matchedKeyword, this.matchedContent);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutableAutoModActionExecution withRuleId(long value) {
/*  301 */     Id newValue = Id.of(value);
/*  302 */     return new ImmutableAutoModActionExecution(this, 
/*      */         
/*  304 */         guildId(), this.action, newValue, this.ruleTriggerType, 
/*      */ 
/*      */ 
/*      */         
/*  308 */         userId(), 
/*  309 */         channelId(), 
/*  310 */         messageId(), 
/*  311 */         alertSystemMessageId(), this.content, this.matchedKeyword, this.matchedContent);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutableAutoModActionExecution withRuleId(String value) {
/*  318 */     Id newValue = Id.of(value);
/*  319 */     return new ImmutableAutoModActionExecution(this, 
/*      */         
/*  321 */         guildId(), this.action, newValue, this.ruleTriggerType, 
/*      */ 
/*      */ 
/*      */         
/*  325 */         userId(), 
/*  326 */         channelId(), 
/*  327 */         messageId(), 
/*  328 */         alertSystemMessageId(), this.content, this.matchedKeyword, this.matchedContent);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableAutoModActionExecution withRuleTriggerType(int value) {
/*  341 */     if (this.ruleTriggerType == value) return this; 
/*  342 */     return new ImmutableAutoModActionExecution(this, 
/*      */         
/*  344 */         guildId(), this.action, 
/*      */         
/*  346 */         ruleId(), value, 
/*      */         
/*  348 */         userId(), 
/*  349 */         channelId(), 
/*  350 */         messageId(), 
/*  351 */         alertSystemMessageId(), this.content, this.matchedKeyword, this.matchedContent);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutableAutoModActionExecution withUserId(long value) {
/*  358 */     Id newValue = Id.of(value);
/*  359 */     return new ImmutableAutoModActionExecution(this, 
/*      */         
/*  361 */         guildId(), this.action, 
/*      */         
/*  363 */         ruleId(), this.ruleTriggerType, newValue, 
/*      */ 
/*      */         
/*  366 */         channelId(), 
/*  367 */         messageId(), 
/*  368 */         alertSystemMessageId(), this.content, this.matchedKeyword, this.matchedContent);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutableAutoModActionExecution withUserId(String value) {
/*  375 */     Id newValue = Id.of(value);
/*  376 */     return new ImmutableAutoModActionExecution(this, 
/*      */         
/*  378 */         guildId(), this.action, 
/*      */         
/*  380 */         ruleId(), this.ruleTriggerType, newValue, 
/*      */ 
/*      */         
/*  383 */         channelId(), 
/*  384 */         messageId(), 
/*  385 */         alertSystemMessageId(), this.content, this.matchedKeyword, this.matchedContent);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutableAutoModActionExecution withChannelId(Possible<Id> value) {
/*  392 */     Possible<Id> newValue = Objects.<Possible<Id>>requireNonNull(value);
/*  393 */     return new ImmutableAutoModActionExecution(this, 
/*      */         
/*  395 */         guildId(), this.action, 
/*      */         
/*  397 */         ruleId(), this.ruleTriggerType, 
/*      */         
/*  399 */         userId(), newValue, 
/*      */         
/*  401 */         messageId(), 
/*  402 */         alertSystemMessageId(), this.content, this.matchedKeyword, this.matchedContent);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutableAutoModActionExecution withChannelId(long value) {
/*  409 */     Possible<Id> newValue = Possible.of(Id.of(value));
/*  410 */     return new ImmutableAutoModActionExecution(this, 
/*      */         
/*  412 */         guildId(), this.action, 
/*      */         
/*  414 */         ruleId(), this.ruleTriggerType, 
/*      */         
/*  416 */         userId(), newValue, 
/*      */         
/*  418 */         messageId(), 
/*  419 */         alertSystemMessageId(), this.content, this.matchedKeyword, this.matchedContent);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutableAutoModActionExecution withMessageId(Possible<Id> value) {
/*  426 */     Possible<Id> newValue = Objects.<Possible<Id>>requireNonNull(value);
/*  427 */     return new ImmutableAutoModActionExecution(this, 
/*      */         
/*  429 */         guildId(), this.action, 
/*      */         
/*  431 */         ruleId(), this.ruleTriggerType, 
/*      */         
/*  433 */         userId(), 
/*  434 */         channelId(), newValue, 
/*      */         
/*  436 */         alertSystemMessageId(), this.content, this.matchedKeyword, this.matchedContent);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutableAutoModActionExecution withMessageId(long value) {
/*  443 */     Possible<Id> newValue = Possible.of(Id.of(value));
/*  444 */     return new ImmutableAutoModActionExecution(this, 
/*      */         
/*  446 */         guildId(), this.action, 
/*      */         
/*  448 */         ruleId(), this.ruleTriggerType, 
/*      */         
/*  450 */         userId(), 
/*  451 */         channelId(), newValue, 
/*      */         
/*  453 */         alertSystemMessageId(), this.content, this.matchedKeyword, this.matchedContent);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutableAutoModActionExecution withAlertSystemMessageId(Possible<Id> value) {
/*  460 */     Possible<Id> newValue = Objects.<Possible<Id>>requireNonNull(value);
/*  461 */     return new ImmutableAutoModActionExecution(this, 
/*      */         
/*  463 */         guildId(), this.action, 
/*      */         
/*  465 */         ruleId(), this.ruleTriggerType, 
/*      */         
/*  467 */         userId(), 
/*  468 */         channelId(), 
/*  469 */         messageId(), newValue, this.content, this.matchedKeyword, this.matchedContent);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutableAutoModActionExecution withAlertSystemMessageId(long value) {
/*  477 */     Possible<Id> newValue = Possible.of(Id.of(value));
/*  478 */     return new ImmutableAutoModActionExecution(this, 
/*      */         
/*  480 */         guildId(), this.action, 
/*      */         
/*  482 */         ruleId(), this.ruleTriggerType, 
/*      */         
/*  484 */         userId(), 
/*  485 */         channelId(), 
/*  486 */         messageId(), newValue, this.content, this.matchedKeyword, this.matchedContent);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableAutoModActionExecution withContent(String value) {
/*  500 */     String newValue = Objects.<String>requireNonNull(value, "content");
/*  501 */     if (this.content.equals(newValue)) return this; 
/*  502 */     return new ImmutableAutoModActionExecution(this, 
/*      */         
/*  504 */         guildId(), this.action, 
/*      */         
/*  506 */         ruleId(), this.ruleTriggerType, 
/*      */         
/*  508 */         userId(), 
/*  509 */         channelId(), 
/*  510 */         messageId(), 
/*  511 */         alertSystemMessageId(), newValue, this.matchedKeyword, this.matchedContent);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableAutoModActionExecution withMatchedKeyword(String value) {
/*  523 */     String newValue = Objects.<String>requireNonNull(value, "matchedKeyword");
/*  524 */     if (Objects.equals(this.matchedKeyword, newValue)) return this; 
/*  525 */     return new ImmutableAutoModActionExecution(this, 
/*      */         
/*  527 */         guildId(), this.action, 
/*      */         
/*  529 */         ruleId(), this.ruleTriggerType, 
/*      */         
/*  531 */         userId(), 
/*  532 */         channelId(), 
/*  533 */         messageId(), 
/*  534 */         alertSystemMessageId(), this.content, newValue, this.matchedContent);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableAutoModActionExecution withMatchedKeyword(Optional<String> optional) {
/*  547 */     String value = optional.orElse(null);
/*  548 */     if (Objects.equals(this.matchedKeyword, value)) return this; 
/*  549 */     return new ImmutableAutoModActionExecution(this, 
/*      */         
/*  551 */         guildId(), this.action, 
/*      */         
/*  553 */         ruleId(), this.ruleTriggerType, 
/*      */         
/*  555 */         userId(), 
/*  556 */         channelId(), 
/*  557 */         messageId(), 
/*  558 */         alertSystemMessageId(), this.content, value, this.matchedContent);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableAutoModActionExecution withMatchedContent(String value) {
/*  570 */     String newValue = Objects.<String>requireNonNull(value, "matchedContent");
/*  571 */     if (Objects.equals(this.matchedContent, newValue)) return this; 
/*  572 */     return new ImmutableAutoModActionExecution(this, 
/*      */         
/*  574 */         guildId(), this.action, 
/*      */         
/*  576 */         ruleId(), this.ruleTriggerType, 
/*      */         
/*  578 */         userId(), 
/*  579 */         channelId(), 
/*  580 */         messageId(), 
/*  581 */         alertSystemMessageId(), this.content, this.matchedKeyword, newValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableAutoModActionExecution withMatchedContent(Optional<String> optional) {
/*  594 */     String value = optional.orElse(null);
/*  595 */     if (Objects.equals(this.matchedContent, value)) return this; 
/*  596 */     return new ImmutableAutoModActionExecution(this, 
/*      */         
/*  598 */         guildId(), this.action, 
/*      */         
/*  600 */         ruleId(), this.ruleTriggerType, 
/*      */         
/*  602 */         userId(), 
/*  603 */         channelId(), 
/*  604 */         messageId(), 
/*  605 */         alertSystemMessageId(), this.content, this.matchedKeyword, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean equals(Object another) {
/*  617 */     if (this == another) return true; 
/*  618 */     return (another instanceof ImmutableAutoModActionExecution && 
/*  619 */       equalTo(0, (ImmutableAutoModActionExecution)another));
/*      */   }
/*      */   
/*      */   private boolean equalTo(int synthetic, ImmutableAutoModActionExecution another) {
/*  623 */     return (Objects.equals(Long.valueOf(this.guildId_value), Long.valueOf(another.guildId_value)) && this.action
/*  624 */       .equals(another.action) && 
/*  625 */       Objects.equals(Long.valueOf(this.ruleId_value), Long.valueOf(another.ruleId_value)) && this.ruleTriggerType == another.ruleTriggerType && 
/*      */       
/*  627 */       Objects.equals(Long.valueOf(this.userId_value), Long.valueOf(another.userId_value)) && 
/*  628 */       channelId().equals(another.channelId()) && 
/*  629 */       messageId().equals(another.messageId()) && 
/*  630 */       alertSystemMessageId().equals(another.alertSystemMessageId()) && this.content
/*  631 */       .equals(another.content) && 
/*  632 */       Objects.equals(this.matchedKeyword, another.matchedKeyword) && 
/*  633 */       Objects.equals(this.matchedContent, another.matchedContent));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int hashCode() {
/*  642 */     int h = 5381;
/*  643 */     h += (h << 5) + Objects.hashCode(Long.valueOf(this.guildId_value));
/*  644 */     h += (h << 5) + this.action.hashCode();
/*  645 */     h += (h << 5) + Objects.hashCode(Long.valueOf(this.ruleId_value));
/*  646 */     h += (h << 5) + this.ruleTriggerType;
/*  647 */     h += (h << 5) + Objects.hashCode(Long.valueOf(this.userId_value));
/*  648 */     h += (h << 5) + channelId().hashCode();
/*  649 */     h += (h << 5) + messageId().hashCode();
/*  650 */     h += (h << 5) + alertSystemMessageId().hashCode();
/*  651 */     h += (h << 5) + this.content.hashCode();
/*  652 */     h += (h << 5) + Objects.hashCode(this.matchedKeyword);
/*  653 */     h += (h << 5) + Objects.hashCode(this.matchedContent);
/*  654 */     return h;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/*  663 */     StringBuilder builder = new StringBuilder("AutoModActionExecution{");
/*  664 */     builder.append("guildId=").append(Objects.toString(Long.valueOf(this.guildId_value)));
/*  665 */     builder.append(", ");
/*  666 */     builder.append("action=").append(this.action);
/*  667 */     builder.append(", ");
/*  668 */     builder.append("ruleId=").append(Objects.toString(Long.valueOf(this.ruleId_value)));
/*  669 */     builder.append(", ");
/*  670 */     builder.append("ruleTriggerType=").append(this.ruleTriggerType);
/*  671 */     builder.append(", ");
/*  672 */     builder.append("userId=").append(Objects.toString(Long.valueOf(this.userId_value)));
/*  673 */     builder.append(", ");
/*  674 */     builder.append("channelId=").append(channelId().toString());
/*  675 */     builder.append(", ");
/*  676 */     builder.append("messageId=").append(messageId().toString());
/*  677 */     builder.append(", ");
/*  678 */     builder.append("alertSystemMessageId=").append(alertSystemMessageId().toString());
/*  679 */     builder.append(", ");
/*  680 */     builder.append("content=").append(this.content);
/*  681 */     if (this.matchedKeyword != null) {
/*  682 */       builder.append(", ");
/*  683 */       builder.append("matchedKeyword=").append(this.matchedKeyword);
/*      */     } 
/*  685 */     if (this.matchedContent != null) {
/*  686 */       builder.append(", ");
/*  687 */       builder.append("matchedContent=").append(this.matchedContent);
/*      */     } 
/*  689 */     return builder.append("}").toString();
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonDeserialize
/*      */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*      */   @Generated(from = "AutoModActionExecution", generator = "Immutables")
/*      */   static final class Json
/*      */     implements AutoModActionExecution
/*      */   {
/*      */     Id guildId;
/*      */     
/*      */     AutoModActionData action;
/*      */     
/*      */     Id ruleId;
/*      */     int ruleTriggerType;
/*      */     boolean ruleTriggerTypeIsSet;
/*      */     Id userId;
/*  708 */     Possible<Id> channelId = Possible.absent();
/*      */ 
/*      */     
/*  711 */     Possible<Id> messageId = Possible.absent();
/*      */ 
/*      */     
/*  714 */     Possible<Id> alertSystemMessageId = Possible.absent();
/*      */     
/*      */     String content;
/*  717 */     Optional<String> matchedKeyword = Optional.empty();
/*  718 */     Optional<String> matchedContent = Optional.empty();
/*      */     @JsonProperty("guild_id")
/*      */     public void setGuildId(Id guildId) {
/*  721 */       this.guildId = guildId;
/*      */     }
/*      */     @JsonProperty("action")
/*      */     public void setAction(AutoModActionData action) {
/*  725 */       this.action = action;
/*      */     }
/*      */     @JsonProperty("rule_id")
/*      */     public void setRuleId(Id ruleId) {
/*  729 */       this.ruleId = ruleId;
/*      */     }
/*      */     @JsonProperty("rule_trigger_type")
/*      */     public void setRuleTriggerType(int ruleTriggerType) {
/*  733 */       this.ruleTriggerType = ruleTriggerType;
/*  734 */       this.ruleTriggerTypeIsSet = true;
/*      */     }
/*      */     @JsonProperty("user_id")
/*      */     public void setUserId(Id userId) {
/*  738 */       this.userId = userId;
/*      */     }
/*      */     @JsonProperty("channel_id")
/*      */     public void setChannelId(Possible<Id> channelId) {
/*  742 */       this.channelId = channelId;
/*      */     }
/*      */     @JsonProperty("message_id")
/*      */     public void setMessageId(Possible<Id> messageId) {
/*  746 */       this.messageId = messageId;
/*      */     }
/*      */     @JsonProperty("alert_system_message_id")
/*      */     public void setAlertSystemMessageId(Possible<Id> alertSystemMessageId) {
/*  750 */       this.alertSystemMessageId = alertSystemMessageId;
/*      */     }
/*      */     @JsonProperty("content")
/*      */     public void setContent(String content) {
/*  754 */       this.content = content;
/*      */     }
/*      */     @JsonProperty("matched_keyword")
/*      */     public void setMatchedKeyword(Optional<String> matchedKeyword) {
/*  758 */       this.matchedKeyword = matchedKeyword;
/*      */     }
/*      */     @JsonProperty("matched_content")
/*      */     public void setMatchedContent(Optional<String> matchedContent) {
/*  762 */       this.matchedContent = matchedContent;
/*      */     }
/*      */     public Id guildId() {
/*  765 */       throw new UnsupportedOperationException();
/*      */     } public AutoModActionData action() {
/*  767 */       throw new UnsupportedOperationException();
/*      */     } public Id ruleId() {
/*  769 */       throw new UnsupportedOperationException();
/*      */     } public int ruleTriggerType() {
/*  771 */       throw new UnsupportedOperationException();
/*      */     } public Id userId() {
/*  773 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Id> channelId() {
/*  775 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Id> messageId() {
/*  777 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Id> alertSystemMessageId() {
/*  779 */       throw new UnsupportedOperationException();
/*      */     } public String content() {
/*  781 */       throw new UnsupportedOperationException();
/*      */     } public Optional<String> matchedKeyword() {
/*  783 */       throw new UnsupportedOperationException();
/*      */     } public Optional<String> matchedContent() {
/*  785 */       throw new UnsupportedOperationException();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*      */   static ImmutableAutoModActionExecution fromJson(Json json) {
/*  796 */     Builder builder = builder();
/*  797 */     if (json.guildId != null) {
/*  798 */       builder.guildId(json.guildId);
/*      */     }
/*  800 */     if (json.action != null) {
/*  801 */       builder.action(json.action);
/*      */     }
/*  803 */     if (json.ruleId != null) {
/*  804 */       builder.ruleId(json.ruleId);
/*      */     }
/*  806 */     if (json.ruleTriggerTypeIsSet) {
/*  807 */       builder.ruleTriggerType(json.ruleTriggerType);
/*      */     }
/*  809 */     if (json.userId != null) {
/*  810 */       builder.userId(json.userId);
/*      */     }
/*  812 */     if (json.channelId != null) {
/*  813 */       builder.channelId(json.channelId);
/*      */     }
/*  815 */     if (json.messageId != null) {
/*  816 */       builder.messageId(json.messageId);
/*      */     }
/*  818 */     if (json.alertSystemMessageId != null) {
/*  819 */       builder.alertSystemMessageId(json.alertSystemMessageId);
/*      */     }
/*  821 */     if (json.content != null) {
/*  822 */       builder.content(json.content);
/*      */     }
/*  824 */     if (json.matchedKeyword != null) {
/*  825 */       builder.matchedKeyword(json.matchedKeyword);
/*      */     }
/*  827 */     if (json.matchedContent != null) {
/*  828 */       builder.matchedContent(json.matchedContent);
/*      */     }
/*  830 */     return builder.build();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableAutoModActionExecution of(Id guildId, AutoModActionData action, Id ruleId, int ruleTriggerType, Id userId, Possible<Id> channelId, Possible<Id> messageId, Possible<Id> alertSystemMessageId, String content, Optional<String> matchedKeyword, Optional<String> matchedContent) {
/*  849 */     return new ImmutableAutoModActionExecution(guildId, action, ruleId, ruleTriggerType, userId, channelId, messageId, alertSystemMessageId, content, matchedKeyword, matchedContent);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableAutoModActionExecution copyOf(AutoModActionExecution instance) {
/*  860 */     if (instance instanceof ImmutableAutoModActionExecution) {
/*  861 */       return (ImmutableAutoModActionExecution)instance;
/*      */     }
/*  863 */     return builder()
/*  864 */       .from(instance)
/*  865 */       .build();
/*      */   }
/*      */   
/*      */   public boolean isChannelIdPresent() {
/*  869 */     return !this.channelId_absent;
/*      */   }
/*      */   
/*      */   public long channelIdOrElse(long defaultValue) {
/*  873 */     return !this.channelId_absent ? this.channelId_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isMessageIdPresent() {
/*  877 */     return !this.messageId_absent;
/*      */   }
/*      */   
/*      */   public long messageIdOrElse(long defaultValue) {
/*  881 */     return !this.messageId_absent ? this.messageId_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isAlertSystemMessageIdPresent() {
/*  885 */     return !this.alertSystemMessageId_absent;
/*      */   }
/*      */   
/*      */   public long alertSystemMessageIdOrElse(long defaultValue) {
/*  889 */     return !this.alertSystemMessageId_absent ? this.alertSystemMessageId_value : defaultValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Builder builder() {
/*  912 */     return new Builder();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   @Generated(from = "AutoModActionExecution", generator = "Immutables")
/*      */   public static final class Builder
/*      */   {
/*      */     private static final long INIT_BIT_ACTION = 1L;
/*      */ 
/*      */     
/*      */     private static final long INIT_BIT_RULE_TRIGGER_TYPE = 2L;
/*      */     
/*      */     private static final long INIT_BIT_CONTENT = 4L;
/*      */     
/*  927 */     private long initBits = 7L;
/*      */     
/*  929 */     private Id guildId_id = null;
/*  930 */     private Id ruleId_id = null;
/*  931 */     private Id userId_id = null;
/*  932 */     private Possible<Id> channelId_possible = Possible.absent();
/*  933 */     private Possible<Id> messageId_possible = Possible.absent();
/*  934 */     private Possible<Id> alertSystemMessageId_possible = Possible.absent();
/*      */ 
/*      */     
/*      */     private AutoModActionData action;
/*      */ 
/*      */     
/*      */     private int ruleTriggerType;
/*      */ 
/*      */     
/*      */     private String content;
/*      */ 
/*      */     
/*      */     private String matchedKeyword;
/*      */     
/*      */     private String matchedContent;
/*      */ 
/*      */     
/*      */     public final Builder from(AutoModActionExecution instance) {
/*  952 */       Objects.requireNonNull(instance, "instance");
/*  953 */       guildId(instance.guildId());
/*  954 */       action(instance.action());
/*  955 */       ruleId(instance.ruleId());
/*  956 */       ruleTriggerType(instance.ruleTriggerType());
/*  957 */       userId(instance.userId());
/*  958 */       channelId(instance.channelId());
/*  959 */       messageId(instance.messageId());
/*  960 */       alertSystemMessageId(instance.alertSystemMessageId());
/*  961 */       content(instance.content());
/*  962 */       Optional<String> matchedKeywordOptional = instance.matchedKeyword();
/*  963 */       if (matchedKeywordOptional.isPresent()) {
/*  964 */         matchedKeyword(matchedKeywordOptional);
/*      */       }
/*  966 */       Optional<String> matchedContentOptional = instance.matchedContent();
/*  967 */       if (matchedContentOptional.isPresent()) {
/*  968 */         matchedContent(matchedContentOptional);
/*      */       }
/*  970 */       return this;
/*      */     }
/*      */     
/*      */     public Builder guildId(String value) {
/*  974 */       this.guildId_id = Id.of(value);
/*  975 */       return this;
/*      */     }
/*      */     
/*      */     public Builder guildId(long value) {
/*  979 */       this.guildId_id = Id.of(value);
/*  980 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("guild_id")
/*      */     public Builder guildId(Id value) {
/*  985 */       this.guildId_id = value;
/*  986 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("action")
/*      */     public final Builder action(AutoModActionData action) {
/*  996 */       this.action = Objects.<AutoModActionData>requireNonNull(action, "action");
/*  997 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/*  998 */       return this;
/*      */     }
/*      */     
/*      */     public Builder ruleId(String value) {
/* 1002 */       this.ruleId_id = Id.of(value);
/* 1003 */       return this;
/*      */     }
/*      */     
/*      */     public Builder ruleId(long value) {
/* 1007 */       this.ruleId_id = Id.of(value);
/* 1008 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("rule_id")
/*      */     public Builder ruleId(Id value) {
/* 1013 */       this.ruleId_id = value;
/* 1014 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("rule_trigger_type")
/*      */     public final Builder ruleTriggerType(int ruleTriggerType) {
/* 1024 */       this.ruleTriggerType = ruleTriggerType;
/* 1025 */       this.initBits &= 0xFFFFFFFFFFFFFFFDL;
/* 1026 */       return this;
/*      */     }
/*      */     
/*      */     public Builder userId(String value) {
/* 1030 */       this.userId_id = Id.of(value);
/* 1031 */       return this;
/*      */     }
/*      */     
/*      */     public Builder userId(long value) {
/* 1035 */       this.userId_id = Id.of(value);
/* 1036 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("user_id")
/*      */     public Builder userId(Id value) {
/* 1041 */       this.userId_id = value;
/* 1042 */       return this;
/*      */     }
/*      */     
/*      */     public Builder channelId(String value) {
/* 1046 */       this.channelId_possible = Possible.of(Id.of(value));
/* 1047 */       return this;
/*      */     }
/*      */     
/*      */     public Builder channelId(long value) {
/* 1051 */       this.channelId_possible = Possible.of(Id.of(value));
/* 1052 */       return this;
/*      */     }
/*      */     
/*      */     public Builder channelId(Id value) {
/* 1056 */       this.channelId_possible = Possible.of(value);
/* 1057 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("channel_id")
/*      */     public Builder channelId(Possible<Id> value) {
/* 1062 */       this.channelId_possible = value;
/* 1063 */       return this;
/*      */     }
/*      */     
/*      */     public Builder messageId(String value) {
/* 1067 */       this.messageId_possible = Possible.of(Id.of(value));
/* 1068 */       return this;
/*      */     }
/*      */     
/*      */     public Builder messageId(long value) {
/* 1072 */       this.messageId_possible = Possible.of(Id.of(value));
/* 1073 */       return this;
/*      */     }
/*      */     
/*      */     public Builder messageId(Id value) {
/* 1077 */       this.messageId_possible = Possible.of(value);
/* 1078 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("message_id")
/*      */     public Builder messageId(Possible<Id> value) {
/* 1083 */       this.messageId_possible = value;
/* 1084 */       return this;
/*      */     }
/*      */     
/*      */     public Builder alertSystemMessageId(String value) {
/* 1088 */       this.alertSystemMessageId_possible = Possible.of(Id.of(value));
/* 1089 */       return this;
/*      */     }
/*      */     
/*      */     public Builder alertSystemMessageId(long value) {
/* 1093 */       this.alertSystemMessageId_possible = Possible.of(Id.of(value));
/* 1094 */       return this;
/*      */     }
/*      */     
/*      */     public Builder alertSystemMessageId(Id value) {
/* 1098 */       this.alertSystemMessageId_possible = Possible.of(value);
/* 1099 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("alert_system_message_id")
/*      */     public Builder alertSystemMessageId(Possible<Id> value) {
/* 1104 */       this.alertSystemMessageId_possible = value;
/* 1105 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("content")
/*      */     public final Builder content(String content) {
/* 1115 */       this.content = Objects.<String>requireNonNull(content, "content");
/* 1116 */       this.initBits &= 0xFFFFFFFFFFFFFFFBL;
/* 1117 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder matchedKeyword(String matchedKeyword) {
/* 1126 */       this.matchedKeyword = Objects.<String>requireNonNull(matchedKeyword, "matchedKeyword");
/* 1127 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("matched_keyword")
/*      */     public final Builder matchedKeyword(Optional<String> matchedKeyword) {
/* 1137 */       this.matchedKeyword = matchedKeyword.orElse(null);
/* 1138 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder matchedContent(String matchedContent) {
/* 1147 */       this.matchedContent = Objects.<String>requireNonNull(matchedContent, "matchedContent");
/* 1148 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("matched_content")
/*      */     public final Builder matchedContent(Optional<String> matchedContent) {
/* 1158 */       this.matchedContent = matchedContent.orElse(null);
/* 1159 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ImmutableAutoModActionExecution build() {
/* 1168 */       if (this.initBits != 0L) {
/* 1169 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*      */       }
/* 1171 */       return new ImmutableAutoModActionExecution(null, 
/*      */           
/* 1173 */           guildId_build(), this.action, 
/*      */           
/* 1175 */           ruleId_build(), this.ruleTriggerType, 
/*      */           
/* 1177 */           userId_build(), 
/* 1178 */           channelId_build(), 
/* 1179 */           messageId_build(), 
/* 1180 */           alertSystemMessageId_build(), this.content, this.matchedKeyword, this.matchedContent);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private String formatRequiredAttributesMessage() {
/* 1187 */       List<String> attributes = new ArrayList<>();
/* 1188 */       if ((this.initBits & 0x1L) != 0L) attributes.add("action"); 
/* 1189 */       if ((this.initBits & 0x2L) != 0L) attributes.add("ruleTriggerType"); 
/* 1190 */       if ((this.initBits & 0x4L) != 0L) attributes.add("content"); 
/* 1191 */       return "Cannot build AutoModActionExecution, some of required attributes are not set " + attributes;
/*      */     }
/*      */     
/*      */     private Id guildId_build() {
/* 1195 */       return this.guildId_id;
/*      */     }
/*      */     
/*      */     private Id ruleId_build() {
/* 1199 */       return this.ruleId_id;
/*      */     }
/*      */     
/*      */     private Id userId_build() {
/* 1203 */       return this.userId_id;
/*      */     }
/*      */     
/*      */     private Possible<Id> channelId_build() {
/* 1207 */       return this.channelId_possible;
/*      */     }
/*      */     
/*      */     private Possible<Id> messageId_build() {
/* 1211 */       return this.messageId_possible;
/*      */     }
/*      */     
/*      */     private Possible<Id> alertSystemMessageId_build() {
/* 1215 */       return this.alertSystemMessageId_possible;
/*      */     }
/*      */     
/*      */     private Builder() {}
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\gateway\ImmutableAutoModActionExecution.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */