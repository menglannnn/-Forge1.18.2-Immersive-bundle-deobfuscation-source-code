/*     */ package discord4j.discordjson.json.gateway;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.Id;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "MessageDelete", generator = "Immutables")
/*     */ public final class ImmutableMessageDelete
/*     */   implements MessageDelete
/*     */ {
/*     */   private final long id_value;
/*     */   private final long channelId_value;
/*     */   private final long guildId_value;
/*     */   private final boolean guildId_absent;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   
/*     */   private ImmutableMessageDelete(Id id, Id channelId, Possible<Id> guildId) {
/*  35 */     Id id$impl = id;
/*  36 */     Id channelId$impl = channelId;
/*  37 */     Possible<Id> guildId$impl = guildId;
/*  38 */     this.id_value = id$impl.asLong();
/*  39 */     this.channelId_value = channelId$impl.asLong();
/*  40 */     this
/*     */       
/*  42 */       .guildId_value = ((Long)guildId$impl.toOptional().map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  43 */     this.guildId_absent = guildId$impl.isAbsent();
/*  44 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ImmutableMessageDelete(ImmutableMessageDelete original, Id id, Id channelId, Possible<Id> guildId) {
/*  52 */     Id id$impl = id;
/*  53 */     Id channelId$impl = channelId;
/*  54 */     Possible<Id> guildId$impl = guildId;
/*  55 */     this.id_value = id$impl.asLong();
/*  56 */     this.channelId_value = channelId$impl.asLong();
/*  57 */     this
/*     */       
/*  59 */       .guildId_value = ((Long)guildId$impl.toOptional().map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  60 */     this.guildId_absent = guildId$impl.isAbsent();
/*  61 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  67 */   private volatile transient InitShim initShim = new InitShim();
/*     */   
/*     */   @Generated(from = "MessageDelete", generator = "Immutables")
/*     */   private final class InitShim {
/*     */     private String formatInitCycleMessage() {
/*  72 */       List<String> attributes = new ArrayList<>();
/*  73 */       return "Cannot build MessageDelete, attribute initializers form cycle " + attributes;
/*     */     }
/*     */ 
/*     */     
/*     */     private InitShim() {}
/*     */   }
/*     */ 
/*     */   
/*     */   @JsonProperty("id")
/*     */   public Id id() {
/*  83 */     return Id.of(this.id_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("channel_id")
/*     */   public Id channelId() {
/*  92 */     return Id.of(this.channelId_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("guild_id")
/*     */   public Possible<Id> guildId() {
/* 101 */     return this.guildId_absent ? Possible.absent() : 
/* 102 */       Possible.of(Id.of(this.guildId_value));
/*     */   }
/*     */   
/*     */   public ImmutableMessageDelete withId(long value) {
/* 106 */     Id newValue = Id.of(value);
/* 107 */     return new ImmutableMessageDelete(this, newValue, channelId(), guildId());
/*     */   }
/*     */   
/*     */   public ImmutableMessageDelete withId(String value) {
/* 111 */     Id newValue = Id.of(value);
/* 112 */     return new ImmutableMessageDelete(this, newValue, channelId(), guildId());
/*     */   }
/*     */   
/*     */   public ImmutableMessageDelete withChannelId(long value) {
/* 116 */     Id newValue = Id.of(value);
/* 117 */     return new ImmutableMessageDelete(this, id(), newValue, guildId());
/*     */   }
/*     */   
/*     */   public ImmutableMessageDelete withChannelId(String value) {
/* 121 */     Id newValue = Id.of(value);
/* 122 */     return new ImmutableMessageDelete(this, id(), newValue, guildId());
/*     */   }
/*     */   
/*     */   public ImmutableMessageDelete withGuildId(Possible<Id> value) {
/* 126 */     Possible<Id> newValue = Objects.<Possible<Id>>requireNonNull(value);
/* 127 */     return new ImmutableMessageDelete(this, id(), channelId(), newValue);
/*     */   }
/*     */   
/*     */   public ImmutableMessageDelete withGuildId(long value) {
/* 131 */     Possible<Id> newValue = Possible.of(Id.of(value));
/* 132 */     return new ImmutableMessageDelete(this, id(), channelId(), newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 141 */     if (this == another) return true; 
/* 142 */     return (another instanceof ImmutableMessageDelete && 
/* 143 */       equalTo(0, (ImmutableMessageDelete)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableMessageDelete another) {
/* 147 */     return (Objects.equals(Long.valueOf(this.id_value), Long.valueOf(another.id_value)) && 
/* 148 */       Objects.equals(Long.valueOf(this.channelId_value), Long.valueOf(another.channelId_value)) && 
/* 149 */       guildId().equals(another.guildId()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 158 */     int h = 5381;
/* 159 */     h += (h << 5) + Objects.hashCode(Long.valueOf(this.id_value));
/* 160 */     h += (h << 5) + Objects.hashCode(Long.valueOf(this.channelId_value));
/* 161 */     h += (h << 5) + guildId().hashCode();
/* 162 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 171 */     return "MessageDelete{id=" + 
/* 172 */       Objects.toString(Long.valueOf(this.id_value)) + ", channelId=" + 
/* 173 */       Objects.toString(Long.valueOf(this.channelId_value)) + ", guildId=" + 
/* 174 */       guildId().toString() + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "MessageDelete", generator = "Immutables")
/*     */   static final class Json
/*     */     implements MessageDelete
/*     */   {
/*     */     Id id;
/*     */     
/*     */     Id channelId;
/*     */     
/* 190 */     Possible<Id> guildId = Possible.absent();
/*     */     
/*     */     @JsonProperty("id")
/*     */     public void setId(Id id) {
/* 194 */       this.id = id;
/*     */     }
/*     */     @JsonProperty("channel_id")
/*     */     public void setChannelId(Id channelId) {
/* 198 */       this.channelId = channelId;
/*     */     }
/*     */     @JsonProperty("guild_id")
/*     */     public void setGuildId(Possible<Id> guildId) {
/* 202 */       this.guildId = guildId;
/*     */     }
/*     */     public Id id() {
/* 205 */       throw new UnsupportedOperationException();
/*     */     } public Id channelId() {
/* 207 */       throw new UnsupportedOperationException();
/*     */     } public Possible<Id> guildId() {
/* 209 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableMessageDelete fromJson(Json json) {
/* 220 */     Builder builder = builder();
/* 221 */     if (json.id != null) {
/* 222 */       builder.id(json.id);
/*     */     }
/* 224 */     if (json.channelId != null) {
/* 225 */       builder.channelId(json.channelId);
/*     */     }
/* 227 */     if (json.guildId != null) {
/* 228 */       builder.guildId(json.guildId);
/*     */     }
/* 230 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableMessageDelete of(Id id, Id channelId, Possible<Id> guildId) {
/* 241 */     return new ImmutableMessageDelete(id, channelId, guildId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableMessageDelete copyOf(MessageDelete instance) {
/* 252 */     if (instance instanceof ImmutableMessageDelete) {
/* 253 */       return (ImmutableMessageDelete)instance;
/*     */     }
/* 255 */     return builder()
/* 256 */       .from(instance)
/* 257 */       .build();
/*     */   }
/*     */   
/*     */   public boolean isGuildIdPresent() {
/* 261 */     return !this.guildId_absent;
/*     */   }
/*     */   
/*     */   public long guildIdOrElse(long defaultValue) {
/* 265 */     return !this.guildId_absent ? this.guildId_value : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 280 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "MessageDelete", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/* 292 */     private Id id_id = null;
/* 293 */     private Id channelId_id = null;
/* 294 */     private Possible<Id> guildId_possible = Possible.absent();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(MessageDelete instance) {
/* 307 */       Objects.requireNonNull(instance, "instance");
/* 308 */       id(instance.id());
/* 309 */       channelId(instance.channelId());
/* 310 */       guildId(instance.guildId());
/* 311 */       return this;
/*     */     }
/*     */     
/*     */     public Builder id(String value) {
/* 315 */       this.id_id = Id.of(value);
/* 316 */       return this;
/*     */     }
/*     */     
/*     */     public Builder id(long value) {
/* 320 */       this.id_id = Id.of(value);
/* 321 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("id")
/*     */     public Builder id(Id value) {
/* 326 */       this.id_id = value;
/* 327 */       return this;
/*     */     }
/*     */     
/*     */     public Builder channelId(String value) {
/* 331 */       this.channelId_id = Id.of(value);
/* 332 */       return this;
/*     */     }
/*     */     
/*     */     public Builder channelId(long value) {
/* 336 */       this.channelId_id = Id.of(value);
/* 337 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("channel_id")
/*     */     public Builder channelId(Id value) {
/* 342 */       this.channelId_id = value;
/* 343 */       return this;
/*     */     }
/*     */     
/*     */     public Builder guildId(String value) {
/* 347 */       this.guildId_possible = Possible.of(Id.of(value));
/* 348 */       return this;
/*     */     }
/*     */     
/*     */     public Builder guildId(long value) {
/* 352 */       this.guildId_possible = Possible.of(Id.of(value));
/* 353 */       return this;
/*     */     }
/*     */     
/*     */     public Builder guildId(Id value) {
/* 357 */       this.guildId_possible = Possible.of(value);
/* 358 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("guild_id")
/*     */     public Builder guildId(Possible<Id> value) {
/* 363 */       this.guildId_possible = value;
/* 364 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableMessageDelete build() {
/* 373 */       return new ImmutableMessageDelete(null, id_build(), channelId_build(), guildId_build());
/*     */     }
/*     */     
/*     */     private Id id_build() {
/* 377 */       return this.id_id;
/*     */     }
/*     */     
/*     */     private Id channelId_build() {
/* 381 */       return this.channelId_id;
/*     */     }
/*     */     
/*     */     private Possible<Id> guildId_build() {
/* 385 */       return this.guildId_possible;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\gateway\ImmutableMessageDelete.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */