/*    */ package discord4j.discordjson.json.gateway;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonProperty;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import discord4j.discordjson.Id;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ @JsonSerialize(as = ImmutableVoiceServerUpdate.class)
/*    */ @JsonDeserialize(as = ImmutableVoiceServerUpdate.class)
/*    */ @Immutable
/*    */ public interface VoiceServerUpdate
/*    */   extends Dispatch {
/*    */   static ImmutableVoiceServerUpdate.Builder builder() {
/* 16 */     return ImmutableVoiceServerUpdate.builder();
/*    */   }
/*    */   
/*    */   String token();
/*    */   
/*    */   @JsonProperty("guild_id")
/*    */   Id guildId();
/*    */   
/*    */   @Nullable
/*    */   String endpoint();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\gateway\VoiceServerUpdate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */