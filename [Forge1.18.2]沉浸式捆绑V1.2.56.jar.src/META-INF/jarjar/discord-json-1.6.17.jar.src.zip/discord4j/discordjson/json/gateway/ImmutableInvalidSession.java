/*     */ package discord4j.discordjson.json.gateway;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "InvalidSession", generator = "Immutables")
/*     */ public final class ImmutableInvalidSession
/*     */   implements InvalidSession
/*     */ {
/*     */   private final boolean resumable;
/*     */   
/*     */   private ImmutableInvalidSession(boolean resumable) {
/*  23 */     this.resumable = resumable;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean resumable() {
/*  31 */     return this.resumable;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableInvalidSession withResumable(boolean value) {
/*  41 */     if (this.resumable == value) return this; 
/*  42 */     return new ImmutableInvalidSession(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/*  51 */     if (this == another) return true; 
/*  52 */     return (another instanceof ImmutableInvalidSession && 
/*  53 */       equalTo(0, (ImmutableInvalidSession)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableInvalidSession another) {
/*  57 */     return (this.resumable == another.resumable);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  66 */     int h = 5381;
/*  67 */     h += (h << 5) + Boolean.hashCode(this.resumable);
/*  68 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/*  77 */     return "InvalidSession{resumable=" + this.resumable + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableInvalidSession of(boolean resumable) {
/*  88 */     return new ImmutableInvalidSession(resumable);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableInvalidSession copyOf(InvalidSession instance) {
/*  99 */     if (instance instanceof ImmutableInvalidSession) {
/* 100 */       return (ImmutableInvalidSession)instance;
/*     */     }
/* 102 */     return (new Builder())
/* 103 */       .from(instance)
/* 104 */       .build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "InvalidSession", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_RESUMABLE = 1L;
/*     */ 
/*     */ 
/*     */     
/* 117 */     private long initBits = 1L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private boolean resumable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(InvalidSession instance) {
/* 140 */       Objects.requireNonNull(instance, "instance");
/* 141 */       resumable(instance.resumable());
/* 142 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder resumable(boolean resumable) {
/* 151 */       this.resumable = resumable;
/* 152 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 153 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableInvalidSession build() {
/* 162 */       if (this.initBits != 0L) {
/* 163 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 165 */       return new ImmutableInvalidSession(this.resumable);
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 169 */       List<String> attributes = new ArrayList<>();
/* 170 */       if ((this.initBits & 0x1L) != 0L) attributes.add("resumable"); 
/* 171 */       return "Cannot build InvalidSession, some of required attributes are not set " + attributes;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\gateway\ImmutableInvalidSession.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */