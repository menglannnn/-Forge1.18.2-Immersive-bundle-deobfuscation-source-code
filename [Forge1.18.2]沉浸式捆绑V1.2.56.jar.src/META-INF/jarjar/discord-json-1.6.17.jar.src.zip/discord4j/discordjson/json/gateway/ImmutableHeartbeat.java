/*     */ package discord4j.discordjson.json.gateway;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "Heartbeat", generator = "Immutables")
/*     */ public final class ImmutableHeartbeat
/*     */   implements Heartbeat
/*     */ {
/*     */   private final int seq;
/*     */   
/*     */   private ImmutableHeartbeat(int seq) {
/*  27 */     this.seq = seq;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("seq")
/*     */   public int seq() {
/*  36 */     return this.seq;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableHeartbeat withSeq(int value) {
/*  46 */     if (this.seq == value) return this; 
/*  47 */     return new ImmutableHeartbeat(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/*  56 */     if (this == another) return true; 
/*  57 */     return (another instanceof ImmutableHeartbeat && 
/*  58 */       equalTo(0, (ImmutableHeartbeat)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableHeartbeat another) {
/*  62 */     return (this.seq == another.seq);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  71 */     int h = 5381;
/*  72 */     h += (h << 5) + this.seq;
/*  73 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/*  82 */     return "Heartbeat{seq=" + this.seq + "}";
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "Heartbeat", generator = "Immutables")
/*     */   static final class Json
/*     */     implements Heartbeat
/*     */   {
/*     */     int seq;
/*     */     
/*     */     boolean seqIsSet;
/*     */ 
/*     */     
/*     */     @JsonProperty("seq")
/*     */     public void setSeq(int seq) {
/* 100 */       this.seq = seq;
/* 101 */       this.seqIsSet = true;
/*     */     }
/*     */     public int seq() {
/* 104 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableHeartbeat fromJson(Json json) {
/* 115 */     Builder builder = builder();
/* 116 */     if (json.seqIsSet) {
/* 117 */       builder.seq(json.seq);
/*     */     }
/* 119 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableHeartbeat of(int seq) {
/* 128 */     return new ImmutableHeartbeat(seq);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableHeartbeat copyOf(Heartbeat instance) {
/* 139 */     if (instance instanceof ImmutableHeartbeat) {
/* 140 */       return (ImmutableHeartbeat)instance;
/*     */     }
/* 142 */     return builder()
/* 143 */       .from(instance)
/* 144 */       .build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 157 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "Heartbeat", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_SEQ = 1L;
/*     */ 
/*     */ 
/*     */     
/* 170 */     private long initBits = 1L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private int seq;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(Heartbeat instance) {
/* 185 */       Objects.requireNonNull(instance, "instance");
/* 186 */       seq(instance.seq());
/* 187 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("seq")
/*     */     public final Builder seq(int seq) {
/* 197 */       this.seq = seq;
/* 198 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 199 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableHeartbeat build() {
/* 208 */       if (this.initBits != 0L) {
/* 209 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 211 */       return new ImmutableHeartbeat(this.seq);
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 215 */       List<String> attributes = new ArrayList<>();
/* 216 */       if ((this.initBits & 0x1L) != 0L) attributes.add("seq"); 
/* 217 */       return "Cannot build Heartbeat, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\gateway\ImmutableHeartbeat.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */