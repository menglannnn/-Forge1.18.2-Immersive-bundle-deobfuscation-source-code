/*     */ package discord4j.discordjson.json.gateway;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.annotation.JsonUnwrapped;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.json.PartialMessageData;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "MessageUpdate", generator = "Immutables")
/*     */ public final class ImmutableMessageUpdate
/*     */   implements MessageUpdate
/*     */ {
/*     */   private final PartialMessageData message;
/*     */   
/*     */   private ImmutableMessageUpdate(PartialMessageData message) {
/*  29 */     this.message = Objects.<PartialMessageData>requireNonNull(message, "message");
/*     */   }
/*     */   
/*     */   private ImmutableMessageUpdate(ImmutableMessageUpdate original, PartialMessageData message) {
/*  33 */     this.message = message;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("message")
/*     */   @JsonUnwrapped
/*     */   public PartialMessageData message() {
/*  43 */     return this.message;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableMessageUpdate withMessage(PartialMessageData value) {
/*  53 */     if (this.message == value) return this; 
/*  54 */     PartialMessageData newValue = Objects.<PartialMessageData>requireNonNull(value, "message");
/*  55 */     return new ImmutableMessageUpdate(this, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/*  64 */     if (this == another) return true; 
/*  65 */     return (another instanceof ImmutableMessageUpdate && 
/*  66 */       equalTo(0, (ImmutableMessageUpdate)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableMessageUpdate another) {
/*  70 */     return this.message.equals(another.message);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  79 */     int h = 5381;
/*  80 */     h += (h << 5) + this.message.hashCode();
/*  81 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/*  90 */     return "MessageUpdate{message=" + this.message + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "MessageUpdate", generator = "Immutables")
/*     */   static final class Json
/*     */     implements MessageUpdate
/*     */   {
/*     */     PartialMessageData message;
/*     */ 
/*     */     
/*     */     @JsonProperty("message")
/*     */     @JsonUnwrapped
/*     */     public void setMessage(PartialMessageData message) {
/* 108 */       this.message = message;
/*     */     }
/*     */     public PartialMessageData message() {
/* 111 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableMessageUpdate fromJson(Json json) {
/* 122 */     Builder builder = builder();
/* 123 */     if (json.message != null) {
/* 124 */       builder.message(json.message);
/*     */     }
/* 126 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableMessageUpdate of(PartialMessageData message) {
/* 135 */     return new ImmutableMessageUpdate(message);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableMessageUpdate copyOf(MessageUpdate instance) {
/* 146 */     if (instance instanceof ImmutableMessageUpdate) {
/* 147 */       return (ImmutableMessageUpdate)instance;
/*     */     }
/* 149 */     return builder()
/* 150 */       .from(instance)
/* 151 */       .build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 164 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "MessageUpdate", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_MESSAGE = 1L;
/*     */ 
/*     */ 
/*     */     
/* 177 */     private long initBits = 1L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private PartialMessageData message;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(MessageUpdate instance) {
/* 192 */       Objects.requireNonNull(instance, "instance");
/* 193 */       message(instance.message());
/* 194 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("message")
/*     */     @JsonUnwrapped
/*     */     public final Builder message(PartialMessageData message) {
/* 205 */       this.message = Objects.<PartialMessageData>requireNonNull(message, "message");
/* 206 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 207 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableMessageUpdate build() {
/* 216 */       if (this.initBits != 0L) {
/* 217 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 219 */       return new ImmutableMessageUpdate(null, this.message);
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 223 */       List<String> attributes = new ArrayList<>();
/* 224 */       if ((this.initBits & 0x1L) != 0L) attributes.add("message"); 
/* 225 */       return "Cannot build MessageUpdate, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\gateway\ImmutableMessageUpdate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */