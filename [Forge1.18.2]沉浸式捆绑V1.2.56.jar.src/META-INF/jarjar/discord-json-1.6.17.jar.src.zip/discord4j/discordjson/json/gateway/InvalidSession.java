/*    */ package discord4j.discordjson.json.gateway;
/*    */ 
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ import org.immutables.value.Value.Style;
/*    */ 
/*    */ @JsonSerialize(as = ImmutableInvalidSession.class)
/*    */ @JsonDeserialize(as = ImmutableInvalidSession.class)
/*    */ @Immutable
/*    */ @Style(builder = "new", jacksonIntegration = false, allParameters = true)
/*    */ public interface InvalidSession
/*    */   extends PayloadData
/*    */ {
/*    */   static ImmutableInvalidSession.Builder builder() {
/* 16 */     return new ImmutableInvalidSession.Builder();
/*    */   }
/*    */   
/*    */   boolean resumable();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\gateway\InvalidSession.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */