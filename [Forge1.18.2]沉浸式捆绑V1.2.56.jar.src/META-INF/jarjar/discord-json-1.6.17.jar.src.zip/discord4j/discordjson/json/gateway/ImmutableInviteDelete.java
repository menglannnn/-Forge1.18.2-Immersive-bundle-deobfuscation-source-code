/*     */ package discord4j.discordjson.json.gateway;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.Id;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "InviteDelete", generator = "Immutables")
/*     */ public final class ImmutableInviteDelete
/*     */   implements InviteDelete
/*     */ {
/*     */   private final long guildId_value;
/*     */   private final long channelId_value;
/*     */   private final String code;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   
/*     */   private ImmutableInviteDelete(Id guildId, Id channelId, String code) {
/*  30 */     Id guildId$impl = guildId;
/*  31 */     Id channelId$impl = channelId;
/*  32 */     this.code = Objects.<String>requireNonNull(code, "code");
/*  33 */     this.guildId_value = guildId$impl.asLong();
/*  34 */     this.channelId_value = channelId$impl.asLong();
/*  35 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ImmutableInviteDelete(ImmutableInviteDelete original, Id guildId, Id channelId, String code) {
/*  43 */     Id guildId$impl = guildId;
/*  44 */     Id channelId$impl = channelId;
/*  45 */     this.code = code;
/*  46 */     this.guildId_value = guildId$impl.asLong();
/*  47 */     this.channelId_value = channelId$impl.asLong();
/*  48 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  54 */   private volatile transient InitShim initShim = new InitShim();
/*     */   
/*     */   @Generated(from = "InviteDelete", generator = "Immutables")
/*     */   private final class InitShim {
/*     */     private String formatInitCycleMessage() {
/*  59 */       List<String> attributes = new ArrayList<>();
/*  60 */       return "Cannot build InviteDelete, attribute initializers form cycle " + attributes;
/*     */     }
/*     */ 
/*     */     
/*     */     private InitShim() {}
/*     */   }
/*     */ 
/*     */   
/*     */   @JsonProperty("guild_id")
/*     */   public Id guildId() {
/*  70 */     return Id.of(this.guildId_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("channel_id")
/*     */   public Id channelId() {
/*  79 */     return Id.of(this.channelId_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("code")
/*     */   public String code() {
/*  88 */     return this.code;
/*     */   }
/*     */   
/*     */   public ImmutableInviteDelete withGuildId(long value) {
/*  92 */     Id newValue = Id.of(value);
/*  93 */     return new ImmutableInviteDelete(this, newValue, channelId(), this.code);
/*     */   }
/*     */   
/*     */   public ImmutableInviteDelete withGuildId(String value) {
/*  97 */     Id newValue = Id.of(value);
/*  98 */     return new ImmutableInviteDelete(this, newValue, channelId(), this.code);
/*     */   }
/*     */   
/*     */   public ImmutableInviteDelete withChannelId(long value) {
/* 102 */     Id newValue = Id.of(value);
/* 103 */     return new ImmutableInviteDelete(this, guildId(), newValue, this.code);
/*     */   }
/*     */   
/*     */   public ImmutableInviteDelete withChannelId(String value) {
/* 107 */     Id newValue = Id.of(value);
/* 108 */     return new ImmutableInviteDelete(this, guildId(), newValue, this.code);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableInviteDelete withCode(String value) {
/* 118 */     String newValue = Objects.<String>requireNonNull(value, "code");
/* 119 */     if (this.code.equals(newValue)) return this; 
/* 120 */     return new ImmutableInviteDelete(this, guildId(), channelId(), newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 129 */     if (this == another) return true; 
/* 130 */     return (another instanceof ImmutableInviteDelete && 
/* 131 */       equalTo(0, (ImmutableInviteDelete)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableInviteDelete another) {
/* 135 */     return (Objects.equals(Long.valueOf(this.guildId_value), Long.valueOf(another.guildId_value)) && 
/* 136 */       Objects.equals(Long.valueOf(this.channelId_value), Long.valueOf(another.channelId_value)) && this.code
/* 137 */       .equals(another.code));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 146 */     int h = 5381;
/* 147 */     h += (h << 5) + Objects.hashCode(Long.valueOf(this.guildId_value));
/* 148 */     h += (h << 5) + Objects.hashCode(Long.valueOf(this.channelId_value));
/* 149 */     h += (h << 5) + this.code.hashCode();
/* 150 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 159 */     return "InviteDelete{guildId=" + 
/* 160 */       Objects.toString(Long.valueOf(this.guildId_value)) + ", channelId=" + 
/* 161 */       Objects.toString(Long.valueOf(this.channelId_value)) + ", code=" + this.code + "}";
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "InviteDelete", generator = "Immutables")
/*     */   static final class Json
/*     */     implements InviteDelete
/*     */   {
/*     */     Id guildId;
/*     */     
/*     */     Id channelId;
/*     */     
/*     */     String code;
/*     */     
/*     */     @JsonProperty("guild_id")
/*     */     public void setGuildId(Id guildId) {
/* 180 */       this.guildId = guildId;
/*     */     }
/*     */     @JsonProperty("channel_id")
/*     */     public void setChannelId(Id channelId) {
/* 184 */       this.channelId = channelId;
/*     */     }
/*     */     @JsonProperty("code")
/*     */     public void setCode(String code) {
/* 188 */       this.code = code;
/*     */     }
/*     */     public Id guildId() {
/* 191 */       throw new UnsupportedOperationException();
/*     */     } public Id channelId() {
/* 193 */       throw new UnsupportedOperationException();
/*     */     } public String code() {
/* 195 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableInviteDelete fromJson(Json json) {
/* 206 */     Builder builder = builder();
/* 207 */     if (json.guildId != null) {
/* 208 */       builder.guildId(json.guildId);
/*     */     }
/* 210 */     if (json.channelId != null) {
/* 211 */       builder.channelId(json.channelId);
/*     */     }
/* 213 */     if (json.code != null) {
/* 214 */       builder.code(json.code);
/*     */     }
/* 216 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableInviteDelete of(Id guildId, Id channelId, String code) {
/* 227 */     return new ImmutableInviteDelete(guildId, channelId, code);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableInviteDelete copyOf(InviteDelete instance) {
/* 238 */     if (instance instanceof ImmutableInviteDelete) {
/* 239 */       return (ImmutableInviteDelete)instance;
/*     */     }
/* 241 */     return builder()
/* 242 */       .from(instance)
/* 243 */       .build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 258 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "InviteDelete", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_CODE = 1L;
/*     */ 
/*     */ 
/*     */     
/* 271 */     private long initBits = 1L;
/*     */     
/* 273 */     private Id guildId_id = null;
/* 274 */     private Id channelId_id = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private String code;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(InviteDelete instance) {
/* 288 */       Objects.requireNonNull(instance, "instance");
/* 289 */       guildId(instance.guildId());
/* 290 */       channelId(instance.channelId());
/* 291 */       code(instance.code());
/* 292 */       return this;
/*     */     }
/*     */     
/*     */     public Builder guildId(String value) {
/* 296 */       this.guildId_id = Id.of(value);
/* 297 */       return this;
/*     */     }
/*     */     
/*     */     public Builder guildId(long value) {
/* 301 */       this.guildId_id = Id.of(value);
/* 302 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("guild_id")
/*     */     public Builder guildId(Id value) {
/* 307 */       this.guildId_id = value;
/* 308 */       return this;
/*     */     }
/*     */     
/*     */     public Builder channelId(String value) {
/* 312 */       this.channelId_id = Id.of(value);
/* 313 */       return this;
/*     */     }
/*     */     
/*     */     public Builder channelId(long value) {
/* 317 */       this.channelId_id = Id.of(value);
/* 318 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("channel_id")
/*     */     public Builder channelId(Id value) {
/* 323 */       this.channelId_id = value;
/* 324 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("code")
/*     */     public final Builder code(String code) {
/* 334 */       this.code = Objects.<String>requireNonNull(code, "code");
/* 335 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 336 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableInviteDelete build() {
/* 345 */       if (this.initBits != 0L) {
/* 346 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 348 */       return new ImmutableInviteDelete(null, guildId_build(), channelId_build(), this.code);
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 352 */       List<String> attributes = new ArrayList<>();
/* 353 */       if ((this.initBits & 0x1L) != 0L) attributes.add("code"); 
/* 354 */       return "Cannot build InviteDelete, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Id guildId_build() {
/* 358 */       return this.guildId_id;
/*     */     }
/*     */     
/*     */     private Id channelId_build() {
/* 362 */       return this.channelId_id;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\gateway\ImmutableInviteDelete.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */