/*    */ package discord4j.discordjson.json.gateway;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonProperty;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import discord4j.discordjson.Id;
/*    */ import discord4j.discordjson.json.UserData;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ @JsonSerialize(as = ImmutableGuildBanRemove.class)
/*    */ @JsonDeserialize(as = ImmutableGuildBanRemove.class)
/*    */ @Immutable
/*    */ public interface GuildBanRemove
/*    */   extends Dispatch {
/*    */   static ImmutableGuildBanRemove.Builder builder() {
/* 16 */     return ImmutableGuildBanRemove.builder();
/*    */   }
/*    */   
/*    */   @JsonProperty("guild_id")
/*    */   Id guildId();
/*    */   
/*    */   UserData user();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\gateway\GuildBanRemove.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */