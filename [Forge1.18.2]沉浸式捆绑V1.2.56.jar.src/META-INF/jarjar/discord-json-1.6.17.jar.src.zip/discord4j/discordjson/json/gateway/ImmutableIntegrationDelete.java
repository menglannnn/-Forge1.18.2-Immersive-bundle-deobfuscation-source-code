/*     */ package discord4j.discordjson.json.gateway;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "IntegrationDelete", generator = "Immutables")
/*     */ public final class ImmutableIntegrationDelete
/*     */   implements IntegrationDelete
/*     */ {
/*     */   private final String id;
/*     */   private final String guildId;
/*     */   private final String applicationId_value;
/*     */   private final boolean applicationId_absent;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   private volatile transient InitShim initShim;
/*     */   
/*     */   private ImmutableIntegrationDelete(String id, String guildId, Possible<String> applicationId) {
/*  58 */     this.initShim = new InitShim(); this.id = Objects.<String>requireNonNull(id, "id"); this.guildId = Objects.<String>requireNonNull(guildId, "guildId"); Possible<String> applicationId$impl = applicationId; this.applicationId_value = applicationId$impl.toOptional().orElse(null); this.applicationId_absent = applicationId$impl.isAbsent(); this.initShim = null; } private ImmutableIntegrationDelete(ImmutableIntegrationDelete original, String id, String guildId, Possible<String> applicationId) { this.initShim = new InitShim(); this.id = id;
/*     */     this.guildId = guildId;
/*     */     Possible<String> applicationId$impl = applicationId;
/*     */     this.applicationId_value = applicationId$impl.toOptional().orElse(null);
/*     */     this.applicationId_absent = applicationId$impl.isAbsent();
/*  63 */     this.initShim = null; } @Generated(from = "IntegrationDelete", generator = "Immutables") private final class InitShim { private InitShim() {} private String formatInitCycleMessage() { List<String> attributes = new ArrayList<>();
/*  64 */       return "Cannot build IntegrationDelete, attribute initializers form cycle " + attributes; }
/*     */      }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("id")
/*     */   public String id() {
/*  74 */     return this.id;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("guild_id")
/*     */   public String guildId() {
/*  83 */     return this.guildId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("application_id")
/*     */   public Possible<String> applicationId() {
/*  92 */     return this.applicationId_absent ? Possible.absent() : Possible.of(this.applicationId_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableIntegrationDelete withId(String value) {
/* 102 */     String newValue = Objects.<String>requireNonNull(value, "id");
/* 103 */     if (this.id.equals(newValue)) return this; 
/* 104 */     return new ImmutableIntegrationDelete(this, newValue, this.guildId, applicationId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableIntegrationDelete withGuildId(String value) {
/* 114 */     String newValue = Objects.<String>requireNonNull(value, "guildId");
/* 115 */     if (this.guildId.equals(newValue)) return this; 
/* 116 */     return new ImmutableIntegrationDelete(this, this.id, newValue, applicationId());
/*     */   }
/*     */   
/*     */   public ImmutableIntegrationDelete withApplicationId(Possible<String> value) {
/* 120 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/* 121 */     return new ImmutableIntegrationDelete(this, this.id, this.guildId, newValue);
/*     */   }
/*     */   
/*     */   public ImmutableIntegrationDelete withApplicationId(String value) {
/* 125 */     Possible<String> newValue = Possible.of(value);
/* 126 */     return new ImmutableIntegrationDelete(this, this.id, this.guildId, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 135 */     if (this == another) return true; 
/* 136 */     return (another instanceof ImmutableIntegrationDelete && 
/* 137 */       equalTo(0, (ImmutableIntegrationDelete)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableIntegrationDelete another) {
/* 141 */     return (this.id.equals(another.id) && this.guildId
/* 142 */       .equals(another.guildId) && 
/* 143 */       applicationId().equals(another.applicationId()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 152 */     int h = 5381;
/* 153 */     h += (h << 5) + this.id.hashCode();
/* 154 */     h += (h << 5) + this.guildId.hashCode();
/* 155 */     h += (h << 5) + applicationId().hashCode();
/* 156 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 165 */     return "IntegrationDelete{id=" + this.id + ", guildId=" + this.guildId + ", applicationId=" + 
/*     */ 
/*     */       
/* 168 */       applicationId().toString() + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "IntegrationDelete", generator = "Immutables")
/*     */   static final class Json
/*     */     implements IntegrationDelete
/*     */   {
/*     */     String id;
/*     */     
/*     */     String guildId;
/*     */     
/* 184 */     Possible<String> applicationId = Possible.absent();
/*     */     
/*     */     @JsonProperty("id")
/*     */     public void setId(String id) {
/* 188 */       this.id = id;
/*     */     }
/*     */     @JsonProperty("guild_id")
/*     */     public void setGuildId(String guildId) {
/* 192 */       this.guildId = guildId;
/*     */     }
/*     */     @JsonProperty("application_id")
/*     */     public void setApplicationId(Possible<String> applicationId) {
/* 196 */       this.applicationId = applicationId;
/*     */     }
/*     */     public String id() {
/* 199 */       throw new UnsupportedOperationException();
/*     */     } public String guildId() {
/* 201 */       throw new UnsupportedOperationException();
/*     */     } public Possible<String> applicationId() {
/* 203 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableIntegrationDelete fromJson(Json json) {
/* 214 */     Builder builder = builder();
/* 215 */     if (json.id != null) {
/* 216 */       builder.id(json.id);
/*     */     }
/* 218 */     if (json.guildId != null) {
/* 219 */       builder.guildId(json.guildId);
/*     */     }
/* 221 */     if (json.applicationId != null) {
/* 222 */       builder.applicationId(json.applicationId);
/*     */     }
/* 224 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableIntegrationDelete of(String id, String guildId, Possible<String> applicationId) {
/* 235 */     return new ImmutableIntegrationDelete(id, guildId, applicationId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableIntegrationDelete copyOf(IntegrationDelete instance) {
/* 246 */     if (instance instanceof ImmutableIntegrationDelete) {
/* 247 */       return (ImmutableIntegrationDelete)instance;
/*     */     }
/* 249 */     return builder()
/* 250 */       .from(instance)
/* 251 */       .build();
/*     */   }
/*     */   
/*     */   public boolean isApplicationIdPresent() {
/* 255 */     return !this.applicationId_absent;
/*     */   }
/*     */   
/*     */   public String applicationIdOrElse(String defaultValue) {
/* 259 */     return !this.applicationId_absent ? this.applicationId_value : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 274 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "IntegrationDelete", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_ID = 1L;
/*     */ 
/*     */     
/*     */     private static final long INIT_BIT_GUILD_ID = 2L;
/*     */ 
/*     */     
/* 288 */     private long initBits = 3L;
/*     */     
/* 290 */     private Possible<String> applicationId_possible = Possible.absent();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private String id;
/*     */ 
/*     */ 
/*     */     
/*     */     private String guildId;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(IntegrationDelete instance) {
/* 305 */       Objects.requireNonNull(instance, "instance");
/* 306 */       id(instance.id());
/* 307 */       guildId(instance.guildId());
/* 308 */       applicationId(instance.applicationId());
/* 309 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("id")
/*     */     public final Builder id(String id) {
/* 319 */       this.id = Objects.<String>requireNonNull(id, "id");
/* 320 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 321 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("guild_id")
/*     */     public final Builder guildId(String guildId) {
/* 331 */       this.guildId = Objects.<String>requireNonNull(guildId, "guildId");
/* 332 */       this.initBits &= 0xFFFFFFFFFFFFFFFDL;
/* 333 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("application_id")
/*     */     public Builder applicationId(Possible<String> value) {
/* 338 */       this.applicationId_possible = value;
/* 339 */       return this;
/*     */     }
/*     */     
/*     */     public Builder applicationId(String value) {
/* 343 */       this.applicationId_possible = Possible.of(value);
/* 344 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableIntegrationDelete build() {
/* 353 */       if (this.initBits != 0L) {
/* 354 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 356 */       return new ImmutableIntegrationDelete(null, this.id, this.guildId, applicationId_build());
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 360 */       List<String> attributes = new ArrayList<>();
/* 361 */       if ((this.initBits & 0x1L) != 0L) attributes.add("id"); 
/* 362 */       if ((this.initBits & 0x2L) != 0L) attributes.add("guildId"); 
/* 363 */       return "Cannot build IntegrationDelete, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Possible<String> applicationId_build() {
/* 367 */       return this.applicationId_possible;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\gateway\ImmutableIntegrationDelete.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */