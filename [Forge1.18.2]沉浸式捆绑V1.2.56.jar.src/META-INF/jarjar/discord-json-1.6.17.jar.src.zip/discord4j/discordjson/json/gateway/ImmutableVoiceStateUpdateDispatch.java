/*     */ package discord4j.discordjson.json.gateway;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.annotation.JsonUnwrapped;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.json.VoiceStateData;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "VoiceStateUpdateDispatch", generator = "Immutables")
/*     */ public final class ImmutableVoiceStateUpdateDispatch
/*     */   implements VoiceStateUpdateDispatch
/*     */ {
/*     */   private final VoiceStateData voiceState;
/*     */   
/*     */   private ImmutableVoiceStateUpdateDispatch(VoiceStateData voiceState) {
/*  30 */     this.voiceState = Objects.<VoiceStateData>requireNonNull(voiceState, "voiceState");
/*     */   }
/*     */   
/*     */   private ImmutableVoiceStateUpdateDispatch(ImmutableVoiceStateUpdateDispatch original, VoiceStateData voiceState) {
/*  34 */     this.voiceState = voiceState;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("voiceState")
/*     */   @JsonUnwrapped
/*     */   public VoiceStateData voiceState() {
/*  44 */     return this.voiceState;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableVoiceStateUpdateDispatch withVoiceState(VoiceStateData value) {
/*  54 */     if (this.voiceState == value) return this; 
/*  55 */     VoiceStateData newValue = Objects.<VoiceStateData>requireNonNull(value, "voiceState");
/*  56 */     return new ImmutableVoiceStateUpdateDispatch(this, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/*  65 */     if (this == another) return true; 
/*  66 */     return (another instanceof ImmutableVoiceStateUpdateDispatch && 
/*  67 */       equalTo(0, (ImmutableVoiceStateUpdateDispatch)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableVoiceStateUpdateDispatch another) {
/*  71 */     return this.voiceState.equals(another.voiceState);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  80 */     int h = 5381;
/*  81 */     h += (h << 5) + this.voiceState.hashCode();
/*  82 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/*  91 */     return "VoiceStateUpdateDispatch{voiceState=" + this.voiceState + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "VoiceStateUpdateDispatch", generator = "Immutables")
/*     */   static final class Json
/*     */     implements VoiceStateUpdateDispatch
/*     */   {
/*     */     VoiceStateData voiceState;
/*     */ 
/*     */     
/*     */     @JsonProperty("voiceState")
/*     */     @JsonUnwrapped
/*     */     public void setVoiceState(VoiceStateData voiceState) {
/* 109 */       this.voiceState = voiceState;
/*     */     }
/*     */     public VoiceStateData voiceState() {
/* 112 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableVoiceStateUpdateDispatch fromJson(Json json) {
/* 123 */     Builder builder = builder();
/* 124 */     if (json.voiceState != null) {
/* 125 */       builder.voiceState(json.voiceState);
/*     */     }
/* 127 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableVoiceStateUpdateDispatch of(VoiceStateData voiceState) {
/* 136 */     return new ImmutableVoiceStateUpdateDispatch(voiceState);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableVoiceStateUpdateDispatch copyOf(VoiceStateUpdateDispatch instance) {
/* 147 */     if (instance instanceof ImmutableVoiceStateUpdateDispatch) {
/* 148 */       return (ImmutableVoiceStateUpdateDispatch)instance;
/*     */     }
/* 150 */     return builder()
/* 151 */       .from(instance)
/* 152 */       .build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 165 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "VoiceStateUpdateDispatch", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_VOICE_STATE = 1L;
/*     */ 
/*     */ 
/*     */     
/* 178 */     private long initBits = 1L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private VoiceStateData voiceState;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(VoiceStateUpdateDispatch instance) {
/* 193 */       Objects.requireNonNull(instance, "instance");
/* 194 */       voiceState(instance.voiceState());
/* 195 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("voiceState")
/*     */     @JsonUnwrapped
/*     */     public final Builder voiceState(VoiceStateData voiceState) {
/* 206 */       this.voiceState = Objects.<VoiceStateData>requireNonNull(voiceState, "voiceState");
/* 207 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 208 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableVoiceStateUpdateDispatch build() {
/* 217 */       if (this.initBits != 0L) {
/* 218 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 220 */       return new ImmutableVoiceStateUpdateDispatch(null, this.voiceState);
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 224 */       List<String> attributes = new ArrayList<>();
/* 225 */       if ((this.initBits & 0x1L) != 0L) attributes.add("voiceState"); 
/* 226 */       return "Cannot build VoiceStateUpdateDispatch, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\gateway\ImmutableVoiceStateUpdateDispatch.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */