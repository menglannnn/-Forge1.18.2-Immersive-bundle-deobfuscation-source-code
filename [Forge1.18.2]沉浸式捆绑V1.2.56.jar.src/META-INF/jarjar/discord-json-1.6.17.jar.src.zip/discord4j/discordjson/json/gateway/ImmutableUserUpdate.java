/*     */ package discord4j.discordjson.json.gateway;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.annotation.JsonUnwrapped;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.json.UserData;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "UserUpdate", generator = "Immutables")
/*     */ public final class ImmutableUserUpdate
/*     */   implements UserUpdate
/*     */ {
/*     */   private final UserData user;
/*     */   
/*     */   private ImmutableUserUpdate(UserData user) {
/*  29 */     this.user = Objects.<UserData>requireNonNull(user, "user");
/*     */   }
/*     */   
/*     */   private ImmutableUserUpdate(ImmutableUserUpdate original, UserData user) {
/*  33 */     this.user = user;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("user")
/*     */   @JsonUnwrapped
/*     */   public UserData user() {
/*  43 */     return this.user;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableUserUpdate withUser(UserData value) {
/*  53 */     if (this.user == value) return this; 
/*  54 */     UserData newValue = Objects.<UserData>requireNonNull(value, "user");
/*  55 */     return new ImmutableUserUpdate(this, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/*  64 */     if (this == another) return true; 
/*  65 */     return (another instanceof ImmutableUserUpdate && 
/*  66 */       equalTo(0, (ImmutableUserUpdate)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableUserUpdate another) {
/*  70 */     return this.user.equals(another.user);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  79 */     int h = 5381;
/*  80 */     h += (h << 5) + this.user.hashCode();
/*  81 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/*  90 */     return "UserUpdate{user=" + this.user + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "UserUpdate", generator = "Immutables")
/*     */   static final class Json
/*     */     implements UserUpdate
/*     */   {
/*     */     UserData user;
/*     */ 
/*     */     
/*     */     @JsonProperty("user")
/*     */     @JsonUnwrapped
/*     */     public void setUser(UserData user) {
/* 108 */       this.user = user;
/*     */     }
/*     */     public UserData user() {
/* 111 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableUserUpdate fromJson(Json json) {
/* 122 */     Builder builder = builder();
/* 123 */     if (json.user != null) {
/* 124 */       builder.user(json.user);
/*     */     }
/* 126 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableUserUpdate of(UserData user) {
/* 135 */     return new ImmutableUserUpdate(user);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableUserUpdate copyOf(UserUpdate instance) {
/* 146 */     if (instance instanceof ImmutableUserUpdate) {
/* 147 */       return (ImmutableUserUpdate)instance;
/*     */     }
/* 149 */     return builder()
/* 150 */       .from(instance)
/* 151 */       .build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 164 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "UserUpdate", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_USER = 1L;
/*     */ 
/*     */ 
/*     */     
/* 177 */     private long initBits = 1L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private UserData user;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(UserUpdate instance) {
/* 192 */       Objects.requireNonNull(instance, "instance");
/* 193 */       user(instance.user());
/* 194 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("user")
/*     */     @JsonUnwrapped
/*     */     public final Builder user(UserData user) {
/* 205 */       this.user = Objects.<UserData>requireNonNull(user, "user");
/* 206 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 207 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableUserUpdate build() {
/* 216 */       if (this.initBits != 0L) {
/* 217 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 219 */       return new ImmutableUserUpdate(null, this.user);
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 223 */       List<String> attributes = new ArrayList<>();
/* 224 */       if ((this.initBits & 0x1L) != 0L) attributes.add("user"); 
/* 225 */       return "Cannot build UserUpdate, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\gateway\ImmutableUserUpdate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */