/*      */ package discord4j.discordjson.json.gateway;
/*      */ 
/*      */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*      */ import com.fasterxml.jackson.annotation.JsonCreator;
/*      */ import com.fasterxml.jackson.annotation.JsonProperty;
/*      */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*      */ import discord4j.discordjson.Id;
/*      */ import discord4j.discordjson.json.UserData;
/*      */ import discord4j.discordjson.possible.Possible;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.List;
/*      */ import java.util.Objects;
/*      */ import java.util.Optional;
/*      */ import org.immutables.value.Generated;
/*      */ import reactor.util.annotation.Nullable;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ @Generated(from = "GuildMemberUpdate", generator = "Immutables")
/*      */ public final class ImmutableGuildMemberUpdate
/*      */   implements GuildMemberUpdate
/*      */ {
/*      */   private final long guildId_value;
/*      */   private final List<String> roles;
/*      */   private final UserData user;
/*      */   private final String nick_value;
/*      */   private final boolean nick_absent;
/*      */   private final String avatar;
/*      */   private final String joinedAt;
/*      */   private final String premiumSince_value;
/*      */   private final boolean premiumSince_absent;
/*      */   private final Boolean pending_value;
/*      */   private final boolean pending_absent;
/*      */   private final String communicationDisabledUntil_value;
/*      */   private final boolean communicationDisabledUntil_absent;
/*      */   private static final byte STAGE_INITIALIZING = -1;
/*      */   private static final byte STAGE_UNINITIALIZED = 0;
/*      */   private static final byte STAGE_INITIALIZED = 1;
/*      */   
/*      */   private ImmutableGuildMemberUpdate(Id guildId, Iterable<String> roles, UserData user, Possible<Optional<String>> nick, Optional<String> avatar, Optional<String> joinedAt, Possible<Optional<String>> premiumSince, Possible<Boolean> pending, Possible<Optional<String>> communicationDisabledUntil) {
/*   56 */     Id guildId$impl = guildId;
/*   57 */     this.roles = createUnmodifiableList(false, createSafeList(roles, true, false));
/*   58 */     this.user = Objects.<UserData>requireNonNull(user, "user");
/*   59 */     Possible<Optional<String>> nick$impl = nick;
/*   60 */     this.avatar = avatar.orElse(null);
/*   61 */     this.joinedAt = joinedAt.orElse(null);
/*   62 */     Possible<Optional<String>> premiumSince$impl = premiumSince;
/*   63 */     Possible<Boolean> pending$impl = pending;
/*   64 */     Possible<Optional<String>> communicationDisabledUntil$impl = communicationDisabledUntil;
/*   65 */     this.guildId_value = guildId$impl.asLong();
/*   66 */     this.nick_value = Possible.flatOpt(nick$impl).orElse(null);
/*   67 */     this.nick_absent = nick$impl.isAbsent();
/*   68 */     this.premiumSince_value = Possible.flatOpt(premiumSince$impl).orElse(null);
/*   69 */     this.premiumSince_absent = premiumSince$impl.isAbsent();
/*   70 */     this.pending_value = pending$impl.toOptional().orElse(null);
/*   71 */     this.pending_absent = pending$impl.isAbsent();
/*   72 */     this.communicationDisabledUntil_value = Possible.flatOpt(communicationDisabledUntil$impl).orElse(null);
/*   73 */     this.communicationDisabledUntil_absent = communicationDisabledUntil$impl.isAbsent();
/*   74 */     this.initShim = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ImmutableGuildMemberUpdate(ImmutableGuildMemberUpdate original, Id guildId, List<String> roles, UserData user, Possible<Optional<String>> nick, String avatar, String joinedAt, Possible<Optional<String>> premiumSince, Possible<Boolean> pending, Possible<Optional<String>> communicationDisabledUntil) {
/*   88 */     Id guildId$impl = guildId;
/*   89 */     this.roles = roles;
/*   90 */     this.user = user;
/*   91 */     Possible<Optional<String>> nick$impl = nick;
/*   92 */     this.avatar = avatar;
/*   93 */     this.joinedAt = joinedAt;
/*   94 */     Possible<Optional<String>> premiumSince$impl = premiumSince;
/*   95 */     Possible<Boolean> pending$impl = pending;
/*   96 */     Possible<Optional<String>> communicationDisabledUntil$impl = communicationDisabledUntil;
/*   97 */     this.guildId_value = guildId$impl.asLong();
/*   98 */     this.nick_value = Possible.flatOpt(nick$impl).orElse(null);
/*   99 */     this.nick_absent = nick$impl.isAbsent();
/*  100 */     this.premiumSince_value = Possible.flatOpt(premiumSince$impl).orElse(null);
/*  101 */     this.premiumSince_absent = premiumSince$impl.isAbsent();
/*  102 */     this.pending_value = pending$impl.toOptional().orElse(null);
/*  103 */     this.pending_absent = pending$impl.isAbsent();
/*  104 */     this.communicationDisabledUntil_value = Possible.flatOpt(communicationDisabledUntil$impl).orElse(null);
/*  105 */     this.communicationDisabledUntil_absent = communicationDisabledUntil$impl.isAbsent();
/*  106 */     this.initShim = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  112 */   private volatile transient InitShim initShim = new InitShim();
/*      */   
/*      */   @Generated(from = "GuildMemberUpdate", generator = "Immutables")
/*      */   private final class InitShim {
/*      */     private String formatInitCycleMessage() {
/*  117 */       List<String> attributes = new ArrayList<>();
/*  118 */       return "Cannot build GuildMemberUpdate, attribute initializers form cycle " + attributes;
/*      */     }
/*      */ 
/*      */     
/*      */     private InitShim() {}
/*      */   }
/*      */ 
/*      */   
/*      */   @JsonProperty("guild_id")
/*      */   public Id guildId() {
/*  128 */     return Id.of(this.guildId_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("roles")
/*      */   public List<String> roles() {
/*  137 */     return this.roles;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("user")
/*      */   public UserData user() {
/*  146 */     return this.user;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("nick")
/*      */   public Possible<Optional<String>> nick() {
/*  155 */     return this.nick_absent ? Possible.absent() : 
/*  156 */       Possible.of(Optional.ofNullable(this.nick_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("avatar")
/*      */   public Optional<String> avatar() {
/*  165 */     return Optional.ofNullable(this.avatar);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("joined_at")
/*      */   public Optional<String> joinedAt() {
/*  174 */     return Optional.ofNullable(this.joinedAt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("premium_since")
/*      */   public Possible<Optional<String>> premiumSince() {
/*  183 */     return this.premiumSince_absent ? Possible.absent() : 
/*  184 */       Possible.of(Optional.ofNullable(this.premiumSince_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("pending")
/*      */   public Possible<Boolean> pending() {
/*  193 */     return this.pending_absent ? Possible.absent() : Possible.of(this.pending_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("communication_disabled_until")
/*      */   public Possible<Optional<String>> communicationDisabledUntil() {
/*  202 */     return this.communicationDisabledUntil_absent ? Possible.absent() : 
/*  203 */       Possible.of(Optional.ofNullable(this.communicationDisabledUntil_value));
/*      */   }
/*      */   
/*      */   public ImmutableGuildMemberUpdate withGuildId(long value) {
/*  207 */     Id newValue = Id.of(value);
/*  208 */     return new ImmutableGuildMemberUpdate(this, newValue, this.roles, this.user, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  213 */         nick(), this.avatar, this.joinedAt, 
/*      */ 
/*      */         
/*  216 */         premiumSince(), 
/*  217 */         pending(), 
/*  218 */         communicationDisabledUntil());
/*      */   }
/*      */   
/*      */   public ImmutableGuildMemberUpdate withGuildId(String value) {
/*  222 */     Id newValue = Id.of(value);
/*  223 */     return new ImmutableGuildMemberUpdate(this, newValue, this.roles, this.user, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  228 */         nick(), this.avatar, this.joinedAt, 
/*      */ 
/*      */         
/*  231 */         premiumSince(), 
/*  232 */         pending(), 
/*  233 */         communicationDisabledUntil());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildMemberUpdate withRoles(String... elements) {
/*  242 */     List<String> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/*  243 */     return new ImmutableGuildMemberUpdate(this, 
/*      */         
/*  245 */         guildId(), newValue, this.user, 
/*      */ 
/*      */         
/*  248 */         nick(), this.avatar, this.joinedAt, 
/*      */ 
/*      */         
/*  251 */         premiumSince(), 
/*  252 */         pending(), 
/*  253 */         communicationDisabledUntil());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildMemberUpdate withRoles(Iterable<String> elements) {
/*  263 */     if (this.roles == elements) return this; 
/*  264 */     List<String> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/*  265 */     return new ImmutableGuildMemberUpdate(this, 
/*      */         
/*  267 */         guildId(), newValue, this.user, 
/*      */ 
/*      */         
/*  270 */         nick(), this.avatar, this.joinedAt, 
/*      */ 
/*      */         
/*  273 */         premiumSince(), 
/*  274 */         pending(), 
/*  275 */         communicationDisabledUntil());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildMemberUpdate withUser(UserData value) {
/*  285 */     if (this.user == value) return this; 
/*  286 */     UserData newValue = Objects.<UserData>requireNonNull(value, "user");
/*  287 */     return new ImmutableGuildMemberUpdate(this, 
/*      */         
/*  289 */         guildId(), this.roles, newValue, 
/*      */ 
/*      */         
/*  292 */         nick(), this.avatar, this.joinedAt, 
/*      */ 
/*      */         
/*  295 */         premiumSince(), 
/*  296 */         pending(), 
/*  297 */         communicationDisabledUntil());
/*      */   }
/*      */   
/*      */   public ImmutableGuildMemberUpdate withNick(Possible<Optional<String>> value) {
/*  301 */     Possible<Optional<String>> newValue = Objects.<Possible<Optional<String>>>requireNonNull(value);
/*  302 */     return new ImmutableGuildMemberUpdate(this, 
/*      */         
/*  304 */         guildId(), this.roles, this.user, newValue, this.avatar, this.joinedAt, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  310 */         premiumSince(), 
/*  311 */         pending(), 
/*  312 */         communicationDisabledUntil());
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public ImmutableGuildMemberUpdate withNick(@Nullable String value) {
/*  317 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/*  318 */     return new ImmutableGuildMemberUpdate(this, 
/*      */         
/*  320 */         guildId(), this.roles, this.user, newValue, this.avatar, this.joinedAt, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  326 */         premiumSince(), 
/*  327 */         pending(), 
/*  328 */         communicationDisabledUntil());
/*      */   }
/*      */   
/*      */   public ImmutableGuildMemberUpdate withNickOrNull(@Nullable String value) {
/*  332 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/*  333 */     return new ImmutableGuildMemberUpdate(this, 
/*      */         
/*  335 */         guildId(), this.roles, this.user, newValue, this.avatar, this.joinedAt, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  341 */         premiumSince(), 
/*  342 */         pending(), 
/*  343 */         communicationDisabledUntil());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildMemberUpdate withAvatar(String value) {
/*  352 */     String newValue = Objects.<String>requireNonNull(value, "avatar");
/*  353 */     if (Objects.equals(this.avatar, newValue)) return this; 
/*  354 */     return new ImmutableGuildMemberUpdate(this, 
/*      */         
/*  356 */         guildId(), this.roles, this.user, 
/*      */ 
/*      */         
/*  359 */         nick(), newValue, this.joinedAt, 
/*      */ 
/*      */         
/*  362 */         premiumSince(), 
/*  363 */         pending(), 
/*  364 */         communicationDisabledUntil());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildMemberUpdate withAvatar(Optional<String> optional) {
/*  374 */     String value = optional.orElse(null);
/*  375 */     if (Objects.equals(this.avatar, value)) return this; 
/*  376 */     return new ImmutableGuildMemberUpdate(this, 
/*      */         
/*  378 */         guildId(), this.roles, this.user, 
/*      */ 
/*      */         
/*  381 */         nick(), value, this.joinedAt, 
/*      */ 
/*      */         
/*  384 */         premiumSince(), 
/*  385 */         pending(), 
/*  386 */         communicationDisabledUntil());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildMemberUpdate withJoinedAt(String value) {
/*  395 */     String newValue = Objects.<String>requireNonNull(value, "joinedAt");
/*  396 */     if (Objects.equals(this.joinedAt, newValue)) return this; 
/*  397 */     return new ImmutableGuildMemberUpdate(this, 
/*      */         
/*  399 */         guildId(), this.roles, this.user, 
/*      */ 
/*      */         
/*  402 */         nick(), this.avatar, newValue, 
/*      */ 
/*      */         
/*  405 */         premiumSince(), 
/*  406 */         pending(), 
/*  407 */         communicationDisabledUntil());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildMemberUpdate withJoinedAt(Optional<String> optional) {
/*  417 */     String value = optional.orElse(null);
/*  418 */     if (Objects.equals(this.joinedAt, value)) return this; 
/*  419 */     return new ImmutableGuildMemberUpdate(this, 
/*      */         
/*  421 */         guildId(), this.roles, this.user, 
/*      */ 
/*      */         
/*  424 */         nick(), this.avatar, value, 
/*      */ 
/*      */         
/*  427 */         premiumSince(), 
/*  428 */         pending(), 
/*  429 */         communicationDisabledUntil());
/*      */   }
/*      */   
/*      */   public ImmutableGuildMemberUpdate withPremiumSince(Possible<Optional<String>> value) {
/*  433 */     Possible<Optional<String>> newValue = Objects.<Possible<Optional<String>>>requireNonNull(value);
/*  434 */     return new ImmutableGuildMemberUpdate(this, 
/*      */         
/*  436 */         guildId(), this.roles, this.user, 
/*      */ 
/*      */         
/*  439 */         nick(), this.avatar, this.joinedAt, newValue, 
/*      */ 
/*      */ 
/*      */         
/*  443 */         pending(), 
/*  444 */         communicationDisabledUntil());
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public ImmutableGuildMemberUpdate withPremiumSince(@Nullable String value) {
/*  449 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/*  450 */     return new ImmutableGuildMemberUpdate(this, 
/*      */         
/*  452 */         guildId(), this.roles, this.user, 
/*      */ 
/*      */         
/*  455 */         nick(), this.avatar, this.joinedAt, newValue, 
/*      */ 
/*      */ 
/*      */         
/*  459 */         pending(), 
/*  460 */         communicationDisabledUntil());
/*      */   }
/*      */   
/*      */   public ImmutableGuildMemberUpdate withPremiumSinceOrNull(@Nullable String value) {
/*  464 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/*  465 */     return new ImmutableGuildMemberUpdate(this, 
/*      */         
/*  467 */         guildId(), this.roles, this.user, 
/*      */ 
/*      */         
/*  470 */         nick(), this.avatar, this.joinedAt, newValue, 
/*      */ 
/*      */ 
/*      */         
/*  474 */         pending(), 
/*  475 */         communicationDisabledUntil());
/*      */   }
/*      */   
/*      */   public ImmutableGuildMemberUpdate withPending(Possible<Boolean> value) {
/*  479 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/*  480 */     return new ImmutableGuildMemberUpdate(this, 
/*      */         
/*  482 */         guildId(), this.roles, this.user, 
/*      */ 
/*      */         
/*  485 */         nick(), this.avatar, this.joinedAt, 
/*      */ 
/*      */         
/*  488 */         premiumSince(), newValue, 
/*      */         
/*  490 */         communicationDisabledUntil());
/*      */   }
/*      */   
/*      */   public ImmutableGuildMemberUpdate withPending(Boolean value) {
/*  494 */     Possible<Boolean> newValue = Possible.of(value);
/*  495 */     return new ImmutableGuildMemberUpdate(this, 
/*      */         
/*  497 */         guildId(), this.roles, this.user, 
/*      */ 
/*      */         
/*  500 */         nick(), this.avatar, this.joinedAt, 
/*      */ 
/*      */         
/*  503 */         premiumSince(), newValue, 
/*      */         
/*  505 */         communicationDisabledUntil());
/*      */   }
/*      */   
/*      */   public ImmutableGuildMemberUpdate withCommunicationDisabledUntil(Possible<Optional<String>> value) {
/*  509 */     Possible<Optional<String>> newValue = Objects.<Possible<Optional<String>>>requireNonNull(value);
/*  510 */     return new ImmutableGuildMemberUpdate(this, 
/*      */         
/*  512 */         guildId(), this.roles, this.user, 
/*      */ 
/*      */         
/*  515 */         nick(), this.avatar, this.joinedAt, 
/*      */ 
/*      */         
/*  518 */         premiumSince(), 
/*  519 */         pending(), newValue);
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public ImmutableGuildMemberUpdate withCommunicationDisabledUntil(@Nullable String value) {
/*  525 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/*  526 */     return new ImmutableGuildMemberUpdate(this, 
/*      */         
/*  528 */         guildId(), this.roles, this.user, 
/*      */ 
/*      */         
/*  531 */         nick(), this.avatar, this.joinedAt, 
/*      */ 
/*      */         
/*  534 */         premiumSince(), 
/*  535 */         pending(), newValue);
/*      */   }
/*      */ 
/*      */   
/*      */   public ImmutableGuildMemberUpdate withCommunicationDisabledUntilOrNull(@Nullable String value) {
/*  540 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/*  541 */     return new ImmutableGuildMemberUpdate(this, 
/*      */         
/*  543 */         guildId(), this.roles, this.user, 
/*      */ 
/*      */         
/*  546 */         nick(), this.avatar, this.joinedAt, 
/*      */ 
/*      */         
/*  549 */         premiumSince(), 
/*  550 */         pending(), newValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean equals(Object another) {
/*  560 */     if (this == another) return true; 
/*  561 */     return (another instanceof ImmutableGuildMemberUpdate && 
/*  562 */       equalTo(0, (ImmutableGuildMemberUpdate)another));
/*      */   }
/*      */   
/*      */   private boolean equalTo(int synthetic, ImmutableGuildMemberUpdate another) {
/*  566 */     return (Objects.equals(Long.valueOf(this.guildId_value), Long.valueOf(another.guildId_value)) && this.roles
/*  567 */       .equals(another.roles) && this.user
/*  568 */       .equals(another.user) && 
/*  569 */       nick().equals(another.nick()) && 
/*  570 */       Objects.equals(this.avatar, another.avatar) && 
/*  571 */       Objects.equals(this.joinedAt, another.joinedAt) && 
/*  572 */       premiumSince().equals(another.premiumSince()) && 
/*  573 */       pending().equals(another.pending()) && 
/*  574 */       communicationDisabledUntil().equals(another.communicationDisabledUntil()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int hashCode() {
/*  583 */     int h = 5381;
/*  584 */     h += (h << 5) + Objects.hashCode(Long.valueOf(this.guildId_value));
/*  585 */     h += (h << 5) + this.roles.hashCode();
/*  586 */     h += (h << 5) + this.user.hashCode();
/*  587 */     h += (h << 5) + nick().hashCode();
/*  588 */     h += (h << 5) + Objects.hashCode(this.avatar);
/*  589 */     h += (h << 5) + Objects.hashCode(this.joinedAt);
/*  590 */     h += (h << 5) + premiumSince().hashCode();
/*  591 */     h += (h << 5) + pending().hashCode();
/*  592 */     h += (h << 5) + communicationDisabledUntil().hashCode();
/*  593 */     return h;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/*  602 */     StringBuilder builder = new StringBuilder("GuildMemberUpdate{");
/*  603 */     builder.append("guildId=").append(Objects.toString(Long.valueOf(this.guildId_value)));
/*  604 */     builder.append(", ");
/*  605 */     builder.append("roles=").append(this.roles);
/*  606 */     builder.append(", ");
/*  607 */     builder.append("user=").append(this.user);
/*  608 */     builder.append(", ");
/*  609 */     builder.append("nick=").append(nick().toString());
/*  610 */     if (this.avatar != null) {
/*  611 */       builder.append(", ");
/*  612 */       builder.append("avatar=").append(this.avatar);
/*      */     } 
/*  614 */     if (this.joinedAt != null) {
/*  615 */       builder.append(", ");
/*  616 */       builder.append("joinedAt=").append(this.joinedAt);
/*      */     } 
/*  618 */     builder.append(", ");
/*  619 */     builder.append("premiumSince=").append(premiumSince().toString());
/*  620 */     builder.append(", ");
/*  621 */     builder.append("pending=").append(pending().toString());
/*  622 */     builder.append(", ");
/*  623 */     builder.append("communicationDisabledUntil=").append(communicationDisabledUntil().toString());
/*  624 */     return builder.append("}").toString();
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonDeserialize
/*      */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*      */   @Generated(from = "GuildMemberUpdate", generator = "Immutables")
/*      */   static final class Json
/*      */     implements GuildMemberUpdate
/*      */   {
/*      */     Id guildId;
/*      */     
/*  637 */     List<String> roles = Collections.emptyList();
/*      */     
/*      */     UserData user;
/*  640 */     Possible<Optional<String>> nick = Possible.absent();
/*      */     
/*  642 */     Optional<String> avatar = Optional.empty();
/*  643 */     Optional<String> joinedAt = Optional.empty();
/*      */     
/*  645 */     Possible<Optional<String>> premiumSince = Possible.absent();
/*      */ 
/*      */     
/*  648 */     Possible<Boolean> pending = Possible.absent();
/*      */ 
/*      */     
/*  651 */     Possible<Optional<String>> communicationDisabledUntil = Possible.absent();
/*      */     
/*      */     @JsonProperty("guild_id")
/*      */     public void setGuildId(Id guildId) {
/*  655 */       this.guildId = guildId;
/*      */     }
/*      */     @JsonProperty("roles")
/*      */     public void setRoles(List<String> roles) {
/*  659 */       this.roles = roles;
/*      */     }
/*      */     @JsonProperty("user")
/*      */     public void setUser(UserData user) {
/*  663 */       this.user = user;
/*      */     }
/*      */     @JsonProperty("nick")
/*      */     public void setNick(Possible<Optional<String>> nick) {
/*  667 */       this.nick = nick;
/*      */     }
/*      */     @JsonProperty("avatar")
/*      */     public void setAvatar(Optional<String> avatar) {
/*  671 */       this.avatar = avatar;
/*      */     }
/*      */     @JsonProperty("joined_at")
/*      */     public void setJoinedAt(Optional<String> joinedAt) {
/*  675 */       this.joinedAt = joinedAt;
/*      */     }
/*      */     @JsonProperty("premium_since")
/*      */     public void setPremiumSince(Possible<Optional<String>> premiumSince) {
/*  679 */       this.premiumSince = premiumSince;
/*      */     }
/*      */     @JsonProperty("pending")
/*      */     public void setPending(Possible<Boolean> pending) {
/*  683 */       this.pending = pending;
/*      */     }
/*      */     @JsonProperty("communication_disabled_until")
/*      */     public void setCommunicationDisabledUntil(Possible<Optional<String>> communicationDisabledUntil) {
/*  687 */       this.communicationDisabledUntil = communicationDisabledUntil;
/*      */     }
/*      */     public Id guildId() {
/*  690 */       throw new UnsupportedOperationException();
/*      */     } public List<String> roles() {
/*  692 */       throw new UnsupportedOperationException();
/*      */     } public UserData user() {
/*  694 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Optional<String>> nick() {
/*  696 */       throw new UnsupportedOperationException();
/*      */     } public Optional<String> avatar() {
/*  698 */       throw new UnsupportedOperationException();
/*      */     } public Optional<String> joinedAt() {
/*  700 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Optional<String>> premiumSince() {
/*  702 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Boolean> pending() {
/*  704 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Optional<String>> communicationDisabledUntil() {
/*  706 */       throw new UnsupportedOperationException();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*      */   static ImmutableGuildMemberUpdate fromJson(Json json) {
/*  717 */     Builder builder = builder();
/*  718 */     if (json.guildId != null) {
/*  719 */       builder.guildId(json.guildId);
/*      */     }
/*  721 */     if (json.roles != null) {
/*  722 */       builder.addAllRoles(json.roles);
/*      */     }
/*  724 */     if (json.user != null) {
/*  725 */       builder.user(json.user);
/*      */     }
/*  727 */     if (json.nick != null) {
/*  728 */       builder.nick(json.nick);
/*      */     }
/*  730 */     if (json.avatar != null) {
/*  731 */       builder.avatar(json.avatar);
/*      */     }
/*  733 */     if (json.joinedAt != null) {
/*  734 */       builder.joinedAt(json.joinedAt);
/*      */     }
/*  736 */     if (json.premiumSince != null) {
/*  737 */       builder.premiumSince(json.premiumSince);
/*      */     }
/*  739 */     if (json.pending != null) {
/*  740 */       builder.pending(json.pending);
/*      */     }
/*  742 */     if (json.communicationDisabledUntil != null) {
/*  743 */       builder.communicationDisabledUntil(json.communicationDisabledUntil);
/*      */     }
/*  745 */     return builder.build();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableGuildMemberUpdate of(Id guildId, List<String> roles, UserData user, Possible<Optional<String>> nick, Optional<String> avatar, Optional<String> joinedAt, Possible<Optional<String>> premiumSince, Possible<Boolean> pending, Possible<Optional<String>> communicationDisabledUntil) {
/*  762 */     return of(guildId, roles, user, nick, avatar, joinedAt, premiumSince, pending, communicationDisabledUntil);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableGuildMemberUpdate of(Id guildId, Iterable<String> roles, UserData user, Possible<Optional<String>> nick, Optional<String> avatar, Optional<String> joinedAt, Possible<Optional<String>> premiumSince, Possible<Boolean> pending, Possible<Optional<String>> communicationDisabledUntil) {
/*  779 */     return new ImmutableGuildMemberUpdate(guildId, roles, user, nick, avatar, joinedAt, premiumSince, pending, communicationDisabledUntil);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableGuildMemberUpdate copyOf(GuildMemberUpdate instance) {
/*  790 */     if (instance instanceof ImmutableGuildMemberUpdate) {
/*  791 */       return (ImmutableGuildMemberUpdate)instance;
/*      */     }
/*  793 */     return builder()
/*  794 */       .from(instance)
/*  795 */       .build();
/*      */   }
/*      */   
/*      */   public boolean isNickPresent() {
/*  799 */     return !this.nick_absent;
/*      */   }
/*      */   
/*      */   public String nickOrElse(String defaultValue) {
/*  803 */     return !this.nick_absent ? this.nick_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isPremiumSincePresent() {
/*  807 */     return !this.premiumSince_absent;
/*      */   }
/*      */   
/*      */   public String premiumSinceOrElse(String defaultValue) {
/*  811 */     return !this.premiumSince_absent ? this.premiumSince_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isPendingPresent() {
/*  815 */     return !this.pending_absent;
/*      */   }
/*      */   
/*      */   public Boolean pendingOrElse(Boolean defaultValue) {
/*  819 */     return !this.pending_absent ? this.pending_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isCommunicationDisabledUntilPresent() {
/*  823 */     return !this.communicationDisabledUntil_absent;
/*      */   }
/*      */   
/*      */   public String communicationDisabledUntilOrElse(String defaultValue) {
/*  827 */     return !this.communicationDisabledUntil_absent ? this.communicationDisabledUntil_value : defaultValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Builder builder() {
/*  848 */     return new Builder();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Generated(from = "GuildMemberUpdate", generator = "Immutables")
/*      */   public static final class Builder
/*      */   {
/*      */     private static final long INIT_BIT_USER = 1L;
/*      */ 
/*      */ 
/*      */     
/*  861 */     private long initBits = 1L;
/*      */     
/*  863 */     private Id guildId_id = null;
/*  864 */     private Possible<Optional<String>> nick_possible = Possible.absent();
/*  865 */     private Possible<Optional<String>> premiumSince_possible = Possible.absent();
/*  866 */     private Possible<Boolean> pending_possible = Possible.absent();
/*  867 */     private Possible<Optional<String>> communicationDisabledUntil_possible = Possible.absent();
/*  868 */     private List<String> roles = new ArrayList<>();
/*      */ 
/*      */ 
/*      */     
/*      */     private UserData user;
/*      */ 
/*      */ 
/*      */     
/*      */     private String avatar;
/*      */ 
/*      */ 
/*      */     
/*      */     private String joinedAt;
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder from(GuildMemberUpdate instance) {
/*  885 */       Objects.requireNonNull(instance, "instance");
/*  886 */       guildId(instance.guildId());
/*  887 */       addAllRoles(instance.roles());
/*  888 */       user(instance.user());
/*  889 */       nick(instance.nick());
/*  890 */       Optional<String> avatarOptional = instance.avatar();
/*  891 */       if (avatarOptional.isPresent()) {
/*  892 */         avatar(avatarOptional);
/*      */       }
/*  894 */       Optional<String> joinedAtOptional = instance.joinedAt();
/*  895 */       if (joinedAtOptional.isPresent()) {
/*  896 */         joinedAt(joinedAtOptional);
/*      */       }
/*  898 */       premiumSince(instance.premiumSince());
/*  899 */       pending(instance.pending());
/*  900 */       communicationDisabledUntil(instance.communicationDisabledUntil());
/*  901 */       return this;
/*      */     }
/*      */     
/*      */     public Builder guildId(String value) {
/*  905 */       this.guildId_id = Id.of(value);
/*  906 */       return this;
/*      */     }
/*      */     
/*      */     public Builder guildId(long value) {
/*  910 */       this.guildId_id = Id.of(value);
/*  911 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("guild_id")
/*      */     public Builder guildId(Id value) {
/*  916 */       this.guildId_id = value;
/*  917 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addRole(String element) {
/*  926 */       this.roles.add(Objects.<String>requireNonNull(element, "roles element"));
/*  927 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addRoles(String... elements) {
/*  936 */       for (String element : elements) {
/*  937 */         this.roles.add(Objects.<String>requireNonNull(element, "roles element"));
/*      */       }
/*  939 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("roles")
/*      */     public final Builder roles(Iterable<String> elements) {
/*  950 */       this.roles.clear();
/*  951 */       return addAllRoles(elements);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addAllRoles(Iterable<String> elements) {
/*  960 */       for (String element : elements) {
/*  961 */         this.roles.add(Objects.<String>requireNonNull(element, "roles element"));
/*      */       }
/*  963 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("user")
/*      */     public final Builder user(UserData user) {
/*  973 */       this.user = Objects.<UserData>requireNonNull(user, "user");
/*  974 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/*  975 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("nick")
/*      */     public Builder nick(Possible<Optional<String>> value) {
/*  980 */       this.nick_possible = value;
/*  981 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public Builder nick(@Nullable String value) {
/*  986 */       this.nick_possible = Possible.of(Optional.ofNullable(value));
/*  987 */       return this;
/*      */     }
/*      */     
/*      */     public Builder nickOrNull(@Nullable String value) {
/*  991 */       this.nick_possible = Possible.of(Optional.ofNullable(value));
/*  992 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder avatar(String avatar) {
/* 1001 */       this.avatar = Objects.<String>requireNonNull(avatar, "avatar");
/* 1002 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("avatar")
/*      */     public final Builder avatar(Optional<String> avatar) {
/* 1012 */       this.avatar = avatar.orElse(null);
/* 1013 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder joinedAt(String joinedAt) {
/* 1022 */       this.joinedAt = Objects.<String>requireNonNull(joinedAt, "joinedAt");
/* 1023 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("joined_at")
/*      */     public final Builder joinedAt(Optional<String> joinedAt) {
/* 1033 */       this.joinedAt = joinedAt.orElse(null);
/* 1034 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("premium_since")
/*      */     public Builder premiumSince(Possible<Optional<String>> value) {
/* 1039 */       this.premiumSince_possible = value;
/* 1040 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public Builder premiumSince(@Nullable String value) {
/* 1045 */       this.premiumSince_possible = Possible.of(Optional.ofNullable(value));
/* 1046 */       return this;
/*      */     }
/*      */     
/*      */     public Builder premiumSinceOrNull(@Nullable String value) {
/* 1050 */       this.premiumSince_possible = Possible.of(Optional.ofNullable(value));
/* 1051 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("pending")
/*      */     public Builder pending(Possible<Boolean> value) {
/* 1056 */       this.pending_possible = value;
/* 1057 */       return this;
/*      */     }
/*      */     
/*      */     public Builder pending(Boolean value) {
/* 1061 */       this.pending_possible = Possible.of(value);
/* 1062 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("communication_disabled_until")
/*      */     public Builder communicationDisabledUntil(Possible<Optional<String>> value) {
/* 1067 */       this.communicationDisabledUntil_possible = value;
/* 1068 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public Builder communicationDisabledUntil(@Nullable String value) {
/* 1073 */       this.communicationDisabledUntil_possible = Possible.of(Optional.ofNullable(value));
/* 1074 */       return this;
/*      */     }
/*      */     
/*      */     public Builder communicationDisabledUntilOrNull(@Nullable String value) {
/* 1078 */       this.communicationDisabledUntil_possible = Possible.of(Optional.ofNullable(value));
/* 1079 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ImmutableGuildMemberUpdate build() {
/* 1088 */       if (this.initBits != 0L) {
/* 1089 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*      */       }
/* 1091 */       return new ImmutableGuildMemberUpdate(null, 
/*      */           
/* 1093 */           guildId_build(), ImmutableGuildMemberUpdate
/* 1094 */           .createUnmodifiableList(true, (List)this.roles), this.user, 
/*      */           
/* 1096 */           nick_build(), this.avatar, this.joinedAt, 
/*      */ 
/*      */           
/* 1099 */           premiumSince_build(), 
/* 1100 */           pending_build(), 
/* 1101 */           communicationDisabledUntil_build());
/*      */     }
/*      */     
/*      */     private String formatRequiredAttributesMessage() {
/* 1105 */       List<String> attributes = new ArrayList<>();
/* 1106 */       if ((this.initBits & 0x1L) != 0L) attributes.add("user"); 
/* 1107 */       return "Cannot build GuildMemberUpdate, some of required attributes are not set " + attributes;
/*      */     }
/*      */     
/*      */     private Id guildId_build() {
/* 1111 */       return this.guildId_id;
/*      */     }
/*      */     
/*      */     private Possible<Optional<String>> nick_build() {
/* 1115 */       return this.nick_possible;
/*      */     }
/*      */     
/*      */     private Possible<Optional<String>> premiumSince_build() {
/* 1119 */       return this.premiumSince_possible;
/*      */     }
/*      */     
/*      */     private Possible<Boolean> pending_build() {
/* 1123 */       return this.pending_possible;
/*      */     }
/*      */     
/*      */     private Possible<Optional<String>> communicationDisabledUntil_build() {
/* 1127 */       return this.communicationDisabledUntil_possible;
/*      */     }
/*      */     private Builder() {} }
/*      */   
/*      */   private static <T> List<T> createSafeList(Iterable<? extends T> iterable, boolean checkNulls, boolean skipNulls) {
/*      */     ArrayList<T> list;
/* 1133 */     if (iterable instanceof Collection) {
/* 1134 */       int size = ((Collection)iterable).size();
/* 1135 */       if (size == 0) return Collections.emptyList(); 
/* 1136 */       list = new ArrayList<>();
/*      */     } else {
/* 1138 */       list = new ArrayList<>();
/*      */     } 
/* 1140 */     for (T element : iterable) {
/* 1141 */       if (skipNulls && element == null)
/* 1142 */         continue;  if (checkNulls) Objects.requireNonNull(element, "element"); 
/* 1143 */       list.add(element);
/*      */     } 
/* 1145 */     return list;
/*      */   }
/*      */   
/*      */   private static <T> List<T> createUnmodifiableList(boolean clone, List<T> list) {
/* 1149 */     switch (list.size()) { case 0:
/* 1150 */         return Collections.emptyList();
/* 1151 */       case 1: return Collections.singletonList(list.get(0)); }
/*      */     
/* 1153 */     if (clone) {
/* 1154 */       return Collections.unmodifiableList(new ArrayList<>(list));
/*      */     }
/* 1156 */     if (list instanceof ArrayList) {
/* 1157 */       ((ArrayList)list).trimToSize();
/*      */     }
/* 1159 */     return Collections.unmodifiableList(list);
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\gateway\ImmutableGuildMemberUpdate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */