/*     */ package discord4j.discordjson.json.gateway;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "Resume", generator = "Immutables")
/*     */ public final class ImmutableResume
/*     */   implements Resume
/*     */ {
/*     */   private final String token;
/*     */   private final String sessionId;
/*     */   private final int seq;
/*     */   
/*     */   private ImmutableResume(String token, String sessionId, int seq) {
/*  29 */     this.token = Objects.<String>requireNonNull(token, "token");
/*  30 */     this.sessionId = Objects.<String>requireNonNull(sessionId, "sessionId");
/*  31 */     this.seq = seq;
/*     */   }
/*     */   
/*     */   private ImmutableResume(ImmutableResume original, String token, String sessionId, int seq) {
/*  35 */     this.token = token;
/*  36 */     this.sessionId = sessionId;
/*  37 */     this.seq = seq;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("token")
/*     */   public String token() {
/*  46 */     return this.token;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("session_id")
/*     */   public String sessionId() {
/*  55 */     return this.sessionId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("seq")
/*     */   public int seq() {
/*  64 */     return this.seq;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableResume withToken(String value) {
/*  74 */     String newValue = Objects.<String>requireNonNull(value, "token");
/*  75 */     if (this.token.equals(newValue)) return this; 
/*  76 */     return new ImmutableResume(this, newValue, this.sessionId, this.seq);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableResume withSessionId(String value) {
/*  86 */     String newValue = Objects.<String>requireNonNull(value, "sessionId");
/*  87 */     if (this.sessionId.equals(newValue)) return this; 
/*  88 */     return new ImmutableResume(this, this.token, newValue, this.seq);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableResume withSeq(int value) {
/*  98 */     if (this.seq == value) return this; 
/*  99 */     return new ImmutableResume(this, this.token, this.sessionId, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 108 */     if (this == another) return true; 
/* 109 */     return (another instanceof ImmutableResume && 
/* 110 */       equalTo(0, (ImmutableResume)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableResume another) {
/* 114 */     return (this.token.equals(another.token) && this.sessionId
/* 115 */       .equals(another.sessionId) && this.seq == another.seq);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 125 */     int h = 5381;
/* 126 */     h += (h << 5) + this.token.hashCode();
/* 127 */     h += (h << 5) + this.sessionId.hashCode();
/* 128 */     h += (h << 5) + this.seq;
/* 129 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 138 */     return "Resume{token=" + this.token + ", sessionId=" + this.sessionId + ", seq=" + this.seq + "}";
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "Resume", generator = "Immutables")
/*     */   static final class Json
/*     */     implements Resume
/*     */   {
/*     */     String token;
/*     */     
/*     */     String sessionId;
/*     */     
/*     */     int seq;
/*     */     
/*     */     boolean seqIsSet;
/*     */ 
/*     */     
/*     */     @JsonProperty("token")
/*     */     public void setToken(String token) {
/* 160 */       this.token = token;
/*     */     }
/*     */     @JsonProperty("session_id")
/*     */     public void setSessionId(String sessionId) {
/* 164 */       this.sessionId = sessionId;
/*     */     }
/*     */     @JsonProperty("seq")
/*     */     public void setSeq(int seq) {
/* 168 */       this.seq = seq;
/* 169 */       this.seqIsSet = true;
/*     */     }
/*     */     public String token() {
/* 172 */       throw new UnsupportedOperationException();
/*     */     } public String sessionId() {
/* 174 */       throw new UnsupportedOperationException();
/*     */     } public int seq() {
/* 176 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableResume fromJson(Json json) {
/* 187 */     Builder builder = builder();
/* 188 */     if (json.token != null) {
/* 189 */       builder.token(json.token);
/*     */     }
/* 191 */     if (json.sessionId != null) {
/* 192 */       builder.sessionId(json.sessionId);
/*     */     }
/* 194 */     if (json.seqIsSet) {
/* 195 */       builder.seq(json.seq);
/*     */     }
/* 197 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableResume of(String token, String sessionId, int seq) {
/* 208 */     return new ImmutableResume(token, sessionId, seq);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableResume copyOf(Resume instance) {
/* 219 */     if (instance instanceof ImmutableResume) {
/* 220 */       return (ImmutableResume)instance;
/*     */     }
/* 222 */     return builder()
/* 223 */       .from(instance)
/* 224 */       .build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 239 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "Resume", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_TOKEN = 1L;
/*     */ 
/*     */     
/*     */     private static final long INIT_BIT_SESSION_ID = 2L;
/*     */     
/*     */     private static final long INIT_BIT_SEQ = 4L;
/*     */     
/* 254 */     private long initBits = 7L;
/*     */ 
/*     */ 
/*     */     
/*     */     private String token;
/*     */ 
/*     */ 
/*     */     
/*     */     private String sessionId;
/*     */ 
/*     */ 
/*     */     
/*     */     private int seq;
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(Resume instance) {
/* 271 */       Objects.requireNonNull(instance, "instance");
/* 272 */       token(instance.token());
/* 273 */       sessionId(instance.sessionId());
/* 274 */       seq(instance.seq());
/* 275 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("token")
/*     */     public final Builder token(String token) {
/* 285 */       this.token = Objects.<String>requireNonNull(token, "token");
/* 286 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 287 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("session_id")
/*     */     public final Builder sessionId(String sessionId) {
/* 297 */       this.sessionId = Objects.<String>requireNonNull(sessionId, "sessionId");
/* 298 */       this.initBits &= 0xFFFFFFFFFFFFFFFDL;
/* 299 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("seq")
/*     */     public final Builder seq(int seq) {
/* 309 */       this.seq = seq;
/* 310 */       this.initBits &= 0xFFFFFFFFFFFFFFFBL;
/* 311 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableResume build() {
/* 320 */       if (this.initBits != 0L) {
/* 321 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 323 */       return new ImmutableResume(null, this.token, this.sessionId, this.seq);
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 327 */       List<String> attributes = new ArrayList<>();
/* 328 */       if ((this.initBits & 0x1L) != 0L) attributes.add("token"); 
/* 329 */       if ((this.initBits & 0x2L) != 0L) attributes.add("sessionId"); 
/* 330 */       if ((this.initBits & 0x4L) != 0L) attributes.add("seq"); 
/* 331 */       return "Cannot build Resume, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\gateway\ImmutableResume.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */