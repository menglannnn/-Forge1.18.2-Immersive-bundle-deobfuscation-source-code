/*     */ package discord4j.discordjson.json.gateway;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.annotation.JsonUnwrapped;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.Id;
/*     */ import discord4j.discordjson.json.MemberData;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "GuildMemberAdd", generator = "Immutables")
/*     */ public final class ImmutableGuildMemberAdd
/*     */   implements GuildMemberAdd
/*     */ {
/*     */   private final long guildId_value;
/*     */   private final MemberData member;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   
/*     */   private ImmutableGuildMemberAdd(Id guildId, MemberData member) {
/*  31 */     Id guildId$impl = guildId;
/*  32 */     this.member = Objects.<MemberData>requireNonNull(member, "member");
/*  33 */     this.guildId_value = guildId$impl.asLong();
/*  34 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ImmutableGuildMemberAdd(ImmutableGuildMemberAdd original, Id guildId, MemberData member) {
/*  41 */     Id guildId$impl = guildId;
/*  42 */     this.member = member;
/*  43 */     this.guildId_value = guildId$impl.asLong();
/*  44 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  50 */   private volatile transient InitShim initShim = new InitShim();
/*     */   
/*     */   @Generated(from = "GuildMemberAdd", generator = "Immutables")
/*     */   private final class InitShim {
/*     */     private String formatInitCycleMessage() {
/*  55 */       List<String> attributes = new ArrayList<>();
/*  56 */       return "Cannot build GuildMemberAdd, attribute initializers form cycle " + attributes;
/*     */     }
/*     */ 
/*     */     
/*     */     private InitShim() {}
/*     */   }
/*     */ 
/*     */   
/*     */   @JsonProperty("guild_id")
/*     */   public Id guildId() {
/*  66 */     return Id.of(this.guildId_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("member")
/*     */   @JsonUnwrapped
/*     */   public MemberData member() {
/*  76 */     return this.member;
/*     */   }
/*     */   
/*     */   public ImmutableGuildMemberAdd withGuildId(long value) {
/*  80 */     Id newValue = Id.of(value);
/*  81 */     return new ImmutableGuildMemberAdd(this, newValue, this.member);
/*     */   }
/*     */   
/*     */   public ImmutableGuildMemberAdd withGuildId(String value) {
/*  85 */     Id newValue = Id.of(value);
/*  86 */     return new ImmutableGuildMemberAdd(this, newValue, this.member);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableGuildMemberAdd withMember(MemberData value) {
/*  96 */     if (this.member == value) return this; 
/*  97 */     MemberData newValue = Objects.<MemberData>requireNonNull(value, "member");
/*  98 */     return new ImmutableGuildMemberAdd(this, guildId(), newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 107 */     if (this == another) return true; 
/* 108 */     return (another instanceof ImmutableGuildMemberAdd && 
/* 109 */       equalTo(0, (ImmutableGuildMemberAdd)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableGuildMemberAdd another) {
/* 113 */     return (Objects.equals(Long.valueOf(this.guildId_value), Long.valueOf(another.guildId_value)) && this.member
/* 114 */       .equals(another.member));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 123 */     int h = 5381;
/* 124 */     h += (h << 5) + Objects.hashCode(Long.valueOf(this.guildId_value));
/* 125 */     h += (h << 5) + this.member.hashCode();
/* 126 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 135 */     return "GuildMemberAdd{guildId=" + 
/* 136 */       Objects.toString(Long.valueOf(this.guildId_value)) + ", member=" + this.member + "}";
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "GuildMemberAdd", generator = "Immutables")
/*     */   static final class Json
/*     */     implements GuildMemberAdd
/*     */   {
/*     */     Id guildId;
/*     */     
/*     */     MemberData member;
/*     */ 
/*     */     
/*     */     @JsonProperty("guild_id")
/*     */     public void setGuildId(Id guildId) {
/* 154 */       this.guildId = guildId;
/*     */     }
/*     */     @JsonProperty("member")
/*     */     @JsonUnwrapped
/*     */     public void setMember(MemberData member) {
/* 159 */       this.member = member;
/*     */     }
/*     */     public Id guildId() {
/* 162 */       throw new UnsupportedOperationException();
/*     */     } public MemberData member() {
/* 164 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableGuildMemberAdd fromJson(Json json) {
/* 175 */     Builder builder = builder();
/* 176 */     if (json.guildId != null) {
/* 177 */       builder.guildId(json.guildId);
/*     */     }
/* 179 */     if (json.member != null) {
/* 180 */       builder.member(json.member);
/*     */     }
/* 182 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableGuildMemberAdd of(Id guildId, MemberData member) {
/* 192 */     return new ImmutableGuildMemberAdd(guildId, member);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableGuildMemberAdd copyOf(GuildMemberAdd instance) {
/* 203 */     if (instance instanceof ImmutableGuildMemberAdd) {
/* 204 */       return (ImmutableGuildMemberAdd)instance;
/*     */     }
/* 206 */     return builder()
/* 207 */       .from(instance)
/* 208 */       .build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 222 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "GuildMemberAdd", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_MEMBER = 1L;
/*     */ 
/*     */ 
/*     */     
/* 235 */     private long initBits = 1L;
/*     */     
/* 237 */     private Id guildId_id = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private MemberData member;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(GuildMemberAdd instance) {
/* 251 */       Objects.requireNonNull(instance, "instance");
/* 252 */       guildId(instance.guildId());
/* 253 */       member(instance.member());
/* 254 */       return this;
/*     */     }
/*     */     
/*     */     public Builder guildId(String value) {
/* 258 */       this.guildId_id = Id.of(value);
/* 259 */       return this;
/*     */     }
/*     */     
/*     */     public Builder guildId(long value) {
/* 263 */       this.guildId_id = Id.of(value);
/* 264 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("guild_id")
/*     */     public Builder guildId(Id value) {
/* 269 */       this.guildId_id = value;
/* 270 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("member")
/*     */     @JsonUnwrapped
/*     */     public final Builder member(MemberData member) {
/* 281 */       this.member = Objects.<MemberData>requireNonNull(member, "member");
/* 282 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 283 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableGuildMemberAdd build() {
/* 292 */       if (this.initBits != 0L) {
/* 293 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 295 */       return new ImmutableGuildMemberAdd(null, guildId_build(), this.member);
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 299 */       List<String> attributes = new ArrayList<>();
/* 300 */       if ((this.initBits & 0x1L) != 0L) attributes.add("member"); 
/* 301 */       return "Cannot build GuildMemberAdd, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Id guildId_build() {
/* 305 */       return this.guildId_id;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\gateway\ImmutableGuildMemberAdd.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */