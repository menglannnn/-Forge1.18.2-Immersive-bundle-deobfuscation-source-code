/*     */ package discord4j.discordjson.json.gateway;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.annotation.JsonUnwrapped;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.json.UnavailableGuildCreateData;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "UnavailableGuildCreate", generator = "Immutables")
/*     */ public final class ImmutableUnavailableGuildCreate
/*     */   implements UnavailableGuildCreate
/*     */ {
/*     */   private final UnavailableGuildCreateData guild;
/*     */   
/*     */   private ImmutableUnavailableGuildCreate(UnavailableGuildCreateData guild) {
/*  30 */     this.guild = Objects.<UnavailableGuildCreateData>requireNonNull(guild, "guild");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private ImmutableUnavailableGuildCreate(ImmutableUnavailableGuildCreate original, UnavailableGuildCreateData guild) {
/*  36 */     this.guild = guild;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("guild")
/*     */   @JsonUnwrapped
/*     */   public UnavailableGuildCreateData guild() {
/*  46 */     return this.guild;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableUnavailableGuildCreate withGuild(UnavailableGuildCreateData value) {
/*  56 */     if (this.guild == value) return this; 
/*  57 */     UnavailableGuildCreateData newValue = Objects.<UnavailableGuildCreateData>requireNonNull(value, "guild");
/*  58 */     return new ImmutableUnavailableGuildCreate(this, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/*  67 */     if (this == another) return true; 
/*  68 */     return (another instanceof ImmutableUnavailableGuildCreate && 
/*  69 */       equalTo(0, (ImmutableUnavailableGuildCreate)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableUnavailableGuildCreate another) {
/*  73 */     return this.guild.equals(another.guild);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  82 */     int h = 5381;
/*  83 */     h += (h << 5) + this.guild.hashCode();
/*  84 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/*  93 */     return "UnavailableGuildCreate{guild=" + this.guild + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "UnavailableGuildCreate", generator = "Immutables")
/*     */   static final class Json
/*     */     implements UnavailableGuildCreate
/*     */   {
/*     */     UnavailableGuildCreateData guild;
/*     */ 
/*     */     
/*     */     @JsonProperty("guild")
/*     */     @JsonUnwrapped
/*     */     public void setGuild(UnavailableGuildCreateData guild) {
/* 111 */       this.guild = guild;
/*     */     }
/*     */     public UnavailableGuildCreateData guild() {
/* 114 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableUnavailableGuildCreate fromJson(Json json) {
/* 125 */     Builder builder = builder();
/* 126 */     if (json.guild != null) {
/* 127 */       builder.guild(json.guild);
/*     */     }
/* 129 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableUnavailableGuildCreate of(UnavailableGuildCreateData guild) {
/* 138 */     return new ImmutableUnavailableGuildCreate(guild);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableUnavailableGuildCreate copyOf(UnavailableGuildCreate instance) {
/* 149 */     if (instance instanceof ImmutableUnavailableGuildCreate) {
/* 150 */       return (ImmutableUnavailableGuildCreate)instance;
/*     */     }
/* 152 */     return builder()
/* 153 */       .from(instance)
/* 154 */       .build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 167 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "UnavailableGuildCreate", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_GUILD = 1L;
/*     */ 
/*     */ 
/*     */     
/* 180 */     private long initBits = 1L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private UnavailableGuildCreateData guild;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(UnavailableGuildCreate instance) {
/* 195 */       Objects.requireNonNull(instance, "instance");
/* 196 */       guild(instance.guild());
/* 197 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("guild")
/*     */     @JsonUnwrapped
/*     */     public final Builder guild(UnavailableGuildCreateData guild) {
/* 208 */       this.guild = Objects.<UnavailableGuildCreateData>requireNonNull(guild, "guild");
/* 209 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 210 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableUnavailableGuildCreate build() {
/* 219 */       if (this.initBits != 0L) {
/* 220 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 222 */       return new ImmutableUnavailableGuildCreate(null, this.guild);
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 226 */       List<String> attributes = new ArrayList<>();
/* 227 */       if ((this.initBits & 0x1L) != 0L) attributes.add("guild"); 
/* 228 */       return "Cannot build UnavailableGuildCreate, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\gateway\ImmutableUnavailableGuildCreate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */