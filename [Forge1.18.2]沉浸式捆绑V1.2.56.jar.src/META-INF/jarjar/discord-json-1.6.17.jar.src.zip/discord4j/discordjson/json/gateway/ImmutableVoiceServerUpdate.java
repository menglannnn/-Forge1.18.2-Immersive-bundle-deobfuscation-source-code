/*     */ package discord4j.discordjson.json.gateway;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.Id;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "VoiceServerUpdate", generator = "Immutables")
/*     */ public final class ImmutableVoiceServerUpdate
/*     */   implements VoiceServerUpdate
/*     */ {
/*     */   private final String token;
/*     */   private final long guildId_value;
/*     */   @Nullable
/*     */   private final String endpoint;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   private volatile transient InitShim initShim;
/*     */   
/*     */   private ImmutableVoiceServerUpdate(String token, Id guildId, @Nullable String endpoint) {
/*  56 */     this.initShim = new InitShim(); this.token = Objects.<String>requireNonNull(token, "token"); Id guildId$impl = guildId; this.endpoint = endpoint; this.guildId_value = guildId$impl.asLong(); this.initShim = null; } private ImmutableVoiceServerUpdate(ImmutableVoiceServerUpdate original, String token, Id guildId, @Nullable String endpoint) { this.initShim = new InitShim();
/*     */     this.token = token;
/*     */     Id guildId$impl = guildId;
/*     */     this.endpoint = endpoint;
/*     */     this.guildId_value = guildId$impl.asLong();
/*  61 */     this.initShim = null; } @Generated(from = "VoiceServerUpdate", generator = "Immutables") private final class InitShim { private InitShim() {} private String formatInitCycleMessage() { List<String> attributes = new ArrayList<>();
/*  62 */       return "Cannot build VoiceServerUpdate, attribute initializers form cycle " + attributes; }
/*     */      }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("token")
/*     */   public String token() {
/*  72 */     return this.token;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("guild_id")
/*     */   public Id guildId() {
/*  81 */     return Id.of(this.guildId_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("endpoint")
/*     */   @Nullable
/*     */   public String endpoint() {
/*  90 */     return this.endpoint;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableVoiceServerUpdate withToken(String value) {
/* 100 */     String newValue = Objects.<String>requireNonNull(value, "token");
/* 101 */     if (this.token.equals(newValue)) return this; 
/* 102 */     return new ImmutableVoiceServerUpdate(this, newValue, guildId(), this.endpoint);
/*     */   }
/*     */   
/*     */   public ImmutableVoiceServerUpdate withGuildId(long value) {
/* 106 */     Id newValue = Id.of(value);
/* 107 */     return new ImmutableVoiceServerUpdate(this, this.token, newValue, this.endpoint);
/*     */   }
/*     */   
/*     */   public ImmutableVoiceServerUpdate withGuildId(String value) {
/* 111 */     Id newValue = Id.of(value);
/* 112 */     return new ImmutableVoiceServerUpdate(this, this.token, newValue, this.endpoint);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableVoiceServerUpdate withEndpoint(@Nullable String value) {
/* 122 */     if (Objects.equals(this.endpoint, value)) return this; 
/* 123 */     return new ImmutableVoiceServerUpdate(this, this.token, guildId(), value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 132 */     if (this == another) return true; 
/* 133 */     return (another instanceof ImmutableVoiceServerUpdate && 
/* 134 */       equalTo(0, (ImmutableVoiceServerUpdate)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableVoiceServerUpdate another) {
/* 138 */     return (this.token.equals(another.token) && 
/* 139 */       Objects.equals(Long.valueOf(this.guildId_value), Long.valueOf(another.guildId_value)) && 
/* 140 */       Objects.equals(this.endpoint, another.endpoint));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 149 */     int h = 5381;
/* 150 */     h += (h << 5) + this.token.hashCode();
/* 151 */     h += (h << 5) + Objects.hashCode(Long.valueOf(this.guildId_value));
/* 152 */     h += (h << 5) + Objects.hashCode(this.endpoint);
/* 153 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 162 */     return "VoiceServerUpdate{token=" + this.token + ", guildId=" + 
/*     */       
/* 164 */       Objects.toString(Long.valueOf(this.guildId_value)) + ", endpoint=" + this.endpoint + "}";
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "VoiceServerUpdate", generator = "Immutables")
/*     */   static final class Json
/*     */     implements VoiceServerUpdate
/*     */   {
/*     */     String token;
/*     */     
/*     */     Id guildId;
/*     */     
/*     */     String endpoint;
/*     */     
/*     */     @JsonProperty("token")
/*     */     public void setToken(String token) {
/* 183 */       this.token = token;
/*     */     }
/*     */     @JsonProperty("guild_id")
/*     */     public void setGuildId(Id guildId) {
/* 187 */       this.guildId = guildId;
/*     */     }
/*     */     @JsonProperty("endpoint")
/*     */     public void setEndpoint(@Nullable String endpoint) {
/* 191 */       this.endpoint = endpoint;
/*     */     }
/*     */     public String token() {
/* 194 */       throw new UnsupportedOperationException();
/*     */     } public Id guildId() {
/* 196 */       throw new UnsupportedOperationException();
/*     */     } public String endpoint() {
/* 198 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableVoiceServerUpdate fromJson(Json json) {
/* 209 */     Builder builder = builder();
/* 210 */     if (json.token != null) {
/* 211 */       builder.token(json.token);
/*     */     }
/* 213 */     if (json.guildId != null) {
/* 214 */       builder.guildId(json.guildId);
/*     */     }
/* 216 */     if (json.endpoint != null) {
/* 217 */       builder.endpoint(json.endpoint);
/*     */     }
/* 219 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableVoiceServerUpdate of(String token, Id guildId, @Nullable String endpoint) {
/* 230 */     return new ImmutableVoiceServerUpdate(token, guildId, endpoint);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableVoiceServerUpdate copyOf(VoiceServerUpdate instance) {
/* 241 */     if (instance instanceof ImmutableVoiceServerUpdate) {
/* 242 */       return (ImmutableVoiceServerUpdate)instance;
/*     */     }
/* 244 */     return builder()
/* 245 */       .from(instance)
/* 246 */       .build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 261 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "VoiceServerUpdate", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_TOKEN = 1L;
/*     */ 
/*     */ 
/*     */     
/* 274 */     private long initBits = 1L;
/*     */     
/* 276 */     private Id guildId_id = null;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private String token;
/*     */ 
/*     */ 
/*     */     
/*     */     private String endpoint;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(VoiceServerUpdate instance) {
/* 291 */       Objects.requireNonNull(instance, "instance");
/* 292 */       token(instance.token());
/* 293 */       guildId(instance.guildId());
/* 294 */       String endpointValue = instance.endpoint();
/* 295 */       if (endpointValue != null) {
/* 296 */         endpoint(endpointValue);
/*     */       }
/* 298 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("token")
/*     */     public final Builder token(String token) {
/* 308 */       this.token = Objects.<String>requireNonNull(token, "token");
/* 309 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 310 */       return this;
/*     */     }
/*     */     
/*     */     public Builder guildId(String value) {
/* 314 */       this.guildId_id = Id.of(value);
/* 315 */       return this;
/*     */     }
/*     */     
/*     */     public Builder guildId(long value) {
/* 319 */       this.guildId_id = Id.of(value);
/* 320 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("guild_id")
/*     */     public Builder guildId(Id value) {
/* 325 */       this.guildId_id = value;
/* 326 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("endpoint")
/*     */     public final Builder endpoint(@Nullable String endpoint) {
/* 336 */       this.endpoint = endpoint;
/* 337 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableVoiceServerUpdate build() {
/* 346 */       if (this.initBits != 0L) {
/* 347 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 349 */       return new ImmutableVoiceServerUpdate(null, this.token, guildId_build(), this.endpoint);
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 353 */       List<String> attributes = new ArrayList<>();
/* 354 */       if ((this.initBits & 0x1L) != 0L) attributes.add("token"); 
/* 355 */       return "Cannot build VoiceServerUpdate, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Id guildId_build() {
/* 359 */       return this.guildId_id;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\gateway\ImmutableVoiceServerUpdate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */