/*     */ package discord4j.discordjson.json.gateway;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "Identify", generator = "Immutables")
/*     */ public final class ImmutableIdentify
/*     */   implements Identify
/*     */ {
/*     */   private final String token;
/*     */   private final IdentifyProperties properties;
/*     */   private final Boolean compress_value;
/*     */   private final boolean compress_absent;
/*     */   private final int largeThreshold;
/*     */   private final int[] shard_value;
/*     */   private final boolean shard_absent;
/*     */   private final StatusUpdate presence_value;
/*     */   private final boolean presence_absent;
/*     */   private final Long intents_value;
/*     */   private final boolean intents_absent;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   private volatile transient InitShim initShim;
/*     */   
/*     */   private ImmutableIdentify(String token, IdentifyProperties properties, Possible<Boolean> compress, int largeThreshold, Possible<int[]> shard, Possible<StatusUpdate> presence, Possible<Long> intents) {
/*  93 */     this.initShim = new InitShim(); this.token = Objects.<String>requireNonNull(token, "token"); this.properties = Objects.<IdentifyProperties>requireNonNull(properties, "properties"); Possible<Boolean> compress$impl = compress; this.largeThreshold = largeThreshold; Possible<int[]> shard$impl = shard; Possible<StatusUpdate> presence$impl = presence; Possible<Long> intents$impl = intents; this.compress_value = compress$impl.toOptional().orElse(null); this.compress_absent = compress$impl.isAbsent(); this.shard_value = shard$impl.toOptional().orElse(null); this.shard_absent = shard$impl.isAbsent(); this.presence_value = presence$impl.toOptional().orElse(null); this.presence_absent = presence$impl.isAbsent(); this.intents_value = intents$impl.toOptional().orElse(null); this.intents_absent = intents$impl.isAbsent(); this.initShim = null; } private ImmutableIdentify(ImmutableIdentify original, String token, IdentifyProperties properties, Possible<Boolean> compress, int largeThreshold, Possible<int[]> shard, Possible<StatusUpdate> presence, Possible<Long> intents) { this.initShim = new InitShim(); this.token = token; this.properties = properties; Possible<Boolean> compress$impl = compress; this.largeThreshold = largeThreshold; Possible<int[]> shard$impl = shard; Possible<StatusUpdate> presence$impl = presence; Possible<Long> intents$impl = intents; this.compress_value = compress$impl.toOptional().orElse(null); this.compress_absent = compress$impl.isAbsent(); this.shard_value = shard$impl.toOptional().orElse(null); this.shard_absent = shard$impl.isAbsent();
/*     */     this.presence_value = presence$impl.toOptional().orElse(null);
/*     */     this.presence_absent = presence$impl.isAbsent();
/*     */     this.intents_value = intents$impl.toOptional().orElse(null);
/*     */     this.intents_absent = intents$impl.isAbsent();
/*  98 */     this.initShim = null; } @Generated(from = "Identify", generator = "Immutables") private final class InitShim { private InitShim() {} private String formatInitCycleMessage() { List<String> attributes = new ArrayList<>();
/*  99 */       return "Cannot build Identify, attribute initializers form cycle " + attributes; }
/*     */      }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("token")
/*     */   public String token() {
/* 109 */     return this.token;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("properties")
/*     */   public IdentifyProperties properties() {
/* 118 */     return this.properties;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("compress")
/*     */   public Possible<Boolean> compress() {
/* 127 */     return this.compress_absent ? Possible.absent() : Possible.of(this.compress_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("large_threshold")
/*     */   public int largeThreshold() {
/* 136 */     return this.largeThreshold;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("shard")
/*     */   public Possible<int[]> shard() {
/* 145 */     return this.shard_absent ? Possible.absent() : Possible.of(this.shard_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("presence")
/*     */   public Possible<StatusUpdate> presence() {
/* 154 */     return this.presence_absent ? Possible.absent() : Possible.of(this.presence_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("intents")
/*     */   public Possible<Long> intents() {
/* 163 */     return this.intents_absent ? Possible.absent() : Possible.of(this.intents_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableIdentify withToken(String value) {
/* 173 */     String newValue = Objects.<String>requireNonNull(value, "token");
/* 174 */     if (this.token.equals(newValue)) return this; 
/* 175 */     return new ImmutableIdentify(this, newValue, this.properties, 
/*     */ 
/*     */ 
/*     */         
/* 179 */         compress(), this.largeThreshold, 
/*     */         
/* 181 */         shard(), 
/* 182 */         presence(), 
/* 183 */         intents());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableIdentify withProperties(IdentifyProperties value) {
/* 193 */     if (this.properties == value) return this; 
/* 194 */     IdentifyProperties newValue = Objects.<IdentifyProperties>requireNonNull(value, "properties");
/* 195 */     return new ImmutableIdentify(this, this.token, newValue, 
/*     */ 
/*     */ 
/*     */         
/* 199 */         compress(), this.largeThreshold, 
/*     */         
/* 201 */         shard(), 
/* 202 */         presence(), 
/* 203 */         intents());
/*     */   }
/*     */   
/*     */   public ImmutableIdentify withCompress(Possible<Boolean> value) {
/* 207 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/* 208 */     return new ImmutableIdentify(this, this.token, this.properties, newValue, this.largeThreshold, 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 214 */         shard(), 
/* 215 */         presence(), 
/* 216 */         intents());
/*     */   }
/*     */   
/*     */   public ImmutableIdentify withCompress(Boolean value) {
/* 220 */     Possible<Boolean> newValue = Possible.of(value);
/* 221 */     return new ImmutableIdentify(this, this.token, this.properties, newValue, this.largeThreshold, 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 227 */         shard(), 
/* 228 */         presence(), 
/* 229 */         intents());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableIdentify withLargeThreshold(int value) {
/* 239 */     if (this.largeThreshold == value) return this; 
/* 240 */     return new ImmutableIdentify(this, this.token, this.properties, 
/*     */ 
/*     */ 
/*     */         
/* 244 */         compress(), value, 
/*     */         
/* 246 */         shard(), 
/* 247 */         presence(), 
/* 248 */         intents());
/*     */   }
/*     */   
/*     */   public ImmutableIdentify withShard(Possible<int[]> value) {
/* 252 */     Possible<int[]> newValue = Objects.<Possible<int[]>>requireNonNull(value);
/* 253 */     return new ImmutableIdentify(this, this.token, this.properties, 
/*     */ 
/*     */ 
/*     */         
/* 257 */         compress(), this.largeThreshold, newValue, 
/*     */ 
/*     */         
/* 260 */         presence(), 
/* 261 */         intents());
/*     */   }
/*     */   
/*     */   public ImmutableIdentify withShard(int[] value) {
/* 265 */     Possible<int[]> newValue = Possible.of(value);
/* 266 */     return new ImmutableIdentify(this, this.token, this.properties, 
/*     */ 
/*     */ 
/*     */         
/* 270 */         compress(), this.largeThreshold, newValue, 
/*     */ 
/*     */         
/* 273 */         presence(), 
/* 274 */         intents());
/*     */   }
/*     */   
/*     */   public ImmutableIdentify withPresence(Possible<StatusUpdate> value) {
/* 278 */     Possible<StatusUpdate> newValue = Objects.<Possible<StatusUpdate>>requireNonNull(value);
/* 279 */     return new ImmutableIdentify(this, this.token, this.properties, 
/*     */ 
/*     */ 
/*     */         
/* 283 */         compress(), this.largeThreshold, 
/*     */         
/* 285 */         shard(), newValue, 
/*     */         
/* 287 */         intents());
/*     */   }
/*     */   
/*     */   public ImmutableIdentify withPresence(StatusUpdate value) {
/* 291 */     Possible<StatusUpdate> newValue = Possible.of(value);
/* 292 */     return new ImmutableIdentify(this, this.token, this.properties, 
/*     */ 
/*     */ 
/*     */         
/* 296 */         compress(), this.largeThreshold, 
/*     */         
/* 298 */         shard(), newValue, 
/*     */         
/* 300 */         intents());
/*     */   }
/*     */   
/*     */   public ImmutableIdentify withIntents(Possible<Long> value) {
/* 304 */     Possible<Long> newValue = Objects.<Possible<Long>>requireNonNull(value);
/* 305 */     return new ImmutableIdentify(this, this.token, this.properties, 
/*     */ 
/*     */ 
/*     */         
/* 309 */         compress(), this.largeThreshold, 
/*     */         
/* 311 */         shard(), 
/* 312 */         presence(), newValue);
/*     */   }
/*     */ 
/*     */   
/*     */   public ImmutableIdentify withIntents(Long value) {
/* 317 */     Possible<Long> newValue = Possible.of(value);
/* 318 */     return new ImmutableIdentify(this, this.token, this.properties, 
/*     */ 
/*     */ 
/*     */         
/* 322 */         compress(), this.largeThreshold, 
/*     */         
/* 324 */         shard(), 
/* 325 */         presence(), newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 335 */     if (this == another) return true; 
/* 336 */     return (another instanceof ImmutableIdentify && 
/* 337 */       equalTo(0, (ImmutableIdentify)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableIdentify another) {
/* 341 */     return (this.token.equals(another.token) && this.properties
/* 342 */       .equals(another.properties) && 
/* 343 */       compress().equals(another.compress()) && this.largeThreshold == another.largeThreshold && 
/*     */       
/* 345 */       shard().equals(another.shard()) && 
/* 346 */       presence().equals(another.presence()) && 
/* 347 */       intents().equals(another.intents()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 356 */     int h = 5381;
/* 357 */     h += (h << 5) + this.token.hashCode();
/* 358 */     h += (h << 5) + this.properties.hashCode();
/* 359 */     h += (h << 5) + compress().hashCode();
/* 360 */     h += (h << 5) + this.largeThreshold;
/* 361 */     h += (h << 5) + shard().hashCode();
/* 362 */     h += (h << 5) + presence().hashCode();
/* 363 */     h += (h << 5) + intents().hashCode();
/* 364 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 373 */     return "Identify{token=" + this.token + ", properties=" + this.properties + ", compress=" + 
/*     */ 
/*     */       
/* 376 */       compress().toString() + ", largeThreshold=" + this.largeThreshold + ", shard=" + 
/*     */       
/* 378 */       shard().toString() + ", presence=" + 
/* 379 */       presence().toString() + ", intents=" + 
/* 380 */       intents().toString() + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "Identify", generator = "Immutables")
/*     */   static final class Json
/*     */     implements Identify
/*     */   {
/*     */     String token;
/*     */     
/*     */     IdentifyProperties properties;
/*     */     
/* 396 */     Possible<Boolean> compress = Possible.absent();
/*     */     
/*     */     int largeThreshold;
/*     */     
/*     */     boolean largeThresholdIsSet;
/* 401 */     Possible<int[]> shard = Possible.absent();
/*     */ 
/*     */     
/* 404 */     Possible<StatusUpdate> presence = Possible.absent();
/*     */ 
/*     */     
/* 407 */     Possible<Long> intents = Possible.absent();
/*     */     
/*     */     @JsonProperty("token")
/*     */     public void setToken(String token) {
/* 411 */       this.token = token;
/*     */     }
/*     */     @JsonProperty("properties")
/*     */     public void setProperties(IdentifyProperties properties) {
/* 415 */       this.properties = properties;
/*     */     }
/*     */     @JsonProperty("compress")
/*     */     public void setCompress(Possible<Boolean> compress) {
/* 419 */       this.compress = compress;
/*     */     }
/*     */     @JsonProperty("large_threshold")
/*     */     public void setLargeThreshold(int largeThreshold) {
/* 423 */       this.largeThreshold = largeThreshold;
/* 424 */       this.largeThresholdIsSet = true;
/*     */     }
/*     */     @JsonProperty("shard")
/*     */     public void setShard(Possible<int[]> shard) {
/* 428 */       this.shard = shard;
/*     */     }
/*     */     @JsonProperty("presence")
/*     */     public void setPresence(Possible<StatusUpdate> presence) {
/* 432 */       this.presence = presence;
/*     */     }
/*     */     @JsonProperty("intents")
/*     */     public void setIntents(Possible<Long> intents) {
/* 436 */       this.intents = intents;
/*     */     }
/*     */     public String token() {
/* 439 */       throw new UnsupportedOperationException();
/*     */     } public IdentifyProperties properties() {
/* 441 */       throw new UnsupportedOperationException();
/*     */     } public Possible<Boolean> compress() {
/* 443 */       throw new UnsupportedOperationException();
/*     */     } public int largeThreshold() {
/* 445 */       throw new UnsupportedOperationException();
/*     */     } public Possible<int[]> shard() {
/* 447 */       throw new UnsupportedOperationException();
/*     */     } public Possible<StatusUpdate> presence() {
/* 449 */       throw new UnsupportedOperationException();
/*     */     } public Possible<Long> intents() {
/* 451 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableIdentify fromJson(Json json) {
/* 462 */     Builder builder = builder();
/* 463 */     if (json.token != null) {
/* 464 */       builder.token(json.token);
/*     */     }
/* 466 */     if (json.properties != null) {
/* 467 */       builder.properties(json.properties);
/*     */     }
/* 469 */     if (json.compress != null) {
/* 470 */       builder.compress(json.compress);
/*     */     }
/* 472 */     if (json.largeThresholdIsSet) {
/* 473 */       builder.largeThreshold(json.largeThreshold);
/*     */     }
/* 475 */     if (json.shard != null) {
/* 476 */       builder.shard(json.shard);
/*     */     }
/* 478 */     if (json.presence != null) {
/* 479 */       builder.presence(json.presence);
/*     */     }
/* 481 */     if (json.intents != null) {
/* 482 */       builder.intents(json.intents);
/*     */     }
/* 484 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableIdentify of(String token, IdentifyProperties properties, Possible<Boolean> compress, int largeThreshold, Possible<int[]> shard, Possible<StatusUpdate> presence, Possible<Long> intents) {
/* 499 */     return new ImmutableIdentify(token, properties, compress, largeThreshold, shard, presence, intents);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableIdentify copyOf(Identify instance) {
/* 510 */     if (instance instanceof ImmutableIdentify) {
/* 511 */       return (ImmutableIdentify)instance;
/*     */     }
/* 513 */     return builder()
/* 514 */       .from(instance)
/* 515 */       .build();
/*     */   }
/*     */   
/*     */   public boolean isCompressPresent() {
/* 519 */     return !this.compress_absent;
/*     */   }
/*     */   
/*     */   public Boolean compressOrElse(Boolean defaultValue) {
/* 523 */     return !this.compress_absent ? this.compress_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isShardPresent() {
/* 527 */     return !this.shard_absent;
/*     */   }
/*     */   
/*     */   public int[] shardOrElse(int[] defaultValue) {
/* 531 */     return !this.shard_absent ? this.shard_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isPresencePresent() {
/* 535 */     return !this.presence_absent;
/*     */   }
/*     */   
/*     */   public StatusUpdate presenceOrElse(StatusUpdate defaultValue) {
/* 539 */     return !this.presence_absent ? this.presence_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isIntentsPresent() {
/* 543 */     return !this.intents_absent;
/*     */   }
/*     */   
/*     */   public Long intentsOrElse(Long defaultValue) {
/* 547 */     return !this.intents_absent ? this.intents_value : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 566 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "Identify", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_TOKEN = 1L;
/*     */ 
/*     */     
/*     */     private static final long INIT_BIT_PROPERTIES = 2L;
/*     */     
/*     */     private static final long INIT_BIT_LARGE_THRESHOLD = 4L;
/*     */     
/* 581 */     private long initBits = 7L;
/*     */     
/* 583 */     private Possible<Boolean> compress_possible = Possible.absent();
/* 584 */     private Possible<int[]> shard_possible = Possible.absent();
/* 585 */     private Possible<StatusUpdate> presence_possible = Possible.absent();
/* 586 */     private Possible<Long> intents_possible = Possible.absent();
/*     */ 
/*     */ 
/*     */     
/*     */     private String token;
/*     */ 
/*     */ 
/*     */     
/*     */     private IdentifyProperties properties;
/*     */ 
/*     */     
/*     */     private int largeThreshold;
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(Identify instance) {
/* 602 */       Objects.requireNonNull(instance, "instance");
/* 603 */       token(instance.token());
/* 604 */       properties(instance.properties());
/* 605 */       compress(instance.compress());
/* 606 */       largeThreshold(instance.largeThreshold());
/* 607 */       shard(instance.shard());
/* 608 */       presence(instance.presence());
/* 609 */       intents(instance.intents());
/* 610 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("token")
/*     */     public final Builder token(String token) {
/* 620 */       this.token = Objects.<String>requireNonNull(token, "token");
/* 621 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 622 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("properties")
/*     */     public final Builder properties(IdentifyProperties properties) {
/* 632 */       this.properties = Objects.<IdentifyProperties>requireNonNull(properties, "properties");
/* 633 */       this.initBits &= 0xFFFFFFFFFFFFFFFDL;
/* 634 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("compress")
/*     */     public Builder compress(Possible<Boolean> value) {
/* 639 */       this.compress_possible = value;
/* 640 */       return this;
/*     */     }
/*     */     
/*     */     public Builder compress(Boolean value) {
/* 644 */       this.compress_possible = Possible.of(value);
/* 645 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("large_threshold")
/*     */     public final Builder largeThreshold(int largeThreshold) {
/* 655 */       this.largeThreshold = largeThreshold;
/* 656 */       this.initBits &= 0xFFFFFFFFFFFFFFFBL;
/* 657 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("shard")
/*     */     public Builder shard(Possible<int[]> value) {
/* 662 */       this.shard_possible = value;
/* 663 */       return this;
/*     */     }
/*     */     
/*     */     public Builder shard(int[] value) {
/* 667 */       this.shard_possible = Possible.of(value);
/* 668 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("presence")
/*     */     public Builder presence(Possible<StatusUpdate> value) {
/* 673 */       this.presence_possible = value;
/* 674 */       return this;
/*     */     }
/*     */     
/*     */     public Builder presence(StatusUpdate value) {
/* 678 */       this.presence_possible = Possible.of(value);
/* 679 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("intents")
/*     */     public Builder intents(Possible<Long> value) {
/* 684 */       this.intents_possible = value;
/* 685 */       return this;
/*     */     }
/*     */     
/*     */     public Builder intents(Long value) {
/* 689 */       this.intents_possible = Possible.of(value);
/* 690 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableIdentify build() {
/* 699 */       if (this.initBits != 0L) {
/* 700 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 702 */       return new ImmutableIdentify(null, this.token, this.properties, 
/*     */ 
/*     */ 
/*     */           
/* 706 */           compress_build(), this.largeThreshold, 
/*     */           
/* 708 */           shard_build(), 
/* 709 */           presence_build(), 
/* 710 */           intents_build());
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 714 */       List<String> attributes = new ArrayList<>();
/* 715 */       if ((this.initBits & 0x1L) != 0L) attributes.add("token"); 
/* 716 */       if ((this.initBits & 0x2L) != 0L) attributes.add("properties"); 
/* 717 */       if ((this.initBits & 0x4L) != 0L) attributes.add("largeThreshold"); 
/* 718 */       return "Cannot build Identify, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Possible<Boolean> compress_build() {
/* 722 */       return this.compress_possible;
/*     */     }
/*     */     
/*     */     private Possible<int[]> shard_build() {
/* 726 */       return this.shard_possible;
/*     */     }
/*     */     
/*     */     private Possible<StatusUpdate> presence_build() {
/* 730 */       return this.presence_possible;
/*     */     }
/*     */     
/*     */     private Possible<Long> intents_build() {
/* 734 */       return this.intents_possible;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\gateway\ImmutableIdentify.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */