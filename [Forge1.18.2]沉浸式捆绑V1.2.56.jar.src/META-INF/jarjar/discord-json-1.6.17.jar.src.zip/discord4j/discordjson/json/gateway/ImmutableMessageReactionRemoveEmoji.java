/*     */ package discord4j.discordjson.json.gateway;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.Id;
/*     */ import discord4j.discordjson.json.EmojiData;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "MessageReactionRemoveEmoji", generator = "Immutables")
/*     */ public final class ImmutableMessageReactionRemoveEmoji
/*     */   implements MessageReactionRemoveEmoji
/*     */ {
/*     */   private final long channelId_value;
/*     */   private final long messageId_value;
/*     */   private final long guildId_value;
/*     */   private final boolean guildId_absent;
/*     */   private final EmojiData emoji;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   
/*     */   private ImmutableMessageReactionRemoveEmoji(Id channelId, Id messageId, Possible<Id> guildId, EmojiData emoji) {
/*  39 */     Id channelId$impl = channelId;
/*  40 */     Id messageId$impl = messageId;
/*  41 */     Possible<Id> guildId$impl = guildId;
/*  42 */     this.emoji = Objects.<EmojiData>requireNonNull(emoji, "emoji");
/*  43 */     this.channelId_value = channelId$impl.asLong();
/*  44 */     this.messageId_value = messageId$impl.asLong();
/*  45 */     this
/*     */       
/*  47 */       .guildId_value = ((Long)guildId$impl.toOptional().map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  48 */     this.guildId_absent = guildId$impl.isAbsent();
/*  49 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ImmutableMessageReactionRemoveEmoji(ImmutableMessageReactionRemoveEmoji original, Id channelId, Id messageId, Possible<Id> guildId, EmojiData emoji) {
/*  58 */     Id channelId$impl = channelId;
/*  59 */     Id messageId$impl = messageId;
/*  60 */     Possible<Id> guildId$impl = guildId;
/*  61 */     this.emoji = emoji;
/*  62 */     this.channelId_value = channelId$impl.asLong();
/*  63 */     this.messageId_value = messageId$impl.asLong();
/*  64 */     this
/*     */       
/*  66 */       .guildId_value = ((Long)guildId$impl.toOptional().map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  67 */     this.guildId_absent = guildId$impl.isAbsent();
/*  68 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  74 */   private volatile transient InitShim initShim = new InitShim();
/*     */   
/*     */   @Generated(from = "MessageReactionRemoveEmoji", generator = "Immutables")
/*     */   private final class InitShim {
/*     */     private String formatInitCycleMessage() {
/*  79 */       List<String> attributes = new ArrayList<>();
/*  80 */       return "Cannot build MessageReactionRemoveEmoji, attribute initializers form cycle " + attributes;
/*     */     }
/*     */ 
/*     */     
/*     */     private InitShim() {}
/*     */   }
/*     */ 
/*     */   
/*     */   @JsonProperty("channel_id")
/*     */   public Id channelId() {
/*  90 */     return Id.of(this.channelId_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("message_id")
/*     */   public Id messageId() {
/*  99 */     return Id.of(this.messageId_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("guild_id")
/*     */   public Possible<Id> guildId() {
/* 108 */     return this.guildId_absent ? Possible.absent() : 
/* 109 */       Possible.of(Id.of(this.guildId_value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("emoji")
/*     */   public EmojiData emoji() {
/* 118 */     return this.emoji;
/*     */   }
/*     */   
/*     */   public ImmutableMessageReactionRemoveEmoji withChannelId(long value) {
/* 122 */     Id newValue = Id.of(value);
/* 123 */     return new ImmutableMessageReactionRemoveEmoji(this, newValue, messageId(), guildId(), this.emoji);
/*     */   }
/*     */   
/*     */   public ImmutableMessageReactionRemoveEmoji withChannelId(String value) {
/* 127 */     Id newValue = Id.of(value);
/* 128 */     return new ImmutableMessageReactionRemoveEmoji(this, newValue, messageId(), guildId(), this.emoji);
/*     */   }
/*     */   
/*     */   public ImmutableMessageReactionRemoveEmoji withMessageId(long value) {
/* 132 */     Id newValue = Id.of(value);
/* 133 */     return new ImmutableMessageReactionRemoveEmoji(this, channelId(), newValue, guildId(), this.emoji);
/*     */   }
/*     */   
/*     */   public ImmutableMessageReactionRemoveEmoji withMessageId(String value) {
/* 137 */     Id newValue = Id.of(value);
/* 138 */     return new ImmutableMessageReactionRemoveEmoji(this, channelId(), newValue, guildId(), this.emoji);
/*     */   }
/*     */   
/*     */   public ImmutableMessageReactionRemoveEmoji withGuildId(Possible<Id> value) {
/* 142 */     Possible<Id> newValue = Objects.<Possible<Id>>requireNonNull(value);
/* 143 */     return new ImmutableMessageReactionRemoveEmoji(this, channelId(), messageId(), newValue, this.emoji);
/*     */   }
/*     */   
/*     */   public ImmutableMessageReactionRemoveEmoji withGuildId(long value) {
/* 147 */     Possible<Id> newValue = Possible.of(Id.of(value));
/* 148 */     return new ImmutableMessageReactionRemoveEmoji(this, channelId(), messageId(), newValue, this.emoji);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableMessageReactionRemoveEmoji withEmoji(EmojiData value) {
/* 158 */     if (this.emoji == value) return this; 
/* 159 */     EmojiData newValue = Objects.<EmojiData>requireNonNull(value, "emoji");
/* 160 */     return new ImmutableMessageReactionRemoveEmoji(this, channelId(), messageId(), guildId(), newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 169 */     if (this == another) return true; 
/* 170 */     return (another instanceof ImmutableMessageReactionRemoveEmoji && 
/* 171 */       equalTo(0, (ImmutableMessageReactionRemoveEmoji)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableMessageReactionRemoveEmoji another) {
/* 175 */     return (Objects.equals(Long.valueOf(this.channelId_value), Long.valueOf(another.channelId_value)) && 
/* 176 */       Objects.equals(Long.valueOf(this.messageId_value), Long.valueOf(another.messageId_value)) && 
/* 177 */       guildId().equals(another.guildId()) && this.emoji
/* 178 */       .equals(another.emoji));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 187 */     int h = 5381;
/* 188 */     h += (h << 5) + Objects.hashCode(Long.valueOf(this.channelId_value));
/* 189 */     h += (h << 5) + Objects.hashCode(Long.valueOf(this.messageId_value));
/* 190 */     h += (h << 5) + guildId().hashCode();
/* 191 */     h += (h << 5) + this.emoji.hashCode();
/* 192 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 201 */     return "MessageReactionRemoveEmoji{channelId=" + 
/* 202 */       Objects.toString(Long.valueOf(this.channelId_value)) + ", messageId=" + 
/* 203 */       Objects.toString(Long.valueOf(this.messageId_value)) + ", guildId=" + 
/* 204 */       guildId().toString() + ", emoji=" + this.emoji + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "MessageReactionRemoveEmoji", generator = "Immutables")
/*     */   static final class Json
/*     */     implements MessageReactionRemoveEmoji
/*     */   {
/*     */     Id channelId;
/*     */ 
/*     */     
/*     */     Id messageId;
/*     */     
/* 221 */     Possible<Id> guildId = Possible.absent();
/*     */     EmojiData emoji;
/*     */     
/*     */     @JsonProperty("channel_id")
/*     */     public void setChannelId(Id channelId) {
/* 226 */       this.channelId = channelId;
/*     */     }
/*     */     @JsonProperty("message_id")
/*     */     public void setMessageId(Id messageId) {
/* 230 */       this.messageId = messageId;
/*     */     }
/*     */     @JsonProperty("guild_id")
/*     */     public void setGuildId(Possible<Id> guildId) {
/* 234 */       this.guildId = guildId;
/*     */     }
/*     */     @JsonProperty("emoji")
/*     */     public void setEmoji(EmojiData emoji) {
/* 238 */       this.emoji = emoji;
/*     */     }
/*     */     public Id channelId() {
/* 241 */       throw new UnsupportedOperationException();
/*     */     } public Id messageId() {
/* 243 */       throw new UnsupportedOperationException();
/*     */     } public Possible<Id> guildId() {
/* 245 */       throw new UnsupportedOperationException();
/*     */     } public EmojiData emoji() {
/* 247 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableMessageReactionRemoveEmoji fromJson(Json json) {
/* 258 */     Builder builder = builder();
/* 259 */     if (json.channelId != null) {
/* 260 */       builder.channelId(json.channelId);
/*     */     }
/* 262 */     if (json.messageId != null) {
/* 263 */       builder.messageId(json.messageId);
/*     */     }
/* 265 */     if (json.guildId != null) {
/* 266 */       builder.guildId(json.guildId);
/*     */     }
/* 268 */     if (json.emoji != null) {
/* 269 */       builder.emoji(json.emoji);
/*     */     }
/* 271 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableMessageReactionRemoveEmoji of(Id channelId, Id messageId, Possible<Id> guildId, EmojiData emoji) {
/* 283 */     return new ImmutableMessageReactionRemoveEmoji(channelId, messageId, guildId, emoji);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableMessageReactionRemoveEmoji copyOf(MessageReactionRemoveEmoji instance) {
/* 294 */     if (instance instanceof ImmutableMessageReactionRemoveEmoji) {
/* 295 */       return (ImmutableMessageReactionRemoveEmoji)instance;
/*     */     }
/* 297 */     return builder()
/* 298 */       .from(instance)
/* 299 */       .build();
/*     */   }
/*     */   
/*     */   public boolean isGuildIdPresent() {
/* 303 */     return !this.guildId_absent;
/*     */   }
/*     */   
/*     */   public long guildIdOrElse(long defaultValue) {
/* 307 */     return !this.guildId_absent ? this.guildId_value : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 323 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "MessageReactionRemoveEmoji", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_EMOJI = 1L;
/*     */ 
/*     */ 
/*     */     
/* 336 */     private long initBits = 1L;
/*     */     
/* 338 */     private Id channelId_id = null;
/* 339 */     private Id messageId_id = null;
/* 340 */     private Possible<Id> guildId_possible = Possible.absent();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private EmojiData emoji;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(MessageReactionRemoveEmoji instance) {
/* 354 */       Objects.requireNonNull(instance, "instance");
/* 355 */       channelId(instance.channelId());
/* 356 */       messageId(instance.messageId());
/* 357 */       guildId(instance.guildId());
/* 358 */       emoji(instance.emoji());
/* 359 */       return this;
/*     */     }
/*     */     
/*     */     public Builder channelId(String value) {
/* 363 */       this.channelId_id = Id.of(value);
/* 364 */       return this;
/*     */     }
/*     */     
/*     */     public Builder channelId(long value) {
/* 368 */       this.channelId_id = Id.of(value);
/* 369 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("channel_id")
/*     */     public Builder channelId(Id value) {
/* 374 */       this.channelId_id = value;
/* 375 */       return this;
/*     */     }
/*     */     
/*     */     public Builder messageId(String value) {
/* 379 */       this.messageId_id = Id.of(value);
/* 380 */       return this;
/*     */     }
/*     */     
/*     */     public Builder messageId(long value) {
/* 384 */       this.messageId_id = Id.of(value);
/* 385 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("message_id")
/*     */     public Builder messageId(Id value) {
/* 390 */       this.messageId_id = value;
/* 391 */       return this;
/*     */     }
/*     */     
/*     */     public Builder guildId(String value) {
/* 395 */       this.guildId_possible = Possible.of(Id.of(value));
/* 396 */       return this;
/*     */     }
/*     */     
/*     */     public Builder guildId(long value) {
/* 400 */       this.guildId_possible = Possible.of(Id.of(value));
/* 401 */       return this;
/*     */     }
/*     */     
/*     */     public Builder guildId(Id value) {
/* 405 */       this.guildId_possible = Possible.of(value);
/* 406 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("guild_id")
/*     */     public Builder guildId(Possible<Id> value) {
/* 411 */       this.guildId_possible = value;
/* 412 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("emoji")
/*     */     public final Builder emoji(EmojiData emoji) {
/* 422 */       this.emoji = Objects.<EmojiData>requireNonNull(emoji, "emoji");
/* 423 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 424 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableMessageReactionRemoveEmoji build() {
/* 433 */       if (this.initBits != 0L) {
/* 434 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 436 */       return new ImmutableMessageReactionRemoveEmoji(null, channelId_build(), messageId_build(), guildId_build(), this.emoji);
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 440 */       List<String> attributes = new ArrayList<>();
/* 441 */       if ((this.initBits & 0x1L) != 0L) attributes.add("emoji"); 
/* 442 */       return "Cannot build MessageReactionRemoveEmoji, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Id channelId_build() {
/* 446 */       return this.channelId_id;
/*     */     }
/*     */     
/*     */     private Id messageId_build() {
/* 450 */       return this.messageId_id;
/*     */     }
/*     */     
/*     */     private Possible<Id> guildId_build() {
/* 454 */       return this.guildId_possible;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\gateway\ImmutableMessageReactionRemoveEmoji.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */