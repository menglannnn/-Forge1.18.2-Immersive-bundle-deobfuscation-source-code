/*    */ package discord4j.discordjson.json.gateway;
/*    */ 
/*    */ import com.fasterxml.jackson.databind.util.StdConverter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HeartbeatConverter
/*    */   extends StdConverter<Heartbeat, Integer>
/*    */ {
/*    */   public Integer convert(Heartbeat value) {
/* 25 */     return Integer.valueOf(value.seq());
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\gateway\HeartbeatConverter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */