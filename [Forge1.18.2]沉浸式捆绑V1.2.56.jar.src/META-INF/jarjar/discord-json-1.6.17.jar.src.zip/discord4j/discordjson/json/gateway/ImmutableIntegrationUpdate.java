/*     */ package discord4j.discordjson.json.gateway;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.annotation.JsonUnwrapped;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.json.IntegrationData;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "IntegrationUpdate", generator = "Immutables")
/*     */ public final class ImmutableIntegrationUpdate
/*     */   implements IntegrationUpdate
/*     */ {
/*     */   private final String guildId;
/*     */   private final IntegrationData integration;
/*     */   
/*     */   private ImmutableIntegrationUpdate(String guildId, IntegrationData integration) {
/*  30 */     this.guildId = Objects.<String>requireNonNull(guildId, "guildId");
/*  31 */     this.integration = Objects.<IntegrationData>requireNonNull(integration, "integration");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ImmutableIntegrationUpdate(ImmutableIntegrationUpdate original, String guildId, IntegrationData integration) {
/*  38 */     this.guildId = guildId;
/*  39 */     this.integration = integration;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("guild_id")
/*     */   public String guildId() {
/*  48 */     return this.guildId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("integration")
/*     */   @JsonUnwrapped
/*     */   public IntegrationData integration() {
/*  58 */     return this.integration;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableIntegrationUpdate withGuildId(String value) {
/*  68 */     String newValue = Objects.<String>requireNonNull(value, "guildId");
/*  69 */     if (this.guildId.equals(newValue)) return this; 
/*  70 */     return new ImmutableIntegrationUpdate(this, newValue, this.integration);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableIntegrationUpdate withIntegration(IntegrationData value) {
/*  80 */     if (this.integration == value) return this; 
/*  81 */     IntegrationData newValue = Objects.<IntegrationData>requireNonNull(value, "integration");
/*  82 */     return new ImmutableIntegrationUpdate(this, this.guildId, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/*  91 */     if (this == another) return true; 
/*  92 */     return (another instanceof ImmutableIntegrationUpdate && 
/*  93 */       equalTo(0, (ImmutableIntegrationUpdate)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableIntegrationUpdate another) {
/*  97 */     return (this.guildId.equals(another.guildId) && this.integration
/*  98 */       .equals(another.integration));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 107 */     int h = 5381;
/* 108 */     h += (h << 5) + this.guildId.hashCode();
/* 109 */     h += (h << 5) + this.integration.hashCode();
/* 110 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 119 */     return "IntegrationUpdate{guildId=" + this.guildId + ", integration=" + this.integration + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "IntegrationUpdate", generator = "Immutables")
/*     */   static final class Json
/*     */     implements IntegrationUpdate
/*     */   {
/*     */     String guildId;
/*     */     
/*     */     IntegrationData integration;
/*     */ 
/*     */     
/*     */     @JsonProperty("guild_id")
/*     */     public void setGuildId(String guildId) {
/* 138 */       this.guildId = guildId;
/*     */     }
/*     */     @JsonProperty("integration")
/*     */     @JsonUnwrapped
/*     */     public void setIntegration(IntegrationData integration) {
/* 143 */       this.integration = integration;
/*     */     }
/*     */     public String guildId() {
/* 146 */       throw new UnsupportedOperationException();
/*     */     } public IntegrationData integration() {
/* 148 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableIntegrationUpdate fromJson(Json json) {
/* 159 */     Builder builder = builder();
/* 160 */     if (json.guildId != null) {
/* 161 */       builder.guildId(json.guildId);
/*     */     }
/* 163 */     if (json.integration != null) {
/* 164 */       builder.integration(json.integration);
/*     */     }
/* 166 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableIntegrationUpdate of(String guildId, IntegrationData integration) {
/* 176 */     return new ImmutableIntegrationUpdate(guildId, integration);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableIntegrationUpdate copyOf(IntegrationUpdate instance) {
/* 187 */     if (instance instanceof ImmutableIntegrationUpdate) {
/* 188 */       return (ImmutableIntegrationUpdate)instance;
/*     */     }
/* 190 */     return builder()
/* 191 */       .from(instance)
/* 192 */       .build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 206 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "IntegrationUpdate", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_GUILD_ID = 1L;
/*     */ 
/*     */     
/*     */     private static final long INIT_BIT_INTEGRATION = 2L;
/*     */ 
/*     */     
/* 220 */     private long initBits = 3L;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private String guildId;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private IntegrationData integration;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(IntegrationUpdate instance) {
/* 236 */       Objects.requireNonNull(instance, "instance");
/* 237 */       guildId(instance.guildId());
/* 238 */       integration(instance.integration());
/* 239 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("guild_id")
/*     */     public final Builder guildId(String guildId) {
/* 249 */       this.guildId = Objects.<String>requireNonNull(guildId, "guildId");
/* 250 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 251 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("integration")
/*     */     @JsonUnwrapped
/*     */     public final Builder integration(IntegrationData integration) {
/* 262 */       this.integration = Objects.<IntegrationData>requireNonNull(integration, "integration");
/* 263 */       this.initBits &= 0xFFFFFFFFFFFFFFFDL;
/* 264 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableIntegrationUpdate build() {
/* 273 */       if (this.initBits != 0L) {
/* 274 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 276 */       return new ImmutableIntegrationUpdate(null, this.guildId, this.integration);
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 280 */       List<String> attributes = new ArrayList<>();
/* 281 */       if ((this.initBits & 0x1L) != 0L) attributes.add("guildId"); 
/* 282 */       if ((this.initBits & 0x2L) != 0L) attributes.add("integration"); 
/* 283 */       return "Cannot build IntegrationUpdate, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\gateway\ImmutableIntegrationUpdate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */