/*     */ package discord4j.discordjson.json.gateway;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.Id;
/*     */ import discord4j.discordjson.json.EmojiData;
/*     */ import discord4j.discordjson.json.MemberData;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "MessageReactionAdd", generator = "Immutables")
/*     */ public final class ImmutableMessageReactionAdd
/*     */   implements MessageReactionAdd
/*     */ {
/*     */   private final long userId_value;
/*     */   private final long channelId_value;
/*     */   private final long messageId_value;
/*     */   private final long guildId_value;
/*     */   private final boolean guildId_absent;
/*     */   private final MemberData member_value;
/*     */   private final boolean member_absent;
/*     */   private final EmojiData emoji;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   
/*     */   private ImmutableMessageReactionAdd(Id userId, Id channelId, Id messageId, Possible<Id> guildId, Possible<MemberData> member, EmojiData emoji) {
/*  45 */     Id userId$impl = userId;
/*  46 */     Id channelId$impl = channelId;
/*  47 */     Id messageId$impl = messageId;
/*  48 */     Possible<Id> guildId$impl = guildId;
/*  49 */     Possible<MemberData> member$impl = member;
/*  50 */     this.emoji = Objects.<EmojiData>requireNonNull(emoji, "emoji");
/*  51 */     this.userId_value = userId$impl.asLong();
/*  52 */     this.channelId_value = channelId$impl.asLong();
/*  53 */     this.messageId_value = messageId$impl.asLong();
/*  54 */     this
/*     */       
/*  56 */       .guildId_value = ((Long)guildId$impl.toOptional().map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  57 */     this.guildId_absent = guildId$impl.isAbsent();
/*  58 */     this.member_value = member$impl.toOptional().orElse(null);
/*  59 */     this.member_absent = member$impl.isAbsent();
/*  60 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ImmutableMessageReactionAdd(ImmutableMessageReactionAdd original, Id userId, Id channelId, Id messageId, Possible<Id> guildId, Possible<MemberData> member, EmojiData emoji) {
/*  71 */     Id userId$impl = userId;
/*  72 */     Id channelId$impl = channelId;
/*  73 */     Id messageId$impl = messageId;
/*  74 */     Possible<Id> guildId$impl = guildId;
/*  75 */     Possible<MemberData> member$impl = member;
/*  76 */     this.emoji = emoji;
/*  77 */     this.userId_value = userId$impl.asLong();
/*  78 */     this.channelId_value = channelId$impl.asLong();
/*  79 */     this.messageId_value = messageId$impl.asLong();
/*  80 */     this
/*     */       
/*  82 */       .guildId_value = ((Long)guildId$impl.toOptional().map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  83 */     this.guildId_absent = guildId$impl.isAbsent();
/*  84 */     this.member_value = member$impl.toOptional().orElse(null);
/*  85 */     this.member_absent = member$impl.isAbsent();
/*  86 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  92 */   private volatile transient InitShim initShim = new InitShim();
/*     */   
/*     */   @Generated(from = "MessageReactionAdd", generator = "Immutables")
/*     */   private final class InitShim {
/*     */     private String formatInitCycleMessage() {
/*  97 */       List<String> attributes = new ArrayList<>();
/*  98 */       return "Cannot build MessageReactionAdd, attribute initializers form cycle " + attributes;
/*     */     }
/*     */ 
/*     */     
/*     */     private InitShim() {}
/*     */   }
/*     */ 
/*     */   
/*     */   @JsonProperty("user_id")
/*     */   public Id userId() {
/* 108 */     return Id.of(this.userId_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("channel_id")
/*     */   public Id channelId() {
/* 117 */     return Id.of(this.channelId_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("message_id")
/*     */   public Id messageId() {
/* 126 */     return Id.of(this.messageId_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("guild_id")
/*     */   public Possible<Id> guildId() {
/* 135 */     return this.guildId_absent ? Possible.absent() : 
/* 136 */       Possible.of(Id.of(this.guildId_value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("member")
/*     */   public Possible<MemberData> member() {
/* 145 */     return this.member_absent ? Possible.absent() : Possible.of(this.member_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("emoji")
/*     */   public EmojiData emoji() {
/* 154 */     return this.emoji;
/*     */   }
/*     */   
/*     */   public ImmutableMessageReactionAdd withUserId(long value) {
/* 158 */     Id newValue = Id.of(value);
/* 159 */     return new ImmutableMessageReactionAdd(this, newValue, channelId(), messageId(), guildId(), member(), this.emoji);
/*     */   }
/*     */   
/*     */   public ImmutableMessageReactionAdd withUserId(String value) {
/* 163 */     Id newValue = Id.of(value);
/* 164 */     return new ImmutableMessageReactionAdd(this, newValue, channelId(), messageId(), guildId(), member(), this.emoji);
/*     */   }
/*     */   
/*     */   public ImmutableMessageReactionAdd withChannelId(long value) {
/* 168 */     Id newValue = Id.of(value);
/* 169 */     return new ImmutableMessageReactionAdd(this, userId(), newValue, messageId(), guildId(), member(), this.emoji);
/*     */   }
/*     */   
/*     */   public ImmutableMessageReactionAdd withChannelId(String value) {
/* 173 */     Id newValue = Id.of(value);
/* 174 */     return new ImmutableMessageReactionAdd(this, userId(), newValue, messageId(), guildId(), member(), this.emoji);
/*     */   }
/*     */   
/*     */   public ImmutableMessageReactionAdd withMessageId(long value) {
/* 178 */     Id newValue = Id.of(value);
/* 179 */     return new ImmutableMessageReactionAdd(this, userId(), channelId(), newValue, guildId(), member(), this.emoji);
/*     */   }
/*     */   
/*     */   public ImmutableMessageReactionAdd withMessageId(String value) {
/* 183 */     Id newValue = Id.of(value);
/* 184 */     return new ImmutableMessageReactionAdd(this, userId(), channelId(), newValue, guildId(), member(), this.emoji);
/*     */   }
/*     */   
/*     */   public ImmutableMessageReactionAdd withGuildId(Possible<Id> value) {
/* 188 */     Possible<Id> newValue = Objects.<Possible<Id>>requireNonNull(value);
/* 189 */     return new ImmutableMessageReactionAdd(this, userId(), channelId(), messageId(), newValue, member(), this.emoji);
/*     */   }
/*     */   
/*     */   public ImmutableMessageReactionAdd withGuildId(long value) {
/* 193 */     Possible<Id> newValue = Possible.of(Id.of(value));
/* 194 */     return new ImmutableMessageReactionAdd(this, userId(), channelId(), messageId(), newValue, member(), this.emoji);
/*     */   }
/*     */   
/*     */   public ImmutableMessageReactionAdd withMember(Possible<MemberData> value) {
/* 198 */     Possible<MemberData> newValue = Objects.<Possible<MemberData>>requireNonNull(value);
/* 199 */     return new ImmutableMessageReactionAdd(this, userId(), channelId(), messageId(), guildId(), newValue, this.emoji);
/*     */   }
/*     */   
/*     */   public ImmutableMessageReactionAdd withMember(MemberData value) {
/* 203 */     Possible<MemberData> newValue = Possible.of(value);
/* 204 */     return new ImmutableMessageReactionAdd(this, userId(), channelId(), messageId(), guildId(), newValue, this.emoji);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableMessageReactionAdd withEmoji(EmojiData value) {
/* 214 */     if (this.emoji == value) return this; 
/* 215 */     EmojiData newValue = Objects.<EmojiData>requireNonNull(value, "emoji");
/* 216 */     return new ImmutableMessageReactionAdd(this, 
/*     */         
/* 218 */         userId(), 
/* 219 */         channelId(), 
/* 220 */         messageId(), 
/* 221 */         guildId(), 
/* 222 */         member(), newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 232 */     if (this == another) return true; 
/* 233 */     return (another instanceof ImmutableMessageReactionAdd && 
/* 234 */       equalTo(0, (ImmutableMessageReactionAdd)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableMessageReactionAdd another) {
/* 238 */     return (Objects.equals(Long.valueOf(this.userId_value), Long.valueOf(another.userId_value)) && 
/* 239 */       Objects.equals(Long.valueOf(this.channelId_value), Long.valueOf(another.channelId_value)) && 
/* 240 */       Objects.equals(Long.valueOf(this.messageId_value), Long.valueOf(another.messageId_value)) && 
/* 241 */       guildId().equals(another.guildId()) && 
/* 242 */       member().equals(another.member()) && this.emoji
/* 243 */       .equals(another.emoji));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 252 */     int h = 5381;
/* 253 */     h += (h << 5) + Objects.hashCode(Long.valueOf(this.userId_value));
/* 254 */     h += (h << 5) + Objects.hashCode(Long.valueOf(this.channelId_value));
/* 255 */     h += (h << 5) + Objects.hashCode(Long.valueOf(this.messageId_value));
/* 256 */     h += (h << 5) + guildId().hashCode();
/* 257 */     h += (h << 5) + member().hashCode();
/* 258 */     h += (h << 5) + this.emoji.hashCode();
/* 259 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 268 */     return "MessageReactionAdd{userId=" + 
/* 269 */       Objects.toString(Long.valueOf(this.userId_value)) + ", channelId=" + 
/* 270 */       Objects.toString(Long.valueOf(this.channelId_value)) + ", messageId=" + 
/* 271 */       Objects.toString(Long.valueOf(this.messageId_value)) + ", guildId=" + 
/* 272 */       guildId().toString() + ", member=" + 
/* 273 */       member().toString() + ", emoji=" + this.emoji + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "MessageReactionAdd", generator = "Immutables")
/*     */   static final class Json
/*     */     implements MessageReactionAdd
/*     */   {
/*     */     Id userId;
/*     */     
/*     */     Id channelId;
/*     */     
/*     */     Id messageId;
/*     */     
/* 291 */     Possible<Id> guildId = Possible.absent();
/*     */ 
/*     */     
/* 294 */     Possible<MemberData> member = Possible.absent();
/*     */     EmojiData emoji;
/*     */     
/*     */     @JsonProperty("user_id")
/*     */     public void setUserId(Id userId) {
/* 299 */       this.userId = userId;
/*     */     }
/*     */     @JsonProperty("channel_id")
/*     */     public void setChannelId(Id channelId) {
/* 303 */       this.channelId = channelId;
/*     */     }
/*     */     @JsonProperty("message_id")
/*     */     public void setMessageId(Id messageId) {
/* 307 */       this.messageId = messageId;
/*     */     }
/*     */     @JsonProperty("guild_id")
/*     */     public void setGuildId(Possible<Id> guildId) {
/* 311 */       this.guildId = guildId;
/*     */     }
/*     */     @JsonProperty("member")
/*     */     public void setMember(Possible<MemberData> member) {
/* 315 */       this.member = member;
/*     */     }
/*     */     @JsonProperty("emoji")
/*     */     public void setEmoji(EmojiData emoji) {
/* 319 */       this.emoji = emoji;
/*     */     }
/*     */     public Id userId() {
/* 322 */       throw new UnsupportedOperationException();
/*     */     } public Id channelId() {
/* 324 */       throw new UnsupportedOperationException();
/*     */     } public Id messageId() {
/* 326 */       throw new UnsupportedOperationException();
/*     */     } public Possible<Id> guildId() {
/* 328 */       throw new UnsupportedOperationException();
/*     */     } public Possible<MemberData> member() {
/* 330 */       throw new UnsupportedOperationException();
/*     */     } public EmojiData emoji() {
/* 332 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableMessageReactionAdd fromJson(Json json) {
/* 343 */     Builder builder = builder();
/* 344 */     if (json.userId != null) {
/* 345 */       builder.userId(json.userId);
/*     */     }
/* 347 */     if (json.channelId != null) {
/* 348 */       builder.channelId(json.channelId);
/*     */     }
/* 350 */     if (json.messageId != null) {
/* 351 */       builder.messageId(json.messageId);
/*     */     }
/* 353 */     if (json.guildId != null) {
/* 354 */       builder.guildId(json.guildId);
/*     */     }
/* 356 */     if (json.member != null) {
/* 357 */       builder.member(json.member);
/*     */     }
/* 359 */     if (json.emoji != null) {
/* 360 */       builder.emoji(json.emoji);
/*     */     }
/* 362 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableMessageReactionAdd of(Id userId, Id channelId, Id messageId, Possible<Id> guildId, Possible<MemberData> member, EmojiData emoji) {
/* 376 */     return new ImmutableMessageReactionAdd(userId, channelId, messageId, guildId, member, emoji);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableMessageReactionAdd copyOf(MessageReactionAdd instance) {
/* 387 */     if (instance instanceof ImmutableMessageReactionAdd) {
/* 388 */       return (ImmutableMessageReactionAdd)instance;
/*     */     }
/* 390 */     return builder()
/* 391 */       .from(instance)
/* 392 */       .build();
/*     */   }
/*     */   
/*     */   public boolean isGuildIdPresent() {
/* 396 */     return !this.guildId_absent;
/*     */   }
/*     */   
/*     */   public long guildIdOrElse(long defaultValue) {
/* 400 */     return !this.guildId_absent ? this.guildId_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isMemberPresent() {
/* 404 */     return !this.member_absent;
/*     */   }
/*     */   
/*     */   public MemberData memberOrElse(MemberData defaultValue) {
/* 408 */     return !this.member_absent ? this.member_value : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 426 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "MessageReactionAdd", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_EMOJI = 1L;
/*     */ 
/*     */ 
/*     */     
/* 439 */     private long initBits = 1L;
/*     */     
/* 441 */     private Id userId_id = null;
/* 442 */     private Id channelId_id = null;
/* 443 */     private Id messageId_id = null;
/* 444 */     private Possible<Id> guildId_possible = Possible.absent();
/* 445 */     private Possible<MemberData> member_possible = Possible.absent();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private EmojiData emoji;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(MessageReactionAdd instance) {
/* 459 */       Objects.requireNonNull(instance, "instance");
/* 460 */       userId(instance.userId());
/* 461 */       channelId(instance.channelId());
/* 462 */       messageId(instance.messageId());
/* 463 */       guildId(instance.guildId());
/* 464 */       member(instance.member());
/* 465 */       emoji(instance.emoji());
/* 466 */       return this;
/*     */     }
/*     */     
/*     */     public Builder userId(String value) {
/* 470 */       this.userId_id = Id.of(value);
/* 471 */       return this;
/*     */     }
/*     */     
/*     */     public Builder userId(long value) {
/* 475 */       this.userId_id = Id.of(value);
/* 476 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("user_id")
/*     */     public Builder userId(Id value) {
/* 481 */       this.userId_id = value;
/* 482 */       return this;
/*     */     }
/*     */     
/*     */     public Builder channelId(String value) {
/* 486 */       this.channelId_id = Id.of(value);
/* 487 */       return this;
/*     */     }
/*     */     
/*     */     public Builder channelId(long value) {
/* 491 */       this.channelId_id = Id.of(value);
/* 492 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("channel_id")
/*     */     public Builder channelId(Id value) {
/* 497 */       this.channelId_id = value;
/* 498 */       return this;
/*     */     }
/*     */     
/*     */     public Builder messageId(String value) {
/* 502 */       this.messageId_id = Id.of(value);
/* 503 */       return this;
/*     */     }
/*     */     
/*     */     public Builder messageId(long value) {
/* 507 */       this.messageId_id = Id.of(value);
/* 508 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("message_id")
/*     */     public Builder messageId(Id value) {
/* 513 */       this.messageId_id = value;
/* 514 */       return this;
/*     */     }
/*     */     
/*     */     public Builder guildId(String value) {
/* 518 */       this.guildId_possible = Possible.of(Id.of(value));
/* 519 */       return this;
/*     */     }
/*     */     
/*     */     public Builder guildId(long value) {
/* 523 */       this.guildId_possible = Possible.of(Id.of(value));
/* 524 */       return this;
/*     */     }
/*     */     
/*     */     public Builder guildId(Id value) {
/* 528 */       this.guildId_possible = Possible.of(value);
/* 529 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("guild_id")
/*     */     public Builder guildId(Possible<Id> value) {
/* 534 */       this.guildId_possible = value;
/* 535 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("member")
/*     */     public Builder member(Possible<MemberData> value) {
/* 540 */       this.member_possible = value;
/* 541 */       return this;
/*     */     }
/*     */     
/*     */     public Builder member(MemberData value) {
/* 545 */       this.member_possible = Possible.of(value);
/* 546 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("emoji")
/*     */     public final Builder emoji(EmojiData emoji) {
/* 556 */       this.emoji = Objects.<EmojiData>requireNonNull(emoji, "emoji");
/* 557 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 558 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableMessageReactionAdd build() {
/* 567 */       if (this.initBits != 0L) {
/* 568 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 570 */       return new ImmutableMessageReactionAdd(null, 
/*     */           
/* 572 */           userId_build(), 
/* 573 */           channelId_build(), 
/* 574 */           messageId_build(), 
/* 575 */           guildId_build(), 
/* 576 */           member_build(), this.emoji);
/*     */     }
/*     */ 
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 581 */       List<String> attributes = new ArrayList<>();
/* 582 */       if ((this.initBits & 0x1L) != 0L) attributes.add("emoji"); 
/* 583 */       return "Cannot build MessageReactionAdd, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Id userId_build() {
/* 587 */       return this.userId_id;
/*     */     }
/*     */     
/*     */     private Id channelId_build() {
/* 591 */       return this.channelId_id;
/*     */     }
/*     */     
/*     */     private Id messageId_build() {
/* 595 */       return this.messageId_id;
/*     */     }
/*     */     
/*     */     private Possible<Id> guildId_build() {
/* 599 */       return this.guildId_possible;
/*     */     }
/*     */     
/*     */     private Possible<MemberData> member_build() {
/* 603 */       return this.member_possible;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\gateway\ImmutableMessageReactionAdd.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */