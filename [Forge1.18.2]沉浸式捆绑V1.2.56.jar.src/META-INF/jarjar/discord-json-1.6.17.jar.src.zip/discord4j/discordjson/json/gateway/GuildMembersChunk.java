/*    */ package discord4j.discordjson.json.gateway;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonProperty;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import discord4j.discordjson.Id;
/*    */ import discord4j.discordjson.json.MemberData;
/*    */ import discord4j.discordjson.json.PresenceData;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import java.util.List;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ @JsonSerialize(as = ImmutableGuildMembersChunk.class)
/*    */ @JsonDeserialize(as = ImmutableGuildMembersChunk.class)
/*    */ @Immutable
/*    */ public interface GuildMembersChunk
/*    */   extends Dispatch
/*    */ {
/*    */   static ImmutableGuildMembersChunk.Builder builder() {
/* 20 */     return ImmutableGuildMembersChunk.builder();
/*    */   }
/*    */   
/*    */   @JsonProperty("guild_id")
/*    */   Id guildId();
/*    */   
/*    */   List<MemberData> members();
/*    */   
/*    */   @JsonProperty("chunk_index")
/*    */   int chunkIndex();
/*    */   
/*    */   @JsonProperty("chunk_count")
/*    */   int chunkCount();
/*    */   
/*    */   @JsonProperty("not_found")
/*    */   Possible<List<String>> notFound();
/*    */   
/*    */   Possible<List<PresenceData>> presences();
/*    */   
/*    */   Possible<String> nonce();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\gateway\GuildMembersChunk.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */