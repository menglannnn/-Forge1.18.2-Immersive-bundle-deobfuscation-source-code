/*    */ package discord4j.discordjson.json.gateway;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonProperty;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import discord4j.discordjson.Id;
/*    */ import discord4j.discordjson.json.MemberData;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ @JsonSerialize(as = ImmutableTypingStart.class)
/*    */ @JsonDeserialize(as = ImmutableTypingStart.class)
/*    */ @Immutable
/*    */ public interface TypingStart
/*    */   extends Dispatch {
/*    */   static ImmutableTypingStart.Builder builder() {
/* 17 */     return ImmutableTypingStart.builder();
/*    */   }
/*    */   
/*    */   @JsonProperty("channel_id")
/*    */   Id channelId();
/*    */   
/*    */   @JsonProperty("guild_id")
/*    */   Possible<Id> guildId();
/*    */   
/*    */   @JsonProperty("user_id")
/*    */   Id userId();
/*    */   
/*    */   long timestamp();
/*    */   
/*    */   Possible<MemberData> member();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\gateway\TypingStart.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */