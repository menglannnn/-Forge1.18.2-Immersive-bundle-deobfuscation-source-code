package discord4j.discordjson.json;

import com.fasterxml.jackson.annotation.JsonProperty;
import discord4j.discordjson.Id;
import discord4j.discordjson.possible.Possible;
import java.util.Optional;

public interface RoleDataFields {
  Id id();
  
  String name();
  
  int color();
  
  boolean hoist();
  
  long permissions();
  
  boolean mentionable();
  
  Possible<Optional<String>> icon();
  
  @JsonProperty("unicode_emoji")
  Possible<Optional<String>> unicodeEmoji();
  
  Possible<RoleTagsData> tags();
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\RoleDataFields.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */