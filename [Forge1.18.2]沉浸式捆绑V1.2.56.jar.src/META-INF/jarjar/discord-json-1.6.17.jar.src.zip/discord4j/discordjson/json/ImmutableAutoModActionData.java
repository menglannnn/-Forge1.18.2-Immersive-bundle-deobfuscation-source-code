/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "AutoModActionData", generator = "Immutables")
/*     */ public final class ImmutableAutoModActionData
/*     */   implements AutoModActionData
/*     */ {
/*     */   private final int type;
/*     */   private final AutoModActionMetaData metadata_value;
/*     */   private final boolean metadata_absent;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   private volatile transient InitShim initShim;
/*     */   
/*     */   private ImmutableAutoModActionData(int type, Possible<AutoModActionMetaData> metadata) {
/*  53 */     this.initShim = new InitShim(); this.type = type; Possible<AutoModActionMetaData> metadata$impl = metadata; this.metadata_value = metadata$impl.toOptional().orElse(null); this.metadata_absent = metadata$impl.isAbsent(); this.initShim = null; } private ImmutableAutoModActionData(ImmutableAutoModActionData original, int type, Possible<AutoModActionMetaData> metadata) { this.initShim = new InitShim();
/*     */     this.type = type;
/*     */     Possible<AutoModActionMetaData> metadata$impl = metadata;
/*     */     this.metadata_value = metadata$impl.toOptional().orElse(null);
/*     */     this.metadata_absent = metadata$impl.isAbsent();
/*  58 */     this.initShim = null; } @Generated(from = "AutoModActionData", generator = "Immutables") private final class InitShim { private InitShim() {} private String formatInitCycleMessage() { List<String> attributes = new ArrayList<>();
/*  59 */       return "Cannot build AutoModActionData, attribute initializers form cycle " + attributes; }
/*     */      }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("type")
/*     */   public int type() {
/*  69 */     return this.type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("metadata")
/*     */   public Possible<AutoModActionMetaData> metadata() {
/*  78 */     return this.metadata_absent ? Possible.absent() : Possible.of(this.metadata_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableAutoModActionData withType(int value) {
/*  88 */     if (this.type == value) return this; 
/*  89 */     return new ImmutableAutoModActionData(this, value, metadata());
/*     */   }
/*     */   
/*     */   public ImmutableAutoModActionData withMetadata(Possible<AutoModActionMetaData> value) {
/*  93 */     Possible<AutoModActionMetaData> newValue = Objects.<Possible<AutoModActionMetaData>>requireNonNull(value);
/*  94 */     return new ImmutableAutoModActionData(this, this.type, newValue);
/*     */   }
/*     */   
/*     */   public ImmutableAutoModActionData withMetadata(AutoModActionMetaData value) {
/*  98 */     Possible<AutoModActionMetaData> newValue = Possible.of(value);
/*  99 */     return new ImmutableAutoModActionData(this, this.type, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 108 */     if (this == another) return true; 
/* 109 */     return (another instanceof ImmutableAutoModActionData && 
/* 110 */       equalTo(0, (ImmutableAutoModActionData)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableAutoModActionData another) {
/* 114 */     return (this.type == another.type && 
/* 115 */       metadata().equals(another.metadata()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 124 */     int h = 5381;
/* 125 */     h += (h << 5) + this.type;
/* 126 */     h += (h << 5) + metadata().hashCode();
/* 127 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 136 */     return "AutoModActionData{type=" + this.type + ", metadata=" + 
/*     */       
/* 138 */       metadata().toString() + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "AutoModActionData", generator = "Immutables")
/*     */   static final class Json
/*     */     implements AutoModActionData
/*     */   {
/*     */     int type;
/*     */     
/*     */     boolean typeIsSet;
/*     */     
/* 154 */     Possible<AutoModActionMetaData> metadata = Possible.absent();
/*     */     
/*     */     @JsonProperty("type")
/*     */     public void setType(int type) {
/* 158 */       this.type = type;
/* 159 */       this.typeIsSet = true;
/*     */     }
/*     */     @JsonProperty("metadata")
/*     */     public void setMetadata(Possible<AutoModActionMetaData> metadata) {
/* 163 */       this.metadata = metadata;
/*     */     }
/*     */     public int type() {
/* 166 */       throw new UnsupportedOperationException();
/*     */     } public Possible<AutoModActionMetaData> metadata() {
/* 168 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableAutoModActionData fromJson(Json json) {
/* 179 */     Builder builder = builder();
/* 180 */     if (json.typeIsSet) {
/* 181 */       builder.type(json.type);
/*     */     }
/* 183 */     if (json.metadata != null) {
/* 184 */       builder.metadata(json.metadata);
/*     */     }
/* 186 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableAutoModActionData of(int type, Possible<AutoModActionMetaData> metadata) {
/* 196 */     return new ImmutableAutoModActionData(type, metadata);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableAutoModActionData copyOf(AutoModActionData instance) {
/* 207 */     if (instance instanceof ImmutableAutoModActionData) {
/* 208 */       return (ImmutableAutoModActionData)instance;
/*     */     }
/* 210 */     return builder()
/* 211 */       .from(instance)
/* 212 */       .build();
/*     */   }
/*     */   
/*     */   public boolean isMetadataPresent() {
/* 216 */     return !this.metadata_absent;
/*     */   }
/*     */   
/*     */   public AutoModActionMetaData metadataOrElse(AutoModActionMetaData defaultValue) {
/* 220 */     return !this.metadata_absent ? this.metadata_value : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 234 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "AutoModActionData", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_TYPE = 1L;
/*     */ 
/*     */ 
/*     */     
/* 247 */     private long initBits = 1L;
/*     */     
/* 249 */     private Possible<AutoModActionMetaData> metadata_possible = Possible.absent();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private int type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(AutoModActionData instance) {
/* 263 */       Objects.requireNonNull(instance, "instance");
/* 264 */       type(instance.type());
/* 265 */       metadata(instance.metadata());
/* 266 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("type")
/*     */     public final Builder type(int type) {
/* 276 */       this.type = type;
/* 277 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 278 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("metadata")
/*     */     public Builder metadata(Possible<AutoModActionMetaData> value) {
/* 283 */       this.metadata_possible = value;
/* 284 */       return this;
/*     */     }
/*     */     
/*     */     public Builder metadata(AutoModActionMetaData value) {
/* 288 */       this.metadata_possible = Possible.of(value);
/* 289 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableAutoModActionData build() {
/* 298 */       if (this.initBits != 0L) {
/* 299 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 301 */       return new ImmutableAutoModActionData(null, this.type, metadata_build());
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 305 */       List<String> attributes = new ArrayList<>();
/* 306 */       if ((this.initBits & 0x1L) != 0L) attributes.add("type"); 
/* 307 */       return "Cannot build AutoModActionData, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Possible<AutoModActionMetaData> metadata_build() {
/* 311 */       return this.metadata_possible;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableAutoModActionData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */