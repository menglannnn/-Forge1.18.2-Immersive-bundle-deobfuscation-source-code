/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "UpdateUserVoiceStateRequest", generator = "Immutables")
/*     */ public final class ImmutableUpdateUserVoiceStateRequest
/*     */   implements UpdateUserVoiceStateRequest
/*     */ {
/*     */   private final String channelId;
/*     */   private final Boolean suppress_value;
/*     */   private final boolean suppress_absent;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   private volatile transient InitShim initShim;
/*     */   
/*     */   private ImmutableUpdateUserVoiceStateRequest(String channelId, Possible<Boolean> suppress) {
/*  52 */     this.initShim = new InitShim(); this.channelId = Objects.<String>requireNonNull(channelId, "channelId"); Possible<Boolean> suppress$impl = suppress; this.suppress_value = suppress$impl.toOptional().orElse(null); this.suppress_absent = suppress$impl.isAbsent(); this.initShim = null; } private ImmutableUpdateUserVoiceStateRequest(ImmutableUpdateUserVoiceStateRequest original, String channelId, Possible<Boolean> suppress) { this.initShim = new InitShim();
/*     */     this.channelId = channelId;
/*     */     Possible<Boolean> suppress$impl = suppress;
/*     */     this.suppress_value = suppress$impl.toOptional().orElse(null);
/*     */     this.suppress_absent = suppress$impl.isAbsent();
/*  57 */     this.initShim = null; } @Generated(from = "UpdateUserVoiceStateRequest", generator = "Immutables") private final class InitShim { private InitShim() {} private String formatInitCycleMessage() { List<String> attributes = new ArrayList<>();
/*  58 */       return "Cannot build UpdateUserVoiceStateRequest, attribute initializers form cycle " + attributes; }
/*     */      }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("channel_id")
/*     */   public String channelId() {
/*  68 */     return this.channelId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("suppress")
/*     */   public Possible<Boolean> suppress() {
/*  77 */     return this.suppress_absent ? Possible.absent() : Possible.of(this.suppress_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableUpdateUserVoiceStateRequest withChannelId(String value) {
/*  87 */     String newValue = Objects.<String>requireNonNull(value, "channelId");
/*  88 */     if (this.channelId.equals(newValue)) return this; 
/*  89 */     return new ImmutableUpdateUserVoiceStateRequest(this, newValue, suppress());
/*     */   }
/*     */   
/*     */   public ImmutableUpdateUserVoiceStateRequest withSuppress(Possible<Boolean> value) {
/*  93 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/*  94 */     return new ImmutableUpdateUserVoiceStateRequest(this, this.channelId, newValue);
/*     */   }
/*     */   
/*     */   public ImmutableUpdateUserVoiceStateRequest withSuppress(Boolean value) {
/*  98 */     Possible<Boolean> newValue = Possible.of(value);
/*  99 */     return new ImmutableUpdateUserVoiceStateRequest(this, this.channelId, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 108 */     if (this == another) return true; 
/* 109 */     return (another instanceof ImmutableUpdateUserVoiceStateRequest && 
/* 110 */       equalTo(0, (ImmutableUpdateUserVoiceStateRequest)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableUpdateUserVoiceStateRequest another) {
/* 114 */     return (this.channelId.equals(another.channelId) && 
/* 115 */       suppress().equals(another.suppress()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 124 */     int h = 5381;
/* 125 */     h += (h << 5) + this.channelId.hashCode();
/* 126 */     h += (h << 5) + suppress().hashCode();
/* 127 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 136 */     return "UpdateUserVoiceStateRequest{channelId=" + this.channelId + ", suppress=" + 
/*     */       
/* 138 */       suppress().toString() + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "UpdateUserVoiceStateRequest", generator = "Immutables")
/*     */   static final class Json
/*     */     implements UpdateUserVoiceStateRequest
/*     */   {
/*     */     String channelId;
/*     */ 
/*     */     
/* 153 */     Possible<Boolean> suppress = Possible.absent();
/*     */     
/*     */     @JsonProperty("channel_id")
/*     */     public void setChannelId(String channelId) {
/* 157 */       this.channelId = channelId;
/*     */     }
/*     */     @JsonProperty("suppress")
/*     */     public void setSuppress(Possible<Boolean> suppress) {
/* 161 */       this.suppress = suppress;
/*     */     }
/*     */     public String channelId() {
/* 164 */       throw new UnsupportedOperationException();
/*     */     } public Possible<Boolean> suppress() {
/* 166 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableUpdateUserVoiceStateRequest fromJson(Json json) {
/* 177 */     Builder builder = builder();
/* 178 */     if (json.channelId != null) {
/* 179 */       builder.channelId(json.channelId);
/*     */     }
/* 181 */     if (json.suppress != null) {
/* 182 */       builder.suppress(json.suppress);
/*     */     }
/* 184 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableUpdateUserVoiceStateRequest of(String channelId, Possible<Boolean> suppress) {
/* 194 */     return new ImmutableUpdateUserVoiceStateRequest(channelId, suppress);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableUpdateUserVoiceStateRequest copyOf(UpdateUserVoiceStateRequest instance) {
/* 205 */     if (instance instanceof ImmutableUpdateUserVoiceStateRequest) {
/* 206 */       return (ImmutableUpdateUserVoiceStateRequest)instance;
/*     */     }
/* 208 */     return builder()
/* 209 */       .from(instance)
/* 210 */       .build();
/*     */   }
/*     */   
/*     */   public boolean isSuppressPresent() {
/* 214 */     return !this.suppress_absent;
/*     */   }
/*     */   
/*     */   public Boolean suppressOrElse(Boolean defaultValue) {
/* 218 */     return !this.suppress_absent ? this.suppress_value : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 232 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "UpdateUserVoiceStateRequest", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_CHANNEL_ID = 1L;
/*     */ 
/*     */ 
/*     */     
/* 245 */     private long initBits = 1L;
/*     */     
/* 247 */     private Possible<Boolean> suppress_possible = Possible.absent();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private String channelId;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(UpdateUserVoiceStateRequest instance) {
/* 261 */       Objects.requireNonNull(instance, "instance");
/* 262 */       channelId(instance.channelId());
/* 263 */       suppress(instance.suppress());
/* 264 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("channel_id")
/*     */     public final Builder channelId(String channelId) {
/* 274 */       this.channelId = Objects.<String>requireNonNull(channelId, "channelId");
/* 275 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 276 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("suppress")
/*     */     public Builder suppress(Possible<Boolean> value) {
/* 281 */       this.suppress_possible = value;
/* 282 */       return this;
/*     */     }
/*     */     
/*     */     public Builder suppress(Boolean value) {
/* 286 */       this.suppress_possible = Possible.of(value);
/* 287 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableUpdateUserVoiceStateRequest build() {
/* 296 */       if (this.initBits != 0L) {
/* 297 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 299 */       return new ImmutableUpdateUserVoiceStateRequest(null, this.channelId, suppress_build());
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 303 */       List<String> attributes = new ArrayList<>();
/* 304 */       if ((this.initBits & 0x1L) != 0L) attributes.add("channelId"); 
/* 305 */       return "Cannot build UpdateUserVoiceStateRequest, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Possible<Boolean> suppress_build() {
/* 309 */       return this.suppress_possible;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableUpdateUserVoiceStateRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */