/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "GroupAddRecipientRequest", generator = "Immutables")
/*     */ public final class ImmutableGroupAddRecipientRequest
/*     */   implements GroupAddRecipientRequest
/*     */ {
/*     */   private final String accessToken;
/*     */   private final String nick;
/*     */   
/*     */   private ImmutableGroupAddRecipientRequest(String accessToken, String nick) {
/*  29 */     this.accessToken = Objects.<String>requireNonNull(accessToken, "accessToken");
/*  30 */     this.nick = Objects.<String>requireNonNull(nick, "nick");
/*     */   }
/*     */   
/*     */   private ImmutableGroupAddRecipientRequest(ImmutableGroupAddRecipientRequest original, String accessToken, String nick) {
/*  34 */     this.accessToken = accessToken;
/*  35 */     this.nick = nick;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("access_token")
/*     */   public String accessToken() {
/*  44 */     return this.accessToken;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("nick")
/*     */   public String nick() {
/*  53 */     return this.nick;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableGroupAddRecipientRequest withAccessToken(String value) {
/*  63 */     String newValue = Objects.<String>requireNonNull(value, "accessToken");
/*  64 */     if (this.accessToken.equals(newValue)) return this; 
/*  65 */     return new ImmutableGroupAddRecipientRequest(this, newValue, this.nick);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableGroupAddRecipientRequest withNick(String value) {
/*  75 */     String newValue = Objects.<String>requireNonNull(value, "nick");
/*  76 */     if (this.nick.equals(newValue)) return this; 
/*  77 */     return new ImmutableGroupAddRecipientRequest(this, this.accessToken, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/*  86 */     if (this == another) return true; 
/*  87 */     return (another instanceof ImmutableGroupAddRecipientRequest && 
/*  88 */       equalTo(0, (ImmutableGroupAddRecipientRequest)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableGroupAddRecipientRequest another) {
/*  92 */     return (this.accessToken.equals(another.accessToken) && this.nick
/*  93 */       .equals(another.nick));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 102 */     int h = 5381;
/* 103 */     h += (h << 5) + this.accessToken.hashCode();
/* 104 */     h += (h << 5) + this.nick.hashCode();
/* 105 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 114 */     return "GroupAddRecipientRequest{accessToken=" + this.accessToken + ", nick=" + this.nick + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "GroupAddRecipientRequest", generator = "Immutables")
/*     */   static final class Json
/*     */     implements GroupAddRecipientRequest
/*     */   {
/*     */     String accessToken;
/*     */     
/*     */     String nick;
/*     */ 
/*     */     
/*     */     @JsonProperty("access_token")
/*     */     public void setAccessToken(String accessToken) {
/* 133 */       this.accessToken = accessToken;
/*     */     }
/*     */     @JsonProperty("nick")
/*     */     public void setNick(String nick) {
/* 137 */       this.nick = nick;
/*     */     }
/*     */     public String accessToken() {
/* 140 */       throw new UnsupportedOperationException();
/*     */     } public String nick() {
/* 142 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableGroupAddRecipientRequest fromJson(Json json) {
/* 153 */     Builder builder = builder();
/* 154 */     if (json.accessToken != null) {
/* 155 */       builder.accessToken(json.accessToken);
/*     */     }
/* 157 */     if (json.nick != null) {
/* 158 */       builder.nick(json.nick);
/*     */     }
/* 160 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableGroupAddRecipientRequest of(String accessToken, String nick) {
/* 170 */     return new ImmutableGroupAddRecipientRequest(accessToken, nick);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableGroupAddRecipientRequest copyOf(GroupAddRecipientRequest instance) {
/* 181 */     if (instance instanceof ImmutableGroupAddRecipientRequest) {
/* 182 */       return (ImmutableGroupAddRecipientRequest)instance;
/*     */     }
/* 184 */     return builder()
/* 185 */       .from(instance)
/* 186 */       .build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 200 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "GroupAddRecipientRequest", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_ACCESS_TOKEN = 1L;
/*     */ 
/*     */     
/*     */     private static final long INIT_BIT_NICK = 2L;
/*     */ 
/*     */     
/* 214 */     private long initBits = 3L;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private String accessToken;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private String nick;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(GroupAddRecipientRequest instance) {
/* 230 */       Objects.requireNonNull(instance, "instance");
/* 231 */       accessToken(instance.accessToken());
/* 232 */       nick(instance.nick());
/* 233 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("access_token")
/*     */     public final Builder accessToken(String accessToken) {
/* 243 */       this.accessToken = Objects.<String>requireNonNull(accessToken, "accessToken");
/* 244 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 245 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("nick")
/*     */     public final Builder nick(String nick) {
/* 255 */       this.nick = Objects.<String>requireNonNull(nick, "nick");
/* 256 */       this.initBits &= 0xFFFFFFFFFFFFFFFDL;
/* 257 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableGroupAddRecipientRequest build() {
/* 266 */       if (this.initBits != 0L) {
/* 267 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 269 */       return new ImmutableGroupAddRecipientRequest(null, this.accessToken, this.nick);
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 273 */       List<String> attributes = new ArrayList<>();
/* 274 */       if ((this.initBits & 0x1L) != 0L) attributes.add("accessToken"); 
/* 275 */       if ((this.initBits & 0x2L) != 0L) attributes.add("nick"); 
/* 276 */       return "Cannot build GroupAddRecipientRequest, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableGroupAddRecipientRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */