/*    */ package discord4j.discordjson.json;
/*    */ 
/*    */ import java.io.UncheckedIOException;
/*    */ import java.io.UnsupportedEncodingException;
/*    */ import java.net.URLEncoder;
/*    */ import java.nio.charset.StandardCharsets;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ 
/*    */ @Immutable
/*    */ public abstract class ClientCredentialsGrantRequest
/*    */ {
/*    */   public static ImmutableClientCredentialsGrantRequest.Builder builder() {
/* 14 */     return ImmutableClientCredentialsGrantRequest.builder();
/*    */   }
/*    */ 
/*    */   
/*    */   public abstract long clientId();
/*    */   
/*    */   public abstract String clientSecret();
/*    */   
/*    */   public abstract String scope();
/*    */   
/*    */   public String toString() {
/*    */     String scope;
/*    */     try {
/* 27 */       scope = URLEncoder.encode(scope(), StandardCharsets.UTF_8.toString());
/* 28 */     } catch (UnsupportedEncodingException e) {
/* 29 */       throw new UncheckedIOException(e);
/*    */     } 
/* 31 */     return "grant_type=client_credentials&scope=" + scope;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ClientCredentialsGrantRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */