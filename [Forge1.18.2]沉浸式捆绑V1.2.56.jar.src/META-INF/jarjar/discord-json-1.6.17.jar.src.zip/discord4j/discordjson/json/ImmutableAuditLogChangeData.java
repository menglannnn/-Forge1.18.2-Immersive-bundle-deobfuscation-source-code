/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.JsonNode;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "AuditLogChangeData", generator = "Immutables")
/*     */ public final class ImmutableAuditLogChangeData
/*     */   implements AuditLogChangeData
/*     */ {
/*     */   private final JsonNode newValue_value;
/*     */   private final boolean newValue_absent;
/*     */   private final JsonNode oldValue_value;
/*     */   private final boolean oldValue_absent;
/*     */   private final String key;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   
/*     */   private ImmutableAuditLogChangeData(Possible<JsonNode> newValue, Possible<JsonNode> oldValue, String key) {
/*  36 */     Possible<JsonNode> newValue$impl = newValue;
/*  37 */     Possible<JsonNode> oldValue$impl = oldValue;
/*  38 */     this.key = Objects.<String>requireNonNull(key, "key");
/*  39 */     this.newValue_value = newValue$impl.toOptional().orElse(null);
/*  40 */     this.newValue_absent = newValue$impl.isAbsent();
/*  41 */     this.oldValue_value = oldValue$impl.toOptional().orElse(null);
/*  42 */     this.oldValue_absent = oldValue$impl.isAbsent();
/*  43 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ImmutableAuditLogChangeData(ImmutableAuditLogChangeData original, Possible<JsonNode> newValue, Possible<JsonNode> oldValue, String key) {
/*  51 */     Possible<JsonNode> newValue$impl = newValue;
/*  52 */     Possible<JsonNode> oldValue$impl = oldValue;
/*  53 */     this.key = key;
/*  54 */     this.newValue_value = newValue$impl.toOptional().orElse(null);
/*  55 */     this.newValue_absent = newValue$impl.isAbsent();
/*  56 */     this.oldValue_value = oldValue$impl.toOptional().orElse(null);
/*  57 */     this.oldValue_absent = oldValue$impl.isAbsent();
/*  58 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  64 */   private volatile transient InitShim initShim = new InitShim();
/*     */   
/*     */   @Generated(from = "AuditLogChangeData", generator = "Immutables")
/*     */   private final class InitShim {
/*     */     private String formatInitCycleMessage() {
/*  69 */       List<String> attributes = new ArrayList<>();
/*  70 */       return "Cannot build AuditLogChangeData, attribute initializers form cycle " + attributes;
/*     */     }
/*     */ 
/*     */     
/*     */     private InitShim() {}
/*     */   }
/*     */ 
/*     */   
/*     */   @JsonProperty("new_value")
/*     */   public Possible<JsonNode> newValue() {
/*  80 */     return this.newValue_absent ? Possible.absent() : Possible.of(this.newValue_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("old_value")
/*     */   public Possible<JsonNode> oldValue() {
/*  89 */     return this.oldValue_absent ? Possible.absent() : Possible.of(this.oldValue_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("key")
/*     */   public String key() {
/*  98 */     return this.key;
/*     */   }
/*     */   
/*     */   public ImmutableAuditLogChangeData withNewValue(Possible<JsonNode> value) {
/* 102 */     Possible<JsonNode> newValue = Objects.<Possible<JsonNode>>requireNonNull(value);
/* 103 */     return new ImmutableAuditLogChangeData(this, newValue, oldValue(), this.key);
/*     */   }
/*     */   
/*     */   public ImmutableAuditLogChangeData withNewValue(JsonNode value) {
/* 107 */     Possible<JsonNode> newValue = Possible.of(value);
/* 108 */     return new ImmutableAuditLogChangeData(this, newValue, oldValue(), this.key);
/*     */   }
/*     */   
/*     */   public ImmutableAuditLogChangeData withOldValue(Possible<JsonNode> value) {
/* 112 */     Possible<JsonNode> newValue = Objects.<Possible<JsonNode>>requireNonNull(value);
/* 113 */     return new ImmutableAuditLogChangeData(this, newValue(), newValue, this.key);
/*     */   }
/*     */   
/*     */   public ImmutableAuditLogChangeData withOldValue(JsonNode value) {
/* 117 */     Possible<JsonNode> newValue = Possible.of(value);
/* 118 */     return new ImmutableAuditLogChangeData(this, newValue(), newValue, this.key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableAuditLogChangeData withKey(String value) {
/* 128 */     String newValue = Objects.<String>requireNonNull(value, "key");
/* 129 */     if (this.key.equals(newValue)) return this; 
/* 130 */     return new ImmutableAuditLogChangeData(this, newValue(), oldValue(), newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 139 */     if (this == another) return true; 
/* 140 */     return (another instanceof ImmutableAuditLogChangeData && 
/* 141 */       equalTo(0, (ImmutableAuditLogChangeData)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableAuditLogChangeData another) {
/* 145 */     return (newValue().equals(another.newValue()) && 
/* 146 */       oldValue().equals(another.oldValue()) && this.key
/* 147 */       .equals(another.key));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 156 */     int h = 5381;
/* 157 */     h += (h << 5) + newValue().hashCode();
/* 158 */     h += (h << 5) + oldValue().hashCode();
/* 159 */     h += (h << 5) + this.key.hashCode();
/* 160 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 169 */     return "AuditLogChangeData{newValue=" + 
/* 170 */       newValue().toString() + ", oldValue=" + 
/* 171 */       oldValue().toString() + ", key=" + this.key + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "AuditLogChangeData", generator = "Immutables")
/*     */   static final class Json
/*     */     implements AuditLogChangeData
/*     */   {
/* 186 */     Possible<JsonNode> newValue = Possible.absent();
/*     */ 
/*     */     
/* 189 */     Possible<JsonNode> oldValue = Possible.absent();
/*     */     String key;
/*     */     
/*     */     @JsonProperty("new_value")
/*     */     public void setNewValue(Possible<JsonNode> newValue) {
/* 194 */       this.newValue = newValue;
/*     */     }
/*     */     @JsonProperty("old_value")
/*     */     public void setOldValue(Possible<JsonNode> oldValue) {
/* 198 */       this.oldValue = oldValue;
/*     */     }
/*     */     @JsonProperty("key")
/*     */     public void setKey(String key) {
/* 202 */       this.key = key;
/*     */     }
/*     */     public Possible<JsonNode> newValue() {
/* 205 */       throw new UnsupportedOperationException();
/*     */     } public Possible<JsonNode> oldValue() {
/* 207 */       throw new UnsupportedOperationException();
/*     */     } public String key() {
/* 209 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableAuditLogChangeData fromJson(Json json) {
/* 220 */     Builder builder = builder();
/* 221 */     if (json.newValue != null) {
/* 222 */       builder.newValue(json.newValue);
/*     */     }
/* 224 */     if (json.oldValue != null) {
/* 225 */       builder.oldValue(json.oldValue);
/*     */     }
/* 227 */     if (json.key != null) {
/* 228 */       builder.key(json.key);
/*     */     }
/* 230 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableAuditLogChangeData of(Possible<JsonNode> newValue, Possible<JsonNode> oldValue, String key) {
/* 241 */     return new ImmutableAuditLogChangeData(newValue, oldValue, key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableAuditLogChangeData copyOf(AuditLogChangeData instance) {
/* 252 */     if (instance instanceof ImmutableAuditLogChangeData) {
/* 253 */       return (ImmutableAuditLogChangeData)instance;
/*     */     }
/* 255 */     return builder()
/* 256 */       .from(instance)
/* 257 */       .build();
/*     */   }
/*     */   
/*     */   public boolean isNewValuePresent() {
/* 261 */     return !this.newValue_absent;
/*     */   }
/*     */   
/*     */   public JsonNode newValueOrElse(JsonNode defaultValue) {
/* 265 */     return !this.newValue_absent ? this.newValue_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isOldValuePresent() {
/* 269 */     return !this.oldValue_absent;
/*     */   }
/*     */   
/*     */   public JsonNode oldValueOrElse(JsonNode defaultValue) {
/* 273 */     return !this.oldValue_absent ? this.oldValue_value : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 288 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "AuditLogChangeData", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_KEY = 1L;
/*     */ 
/*     */ 
/*     */     
/* 301 */     private long initBits = 1L;
/*     */     
/* 303 */     private Possible<JsonNode> newValue_possible = Possible.absent();
/* 304 */     private Possible<JsonNode> oldValue_possible = Possible.absent();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private String key;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(AuditLogChangeData instance) {
/* 318 */       Objects.requireNonNull(instance, "instance");
/* 319 */       newValue(instance.newValue());
/* 320 */       oldValue(instance.oldValue());
/* 321 */       key(instance.key());
/* 322 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("new_value")
/*     */     public Builder newValue(Possible<JsonNode> value) {
/* 327 */       this.newValue_possible = value;
/* 328 */       return this;
/*     */     }
/*     */     
/*     */     public Builder newValue(JsonNode value) {
/* 332 */       this.newValue_possible = Possible.of(value);
/* 333 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("old_value")
/*     */     public Builder oldValue(Possible<JsonNode> value) {
/* 338 */       this.oldValue_possible = value;
/* 339 */       return this;
/*     */     }
/*     */     
/*     */     public Builder oldValue(JsonNode value) {
/* 343 */       this.oldValue_possible = Possible.of(value);
/* 344 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("key")
/*     */     public final Builder key(String key) {
/* 354 */       this.key = Objects.<String>requireNonNull(key, "key");
/* 355 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 356 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableAuditLogChangeData build() {
/* 365 */       if (this.initBits != 0L) {
/* 366 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 368 */       return new ImmutableAuditLogChangeData(null, newValue_build(), oldValue_build(), this.key);
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 372 */       List<String> attributes = new ArrayList<>();
/* 373 */       if ((this.initBits & 0x1L) != 0L) attributes.add("key"); 
/* 374 */       return "Cannot build AuditLogChangeData, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Possible<JsonNode> newValue_build() {
/* 378 */       return this.newValue_possible;
/*     */     }
/*     */     
/*     */     private Possible<JsonNode> oldValue_build() {
/* 382 */       return this.oldValue_possible;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableAuditLogChangeData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */