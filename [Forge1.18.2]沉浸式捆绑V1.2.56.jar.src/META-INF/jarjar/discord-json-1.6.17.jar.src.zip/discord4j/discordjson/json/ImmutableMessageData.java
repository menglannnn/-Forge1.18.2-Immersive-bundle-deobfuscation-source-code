/*      */ package discord4j.discordjson.json;
/*      */ 
/*      */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*      */ import com.fasterxml.jackson.annotation.JsonCreator;
/*      */ import com.fasterxml.jackson.annotation.JsonProperty;
/*      */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*      */ import discord4j.discordjson.Id;
/*      */ import discord4j.discordjson.possible.Possible;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.List;
/*      */ import java.util.Objects;
/*      */ import java.util.Optional;
/*      */ import java.util.stream.Collectors;
/*      */ import java.util.stream.StreamSupport;
/*      */ import org.immutables.value.Generated;
/*      */ import reactor.util.annotation.Nullable;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ @Generated(from = "MessageData", generator = "Immutables")
/*      */ public final class ImmutableMessageData
/*      */   implements MessageData
/*      */ {
/*      */   private final long id_value;
/*      */   private final long channelId_value;
/*      */   private final long guildId_value;
/*      */   private final boolean guildId_absent;
/*      */   private final UserData author;
/*      */   private final PartialMemberData member_value;
/*      */   private final boolean member_absent;
/*      */   private final String content;
/*      */   private final String timestamp;
/*      */   private final String editedTimestamp;
/*      */   private final boolean tts;
/*      */   private final boolean mentionEveryone;
/*      */   private final List<UserWithMemberData> mentions;
/*      */   private final List<String> mentionRoles;
/*      */   private final List<ChannelMentionData> mentionChannels_value;
/*      */   private final boolean mentionChannels_absent;
/*      */   private final List<AttachmentData> attachments;
/*      */   private final List<EmbedData> embeds;
/*      */   private final List<ReactionData> reactions_value;
/*      */   private final boolean reactions_absent;
/*      */   private final Object nonce_value;
/*      */   private final boolean nonce_absent;
/*      */   private final boolean pinned;
/*      */   private final long webhookId_value;
/*      */   private final boolean webhookId_absent;
/*      */   private final int type;
/*      */   private final MessageActivityData activity_value;
/*      */   private final boolean activity_absent;
/*      */   private final MessageApplicationData application_value;
/*      */   private final boolean application_absent;
/*      */   private final long applicationId_value;
/*      */   private final boolean applicationId_absent;
/*      */   private final MessageReferenceData messageReference_value;
/*      */   private final boolean messageReference_absent;
/*      */   private final Integer flags_value;
/*      */   private final boolean flags_absent;
/*      */   private final List<StickerData> stickers_value;
/*      */   private final boolean stickers_absent;
/*      */   private final List<PartialStickerData> stickerItems_value;
/*      */   private final boolean stickerItems_absent;
/*      */   private final MessageData referencedMessage_value;
/*      */   private final boolean referencedMessage_absent;
/*      */   private final MessageInteractionData interaction_value;
/*      */   private final boolean interaction_absent;
/*      */   private final List<ComponentData> components_value;
/*      */   private final boolean components_absent;
/*      */   private static final byte STAGE_INITIALIZING = -1;
/*      */   private static final byte STAGE_UNINITIALIZED = 0;
/*      */   private static final byte STAGE_INITIALIZED = 1;
/*      */   
/*      */   private ImmutableMessageData(Id id, Id channelId, Possible<Id> guildId, UserData author, Possible<PartialMemberData> member, String content, String timestamp, Optional<String> editedTimestamp, boolean tts, boolean mentionEveryone, Iterable<? extends UserWithMemberData> mentions, Iterable<String> mentionRoles, Possible<List<ChannelMentionData>> mentionChannels, Iterable<? extends AttachmentData> attachments, Iterable<? extends EmbedData> embeds, Possible<List<ReactionData>> reactions, Possible<Object> nonce, boolean pinned, Possible<Id> webhookId, int type, Possible<MessageActivityData> activity, Possible<MessageApplicationData> application, Possible<Id> applicationId, Possible<MessageReferenceData> messageReference, Possible<Integer> flags, Possible<List<StickerData>> stickers, Possible<List<PartialStickerData>> stickerItems, Possible<Optional<MessageData>> referencedMessage, Possible<MessageInteractionData> interaction, Possible<List<ComponentData>> components) {
/*  111 */     Id id$impl = id;
/*  112 */     Id channelId$impl = channelId;
/*  113 */     Possible<Id> guildId$impl = guildId;
/*  114 */     this.author = Objects.<UserData>requireNonNull(author, "author");
/*  115 */     Possible<PartialMemberData> member$impl = member;
/*  116 */     this.content = Objects.<String>requireNonNull(content, "content");
/*  117 */     this.timestamp = Objects.<String>requireNonNull(timestamp, "timestamp");
/*  118 */     this.editedTimestamp = editedTimestamp.orElse(null);
/*  119 */     this.tts = tts;
/*  120 */     this.mentionEveryone = mentionEveryone;
/*  121 */     this.mentions = createUnmodifiableList(false, createSafeList(mentions, true, false));
/*  122 */     this.mentionRoles = createUnmodifiableList(false, createSafeList(mentionRoles, true, false));
/*  123 */     Possible<List<ChannelMentionData>> mentionChannels$impl = mentionChannels;
/*  124 */     this.attachments = createUnmodifiableList(false, createSafeList(attachments, true, false));
/*  125 */     this.embeds = createUnmodifiableList(false, createSafeList(embeds, true, false));
/*  126 */     Possible<List<ReactionData>> reactions$impl = reactions;
/*  127 */     Possible<Object> nonce$impl = nonce;
/*  128 */     this.pinned = pinned;
/*  129 */     Possible<Id> webhookId$impl = webhookId;
/*  130 */     this.type = type;
/*  131 */     Possible<MessageActivityData> activity$impl = activity;
/*  132 */     Possible<MessageApplicationData> application$impl = application;
/*  133 */     Possible<Id> applicationId$impl = applicationId;
/*  134 */     Possible<MessageReferenceData> messageReference$impl = messageReference;
/*  135 */     Possible<Integer> flags$impl = flags;
/*  136 */     Possible<List<StickerData>> stickers$impl = stickers;
/*  137 */     Possible<List<PartialStickerData>> stickerItems$impl = stickerItems;
/*  138 */     Possible<Optional<MessageData>> referencedMessage$impl = referencedMessage;
/*  139 */     Possible<MessageInteractionData> interaction$impl = interaction;
/*  140 */     Possible<List<ComponentData>> components$impl = components;
/*  141 */     this.id_value = id$impl.asLong();
/*  142 */     this.channelId_value = channelId$impl.asLong();
/*  143 */     this
/*      */       
/*  145 */       .guildId_value = ((Long)guildId$impl.toOptional().map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  146 */     this.guildId_absent = guildId$impl.isAbsent();
/*  147 */     this.member_value = member$impl.toOptional().orElse(null);
/*  148 */     this.member_absent = member$impl.isAbsent();
/*  149 */     this.mentionChannels_value = mentionChannels$impl.toOptional().orElse(null);
/*  150 */     this.mentionChannels_absent = mentionChannels$impl.isAbsent();
/*  151 */     this.reactions_value = reactions$impl.toOptional().orElse(null);
/*  152 */     this.reactions_absent = reactions$impl.isAbsent();
/*  153 */     this.nonce_value = nonce$impl.toOptional().orElse(null);
/*  154 */     this.nonce_absent = nonce$impl.isAbsent();
/*  155 */     this
/*      */       
/*  157 */       .webhookId_value = ((Long)webhookId$impl.toOptional().map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  158 */     this.webhookId_absent = webhookId$impl.isAbsent();
/*  159 */     this.activity_value = activity$impl.toOptional().orElse(null);
/*  160 */     this.activity_absent = activity$impl.isAbsent();
/*  161 */     this.application_value = application$impl.toOptional().orElse(null);
/*  162 */     this.application_absent = application$impl.isAbsent();
/*  163 */     this
/*      */       
/*  165 */       .applicationId_value = ((Long)applicationId$impl.toOptional().map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  166 */     this.applicationId_absent = applicationId$impl.isAbsent();
/*  167 */     this.messageReference_value = messageReference$impl.toOptional().orElse(null);
/*  168 */     this.messageReference_absent = messageReference$impl.isAbsent();
/*  169 */     this.flags_value = flags$impl.toOptional().orElse(null);
/*  170 */     this.flags_absent = flags$impl.isAbsent();
/*  171 */     this.stickers_value = stickers$impl.toOptional().orElse(null);
/*  172 */     this.stickers_absent = stickers$impl.isAbsent();
/*  173 */     this.stickerItems_value = stickerItems$impl.toOptional().orElse(null);
/*  174 */     this.stickerItems_absent = stickerItems$impl.isAbsent();
/*  175 */     this.referencedMessage_value = Possible.flatOpt(referencedMessage$impl).orElse(null);
/*  176 */     this.referencedMessage_absent = referencedMessage$impl.isAbsent();
/*  177 */     this.interaction_value = interaction$impl.toOptional().orElse(null);
/*  178 */     this.interaction_absent = interaction$impl.isAbsent();
/*  179 */     this.components_value = components$impl.toOptional().orElse(null);
/*  180 */     this.components_absent = components$impl.isAbsent();
/*  181 */     this.initShim = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ImmutableMessageData(ImmutableMessageData original, Id id, Id channelId, Possible<Id> guildId, UserData author, Possible<PartialMemberData> member, String content, String timestamp, String editedTimestamp, boolean tts, boolean mentionEveryone, List<UserWithMemberData> mentions, List<String> mentionRoles, Possible<List<ChannelMentionData>> mentionChannels, List<AttachmentData> attachments, List<EmbedData> embeds, Possible<List<ReactionData>> reactions, Possible<Object> nonce, boolean pinned, Possible<Id> webhookId, int type, Possible<MessageActivityData> activity, Possible<MessageApplicationData> application, Possible<Id> applicationId, Possible<MessageReferenceData> messageReference, Possible<Integer> flags, Possible<List<StickerData>> stickers, Possible<List<PartialStickerData>> stickerItems, Possible<Optional<MessageData>> referencedMessage, Possible<MessageInteractionData> interaction, Possible<List<ComponentData>> components) {
/*  216 */     Id id$impl = id;
/*  217 */     Id channelId$impl = channelId;
/*  218 */     Possible<Id> guildId$impl = guildId;
/*  219 */     this.author = author;
/*  220 */     Possible<PartialMemberData> member$impl = member;
/*  221 */     this.content = content;
/*  222 */     this.timestamp = timestamp;
/*  223 */     this.editedTimestamp = editedTimestamp;
/*  224 */     this.tts = tts;
/*  225 */     this.mentionEveryone = mentionEveryone;
/*  226 */     this.mentions = mentions;
/*  227 */     this.mentionRoles = mentionRoles;
/*  228 */     Possible<List<ChannelMentionData>> mentionChannels$impl = mentionChannels;
/*  229 */     this.attachments = attachments;
/*  230 */     this.embeds = embeds;
/*  231 */     Possible<List<ReactionData>> reactions$impl = reactions;
/*  232 */     Possible<Object> nonce$impl = nonce;
/*  233 */     this.pinned = pinned;
/*  234 */     Possible<Id> webhookId$impl = webhookId;
/*  235 */     this.type = type;
/*  236 */     Possible<MessageActivityData> activity$impl = activity;
/*  237 */     Possible<MessageApplicationData> application$impl = application;
/*  238 */     Possible<Id> applicationId$impl = applicationId;
/*  239 */     Possible<MessageReferenceData> messageReference$impl = messageReference;
/*  240 */     Possible<Integer> flags$impl = flags;
/*  241 */     Possible<List<StickerData>> stickers$impl = stickers;
/*  242 */     Possible<List<PartialStickerData>> stickerItems$impl = stickerItems;
/*  243 */     Possible<Optional<MessageData>> referencedMessage$impl = referencedMessage;
/*  244 */     Possible<MessageInteractionData> interaction$impl = interaction;
/*  245 */     Possible<List<ComponentData>> components$impl = components;
/*  246 */     this.id_value = id$impl.asLong();
/*  247 */     this.channelId_value = channelId$impl.asLong();
/*  248 */     this
/*      */       
/*  250 */       .guildId_value = ((Long)guildId$impl.toOptional().map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  251 */     this.guildId_absent = guildId$impl.isAbsent();
/*  252 */     this.member_value = member$impl.toOptional().orElse(null);
/*  253 */     this.member_absent = member$impl.isAbsent();
/*  254 */     this.mentionChannels_value = mentionChannels$impl.toOptional().orElse(null);
/*  255 */     this.mentionChannels_absent = mentionChannels$impl.isAbsent();
/*  256 */     this.reactions_value = reactions$impl.toOptional().orElse(null);
/*  257 */     this.reactions_absent = reactions$impl.isAbsent();
/*  258 */     this.nonce_value = nonce$impl.toOptional().orElse(null);
/*  259 */     this.nonce_absent = nonce$impl.isAbsent();
/*  260 */     this
/*      */       
/*  262 */       .webhookId_value = ((Long)webhookId$impl.toOptional().map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  263 */     this.webhookId_absent = webhookId$impl.isAbsent();
/*  264 */     this.activity_value = activity$impl.toOptional().orElse(null);
/*  265 */     this.activity_absent = activity$impl.isAbsent();
/*  266 */     this.application_value = application$impl.toOptional().orElse(null);
/*  267 */     this.application_absent = application$impl.isAbsent();
/*  268 */     this
/*      */       
/*  270 */       .applicationId_value = ((Long)applicationId$impl.toOptional().map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  271 */     this.applicationId_absent = applicationId$impl.isAbsent();
/*  272 */     this.messageReference_value = messageReference$impl.toOptional().orElse(null);
/*  273 */     this.messageReference_absent = messageReference$impl.isAbsent();
/*  274 */     this.flags_value = flags$impl.toOptional().orElse(null);
/*  275 */     this.flags_absent = flags$impl.isAbsent();
/*  276 */     this.stickers_value = stickers$impl.toOptional().orElse(null);
/*  277 */     this.stickers_absent = stickers$impl.isAbsent();
/*  278 */     this.stickerItems_value = stickerItems$impl.toOptional().orElse(null);
/*  279 */     this.stickerItems_absent = stickerItems$impl.isAbsent();
/*  280 */     this.referencedMessage_value = Possible.flatOpt(referencedMessage$impl).orElse(null);
/*  281 */     this.referencedMessage_absent = referencedMessage$impl.isAbsent();
/*  282 */     this.interaction_value = interaction$impl.toOptional().orElse(null);
/*  283 */     this.interaction_absent = interaction$impl.isAbsent();
/*  284 */     this.components_value = components$impl.toOptional().orElse(null);
/*  285 */     this.components_absent = components$impl.isAbsent();
/*  286 */     this.initShim = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  292 */   private volatile transient InitShim initShim = new InitShim();
/*      */   
/*      */   @Generated(from = "MessageData", generator = "Immutables")
/*      */   private final class InitShim {
/*      */     private String formatInitCycleMessage() {
/*  297 */       List<String> attributes = new ArrayList<>();
/*  298 */       return "Cannot build MessageData, attribute initializers form cycle " + attributes;
/*      */     }
/*      */ 
/*      */     
/*      */     private InitShim() {}
/*      */   }
/*      */ 
/*      */   
/*      */   @JsonProperty("id")
/*      */   public Id id() {
/*  308 */     return Id.of(this.id_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("channel_id")
/*      */   public Id channelId() {
/*  317 */     return Id.of(this.channelId_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("guild_id")
/*      */   public Possible<Id> guildId() {
/*  326 */     return this.guildId_absent ? Possible.absent() : 
/*  327 */       Possible.of(Id.of(this.guildId_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("author")
/*      */   public UserData author() {
/*  336 */     return this.author;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("member")
/*      */   public Possible<PartialMemberData> member() {
/*  345 */     return this.member_absent ? Possible.absent() : Possible.of(this.member_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("content")
/*      */   public String content() {
/*  354 */     return this.content;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("timestamp")
/*      */   public String timestamp() {
/*  363 */     return this.timestamp;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("edited_timestamp")
/*      */   public Optional<String> editedTimestamp() {
/*  372 */     return Optional.ofNullable(this.editedTimestamp);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("tts")
/*      */   public boolean tts() {
/*  381 */     return this.tts;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("mention_everyone")
/*      */   public boolean mentionEveryone() {
/*  390 */     return this.mentionEveryone;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("mentions")
/*      */   public List<UserWithMemberData> mentions() {
/*  399 */     return this.mentions;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("mention_roles")
/*      */   public List<String> mentionRoles() {
/*  408 */     return this.mentionRoles;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("mention_channels")
/*      */   public Possible<List<ChannelMentionData>> mentionChannels() {
/*  417 */     return this.mentionChannels_absent ? Possible.absent() : 
/*  418 */       Possible.of(this.mentionChannels_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("attachments")
/*      */   public List<AttachmentData> attachments() {
/*  427 */     return this.attachments;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("embeds")
/*      */   public List<EmbedData> embeds() {
/*  436 */     return this.embeds;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("reactions")
/*      */   public Possible<List<ReactionData>> reactions() {
/*  445 */     return this.reactions_absent ? Possible.absent() : 
/*  446 */       Possible.of(this.reactions_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("nonce")
/*      */   public Possible<Object> nonce() {
/*  455 */     return this.nonce_absent ? Possible.absent() : Possible.of(this.nonce_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("pinned")
/*      */   public boolean pinned() {
/*  464 */     return this.pinned;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("webhook_id")
/*      */   public Possible<Id> webhookId() {
/*  473 */     return this.webhookId_absent ? Possible.absent() : 
/*  474 */       Possible.of(Id.of(this.webhookId_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("type")
/*      */   public int type() {
/*  483 */     return this.type;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("activity")
/*      */   public Possible<MessageActivityData> activity() {
/*  492 */     return this.activity_absent ? Possible.absent() : Possible.of(this.activity_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("application")
/*      */   public Possible<MessageApplicationData> application() {
/*  501 */     return this.application_absent ? Possible.absent() : Possible.of(this.application_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("application_id")
/*      */   public Possible<Id> applicationId() {
/*  510 */     return this.applicationId_absent ? Possible.absent() : 
/*  511 */       Possible.of(Id.of(this.applicationId_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("message_reference")
/*      */   public Possible<MessageReferenceData> messageReference() {
/*  520 */     return this.messageReference_absent ? Possible.absent() : Possible.of(this.messageReference_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("flags")
/*      */   public Possible<Integer> flags() {
/*  529 */     return this.flags_absent ? Possible.absent() : Possible.of(this.flags_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("stickers")
/*      */   @Deprecated
/*      */   public Possible<List<StickerData>> stickers() {
/*  539 */     return this.stickers_absent ? Possible.absent() : 
/*  540 */       Possible.of(this.stickers_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("sticker_items")
/*      */   public Possible<List<PartialStickerData>> stickerItems() {
/*  549 */     return this.stickerItems_absent ? Possible.absent() : 
/*  550 */       Possible.of(this.stickerItems_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("referenced_message")
/*      */   public Possible<Optional<MessageData>> referencedMessage() {
/*  559 */     return this.referencedMessage_absent ? Possible.absent() : 
/*  560 */       Possible.of(Optional.ofNullable(this.referencedMessage_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("interaction")
/*      */   public Possible<MessageInteractionData> interaction() {
/*  569 */     return this.interaction_absent ? Possible.absent() : Possible.of(this.interaction_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("components")
/*      */   public Possible<List<ComponentData>> components() {
/*  578 */     return this.components_absent ? Possible.absent() : 
/*  579 */       Possible.of(this.components_value);
/*      */   }
/*      */   
/*      */   public ImmutableMessageData withId(long value) {
/*  583 */     Id newValue = Id.of(value);
/*  584 */     return new ImmutableMessageData(this, newValue, 
/*      */ 
/*      */         
/*  587 */         channelId(), 
/*  588 */         guildId(), this.author, 
/*      */         
/*  590 */         member(), this.content, this.timestamp, this.editedTimestamp, this.tts, this.mentionEveryone, this.mentions, this.mentionRoles, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  598 */         mentionChannels(), this.attachments, this.embeds, 
/*      */ 
/*      */         
/*  601 */         reactions(), 
/*  602 */         nonce(), this.pinned, 
/*      */         
/*  604 */         webhookId(), this.type, 
/*      */         
/*  606 */         activity(), 
/*  607 */         application(), 
/*  608 */         applicationId(), 
/*  609 */         messageReference(), 
/*  610 */         flags(), 
/*  611 */         stickers(), 
/*  612 */         stickerItems(), 
/*  613 */         referencedMessage(), 
/*  614 */         interaction(), 
/*  615 */         components());
/*      */   }
/*      */   
/*      */   public ImmutableMessageData withId(String value) {
/*  619 */     Id newValue = Id.of(value);
/*  620 */     return new ImmutableMessageData(this, newValue, 
/*      */ 
/*      */         
/*  623 */         channelId(), 
/*  624 */         guildId(), this.author, 
/*      */         
/*  626 */         member(), this.content, this.timestamp, this.editedTimestamp, this.tts, this.mentionEveryone, this.mentions, this.mentionRoles, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  634 */         mentionChannels(), this.attachments, this.embeds, 
/*      */ 
/*      */         
/*  637 */         reactions(), 
/*  638 */         nonce(), this.pinned, 
/*      */         
/*  640 */         webhookId(), this.type, 
/*      */         
/*  642 */         activity(), 
/*  643 */         application(), 
/*  644 */         applicationId(), 
/*  645 */         messageReference(), 
/*  646 */         flags(), 
/*  647 */         stickers(), 
/*  648 */         stickerItems(), 
/*  649 */         referencedMessage(), 
/*  650 */         interaction(), 
/*  651 */         components());
/*      */   }
/*      */   
/*      */   public ImmutableMessageData withChannelId(long value) {
/*  655 */     Id newValue = Id.of(value);
/*  656 */     return new ImmutableMessageData(this, 
/*      */         
/*  658 */         id(), newValue, 
/*      */         
/*  660 */         guildId(), this.author, 
/*      */         
/*  662 */         member(), this.content, this.timestamp, this.editedTimestamp, this.tts, this.mentionEveryone, this.mentions, this.mentionRoles, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  670 */         mentionChannels(), this.attachments, this.embeds, 
/*      */ 
/*      */         
/*  673 */         reactions(), 
/*  674 */         nonce(), this.pinned, 
/*      */         
/*  676 */         webhookId(), this.type, 
/*      */         
/*  678 */         activity(), 
/*  679 */         application(), 
/*  680 */         applicationId(), 
/*  681 */         messageReference(), 
/*  682 */         flags(), 
/*  683 */         stickers(), 
/*  684 */         stickerItems(), 
/*  685 */         referencedMessage(), 
/*  686 */         interaction(), 
/*  687 */         components());
/*      */   }
/*      */   
/*      */   public ImmutableMessageData withChannelId(String value) {
/*  691 */     Id newValue = Id.of(value);
/*  692 */     return new ImmutableMessageData(this, 
/*      */         
/*  694 */         id(), newValue, 
/*      */         
/*  696 */         guildId(), this.author, 
/*      */         
/*  698 */         member(), this.content, this.timestamp, this.editedTimestamp, this.tts, this.mentionEveryone, this.mentions, this.mentionRoles, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  706 */         mentionChannels(), this.attachments, this.embeds, 
/*      */ 
/*      */         
/*  709 */         reactions(), 
/*  710 */         nonce(), this.pinned, 
/*      */         
/*  712 */         webhookId(), this.type, 
/*      */         
/*  714 */         activity(), 
/*  715 */         application(), 
/*  716 */         applicationId(), 
/*  717 */         messageReference(), 
/*  718 */         flags(), 
/*  719 */         stickers(), 
/*  720 */         stickerItems(), 
/*  721 */         referencedMessage(), 
/*  722 */         interaction(), 
/*  723 */         components());
/*      */   }
/*      */   
/*      */   public ImmutableMessageData withGuildId(Possible<Id> value) {
/*  727 */     Possible<Id> newValue = Objects.<Possible<Id>>requireNonNull(value);
/*  728 */     return new ImmutableMessageData(this, 
/*      */         
/*  730 */         id(), 
/*  731 */         channelId(), newValue, this.author, 
/*      */ 
/*      */         
/*  734 */         member(), this.content, this.timestamp, this.editedTimestamp, this.tts, this.mentionEveryone, this.mentions, this.mentionRoles, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  742 */         mentionChannels(), this.attachments, this.embeds, 
/*      */ 
/*      */         
/*  745 */         reactions(), 
/*  746 */         nonce(), this.pinned, 
/*      */         
/*  748 */         webhookId(), this.type, 
/*      */         
/*  750 */         activity(), 
/*  751 */         application(), 
/*  752 */         applicationId(), 
/*  753 */         messageReference(), 
/*  754 */         flags(), 
/*  755 */         stickers(), 
/*  756 */         stickerItems(), 
/*  757 */         referencedMessage(), 
/*  758 */         interaction(), 
/*  759 */         components());
/*      */   }
/*      */   
/*      */   public ImmutableMessageData withGuildId(long value) {
/*  763 */     Possible<Id> newValue = Possible.of(Id.of(value));
/*  764 */     return new ImmutableMessageData(this, 
/*      */         
/*  766 */         id(), 
/*  767 */         channelId(), newValue, this.author, 
/*      */ 
/*      */         
/*  770 */         member(), this.content, this.timestamp, this.editedTimestamp, this.tts, this.mentionEveryone, this.mentions, this.mentionRoles, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  778 */         mentionChannels(), this.attachments, this.embeds, 
/*      */ 
/*      */         
/*  781 */         reactions(), 
/*  782 */         nonce(), this.pinned, 
/*      */         
/*  784 */         webhookId(), this.type, 
/*      */         
/*  786 */         activity(), 
/*  787 */         application(), 
/*  788 */         applicationId(), 
/*  789 */         messageReference(), 
/*  790 */         flags(), 
/*  791 */         stickers(), 
/*  792 */         stickerItems(), 
/*  793 */         referencedMessage(), 
/*  794 */         interaction(), 
/*  795 */         components());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableMessageData withAuthor(UserData value) {
/*  805 */     if (this.author == value) return this; 
/*  806 */     UserData newValue = Objects.<UserData>requireNonNull(value, "author");
/*  807 */     return new ImmutableMessageData(this, 
/*      */         
/*  809 */         id(), 
/*  810 */         channelId(), 
/*  811 */         guildId(), newValue, 
/*      */         
/*  813 */         member(), this.content, this.timestamp, this.editedTimestamp, this.tts, this.mentionEveryone, this.mentions, this.mentionRoles, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  821 */         mentionChannels(), this.attachments, this.embeds, 
/*      */ 
/*      */         
/*  824 */         reactions(), 
/*  825 */         nonce(), this.pinned, 
/*      */         
/*  827 */         webhookId(), this.type, 
/*      */         
/*  829 */         activity(), 
/*  830 */         application(), 
/*  831 */         applicationId(), 
/*  832 */         messageReference(), 
/*  833 */         flags(), 
/*  834 */         stickers(), 
/*  835 */         stickerItems(), 
/*  836 */         referencedMessage(), 
/*  837 */         interaction(), 
/*  838 */         components());
/*      */   }
/*      */   
/*      */   public ImmutableMessageData withMember(Possible<PartialMemberData> value) {
/*  842 */     Possible<PartialMemberData> newValue = Objects.<Possible<PartialMemberData>>requireNonNull(value);
/*  843 */     return new ImmutableMessageData(this, 
/*      */         
/*  845 */         id(), 
/*  846 */         channelId(), 
/*  847 */         guildId(), this.author, newValue, this.content, this.timestamp, this.editedTimestamp, this.tts, this.mentionEveryone, this.mentions, this.mentionRoles, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  857 */         mentionChannels(), this.attachments, this.embeds, 
/*      */ 
/*      */         
/*  860 */         reactions(), 
/*  861 */         nonce(), this.pinned, 
/*      */         
/*  863 */         webhookId(), this.type, 
/*      */         
/*  865 */         activity(), 
/*  866 */         application(), 
/*  867 */         applicationId(), 
/*  868 */         messageReference(), 
/*  869 */         flags(), 
/*  870 */         stickers(), 
/*  871 */         stickerItems(), 
/*  872 */         referencedMessage(), 
/*  873 */         interaction(), 
/*  874 */         components());
/*      */   }
/*      */   
/*      */   public ImmutableMessageData withMember(PartialMemberData value) {
/*  878 */     Possible<PartialMemberData> newValue = Possible.of(value);
/*  879 */     return new ImmutableMessageData(this, 
/*      */         
/*  881 */         id(), 
/*  882 */         channelId(), 
/*  883 */         guildId(), this.author, newValue, this.content, this.timestamp, this.editedTimestamp, this.tts, this.mentionEveryone, this.mentions, this.mentionRoles, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  893 */         mentionChannels(), this.attachments, this.embeds, 
/*      */ 
/*      */         
/*  896 */         reactions(), 
/*  897 */         nonce(), this.pinned, 
/*      */         
/*  899 */         webhookId(), this.type, 
/*      */         
/*  901 */         activity(), 
/*  902 */         application(), 
/*  903 */         applicationId(), 
/*  904 */         messageReference(), 
/*  905 */         flags(), 
/*  906 */         stickers(), 
/*  907 */         stickerItems(), 
/*  908 */         referencedMessage(), 
/*  909 */         interaction(), 
/*  910 */         components());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableMessageData withContent(String value) {
/*  920 */     String newValue = Objects.<String>requireNonNull(value, "content");
/*  921 */     if (this.content.equals(newValue)) return this; 
/*  922 */     return new ImmutableMessageData(this, 
/*      */         
/*  924 */         id(), 
/*  925 */         channelId(), 
/*  926 */         guildId(), this.author, 
/*      */         
/*  928 */         member(), newValue, this.timestamp, this.editedTimestamp, this.tts, this.mentionEveryone, this.mentions, this.mentionRoles, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  936 */         mentionChannels(), this.attachments, this.embeds, 
/*      */ 
/*      */         
/*  939 */         reactions(), 
/*  940 */         nonce(), this.pinned, 
/*      */         
/*  942 */         webhookId(), this.type, 
/*      */         
/*  944 */         activity(), 
/*  945 */         application(), 
/*  946 */         applicationId(), 
/*  947 */         messageReference(), 
/*  948 */         flags(), 
/*  949 */         stickers(), 
/*  950 */         stickerItems(), 
/*  951 */         referencedMessage(), 
/*  952 */         interaction(), 
/*  953 */         components());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableMessageData withTimestamp(String value) {
/*  963 */     String newValue = Objects.<String>requireNonNull(value, "timestamp");
/*  964 */     if (this.timestamp.equals(newValue)) return this; 
/*  965 */     return new ImmutableMessageData(this, 
/*      */         
/*  967 */         id(), 
/*  968 */         channelId(), 
/*  969 */         guildId(), this.author, 
/*      */         
/*  971 */         member(), this.content, newValue, this.editedTimestamp, this.tts, this.mentionEveryone, this.mentions, this.mentionRoles, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  979 */         mentionChannels(), this.attachments, this.embeds, 
/*      */ 
/*      */         
/*  982 */         reactions(), 
/*  983 */         nonce(), this.pinned, 
/*      */         
/*  985 */         webhookId(), this.type, 
/*      */         
/*  987 */         activity(), 
/*  988 */         application(), 
/*  989 */         applicationId(), 
/*  990 */         messageReference(), 
/*  991 */         flags(), 
/*  992 */         stickers(), 
/*  993 */         stickerItems(), 
/*  994 */         referencedMessage(), 
/*  995 */         interaction(), 
/*  996 */         components());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableMessageData withEditedTimestamp(String value) {
/* 1005 */     String newValue = Objects.<String>requireNonNull(value, "editedTimestamp");
/* 1006 */     if (Objects.equals(this.editedTimestamp, newValue)) return this; 
/* 1007 */     return new ImmutableMessageData(this, 
/*      */         
/* 1009 */         id(), 
/* 1010 */         channelId(), 
/* 1011 */         guildId(), this.author, 
/*      */         
/* 1013 */         member(), this.content, this.timestamp, newValue, this.tts, this.mentionEveryone, this.mentions, this.mentionRoles, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1021 */         mentionChannels(), this.attachments, this.embeds, 
/*      */ 
/*      */         
/* 1024 */         reactions(), 
/* 1025 */         nonce(), this.pinned, 
/*      */         
/* 1027 */         webhookId(), this.type, 
/*      */         
/* 1029 */         activity(), 
/* 1030 */         application(), 
/* 1031 */         applicationId(), 
/* 1032 */         messageReference(), 
/* 1033 */         flags(), 
/* 1034 */         stickers(), 
/* 1035 */         stickerItems(), 
/* 1036 */         referencedMessage(), 
/* 1037 */         interaction(), 
/* 1038 */         components());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableMessageData withEditedTimestamp(Optional<String> optional) {
/* 1048 */     String value = optional.orElse(null);
/* 1049 */     if (Objects.equals(this.editedTimestamp, value)) return this; 
/* 1050 */     return new ImmutableMessageData(this, 
/*      */         
/* 1052 */         id(), 
/* 1053 */         channelId(), 
/* 1054 */         guildId(), this.author, 
/*      */         
/* 1056 */         member(), this.content, this.timestamp, value, this.tts, this.mentionEveryone, this.mentions, this.mentionRoles, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1064 */         mentionChannels(), this.attachments, this.embeds, 
/*      */ 
/*      */         
/* 1067 */         reactions(), 
/* 1068 */         nonce(), this.pinned, 
/*      */         
/* 1070 */         webhookId(), this.type, 
/*      */         
/* 1072 */         activity(), 
/* 1073 */         application(), 
/* 1074 */         applicationId(), 
/* 1075 */         messageReference(), 
/* 1076 */         flags(), 
/* 1077 */         stickers(), 
/* 1078 */         stickerItems(), 
/* 1079 */         referencedMessage(), 
/* 1080 */         interaction(), 
/* 1081 */         components());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableMessageData withTts(boolean value) {
/* 1091 */     if (this.tts == value) return this; 
/* 1092 */     return new ImmutableMessageData(this, 
/*      */         
/* 1094 */         id(), 
/* 1095 */         channelId(), 
/* 1096 */         guildId(), this.author, 
/*      */         
/* 1098 */         member(), this.content, this.timestamp, this.editedTimestamp, value, this.mentionEveryone, this.mentions, this.mentionRoles, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1106 */         mentionChannels(), this.attachments, this.embeds, 
/*      */ 
/*      */         
/* 1109 */         reactions(), 
/* 1110 */         nonce(), this.pinned, 
/*      */         
/* 1112 */         webhookId(), this.type, 
/*      */         
/* 1114 */         activity(), 
/* 1115 */         application(), 
/* 1116 */         applicationId(), 
/* 1117 */         messageReference(), 
/* 1118 */         flags(), 
/* 1119 */         stickers(), 
/* 1120 */         stickerItems(), 
/* 1121 */         referencedMessage(), 
/* 1122 */         interaction(), 
/* 1123 */         components());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableMessageData withMentionEveryone(boolean value) {
/* 1133 */     if (this.mentionEveryone == value) return this; 
/* 1134 */     return new ImmutableMessageData(this, 
/*      */         
/* 1136 */         id(), 
/* 1137 */         channelId(), 
/* 1138 */         guildId(), this.author, 
/*      */         
/* 1140 */         member(), this.content, this.timestamp, this.editedTimestamp, this.tts, value, this.mentions, this.mentionRoles, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1148 */         mentionChannels(), this.attachments, this.embeds, 
/*      */ 
/*      */         
/* 1151 */         reactions(), 
/* 1152 */         nonce(), this.pinned, 
/*      */         
/* 1154 */         webhookId(), this.type, 
/*      */         
/* 1156 */         activity(), 
/* 1157 */         application(), 
/* 1158 */         applicationId(), 
/* 1159 */         messageReference(), 
/* 1160 */         flags(), 
/* 1161 */         stickers(), 
/* 1162 */         stickerItems(), 
/* 1163 */         referencedMessage(), 
/* 1164 */         interaction(), 
/* 1165 */         components());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableMessageData withMentions(UserWithMemberData... elements) {
/* 1174 */     List<UserWithMemberData> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/* 1175 */     return new ImmutableMessageData(this, 
/*      */         
/* 1177 */         id(), 
/* 1178 */         channelId(), 
/* 1179 */         guildId(), this.author, 
/*      */         
/* 1181 */         member(), this.content, this.timestamp, this.editedTimestamp, this.tts, this.mentionEveryone, newValue, this.mentionRoles, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1189 */         mentionChannels(), this.attachments, this.embeds, 
/*      */ 
/*      */         
/* 1192 */         reactions(), 
/* 1193 */         nonce(), this.pinned, 
/*      */         
/* 1195 */         webhookId(), this.type, 
/*      */         
/* 1197 */         activity(), 
/* 1198 */         application(), 
/* 1199 */         applicationId(), 
/* 1200 */         messageReference(), 
/* 1201 */         flags(), 
/* 1202 */         stickers(), 
/* 1203 */         stickerItems(), 
/* 1204 */         referencedMessage(), 
/* 1205 */         interaction(), 
/* 1206 */         components());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableMessageData withMentions(Iterable<? extends UserWithMemberData> elements) {
/* 1216 */     if (this.mentions == elements) return this; 
/* 1217 */     List<UserWithMemberData> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/* 1218 */     return new ImmutableMessageData(this, 
/*      */         
/* 1220 */         id(), 
/* 1221 */         channelId(), 
/* 1222 */         guildId(), this.author, 
/*      */         
/* 1224 */         member(), this.content, this.timestamp, this.editedTimestamp, this.tts, this.mentionEveryone, newValue, this.mentionRoles, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1232 */         mentionChannels(), this.attachments, this.embeds, 
/*      */ 
/*      */         
/* 1235 */         reactions(), 
/* 1236 */         nonce(), this.pinned, 
/*      */         
/* 1238 */         webhookId(), this.type, 
/*      */         
/* 1240 */         activity(), 
/* 1241 */         application(), 
/* 1242 */         applicationId(), 
/* 1243 */         messageReference(), 
/* 1244 */         flags(), 
/* 1245 */         stickers(), 
/* 1246 */         stickerItems(), 
/* 1247 */         referencedMessage(), 
/* 1248 */         interaction(), 
/* 1249 */         components());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableMessageData withMentionRoles(String... elements) {
/* 1258 */     List<String> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/* 1259 */     return new ImmutableMessageData(this, 
/*      */         
/* 1261 */         id(), 
/* 1262 */         channelId(), 
/* 1263 */         guildId(), this.author, 
/*      */         
/* 1265 */         member(), this.content, this.timestamp, this.editedTimestamp, this.tts, this.mentionEveryone, this.mentions, newValue, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1273 */         mentionChannels(), this.attachments, this.embeds, 
/*      */ 
/*      */         
/* 1276 */         reactions(), 
/* 1277 */         nonce(), this.pinned, 
/*      */         
/* 1279 */         webhookId(), this.type, 
/*      */         
/* 1281 */         activity(), 
/* 1282 */         application(), 
/* 1283 */         applicationId(), 
/* 1284 */         messageReference(), 
/* 1285 */         flags(), 
/* 1286 */         stickers(), 
/* 1287 */         stickerItems(), 
/* 1288 */         referencedMessage(), 
/* 1289 */         interaction(), 
/* 1290 */         components());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableMessageData withMentionRoles(Iterable<String> elements) {
/* 1300 */     if (this.mentionRoles == elements) return this; 
/* 1301 */     List<String> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/* 1302 */     return new ImmutableMessageData(this, 
/*      */         
/* 1304 */         id(), 
/* 1305 */         channelId(), 
/* 1306 */         guildId(), this.author, 
/*      */         
/* 1308 */         member(), this.content, this.timestamp, this.editedTimestamp, this.tts, this.mentionEveryone, this.mentions, newValue, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1316 */         mentionChannels(), this.attachments, this.embeds, 
/*      */ 
/*      */         
/* 1319 */         reactions(), 
/* 1320 */         nonce(), this.pinned, 
/*      */         
/* 1322 */         webhookId(), this.type, 
/*      */         
/* 1324 */         activity(), 
/* 1325 */         application(), 
/* 1326 */         applicationId(), 
/* 1327 */         messageReference(), 
/* 1328 */         flags(), 
/* 1329 */         stickers(), 
/* 1330 */         stickerItems(), 
/* 1331 */         referencedMessage(), 
/* 1332 */         interaction(), 
/* 1333 */         components());
/*      */   }
/*      */   
/*      */   public ImmutableMessageData withMentionChannels(Possible<List<ChannelMentionData>> possible) {
/* 1337 */     Possible<List<ChannelMentionData>> newValue = Objects.<Possible<List<ChannelMentionData>>>requireNonNull(possible);
/* 1338 */     return new ImmutableMessageData(this, 
/*      */         
/* 1340 */         id(), 
/* 1341 */         channelId(), 
/* 1342 */         guildId(), this.author, 
/*      */         
/* 1344 */         member(), this.content, this.timestamp, this.editedTimestamp, this.tts, this.mentionEveryone, this.mentions, this.mentionRoles, newValue, this.attachments, this.embeds, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1355 */         reactions(), 
/* 1356 */         nonce(), this.pinned, 
/*      */         
/* 1358 */         webhookId(), this.type, 
/*      */         
/* 1360 */         activity(), 
/* 1361 */         application(), 
/* 1362 */         applicationId(), 
/* 1363 */         messageReference(), 
/* 1364 */         flags(), 
/* 1365 */         stickers(), 
/* 1366 */         stickerItems(), 
/* 1367 */         referencedMessage(), 
/* 1368 */         interaction(), 
/* 1369 */         components());
/*      */   }
/*      */   
/*      */   public ImmutableMessageData withMentionChannels(Iterable<ChannelMentionData> elements) {
/* 1373 */     Possible<List<ChannelMentionData>> newValue = Possible.of(
/* 1374 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/* 1375 */     return new ImmutableMessageData(this, 
/*      */         
/* 1377 */         id(), 
/* 1378 */         channelId(), 
/* 1379 */         guildId(), this.author, 
/*      */         
/* 1381 */         member(), this.content, this.timestamp, this.editedTimestamp, this.tts, this.mentionEveryone, this.mentions, this.mentionRoles, newValue, this.attachments, this.embeds, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1392 */         reactions(), 
/* 1393 */         nonce(), this.pinned, 
/*      */         
/* 1395 */         webhookId(), this.type, 
/*      */         
/* 1397 */         activity(), 
/* 1398 */         application(), 
/* 1399 */         applicationId(), 
/* 1400 */         messageReference(), 
/* 1401 */         flags(), 
/* 1402 */         stickers(), 
/* 1403 */         stickerItems(), 
/* 1404 */         referencedMessage(), 
/* 1405 */         interaction(), 
/* 1406 */         components());
/*      */   }
/*      */   
/*      */   @SafeVarargs
/*      */   public final ImmutableMessageData withMentionChannels(ChannelMentionData... elements) {
/* 1411 */     Possible<List<ChannelMentionData>> newValue = Possible.of(Arrays.asList(elements));
/* 1412 */     return new ImmutableMessageData(this, 
/*      */         
/* 1414 */         id(), 
/* 1415 */         channelId(), 
/* 1416 */         guildId(), this.author, 
/*      */         
/* 1418 */         member(), this.content, this.timestamp, this.editedTimestamp, this.tts, this.mentionEveryone, this.mentions, this.mentionRoles, newValue, this.attachments, this.embeds, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1429 */         reactions(), 
/* 1430 */         nonce(), this.pinned, 
/*      */         
/* 1432 */         webhookId(), this.type, 
/*      */         
/* 1434 */         activity(), 
/* 1435 */         application(), 
/* 1436 */         applicationId(), 
/* 1437 */         messageReference(), 
/* 1438 */         flags(), 
/* 1439 */         stickers(), 
/* 1440 */         stickerItems(), 
/* 1441 */         referencedMessage(), 
/* 1442 */         interaction(), 
/* 1443 */         components());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableMessageData withAttachments(AttachmentData... elements) {
/* 1452 */     List<AttachmentData> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/* 1453 */     return new ImmutableMessageData(this, 
/*      */         
/* 1455 */         id(), 
/* 1456 */         channelId(), 
/* 1457 */         guildId(), this.author, 
/*      */         
/* 1459 */         member(), this.content, this.timestamp, this.editedTimestamp, this.tts, this.mentionEveryone, this.mentions, this.mentionRoles, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1467 */         mentionChannels(), newValue, this.embeds, 
/*      */ 
/*      */         
/* 1470 */         reactions(), 
/* 1471 */         nonce(), this.pinned, 
/*      */         
/* 1473 */         webhookId(), this.type, 
/*      */         
/* 1475 */         activity(), 
/* 1476 */         application(), 
/* 1477 */         applicationId(), 
/* 1478 */         messageReference(), 
/* 1479 */         flags(), 
/* 1480 */         stickers(), 
/* 1481 */         stickerItems(), 
/* 1482 */         referencedMessage(), 
/* 1483 */         interaction(), 
/* 1484 */         components());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableMessageData withAttachments(Iterable<? extends AttachmentData> elements) {
/* 1494 */     if (this.attachments == elements) return this; 
/* 1495 */     List<AttachmentData> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/* 1496 */     return new ImmutableMessageData(this, 
/*      */         
/* 1498 */         id(), 
/* 1499 */         channelId(), 
/* 1500 */         guildId(), this.author, 
/*      */         
/* 1502 */         member(), this.content, this.timestamp, this.editedTimestamp, this.tts, this.mentionEveryone, this.mentions, this.mentionRoles, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1510 */         mentionChannels(), newValue, this.embeds, 
/*      */ 
/*      */         
/* 1513 */         reactions(), 
/* 1514 */         nonce(), this.pinned, 
/*      */         
/* 1516 */         webhookId(), this.type, 
/*      */         
/* 1518 */         activity(), 
/* 1519 */         application(), 
/* 1520 */         applicationId(), 
/* 1521 */         messageReference(), 
/* 1522 */         flags(), 
/* 1523 */         stickers(), 
/* 1524 */         stickerItems(), 
/* 1525 */         referencedMessage(), 
/* 1526 */         interaction(), 
/* 1527 */         components());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableMessageData withEmbeds(EmbedData... elements) {
/* 1536 */     List<EmbedData> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/* 1537 */     return new ImmutableMessageData(this, 
/*      */         
/* 1539 */         id(), 
/* 1540 */         channelId(), 
/* 1541 */         guildId(), this.author, 
/*      */         
/* 1543 */         member(), this.content, this.timestamp, this.editedTimestamp, this.tts, this.mentionEveryone, this.mentions, this.mentionRoles, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1551 */         mentionChannels(), this.attachments, newValue, 
/*      */ 
/*      */         
/* 1554 */         reactions(), 
/* 1555 */         nonce(), this.pinned, 
/*      */         
/* 1557 */         webhookId(), this.type, 
/*      */         
/* 1559 */         activity(), 
/* 1560 */         application(), 
/* 1561 */         applicationId(), 
/* 1562 */         messageReference(), 
/* 1563 */         flags(), 
/* 1564 */         stickers(), 
/* 1565 */         stickerItems(), 
/* 1566 */         referencedMessage(), 
/* 1567 */         interaction(), 
/* 1568 */         components());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableMessageData withEmbeds(Iterable<? extends EmbedData> elements) {
/* 1578 */     if (this.embeds == elements) return this; 
/* 1579 */     List<EmbedData> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/* 1580 */     return new ImmutableMessageData(this, 
/*      */         
/* 1582 */         id(), 
/* 1583 */         channelId(), 
/* 1584 */         guildId(), this.author, 
/*      */         
/* 1586 */         member(), this.content, this.timestamp, this.editedTimestamp, this.tts, this.mentionEveryone, this.mentions, this.mentionRoles, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1594 */         mentionChannels(), this.attachments, newValue, 
/*      */ 
/*      */         
/* 1597 */         reactions(), 
/* 1598 */         nonce(), this.pinned, 
/*      */         
/* 1600 */         webhookId(), this.type, 
/*      */         
/* 1602 */         activity(), 
/* 1603 */         application(), 
/* 1604 */         applicationId(), 
/* 1605 */         messageReference(), 
/* 1606 */         flags(), 
/* 1607 */         stickers(), 
/* 1608 */         stickerItems(), 
/* 1609 */         referencedMessage(), 
/* 1610 */         interaction(), 
/* 1611 */         components());
/*      */   }
/*      */   
/*      */   public ImmutableMessageData withReactions(Possible<List<ReactionData>> possible) {
/* 1615 */     Possible<List<ReactionData>> newValue = Objects.<Possible<List<ReactionData>>>requireNonNull(possible);
/* 1616 */     return new ImmutableMessageData(this, 
/*      */         
/* 1618 */         id(), 
/* 1619 */         channelId(), 
/* 1620 */         guildId(), this.author, 
/*      */         
/* 1622 */         member(), this.content, this.timestamp, this.editedTimestamp, this.tts, this.mentionEveryone, this.mentions, this.mentionRoles, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1630 */         mentionChannels(), this.attachments, this.embeds, newValue, 
/*      */ 
/*      */ 
/*      */         
/* 1634 */         nonce(), this.pinned, 
/*      */         
/* 1636 */         webhookId(), this.type, 
/*      */         
/* 1638 */         activity(), 
/* 1639 */         application(), 
/* 1640 */         applicationId(), 
/* 1641 */         messageReference(), 
/* 1642 */         flags(), 
/* 1643 */         stickers(), 
/* 1644 */         stickerItems(), 
/* 1645 */         referencedMessage(), 
/* 1646 */         interaction(), 
/* 1647 */         components());
/*      */   }
/*      */   
/*      */   public ImmutableMessageData withReactions(Iterable<ReactionData> elements) {
/* 1651 */     Possible<List<ReactionData>> newValue = Possible.of(
/* 1652 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/* 1653 */     return new ImmutableMessageData(this, 
/*      */         
/* 1655 */         id(), 
/* 1656 */         channelId(), 
/* 1657 */         guildId(), this.author, 
/*      */         
/* 1659 */         member(), this.content, this.timestamp, this.editedTimestamp, this.tts, this.mentionEveryone, this.mentions, this.mentionRoles, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1667 */         mentionChannels(), this.attachments, this.embeds, newValue, 
/*      */ 
/*      */ 
/*      */         
/* 1671 */         nonce(), this.pinned, 
/*      */         
/* 1673 */         webhookId(), this.type, 
/*      */         
/* 1675 */         activity(), 
/* 1676 */         application(), 
/* 1677 */         applicationId(), 
/* 1678 */         messageReference(), 
/* 1679 */         flags(), 
/* 1680 */         stickers(), 
/* 1681 */         stickerItems(), 
/* 1682 */         referencedMessage(), 
/* 1683 */         interaction(), 
/* 1684 */         components());
/*      */   }
/*      */   
/*      */   @SafeVarargs
/*      */   public final ImmutableMessageData withReactions(ReactionData... elements) {
/* 1689 */     Possible<List<ReactionData>> newValue = Possible.of(Arrays.asList(elements));
/* 1690 */     return new ImmutableMessageData(this, 
/*      */         
/* 1692 */         id(), 
/* 1693 */         channelId(), 
/* 1694 */         guildId(), this.author, 
/*      */         
/* 1696 */         member(), this.content, this.timestamp, this.editedTimestamp, this.tts, this.mentionEveryone, this.mentions, this.mentionRoles, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1704 */         mentionChannels(), this.attachments, this.embeds, newValue, 
/*      */ 
/*      */ 
/*      */         
/* 1708 */         nonce(), this.pinned, 
/*      */         
/* 1710 */         webhookId(), this.type, 
/*      */         
/* 1712 */         activity(), 
/* 1713 */         application(), 
/* 1714 */         applicationId(), 
/* 1715 */         messageReference(), 
/* 1716 */         flags(), 
/* 1717 */         stickers(), 
/* 1718 */         stickerItems(), 
/* 1719 */         referencedMessage(), 
/* 1720 */         interaction(), 
/* 1721 */         components());
/*      */   }
/*      */   
/*      */   public ImmutableMessageData withNonce(Possible<Object> value) {
/* 1725 */     Possible<Object> newValue = Objects.<Possible<Object>>requireNonNull(value);
/* 1726 */     return new ImmutableMessageData(this, 
/*      */         
/* 1728 */         id(), 
/* 1729 */         channelId(), 
/* 1730 */         guildId(), this.author, 
/*      */         
/* 1732 */         member(), this.content, this.timestamp, this.editedTimestamp, this.tts, this.mentionEveryone, this.mentions, this.mentionRoles, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1740 */         mentionChannels(), this.attachments, this.embeds, 
/*      */ 
/*      */         
/* 1743 */         reactions(), newValue, this.pinned, 
/*      */ 
/*      */         
/* 1746 */         webhookId(), this.type, 
/*      */         
/* 1748 */         activity(), 
/* 1749 */         application(), 
/* 1750 */         applicationId(), 
/* 1751 */         messageReference(), 
/* 1752 */         flags(), 
/* 1753 */         stickers(), 
/* 1754 */         stickerItems(), 
/* 1755 */         referencedMessage(), 
/* 1756 */         interaction(), 
/* 1757 */         components());
/*      */   }
/*      */   
/*      */   public ImmutableMessageData withNonce(Object value) {
/* 1761 */     Possible<Object> newValue = Possible.of(value);
/* 1762 */     return new ImmutableMessageData(this, 
/*      */         
/* 1764 */         id(), 
/* 1765 */         channelId(), 
/* 1766 */         guildId(), this.author, 
/*      */         
/* 1768 */         member(), this.content, this.timestamp, this.editedTimestamp, this.tts, this.mentionEveryone, this.mentions, this.mentionRoles, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1776 */         mentionChannels(), this.attachments, this.embeds, 
/*      */ 
/*      */         
/* 1779 */         reactions(), newValue, this.pinned, 
/*      */ 
/*      */         
/* 1782 */         webhookId(), this.type, 
/*      */         
/* 1784 */         activity(), 
/* 1785 */         application(), 
/* 1786 */         applicationId(), 
/* 1787 */         messageReference(), 
/* 1788 */         flags(), 
/* 1789 */         stickers(), 
/* 1790 */         stickerItems(), 
/* 1791 */         referencedMessage(), 
/* 1792 */         interaction(), 
/* 1793 */         components());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableMessageData withPinned(boolean value) {
/* 1803 */     if (this.pinned == value) return this; 
/* 1804 */     return new ImmutableMessageData(this, 
/*      */         
/* 1806 */         id(), 
/* 1807 */         channelId(), 
/* 1808 */         guildId(), this.author, 
/*      */         
/* 1810 */         member(), this.content, this.timestamp, this.editedTimestamp, this.tts, this.mentionEveryone, this.mentions, this.mentionRoles, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1818 */         mentionChannels(), this.attachments, this.embeds, 
/*      */ 
/*      */         
/* 1821 */         reactions(), 
/* 1822 */         nonce(), value, 
/*      */         
/* 1824 */         webhookId(), this.type, 
/*      */         
/* 1826 */         activity(), 
/* 1827 */         application(), 
/* 1828 */         applicationId(), 
/* 1829 */         messageReference(), 
/* 1830 */         flags(), 
/* 1831 */         stickers(), 
/* 1832 */         stickerItems(), 
/* 1833 */         referencedMessage(), 
/* 1834 */         interaction(), 
/* 1835 */         components());
/*      */   }
/*      */   
/*      */   public ImmutableMessageData withWebhookId(Possible<Id> value) {
/* 1839 */     Possible<Id> newValue = Objects.<Possible<Id>>requireNonNull(value);
/* 1840 */     return new ImmutableMessageData(this, 
/*      */         
/* 1842 */         id(), 
/* 1843 */         channelId(), 
/* 1844 */         guildId(), this.author, 
/*      */         
/* 1846 */         member(), this.content, this.timestamp, this.editedTimestamp, this.tts, this.mentionEveryone, this.mentions, this.mentionRoles, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1854 */         mentionChannels(), this.attachments, this.embeds, 
/*      */ 
/*      */         
/* 1857 */         reactions(), 
/* 1858 */         nonce(), this.pinned, newValue, this.type, 
/*      */ 
/*      */ 
/*      */         
/* 1862 */         activity(), 
/* 1863 */         application(), 
/* 1864 */         applicationId(), 
/* 1865 */         messageReference(), 
/* 1866 */         flags(), 
/* 1867 */         stickers(), 
/* 1868 */         stickerItems(), 
/* 1869 */         referencedMessage(), 
/* 1870 */         interaction(), 
/* 1871 */         components());
/*      */   }
/*      */   
/*      */   public ImmutableMessageData withWebhookId(long value) {
/* 1875 */     Possible<Id> newValue = Possible.of(Id.of(value));
/* 1876 */     return new ImmutableMessageData(this, 
/*      */         
/* 1878 */         id(), 
/* 1879 */         channelId(), 
/* 1880 */         guildId(), this.author, 
/*      */         
/* 1882 */         member(), this.content, this.timestamp, this.editedTimestamp, this.tts, this.mentionEveryone, this.mentions, this.mentionRoles, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1890 */         mentionChannels(), this.attachments, this.embeds, 
/*      */ 
/*      */         
/* 1893 */         reactions(), 
/* 1894 */         nonce(), this.pinned, newValue, this.type, 
/*      */ 
/*      */ 
/*      */         
/* 1898 */         activity(), 
/* 1899 */         application(), 
/* 1900 */         applicationId(), 
/* 1901 */         messageReference(), 
/* 1902 */         flags(), 
/* 1903 */         stickers(), 
/* 1904 */         stickerItems(), 
/* 1905 */         referencedMessage(), 
/* 1906 */         interaction(), 
/* 1907 */         components());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableMessageData withType(int value) {
/* 1917 */     if (this.type == value) return this; 
/* 1918 */     return new ImmutableMessageData(this, 
/*      */         
/* 1920 */         id(), 
/* 1921 */         channelId(), 
/* 1922 */         guildId(), this.author, 
/*      */         
/* 1924 */         member(), this.content, this.timestamp, this.editedTimestamp, this.tts, this.mentionEveryone, this.mentions, this.mentionRoles, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1932 */         mentionChannels(), this.attachments, this.embeds, 
/*      */ 
/*      */         
/* 1935 */         reactions(), 
/* 1936 */         nonce(), this.pinned, 
/*      */         
/* 1938 */         webhookId(), value, 
/*      */         
/* 1940 */         activity(), 
/* 1941 */         application(), 
/* 1942 */         applicationId(), 
/* 1943 */         messageReference(), 
/* 1944 */         flags(), 
/* 1945 */         stickers(), 
/* 1946 */         stickerItems(), 
/* 1947 */         referencedMessage(), 
/* 1948 */         interaction(), 
/* 1949 */         components());
/*      */   }
/*      */   
/*      */   public ImmutableMessageData withActivity(Possible<MessageActivityData> value) {
/* 1953 */     Possible<MessageActivityData> newValue = Objects.<Possible<MessageActivityData>>requireNonNull(value);
/* 1954 */     return new ImmutableMessageData(this, 
/*      */         
/* 1956 */         id(), 
/* 1957 */         channelId(), 
/* 1958 */         guildId(), this.author, 
/*      */         
/* 1960 */         member(), this.content, this.timestamp, this.editedTimestamp, this.tts, this.mentionEveryone, this.mentions, this.mentionRoles, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1968 */         mentionChannels(), this.attachments, this.embeds, 
/*      */ 
/*      */         
/* 1971 */         reactions(), 
/* 1972 */         nonce(), this.pinned, 
/*      */         
/* 1974 */         webhookId(), this.type, newValue, 
/*      */ 
/*      */         
/* 1977 */         application(), 
/* 1978 */         applicationId(), 
/* 1979 */         messageReference(), 
/* 1980 */         flags(), 
/* 1981 */         stickers(), 
/* 1982 */         stickerItems(), 
/* 1983 */         referencedMessage(), 
/* 1984 */         interaction(), 
/* 1985 */         components());
/*      */   }
/*      */   
/*      */   public ImmutableMessageData withActivity(MessageActivityData value) {
/* 1989 */     Possible<MessageActivityData> newValue = Possible.of(value);
/* 1990 */     return new ImmutableMessageData(this, 
/*      */         
/* 1992 */         id(), 
/* 1993 */         channelId(), 
/* 1994 */         guildId(), this.author, 
/*      */         
/* 1996 */         member(), this.content, this.timestamp, this.editedTimestamp, this.tts, this.mentionEveryone, this.mentions, this.mentionRoles, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2004 */         mentionChannels(), this.attachments, this.embeds, 
/*      */ 
/*      */         
/* 2007 */         reactions(), 
/* 2008 */         nonce(), this.pinned, 
/*      */         
/* 2010 */         webhookId(), this.type, newValue, 
/*      */ 
/*      */         
/* 2013 */         application(), 
/* 2014 */         applicationId(), 
/* 2015 */         messageReference(), 
/* 2016 */         flags(), 
/* 2017 */         stickers(), 
/* 2018 */         stickerItems(), 
/* 2019 */         referencedMessage(), 
/* 2020 */         interaction(), 
/* 2021 */         components());
/*      */   }
/*      */   
/*      */   public ImmutableMessageData withApplication(Possible<MessageApplicationData> value) {
/* 2025 */     Possible<MessageApplicationData> newValue = Objects.<Possible<MessageApplicationData>>requireNonNull(value);
/* 2026 */     return new ImmutableMessageData(this, 
/*      */         
/* 2028 */         id(), 
/* 2029 */         channelId(), 
/* 2030 */         guildId(), this.author, 
/*      */         
/* 2032 */         member(), this.content, this.timestamp, this.editedTimestamp, this.tts, this.mentionEveryone, this.mentions, this.mentionRoles, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2040 */         mentionChannels(), this.attachments, this.embeds, 
/*      */ 
/*      */         
/* 2043 */         reactions(), 
/* 2044 */         nonce(), this.pinned, 
/*      */         
/* 2046 */         webhookId(), this.type, 
/*      */         
/* 2048 */         activity(), newValue, 
/*      */         
/* 2050 */         applicationId(), 
/* 2051 */         messageReference(), 
/* 2052 */         flags(), 
/* 2053 */         stickers(), 
/* 2054 */         stickerItems(), 
/* 2055 */         referencedMessage(), 
/* 2056 */         interaction(), 
/* 2057 */         components());
/*      */   }
/*      */   
/*      */   public ImmutableMessageData withApplication(MessageApplicationData value) {
/* 2061 */     Possible<MessageApplicationData> newValue = Possible.of(value);
/* 2062 */     return new ImmutableMessageData(this, 
/*      */         
/* 2064 */         id(), 
/* 2065 */         channelId(), 
/* 2066 */         guildId(), this.author, 
/*      */         
/* 2068 */         member(), this.content, this.timestamp, this.editedTimestamp, this.tts, this.mentionEveryone, this.mentions, this.mentionRoles, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2076 */         mentionChannels(), this.attachments, this.embeds, 
/*      */ 
/*      */         
/* 2079 */         reactions(), 
/* 2080 */         nonce(), this.pinned, 
/*      */         
/* 2082 */         webhookId(), this.type, 
/*      */         
/* 2084 */         activity(), newValue, 
/*      */         
/* 2086 */         applicationId(), 
/* 2087 */         messageReference(), 
/* 2088 */         flags(), 
/* 2089 */         stickers(), 
/* 2090 */         stickerItems(), 
/* 2091 */         referencedMessage(), 
/* 2092 */         interaction(), 
/* 2093 */         components());
/*      */   }
/*      */   
/*      */   public ImmutableMessageData withApplicationId(Possible<Id> value) {
/* 2097 */     Possible<Id> newValue = Objects.<Possible<Id>>requireNonNull(value);
/* 2098 */     return new ImmutableMessageData(this, 
/*      */         
/* 2100 */         id(), 
/* 2101 */         channelId(), 
/* 2102 */         guildId(), this.author, 
/*      */         
/* 2104 */         member(), this.content, this.timestamp, this.editedTimestamp, this.tts, this.mentionEveryone, this.mentions, this.mentionRoles, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2112 */         mentionChannels(), this.attachments, this.embeds, 
/*      */ 
/*      */         
/* 2115 */         reactions(), 
/* 2116 */         nonce(), this.pinned, 
/*      */         
/* 2118 */         webhookId(), this.type, 
/*      */         
/* 2120 */         activity(), 
/* 2121 */         application(), newValue, 
/*      */         
/* 2123 */         messageReference(), 
/* 2124 */         flags(), 
/* 2125 */         stickers(), 
/* 2126 */         stickerItems(), 
/* 2127 */         referencedMessage(), 
/* 2128 */         interaction(), 
/* 2129 */         components());
/*      */   }
/*      */   
/*      */   public ImmutableMessageData withApplicationId(long value) {
/* 2133 */     Possible<Id> newValue = Possible.of(Id.of(value));
/* 2134 */     return new ImmutableMessageData(this, 
/*      */         
/* 2136 */         id(), 
/* 2137 */         channelId(), 
/* 2138 */         guildId(), this.author, 
/*      */         
/* 2140 */         member(), this.content, this.timestamp, this.editedTimestamp, this.tts, this.mentionEveryone, this.mentions, this.mentionRoles, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2148 */         mentionChannels(), this.attachments, this.embeds, 
/*      */ 
/*      */         
/* 2151 */         reactions(), 
/* 2152 */         nonce(), this.pinned, 
/*      */         
/* 2154 */         webhookId(), this.type, 
/*      */         
/* 2156 */         activity(), 
/* 2157 */         application(), newValue, 
/*      */         
/* 2159 */         messageReference(), 
/* 2160 */         flags(), 
/* 2161 */         stickers(), 
/* 2162 */         stickerItems(), 
/* 2163 */         referencedMessage(), 
/* 2164 */         interaction(), 
/* 2165 */         components());
/*      */   }
/*      */   
/*      */   public ImmutableMessageData withMessageReference(Possible<MessageReferenceData> value) {
/* 2169 */     Possible<MessageReferenceData> newValue = Objects.<Possible<MessageReferenceData>>requireNonNull(value);
/* 2170 */     return new ImmutableMessageData(this, 
/*      */         
/* 2172 */         id(), 
/* 2173 */         channelId(), 
/* 2174 */         guildId(), this.author, 
/*      */         
/* 2176 */         member(), this.content, this.timestamp, this.editedTimestamp, this.tts, this.mentionEveryone, this.mentions, this.mentionRoles, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2184 */         mentionChannels(), this.attachments, this.embeds, 
/*      */ 
/*      */         
/* 2187 */         reactions(), 
/* 2188 */         nonce(), this.pinned, 
/*      */         
/* 2190 */         webhookId(), this.type, 
/*      */         
/* 2192 */         activity(), 
/* 2193 */         application(), 
/* 2194 */         applicationId(), newValue, 
/*      */         
/* 2196 */         flags(), 
/* 2197 */         stickers(), 
/* 2198 */         stickerItems(), 
/* 2199 */         referencedMessage(), 
/* 2200 */         interaction(), 
/* 2201 */         components());
/*      */   }
/*      */   
/*      */   public ImmutableMessageData withMessageReference(MessageReferenceData value) {
/* 2205 */     Possible<MessageReferenceData> newValue = Possible.of(value);
/* 2206 */     return new ImmutableMessageData(this, 
/*      */         
/* 2208 */         id(), 
/* 2209 */         channelId(), 
/* 2210 */         guildId(), this.author, 
/*      */         
/* 2212 */         member(), this.content, this.timestamp, this.editedTimestamp, this.tts, this.mentionEveryone, this.mentions, this.mentionRoles, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2220 */         mentionChannels(), this.attachments, this.embeds, 
/*      */ 
/*      */         
/* 2223 */         reactions(), 
/* 2224 */         nonce(), this.pinned, 
/*      */         
/* 2226 */         webhookId(), this.type, 
/*      */         
/* 2228 */         activity(), 
/* 2229 */         application(), 
/* 2230 */         applicationId(), newValue, 
/*      */         
/* 2232 */         flags(), 
/* 2233 */         stickers(), 
/* 2234 */         stickerItems(), 
/* 2235 */         referencedMessage(), 
/* 2236 */         interaction(), 
/* 2237 */         components());
/*      */   }
/*      */   
/*      */   public ImmutableMessageData withFlags(Possible<Integer> value) {
/* 2241 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/* 2242 */     return new ImmutableMessageData(this, 
/*      */         
/* 2244 */         id(), 
/* 2245 */         channelId(), 
/* 2246 */         guildId(), this.author, 
/*      */         
/* 2248 */         member(), this.content, this.timestamp, this.editedTimestamp, this.tts, this.mentionEveryone, this.mentions, this.mentionRoles, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2256 */         mentionChannels(), this.attachments, this.embeds, 
/*      */ 
/*      */         
/* 2259 */         reactions(), 
/* 2260 */         nonce(), this.pinned, 
/*      */         
/* 2262 */         webhookId(), this.type, 
/*      */         
/* 2264 */         activity(), 
/* 2265 */         application(), 
/* 2266 */         applicationId(), 
/* 2267 */         messageReference(), newValue, 
/*      */         
/* 2269 */         stickers(), 
/* 2270 */         stickerItems(), 
/* 2271 */         referencedMessage(), 
/* 2272 */         interaction(), 
/* 2273 */         components());
/*      */   }
/*      */   
/*      */   public ImmutableMessageData withFlags(Integer value) {
/* 2277 */     Possible<Integer> newValue = Possible.of(value);
/* 2278 */     return new ImmutableMessageData(this, 
/*      */         
/* 2280 */         id(), 
/* 2281 */         channelId(), 
/* 2282 */         guildId(), this.author, 
/*      */         
/* 2284 */         member(), this.content, this.timestamp, this.editedTimestamp, this.tts, this.mentionEveryone, this.mentions, this.mentionRoles, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2292 */         mentionChannels(), this.attachments, this.embeds, 
/*      */ 
/*      */         
/* 2295 */         reactions(), 
/* 2296 */         nonce(), this.pinned, 
/*      */         
/* 2298 */         webhookId(), this.type, 
/*      */         
/* 2300 */         activity(), 
/* 2301 */         application(), 
/* 2302 */         applicationId(), 
/* 2303 */         messageReference(), newValue, 
/*      */         
/* 2305 */         stickers(), 
/* 2306 */         stickerItems(), 
/* 2307 */         referencedMessage(), 
/* 2308 */         interaction(), 
/* 2309 */         components());
/*      */   }
/*      */   
/*      */   public ImmutableMessageData withStickers(Possible<List<StickerData>> possible) {
/* 2313 */     Possible<List<StickerData>> newValue = Objects.<Possible<List<StickerData>>>requireNonNull(possible);
/* 2314 */     return new ImmutableMessageData(this, 
/*      */         
/* 2316 */         id(), 
/* 2317 */         channelId(), 
/* 2318 */         guildId(), this.author, 
/*      */         
/* 2320 */         member(), this.content, this.timestamp, this.editedTimestamp, this.tts, this.mentionEveryone, this.mentions, this.mentionRoles, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2328 */         mentionChannels(), this.attachments, this.embeds, 
/*      */ 
/*      */         
/* 2331 */         reactions(), 
/* 2332 */         nonce(), this.pinned, 
/*      */         
/* 2334 */         webhookId(), this.type, 
/*      */         
/* 2336 */         activity(), 
/* 2337 */         application(), 
/* 2338 */         applicationId(), 
/* 2339 */         messageReference(), 
/* 2340 */         flags(), newValue, 
/*      */         
/* 2342 */         stickerItems(), 
/* 2343 */         referencedMessage(), 
/* 2344 */         interaction(), 
/* 2345 */         components());
/*      */   }
/*      */   
/*      */   public ImmutableMessageData withStickers(Iterable<StickerData> elements) {
/* 2349 */     Possible<List<StickerData>> newValue = Possible.of(
/* 2350 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/* 2351 */     return new ImmutableMessageData(this, 
/*      */         
/* 2353 */         id(), 
/* 2354 */         channelId(), 
/* 2355 */         guildId(), this.author, 
/*      */         
/* 2357 */         member(), this.content, this.timestamp, this.editedTimestamp, this.tts, this.mentionEveryone, this.mentions, this.mentionRoles, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2365 */         mentionChannels(), this.attachments, this.embeds, 
/*      */ 
/*      */         
/* 2368 */         reactions(), 
/* 2369 */         nonce(), this.pinned, 
/*      */         
/* 2371 */         webhookId(), this.type, 
/*      */         
/* 2373 */         activity(), 
/* 2374 */         application(), 
/* 2375 */         applicationId(), 
/* 2376 */         messageReference(), 
/* 2377 */         flags(), newValue, 
/*      */         
/* 2379 */         stickerItems(), 
/* 2380 */         referencedMessage(), 
/* 2381 */         interaction(), 
/* 2382 */         components());
/*      */   }
/*      */   
/*      */   @SafeVarargs
/*      */   public final ImmutableMessageData withStickers(StickerData... elements) {
/* 2387 */     Possible<List<StickerData>> newValue = Possible.of(Arrays.asList(elements));
/* 2388 */     return new ImmutableMessageData(this, 
/*      */         
/* 2390 */         id(), 
/* 2391 */         channelId(), 
/* 2392 */         guildId(), this.author, 
/*      */         
/* 2394 */         member(), this.content, this.timestamp, this.editedTimestamp, this.tts, this.mentionEveryone, this.mentions, this.mentionRoles, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2402 */         mentionChannels(), this.attachments, this.embeds, 
/*      */ 
/*      */         
/* 2405 */         reactions(), 
/* 2406 */         nonce(), this.pinned, 
/*      */         
/* 2408 */         webhookId(), this.type, 
/*      */         
/* 2410 */         activity(), 
/* 2411 */         application(), 
/* 2412 */         applicationId(), 
/* 2413 */         messageReference(), 
/* 2414 */         flags(), newValue, 
/*      */         
/* 2416 */         stickerItems(), 
/* 2417 */         referencedMessage(), 
/* 2418 */         interaction(), 
/* 2419 */         components());
/*      */   }
/*      */   
/*      */   public ImmutableMessageData withStickerItems(Possible<List<PartialStickerData>> possible) {
/* 2423 */     Possible<List<PartialStickerData>> newValue = Objects.<Possible<List<PartialStickerData>>>requireNonNull(possible);
/* 2424 */     return new ImmutableMessageData(this, 
/*      */         
/* 2426 */         id(), 
/* 2427 */         channelId(), 
/* 2428 */         guildId(), this.author, 
/*      */         
/* 2430 */         member(), this.content, this.timestamp, this.editedTimestamp, this.tts, this.mentionEveryone, this.mentions, this.mentionRoles, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2438 */         mentionChannels(), this.attachments, this.embeds, 
/*      */ 
/*      */         
/* 2441 */         reactions(), 
/* 2442 */         nonce(), this.pinned, 
/*      */         
/* 2444 */         webhookId(), this.type, 
/*      */         
/* 2446 */         activity(), 
/* 2447 */         application(), 
/* 2448 */         applicationId(), 
/* 2449 */         messageReference(), 
/* 2450 */         flags(), 
/* 2451 */         stickers(), newValue, 
/*      */         
/* 2453 */         referencedMessage(), 
/* 2454 */         interaction(), 
/* 2455 */         components());
/*      */   }
/*      */   
/*      */   public ImmutableMessageData withStickerItems(Iterable<PartialStickerData> elements) {
/* 2459 */     Possible<List<PartialStickerData>> newValue = Possible.of(
/* 2460 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/* 2461 */     return new ImmutableMessageData(this, 
/*      */         
/* 2463 */         id(), 
/* 2464 */         channelId(), 
/* 2465 */         guildId(), this.author, 
/*      */         
/* 2467 */         member(), this.content, this.timestamp, this.editedTimestamp, this.tts, this.mentionEveryone, this.mentions, this.mentionRoles, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2475 */         mentionChannels(), this.attachments, this.embeds, 
/*      */ 
/*      */         
/* 2478 */         reactions(), 
/* 2479 */         nonce(), this.pinned, 
/*      */         
/* 2481 */         webhookId(), this.type, 
/*      */         
/* 2483 */         activity(), 
/* 2484 */         application(), 
/* 2485 */         applicationId(), 
/* 2486 */         messageReference(), 
/* 2487 */         flags(), 
/* 2488 */         stickers(), newValue, 
/*      */         
/* 2490 */         referencedMessage(), 
/* 2491 */         interaction(), 
/* 2492 */         components());
/*      */   }
/*      */   
/*      */   @SafeVarargs
/*      */   public final ImmutableMessageData withStickerItems(PartialStickerData... elements) {
/* 2497 */     Possible<List<PartialStickerData>> newValue = Possible.of(Arrays.asList(elements));
/* 2498 */     return new ImmutableMessageData(this, 
/*      */         
/* 2500 */         id(), 
/* 2501 */         channelId(), 
/* 2502 */         guildId(), this.author, 
/*      */         
/* 2504 */         member(), this.content, this.timestamp, this.editedTimestamp, this.tts, this.mentionEveryone, this.mentions, this.mentionRoles, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2512 */         mentionChannels(), this.attachments, this.embeds, 
/*      */ 
/*      */         
/* 2515 */         reactions(), 
/* 2516 */         nonce(), this.pinned, 
/*      */         
/* 2518 */         webhookId(), this.type, 
/*      */         
/* 2520 */         activity(), 
/* 2521 */         application(), 
/* 2522 */         applicationId(), 
/* 2523 */         messageReference(), 
/* 2524 */         flags(), 
/* 2525 */         stickers(), newValue, 
/*      */         
/* 2527 */         referencedMessage(), 
/* 2528 */         interaction(), 
/* 2529 */         components());
/*      */   }
/*      */   
/*      */   public ImmutableMessageData withReferencedMessage(Possible<Optional<MessageData>> value) {
/* 2533 */     Possible<Optional<MessageData>> newValue = Objects.<Possible<Optional<MessageData>>>requireNonNull(value);
/* 2534 */     return new ImmutableMessageData(this, 
/*      */         
/* 2536 */         id(), 
/* 2537 */         channelId(), 
/* 2538 */         guildId(), this.author, 
/*      */         
/* 2540 */         member(), this.content, this.timestamp, this.editedTimestamp, this.tts, this.mentionEveryone, this.mentions, this.mentionRoles, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2548 */         mentionChannels(), this.attachments, this.embeds, 
/*      */ 
/*      */         
/* 2551 */         reactions(), 
/* 2552 */         nonce(), this.pinned, 
/*      */         
/* 2554 */         webhookId(), this.type, 
/*      */         
/* 2556 */         activity(), 
/* 2557 */         application(), 
/* 2558 */         applicationId(), 
/* 2559 */         messageReference(), 
/* 2560 */         flags(), 
/* 2561 */         stickers(), 
/* 2562 */         stickerItems(), newValue, 
/*      */         
/* 2564 */         interaction(), 
/* 2565 */         components());
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public ImmutableMessageData withReferencedMessage(@Nullable MessageData value) {
/* 2570 */     Possible<Optional<MessageData>> newValue = Possible.of(Optional.ofNullable(value));
/* 2571 */     return new ImmutableMessageData(this, 
/*      */         
/* 2573 */         id(), 
/* 2574 */         channelId(), 
/* 2575 */         guildId(), this.author, 
/*      */         
/* 2577 */         member(), this.content, this.timestamp, this.editedTimestamp, this.tts, this.mentionEveryone, this.mentions, this.mentionRoles, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2585 */         mentionChannels(), this.attachments, this.embeds, 
/*      */ 
/*      */         
/* 2588 */         reactions(), 
/* 2589 */         nonce(), this.pinned, 
/*      */         
/* 2591 */         webhookId(), this.type, 
/*      */         
/* 2593 */         activity(), 
/* 2594 */         application(), 
/* 2595 */         applicationId(), 
/* 2596 */         messageReference(), 
/* 2597 */         flags(), 
/* 2598 */         stickers(), 
/* 2599 */         stickerItems(), newValue, 
/*      */         
/* 2601 */         interaction(), 
/* 2602 */         components());
/*      */   }
/*      */   
/*      */   public ImmutableMessageData withReferencedMessageOrNull(@Nullable MessageData value) {
/* 2606 */     Possible<Optional<MessageData>> newValue = Possible.of(Optional.ofNullable(value));
/* 2607 */     return new ImmutableMessageData(this, 
/*      */         
/* 2609 */         id(), 
/* 2610 */         channelId(), 
/* 2611 */         guildId(), this.author, 
/*      */         
/* 2613 */         member(), this.content, this.timestamp, this.editedTimestamp, this.tts, this.mentionEveryone, this.mentions, this.mentionRoles, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2621 */         mentionChannels(), this.attachments, this.embeds, 
/*      */ 
/*      */         
/* 2624 */         reactions(), 
/* 2625 */         nonce(), this.pinned, 
/*      */         
/* 2627 */         webhookId(), this.type, 
/*      */         
/* 2629 */         activity(), 
/* 2630 */         application(), 
/* 2631 */         applicationId(), 
/* 2632 */         messageReference(), 
/* 2633 */         flags(), 
/* 2634 */         stickers(), 
/* 2635 */         stickerItems(), newValue, 
/*      */         
/* 2637 */         interaction(), 
/* 2638 */         components());
/*      */   }
/*      */   
/*      */   public ImmutableMessageData withInteraction(Possible<MessageInteractionData> value) {
/* 2642 */     Possible<MessageInteractionData> newValue = Objects.<Possible<MessageInteractionData>>requireNonNull(value);
/* 2643 */     return new ImmutableMessageData(this, 
/*      */         
/* 2645 */         id(), 
/* 2646 */         channelId(), 
/* 2647 */         guildId(), this.author, 
/*      */         
/* 2649 */         member(), this.content, this.timestamp, this.editedTimestamp, this.tts, this.mentionEveryone, this.mentions, this.mentionRoles, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2657 */         mentionChannels(), this.attachments, this.embeds, 
/*      */ 
/*      */         
/* 2660 */         reactions(), 
/* 2661 */         nonce(), this.pinned, 
/*      */         
/* 2663 */         webhookId(), this.type, 
/*      */         
/* 2665 */         activity(), 
/* 2666 */         application(), 
/* 2667 */         applicationId(), 
/* 2668 */         messageReference(), 
/* 2669 */         flags(), 
/* 2670 */         stickers(), 
/* 2671 */         stickerItems(), 
/* 2672 */         referencedMessage(), newValue, 
/*      */         
/* 2674 */         components());
/*      */   }
/*      */   
/*      */   public ImmutableMessageData withInteraction(MessageInteractionData value) {
/* 2678 */     Possible<MessageInteractionData> newValue = Possible.of(value);
/* 2679 */     return new ImmutableMessageData(this, 
/*      */         
/* 2681 */         id(), 
/* 2682 */         channelId(), 
/* 2683 */         guildId(), this.author, 
/*      */         
/* 2685 */         member(), this.content, this.timestamp, this.editedTimestamp, this.tts, this.mentionEveryone, this.mentions, this.mentionRoles, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2693 */         mentionChannels(), this.attachments, this.embeds, 
/*      */ 
/*      */         
/* 2696 */         reactions(), 
/* 2697 */         nonce(), this.pinned, 
/*      */         
/* 2699 */         webhookId(), this.type, 
/*      */         
/* 2701 */         activity(), 
/* 2702 */         application(), 
/* 2703 */         applicationId(), 
/* 2704 */         messageReference(), 
/* 2705 */         flags(), 
/* 2706 */         stickers(), 
/* 2707 */         stickerItems(), 
/* 2708 */         referencedMessage(), newValue, 
/*      */         
/* 2710 */         components());
/*      */   }
/*      */   
/*      */   public ImmutableMessageData withComponents(Possible<List<ComponentData>> possible) {
/* 2714 */     Possible<List<ComponentData>> newValue = Objects.<Possible<List<ComponentData>>>requireNonNull(possible);
/* 2715 */     return new ImmutableMessageData(this, 
/*      */         
/* 2717 */         id(), 
/* 2718 */         channelId(), 
/* 2719 */         guildId(), this.author, 
/*      */         
/* 2721 */         member(), this.content, this.timestamp, this.editedTimestamp, this.tts, this.mentionEveryone, this.mentions, this.mentionRoles, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2729 */         mentionChannels(), this.attachments, this.embeds, 
/*      */ 
/*      */         
/* 2732 */         reactions(), 
/* 2733 */         nonce(), this.pinned, 
/*      */         
/* 2735 */         webhookId(), this.type, 
/*      */         
/* 2737 */         activity(), 
/* 2738 */         application(), 
/* 2739 */         applicationId(), 
/* 2740 */         messageReference(), 
/* 2741 */         flags(), 
/* 2742 */         stickers(), 
/* 2743 */         stickerItems(), 
/* 2744 */         referencedMessage(), 
/* 2745 */         interaction(), newValue);
/*      */   }
/*      */ 
/*      */   
/*      */   public ImmutableMessageData withComponents(Iterable<ComponentData> elements) {
/* 2750 */     Possible<List<ComponentData>> newValue = Possible.of(
/* 2751 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/* 2752 */     return new ImmutableMessageData(this, 
/*      */         
/* 2754 */         id(), 
/* 2755 */         channelId(), 
/* 2756 */         guildId(), this.author, 
/*      */         
/* 2758 */         member(), this.content, this.timestamp, this.editedTimestamp, this.tts, this.mentionEveryone, this.mentions, this.mentionRoles, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2766 */         mentionChannels(), this.attachments, this.embeds, 
/*      */ 
/*      */         
/* 2769 */         reactions(), 
/* 2770 */         nonce(), this.pinned, 
/*      */         
/* 2772 */         webhookId(), this.type, 
/*      */         
/* 2774 */         activity(), 
/* 2775 */         application(), 
/* 2776 */         applicationId(), 
/* 2777 */         messageReference(), 
/* 2778 */         flags(), 
/* 2779 */         stickers(), 
/* 2780 */         stickerItems(), 
/* 2781 */         referencedMessage(), 
/* 2782 */         interaction(), newValue);
/*      */   }
/*      */ 
/*      */   
/*      */   @SafeVarargs
/*      */   public final ImmutableMessageData withComponents(ComponentData... elements) {
/* 2788 */     Possible<List<ComponentData>> newValue = Possible.of(Arrays.asList(elements));
/* 2789 */     return new ImmutableMessageData(this, 
/*      */         
/* 2791 */         id(), 
/* 2792 */         channelId(), 
/* 2793 */         guildId(), this.author, 
/*      */         
/* 2795 */         member(), this.content, this.timestamp, this.editedTimestamp, this.tts, this.mentionEveryone, this.mentions, this.mentionRoles, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2803 */         mentionChannels(), this.attachments, this.embeds, 
/*      */ 
/*      */         
/* 2806 */         reactions(), 
/* 2807 */         nonce(), this.pinned, 
/*      */         
/* 2809 */         webhookId(), this.type, 
/*      */         
/* 2811 */         activity(), 
/* 2812 */         application(), 
/* 2813 */         applicationId(), 
/* 2814 */         messageReference(), 
/* 2815 */         flags(), 
/* 2816 */         stickers(), 
/* 2817 */         stickerItems(), 
/* 2818 */         referencedMessage(), 
/* 2819 */         interaction(), newValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean equals(Object another) {
/* 2829 */     if (this == another) return true; 
/* 2830 */     return (another instanceof ImmutableMessageData && 
/* 2831 */       equalTo(0, (ImmutableMessageData)another));
/*      */   }
/*      */   
/*      */   private boolean equalTo(int synthetic, ImmutableMessageData another) {
/* 2835 */     return (Objects.equals(Long.valueOf(this.id_value), Long.valueOf(another.id_value)) && 
/* 2836 */       Objects.equals(Long.valueOf(this.channelId_value), Long.valueOf(another.channelId_value)) && 
/* 2837 */       guildId().equals(another.guildId()) && this.author
/* 2838 */       .equals(another.author) && 
/* 2839 */       member().equals(another.member()) && this.content
/* 2840 */       .equals(another.content) && this.timestamp
/* 2841 */       .equals(another.timestamp) && 
/* 2842 */       Objects.equals(this.editedTimestamp, another.editedTimestamp) && this.tts == another.tts && this.mentionEveryone == another.mentionEveryone && this.mentions
/*      */ 
/*      */       
/* 2845 */       .equals(another.mentions) && this.mentionRoles
/* 2846 */       .equals(another.mentionRoles) && 
/* 2847 */       Objects.equals(this.mentionChannels_value, another.mentionChannels_value) && this.attachments
/* 2848 */       .equals(another.attachments) && this.embeds
/* 2849 */       .equals(another.embeds) && 
/* 2850 */       Objects.equals(this.reactions_value, another.reactions_value) && 
/* 2851 */       nonce().equals(another.nonce()) && this.pinned == another.pinned && 
/*      */       
/* 2853 */       webhookId().equals(another.webhookId()) && this.type == another.type && 
/*      */       
/* 2855 */       activity().equals(another.activity()) && 
/* 2856 */       application().equals(another.application()) && 
/* 2857 */       applicationId().equals(another.applicationId()) && 
/* 2858 */       messageReference().equals(another.messageReference()) && 
/* 2859 */       flags().equals(another.flags()) && 
/* 2860 */       Objects.equals(this.stickers_value, another.stickers_value) && 
/* 2861 */       Objects.equals(this.stickerItems_value, another.stickerItems_value) && 
/* 2862 */       referencedMessage().equals(another.referencedMessage()) && 
/* 2863 */       interaction().equals(another.interaction()) && 
/* 2864 */       Objects.equals(this.components_value, another.components_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int hashCode() {
/* 2873 */     int h = 5381;
/* 2874 */     h += (h << 5) + Objects.hashCode(Long.valueOf(this.id_value));
/* 2875 */     h += (h << 5) + Objects.hashCode(Long.valueOf(this.channelId_value));
/* 2876 */     h += (h << 5) + guildId().hashCode();
/* 2877 */     h += (h << 5) + this.author.hashCode();
/* 2878 */     h += (h << 5) + member().hashCode();
/* 2879 */     h += (h << 5) + this.content.hashCode();
/* 2880 */     h += (h << 5) + this.timestamp.hashCode();
/* 2881 */     h += (h << 5) + Objects.hashCode(this.editedTimestamp);
/* 2882 */     h += (h << 5) + Boolean.hashCode(this.tts);
/* 2883 */     h += (h << 5) + Boolean.hashCode(this.mentionEveryone);
/* 2884 */     h += (h << 5) + this.mentions.hashCode();
/* 2885 */     h += (h << 5) + this.mentionRoles.hashCode();
/* 2886 */     h += (h << 5) + Objects.hashCode(this.mentionChannels_value);
/* 2887 */     h += (h << 5) + this.attachments.hashCode();
/* 2888 */     h += (h << 5) + this.embeds.hashCode();
/* 2889 */     h += (h << 5) + Objects.hashCode(this.reactions_value);
/* 2890 */     h += (h << 5) + nonce().hashCode();
/* 2891 */     h += (h << 5) + Boolean.hashCode(this.pinned);
/* 2892 */     h += (h << 5) + webhookId().hashCode();
/* 2893 */     h += (h << 5) + this.type;
/* 2894 */     h += (h << 5) + activity().hashCode();
/* 2895 */     h += (h << 5) + application().hashCode();
/* 2896 */     h += (h << 5) + applicationId().hashCode();
/* 2897 */     h += (h << 5) + messageReference().hashCode();
/* 2898 */     h += (h << 5) + flags().hashCode();
/* 2899 */     h += (h << 5) + Objects.hashCode(this.stickers_value);
/* 2900 */     h += (h << 5) + Objects.hashCode(this.stickerItems_value);
/* 2901 */     h += (h << 5) + referencedMessage().hashCode();
/* 2902 */     h += (h << 5) + interaction().hashCode();
/* 2903 */     h += (h << 5) + Objects.hashCode(this.components_value);
/* 2904 */     return h;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/* 2913 */     StringBuilder builder = new StringBuilder("MessageData{");
/* 2914 */     builder.append("id=").append(Objects.toString(Long.valueOf(this.id_value)));
/* 2915 */     builder.append(", ");
/* 2916 */     builder.append("channelId=").append(Objects.toString(Long.valueOf(this.channelId_value)));
/* 2917 */     builder.append(", ");
/* 2918 */     builder.append("guildId=").append(guildId().toString());
/* 2919 */     builder.append(", ");
/* 2920 */     builder.append("author=").append(this.author);
/* 2921 */     builder.append(", ");
/* 2922 */     builder.append("member=").append(member().toString());
/* 2923 */     builder.append(", ");
/* 2924 */     builder.append("content=").append(this.content);
/* 2925 */     builder.append(", ");
/* 2926 */     builder.append("timestamp=").append(this.timestamp);
/* 2927 */     if (this.editedTimestamp != null) {
/* 2928 */       builder.append(", ");
/* 2929 */       builder.append("editedTimestamp=").append(this.editedTimestamp);
/*      */     } 
/* 2931 */     builder.append(", ");
/* 2932 */     builder.append("tts=").append(this.tts);
/* 2933 */     builder.append(", ");
/* 2934 */     builder.append("mentionEveryone=").append(this.mentionEveryone);
/* 2935 */     builder.append(", ");
/* 2936 */     builder.append("mentions=").append(this.mentions);
/* 2937 */     builder.append(", ");
/* 2938 */     builder.append("mentionRoles=").append(this.mentionRoles);
/* 2939 */     builder.append(", ");
/* 2940 */     builder.append("mentionChannels=").append(Objects.toString(this.mentionChannels_value));
/* 2941 */     builder.append(", ");
/* 2942 */     builder.append("attachments=").append(this.attachments);
/* 2943 */     builder.append(", ");
/* 2944 */     builder.append("embeds=").append(this.embeds);
/* 2945 */     builder.append(", ");
/* 2946 */     builder.append("reactions=").append(Objects.toString(this.reactions_value));
/* 2947 */     builder.append(", ");
/* 2948 */     builder.append("nonce=").append(nonce().toString());
/* 2949 */     builder.append(", ");
/* 2950 */     builder.append("pinned=").append(this.pinned);
/* 2951 */     builder.append(", ");
/* 2952 */     builder.append("webhookId=").append(webhookId().toString());
/* 2953 */     builder.append(", ");
/* 2954 */     builder.append("type=").append(this.type);
/* 2955 */     builder.append(", ");
/* 2956 */     builder.append("activity=").append(activity().toString());
/* 2957 */     builder.append(", ");
/* 2958 */     builder.append("application=").append(application().toString());
/* 2959 */     builder.append(", ");
/* 2960 */     builder.append("applicationId=").append(applicationId().toString());
/* 2961 */     builder.append(", ");
/* 2962 */     builder.append("messageReference=").append(messageReference().toString());
/* 2963 */     builder.append(", ");
/* 2964 */     builder.append("flags=").append(flags().toString());
/* 2965 */     builder.append(", ");
/* 2966 */     builder.append("stickers=").append(Objects.toString(this.stickers_value));
/* 2967 */     builder.append(", ");
/* 2968 */     builder.append("stickerItems=").append(Objects.toString(this.stickerItems_value));
/* 2969 */     builder.append(", ");
/* 2970 */     builder.append("referencedMessage=").append(referencedMessage().toString());
/* 2971 */     builder.append(", ");
/* 2972 */     builder.append("interaction=").append(interaction().toString());
/* 2973 */     builder.append(", ");
/* 2974 */     builder.append("components=").append(Objects.toString(this.components_value));
/* 2975 */     return builder.append("}").toString();
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonDeserialize
/*      */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*      */   @Generated(from = "MessageData", generator = "Immutables")
/*      */   static final class Json
/*      */     implements MessageData
/*      */   {
/*      */     Id id;
/*      */     
/*      */     Id channelId;
/*      */     
/* 2990 */     Possible<Id> guildId = Possible.absent();
/*      */     
/*      */     UserData author;
/*      */     
/* 2994 */     Possible<PartialMemberData> member = Possible.absent();
/*      */     
/*      */     String content;
/*      */     String timestamp;
/* 2998 */     Optional<String> editedTimestamp = Optional.empty();
/*      */     boolean tts;
/*      */     boolean ttsIsSet;
/*      */     boolean mentionEveryone;
/*      */     boolean mentionEveryoneIsSet;
/* 3003 */     List<UserWithMemberData> mentions = Collections.emptyList();
/* 3004 */     List<String> mentionRoles = Collections.emptyList();
/*      */     
/* 3006 */     Possible<List<ChannelMentionData>> mentionChannels = Possible.absent();
/*      */     
/* 3008 */     List<AttachmentData> attachments = Collections.emptyList();
/* 3009 */     List<EmbedData> embeds = Collections.emptyList();
/*      */     
/* 3011 */     Possible<List<ReactionData>> reactions = Possible.absent();
/*      */ 
/*      */     
/* 3014 */     Possible<Object> nonce = Possible.absent();
/*      */     
/*      */     boolean pinned;
/*      */     
/*      */     boolean pinnedIsSet;
/* 3019 */     Possible<Id> webhookId = Possible.absent();
/*      */     
/*      */     int type;
/*      */     
/*      */     boolean typeIsSet;
/* 3024 */     Possible<MessageActivityData> activity = Possible.absent();
/*      */ 
/*      */     
/* 3027 */     Possible<MessageApplicationData> application = Possible.absent();
/*      */ 
/*      */     
/* 3030 */     Possible<Id> applicationId = Possible.absent();
/*      */ 
/*      */     
/* 3033 */     Possible<MessageReferenceData> messageReference = Possible.absent();
/*      */ 
/*      */     
/* 3036 */     Possible<Integer> flags = Possible.absent();
/*      */ 
/*      */     
/* 3039 */     Possible<List<StickerData>> stickers = Possible.absent();
/*      */ 
/*      */     
/* 3042 */     Possible<List<PartialStickerData>> stickerItems = Possible.absent();
/*      */ 
/*      */     
/* 3045 */     Possible<Optional<MessageData>> referencedMessage = Possible.absent();
/*      */ 
/*      */     
/* 3048 */     Possible<MessageInteractionData> interaction = Possible.absent();
/*      */ 
/*      */     
/* 3051 */     Possible<List<ComponentData>> components = Possible.absent();
/*      */     
/*      */     @JsonProperty("id")
/*      */     public void setId(Id id) {
/* 3055 */       this.id = id;
/*      */     }
/*      */     @JsonProperty("channel_id")
/*      */     public void setChannelId(Id channelId) {
/* 3059 */       this.channelId = channelId;
/*      */     }
/*      */     @JsonProperty("guild_id")
/*      */     public void setGuildId(Possible<Id> guildId) {
/* 3063 */       this.guildId = guildId;
/*      */     }
/*      */     @JsonProperty("author")
/*      */     public void setAuthor(UserData author) {
/* 3067 */       this.author = author;
/*      */     }
/*      */     @JsonProperty("member")
/*      */     public void setMember(Possible<PartialMemberData> member) {
/* 3071 */       this.member = member;
/*      */     }
/*      */     @JsonProperty("content")
/*      */     public void setContent(String content) {
/* 3075 */       this.content = content;
/*      */     }
/*      */     @JsonProperty("timestamp")
/*      */     public void setTimestamp(String timestamp) {
/* 3079 */       this.timestamp = timestamp;
/*      */     }
/*      */     @JsonProperty("edited_timestamp")
/*      */     public void setEditedTimestamp(Optional<String> editedTimestamp) {
/* 3083 */       this.editedTimestamp = editedTimestamp;
/*      */     }
/*      */     @JsonProperty("tts")
/*      */     public void setTts(boolean tts) {
/* 3087 */       this.tts = tts;
/* 3088 */       this.ttsIsSet = true;
/*      */     }
/*      */     @JsonProperty("mention_everyone")
/*      */     public void setMentionEveryone(boolean mentionEveryone) {
/* 3092 */       this.mentionEveryone = mentionEveryone;
/* 3093 */       this.mentionEveryoneIsSet = true;
/*      */     }
/*      */     @JsonProperty("mentions")
/*      */     public void setMentions(List<UserWithMemberData> mentions) {
/* 3097 */       this.mentions = mentions;
/*      */     }
/*      */     @JsonProperty("mention_roles")
/*      */     public void setMentionRoles(List<String> mentionRoles) {
/* 3101 */       this.mentionRoles = mentionRoles;
/*      */     }
/*      */     @JsonProperty("mention_channels")
/*      */     public void setMentionChannels(Possible<List<ChannelMentionData>> mentionChannels) {
/* 3105 */       this.mentionChannels = mentionChannels;
/*      */     }
/*      */     @JsonProperty("attachments")
/*      */     public void setAttachments(List<AttachmentData> attachments) {
/* 3109 */       this.attachments = attachments;
/*      */     }
/*      */     @JsonProperty("embeds")
/*      */     public void setEmbeds(List<EmbedData> embeds) {
/* 3113 */       this.embeds = embeds;
/*      */     }
/*      */     @JsonProperty("reactions")
/*      */     public void setReactions(Possible<List<ReactionData>> reactions) {
/* 3117 */       this.reactions = reactions;
/*      */     }
/*      */     @JsonProperty("nonce")
/*      */     public void setNonce(Possible<Object> nonce) {
/* 3121 */       this.nonce = nonce;
/*      */     }
/*      */     @JsonProperty("pinned")
/*      */     public void setPinned(boolean pinned) {
/* 3125 */       this.pinned = pinned;
/* 3126 */       this.pinnedIsSet = true;
/*      */     }
/*      */     @JsonProperty("webhook_id")
/*      */     public void setWebhookId(Possible<Id> webhookId) {
/* 3130 */       this.webhookId = webhookId;
/*      */     }
/*      */     @JsonProperty("type")
/*      */     public void setType(int type) {
/* 3134 */       this.type = type;
/* 3135 */       this.typeIsSet = true;
/*      */     }
/*      */     @JsonProperty("activity")
/*      */     public void setActivity(Possible<MessageActivityData> activity) {
/* 3139 */       this.activity = activity;
/*      */     }
/*      */     @JsonProperty("application")
/*      */     public void setApplication(Possible<MessageApplicationData> application) {
/* 3143 */       this.application = application;
/*      */     }
/*      */     @JsonProperty("application_id")
/*      */     public void setApplicationId(Possible<Id> applicationId) {
/* 3147 */       this.applicationId = applicationId;
/*      */     }
/*      */     @JsonProperty("message_reference")
/*      */     public void setMessageReference(Possible<MessageReferenceData> messageReference) {
/* 3151 */       this.messageReference = messageReference;
/*      */     }
/*      */     @JsonProperty("flags")
/*      */     public void setFlags(Possible<Integer> flags) {
/* 3155 */       this.flags = flags;
/*      */     }
/*      */     @JsonProperty("stickers")
/*      */     public void setStickers(Possible<List<StickerData>> stickers) {
/* 3159 */       this.stickers = stickers;
/*      */     }
/*      */     @JsonProperty("sticker_items")
/*      */     public void setStickerItems(Possible<List<PartialStickerData>> stickerItems) {
/* 3163 */       this.stickerItems = stickerItems;
/*      */     }
/*      */     @JsonProperty("referenced_message")
/*      */     public void setReferencedMessage(Possible<Optional<MessageData>> referencedMessage) {
/* 3167 */       this.referencedMessage = referencedMessage;
/*      */     }
/*      */     @JsonProperty("interaction")
/*      */     public void setInteraction(Possible<MessageInteractionData> interaction) {
/* 3171 */       this.interaction = interaction;
/*      */     }
/*      */     @JsonProperty("components")
/*      */     public void setComponents(Possible<List<ComponentData>> components) {
/* 3175 */       this.components = components;
/*      */     }
/*      */     public Id id() {
/* 3178 */       throw new UnsupportedOperationException();
/*      */     } public Id channelId() {
/* 3180 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Id> guildId() {
/* 3182 */       throw new UnsupportedOperationException();
/*      */     } public UserData author() {
/* 3184 */       throw new UnsupportedOperationException();
/*      */     } public Possible<PartialMemberData> member() {
/* 3186 */       throw new UnsupportedOperationException();
/*      */     } public String content() {
/* 3188 */       throw new UnsupportedOperationException();
/*      */     } public String timestamp() {
/* 3190 */       throw new UnsupportedOperationException();
/*      */     } public Optional<String> editedTimestamp() {
/* 3192 */       throw new UnsupportedOperationException();
/*      */     } public boolean tts() {
/* 3194 */       throw new UnsupportedOperationException();
/*      */     } public boolean mentionEveryone() {
/* 3196 */       throw new UnsupportedOperationException();
/*      */     } public List<UserWithMemberData> mentions() {
/* 3198 */       throw new UnsupportedOperationException();
/*      */     } public List<String> mentionRoles() {
/* 3200 */       throw new UnsupportedOperationException();
/*      */     } public Possible<List<ChannelMentionData>> mentionChannels() {
/* 3202 */       throw new UnsupportedOperationException();
/*      */     } public List<AttachmentData> attachments() {
/* 3204 */       throw new UnsupportedOperationException();
/*      */     } public List<EmbedData> embeds() {
/* 3206 */       throw new UnsupportedOperationException();
/*      */     } public Possible<List<ReactionData>> reactions() {
/* 3208 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Object> nonce() {
/* 3210 */       throw new UnsupportedOperationException();
/*      */     } public boolean pinned() {
/* 3212 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Id> webhookId() {
/* 3214 */       throw new UnsupportedOperationException();
/*      */     } public int type() {
/* 3216 */       throw new UnsupportedOperationException();
/*      */     } public Possible<MessageActivityData> activity() {
/* 3218 */       throw new UnsupportedOperationException();
/*      */     } public Possible<MessageApplicationData> application() {
/* 3220 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Id> applicationId() {
/* 3222 */       throw new UnsupportedOperationException();
/*      */     } public Possible<MessageReferenceData> messageReference() {
/* 3224 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Integer> flags() {
/* 3226 */       throw new UnsupportedOperationException();
/*      */     } public Possible<List<StickerData>> stickers() {
/* 3228 */       throw new UnsupportedOperationException();
/*      */     } public Possible<List<PartialStickerData>> stickerItems() {
/* 3230 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Optional<MessageData>> referencedMessage() {
/* 3232 */       throw new UnsupportedOperationException();
/*      */     } public Possible<MessageInteractionData> interaction() {
/* 3234 */       throw new UnsupportedOperationException();
/*      */     } public Possible<List<ComponentData>> components() {
/* 3236 */       throw new UnsupportedOperationException();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*      */   static ImmutableMessageData fromJson(Json json) {
/* 3247 */     Builder builder = builder();
/* 3248 */     if (json.id != null) {
/* 3249 */       builder.id(json.id);
/*      */     }
/* 3251 */     if (json.channelId != null) {
/* 3252 */       builder.channelId(json.channelId);
/*      */     }
/* 3254 */     if (json.guildId != null) {
/* 3255 */       builder.guildId(json.guildId);
/*      */     }
/* 3257 */     if (json.author != null) {
/* 3258 */       builder.author(json.author);
/*      */     }
/* 3260 */     if (json.member != null) {
/* 3261 */       builder.member(json.member);
/*      */     }
/* 3263 */     if (json.content != null) {
/* 3264 */       builder.content(json.content);
/*      */     }
/* 3266 */     if (json.timestamp != null) {
/* 3267 */       builder.timestamp(json.timestamp);
/*      */     }
/* 3269 */     if (json.editedTimestamp != null) {
/* 3270 */       builder.editedTimestamp(json.editedTimestamp);
/*      */     }
/* 3272 */     if (json.ttsIsSet) {
/* 3273 */       builder.tts(json.tts);
/*      */     }
/* 3275 */     if (json.mentionEveryoneIsSet) {
/* 3276 */       builder.mentionEveryone(json.mentionEveryone);
/*      */     }
/* 3278 */     if (json.mentions != null) {
/* 3279 */       builder.addAllMentions(json.mentions);
/*      */     }
/* 3281 */     if (json.mentionRoles != null) {
/* 3282 */       builder.addAllMentionRoles(json.mentionRoles);
/*      */     }
/* 3284 */     if (json.mentionChannels != null) {
/* 3285 */       builder.mentionChannels(json.mentionChannels);
/*      */     }
/* 3287 */     if (json.attachments != null) {
/* 3288 */       builder.addAllAttachments(json.attachments);
/*      */     }
/* 3290 */     if (json.embeds != null) {
/* 3291 */       builder.addAllEmbeds(json.embeds);
/*      */     }
/* 3293 */     if (json.reactions != null) {
/* 3294 */       builder.reactions(json.reactions);
/*      */     }
/* 3296 */     if (json.nonce != null) {
/* 3297 */       builder.nonce(json.nonce);
/*      */     }
/* 3299 */     if (json.pinnedIsSet) {
/* 3300 */       builder.pinned(json.pinned);
/*      */     }
/* 3302 */     if (json.webhookId != null) {
/* 3303 */       builder.webhookId(json.webhookId);
/*      */     }
/* 3305 */     if (json.typeIsSet) {
/* 3306 */       builder.type(json.type);
/*      */     }
/* 3308 */     if (json.activity != null) {
/* 3309 */       builder.activity(json.activity);
/*      */     }
/* 3311 */     if (json.application != null) {
/* 3312 */       builder.application(json.application);
/*      */     }
/* 3314 */     if (json.applicationId != null) {
/* 3315 */       builder.applicationId(json.applicationId);
/*      */     }
/* 3317 */     if (json.messageReference != null) {
/* 3318 */       builder.messageReference(json.messageReference);
/*      */     }
/* 3320 */     if (json.flags != null) {
/* 3321 */       builder.flags(json.flags);
/*      */     }
/* 3323 */     if (json.stickers != null) {
/* 3324 */       builder.stickers(json.stickers);
/*      */     }
/* 3326 */     if (json.stickerItems != null) {
/* 3327 */       builder.stickerItems(json.stickerItems);
/*      */     }
/* 3329 */     if (json.referencedMessage != null) {
/* 3330 */       builder.referencedMessage(json.referencedMessage);
/*      */     }
/* 3332 */     if (json.interaction != null) {
/* 3333 */       builder.interaction(json.interaction);
/*      */     }
/* 3335 */     if (json.components != null) {
/* 3336 */       builder.components(json.components);
/*      */     }
/* 3338 */     return builder.build();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableMessageData of(Id id, Id channelId, Possible<Id> guildId, UserData author, Possible<PartialMemberData> member, String content, String timestamp, Optional<String> editedTimestamp, boolean tts, boolean mentionEveryone, List<UserWithMemberData> mentions, List<String> mentionRoles, Possible<List<ChannelMentionData>> mentionChannels, List<AttachmentData> attachments, List<EmbedData> embeds, Possible<List<ReactionData>> reactions, Possible<Object> nonce, boolean pinned, Possible<Id> webhookId, int type, Possible<MessageActivityData> activity, Possible<MessageApplicationData> application, Possible<Id> applicationId, Possible<MessageReferenceData> messageReference, Possible<Integer> flags, Possible<List<StickerData>> stickers, Possible<List<PartialStickerData>> stickerItems, Possible<Optional<MessageData>> referencedMessage, Possible<MessageInteractionData> interaction, Possible<List<ComponentData>> components) {
/* 3376 */     return of(id, channelId, guildId, author, member, content, timestamp, editedTimestamp, tts, mentionEveryone, mentions, mentionRoles, mentionChannels, attachments, embeds, reactions, nonce, pinned, webhookId, type, activity, application, applicationId, messageReference, flags, stickers, stickerItems, referencedMessage, interaction, components);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableMessageData of(Id id, Id channelId, Possible<Id> guildId, UserData author, Possible<PartialMemberData> member, String content, String timestamp, Optional<String> editedTimestamp, boolean tts, boolean mentionEveryone, Iterable<? extends UserWithMemberData> mentions, Iterable<String> mentionRoles, Possible<List<ChannelMentionData>> mentionChannels, Iterable<? extends AttachmentData> attachments, Iterable<? extends EmbedData> embeds, Possible<List<ReactionData>> reactions, Possible<Object> nonce, boolean pinned, Possible<Id> webhookId, int type, Possible<MessageActivityData> activity, Possible<MessageApplicationData> application, Possible<Id> applicationId, Possible<MessageReferenceData> messageReference, Possible<Integer> flags, Possible<List<StickerData>> stickers, Possible<List<PartialStickerData>> stickerItems, Possible<Optional<MessageData>> referencedMessage, Possible<MessageInteractionData> interaction, Possible<List<ComponentData>> components) {
/* 3414 */     return new ImmutableMessageData(id, channelId, guildId, author, member, content, timestamp, editedTimestamp, tts, mentionEveryone, mentions, mentionRoles, mentionChannels, attachments, embeds, reactions, nonce, pinned, webhookId, type, activity, application, applicationId, messageReference, flags, stickers, stickerItems, referencedMessage, interaction, components);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableMessageData copyOf(MessageData instance) {
/* 3425 */     if (instance instanceof ImmutableMessageData) {
/* 3426 */       return (ImmutableMessageData)instance;
/*      */     }
/* 3428 */     return builder()
/* 3429 */       .from(instance)
/* 3430 */       .build();
/*      */   }
/*      */   
/*      */   public boolean isGuildIdPresent() {
/* 3434 */     return !this.guildId_absent;
/*      */   }
/*      */   
/*      */   public long guildIdOrElse(long defaultValue) {
/* 3438 */     return !this.guildId_absent ? this.guildId_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isMemberPresent() {
/* 3442 */     return !this.member_absent;
/*      */   }
/*      */   
/*      */   public PartialMemberData memberOrElse(PartialMemberData defaultValue) {
/* 3446 */     return !this.member_absent ? this.member_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isMentionChannelsPresent() {
/* 3450 */     return !this.mentionChannels_absent;
/*      */   }
/*      */   
/*      */   public List<ChannelMentionData> mentionChannelsOrElse(List<ChannelMentionData> defaultValue) {
/* 3454 */     return !this.mentionChannels_absent ? this.mentionChannels_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isReactionsPresent() {
/* 3458 */     return !this.reactions_absent;
/*      */   }
/*      */   
/*      */   public List<ReactionData> reactionsOrElse(List<ReactionData> defaultValue) {
/* 3462 */     return !this.reactions_absent ? this.reactions_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isNoncePresent() {
/* 3466 */     return !this.nonce_absent;
/*      */   }
/*      */   
/*      */   public Object nonceOrElse(Object defaultValue) {
/* 3470 */     return !this.nonce_absent ? this.nonce_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isWebhookIdPresent() {
/* 3474 */     return !this.webhookId_absent;
/*      */   }
/*      */   
/*      */   public long webhookIdOrElse(long defaultValue) {
/* 3478 */     return !this.webhookId_absent ? this.webhookId_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isActivityPresent() {
/* 3482 */     return !this.activity_absent;
/*      */   }
/*      */   
/*      */   public MessageActivityData activityOrElse(MessageActivityData defaultValue) {
/* 3486 */     return !this.activity_absent ? this.activity_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isApplicationPresent() {
/* 3490 */     return !this.application_absent;
/*      */   }
/*      */   
/*      */   public MessageApplicationData applicationOrElse(MessageApplicationData defaultValue) {
/* 3494 */     return !this.application_absent ? this.application_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isApplicationIdPresent() {
/* 3498 */     return !this.applicationId_absent;
/*      */   }
/*      */   
/*      */   public long applicationIdOrElse(long defaultValue) {
/* 3502 */     return !this.applicationId_absent ? this.applicationId_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isMessageReferencePresent() {
/* 3506 */     return !this.messageReference_absent;
/*      */   }
/*      */   
/*      */   public MessageReferenceData messageReferenceOrElse(MessageReferenceData defaultValue) {
/* 3510 */     return !this.messageReference_absent ? this.messageReference_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isFlagsPresent() {
/* 3514 */     return !this.flags_absent;
/*      */   }
/*      */   
/*      */   public Integer flagsOrElse(Integer defaultValue) {
/* 3518 */     return !this.flags_absent ? this.flags_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isStickersPresent() {
/* 3522 */     return !this.stickers_absent;
/*      */   }
/*      */   
/*      */   public List<StickerData> stickersOrElse(List<StickerData> defaultValue) {
/* 3526 */     return !this.stickers_absent ? this.stickers_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isStickerItemsPresent() {
/* 3530 */     return !this.stickerItems_absent;
/*      */   }
/*      */   
/*      */   public List<PartialStickerData> stickerItemsOrElse(List<PartialStickerData> defaultValue) {
/* 3534 */     return !this.stickerItems_absent ? this.stickerItems_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isReferencedMessagePresent() {
/* 3538 */     return !this.referencedMessage_absent;
/*      */   }
/*      */   
/*      */   public MessageData referencedMessageOrElse(MessageData defaultValue) {
/* 3542 */     return !this.referencedMessage_absent ? this.referencedMessage_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isInteractionPresent() {
/* 3546 */     return !this.interaction_absent;
/*      */   }
/*      */   
/*      */   public MessageInteractionData interactionOrElse(MessageInteractionData defaultValue) {
/* 3550 */     return !this.interaction_absent ? this.interaction_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isComponentsPresent() {
/* 3554 */     return !this.components_absent;
/*      */   }
/*      */   
/*      */   public List<ComponentData> componentsOrElse(List<ComponentData> defaultValue) {
/* 3558 */     return !this.components_absent ? this.components_value : defaultValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Builder builder() {
/* 3600 */     return new Builder();
/*      */   }
/*      */ 
/*      */   
/*      */   @Generated(from = "MessageData", generator = "Immutables")
/*      */   public static final class Builder
/*      */   {
/*      */     private static final long INIT_BIT_AUTHOR = 1L;
/*      */     
/*      */     private static final long INIT_BIT_CONTENT = 2L;
/*      */     
/*      */     private static final long INIT_BIT_TIMESTAMP = 4L;
/*      */     
/*      */     private static final long INIT_BIT_TTS = 8L;
/*      */     
/*      */     private static final long INIT_BIT_MENTION_EVERYONE = 16L;
/*      */     
/*      */     private static final long INIT_BIT_PINNED = 32L;
/*      */     private static final long INIT_BIT_TYPE = 64L;
/* 3619 */     private long initBits = 127L;
/*      */     
/* 3621 */     private Id id_id = null;
/* 3622 */     private Id channelId_id = null;
/* 3623 */     private Possible<Id> guildId_possible = Possible.absent();
/* 3624 */     private Possible<PartialMemberData> member_possible = Possible.absent();
/* 3625 */     private List<ChannelMentionData> mentionChannels_list = null;
/* 3626 */     private List<ReactionData> reactions_list = null;
/* 3627 */     private Possible<Object> nonce_possible = Possible.absent();
/* 3628 */     private Possible<Id> webhookId_possible = Possible.absent();
/* 3629 */     private Possible<MessageActivityData> activity_possible = Possible.absent();
/* 3630 */     private Possible<MessageApplicationData> application_possible = Possible.absent();
/* 3631 */     private Possible<Id> applicationId_possible = Possible.absent();
/* 3632 */     private Possible<MessageReferenceData> messageReference_possible = Possible.absent();
/* 3633 */     private Possible<Integer> flags_possible = Possible.absent();
/* 3634 */     private List<StickerData> stickers_list = null;
/* 3635 */     private List<PartialStickerData> stickerItems_list = null;
/* 3636 */     private Possible<Optional<MessageData>> referencedMessage_possible = Possible.absent();
/* 3637 */     private Possible<MessageInteractionData> interaction_possible = Possible.absent();
/* 3638 */     private List<ComponentData> components_list = null;
/*      */     private UserData author;
/*      */     private String content;
/*      */     private String timestamp;
/*      */     private String editedTimestamp;
/*      */     private boolean tts;
/*      */     private boolean mentionEveryone;
/* 3645 */     private List<UserWithMemberData> mentions = new ArrayList<>();
/* 3646 */     private List<String> mentionRoles = new ArrayList<>();
/* 3647 */     private List<AttachmentData> attachments = new ArrayList<>();
/* 3648 */     private List<EmbedData> embeds = new ArrayList<>();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private boolean pinned;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private int type;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder from(MessageData instance) {
/* 3664 */       Objects.requireNonNull(instance, "instance");
/* 3665 */       id(instance.id());
/* 3666 */       channelId(instance.channelId());
/* 3667 */       guildId(instance.guildId());
/* 3668 */       author(instance.author());
/* 3669 */       member(instance.member());
/* 3670 */       content(instance.content());
/* 3671 */       timestamp(instance.timestamp());
/* 3672 */       Optional<String> editedTimestampOptional = instance.editedTimestamp();
/* 3673 */       if (editedTimestampOptional.isPresent()) {
/* 3674 */         editedTimestamp(editedTimestampOptional);
/*      */       }
/* 3676 */       tts(instance.tts());
/* 3677 */       mentionEveryone(instance.mentionEveryone());
/* 3678 */       addAllMentions(instance.mentions());
/* 3679 */       addAllMentionRoles(instance.mentionRoles());
/* 3680 */       mentionChannels(instance.mentionChannels());
/* 3681 */       addAllAttachments(instance.attachments());
/* 3682 */       addAllEmbeds(instance.embeds());
/* 3683 */       reactions(instance.reactions());
/* 3684 */       nonce(instance.nonce());
/* 3685 */       pinned(instance.pinned());
/* 3686 */       webhookId(instance.webhookId());
/* 3687 */       type(instance.type());
/* 3688 */       activity(instance.activity());
/* 3689 */       application(instance.application());
/* 3690 */       applicationId(instance.applicationId());
/* 3691 */       messageReference(instance.messageReference());
/* 3692 */       flags(instance.flags());
/* 3693 */       stickers(instance.stickers());
/* 3694 */       stickerItems(instance.stickerItems());
/* 3695 */       referencedMessage(instance.referencedMessage());
/* 3696 */       interaction(instance.interaction());
/* 3697 */       components(instance.components());
/* 3698 */       return this;
/*      */     }
/*      */     
/*      */     public Builder id(String value) {
/* 3702 */       this.id_id = Id.of(value);
/* 3703 */       return this;
/*      */     }
/*      */     
/*      */     public Builder id(long value) {
/* 3707 */       this.id_id = Id.of(value);
/* 3708 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("id")
/*      */     public Builder id(Id value) {
/* 3713 */       this.id_id = value;
/* 3714 */       return this;
/*      */     }
/*      */     
/*      */     public Builder channelId(String value) {
/* 3718 */       this.channelId_id = Id.of(value);
/* 3719 */       return this;
/*      */     }
/*      */     
/*      */     public Builder channelId(long value) {
/* 3723 */       this.channelId_id = Id.of(value);
/* 3724 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("channel_id")
/*      */     public Builder channelId(Id value) {
/* 3729 */       this.channelId_id = value;
/* 3730 */       return this;
/*      */     }
/*      */     
/*      */     public Builder guildId(String value) {
/* 3734 */       this.guildId_possible = Possible.of(Id.of(value));
/* 3735 */       return this;
/*      */     }
/*      */     
/*      */     public Builder guildId(long value) {
/* 3739 */       this.guildId_possible = Possible.of(Id.of(value));
/* 3740 */       return this;
/*      */     }
/*      */     
/*      */     public Builder guildId(Id value) {
/* 3744 */       this.guildId_possible = Possible.of(value);
/* 3745 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("guild_id")
/*      */     public Builder guildId(Possible<Id> value) {
/* 3750 */       this.guildId_possible = value;
/* 3751 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("author")
/*      */     public final Builder author(UserData author) {
/* 3761 */       this.author = Objects.<UserData>requireNonNull(author, "author");
/* 3762 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 3763 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("member")
/*      */     public Builder member(Possible<PartialMemberData> value) {
/* 3768 */       this.member_possible = value;
/* 3769 */       return this;
/*      */     }
/*      */     
/*      */     public Builder member(PartialMemberData value) {
/* 3773 */       this.member_possible = Possible.of(value);
/* 3774 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("content")
/*      */     public final Builder content(String content) {
/* 3784 */       this.content = Objects.<String>requireNonNull(content, "content");
/* 3785 */       this.initBits &= 0xFFFFFFFFFFFFFFFDL;
/* 3786 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("timestamp")
/*      */     public final Builder timestamp(String timestamp) {
/* 3796 */       this.timestamp = Objects.<String>requireNonNull(timestamp, "timestamp");
/* 3797 */       this.initBits &= 0xFFFFFFFFFFFFFFFBL;
/* 3798 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder editedTimestamp(String editedTimestamp) {
/* 3807 */       this.editedTimestamp = Objects.<String>requireNonNull(editedTimestamp, "editedTimestamp");
/* 3808 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("edited_timestamp")
/*      */     public final Builder editedTimestamp(Optional<String> editedTimestamp) {
/* 3818 */       this.editedTimestamp = editedTimestamp.orElse(null);
/* 3819 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("tts")
/*      */     public final Builder tts(boolean tts) {
/* 3829 */       this.tts = tts;
/* 3830 */       this.initBits &= 0xFFFFFFFFFFFFFFF7L;
/* 3831 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("mention_everyone")
/*      */     public final Builder mentionEveryone(boolean mentionEveryone) {
/* 3841 */       this.mentionEveryone = mentionEveryone;
/* 3842 */       this.initBits &= 0xFFFFFFFFFFFFFFEFL;
/* 3843 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addMention(UserWithMemberData element) {
/* 3852 */       this.mentions.add(Objects.<UserWithMemberData>requireNonNull(element, "mentions element"));
/* 3853 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addMentions(UserWithMemberData... elements) {
/* 3862 */       for (UserWithMemberData element : elements) {
/* 3863 */         this.mentions.add(Objects.<UserWithMemberData>requireNonNull(element, "mentions element"));
/*      */       }
/* 3865 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("mentions")
/*      */     public final Builder mentions(Iterable<? extends UserWithMemberData> elements) {
/* 3876 */       this.mentions.clear();
/* 3877 */       return addAllMentions(elements);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addAllMentions(Iterable<? extends UserWithMemberData> elements) {
/* 3886 */       for (UserWithMemberData element : elements) {
/* 3887 */         this.mentions.add(Objects.<UserWithMemberData>requireNonNull(element, "mentions element"));
/*      */       }
/* 3889 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addMentionRole(String element) {
/* 3898 */       this.mentionRoles.add(Objects.<String>requireNonNull(element, "mentionRoles element"));
/* 3899 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addMentionRoles(String... elements) {
/* 3908 */       for (String element : elements) {
/* 3909 */         this.mentionRoles.add(Objects.<String>requireNonNull(element, "mentionRoles element"));
/*      */       }
/* 3911 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("mention_roles")
/*      */     public final Builder mentionRoles(Iterable<String> elements) {
/* 3922 */       this.mentionRoles.clear();
/* 3923 */       return addAllMentionRoles(elements);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addAllMentionRoles(Iterable<String> elements) {
/* 3932 */       for (String element : elements) {
/* 3933 */         this.mentionRoles.add(Objects.<String>requireNonNull(element, "mentionRoles element"));
/*      */       }
/* 3935 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addMentionChannel(ChannelMentionData element) {
/* 3939 */       mentionChannels_getOrCreate().add(element);
/* 3940 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addAllMentionChannels(List<ChannelMentionData> elements) {
/* 3944 */       mentionChannels_getOrCreate().addAll(elements);
/* 3945 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("mention_channels")
/*      */     public Builder mentionChannels(Possible<List<ChannelMentionData>> elements) {
/* 3950 */       this.mentionChannels_list = null;
/* 3951 */       elements.toOptional().ifPresent(e -> mentionChannels_getOrCreate().addAll(e));
/* 3952 */       return this;
/*      */     }
/*      */     
/*      */     public Builder mentionChannels(List<ChannelMentionData> elements) {
/* 3956 */       this.mentionChannels_list = new ArrayList<>(elements);
/* 3957 */       return this;
/*      */     }
/*      */     
/*      */     public Builder mentionChannels(Iterable<ChannelMentionData> elements) {
/* 3961 */       this.mentionChannels_list = (List<ChannelMentionData>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/* 3962 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addAttachment(AttachmentData element) {
/* 3971 */       this.attachments.add(Objects.<AttachmentData>requireNonNull(element, "attachments element"));
/* 3972 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addAttachments(AttachmentData... elements) {
/* 3981 */       for (AttachmentData element : elements) {
/* 3982 */         this.attachments.add(Objects.<AttachmentData>requireNonNull(element, "attachments element"));
/*      */       }
/* 3984 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("attachments")
/*      */     public final Builder attachments(Iterable<? extends AttachmentData> elements) {
/* 3995 */       this.attachments.clear();
/* 3996 */       return addAllAttachments(elements);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addAllAttachments(Iterable<? extends AttachmentData> elements) {
/* 4005 */       for (AttachmentData element : elements) {
/* 4006 */         this.attachments.add(Objects.<AttachmentData>requireNonNull(element, "attachments element"));
/*      */       }
/* 4008 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addEmbed(EmbedData element) {
/* 4017 */       this.embeds.add(Objects.<EmbedData>requireNonNull(element, "embeds element"));
/* 4018 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addEmbeds(EmbedData... elements) {
/* 4027 */       for (EmbedData element : elements) {
/* 4028 */         this.embeds.add(Objects.<EmbedData>requireNonNull(element, "embeds element"));
/*      */       }
/* 4030 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("embeds")
/*      */     public final Builder embeds(Iterable<? extends EmbedData> elements) {
/* 4041 */       this.embeds.clear();
/* 4042 */       return addAllEmbeds(elements);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addAllEmbeds(Iterable<? extends EmbedData> elements) {
/* 4051 */       for (EmbedData element : elements) {
/* 4052 */         this.embeds.add(Objects.<EmbedData>requireNonNull(element, "embeds element"));
/*      */       }
/* 4054 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addReaction(ReactionData element) {
/* 4058 */       reactions_getOrCreate().add(element);
/* 4059 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addAllReactions(List<ReactionData> elements) {
/* 4063 */       reactions_getOrCreate().addAll(elements);
/* 4064 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("reactions")
/*      */     public Builder reactions(Possible<List<ReactionData>> elements) {
/* 4069 */       this.reactions_list = null;
/* 4070 */       elements.toOptional().ifPresent(e -> reactions_getOrCreate().addAll(e));
/* 4071 */       return this;
/*      */     }
/*      */     
/*      */     public Builder reactions(List<ReactionData> elements) {
/* 4075 */       this.reactions_list = new ArrayList<>(elements);
/* 4076 */       return this;
/*      */     }
/*      */     
/*      */     public Builder reactions(Iterable<ReactionData> elements) {
/* 4080 */       this.reactions_list = (List<ReactionData>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/* 4081 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("nonce")
/*      */     public Builder nonce(Possible<Object> value) {
/* 4086 */       this.nonce_possible = value;
/* 4087 */       return this;
/*      */     }
/*      */     
/*      */     public Builder nonce(Object value) {
/* 4091 */       this.nonce_possible = Possible.of(value);
/* 4092 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("pinned")
/*      */     public final Builder pinned(boolean pinned) {
/* 4102 */       this.pinned = pinned;
/* 4103 */       this.initBits &= 0xFFFFFFFFFFFFFFDFL;
/* 4104 */       return this;
/*      */     }
/*      */     
/*      */     public Builder webhookId(String value) {
/* 4108 */       this.webhookId_possible = Possible.of(Id.of(value));
/* 4109 */       return this;
/*      */     }
/*      */     
/*      */     public Builder webhookId(long value) {
/* 4113 */       this.webhookId_possible = Possible.of(Id.of(value));
/* 4114 */       return this;
/*      */     }
/*      */     
/*      */     public Builder webhookId(Id value) {
/* 4118 */       this.webhookId_possible = Possible.of(value);
/* 4119 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("webhook_id")
/*      */     public Builder webhookId(Possible<Id> value) {
/* 4124 */       this.webhookId_possible = value;
/* 4125 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("type")
/*      */     public final Builder type(int type) {
/* 4135 */       this.type = type;
/* 4136 */       this.initBits &= 0xFFFFFFFFFFFFFFBFL;
/* 4137 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("activity")
/*      */     public Builder activity(Possible<MessageActivityData> value) {
/* 4142 */       this.activity_possible = value;
/* 4143 */       return this;
/*      */     }
/*      */     
/*      */     public Builder activity(MessageActivityData value) {
/* 4147 */       this.activity_possible = Possible.of(value);
/* 4148 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("application")
/*      */     public Builder application(Possible<MessageApplicationData> value) {
/* 4153 */       this.application_possible = value;
/* 4154 */       return this;
/*      */     }
/*      */     
/*      */     public Builder application(MessageApplicationData value) {
/* 4158 */       this.application_possible = Possible.of(value);
/* 4159 */       return this;
/*      */     }
/*      */     
/*      */     public Builder applicationId(String value) {
/* 4163 */       this.applicationId_possible = Possible.of(Id.of(value));
/* 4164 */       return this;
/*      */     }
/*      */     
/*      */     public Builder applicationId(long value) {
/* 4168 */       this.applicationId_possible = Possible.of(Id.of(value));
/* 4169 */       return this;
/*      */     }
/*      */     
/*      */     public Builder applicationId(Id value) {
/* 4173 */       this.applicationId_possible = Possible.of(value);
/* 4174 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("application_id")
/*      */     public Builder applicationId(Possible<Id> value) {
/* 4179 */       this.applicationId_possible = value;
/* 4180 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("message_reference")
/*      */     public Builder messageReference(Possible<MessageReferenceData> value) {
/* 4185 */       this.messageReference_possible = value;
/* 4186 */       return this;
/*      */     }
/*      */     
/*      */     public Builder messageReference(MessageReferenceData value) {
/* 4190 */       this.messageReference_possible = Possible.of(value);
/* 4191 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("flags")
/*      */     public Builder flags(Possible<Integer> value) {
/* 4196 */       this.flags_possible = value;
/* 4197 */       return this;
/*      */     }
/*      */     
/*      */     public Builder flags(Integer value) {
/* 4201 */       this.flags_possible = Possible.of(value);
/* 4202 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addSticker(StickerData element) {
/* 4206 */       stickers_getOrCreate().add(element);
/* 4207 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addAllStickers(List<StickerData> elements) {
/* 4211 */       stickers_getOrCreate().addAll(elements);
/* 4212 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("stickers")
/*      */     public Builder stickers(Possible<List<StickerData>> elements) {
/* 4217 */       this.stickers_list = null;
/* 4218 */       elements.toOptional().ifPresent(e -> stickers_getOrCreate().addAll(e));
/* 4219 */       return this;
/*      */     }
/*      */     
/*      */     public Builder stickers(List<StickerData> elements) {
/* 4223 */       this.stickers_list = new ArrayList<>(elements);
/* 4224 */       return this;
/*      */     }
/*      */     
/*      */     public Builder stickers(Iterable<StickerData> elements) {
/* 4228 */       this.stickers_list = (List<StickerData>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/* 4229 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addStickerItem(PartialStickerData element) {
/* 4233 */       stickerItems_getOrCreate().add(element);
/* 4234 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addAllStickerItems(List<PartialStickerData> elements) {
/* 4238 */       stickerItems_getOrCreate().addAll(elements);
/* 4239 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("sticker_items")
/*      */     public Builder stickerItems(Possible<List<PartialStickerData>> elements) {
/* 4244 */       this.stickerItems_list = null;
/* 4245 */       elements.toOptional().ifPresent(e -> stickerItems_getOrCreate().addAll(e));
/* 4246 */       return this;
/*      */     }
/*      */     
/*      */     public Builder stickerItems(List<PartialStickerData> elements) {
/* 4250 */       this.stickerItems_list = new ArrayList<>(elements);
/* 4251 */       return this;
/*      */     }
/*      */     
/*      */     public Builder stickerItems(Iterable<PartialStickerData> elements) {
/* 4255 */       this.stickerItems_list = (List<PartialStickerData>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/* 4256 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("referenced_message")
/*      */     public Builder referencedMessage(Possible<Optional<MessageData>> value) {
/* 4261 */       this.referencedMessage_possible = value;
/* 4262 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public Builder referencedMessage(@Nullable MessageData value) {
/* 4267 */       this.referencedMessage_possible = Possible.of(Optional.ofNullable(value));
/* 4268 */       return this;
/*      */     }
/*      */     
/*      */     public Builder referencedMessageOrNull(@Nullable MessageData value) {
/* 4272 */       this.referencedMessage_possible = Possible.of(Optional.ofNullable(value));
/* 4273 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("interaction")
/*      */     public Builder interaction(Possible<MessageInteractionData> value) {
/* 4278 */       this.interaction_possible = value;
/* 4279 */       return this;
/*      */     }
/*      */     
/*      */     public Builder interaction(MessageInteractionData value) {
/* 4283 */       this.interaction_possible = Possible.of(value);
/* 4284 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addComponent(ComponentData element) {
/* 4288 */       components_getOrCreate().add(element);
/* 4289 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addAllComponents(List<ComponentData> elements) {
/* 4293 */       components_getOrCreate().addAll(elements);
/* 4294 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("components")
/*      */     public Builder components(Possible<List<ComponentData>> elements) {
/* 4299 */       this.components_list = null;
/* 4300 */       elements.toOptional().ifPresent(e -> components_getOrCreate().addAll(e));
/* 4301 */       return this;
/*      */     }
/*      */     
/*      */     public Builder components(List<ComponentData> elements) {
/* 4305 */       this.components_list = new ArrayList<>(elements);
/* 4306 */       return this;
/*      */     }
/*      */     
/*      */     public Builder components(Iterable<ComponentData> elements) {
/* 4310 */       this.components_list = (List<ComponentData>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/* 4311 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ImmutableMessageData build() {
/* 4320 */       if (this.initBits != 0L) {
/* 4321 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*      */       }
/* 4323 */       return new ImmutableMessageData(null, 
/*      */           
/* 4325 */           id_build(), 
/* 4326 */           channelId_build(), 
/* 4327 */           guildId_build(), this.author, 
/*      */           
/* 4329 */           member_build(), this.content, this.timestamp, this.editedTimestamp, this.tts, this.mentionEveryone, ImmutableMessageData
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 4335 */           .createUnmodifiableList(true, (List)this.mentions), ImmutableMessageData
/* 4336 */           .createUnmodifiableList(true, (List)this.mentionRoles), 
/* 4337 */           mentionChannels_build(), ImmutableMessageData
/* 4338 */           .createUnmodifiableList(true, (List)this.attachments), ImmutableMessageData
/* 4339 */           .createUnmodifiableList(true, (List)this.embeds), 
/* 4340 */           reactions_build(), 
/* 4341 */           nonce_build(), this.pinned, 
/*      */           
/* 4343 */           webhookId_build(), this.type, 
/*      */           
/* 4345 */           activity_build(), 
/* 4346 */           application_build(), 
/* 4347 */           applicationId_build(), 
/* 4348 */           messageReference_build(), 
/* 4349 */           flags_build(), 
/* 4350 */           stickers_build(), 
/* 4351 */           stickerItems_build(), 
/* 4352 */           referencedMessage_build(), 
/* 4353 */           interaction_build(), 
/* 4354 */           components_build());
/*      */     }
/*      */     
/*      */     private String formatRequiredAttributesMessage() {
/* 4358 */       List<String> attributes = new ArrayList<>();
/* 4359 */       if ((this.initBits & 0x1L) != 0L) attributes.add("author"); 
/* 4360 */       if ((this.initBits & 0x2L) != 0L) attributes.add("content"); 
/* 4361 */       if ((this.initBits & 0x4L) != 0L) attributes.add("timestamp"); 
/* 4362 */       if ((this.initBits & 0x8L) != 0L) attributes.add("tts"); 
/* 4363 */       if ((this.initBits & 0x10L) != 0L) attributes.add("mentionEveryone"); 
/* 4364 */       if ((this.initBits & 0x20L) != 0L) attributes.add("pinned"); 
/* 4365 */       if ((this.initBits & 0x40L) != 0L) attributes.add("type"); 
/* 4366 */       return "Cannot build MessageData, some of required attributes are not set " + attributes;
/*      */     }
/*      */     
/*      */     private Id id_build() {
/* 4370 */       return this.id_id;
/*      */     }
/*      */     
/*      */     private Id channelId_build() {
/* 4374 */       return this.channelId_id;
/*      */     }
/*      */     
/*      */     private Possible<Id> guildId_build() {
/* 4378 */       return this.guildId_possible;
/*      */     }
/*      */     
/*      */     private Possible<PartialMemberData> member_build() {
/* 4382 */       return this.member_possible;
/*      */     }
/*      */     
/*      */     private Possible<List<ChannelMentionData>> mentionChannels_build() {
/* 4386 */       return (this.mentionChannels_list == null) ? Possible.absent() : 
/* 4387 */         Possible.of(this.mentionChannels_list);
/*      */     }
/*      */     
/*      */     private List<ChannelMentionData> mentionChannels_getOrCreate() {
/* 4391 */       if (this.mentionChannels_list == null) {
/* 4392 */         this.mentionChannels_list = new ArrayList<>();
/*      */       }
/* 4394 */       return this.mentionChannels_list;
/*      */     }
/*      */     
/*      */     private Possible<List<ReactionData>> reactions_build() {
/* 4398 */       return (this.reactions_list == null) ? Possible.absent() : 
/* 4399 */         Possible.of(this.reactions_list);
/*      */     }
/*      */     
/*      */     private List<ReactionData> reactions_getOrCreate() {
/* 4403 */       if (this.reactions_list == null) {
/* 4404 */         this.reactions_list = new ArrayList<>();
/*      */       }
/* 4406 */       return this.reactions_list;
/*      */     }
/*      */     
/*      */     private Possible<Object> nonce_build() {
/* 4410 */       return this.nonce_possible;
/*      */     }
/*      */     
/*      */     private Possible<Id> webhookId_build() {
/* 4414 */       return this.webhookId_possible;
/*      */     }
/*      */     
/*      */     private Possible<MessageActivityData> activity_build() {
/* 4418 */       return this.activity_possible;
/*      */     }
/*      */     
/*      */     private Possible<MessageApplicationData> application_build() {
/* 4422 */       return this.application_possible;
/*      */     }
/*      */     
/*      */     private Possible<Id> applicationId_build() {
/* 4426 */       return this.applicationId_possible;
/*      */     }
/*      */     
/*      */     private Possible<MessageReferenceData> messageReference_build() {
/* 4430 */       return this.messageReference_possible;
/*      */     }
/*      */     
/*      */     private Possible<Integer> flags_build() {
/* 4434 */       return this.flags_possible;
/*      */     }
/*      */     
/*      */     private Possible<List<StickerData>> stickers_build() {
/* 4438 */       return (this.stickers_list == null) ? Possible.absent() : 
/* 4439 */         Possible.of(this.stickers_list);
/*      */     }
/*      */     
/*      */     private List<StickerData> stickers_getOrCreate() {
/* 4443 */       if (this.stickers_list == null) {
/* 4444 */         this.stickers_list = new ArrayList<>();
/*      */       }
/* 4446 */       return this.stickers_list;
/*      */     }
/*      */     
/*      */     private Possible<List<PartialStickerData>> stickerItems_build() {
/* 4450 */       return (this.stickerItems_list == null) ? Possible.absent() : 
/* 4451 */         Possible.of(this.stickerItems_list);
/*      */     }
/*      */     
/*      */     private List<PartialStickerData> stickerItems_getOrCreate() {
/* 4455 */       if (this.stickerItems_list == null) {
/* 4456 */         this.stickerItems_list = new ArrayList<>();
/*      */       }
/* 4458 */       return this.stickerItems_list;
/*      */     }
/*      */     
/*      */     private Possible<Optional<MessageData>> referencedMessage_build() {
/* 4462 */       return this.referencedMessage_possible;
/*      */     }
/*      */     
/*      */     private Possible<MessageInteractionData> interaction_build() {
/* 4466 */       return this.interaction_possible;
/*      */     }
/*      */     
/*      */     private Possible<List<ComponentData>> components_build() {
/* 4470 */       return (this.components_list == null) ? Possible.absent() : 
/* 4471 */         Possible.of(this.components_list);
/*      */     }
/*      */     
/*      */     private List<ComponentData> components_getOrCreate() {
/* 4475 */       if (this.components_list == null) {
/* 4476 */         this.components_list = new ArrayList<>();
/*      */       }
/* 4478 */       return this.components_list;
/*      */     }
/*      */     private Builder() {} }
/*      */   
/*      */   private static <T> List<T> createSafeList(Iterable<? extends T> iterable, boolean checkNulls, boolean skipNulls) {
/*      */     ArrayList<T> list;
/* 4484 */     if (iterable instanceof Collection) {
/* 4485 */       int size = ((Collection)iterable).size();
/* 4486 */       if (size == 0) return Collections.emptyList(); 
/* 4487 */       list = new ArrayList<>();
/*      */     } else {
/* 4489 */       list = new ArrayList<>();
/*      */     } 
/* 4491 */     for (T element : iterable) {
/* 4492 */       if (skipNulls && element == null)
/* 4493 */         continue;  if (checkNulls) Objects.requireNonNull(element, "element"); 
/* 4494 */       list.add(element);
/*      */     } 
/* 4496 */     return list;
/*      */   }
/*      */   
/*      */   private static <T> List<T> createUnmodifiableList(boolean clone, List<T> list) {
/* 4500 */     switch (list.size()) { case 0:
/* 4501 */         return Collections.emptyList();
/* 4502 */       case 1: return Collections.singletonList(list.get(0)); }
/*      */     
/* 4504 */     if (clone) {
/* 4505 */       return Collections.unmodifiableList(new ArrayList<>(list));
/*      */     }
/* 4507 */     if (list instanceof ArrayList) {
/* 4508 */       ((ArrayList)list).trimToSize();
/*      */     }
/* 4510 */     return Collections.unmodifiableList(list);
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableMessageData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */