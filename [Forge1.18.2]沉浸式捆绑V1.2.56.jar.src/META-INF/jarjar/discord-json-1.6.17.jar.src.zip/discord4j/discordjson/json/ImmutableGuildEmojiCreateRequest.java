/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "GuildEmojiCreateRequest", generator = "Immutables")
/*     */ public final class ImmutableGuildEmojiCreateRequest
/*     */   implements GuildEmojiCreateRequest
/*     */ {
/*     */   private final String name;
/*     */   private final String image;
/*     */   private final List<String> roles;
/*     */   
/*     */   private ImmutableGuildEmojiCreateRequest(String name, String image, Iterable<String> roles) {
/*  33 */     this.name = Objects.<String>requireNonNull(name, "name");
/*  34 */     this.image = Objects.<String>requireNonNull(image, "image");
/*  35 */     this.roles = createUnmodifiableList(false, createSafeList(roles, true, false));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ImmutableGuildEmojiCreateRequest(ImmutableGuildEmojiCreateRequest original, String name, String image, List<String> roles) {
/*  43 */     this.name = name;
/*  44 */     this.image = image;
/*  45 */     this.roles = roles;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("name")
/*     */   public String name() {
/*  54 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("image")
/*     */   public String image() {
/*  63 */     return this.image;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("roles")
/*     */   public List<String> roles() {
/*  72 */     return this.roles;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableGuildEmojiCreateRequest withName(String value) {
/*  82 */     String newValue = Objects.<String>requireNonNull(value, "name");
/*  83 */     if (this.name.equals(newValue)) return this; 
/*  84 */     return new ImmutableGuildEmojiCreateRequest(this, newValue, this.image, this.roles);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableGuildEmojiCreateRequest withImage(String value) {
/*  94 */     String newValue = Objects.<String>requireNonNull(value, "image");
/*  95 */     if (this.image.equals(newValue)) return this; 
/*  96 */     return new ImmutableGuildEmojiCreateRequest(this, this.name, newValue, this.roles);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableGuildEmojiCreateRequest withRoles(String... elements) {
/* 105 */     List<String> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/* 106 */     return new ImmutableGuildEmojiCreateRequest(this, this.name, this.image, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableGuildEmojiCreateRequest withRoles(Iterable<String> elements) {
/* 116 */     if (this.roles == elements) return this; 
/* 117 */     List<String> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/* 118 */     return new ImmutableGuildEmojiCreateRequest(this, this.name, this.image, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 127 */     if (this == another) return true; 
/* 128 */     return (another instanceof ImmutableGuildEmojiCreateRequest && 
/* 129 */       equalTo(0, (ImmutableGuildEmojiCreateRequest)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableGuildEmojiCreateRequest another) {
/* 133 */     return (this.name.equals(another.name) && this.image
/* 134 */       .equals(another.image) && this.roles
/* 135 */       .equals(another.roles));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 144 */     int h = 5381;
/* 145 */     h += (h << 5) + this.name.hashCode();
/* 146 */     h += (h << 5) + this.image.hashCode();
/* 147 */     h += (h << 5) + this.roles.hashCode();
/* 148 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 157 */     return "GuildEmojiCreateRequest{name=" + this.name + ", image=" + this.image + ", roles=" + this.roles + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "GuildEmojiCreateRequest", generator = "Immutables")
/*     */   static final class Json
/*     */     implements GuildEmojiCreateRequest
/*     */   {
/*     */     String name;
/*     */ 
/*     */     
/*     */     String image;
/*     */ 
/*     */     
/* 175 */     List<String> roles = Collections.emptyList();
/*     */     @JsonProperty("name")
/*     */     public void setName(String name) {
/* 178 */       this.name = name;
/*     */     }
/*     */     @JsonProperty("image")
/*     */     public void setImage(String image) {
/* 182 */       this.image = image;
/*     */     }
/*     */     @JsonProperty("roles")
/*     */     public void setRoles(List<String> roles) {
/* 186 */       this.roles = roles;
/*     */     }
/*     */     public String name() {
/* 189 */       throw new UnsupportedOperationException();
/*     */     } public String image() {
/* 191 */       throw new UnsupportedOperationException();
/*     */     } public List<String> roles() {
/* 193 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableGuildEmojiCreateRequest fromJson(Json json) {
/* 204 */     Builder builder = builder();
/* 205 */     if (json.name != null) {
/* 206 */       builder.name(json.name);
/*     */     }
/* 208 */     if (json.image != null) {
/* 209 */       builder.image(json.image);
/*     */     }
/* 211 */     if (json.roles != null) {
/* 212 */       builder.addAllRoles(json.roles);
/*     */     }
/* 214 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableGuildEmojiCreateRequest of(String name, String image, List<String> roles) {
/* 225 */     return of(name, image, roles);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableGuildEmojiCreateRequest of(String name, String image, Iterable<String> roles) {
/* 236 */     return new ImmutableGuildEmojiCreateRequest(name, image, roles);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableGuildEmojiCreateRequest copyOf(GuildEmojiCreateRequest instance) {
/* 247 */     if (instance instanceof ImmutableGuildEmojiCreateRequest) {
/* 248 */       return (ImmutableGuildEmojiCreateRequest)instance;
/*     */     }
/* 250 */     return builder()
/* 251 */       .from(instance)
/* 252 */       .build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 267 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "GuildEmojiCreateRequest", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_NAME = 1L;
/*     */ 
/*     */     
/*     */     private static final long INIT_BIT_IMAGE = 2L;
/*     */ 
/*     */     
/* 281 */     private long initBits = 3L;
/*     */     
/*     */     private String name;
/*     */     private String image;
/* 285 */     private List<String> roles = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(GuildEmojiCreateRequest instance) {
/* 299 */       Objects.requireNonNull(instance, "instance");
/* 300 */       name(instance.name());
/* 301 */       image(instance.image());
/* 302 */       addAllRoles(instance.roles());
/* 303 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("name")
/*     */     public final Builder name(String name) {
/* 313 */       this.name = Objects.<String>requireNonNull(name, "name");
/* 314 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 315 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("image")
/*     */     public final Builder image(String image) {
/* 325 */       this.image = Objects.<String>requireNonNull(image, "image");
/* 326 */       this.initBits &= 0xFFFFFFFFFFFFFFFDL;
/* 327 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder addRole(String element) {
/* 336 */       this.roles.add(Objects.<String>requireNonNull(element, "roles element"));
/* 337 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder addRoles(String... elements) {
/* 346 */       for (String element : elements) {
/* 347 */         this.roles.add(Objects.<String>requireNonNull(element, "roles element"));
/*     */       }
/* 349 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("roles")
/*     */     public final Builder roles(Iterable<String> elements) {
/* 360 */       this.roles.clear();
/* 361 */       return addAllRoles(elements);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder addAllRoles(Iterable<String> elements) {
/* 370 */       for (String element : elements) {
/* 371 */         this.roles.add(Objects.<String>requireNonNull(element, "roles element"));
/*     */       }
/* 373 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableGuildEmojiCreateRequest build() {
/* 382 */       if (this.initBits != 0L) {
/* 383 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 385 */       return new ImmutableGuildEmojiCreateRequest(null, this.name, this.image, ImmutableGuildEmojiCreateRequest.createUnmodifiableList(true, (List)this.roles));
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 389 */       List<String> attributes = new ArrayList<>();
/* 390 */       if ((this.initBits & 0x1L) != 0L) attributes.add("name"); 
/* 391 */       if ((this.initBits & 0x2L) != 0L) attributes.add("image"); 
/* 392 */       return "Cannot build GuildEmojiCreateRequest, some of required attributes are not set " + attributes;
/*     */     }
/*     */     private Builder() {} }
/*     */   
/*     */   private static <T> List<T> createSafeList(Iterable<? extends T> iterable, boolean checkNulls, boolean skipNulls) {
/*     */     ArrayList<T> list;
/* 398 */     if (iterable instanceof Collection) {
/* 399 */       int size = ((Collection)iterable).size();
/* 400 */       if (size == 0) return Collections.emptyList(); 
/* 401 */       list = new ArrayList<>();
/*     */     } else {
/* 403 */       list = new ArrayList<>();
/*     */     } 
/* 405 */     for (T element : iterable) {
/* 406 */       if (skipNulls && element == null)
/* 407 */         continue;  if (checkNulls) Objects.requireNonNull(element, "element"); 
/* 408 */       list.add(element);
/*     */     } 
/* 410 */     return list;
/*     */   }
/*     */   
/*     */   private static <T> List<T> createUnmodifiableList(boolean clone, List<T> list) {
/* 414 */     switch (list.size()) { case 0:
/* 415 */         return Collections.emptyList();
/* 416 */       case 1: return Collections.singletonList(list.get(0)); }
/*     */     
/* 418 */     if (clone) {
/* 419 */       return Collections.unmodifiableList(new ArrayList<>(list));
/*     */     }
/* 421 */     if (list instanceof ArrayList) {
/* 422 */       ((ArrayList)list).trimToSize();
/*     */     }
/* 424 */     return Collections.unmodifiableList(list);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableGuildEmojiCreateRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */