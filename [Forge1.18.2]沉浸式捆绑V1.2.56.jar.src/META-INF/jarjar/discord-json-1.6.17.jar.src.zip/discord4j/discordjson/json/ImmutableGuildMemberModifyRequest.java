/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.stream.StreamSupport;
/*     */ import org.immutables.value.Generated;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "GuildMemberModifyRequest", generator = "Immutables")
/*     */ public final class ImmutableGuildMemberModifyRequest
/*     */   implements GuildMemberModifyRequest
/*     */ {
/*     */   private final String nick_value;
/*     */   private final boolean nick_absent;
/*     */   private final List<String> roles_value;
/*     */   private final boolean roles_absent;
/*     */   private final Boolean mute_value;
/*     */   private final boolean mute_absent;
/*     */   private final Boolean deaf_value;
/*     */   private final boolean deaf_absent;
/*     */   private final String channelId_value;
/*     */   private final boolean channelId_absent;
/*     */   private final String communicationDisabledUntil_value;
/*     */   private final boolean communicationDisabledUntil_absent;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   
/*     */   private ImmutableGuildMemberModifyRequest(Possible<Optional<String>> nick, Possible<List<String>> roles, Possible<Boolean> mute, Possible<Boolean> deaf, Possible<Optional<String>> channelId, Possible<Optional<String>> communicationDisabledUntil) {
/*  51 */     Possible<Optional<String>> nick$impl = nick;
/*  52 */     Possible<List<String>> roles$impl = roles;
/*  53 */     Possible<Boolean> mute$impl = mute;
/*  54 */     Possible<Boolean> deaf$impl = deaf;
/*  55 */     Possible<Optional<String>> channelId$impl = channelId;
/*  56 */     Possible<Optional<String>> communicationDisabledUntil$impl = communicationDisabledUntil;
/*  57 */     this.nick_value = Possible.flatOpt(nick$impl).orElse(null);
/*  58 */     this.nick_absent = nick$impl.isAbsent();
/*  59 */     this.roles_value = roles$impl.toOptional().orElse(null);
/*  60 */     this.roles_absent = roles$impl.isAbsent();
/*  61 */     this.mute_value = mute$impl.toOptional().orElse(null);
/*  62 */     this.mute_absent = mute$impl.isAbsent();
/*  63 */     this.deaf_value = deaf$impl.toOptional().orElse(null);
/*  64 */     this.deaf_absent = deaf$impl.isAbsent();
/*  65 */     this.channelId_value = Possible.flatOpt(channelId$impl).orElse(null);
/*  66 */     this.channelId_absent = channelId$impl.isAbsent();
/*  67 */     this.communicationDisabledUntil_value = Possible.flatOpt(communicationDisabledUntil$impl).orElse(null);
/*  68 */     this.communicationDisabledUntil_absent = communicationDisabledUntil$impl.isAbsent();
/*  69 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ImmutableGuildMemberModifyRequest(ImmutableGuildMemberModifyRequest original, Possible<Optional<String>> nick, Possible<List<String>> roles, Possible<Boolean> mute, Possible<Boolean> deaf, Possible<Optional<String>> channelId, Possible<Optional<String>> communicationDisabledUntil) {
/*  80 */     Possible<Optional<String>> nick$impl = nick;
/*  81 */     Possible<List<String>> roles$impl = roles;
/*  82 */     Possible<Boolean> mute$impl = mute;
/*  83 */     Possible<Boolean> deaf$impl = deaf;
/*  84 */     Possible<Optional<String>> channelId$impl = channelId;
/*  85 */     Possible<Optional<String>> communicationDisabledUntil$impl = communicationDisabledUntil;
/*  86 */     this.nick_value = Possible.flatOpt(nick$impl).orElse(null);
/*  87 */     this.nick_absent = nick$impl.isAbsent();
/*  88 */     this.roles_value = roles$impl.toOptional().orElse(null);
/*  89 */     this.roles_absent = roles$impl.isAbsent();
/*  90 */     this.mute_value = mute$impl.toOptional().orElse(null);
/*  91 */     this.mute_absent = mute$impl.isAbsent();
/*  92 */     this.deaf_value = deaf$impl.toOptional().orElse(null);
/*  93 */     this.deaf_absent = deaf$impl.isAbsent();
/*  94 */     this.channelId_value = Possible.flatOpt(channelId$impl).orElse(null);
/*  95 */     this.channelId_absent = channelId$impl.isAbsent();
/*  96 */     this.communicationDisabledUntil_value = Possible.flatOpt(communicationDisabledUntil$impl).orElse(null);
/*  97 */     this.communicationDisabledUntil_absent = communicationDisabledUntil$impl.isAbsent();
/*  98 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 104 */   private volatile transient InitShim initShim = new InitShim();
/*     */   
/*     */   @Generated(from = "GuildMemberModifyRequest", generator = "Immutables")
/*     */   private final class InitShim {
/*     */     private String formatInitCycleMessage() {
/* 109 */       List<String> attributes = new ArrayList<>();
/* 110 */       return "Cannot build GuildMemberModifyRequest, attribute initializers form cycle " + attributes;
/*     */     }
/*     */ 
/*     */     
/*     */     private InitShim() {}
/*     */   }
/*     */ 
/*     */   
/*     */   @JsonProperty("nick")
/*     */   public Possible<Optional<String>> nick() {
/* 120 */     return this.nick_absent ? Possible.absent() : 
/* 121 */       Possible.of(Optional.ofNullable(this.nick_value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("roles")
/*     */   public Possible<List<String>> roles() {
/* 130 */     return this.roles_absent ? Possible.absent() : 
/* 131 */       Possible.of(this.roles_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("mute")
/*     */   public Possible<Boolean> mute() {
/* 140 */     return this.mute_absent ? Possible.absent() : Possible.of(this.mute_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("deaf")
/*     */   public Possible<Boolean> deaf() {
/* 149 */     return this.deaf_absent ? Possible.absent() : Possible.of(this.deaf_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("channel_id")
/*     */   public Possible<Optional<String>> channelId() {
/* 158 */     return this.channelId_absent ? Possible.absent() : 
/* 159 */       Possible.of(Optional.ofNullable(this.channelId_value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("communication_disabled_until")
/*     */   public Possible<Optional<String>> communicationDisabledUntil() {
/* 168 */     return this.communicationDisabledUntil_absent ? Possible.absent() : 
/* 169 */       Possible.of(Optional.ofNullable(this.communicationDisabledUntil_value));
/*     */   }
/*     */   
/*     */   public ImmutableGuildMemberModifyRequest withNick(Possible<Optional<String>> value) {
/* 173 */     Possible<Optional<String>> newValue = Objects.<Possible<Optional<String>>>requireNonNull(value);
/* 174 */     return new ImmutableGuildMemberModifyRequest(this, newValue, 
/*     */ 
/*     */         
/* 177 */         roles(), 
/* 178 */         mute(), 
/* 179 */         deaf(), 
/* 180 */         channelId(), 
/* 181 */         communicationDisabledUntil());
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public ImmutableGuildMemberModifyRequest withNick(@Nullable String value) {
/* 186 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/* 187 */     return new ImmutableGuildMemberModifyRequest(this, newValue, 
/*     */ 
/*     */         
/* 190 */         roles(), 
/* 191 */         mute(), 
/* 192 */         deaf(), 
/* 193 */         channelId(), 
/* 194 */         communicationDisabledUntil());
/*     */   }
/*     */   
/*     */   public ImmutableGuildMemberModifyRequest withNickOrNull(@Nullable String value) {
/* 198 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/* 199 */     return new ImmutableGuildMemberModifyRequest(this, newValue, 
/*     */ 
/*     */         
/* 202 */         roles(), 
/* 203 */         mute(), 
/* 204 */         deaf(), 
/* 205 */         channelId(), 
/* 206 */         communicationDisabledUntil());
/*     */   }
/*     */   
/*     */   public ImmutableGuildMemberModifyRequest withRoles(Possible<List<String>> possible) {
/* 210 */     Possible<List<String>> newValue = Objects.<Possible<List<String>>>requireNonNull(possible);
/* 211 */     return new ImmutableGuildMemberModifyRequest(this, 
/*     */         
/* 213 */         nick(), newValue, 
/*     */         
/* 215 */         mute(), 
/* 216 */         deaf(), 
/* 217 */         channelId(), 
/* 218 */         communicationDisabledUntil());
/*     */   }
/*     */   
/*     */   public ImmutableGuildMemberModifyRequest withRoles(Iterable<String> elements) {
/* 222 */     Possible<List<String>> newValue = Possible.of(
/* 223 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/* 224 */     return new ImmutableGuildMemberModifyRequest(this, 
/*     */         
/* 226 */         nick(), newValue, 
/*     */         
/* 228 */         mute(), 
/* 229 */         deaf(), 
/* 230 */         channelId(), 
/* 231 */         communicationDisabledUntil());
/*     */   }
/*     */   
/*     */   @SafeVarargs
/*     */   public final ImmutableGuildMemberModifyRequest withRoles(String... elements) {
/* 236 */     Possible<List<String>> newValue = Possible.of(Arrays.asList(elements));
/* 237 */     return new ImmutableGuildMemberModifyRequest(this, 
/*     */         
/* 239 */         nick(), newValue, 
/*     */         
/* 241 */         mute(), 
/* 242 */         deaf(), 
/* 243 */         channelId(), 
/* 244 */         communicationDisabledUntil());
/*     */   }
/*     */   
/*     */   public ImmutableGuildMemberModifyRequest withMute(Possible<Boolean> value) {
/* 248 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/* 249 */     return new ImmutableGuildMemberModifyRequest(this, 
/*     */         
/* 251 */         nick(), 
/* 252 */         roles(), newValue, 
/*     */         
/* 254 */         deaf(), 
/* 255 */         channelId(), 
/* 256 */         communicationDisabledUntil());
/*     */   }
/*     */   
/*     */   public ImmutableGuildMemberModifyRequest withMute(Boolean value) {
/* 260 */     Possible<Boolean> newValue = Possible.of(value);
/* 261 */     return new ImmutableGuildMemberModifyRequest(this, 
/*     */         
/* 263 */         nick(), 
/* 264 */         roles(), newValue, 
/*     */         
/* 266 */         deaf(), 
/* 267 */         channelId(), 
/* 268 */         communicationDisabledUntil());
/*     */   }
/*     */   
/*     */   public ImmutableGuildMemberModifyRequest withDeaf(Possible<Boolean> value) {
/* 272 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/* 273 */     return new ImmutableGuildMemberModifyRequest(this, 
/*     */         
/* 275 */         nick(), 
/* 276 */         roles(), 
/* 277 */         mute(), newValue, 
/*     */         
/* 279 */         channelId(), 
/* 280 */         communicationDisabledUntil());
/*     */   }
/*     */   
/*     */   public ImmutableGuildMemberModifyRequest withDeaf(Boolean value) {
/* 284 */     Possible<Boolean> newValue = Possible.of(value);
/* 285 */     return new ImmutableGuildMemberModifyRequest(this, 
/*     */         
/* 287 */         nick(), 
/* 288 */         roles(), 
/* 289 */         mute(), newValue, 
/*     */         
/* 291 */         channelId(), 
/* 292 */         communicationDisabledUntil());
/*     */   }
/*     */   
/*     */   public ImmutableGuildMemberModifyRequest withChannelId(Possible<Optional<String>> value) {
/* 296 */     Possible<Optional<String>> newValue = Objects.<Possible<Optional<String>>>requireNonNull(value);
/* 297 */     return new ImmutableGuildMemberModifyRequest(this, 
/*     */         
/* 299 */         nick(), 
/* 300 */         roles(), 
/* 301 */         mute(), 
/* 302 */         deaf(), newValue, 
/*     */         
/* 304 */         communicationDisabledUntil());
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public ImmutableGuildMemberModifyRequest withChannelId(@Nullable String value) {
/* 309 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/* 310 */     return new ImmutableGuildMemberModifyRequest(this, 
/*     */         
/* 312 */         nick(), 
/* 313 */         roles(), 
/* 314 */         mute(), 
/* 315 */         deaf(), newValue, 
/*     */         
/* 317 */         communicationDisabledUntil());
/*     */   }
/*     */   
/*     */   public ImmutableGuildMemberModifyRequest withChannelIdOrNull(@Nullable String value) {
/* 321 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/* 322 */     return new ImmutableGuildMemberModifyRequest(this, 
/*     */         
/* 324 */         nick(), 
/* 325 */         roles(), 
/* 326 */         mute(), 
/* 327 */         deaf(), newValue, 
/*     */         
/* 329 */         communicationDisabledUntil());
/*     */   }
/*     */   
/*     */   public ImmutableGuildMemberModifyRequest withCommunicationDisabledUntil(Possible<Optional<String>> value) {
/* 333 */     Possible<Optional<String>> newValue = Objects.<Possible<Optional<String>>>requireNonNull(value);
/* 334 */     return new ImmutableGuildMemberModifyRequest(this, nick(), roles(), mute(), deaf(), channelId(), newValue);
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public ImmutableGuildMemberModifyRequest withCommunicationDisabledUntil(@Nullable String value) {
/* 339 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/* 340 */     return new ImmutableGuildMemberModifyRequest(this, nick(), roles(), mute(), deaf(), channelId(), newValue);
/*     */   }
/*     */   
/*     */   public ImmutableGuildMemberModifyRequest withCommunicationDisabledUntilOrNull(@Nullable String value) {
/* 344 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/* 345 */     return new ImmutableGuildMemberModifyRequest(this, nick(), roles(), mute(), deaf(), channelId(), newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 354 */     if (this == another) return true; 
/* 355 */     return (another instanceof ImmutableGuildMemberModifyRequest && 
/* 356 */       equalTo(0, (ImmutableGuildMemberModifyRequest)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableGuildMemberModifyRequest another) {
/* 360 */     return (nick().equals(another.nick()) && 
/* 361 */       Objects.equals(this.roles_value, another.roles_value) && 
/* 362 */       mute().equals(another.mute()) && 
/* 363 */       deaf().equals(another.deaf()) && 
/* 364 */       channelId().equals(another.channelId()) && 
/* 365 */       communicationDisabledUntil().equals(another.communicationDisabledUntil()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 374 */     int h = 5381;
/* 375 */     h += (h << 5) + nick().hashCode();
/* 376 */     h += (h << 5) + Objects.hashCode(this.roles_value);
/* 377 */     h += (h << 5) + mute().hashCode();
/* 378 */     h += (h << 5) + deaf().hashCode();
/* 379 */     h += (h << 5) + channelId().hashCode();
/* 380 */     h += (h << 5) + communicationDisabledUntil().hashCode();
/* 381 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 390 */     return "GuildMemberModifyRequest{nick=" + 
/* 391 */       nick().toString() + ", roles=" + 
/* 392 */       Objects.toString(this.roles_value) + ", mute=" + 
/* 393 */       mute().toString() + ", deaf=" + 
/* 394 */       deaf().toString() + ", channelId=" + 
/* 395 */       channelId().toString() + ", communicationDisabledUntil=" + 
/* 396 */       communicationDisabledUntil().toString() + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "GuildMemberModifyRequest", generator = "Immutables")
/*     */   static final class Json
/*     */     implements GuildMemberModifyRequest
/*     */   {
/* 410 */     Possible<Optional<String>> nick = Possible.absent();
/*     */ 
/*     */     
/* 413 */     Possible<List<String>> roles = Possible.absent();
/*     */ 
/*     */     
/* 416 */     Possible<Boolean> mute = Possible.absent();
/*     */ 
/*     */     
/* 419 */     Possible<Boolean> deaf = Possible.absent();
/*     */ 
/*     */     
/* 422 */     Possible<Optional<String>> channelId = Possible.absent();
/*     */ 
/*     */     
/* 425 */     Possible<Optional<String>> communicationDisabledUntil = Possible.absent();
/*     */     
/*     */     @JsonProperty("nick")
/*     */     public void setNick(Possible<Optional<String>> nick) {
/* 429 */       this.nick = nick;
/*     */     }
/*     */     @JsonProperty("roles")
/*     */     public void setRoles(Possible<List<String>> roles) {
/* 433 */       this.roles = roles;
/*     */     }
/*     */     @JsonProperty("mute")
/*     */     public void setMute(Possible<Boolean> mute) {
/* 437 */       this.mute = mute;
/*     */     }
/*     */     @JsonProperty("deaf")
/*     */     public void setDeaf(Possible<Boolean> deaf) {
/* 441 */       this.deaf = deaf;
/*     */     }
/*     */     @JsonProperty("channel_id")
/*     */     public void setChannelId(Possible<Optional<String>> channelId) {
/* 445 */       this.channelId = channelId;
/*     */     }
/*     */     @JsonProperty("communication_disabled_until")
/*     */     public void setCommunicationDisabledUntil(Possible<Optional<String>> communicationDisabledUntil) {
/* 449 */       this.communicationDisabledUntil = communicationDisabledUntil;
/*     */     }
/*     */     public Possible<Optional<String>> nick() {
/* 452 */       throw new UnsupportedOperationException();
/*     */     } public Possible<List<String>> roles() {
/* 454 */       throw new UnsupportedOperationException();
/*     */     } public Possible<Boolean> mute() {
/* 456 */       throw new UnsupportedOperationException();
/*     */     } public Possible<Boolean> deaf() {
/* 458 */       throw new UnsupportedOperationException();
/*     */     } public Possible<Optional<String>> channelId() {
/* 460 */       throw new UnsupportedOperationException();
/*     */     } public Possible<Optional<String>> communicationDisabledUntil() {
/* 462 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableGuildMemberModifyRequest fromJson(Json json) {
/* 473 */     Builder builder = builder();
/* 474 */     if (json.nick != null) {
/* 475 */       builder.nick(json.nick);
/*     */     }
/* 477 */     if (json.roles != null) {
/* 478 */       builder.roles(json.roles);
/*     */     }
/* 480 */     if (json.mute != null) {
/* 481 */       builder.mute(json.mute);
/*     */     }
/* 483 */     if (json.deaf != null) {
/* 484 */       builder.deaf(json.deaf);
/*     */     }
/* 486 */     if (json.channelId != null) {
/* 487 */       builder.channelId(json.channelId);
/*     */     }
/* 489 */     if (json.communicationDisabledUntil != null) {
/* 490 */       builder.communicationDisabledUntil(json.communicationDisabledUntil);
/*     */     }
/* 492 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableGuildMemberModifyRequest of(Possible<Optional<String>> nick, Possible<List<String>> roles, Possible<Boolean> mute, Possible<Boolean> deaf, Possible<Optional<String>> channelId, Possible<Optional<String>> communicationDisabledUntil) {
/* 506 */     return new ImmutableGuildMemberModifyRequest(nick, roles, mute, deaf, channelId, communicationDisabledUntil);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableGuildMemberModifyRequest copyOf(GuildMemberModifyRequest instance) {
/* 517 */     if (instance instanceof ImmutableGuildMemberModifyRequest) {
/* 518 */       return (ImmutableGuildMemberModifyRequest)instance;
/*     */     }
/* 520 */     return builder()
/* 521 */       .from(instance)
/* 522 */       .build();
/*     */   }
/*     */   
/*     */   public boolean isNickPresent() {
/* 526 */     return !this.nick_absent;
/*     */   }
/*     */   
/*     */   public String nickOrElse(String defaultValue) {
/* 530 */     return !this.nick_absent ? this.nick_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isRolesPresent() {
/* 534 */     return !this.roles_absent;
/*     */   }
/*     */   
/*     */   public List<String> rolesOrElse(List<String> defaultValue) {
/* 538 */     return !this.roles_absent ? this.roles_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isMutePresent() {
/* 542 */     return !this.mute_absent;
/*     */   }
/*     */   
/*     */   public Boolean muteOrElse(Boolean defaultValue) {
/* 546 */     return !this.mute_absent ? this.mute_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isDeafPresent() {
/* 550 */     return !this.deaf_absent;
/*     */   }
/*     */   
/*     */   public Boolean deafOrElse(Boolean defaultValue) {
/* 554 */     return !this.deaf_absent ? this.deaf_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isChannelIdPresent() {
/* 558 */     return !this.channelId_absent;
/*     */   }
/*     */   
/*     */   public String channelIdOrElse(String defaultValue) {
/* 562 */     return !this.channelId_absent ? this.channelId_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isCommunicationDisabledUntilPresent() {
/* 566 */     return !this.communicationDisabledUntil_absent;
/*     */   }
/*     */   
/*     */   public String communicationDisabledUntilOrElse(String defaultValue) {
/* 570 */     return !this.communicationDisabledUntil_absent ? this.communicationDisabledUntil_value : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 588 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "GuildMemberModifyRequest", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/* 600 */     private Possible<Optional<String>> nick_possible = Possible.absent();
/* 601 */     private List<String> roles_list = null;
/* 602 */     private Possible<Boolean> mute_possible = Possible.absent();
/* 603 */     private Possible<Boolean> deaf_possible = Possible.absent();
/* 604 */     private Possible<Optional<String>> channelId_possible = Possible.absent();
/* 605 */     private Possible<Optional<String>> communicationDisabledUntil_possible = Possible.absent();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(GuildMemberModifyRequest instance) {
/* 618 */       Objects.requireNonNull(instance, "instance");
/* 619 */       nick(instance.nick());
/* 620 */       roles(instance.roles());
/* 621 */       mute(instance.mute());
/* 622 */       deaf(instance.deaf());
/* 623 */       channelId(instance.channelId());
/* 624 */       communicationDisabledUntil(instance.communicationDisabledUntil());
/* 625 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("nick")
/*     */     public Builder nick(Possible<Optional<String>> value) {
/* 630 */       this.nick_possible = value;
/* 631 */       return this;
/*     */     }
/*     */     
/*     */     @Deprecated
/*     */     public Builder nick(@Nullable String value) {
/* 636 */       this.nick_possible = Possible.of(Optional.ofNullable(value));
/* 637 */       return this;
/*     */     }
/*     */     
/*     */     public Builder nickOrNull(@Nullable String value) {
/* 641 */       this.nick_possible = Possible.of(Optional.ofNullable(value));
/* 642 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addRole(String element) {
/* 646 */       roles_getOrCreate().add(element);
/* 647 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addAllRoles(List<String> elements) {
/* 651 */       roles_getOrCreate().addAll(elements);
/* 652 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("roles")
/*     */     public Builder roles(Possible<List<String>> elements) {
/* 657 */       this.roles_list = null;
/* 658 */       elements.toOptional().ifPresent(e -> roles_getOrCreate().addAll(e));
/* 659 */       return this;
/*     */     }
/*     */     
/*     */     public Builder roles(List<String> elements) {
/* 663 */       this.roles_list = new ArrayList<>(elements);
/* 664 */       return this;
/*     */     }
/*     */     
/*     */     public Builder roles(Iterable<String> elements) {
/* 668 */       this.roles_list = (List<String>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/* 669 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("mute")
/*     */     public Builder mute(Possible<Boolean> value) {
/* 674 */       this.mute_possible = value;
/* 675 */       return this;
/*     */     }
/*     */     
/*     */     public Builder mute(Boolean value) {
/* 679 */       this.mute_possible = Possible.of(value);
/* 680 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("deaf")
/*     */     public Builder deaf(Possible<Boolean> value) {
/* 685 */       this.deaf_possible = value;
/* 686 */       return this;
/*     */     }
/*     */     
/*     */     public Builder deaf(Boolean value) {
/* 690 */       this.deaf_possible = Possible.of(value);
/* 691 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("channel_id")
/*     */     public Builder channelId(Possible<Optional<String>> value) {
/* 696 */       this.channelId_possible = value;
/* 697 */       return this;
/*     */     }
/*     */     
/*     */     @Deprecated
/*     */     public Builder channelId(@Nullable String value) {
/* 702 */       this.channelId_possible = Possible.of(Optional.ofNullable(value));
/* 703 */       return this;
/*     */     }
/*     */     
/*     */     public Builder channelIdOrNull(@Nullable String value) {
/* 707 */       this.channelId_possible = Possible.of(Optional.ofNullable(value));
/* 708 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("communication_disabled_until")
/*     */     public Builder communicationDisabledUntil(Possible<Optional<String>> value) {
/* 713 */       this.communicationDisabledUntil_possible = value;
/* 714 */       return this;
/*     */     }
/*     */     
/*     */     @Deprecated
/*     */     public Builder communicationDisabledUntil(@Nullable String value) {
/* 719 */       this.communicationDisabledUntil_possible = Possible.of(Optional.ofNullable(value));
/* 720 */       return this;
/*     */     }
/*     */     
/*     */     public Builder communicationDisabledUntilOrNull(@Nullable String value) {
/* 724 */       this.communicationDisabledUntil_possible = Possible.of(Optional.ofNullable(value));
/* 725 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableGuildMemberModifyRequest build() {
/* 734 */       return new ImmutableGuildMemberModifyRequest(null, 
/*     */           
/* 736 */           nick_build(), 
/* 737 */           roles_build(), 
/* 738 */           mute_build(), 
/* 739 */           deaf_build(), 
/* 740 */           channelId_build(), 
/* 741 */           communicationDisabledUntil_build());
/*     */     }
/*     */     
/*     */     private Possible<Optional<String>> nick_build() {
/* 745 */       return this.nick_possible;
/*     */     }
/*     */     
/*     */     private Possible<List<String>> roles_build() {
/* 749 */       return (this.roles_list == null) ? Possible.absent() : 
/* 750 */         Possible.of(this.roles_list);
/*     */     }
/*     */     
/*     */     private List<String> roles_getOrCreate() {
/* 754 */       if (this.roles_list == null) {
/* 755 */         this.roles_list = new ArrayList<>();
/*     */       }
/* 757 */       return this.roles_list;
/*     */     }
/*     */     
/*     */     private Possible<Boolean> mute_build() {
/* 761 */       return this.mute_possible;
/*     */     }
/*     */     
/*     */     private Possible<Boolean> deaf_build() {
/* 765 */       return this.deaf_possible;
/*     */     }
/*     */     
/*     */     private Possible<Optional<String>> channelId_build() {
/* 769 */       return this.channelId_possible;
/*     */     }
/*     */     
/*     */     private Possible<Optional<String>> communicationDisabledUntil_build() {
/* 773 */       return this.communicationDisabledUntil_possible;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableGuildMemberModifyRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */