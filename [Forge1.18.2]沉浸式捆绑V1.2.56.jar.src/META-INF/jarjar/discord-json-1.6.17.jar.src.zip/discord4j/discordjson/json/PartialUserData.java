/*    */ package discord4j.discordjson.json;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonProperty;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import discord4j.discordjson.Id;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import java.util.Optional;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ 
/*    */ @JsonSerialize(as = ImmutablePartialUserData.class)
/*    */ @JsonDeserialize(as = ImmutablePartialUserData.class)
/*    */ @Immutable
/*    */ public interface PartialUserData
/*    */ {
/*    */   static ImmutablePartialUserData.Builder builder() {
/* 18 */     return ImmutablePartialUserData.builder();
/*    */   }
/*    */   
/*    */   Id id();
/*    */   
/*    */   @JsonProperty("global_name")
/*    */   Possible<Optional<String>> globalName();
/*    */   
/*    */   Possible<String> username();
/*    */   
/*    */   @Deprecated
/*    */   Possible<String> discriminator();
/*    */   
/*    */   Possible<Optional<String>> avatar();
/*    */   
/*    */   Possible<Optional<String>> banner();
/*    */   
/*    */   @JsonProperty("accent_color")
/*    */   Possible<Optional<Integer>> accentColor();
/*    */   
/*    */   Possible<Boolean> bot();
/*    */   
/*    */   Possible<Boolean> system();
/*    */   
/*    */   @JsonProperty("mfa_enabled")
/*    */   Possible<Boolean> mfaEnabled();
/*    */   
/*    */   Possible<String> locale();
/*    */   
/*    */   Possible<Boolean> verified();
/*    */   
/*    */   Possible<String> email();
/*    */   
/*    */   Possible<Long> flags();
/*    */   
/*    */   @JsonProperty("premium_type")
/*    */   Possible<Integer> premiumType();
/*    */   
/*    */   @JsonProperty("public_flags")
/*    */   Possible<Long> publicFlags();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\PartialUserData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */