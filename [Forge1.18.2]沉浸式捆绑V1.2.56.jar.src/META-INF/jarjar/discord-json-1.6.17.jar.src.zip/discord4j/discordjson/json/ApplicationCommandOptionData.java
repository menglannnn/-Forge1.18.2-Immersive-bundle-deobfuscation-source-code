/*    */ package discord4j.discordjson.json;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonProperty;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import java.util.Optional;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ 
/*    */ @JsonSerialize(as = ImmutableApplicationCommandOptionData.class)
/*    */ @JsonDeserialize(as = ImmutableApplicationCommandOptionData.class)
/*    */ @Immutable
/*    */ public interface ApplicationCommandOptionData
/*    */ {
/*    */   static ImmutableApplicationCommandOptionData.Builder builder() {
/* 19 */     return ImmutableApplicationCommandOptionData.builder();
/*    */   }
/*    */   
/*    */   int type();
/*    */   
/*    */   String name();
/*    */   
/*    */   @JsonProperty("name_localizations")
/*    */   Possible<Optional<Map<String, String>>> nameLocalizations();
/*    */   
/*    */   String description();
/*    */   
/*    */   @JsonProperty("description_localizations")
/*    */   Possible<Optional<Map<String, String>>> descriptionLocalizations();
/*    */   
/*    */   Possible<Boolean> required();
/*    */   
/*    */   Possible<List<ApplicationCommandOptionChoiceData>> choices();
/*    */   
/*    */   Possible<List<ApplicationCommandOptionData>> options();
/*    */   
/*    */   Possible<Boolean> autocomplete();
/*    */   
/*    */   @JsonProperty("channel_types")
/*    */   Possible<List<Integer>> channelTypes();
/*    */   
/*    */   @JsonProperty("min_value")
/*    */   Possible<Double> minValue();
/*    */   
/*    */   @JsonProperty("max_value")
/*    */   Possible<Double> maxValue();
/*    */   
/*    */   @JsonProperty("min_length")
/*    */   Possible<Integer> minLength();
/*    */   
/*    */   @JsonProperty("max_length")
/*    */   Possible<Integer> maxLength();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ApplicationCommandOptionData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */