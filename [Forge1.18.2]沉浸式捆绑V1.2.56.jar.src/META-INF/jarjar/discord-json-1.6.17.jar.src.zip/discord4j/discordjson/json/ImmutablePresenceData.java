/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "PresenceData", generator = "Immutables")
/*     */ public final class ImmutablePresenceData
/*     */   implements PresenceData
/*     */ {
/*     */   private final PartialUserData user;
/*     */   private final String status;
/*     */   private final List<ActivityData> activities;
/*     */   private final ClientStatusData clientStatus;
/*     */   
/*     */   private ImmutablePresenceData(PartialUserData user, String status, Iterable<? extends ActivityData> activities, ClientStatusData clientStatus) {
/*  37 */     this.user = Objects.<PartialUserData>requireNonNull(user, "user");
/*  38 */     this.status = Objects.<String>requireNonNull(status, "status");
/*  39 */     this.activities = createUnmodifiableList(false, createSafeList(activities, true, false));
/*  40 */     this.clientStatus = Objects.<ClientStatusData>requireNonNull(clientStatus, "clientStatus");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ImmutablePresenceData(ImmutablePresenceData original, PartialUserData user, String status, List<ActivityData> activities, ClientStatusData clientStatus) {
/*  49 */     this.user = user;
/*  50 */     this.status = status;
/*  51 */     this.activities = activities;
/*  52 */     this.clientStatus = clientStatus;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("user")
/*     */   public PartialUserData user() {
/*  61 */     return this.user;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("status")
/*     */   public String status() {
/*  70 */     return this.status;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("activities")
/*     */   public List<ActivityData> activities() {
/*  79 */     return this.activities;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("client_status")
/*     */   public ClientStatusData clientStatus() {
/*  88 */     return this.clientStatus;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutablePresenceData withUser(PartialUserData value) {
/*  98 */     if (this.user == value) return this; 
/*  99 */     PartialUserData newValue = Objects.<PartialUserData>requireNonNull(value, "user");
/* 100 */     return new ImmutablePresenceData(this, newValue, this.status, this.activities, this.clientStatus);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutablePresenceData withStatus(String value) {
/* 110 */     String newValue = Objects.<String>requireNonNull(value, "status");
/* 111 */     if (this.status.equals(newValue)) return this; 
/* 112 */     return new ImmutablePresenceData(this, this.user, newValue, this.activities, this.clientStatus);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutablePresenceData withActivities(ActivityData... elements) {
/* 121 */     List<ActivityData> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/* 122 */     return new ImmutablePresenceData(this, this.user, this.status, newValue, this.clientStatus);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutablePresenceData withActivities(Iterable<? extends ActivityData> elements) {
/* 132 */     if (this.activities == elements) return this; 
/* 133 */     List<ActivityData> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/* 134 */     return new ImmutablePresenceData(this, this.user, this.status, newValue, this.clientStatus);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutablePresenceData withClientStatus(ClientStatusData value) {
/* 144 */     if (this.clientStatus == value) return this; 
/* 145 */     ClientStatusData newValue = Objects.<ClientStatusData>requireNonNull(value, "clientStatus");
/* 146 */     return new ImmutablePresenceData(this, this.user, this.status, this.activities, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 155 */     if (this == another) return true; 
/* 156 */     return (another instanceof ImmutablePresenceData && 
/* 157 */       equalTo(0, (ImmutablePresenceData)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutablePresenceData another) {
/* 161 */     return (this.user.equals(another.user) && this.status
/* 162 */       .equals(another.status) && this.activities
/* 163 */       .equals(another.activities) && this.clientStatus
/* 164 */       .equals(another.clientStatus));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 173 */     int h = 5381;
/* 174 */     h += (h << 5) + this.user.hashCode();
/* 175 */     h += (h << 5) + this.status.hashCode();
/* 176 */     h += (h << 5) + this.activities.hashCode();
/* 177 */     h += (h << 5) + this.clientStatus.hashCode();
/* 178 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 187 */     return "PresenceData{user=" + this.user + ", status=" + this.status + ", activities=" + this.activities + ", clientStatus=" + this.clientStatus + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "PresenceData", generator = "Immutables")
/*     */   static final class Json
/*     */     implements PresenceData
/*     */   {
/*     */     PartialUserData user;
/*     */ 
/*     */     
/*     */     String status;
/*     */ 
/*     */     
/* 206 */     List<ActivityData> activities = Collections.emptyList(); ClientStatusData clientStatus;
/*     */     
/*     */     @JsonProperty("user")
/*     */     public void setUser(PartialUserData user) {
/* 210 */       this.user = user;
/*     */     }
/*     */     @JsonProperty("status")
/*     */     public void setStatus(String status) {
/* 214 */       this.status = status;
/*     */     }
/*     */     @JsonProperty("activities")
/*     */     public void setActivities(List<ActivityData> activities) {
/* 218 */       this.activities = activities;
/*     */     }
/*     */     @JsonProperty("client_status")
/*     */     public void setClientStatus(ClientStatusData clientStatus) {
/* 222 */       this.clientStatus = clientStatus;
/*     */     }
/*     */     public PartialUserData user() {
/* 225 */       throw new UnsupportedOperationException();
/*     */     } public String status() {
/* 227 */       throw new UnsupportedOperationException();
/*     */     } public List<ActivityData> activities() {
/* 229 */       throw new UnsupportedOperationException();
/*     */     } public ClientStatusData clientStatus() {
/* 231 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutablePresenceData fromJson(Json json) {
/* 242 */     Builder builder = builder();
/* 243 */     if (json.user != null) {
/* 244 */       builder.user(json.user);
/*     */     }
/* 246 */     if (json.status != null) {
/* 247 */       builder.status(json.status);
/*     */     }
/* 249 */     if (json.activities != null) {
/* 250 */       builder.addAllActivities(json.activities);
/*     */     }
/* 252 */     if (json.clientStatus != null) {
/* 253 */       builder.clientStatus(json.clientStatus);
/*     */     }
/* 255 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutablePresenceData of(PartialUserData user, String status, List<ActivityData> activities, ClientStatusData clientStatus) {
/* 267 */     return of(user, status, activities, clientStatus);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutablePresenceData of(PartialUserData user, String status, Iterable<? extends ActivityData> activities, ClientStatusData clientStatus) {
/* 279 */     return new ImmutablePresenceData(user, status, activities, clientStatus);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutablePresenceData copyOf(PresenceData instance) {
/* 290 */     if (instance instanceof ImmutablePresenceData) {
/* 291 */       return (ImmutablePresenceData)instance;
/*     */     }
/* 293 */     return builder()
/* 294 */       .from(instance)
/* 295 */       .build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 311 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "PresenceData", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_USER = 1L;
/*     */ 
/*     */     
/*     */     private static final long INIT_BIT_STATUS = 2L;
/*     */     
/*     */     private static final long INIT_BIT_CLIENT_STATUS = 4L;
/*     */     
/* 326 */     private long initBits = 7L;
/*     */     
/*     */     private PartialUserData user;
/*     */     private String status;
/* 330 */     private List<ActivityData> activities = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private ClientStatusData clientStatus;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(PresenceData instance) {
/* 345 */       Objects.requireNonNull(instance, "instance");
/* 346 */       user(instance.user());
/* 347 */       status(instance.status());
/* 348 */       addAllActivities(instance.activities());
/* 349 */       clientStatus(instance.clientStatus());
/* 350 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("user")
/*     */     public final Builder user(PartialUserData user) {
/* 360 */       this.user = Objects.<PartialUserData>requireNonNull(user, "user");
/* 361 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 362 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("status")
/*     */     public final Builder status(String status) {
/* 372 */       this.status = Objects.<String>requireNonNull(status, "status");
/* 373 */       this.initBits &= 0xFFFFFFFFFFFFFFFDL;
/* 374 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder addActivity(ActivityData element) {
/* 383 */       this.activities.add(Objects.<ActivityData>requireNonNull(element, "activities element"));
/* 384 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder addActivities(ActivityData... elements) {
/* 393 */       for (ActivityData element : elements) {
/* 394 */         this.activities.add(Objects.<ActivityData>requireNonNull(element, "activities element"));
/*     */       }
/* 396 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("activities")
/*     */     public final Builder activities(Iterable<? extends ActivityData> elements) {
/* 407 */       this.activities.clear();
/* 408 */       return addAllActivities(elements);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder addAllActivities(Iterable<? extends ActivityData> elements) {
/* 417 */       for (ActivityData element : elements) {
/* 418 */         this.activities.add(Objects.<ActivityData>requireNonNull(element, "activities element"));
/*     */       }
/* 420 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("client_status")
/*     */     public final Builder clientStatus(ClientStatusData clientStatus) {
/* 430 */       this.clientStatus = Objects.<ClientStatusData>requireNonNull(clientStatus, "clientStatus");
/* 431 */       this.initBits &= 0xFFFFFFFFFFFFFFFBL;
/* 432 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutablePresenceData build() {
/* 441 */       if (this.initBits != 0L) {
/* 442 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 444 */       return new ImmutablePresenceData(null, this.user, this.status, ImmutablePresenceData.createUnmodifiableList(true, (List)this.activities), this.clientStatus);
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 448 */       List<String> attributes = new ArrayList<>();
/* 449 */       if ((this.initBits & 0x1L) != 0L) attributes.add("user"); 
/* 450 */       if ((this.initBits & 0x2L) != 0L) attributes.add("status"); 
/* 451 */       if ((this.initBits & 0x4L) != 0L) attributes.add("clientStatus"); 
/* 452 */       return "Cannot build PresenceData, some of required attributes are not set " + attributes;
/*     */     }
/*     */     private Builder() {} }
/*     */   
/*     */   private static <T> List<T> createSafeList(Iterable<? extends T> iterable, boolean checkNulls, boolean skipNulls) {
/*     */     ArrayList<T> list;
/* 458 */     if (iterable instanceof Collection) {
/* 459 */       int size = ((Collection)iterable).size();
/* 460 */       if (size == 0) return Collections.emptyList(); 
/* 461 */       list = new ArrayList<>();
/*     */     } else {
/* 463 */       list = new ArrayList<>();
/*     */     } 
/* 465 */     for (T element : iterable) {
/* 466 */       if (skipNulls && element == null)
/* 467 */         continue;  if (checkNulls) Objects.requireNonNull(element, "element"); 
/* 468 */       list.add(element);
/*     */     } 
/* 470 */     return list;
/*     */   }
/*     */   
/*     */   private static <T> List<T> createUnmodifiableList(boolean clone, List<T> list) {
/* 474 */     switch (list.size()) { case 0:
/* 475 */         return Collections.emptyList();
/* 476 */       case 1: return Collections.singletonList(list.get(0)); }
/*     */     
/* 478 */     if (clone) {
/* 479 */       return Collections.unmodifiableList(new ArrayList<>(list));
/*     */     }
/* 481 */     if (list instanceof ArrayList) {
/* 482 */       ((ArrayList)list).trimToSize();
/*     */     }
/* 484 */     return Collections.unmodifiableList(list);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutablePresenceData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */