/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "TokenRefreshRequest", generator = "Immutables")
/*     */ public final class ImmutableTokenRefreshRequest
/*     */   extends TokenRefreshRequest
/*     */ {
/*     */   private final long clientId;
/*     */   private final String clientSecret;
/*     */   private final String refreshToken;
/*     */   
/*     */   private ImmutableTokenRefreshRequest(long clientId, String clientSecret, String refreshToken) {
/*  25 */     this.clientId = clientId;
/*  26 */     this.clientSecret = Objects.<String>requireNonNull(clientSecret, "clientSecret");
/*  27 */     this.refreshToken = Objects.<String>requireNonNull(refreshToken, "refreshToken");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ImmutableTokenRefreshRequest(ImmutableTokenRefreshRequest original, long clientId, String clientSecret, String refreshToken) {
/*  35 */     this.clientId = clientId;
/*  36 */     this.clientSecret = clientSecret;
/*  37 */     this.refreshToken = refreshToken;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long clientId() {
/*  45 */     return this.clientId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String clientSecret() {
/*  53 */     return this.clientSecret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String refreshToken() {
/*  61 */     return this.refreshToken;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableTokenRefreshRequest withClientId(long value) {
/*  71 */     if (this.clientId == value) return this; 
/*  72 */     return new ImmutableTokenRefreshRequest(this, value, this.clientSecret, this.refreshToken);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableTokenRefreshRequest withClientSecret(String value) {
/*  82 */     String newValue = Objects.<String>requireNonNull(value, "clientSecret");
/*  83 */     if (this.clientSecret.equals(newValue)) return this; 
/*  84 */     return new ImmutableTokenRefreshRequest(this, this.clientId, newValue, this.refreshToken);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableTokenRefreshRequest withRefreshToken(String value) {
/*  94 */     String newValue = Objects.<String>requireNonNull(value, "refreshToken");
/*  95 */     if (this.refreshToken.equals(newValue)) return this; 
/*  96 */     return new ImmutableTokenRefreshRequest(this, this.clientId, this.clientSecret, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 105 */     if (this == another) return true; 
/* 106 */     return (another instanceof ImmutableTokenRefreshRequest && 
/* 107 */       equalTo(0, (ImmutableTokenRefreshRequest)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableTokenRefreshRequest another) {
/* 111 */     return (this.clientId == another.clientId && this.clientSecret
/* 112 */       .equals(another.clientSecret) && this.refreshToken
/* 113 */       .equals(another.refreshToken));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 122 */     int h = 5381;
/* 123 */     h += (h << 5) + Long.hashCode(this.clientId);
/* 124 */     h += (h << 5) + this.clientSecret.hashCode();
/* 125 */     h += (h << 5) + this.refreshToken.hashCode();
/* 126 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableTokenRefreshRequest of(long clientId, String clientSecret, String refreshToken) {
/* 137 */     return new ImmutableTokenRefreshRequest(clientId, clientSecret, refreshToken);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableTokenRefreshRequest copyOf(TokenRefreshRequest instance) {
/* 148 */     if (instance instanceof ImmutableTokenRefreshRequest) {
/* 149 */       return (ImmutableTokenRefreshRequest)instance;
/*     */     }
/* 151 */     return builder()
/* 152 */       .from(instance)
/* 153 */       .build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 168 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "TokenRefreshRequest", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_CLIENT_ID = 1L;
/*     */ 
/*     */     
/*     */     private static final long INIT_BIT_CLIENT_SECRET = 2L;
/*     */     
/*     */     private static final long INIT_BIT_REFRESH_TOKEN = 4L;
/*     */     
/* 183 */     private long initBits = 7L;
/*     */ 
/*     */ 
/*     */     
/*     */     private long clientId;
/*     */ 
/*     */ 
/*     */     
/*     */     private String clientSecret;
/*     */ 
/*     */ 
/*     */     
/*     */     private String refreshToken;
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(TokenRefreshRequest instance) {
/* 200 */       Objects.requireNonNull(instance, "instance");
/* 201 */       clientId(instance.clientId());
/* 202 */       clientSecret(instance.clientSecret());
/* 203 */       refreshToken(instance.refreshToken());
/* 204 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder clientId(long clientId) {
/* 213 */       this.clientId = clientId;
/* 214 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 215 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder clientSecret(String clientSecret) {
/* 224 */       this.clientSecret = Objects.<String>requireNonNull(clientSecret, "clientSecret");
/* 225 */       this.initBits &= 0xFFFFFFFFFFFFFFFDL;
/* 226 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder refreshToken(String refreshToken) {
/* 235 */       this.refreshToken = Objects.<String>requireNonNull(refreshToken, "refreshToken");
/* 236 */       this.initBits &= 0xFFFFFFFFFFFFFFFBL;
/* 237 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableTokenRefreshRequest build() {
/* 246 */       if (this.initBits != 0L) {
/* 247 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 249 */       return new ImmutableTokenRefreshRequest(null, this.clientId, this.clientSecret, this.refreshToken);
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 253 */       List<String> attributes = new ArrayList<>();
/* 254 */       if ((this.initBits & 0x1L) != 0L) attributes.add("clientId"); 
/* 255 */       if ((this.initBits & 0x2L) != 0L) attributes.add("clientSecret"); 
/* 256 */       if ((this.initBits & 0x4L) != 0L) attributes.add("refreshToken"); 
/* 257 */       return "Cannot build TokenRefreshRequest, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableTokenRefreshRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */