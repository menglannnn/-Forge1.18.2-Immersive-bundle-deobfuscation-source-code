/*      */ package discord4j.discordjson.json;
/*      */ 
/*      */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*      */ import com.fasterxml.jackson.annotation.JsonCreator;
/*      */ import com.fasterxml.jackson.annotation.JsonProperty;
/*      */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*      */ import discord4j.discordjson.Id;
/*      */ import discord4j.discordjson.possible.Possible;
/*      */ import java.util.ArrayList;
/*      */ import java.util.List;
/*      */ import java.util.Objects;
/*      */ import java.util.Optional;
/*      */ import org.immutables.value.Generated;
/*      */ import reactor.util.annotation.Nullable;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ @Generated(from = "AttachmentData", generator = "Immutables")
/*      */ public final class ImmutableAttachmentData
/*      */   implements AttachmentData
/*      */ {
/*      */   private final long id_value;
/*      */   private final String filename;
/*      */   private final String description_value;
/*      */   private final boolean description_absent;
/*      */   private final String contentType_value;
/*      */   private final boolean contentType_absent;
/*      */   private final int size;
/*      */   private final String url;
/*      */   private final String proxyUrl;
/*      */   private final Integer height_value;
/*      */   private final boolean height_absent;
/*      */   private final Integer width_value;
/*      */   private final boolean width_absent;
/*      */   private final Boolean ephemeral_value;
/*      */   private final boolean ephemeral_absent;
/*      */   private static final byte STAGE_INITIALIZING = -1;
/*      */   private static final byte STAGE_UNINITIALIZED = 0;
/*      */   private static final byte STAGE_INITIALIZED = 1;
/*      */   
/*      */   private ImmutableAttachmentData(Id id, String filename, Possible<String> description, Possible<String> contentType, int size, String url, String proxyUrl, Possible<Optional<Integer>> height, Possible<Optional<Integer>> width, Possible<Boolean> ephemeral) {
/*   55 */     Id id$impl = id;
/*   56 */     this.filename = Objects.<String>requireNonNull(filename, "filename");
/*   57 */     Possible<String> description$impl = description;
/*   58 */     Possible<String> contentType$impl = contentType;
/*   59 */     this.size = size;
/*   60 */     this.url = Objects.<String>requireNonNull(url, "url");
/*   61 */     this.proxyUrl = Objects.<String>requireNonNull(proxyUrl, "proxyUrl");
/*   62 */     Possible<Optional<Integer>> height$impl = height;
/*   63 */     Possible<Optional<Integer>> width$impl = width;
/*   64 */     Possible<Boolean> ephemeral$impl = ephemeral;
/*   65 */     this.id_value = id$impl.asLong();
/*   66 */     this.description_value = description$impl.toOptional().orElse(null);
/*   67 */     this.description_absent = description$impl.isAbsent();
/*   68 */     this.contentType_value = contentType$impl.toOptional().orElse(null);
/*   69 */     this.contentType_absent = contentType$impl.isAbsent();
/*   70 */     this.height_value = Possible.flatOpt(height$impl).orElse(null);
/*   71 */     this.height_absent = height$impl.isAbsent();
/*   72 */     this.width_value = Possible.flatOpt(width$impl).orElse(null);
/*   73 */     this.width_absent = width$impl.isAbsent();
/*   74 */     this.ephemeral_value = ephemeral$impl.toOptional().orElse(null);
/*   75 */     this.ephemeral_absent = ephemeral$impl.isAbsent();
/*   76 */     this.initShim = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ImmutableAttachmentData(ImmutableAttachmentData original, Id id, String filename, Possible<String> description, Possible<String> contentType, int size, String url, String proxyUrl, Possible<Optional<Integer>> height, Possible<Optional<Integer>> width, Possible<Boolean> ephemeral) {
/*   91 */     Id id$impl = id;
/*   92 */     this.filename = filename;
/*   93 */     Possible<String> description$impl = description;
/*   94 */     Possible<String> contentType$impl = contentType;
/*   95 */     this.size = size;
/*   96 */     this.url = url;
/*   97 */     this.proxyUrl = proxyUrl;
/*   98 */     Possible<Optional<Integer>> height$impl = height;
/*   99 */     Possible<Optional<Integer>> width$impl = width;
/*  100 */     Possible<Boolean> ephemeral$impl = ephemeral;
/*  101 */     this.id_value = id$impl.asLong();
/*  102 */     this.description_value = description$impl.toOptional().orElse(null);
/*  103 */     this.description_absent = description$impl.isAbsent();
/*  104 */     this.contentType_value = contentType$impl.toOptional().orElse(null);
/*  105 */     this.contentType_absent = contentType$impl.isAbsent();
/*  106 */     this.height_value = Possible.flatOpt(height$impl).orElse(null);
/*  107 */     this.height_absent = height$impl.isAbsent();
/*  108 */     this.width_value = Possible.flatOpt(width$impl).orElse(null);
/*  109 */     this.width_absent = width$impl.isAbsent();
/*  110 */     this.ephemeral_value = ephemeral$impl.toOptional().orElse(null);
/*  111 */     this.ephemeral_absent = ephemeral$impl.isAbsent();
/*  112 */     this.initShim = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  118 */   private volatile transient InitShim initShim = new InitShim();
/*      */   
/*      */   @Generated(from = "AttachmentData", generator = "Immutables")
/*      */   private final class InitShim {
/*      */     private String formatInitCycleMessage() {
/*  123 */       List<String> attributes = new ArrayList<>();
/*  124 */       return "Cannot build AttachmentData, attribute initializers form cycle " + attributes;
/*      */     }
/*      */ 
/*      */     
/*      */     private InitShim() {}
/*      */   }
/*      */ 
/*      */   
/*      */   @JsonProperty("id")
/*      */   public Id id() {
/*  134 */     return Id.of(this.id_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("filename")
/*      */   public String filename() {
/*  143 */     return this.filename;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("description")
/*      */   public Possible<String> description() {
/*  152 */     return this.description_absent ? Possible.absent() : Possible.of(this.description_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("content_type")
/*      */   public Possible<String> contentType() {
/*  161 */     return this.contentType_absent ? Possible.absent() : Possible.of(this.contentType_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("size")
/*      */   public int size() {
/*  170 */     return this.size;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("url")
/*      */   public String url() {
/*  179 */     return this.url;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("proxy_url")
/*      */   public String proxyUrl() {
/*  188 */     return this.proxyUrl;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("height")
/*      */   public Possible<Optional<Integer>> height() {
/*  197 */     return this.height_absent ? Possible.absent() : 
/*  198 */       Possible.of(Optional.ofNullable(this.height_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("width")
/*      */   public Possible<Optional<Integer>> width() {
/*  207 */     return this.width_absent ? Possible.absent() : 
/*  208 */       Possible.of(Optional.ofNullable(this.width_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("ephemeral")
/*      */   public Possible<Boolean> ephemeral() {
/*  217 */     return this.ephemeral_absent ? Possible.absent() : Possible.of(this.ephemeral_value);
/*      */   }
/*      */   
/*      */   public ImmutableAttachmentData withId(long value) {
/*  221 */     Id newValue = Id.of(value);
/*  222 */     return new ImmutableAttachmentData(this, newValue, this.filename, 
/*      */ 
/*      */ 
/*      */         
/*  226 */         description(), 
/*  227 */         contentType(), this.size, this.url, this.proxyUrl, 
/*      */ 
/*      */ 
/*      */         
/*  231 */         height(), 
/*  232 */         width(), 
/*  233 */         ephemeral());
/*      */   }
/*      */   
/*      */   public ImmutableAttachmentData withId(String value) {
/*  237 */     Id newValue = Id.of(value);
/*  238 */     return new ImmutableAttachmentData(this, newValue, this.filename, 
/*      */ 
/*      */ 
/*      */         
/*  242 */         description(), 
/*  243 */         contentType(), this.size, this.url, this.proxyUrl, 
/*      */ 
/*      */ 
/*      */         
/*  247 */         height(), 
/*  248 */         width(), 
/*  249 */         ephemeral());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableAttachmentData withFilename(String value) {
/*  259 */     String newValue = Objects.<String>requireNonNull(value, "filename");
/*  260 */     if (this.filename.equals(newValue)) return this; 
/*  261 */     return new ImmutableAttachmentData(this, 
/*      */         
/*  263 */         id(), newValue, 
/*      */         
/*  265 */         description(), 
/*  266 */         contentType(), this.size, this.url, this.proxyUrl, 
/*      */ 
/*      */ 
/*      */         
/*  270 */         height(), 
/*  271 */         width(), 
/*  272 */         ephemeral());
/*      */   }
/*      */   
/*      */   public ImmutableAttachmentData withDescription(Possible<String> value) {
/*  276 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/*  277 */     return new ImmutableAttachmentData(this, 
/*      */         
/*  279 */         id(), this.filename, newValue, 
/*      */ 
/*      */         
/*  282 */         contentType(), this.size, this.url, this.proxyUrl, 
/*      */ 
/*      */ 
/*      */         
/*  286 */         height(), 
/*  287 */         width(), 
/*  288 */         ephemeral());
/*      */   }
/*      */   
/*      */   public ImmutableAttachmentData withDescription(String value) {
/*  292 */     Possible<String> newValue = Possible.of(value);
/*  293 */     return new ImmutableAttachmentData(this, 
/*      */         
/*  295 */         id(), this.filename, newValue, 
/*      */ 
/*      */         
/*  298 */         contentType(), this.size, this.url, this.proxyUrl, 
/*      */ 
/*      */ 
/*      */         
/*  302 */         height(), 
/*  303 */         width(), 
/*  304 */         ephemeral());
/*      */   }
/*      */   
/*      */   public ImmutableAttachmentData withContentType(Possible<String> value) {
/*  308 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/*  309 */     return new ImmutableAttachmentData(this, 
/*      */         
/*  311 */         id(), this.filename, 
/*      */         
/*  313 */         description(), newValue, this.size, this.url, this.proxyUrl, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  318 */         height(), 
/*  319 */         width(), 
/*  320 */         ephemeral());
/*      */   }
/*      */   
/*      */   public ImmutableAttachmentData withContentType(String value) {
/*  324 */     Possible<String> newValue = Possible.of(value);
/*  325 */     return new ImmutableAttachmentData(this, 
/*      */         
/*  327 */         id(), this.filename, 
/*      */         
/*  329 */         description(), newValue, this.size, this.url, this.proxyUrl, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  334 */         height(), 
/*  335 */         width(), 
/*  336 */         ephemeral());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableAttachmentData withSize(int value) {
/*  346 */     if (this.size == value) return this; 
/*  347 */     return new ImmutableAttachmentData(this, 
/*      */         
/*  349 */         id(), this.filename, 
/*      */         
/*  351 */         description(), 
/*  352 */         contentType(), value, this.url, this.proxyUrl, 
/*      */ 
/*      */ 
/*      */         
/*  356 */         height(), 
/*  357 */         width(), 
/*  358 */         ephemeral());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableAttachmentData withUrl(String value) {
/*  368 */     String newValue = Objects.<String>requireNonNull(value, "url");
/*  369 */     if (this.url.equals(newValue)) return this; 
/*  370 */     return new ImmutableAttachmentData(this, 
/*      */         
/*  372 */         id(), this.filename, 
/*      */         
/*  374 */         description(), 
/*  375 */         contentType(), this.size, newValue, this.proxyUrl, 
/*      */ 
/*      */ 
/*      */         
/*  379 */         height(), 
/*  380 */         width(), 
/*  381 */         ephemeral());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableAttachmentData withProxyUrl(String value) {
/*  391 */     String newValue = Objects.<String>requireNonNull(value, "proxyUrl");
/*  392 */     if (this.proxyUrl.equals(newValue)) return this; 
/*  393 */     return new ImmutableAttachmentData(this, 
/*      */         
/*  395 */         id(), this.filename, 
/*      */         
/*  397 */         description(), 
/*  398 */         contentType(), this.size, this.url, newValue, 
/*      */ 
/*      */ 
/*      */         
/*  402 */         height(), 
/*  403 */         width(), 
/*  404 */         ephemeral());
/*      */   }
/*      */   
/*      */   public ImmutableAttachmentData withHeight(Possible<Optional<Integer>> value) {
/*  408 */     Possible<Optional<Integer>> newValue = Objects.<Possible<Optional<Integer>>>requireNonNull(value);
/*  409 */     return new ImmutableAttachmentData(this, 
/*      */         
/*  411 */         id(), this.filename, 
/*      */         
/*  413 */         description(), 
/*  414 */         contentType(), this.size, this.url, this.proxyUrl, newValue, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  419 */         width(), 
/*  420 */         ephemeral());
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public ImmutableAttachmentData withHeight(@Nullable Integer value) {
/*  425 */     Possible<Optional<Integer>> newValue = Possible.of(Optional.ofNullable(value));
/*  426 */     return new ImmutableAttachmentData(this, 
/*      */         
/*  428 */         id(), this.filename, 
/*      */         
/*  430 */         description(), 
/*  431 */         contentType(), this.size, this.url, this.proxyUrl, newValue, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  436 */         width(), 
/*  437 */         ephemeral());
/*      */   }
/*      */   
/*      */   public ImmutableAttachmentData withHeightOrNull(@Nullable Integer value) {
/*  441 */     Possible<Optional<Integer>> newValue = Possible.of(Optional.ofNullable(value));
/*  442 */     return new ImmutableAttachmentData(this, 
/*      */         
/*  444 */         id(), this.filename, 
/*      */         
/*  446 */         description(), 
/*  447 */         contentType(), this.size, this.url, this.proxyUrl, newValue, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  452 */         width(), 
/*  453 */         ephemeral());
/*      */   }
/*      */   
/*      */   public ImmutableAttachmentData withWidth(Possible<Optional<Integer>> value) {
/*  457 */     Possible<Optional<Integer>> newValue = Objects.<Possible<Optional<Integer>>>requireNonNull(value);
/*  458 */     return new ImmutableAttachmentData(this, 
/*      */         
/*  460 */         id(), this.filename, 
/*      */         
/*  462 */         description(), 
/*  463 */         contentType(), this.size, this.url, this.proxyUrl, 
/*      */ 
/*      */ 
/*      */         
/*  467 */         height(), newValue, 
/*      */         
/*  469 */         ephemeral());
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public ImmutableAttachmentData withWidth(@Nullable Integer value) {
/*  474 */     Possible<Optional<Integer>> newValue = Possible.of(Optional.ofNullable(value));
/*  475 */     return new ImmutableAttachmentData(this, 
/*      */         
/*  477 */         id(), this.filename, 
/*      */         
/*  479 */         description(), 
/*  480 */         contentType(), this.size, this.url, this.proxyUrl, 
/*      */ 
/*      */ 
/*      */         
/*  484 */         height(), newValue, 
/*      */         
/*  486 */         ephemeral());
/*      */   }
/*      */   
/*      */   public ImmutableAttachmentData withWidthOrNull(@Nullable Integer value) {
/*  490 */     Possible<Optional<Integer>> newValue = Possible.of(Optional.ofNullable(value));
/*  491 */     return new ImmutableAttachmentData(this, 
/*      */         
/*  493 */         id(), this.filename, 
/*      */         
/*  495 */         description(), 
/*  496 */         contentType(), this.size, this.url, this.proxyUrl, 
/*      */ 
/*      */ 
/*      */         
/*  500 */         height(), newValue, 
/*      */         
/*  502 */         ephemeral());
/*      */   }
/*      */   
/*      */   public ImmutableAttachmentData withEphemeral(Possible<Boolean> value) {
/*  506 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/*  507 */     return new ImmutableAttachmentData(this, 
/*      */         
/*  509 */         id(), this.filename, 
/*      */         
/*  511 */         description(), 
/*  512 */         contentType(), this.size, this.url, this.proxyUrl, 
/*      */ 
/*      */ 
/*      */         
/*  516 */         height(), 
/*  517 */         width(), newValue);
/*      */   }
/*      */ 
/*      */   
/*      */   public ImmutableAttachmentData withEphemeral(Boolean value) {
/*  522 */     Possible<Boolean> newValue = Possible.of(value);
/*  523 */     return new ImmutableAttachmentData(this, 
/*      */         
/*  525 */         id(), this.filename, 
/*      */         
/*  527 */         description(), 
/*  528 */         contentType(), this.size, this.url, this.proxyUrl, 
/*      */ 
/*      */ 
/*      */         
/*  532 */         height(), 
/*  533 */         width(), newValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean equals(Object another) {
/*  543 */     if (this == another) return true; 
/*  544 */     return (another instanceof ImmutableAttachmentData && 
/*  545 */       equalTo(0, (ImmutableAttachmentData)another));
/*      */   }
/*      */   
/*      */   private boolean equalTo(int synthetic, ImmutableAttachmentData another) {
/*  549 */     return (Objects.equals(Long.valueOf(this.id_value), Long.valueOf(another.id_value)) && this.filename
/*  550 */       .equals(another.filename) && 
/*  551 */       description().equals(another.description()) && 
/*  552 */       contentType().equals(another.contentType()) && this.size == another.size && this.url
/*      */       
/*  554 */       .equals(another.url) && this.proxyUrl
/*  555 */       .equals(another.proxyUrl) && 
/*  556 */       height().equals(another.height()) && 
/*  557 */       width().equals(another.width()) && 
/*  558 */       ephemeral().equals(another.ephemeral()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int hashCode() {
/*  567 */     int h = 5381;
/*  568 */     h += (h << 5) + Objects.hashCode(Long.valueOf(this.id_value));
/*  569 */     h += (h << 5) + this.filename.hashCode();
/*  570 */     h += (h << 5) + description().hashCode();
/*  571 */     h += (h << 5) + contentType().hashCode();
/*  572 */     h += (h << 5) + this.size;
/*  573 */     h += (h << 5) + this.url.hashCode();
/*  574 */     h += (h << 5) + this.proxyUrl.hashCode();
/*  575 */     h += (h << 5) + height().hashCode();
/*  576 */     h += (h << 5) + width().hashCode();
/*  577 */     h += (h << 5) + ephemeral().hashCode();
/*  578 */     return h;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/*  587 */     return "AttachmentData{id=" + 
/*  588 */       Objects.toString(Long.valueOf(this.id_value)) + ", filename=" + this.filename + ", description=" + 
/*      */       
/*  590 */       description().toString() + ", contentType=" + 
/*  591 */       contentType().toString() + ", size=" + this.size + ", url=" + this.url + ", proxyUrl=" + this.proxyUrl + ", height=" + 
/*      */ 
/*      */ 
/*      */       
/*  595 */       height().toString() + ", width=" + 
/*  596 */       width().toString() + ", ephemeral=" + 
/*  597 */       ephemeral().toString() + "}";
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonDeserialize
/*      */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*      */   @Generated(from = "AttachmentData", generator = "Immutables")
/*      */   static final class Json
/*      */     implements AttachmentData
/*      */   {
/*      */     Id id;
/*      */     
/*      */     String filename;
/*      */     
/*  613 */     Possible<String> description = Possible.absent();
/*      */ 
/*      */     
/*  616 */     Possible<String> contentType = Possible.absent();
/*      */     
/*      */     int size;
/*      */     
/*      */     boolean sizeIsSet;
/*      */     String url;
/*      */     String proxyUrl;
/*  623 */     Possible<Optional<Integer>> height = Possible.absent();
/*      */ 
/*      */     
/*  626 */     Possible<Optional<Integer>> width = Possible.absent();
/*      */ 
/*      */     
/*  629 */     Possible<Boolean> ephemeral = Possible.absent();
/*      */     
/*      */     @JsonProperty("id")
/*      */     public void setId(Id id) {
/*  633 */       this.id = id;
/*      */     }
/*      */     @JsonProperty("filename")
/*      */     public void setFilename(String filename) {
/*  637 */       this.filename = filename;
/*      */     }
/*      */     @JsonProperty("description")
/*      */     public void setDescription(Possible<String> description) {
/*  641 */       this.description = description;
/*      */     }
/*      */     @JsonProperty("content_type")
/*      */     public void setContentType(Possible<String> contentType) {
/*  645 */       this.contentType = contentType;
/*      */     }
/*      */     @JsonProperty("size")
/*      */     public void setSize(int size) {
/*  649 */       this.size = size;
/*  650 */       this.sizeIsSet = true;
/*      */     }
/*      */     @JsonProperty("url")
/*      */     public void setUrl(String url) {
/*  654 */       this.url = url;
/*      */     }
/*      */     @JsonProperty("proxy_url")
/*      */     public void setProxyUrl(String proxyUrl) {
/*  658 */       this.proxyUrl = proxyUrl;
/*      */     }
/*      */     @JsonProperty("height")
/*      */     public void setHeight(Possible<Optional<Integer>> height) {
/*  662 */       this.height = height;
/*      */     }
/*      */     @JsonProperty("width")
/*      */     public void setWidth(Possible<Optional<Integer>> width) {
/*  666 */       this.width = width;
/*      */     }
/*      */     @JsonProperty("ephemeral")
/*      */     public void setEphemeral(Possible<Boolean> ephemeral) {
/*  670 */       this.ephemeral = ephemeral;
/*      */     }
/*      */     public Id id() {
/*  673 */       throw new UnsupportedOperationException();
/*      */     } public String filename() {
/*  675 */       throw new UnsupportedOperationException();
/*      */     } public Possible<String> description() {
/*  677 */       throw new UnsupportedOperationException();
/*      */     } public Possible<String> contentType() {
/*  679 */       throw new UnsupportedOperationException();
/*      */     } public int size() {
/*  681 */       throw new UnsupportedOperationException();
/*      */     } public String url() {
/*  683 */       throw new UnsupportedOperationException();
/*      */     } public String proxyUrl() {
/*  685 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Optional<Integer>> height() {
/*  687 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Optional<Integer>> width() {
/*  689 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Boolean> ephemeral() {
/*  691 */       throw new UnsupportedOperationException();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*      */   static ImmutableAttachmentData fromJson(Json json) {
/*  702 */     Builder builder = builder();
/*  703 */     if (json.id != null) {
/*  704 */       builder.id(json.id);
/*      */     }
/*  706 */     if (json.filename != null) {
/*  707 */       builder.filename(json.filename);
/*      */     }
/*  709 */     if (json.description != null) {
/*  710 */       builder.description(json.description);
/*      */     }
/*  712 */     if (json.contentType != null) {
/*  713 */       builder.contentType(json.contentType);
/*      */     }
/*  715 */     if (json.sizeIsSet) {
/*  716 */       builder.size(json.size);
/*      */     }
/*  718 */     if (json.url != null) {
/*  719 */       builder.url(json.url);
/*      */     }
/*  721 */     if (json.proxyUrl != null) {
/*  722 */       builder.proxyUrl(json.proxyUrl);
/*      */     }
/*  724 */     if (json.height != null) {
/*  725 */       builder.height(json.height);
/*      */     }
/*  727 */     if (json.width != null) {
/*  728 */       builder.width(json.width);
/*      */     }
/*  730 */     if (json.ephemeral != null) {
/*  731 */       builder.ephemeral(json.ephemeral);
/*      */     }
/*  733 */     return builder.build();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableAttachmentData of(Id id, String filename, Possible<String> description, Possible<String> contentType, int size, String url, String proxyUrl, Possible<Optional<Integer>> height, Possible<Optional<Integer>> width, Possible<Boolean> ephemeral) {
/*  751 */     return new ImmutableAttachmentData(id, filename, description, contentType, size, url, proxyUrl, height, width, ephemeral);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableAttachmentData copyOf(AttachmentData instance) {
/*  762 */     if (instance instanceof ImmutableAttachmentData) {
/*  763 */       return (ImmutableAttachmentData)instance;
/*      */     }
/*  765 */     return builder()
/*  766 */       .from(instance)
/*  767 */       .build();
/*      */   }
/*      */   
/*      */   public boolean isDescriptionPresent() {
/*  771 */     return !this.description_absent;
/*      */   }
/*      */   
/*      */   public String descriptionOrElse(String defaultValue) {
/*  775 */     return !this.description_absent ? this.description_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isContentTypePresent() {
/*  779 */     return !this.contentType_absent;
/*      */   }
/*      */   
/*      */   public String contentTypeOrElse(String defaultValue) {
/*  783 */     return !this.contentType_absent ? this.contentType_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isHeightPresent() {
/*  787 */     return !this.height_absent;
/*      */   }
/*      */   
/*      */   public Integer heightOrElse(Integer defaultValue) {
/*  791 */     return !this.height_absent ? this.height_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isWidthPresent() {
/*  795 */     return !this.width_absent;
/*      */   }
/*      */   
/*      */   public Integer widthOrElse(Integer defaultValue) {
/*  799 */     return !this.width_absent ? this.width_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isEphemeralPresent() {
/*  803 */     return !this.ephemeral_absent;
/*      */   }
/*      */   
/*      */   public Boolean ephemeralOrElse(Boolean defaultValue) {
/*  807 */     return !this.ephemeral_absent ? this.ephemeral_value : defaultValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Builder builder() {
/*  829 */     return new Builder();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   @Generated(from = "AttachmentData", generator = "Immutables")
/*      */   public static final class Builder
/*      */   {
/*      */     private static final long INIT_BIT_FILENAME = 1L;
/*      */     
/*      */     private static final long INIT_BIT_SIZE = 2L;
/*      */     
/*      */     private static final long INIT_BIT_URL = 4L;
/*      */     
/*      */     private static final long INIT_BIT_PROXY_URL = 8L;
/*      */     
/*  845 */     private long initBits = 15L;
/*      */     
/*  847 */     private Id id_id = null;
/*  848 */     private Possible<String> description_possible = Possible.absent();
/*  849 */     private Possible<String> contentType_possible = Possible.absent();
/*  850 */     private Possible<Optional<Integer>> height_possible = Possible.absent();
/*  851 */     private Possible<Optional<Integer>> width_possible = Possible.absent();
/*  852 */     private Possible<Boolean> ephemeral_possible = Possible.absent();
/*      */ 
/*      */     
/*      */     private String filename;
/*      */ 
/*      */     
/*      */     private int size;
/*      */ 
/*      */     
/*      */     private String url;
/*      */ 
/*      */     
/*      */     private String proxyUrl;
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder from(AttachmentData instance) {
/*  869 */       Objects.requireNonNull(instance, "instance");
/*  870 */       id(instance.id());
/*  871 */       filename(instance.filename());
/*  872 */       description(instance.description());
/*  873 */       contentType(instance.contentType());
/*  874 */       size(instance.size());
/*  875 */       url(instance.url());
/*  876 */       proxyUrl(instance.proxyUrl());
/*  877 */       height(instance.height());
/*  878 */       width(instance.width());
/*  879 */       ephemeral(instance.ephemeral());
/*  880 */       return this;
/*      */     }
/*      */     
/*      */     public Builder id(String value) {
/*  884 */       this.id_id = Id.of(value);
/*  885 */       return this;
/*      */     }
/*      */     
/*      */     public Builder id(long value) {
/*  889 */       this.id_id = Id.of(value);
/*  890 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("id")
/*      */     public Builder id(Id value) {
/*  895 */       this.id_id = value;
/*  896 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("filename")
/*      */     public final Builder filename(String filename) {
/*  906 */       this.filename = Objects.<String>requireNonNull(filename, "filename");
/*  907 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/*  908 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("description")
/*      */     public Builder description(Possible<String> value) {
/*  913 */       this.description_possible = value;
/*  914 */       return this;
/*      */     }
/*      */     
/*      */     public Builder description(String value) {
/*  918 */       this.description_possible = Possible.of(value);
/*  919 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("content_type")
/*      */     public Builder contentType(Possible<String> value) {
/*  924 */       this.contentType_possible = value;
/*  925 */       return this;
/*      */     }
/*      */     
/*      */     public Builder contentType(String value) {
/*  929 */       this.contentType_possible = Possible.of(value);
/*  930 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("size")
/*      */     public final Builder size(int size) {
/*  940 */       this.size = size;
/*  941 */       this.initBits &= 0xFFFFFFFFFFFFFFFDL;
/*  942 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("url")
/*      */     public final Builder url(String url) {
/*  952 */       this.url = Objects.<String>requireNonNull(url, "url");
/*  953 */       this.initBits &= 0xFFFFFFFFFFFFFFFBL;
/*  954 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("proxy_url")
/*      */     public final Builder proxyUrl(String proxyUrl) {
/*  964 */       this.proxyUrl = Objects.<String>requireNonNull(proxyUrl, "proxyUrl");
/*  965 */       this.initBits &= 0xFFFFFFFFFFFFFFF7L;
/*  966 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("height")
/*      */     public Builder height(Possible<Optional<Integer>> value) {
/*  971 */       this.height_possible = value;
/*  972 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public Builder height(@Nullable Integer value) {
/*  977 */       this.height_possible = Possible.of(Optional.ofNullable(value));
/*  978 */       return this;
/*      */     }
/*      */     
/*      */     public Builder heightOrNull(@Nullable Integer value) {
/*  982 */       this.height_possible = Possible.of(Optional.ofNullable(value));
/*  983 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("width")
/*      */     public Builder width(Possible<Optional<Integer>> value) {
/*  988 */       this.width_possible = value;
/*  989 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public Builder width(@Nullable Integer value) {
/*  994 */       this.width_possible = Possible.of(Optional.ofNullable(value));
/*  995 */       return this;
/*      */     }
/*      */     
/*      */     public Builder widthOrNull(@Nullable Integer value) {
/*  999 */       this.width_possible = Possible.of(Optional.ofNullable(value));
/* 1000 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("ephemeral")
/*      */     public Builder ephemeral(Possible<Boolean> value) {
/* 1005 */       this.ephemeral_possible = value;
/* 1006 */       return this;
/*      */     }
/*      */     
/*      */     public Builder ephemeral(Boolean value) {
/* 1010 */       this.ephemeral_possible = Possible.of(value);
/* 1011 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ImmutableAttachmentData build() {
/* 1020 */       if (this.initBits != 0L) {
/* 1021 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*      */       }
/* 1023 */       return new ImmutableAttachmentData(null, 
/*      */           
/* 1025 */           id_build(), this.filename, 
/*      */           
/* 1027 */           description_build(), 
/* 1028 */           contentType_build(), this.size, this.url, this.proxyUrl, 
/*      */ 
/*      */ 
/*      */           
/* 1032 */           height_build(), 
/* 1033 */           width_build(), 
/* 1034 */           ephemeral_build());
/*      */     }
/*      */     
/*      */     private String formatRequiredAttributesMessage() {
/* 1038 */       List<String> attributes = new ArrayList<>();
/* 1039 */       if ((this.initBits & 0x1L) != 0L) attributes.add("filename"); 
/* 1040 */       if ((this.initBits & 0x2L) != 0L) attributes.add("size"); 
/* 1041 */       if ((this.initBits & 0x4L) != 0L) attributes.add("url"); 
/* 1042 */       if ((this.initBits & 0x8L) != 0L) attributes.add("proxyUrl"); 
/* 1043 */       return "Cannot build AttachmentData, some of required attributes are not set " + attributes;
/*      */     }
/*      */     
/*      */     private Id id_build() {
/* 1047 */       return this.id_id;
/*      */     }
/*      */     
/*      */     private Possible<String> description_build() {
/* 1051 */       return this.description_possible;
/*      */     }
/*      */     
/*      */     private Possible<String> contentType_build() {
/* 1055 */       return this.contentType_possible;
/*      */     }
/*      */     
/*      */     private Possible<Optional<Integer>> height_build() {
/* 1059 */       return this.height_possible;
/*      */     }
/*      */     
/*      */     private Possible<Optional<Integer>> width_build() {
/* 1063 */       return this.width_possible;
/*      */     }
/*      */     
/*      */     private Possible<Boolean> ephemeral_build() {
/* 1067 */       return this.ephemeral_possible;
/*      */     }
/*      */     
/*      */     private Builder() {}
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableAttachmentData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */