/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import org.immutables.value.Generated;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "UpdateCurrentUserVoiceStateRequest", generator = "Immutables")
/*     */ public final class ImmutableUpdateCurrentUserVoiceStateRequest
/*     */   implements UpdateCurrentUserVoiceStateRequest
/*     */ {
/*     */   private final String channelId;
/*     */   private final Boolean suppress_value;
/*     */   private final boolean suppress_absent;
/*     */   private final String requestToSpeakTimestamp_value;
/*     */   private final boolean requestToSpeakTimestamp_absent;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   private volatile transient InitShim initShim;
/*     */   
/*     */   private ImmutableUpdateCurrentUserVoiceStateRequest(String channelId, Possible<Boolean> suppress, Possible<Optional<String>> requestToSpeakTimestamp) {
/*  66 */     this.initShim = new InitShim(); this.channelId = Objects.<String>requireNonNull(channelId, "channelId"); Possible<Boolean> suppress$impl = suppress; Possible<Optional<String>> requestToSpeakTimestamp$impl = requestToSpeakTimestamp; this.suppress_value = suppress$impl.toOptional().orElse(null); this.suppress_absent = suppress$impl.isAbsent(); this.requestToSpeakTimestamp_value = Possible.flatOpt(requestToSpeakTimestamp$impl).orElse(null); this.requestToSpeakTimestamp_absent = requestToSpeakTimestamp$impl.isAbsent(); this.initShim = null; } private ImmutableUpdateCurrentUserVoiceStateRequest(ImmutableUpdateCurrentUserVoiceStateRequest original, String channelId, Possible<Boolean> suppress, Possible<Optional<String>> requestToSpeakTimestamp) { this.initShim = new InitShim(); this.channelId = channelId; Possible<Boolean> suppress$impl = suppress; Possible<Optional<String>> requestToSpeakTimestamp$impl = requestToSpeakTimestamp;
/*     */     this.suppress_value = suppress$impl.toOptional().orElse(null);
/*     */     this.suppress_absent = suppress$impl.isAbsent();
/*     */     this.requestToSpeakTimestamp_value = Possible.flatOpt(requestToSpeakTimestamp$impl).orElse(null);
/*     */     this.requestToSpeakTimestamp_absent = requestToSpeakTimestamp$impl.isAbsent();
/*  71 */     this.initShim = null; } @Generated(from = "UpdateCurrentUserVoiceStateRequest", generator = "Immutables") private final class InitShim { private InitShim() {} private String formatInitCycleMessage() { List<String> attributes = new ArrayList<>();
/*  72 */       return "Cannot build UpdateCurrentUserVoiceStateRequest, attribute initializers form cycle " + attributes; }
/*     */      }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("channel_id")
/*     */   public String channelId() {
/*  82 */     return this.channelId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("suppress")
/*     */   public Possible<Boolean> suppress() {
/*  91 */     return this.suppress_absent ? Possible.absent() : Possible.of(this.suppress_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("request_to_speak_timestamp")
/*     */   public Possible<Optional<String>> requestToSpeakTimestamp() {
/* 100 */     return this.requestToSpeakTimestamp_absent ? Possible.absent() : 
/* 101 */       Possible.of(Optional.ofNullable(this.requestToSpeakTimestamp_value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableUpdateCurrentUserVoiceStateRequest withChannelId(String value) {
/* 111 */     String newValue = Objects.<String>requireNonNull(value, "channelId");
/* 112 */     if (this.channelId.equals(newValue)) return this; 
/* 113 */     return new ImmutableUpdateCurrentUserVoiceStateRequest(this, newValue, suppress(), requestToSpeakTimestamp());
/*     */   }
/*     */   
/*     */   public ImmutableUpdateCurrentUserVoiceStateRequest withSuppress(Possible<Boolean> value) {
/* 117 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/* 118 */     return new ImmutableUpdateCurrentUserVoiceStateRequest(this, this.channelId, newValue, requestToSpeakTimestamp());
/*     */   }
/*     */   
/*     */   public ImmutableUpdateCurrentUserVoiceStateRequest withSuppress(Boolean value) {
/* 122 */     Possible<Boolean> newValue = Possible.of(value);
/* 123 */     return new ImmutableUpdateCurrentUserVoiceStateRequest(this, this.channelId, newValue, requestToSpeakTimestamp());
/*     */   }
/*     */   
/*     */   public ImmutableUpdateCurrentUserVoiceStateRequest withRequestToSpeakTimestamp(Possible<Optional<String>> value) {
/* 127 */     Possible<Optional<String>> newValue = Objects.<Possible<Optional<String>>>requireNonNull(value);
/* 128 */     return new ImmutableUpdateCurrentUserVoiceStateRequest(this, this.channelId, suppress(), newValue);
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public ImmutableUpdateCurrentUserVoiceStateRequest withRequestToSpeakTimestamp(@Nullable String value) {
/* 133 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/* 134 */     return new ImmutableUpdateCurrentUserVoiceStateRequest(this, this.channelId, suppress(), newValue);
/*     */   }
/*     */   
/*     */   public ImmutableUpdateCurrentUserVoiceStateRequest withRequestToSpeakTimestampOrNull(@Nullable String value) {
/* 138 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/* 139 */     return new ImmutableUpdateCurrentUserVoiceStateRequest(this, this.channelId, suppress(), newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 148 */     if (this == another) return true; 
/* 149 */     return (another instanceof ImmutableUpdateCurrentUserVoiceStateRequest && 
/* 150 */       equalTo(0, (ImmutableUpdateCurrentUserVoiceStateRequest)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableUpdateCurrentUserVoiceStateRequest another) {
/* 154 */     return (this.channelId.equals(another.channelId) && 
/* 155 */       suppress().equals(another.suppress()) && 
/* 156 */       requestToSpeakTimestamp().equals(another.requestToSpeakTimestamp()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 165 */     int h = 5381;
/* 166 */     h += (h << 5) + this.channelId.hashCode();
/* 167 */     h += (h << 5) + suppress().hashCode();
/* 168 */     h += (h << 5) + requestToSpeakTimestamp().hashCode();
/* 169 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 178 */     return "UpdateCurrentUserVoiceStateRequest{channelId=" + this.channelId + ", suppress=" + 
/*     */       
/* 180 */       suppress().toString() + ", requestToSpeakTimestamp=" + 
/* 181 */       requestToSpeakTimestamp().toString() + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "UpdateCurrentUserVoiceStateRequest", generator = "Immutables")
/*     */   static final class Json
/*     */     implements UpdateCurrentUserVoiceStateRequest
/*     */   {
/*     */     String channelId;
/*     */ 
/*     */     
/* 196 */     Possible<Boolean> suppress = Possible.absent();
/*     */ 
/*     */     
/* 199 */     Possible<Optional<String>> requestToSpeakTimestamp = Possible.absent();
/*     */     
/*     */     @JsonProperty("channel_id")
/*     */     public void setChannelId(String channelId) {
/* 203 */       this.channelId = channelId;
/*     */     }
/*     */     @JsonProperty("suppress")
/*     */     public void setSuppress(Possible<Boolean> suppress) {
/* 207 */       this.suppress = suppress;
/*     */     }
/*     */     @JsonProperty("request_to_speak_timestamp")
/*     */     public void setRequestToSpeakTimestamp(Possible<Optional<String>> requestToSpeakTimestamp) {
/* 211 */       this.requestToSpeakTimestamp = requestToSpeakTimestamp;
/*     */     }
/*     */     public String channelId() {
/* 214 */       throw new UnsupportedOperationException();
/*     */     } public Possible<Boolean> suppress() {
/* 216 */       throw new UnsupportedOperationException();
/*     */     } public Possible<Optional<String>> requestToSpeakTimestamp() {
/* 218 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableUpdateCurrentUserVoiceStateRequest fromJson(Json json) {
/* 229 */     Builder builder = builder();
/* 230 */     if (json.channelId != null) {
/* 231 */       builder.channelId(json.channelId);
/*     */     }
/* 233 */     if (json.suppress != null) {
/* 234 */       builder.suppress(json.suppress);
/*     */     }
/* 236 */     if (json.requestToSpeakTimestamp != null) {
/* 237 */       builder.requestToSpeakTimestamp(json.requestToSpeakTimestamp);
/*     */     }
/* 239 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableUpdateCurrentUserVoiceStateRequest of(String channelId, Possible<Boolean> suppress, Possible<Optional<String>> requestToSpeakTimestamp) {
/* 250 */     return new ImmutableUpdateCurrentUserVoiceStateRequest(channelId, suppress, requestToSpeakTimestamp);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableUpdateCurrentUserVoiceStateRequest copyOf(UpdateCurrentUserVoiceStateRequest instance) {
/* 261 */     if (instance instanceof ImmutableUpdateCurrentUserVoiceStateRequest) {
/* 262 */       return (ImmutableUpdateCurrentUserVoiceStateRequest)instance;
/*     */     }
/* 264 */     return builder()
/* 265 */       .from(instance)
/* 266 */       .build();
/*     */   }
/*     */   
/*     */   public boolean isSuppressPresent() {
/* 270 */     return !this.suppress_absent;
/*     */   }
/*     */   
/*     */   public Boolean suppressOrElse(Boolean defaultValue) {
/* 274 */     return !this.suppress_absent ? this.suppress_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isRequestToSpeakTimestampPresent() {
/* 278 */     return !this.requestToSpeakTimestamp_absent;
/*     */   }
/*     */   
/*     */   public String requestToSpeakTimestampOrElse(String defaultValue) {
/* 282 */     return !this.requestToSpeakTimestamp_absent ? this.requestToSpeakTimestamp_value : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 297 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "UpdateCurrentUserVoiceStateRequest", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_CHANNEL_ID = 1L;
/*     */ 
/*     */ 
/*     */     
/* 310 */     private long initBits = 1L;
/*     */     
/* 312 */     private Possible<Boolean> suppress_possible = Possible.absent();
/* 313 */     private Possible<Optional<String>> requestToSpeakTimestamp_possible = Possible.absent();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private String channelId;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(UpdateCurrentUserVoiceStateRequest instance) {
/* 327 */       Objects.requireNonNull(instance, "instance");
/* 328 */       channelId(instance.channelId());
/* 329 */       suppress(instance.suppress());
/* 330 */       requestToSpeakTimestamp(instance.requestToSpeakTimestamp());
/* 331 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("channel_id")
/*     */     public final Builder channelId(String channelId) {
/* 341 */       this.channelId = Objects.<String>requireNonNull(channelId, "channelId");
/* 342 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 343 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("suppress")
/*     */     public Builder suppress(Possible<Boolean> value) {
/* 348 */       this.suppress_possible = value;
/* 349 */       return this;
/*     */     }
/*     */     
/*     */     public Builder suppress(Boolean value) {
/* 353 */       this.suppress_possible = Possible.of(value);
/* 354 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("request_to_speak_timestamp")
/*     */     public Builder requestToSpeakTimestamp(Possible<Optional<String>> value) {
/* 359 */       this.requestToSpeakTimestamp_possible = value;
/* 360 */       return this;
/*     */     }
/*     */     
/*     */     @Deprecated
/*     */     public Builder requestToSpeakTimestamp(@Nullable String value) {
/* 365 */       this.requestToSpeakTimestamp_possible = Possible.of(Optional.ofNullable(value));
/* 366 */       return this;
/*     */     }
/*     */     
/*     */     public Builder requestToSpeakTimestampOrNull(@Nullable String value) {
/* 370 */       this.requestToSpeakTimestamp_possible = Possible.of(Optional.ofNullable(value));
/* 371 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableUpdateCurrentUserVoiceStateRequest build() {
/* 380 */       if (this.initBits != 0L) {
/* 381 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 383 */       return new ImmutableUpdateCurrentUserVoiceStateRequest(null, this.channelId, suppress_build(), requestToSpeakTimestamp_build());
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 387 */       List<String> attributes = new ArrayList<>();
/* 388 */       if ((this.initBits & 0x1L) != 0L) attributes.add("channelId"); 
/* 389 */       return "Cannot build UpdateCurrentUserVoiceStateRequest, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Possible<Boolean> suppress_build() {
/* 393 */       return this.suppress_possible;
/*     */     }
/*     */     
/*     */     private Possible<Optional<String>> requestToSpeakTimestamp_build() {
/* 397 */       return this.requestToSpeakTimestamp_possible;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableUpdateCurrentUserVoiceStateRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */