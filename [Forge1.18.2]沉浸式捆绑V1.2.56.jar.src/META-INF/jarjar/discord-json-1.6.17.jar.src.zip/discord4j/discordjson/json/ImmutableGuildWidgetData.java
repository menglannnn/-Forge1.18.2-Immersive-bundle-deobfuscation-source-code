/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.Id;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "GuildWidgetData", generator = "Immutables")
/*     */ public final class ImmutableGuildWidgetData
/*     */   implements GuildWidgetData
/*     */ {
/*     */   private final boolean enabled;
/*     */   private final long channelId_value;
/*     */   private final boolean channelId_present;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   private volatile transient InitShim initShim;
/*     */   
/*     */   private ImmutableGuildWidgetData(boolean enabled, Optional<Id> channelId) {
/*  56 */     this.initShim = new InitShim(); this.enabled = enabled; Optional<Id> channelId$impl = channelId; this.channelId_value = ((Long)channelId$impl.<Long>map(Id::asLong).orElse(Long.valueOf(0L))).longValue(); this.channelId_present = channelId$impl.isPresent(); this.initShim = null; } private ImmutableGuildWidgetData(ImmutableGuildWidgetData original, boolean enabled, Optional<Id> channelId) { this.initShim = new InitShim();
/*     */     this.enabled = enabled;
/*     */     Optional<Id> channelId$impl = channelId;
/*     */     this.channelId_value = ((Long)channelId$impl.<Long>map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*     */     this.channelId_present = channelId$impl.isPresent();
/*  61 */     this.initShim = null; } @Generated(from = "GuildWidgetData", generator = "Immutables") private final class InitShim { private InitShim() {} private String formatInitCycleMessage() { List<String> attributes = new ArrayList<>();
/*  62 */       return "Cannot build GuildWidgetData, attribute initializers form cycle " + attributes; }
/*     */      }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("enabled")
/*     */   public boolean enabled() {
/*  72 */     return this.enabled;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("channel_id")
/*     */   public Optional<Id> channelId() {
/*  81 */     return this.channelId_present ? Optional.<Id>of(Id.of(this.channelId_value)) : Optional.<Id>empty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableGuildWidgetData withEnabled(boolean value) {
/*  91 */     if (this.enabled == value) return this; 
/*  92 */     return new ImmutableGuildWidgetData(this, value, channelId());
/*     */   }
/*     */   
/*     */   public ImmutableGuildWidgetData withChannelId(Optional<Id> value) {
/*  96 */     Optional<Id> newValue = Objects.<Optional<Id>>requireNonNull(value);
/*  97 */     return new ImmutableGuildWidgetData(this, this.enabled, newValue);
/*     */   }
/*     */   
/*     */   public ImmutableGuildWidgetData withChannelId(long value) {
/* 101 */     Optional<Id> newValue = Optional.of(Id.of(value));
/* 102 */     return new ImmutableGuildWidgetData(this, this.enabled, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 111 */     if (this == another) return true; 
/* 112 */     return (another instanceof ImmutableGuildWidgetData && 
/* 113 */       equalTo(0, (ImmutableGuildWidgetData)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableGuildWidgetData another) {
/* 117 */     return (this.enabled == another.enabled && 
/* 118 */       channelId().equals(another.channelId()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 127 */     int h = 5381;
/* 128 */     h += (h << 5) + Boolean.hashCode(this.enabled);
/* 129 */     h += (h << 5) + channelId().hashCode();
/* 130 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 139 */     return "GuildWidgetData{enabled=" + this.enabled + ", channelId=" + 
/*     */       
/* 141 */       channelId().toString() + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "GuildWidgetData", generator = "Immutables")
/*     */   static final class Json
/*     */     implements GuildWidgetData
/*     */   {
/*     */     boolean enabled;
/*     */     
/*     */     boolean enabledIsSet;
/*     */     
/* 157 */     Optional<Id> channelId = Optional.empty();
/*     */     
/*     */     @JsonProperty("enabled")
/*     */     public void setEnabled(boolean enabled) {
/* 161 */       this.enabled = enabled;
/* 162 */       this.enabledIsSet = true;
/*     */     }
/*     */     @JsonProperty("channel_id")
/*     */     public void setChannelId(Optional<Id> channelId) {
/* 166 */       this.channelId = channelId;
/*     */     }
/*     */     public boolean enabled() {
/* 169 */       throw new UnsupportedOperationException();
/*     */     } public Optional<Id> channelId() {
/* 171 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableGuildWidgetData fromJson(Json json) {
/* 182 */     Builder builder = builder();
/* 183 */     if (json.enabledIsSet) {
/* 184 */       builder.enabled(json.enabled);
/*     */     }
/* 186 */     if (json.channelId != null) {
/* 187 */       builder.channelId(json.channelId);
/*     */     }
/* 189 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableGuildWidgetData of(boolean enabled, Optional<Id> channelId) {
/* 199 */     return new ImmutableGuildWidgetData(enabled, channelId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableGuildWidgetData copyOf(GuildWidgetData instance) {
/* 210 */     if (instance instanceof ImmutableGuildWidgetData) {
/* 211 */       return (ImmutableGuildWidgetData)instance;
/*     */     }
/* 213 */     return builder()
/* 214 */       .from(instance)
/* 215 */       .build();
/*     */   }
/*     */   
/*     */   public boolean isChannelIdPresent() {
/* 219 */     return this.channelId_present;
/*     */   }
/*     */   
/*     */   public long channelIdOrElse(long defaultValue) {
/* 223 */     return this.channelId_present ? this.channelId_value : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 237 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "GuildWidgetData", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_ENABLED = 1L;
/*     */ 
/*     */ 
/*     */     
/* 250 */     private long initBits = 1L;
/*     */     
/* 252 */     private Optional<Id> channelId_optional = Optional.empty();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private boolean enabled;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(GuildWidgetData instance) {
/* 266 */       Objects.requireNonNull(instance, "instance");
/* 267 */       enabled(instance.enabled());
/* 268 */       channelId(instance.channelId());
/* 269 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("enabled")
/*     */     public final Builder enabled(boolean enabled) {
/* 279 */       this.enabled = enabled;
/* 280 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 281 */       return this;
/*     */     }
/*     */     
/*     */     public Builder channelId(String value) {
/* 285 */       this.channelId_optional = Optional.of(Id.of(value));
/* 286 */       return this;
/*     */     }
/*     */     
/*     */     public Builder channelId(long value) {
/* 290 */       this.channelId_optional = Optional.of(Id.of(value));
/* 291 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("channel_id")
/*     */     public Builder channelId(Optional<Id> value) {
/* 296 */       this.channelId_optional = value;
/* 297 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableGuildWidgetData build() {
/* 306 */       if (this.initBits != 0L) {
/* 307 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 309 */       return new ImmutableGuildWidgetData(null, this.enabled, channelId_build());
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 313 */       List<String> attributes = new ArrayList<>();
/* 314 */       if ((this.initBits & 0x1L) != 0L) attributes.add("enabled"); 
/* 315 */       return "Cannot build GuildWidgetData, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Optional<Id> channelId_build() {
/* 319 */       return this.channelId_optional;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableGuildWidgetData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */