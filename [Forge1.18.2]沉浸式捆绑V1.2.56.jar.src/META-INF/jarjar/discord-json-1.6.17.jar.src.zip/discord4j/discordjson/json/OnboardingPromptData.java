/*    */ package discord4j.discordjson.json;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonProperty;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import discord4j.discordjson.Id;
/*    */ import java.util.List;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ @JsonSerialize(as = ImmutableOnboardingPromptData.class)
/*    */ @JsonDeserialize(as = ImmutableOnboardingPromptData.class)
/*    */ @Immutable
/*    */ public interface OnboardingPromptData
/*    */ {
/*    */   static ImmutableOnboardingPromptData.Builder builder() {
/* 16 */     return ImmutableOnboardingPromptData.builder();
/*    */   }
/*    */   
/*    */   Id id();
/*    */   
/*    */   int type();
/*    */   
/*    */   List<OnboardingPromptOptionData> options();
/*    */   
/*    */   String title();
/*    */   
/*    */   @JsonProperty("single_select")
/*    */   boolean singleSelect();
/*    */   
/*    */   boolean required();
/*    */   
/*    */   @JsonProperty("in_onboarding")
/*    */   boolean inOnboarding();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\OnboardingPromptData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */