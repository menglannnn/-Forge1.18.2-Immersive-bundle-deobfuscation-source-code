/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "GuildApplicationCommandPermissionsData", generator = "Immutables")
/*     */ public final class ImmutableGuildApplicationCommandPermissionsData
/*     */   implements GuildApplicationCommandPermissionsData
/*     */ {
/*     */   private final String id;
/*     */   private final String applicationId;
/*     */   private final String guildId;
/*     */   private final List<ApplicationCommandPermissionsData> permissions;
/*     */   
/*     */   private ImmutableGuildApplicationCommandPermissionsData(String id, String applicationId, String guildId, Iterable<? extends ApplicationCommandPermissionsData> permissions) {
/*  38 */     this.id = Objects.<String>requireNonNull(id, "id");
/*  39 */     this.applicationId = Objects.<String>requireNonNull(applicationId, "applicationId");
/*  40 */     this.guildId = Objects.<String>requireNonNull(guildId, "guildId");
/*  41 */     this.permissions = createUnmodifiableList(false, createSafeList(permissions, true, false));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ImmutableGuildApplicationCommandPermissionsData(ImmutableGuildApplicationCommandPermissionsData original, String id, String applicationId, String guildId, List<ApplicationCommandPermissionsData> permissions) {
/*  50 */     this.id = id;
/*  51 */     this.applicationId = applicationId;
/*  52 */     this.guildId = guildId;
/*  53 */     this.permissions = permissions;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("id")
/*     */   public String id() {
/*  62 */     return this.id;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("application_id")
/*     */   public String applicationId() {
/*  71 */     return this.applicationId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("guild_id")
/*     */   public String guildId() {
/*  80 */     return this.guildId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("permissions")
/*     */   public List<ApplicationCommandPermissionsData> permissions() {
/*  89 */     return this.permissions;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableGuildApplicationCommandPermissionsData withId(String value) {
/*  99 */     String newValue = Objects.<String>requireNonNull(value, "id");
/* 100 */     if (this.id.equals(newValue)) return this; 
/* 101 */     return new ImmutableGuildApplicationCommandPermissionsData(this, newValue, this.applicationId, this.guildId, this.permissions);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableGuildApplicationCommandPermissionsData withApplicationId(String value) {
/* 111 */     String newValue = Objects.<String>requireNonNull(value, "applicationId");
/* 112 */     if (this.applicationId.equals(newValue)) return this; 
/* 113 */     return new ImmutableGuildApplicationCommandPermissionsData(this, this.id, newValue, this.guildId, this.permissions);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableGuildApplicationCommandPermissionsData withGuildId(String value) {
/* 123 */     String newValue = Objects.<String>requireNonNull(value, "guildId");
/* 124 */     if (this.guildId.equals(newValue)) return this; 
/* 125 */     return new ImmutableGuildApplicationCommandPermissionsData(this, this.id, this.applicationId, newValue, this.permissions);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableGuildApplicationCommandPermissionsData withPermissions(ApplicationCommandPermissionsData... elements) {
/* 134 */     List<ApplicationCommandPermissionsData> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/* 135 */     return new ImmutableGuildApplicationCommandPermissionsData(this, this.id, this.applicationId, this.guildId, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableGuildApplicationCommandPermissionsData withPermissions(Iterable<? extends ApplicationCommandPermissionsData> elements) {
/* 145 */     if (this.permissions == elements) return this; 
/* 146 */     List<ApplicationCommandPermissionsData> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/* 147 */     return new ImmutableGuildApplicationCommandPermissionsData(this, this.id, this.applicationId, this.guildId, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 156 */     if (this == another) return true; 
/* 157 */     return (another instanceof ImmutableGuildApplicationCommandPermissionsData && 
/* 158 */       equalTo(0, (ImmutableGuildApplicationCommandPermissionsData)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableGuildApplicationCommandPermissionsData another) {
/* 162 */     return (this.id.equals(another.id) && this.applicationId
/* 163 */       .equals(another.applicationId) && this.guildId
/* 164 */       .equals(another.guildId) && this.permissions
/* 165 */       .equals(another.permissions));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 174 */     int h = 5381;
/* 175 */     h += (h << 5) + this.id.hashCode();
/* 176 */     h += (h << 5) + this.applicationId.hashCode();
/* 177 */     h += (h << 5) + this.guildId.hashCode();
/* 178 */     h += (h << 5) + this.permissions.hashCode();
/* 179 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 188 */     return "GuildApplicationCommandPermissionsData{id=" + this.id + ", applicationId=" + this.applicationId + ", guildId=" + this.guildId + ", permissions=" + this.permissions + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "GuildApplicationCommandPermissionsData", generator = "Immutables")
/*     */   static final class Json
/*     */     implements GuildApplicationCommandPermissionsData
/*     */   {
/*     */     String id;
/*     */ 
/*     */     
/*     */     String applicationId;
/*     */ 
/*     */     
/*     */     String guildId;
/*     */     
/* 208 */     List<ApplicationCommandPermissionsData> permissions = Collections.emptyList();
/*     */     @JsonProperty("id")
/*     */     public void setId(String id) {
/* 211 */       this.id = id;
/*     */     }
/*     */     @JsonProperty("application_id")
/*     */     public void setApplicationId(String applicationId) {
/* 215 */       this.applicationId = applicationId;
/*     */     }
/*     */     @JsonProperty("guild_id")
/*     */     public void setGuildId(String guildId) {
/* 219 */       this.guildId = guildId;
/*     */     }
/*     */     @JsonProperty("permissions")
/*     */     public void setPermissions(List<ApplicationCommandPermissionsData> permissions) {
/* 223 */       this.permissions = permissions;
/*     */     }
/*     */     public String id() {
/* 226 */       throw new UnsupportedOperationException();
/*     */     } public String applicationId() {
/* 228 */       throw new UnsupportedOperationException();
/*     */     } public String guildId() {
/* 230 */       throw new UnsupportedOperationException();
/*     */     } public List<ApplicationCommandPermissionsData> permissions() {
/* 232 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableGuildApplicationCommandPermissionsData fromJson(Json json) {
/* 243 */     Builder builder = builder();
/* 244 */     if (json.id != null) {
/* 245 */       builder.id(json.id);
/*     */     }
/* 247 */     if (json.applicationId != null) {
/* 248 */       builder.applicationId(json.applicationId);
/*     */     }
/* 250 */     if (json.guildId != null) {
/* 251 */       builder.guildId(json.guildId);
/*     */     }
/* 253 */     if (json.permissions != null) {
/* 254 */       builder.addAllPermissions(json.permissions);
/*     */     }
/* 256 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableGuildApplicationCommandPermissionsData of(String id, String applicationId, String guildId, List<ApplicationCommandPermissionsData> permissions) {
/* 268 */     return of(id, applicationId, guildId, permissions);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableGuildApplicationCommandPermissionsData of(String id, String applicationId, String guildId, Iterable<? extends ApplicationCommandPermissionsData> permissions) {
/* 280 */     return new ImmutableGuildApplicationCommandPermissionsData(id, applicationId, guildId, permissions);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableGuildApplicationCommandPermissionsData copyOf(GuildApplicationCommandPermissionsData instance) {
/* 291 */     if (instance instanceof ImmutableGuildApplicationCommandPermissionsData) {
/* 292 */       return (ImmutableGuildApplicationCommandPermissionsData)instance;
/*     */     }
/* 294 */     return builder()
/* 295 */       .from(instance)
/* 296 */       .build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 312 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "GuildApplicationCommandPermissionsData", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_ID = 1L;
/*     */ 
/*     */     
/*     */     private static final long INIT_BIT_APPLICATION_ID = 2L;
/*     */     
/*     */     private static final long INIT_BIT_GUILD_ID = 4L;
/*     */     
/* 327 */     private long initBits = 7L;
/*     */     
/*     */     private String id;
/*     */     private String applicationId;
/*     */     private String guildId;
/* 332 */     private List<ApplicationCommandPermissionsData> permissions = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(GuildApplicationCommandPermissionsData instance) {
/* 346 */       Objects.requireNonNull(instance, "instance");
/* 347 */       id(instance.id());
/* 348 */       applicationId(instance.applicationId());
/* 349 */       guildId(instance.guildId());
/* 350 */       addAllPermissions(instance.permissions());
/* 351 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("id")
/*     */     public final Builder id(String id) {
/* 361 */       this.id = Objects.<String>requireNonNull(id, "id");
/* 362 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 363 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("application_id")
/*     */     public final Builder applicationId(String applicationId) {
/* 373 */       this.applicationId = Objects.<String>requireNonNull(applicationId, "applicationId");
/* 374 */       this.initBits &= 0xFFFFFFFFFFFFFFFDL;
/* 375 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("guild_id")
/*     */     public final Builder guildId(String guildId) {
/* 385 */       this.guildId = Objects.<String>requireNonNull(guildId, "guildId");
/* 386 */       this.initBits &= 0xFFFFFFFFFFFFFFFBL;
/* 387 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder addPermission(ApplicationCommandPermissionsData element) {
/* 396 */       this.permissions.add(Objects.<ApplicationCommandPermissionsData>requireNonNull(element, "permissions element"));
/* 397 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder addPermissions(ApplicationCommandPermissionsData... elements) {
/* 406 */       for (ApplicationCommandPermissionsData element : elements) {
/* 407 */         this.permissions.add(Objects.<ApplicationCommandPermissionsData>requireNonNull(element, "permissions element"));
/*     */       }
/* 409 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("permissions")
/*     */     public final Builder permissions(Iterable<? extends ApplicationCommandPermissionsData> elements) {
/* 420 */       this.permissions.clear();
/* 421 */       return addAllPermissions(elements);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder addAllPermissions(Iterable<? extends ApplicationCommandPermissionsData> elements) {
/* 430 */       for (ApplicationCommandPermissionsData element : elements) {
/* 431 */         this.permissions.add(Objects.<ApplicationCommandPermissionsData>requireNonNull(element, "permissions element"));
/*     */       }
/* 433 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableGuildApplicationCommandPermissionsData build() {
/* 442 */       if (this.initBits != 0L) {
/* 443 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 445 */       return new ImmutableGuildApplicationCommandPermissionsData(null, this.id, this.applicationId, this.guildId, ImmutableGuildApplicationCommandPermissionsData.createUnmodifiableList(true, (List)this.permissions));
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 449 */       List<String> attributes = new ArrayList<>();
/* 450 */       if ((this.initBits & 0x1L) != 0L) attributes.add("id"); 
/* 451 */       if ((this.initBits & 0x2L) != 0L) attributes.add("applicationId"); 
/* 452 */       if ((this.initBits & 0x4L) != 0L) attributes.add("guildId"); 
/* 453 */       return "Cannot build GuildApplicationCommandPermissionsData, some of required attributes are not set " + attributes;
/*     */     }
/*     */     private Builder() {} }
/*     */   
/*     */   private static <T> List<T> createSafeList(Iterable<? extends T> iterable, boolean checkNulls, boolean skipNulls) {
/*     */     ArrayList<T> list;
/* 459 */     if (iterable instanceof Collection) {
/* 460 */       int size = ((Collection)iterable).size();
/* 461 */       if (size == 0) return Collections.emptyList(); 
/* 462 */       list = new ArrayList<>();
/*     */     } else {
/* 464 */       list = new ArrayList<>();
/*     */     } 
/* 466 */     for (T element : iterable) {
/* 467 */       if (skipNulls && element == null)
/* 468 */         continue;  if (checkNulls) Objects.requireNonNull(element, "element"); 
/* 469 */       list.add(element);
/*     */     } 
/* 471 */     return list;
/*     */   }
/*     */   
/*     */   private static <T> List<T> createUnmodifiableList(boolean clone, List<T> list) {
/* 475 */     switch (list.size()) { case 0:
/* 476 */         return Collections.emptyList();
/* 477 */       case 1: return Collections.singletonList(list.get(0)); }
/*     */     
/* 479 */     if (clone) {
/* 480 */       return Collections.unmodifiableList(new ArrayList<>(list));
/*     */     }
/* 482 */     if (list instanceof ArrayList) {
/* 483 */       ((ArrayList)list).trimToSize();
/*     */     }
/* 485 */     return Collections.unmodifiableList(list);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableGuildApplicationCommandPermissionsData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */