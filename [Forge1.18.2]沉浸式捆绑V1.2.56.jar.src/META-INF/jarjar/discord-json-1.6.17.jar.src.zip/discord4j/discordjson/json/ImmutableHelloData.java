/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "HelloData", generator = "Immutables")
/*     */ public final class ImmutableHelloData
/*     */   implements HelloData
/*     */ {
/*     */   private final int heartbeatInterval;
/*     */   
/*     */   private ImmutableHelloData(int heartbeatInterval) {
/*  27 */     this.heartbeatInterval = heartbeatInterval;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("heartbeat_interval")
/*     */   public int heartbeatInterval() {
/*  36 */     return this.heartbeatInterval;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableHelloData withHeartbeatInterval(int value) {
/*  46 */     if (this.heartbeatInterval == value) return this; 
/*  47 */     return new ImmutableHelloData(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/*  56 */     if (this == another) return true; 
/*  57 */     return (another instanceof ImmutableHelloData && 
/*  58 */       equalTo(0, (ImmutableHelloData)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableHelloData another) {
/*  62 */     return (this.heartbeatInterval == another.heartbeatInterval);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  71 */     int h = 5381;
/*  72 */     h += (h << 5) + this.heartbeatInterval;
/*  73 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/*  82 */     return "HelloData{heartbeatInterval=" + this.heartbeatInterval + "}";
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "HelloData", generator = "Immutables")
/*     */   static final class Json
/*     */     implements HelloData
/*     */   {
/*     */     int heartbeatInterval;
/*     */     
/*     */     boolean heartbeatIntervalIsSet;
/*     */ 
/*     */     
/*     */     @JsonProperty("heartbeat_interval")
/*     */     public void setHeartbeatInterval(int heartbeatInterval) {
/* 100 */       this.heartbeatInterval = heartbeatInterval;
/* 101 */       this.heartbeatIntervalIsSet = true;
/*     */     }
/*     */     public int heartbeatInterval() {
/* 104 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableHelloData fromJson(Json json) {
/* 115 */     Builder builder = builder();
/* 116 */     if (json.heartbeatIntervalIsSet) {
/* 117 */       builder.heartbeatInterval(json.heartbeatInterval);
/*     */     }
/* 119 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableHelloData of(int heartbeatInterval) {
/* 128 */     return new ImmutableHelloData(heartbeatInterval);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableHelloData copyOf(HelloData instance) {
/* 139 */     if (instance instanceof ImmutableHelloData) {
/* 140 */       return (ImmutableHelloData)instance;
/*     */     }
/* 142 */     return builder()
/* 143 */       .from(instance)
/* 144 */       .build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 157 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "HelloData", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_HEARTBEAT_INTERVAL = 1L;
/*     */ 
/*     */ 
/*     */     
/* 170 */     private long initBits = 1L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private int heartbeatInterval;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(HelloData instance) {
/* 185 */       Objects.requireNonNull(instance, "instance");
/* 186 */       heartbeatInterval(instance.heartbeatInterval());
/* 187 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("heartbeat_interval")
/*     */     public final Builder heartbeatInterval(int heartbeatInterval) {
/* 197 */       this.heartbeatInterval = heartbeatInterval;
/* 198 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 199 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableHelloData build() {
/* 208 */       if (this.initBits != 0L) {
/* 209 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 211 */       return new ImmutableHelloData(this.heartbeatInterval);
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 215 */       List<String> attributes = new ArrayList<>();
/* 216 */       if ((this.initBits & 0x1L) != 0L) attributes.add("heartbeatInterval"); 
/* 217 */       return "Cannot build HelloData, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableHelloData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */