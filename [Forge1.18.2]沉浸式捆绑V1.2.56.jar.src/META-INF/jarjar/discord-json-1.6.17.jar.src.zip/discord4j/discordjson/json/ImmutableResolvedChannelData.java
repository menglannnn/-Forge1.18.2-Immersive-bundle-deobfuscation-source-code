/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "ResolvedChannelData", generator = "Immutables")
/*     */ public final class ImmutableResolvedChannelData
/*     */   implements ResolvedChannelData
/*     */ {
/*     */   private final String id;
/*     */   private final String name;
/*     */   private final int type;
/*     */   private final String permissions;
/*     */   
/*     */   private ImmutableResolvedChannelData(String id, String name, int type, String permissions) {
/*  30 */     this.id = Objects.<String>requireNonNull(id, "id");
/*  31 */     this.name = Objects.<String>requireNonNull(name, "name");
/*  32 */     this.type = type;
/*  33 */     this.permissions = Objects.<String>requireNonNull(permissions, "permissions");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ImmutableResolvedChannelData(ImmutableResolvedChannelData original, String id, String name, int type, String permissions) {
/*  42 */     this.id = id;
/*  43 */     this.name = name;
/*  44 */     this.type = type;
/*  45 */     this.permissions = permissions;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("id")
/*     */   public String id() {
/*  54 */     return this.id;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("name")
/*     */   public String name() {
/*  63 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("type")
/*     */   public int type() {
/*  72 */     return this.type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("permissions")
/*     */   public String permissions() {
/*  81 */     return this.permissions;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableResolvedChannelData withId(String value) {
/*  91 */     String newValue = Objects.<String>requireNonNull(value, "id");
/*  92 */     if (this.id.equals(newValue)) return this; 
/*  93 */     return new ImmutableResolvedChannelData(this, newValue, this.name, this.type, this.permissions);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableResolvedChannelData withName(String value) {
/* 103 */     String newValue = Objects.<String>requireNonNull(value, "name");
/* 104 */     if (this.name.equals(newValue)) return this; 
/* 105 */     return new ImmutableResolvedChannelData(this, this.id, newValue, this.type, this.permissions);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableResolvedChannelData withType(int value) {
/* 115 */     if (this.type == value) return this; 
/* 116 */     return new ImmutableResolvedChannelData(this, this.id, this.name, value, this.permissions);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableResolvedChannelData withPermissions(String value) {
/* 126 */     String newValue = Objects.<String>requireNonNull(value, "permissions");
/* 127 */     if (this.permissions.equals(newValue)) return this; 
/* 128 */     return new ImmutableResolvedChannelData(this, this.id, this.name, this.type, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 137 */     if (this == another) return true; 
/* 138 */     return (another instanceof ImmutableResolvedChannelData && 
/* 139 */       equalTo(0, (ImmutableResolvedChannelData)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableResolvedChannelData another) {
/* 143 */     return (this.id.equals(another.id) && this.name
/* 144 */       .equals(another.name) && this.type == another.type && this.permissions
/*     */       
/* 146 */       .equals(another.permissions));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 155 */     int h = 5381;
/* 156 */     h += (h << 5) + this.id.hashCode();
/* 157 */     h += (h << 5) + this.name.hashCode();
/* 158 */     h += (h << 5) + this.type;
/* 159 */     h += (h << 5) + this.permissions.hashCode();
/* 160 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 169 */     return "ResolvedChannelData{id=" + this.id + ", name=" + this.name + ", type=" + this.type + ", permissions=" + this.permissions + "}";
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "ResolvedChannelData", generator = "Immutables")
/*     */   static final class Json
/*     */     implements ResolvedChannelData
/*     */   {
/*     */     String id;
/*     */     
/*     */     String name;
/*     */     
/*     */     int type;
/*     */     
/*     */     boolean typeIsSet;
/*     */     
/*     */     String permissions;
/*     */ 
/*     */     
/*     */     @JsonProperty("id")
/*     */     public void setId(String id) {
/* 193 */       this.id = id;
/*     */     }
/*     */     @JsonProperty("name")
/*     */     public void setName(String name) {
/* 197 */       this.name = name;
/*     */     }
/*     */     @JsonProperty("type")
/*     */     public void setType(int type) {
/* 201 */       this.type = type;
/* 202 */       this.typeIsSet = true;
/*     */     }
/*     */     @JsonProperty("permissions")
/*     */     public void setPermissions(String permissions) {
/* 206 */       this.permissions = permissions;
/*     */     }
/*     */     public String id() {
/* 209 */       throw new UnsupportedOperationException();
/*     */     } public String name() {
/* 211 */       throw new UnsupportedOperationException();
/*     */     } public int type() {
/* 213 */       throw new UnsupportedOperationException();
/*     */     } public String permissions() {
/* 215 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableResolvedChannelData fromJson(Json json) {
/* 226 */     Builder builder = builder();
/* 227 */     if (json.id != null) {
/* 228 */       builder.id(json.id);
/*     */     }
/* 230 */     if (json.name != null) {
/* 231 */       builder.name(json.name);
/*     */     }
/* 233 */     if (json.typeIsSet) {
/* 234 */       builder.type(json.type);
/*     */     }
/* 236 */     if (json.permissions != null) {
/* 237 */       builder.permissions(json.permissions);
/*     */     }
/* 239 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableResolvedChannelData of(String id, String name, int type, String permissions) {
/* 251 */     return new ImmutableResolvedChannelData(id, name, type, permissions);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableResolvedChannelData copyOf(ResolvedChannelData instance) {
/* 262 */     if (instance instanceof ImmutableResolvedChannelData) {
/* 263 */       return (ImmutableResolvedChannelData)instance;
/*     */     }
/* 265 */     return builder()
/* 266 */       .from(instance)
/* 267 */       .build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 283 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "ResolvedChannelData", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_ID = 1L;
/*     */     
/*     */     private static final long INIT_BIT_NAME = 2L;
/*     */     
/*     */     private static final long INIT_BIT_TYPE = 4L;
/*     */     
/*     */     private static final long INIT_BIT_PERMISSIONS = 8L;
/*     */     
/* 299 */     private long initBits = 15L;
/*     */ 
/*     */ 
/*     */     
/*     */     private String id;
/*     */ 
/*     */     
/*     */     private String name;
/*     */ 
/*     */     
/*     */     private int type;
/*     */ 
/*     */     
/*     */     private String permissions;
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(ResolvedChannelData instance) {
/* 317 */       Objects.requireNonNull(instance, "instance");
/* 318 */       id(instance.id());
/* 319 */       name(instance.name());
/* 320 */       type(instance.type());
/* 321 */       permissions(instance.permissions());
/* 322 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("id")
/*     */     public final Builder id(String id) {
/* 332 */       this.id = Objects.<String>requireNonNull(id, "id");
/* 333 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 334 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("name")
/*     */     public final Builder name(String name) {
/* 344 */       this.name = Objects.<String>requireNonNull(name, "name");
/* 345 */       this.initBits &= 0xFFFFFFFFFFFFFFFDL;
/* 346 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("type")
/*     */     public final Builder type(int type) {
/* 356 */       this.type = type;
/* 357 */       this.initBits &= 0xFFFFFFFFFFFFFFFBL;
/* 358 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("permissions")
/*     */     public final Builder permissions(String permissions) {
/* 368 */       this.permissions = Objects.<String>requireNonNull(permissions, "permissions");
/* 369 */       this.initBits &= 0xFFFFFFFFFFFFFFF7L;
/* 370 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableResolvedChannelData build() {
/* 379 */       if (this.initBits != 0L) {
/* 380 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 382 */       return new ImmutableResolvedChannelData(null, this.id, this.name, this.type, this.permissions);
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 386 */       List<String> attributes = new ArrayList<>();
/* 387 */       if ((this.initBits & 0x1L) != 0L) attributes.add("id"); 
/* 388 */       if ((this.initBits & 0x2L) != 0L) attributes.add("name"); 
/* 389 */       if ((this.initBits & 0x4L) != 0L) attributes.add("type"); 
/* 390 */       if ((this.initBits & 0x8L) != 0L) attributes.add("permissions"); 
/* 391 */       return "Cannot build ResolvedChannelData, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableResolvedChannelData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */