/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.stream.StreamSupport;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "ConnectionData", generator = "Immutables")
/*     */ public final class ImmutableConnectionData
/*     */   implements ConnectionData
/*     */ {
/*     */   private final String id;
/*     */   private final String name;
/*     */   private final String type;
/*     */   private final Boolean revoked_value;
/*     */   private final boolean revoked_absent;
/*     */   private final List<IntegrationData> integrations_value;
/*     */   private final boolean integrations_absent;
/*     */   private final boolean verified;
/*     */   private final boolean friendSync;
/*     */   private final boolean showActivity;
/*     */   private final int visibility;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   private volatile transient InitShim initShim;
/*     */   
/*     */   private ImmutableConnectionData(String id, String name, String type, Possible<Boolean> revoked, Possible<List<IntegrationData>> integrations, boolean verified, boolean friendSync, boolean showActivity, int visibility) {
/*  96 */     this.initShim = new InitShim(); this.id = Objects.<String>requireNonNull(id, "id"); this.name = Objects.<String>requireNonNull(name, "name"); this.type = Objects.<String>requireNonNull(type, "type"); Possible<Boolean> revoked$impl = revoked; Possible<List<IntegrationData>> integrations$impl = integrations; this.verified = verified; this.friendSync = friendSync; this.showActivity = showActivity; this.visibility = visibility; this.revoked_value = revoked$impl.toOptional().orElse(null); this.revoked_absent = revoked$impl.isAbsent(); this.integrations_value = integrations$impl.toOptional().orElse(null); this.integrations_absent = integrations$impl.isAbsent(); this.initShim = null; } private ImmutableConnectionData(ImmutableConnectionData original, String id, String name, String type, Possible<Boolean> revoked, Possible<List<IntegrationData>> integrations, boolean verified, boolean friendSync, boolean showActivity, int visibility) { this.initShim = new InitShim(); this.id = id; this.name = name; this.type = type; Possible<Boolean> revoked$impl = revoked; Possible<List<IntegrationData>> integrations$impl = integrations; this.verified = verified; this.friendSync = friendSync; this.showActivity = showActivity; this.visibility = visibility;
/*     */     this.revoked_value = revoked$impl.toOptional().orElse(null);
/*     */     this.revoked_absent = revoked$impl.isAbsent();
/*     */     this.integrations_value = integrations$impl.toOptional().orElse(null);
/*     */     this.integrations_absent = integrations$impl.isAbsent();
/* 101 */     this.initShim = null; } @Generated(from = "ConnectionData", generator = "Immutables") private final class InitShim { private InitShim() {} private String formatInitCycleMessage() { List<String> attributes = new ArrayList<>();
/* 102 */       return "Cannot build ConnectionData, attribute initializers form cycle " + attributes; }
/*     */      }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("id")
/*     */   public String id() {
/* 112 */     return this.id;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("name")
/*     */   public String name() {
/* 121 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("type")
/*     */   public String type() {
/* 130 */     return this.type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("revoked")
/*     */   public Possible<Boolean> revoked() {
/* 139 */     return this.revoked_absent ? Possible.absent() : Possible.of(this.revoked_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("integrations")
/*     */   public Possible<List<IntegrationData>> integrations() {
/* 148 */     return this.integrations_absent ? Possible.absent() : 
/* 149 */       Possible.of(this.integrations_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("verified")
/*     */   public boolean verified() {
/* 158 */     return this.verified;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("friend_sync")
/*     */   public boolean friendSync() {
/* 167 */     return this.friendSync;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("show_activity")
/*     */   public boolean showActivity() {
/* 176 */     return this.showActivity;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("visibility")
/*     */   public int visibility() {
/* 185 */     return this.visibility;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableConnectionData withId(String value) {
/* 195 */     String newValue = Objects.<String>requireNonNull(value, "id");
/* 196 */     if (this.id.equals(newValue)) return this; 
/* 197 */     return new ImmutableConnectionData(this, newValue, this.name, this.type, 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 202 */         revoked(), 
/* 203 */         integrations(), this.verified, this.friendSync, this.showActivity, this.visibility);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableConnectionData withName(String value) {
/* 217 */     String newValue = Objects.<String>requireNonNull(value, "name");
/* 218 */     if (this.name.equals(newValue)) return this; 
/* 219 */     return new ImmutableConnectionData(this, this.id, newValue, this.type, 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 224 */         revoked(), 
/* 225 */         integrations(), this.verified, this.friendSync, this.showActivity, this.visibility);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableConnectionData withType(String value) {
/* 239 */     String newValue = Objects.<String>requireNonNull(value, "type");
/* 240 */     if (this.type.equals(newValue)) return this; 
/* 241 */     return new ImmutableConnectionData(this, this.id, this.name, newValue, 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 246 */         revoked(), 
/* 247 */         integrations(), this.verified, this.friendSync, this.showActivity, this.visibility);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImmutableConnectionData withRevoked(Possible<Boolean> value) {
/* 255 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/* 256 */     return new ImmutableConnectionData(this, this.id, this.name, this.type, newValue, 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 262 */         integrations(), this.verified, this.friendSync, this.showActivity, this.visibility);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImmutableConnectionData withRevoked(Boolean value) {
/* 270 */     Possible<Boolean> newValue = Possible.of(value);
/* 271 */     return new ImmutableConnectionData(this, this.id, this.name, this.type, newValue, 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 277 */         integrations(), this.verified, this.friendSync, this.showActivity, this.visibility);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImmutableConnectionData withIntegrations(Possible<List<IntegrationData>> possible) {
/* 285 */     Possible<List<IntegrationData>> newValue = Objects.<Possible<List<IntegrationData>>>requireNonNull(possible);
/* 286 */     return new ImmutableConnectionData(this, this.id, this.name, this.type, 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 291 */         revoked(), newValue, this.verified, this.friendSync, this.showActivity, this.visibility);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImmutableConnectionData withIntegrations(Iterable<IntegrationData> elements) {
/* 300 */     Possible<List<IntegrationData>> newValue = Possible.of(
/* 301 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/* 302 */     return new ImmutableConnectionData(this, this.id, this.name, this.type, 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 307 */         revoked(), newValue, this.verified, this.friendSync, this.showActivity, this.visibility);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SafeVarargs
/*     */   public final ImmutableConnectionData withIntegrations(IntegrationData... elements) {
/* 317 */     Possible<List<IntegrationData>> newValue = Possible.of(Arrays.asList(elements));
/* 318 */     return new ImmutableConnectionData(this, this.id, this.name, this.type, 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 323 */         revoked(), newValue, this.verified, this.friendSync, this.showActivity, this.visibility);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableConnectionData withVerified(boolean value) {
/* 338 */     if (this.verified == value) return this; 
/* 339 */     return new ImmutableConnectionData(this, this.id, this.name, this.type, 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 344 */         revoked(), 
/* 345 */         integrations(), value, this.friendSync, this.showActivity, this.visibility);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableConnectionData withFriendSync(boolean value) {
/* 359 */     if (this.friendSync == value) return this; 
/* 360 */     return new ImmutableConnectionData(this, this.id, this.name, this.type, 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 365 */         revoked(), 
/* 366 */         integrations(), this.verified, value, this.showActivity, this.visibility);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableConnectionData withShowActivity(boolean value) {
/* 380 */     if (this.showActivity == value) return this; 
/* 381 */     return new ImmutableConnectionData(this, this.id, this.name, this.type, 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 386 */         revoked(), 
/* 387 */         integrations(), this.verified, this.friendSync, value, this.visibility);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableConnectionData withVisibility(int value) {
/* 401 */     if (this.visibility == value) return this; 
/* 402 */     return new ImmutableConnectionData(this, this.id, this.name, this.type, 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 407 */         revoked(), 
/* 408 */         integrations(), this.verified, this.friendSync, this.showActivity, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 421 */     if (this == another) return true; 
/* 422 */     return (another instanceof ImmutableConnectionData && 
/* 423 */       equalTo(0, (ImmutableConnectionData)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableConnectionData another) {
/* 427 */     return (this.id.equals(another.id) && this.name
/* 428 */       .equals(another.name) && this.type
/* 429 */       .equals(another.type) && 
/* 430 */       revoked().equals(another.revoked()) && 
/* 431 */       Objects.equals(this.integrations_value, another.integrations_value) && this.verified == another.verified && this.friendSync == another.friendSync && this.showActivity == another.showActivity && this.visibility == another.visibility);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 444 */     int h = 5381;
/* 445 */     h += (h << 5) + this.id.hashCode();
/* 446 */     h += (h << 5) + this.name.hashCode();
/* 447 */     h += (h << 5) + this.type.hashCode();
/* 448 */     h += (h << 5) + revoked().hashCode();
/* 449 */     h += (h << 5) + Objects.hashCode(this.integrations_value);
/* 450 */     h += (h << 5) + Boolean.hashCode(this.verified);
/* 451 */     h += (h << 5) + Boolean.hashCode(this.friendSync);
/* 452 */     h += (h << 5) + Boolean.hashCode(this.showActivity);
/* 453 */     h += (h << 5) + this.visibility;
/* 454 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 463 */     return "ConnectionData{id=" + this.id + ", name=" + this.name + ", type=" + this.type + ", revoked=" + 
/*     */ 
/*     */ 
/*     */       
/* 467 */       revoked().toString() + ", integrations=" + 
/* 468 */       Objects.toString(this.integrations_value) + ", verified=" + this.verified + ", friendSync=" + this.friendSync + ", showActivity=" + this.showActivity + ", visibility=" + this.visibility + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "ConnectionData", generator = "Immutables")
/*     */   static final class Json
/*     */     implements ConnectionData
/*     */   {
/*     */     String id;
/*     */ 
/*     */     
/*     */     String name;
/*     */ 
/*     */     
/*     */     String type;
/*     */ 
/*     */     
/* 489 */     Possible<Boolean> revoked = Possible.absent();
/*     */ 
/*     */     
/* 492 */     Possible<List<IntegrationData>> integrations = Possible.absent();
/*     */     boolean verified;
/*     */     boolean verifiedIsSet;
/*     */     boolean friendSync;
/*     */     boolean friendSyncIsSet;
/*     */     boolean showActivity;
/*     */     boolean showActivityIsSet;
/*     */     int visibility;
/*     */     boolean visibilityIsSet;
/*     */     
/*     */     @JsonProperty("id")
/*     */     public void setId(String id) {
/* 504 */       this.id = id;
/*     */     }
/*     */     @JsonProperty("name")
/*     */     public void setName(String name) {
/* 508 */       this.name = name;
/*     */     }
/*     */     @JsonProperty("type")
/*     */     public void setType(String type) {
/* 512 */       this.type = type;
/*     */     }
/*     */     @JsonProperty("revoked")
/*     */     public void setRevoked(Possible<Boolean> revoked) {
/* 516 */       this.revoked = revoked;
/*     */     }
/*     */     @JsonProperty("integrations")
/*     */     public void setIntegrations(Possible<List<IntegrationData>> integrations) {
/* 520 */       this.integrations = integrations;
/*     */     }
/*     */     @JsonProperty("verified")
/*     */     public void setVerified(boolean verified) {
/* 524 */       this.verified = verified;
/* 525 */       this.verifiedIsSet = true;
/*     */     }
/*     */     @JsonProperty("friend_sync")
/*     */     public void setFriendSync(boolean friendSync) {
/* 529 */       this.friendSync = friendSync;
/* 530 */       this.friendSyncIsSet = true;
/*     */     }
/*     */     @JsonProperty("show_activity")
/*     */     public void setShowActivity(boolean showActivity) {
/* 534 */       this.showActivity = showActivity;
/* 535 */       this.showActivityIsSet = true;
/*     */     }
/*     */     @JsonProperty("visibility")
/*     */     public void setVisibility(int visibility) {
/* 539 */       this.visibility = visibility;
/* 540 */       this.visibilityIsSet = true;
/*     */     }
/*     */     public String id() {
/* 543 */       throw new UnsupportedOperationException();
/*     */     } public String name() {
/* 545 */       throw new UnsupportedOperationException();
/*     */     } public String type() {
/* 547 */       throw new UnsupportedOperationException();
/*     */     } public Possible<Boolean> revoked() {
/* 549 */       throw new UnsupportedOperationException();
/*     */     } public Possible<List<IntegrationData>> integrations() {
/* 551 */       throw new UnsupportedOperationException();
/*     */     } public boolean verified() {
/* 553 */       throw new UnsupportedOperationException();
/*     */     } public boolean friendSync() {
/* 555 */       throw new UnsupportedOperationException();
/*     */     } public boolean showActivity() {
/* 557 */       throw new UnsupportedOperationException();
/*     */     } public int visibility() {
/* 559 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableConnectionData fromJson(Json json) {
/* 570 */     Builder builder = builder();
/* 571 */     if (json.id != null) {
/* 572 */       builder.id(json.id);
/*     */     }
/* 574 */     if (json.name != null) {
/* 575 */       builder.name(json.name);
/*     */     }
/* 577 */     if (json.type != null) {
/* 578 */       builder.type(json.type);
/*     */     }
/* 580 */     if (json.revoked != null) {
/* 581 */       builder.revoked(json.revoked);
/*     */     }
/* 583 */     if (json.integrations != null) {
/* 584 */       builder.integrations(json.integrations);
/*     */     }
/* 586 */     if (json.verifiedIsSet) {
/* 587 */       builder.verified(json.verified);
/*     */     }
/* 589 */     if (json.friendSyncIsSet) {
/* 590 */       builder.friendSync(json.friendSync);
/*     */     }
/* 592 */     if (json.showActivityIsSet) {
/* 593 */       builder.showActivity(json.showActivity);
/*     */     }
/* 595 */     if (json.visibilityIsSet) {
/* 596 */       builder.visibility(json.visibility);
/*     */     }
/* 598 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableConnectionData of(String id, String name, String type, Possible<Boolean> revoked, Possible<List<IntegrationData>> integrations, boolean verified, boolean friendSync, boolean showActivity, int visibility) {
/* 615 */     return new ImmutableConnectionData(id, name, type, revoked, integrations, verified, friendSync, showActivity, visibility);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableConnectionData copyOf(ConnectionData instance) {
/* 626 */     if (instance instanceof ImmutableConnectionData) {
/* 627 */       return (ImmutableConnectionData)instance;
/*     */     }
/* 629 */     return builder()
/* 630 */       .from(instance)
/* 631 */       .build();
/*     */   }
/*     */   
/*     */   public boolean isRevokedPresent() {
/* 635 */     return !this.revoked_absent;
/*     */   }
/*     */   
/*     */   public Boolean revokedOrElse(Boolean defaultValue) {
/* 639 */     return !this.revoked_absent ? this.revoked_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isIntegrationsPresent() {
/* 643 */     return !this.integrations_absent;
/*     */   }
/*     */   
/*     */   public List<IntegrationData> integrationsOrElse(List<IntegrationData> defaultValue) {
/* 647 */     return !this.integrations_absent ? this.integrations_value : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 668 */     return new Builder();
/*     */   }
/*     */ 
/*     */   
/*     */   @Generated(from = "ConnectionData", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_ID = 1L;
/*     */     
/*     */     private static final long INIT_BIT_NAME = 2L;
/*     */     
/*     */     private static final long INIT_BIT_TYPE = 4L;
/*     */     
/*     */     private static final long INIT_BIT_VERIFIED = 8L;
/*     */     
/*     */     private static final long INIT_BIT_FRIEND_SYNC = 16L;
/*     */     
/*     */     private static final long INIT_BIT_SHOW_ACTIVITY = 32L;
/*     */     private static final long INIT_BIT_VISIBILITY = 64L;
/* 687 */     private long initBits = 127L;
/*     */     
/* 689 */     private Possible<Boolean> revoked_possible = Possible.absent();
/* 690 */     private List<IntegrationData> integrations_list = null;
/*     */ 
/*     */     
/*     */     private String id;
/*     */ 
/*     */     
/*     */     private String name;
/*     */     
/*     */     private String type;
/*     */     
/*     */     private boolean verified;
/*     */     
/*     */     private boolean friendSync;
/*     */     
/*     */     private boolean showActivity;
/*     */     
/*     */     private int visibility;
/*     */ 
/*     */     
/*     */     public final Builder from(ConnectionData instance) {
/* 710 */       Objects.requireNonNull(instance, "instance");
/* 711 */       id(instance.id());
/* 712 */       name(instance.name());
/* 713 */       type(instance.type());
/* 714 */       revoked(instance.revoked());
/* 715 */       integrations(instance.integrations());
/* 716 */       verified(instance.verified());
/* 717 */       friendSync(instance.friendSync());
/* 718 */       showActivity(instance.showActivity());
/* 719 */       visibility(instance.visibility());
/* 720 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("id")
/*     */     public final Builder id(String id) {
/* 730 */       this.id = Objects.<String>requireNonNull(id, "id");
/* 731 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 732 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("name")
/*     */     public final Builder name(String name) {
/* 742 */       this.name = Objects.<String>requireNonNull(name, "name");
/* 743 */       this.initBits &= 0xFFFFFFFFFFFFFFFDL;
/* 744 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("type")
/*     */     public final Builder type(String type) {
/* 754 */       this.type = Objects.<String>requireNonNull(type, "type");
/* 755 */       this.initBits &= 0xFFFFFFFFFFFFFFFBL;
/* 756 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("revoked")
/*     */     public Builder revoked(Possible<Boolean> value) {
/* 761 */       this.revoked_possible = value;
/* 762 */       return this;
/*     */     }
/*     */     
/*     */     public Builder revoked(Boolean value) {
/* 766 */       this.revoked_possible = Possible.of(value);
/* 767 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addIntegration(IntegrationData element) {
/* 771 */       integrations_getOrCreate().add(element);
/* 772 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addAllIntegrations(List<IntegrationData> elements) {
/* 776 */       integrations_getOrCreate().addAll(elements);
/* 777 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("integrations")
/*     */     public Builder integrations(Possible<List<IntegrationData>> elements) {
/* 782 */       this.integrations_list = null;
/* 783 */       elements.toOptional().ifPresent(e -> integrations_getOrCreate().addAll(e));
/* 784 */       return this;
/*     */     }
/*     */     
/*     */     public Builder integrations(List<IntegrationData> elements) {
/* 788 */       this.integrations_list = new ArrayList<>(elements);
/* 789 */       return this;
/*     */     }
/*     */     
/*     */     public Builder integrations(Iterable<IntegrationData> elements) {
/* 793 */       this.integrations_list = (List<IntegrationData>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/* 794 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("verified")
/*     */     public final Builder verified(boolean verified) {
/* 804 */       this.verified = verified;
/* 805 */       this.initBits &= 0xFFFFFFFFFFFFFFF7L;
/* 806 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("friend_sync")
/*     */     public final Builder friendSync(boolean friendSync) {
/* 816 */       this.friendSync = friendSync;
/* 817 */       this.initBits &= 0xFFFFFFFFFFFFFFEFL;
/* 818 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("show_activity")
/*     */     public final Builder showActivity(boolean showActivity) {
/* 828 */       this.showActivity = showActivity;
/* 829 */       this.initBits &= 0xFFFFFFFFFFFFFFDFL;
/* 830 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("visibility")
/*     */     public final Builder visibility(int visibility) {
/* 840 */       this.visibility = visibility;
/* 841 */       this.initBits &= 0xFFFFFFFFFFFFFFBFL;
/* 842 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableConnectionData build() {
/* 851 */       if (this.initBits != 0L) {
/* 852 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 854 */       return new ImmutableConnectionData(null, this.id, this.name, this.type, 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 859 */           revoked_build(), 
/* 860 */           integrations_build(), this.verified, this.friendSync, this.showActivity, this.visibility);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 868 */       List<String> attributes = new ArrayList<>();
/* 869 */       if ((this.initBits & 0x1L) != 0L) attributes.add("id"); 
/* 870 */       if ((this.initBits & 0x2L) != 0L) attributes.add("name"); 
/* 871 */       if ((this.initBits & 0x4L) != 0L) attributes.add("type"); 
/* 872 */       if ((this.initBits & 0x8L) != 0L) attributes.add("verified"); 
/* 873 */       if ((this.initBits & 0x10L) != 0L) attributes.add("friendSync"); 
/* 874 */       if ((this.initBits & 0x20L) != 0L) attributes.add("showActivity"); 
/* 875 */       if ((this.initBits & 0x40L) != 0L) attributes.add("visibility"); 
/* 876 */       return "Cannot build ConnectionData, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Possible<Boolean> revoked_build() {
/* 880 */       return this.revoked_possible;
/*     */     }
/*     */     
/*     */     private Possible<List<IntegrationData>> integrations_build() {
/* 884 */       return (this.integrations_list == null) ? Possible.absent() : 
/* 885 */         Possible.of(this.integrations_list);
/*     */     }
/*     */     
/*     */     private List<IntegrationData> integrations_getOrCreate() {
/* 889 */       if (this.integrations_list == null) {
/* 890 */         this.integrations_list = new ArrayList<>();
/*     */       }
/* 892 */       return this.integrations_list;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableConnectionData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */