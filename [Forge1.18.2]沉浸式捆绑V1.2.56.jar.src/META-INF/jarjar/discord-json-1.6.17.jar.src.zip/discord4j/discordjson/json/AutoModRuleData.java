/*    */ package discord4j.discordjson.json;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonProperty;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import discord4j.discordjson.Id;
/*    */ import java.util.List;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ 
/*    */ @JsonSerialize(as = ImmutableAutoModRuleData.class)
/*    */ @JsonDeserialize(as = ImmutableAutoModRuleData.class)
/*    */ @Immutable
/*    */ public interface AutoModRuleData
/*    */ {
/*    */   static ImmutableAutoModRuleData.Builder builder() {
/* 17 */     return ImmutableAutoModRuleData.builder();
/*    */   }
/*    */   
/*    */   Id id();
/*    */   
/*    */   String name();
/*    */   
/*    */   @JsonProperty("creator_id")
/*    */   Id creatorId();
/*    */   
/*    */   @JsonProperty("guild_id")
/*    */   Id guildId();
/*    */   
/*    */   @JsonProperty("event_type")
/*    */   int eventType();
/*    */   
/*    */   @JsonProperty("trigger_type")
/*    */   int triggerType();
/*    */   
/*    */   @JsonProperty("trigger_metadata")
/*    */   AutoModTriggerMetaData triggerMetadata();
/*    */   
/*    */   List<AutoModActionData> actions();
/*    */   
/*    */   boolean enabled();
/*    */   
/*    */   @JsonProperty("exempt_roles")
/*    */   List<Id> exemptRoles();
/*    */   
/*    */   @JsonProperty("exempt_channels")
/*    */   List<Id> exemptChannels();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\AutoModRuleData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */