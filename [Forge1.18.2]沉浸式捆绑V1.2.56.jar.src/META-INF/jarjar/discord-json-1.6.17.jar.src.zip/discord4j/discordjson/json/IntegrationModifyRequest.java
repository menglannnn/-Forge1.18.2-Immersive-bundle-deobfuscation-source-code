/*    */ package discord4j.discordjson.json;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonProperty;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ @JsonSerialize(as = ImmutableIntegrationModifyRequest.class)
/*    */ @JsonDeserialize(as = ImmutableIntegrationModifyRequest.class)
/*    */ @Immutable
/*    */ public interface IntegrationModifyRequest
/*    */ {
/*    */   static ImmutableIntegrationModifyRequest.Builder builder() {
/* 15 */     return ImmutableIntegrationModifyRequest.builder();
/*    */   }
/*    */   
/*    */   @JsonProperty("expire_behavior")
/*    */   Possible<Integer> expireBehavior();
/*    */   
/*    */   @JsonProperty("expire_grace_period")
/*    */   Possible<Integer> expireGracePeriod();
/*    */   
/*    */   @JsonProperty("enable_emoticons")
/*    */   Possible<Boolean> enableEmoticons();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\IntegrationModifyRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */