/*      */ package discord4j.discordjson.json;
/*      */ 
/*      */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*      */ import com.fasterxml.jackson.annotation.JsonCreator;
/*      */ import com.fasterxml.jackson.annotation.JsonProperty;
/*      */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*      */ import discord4j.discordjson.Id;
/*      */ import discord4j.discordjson.possible.Possible;
/*      */ import java.util.ArrayList;
/*      */ import java.util.List;
/*      */ import java.util.Objects;
/*      */ import java.util.Optional;
/*      */ import java.util.stream.Collectors;
/*      */ import java.util.stream.LongStream;
/*      */ import java.util.stream.StreamSupport;
/*      */ import org.immutables.value.Generated;
/*      */ import reactor.util.annotation.Nullable;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ @Generated(from = "MemberData", generator = "Immutables")
/*      */ public final class ImmutableMemberData
/*      */   implements MemberData
/*      */ {
/*      */   private final String nick_value;
/*      */   private final boolean nick_absent;
/*      */   private final String avatar;
/*      */   private final long[] roles_value;
/*      */   private final String joinedAt;
/*      */   private final String premiumSince_value;
/*      */   private final boolean premiumSince_absent;
/*      */   private final String hoistedRole;
/*      */   private final boolean deaf;
/*      */   private final boolean mute;
/*      */   private final String communicationDisabledUntil_value;
/*      */   private final boolean communicationDisabledUntil_absent;
/*      */   private final long flags;
/*      */   private final UserData user;
/*      */   private final Boolean pending_value;
/*      */   private final boolean pending_absent;
/*      */   private final String permissions_value;
/*      */   private final boolean permissions_absent;
/*      */   private static final byte STAGE_INITIALIZING = -1;
/*      */   private static final byte STAGE_UNINITIALIZED = 0;
/*      */   private static final byte STAGE_INITIALIZED = 1;
/*      */   
/*      */   private ImmutableMemberData(Possible<Optional<String>> nick, Optional<String> avatar, List<Id> roles, Optional<String> joinedAt, Possible<Optional<String>> premiumSince, Optional<String> hoistedRole, boolean deaf, boolean mute, Possible<Optional<String>> communicationDisabledUntil, long flags, UserData user, Possible<Boolean> pending, Possible<String> permissions) {
/*   64 */     Possible<Optional<String>> nick$impl = nick;
/*   65 */     this.avatar = avatar.orElse(null);
/*   66 */     List<Id> roles$impl = roles;
/*   67 */     this.joinedAt = joinedAt.orElse(null);
/*   68 */     Possible<Optional<String>> premiumSince$impl = premiumSince;
/*   69 */     this.hoistedRole = hoistedRole.orElse(null);
/*   70 */     this.deaf = deaf;
/*   71 */     this.mute = mute;
/*   72 */     Possible<Optional<String>> communicationDisabledUntil$impl = communicationDisabledUntil;
/*   73 */     this.initShim.flags(flags);
/*   74 */     this.user = Objects.<UserData>requireNonNull(user, "user");
/*   75 */     Possible<Boolean> pending$impl = pending;
/*   76 */     Possible<String> permissions$impl = permissions;
/*   77 */     this.nick_value = Possible.flatOpt(nick$impl).orElse(null);
/*   78 */     this.nick_absent = nick$impl.isAbsent();
/*   79 */     this
/*      */       
/*   81 */       .roles_value = roles$impl.stream().mapToLong(Id::asLong).toArray();
/*   82 */     this.premiumSince_value = Possible.flatOpt(premiumSince$impl).orElse(null);
/*   83 */     this.premiumSince_absent = premiumSince$impl.isAbsent();
/*   84 */     this.communicationDisabledUntil_value = Possible.flatOpt(communicationDisabledUntil$impl).orElse(null);
/*   85 */     this.communicationDisabledUntil_absent = communicationDisabledUntil$impl.isAbsent();
/*   86 */     this.pending_value = pending$impl.toOptional().orElse(null);
/*   87 */     this.pending_absent = pending$impl.isAbsent();
/*   88 */     this.permissions_value = permissions$impl.toOptional().orElse(null);
/*   89 */     this.permissions_absent = permissions$impl.isAbsent();
/*   90 */     this.flags = this.initShim.flags();
/*   91 */     this.initShim = null;
/*      */   }
/*      */   
/*      */   private ImmutableMemberData(Builder builder) {
/*   95 */     Possible<Optional<String>> nick$impl = builder.nick_build();
/*   96 */     this.avatar = builder.avatar;
/*   97 */     List<Id> roles$impl = builder.roles_build();
/*   98 */     this.joinedAt = builder.joinedAt;
/*   99 */     Possible<Optional<String>> premiumSince$impl = builder.premiumSince_build();
/*  100 */     this.hoistedRole = builder.hoistedRole;
/*  101 */     this.deaf = builder.deaf;
/*  102 */     this.mute = builder.mute;
/*  103 */     Possible<Optional<String>> communicationDisabledUntil$impl = builder.communicationDisabledUntil_build();
/*  104 */     this.user = builder.user;
/*  105 */     Possible<Boolean> pending$impl = builder.pending_build();
/*  106 */     Possible<String> permissions$impl = builder.permissions_build();
/*  107 */     if (builder.flagsIsSet()) {
/*  108 */       this.initShim.flags(builder.flags);
/*      */     }
/*  110 */     this.nick_value = Possible.flatOpt(nick$impl).orElse(null);
/*  111 */     this.nick_absent = nick$impl.isAbsent();
/*  112 */     this
/*      */       
/*  114 */       .roles_value = roles$impl.stream().mapToLong(Id::asLong).toArray();
/*  115 */     this.premiumSince_value = Possible.flatOpt(premiumSince$impl).orElse(null);
/*  116 */     this.premiumSince_absent = premiumSince$impl.isAbsent();
/*  117 */     this.communicationDisabledUntil_value = Possible.flatOpt(communicationDisabledUntil$impl).orElse(null);
/*  118 */     this.communicationDisabledUntil_absent = communicationDisabledUntil$impl.isAbsent();
/*  119 */     this.pending_value = pending$impl.toOptional().orElse(null);
/*  120 */     this.pending_absent = pending$impl.isAbsent();
/*  121 */     this.permissions_value = permissions$impl.toOptional().orElse(null);
/*  122 */     this.permissions_absent = permissions$impl.isAbsent();
/*  123 */     this.flags = this.initShim.flags();
/*  124 */     this.initShim = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ImmutableMemberData(ImmutableMemberData original, Possible<Optional<String>> nick, String avatar, List<Id> roles, String joinedAt, Possible<Optional<String>> premiumSince, String hoistedRole, boolean deaf, boolean mute, Possible<Optional<String>> communicationDisabledUntil, long flags, UserData user, Possible<Boolean> pending, Possible<String> permissions) {
/*  142 */     Possible<Optional<String>> nick$impl = nick;
/*  143 */     this.avatar = avatar;
/*  144 */     List<Id> roles$impl = roles;
/*  145 */     this.joinedAt = joinedAt;
/*  146 */     Possible<Optional<String>> premiumSince$impl = premiumSince;
/*  147 */     this.hoistedRole = hoistedRole;
/*  148 */     this.deaf = deaf;
/*  149 */     this.mute = mute;
/*  150 */     Possible<Optional<String>> communicationDisabledUntil$impl = communicationDisabledUntil;
/*  151 */     this.initShim.flags(flags);
/*  152 */     this.user = user;
/*  153 */     Possible<Boolean> pending$impl = pending;
/*  154 */     Possible<String> permissions$impl = permissions;
/*  155 */     this.nick_value = Possible.flatOpt(nick$impl).orElse(null);
/*  156 */     this.nick_absent = nick$impl.isAbsent();
/*  157 */     this
/*      */       
/*  159 */       .roles_value = roles$impl.stream().mapToLong(Id::asLong).toArray();
/*  160 */     this.premiumSince_value = Possible.flatOpt(premiumSince$impl).orElse(null);
/*  161 */     this.premiumSince_absent = premiumSince$impl.isAbsent();
/*  162 */     this.communicationDisabledUntil_value = Possible.flatOpt(communicationDisabledUntil$impl).orElse(null);
/*  163 */     this.communicationDisabledUntil_absent = communicationDisabledUntil$impl.isAbsent();
/*  164 */     this.pending_value = pending$impl.toOptional().orElse(null);
/*  165 */     this.pending_absent = pending$impl.isAbsent();
/*  166 */     this.permissions_value = permissions$impl.toOptional().orElse(null);
/*  167 */     this.permissions_absent = permissions$impl.isAbsent();
/*  168 */     this.flags = this.initShim.flags();
/*  169 */     this.initShim = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  175 */   private volatile transient InitShim initShim = new InitShim();
/*      */   
/*      */   @Generated(from = "MemberData", generator = "Immutables")
/*      */   private final class InitShim {
/*  179 */     private byte flagsBuildStage = 0;
/*      */     private long flags;
/*      */     
/*      */     long flags() {
/*  183 */       if (this.flagsBuildStage == -1) throw new IllegalStateException(formatInitCycleMessage()); 
/*  184 */       if (this.flagsBuildStage == 0) {
/*  185 */         this.flagsBuildStage = -1;
/*  186 */         this.flags = ImmutableMemberData.this.flagsInitialize();
/*  187 */         this.flagsBuildStage = 1;
/*      */       } 
/*  189 */       return this.flags;
/*      */     }
/*      */     
/*      */     void flags(long flags) {
/*  193 */       this.flags = flags;
/*  194 */       this.flagsBuildStage = 1;
/*      */     }
/*      */     private InitShim() {}
/*      */     private String formatInitCycleMessage() {
/*  198 */       List<String> attributes = new ArrayList<>();
/*  199 */       if (this.flagsBuildStage == -1) attributes.add("flags"); 
/*  200 */       return "Cannot build MemberData, attribute initializers form cycle " + attributes;
/*      */     }
/*      */   }
/*      */   
/*      */   private long flagsInitialize() {
/*  205 */     return super.flags();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("nick")
/*      */   public Possible<Optional<String>> nick() {
/*  214 */     return this.nick_absent ? Possible.absent() : 
/*  215 */       Possible.of(Optional.ofNullable(this.nick_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("avatar")
/*      */   public Optional<String> avatar() {
/*  224 */     return Optional.ofNullable(this.avatar);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("roles")
/*      */   public List<Id> roles() {
/*  233 */     return (List<Id>)LongStream.of(this.roles_value)
/*  234 */       .mapToObj(Id::of)
/*  235 */       .collect(Collectors.toList());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("joined_at")
/*      */   public Optional<String> joinedAt() {
/*  244 */     return Optional.ofNullable(this.joinedAt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("premium_since")
/*      */   public Possible<Optional<String>> premiumSince() {
/*  253 */     return this.premiumSince_absent ? Possible.absent() : 
/*  254 */       Possible.of(Optional.ofNullable(this.premiumSince_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("hoisted_role")
/*      */   public Optional<String> hoistedRole() {
/*  263 */     return Optional.ofNullable(this.hoistedRole);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("deaf")
/*      */   public boolean deaf() {
/*  272 */     return this.deaf;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("mute")
/*      */   public boolean mute() {
/*  281 */     return this.mute;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("communication_disabled_until")
/*      */   public Possible<Optional<String>> communicationDisabledUntil() {
/*  290 */     return this.communicationDisabledUntil_absent ? Possible.absent() : 
/*  291 */       Possible.of(Optional.ofNullable(this.communicationDisabledUntil_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("flags")
/*      */   public long flags() {
/*  300 */     InitShim shim = this.initShim;
/*  301 */     return (shim != null) ? 
/*  302 */       shim.flags() : 
/*  303 */       this.flags;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("user")
/*      */   public UserData user() {
/*  312 */     return this.user;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("pending")
/*      */   public Possible<Boolean> pending() {
/*  321 */     return this.pending_absent ? Possible.absent() : Possible.of(this.pending_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("permissions")
/*      */   public Possible<String> permissions() {
/*  330 */     return this.permissions_absent ? Possible.absent() : Possible.of(this.permissions_value);
/*      */   }
/*      */   
/*      */   public ImmutableMemberData withNick(Possible<Optional<String>> value) {
/*  334 */     Possible<Optional<String>> newValue = Objects.<Possible<Optional<String>>>requireNonNull(value);
/*  335 */     return new ImmutableMemberData(this, newValue, this.avatar, 
/*      */ 
/*      */ 
/*      */         
/*  339 */         roles(), this.joinedAt, 
/*      */         
/*  341 */         premiumSince(), this.hoistedRole, this.deaf, this.mute, 
/*      */ 
/*      */ 
/*      */         
/*  345 */         communicationDisabledUntil(), this.flags, this.user, 
/*      */ 
/*      */         
/*  348 */         pending(), 
/*  349 */         permissions());
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public ImmutableMemberData withNick(@Nullable String value) {
/*  354 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/*  355 */     return new ImmutableMemberData(this, newValue, this.avatar, 
/*      */ 
/*      */ 
/*      */         
/*  359 */         roles(), this.joinedAt, 
/*      */         
/*  361 */         premiumSince(), this.hoistedRole, this.deaf, this.mute, 
/*      */ 
/*      */ 
/*      */         
/*  365 */         communicationDisabledUntil(), this.flags, this.user, 
/*      */ 
/*      */         
/*  368 */         pending(), 
/*  369 */         permissions());
/*      */   }
/*      */   
/*      */   public ImmutableMemberData withNickOrNull(@Nullable String value) {
/*  373 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/*  374 */     return new ImmutableMemberData(this, newValue, this.avatar, 
/*      */ 
/*      */ 
/*      */         
/*  378 */         roles(), this.joinedAt, 
/*      */         
/*  380 */         premiumSince(), this.hoistedRole, this.deaf, this.mute, 
/*      */ 
/*      */ 
/*      */         
/*  384 */         communicationDisabledUntil(), this.flags, this.user, 
/*      */ 
/*      */         
/*  387 */         pending(), 
/*  388 */         permissions());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableMemberData withAvatar(String value) {
/*  397 */     String newValue = Objects.<String>requireNonNull(value, "avatar");
/*  398 */     if (Objects.equals(this.avatar, newValue)) return this; 
/*  399 */     return new ImmutableMemberData(this, 
/*      */         
/*  401 */         nick(), newValue, 
/*      */         
/*  403 */         roles(), this.joinedAt, 
/*      */         
/*  405 */         premiumSince(), this.hoistedRole, this.deaf, this.mute, 
/*      */ 
/*      */ 
/*      */         
/*  409 */         communicationDisabledUntil(), this.flags, this.user, 
/*      */ 
/*      */         
/*  412 */         pending(), 
/*  413 */         permissions());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableMemberData withAvatar(Optional<String> optional) {
/*  423 */     String value = optional.orElse(null);
/*  424 */     if (Objects.equals(this.avatar, value)) return this; 
/*  425 */     return new ImmutableMemberData(this, 
/*      */         
/*  427 */         nick(), value, 
/*      */         
/*  429 */         roles(), this.joinedAt, 
/*      */         
/*  431 */         premiumSince(), this.hoistedRole, this.deaf, this.mute, 
/*      */ 
/*      */ 
/*      */         
/*  435 */         communicationDisabledUntil(), this.flags, this.user, 
/*      */ 
/*      */         
/*  438 */         pending(), 
/*  439 */         permissions());
/*      */   }
/*      */   
/*      */   public ImmutableMemberData withRoles(List<Id> value) {
/*  443 */     List<Id> newValue = value;
/*  444 */     return new ImmutableMemberData(this, 
/*      */         
/*  446 */         nick(), this.avatar, newValue, this.joinedAt, 
/*      */ 
/*      */ 
/*      */         
/*  450 */         premiumSince(), this.hoistedRole, this.deaf, this.mute, 
/*      */ 
/*      */ 
/*      */         
/*  454 */         communicationDisabledUntil(), this.flags, this.user, 
/*      */ 
/*      */         
/*  457 */         pending(), 
/*  458 */         permissions());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableMemberData withJoinedAt(String value) {
/*  467 */     String newValue = Objects.<String>requireNonNull(value, "joinedAt");
/*  468 */     if (Objects.equals(this.joinedAt, newValue)) return this; 
/*  469 */     return new ImmutableMemberData(this, 
/*      */         
/*  471 */         nick(), this.avatar, 
/*      */         
/*  473 */         roles(), newValue, 
/*      */         
/*  475 */         premiumSince(), this.hoistedRole, this.deaf, this.mute, 
/*      */ 
/*      */ 
/*      */         
/*  479 */         communicationDisabledUntil(), this.flags, this.user, 
/*      */ 
/*      */         
/*  482 */         pending(), 
/*  483 */         permissions());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableMemberData withJoinedAt(Optional<String> optional) {
/*  493 */     String value = optional.orElse(null);
/*  494 */     if (Objects.equals(this.joinedAt, value)) return this; 
/*  495 */     return new ImmutableMemberData(this, 
/*      */         
/*  497 */         nick(), this.avatar, 
/*      */         
/*  499 */         roles(), value, 
/*      */         
/*  501 */         premiumSince(), this.hoistedRole, this.deaf, this.mute, 
/*      */ 
/*      */ 
/*      */         
/*  505 */         communicationDisabledUntil(), this.flags, this.user, 
/*      */ 
/*      */         
/*  508 */         pending(), 
/*  509 */         permissions());
/*      */   }
/*      */   
/*      */   public ImmutableMemberData withPremiumSince(Possible<Optional<String>> value) {
/*  513 */     Possible<Optional<String>> newValue = Objects.<Possible<Optional<String>>>requireNonNull(value);
/*  514 */     return new ImmutableMemberData(this, 
/*      */         
/*  516 */         nick(), this.avatar, 
/*      */         
/*  518 */         roles(), this.joinedAt, newValue, this.hoistedRole, this.deaf, this.mute, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  524 */         communicationDisabledUntil(), this.flags, this.user, 
/*      */ 
/*      */         
/*  527 */         pending(), 
/*  528 */         permissions());
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public ImmutableMemberData withPremiumSince(@Nullable String value) {
/*  533 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/*  534 */     return new ImmutableMemberData(this, 
/*      */         
/*  536 */         nick(), this.avatar, 
/*      */         
/*  538 */         roles(), this.joinedAt, newValue, this.hoistedRole, this.deaf, this.mute, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  544 */         communicationDisabledUntil(), this.flags, this.user, 
/*      */ 
/*      */         
/*  547 */         pending(), 
/*  548 */         permissions());
/*      */   }
/*      */   
/*      */   public ImmutableMemberData withPremiumSinceOrNull(@Nullable String value) {
/*  552 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/*  553 */     return new ImmutableMemberData(this, 
/*      */         
/*  555 */         nick(), this.avatar, 
/*      */         
/*  557 */         roles(), this.joinedAt, newValue, this.hoistedRole, this.deaf, this.mute, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  563 */         communicationDisabledUntil(), this.flags, this.user, 
/*      */ 
/*      */         
/*  566 */         pending(), 
/*  567 */         permissions());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableMemberData withHoistedRole(String value) {
/*  576 */     String newValue = Objects.<String>requireNonNull(value, "hoistedRole");
/*  577 */     if (Objects.equals(this.hoistedRole, newValue)) return this; 
/*  578 */     return new ImmutableMemberData(this, 
/*      */         
/*  580 */         nick(), this.avatar, 
/*      */         
/*  582 */         roles(), this.joinedAt, 
/*      */         
/*  584 */         premiumSince(), newValue, this.deaf, this.mute, 
/*      */ 
/*      */ 
/*      */         
/*  588 */         communicationDisabledUntil(), this.flags, this.user, 
/*      */ 
/*      */         
/*  591 */         pending(), 
/*  592 */         permissions());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableMemberData withHoistedRole(Optional<String> optional) {
/*  602 */     String value = optional.orElse(null);
/*  603 */     if (Objects.equals(this.hoistedRole, value)) return this; 
/*  604 */     return new ImmutableMemberData(this, 
/*      */         
/*  606 */         nick(), this.avatar, 
/*      */         
/*  608 */         roles(), this.joinedAt, 
/*      */         
/*  610 */         premiumSince(), value, this.deaf, this.mute, 
/*      */ 
/*      */ 
/*      */         
/*  614 */         communicationDisabledUntil(), this.flags, this.user, 
/*      */ 
/*      */         
/*  617 */         pending(), 
/*  618 */         permissions());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableMemberData withDeaf(boolean value) {
/*  628 */     if (this.deaf == value) return this; 
/*  629 */     return new ImmutableMemberData(this, 
/*      */         
/*  631 */         nick(), this.avatar, 
/*      */         
/*  633 */         roles(), this.joinedAt, 
/*      */         
/*  635 */         premiumSince(), this.hoistedRole, value, this.mute, 
/*      */ 
/*      */ 
/*      */         
/*  639 */         communicationDisabledUntil(), this.flags, this.user, 
/*      */ 
/*      */         
/*  642 */         pending(), 
/*  643 */         permissions());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableMemberData withMute(boolean value) {
/*  653 */     if (this.mute == value) return this; 
/*  654 */     return new ImmutableMemberData(this, 
/*      */         
/*  656 */         nick(), this.avatar, 
/*      */         
/*  658 */         roles(), this.joinedAt, 
/*      */         
/*  660 */         premiumSince(), this.hoistedRole, this.deaf, value, 
/*      */ 
/*      */ 
/*      */         
/*  664 */         communicationDisabledUntil(), this.flags, this.user, 
/*      */ 
/*      */         
/*  667 */         pending(), 
/*  668 */         permissions());
/*      */   }
/*      */   
/*      */   public ImmutableMemberData withCommunicationDisabledUntil(Possible<Optional<String>> value) {
/*  672 */     Possible<Optional<String>> newValue = Objects.<Possible<Optional<String>>>requireNonNull(value);
/*  673 */     return new ImmutableMemberData(this, 
/*      */         
/*  675 */         nick(), this.avatar, 
/*      */         
/*  677 */         roles(), this.joinedAt, 
/*      */         
/*  679 */         premiumSince(), this.hoistedRole, this.deaf, this.mute, newValue, this.flags, this.user, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  686 */         pending(), 
/*  687 */         permissions());
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public ImmutableMemberData withCommunicationDisabledUntil(@Nullable String value) {
/*  692 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/*  693 */     return new ImmutableMemberData(this, 
/*      */         
/*  695 */         nick(), this.avatar, 
/*      */         
/*  697 */         roles(), this.joinedAt, 
/*      */         
/*  699 */         premiumSince(), this.hoistedRole, this.deaf, this.mute, newValue, this.flags, this.user, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  706 */         pending(), 
/*  707 */         permissions());
/*      */   }
/*      */   
/*      */   public ImmutableMemberData withCommunicationDisabledUntilOrNull(@Nullable String value) {
/*  711 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/*  712 */     return new ImmutableMemberData(this, 
/*      */         
/*  714 */         nick(), this.avatar, 
/*      */         
/*  716 */         roles(), this.joinedAt, 
/*      */         
/*  718 */         premiumSince(), this.hoistedRole, this.deaf, this.mute, newValue, this.flags, this.user, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  725 */         pending(), 
/*  726 */         permissions());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableMemberData withFlags(long value) {
/*  736 */     if (this.flags == value) return this; 
/*  737 */     return new ImmutableMemberData(this, 
/*      */         
/*  739 */         nick(), this.avatar, 
/*      */         
/*  741 */         roles(), this.joinedAt, 
/*      */         
/*  743 */         premiumSince(), this.hoistedRole, this.deaf, this.mute, 
/*      */ 
/*      */ 
/*      */         
/*  747 */         communicationDisabledUntil(), value, this.user, 
/*      */ 
/*      */         
/*  750 */         pending(), 
/*  751 */         permissions());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableMemberData withUser(UserData value) {
/*  761 */     if (this.user == value) return this; 
/*  762 */     UserData newValue = Objects.<UserData>requireNonNull(value, "user");
/*  763 */     return new ImmutableMemberData(this, 
/*      */         
/*  765 */         nick(), this.avatar, 
/*      */         
/*  767 */         roles(), this.joinedAt, 
/*      */         
/*  769 */         premiumSince(), this.hoistedRole, this.deaf, this.mute, 
/*      */ 
/*      */ 
/*      */         
/*  773 */         communicationDisabledUntil(), this.flags, newValue, 
/*      */ 
/*      */         
/*  776 */         pending(), 
/*  777 */         permissions());
/*      */   }
/*      */   
/*      */   public ImmutableMemberData withPending(Possible<Boolean> value) {
/*  781 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/*  782 */     return new ImmutableMemberData(this, 
/*      */         
/*  784 */         nick(), this.avatar, 
/*      */         
/*  786 */         roles(), this.joinedAt, 
/*      */         
/*  788 */         premiumSince(), this.hoistedRole, this.deaf, this.mute, 
/*      */ 
/*      */ 
/*      */         
/*  792 */         communicationDisabledUntil(), this.flags, this.user, newValue, 
/*      */ 
/*      */ 
/*      */         
/*  796 */         permissions());
/*      */   }
/*      */   
/*      */   public ImmutableMemberData withPending(Boolean value) {
/*  800 */     Possible<Boolean> newValue = Possible.of(value);
/*  801 */     return new ImmutableMemberData(this, 
/*      */         
/*  803 */         nick(), this.avatar, 
/*      */         
/*  805 */         roles(), this.joinedAt, 
/*      */         
/*  807 */         premiumSince(), this.hoistedRole, this.deaf, this.mute, 
/*      */ 
/*      */ 
/*      */         
/*  811 */         communicationDisabledUntil(), this.flags, this.user, newValue, 
/*      */ 
/*      */ 
/*      */         
/*  815 */         permissions());
/*      */   }
/*      */   
/*      */   public ImmutableMemberData withPermissions(Possible<String> value) {
/*  819 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/*  820 */     return new ImmutableMemberData(this, 
/*      */         
/*  822 */         nick(), this.avatar, 
/*      */         
/*  824 */         roles(), this.joinedAt, 
/*      */         
/*  826 */         premiumSince(), this.hoistedRole, this.deaf, this.mute, 
/*      */ 
/*      */ 
/*      */         
/*  830 */         communicationDisabledUntil(), this.flags, this.user, 
/*      */ 
/*      */         
/*  833 */         pending(), newValue);
/*      */   }
/*      */ 
/*      */   
/*      */   public ImmutableMemberData withPermissions(String value) {
/*  838 */     Possible<String> newValue = Possible.of(value);
/*  839 */     return new ImmutableMemberData(this, 
/*      */         
/*  841 */         nick(), this.avatar, 
/*      */         
/*  843 */         roles(), this.joinedAt, 
/*      */         
/*  845 */         premiumSince(), this.hoistedRole, this.deaf, this.mute, 
/*      */ 
/*      */ 
/*      */         
/*  849 */         communicationDisabledUntil(), this.flags, this.user, 
/*      */ 
/*      */         
/*  852 */         pending(), newValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean equals(Object another) {
/*  862 */     if (this == another) return true; 
/*  863 */     return (another instanceof ImmutableMemberData && 
/*  864 */       equalTo(0, (ImmutableMemberData)another));
/*      */   }
/*      */   
/*      */   private boolean equalTo(int synthetic, ImmutableMemberData another) {
/*  868 */     return (nick().equals(another.nick()) && 
/*  869 */       Objects.equals(this.avatar, another.avatar) && 
/*  870 */       Objects.equals(this.roles_value, another.roles_value) && 
/*  871 */       Objects.equals(this.joinedAt, another.joinedAt) && 
/*  872 */       premiumSince().equals(another.premiumSince()) && 
/*  873 */       Objects.equals(this.hoistedRole, another.hoistedRole) && this.deaf == another.deaf && this.mute == another.mute && 
/*      */ 
/*      */       
/*  876 */       communicationDisabledUntil().equals(another.communicationDisabledUntil()) && this.flags == another.flags && this.user
/*      */       
/*  878 */       .equals(another.user) && 
/*  879 */       pending().equals(another.pending()) && 
/*  880 */       permissions().equals(another.permissions()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int hashCode() {
/*  889 */     int h = 5381;
/*  890 */     h += (h << 5) + nick().hashCode();
/*  891 */     h += (h << 5) + Objects.hashCode(this.avatar);
/*  892 */     h += (h << 5) + Objects.hashCode(this.roles_value);
/*  893 */     h += (h << 5) + Objects.hashCode(this.joinedAt);
/*  894 */     h += (h << 5) + premiumSince().hashCode();
/*  895 */     h += (h << 5) + Objects.hashCode(this.hoistedRole);
/*  896 */     h += (h << 5) + Boolean.hashCode(this.deaf);
/*  897 */     h += (h << 5) + Boolean.hashCode(this.mute);
/*  898 */     h += (h << 5) + communicationDisabledUntil().hashCode();
/*  899 */     h += (h << 5) + Long.hashCode(this.flags);
/*  900 */     h += (h << 5) + this.user.hashCode();
/*  901 */     h += (h << 5) + pending().hashCode();
/*  902 */     h += (h << 5) + permissions().hashCode();
/*  903 */     return h;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/*  912 */     StringBuilder builder = new StringBuilder("MemberData{");
/*  913 */     builder.append("nick=").append(nick().toString());
/*  914 */     if (this.avatar != null) {
/*  915 */       builder.append(", ");
/*  916 */       builder.append("avatar=").append(this.avatar);
/*      */     } 
/*  918 */     builder.append(", ");
/*  919 */     builder.append("roles=").append(Objects.toString(this.roles_value));
/*  920 */     if (this.joinedAt != null) {
/*  921 */       builder.append(", ");
/*  922 */       builder.append("joinedAt=").append(this.joinedAt);
/*      */     } 
/*  924 */     builder.append(", ");
/*  925 */     builder.append("premiumSince=").append(premiumSince().toString());
/*  926 */     if (this.hoistedRole != null) {
/*  927 */       builder.append(", ");
/*  928 */       builder.append("hoistedRole=").append(this.hoistedRole);
/*      */     } 
/*  930 */     builder.append(", ");
/*  931 */     builder.append("deaf=").append(this.deaf);
/*  932 */     builder.append(", ");
/*  933 */     builder.append("mute=").append(this.mute);
/*  934 */     builder.append(", ");
/*  935 */     builder.append("communicationDisabledUntil=").append(communicationDisabledUntil().toString());
/*  936 */     builder.append(", ");
/*  937 */     builder.append("flags=").append(this.flags);
/*  938 */     builder.append(", ");
/*  939 */     builder.append("user=").append(this.user);
/*  940 */     builder.append(", ");
/*  941 */     builder.append("pending=").append(pending().toString());
/*  942 */     builder.append(", ");
/*  943 */     builder.append("permissions=").append(permissions().toString());
/*  944 */     return builder.append("}").toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonDeserialize
/*      */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*      */   @Generated(from = "MemberData", generator = "Immutables")
/*      */   static final class Json
/*      */     implements MemberData
/*      */   {
/*  957 */     Possible<Optional<String>> nick = Possible.absent();
/*      */     
/*  959 */     Optional<String> avatar = Optional.empty();
/*      */     List<Id> roles;
/*  961 */     Optional<String> joinedAt = Optional.empty();
/*      */     
/*  963 */     Possible<Optional<String>> premiumSince = Possible.absent();
/*      */     
/*  965 */     Optional<String> hoistedRole = Optional.empty();
/*      */     
/*      */     boolean deaf;
/*      */     boolean deafIsSet;
/*      */     boolean mute;
/*      */     boolean muteIsSet;
/*  971 */     Possible<Optional<String>> communicationDisabledUntil = Possible.absent();
/*      */     
/*      */     long flags;
/*      */     
/*      */     boolean flagsIsSet;
/*      */     UserData user;
/*  977 */     Possible<Boolean> pending = Possible.absent();
/*      */ 
/*      */     
/*  980 */     Possible<String> permissions = Possible.absent();
/*      */     
/*      */     @JsonProperty("nick")
/*      */     public void setNick(Possible<Optional<String>> nick) {
/*  984 */       this.nick = nick;
/*      */     }
/*      */     @JsonProperty("avatar")
/*      */     public void setAvatar(Optional<String> avatar) {
/*  988 */       this.avatar = avatar;
/*      */     }
/*      */     @JsonProperty("roles")
/*      */     public void setRoles(List<Id> roles) {
/*  992 */       this.roles = roles;
/*      */     }
/*      */     @JsonProperty("joined_at")
/*      */     public void setJoinedAt(Optional<String> joinedAt) {
/*  996 */       this.joinedAt = joinedAt;
/*      */     }
/*      */     @JsonProperty("premium_since")
/*      */     public void setPremiumSince(Possible<Optional<String>> premiumSince) {
/* 1000 */       this.premiumSince = premiumSince;
/*      */     }
/*      */     @JsonProperty("hoisted_role")
/*      */     public void setHoistedRole(Optional<String> hoistedRole) {
/* 1004 */       this.hoistedRole = hoistedRole;
/*      */     }
/*      */     @JsonProperty("deaf")
/*      */     public void setDeaf(boolean deaf) {
/* 1008 */       this.deaf = deaf;
/* 1009 */       this.deafIsSet = true;
/*      */     }
/*      */     @JsonProperty("mute")
/*      */     public void setMute(boolean mute) {
/* 1013 */       this.mute = mute;
/* 1014 */       this.muteIsSet = true;
/*      */     }
/*      */     @JsonProperty("communication_disabled_until")
/*      */     public void setCommunicationDisabledUntil(Possible<Optional<String>> communicationDisabledUntil) {
/* 1018 */       this.communicationDisabledUntil = communicationDisabledUntil;
/*      */     }
/*      */     @JsonProperty("flags")
/*      */     public void setFlags(long flags) {
/* 1022 */       this.flags = flags;
/* 1023 */       this.flagsIsSet = true;
/*      */     }
/*      */     @JsonProperty("user")
/*      */     public void setUser(UserData user) {
/* 1027 */       this.user = user;
/*      */     }
/*      */     @JsonProperty("pending")
/*      */     public void setPending(Possible<Boolean> pending) {
/* 1031 */       this.pending = pending;
/*      */     }
/*      */     @JsonProperty("permissions")
/*      */     public void setPermissions(Possible<String> permissions) {
/* 1035 */       this.permissions = permissions;
/*      */     }
/*      */     public Possible<Optional<String>> nick() {
/* 1038 */       throw new UnsupportedOperationException();
/*      */     } public Optional<String> avatar() {
/* 1040 */       throw new UnsupportedOperationException();
/*      */     } public List<Id> roles() {
/* 1042 */       throw new UnsupportedOperationException();
/*      */     } public Optional<String> joinedAt() {
/* 1044 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Optional<String>> premiumSince() {
/* 1046 */       throw new UnsupportedOperationException();
/*      */     } public Optional<String> hoistedRole() {
/* 1048 */       throw new UnsupportedOperationException();
/*      */     } public boolean deaf() {
/* 1050 */       throw new UnsupportedOperationException();
/*      */     } public boolean mute() {
/* 1052 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Optional<String>> communicationDisabledUntil() {
/* 1054 */       throw new UnsupportedOperationException();
/*      */     } public long flags() {
/* 1056 */       throw new UnsupportedOperationException();
/*      */     } public UserData user() {
/* 1058 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Boolean> pending() {
/* 1060 */       throw new UnsupportedOperationException();
/*      */     } public Possible<String> permissions() {
/* 1062 */       throw new UnsupportedOperationException();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*      */   static ImmutableMemberData fromJson(Json json) {
/* 1073 */     Builder builder = builder();
/* 1074 */     if (json.nick != null) {
/* 1075 */       builder.nick(json.nick);
/*      */     }
/* 1077 */     if (json.avatar != null) {
/* 1078 */       builder.avatar(json.avatar);
/*      */     }
/* 1080 */     if (json.roles != null) {
/* 1081 */       builder.roles(json.roles);
/*      */     }
/* 1083 */     if (json.joinedAt != null) {
/* 1084 */       builder.joinedAt(json.joinedAt);
/*      */     }
/* 1086 */     if (json.premiumSince != null) {
/* 1087 */       builder.premiumSince(json.premiumSince);
/*      */     }
/* 1089 */     if (json.hoistedRole != null) {
/* 1090 */       builder.hoistedRole(json.hoistedRole);
/*      */     }
/* 1092 */     if (json.deafIsSet) {
/* 1093 */       builder.deaf(json.deaf);
/*      */     }
/* 1095 */     if (json.muteIsSet) {
/* 1096 */       builder.mute(json.mute);
/*      */     }
/* 1098 */     if (json.communicationDisabledUntil != null) {
/* 1099 */       builder.communicationDisabledUntil(json.communicationDisabledUntil);
/*      */     }
/* 1101 */     if (json.flagsIsSet) {
/* 1102 */       builder.flags(json.flags);
/*      */     }
/* 1104 */     if (json.user != null) {
/* 1105 */       builder.user(json.user);
/*      */     }
/* 1107 */     if (json.pending != null) {
/* 1108 */       builder.pending(json.pending);
/*      */     }
/* 1110 */     if (json.permissions != null) {
/* 1111 */       builder.permissions(json.permissions);
/*      */     }
/* 1113 */     return builder.build();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableMemberData of(Possible<Optional<String>> nick, Optional<String> avatar, List<Id> roles, Optional<String> joinedAt, Possible<Optional<String>> premiumSince, Optional<String> hoistedRole, boolean deaf, boolean mute, Possible<Optional<String>> communicationDisabledUntil, long flags, UserData user, Possible<Boolean> pending, Possible<String> permissions) {
/* 1134 */     return new ImmutableMemberData(nick, avatar, roles, joinedAt, premiumSince, hoistedRole, deaf, mute, communicationDisabledUntil, flags, user, pending, permissions);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableMemberData copyOf(MemberData instance) {
/* 1145 */     if (instance instanceof ImmutableMemberData) {
/* 1146 */       return (ImmutableMemberData)instance;
/*      */     }
/* 1148 */     return builder()
/* 1149 */       .from(instance)
/* 1150 */       .build();
/*      */   }
/*      */   
/*      */   public boolean isNickPresent() {
/* 1154 */     return !this.nick_absent;
/*      */   }
/*      */   
/*      */   public String nickOrElse(String defaultValue) {
/* 1158 */     return !this.nick_absent ? this.nick_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isPremiumSincePresent() {
/* 1162 */     return !this.premiumSince_absent;
/*      */   }
/*      */   
/*      */   public String premiumSinceOrElse(String defaultValue) {
/* 1166 */     return !this.premiumSince_absent ? this.premiumSince_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isCommunicationDisabledUntilPresent() {
/* 1170 */     return !this.communicationDisabledUntil_absent;
/*      */   }
/*      */   
/*      */   public String communicationDisabledUntilOrElse(String defaultValue) {
/* 1174 */     return !this.communicationDisabledUntil_absent ? this.communicationDisabledUntil_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isPendingPresent() {
/* 1178 */     return !this.pending_absent;
/*      */   }
/*      */   
/*      */   public Boolean pendingOrElse(Boolean defaultValue) {
/* 1182 */     return !this.pending_absent ? this.pending_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isPermissionsPresent() {
/* 1186 */     return !this.permissions_absent;
/*      */   }
/*      */   
/*      */   public String permissionsOrElse(String defaultValue) {
/* 1190 */     return !this.permissions_absent ? this.permissions_value : defaultValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Builder builder() {
/* 1215 */     return new Builder();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   @Generated(from = "MemberData", generator = "Immutables")
/*      */   public static final class Builder
/*      */   {
/*      */     private static final long INIT_BIT_DEAF = 1L;
/*      */     
/*      */     private static final long INIT_BIT_MUTE = 2L;
/*      */     
/*      */     private static final long INIT_BIT_USER = 4L;
/*      */     
/*      */     private static final long OPT_BIT_FLAGS = 1L;
/*      */     
/* 1231 */     private long initBits = 7L;
/*      */     
/*      */     private long optBits;
/* 1234 */     private Possible<Optional<String>> nick_possible = Possible.absent();
/* 1235 */     private List<Long> roles_list = null;
/* 1236 */     private Possible<Optional<String>> premiumSince_possible = Possible.absent();
/* 1237 */     private Possible<Optional<String>> communicationDisabledUntil_possible = Possible.absent();
/* 1238 */     private Possible<Boolean> pending_possible = Possible.absent();
/* 1239 */     private Possible<String> permissions_possible = Possible.absent();
/*      */     
/*      */     private String avatar;
/*      */     
/*      */     private String joinedAt;
/*      */     
/*      */     private String hoistedRole;
/*      */     
/*      */     private boolean deaf;
/*      */     
/*      */     private boolean mute;
/*      */     
/*      */     private long flags;
/*      */     
/*      */     private UserData user;
/*      */ 
/*      */     
/*      */     public final Builder from(PartialMemberData instance) {
/* 1257 */       Objects.requireNonNull(instance, "instance");
/* 1258 */       from(instance);
/* 1259 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder from(MemberData instance) {
/* 1268 */       Objects.requireNonNull(instance, "instance");
/* 1269 */       from(instance);
/* 1270 */       return this;
/*      */     }
/*      */     
/*      */     private void from(Object object) {
/* 1274 */       long bits = 0L;
/* 1275 */       if (object instanceof PartialMemberData) {
/* 1276 */         PartialMemberData instance = (PartialMemberData)object;
/* 1277 */         if ((bits & 0x100L) == 0L) {
/* 1278 */           nick(instance.nick());
/* 1279 */           bits |= 0x100L;
/*      */         } 
/* 1281 */         if ((bits & 0x200L) == 0L) {
/* 1282 */           Optional<String> hoistedRoleOptional = instance.hoistedRole();
/* 1283 */           if (hoistedRoleOptional.isPresent()) {
/* 1284 */             hoistedRole(hoistedRoleOptional);
/*      */           }
/* 1286 */           bits |= 0x200L;
/*      */         } 
/* 1288 */         if ((bits & 0x1L) == 0L) {
/* 1289 */           Optional<String> joinedAtOptional = instance.joinedAt();
/* 1290 */           if (joinedAtOptional.isPresent()) {
/* 1291 */             joinedAt(joinedAtOptional);
/*      */           }
/* 1293 */           bits |= 0x1L;
/*      */         } 
/* 1295 */         if ((bits & 0x2L) == 0L) {
/* 1296 */           roles(instance.roles());
/* 1297 */           bits |= 0x2L;
/*      */         } 
/* 1299 */         if ((bits & 0x4L) == 0L) {
/* 1300 */           premiumSince(instance.premiumSince());
/* 1301 */           bits |= 0x4L;
/*      */         } 
/* 1303 */         if ((bits & 0x8L) == 0L) {
/* 1304 */           communicationDisabledUntil(instance.communicationDisabledUntil());
/* 1305 */           bits |= 0x8L;
/*      */         } 
/* 1307 */         if ((bits & 0x10L) == 0L) {
/* 1308 */           deaf(instance.deaf());
/* 1309 */           bits |= 0x10L;
/*      */         } 
/* 1311 */         if ((bits & 0x20L) == 0L) {
/* 1312 */           flags(instance.flags());
/* 1313 */           bits |= 0x20L;
/*      */         } 
/* 1315 */         if ((bits & 0x40L) == 0L) {
/* 1316 */           mute(instance.mute());
/* 1317 */           bits |= 0x40L;
/*      */         } 
/* 1319 */         if ((bits & 0x80L) == 0L) {
/* 1320 */           Optional<String> avatarOptional = instance.avatar();
/* 1321 */           if (avatarOptional.isPresent()) {
/* 1322 */             avatar(avatarOptional);
/*      */           }
/* 1324 */           bits |= 0x80L;
/*      */         } 
/*      */       } 
/* 1327 */       if (object instanceof MemberData) {
/* 1328 */         MemberData instance = (MemberData)object;
/* 1329 */         if ((bits & 0x1L) == 0L) {
/* 1330 */           Optional<String> joinedAtOptional = instance.joinedAt();
/* 1331 */           if (joinedAtOptional.isPresent()) {
/* 1332 */             joinedAt(joinedAtOptional);
/*      */           }
/* 1334 */           bits |= 0x1L;
/*      */         } 
/* 1336 */         if ((bits & 0x2L) == 0L) {
/* 1337 */           roles(instance.roles());
/* 1338 */           bits |= 0x2L;
/*      */         } 
/* 1340 */         if ((bits & 0x4L) == 0L) {
/* 1341 */           premiumSince(instance.premiumSince());
/* 1342 */           bits |= 0x4L;
/*      */         } 
/* 1344 */         if ((bits & 0x8L) == 0L) {
/* 1345 */           communicationDisabledUntil(instance.communicationDisabledUntil());
/* 1346 */           bits |= 0x8L;
/*      */         } 
/* 1348 */         pending(instance.pending());
/* 1349 */         if ((bits & 0x10L) == 0L) {
/* 1350 */           deaf(instance.deaf());
/* 1351 */           bits |= 0x10L;
/*      */         } 
/* 1353 */         if ((bits & 0x20L) == 0L) {
/* 1354 */           flags(instance.flags());
/* 1355 */           bits |= 0x20L;
/*      */         } 
/* 1357 */         if ((bits & 0x40L) == 0L) {
/* 1358 */           mute(instance.mute());
/* 1359 */           bits |= 0x40L;
/*      */         } 
/* 1361 */         if ((bits & 0x80L) == 0L) {
/* 1362 */           Optional<String> avatarOptional = instance.avatar();
/* 1363 */           if (avatarOptional.isPresent()) {
/* 1364 */             avatar(avatarOptional);
/*      */           }
/* 1366 */           bits |= 0x80L;
/*      */         } 
/* 1368 */         if ((bits & 0x100L) == 0L) {
/* 1369 */           nick(instance.nick());
/* 1370 */           bits |= 0x100L;
/*      */         } 
/* 1372 */         if ((bits & 0x200L) == 0L) {
/* 1373 */           Optional<String> hoistedRoleOptional = instance.hoistedRole();
/* 1374 */           if (hoistedRoleOptional.isPresent()) {
/* 1375 */             hoistedRole(hoistedRoleOptional);
/*      */           }
/* 1377 */           bits |= 0x200L;
/*      */         } 
/* 1379 */         permissions(instance.permissions());
/* 1380 */         user(instance.user());
/*      */       } 
/*      */     }
/*      */     
/*      */     @JsonProperty("nick")
/*      */     public Builder nick(Possible<Optional<String>> value) {
/* 1386 */       this.nick_possible = value;
/* 1387 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public Builder nick(@Nullable String value) {
/* 1392 */       this.nick_possible = Possible.of(Optional.ofNullable(value));
/* 1393 */       return this;
/*      */     }
/*      */     
/*      */     public Builder nickOrNull(@Nullable String value) {
/* 1397 */       this.nick_possible = Possible.of(Optional.ofNullable(value));
/* 1398 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder avatar(String avatar) {
/* 1407 */       this.avatar = Objects.<String>requireNonNull(avatar, "avatar");
/* 1408 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("avatar")
/*      */     public final Builder avatar(Optional<String> avatar) {
/* 1418 */       this.avatar = avatar.orElse(null);
/* 1419 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addRole(long element) {
/* 1423 */       roles_getOrCreate().add(Long.valueOf(element));
/* 1424 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addRole(String element) {
/* 1428 */       roles_getOrCreate().add(Long.valueOf(Id.of(element).asLong()));
/* 1429 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addRole(Id element) {
/* 1433 */       roles_getOrCreate().add(Long.valueOf(element.asLong()));
/* 1434 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addAllRoles(List<Long> elements) {
/* 1438 */       roles_getOrCreate().addAll(elements);
/* 1439 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("roles")
/*      */     public Builder roles(List<Id> elements) {
/* 1444 */       this.roles_list = (List<Long>)elements.stream().map(Id::asLong).collect(Collectors.toList());
/* 1445 */       return this;
/*      */     }
/*      */     
/*      */     public Builder roles(Iterable<Id> elements) {
/* 1449 */       this
/*      */         
/* 1451 */         .roles_list = (List<Long>)StreamSupport.stream(elements.spliterator(), false).map(Id::asLong).collect(Collectors.toList());
/* 1452 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder joinedAt(String joinedAt) {
/* 1461 */       this.joinedAt = Objects.<String>requireNonNull(joinedAt, "joinedAt");
/* 1462 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("joined_at")
/*      */     public final Builder joinedAt(Optional<String> joinedAt) {
/* 1472 */       this.joinedAt = joinedAt.orElse(null);
/* 1473 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("premium_since")
/*      */     public Builder premiumSince(Possible<Optional<String>> value) {
/* 1478 */       this.premiumSince_possible = value;
/* 1479 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public Builder premiumSince(@Nullable String value) {
/* 1484 */       this.premiumSince_possible = Possible.of(Optional.ofNullable(value));
/* 1485 */       return this;
/*      */     }
/*      */     
/*      */     public Builder premiumSinceOrNull(@Nullable String value) {
/* 1489 */       this.premiumSince_possible = Possible.of(Optional.ofNullable(value));
/* 1490 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder hoistedRole(String hoistedRole) {
/* 1499 */       this.hoistedRole = Objects.<String>requireNonNull(hoistedRole, "hoistedRole");
/* 1500 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("hoisted_role")
/*      */     public final Builder hoistedRole(Optional<String> hoistedRole) {
/* 1510 */       this.hoistedRole = hoistedRole.orElse(null);
/* 1511 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("deaf")
/*      */     public final Builder deaf(boolean deaf) {
/* 1521 */       this.deaf = deaf;
/* 1522 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 1523 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("mute")
/*      */     public final Builder mute(boolean mute) {
/* 1533 */       this.mute = mute;
/* 1534 */       this.initBits &= 0xFFFFFFFFFFFFFFFDL;
/* 1535 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("communication_disabled_until")
/*      */     public Builder communicationDisabledUntil(Possible<Optional<String>> value) {
/* 1540 */       this.communicationDisabledUntil_possible = value;
/* 1541 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public Builder communicationDisabledUntil(@Nullable String value) {
/* 1546 */       this.communicationDisabledUntil_possible = Possible.of(Optional.ofNullable(value));
/* 1547 */       return this;
/*      */     }
/*      */     
/*      */     public Builder communicationDisabledUntilOrNull(@Nullable String value) {
/* 1551 */       this.communicationDisabledUntil_possible = Possible.of(Optional.ofNullable(value));
/* 1552 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("flags")
/*      */     public final Builder flags(long flags) {
/* 1563 */       this.flags = flags;
/* 1564 */       this.optBits |= 0x1L;
/* 1565 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("user")
/*      */     public final Builder user(UserData user) {
/* 1575 */       this.user = Objects.<UserData>requireNonNull(user, "user");
/* 1576 */       this.initBits &= 0xFFFFFFFFFFFFFFFBL;
/* 1577 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("pending")
/*      */     public Builder pending(Possible<Boolean> value) {
/* 1582 */       this.pending_possible = value;
/* 1583 */       return this;
/*      */     }
/*      */     
/*      */     public Builder pending(Boolean value) {
/* 1587 */       this.pending_possible = Possible.of(value);
/* 1588 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("permissions")
/*      */     public Builder permissions(Possible<String> value) {
/* 1593 */       this.permissions_possible = value;
/* 1594 */       return this;
/*      */     }
/*      */     
/*      */     public Builder permissions(String value) {
/* 1598 */       this.permissions_possible = Possible.of(value);
/* 1599 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ImmutableMemberData build() {
/* 1608 */       if (this.initBits != 0L) {
/* 1609 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*      */       }
/* 1611 */       return new ImmutableMemberData(this);
/*      */     }
/*      */     
/*      */     private boolean flagsIsSet() {
/* 1615 */       return ((this.optBits & 0x1L) != 0L);
/*      */     }
/*      */     
/*      */     private String formatRequiredAttributesMessage() {
/* 1619 */       List<String> attributes = new ArrayList<>();
/* 1620 */       if ((this.initBits & 0x1L) != 0L) attributes.add("deaf"); 
/* 1621 */       if ((this.initBits & 0x2L) != 0L) attributes.add("mute"); 
/* 1622 */       if ((this.initBits & 0x4L) != 0L) attributes.add("user"); 
/* 1623 */       return "Cannot build MemberData, some of required attributes are not set " + attributes;
/*      */     }
/*      */     
/*      */     private Possible<Optional<String>> nick_build() {
/* 1627 */       return this.nick_possible;
/*      */     }
/*      */     
/*      */     private List<Id> roles_build() {
/* 1631 */       return (List<Id>)roles_getOrCreate().stream().map(Id::of).collect(Collectors.toList());
/*      */     }
/*      */     
/*      */     private List<Long> roles_getOrCreate() {
/* 1635 */       if (this.roles_list == null) {
/* 1636 */         this.roles_list = new ArrayList<>();
/*      */       }
/* 1638 */       return this.roles_list;
/*      */     }
/*      */     
/*      */     private Possible<Optional<String>> premiumSince_build() {
/* 1642 */       return this.premiumSince_possible;
/*      */     }
/*      */     
/*      */     private Possible<Optional<String>> communicationDisabledUntil_build() {
/* 1646 */       return this.communicationDisabledUntil_possible;
/*      */     }
/*      */     
/*      */     private Possible<Boolean> pending_build() {
/* 1650 */       return this.pending_possible;
/*      */     }
/*      */     
/*      */     private Possible<String> permissions_build() {
/* 1654 */       return this.permissions_possible;
/*      */     }
/*      */     
/*      */     private Builder() {}
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableMemberData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */