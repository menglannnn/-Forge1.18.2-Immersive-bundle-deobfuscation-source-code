/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.Id;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "ChannelMentionData", generator = "Immutables")
/*     */ public final class ImmutableChannelMentionData
/*     */   implements ChannelMentionData
/*     */ {
/*     */   private final long id_value;
/*     */   private final long guildId_value;
/*     */   private final int type;
/*     */   private final String name;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   
/*     */   private ImmutableChannelMentionData(Id id, Id guildId, int type, String name) {
/*  31 */     Id id$impl = id;
/*  32 */     Id guildId$impl = guildId;
/*  33 */     this.type = type;
/*  34 */     this.name = Objects.<String>requireNonNull(name, "name");
/*  35 */     this.id_value = id$impl.asLong();
/*  36 */     this.guildId_value = guildId$impl.asLong();
/*  37 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ImmutableChannelMentionData(ImmutableChannelMentionData original, Id id, Id guildId, int type, String name) {
/*  46 */     Id id$impl = id;
/*  47 */     Id guildId$impl = guildId;
/*  48 */     this.type = type;
/*  49 */     this.name = name;
/*  50 */     this.id_value = id$impl.asLong();
/*  51 */     this.guildId_value = guildId$impl.asLong();
/*  52 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  58 */   private volatile transient InitShim initShim = new InitShim();
/*     */   
/*     */   @Generated(from = "ChannelMentionData", generator = "Immutables")
/*     */   private final class InitShim {
/*     */     private String formatInitCycleMessage() {
/*  63 */       List<String> attributes = new ArrayList<>();
/*  64 */       return "Cannot build ChannelMentionData, attribute initializers form cycle " + attributes;
/*     */     }
/*     */ 
/*     */     
/*     */     private InitShim() {}
/*     */   }
/*     */ 
/*     */   
/*     */   @JsonProperty("id")
/*     */   public Id id() {
/*  74 */     return Id.of(this.id_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("guild_id")
/*     */   public Id guildId() {
/*  83 */     return Id.of(this.guildId_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("type")
/*     */   public int type() {
/*  92 */     return this.type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("name")
/*     */   public String name() {
/* 101 */     return this.name;
/*     */   }
/*     */   
/*     */   public ImmutableChannelMentionData withId(long value) {
/* 105 */     Id newValue = Id.of(value);
/* 106 */     return new ImmutableChannelMentionData(this, newValue, guildId(), this.type, this.name);
/*     */   }
/*     */   
/*     */   public ImmutableChannelMentionData withId(String value) {
/* 110 */     Id newValue = Id.of(value);
/* 111 */     return new ImmutableChannelMentionData(this, newValue, guildId(), this.type, this.name);
/*     */   }
/*     */   
/*     */   public ImmutableChannelMentionData withGuildId(long value) {
/* 115 */     Id newValue = Id.of(value);
/* 116 */     return new ImmutableChannelMentionData(this, id(), newValue, this.type, this.name);
/*     */   }
/*     */   
/*     */   public ImmutableChannelMentionData withGuildId(String value) {
/* 120 */     Id newValue = Id.of(value);
/* 121 */     return new ImmutableChannelMentionData(this, id(), newValue, this.type, this.name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableChannelMentionData withType(int value) {
/* 131 */     if (this.type == value) return this; 
/* 132 */     return new ImmutableChannelMentionData(this, id(), guildId(), value, this.name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableChannelMentionData withName(String value) {
/* 142 */     String newValue = Objects.<String>requireNonNull(value, "name");
/* 143 */     if (this.name.equals(newValue)) return this; 
/* 144 */     return new ImmutableChannelMentionData(this, id(), guildId(), this.type, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 153 */     if (this == another) return true; 
/* 154 */     return (another instanceof ImmutableChannelMentionData && 
/* 155 */       equalTo(0, (ImmutableChannelMentionData)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableChannelMentionData another) {
/* 159 */     return (Objects.equals(Long.valueOf(this.id_value), Long.valueOf(another.id_value)) && 
/* 160 */       Objects.equals(Long.valueOf(this.guildId_value), Long.valueOf(another.guildId_value)) && this.type == another.type && this.name
/*     */       
/* 162 */       .equals(another.name));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 171 */     int h = 5381;
/* 172 */     h += (h << 5) + Objects.hashCode(Long.valueOf(this.id_value));
/* 173 */     h += (h << 5) + Objects.hashCode(Long.valueOf(this.guildId_value));
/* 174 */     h += (h << 5) + this.type;
/* 175 */     h += (h << 5) + this.name.hashCode();
/* 176 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 185 */     return "ChannelMentionData{id=" + 
/* 186 */       Objects.toString(Long.valueOf(this.id_value)) + ", guildId=" + 
/* 187 */       Objects.toString(Long.valueOf(this.guildId_value)) + ", type=" + this.type + ", name=" + this.name + "}";
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "ChannelMentionData", generator = "Immutables")
/*     */   static final class Json
/*     */     implements ChannelMentionData
/*     */   {
/*     */     Id id;
/*     */     
/*     */     Id guildId;
/*     */     
/*     */     int type;
/*     */     
/*     */     boolean typeIsSet;
/*     */     String name;
/*     */     
/*     */     @JsonProperty("id")
/*     */     public void setId(Id id) {
/* 209 */       this.id = id;
/*     */     }
/*     */     @JsonProperty("guild_id")
/*     */     public void setGuildId(Id guildId) {
/* 213 */       this.guildId = guildId;
/*     */     }
/*     */     @JsonProperty("type")
/*     */     public void setType(int type) {
/* 217 */       this.type = type;
/* 218 */       this.typeIsSet = true;
/*     */     }
/*     */     @JsonProperty("name")
/*     */     public void setName(String name) {
/* 222 */       this.name = name;
/*     */     }
/*     */     public Id id() {
/* 225 */       throw new UnsupportedOperationException();
/*     */     } public Id guildId() {
/* 227 */       throw new UnsupportedOperationException();
/*     */     } public int type() {
/* 229 */       throw new UnsupportedOperationException();
/*     */     } public String name() {
/* 231 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableChannelMentionData fromJson(Json json) {
/* 242 */     Builder builder = builder();
/* 243 */     if (json.id != null) {
/* 244 */       builder.id(json.id);
/*     */     }
/* 246 */     if (json.guildId != null) {
/* 247 */       builder.guildId(json.guildId);
/*     */     }
/* 249 */     if (json.typeIsSet) {
/* 250 */       builder.type(json.type);
/*     */     }
/* 252 */     if (json.name != null) {
/* 253 */       builder.name(json.name);
/*     */     }
/* 255 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableChannelMentionData of(Id id, Id guildId, int type, String name) {
/* 267 */     return new ImmutableChannelMentionData(id, guildId, type, name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableChannelMentionData copyOf(ChannelMentionData instance) {
/* 278 */     if (instance instanceof ImmutableChannelMentionData) {
/* 279 */       return (ImmutableChannelMentionData)instance;
/*     */     }
/* 281 */     return builder()
/* 282 */       .from(instance)
/* 283 */       .build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 299 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "ChannelMentionData", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_TYPE = 1L;
/*     */ 
/*     */     
/*     */     private static final long INIT_BIT_NAME = 2L;
/*     */ 
/*     */     
/* 313 */     private long initBits = 3L;
/*     */     
/* 315 */     private Id id_id = null;
/* 316 */     private Id guildId_id = null;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private int type;
/*     */ 
/*     */ 
/*     */     
/*     */     private String name;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(ChannelMentionData instance) {
/* 331 */       Objects.requireNonNull(instance, "instance");
/* 332 */       id(instance.id());
/* 333 */       guildId(instance.guildId());
/* 334 */       type(instance.type());
/* 335 */       name(instance.name());
/* 336 */       return this;
/*     */     }
/*     */     
/*     */     public Builder id(String value) {
/* 340 */       this.id_id = Id.of(value);
/* 341 */       return this;
/*     */     }
/*     */     
/*     */     public Builder id(long value) {
/* 345 */       this.id_id = Id.of(value);
/* 346 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("id")
/*     */     public Builder id(Id value) {
/* 351 */       this.id_id = value;
/* 352 */       return this;
/*     */     }
/*     */     
/*     */     public Builder guildId(String value) {
/* 356 */       this.guildId_id = Id.of(value);
/* 357 */       return this;
/*     */     }
/*     */     
/*     */     public Builder guildId(long value) {
/* 361 */       this.guildId_id = Id.of(value);
/* 362 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("guild_id")
/*     */     public Builder guildId(Id value) {
/* 367 */       this.guildId_id = value;
/* 368 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("type")
/*     */     public final Builder type(int type) {
/* 378 */       this.type = type;
/* 379 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 380 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("name")
/*     */     public final Builder name(String name) {
/* 390 */       this.name = Objects.<String>requireNonNull(name, "name");
/* 391 */       this.initBits &= 0xFFFFFFFFFFFFFFFDL;
/* 392 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableChannelMentionData build() {
/* 401 */       if (this.initBits != 0L) {
/* 402 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 404 */       return new ImmutableChannelMentionData(null, id_build(), guildId_build(), this.type, this.name);
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 408 */       List<String> attributes = new ArrayList<>();
/* 409 */       if ((this.initBits & 0x1L) != 0L) attributes.add("type"); 
/* 410 */       if ((this.initBits & 0x2L) != 0L) attributes.add("name"); 
/* 411 */       return "Cannot build ChannelMentionData, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Id id_build() {
/* 415 */       return this.id_id;
/*     */     }
/*     */     
/*     */     private Id guildId_build() {
/* 419 */       return this.guildId_id;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableChannelMentionData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */