/*    */ package discord4j.discordjson.json;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonProperty;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ @JsonSerialize(as = ImmutableEmbedThumbnailData.class)
/*    */ @JsonDeserialize(as = ImmutableEmbedThumbnailData.class)
/*    */ @Immutable
/*    */ public interface EmbedThumbnailData
/*    */ {
/*    */   static ImmutableEmbedThumbnailData.Builder builder() {
/* 15 */     return ImmutableEmbedThumbnailData.builder();
/*    */   }
/*    */   
/*    */   Possible<String> url();
/*    */   
/*    */   @JsonProperty("proxy_url")
/*    */   Possible<String> proxyUrl();
/*    */   
/*    */   Possible<Integer> height();
/*    */   
/*    */   Possible<Integer> width();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\EmbedThumbnailData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */