/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.Id;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "PartialStickerData", generator = "Immutables")
/*     */ public final class ImmutablePartialStickerData
/*     */   implements PartialStickerData
/*     */ {
/*     */   private final long id_value;
/*     */   private final String name;
/*     */   private final int formatType;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   
/*     */   private ImmutablePartialStickerData(Id id, String name, int formatType) {
/*  30 */     Id id$impl = id;
/*  31 */     this.name = Objects.<String>requireNonNull(name, "name");
/*  32 */     this.formatType = formatType;
/*  33 */     this.id_value = id$impl.asLong();
/*  34 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ImmutablePartialStickerData(ImmutablePartialStickerData original, Id id, String name, int formatType) {
/*  42 */     Id id$impl = id;
/*  43 */     this.name = name;
/*  44 */     this.formatType = formatType;
/*  45 */     this.id_value = id$impl.asLong();
/*  46 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  52 */   private volatile transient InitShim initShim = new InitShim();
/*     */   
/*     */   @Generated(from = "PartialStickerData", generator = "Immutables")
/*     */   private final class InitShim {
/*     */     private String formatInitCycleMessage() {
/*  57 */       List<String> attributes = new ArrayList<>();
/*  58 */       return "Cannot build PartialStickerData, attribute initializers form cycle " + attributes;
/*     */     }
/*     */ 
/*     */     
/*     */     private InitShim() {}
/*     */   }
/*     */ 
/*     */   
/*     */   @JsonProperty("id")
/*     */   public Id id() {
/*  68 */     return Id.of(this.id_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("name")
/*     */   public String name() {
/*  77 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("format_type")
/*     */   public int formatType() {
/*  86 */     return this.formatType;
/*     */   }
/*     */   
/*     */   public ImmutablePartialStickerData withId(long value) {
/*  90 */     Id newValue = Id.of(value);
/*  91 */     return new ImmutablePartialStickerData(this, newValue, this.name, this.formatType);
/*     */   }
/*     */   
/*     */   public ImmutablePartialStickerData withId(String value) {
/*  95 */     Id newValue = Id.of(value);
/*  96 */     return new ImmutablePartialStickerData(this, newValue, this.name, this.formatType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutablePartialStickerData withName(String value) {
/* 106 */     String newValue = Objects.<String>requireNonNull(value, "name");
/* 107 */     if (this.name.equals(newValue)) return this; 
/* 108 */     return new ImmutablePartialStickerData(this, id(), newValue, this.formatType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutablePartialStickerData withFormatType(int value) {
/* 118 */     if (this.formatType == value) return this; 
/* 119 */     return new ImmutablePartialStickerData(this, id(), this.name, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 128 */     if (this == another) return true; 
/* 129 */     return (another instanceof ImmutablePartialStickerData && 
/* 130 */       equalTo(0, (ImmutablePartialStickerData)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutablePartialStickerData another) {
/* 134 */     return (Objects.equals(Long.valueOf(this.id_value), Long.valueOf(another.id_value)) && this.name
/* 135 */       .equals(another.name) && this.formatType == another.formatType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 145 */     int h = 5381;
/* 146 */     h += (h << 5) + Objects.hashCode(Long.valueOf(this.id_value));
/* 147 */     h += (h << 5) + this.name.hashCode();
/* 148 */     h += (h << 5) + this.formatType;
/* 149 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 158 */     return "PartialStickerData{id=" + 
/* 159 */       Objects.toString(Long.valueOf(this.id_value)) + ", name=" + this.name + ", formatType=" + this.formatType + "}";
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "PartialStickerData", generator = "Immutables")
/*     */   static final class Json
/*     */     implements PartialStickerData
/*     */   {
/*     */     Id id;
/*     */     
/*     */     String name;
/*     */     
/*     */     int formatType;
/*     */     
/*     */     boolean formatTypeIsSet;
/*     */     
/*     */     @JsonProperty("id")
/*     */     public void setId(Id id) {
/* 180 */       this.id = id;
/*     */     }
/*     */     @JsonProperty("name")
/*     */     public void setName(String name) {
/* 184 */       this.name = name;
/*     */     }
/*     */     @JsonProperty("format_type")
/*     */     public void setFormatType(int formatType) {
/* 188 */       this.formatType = formatType;
/* 189 */       this.formatTypeIsSet = true;
/*     */     }
/*     */     public Id id() {
/* 192 */       throw new UnsupportedOperationException();
/*     */     } public String name() {
/* 194 */       throw new UnsupportedOperationException();
/*     */     } public int formatType() {
/* 196 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutablePartialStickerData fromJson(Json json) {
/* 207 */     Builder builder = builder();
/* 208 */     if (json.id != null) {
/* 209 */       builder.id(json.id);
/*     */     }
/* 211 */     if (json.name != null) {
/* 212 */       builder.name(json.name);
/*     */     }
/* 214 */     if (json.formatTypeIsSet) {
/* 215 */       builder.formatType(json.formatType);
/*     */     }
/* 217 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutablePartialStickerData of(Id id, String name, int formatType) {
/* 228 */     return new ImmutablePartialStickerData(id, name, formatType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutablePartialStickerData copyOf(PartialStickerData instance) {
/* 239 */     if (instance instanceof ImmutablePartialStickerData) {
/* 240 */       return (ImmutablePartialStickerData)instance;
/*     */     }
/* 242 */     return builder()
/* 243 */       .from(instance)
/* 244 */       .build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 259 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "PartialStickerData", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_NAME = 1L;
/*     */ 
/*     */     
/*     */     private static final long INIT_BIT_FORMAT_TYPE = 2L;
/*     */ 
/*     */     
/* 273 */     private long initBits = 3L;
/*     */     
/* 275 */     private Id id_id = null;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private String name;
/*     */ 
/*     */ 
/*     */     
/*     */     private int formatType;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(PartialStickerData instance) {
/* 290 */       Objects.requireNonNull(instance, "instance");
/* 291 */       id(instance.id());
/* 292 */       name(instance.name());
/* 293 */       formatType(instance.formatType());
/* 294 */       return this;
/*     */     }
/*     */     
/*     */     public Builder id(String value) {
/* 298 */       this.id_id = Id.of(value);
/* 299 */       return this;
/*     */     }
/*     */     
/*     */     public Builder id(long value) {
/* 303 */       this.id_id = Id.of(value);
/* 304 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("id")
/*     */     public Builder id(Id value) {
/* 309 */       this.id_id = value;
/* 310 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("name")
/*     */     public final Builder name(String name) {
/* 320 */       this.name = Objects.<String>requireNonNull(name, "name");
/* 321 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 322 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("format_type")
/*     */     public final Builder formatType(int formatType) {
/* 332 */       this.formatType = formatType;
/* 333 */       this.initBits &= 0xFFFFFFFFFFFFFFFDL;
/* 334 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutablePartialStickerData build() {
/* 343 */       if (this.initBits != 0L) {
/* 344 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 346 */       return new ImmutablePartialStickerData(null, id_build(), this.name, this.formatType);
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 350 */       List<String> attributes = new ArrayList<>();
/* 351 */       if ((this.initBits & 0x1L) != 0L) attributes.add("name"); 
/* 352 */       if ((this.initBits & 0x2L) != 0L) attributes.add("formatType"); 
/* 353 */       return "Cannot build PartialStickerData, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Id id_build() {
/* 357 */       return this.id_id;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutablePartialStickerData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */