/*    */ package discord4j.discordjson.json;
/*    */ 
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ @JsonSerialize(as = ImmutableActivitySecretsData.class)
/*    */ @JsonDeserialize(as = ImmutableActivitySecretsData.class)
/*    */ @Immutable
/*    */ public interface ActivitySecretsData
/*    */ {
/*    */   static ImmutableActivitySecretsData.Builder builder() {
/* 14 */     return ImmutableActivitySecretsData.builder();
/*    */   }
/*    */   
/*    */   Possible<String> join();
/*    */   
/*    */   Possible<String> spectate();
/*    */   
/*    */   Possible<String> match();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ActivitySecretsData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */