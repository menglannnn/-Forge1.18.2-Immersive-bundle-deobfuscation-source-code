/*      */ package discord4j.discordjson.json;
/*      */ 
/*      */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*      */ import com.fasterxml.jackson.annotation.JsonCreator;
/*      */ import com.fasterxml.jackson.annotation.JsonProperty;
/*      */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*      */ import discord4j.discordjson.possible.Possible;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.List;
/*      */ import java.util.Objects;
/*      */ import java.util.Optional;
/*      */ import org.immutables.value.Generated;
/*      */ import reactor.util.annotation.Nullable;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ @Generated(from = "ResolvedMemberData", generator = "Immutables")
/*      */ public final class ImmutableResolvedMemberData
/*      */   implements ResolvedMemberData
/*      */ {
/*      */   private final String nick_value;
/*      */   private final boolean nick_absent;
/*      */   private final List<String> roles;
/*      */   private final String joinedAt;
/*      */   private final String premiumSince_value;
/*      */   private final boolean premiumSince_absent;
/*      */   private final Boolean pending_value;
/*      */   private final boolean pending_absent;
/*      */   private final String permissions_value;
/*      */   private final boolean permissions_absent;
/*      */   private final String communicationDisabledUntil_value;
/*      */   private final boolean communicationDisabledUntil_absent;
/*      */   private final long flags;
/*      */   private static final byte STAGE_INITIALIZING = -1;
/*      */   private static final byte STAGE_UNINITIALIZED = 0;
/*      */   private static final byte STAGE_INITIALIZED = 1;
/*      */   
/*      */   private ImmutableResolvedMemberData(Possible<Optional<String>> nick, Iterable<String> roles, String joinedAt, Possible<Optional<String>> premiumSince, Possible<Boolean> pending, Possible<String> permissions, Possible<Optional<String>> communicationDisabledUntil, long flags) {
/*   53 */     Possible<Optional<String>> nick$impl = nick;
/*   54 */     this.roles = createUnmodifiableList(false, createSafeList(roles, true, false));
/*   55 */     this.joinedAt = Objects.<String>requireNonNull(joinedAt, "joinedAt");
/*   56 */     Possible<Optional<String>> premiumSince$impl = premiumSince;
/*   57 */     Possible<Boolean> pending$impl = pending;
/*   58 */     Possible<String> permissions$impl = permissions;
/*   59 */     Possible<Optional<String>> communicationDisabledUntil$impl = communicationDisabledUntil;
/*   60 */     this.initShim.flags(flags);
/*   61 */     this.nick_value = Possible.flatOpt(nick$impl).orElse(null);
/*   62 */     this.nick_absent = nick$impl.isAbsent();
/*   63 */     this.premiumSince_value = Possible.flatOpt(premiumSince$impl).orElse(null);
/*   64 */     this.premiumSince_absent = premiumSince$impl.isAbsent();
/*   65 */     this.pending_value = pending$impl.toOptional().orElse(null);
/*   66 */     this.pending_absent = pending$impl.isAbsent();
/*   67 */     this.permissions_value = permissions$impl.toOptional().orElse(null);
/*   68 */     this.permissions_absent = permissions$impl.isAbsent();
/*   69 */     this.communicationDisabledUntil_value = Possible.flatOpt(communicationDisabledUntil$impl).orElse(null);
/*   70 */     this.communicationDisabledUntil_absent = communicationDisabledUntil$impl.isAbsent();
/*   71 */     this.flags = this.initShim.flags();
/*   72 */     this.initShim = null;
/*      */   }
/*      */   
/*      */   private ImmutableResolvedMemberData(Builder builder) {
/*   76 */     Possible<Optional<String>> nick$impl = builder.nick_build();
/*   77 */     this.roles = createUnmodifiableList(true, builder.roles);
/*   78 */     this.joinedAt = builder.joinedAt;
/*   79 */     Possible<Optional<String>> premiumSince$impl = builder.premiumSince_build();
/*   80 */     Possible<Boolean> pending$impl = builder.pending_build();
/*   81 */     Possible<String> permissions$impl = builder.permissions_build();
/*   82 */     Possible<Optional<String>> communicationDisabledUntil$impl = builder.communicationDisabledUntil_build();
/*   83 */     if (builder.flagsIsSet()) {
/*   84 */       this.initShim.flags(builder.flags);
/*      */     }
/*   86 */     this.nick_value = Possible.flatOpt(nick$impl).orElse(null);
/*   87 */     this.nick_absent = nick$impl.isAbsent();
/*   88 */     this.premiumSince_value = Possible.flatOpt(premiumSince$impl).orElse(null);
/*   89 */     this.premiumSince_absent = premiumSince$impl.isAbsent();
/*   90 */     this.pending_value = pending$impl.toOptional().orElse(null);
/*   91 */     this.pending_absent = pending$impl.isAbsent();
/*   92 */     this.permissions_value = permissions$impl.toOptional().orElse(null);
/*   93 */     this.permissions_absent = permissions$impl.isAbsent();
/*   94 */     this.communicationDisabledUntil_value = Possible.flatOpt(communicationDisabledUntil$impl).orElse(null);
/*   95 */     this.communicationDisabledUntil_absent = communicationDisabledUntil$impl.isAbsent();
/*   96 */     this.flags = this.initShim.flags();
/*   97 */     this.initShim = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ImmutableResolvedMemberData(ImmutableResolvedMemberData original, Possible<Optional<String>> nick, List<String> roles, String joinedAt, Possible<Optional<String>> premiumSince, Possible<Boolean> pending, Possible<String> permissions, Possible<Optional<String>> communicationDisabledUntil, long flags) {
/*  110 */     Possible<Optional<String>> nick$impl = nick;
/*  111 */     this.roles = roles;
/*  112 */     this.joinedAt = joinedAt;
/*  113 */     Possible<Optional<String>> premiumSince$impl = premiumSince;
/*  114 */     Possible<Boolean> pending$impl = pending;
/*  115 */     Possible<String> permissions$impl = permissions;
/*  116 */     Possible<Optional<String>> communicationDisabledUntil$impl = communicationDisabledUntil;
/*  117 */     this.initShim.flags(flags);
/*  118 */     this.nick_value = Possible.flatOpt(nick$impl).orElse(null);
/*  119 */     this.nick_absent = nick$impl.isAbsent();
/*  120 */     this.premiumSince_value = Possible.flatOpt(premiumSince$impl).orElse(null);
/*  121 */     this.premiumSince_absent = premiumSince$impl.isAbsent();
/*  122 */     this.pending_value = pending$impl.toOptional().orElse(null);
/*  123 */     this.pending_absent = pending$impl.isAbsent();
/*  124 */     this.permissions_value = permissions$impl.toOptional().orElse(null);
/*  125 */     this.permissions_absent = permissions$impl.isAbsent();
/*  126 */     this.communicationDisabledUntil_value = Possible.flatOpt(communicationDisabledUntil$impl).orElse(null);
/*  127 */     this.communicationDisabledUntil_absent = communicationDisabledUntil$impl.isAbsent();
/*  128 */     this.flags = this.initShim.flags();
/*  129 */     this.initShim = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  135 */   private volatile transient InitShim initShim = new InitShim();
/*      */   
/*      */   @Generated(from = "ResolvedMemberData", generator = "Immutables")
/*      */   private final class InitShim {
/*  139 */     private byte flagsBuildStage = 0;
/*      */     private long flags;
/*      */     
/*      */     long flags() {
/*  143 */       if (this.flagsBuildStage == -1) throw new IllegalStateException(formatInitCycleMessage()); 
/*  144 */       if (this.flagsBuildStage == 0) {
/*  145 */         this.flagsBuildStage = -1;
/*  146 */         this.flags = ImmutableResolvedMemberData.this.flagsInitialize();
/*  147 */         this.flagsBuildStage = 1;
/*      */       } 
/*  149 */       return this.flags;
/*      */     }
/*      */     
/*      */     void flags(long flags) {
/*  153 */       this.flags = flags;
/*  154 */       this.flagsBuildStage = 1;
/*      */     }
/*      */     private InitShim() {}
/*      */     private String formatInitCycleMessage() {
/*  158 */       List<String> attributes = new ArrayList<>();
/*  159 */       if (this.flagsBuildStage == -1) attributes.add("flags"); 
/*  160 */       return "Cannot build ResolvedMemberData, attribute initializers form cycle " + attributes;
/*      */     }
/*      */   }
/*      */   
/*      */   private long flagsInitialize() {
/*  165 */     return super.flags();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("nick")
/*      */   public Possible<Optional<String>> nick() {
/*  174 */     return this.nick_absent ? Possible.absent() : 
/*  175 */       Possible.of(Optional.ofNullable(this.nick_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("roles")
/*      */   public List<String> roles() {
/*  184 */     return this.roles;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("joined_at")
/*      */   public String joinedAt() {
/*  193 */     return this.joinedAt;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("premium_since")
/*      */   public Possible<Optional<String>> premiumSince() {
/*  202 */     return this.premiumSince_absent ? Possible.absent() : 
/*  203 */       Possible.of(Optional.ofNullable(this.premiumSince_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("pending")
/*      */   public Possible<Boolean> pending() {
/*  212 */     return this.pending_absent ? Possible.absent() : Possible.of(this.pending_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("permissions")
/*      */   public Possible<String> permissions() {
/*  221 */     return this.permissions_absent ? Possible.absent() : Possible.of(this.permissions_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("communication_disabled_until")
/*      */   public Possible<Optional<String>> communicationDisabledUntil() {
/*  230 */     return this.communicationDisabledUntil_absent ? Possible.absent() : 
/*  231 */       Possible.of(Optional.ofNullable(this.communicationDisabledUntil_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("flags")
/*      */   public long flags() {
/*  240 */     InitShim shim = this.initShim;
/*  241 */     return (shim != null) ? 
/*  242 */       shim.flags() : 
/*  243 */       this.flags;
/*      */   }
/*      */   
/*      */   public ImmutableResolvedMemberData withNick(Possible<Optional<String>> value) {
/*  247 */     Possible<Optional<String>> newValue = Objects.<Possible<Optional<String>>>requireNonNull(value);
/*  248 */     return new ImmutableResolvedMemberData(this, newValue, this.roles, this.joinedAt, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  253 */         premiumSince(), 
/*  254 */         pending(), 
/*  255 */         permissions(), 
/*  256 */         communicationDisabledUntil(), this.flags);
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public ImmutableResolvedMemberData withNick(@Nullable String value) {
/*  262 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/*  263 */     return new ImmutableResolvedMemberData(this, newValue, this.roles, this.joinedAt, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  268 */         premiumSince(), 
/*  269 */         pending(), 
/*  270 */         permissions(), 
/*  271 */         communicationDisabledUntil(), this.flags);
/*      */   }
/*      */ 
/*      */   
/*      */   public ImmutableResolvedMemberData withNickOrNull(@Nullable String value) {
/*  276 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/*  277 */     return new ImmutableResolvedMemberData(this, newValue, this.roles, this.joinedAt, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  282 */         premiumSince(), 
/*  283 */         pending(), 
/*  284 */         permissions(), 
/*  285 */         communicationDisabledUntil(), this.flags);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableResolvedMemberData withRoles(String... elements) {
/*  295 */     List<String> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/*  296 */     return new ImmutableResolvedMemberData(this, 
/*      */         
/*  298 */         nick(), newValue, this.joinedAt, 
/*      */ 
/*      */         
/*  301 */         premiumSince(), 
/*  302 */         pending(), 
/*  303 */         permissions(), 
/*  304 */         communicationDisabledUntil(), this.flags);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableResolvedMemberData withRoles(Iterable<String> elements) {
/*  315 */     if (this.roles == elements) return this; 
/*  316 */     List<String> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/*  317 */     return new ImmutableResolvedMemberData(this, 
/*      */         
/*  319 */         nick(), newValue, this.joinedAt, 
/*      */ 
/*      */         
/*  322 */         premiumSince(), 
/*  323 */         pending(), 
/*  324 */         permissions(), 
/*  325 */         communicationDisabledUntil(), this.flags);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableResolvedMemberData withJoinedAt(String value) {
/*  336 */     String newValue = Objects.<String>requireNonNull(value, "joinedAt");
/*  337 */     if (this.joinedAt.equals(newValue)) return this; 
/*  338 */     return new ImmutableResolvedMemberData(this, 
/*      */         
/*  340 */         nick(), this.roles, newValue, 
/*      */ 
/*      */         
/*  343 */         premiumSince(), 
/*  344 */         pending(), 
/*  345 */         permissions(), 
/*  346 */         communicationDisabledUntil(), this.flags);
/*      */   }
/*      */ 
/*      */   
/*      */   public ImmutableResolvedMemberData withPremiumSince(Possible<Optional<String>> value) {
/*  351 */     Possible<Optional<String>> newValue = Objects.<Possible<Optional<String>>>requireNonNull(value);
/*  352 */     return new ImmutableResolvedMemberData(this, 
/*      */         
/*  354 */         nick(), this.roles, this.joinedAt, newValue, 
/*      */ 
/*      */ 
/*      */         
/*  358 */         pending(), 
/*  359 */         permissions(), 
/*  360 */         communicationDisabledUntil(), this.flags);
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public ImmutableResolvedMemberData withPremiumSince(@Nullable String value) {
/*  366 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/*  367 */     return new ImmutableResolvedMemberData(this, 
/*      */         
/*  369 */         nick(), this.roles, this.joinedAt, newValue, 
/*      */ 
/*      */ 
/*      */         
/*  373 */         pending(), 
/*  374 */         permissions(), 
/*  375 */         communicationDisabledUntil(), this.flags);
/*      */   }
/*      */ 
/*      */   
/*      */   public ImmutableResolvedMemberData withPremiumSinceOrNull(@Nullable String value) {
/*  380 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/*  381 */     return new ImmutableResolvedMemberData(this, 
/*      */         
/*  383 */         nick(), this.roles, this.joinedAt, newValue, 
/*      */ 
/*      */ 
/*      */         
/*  387 */         pending(), 
/*  388 */         permissions(), 
/*  389 */         communicationDisabledUntil(), this.flags);
/*      */   }
/*      */ 
/*      */   
/*      */   public ImmutableResolvedMemberData withPending(Possible<Boolean> value) {
/*  394 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/*  395 */     return new ImmutableResolvedMemberData(this, 
/*      */         
/*  397 */         nick(), this.roles, this.joinedAt, 
/*      */ 
/*      */         
/*  400 */         premiumSince(), newValue, 
/*      */         
/*  402 */         permissions(), 
/*  403 */         communicationDisabledUntil(), this.flags);
/*      */   }
/*      */ 
/*      */   
/*      */   public ImmutableResolvedMemberData withPending(Boolean value) {
/*  408 */     Possible<Boolean> newValue = Possible.of(value);
/*  409 */     return new ImmutableResolvedMemberData(this, 
/*      */         
/*  411 */         nick(), this.roles, this.joinedAt, 
/*      */ 
/*      */         
/*  414 */         premiumSince(), newValue, 
/*      */         
/*  416 */         permissions(), 
/*  417 */         communicationDisabledUntil(), this.flags);
/*      */   }
/*      */ 
/*      */   
/*      */   public ImmutableResolvedMemberData withPermissions(Possible<String> value) {
/*  422 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/*  423 */     return new ImmutableResolvedMemberData(this, 
/*      */         
/*  425 */         nick(), this.roles, this.joinedAt, 
/*      */ 
/*      */         
/*  428 */         premiumSince(), 
/*  429 */         pending(), newValue, 
/*      */         
/*  431 */         communicationDisabledUntil(), this.flags);
/*      */   }
/*      */ 
/*      */   
/*      */   public ImmutableResolvedMemberData withPermissions(String value) {
/*  436 */     Possible<String> newValue = Possible.of(value);
/*  437 */     return new ImmutableResolvedMemberData(this, 
/*      */         
/*  439 */         nick(), this.roles, this.joinedAt, 
/*      */ 
/*      */         
/*  442 */         premiumSince(), 
/*  443 */         pending(), newValue, 
/*      */         
/*  445 */         communicationDisabledUntil(), this.flags);
/*      */   }
/*      */ 
/*      */   
/*      */   public ImmutableResolvedMemberData withCommunicationDisabledUntil(Possible<Optional<String>> value) {
/*  450 */     Possible<Optional<String>> newValue = Objects.<Possible<Optional<String>>>requireNonNull(value);
/*  451 */     return new ImmutableResolvedMemberData(this, 
/*      */         
/*  453 */         nick(), this.roles, this.joinedAt, 
/*      */ 
/*      */         
/*  456 */         premiumSince(), 
/*  457 */         pending(), 
/*  458 */         permissions(), newValue, this.flags);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public ImmutableResolvedMemberData withCommunicationDisabledUntil(@Nullable String value) {
/*  465 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/*  466 */     return new ImmutableResolvedMemberData(this, 
/*      */         
/*  468 */         nick(), this.roles, this.joinedAt, 
/*      */ 
/*      */         
/*  471 */         premiumSince(), 
/*  472 */         pending(), 
/*  473 */         permissions(), newValue, this.flags);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutableResolvedMemberData withCommunicationDisabledUntilOrNull(@Nullable String value) {
/*  479 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/*  480 */     return new ImmutableResolvedMemberData(this, 
/*      */         
/*  482 */         nick(), this.roles, this.joinedAt, 
/*      */ 
/*      */         
/*  485 */         premiumSince(), 
/*  486 */         pending(), 
/*  487 */         permissions(), newValue, this.flags);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableResolvedMemberData withFlags(long value) {
/*  499 */     if (this.flags == value) return this; 
/*  500 */     return new ImmutableResolvedMemberData(this, 
/*      */         
/*  502 */         nick(), this.roles, this.joinedAt, 
/*      */ 
/*      */         
/*  505 */         premiumSince(), 
/*  506 */         pending(), 
/*  507 */         permissions(), 
/*  508 */         communicationDisabledUntil(), value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean equals(Object another) {
/*  518 */     if (this == another) return true; 
/*  519 */     return (another instanceof ImmutableResolvedMemberData && 
/*  520 */       equalTo(0, (ImmutableResolvedMemberData)another));
/*      */   }
/*      */   
/*      */   private boolean equalTo(int synthetic, ImmutableResolvedMemberData another) {
/*  524 */     return (nick().equals(another.nick()) && this.roles
/*  525 */       .equals(another.roles) && this.joinedAt
/*  526 */       .equals(another.joinedAt) && 
/*  527 */       premiumSince().equals(another.premiumSince()) && 
/*  528 */       pending().equals(another.pending()) && 
/*  529 */       permissions().equals(another.permissions()) && 
/*  530 */       communicationDisabledUntil().equals(another.communicationDisabledUntil()) && this.flags == another.flags);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int hashCode() {
/*  540 */     int h = 5381;
/*  541 */     h += (h << 5) + nick().hashCode();
/*  542 */     h += (h << 5) + this.roles.hashCode();
/*  543 */     h += (h << 5) + this.joinedAt.hashCode();
/*  544 */     h += (h << 5) + premiumSince().hashCode();
/*  545 */     h += (h << 5) + pending().hashCode();
/*  546 */     h += (h << 5) + permissions().hashCode();
/*  547 */     h += (h << 5) + communicationDisabledUntil().hashCode();
/*  548 */     h += (h << 5) + Long.hashCode(this.flags);
/*  549 */     return h;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/*  558 */     return "ResolvedMemberData{nick=" + 
/*  559 */       nick().toString() + ", roles=" + this.roles + ", joinedAt=" + this.joinedAt + ", premiumSince=" + 
/*      */ 
/*      */       
/*  562 */       premiumSince().toString() + ", pending=" + 
/*  563 */       pending().toString() + ", permissions=" + 
/*  564 */       permissions().toString() + ", communicationDisabledUntil=" + 
/*  565 */       communicationDisabledUntil().toString() + ", flags=" + this.flags + "}";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonDeserialize
/*      */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*      */   @Generated(from = "ResolvedMemberData", generator = "Immutables")
/*      */   static final class Json
/*      */     implements ResolvedMemberData
/*      */   {
/*  580 */     Possible<Optional<String>> nick = Possible.absent();
/*      */     
/*  582 */     List<String> roles = Collections.emptyList();
/*      */     
/*      */     String joinedAt;
/*  585 */     Possible<Optional<String>> premiumSince = Possible.absent();
/*      */ 
/*      */     
/*  588 */     Possible<Boolean> pending = Possible.absent();
/*      */ 
/*      */     
/*  591 */     Possible<String> permissions = Possible.absent();
/*      */ 
/*      */     
/*  594 */     Possible<Optional<String>> communicationDisabledUntil = Possible.absent();
/*      */     long flags;
/*      */     boolean flagsIsSet;
/*      */     
/*      */     @JsonProperty("nick")
/*      */     public void setNick(Possible<Optional<String>> nick) {
/*  600 */       this.nick = nick;
/*      */     }
/*      */     @JsonProperty("roles")
/*      */     public void setRoles(List<String> roles) {
/*  604 */       this.roles = roles;
/*      */     }
/*      */     @JsonProperty("joined_at")
/*      */     public void setJoinedAt(String joinedAt) {
/*  608 */       this.joinedAt = joinedAt;
/*      */     }
/*      */     @JsonProperty("premium_since")
/*      */     public void setPremiumSince(Possible<Optional<String>> premiumSince) {
/*  612 */       this.premiumSince = premiumSince;
/*      */     }
/*      */     @JsonProperty("pending")
/*      */     public void setPending(Possible<Boolean> pending) {
/*  616 */       this.pending = pending;
/*      */     }
/*      */     @JsonProperty("permissions")
/*      */     public void setPermissions(Possible<String> permissions) {
/*  620 */       this.permissions = permissions;
/*      */     }
/*      */     @JsonProperty("communication_disabled_until")
/*      */     public void setCommunicationDisabledUntil(Possible<Optional<String>> communicationDisabledUntil) {
/*  624 */       this.communicationDisabledUntil = communicationDisabledUntil;
/*      */     }
/*      */     @JsonProperty("flags")
/*      */     public void setFlags(long flags) {
/*  628 */       this.flags = flags;
/*  629 */       this.flagsIsSet = true;
/*      */     }
/*      */     public Possible<Optional<String>> nick() {
/*  632 */       throw new UnsupportedOperationException();
/*      */     } public List<String> roles() {
/*  634 */       throw new UnsupportedOperationException();
/*      */     } public String joinedAt() {
/*  636 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Optional<String>> premiumSince() {
/*  638 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Boolean> pending() {
/*  640 */       throw new UnsupportedOperationException();
/*      */     } public Possible<String> permissions() {
/*  642 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Optional<String>> communicationDisabledUntil() {
/*  644 */       throw new UnsupportedOperationException();
/*      */     } public long flags() {
/*  646 */       throw new UnsupportedOperationException();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*      */   static ImmutableResolvedMemberData fromJson(Json json) {
/*  657 */     Builder builder = builder();
/*  658 */     if (json.nick != null) {
/*  659 */       builder.nick(json.nick);
/*      */     }
/*  661 */     if (json.roles != null) {
/*  662 */       builder.addAllRoles(json.roles);
/*      */     }
/*  664 */     if (json.joinedAt != null) {
/*  665 */       builder.joinedAt(json.joinedAt);
/*      */     }
/*  667 */     if (json.premiumSince != null) {
/*  668 */       builder.premiumSince(json.premiumSince);
/*      */     }
/*  670 */     if (json.pending != null) {
/*  671 */       builder.pending(json.pending);
/*      */     }
/*  673 */     if (json.permissions != null) {
/*  674 */       builder.permissions(json.permissions);
/*      */     }
/*  676 */     if (json.communicationDisabledUntil != null) {
/*  677 */       builder.communicationDisabledUntil(json.communicationDisabledUntil);
/*      */     }
/*  679 */     if (json.flagsIsSet) {
/*  680 */       builder.flags(json.flags);
/*      */     }
/*  682 */     return builder.build();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableResolvedMemberData of(Possible<Optional<String>> nick, List<String> roles, String joinedAt, Possible<Optional<String>> premiumSince, Possible<Boolean> pending, Possible<String> permissions, Possible<Optional<String>> communicationDisabledUntil, long flags) {
/*  698 */     return of(nick, roles, joinedAt, premiumSince, pending, permissions, communicationDisabledUntil, flags);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableResolvedMemberData of(Possible<Optional<String>> nick, Iterable<String> roles, String joinedAt, Possible<Optional<String>> premiumSince, Possible<Boolean> pending, Possible<String> permissions, Possible<Optional<String>> communicationDisabledUntil, long flags) {
/*  714 */     return new ImmutableResolvedMemberData(nick, roles, joinedAt, premiumSince, pending, permissions, communicationDisabledUntil, flags);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableResolvedMemberData copyOf(ResolvedMemberData instance) {
/*  725 */     if (instance instanceof ImmutableResolvedMemberData) {
/*  726 */       return (ImmutableResolvedMemberData)instance;
/*      */     }
/*  728 */     return builder()
/*  729 */       .from(instance)
/*  730 */       .build();
/*      */   }
/*      */   
/*      */   public boolean isNickPresent() {
/*  734 */     return !this.nick_absent;
/*      */   }
/*      */   
/*      */   public String nickOrElse(String defaultValue) {
/*  738 */     return !this.nick_absent ? this.nick_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isPremiumSincePresent() {
/*  742 */     return !this.premiumSince_absent;
/*      */   }
/*      */   
/*      */   public String premiumSinceOrElse(String defaultValue) {
/*  746 */     return !this.premiumSince_absent ? this.premiumSince_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isPendingPresent() {
/*  750 */     return !this.pending_absent;
/*      */   }
/*      */   
/*      */   public Boolean pendingOrElse(Boolean defaultValue) {
/*  754 */     return !this.pending_absent ? this.pending_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isPermissionsPresent() {
/*  758 */     return !this.permissions_absent;
/*      */   }
/*      */   
/*      */   public String permissionsOrElse(String defaultValue) {
/*  762 */     return !this.permissions_absent ? this.permissions_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isCommunicationDisabledUntilPresent() {
/*  766 */     return !this.communicationDisabledUntil_absent;
/*      */   }
/*      */   
/*      */   public String communicationDisabledUntilOrElse(String defaultValue) {
/*  770 */     return !this.communicationDisabledUntil_absent ? this.communicationDisabledUntil_value : defaultValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Builder builder() {
/*  790 */     return new Builder();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   @Generated(from = "ResolvedMemberData", generator = "Immutables")
/*      */   public static final class Builder
/*      */   {
/*      */     private static final long INIT_BIT_JOINED_AT = 1L;
/*      */ 
/*      */     
/*      */     private static final long OPT_BIT_FLAGS = 1L;
/*      */ 
/*      */     
/*  804 */     private long initBits = 1L;
/*      */     
/*      */     private long optBits;
/*  807 */     private Possible<Optional<String>> nick_possible = Possible.absent();
/*  808 */     private Possible<Optional<String>> premiumSince_possible = Possible.absent();
/*  809 */     private Possible<Boolean> pending_possible = Possible.absent();
/*  810 */     private Possible<String> permissions_possible = Possible.absent();
/*  811 */     private Possible<Optional<String>> communicationDisabledUntil_possible = Possible.absent();
/*  812 */     private List<String> roles = new ArrayList<>();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private String joinedAt;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private long flags;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder from(ResolvedMemberData instance) {
/*  828 */       Objects.requireNonNull(instance, "instance");
/*  829 */       nick(instance.nick());
/*  830 */       addAllRoles(instance.roles());
/*  831 */       joinedAt(instance.joinedAt());
/*  832 */       premiumSince(instance.premiumSince());
/*  833 */       pending(instance.pending());
/*  834 */       permissions(instance.permissions());
/*  835 */       communicationDisabledUntil(instance.communicationDisabledUntil());
/*  836 */       flags(instance.flags());
/*  837 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("nick")
/*      */     public Builder nick(Possible<Optional<String>> value) {
/*  842 */       this.nick_possible = value;
/*  843 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public Builder nick(@Nullable String value) {
/*  848 */       this.nick_possible = Possible.of(Optional.ofNullable(value));
/*  849 */       return this;
/*      */     }
/*      */     
/*      */     public Builder nickOrNull(@Nullable String value) {
/*  853 */       this.nick_possible = Possible.of(Optional.ofNullable(value));
/*  854 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addRole(String element) {
/*  863 */       this.roles.add(Objects.<String>requireNonNull(element, "roles element"));
/*  864 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addRoles(String... elements) {
/*  873 */       for (String element : elements) {
/*  874 */         this.roles.add(Objects.<String>requireNonNull(element, "roles element"));
/*      */       }
/*  876 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("roles")
/*      */     public final Builder roles(Iterable<String> elements) {
/*  887 */       this.roles.clear();
/*  888 */       return addAllRoles(elements);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addAllRoles(Iterable<String> elements) {
/*  897 */       for (String element : elements) {
/*  898 */         this.roles.add(Objects.<String>requireNonNull(element, "roles element"));
/*      */       }
/*  900 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("joined_at")
/*      */     public final Builder joinedAt(String joinedAt) {
/*  910 */       this.joinedAt = Objects.<String>requireNonNull(joinedAt, "joinedAt");
/*  911 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/*  912 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("premium_since")
/*      */     public Builder premiumSince(Possible<Optional<String>> value) {
/*  917 */       this.premiumSince_possible = value;
/*  918 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public Builder premiumSince(@Nullable String value) {
/*  923 */       this.premiumSince_possible = Possible.of(Optional.ofNullable(value));
/*  924 */       return this;
/*      */     }
/*      */     
/*      */     public Builder premiumSinceOrNull(@Nullable String value) {
/*  928 */       this.premiumSince_possible = Possible.of(Optional.ofNullable(value));
/*  929 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("pending")
/*      */     public Builder pending(Possible<Boolean> value) {
/*  934 */       this.pending_possible = value;
/*  935 */       return this;
/*      */     }
/*      */     
/*      */     public Builder pending(Boolean value) {
/*  939 */       this.pending_possible = Possible.of(value);
/*  940 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("permissions")
/*      */     public Builder permissions(Possible<String> value) {
/*  945 */       this.permissions_possible = value;
/*  946 */       return this;
/*      */     }
/*      */     
/*      */     public Builder permissions(String value) {
/*  950 */       this.permissions_possible = Possible.of(value);
/*  951 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("communication_disabled_until")
/*      */     public Builder communicationDisabledUntil(Possible<Optional<String>> value) {
/*  956 */       this.communicationDisabledUntil_possible = value;
/*  957 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public Builder communicationDisabledUntil(@Nullable String value) {
/*  962 */       this.communicationDisabledUntil_possible = Possible.of(Optional.ofNullable(value));
/*  963 */       return this;
/*      */     }
/*      */     
/*      */     public Builder communicationDisabledUntilOrNull(@Nullable String value) {
/*  967 */       this.communicationDisabledUntil_possible = Possible.of(Optional.ofNullable(value));
/*  968 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("flags")
/*      */     public final Builder flags(long flags) {
/*  979 */       this.flags = flags;
/*  980 */       this.optBits |= 0x1L;
/*  981 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ImmutableResolvedMemberData build() {
/*  990 */       if (this.initBits != 0L) {
/*  991 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*      */       }
/*  993 */       return new ImmutableResolvedMemberData(this);
/*      */     }
/*      */     
/*      */     private boolean flagsIsSet() {
/*  997 */       return ((this.optBits & 0x1L) != 0L);
/*      */     }
/*      */     
/*      */     private String formatRequiredAttributesMessage() {
/* 1001 */       List<String> attributes = new ArrayList<>();
/* 1002 */       if ((this.initBits & 0x1L) != 0L) attributes.add("joinedAt"); 
/* 1003 */       return "Cannot build ResolvedMemberData, some of required attributes are not set " + attributes;
/*      */     }
/*      */     
/*      */     private Possible<Optional<String>> nick_build() {
/* 1007 */       return this.nick_possible;
/*      */     }
/*      */     
/*      */     private Possible<Optional<String>> premiumSince_build() {
/* 1011 */       return this.premiumSince_possible;
/*      */     }
/*      */     
/*      */     private Possible<Boolean> pending_build() {
/* 1015 */       return this.pending_possible;
/*      */     }
/*      */     
/*      */     private Possible<String> permissions_build() {
/* 1019 */       return this.permissions_possible;
/*      */     }
/*      */     
/*      */     private Possible<Optional<String>> communicationDisabledUntil_build() {
/* 1023 */       return this.communicationDisabledUntil_possible;
/*      */     }
/*      */     private Builder() {} }
/*      */   
/*      */   private static <T> List<T> createSafeList(Iterable<? extends T> iterable, boolean checkNulls, boolean skipNulls) {
/*      */     ArrayList<T> list;
/* 1029 */     if (iterable instanceof Collection) {
/* 1030 */       int size = ((Collection)iterable).size();
/* 1031 */       if (size == 0) return Collections.emptyList(); 
/* 1032 */       list = new ArrayList<>();
/*      */     } else {
/* 1034 */       list = new ArrayList<>();
/*      */     } 
/* 1036 */     for (T element : iterable) {
/* 1037 */       if (skipNulls && element == null)
/* 1038 */         continue;  if (checkNulls) Objects.requireNonNull(element, "element"); 
/* 1039 */       list.add(element);
/*      */     } 
/* 1041 */     return list;
/*      */   }
/*      */   
/*      */   private static <T> List<T> createUnmodifiableList(boolean clone, List<T> list) {
/* 1045 */     switch (list.size()) { case 0:
/* 1046 */         return Collections.emptyList();
/* 1047 */       case 1: return Collections.singletonList(list.get(0)); }
/*      */     
/* 1049 */     if (clone) {
/* 1050 */       return Collections.unmodifiableList(new ArrayList<>(list));
/*      */     }
/* 1052 */     if (list instanceof ArrayList) {
/* 1053 */       ((ArrayList)list).trimToSize();
/*      */     }
/* 1055 */     return Collections.unmodifiableList(list);
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableResolvedMemberData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */