/*      */ package discord4j.discordjson.json;
/*      */ 
/*      */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*      */ import com.fasterxml.jackson.annotation.JsonCreator;
/*      */ import com.fasterxml.jackson.annotation.JsonProperty;
/*      */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*      */ import discord4j.discordjson.Id;
/*      */ import discord4j.discordjson.possible.Possible;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.List;
/*      */ import java.util.Objects;
/*      */ import java.util.Optional;
/*      */ import java.util.stream.Collectors;
/*      */ import java.util.stream.StreamSupport;
/*      */ import org.immutables.value.Generated;
/*      */ import reactor.util.annotation.Nullable;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ @Generated(from = "PartialMessageData", generator = "Immutables")
/*      */ public final class ImmutablePartialMessageData
/*      */   implements PartialMessageData
/*      */ {
/*      */   private final long id_value;
/*      */   private final long channelId_value;
/*      */   private final long guildId_value;
/*      */   private final boolean guildId_absent;
/*      */   private final UserData author_value;
/*      */   private final boolean author_absent;
/*      */   private final PartialMemberData member_value;
/*      */   private final boolean member_absent;
/*      */   private final String content_value;
/*      */   private final boolean content_absent;
/*      */   private final String timestamp_value;
/*      */   private final boolean timestamp_absent;
/*      */   private final String editedTimestamp;
/*      */   private final Boolean tts_value;
/*      */   private final boolean tts_absent;
/*      */   private final Boolean mentionEveryone_value;
/*      */   private final boolean mentionEveryone_absent;
/*      */   private final List<UserWithMemberData> mentions;
/*      */   private final List<String> mentionRoles;
/*      */   private final List<ChannelMentionData> mentionChannels_value;
/*      */   private final boolean mentionChannels_absent;
/*      */   private final List<AttachmentData> attachments;
/*      */   private final List<EmbedData> embeds;
/*      */   private final List<ReactionData> reactions_value;
/*      */   private final boolean reactions_absent;
/*      */   private final Object nonce_value;
/*      */   private final boolean nonce_absent;
/*      */   private final Boolean pinned_value;
/*      */   private final boolean pinned_absent;
/*      */   private final long webhookId_value;
/*      */   private final boolean webhookId_absent;
/*      */   private final Integer type_value;
/*      */   private final boolean type_absent;
/*      */   private final MessageActivityData activity_value;
/*      */   private final boolean activity_absent;
/*      */   private final MessageApplicationData application_value;
/*      */   private final boolean application_absent;
/*      */   private final MessageReferenceData messageReference_value;
/*      */   private final boolean messageReference_absent;
/*      */   private final Integer flags_value;
/*      */   private final boolean flags_absent;
/*      */   private final List<StickerData> stickers_value;
/*      */   private final boolean stickers_absent;
/*      */   private final List<PartialStickerData> stickerItems_value;
/*      */   private final boolean stickerItems_absent;
/*      */   private final MessageData referencedMessage_value;
/*      */   private final boolean referencedMessage_absent;
/*      */   private final MessageInteractionData interaction_value;
/*      */   private final boolean interaction_absent;
/*      */   private static final byte STAGE_INITIALIZING = -1;
/*      */   private static final byte STAGE_UNINITIALIZED = 0;
/*      */   private static final byte STAGE_INITIALIZED = 1;
/*      */   
/*      */   private ImmutablePartialMessageData(Id id, Id channelId, Possible<Id> guildId, Possible<UserData> author, Possible<PartialMemberData> member, Possible<String> content, Possible<String> timestamp, Optional<String> editedTimestamp, Possible<Boolean> tts, Possible<Boolean> mentionEveryone, Iterable<? extends UserWithMemberData> mentions, Iterable<String> mentionRoles, Possible<List<ChannelMentionData>> mentionChannels, Iterable<? extends AttachmentData> attachments, Iterable<? extends EmbedData> embeds, Possible<List<ReactionData>> reactions, Possible<Object> nonce, Possible<Boolean> pinned, Possible<Id> webhookId, Possible<Integer> type, Possible<MessageActivityData> activity, Possible<MessageApplicationData> application, Possible<MessageReferenceData> messageReference, Possible<Integer> flags, Possible<List<StickerData>> stickers, Possible<List<PartialStickerData>> stickerItems, Possible<Optional<MessageData>> referencedMessage, Possible<MessageInteractionData> interaction) {
/*  112 */     Id id$impl = id;
/*  113 */     Id channelId$impl = channelId;
/*  114 */     Possible<Id> guildId$impl = guildId;
/*  115 */     Possible<UserData> author$impl = author;
/*  116 */     Possible<PartialMemberData> member$impl = member;
/*  117 */     Possible<String> content$impl = content;
/*  118 */     Possible<String> timestamp$impl = timestamp;
/*  119 */     this.editedTimestamp = editedTimestamp.orElse(null);
/*  120 */     Possible<Boolean> tts$impl = tts;
/*  121 */     Possible<Boolean> mentionEveryone$impl = mentionEveryone;
/*  122 */     this.mentions = createUnmodifiableList(false, createSafeList(mentions, true, false));
/*  123 */     this.mentionRoles = createUnmodifiableList(false, createSafeList(mentionRoles, true, false));
/*  124 */     Possible<List<ChannelMentionData>> mentionChannels$impl = mentionChannels;
/*  125 */     this.attachments = createUnmodifiableList(false, createSafeList(attachments, true, false));
/*  126 */     this.embeds = createUnmodifiableList(false, createSafeList(embeds, true, false));
/*  127 */     Possible<List<ReactionData>> reactions$impl = reactions;
/*  128 */     Possible<Object> nonce$impl = nonce;
/*  129 */     Possible<Boolean> pinned$impl = pinned;
/*  130 */     Possible<Id> webhookId$impl = webhookId;
/*  131 */     Possible<Integer> type$impl = type;
/*  132 */     Possible<MessageActivityData> activity$impl = activity;
/*  133 */     Possible<MessageApplicationData> application$impl = application;
/*  134 */     Possible<MessageReferenceData> messageReference$impl = messageReference;
/*  135 */     Possible<Integer> flags$impl = flags;
/*  136 */     Possible<List<StickerData>> stickers$impl = stickers;
/*  137 */     Possible<List<PartialStickerData>> stickerItems$impl = stickerItems;
/*  138 */     Possible<Optional<MessageData>> referencedMessage$impl = referencedMessage;
/*  139 */     Possible<MessageInteractionData> interaction$impl = interaction;
/*  140 */     this.id_value = id$impl.asLong();
/*  141 */     this.channelId_value = channelId$impl.asLong();
/*  142 */     this
/*      */       
/*  144 */       .guildId_value = ((Long)guildId$impl.toOptional().map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  145 */     this.guildId_absent = guildId$impl.isAbsent();
/*  146 */     this.author_value = author$impl.toOptional().orElse(null);
/*  147 */     this.author_absent = author$impl.isAbsent();
/*  148 */     this.member_value = member$impl.toOptional().orElse(null);
/*  149 */     this.member_absent = member$impl.isAbsent();
/*  150 */     this.content_value = content$impl.toOptional().orElse(null);
/*  151 */     this.content_absent = content$impl.isAbsent();
/*  152 */     this.timestamp_value = timestamp$impl.toOptional().orElse(null);
/*  153 */     this.timestamp_absent = timestamp$impl.isAbsent();
/*  154 */     this.tts_value = tts$impl.toOptional().orElse(null);
/*  155 */     this.tts_absent = tts$impl.isAbsent();
/*  156 */     this.mentionEveryone_value = mentionEveryone$impl.toOptional().orElse(null);
/*  157 */     this.mentionEveryone_absent = mentionEveryone$impl.isAbsent();
/*  158 */     this.mentionChannels_value = mentionChannels$impl.toOptional().orElse(null);
/*  159 */     this.mentionChannels_absent = mentionChannels$impl.isAbsent();
/*  160 */     this.reactions_value = reactions$impl.toOptional().orElse(null);
/*  161 */     this.reactions_absent = reactions$impl.isAbsent();
/*  162 */     this.nonce_value = nonce$impl.toOptional().orElse(null);
/*  163 */     this.nonce_absent = nonce$impl.isAbsent();
/*  164 */     this.pinned_value = pinned$impl.toOptional().orElse(null);
/*  165 */     this.pinned_absent = pinned$impl.isAbsent();
/*  166 */     this
/*      */       
/*  168 */       .webhookId_value = ((Long)webhookId$impl.toOptional().map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  169 */     this.webhookId_absent = webhookId$impl.isAbsent();
/*  170 */     this.type_value = type$impl.toOptional().orElse(null);
/*  171 */     this.type_absent = type$impl.isAbsent();
/*  172 */     this.activity_value = activity$impl.toOptional().orElse(null);
/*  173 */     this.activity_absent = activity$impl.isAbsent();
/*  174 */     this.application_value = application$impl.toOptional().orElse(null);
/*  175 */     this.application_absent = application$impl.isAbsent();
/*  176 */     this.messageReference_value = messageReference$impl.toOptional().orElse(null);
/*  177 */     this.messageReference_absent = messageReference$impl.isAbsent();
/*  178 */     this.flags_value = flags$impl.toOptional().orElse(null);
/*  179 */     this.flags_absent = flags$impl.isAbsent();
/*  180 */     this.stickers_value = stickers$impl.toOptional().orElse(null);
/*  181 */     this.stickers_absent = stickers$impl.isAbsent();
/*  182 */     this.stickerItems_value = stickerItems$impl.toOptional().orElse(null);
/*  183 */     this.stickerItems_absent = stickerItems$impl.isAbsent();
/*  184 */     this.referencedMessage_value = Possible.flatOpt(referencedMessage$impl).orElse(null);
/*  185 */     this.referencedMessage_absent = referencedMessage$impl.isAbsent();
/*  186 */     this.interaction_value = interaction$impl.toOptional().orElse(null);
/*  187 */     this.interaction_absent = interaction$impl.isAbsent();
/*  188 */     this.initShim = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ImmutablePartialMessageData(ImmutablePartialMessageData original, Id id, Id channelId, Possible<Id> guildId, Possible<UserData> author, Possible<PartialMemberData> member, Possible<String> content, Possible<String> timestamp, String editedTimestamp, Possible<Boolean> tts, Possible<Boolean> mentionEveryone, List<UserWithMemberData> mentions, List<String> mentionRoles, Possible<List<ChannelMentionData>> mentionChannels, List<AttachmentData> attachments, List<EmbedData> embeds, Possible<List<ReactionData>> reactions, Possible<Object> nonce, Possible<Boolean> pinned, Possible<Id> webhookId, Possible<Integer> type, Possible<MessageActivityData> activity, Possible<MessageApplicationData> application, Possible<MessageReferenceData> messageReference, Possible<Integer> flags, Possible<List<StickerData>> stickers, Possible<List<PartialStickerData>> stickerItems, Possible<Optional<MessageData>> referencedMessage, Possible<MessageInteractionData> interaction) {
/*  221 */     Id id$impl = id;
/*  222 */     Id channelId$impl = channelId;
/*  223 */     Possible<Id> guildId$impl = guildId;
/*  224 */     Possible<UserData> author$impl = author;
/*  225 */     Possible<PartialMemberData> member$impl = member;
/*  226 */     Possible<String> content$impl = content;
/*  227 */     Possible<String> timestamp$impl = timestamp;
/*  228 */     this.editedTimestamp = editedTimestamp;
/*  229 */     Possible<Boolean> tts$impl = tts;
/*  230 */     Possible<Boolean> mentionEveryone$impl = mentionEveryone;
/*  231 */     this.mentions = mentions;
/*  232 */     this.mentionRoles = mentionRoles;
/*  233 */     Possible<List<ChannelMentionData>> mentionChannels$impl = mentionChannels;
/*  234 */     this.attachments = attachments;
/*  235 */     this.embeds = embeds;
/*  236 */     Possible<List<ReactionData>> reactions$impl = reactions;
/*  237 */     Possible<Object> nonce$impl = nonce;
/*  238 */     Possible<Boolean> pinned$impl = pinned;
/*  239 */     Possible<Id> webhookId$impl = webhookId;
/*  240 */     Possible<Integer> type$impl = type;
/*  241 */     Possible<MessageActivityData> activity$impl = activity;
/*  242 */     Possible<MessageApplicationData> application$impl = application;
/*  243 */     Possible<MessageReferenceData> messageReference$impl = messageReference;
/*  244 */     Possible<Integer> flags$impl = flags;
/*  245 */     Possible<List<StickerData>> stickers$impl = stickers;
/*  246 */     Possible<List<PartialStickerData>> stickerItems$impl = stickerItems;
/*  247 */     Possible<Optional<MessageData>> referencedMessage$impl = referencedMessage;
/*  248 */     Possible<MessageInteractionData> interaction$impl = interaction;
/*  249 */     this.id_value = id$impl.asLong();
/*  250 */     this.channelId_value = channelId$impl.asLong();
/*  251 */     this
/*      */       
/*  253 */       .guildId_value = ((Long)guildId$impl.toOptional().map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  254 */     this.guildId_absent = guildId$impl.isAbsent();
/*  255 */     this.author_value = author$impl.toOptional().orElse(null);
/*  256 */     this.author_absent = author$impl.isAbsent();
/*  257 */     this.member_value = member$impl.toOptional().orElse(null);
/*  258 */     this.member_absent = member$impl.isAbsent();
/*  259 */     this.content_value = content$impl.toOptional().orElse(null);
/*  260 */     this.content_absent = content$impl.isAbsent();
/*  261 */     this.timestamp_value = timestamp$impl.toOptional().orElse(null);
/*  262 */     this.timestamp_absent = timestamp$impl.isAbsent();
/*  263 */     this.tts_value = tts$impl.toOptional().orElse(null);
/*  264 */     this.tts_absent = tts$impl.isAbsent();
/*  265 */     this.mentionEveryone_value = mentionEveryone$impl.toOptional().orElse(null);
/*  266 */     this.mentionEveryone_absent = mentionEveryone$impl.isAbsent();
/*  267 */     this.mentionChannels_value = mentionChannels$impl.toOptional().orElse(null);
/*  268 */     this.mentionChannels_absent = mentionChannels$impl.isAbsent();
/*  269 */     this.reactions_value = reactions$impl.toOptional().orElse(null);
/*  270 */     this.reactions_absent = reactions$impl.isAbsent();
/*  271 */     this.nonce_value = nonce$impl.toOptional().orElse(null);
/*  272 */     this.nonce_absent = nonce$impl.isAbsent();
/*  273 */     this.pinned_value = pinned$impl.toOptional().orElse(null);
/*  274 */     this.pinned_absent = pinned$impl.isAbsent();
/*  275 */     this
/*      */       
/*  277 */       .webhookId_value = ((Long)webhookId$impl.toOptional().map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  278 */     this.webhookId_absent = webhookId$impl.isAbsent();
/*  279 */     this.type_value = type$impl.toOptional().orElse(null);
/*  280 */     this.type_absent = type$impl.isAbsent();
/*  281 */     this.activity_value = activity$impl.toOptional().orElse(null);
/*  282 */     this.activity_absent = activity$impl.isAbsent();
/*  283 */     this.application_value = application$impl.toOptional().orElse(null);
/*  284 */     this.application_absent = application$impl.isAbsent();
/*  285 */     this.messageReference_value = messageReference$impl.toOptional().orElse(null);
/*  286 */     this.messageReference_absent = messageReference$impl.isAbsent();
/*  287 */     this.flags_value = flags$impl.toOptional().orElse(null);
/*  288 */     this.flags_absent = flags$impl.isAbsent();
/*  289 */     this.stickers_value = stickers$impl.toOptional().orElse(null);
/*  290 */     this.stickers_absent = stickers$impl.isAbsent();
/*  291 */     this.stickerItems_value = stickerItems$impl.toOptional().orElse(null);
/*  292 */     this.stickerItems_absent = stickerItems$impl.isAbsent();
/*  293 */     this.referencedMessage_value = Possible.flatOpt(referencedMessage$impl).orElse(null);
/*  294 */     this.referencedMessage_absent = referencedMessage$impl.isAbsent();
/*  295 */     this.interaction_value = interaction$impl.toOptional().orElse(null);
/*  296 */     this.interaction_absent = interaction$impl.isAbsent();
/*  297 */     this.initShim = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  303 */   private volatile transient InitShim initShim = new InitShim();
/*      */   
/*      */   @Generated(from = "PartialMessageData", generator = "Immutables")
/*      */   private final class InitShim {
/*      */     private String formatInitCycleMessage() {
/*  308 */       List<String> attributes = new ArrayList<>();
/*  309 */       return "Cannot build PartialMessageData, attribute initializers form cycle " + attributes;
/*      */     }
/*      */ 
/*      */     
/*      */     private InitShim() {}
/*      */   }
/*      */ 
/*      */   
/*      */   @JsonProperty("id")
/*      */   public Id id() {
/*  319 */     return Id.of(this.id_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("channel_id")
/*      */   public Id channelId() {
/*  328 */     return Id.of(this.channelId_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("guild_id")
/*      */   public Possible<Id> guildId() {
/*  337 */     return this.guildId_absent ? Possible.absent() : 
/*  338 */       Possible.of(Id.of(this.guildId_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("author")
/*      */   public Possible<UserData> author() {
/*  347 */     return this.author_absent ? Possible.absent() : Possible.of(this.author_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("member")
/*      */   public Possible<PartialMemberData> member() {
/*  356 */     return this.member_absent ? Possible.absent() : Possible.of(this.member_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("content")
/*      */   public Possible<String> content() {
/*  365 */     return this.content_absent ? Possible.absent() : Possible.of(this.content_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("timestamp")
/*      */   public Possible<String> timestamp() {
/*  374 */     return this.timestamp_absent ? Possible.absent() : Possible.of(this.timestamp_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("edited_timestamp")
/*      */   public Optional<String> editedTimestamp() {
/*  383 */     return Optional.ofNullable(this.editedTimestamp);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("tts")
/*      */   public Possible<Boolean> tts() {
/*  392 */     return this.tts_absent ? Possible.absent() : Possible.of(this.tts_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("mention_everyone")
/*      */   public Possible<Boolean> mentionEveryone() {
/*  401 */     return this.mentionEveryone_absent ? Possible.absent() : Possible.of(this.mentionEveryone_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("mentions")
/*      */   public List<UserWithMemberData> mentions() {
/*  410 */     return this.mentions;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("mention_roles")
/*      */   public List<String> mentionRoles() {
/*  419 */     return this.mentionRoles;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("mention_channels")
/*      */   public Possible<List<ChannelMentionData>> mentionChannels() {
/*  428 */     return this.mentionChannels_absent ? Possible.absent() : 
/*  429 */       Possible.of(this.mentionChannels_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("attachments")
/*      */   public List<AttachmentData> attachments() {
/*  438 */     return this.attachments;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("embeds")
/*      */   public List<EmbedData> embeds() {
/*  447 */     return this.embeds;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("reactions")
/*      */   public Possible<List<ReactionData>> reactions() {
/*  456 */     return this.reactions_absent ? Possible.absent() : 
/*  457 */       Possible.of(this.reactions_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("nonce")
/*      */   public Possible<Object> nonce() {
/*  466 */     return this.nonce_absent ? Possible.absent() : Possible.of(this.nonce_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("pinned")
/*      */   public Possible<Boolean> pinned() {
/*  475 */     return this.pinned_absent ? Possible.absent() : Possible.of(this.pinned_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("webhook_id")
/*      */   public Possible<Id> webhookId() {
/*  484 */     return this.webhookId_absent ? Possible.absent() : 
/*  485 */       Possible.of(Id.of(this.webhookId_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("type")
/*      */   public Possible<Integer> type() {
/*  494 */     return this.type_absent ? Possible.absent() : Possible.of(this.type_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("activity")
/*      */   public Possible<MessageActivityData> activity() {
/*  503 */     return this.activity_absent ? Possible.absent() : Possible.of(this.activity_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("application")
/*      */   public Possible<MessageApplicationData> application() {
/*  512 */     return this.application_absent ? Possible.absent() : Possible.of(this.application_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("message_reference")
/*      */   public Possible<MessageReferenceData> messageReference() {
/*  521 */     return this.messageReference_absent ? Possible.absent() : Possible.of(this.messageReference_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("flags")
/*      */   public Possible<Integer> flags() {
/*  530 */     return this.flags_absent ? Possible.absent() : Possible.of(this.flags_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("stickers")
/*      */   @Deprecated
/*      */   public Possible<List<StickerData>> stickers() {
/*  540 */     return this.stickers_absent ? Possible.absent() : 
/*  541 */       Possible.of(this.stickers_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("sticker_items")
/*      */   public Possible<List<PartialStickerData>> stickerItems() {
/*  550 */     return this.stickerItems_absent ? Possible.absent() : 
/*  551 */       Possible.of(this.stickerItems_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("referenced_message")
/*      */   public Possible<Optional<MessageData>> referencedMessage() {
/*  560 */     return this.referencedMessage_absent ? Possible.absent() : 
/*  561 */       Possible.of(Optional.ofNullable(this.referencedMessage_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("interaction")
/*      */   public Possible<MessageInteractionData> interaction() {
/*  570 */     return this.interaction_absent ? Possible.absent() : Possible.of(this.interaction_value);
/*      */   }
/*      */   
/*      */   public ImmutablePartialMessageData withId(long value) {
/*  574 */     Id newValue = Id.of(value);
/*  575 */     return new ImmutablePartialMessageData(this, newValue, 
/*      */ 
/*      */         
/*  578 */         channelId(), 
/*  579 */         guildId(), 
/*  580 */         author(), 
/*  581 */         member(), 
/*  582 */         content(), 
/*  583 */         timestamp(), this.editedTimestamp, 
/*      */         
/*  585 */         tts(), 
/*  586 */         mentionEveryone(), this.mentions, this.mentionRoles, 
/*      */ 
/*      */         
/*  589 */         mentionChannels(), this.attachments, this.embeds, 
/*      */ 
/*      */         
/*  592 */         reactions(), 
/*  593 */         nonce(), 
/*  594 */         pinned(), 
/*  595 */         webhookId(), 
/*  596 */         type(), 
/*  597 */         activity(), 
/*  598 */         application(), 
/*  599 */         messageReference(), 
/*  600 */         flags(), 
/*  601 */         stickers(), 
/*  602 */         stickerItems(), 
/*  603 */         referencedMessage(), 
/*  604 */         interaction());
/*      */   }
/*      */   
/*      */   public ImmutablePartialMessageData withId(String value) {
/*  608 */     Id newValue = Id.of(value);
/*  609 */     return new ImmutablePartialMessageData(this, newValue, 
/*      */ 
/*      */         
/*  612 */         channelId(), 
/*  613 */         guildId(), 
/*  614 */         author(), 
/*  615 */         member(), 
/*  616 */         content(), 
/*  617 */         timestamp(), this.editedTimestamp, 
/*      */         
/*  619 */         tts(), 
/*  620 */         mentionEveryone(), this.mentions, this.mentionRoles, 
/*      */ 
/*      */         
/*  623 */         mentionChannels(), this.attachments, this.embeds, 
/*      */ 
/*      */         
/*  626 */         reactions(), 
/*  627 */         nonce(), 
/*  628 */         pinned(), 
/*  629 */         webhookId(), 
/*  630 */         type(), 
/*  631 */         activity(), 
/*  632 */         application(), 
/*  633 */         messageReference(), 
/*  634 */         flags(), 
/*  635 */         stickers(), 
/*  636 */         stickerItems(), 
/*  637 */         referencedMessage(), 
/*  638 */         interaction());
/*      */   }
/*      */   
/*      */   public ImmutablePartialMessageData withChannelId(long value) {
/*  642 */     Id newValue = Id.of(value);
/*  643 */     return new ImmutablePartialMessageData(this, 
/*      */         
/*  645 */         id(), newValue, 
/*      */         
/*  647 */         guildId(), 
/*  648 */         author(), 
/*  649 */         member(), 
/*  650 */         content(), 
/*  651 */         timestamp(), this.editedTimestamp, 
/*      */         
/*  653 */         tts(), 
/*  654 */         mentionEveryone(), this.mentions, this.mentionRoles, 
/*      */ 
/*      */         
/*  657 */         mentionChannels(), this.attachments, this.embeds, 
/*      */ 
/*      */         
/*  660 */         reactions(), 
/*  661 */         nonce(), 
/*  662 */         pinned(), 
/*  663 */         webhookId(), 
/*  664 */         type(), 
/*  665 */         activity(), 
/*  666 */         application(), 
/*  667 */         messageReference(), 
/*  668 */         flags(), 
/*  669 */         stickers(), 
/*  670 */         stickerItems(), 
/*  671 */         referencedMessage(), 
/*  672 */         interaction());
/*      */   }
/*      */   
/*      */   public ImmutablePartialMessageData withChannelId(String value) {
/*  676 */     Id newValue = Id.of(value);
/*  677 */     return new ImmutablePartialMessageData(this, 
/*      */         
/*  679 */         id(), newValue, 
/*      */         
/*  681 */         guildId(), 
/*  682 */         author(), 
/*  683 */         member(), 
/*  684 */         content(), 
/*  685 */         timestamp(), this.editedTimestamp, 
/*      */         
/*  687 */         tts(), 
/*  688 */         mentionEveryone(), this.mentions, this.mentionRoles, 
/*      */ 
/*      */         
/*  691 */         mentionChannels(), this.attachments, this.embeds, 
/*      */ 
/*      */         
/*  694 */         reactions(), 
/*  695 */         nonce(), 
/*  696 */         pinned(), 
/*  697 */         webhookId(), 
/*  698 */         type(), 
/*  699 */         activity(), 
/*  700 */         application(), 
/*  701 */         messageReference(), 
/*  702 */         flags(), 
/*  703 */         stickers(), 
/*  704 */         stickerItems(), 
/*  705 */         referencedMessage(), 
/*  706 */         interaction());
/*      */   }
/*      */   
/*      */   public ImmutablePartialMessageData withGuildId(Possible<Id> value) {
/*  710 */     Possible<Id> newValue = Objects.<Possible<Id>>requireNonNull(value);
/*  711 */     return new ImmutablePartialMessageData(this, 
/*      */         
/*  713 */         id(), 
/*  714 */         channelId(), newValue, 
/*      */         
/*  716 */         author(), 
/*  717 */         member(), 
/*  718 */         content(), 
/*  719 */         timestamp(), this.editedTimestamp, 
/*      */         
/*  721 */         tts(), 
/*  722 */         mentionEveryone(), this.mentions, this.mentionRoles, 
/*      */ 
/*      */         
/*  725 */         mentionChannels(), this.attachments, this.embeds, 
/*      */ 
/*      */         
/*  728 */         reactions(), 
/*  729 */         nonce(), 
/*  730 */         pinned(), 
/*  731 */         webhookId(), 
/*  732 */         type(), 
/*  733 */         activity(), 
/*  734 */         application(), 
/*  735 */         messageReference(), 
/*  736 */         flags(), 
/*  737 */         stickers(), 
/*  738 */         stickerItems(), 
/*  739 */         referencedMessage(), 
/*  740 */         interaction());
/*      */   }
/*      */   
/*      */   public ImmutablePartialMessageData withGuildId(long value) {
/*  744 */     Possible<Id> newValue = Possible.of(Id.of(value));
/*  745 */     return new ImmutablePartialMessageData(this, 
/*      */         
/*  747 */         id(), 
/*  748 */         channelId(), newValue, 
/*      */         
/*  750 */         author(), 
/*  751 */         member(), 
/*  752 */         content(), 
/*  753 */         timestamp(), this.editedTimestamp, 
/*      */         
/*  755 */         tts(), 
/*  756 */         mentionEveryone(), this.mentions, this.mentionRoles, 
/*      */ 
/*      */         
/*  759 */         mentionChannels(), this.attachments, this.embeds, 
/*      */ 
/*      */         
/*  762 */         reactions(), 
/*  763 */         nonce(), 
/*  764 */         pinned(), 
/*  765 */         webhookId(), 
/*  766 */         type(), 
/*  767 */         activity(), 
/*  768 */         application(), 
/*  769 */         messageReference(), 
/*  770 */         flags(), 
/*  771 */         stickers(), 
/*  772 */         stickerItems(), 
/*  773 */         referencedMessage(), 
/*  774 */         interaction());
/*      */   }
/*      */   
/*      */   public ImmutablePartialMessageData withAuthor(Possible<UserData> value) {
/*  778 */     Possible<UserData> newValue = Objects.<Possible<UserData>>requireNonNull(value);
/*  779 */     return new ImmutablePartialMessageData(this, 
/*      */         
/*  781 */         id(), 
/*  782 */         channelId(), 
/*  783 */         guildId(), newValue, 
/*      */         
/*  785 */         member(), 
/*  786 */         content(), 
/*  787 */         timestamp(), this.editedTimestamp, 
/*      */         
/*  789 */         tts(), 
/*  790 */         mentionEveryone(), this.mentions, this.mentionRoles, 
/*      */ 
/*      */         
/*  793 */         mentionChannels(), this.attachments, this.embeds, 
/*      */ 
/*      */         
/*  796 */         reactions(), 
/*  797 */         nonce(), 
/*  798 */         pinned(), 
/*  799 */         webhookId(), 
/*  800 */         type(), 
/*  801 */         activity(), 
/*  802 */         application(), 
/*  803 */         messageReference(), 
/*  804 */         flags(), 
/*  805 */         stickers(), 
/*  806 */         stickerItems(), 
/*  807 */         referencedMessage(), 
/*  808 */         interaction());
/*      */   }
/*      */   
/*      */   public ImmutablePartialMessageData withAuthor(UserData value) {
/*  812 */     Possible<UserData> newValue = Possible.of(value);
/*  813 */     return new ImmutablePartialMessageData(this, 
/*      */         
/*  815 */         id(), 
/*  816 */         channelId(), 
/*  817 */         guildId(), newValue, 
/*      */         
/*  819 */         member(), 
/*  820 */         content(), 
/*  821 */         timestamp(), this.editedTimestamp, 
/*      */         
/*  823 */         tts(), 
/*  824 */         mentionEveryone(), this.mentions, this.mentionRoles, 
/*      */ 
/*      */         
/*  827 */         mentionChannels(), this.attachments, this.embeds, 
/*      */ 
/*      */         
/*  830 */         reactions(), 
/*  831 */         nonce(), 
/*  832 */         pinned(), 
/*  833 */         webhookId(), 
/*  834 */         type(), 
/*  835 */         activity(), 
/*  836 */         application(), 
/*  837 */         messageReference(), 
/*  838 */         flags(), 
/*  839 */         stickers(), 
/*  840 */         stickerItems(), 
/*  841 */         referencedMessage(), 
/*  842 */         interaction());
/*      */   }
/*      */   
/*      */   public ImmutablePartialMessageData withMember(Possible<PartialMemberData> value) {
/*  846 */     Possible<PartialMemberData> newValue = Objects.<Possible<PartialMemberData>>requireNonNull(value);
/*  847 */     return new ImmutablePartialMessageData(this, 
/*      */         
/*  849 */         id(), 
/*  850 */         channelId(), 
/*  851 */         guildId(), 
/*  852 */         author(), newValue, 
/*      */         
/*  854 */         content(), 
/*  855 */         timestamp(), this.editedTimestamp, 
/*      */         
/*  857 */         tts(), 
/*  858 */         mentionEveryone(), this.mentions, this.mentionRoles, 
/*      */ 
/*      */         
/*  861 */         mentionChannels(), this.attachments, this.embeds, 
/*      */ 
/*      */         
/*  864 */         reactions(), 
/*  865 */         nonce(), 
/*  866 */         pinned(), 
/*  867 */         webhookId(), 
/*  868 */         type(), 
/*  869 */         activity(), 
/*  870 */         application(), 
/*  871 */         messageReference(), 
/*  872 */         flags(), 
/*  873 */         stickers(), 
/*  874 */         stickerItems(), 
/*  875 */         referencedMessage(), 
/*  876 */         interaction());
/*      */   }
/*      */   
/*      */   public ImmutablePartialMessageData withMember(PartialMemberData value) {
/*  880 */     Possible<PartialMemberData> newValue = Possible.of(value);
/*  881 */     return new ImmutablePartialMessageData(this, 
/*      */         
/*  883 */         id(), 
/*  884 */         channelId(), 
/*  885 */         guildId(), 
/*  886 */         author(), newValue, 
/*      */         
/*  888 */         content(), 
/*  889 */         timestamp(), this.editedTimestamp, 
/*      */         
/*  891 */         tts(), 
/*  892 */         mentionEveryone(), this.mentions, this.mentionRoles, 
/*      */ 
/*      */         
/*  895 */         mentionChannels(), this.attachments, this.embeds, 
/*      */ 
/*      */         
/*  898 */         reactions(), 
/*  899 */         nonce(), 
/*  900 */         pinned(), 
/*  901 */         webhookId(), 
/*  902 */         type(), 
/*  903 */         activity(), 
/*  904 */         application(), 
/*  905 */         messageReference(), 
/*  906 */         flags(), 
/*  907 */         stickers(), 
/*  908 */         stickerItems(), 
/*  909 */         referencedMessage(), 
/*  910 */         interaction());
/*      */   }
/*      */   
/*      */   public ImmutablePartialMessageData withContent(Possible<String> value) {
/*  914 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/*  915 */     return new ImmutablePartialMessageData(this, 
/*      */         
/*  917 */         id(), 
/*  918 */         channelId(), 
/*  919 */         guildId(), 
/*  920 */         author(), 
/*  921 */         member(), newValue, 
/*      */         
/*  923 */         timestamp(), this.editedTimestamp, 
/*      */         
/*  925 */         tts(), 
/*  926 */         mentionEveryone(), this.mentions, this.mentionRoles, 
/*      */ 
/*      */         
/*  929 */         mentionChannels(), this.attachments, this.embeds, 
/*      */ 
/*      */         
/*  932 */         reactions(), 
/*  933 */         nonce(), 
/*  934 */         pinned(), 
/*  935 */         webhookId(), 
/*  936 */         type(), 
/*  937 */         activity(), 
/*  938 */         application(), 
/*  939 */         messageReference(), 
/*  940 */         flags(), 
/*  941 */         stickers(), 
/*  942 */         stickerItems(), 
/*  943 */         referencedMessage(), 
/*  944 */         interaction());
/*      */   }
/*      */   
/*      */   public ImmutablePartialMessageData withContent(String value) {
/*  948 */     Possible<String> newValue = Possible.of(value);
/*  949 */     return new ImmutablePartialMessageData(this, 
/*      */         
/*  951 */         id(), 
/*  952 */         channelId(), 
/*  953 */         guildId(), 
/*  954 */         author(), 
/*  955 */         member(), newValue, 
/*      */         
/*  957 */         timestamp(), this.editedTimestamp, 
/*      */         
/*  959 */         tts(), 
/*  960 */         mentionEveryone(), this.mentions, this.mentionRoles, 
/*      */ 
/*      */         
/*  963 */         mentionChannels(), this.attachments, this.embeds, 
/*      */ 
/*      */         
/*  966 */         reactions(), 
/*  967 */         nonce(), 
/*  968 */         pinned(), 
/*  969 */         webhookId(), 
/*  970 */         type(), 
/*  971 */         activity(), 
/*  972 */         application(), 
/*  973 */         messageReference(), 
/*  974 */         flags(), 
/*  975 */         stickers(), 
/*  976 */         stickerItems(), 
/*  977 */         referencedMessage(), 
/*  978 */         interaction());
/*      */   }
/*      */   
/*      */   public ImmutablePartialMessageData withTimestamp(Possible<String> value) {
/*  982 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/*  983 */     return new ImmutablePartialMessageData(this, 
/*      */         
/*  985 */         id(), 
/*  986 */         channelId(), 
/*  987 */         guildId(), 
/*  988 */         author(), 
/*  989 */         member(), 
/*  990 */         content(), newValue, this.editedTimestamp, 
/*      */ 
/*      */         
/*  993 */         tts(), 
/*  994 */         mentionEveryone(), this.mentions, this.mentionRoles, 
/*      */ 
/*      */         
/*  997 */         mentionChannels(), this.attachments, this.embeds, 
/*      */ 
/*      */         
/* 1000 */         reactions(), 
/* 1001 */         nonce(), 
/* 1002 */         pinned(), 
/* 1003 */         webhookId(), 
/* 1004 */         type(), 
/* 1005 */         activity(), 
/* 1006 */         application(), 
/* 1007 */         messageReference(), 
/* 1008 */         flags(), 
/* 1009 */         stickers(), 
/* 1010 */         stickerItems(), 
/* 1011 */         referencedMessage(), 
/* 1012 */         interaction());
/*      */   }
/*      */   
/*      */   public ImmutablePartialMessageData withTimestamp(String value) {
/* 1016 */     Possible<String> newValue = Possible.of(value);
/* 1017 */     return new ImmutablePartialMessageData(this, 
/*      */         
/* 1019 */         id(), 
/* 1020 */         channelId(), 
/* 1021 */         guildId(), 
/* 1022 */         author(), 
/* 1023 */         member(), 
/* 1024 */         content(), newValue, this.editedTimestamp, 
/*      */ 
/*      */         
/* 1027 */         tts(), 
/* 1028 */         mentionEveryone(), this.mentions, this.mentionRoles, 
/*      */ 
/*      */         
/* 1031 */         mentionChannels(), this.attachments, this.embeds, 
/*      */ 
/*      */         
/* 1034 */         reactions(), 
/* 1035 */         nonce(), 
/* 1036 */         pinned(), 
/* 1037 */         webhookId(), 
/* 1038 */         type(), 
/* 1039 */         activity(), 
/* 1040 */         application(), 
/* 1041 */         messageReference(), 
/* 1042 */         flags(), 
/* 1043 */         stickers(), 
/* 1044 */         stickerItems(), 
/* 1045 */         referencedMessage(), 
/* 1046 */         interaction());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutablePartialMessageData withEditedTimestamp(String value) {
/* 1055 */     String newValue = Objects.<String>requireNonNull(value, "editedTimestamp");
/* 1056 */     if (Objects.equals(this.editedTimestamp, newValue)) return this; 
/* 1057 */     return new ImmutablePartialMessageData(this, 
/*      */         
/* 1059 */         id(), 
/* 1060 */         channelId(), 
/* 1061 */         guildId(), 
/* 1062 */         author(), 
/* 1063 */         member(), 
/* 1064 */         content(), 
/* 1065 */         timestamp(), newValue, 
/*      */         
/* 1067 */         tts(), 
/* 1068 */         mentionEveryone(), this.mentions, this.mentionRoles, 
/*      */ 
/*      */         
/* 1071 */         mentionChannels(), this.attachments, this.embeds, 
/*      */ 
/*      */         
/* 1074 */         reactions(), 
/* 1075 */         nonce(), 
/* 1076 */         pinned(), 
/* 1077 */         webhookId(), 
/* 1078 */         type(), 
/* 1079 */         activity(), 
/* 1080 */         application(), 
/* 1081 */         messageReference(), 
/* 1082 */         flags(), 
/* 1083 */         stickers(), 
/* 1084 */         stickerItems(), 
/* 1085 */         referencedMessage(), 
/* 1086 */         interaction());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutablePartialMessageData withEditedTimestamp(Optional<String> optional) {
/* 1096 */     String value = optional.orElse(null);
/* 1097 */     if (Objects.equals(this.editedTimestamp, value)) return this; 
/* 1098 */     return new ImmutablePartialMessageData(this, 
/*      */         
/* 1100 */         id(), 
/* 1101 */         channelId(), 
/* 1102 */         guildId(), 
/* 1103 */         author(), 
/* 1104 */         member(), 
/* 1105 */         content(), 
/* 1106 */         timestamp(), value, 
/*      */         
/* 1108 */         tts(), 
/* 1109 */         mentionEveryone(), this.mentions, this.mentionRoles, 
/*      */ 
/*      */         
/* 1112 */         mentionChannels(), this.attachments, this.embeds, 
/*      */ 
/*      */         
/* 1115 */         reactions(), 
/* 1116 */         nonce(), 
/* 1117 */         pinned(), 
/* 1118 */         webhookId(), 
/* 1119 */         type(), 
/* 1120 */         activity(), 
/* 1121 */         application(), 
/* 1122 */         messageReference(), 
/* 1123 */         flags(), 
/* 1124 */         stickers(), 
/* 1125 */         stickerItems(), 
/* 1126 */         referencedMessage(), 
/* 1127 */         interaction());
/*      */   }
/*      */   
/*      */   public ImmutablePartialMessageData withTts(Possible<Boolean> value) {
/* 1131 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/* 1132 */     return new ImmutablePartialMessageData(this, 
/*      */         
/* 1134 */         id(), 
/* 1135 */         channelId(), 
/* 1136 */         guildId(), 
/* 1137 */         author(), 
/* 1138 */         member(), 
/* 1139 */         content(), 
/* 1140 */         timestamp(), this.editedTimestamp, newValue, 
/*      */ 
/*      */         
/* 1143 */         mentionEveryone(), this.mentions, this.mentionRoles, 
/*      */ 
/*      */         
/* 1146 */         mentionChannels(), this.attachments, this.embeds, 
/*      */ 
/*      */         
/* 1149 */         reactions(), 
/* 1150 */         nonce(), 
/* 1151 */         pinned(), 
/* 1152 */         webhookId(), 
/* 1153 */         type(), 
/* 1154 */         activity(), 
/* 1155 */         application(), 
/* 1156 */         messageReference(), 
/* 1157 */         flags(), 
/* 1158 */         stickers(), 
/* 1159 */         stickerItems(), 
/* 1160 */         referencedMessage(), 
/* 1161 */         interaction());
/*      */   }
/*      */   
/*      */   public ImmutablePartialMessageData withTts(Boolean value) {
/* 1165 */     Possible<Boolean> newValue = Possible.of(value);
/* 1166 */     return new ImmutablePartialMessageData(this, 
/*      */         
/* 1168 */         id(), 
/* 1169 */         channelId(), 
/* 1170 */         guildId(), 
/* 1171 */         author(), 
/* 1172 */         member(), 
/* 1173 */         content(), 
/* 1174 */         timestamp(), this.editedTimestamp, newValue, 
/*      */ 
/*      */         
/* 1177 */         mentionEveryone(), this.mentions, this.mentionRoles, 
/*      */ 
/*      */         
/* 1180 */         mentionChannels(), this.attachments, this.embeds, 
/*      */ 
/*      */         
/* 1183 */         reactions(), 
/* 1184 */         nonce(), 
/* 1185 */         pinned(), 
/* 1186 */         webhookId(), 
/* 1187 */         type(), 
/* 1188 */         activity(), 
/* 1189 */         application(), 
/* 1190 */         messageReference(), 
/* 1191 */         flags(), 
/* 1192 */         stickers(), 
/* 1193 */         stickerItems(), 
/* 1194 */         referencedMessage(), 
/* 1195 */         interaction());
/*      */   }
/*      */   
/*      */   public ImmutablePartialMessageData withMentionEveryone(Possible<Boolean> value) {
/* 1199 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/* 1200 */     return new ImmutablePartialMessageData(this, 
/*      */         
/* 1202 */         id(), 
/* 1203 */         channelId(), 
/* 1204 */         guildId(), 
/* 1205 */         author(), 
/* 1206 */         member(), 
/* 1207 */         content(), 
/* 1208 */         timestamp(), this.editedTimestamp, 
/*      */         
/* 1210 */         tts(), newValue, this.mentions, this.mentionRoles, 
/*      */ 
/*      */ 
/*      */         
/* 1214 */         mentionChannels(), this.attachments, this.embeds, 
/*      */ 
/*      */         
/* 1217 */         reactions(), 
/* 1218 */         nonce(), 
/* 1219 */         pinned(), 
/* 1220 */         webhookId(), 
/* 1221 */         type(), 
/* 1222 */         activity(), 
/* 1223 */         application(), 
/* 1224 */         messageReference(), 
/* 1225 */         flags(), 
/* 1226 */         stickers(), 
/* 1227 */         stickerItems(), 
/* 1228 */         referencedMessage(), 
/* 1229 */         interaction());
/*      */   }
/*      */   
/*      */   public ImmutablePartialMessageData withMentionEveryone(Boolean value) {
/* 1233 */     Possible<Boolean> newValue = Possible.of(value);
/* 1234 */     return new ImmutablePartialMessageData(this, 
/*      */         
/* 1236 */         id(), 
/* 1237 */         channelId(), 
/* 1238 */         guildId(), 
/* 1239 */         author(), 
/* 1240 */         member(), 
/* 1241 */         content(), 
/* 1242 */         timestamp(), this.editedTimestamp, 
/*      */         
/* 1244 */         tts(), newValue, this.mentions, this.mentionRoles, 
/*      */ 
/*      */ 
/*      */         
/* 1248 */         mentionChannels(), this.attachments, this.embeds, 
/*      */ 
/*      */         
/* 1251 */         reactions(), 
/* 1252 */         nonce(), 
/* 1253 */         pinned(), 
/* 1254 */         webhookId(), 
/* 1255 */         type(), 
/* 1256 */         activity(), 
/* 1257 */         application(), 
/* 1258 */         messageReference(), 
/* 1259 */         flags(), 
/* 1260 */         stickers(), 
/* 1261 */         stickerItems(), 
/* 1262 */         referencedMessage(), 
/* 1263 */         interaction());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutablePartialMessageData withMentions(UserWithMemberData... elements) {
/* 1272 */     List<UserWithMemberData> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/* 1273 */     return new ImmutablePartialMessageData(this, 
/*      */         
/* 1275 */         id(), 
/* 1276 */         channelId(), 
/* 1277 */         guildId(), 
/* 1278 */         author(), 
/* 1279 */         member(), 
/* 1280 */         content(), 
/* 1281 */         timestamp(), this.editedTimestamp, 
/*      */         
/* 1283 */         tts(), 
/* 1284 */         mentionEveryone(), newValue, this.mentionRoles, 
/*      */ 
/*      */         
/* 1287 */         mentionChannels(), this.attachments, this.embeds, 
/*      */ 
/*      */         
/* 1290 */         reactions(), 
/* 1291 */         nonce(), 
/* 1292 */         pinned(), 
/* 1293 */         webhookId(), 
/* 1294 */         type(), 
/* 1295 */         activity(), 
/* 1296 */         application(), 
/* 1297 */         messageReference(), 
/* 1298 */         flags(), 
/* 1299 */         stickers(), 
/* 1300 */         stickerItems(), 
/* 1301 */         referencedMessage(), 
/* 1302 */         interaction());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutablePartialMessageData withMentions(Iterable<? extends UserWithMemberData> elements) {
/* 1312 */     if (this.mentions == elements) return this; 
/* 1313 */     List<UserWithMemberData> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/* 1314 */     return new ImmutablePartialMessageData(this, 
/*      */         
/* 1316 */         id(), 
/* 1317 */         channelId(), 
/* 1318 */         guildId(), 
/* 1319 */         author(), 
/* 1320 */         member(), 
/* 1321 */         content(), 
/* 1322 */         timestamp(), this.editedTimestamp, 
/*      */         
/* 1324 */         tts(), 
/* 1325 */         mentionEveryone(), newValue, this.mentionRoles, 
/*      */ 
/*      */         
/* 1328 */         mentionChannels(), this.attachments, this.embeds, 
/*      */ 
/*      */         
/* 1331 */         reactions(), 
/* 1332 */         nonce(), 
/* 1333 */         pinned(), 
/* 1334 */         webhookId(), 
/* 1335 */         type(), 
/* 1336 */         activity(), 
/* 1337 */         application(), 
/* 1338 */         messageReference(), 
/* 1339 */         flags(), 
/* 1340 */         stickers(), 
/* 1341 */         stickerItems(), 
/* 1342 */         referencedMessage(), 
/* 1343 */         interaction());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutablePartialMessageData withMentionRoles(String... elements) {
/* 1352 */     List<String> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/* 1353 */     return new ImmutablePartialMessageData(this, 
/*      */         
/* 1355 */         id(), 
/* 1356 */         channelId(), 
/* 1357 */         guildId(), 
/* 1358 */         author(), 
/* 1359 */         member(), 
/* 1360 */         content(), 
/* 1361 */         timestamp(), this.editedTimestamp, 
/*      */         
/* 1363 */         tts(), 
/* 1364 */         mentionEveryone(), this.mentions, newValue, 
/*      */ 
/*      */         
/* 1367 */         mentionChannels(), this.attachments, this.embeds, 
/*      */ 
/*      */         
/* 1370 */         reactions(), 
/* 1371 */         nonce(), 
/* 1372 */         pinned(), 
/* 1373 */         webhookId(), 
/* 1374 */         type(), 
/* 1375 */         activity(), 
/* 1376 */         application(), 
/* 1377 */         messageReference(), 
/* 1378 */         flags(), 
/* 1379 */         stickers(), 
/* 1380 */         stickerItems(), 
/* 1381 */         referencedMessage(), 
/* 1382 */         interaction());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutablePartialMessageData withMentionRoles(Iterable<String> elements) {
/* 1392 */     if (this.mentionRoles == elements) return this; 
/* 1393 */     List<String> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/* 1394 */     return new ImmutablePartialMessageData(this, 
/*      */         
/* 1396 */         id(), 
/* 1397 */         channelId(), 
/* 1398 */         guildId(), 
/* 1399 */         author(), 
/* 1400 */         member(), 
/* 1401 */         content(), 
/* 1402 */         timestamp(), this.editedTimestamp, 
/*      */         
/* 1404 */         tts(), 
/* 1405 */         mentionEveryone(), this.mentions, newValue, 
/*      */ 
/*      */         
/* 1408 */         mentionChannels(), this.attachments, this.embeds, 
/*      */ 
/*      */         
/* 1411 */         reactions(), 
/* 1412 */         nonce(), 
/* 1413 */         pinned(), 
/* 1414 */         webhookId(), 
/* 1415 */         type(), 
/* 1416 */         activity(), 
/* 1417 */         application(), 
/* 1418 */         messageReference(), 
/* 1419 */         flags(), 
/* 1420 */         stickers(), 
/* 1421 */         stickerItems(), 
/* 1422 */         referencedMessage(), 
/* 1423 */         interaction());
/*      */   }
/*      */   
/*      */   public ImmutablePartialMessageData withMentionChannels(Possible<List<ChannelMentionData>> possible) {
/* 1427 */     Possible<List<ChannelMentionData>> newValue = Objects.<Possible<List<ChannelMentionData>>>requireNonNull(possible);
/* 1428 */     return new ImmutablePartialMessageData(this, 
/*      */         
/* 1430 */         id(), 
/* 1431 */         channelId(), 
/* 1432 */         guildId(), 
/* 1433 */         author(), 
/* 1434 */         member(), 
/* 1435 */         content(), 
/* 1436 */         timestamp(), this.editedTimestamp, 
/*      */         
/* 1438 */         tts(), 
/* 1439 */         mentionEveryone(), this.mentions, this.mentionRoles, newValue, this.attachments, this.embeds, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1445 */         reactions(), 
/* 1446 */         nonce(), 
/* 1447 */         pinned(), 
/* 1448 */         webhookId(), 
/* 1449 */         type(), 
/* 1450 */         activity(), 
/* 1451 */         application(), 
/* 1452 */         messageReference(), 
/* 1453 */         flags(), 
/* 1454 */         stickers(), 
/* 1455 */         stickerItems(), 
/* 1456 */         referencedMessage(), 
/* 1457 */         interaction());
/*      */   }
/*      */   
/*      */   public ImmutablePartialMessageData withMentionChannels(Iterable<ChannelMentionData> elements) {
/* 1461 */     Possible<List<ChannelMentionData>> newValue = Possible.of(
/* 1462 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/* 1463 */     return new ImmutablePartialMessageData(this, 
/*      */         
/* 1465 */         id(), 
/* 1466 */         channelId(), 
/* 1467 */         guildId(), 
/* 1468 */         author(), 
/* 1469 */         member(), 
/* 1470 */         content(), 
/* 1471 */         timestamp(), this.editedTimestamp, 
/*      */         
/* 1473 */         tts(), 
/* 1474 */         mentionEveryone(), this.mentions, this.mentionRoles, newValue, this.attachments, this.embeds, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1480 */         reactions(), 
/* 1481 */         nonce(), 
/* 1482 */         pinned(), 
/* 1483 */         webhookId(), 
/* 1484 */         type(), 
/* 1485 */         activity(), 
/* 1486 */         application(), 
/* 1487 */         messageReference(), 
/* 1488 */         flags(), 
/* 1489 */         stickers(), 
/* 1490 */         stickerItems(), 
/* 1491 */         referencedMessage(), 
/* 1492 */         interaction());
/*      */   }
/*      */   
/*      */   @SafeVarargs
/*      */   public final ImmutablePartialMessageData withMentionChannels(ChannelMentionData... elements) {
/* 1497 */     Possible<List<ChannelMentionData>> newValue = Possible.of(Arrays.asList(elements));
/* 1498 */     return new ImmutablePartialMessageData(this, 
/*      */         
/* 1500 */         id(), 
/* 1501 */         channelId(), 
/* 1502 */         guildId(), 
/* 1503 */         author(), 
/* 1504 */         member(), 
/* 1505 */         content(), 
/* 1506 */         timestamp(), this.editedTimestamp, 
/*      */         
/* 1508 */         tts(), 
/* 1509 */         mentionEveryone(), this.mentions, this.mentionRoles, newValue, this.attachments, this.embeds, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1515 */         reactions(), 
/* 1516 */         nonce(), 
/* 1517 */         pinned(), 
/* 1518 */         webhookId(), 
/* 1519 */         type(), 
/* 1520 */         activity(), 
/* 1521 */         application(), 
/* 1522 */         messageReference(), 
/* 1523 */         flags(), 
/* 1524 */         stickers(), 
/* 1525 */         stickerItems(), 
/* 1526 */         referencedMessage(), 
/* 1527 */         interaction());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutablePartialMessageData withAttachments(AttachmentData... elements) {
/* 1536 */     List<AttachmentData> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/* 1537 */     return new ImmutablePartialMessageData(this, 
/*      */         
/* 1539 */         id(), 
/* 1540 */         channelId(), 
/* 1541 */         guildId(), 
/* 1542 */         author(), 
/* 1543 */         member(), 
/* 1544 */         content(), 
/* 1545 */         timestamp(), this.editedTimestamp, 
/*      */         
/* 1547 */         tts(), 
/* 1548 */         mentionEveryone(), this.mentions, this.mentionRoles, 
/*      */ 
/*      */         
/* 1551 */         mentionChannels(), newValue, this.embeds, 
/*      */ 
/*      */         
/* 1554 */         reactions(), 
/* 1555 */         nonce(), 
/* 1556 */         pinned(), 
/* 1557 */         webhookId(), 
/* 1558 */         type(), 
/* 1559 */         activity(), 
/* 1560 */         application(), 
/* 1561 */         messageReference(), 
/* 1562 */         flags(), 
/* 1563 */         stickers(), 
/* 1564 */         stickerItems(), 
/* 1565 */         referencedMessage(), 
/* 1566 */         interaction());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutablePartialMessageData withAttachments(Iterable<? extends AttachmentData> elements) {
/* 1576 */     if (this.attachments == elements) return this; 
/* 1577 */     List<AttachmentData> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/* 1578 */     return new ImmutablePartialMessageData(this, 
/*      */         
/* 1580 */         id(), 
/* 1581 */         channelId(), 
/* 1582 */         guildId(), 
/* 1583 */         author(), 
/* 1584 */         member(), 
/* 1585 */         content(), 
/* 1586 */         timestamp(), this.editedTimestamp, 
/*      */         
/* 1588 */         tts(), 
/* 1589 */         mentionEveryone(), this.mentions, this.mentionRoles, 
/*      */ 
/*      */         
/* 1592 */         mentionChannels(), newValue, this.embeds, 
/*      */ 
/*      */         
/* 1595 */         reactions(), 
/* 1596 */         nonce(), 
/* 1597 */         pinned(), 
/* 1598 */         webhookId(), 
/* 1599 */         type(), 
/* 1600 */         activity(), 
/* 1601 */         application(), 
/* 1602 */         messageReference(), 
/* 1603 */         flags(), 
/* 1604 */         stickers(), 
/* 1605 */         stickerItems(), 
/* 1606 */         referencedMessage(), 
/* 1607 */         interaction());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutablePartialMessageData withEmbeds(EmbedData... elements) {
/* 1616 */     List<EmbedData> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/* 1617 */     return new ImmutablePartialMessageData(this, 
/*      */         
/* 1619 */         id(), 
/* 1620 */         channelId(), 
/* 1621 */         guildId(), 
/* 1622 */         author(), 
/* 1623 */         member(), 
/* 1624 */         content(), 
/* 1625 */         timestamp(), this.editedTimestamp, 
/*      */         
/* 1627 */         tts(), 
/* 1628 */         mentionEveryone(), this.mentions, this.mentionRoles, 
/*      */ 
/*      */         
/* 1631 */         mentionChannels(), this.attachments, newValue, 
/*      */ 
/*      */         
/* 1634 */         reactions(), 
/* 1635 */         nonce(), 
/* 1636 */         pinned(), 
/* 1637 */         webhookId(), 
/* 1638 */         type(), 
/* 1639 */         activity(), 
/* 1640 */         application(), 
/* 1641 */         messageReference(), 
/* 1642 */         flags(), 
/* 1643 */         stickers(), 
/* 1644 */         stickerItems(), 
/* 1645 */         referencedMessage(), 
/* 1646 */         interaction());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutablePartialMessageData withEmbeds(Iterable<? extends EmbedData> elements) {
/* 1656 */     if (this.embeds == elements) return this; 
/* 1657 */     List<EmbedData> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/* 1658 */     return new ImmutablePartialMessageData(this, 
/*      */         
/* 1660 */         id(), 
/* 1661 */         channelId(), 
/* 1662 */         guildId(), 
/* 1663 */         author(), 
/* 1664 */         member(), 
/* 1665 */         content(), 
/* 1666 */         timestamp(), this.editedTimestamp, 
/*      */         
/* 1668 */         tts(), 
/* 1669 */         mentionEveryone(), this.mentions, this.mentionRoles, 
/*      */ 
/*      */         
/* 1672 */         mentionChannels(), this.attachments, newValue, 
/*      */ 
/*      */         
/* 1675 */         reactions(), 
/* 1676 */         nonce(), 
/* 1677 */         pinned(), 
/* 1678 */         webhookId(), 
/* 1679 */         type(), 
/* 1680 */         activity(), 
/* 1681 */         application(), 
/* 1682 */         messageReference(), 
/* 1683 */         flags(), 
/* 1684 */         stickers(), 
/* 1685 */         stickerItems(), 
/* 1686 */         referencedMessage(), 
/* 1687 */         interaction());
/*      */   }
/*      */   
/*      */   public ImmutablePartialMessageData withReactions(Possible<List<ReactionData>> possible) {
/* 1691 */     Possible<List<ReactionData>> newValue = Objects.<Possible<List<ReactionData>>>requireNonNull(possible);
/* 1692 */     return new ImmutablePartialMessageData(this, 
/*      */         
/* 1694 */         id(), 
/* 1695 */         channelId(), 
/* 1696 */         guildId(), 
/* 1697 */         author(), 
/* 1698 */         member(), 
/* 1699 */         content(), 
/* 1700 */         timestamp(), this.editedTimestamp, 
/*      */         
/* 1702 */         tts(), 
/* 1703 */         mentionEveryone(), this.mentions, this.mentionRoles, 
/*      */ 
/*      */         
/* 1706 */         mentionChannels(), this.attachments, this.embeds, newValue, 
/*      */ 
/*      */ 
/*      */         
/* 1710 */         nonce(), 
/* 1711 */         pinned(), 
/* 1712 */         webhookId(), 
/* 1713 */         type(), 
/* 1714 */         activity(), 
/* 1715 */         application(), 
/* 1716 */         messageReference(), 
/* 1717 */         flags(), 
/* 1718 */         stickers(), 
/* 1719 */         stickerItems(), 
/* 1720 */         referencedMessage(), 
/* 1721 */         interaction());
/*      */   }
/*      */   
/*      */   public ImmutablePartialMessageData withReactions(Iterable<ReactionData> elements) {
/* 1725 */     Possible<List<ReactionData>> newValue = Possible.of(
/* 1726 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/* 1727 */     return new ImmutablePartialMessageData(this, 
/*      */         
/* 1729 */         id(), 
/* 1730 */         channelId(), 
/* 1731 */         guildId(), 
/* 1732 */         author(), 
/* 1733 */         member(), 
/* 1734 */         content(), 
/* 1735 */         timestamp(), this.editedTimestamp, 
/*      */         
/* 1737 */         tts(), 
/* 1738 */         mentionEveryone(), this.mentions, this.mentionRoles, 
/*      */ 
/*      */         
/* 1741 */         mentionChannels(), this.attachments, this.embeds, newValue, 
/*      */ 
/*      */ 
/*      */         
/* 1745 */         nonce(), 
/* 1746 */         pinned(), 
/* 1747 */         webhookId(), 
/* 1748 */         type(), 
/* 1749 */         activity(), 
/* 1750 */         application(), 
/* 1751 */         messageReference(), 
/* 1752 */         flags(), 
/* 1753 */         stickers(), 
/* 1754 */         stickerItems(), 
/* 1755 */         referencedMessage(), 
/* 1756 */         interaction());
/*      */   }
/*      */   
/*      */   @SafeVarargs
/*      */   public final ImmutablePartialMessageData withReactions(ReactionData... elements) {
/* 1761 */     Possible<List<ReactionData>> newValue = Possible.of(Arrays.asList(elements));
/* 1762 */     return new ImmutablePartialMessageData(this, 
/*      */         
/* 1764 */         id(), 
/* 1765 */         channelId(), 
/* 1766 */         guildId(), 
/* 1767 */         author(), 
/* 1768 */         member(), 
/* 1769 */         content(), 
/* 1770 */         timestamp(), this.editedTimestamp, 
/*      */         
/* 1772 */         tts(), 
/* 1773 */         mentionEveryone(), this.mentions, this.mentionRoles, 
/*      */ 
/*      */         
/* 1776 */         mentionChannels(), this.attachments, this.embeds, newValue, 
/*      */ 
/*      */ 
/*      */         
/* 1780 */         nonce(), 
/* 1781 */         pinned(), 
/* 1782 */         webhookId(), 
/* 1783 */         type(), 
/* 1784 */         activity(), 
/* 1785 */         application(), 
/* 1786 */         messageReference(), 
/* 1787 */         flags(), 
/* 1788 */         stickers(), 
/* 1789 */         stickerItems(), 
/* 1790 */         referencedMessage(), 
/* 1791 */         interaction());
/*      */   }
/*      */   
/*      */   public ImmutablePartialMessageData withNonce(Possible<Object> value) {
/* 1795 */     Possible<Object> newValue = Objects.<Possible<Object>>requireNonNull(value);
/* 1796 */     return new ImmutablePartialMessageData(this, 
/*      */         
/* 1798 */         id(), 
/* 1799 */         channelId(), 
/* 1800 */         guildId(), 
/* 1801 */         author(), 
/* 1802 */         member(), 
/* 1803 */         content(), 
/* 1804 */         timestamp(), this.editedTimestamp, 
/*      */         
/* 1806 */         tts(), 
/* 1807 */         mentionEveryone(), this.mentions, this.mentionRoles, 
/*      */ 
/*      */         
/* 1810 */         mentionChannels(), this.attachments, this.embeds, 
/*      */ 
/*      */         
/* 1813 */         reactions(), newValue, 
/*      */         
/* 1815 */         pinned(), 
/* 1816 */         webhookId(), 
/* 1817 */         type(), 
/* 1818 */         activity(), 
/* 1819 */         application(), 
/* 1820 */         messageReference(), 
/* 1821 */         flags(), 
/* 1822 */         stickers(), 
/* 1823 */         stickerItems(), 
/* 1824 */         referencedMessage(), 
/* 1825 */         interaction());
/*      */   }
/*      */   
/*      */   public ImmutablePartialMessageData withNonce(Object value) {
/* 1829 */     Possible<Object> newValue = Possible.of(value);
/* 1830 */     return new ImmutablePartialMessageData(this, 
/*      */         
/* 1832 */         id(), 
/* 1833 */         channelId(), 
/* 1834 */         guildId(), 
/* 1835 */         author(), 
/* 1836 */         member(), 
/* 1837 */         content(), 
/* 1838 */         timestamp(), this.editedTimestamp, 
/*      */         
/* 1840 */         tts(), 
/* 1841 */         mentionEveryone(), this.mentions, this.mentionRoles, 
/*      */ 
/*      */         
/* 1844 */         mentionChannels(), this.attachments, this.embeds, 
/*      */ 
/*      */         
/* 1847 */         reactions(), newValue, 
/*      */         
/* 1849 */         pinned(), 
/* 1850 */         webhookId(), 
/* 1851 */         type(), 
/* 1852 */         activity(), 
/* 1853 */         application(), 
/* 1854 */         messageReference(), 
/* 1855 */         flags(), 
/* 1856 */         stickers(), 
/* 1857 */         stickerItems(), 
/* 1858 */         referencedMessage(), 
/* 1859 */         interaction());
/*      */   }
/*      */   
/*      */   public ImmutablePartialMessageData withPinned(Possible<Boolean> value) {
/* 1863 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/* 1864 */     return new ImmutablePartialMessageData(this, 
/*      */         
/* 1866 */         id(), 
/* 1867 */         channelId(), 
/* 1868 */         guildId(), 
/* 1869 */         author(), 
/* 1870 */         member(), 
/* 1871 */         content(), 
/* 1872 */         timestamp(), this.editedTimestamp, 
/*      */         
/* 1874 */         tts(), 
/* 1875 */         mentionEveryone(), this.mentions, this.mentionRoles, 
/*      */ 
/*      */         
/* 1878 */         mentionChannels(), this.attachments, this.embeds, 
/*      */ 
/*      */         
/* 1881 */         reactions(), 
/* 1882 */         nonce(), newValue, 
/*      */         
/* 1884 */         webhookId(), 
/* 1885 */         type(), 
/* 1886 */         activity(), 
/* 1887 */         application(), 
/* 1888 */         messageReference(), 
/* 1889 */         flags(), 
/* 1890 */         stickers(), 
/* 1891 */         stickerItems(), 
/* 1892 */         referencedMessage(), 
/* 1893 */         interaction());
/*      */   }
/*      */   
/*      */   public ImmutablePartialMessageData withPinned(Boolean value) {
/* 1897 */     Possible<Boolean> newValue = Possible.of(value);
/* 1898 */     return new ImmutablePartialMessageData(this, 
/*      */         
/* 1900 */         id(), 
/* 1901 */         channelId(), 
/* 1902 */         guildId(), 
/* 1903 */         author(), 
/* 1904 */         member(), 
/* 1905 */         content(), 
/* 1906 */         timestamp(), this.editedTimestamp, 
/*      */         
/* 1908 */         tts(), 
/* 1909 */         mentionEveryone(), this.mentions, this.mentionRoles, 
/*      */ 
/*      */         
/* 1912 */         mentionChannels(), this.attachments, this.embeds, 
/*      */ 
/*      */         
/* 1915 */         reactions(), 
/* 1916 */         nonce(), newValue, 
/*      */         
/* 1918 */         webhookId(), 
/* 1919 */         type(), 
/* 1920 */         activity(), 
/* 1921 */         application(), 
/* 1922 */         messageReference(), 
/* 1923 */         flags(), 
/* 1924 */         stickers(), 
/* 1925 */         stickerItems(), 
/* 1926 */         referencedMessage(), 
/* 1927 */         interaction());
/*      */   }
/*      */   
/*      */   public ImmutablePartialMessageData withWebhookId(Possible<Id> value) {
/* 1931 */     Possible<Id> newValue = Objects.<Possible<Id>>requireNonNull(value);
/* 1932 */     return new ImmutablePartialMessageData(this, 
/*      */         
/* 1934 */         id(), 
/* 1935 */         channelId(), 
/* 1936 */         guildId(), 
/* 1937 */         author(), 
/* 1938 */         member(), 
/* 1939 */         content(), 
/* 1940 */         timestamp(), this.editedTimestamp, 
/*      */         
/* 1942 */         tts(), 
/* 1943 */         mentionEveryone(), this.mentions, this.mentionRoles, 
/*      */ 
/*      */         
/* 1946 */         mentionChannels(), this.attachments, this.embeds, 
/*      */ 
/*      */         
/* 1949 */         reactions(), 
/* 1950 */         nonce(), 
/* 1951 */         pinned(), newValue, 
/*      */         
/* 1953 */         type(), 
/* 1954 */         activity(), 
/* 1955 */         application(), 
/* 1956 */         messageReference(), 
/* 1957 */         flags(), 
/* 1958 */         stickers(), 
/* 1959 */         stickerItems(), 
/* 1960 */         referencedMessage(), 
/* 1961 */         interaction());
/*      */   }
/*      */   
/*      */   public ImmutablePartialMessageData withWebhookId(long value) {
/* 1965 */     Possible<Id> newValue = Possible.of(Id.of(value));
/* 1966 */     return new ImmutablePartialMessageData(this, 
/*      */         
/* 1968 */         id(), 
/* 1969 */         channelId(), 
/* 1970 */         guildId(), 
/* 1971 */         author(), 
/* 1972 */         member(), 
/* 1973 */         content(), 
/* 1974 */         timestamp(), this.editedTimestamp, 
/*      */         
/* 1976 */         tts(), 
/* 1977 */         mentionEveryone(), this.mentions, this.mentionRoles, 
/*      */ 
/*      */         
/* 1980 */         mentionChannels(), this.attachments, this.embeds, 
/*      */ 
/*      */         
/* 1983 */         reactions(), 
/* 1984 */         nonce(), 
/* 1985 */         pinned(), newValue, 
/*      */         
/* 1987 */         type(), 
/* 1988 */         activity(), 
/* 1989 */         application(), 
/* 1990 */         messageReference(), 
/* 1991 */         flags(), 
/* 1992 */         stickers(), 
/* 1993 */         stickerItems(), 
/* 1994 */         referencedMessage(), 
/* 1995 */         interaction());
/*      */   }
/*      */   
/*      */   public ImmutablePartialMessageData withType(Possible<Integer> value) {
/* 1999 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/* 2000 */     return new ImmutablePartialMessageData(this, 
/*      */         
/* 2002 */         id(), 
/* 2003 */         channelId(), 
/* 2004 */         guildId(), 
/* 2005 */         author(), 
/* 2006 */         member(), 
/* 2007 */         content(), 
/* 2008 */         timestamp(), this.editedTimestamp, 
/*      */         
/* 2010 */         tts(), 
/* 2011 */         mentionEveryone(), this.mentions, this.mentionRoles, 
/*      */ 
/*      */         
/* 2014 */         mentionChannels(), this.attachments, this.embeds, 
/*      */ 
/*      */         
/* 2017 */         reactions(), 
/* 2018 */         nonce(), 
/* 2019 */         pinned(), 
/* 2020 */         webhookId(), newValue, 
/*      */         
/* 2022 */         activity(), 
/* 2023 */         application(), 
/* 2024 */         messageReference(), 
/* 2025 */         flags(), 
/* 2026 */         stickers(), 
/* 2027 */         stickerItems(), 
/* 2028 */         referencedMessage(), 
/* 2029 */         interaction());
/*      */   }
/*      */   
/*      */   public ImmutablePartialMessageData withType(Integer value) {
/* 2033 */     Possible<Integer> newValue = Possible.of(value);
/* 2034 */     return new ImmutablePartialMessageData(this, 
/*      */         
/* 2036 */         id(), 
/* 2037 */         channelId(), 
/* 2038 */         guildId(), 
/* 2039 */         author(), 
/* 2040 */         member(), 
/* 2041 */         content(), 
/* 2042 */         timestamp(), this.editedTimestamp, 
/*      */         
/* 2044 */         tts(), 
/* 2045 */         mentionEveryone(), this.mentions, this.mentionRoles, 
/*      */ 
/*      */         
/* 2048 */         mentionChannels(), this.attachments, this.embeds, 
/*      */ 
/*      */         
/* 2051 */         reactions(), 
/* 2052 */         nonce(), 
/* 2053 */         pinned(), 
/* 2054 */         webhookId(), newValue, 
/*      */         
/* 2056 */         activity(), 
/* 2057 */         application(), 
/* 2058 */         messageReference(), 
/* 2059 */         flags(), 
/* 2060 */         stickers(), 
/* 2061 */         stickerItems(), 
/* 2062 */         referencedMessage(), 
/* 2063 */         interaction());
/*      */   }
/*      */   
/*      */   public ImmutablePartialMessageData withActivity(Possible<MessageActivityData> value) {
/* 2067 */     Possible<MessageActivityData> newValue = Objects.<Possible<MessageActivityData>>requireNonNull(value);
/* 2068 */     return new ImmutablePartialMessageData(this, 
/*      */         
/* 2070 */         id(), 
/* 2071 */         channelId(), 
/* 2072 */         guildId(), 
/* 2073 */         author(), 
/* 2074 */         member(), 
/* 2075 */         content(), 
/* 2076 */         timestamp(), this.editedTimestamp, 
/*      */         
/* 2078 */         tts(), 
/* 2079 */         mentionEveryone(), this.mentions, this.mentionRoles, 
/*      */ 
/*      */         
/* 2082 */         mentionChannels(), this.attachments, this.embeds, 
/*      */ 
/*      */         
/* 2085 */         reactions(), 
/* 2086 */         nonce(), 
/* 2087 */         pinned(), 
/* 2088 */         webhookId(), 
/* 2089 */         type(), newValue, 
/*      */         
/* 2091 */         application(), 
/* 2092 */         messageReference(), 
/* 2093 */         flags(), 
/* 2094 */         stickers(), 
/* 2095 */         stickerItems(), 
/* 2096 */         referencedMessage(), 
/* 2097 */         interaction());
/*      */   }
/*      */   
/*      */   public ImmutablePartialMessageData withActivity(MessageActivityData value) {
/* 2101 */     Possible<MessageActivityData> newValue = Possible.of(value);
/* 2102 */     return new ImmutablePartialMessageData(this, 
/*      */         
/* 2104 */         id(), 
/* 2105 */         channelId(), 
/* 2106 */         guildId(), 
/* 2107 */         author(), 
/* 2108 */         member(), 
/* 2109 */         content(), 
/* 2110 */         timestamp(), this.editedTimestamp, 
/*      */         
/* 2112 */         tts(), 
/* 2113 */         mentionEveryone(), this.mentions, this.mentionRoles, 
/*      */ 
/*      */         
/* 2116 */         mentionChannels(), this.attachments, this.embeds, 
/*      */ 
/*      */         
/* 2119 */         reactions(), 
/* 2120 */         nonce(), 
/* 2121 */         pinned(), 
/* 2122 */         webhookId(), 
/* 2123 */         type(), newValue, 
/*      */         
/* 2125 */         application(), 
/* 2126 */         messageReference(), 
/* 2127 */         flags(), 
/* 2128 */         stickers(), 
/* 2129 */         stickerItems(), 
/* 2130 */         referencedMessage(), 
/* 2131 */         interaction());
/*      */   }
/*      */   
/*      */   public ImmutablePartialMessageData withApplication(Possible<MessageApplicationData> value) {
/* 2135 */     Possible<MessageApplicationData> newValue = Objects.<Possible<MessageApplicationData>>requireNonNull(value);
/* 2136 */     return new ImmutablePartialMessageData(this, 
/*      */         
/* 2138 */         id(), 
/* 2139 */         channelId(), 
/* 2140 */         guildId(), 
/* 2141 */         author(), 
/* 2142 */         member(), 
/* 2143 */         content(), 
/* 2144 */         timestamp(), this.editedTimestamp, 
/*      */         
/* 2146 */         tts(), 
/* 2147 */         mentionEveryone(), this.mentions, this.mentionRoles, 
/*      */ 
/*      */         
/* 2150 */         mentionChannels(), this.attachments, this.embeds, 
/*      */ 
/*      */         
/* 2153 */         reactions(), 
/* 2154 */         nonce(), 
/* 2155 */         pinned(), 
/* 2156 */         webhookId(), 
/* 2157 */         type(), 
/* 2158 */         activity(), newValue, 
/*      */         
/* 2160 */         messageReference(), 
/* 2161 */         flags(), 
/* 2162 */         stickers(), 
/* 2163 */         stickerItems(), 
/* 2164 */         referencedMessage(), 
/* 2165 */         interaction());
/*      */   }
/*      */   
/*      */   public ImmutablePartialMessageData withApplication(MessageApplicationData value) {
/* 2169 */     Possible<MessageApplicationData> newValue = Possible.of(value);
/* 2170 */     return new ImmutablePartialMessageData(this, 
/*      */         
/* 2172 */         id(), 
/* 2173 */         channelId(), 
/* 2174 */         guildId(), 
/* 2175 */         author(), 
/* 2176 */         member(), 
/* 2177 */         content(), 
/* 2178 */         timestamp(), this.editedTimestamp, 
/*      */         
/* 2180 */         tts(), 
/* 2181 */         mentionEveryone(), this.mentions, this.mentionRoles, 
/*      */ 
/*      */         
/* 2184 */         mentionChannels(), this.attachments, this.embeds, 
/*      */ 
/*      */         
/* 2187 */         reactions(), 
/* 2188 */         nonce(), 
/* 2189 */         pinned(), 
/* 2190 */         webhookId(), 
/* 2191 */         type(), 
/* 2192 */         activity(), newValue, 
/*      */         
/* 2194 */         messageReference(), 
/* 2195 */         flags(), 
/* 2196 */         stickers(), 
/* 2197 */         stickerItems(), 
/* 2198 */         referencedMessage(), 
/* 2199 */         interaction());
/*      */   }
/*      */   
/*      */   public ImmutablePartialMessageData withMessageReference(Possible<MessageReferenceData> value) {
/* 2203 */     Possible<MessageReferenceData> newValue = Objects.<Possible<MessageReferenceData>>requireNonNull(value);
/* 2204 */     return new ImmutablePartialMessageData(this, 
/*      */         
/* 2206 */         id(), 
/* 2207 */         channelId(), 
/* 2208 */         guildId(), 
/* 2209 */         author(), 
/* 2210 */         member(), 
/* 2211 */         content(), 
/* 2212 */         timestamp(), this.editedTimestamp, 
/*      */         
/* 2214 */         tts(), 
/* 2215 */         mentionEveryone(), this.mentions, this.mentionRoles, 
/*      */ 
/*      */         
/* 2218 */         mentionChannels(), this.attachments, this.embeds, 
/*      */ 
/*      */         
/* 2221 */         reactions(), 
/* 2222 */         nonce(), 
/* 2223 */         pinned(), 
/* 2224 */         webhookId(), 
/* 2225 */         type(), 
/* 2226 */         activity(), 
/* 2227 */         application(), newValue, 
/*      */         
/* 2229 */         flags(), 
/* 2230 */         stickers(), 
/* 2231 */         stickerItems(), 
/* 2232 */         referencedMessage(), 
/* 2233 */         interaction());
/*      */   }
/*      */   
/*      */   public ImmutablePartialMessageData withMessageReference(MessageReferenceData value) {
/* 2237 */     Possible<MessageReferenceData> newValue = Possible.of(value);
/* 2238 */     return new ImmutablePartialMessageData(this, 
/*      */         
/* 2240 */         id(), 
/* 2241 */         channelId(), 
/* 2242 */         guildId(), 
/* 2243 */         author(), 
/* 2244 */         member(), 
/* 2245 */         content(), 
/* 2246 */         timestamp(), this.editedTimestamp, 
/*      */         
/* 2248 */         tts(), 
/* 2249 */         mentionEveryone(), this.mentions, this.mentionRoles, 
/*      */ 
/*      */         
/* 2252 */         mentionChannels(), this.attachments, this.embeds, 
/*      */ 
/*      */         
/* 2255 */         reactions(), 
/* 2256 */         nonce(), 
/* 2257 */         pinned(), 
/* 2258 */         webhookId(), 
/* 2259 */         type(), 
/* 2260 */         activity(), 
/* 2261 */         application(), newValue, 
/*      */         
/* 2263 */         flags(), 
/* 2264 */         stickers(), 
/* 2265 */         stickerItems(), 
/* 2266 */         referencedMessage(), 
/* 2267 */         interaction());
/*      */   }
/*      */   
/*      */   public ImmutablePartialMessageData withFlags(Possible<Integer> value) {
/* 2271 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/* 2272 */     return new ImmutablePartialMessageData(this, 
/*      */         
/* 2274 */         id(), 
/* 2275 */         channelId(), 
/* 2276 */         guildId(), 
/* 2277 */         author(), 
/* 2278 */         member(), 
/* 2279 */         content(), 
/* 2280 */         timestamp(), this.editedTimestamp, 
/*      */         
/* 2282 */         tts(), 
/* 2283 */         mentionEveryone(), this.mentions, this.mentionRoles, 
/*      */ 
/*      */         
/* 2286 */         mentionChannels(), this.attachments, this.embeds, 
/*      */ 
/*      */         
/* 2289 */         reactions(), 
/* 2290 */         nonce(), 
/* 2291 */         pinned(), 
/* 2292 */         webhookId(), 
/* 2293 */         type(), 
/* 2294 */         activity(), 
/* 2295 */         application(), 
/* 2296 */         messageReference(), newValue, 
/*      */         
/* 2298 */         stickers(), 
/* 2299 */         stickerItems(), 
/* 2300 */         referencedMessage(), 
/* 2301 */         interaction());
/*      */   }
/*      */   
/*      */   public ImmutablePartialMessageData withFlags(Integer value) {
/* 2305 */     Possible<Integer> newValue = Possible.of(value);
/* 2306 */     return new ImmutablePartialMessageData(this, 
/*      */         
/* 2308 */         id(), 
/* 2309 */         channelId(), 
/* 2310 */         guildId(), 
/* 2311 */         author(), 
/* 2312 */         member(), 
/* 2313 */         content(), 
/* 2314 */         timestamp(), this.editedTimestamp, 
/*      */         
/* 2316 */         tts(), 
/* 2317 */         mentionEveryone(), this.mentions, this.mentionRoles, 
/*      */ 
/*      */         
/* 2320 */         mentionChannels(), this.attachments, this.embeds, 
/*      */ 
/*      */         
/* 2323 */         reactions(), 
/* 2324 */         nonce(), 
/* 2325 */         pinned(), 
/* 2326 */         webhookId(), 
/* 2327 */         type(), 
/* 2328 */         activity(), 
/* 2329 */         application(), 
/* 2330 */         messageReference(), newValue, 
/*      */         
/* 2332 */         stickers(), 
/* 2333 */         stickerItems(), 
/* 2334 */         referencedMessage(), 
/* 2335 */         interaction());
/*      */   }
/*      */   
/*      */   public ImmutablePartialMessageData withStickers(Possible<List<StickerData>> possible) {
/* 2339 */     Possible<List<StickerData>> newValue = Objects.<Possible<List<StickerData>>>requireNonNull(possible);
/* 2340 */     return new ImmutablePartialMessageData(this, 
/*      */         
/* 2342 */         id(), 
/* 2343 */         channelId(), 
/* 2344 */         guildId(), 
/* 2345 */         author(), 
/* 2346 */         member(), 
/* 2347 */         content(), 
/* 2348 */         timestamp(), this.editedTimestamp, 
/*      */         
/* 2350 */         tts(), 
/* 2351 */         mentionEveryone(), this.mentions, this.mentionRoles, 
/*      */ 
/*      */         
/* 2354 */         mentionChannels(), this.attachments, this.embeds, 
/*      */ 
/*      */         
/* 2357 */         reactions(), 
/* 2358 */         nonce(), 
/* 2359 */         pinned(), 
/* 2360 */         webhookId(), 
/* 2361 */         type(), 
/* 2362 */         activity(), 
/* 2363 */         application(), 
/* 2364 */         messageReference(), 
/* 2365 */         flags(), newValue, 
/*      */         
/* 2367 */         stickerItems(), 
/* 2368 */         referencedMessage(), 
/* 2369 */         interaction());
/*      */   }
/*      */   
/*      */   public ImmutablePartialMessageData withStickers(Iterable<StickerData> elements) {
/* 2373 */     Possible<List<StickerData>> newValue = Possible.of(
/* 2374 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/* 2375 */     return new ImmutablePartialMessageData(this, 
/*      */         
/* 2377 */         id(), 
/* 2378 */         channelId(), 
/* 2379 */         guildId(), 
/* 2380 */         author(), 
/* 2381 */         member(), 
/* 2382 */         content(), 
/* 2383 */         timestamp(), this.editedTimestamp, 
/*      */         
/* 2385 */         tts(), 
/* 2386 */         mentionEveryone(), this.mentions, this.mentionRoles, 
/*      */ 
/*      */         
/* 2389 */         mentionChannels(), this.attachments, this.embeds, 
/*      */ 
/*      */         
/* 2392 */         reactions(), 
/* 2393 */         nonce(), 
/* 2394 */         pinned(), 
/* 2395 */         webhookId(), 
/* 2396 */         type(), 
/* 2397 */         activity(), 
/* 2398 */         application(), 
/* 2399 */         messageReference(), 
/* 2400 */         flags(), newValue, 
/*      */         
/* 2402 */         stickerItems(), 
/* 2403 */         referencedMessage(), 
/* 2404 */         interaction());
/*      */   }
/*      */   
/*      */   @SafeVarargs
/*      */   public final ImmutablePartialMessageData withStickers(StickerData... elements) {
/* 2409 */     Possible<List<StickerData>> newValue = Possible.of(Arrays.asList(elements));
/* 2410 */     return new ImmutablePartialMessageData(this, 
/*      */         
/* 2412 */         id(), 
/* 2413 */         channelId(), 
/* 2414 */         guildId(), 
/* 2415 */         author(), 
/* 2416 */         member(), 
/* 2417 */         content(), 
/* 2418 */         timestamp(), this.editedTimestamp, 
/*      */         
/* 2420 */         tts(), 
/* 2421 */         mentionEveryone(), this.mentions, this.mentionRoles, 
/*      */ 
/*      */         
/* 2424 */         mentionChannels(), this.attachments, this.embeds, 
/*      */ 
/*      */         
/* 2427 */         reactions(), 
/* 2428 */         nonce(), 
/* 2429 */         pinned(), 
/* 2430 */         webhookId(), 
/* 2431 */         type(), 
/* 2432 */         activity(), 
/* 2433 */         application(), 
/* 2434 */         messageReference(), 
/* 2435 */         flags(), newValue, 
/*      */         
/* 2437 */         stickerItems(), 
/* 2438 */         referencedMessage(), 
/* 2439 */         interaction());
/*      */   }
/*      */   
/*      */   public ImmutablePartialMessageData withStickerItems(Possible<List<PartialStickerData>> possible) {
/* 2443 */     Possible<List<PartialStickerData>> newValue = Objects.<Possible<List<PartialStickerData>>>requireNonNull(possible);
/* 2444 */     return new ImmutablePartialMessageData(this, 
/*      */         
/* 2446 */         id(), 
/* 2447 */         channelId(), 
/* 2448 */         guildId(), 
/* 2449 */         author(), 
/* 2450 */         member(), 
/* 2451 */         content(), 
/* 2452 */         timestamp(), this.editedTimestamp, 
/*      */         
/* 2454 */         tts(), 
/* 2455 */         mentionEveryone(), this.mentions, this.mentionRoles, 
/*      */ 
/*      */         
/* 2458 */         mentionChannels(), this.attachments, this.embeds, 
/*      */ 
/*      */         
/* 2461 */         reactions(), 
/* 2462 */         nonce(), 
/* 2463 */         pinned(), 
/* 2464 */         webhookId(), 
/* 2465 */         type(), 
/* 2466 */         activity(), 
/* 2467 */         application(), 
/* 2468 */         messageReference(), 
/* 2469 */         flags(), 
/* 2470 */         stickers(), newValue, 
/*      */         
/* 2472 */         referencedMessage(), 
/* 2473 */         interaction());
/*      */   }
/*      */   
/*      */   public ImmutablePartialMessageData withStickerItems(Iterable<PartialStickerData> elements) {
/* 2477 */     Possible<List<PartialStickerData>> newValue = Possible.of(
/* 2478 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/* 2479 */     return new ImmutablePartialMessageData(this, 
/*      */         
/* 2481 */         id(), 
/* 2482 */         channelId(), 
/* 2483 */         guildId(), 
/* 2484 */         author(), 
/* 2485 */         member(), 
/* 2486 */         content(), 
/* 2487 */         timestamp(), this.editedTimestamp, 
/*      */         
/* 2489 */         tts(), 
/* 2490 */         mentionEveryone(), this.mentions, this.mentionRoles, 
/*      */ 
/*      */         
/* 2493 */         mentionChannels(), this.attachments, this.embeds, 
/*      */ 
/*      */         
/* 2496 */         reactions(), 
/* 2497 */         nonce(), 
/* 2498 */         pinned(), 
/* 2499 */         webhookId(), 
/* 2500 */         type(), 
/* 2501 */         activity(), 
/* 2502 */         application(), 
/* 2503 */         messageReference(), 
/* 2504 */         flags(), 
/* 2505 */         stickers(), newValue, 
/*      */         
/* 2507 */         referencedMessage(), 
/* 2508 */         interaction());
/*      */   }
/*      */   
/*      */   @SafeVarargs
/*      */   public final ImmutablePartialMessageData withStickerItems(PartialStickerData... elements) {
/* 2513 */     Possible<List<PartialStickerData>> newValue = Possible.of(Arrays.asList(elements));
/* 2514 */     return new ImmutablePartialMessageData(this, 
/*      */         
/* 2516 */         id(), 
/* 2517 */         channelId(), 
/* 2518 */         guildId(), 
/* 2519 */         author(), 
/* 2520 */         member(), 
/* 2521 */         content(), 
/* 2522 */         timestamp(), this.editedTimestamp, 
/*      */         
/* 2524 */         tts(), 
/* 2525 */         mentionEveryone(), this.mentions, this.mentionRoles, 
/*      */ 
/*      */         
/* 2528 */         mentionChannels(), this.attachments, this.embeds, 
/*      */ 
/*      */         
/* 2531 */         reactions(), 
/* 2532 */         nonce(), 
/* 2533 */         pinned(), 
/* 2534 */         webhookId(), 
/* 2535 */         type(), 
/* 2536 */         activity(), 
/* 2537 */         application(), 
/* 2538 */         messageReference(), 
/* 2539 */         flags(), 
/* 2540 */         stickers(), newValue, 
/*      */         
/* 2542 */         referencedMessage(), 
/* 2543 */         interaction());
/*      */   }
/*      */   
/*      */   public ImmutablePartialMessageData withReferencedMessage(Possible<Optional<MessageData>> value) {
/* 2547 */     Possible<Optional<MessageData>> newValue = Objects.<Possible<Optional<MessageData>>>requireNonNull(value);
/* 2548 */     return new ImmutablePartialMessageData(this, 
/*      */         
/* 2550 */         id(), 
/* 2551 */         channelId(), 
/* 2552 */         guildId(), 
/* 2553 */         author(), 
/* 2554 */         member(), 
/* 2555 */         content(), 
/* 2556 */         timestamp(), this.editedTimestamp, 
/*      */         
/* 2558 */         tts(), 
/* 2559 */         mentionEveryone(), this.mentions, this.mentionRoles, 
/*      */ 
/*      */         
/* 2562 */         mentionChannels(), this.attachments, this.embeds, 
/*      */ 
/*      */         
/* 2565 */         reactions(), 
/* 2566 */         nonce(), 
/* 2567 */         pinned(), 
/* 2568 */         webhookId(), 
/* 2569 */         type(), 
/* 2570 */         activity(), 
/* 2571 */         application(), 
/* 2572 */         messageReference(), 
/* 2573 */         flags(), 
/* 2574 */         stickers(), 
/* 2575 */         stickerItems(), newValue, 
/*      */         
/* 2577 */         interaction());
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public ImmutablePartialMessageData withReferencedMessage(@Nullable MessageData value) {
/* 2582 */     Possible<Optional<MessageData>> newValue = Possible.of(Optional.ofNullable(value));
/* 2583 */     return new ImmutablePartialMessageData(this, 
/*      */         
/* 2585 */         id(), 
/* 2586 */         channelId(), 
/* 2587 */         guildId(), 
/* 2588 */         author(), 
/* 2589 */         member(), 
/* 2590 */         content(), 
/* 2591 */         timestamp(), this.editedTimestamp, 
/*      */         
/* 2593 */         tts(), 
/* 2594 */         mentionEveryone(), this.mentions, this.mentionRoles, 
/*      */ 
/*      */         
/* 2597 */         mentionChannels(), this.attachments, this.embeds, 
/*      */ 
/*      */         
/* 2600 */         reactions(), 
/* 2601 */         nonce(), 
/* 2602 */         pinned(), 
/* 2603 */         webhookId(), 
/* 2604 */         type(), 
/* 2605 */         activity(), 
/* 2606 */         application(), 
/* 2607 */         messageReference(), 
/* 2608 */         flags(), 
/* 2609 */         stickers(), 
/* 2610 */         stickerItems(), newValue, 
/*      */         
/* 2612 */         interaction());
/*      */   }
/*      */   
/*      */   public ImmutablePartialMessageData withReferencedMessageOrNull(@Nullable MessageData value) {
/* 2616 */     Possible<Optional<MessageData>> newValue = Possible.of(Optional.ofNullable(value));
/* 2617 */     return new ImmutablePartialMessageData(this, 
/*      */         
/* 2619 */         id(), 
/* 2620 */         channelId(), 
/* 2621 */         guildId(), 
/* 2622 */         author(), 
/* 2623 */         member(), 
/* 2624 */         content(), 
/* 2625 */         timestamp(), this.editedTimestamp, 
/*      */         
/* 2627 */         tts(), 
/* 2628 */         mentionEveryone(), this.mentions, this.mentionRoles, 
/*      */ 
/*      */         
/* 2631 */         mentionChannels(), this.attachments, this.embeds, 
/*      */ 
/*      */         
/* 2634 */         reactions(), 
/* 2635 */         nonce(), 
/* 2636 */         pinned(), 
/* 2637 */         webhookId(), 
/* 2638 */         type(), 
/* 2639 */         activity(), 
/* 2640 */         application(), 
/* 2641 */         messageReference(), 
/* 2642 */         flags(), 
/* 2643 */         stickers(), 
/* 2644 */         stickerItems(), newValue, 
/*      */         
/* 2646 */         interaction());
/*      */   }
/*      */   
/*      */   public ImmutablePartialMessageData withInteraction(Possible<MessageInteractionData> value) {
/* 2650 */     Possible<MessageInteractionData> newValue = Objects.<Possible<MessageInteractionData>>requireNonNull(value);
/* 2651 */     return new ImmutablePartialMessageData(this, 
/*      */         
/* 2653 */         id(), 
/* 2654 */         channelId(), 
/* 2655 */         guildId(), 
/* 2656 */         author(), 
/* 2657 */         member(), 
/* 2658 */         content(), 
/* 2659 */         timestamp(), this.editedTimestamp, 
/*      */         
/* 2661 */         tts(), 
/* 2662 */         mentionEveryone(), this.mentions, this.mentionRoles, 
/*      */ 
/*      */         
/* 2665 */         mentionChannels(), this.attachments, this.embeds, 
/*      */ 
/*      */         
/* 2668 */         reactions(), 
/* 2669 */         nonce(), 
/* 2670 */         pinned(), 
/* 2671 */         webhookId(), 
/* 2672 */         type(), 
/* 2673 */         activity(), 
/* 2674 */         application(), 
/* 2675 */         messageReference(), 
/* 2676 */         flags(), 
/* 2677 */         stickers(), 
/* 2678 */         stickerItems(), 
/* 2679 */         referencedMessage(), newValue);
/*      */   }
/*      */ 
/*      */   
/*      */   public ImmutablePartialMessageData withInteraction(MessageInteractionData value) {
/* 2684 */     Possible<MessageInteractionData> newValue = Possible.of(value);
/* 2685 */     return new ImmutablePartialMessageData(this, 
/*      */         
/* 2687 */         id(), 
/* 2688 */         channelId(), 
/* 2689 */         guildId(), 
/* 2690 */         author(), 
/* 2691 */         member(), 
/* 2692 */         content(), 
/* 2693 */         timestamp(), this.editedTimestamp, 
/*      */         
/* 2695 */         tts(), 
/* 2696 */         mentionEveryone(), this.mentions, this.mentionRoles, 
/*      */ 
/*      */         
/* 2699 */         mentionChannels(), this.attachments, this.embeds, 
/*      */ 
/*      */         
/* 2702 */         reactions(), 
/* 2703 */         nonce(), 
/* 2704 */         pinned(), 
/* 2705 */         webhookId(), 
/* 2706 */         type(), 
/* 2707 */         activity(), 
/* 2708 */         application(), 
/* 2709 */         messageReference(), 
/* 2710 */         flags(), 
/* 2711 */         stickers(), 
/* 2712 */         stickerItems(), 
/* 2713 */         referencedMessage(), newValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean equals(Object another) {
/* 2723 */     if (this == another) return true; 
/* 2724 */     return (another instanceof ImmutablePartialMessageData && 
/* 2725 */       equalTo(0, (ImmutablePartialMessageData)another));
/*      */   }
/*      */   
/*      */   private boolean equalTo(int synthetic, ImmutablePartialMessageData another) {
/* 2729 */     return (Objects.equals(Long.valueOf(this.id_value), Long.valueOf(another.id_value)) && 
/* 2730 */       Objects.equals(Long.valueOf(this.channelId_value), Long.valueOf(another.channelId_value)) && 
/* 2731 */       guildId().equals(another.guildId()) && 
/* 2732 */       author().equals(another.author()) && 
/* 2733 */       member().equals(another.member()) && 
/* 2734 */       content().equals(another.content()) && 
/* 2735 */       timestamp().equals(another.timestamp()) && 
/* 2736 */       Objects.equals(this.editedTimestamp, another.editedTimestamp) && 
/* 2737 */       tts().equals(another.tts()) && 
/* 2738 */       mentionEveryone().equals(another.mentionEveryone()) && this.mentions
/* 2739 */       .equals(another.mentions) && this.mentionRoles
/* 2740 */       .equals(another.mentionRoles) && 
/* 2741 */       Objects.equals(this.mentionChannels_value, another.mentionChannels_value) && this.attachments
/* 2742 */       .equals(another.attachments) && this.embeds
/* 2743 */       .equals(another.embeds) && 
/* 2744 */       Objects.equals(this.reactions_value, another.reactions_value) && 
/* 2745 */       nonce().equals(another.nonce()) && 
/* 2746 */       pinned().equals(another.pinned()) && 
/* 2747 */       webhookId().equals(another.webhookId()) && 
/* 2748 */       type().equals(another.type()) && 
/* 2749 */       activity().equals(another.activity()) && 
/* 2750 */       application().equals(another.application()) && 
/* 2751 */       messageReference().equals(another.messageReference()) && 
/* 2752 */       flags().equals(another.flags()) && 
/* 2753 */       Objects.equals(this.stickers_value, another.stickers_value) && 
/* 2754 */       Objects.equals(this.stickerItems_value, another.stickerItems_value) && 
/* 2755 */       referencedMessage().equals(another.referencedMessage()) && 
/* 2756 */       interaction().equals(another.interaction()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int hashCode() {
/* 2765 */     int h = 5381;
/* 2766 */     h += (h << 5) + Objects.hashCode(Long.valueOf(this.id_value));
/* 2767 */     h += (h << 5) + Objects.hashCode(Long.valueOf(this.channelId_value));
/* 2768 */     h += (h << 5) + guildId().hashCode();
/* 2769 */     h += (h << 5) + author().hashCode();
/* 2770 */     h += (h << 5) + member().hashCode();
/* 2771 */     h += (h << 5) + content().hashCode();
/* 2772 */     h += (h << 5) + timestamp().hashCode();
/* 2773 */     h += (h << 5) + Objects.hashCode(this.editedTimestamp);
/* 2774 */     h += (h << 5) + tts().hashCode();
/* 2775 */     h += (h << 5) + mentionEveryone().hashCode();
/* 2776 */     h += (h << 5) + this.mentions.hashCode();
/* 2777 */     h += (h << 5) + this.mentionRoles.hashCode();
/* 2778 */     h += (h << 5) + Objects.hashCode(this.mentionChannels_value);
/* 2779 */     h += (h << 5) + this.attachments.hashCode();
/* 2780 */     h += (h << 5) + this.embeds.hashCode();
/* 2781 */     h += (h << 5) + Objects.hashCode(this.reactions_value);
/* 2782 */     h += (h << 5) + nonce().hashCode();
/* 2783 */     h += (h << 5) + pinned().hashCode();
/* 2784 */     h += (h << 5) + webhookId().hashCode();
/* 2785 */     h += (h << 5) + type().hashCode();
/* 2786 */     h += (h << 5) + activity().hashCode();
/* 2787 */     h += (h << 5) + application().hashCode();
/* 2788 */     h += (h << 5) + messageReference().hashCode();
/* 2789 */     h += (h << 5) + flags().hashCode();
/* 2790 */     h += (h << 5) + Objects.hashCode(this.stickers_value);
/* 2791 */     h += (h << 5) + Objects.hashCode(this.stickerItems_value);
/* 2792 */     h += (h << 5) + referencedMessage().hashCode();
/* 2793 */     h += (h << 5) + interaction().hashCode();
/* 2794 */     return h;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/* 2803 */     StringBuilder builder = new StringBuilder("PartialMessageData{");
/* 2804 */     builder.append("id=").append(Objects.toString(Long.valueOf(this.id_value)));
/* 2805 */     builder.append(", ");
/* 2806 */     builder.append("channelId=").append(Objects.toString(Long.valueOf(this.channelId_value)));
/* 2807 */     builder.append(", ");
/* 2808 */     builder.append("guildId=").append(guildId().toString());
/* 2809 */     builder.append(", ");
/* 2810 */     builder.append("author=").append(author().toString());
/* 2811 */     builder.append(", ");
/* 2812 */     builder.append("member=").append(member().toString());
/* 2813 */     builder.append(", ");
/* 2814 */     builder.append("content=").append(content().toString());
/* 2815 */     builder.append(", ");
/* 2816 */     builder.append("timestamp=").append(timestamp().toString());
/* 2817 */     if (this.editedTimestamp != null) {
/* 2818 */       builder.append(", ");
/* 2819 */       builder.append("editedTimestamp=").append(this.editedTimestamp);
/*      */     } 
/* 2821 */     builder.append(", ");
/* 2822 */     builder.append("tts=").append(tts().toString());
/* 2823 */     builder.append(", ");
/* 2824 */     builder.append("mentionEveryone=").append(mentionEveryone().toString());
/* 2825 */     builder.append(", ");
/* 2826 */     builder.append("mentions=").append(this.mentions);
/* 2827 */     builder.append(", ");
/* 2828 */     builder.append("mentionRoles=").append(this.mentionRoles);
/* 2829 */     builder.append(", ");
/* 2830 */     builder.append("mentionChannels=").append(Objects.toString(this.mentionChannels_value));
/* 2831 */     builder.append(", ");
/* 2832 */     builder.append("attachments=").append(this.attachments);
/* 2833 */     builder.append(", ");
/* 2834 */     builder.append("embeds=").append(this.embeds);
/* 2835 */     builder.append(", ");
/* 2836 */     builder.append("reactions=").append(Objects.toString(this.reactions_value));
/* 2837 */     builder.append(", ");
/* 2838 */     builder.append("nonce=").append(nonce().toString());
/* 2839 */     builder.append(", ");
/* 2840 */     builder.append("pinned=").append(pinned().toString());
/* 2841 */     builder.append(", ");
/* 2842 */     builder.append("webhookId=").append(webhookId().toString());
/* 2843 */     builder.append(", ");
/* 2844 */     builder.append("type=").append(type().toString());
/* 2845 */     builder.append(", ");
/* 2846 */     builder.append("activity=").append(activity().toString());
/* 2847 */     builder.append(", ");
/* 2848 */     builder.append("application=").append(application().toString());
/* 2849 */     builder.append(", ");
/* 2850 */     builder.append("messageReference=").append(messageReference().toString());
/* 2851 */     builder.append(", ");
/* 2852 */     builder.append("flags=").append(flags().toString());
/* 2853 */     builder.append(", ");
/* 2854 */     builder.append("stickers=").append(Objects.toString(this.stickers_value));
/* 2855 */     builder.append(", ");
/* 2856 */     builder.append("stickerItems=").append(Objects.toString(this.stickerItems_value));
/* 2857 */     builder.append(", ");
/* 2858 */     builder.append("referencedMessage=").append(referencedMessage().toString());
/* 2859 */     builder.append(", ");
/* 2860 */     builder.append("interaction=").append(interaction().toString());
/* 2861 */     return builder.append("}").toString();
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonDeserialize
/*      */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*      */   @Generated(from = "PartialMessageData", generator = "Immutables")
/*      */   static final class Json
/*      */     implements PartialMessageData
/*      */   {
/*      */     Id id;
/*      */     
/*      */     Id channelId;
/*      */     
/* 2876 */     Possible<Id> guildId = Possible.absent();
/*      */ 
/*      */     
/* 2879 */     Possible<UserData> author = Possible.absent();
/*      */ 
/*      */     
/* 2882 */     Possible<PartialMemberData> member = Possible.absent();
/*      */ 
/*      */     
/* 2885 */     Possible<String> content = Possible.absent();
/*      */ 
/*      */     
/* 2888 */     Possible<String> timestamp = Possible.absent();
/*      */     
/* 2890 */     Optional<String> editedTimestamp = Optional.empty();
/*      */     
/* 2892 */     Possible<Boolean> tts = Possible.absent();
/*      */ 
/*      */     
/* 2895 */     Possible<Boolean> mentionEveryone = Possible.absent();
/*      */     
/* 2897 */     List<UserWithMemberData> mentions = Collections.emptyList();
/* 2898 */     List<String> mentionRoles = Collections.emptyList();
/*      */     
/* 2900 */     Possible<List<ChannelMentionData>> mentionChannels = Possible.absent();
/*      */     
/* 2902 */     List<AttachmentData> attachments = Collections.emptyList();
/* 2903 */     List<EmbedData> embeds = Collections.emptyList();
/*      */     
/* 2905 */     Possible<List<ReactionData>> reactions = Possible.absent();
/*      */ 
/*      */     
/* 2908 */     Possible<Object> nonce = Possible.absent();
/*      */ 
/*      */     
/* 2911 */     Possible<Boolean> pinned = Possible.absent();
/*      */ 
/*      */     
/* 2914 */     Possible<Id> webhookId = Possible.absent();
/*      */ 
/*      */     
/* 2917 */     Possible<Integer> type = Possible.absent();
/*      */ 
/*      */     
/* 2920 */     Possible<MessageActivityData> activity = Possible.absent();
/*      */ 
/*      */     
/* 2923 */     Possible<MessageApplicationData> application = Possible.absent();
/*      */ 
/*      */     
/* 2926 */     Possible<MessageReferenceData> messageReference = Possible.absent();
/*      */ 
/*      */     
/* 2929 */     Possible<Integer> flags = Possible.absent();
/*      */ 
/*      */     
/* 2932 */     Possible<List<StickerData>> stickers = Possible.absent();
/*      */ 
/*      */     
/* 2935 */     Possible<List<PartialStickerData>> stickerItems = Possible.absent();
/*      */ 
/*      */     
/* 2938 */     Possible<Optional<MessageData>> referencedMessage = Possible.absent();
/*      */ 
/*      */     
/* 2941 */     Possible<MessageInteractionData> interaction = Possible.absent();
/*      */     
/*      */     @JsonProperty("id")
/*      */     public void setId(Id id) {
/* 2945 */       this.id = id;
/*      */     }
/*      */     @JsonProperty("channel_id")
/*      */     public void setChannelId(Id channelId) {
/* 2949 */       this.channelId = channelId;
/*      */     }
/*      */     @JsonProperty("guild_id")
/*      */     public void setGuildId(Possible<Id> guildId) {
/* 2953 */       this.guildId = guildId;
/*      */     }
/*      */     @JsonProperty("author")
/*      */     public void setAuthor(Possible<UserData> author) {
/* 2957 */       this.author = author;
/*      */     }
/*      */     @JsonProperty("member")
/*      */     public void setMember(Possible<PartialMemberData> member) {
/* 2961 */       this.member = member;
/*      */     }
/*      */     @JsonProperty("content")
/*      */     public void setContent(Possible<String> content) {
/* 2965 */       this.content = content;
/*      */     }
/*      */     @JsonProperty("timestamp")
/*      */     public void setTimestamp(Possible<String> timestamp) {
/* 2969 */       this.timestamp = timestamp;
/*      */     }
/*      */     @JsonProperty("edited_timestamp")
/*      */     public void setEditedTimestamp(Optional<String> editedTimestamp) {
/* 2973 */       this.editedTimestamp = editedTimestamp;
/*      */     }
/*      */     @JsonProperty("tts")
/*      */     public void setTts(Possible<Boolean> tts) {
/* 2977 */       this.tts = tts;
/*      */     }
/*      */     @JsonProperty("mention_everyone")
/*      */     public void setMentionEveryone(Possible<Boolean> mentionEveryone) {
/* 2981 */       this.mentionEveryone = mentionEveryone;
/*      */     }
/*      */     @JsonProperty("mentions")
/*      */     public void setMentions(List<UserWithMemberData> mentions) {
/* 2985 */       this.mentions = mentions;
/*      */     }
/*      */     @JsonProperty("mention_roles")
/*      */     public void setMentionRoles(List<String> mentionRoles) {
/* 2989 */       this.mentionRoles = mentionRoles;
/*      */     }
/*      */     @JsonProperty("mention_channels")
/*      */     public void setMentionChannels(Possible<List<ChannelMentionData>> mentionChannels) {
/* 2993 */       this.mentionChannels = mentionChannels;
/*      */     }
/*      */     @JsonProperty("attachments")
/*      */     public void setAttachments(List<AttachmentData> attachments) {
/* 2997 */       this.attachments = attachments;
/*      */     }
/*      */     @JsonProperty("embeds")
/*      */     public void setEmbeds(List<EmbedData> embeds) {
/* 3001 */       this.embeds = embeds;
/*      */     }
/*      */     @JsonProperty("reactions")
/*      */     public void setReactions(Possible<List<ReactionData>> reactions) {
/* 3005 */       this.reactions = reactions;
/*      */     }
/*      */     @JsonProperty("nonce")
/*      */     public void setNonce(Possible<Object> nonce) {
/* 3009 */       this.nonce = nonce;
/*      */     }
/*      */     @JsonProperty("pinned")
/*      */     public void setPinned(Possible<Boolean> pinned) {
/* 3013 */       this.pinned = pinned;
/*      */     }
/*      */     @JsonProperty("webhook_id")
/*      */     public void setWebhookId(Possible<Id> webhookId) {
/* 3017 */       this.webhookId = webhookId;
/*      */     }
/*      */     @JsonProperty("type")
/*      */     public void setType(Possible<Integer> type) {
/* 3021 */       this.type = type;
/*      */     }
/*      */     @JsonProperty("activity")
/*      */     public void setActivity(Possible<MessageActivityData> activity) {
/* 3025 */       this.activity = activity;
/*      */     }
/*      */     @JsonProperty("application")
/*      */     public void setApplication(Possible<MessageApplicationData> application) {
/* 3029 */       this.application = application;
/*      */     }
/*      */     @JsonProperty("message_reference")
/*      */     public void setMessageReference(Possible<MessageReferenceData> messageReference) {
/* 3033 */       this.messageReference = messageReference;
/*      */     }
/*      */     @JsonProperty("flags")
/*      */     public void setFlags(Possible<Integer> flags) {
/* 3037 */       this.flags = flags;
/*      */     }
/*      */     @JsonProperty("stickers")
/*      */     public void setStickers(Possible<List<StickerData>> stickers) {
/* 3041 */       this.stickers = stickers;
/*      */     }
/*      */     @JsonProperty("sticker_items")
/*      */     public void setStickerItems(Possible<List<PartialStickerData>> stickerItems) {
/* 3045 */       this.stickerItems = stickerItems;
/*      */     }
/*      */     @JsonProperty("referenced_message")
/*      */     public void setReferencedMessage(Possible<Optional<MessageData>> referencedMessage) {
/* 3049 */       this.referencedMessage = referencedMessage;
/*      */     }
/*      */     @JsonProperty("interaction")
/*      */     public void setInteraction(Possible<MessageInteractionData> interaction) {
/* 3053 */       this.interaction = interaction;
/*      */     }
/*      */     public Id id() {
/* 3056 */       throw new UnsupportedOperationException();
/*      */     } public Id channelId() {
/* 3058 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Id> guildId() {
/* 3060 */       throw new UnsupportedOperationException();
/*      */     } public Possible<UserData> author() {
/* 3062 */       throw new UnsupportedOperationException();
/*      */     } public Possible<PartialMemberData> member() {
/* 3064 */       throw new UnsupportedOperationException();
/*      */     } public Possible<String> content() {
/* 3066 */       throw new UnsupportedOperationException();
/*      */     } public Possible<String> timestamp() {
/* 3068 */       throw new UnsupportedOperationException();
/*      */     } public Optional<String> editedTimestamp() {
/* 3070 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Boolean> tts() {
/* 3072 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Boolean> mentionEveryone() {
/* 3074 */       throw new UnsupportedOperationException();
/*      */     } public List<UserWithMemberData> mentions() {
/* 3076 */       throw new UnsupportedOperationException();
/*      */     } public List<String> mentionRoles() {
/* 3078 */       throw new UnsupportedOperationException();
/*      */     } public Possible<List<ChannelMentionData>> mentionChannels() {
/* 3080 */       throw new UnsupportedOperationException();
/*      */     } public List<AttachmentData> attachments() {
/* 3082 */       throw new UnsupportedOperationException();
/*      */     } public List<EmbedData> embeds() {
/* 3084 */       throw new UnsupportedOperationException();
/*      */     } public Possible<List<ReactionData>> reactions() {
/* 3086 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Object> nonce() {
/* 3088 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Boolean> pinned() {
/* 3090 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Id> webhookId() {
/* 3092 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Integer> type() {
/* 3094 */       throw new UnsupportedOperationException();
/*      */     } public Possible<MessageActivityData> activity() {
/* 3096 */       throw new UnsupportedOperationException();
/*      */     } public Possible<MessageApplicationData> application() {
/* 3098 */       throw new UnsupportedOperationException();
/*      */     } public Possible<MessageReferenceData> messageReference() {
/* 3100 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Integer> flags() {
/* 3102 */       throw new UnsupportedOperationException();
/*      */     } public Possible<List<StickerData>> stickers() {
/* 3104 */       throw new UnsupportedOperationException();
/*      */     } public Possible<List<PartialStickerData>> stickerItems() {
/* 3106 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Optional<MessageData>> referencedMessage() {
/* 3108 */       throw new UnsupportedOperationException();
/*      */     } public Possible<MessageInteractionData> interaction() {
/* 3110 */       throw new UnsupportedOperationException();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*      */   static ImmutablePartialMessageData fromJson(Json json) {
/* 3121 */     Builder builder = builder();
/* 3122 */     if (json.id != null) {
/* 3123 */       builder.id(json.id);
/*      */     }
/* 3125 */     if (json.channelId != null) {
/* 3126 */       builder.channelId(json.channelId);
/*      */     }
/* 3128 */     if (json.guildId != null) {
/* 3129 */       builder.guildId(json.guildId);
/*      */     }
/* 3131 */     if (json.author != null) {
/* 3132 */       builder.author(json.author);
/*      */     }
/* 3134 */     if (json.member != null) {
/* 3135 */       builder.member(json.member);
/*      */     }
/* 3137 */     if (json.content != null) {
/* 3138 */       builder.content(json.content);
/*      */     }
/* 3140 */     if (json.timestamp != null) {
/* 3141 */       builder.timestamp(json.timestamp);
/*      */     }
/* 3143 */     if (json.editedTimestamp != null) {
/* 3144 */       builder.editedTimestamp(json.editedTimestamp);
/*      */     }
/* 3146 */     if (json.tts != null) {
/* 3147 */       builder.tts(json.tts);
/*      */     }
/* 3149 */     if (json.mentionEveryone != null) {
/* 3150 */       builder.mentionEveryone(json.mentionEveryone);
/*      */     }
/* 3152 */     if (json.mentions != null) {
/* 3153 */       builder.addAllMentions(json.mentions);
/*      */     }
/* 3155 */     if (json.mentionRoles != null) {
/* 3156 */       builder.addAllMentionRoles(json.mentionRoles);
/*      */     }
/* 3158 */     if (json.mentionChannels != null) {
/* 3159 */       builder.mentionChannels(json.mentionChannels);
/*      */     }
/* 3161 */     if (json.attachments != null) {
/* 3162 */       builder.addAllAttachments(json.attachments);
/*      */     }
/* 3164 */     if (json.embeds != null) {
/* 3165 */       builder.addAllEmbeds(json.embeds);
/*      */     }
/* 3167 */     if (json.reactions != null) {
/* 3168 */       builder.reactions(json.reactions);
/*      */     }
/* 3170 */     if (json.nonce != null) {
/* 3171 */       builder.nonce(json.nonce);
/*      */     }
/* 3173 */     if (json.pinned != null) {
/* 3174 */       builder.pinned(json.pinned);
/*      */     }
/* 3176 */     if (json.webhookId != null) {
/* 3177 */       builder.webhookId(json.webhookId);
/*      */     }
/* 3179 */     if (json.type != null) {
/* 3180 */       builder.type(json.type);
/*      */     }
/* 3182 */     if (json.activity != null) {
/* 3183 */       builder.activity(json.activity);
/*      */     }
/* 3185 */     if (json.application != null) {
/* 3186 */       builder.application(json.application);
/*      */     }
/* 3188 */     if (json.messageReference != null) {
/* 3189 */       builder.messageReference(json.messageReference);
/*      */     }
/* 3191 */     if (json.flags != null) {
/* 3192 */       builder.flags(json.flags);
/*      */     }
/* 3194 */     if (json.stickers != null) {
/* 3195 */       builder.stickers(json.stickers);
/*      */     }
/* 3197 */     if (json.stickerItems != null) {
/* 3198 */       builder.stickerItems(json.stickerItems);
/*      */     }
/* 3200 */     if (json.referencedMessage != null) {
/* 3201 */       builder.referencedMessage(json.referencedMessage);
/*      */     }
/* 3203 */     if (json.interaction != null) {
/* 3204 */       builder.interaction(json.interaction);
/*      */     }
/* 3206 */     return builder.build();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutablePartialMessageData of(Id id, Id channelId, Possible<Id> guildId, Possible<UserData> author, Possible<PartialMemberData> member, Possible<String> content, Possible<String> timestamp, Optional<String> editedTimestamp, Possible<Boolean> tts, Possible<Boolean> mentionEveryone, List<UserWithMemberData> mentions, List<String> mentionRoles, Possible<List<ChannelMentionData>> mentionChannels, List<AttachmentData> attachments, List<EmbedData> embeds, Possible<List<ReactionData>> reactions, Possible<Object> nonce, Possible<Boolean> pinned, Possible<Id> webhookId, Possible<Integer> type, Possible<MessageActivityData> activity, Possible<MessageApplicationData> application, Possible<MessageReferenceData> messageReference, Possible<Integer> flags, Possible<List<StickerData>> stickers, Possible<List<PartialStickerData>> stickerItems, Possible<Optional<MessageData>> referencedMessage, Possible<MessageInteractionData> interaction) {
/* 3242 */     return of(id, channelId, guildId, author, member, content, timestamp, editedTimestamp, tts, mentionEveryone, mentions, mentionRoles, mentionChannels, attachments, embeds, reactions, nonce, pinned, webhookId, type, activity, application, messageReference, flags, stickers, stickerItems, referencedMessage, interaction);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutablePartialMessageData of(Id id, Id channelId, Possible<Id> guildId, Possible<UserData> author, Possible<PartialMemberData> member, Possible<String> content, Possible<String> timestamp, Optional<String> editedTimestamp, Possible<Boolean> tts, Possible<Boolean> mentionEveryone, Iterable<? extends UserWithMemberData> mentions, Iterable<String> mentionRoles, Possible<List<ChannelMentionData>> mentionChannels, Iterable<? extends AttachmentData> attachments, Iterable<? extends EmbedData> embeds, Possible<List<ReactionData>> reactions, Possible<Object> nonce, Possible<Boolean> pinned, Possible<Id> webhookId, Possible<Integer> type, Possible<MessageActivityData> activity, Possible<MessageApplicationData> application, Possible<MessageReferenceData> messageReference, Possible<Integer> flags, Possible<List<StickerData>> stickers, Possible<List<PartialStickerData>> stickerItems, Possible<Optional<MessageData>> referencedMessage, Possible<MessageInteractionData> interaction) {
/* 3278 */     return new ImmutablePartialMessageData(id, channelId, guildId, author, member, content, timestamp, editedTimestamp, tts, mentionEveryone, mentions, mentionRoles, mentionChannels, attachments, embeds, reactions, nonce, pinned, webhookId, type, activity, application, messageReference, flags, stickers, stickerItems, referencedMessage, interaction);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutablePartialMessageData copyOf(PartialMessageData instance) {
/* 3289 */     if (instance instanceof ImmutablePartialMessageData) {
/* 3290 */       return (ImmutablePartialMessageData)instance;
/*      */     }
/* 3292 */     return builder()
/* 3293 */       .from(instance)
/* 3294 */       .build();
/*      */   }
/*      */   
/*      */   public boolean isGuildIdPresent() {
/* 3298 */     return !this.guildId_absent;
/*      */   }
/*      */   
/*      */   public long guildIdOrElse(long defaultValue) {
/* 3302 */     return !this.guildId_absent ? this.guildId_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isAuthorPresent() {
/* 3306 */     return !this.author_absent;
/*      */   }
/*      */   
/*      */   public UserData authorOrElse(UserData defaultValue) {
/* 3310 */     return !this.author_absent ? this.author_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isMemberPresent() {
/* 3314 */     return !this.member_absent;
/*      */   }
/*      */   
/*      */   public PartialMemberData memberOrElse(PartialMemberData defaultValue) {
/* 3318 */     return !this.member_absent ? this.member_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isContentPresent() {
/* 3322 */     return !this.content_absent;
/*      */   }
/*      */   
/*      */   public String contentOrElse(String defaultValue) {
/* 3326 */     return !this.content_absent ? this.content_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isTimestampPresent() {
/* 3330 */     return !this.timestamp_absent;
/*      */   }
/*      */   
/*      */   public String timestampOrElse(String defaultValue) {
/* 3334 */     return !this.timestamp_absent ? this.timestamp_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isTtsPresent() {
/* 3338 */     return !this.tts_absent;
/*      */   }
/*      */   
/*      */   public Boolean ttsOrElse(Boolean defaultValue) {
/* 3342 */     return !this.tts_absent ? this.tts_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isMentionEveryonePresent() {
/* 3346 */     return !this.mentionEveryone_absent;
/*      */   }
/*      */   
/*      */   public Boolean mentionEveryoneOrElse(Boolean defaultValue) {
/* 3350 */     return !this.mentionEveryone_absent ? this.mentionEveryone_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isMentionChannelsPresent() {
/* 3354 */     return !this.mentionChannels_absent;
/*      */   }
/*      */   
/*      */   public List<ChannelMentionData> mentionChannelsOrElse(List<ChannelMentionData> defaultValue) {
/* 3358 */     return !this.mentionChannels_absent ? this.mentionChannels_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isReactionsPresent() {
/* 3362 */     return !this.reactions_absent;
/*      */   }
/*      */   
/*      */   public List<ReactionData> reactionsOrElse(List<ReactionData> defaultValue) {
/* 3366 */     return !this.reactions_absent ? this.reactions_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isNoncePresent() {
/* 3370 */     return !this.nonce_absent;
/*      */   }
/*      */   
/*      */   public Object nonceOrElse(Object defaultValue) {
/* 3374 */     return !this.nonce_absent ? this.nonce_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isPinnedPresent() {
/* 3378 */     return !this.pinned_absent;
/*      */   }
/*      */   
/*      */   public Boolean pinnedOrElse(Boolean defaultValue) {
/* 3382 */     return !this.pinned_absent ? this.pinned_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isWebhookIdPresent() {
/* 3386 */     return !this.webhookId_absent;
/*      */   }
/*      */   
/*      */   public long webhookIdOrElse(long defaultValue) {
/* 3390 */     return !this.webhookId_absent ? this.webhookId_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isTypePresent() {
/* 3394 */     return !this.type_absent;
/*      */   }
/*      */   
/*      */   public Integer typeOrElse(Integer defaultValue) {
/* 3398 */     return !this.type_absent ? this.type_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isActivityPresent() {
/* 3402 */     return !this.activity_absent;
/*      */   }
/*      */   
/*      */   public MessageActivityData activityOrElse(MessageActivityData defaultValue) {
/* 3406 */     return !this.activity_absent ? this.activity_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isApplicationPresent() {
/* 3410 */     return !this.application_absent;
/*      */   }
/*      */   
/*      */   public MessageApplicationData applicationOrElse(MessageApplicationData defaultValue) {
/* 3414 */     return !this.application_absent ? this.application_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isMessageReferencePresent() {
/* 3418 */     return !this.messageReference_absent;
/*      */   }
/*      */   
/*      */   public MessageReferenceData messageReferenceOrElse(MessageReferenceData defaultValue) {
/* 3422 */     return !this.messageReference_absent ? this.messageReference_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isFlagsPresent() {
/* 3426 */     return !this.flags_absent;
/*      */   }
/*      */   
/*      */   public Integer flagsOrElse(Integer defaultValue) {
/* 3430 */     return !this.flags_absent ? this.flags_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isStickersPresent() {
/* 3434 */     return !this.stickers_absent;
/*      */   }
/*      */   
/*      */   public List<StickerData> stickersOrElse(List<StickerData> defaultValue) {
/* 3438 */     return !this.stickers_absent ? this.stickers_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isStickerItemsPresent() {
/* 3442 */     return !this.stickerItems_absent;
/*      */   }
/*      */   
/*      */   public List<PartialStickerData> stickerItemsOrElse(List<PartialStickerData> defaultValue) {
/* 3446 */     return !this.stickerItems_absent ? this.stickerItems_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isReferencedMessagePresent() {
/* 3450 */     return !this.referencedMessage_absent;
/*      */   }
/*      */   
/*      */   public MessageData referencedMessageOrElse(MessageData defaultValue) {
/* 3454 */     return !this.referencedMessage_absent ? this.referencedMessage_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isInteractionPresent() {
/* 3458 */     return !this.interaction_absent;
/*      */   }
/*      */   
/*      */   public MessageInteractionData interactionOrElse(MessageInteractionData defaultValue) {
/* 3462 */     return !this.interaction_absent ? this.interaction_value : defaultValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Builder builder() {
/* 3502 */     return new Builder();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Generated(from = "PartialMessageData", generator = "Immutables")
/*      */   public static final class Builder
/*      */   {
/* 3514 */     private Id id_id = null;
/* 3515 */     private Id channelId_id = null;
/* 3516 */     private Possible<Id> guildId_possible = Possible.absent();
/* 3517 */     private Possible<UserData> author_possible = Possible.absent();
/* 3518 */     private Possible<PartialMemberData> member_possible = Possible.absent();
/* 3519 */     private Possible<String> content_possible = Possible.absent();
/* 3520 */     private Possible<String> timestamp_possible = Possible.absent();
/* 3521 */     private Possible<Boolean> tts_possible = Possible.absent();
/* 3522 */     private Possible<Boolean> mentionEveryone_possible = Possible.absent();
/* 3523 */     private List<ChannelMentionData> mentionChannels_list = null;
/* 3524 */     private List<ReactionData> reactions_list = null;
/* 3525 */     private Possible<Object> nonce_possible = Possible.absent();
/* 3526 */     private Possible<Boolean> pinned_possible = Possible.absent();
/* 3527 */     private Possible<Id> webhookId_possible = Possible.absent();
/* 3528 */     private Possible<Integer> type_possible = Possible.absent();
/* 3529 */     private Possible<MessageActivityData> activity_possible = Possible.absent();
/* 3530 */     private Possible<MessageApplicationData> application_possible = Possible.absent();
/* 3531 */     private Possible<MessageReferenceData> messageReference_possible = Possible.absent();
/* 3532 */     private Possible<Integer> flags_possible = Possible.absent();
/* 3533 */     private List<StickerData> stickers_list = null;
/* 3534 */     private List<PartialStickerData> stickerItems_list = null;
/* 3535 */     private Possible<Optional<MessageData>> referencedMessage_possible = Possible.absent();
/* 3536 */     private Possible<MessageInteractionData> interaction_possible = Possible.absent();
/*      */     private String editedTimestamp;
/* 3538 */     private List<UserWithMemberData> mentions = new ArrayList<>();
/* 3539 */     private List<String> mentionRoles = new ArrayList<>();
/* 3540 */     private List<AttachmentData> attachments = new ArrayList<>();
/* 3541 */     private List<EmbedData> embeds = new ArrayList<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder from(PartialMessageData instance) {
/* 3555 */       Objects.requireNonNull(instance, "instance");
/* 3556 */       id(instance.id());
/* 3557 */       channelId(instance.channelId());
/* 3558 */       guildId(instance.guildId());
/* 3559 */       author(instance.author());
/* 3560 */       member(instance.member());
/* 3561 */       content(instance.content());
/* 3562 */       timestamp(instance.timestamp());
/* 3563 */       Optional<String> editedTimestampOptional = instance.editedTimestamp();
/* 3564 */       if (editedTimestampOptional.isPresent()) {
/* 3565 */         editedTimestamp(editedTimestampOptional);
/*      */       }
/* 3567 */       tts(instance.tts());
/* 3568 */       mentionEveryone(instance.mentionEveryone());
/* 3569 */       addAllMentions(instance.mentions());
/* 3570 */       addAllMentionRoles(instance.mentionRoles());
/* 3571 */       mentionChannels(instance.mentionChannels());
/* 3572 */       addAllAttachments(instance.attachments());
/* 3573 */       addAllEmbeds(instance.embeds());
/* 3574 */       reactions(instance.reactions());
/* 3575 */       nonce(instance.nonce());
/* 3576 */       pinned(instance.pinned());
/* 3577 */       webhookId(instance.webhookId());
/* 3578 */       type(instance.type());
/* 3579 */       activity(instance.activity());
/* 3580 */       application(instance.application());
/* 3581 */       messageReference(instance.messageReference());
/* 3582 */       flags(instance.flags());
/* 3583 */       stickers(instance.stickers());
/* 3584 */       stickerItems(instance.stickerItems());
/* 3585 */       referencedMessage(instance.referencedMessage());
/* 3586 */       interaction(instance.interaction());
/* 3587 */       return this;
/*      */     }
/*      */     
/*      */     public Builder id(String value) {
/* 3591 */       this.id_id = Id.of(value);
/* 3592 */       return this;
/*      */     }
/*      */     
/*      */     public Builder id(long value) {
/* 3596 */       this.id_id = Id.of(value);
/* 3597 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("id")
/*      */     public Builder id(Id value) {
/* 3602 */       this.id_id = value;
/* 3603 */       return this;
/*      */     }
/*      */     
/*      */     public Builder channelId(String value) {
/* 3607 */       this.channelId_id = Id.of(value);
/* 3608 */       return this;
/*      */     }
/*      */     
/*      */     public Builder channelId(long value) {
/* 3612 */       this.channelId_id = Id.of(value);
/* 3613 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("channel_id")
/*      */     public Builder channelId(Id value) {
/* 3618 */       this.channelId_id = value;
/* 3619 */       return this;
/*      */     }
/*      */     
/*      */     public Builder guildId(String value) {
/* 3623 */       this.guildId_possible = Possible.of(Id.of(value));
/* 3624 */       return this;
/*      */     }
/*      */     
/*      */     public Builder guildId(long value) {
/* 3628 */       this.guildId_possible = Possible.of(Id.of(value));
/* 3629 */       return this;
/*      */     }
/*      */     
/*      */     public Builder guildId(Id value) {
/* 3633 */       this.guildId_possible = Possible.of(value);
/* 3634 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("guild_id")
/*      */     public Builder guildId(Possible<Id> value) {
/* 3639 */       this.guildId_possible = value;
/* 3640 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("author")
/*      */     public Builder author(Possible<UserData> value) {
/* 3645 */       this.author_possible = value;
/* 3646 */       return this;
/*      */     }
/*      */     
/*      */     public Builder author(UserData value) {
/* 3650 */       this.author_possible = Possible.of(value);
/* 3651 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("member")
/*      */     public Builder member(Possible<PartialMemberData> value) {
/* 3656 */       this.member_possible = value;
/* 3657 */       return this;
/*      */     }
/*      */     
/*      */     public Builder member(PartialMemberData value) {
/* 3661 */       this.member_possible = Possible.of(value);
/* 3662 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("content")
/*      */     public Builder content(Possible<String> value) {
/* 3667 */       this.content_possible = value;
/* 3668 */       return this;
/*      */     }
/*      */     
/*      */     public Builder content(String value) {
/* 3672 */       this.content_possible = Possible.of(value);
/* 3673 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("timestamp")
/*      */     public Builder timestamp(Possible<String> value) {
/* 3678 */       this.timestamp_possible = value;
/* 3679 */       return this;
/*      */     }
/*      */     
/*      */     public Builder timestamp(String value) {
/* 3683 */       this.timestamp_possible = Possible.of(value);
/* 3684 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder editedTimestamp(String editedTimestamp) {
/* 3693 */       this.editedTimestamp = Objects.<String>requireNonNull(editedTimestamp, "editedTimestamp");
/* 3694 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("edited_timestamp")
/*      */     public final Builder editedTimestamp(Optional<String> editedTimestamp) {
/* 3704 */       this.editedTimestamp = editedTimestamp.orElse(null);
/* 3705 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("tts")
/*      */     public Builder tts(Possible<Boolean> value) {
/* 3710 */       this.tts_possible = value;
/* 3711 */       return this;
/*      */     }
/*      */     
/*      */     public Builder tts(Boolean value) {
/* 3715 */       this.tts_possible = Possible.of(value);
/* 3716 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("mention_everyone")
/*      */     public Builder mentionEveryone(Possible<Boolean> value) {
/* 3721 */       this.mentionEveryone_possible = value;
/* 3722 */       return this;
/*      */     }
/*      */     
/*      */     public Builder mentionEveryone(Boolean value) {
/* 3726 */       this.mentionEveryone_possible = Possible.of(value);
/* 3727 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addMention(UserWithMemberData element) {
/* 3736 */       this.mentions.add(Objects.<UserWithMemberData>requireNonNull(element, "mentions element"));
/* 3737 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addMentions(UserWithMemberData... elements) {
/* 3746 */       for (UserWithMemberData element : elements) {
/* 3747 */         this.mentions.add(Objects.<UserWithMemberData>requireNonNull(element, "mentions element"));
/*      */       }
/* 3749 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("mentions")
/*      */     public final Builder mentions(Iterable<? extends UserWithMemberData> elements) {
/* 3760 */       this.mentions.clear();
/* 3761 */       return addAllMentions(elements);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addAllMentions(Iterable<? extends UserWithMemberData> elements) {
/* 3770 */       for (UserWithMemberData element : elements) {
/* 3771 */         this.mentions.add(Objects.<UserWithMemberData>requireNonNull(element, "mentions element"));
/*      */       }
/* 3773 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addMentionRole(String element) {
/* 3782 */       this.mentionRoles.add(Objects.<String>requireNonNull(element, "mentionRoles element"));
/* 3783 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addMentionRoles(String... elements) {
/* 3792 */       for (String element : elements) {
/* 3793 */         this.mentionRoles.add(Objects.<String>requireNonNull(element, "mentionRoles element"));
/*      */       }
/* 3795 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("mention_roles")
/*      */     public final Builder mentionRoles(Iterable<String> elements) {
/* 3806 */       this.mentionRoles.clear();
/* 3807 */       return addAllMentionRoles(elements);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addAllMentionRoles(Iterable<String> elements) {
/* 3816 */       for (String element : elements) {
/* 3817 */         this.mentionRoles.add(Objects.<String>requireNonNull(element, "mentionRoles element"));
/*      */       }
/* 3819 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addMentionChannel(ChannelMentionData element) {
/* 3823 */       mentionChannels_getOrCreate().add(element);
/* 3824 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addAllMentionChannels(List<ChannelMentionData> elements) {
/* 3828 */       mentionChannels_getOrCreate().addAll(elements);
/* 3829 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("mention_channels")
/*      */     public Builder mentionChannels(Possible<List<ChannelMentionData>> elements) {
/* 3834 */       this.mentionChannels_list = null;
/* 3835 */       elements.toOptional().ifPresent(e -> mentionChannels_getOrCreate().addAll(e));
/* 3836 */       return this;
/*      */     }
/*      */     
/*      */     public Builder mentionChannels(List<ChannelMentionData> elements) {
/* 3840 */       this.mentionChannels_list = new ArrayList<>(elements);
/* 3841 */       return this;
/*      */     }
/*      */     
/*      */     public Builder mentionChannels(Iterable<ChannelMentionData> elements) {
/* 3845 */       this.mentionChannels_list = (List<ChannelMentionData>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/* 3846 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addAttachment(AttachmentData element) {
/* 3855 */       this.attachments.add(Objects.<AttachmentData>requireNonNull(element, "attachments element"));
/* 3856 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addAttachments(AttachmentData... elements) {
/* 3865 */       for (AttachmentData element : elements) {
/* 3866 */         this.attachments.add(Objects.<AttachmentData>requireNonNull(element, "attachments element"));
/*      */       }
/* 3868 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("attachments")
/*      */     public final Builder attachments(Iterable<? extends AttachmentData> elements) {
/* 3879 */       this.attachments.clear();
/* 3880 */       return addAllAttachments(elements);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addAllAttachments(Iterable<? extends AttachmentData> elements) {
/* 3889 */       for (AttachmentData element : elements) {
/* 3890 */         this.attachments.add(Objects.<AttachmentData>requireNonNull(element, "attachments element"));
/*      */       }
/* 3892 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addEmbed(EmbedData element) {
/* 3901 */       this.embeds.add(Objects.<EmbedData>requireNonNull(element, "embeds element"));
/* 3902 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addEmbeds(EmbedData... elements) {
/* 3911 */       for (EmbedData element : elements) {
/* 3912 */         this.embeds.add(Objects.<EmbedData>requireNonNull(element, "embeds element"));
/*      */       }
/* 3914 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("embeds")
/*      */     public final Builder embeds(Iterable<? extends EmbedData> elements) {
/* 3925 */       this.embeds.clear();
/* 3926 */       return addAllEmbeds(elements);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addAllEmbeds(Iterable<? extends EmbedData> elements) {
/* 3935 */       for (EmbedData element : elements) {
/* 3936 */         this.embeds.add(Objects.<EmbedData>requireNonNull(element, "embeds element"));
/*      */       }
/* 3938 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addReaction(ReactionData element) {
/* 3942 */       reactions_getOrCreate().add(element);
/* 3943 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addAllReactions(List<ReactionData> elements) {
/* 3947 */       reactions_getOrCreate().addAll(elements);
/* 3948 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("reactions")
/*      */     public Builder reactions(Possible<List<ReactionData>> elements) {
/* 3953 */       this.reactions_list = null;
/* 3954 */       elements.toOptional().ifPresent(e -> reactions_getOrCreate().addAll(e));
/* 3955 */       return this;
/*      */     }
/*      */     
/*      */     public Builder reactions(List<ReactionData> elements) {
/* 3959 */       this.reactions_list = new ArrayList<>(elements);
/* 3960 */       return this;
/*      */     }
/*      */     
/*      */     public Builder reactions(Iterable<ReactionData> elements) {
/* 3964 */       this.reactions_list = (List<ReactionData>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/* 3965 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("nonce")
/*      */     public Builder nonce(Possible<Object> value) {
/* 3970 */       this.nonce_possible = value;
/* 3971 */       return this;
/*      */     }
/*      */     
/*      */     public Builder nonce(Object value) {
/* 3975 */       this.nonce_possible = Possible.of(value);
/* 3976 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("pinned")
/*      */     public Builder pinned(Possible<Boolean> value) {
/* 3981 */       this.pinned_possible = value;
/* 3982 */       return this;
/*      */     }
/*      */     
/*      */     public Builder pinned(Boolean value) {
/* 3986 */       this.pinned_possible = Possible.of(value);
/* 3987 */       return this;
/*      */     }
/*      */     
/*      */     public Builder webhookId(String value) {
/* 3991 */       this.webhookId_possible = Possible.of(Id.of(value));
/* 3992 */       return this;
/*      */     }
/*      */     
/*      */     public Builder webhookId(long value) {
/* 3996 */       this.webhookId_possible = Possible.of(Id.of(value));
/* 3997 */       return this;
/*      */     }
/*      */     
/*      */     public Builder webhookId(Id value) {
/* 4001 */       this.webhookId_possible = Possible.of(value);
/* 4002 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("webhook_id")
/*      */     public Builder webhookId(Possible<Id> value) {
/* 4007 */       this.webhookId_possible = value;
/* 4008 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("type")
/*      */     public Builder type(Possible<Integer> value) {
/* 4013 */       this.type_possible = value;
/* 4014 */       return this;
/*      */     }
/*      */     
/*      */     public Builder type(Integer value) {
/* 4018 */       this.type_possible = Possible.of(value);
/* 4019 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("activity")
/*      */     public Builder activity(Possible<MessageActivityData> value) {
/* 4024 */       this.activity_possible = value;
/* 4025 */       return this;
/*      */     }
/*      */     
/*      */     public Builder activity(MessageActivityData value) {
/* 4029 */       this.activity_possible = Possible.of(value);
/* 4030 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("application")
/*      */     public Builder application(Possible<MessageApplicationData> value) {
/* 4035 */       this.application_possible = value;
/* 4036 */       return this;
/*      */     }
/*      */     
/*      */     public Builder application(MessageApplicationData value) {
/* 4040 */       this.application_possible = Possible.of(value);
/* 4041 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("message_reference")
/*      */     public Builder messageReference(Possible<MessageReferenceData> value) {
/* 4046 */       this.messageReference_possible = value;
/* 4047 */       return this;
/*      */     }
/*      */     
/*      */     public Builder messageReference(MessageReferenceData value) {
/* 4051 */       this.messageReference_possible = Possible.of(value);
/* 4052 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("flags")
/*      */     public Builder flags(Possible<Integer> value) {
/* 4057 */       this.flags_possible = value;
/* 4058 */       return this;
/*      */     }
/*      */     
/*      */     public Builder flags(Integer value) {
/* 4062 */       this.flags_possible = Possible.of(value);
/* 4063 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addSticker(StickerData element) {
/* 4067 */       stickers_getOrCreate().add(element);
/* 4068 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addAllStickers(List<StickerData> elements) {
/* 4072 */       stickers_getOrCreate().addAll(elements);
/* 4073 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("stickers")
/*      */     public Builder stickers(Possible<List<StickerData>> elements) {
/* 4078 */       this.stickers_list = null;
/* 4079 */       elements.toOptional().ifPresent(e -> stickers_getOrCreate().addAll(e));
/* 4080 */       return this;
/*      */     }
/*      */     
/*      */     public Builder stickers(List<StickerData> elements) {
/* 4084 */       this.stickers_list = new ArrayList<>(elements);
/* 4085 */       return this;
/*      */     }
/*      */     
/*      */     public Builder stickers(Iterable<StickerData> elements) {
/* 4089 */       this.stickers_list = (List<StickerData>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/* 4090 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addStickerItem(PartialStickerData element) {
/* 4094 */       stickerItems_getOrCreate().add(element);
/* 4095 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addAllStickerItems(List<PartialStickerData> elements) {
/* 4099 */       stickerItems_getOrCreate().addAll(elements);
/* 4100 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("sticker_items")
/*      */     public Builder stickerItems(Possible<List<PartialStickerData>> elements) {
/* 4105 */       this.stickerItems_list = null;
/* 4106 */       elements.toOptional().ifPresent(e -> stickerItems_getOrCreate().addAll(e));
/* 4107 */       return this;
/*      */     }
/*      */     
/*      */     public Builder stickerItems(List<PartialStickerData> elements) {
/* 4111 */       this.stickerItems_list = new ArrayList<>(elements);
/* 4112 */       return this;
/*      */     }
/*      */     
/*      */     public Builder stickerItems(Iterable<PartialStickerData> elements) {
/* 4116 */       this.stickerItems_list = (List<PartialStickerData>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/* 4117 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("referenced_message")
/*      */     public Builder referencedMessage(Possible<Optional<MessageData>> value) {
/* 4122 */       this.referencedMessage_possible = value;
/* 4123 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public Builder referencedMessage(@Nullable MessageData value) {
/* 4128 */       this.referencedMessage_possible = Possible.of(Optional.ofNullable(value));
/* 4129 */       return this;
/*      */     }
/*      */     
/*      */     public Builder referencedMessageOrNull(@Nullable MessageData value) {
/* 4133 */       this.referencedMessage_possible = Possible.of(Optional.ofNullable(value));
/* 4134 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("interaction")
/*      */     public Builder interaction(Possible<MessageInteractionData> value) {
/* 4139 */       this.interaction_possible = value;
/* 4140 */       return this;
/*      */     }
/*      */     
/*      */     public Builder interaction(MessageInteractionData value) {
/* 4144 */       this.interaction_possible = Possible.of(value);
/* 4145 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ImmutablePartialMessageData build() {
/* 4154 */       return new ImmutablePartialMessageData(null, 
/*      */           
/* 4156 */           id_build(), 
/* 4157 */           channelId_build(), 
/* 4158 */           guildId_build(), 
/* 4159 */           author_build(), 
/* 4160 */           member_build(), 
/* 4161 */           content_build(), 
/* 4162 */           timestamp_build(), this.editedTimestamp, 
/*      */           
/* 4164 */           tts_build(), 
/* 4165 */           mentionEveryone_build(), ImmutablePartialMessageData
/* 4166 */           .createUnmodifiableList(true, (List)this.mentions), ImmutablePartialMessageData
/* 4167 */           .createUnmodifiableList(true, (List)this.mentionRoles), 
/* 4168 */           mentionChannels_build(), ImmutablePartialMessageData
/* 4169 */           .createUnmodifiableList(true, (List)this.attachments), ImmutablePartialMessageData
/* 4170 */           .createUnmodifiableList(true, (List)this.embeds), 
/* 4171 */           reactions_build(), 
/* 4172 */           nonce_build(), 
/* 4173 */           pinned_build(), 
/* 4174 */           webhookId_build(), 
/* 4175 */           type_build(), 
/* 4176 */           activity_build(), 
/* 4177 */           application_build(), 
/* 4178 */           messageReference_build(), 
/* 4179 */           flags_build(), 
/* 4180 */           stickers_build(), 
/* 4181 */           stickerItems_build(), 
/* 4182 */           referencedMessage_build(), 
/* 4183 */           interaction_build());
/*      */     }
/*      */     
/*      */     private Id id_build() {
/* 4187 */       return this.id_id;
/*      */     }
/*      */     
/*      */     private Id channelId_build() {
/* 4191 */       return this.channelId_id;
/*      */     }
/*      */     
/*      */     private Possible<Id> guildId_build() {
/* 4195 */       return this.guildId_possible;
/*      */     }
/*      */     
/*      */     private Possible<UserData> author_build() {
/* 4199 */       return this.author_possible;
/*      */     }
/*      */     
/*      */     private Possible<PartialMemberData> member_build() {
/* 4203 */       return this.member_possible;
/*      */     }
/*      */     
/*      */     private Possible<String> content_build() {
/* 4207 */       return this.content_possible;
/*      */     }
/*      */     
/*      */     private Possible<String> timestamp_build() {
/* 4211 */       return this.timestamp_possible;
/*      */     }
/*      */     
/*      */     private Possible<Boolean> tts_build() {
/* 4215 */       return this.tts_possible;
/*      */     }
/*      */     
/*      */     private Possible<Boolean> mentionEveryone_build() {
/* 4219 */       return this.mentionEveryone_possible;
/*      */     }
/*      */     
/*      */     private Possible<List<ChannelMentionData>> mentionChannels_build() {
/* 4223 */       return (this.mentionChannels_list == null) ? Possible.absent() : 
/* 4224 */         Possible.of(this.mentionChannels_list);
/*      */     }
/*      */     
/*      */     private List<ChannelMentionData> mentionChannels_getOrCreate() {
/* 4228 */       if (this.mentionChannels_list == null) {
/* 4229 */         this.mentionChannels_list = new ArrayList<>();
/*      */       }
/* 4231 */       return this.mentionChannels_list;
/*      */     }
/*      */     
/*      */     private Possible<List<ReactionData>> reactions_build() {
/* 4235 */       return (this.reactions_list == null) ? Possible.absent() : 
/* 4236 */         Possible.of(this.reactions_list);
/*      */     }
/*      */     
/*      */     private List<ReactionData> reactions_getOrCreate() {
/* 4240 */       if (this.reactions_list == null) {
/* 4241 */         this.reactions_list = new ArrayList<>();
/*      */       }
/* 4243 */       return this.reactions_list;
/*      */     }
/*      */     
/*      */     private Possible<Object> nonce_build() {
/* 4247 */       return this.nonce_possible;
/*      */     }
/*      */     
/*      */     private Possible<Boolean> pinned_build() {
/* 4251 */       return this.pinned_possible;
/*      */     }
/*      */     
/*      */     private Possible<Id> webhookId_build() {
/* 4255 */       return this.webhookId_possible;
/*      */     }
/*      */     
/*      */     private Possible<Integer> type_build() {
/* 4259 */       return this.type_possible;
/*      */     }
/*      */     
/*      */     private Possible<MessageActivityData> activity_build() {
/* 4263 */       return this.activity_possible;
/*      */     }
/*      */     
/*      */     private Possible<MessageApplicationData> application_build() {
/* 4267 */       return this.application_possible;
/*      */     }
/*      */     
/*      */     private Possible<MessageReferenceData> messageReference_build() {
/* 4271 */       return this.messageReference_possible;
/*      */     }
/*      */     
/*      */     private Possible<Integer> flags_build() {
/* 4275 */       return this.flags_possible;
/*      */     }
/*      */     
/*      */     private Possible<List<StickerData>> stickers_build() {
/* 4279 */       return (this.stickers_list == null) ? Possible.absent() : 
/* 4280 */         Possible.of(this.stickers_list);
/*      */     }
/*      */     
/*      */     private List<StickerData> stickers_getOrCreate() {
/* 4284 */       if (this.stickers_list == null) {
/* 4285 */         this.stickers_list = new ArrayList<>();
/*      */       }
/* 4287 */       return this.stickers_list;
/*      */     }
/*      */     
/*      */     private Possible<List<PartialStickerData>> stickerItems_build() {
/* 4291 */       return (this.stickerItems_list == null) ? Possible.absent() : 
/* 4292 */         Possible.of(this.stickerItems_list);
/*      */     }
/*      */     
/*      */     private List<PartialStickerData> stickerItems_getOrCreate() {
/* 4296 */       if (this.stickerItems_list == null) {
/* 4297 */         this.stickerItems_list = new ArrayList<>();
/*      */       }
/* 4299 */       return this.stickerItems_list;
/*      */     }
/*      */     
/*      */     private Possible<Optional<MessageData>> referencedMessage_build() {
/* 4303 */       return this.referencedMessage_possible;
/*      */     }
/*      */     
/*      */     private Possible<MessageInteractionData> interaction_build() {
/* 4307 */       return this.interaction_possible;
/*      */     }
/*      */     private Builder() {} }
/*      */   
/*      */   private static <T> List<T> createSafeList(Iterable<? extends T> iterable, boolean checkNulls, boolean skipNulls) {
/*      */     ArrayList<T> list;
/* 4313 */     if (iterable instanceof Collection) {
/* 4314 */       int size = ((Collection)iterable).size();
/* 4315 */       if (size == 0) return Collections.emptyList(); 
/* 4316 */       list = new ArrayList<>();
/*      */     } else {
/* 4318 */       list = new ArrayList<>();
/*      */     } 
/* 4320 */     for (T element : iterable) {
/* 4321 */       if (skipNulls && element == null)
/* 4322 */         continue;  if (checkNulls) Objects.requireNonNull(element, "element"); 
/* 4323 */       list.add(element);
/*      */     } 
/* 4325 */     return list;
/*      */   }
/*      */   
/*      */   private static <T> List<T> createUnmodifiableList(boolean clone, List<T> list) {
/* 4329 */     switch (list.size()) { case 0:
/* 4330 */         return Collections.emptyList();
/* 4331 */       case 1: return Collections.singletonList(list.get(0)); }
/*      */     
/* 4333 */     if (clone) {
/* 4334 */       return Collections.unmodifiableList(new ArrayList<>(list));
/*      */     }
/* 4336 */     if (list instanceof ArrayList) {
/* 4337 */       ((ArrayList)list).trimToSize();
/*      */     }
/* 4339 */     return Collections.unmodifiableList(list);
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutablePartialMessageData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */