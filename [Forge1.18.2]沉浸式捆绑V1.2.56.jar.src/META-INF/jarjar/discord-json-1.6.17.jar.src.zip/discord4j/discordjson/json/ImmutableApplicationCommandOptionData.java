/*      */ package discord4j.discordjson.json;
/*      */ 
/*      */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*      */ import com.fasterxml.jackson.annotation.JsonCreator;
/*      */ import com.fasterxml.jackson.annotation.JsonProperty;
/*      */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*      */ import discord4j.discordjson.possible.Possible;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Objects;
/*      */ import java.util.Optional;
/*      */ import java.util.stream.Collectors;
/*      */ import java.util.stream.StreamSupport;
/*      */ import org.immutables.value.Generated;
/*      */ import reactor.util.annotation.Nullable;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ @Generated(from = "ApplicationCommandOptionData", generator = "Immutables")
/*      */ public final class ImmutableApplicationCommandOptionData
/*      */   implements ApplicationCommandOptionData
/*      */ {
/*      */   private final int type;
/*      */   private final String name;
/*      */   private final Map<String, String> nameLocalizations_value;
/*      */   private final boolean nameLocalizations_absent;
/*      */   private final String description;
/*      */   private final Map<String, String> descriptionLocalizations_value;
/*      */   private final boolean descriptionLocalizations_absent;
/*      */   private final Boolean required_value;
/*      */   private final boolean required_absent;
/*      */   private final List<ApplicationCommandOptionChoiceData> choices_value;
/*      */   private final boolean choices_absent;
/*      */   private final List<ApplicationCommandOptionData> options_value;
/*      */   private final boolean options_absent;
/*      */   private final Boolean autocomplete_value;
/*      */   private final boolean autocomplete_absent;
/*      */   private final List<Integer> channelTypes_value;
/*      */   private final boolean channelTypes_absent;
/*      */   private final Double minValue_value;
/*      */   private final boolean minValue_absent;
/*      */   private final Double maxValue_value;
/*      */   private final boolean maxValue_absent;
/*      */   private final Integer minLength_value;
/*      */   private final boolean minLength_absent;
/*      */   private final Integer maxLength_value;
/*      */   private final boolean maxLength_absent;
/*      */   private static final byte STAGE_INITIALIZING = -1;
/*      */   private static final byte STAGE_UNINITIALIZED = 0;
/*      */   private static final byte STAGE_INITIALIZED = 1;
/*      */   private volatile transient InitShim initShim;
/*      */   
/*      */   private ImmutableApplicationCommandOptionData(int type, String name, Possible<Optional<Map<String, String>>> nameLocalizations, String description, Possible<Optional<Map<String, String>>> descriptionLocalizations, Possible<Boolean> required, Possible<List<ApplicationCommandOptionChoiceData>> choices, Possible<List<ApplicationCommandOptionData>> options, Possible<Boolean> autocomplete, Possible<List<Integer>> channelTypes, Possible<Double> minValue, Possible<Double> maxValue, Possible<Integer> minLength, Possible<Integer> maxLength) {
/*  170 */     this.initShim = new InitShim(); this.type = type; this.name = Objects.<String>requireNonNull(name, "name"); Possible<Optional<Map<String, String>>> nameLocalizations$impl = nameLocalizations; this.description = Objects.<String>requireNonNull(description, "description"); Possible<Optional<Map<String, String>>> descriptionLocalizations$impl = descriptionLocalizations; Possible<Boolean> required$impl = required; Possible<List<ApplicationCommandOptionChoiceData>> choices$impl = choices; Possible<List<ApplicationCommandOptionData>> options$impl = options; Possible<Boolean> autocomplete$impl = autocomplete; Possible<List<Integer>> channelTypes$impl = channelTypes; Possible<Double> minValue$impl = minValue; Possible<Double> maxValue$impl = maxValue; Possible<Integer> minLength$impl = minLength; Possible<Integer> maxLength$impl = maxLength; this.nameLocalizations_value = Possible.flatOpt(nameLocalizations$impl).orElse(null); this.nameLocalizations_absent = nameLocalizations$impl.isAbsent(); this.descriptionLocalizations_value = Possible.flatOpt(descriptionLocalizations$impl).orElse(null); this.descriptionLocalizations_absent = descriptionLocalizations$impl.isAbsent(); this.required_value = required$impl.toOptional().orElse(null); this.required_absent = required$impl.isAbsent(); this.choices_value = choices$impl.toOptional().orElse(null); this.choices_absent = choices$impl.isAbsent(); this.options_value = options$impl.toOptional().orElse(null); this.options_absent = options$impl.isAbsent(); this.autocomplete_value = autocomplete$impl.toOptional().orElse(null); this.autocomplete_absent = autocomplete$impl.isAbsent(); this.channelTypes_value = channelTypes$impl.toOptional().orElse(null); this.channelTypes_absent = channelTypes$impl.isAbsent(); this.minValue_value = minValue$impl.toOptional().orElse(null); this.minValue_absent = minValue$impl.isAbsent(); this.maxValue_value = maxValue$impl.toOptional().orElse(null); this.maxValue_absent = maxValue$impl.isAbsent(); this.minLength_value = minLength$impl.toOptional().orElse(null); this.minLength_absent = minLength$impl.isAbsent(); this.maxLength_value = maxLength$impl.toOptional().orElse(null); this.maxLength_absent = maxLength$impl.isAbsent(); this.initShim = null; } private ImmutableApplicationCommandOptionData(ImmutableApplicationCommandOptionData original, int type, String name, Possible<Optional<Map<String, String>>> nameLocalizations, String description, Possible<Optional<Map<String, String>>> descriptionLocalizations, Possible<Boolean> required, Possible<List<ApplicationCommandOptionChoiceData>> choices, Possible<List<ApplicationCommandOptionData>> options, Possible<Boolean> autocomplete, Possible<List<Integer>> channelTypes, Possible<Double> minValue, Possible<Double> maxValue, Possible<Integer> minLength, Possible<Integer> maxLength) { this.initShim = new InitShim(); this.type = type; this.name = name; Possible<Optional<Map<String, String>>> nameLocalizations$impl = nameLocalizations; this.description = description; Possible<Optional<Map<String, String>>> descriptionLocalizations$impl = descriptionLocalizations; Possible<Boolean> required$impl = required; Possible<List<ApplicationCommandOptionChoiceData>> choices$impl = choices; Possible<List<ApplicationCommandOptionData>> options$impl = options; Possible<Boolean> autocomplete$impl = autocomplete; Possible<List<Integer>> channelTypes$impl = channelTypes; Possible<Double> minValue$impl = minValue; Possible<Double> maxValue$impl = maxValue; Possible<Integer> minLength$impl = minLength; Possible<Integer> maxLength$impl = maxLength; this.nameLocalizations_value = Possible.flatOpt(nameLocalizations$impl).orElse(null); this.nameLocalizations_absent = nameLocalizations$impl.isAbsent(); this.descriptionLocalizations_value = Possible.flatOpt(descriptionLocalizations$impl).orElse(null); this.descriptionLocalizations_absent = descriptionLocalizations$impl.isAbsent(); this.required_value = required$impl.toOptional().orElse(null); this.required_absent = required$impl.isAbsent(); this.choices_value = choices$impl.toOptional().orElse(null); this.choices_absent = choices$impl.isAbsent(); this.options_value = options$impl.toOptional().orElse(null); this.options_absent = options$impl.isAbsent(); this.autocomplete_value = autocomplete$impl.toOptional().orElse(null); this.autocomplete_absent = autocomplete$impl.isAbsent(); this.channelTypes_value = channelTypes$impl.toOptional().orElse(null); this.channelTypes_absent = channelTypes$impl.isAbsent(); this.minValue_value = minValue$impl.toOptional().orElse(null); this.minValue_absent = minValue$impl.isAbsent(); this.maxValue_value = maxValue$impl.toOptional().orElse(null); this.maxValue_absent = maxValue$impl.isAbsent();
/*      */     this.minLength_value = minLength$impl.toOptional().orElse(null);
/*      */     this.minLength_absent = minLength$impl.isAbsent();
/*      */     this.maxLength_value = maxLength$impl.toOptional().orElse(null);
/*      */     this.maxLength_absent = maxLength$impl.isAbsent();
/*  175 */     this.initShim = null; } @Generated(from = "ApplicationCommandOptionData", generator = "Immutables") private final class InitShim { private InitShim() {} private String formatInitCycleMessage() { List<String> attributes = new ArrayList<>();
/*  176 */       return "Cannot build ApplicationCommandOptionData, attribute initializers form cycle " + attributes; }
/*      */      }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("type")
/*      */   public int type() {
/*  186 */     return this.type;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("name")
/*      */   public String name() {
/*  195 */     return this.name;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("name_localizations")
/*      */   public Possible<Optional<Map<String, String>>> nameLocalizations() {
/*  204 */     return this.nameLocalizations_absent ? Possible.absent() : 
/*  205 */       Possible.of(Optional.ofNullable(this.nameLocalizations_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("description")
/*      */   public String description() {
/*  214 */     return this.description;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("description_localizations")
/*      */   public Possible<Optional<Map<String, String>>> descriptionLocalizations() {
/*  223 */     return this.descriptionLocalizations_absent ? Possible.absent() : 
/*  224 */       Possible.of(Optional.ofNullable(this.descriptionLocalizations_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("required")
/*      */   public Possible<Boolean> required() {
/*  233 */     return this.required_absent ? Possible.absent() : Possible.of(this.required_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("choices")
/*      */   public Possible<List<ApplicationCommandOptionChoiceData>> choices() {
/*  242 */     return this.choices_absent ? Possible.absent() : 
/*  243 */       Possible.of(this.choices_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("options")
/*      */   public Possible<List<ApplicationCommandOptionData>> options() {
/*  252 */     return this.options_absent ? Possible.absent() : 
/*  253 */       Possible.of(this.options_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("autocomplete")
/*      */   public Possible<Boolean> autocomplete() {
/*  264 */     return this.autocomplete_absent ? Possible.absent() : Possible.of(this.autocomplete_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("channel_types")
/*      */   public Possible<List<Integer>> channelTypes() {
/*  275 */     return this.channelTypes_absent ? Possible.absent() : 
/*  276 */       Possible.of(this.channelTypes_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("min_value")
/*      */   public Possible<Double> minValue() {
/*  287 */     return this.minValue_absent ? Possible.absent() : Possible.of(this.minValue_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("max_value")
/*      */   public Possible<Double> maxValue() {
/*  298 */     return this.maxValue_absent ? Possible.absent() : Possible.of(this.maxValue_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("min_length")
/*      */   public Possible<Integer> minLength() {
/*  309 */     return this.minLength_absent ? Possible.absent() : Possible.of(this.minLength_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("max_length")
/*      */   public Possible<Integer> maxLength() {
/*  320 */     return this.maxLength_absent ? Possible.absent() : Possible.of(this.maxLength_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableApplicationCommandOptionData withType(int value) {
/*  330 */     if (this.type == value) return this; 
/*  331 */     return new ImmutableApplicationCommandOptionData(this, value, this.name, 
/*      */ 
/*      */ 
/*      */         
/*  335 */         nameLocalizations(), this.description, 
/*      */         
/*  337 */         descriptionLocalizations(), 
/*  338 */         required(), 
/*  339 */         choices(), 
/*  340 */         options(), 
/*  341 */         autocomplete(), 
/*  342 */         channelTypes(), 
/*  343 */         minValue(), 
/*  344 */         maxValue(), 
/*  345 */         minLength(), 
/*  346 */         maxLength());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableApplicationCommandOptionData withName(String value) {
/*  356 */     String newValue = Objects.<String>requireNonNull(value, "name");
/*  357 */     if (this.name.equals(newValue)) return this; 
/*  358 */     return new ImmutableApplicationCommandOptionData(this, this.type, newValue, 
/*      */ 
/*      */ 
/*      */         
/*  362 */         nameLocalizations(), this.description, 
/*      */         
/*  364 */         descriptionLocalizations(), 
/*  365 */         required(), 
/*  366 */         choices(), 
/*  367 */         options(), 
/*  368 */         autocomplete(), 
/*  369 */         channelTypes(), 
/*  370 */         minValue(), 
/*  371 */         maxValue(), 
/*  372 */         minLength(), 
/*  373 */         maxLength());
/*      */   }
/*      */   
/*      */   public ImmutableApplicationCommandOptionData withNameLocalizations(Possible<Optional<Map<String, String>>> value) {
/*  377 */     Possible<Optional<Map<String, String>>> newValue = Objects.<Possible<Optional<Map<String, String>>>>requireNonNull(value);
/*  378 */     return new ImmutableApplicationCommandOptionData(this, this.type, this.name, newValue, this.description, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  384 */         descriptionLocalizations(), 
/*  385 */         required(), 
/*  386 */         choices(), 
/*  387 */         options(), 
/*  388 */         autocomplete(), 
/*  389 */         channelTypes(), 
/*  390 */         minValue(), 
/*  391 */         maxValue(), 
/*  392 */         minLength(), 
/*  393 */         maxLength());
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public ImmutableApplicationCommandOptionData withNameLocalizations(@Nullable Map<String, String> value) {
/*  398 */     Possible<Optional<Map<String, String>>> newValue = Possible.of(Optional.ofNullable(value));
/*  399 */     return new ImmutableApplicationCommandOptionData(this, this.type, this.name, newValue, this.description, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  405 */         descriptionLocalizations(), 
/*  406 */         required(), 
/*  407 */         choices(), 
/*  408 */         options(), 
/*  409 */         autocomplete(), 
/*  410 */         channelTypes(), 
/*  411 */         minValue(), 
/*  412 */         maxValue(), 
/*  413 */         minLength(), 
/*  414 */         maxLength());
/*      */   }
/*      */   
/*      */   public ImmutableApplicationCommandOptionData withNameLocalizationsOrNull(@Nullable Map<String, String> value) {
/*  418 */     Possible<Optional<Map<String, String>>> newValue = Possible.of(Optional.ofNullable(value));
/*  419 */     return new ImmutableApplicationCommandOptionData(this, this.type, this.name, newValue, this.description, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  425 */         descriptionLocalizations(), 
/*  426 */         required(), 
/*  427 */         choices(), 
/*  428 */         options(), 
/*  429 */         autocomplete(), 
/*  430 */         channelTypes(), 
/*  431 */         minValue(), 
/*  432 */         maxValue(), 
/*  433 */         minLength(), 
/*  434 */         maxLength());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableApplicationCommandOptionData withDescription(String value) {
/*  444 */     String newValue = Objects.<String>requireNonNull(value, "description");
/*  445 */     if (this.description.equals(newValue)) return this; 
/*  446 */     return new ImmutableApplicationCommandOptionData(this, this.type, this.name, 
/*      */ 
/*      */ 
/*      */         
/*  450 */         nameLocalizations(), newValue, 
/*      */         
/*  452 */         descriptionLocalizations(), 
/*  453 */         required(), 
/*  454 */         choices(), 
/*  455 */         options(), 
/*  456 */         autocomplete(), 
/*  457 */         channelTypes(), 
/*  458 */         minValue(), 
/*  459 */         maxValue(), 
/*  460 */         minLength(), 
/*  461 */         maxLength());
/*      */   }
/*      */   
/*      */   public ImmutableApplicationCommandOptionData withDescriptionLocalizations(Possible<Optional<Map<String, String>>> value) {
/*  465 */     Possible<Optional<Map<String, String>>> newValue = Objects.<Possible<Optional<Map<String, String>>>>requireNonNull(value);
/*  466 */     return new ImmutableApplicationCommandOptionData(this, this.type, this.name, 
/*      */ 
/*      */ 
/*      */         
/*  470 */         nameLocalizations(), this.description, newValue, 
/*      */ 
/*      */         
/*  473 */         required(), 
/*  474 */         choices(), 
/*  475 */         options(), 
/*  476 */         autocomplete(), 
/*  477 */         channelTypes(), 
/*  478 */         minValue(), 
/*  479 */         maxValue(), 
/*  480 */         minLength(), 
/*  481 */         maxLength());
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public ImmutableApplicationCommandOptionData withDescriptionLocalizations(@Nullable Map<String, String> value) {
/*  486 */     Possible<Optional<Map<String, String>>> newValue = Possible.of(Optional.ofNullable(value));
/*  487 */     return new ImmutableApplicationCommandOptionData(this, this.type, this.name, 
/*      */ 
/*      */ 
/*      */         
/*  491 */         nameLocalizations(), this.description, newValue, 
/*      */ 
/*      */         
/*  494 */         required(), 
/*  495 */         choices(), 
/*  496 */         options(), 
/*  497 */         autocomplete(), 
/*  498 */         channelTypes(), 
/*  499 */         minValue(), 
/*  500 */         maxValue(), 
/*  501 */         minLength(), 
/*  502 */         maxLength());
/*      */   }
/*      */   
/*      */   public ImmutableApplicationCommandOptionData withDescriptionLocalizationsOrNull(@Nullable Map<String, String> value) {
/*  506 */     Possible<Optional<Map<String, String>>> newValue = Possible.of(Optional.ofNullable(value));
/*  507 */     return new ImmutableApplicationCommandOptionData(this, this.type, this.name, 
/*      */ 
/*      */ 
/*      */         
/*  511 */         nameLocalizations(), this.description, newValue, 
/*      */ 
/*      */         
/*  514 */         required(), 
/*  515 */         choices(), 
/*  516 */         options(), 
/*  517 */         autocomplete(), 
/*  518 */         channelTypes(), 
/*  519 */         minValue(), 
/*  520 */         maxValue(), 
/*  521 */         minLength(), 
/*  522 */         maxLength());
/*      */   }
/*      */   
/*      */   public ImmutableApplicationCommandOptionData withRequired(Possible<Boolean> value) {
/*  526 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/*  527 */     return new ImmutableApplicationCommandOptionData(this, this.type, this.name, 
/*      */ 
/*      */ 
/*      */         
/*  531 */         nameLocalizations(), this.description, 
/*      */         
/*  533 */         descriptionLocalizations(), newValue, 
/*      */         
/*  535 */         choices(), 
/*  536 */         options(), 
/*  537 */         autocomplete(), 
/*  538 */         channelTypes(), 
/*  539 */         minValue(), 
/*  540 */         maxValue(), 
/*  541 */         minLength(), 
/*  542 */         maxLength());
/*      */   }
/*      */   
/*      */   public ImmutableApplicationCommandOptionData withRequired(Boolean value) {
/*  546 */     Possible<Boolean> newValue = Possible.of(value);
/*  547 */     return new ImmutableApplicationCommandOptionData(this, this.type, this.name, 
/*      */ 
/*      */ 
/*      */         
/*  551 */         nameLocalizations(), this.description, 
/*      */         
/*  553 */         descriptionLocalizations(), newValue, 
/*      */         
/*  555 */         choices(), 
/*  556 */         options(), 
/*  557 */         autocomplete(), 
/*  558 */         channelTypes(), 
/*  559 */         minValue(), 
/*  560 */         maxValue(), 
/*  561 */         minLength(), 
/*  562 */         maxLength());
/*      */   }
/*      */   
/*      */   public ImmutableApplicationCommandOptionData withChoices(Possible<List<ApplicationCommandOptionChoiceData>> possible) {
/*  566 */     Possible<List<ApplicationCommandOptionChoiceData>> newValue = Objects.<Possible<List<ApplicationCommandOptionChoiceData>>>requireNonNull(possible);
/*  567 */     return new ImmutableApplicationCommandOptionData(this, this.type, this.name, 
/*      */ 
/*      */ 
/*      */         
/*  571 */         nameLocalizations(), this.description, 
/*      */         
/*  573 */         descriptionLocalizations(), 
/*  574 */         required(), newValue, 
/*      */         
/*  576 */         options(), 
/*  577 */         autocomplete(), 
/*  578 */         channelTypes(), 
/*  579 */         minValue(), 
/*  580 */         maxValue(), 
/*  581 */         minLength(), 
/*  582 */         maxLength());
/*      */   }
/*      */   
/*      */   public ImmutableApplicationCommandOptionData withChoices(Iterable<ApplicationCommandOptionChoiceData> elements) {
/*  586 */     Possible<List<ApplicationCommandOptionChoiceData>> newValue = Possible.of(
/*  587 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/*  588 */     return new ImmutableApplicationCommandOptionData(this, this.type, this.name, 
/*      */ 
/*      */ 
/*      */         
/*  592 */         nameLocalizations(), this.description, 
/*      */         
/*  594 */         descriptionLocalizations(), 
/*  595 */         required(), newValue, 
/*      */         
/*  597 */         options(), 
/*  598 */         autocomplete(), 
/*  599 */         channelTypes(), 
/*  600 */         minValue(), 
/*  601 */         maxValue(), 
/*  602 */         minLength(), 
/*  603 */         maxLength());
/*      */   }
/*      */   
/*      */   @SafeVarargs
/*      */   public final ImmutableApplicationCommandOptionData withChoices(ApplicationCommandOptionChoiceData... elements) {
/*  608 */     Possible<List<ApplicationCommandOptionChoiceData>> newValue = Possible.of(Arrays.asList(elements));
/*  609 */     return new ImmutableApplicationCommandOptionData(this, this.type, this.name, 
/*      */ 
/*      */ 
/*      */         
/*  613 */         nameLocalizations(), this.description, 
/*      */         
/*  615 */         descriptionLocalizations(), 
/*  616 */         required(), newValue, 
/*      */         
/*  618 */         options(), 
/*  619 */         autocomplete(), 
/*  620 */         channelTypes(), 
/*  621 */         minValue(), 
/*  622 */         maxValue(), 
/*  623 */         minLength(), 
/*  624 */         maxLength());
/*      */   }
/*      */   
/*      */   public ImmutableApplicationCommandOptionData withOptions(Possible<List<ApplicationCommandOptionData>> possible) {
/*  628 */     Possible<List<ApplicationCommandOptionData>> newValue = Objects.<Possible<List<ApplicationCommandOptionData>>>requireNonNull(possible);
/*  629 */     return new ImmutableApplicationCommandOptionData(this, this.type, this.name, 
/*      */ 
/*      */ 
/*      */         
/*  633 */         nameLocalizations(), this.description, 
/*      */         
/*  635 */         descriptionLocalizations(), 
/*  636 */         required(), 
/*  637 */         choices(), newValue, 
/*      */         
/*  639 */         autocomplete(), 
/*  640 */         channelTypes(), 
/*  641 */         minValue(), 
/*  642 */         maxValue(), 
/*  643 */         minLength(), 
/*  644 */         maxLength());
/*      */   }
/*      */   
/*      */   public ImmutableApplicationCommandOptionData withOptions(Iterable<ApplicationCommandOptionData> elements) {
/*  648 */     Possible<List<ApplicationCommandOptionData>> newValue = Possible.of(
/*  649 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/*  650 */     return new ImmutableApplicationCommandOptionData(this, this.type, this.name, 
/*      */ 
/*      */ 
/*      */         
/*  654 */         nameLocalizations(), this.description, 
/*      */         
/*  656 */         descriptionLocalizations(), 
/*  657 */         required(), 
/*  658 */         choices(), newValue, 
/*      */         
/*  660 */         autocomplete(), 
/*  661 */         channelTypes(), 
/*  662 */         minValue(), 
/*  663 */         maxValue(), 
/*  664 */         minLength(), 
/*  665 */         maxLength());
/*      */   }
/*      */   
/*      */   @SafeVarargs
/*      */   public final ImmutableApplicationCommandOptionData withOptions(ApplicationCommandOptionData... elements) {
/*  670 */     Possible<List<ApplicationCommandOptionData>> newValue = Possible.of(Arrays.asList(elements));
/*  671 */     return new ImmutableApplicationCommandOptionData(this, this.type, this.name, 
/*      */ 
/*      */ 
/*      */         
/*  675 */         nameLocalizations(), this.description, 
/*      */         
/*  677 */         descriptionLocalizations(), 
/*  678 */         required(), 
/*  679 */         choices(), newValue, 
/*      */         
/*  681 */         autocomplete(), 
/*  682 */         channelTypes(), 
/*  683 */         minValue(), 
/*  684 */         maxValue(), 
/*  685 */         minLength(), 
/*  686 */         maxLength());
/*      */   }
/*      */   
/*      */   public ImmutableApplicationCommandOptionData withAutocomplete(Possible<Boolean> value) {
/*  690 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/*  691 */     return new ImmutableApplicationCommandOptionData(this, this.type, this.name, 
/*      */ 
/*      */ 
/*      */         
/*  695 */         nameLocalizations(), this.description, 
/*      */         
/*  697 */         descriptionLocalizations(), 
/*  698 */         required(), 
/*  699 */         choices(), 
/*  700 */         options(), newValue, 
/*      */         
/*  702 */         channelTypes(), 
/*  703 */         minValue(), 
/*  704 */         maxValue(), 
/*  705 */         minLength(), 
/*  706 */         maxLength());
/*      */   }
/*      */   
/*      */   public ImmutableApplicationCommandOptionData withAutocomplete(Boolean value) {
/*  710 */     Possible<Boolean> newValue = Possible.of(value);
/*  711 */     return new ImmutableApplicationCommandOptionData(this, this.type, this.name, 
/*      */ 
/*      */ 
/*      */         
/*  715 */         nameLocalizations(), this.description, 
/*      */         
/*  717 */         descriptionLocalizations(), 
/*  718 */         required(), 
/*  719 */         choices(), 
/*  720 */         options(), newValue, 
/*      */         
/*  722 */         channelTypes(), 
/*  723 */         minValue(), 
/*  724 */         maxValue(), 
/*  725 */         minLength(), 
/*  726 */         maxLength());
/*      */   }
/*      */   
/*      */   public ImmutableApplicationCommandOptionData withChannelTypes(Possible<List<Integer>> possible) {
/*  730 */     Possible<List<Integer>> newValue = Objects.<Possible<List<Integer>>>requireNonNull(possible);
/*  731 */     return new ImmutableApplicationCommandOptionData(this, this.type, this.name, 
/*      */ 
/*      */ 
/*      */         
/*  735 */         nameLocalizations(), this.description, 
/*      */         
/*  737 */         descriptionLocalizations(), 
/*  738 */         required(), 
/*  739 */         choices(), 
/*  740 */         options(), 
/*  741 */         autocomplete(), newValue, 
/*      */         
/*  743 */         minValue(), 
/*  744 */         maxValue(), 
/*  745 */         minLength(), 
/*  746 */         maxLength());
/*      */   }
/*      */   
/*      */   public ImmutableApplicationCommandOptionData withChannelTypes(Iterable<Integer> elements) {
/*  750 */     Possible<List<Integer>> newValue = Possible.of(
/*  751 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/*  752 */     return new ImmutableApplicationCommandOptionData(this, this.type, this.name, 
/*      */ 
/*      */ 
/*      */         
/*  756 */         nameLocalizations(), this.description, 
/*      */         
/*  758 */         descriptionLocalizations(), 
/*  759 */         required(), 
/*  760 */         choices(), 
/*  761 */         options(), 
/*  762 */         autocomplete(), newValue, 
/*      */         
/*  764 */         minValue(), 
/*  765 */         maxValue(), 
/*  766 */         minLength(), 
/*  767 */         maxLength());
/*      */   }
/*      */   
/*      */   @SafeVarargs
/*      */   public final ImmutableApplicationCommandOptionData withChannelTypes(Integer... elements) {
/*  772 */     Possible<List<Integer>> newValue = Possible.of(Arrays.asList(elements));
/*  773 */     return new ImmutableApplicationCommandOptionData(this, this.type, this.name, 
/*      */ 
/*      */ 
/*      */         
/*  777 */         nameLocalizations(), this.description, 
/*      */         
/*  779 */         descriptionLocalizations(), 
/*  780 */         required(), 
/*  781 */         choices(), 
/*  782 */         options(), 
/*  783 */         autocomplete(), newValue, 
/*      */         
/*  785 */         minValue(), 
/*  786 */         maxValue(), 
/*  787 */         minLength(), 
/*  788 */         maxLength());
/*      */   }
/*      */   
/*      */   public ImmutableApplicationCommandOptionData withMinValue(Possible<Double> value) {
/*  792 */     Possible<Double> newValue = Objects.<Possible<Double>>requireNonNull(value);
/*  793 */     return new ImmutableApplicationCommandOptionData(this, this.type, this.name, 
/*      */ 
/*      */ 
/*      */         
/*  797 */         nameLocalizations(), this.description, 
/*      */         
/*  799 */         descriptionLocalizations(), 
/*  800 */         required(), 
/*  801 */         choices(), 
/*  802 */         options(), 
/*  803 */         autocomplete(), 
/*  804 */         channelTypes(), newValue, 
/*      */         
/*  806 */         maxValue(), 
/*  807 */         minLength(), 
/*  808 */         maxLength());
/*      */   }
/*      */   
/*      */   public ImmutableApplicationCommandOptionData withMinValue(Double value) {
/*  812 */     Possible<Double> newValue = Possible.of(value);
/*  813 */     return new ImmutableApplicationCommandOptionData(this, this.type, this.name, 
/*      */ 
/*      */ 
/*      */         
/*  817 */         nameLocalizations(), this.description, 
/*      */         
/*  819 */         descriptionLocalizations(), 
/*  820 */         required(), 
/*  821 */         choices(), 
/*  822 */         options(), 
/*  823 */         autocomplete(), 
/*  824 */         channelTypes(), newValue, 
/*      */         
/*  826 */         maxValue(), 
/*  827 */         minLength(), 
/*  828 */         maxLength());
/*      */   }
/*      */   
/*      */   public ImmutableApplicationCommandOptionData withMaxValue(Possible<Double> value) {
/*  832 */     Possible<Double> newValue = Objects.<Possible<Double>>requireNonNull(value);
/*  833 */     return new ImmutableApplicationCommandOptionData(this, this.type, this.name, 
/*      */ 
/*      */ 
/*      */         
/*  837 */         nameLocalizations(), this.description, 
/*      */         
/*  839 */         descriptionLocalizations(), 
/*  840 */         required(), 
/*  841 */         choices(), 
/*  842 */         options(), 
/*  843 */         autocomplete(), 
/*  844 */         channelTypes(), 
/*  845 */         minValue(), newValue, 
/*      */         
/*  847 */         minLength(), 
/*  848 */         maxLength());
/*      */   }
/*      */   
/*      */   public ImmutableApplicationCommandOptionData withMaxValue(Double value) {
/*  852 */     Possible<Double> newValue = Possible.of(value);
/*  853 */     return new ImmutableApplicationCommandOptionData(this, this.type, this.name, 
/*      */ 
/*      */ 
/*      */         
/*  857 */         nameLocalizations(), this.description, 
/*      */         
/*  859 */         descriptionLocalizations(), 
/*  860 */         required(), 
/*  861 */         choices(), 
/*  862 */         options(), 
/*  863 */         autocomplete(), 
/*  864 */         channelTypes(), 
/*  865 */         minValue(), newValue, 
/*      */         
/*  867 */         minLength(), 
/*  868 */         maxLength());
/*      */   }
/*      */   
/*      */   public ImmutableApplicationCommandOptionData withMinLength(Possible<Integer> value) {
/*  872 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/*  873 */     return new ImmutableApplicationCommandOptionData(this, this.type, this.name, 
/*      */ 
/*      */ 
/*      */         
/*  877 */         nameLocalizations(), this.description, 
/*      */         
/*  879 */         descriptionLocalizations(), 
/*  880 */         required(), 
/*  881 */         choices(), 
/*  882 */         options(), 
/*  883 */         autocomplete(), 
/*  884 */         channelTypes(), 
/*  885 */         minValue(), 
/*  886 */         maxValue(), newValue, 
/*      */         
/*  888 */         maxLength());
/*      */   }
/*      */   
/*      */   public ImmutableApplicationCommandOptionData withMinLength(Integer value) {
/*  892 */     Possible<Integer> newValue = Possible.of(value);
/*  893 */     return new ImmutableApplicationCommandOptionData(this, this.type, this.name, 
/*      */ 
/*      */ 
/*      */         
/*  897 */         nameLocalizations(), this.description, 
/*      */         
/*  899 */         descriptionLocalizations(), 
/*  900 */         required(), 
/*  901 */         choices(), 
/*  902 */         options(), 
/*  903 */         autocomplete(), 
/*  904 */         channelTypes(), 
/*  905 */         minValue(), 
/*  906 */         maxValue(), newValue, 
/*      */         
/*  908 */         maxLength());
/*      */   }
/*      */   
/*      */   public ImmutableApplicationCommandOptionData withMaxLength(Possible<Integer> value) {
/*  912 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/*  913 */     return new ImmutableApplicationCommandOptionData(this, this.type, this.name, 
/*      */ 
/*      */ 
/*      */         
/*  917 */         nameLocalizations(), this.description, 
/*      */         
/*  919 */         descriptionLocalizations(), 
/*  920 */         required(), 
/*  921 */         choices(), 
/*  922 */         options(), 
/*  923 */         autocomplete(), 
/*  924 */         channelTypes(), 
/*  925 */         minValue(), 
/*  926 */         maxValue(), 
/*  927 */         minLength(), newValue);
/*      */   }
/*      */ 
/*      */   
/*      */   public ImmutableApplicationCommandOptionData withMaxLength(Integer value) {
/*  932 */     Possible<Integer> newValue = Possible.of(value);
/*  933 */     return new ImmutableApplicationCommandOptionData(this, this.type, this.name, 
/*      */ 
/*      */ 
/*      */         
/*  937 */         nameLocalizations(), this.description, 
/*      */         
/*  939 */         descriptionLocalizations(), 
/*  940 */         required(), 
/*  941 */         choices(), 
/*  942 */         options(), 
/*  943 */         autocomplete(), 
/*  944 */         channelTypes(), 
/*  945 */         minValue(), 
/*  946 */         maxValue(), 
/*  947 */         minLength(), newValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean equals(Object another) {
/*  957 */     if (this == another) return true; 
/*  958 */     return (another instanceof ImmutableApplicationCommandOptionData && 
/*  959 */       equalTo(0, (ImmutableApplicationCommandOptionData)another));
/*      */   }
/*      */   
/*      */   private boolean equalTo(int synthetic, ImmutableApplicationCommandOptionData another) {
/*  963 */     return (this.type == another.type && this.name
/*  964 */       .equals(another.name) && 
/*  965 */       nameLocalizations().equals(another.nameLocalizations()) && this.description
/*  966 */       .equals(another.description) && 
/*  967 */       descriptionLocalizations().equals(another.descriptionLocalizations()) && 
/*  968 */       required().equals(another.required()) && 
/*  969 */       Objects.equals(this.choices_value, another.choices_value) && 
/*  970 */       Objects.equals(this.options_value, another.options_value) && 
/*  971 */       autocomplete().equals(another.autocomplete()) && 
/*  972 */       Objects.equals(this.channelTypes_value, another.channelTypes_value) && 
/*  973 */       minValue().equals(another.minValue()) && 
/*  974 */       maxValue().equals(another.maxValue()) && 
/*  975 */       minLength().equals(another.minLength()) && 
/*  976 */       maxLength().equals(another.maxLength()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int hashCode() {
/*  985 */     int h = 5381;
/*  986 */     h += (h << 5) + this.type;
/*  987 */     h += (h << 5) + this.name.hashCode();
/*  988 */     h += (h << 5) + nameLocalizations().hashCode();
/*  989 */     h += (h << 5) + this.description.hashCode();
/*  990 */     h += (h << 5) + descriptionLocalizations().hashCode();
/*  991 */     h += (h << 5) + required().hashCode();
/*  992 */     h += (h << 5) + Objects.hashCode(this.choices_value);
/*  993 */     h += (h << 5) + Objects.hashCode(this.options_value);
/*  994 */     h += (h << 5) + autocomplete().hashCode();
/*  995 */     h += (h << 5) + Objects.hashCode(this.channelTypes_value);
/*  996 */     h += (h << 5) + minValue().hashCode();
/*  997 */     h += (h << 5) + maxValue().hashCode();
/*  998 */     h += (h << 5) + minLength().hashCode();
/*  999 */     h += (h << 5) + maxLength().hashCode();
/* 1000 */     return h;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/* 1009 */     return "ApplicationCommandOptionData{type=" + this.type + ", name=" + this.name + ", nameLocalizations=" + 
/*      */ 
/*      */       
/* 1012 */       nameLocalizations().toString() + ", description=" + this.description + ", descriptionLocalizations=" + 
/*      */       
/* 1014 */       descriptionLocalizations().toString() + ", required=" + 
/* 1015 */       required().toString() + ", choices=" + 
/* 1016 */       Objects.toString(this.choices_value) + ", options=" + 
/* 1017 */       Objects.toString(this.options_value) + ", autocomplete=" + 
/* 1018 */       autocomplete().toString() + ", channelTypes=" + 
/* 1019 */       Objects.toString(this.channelTypes_value) + ", minValue=" + 
/* 1020 */       minValue().toString() + ", maxValue=" + 
/* 1021 */       maxValue().toString() + ", minLength=" + 
/* 1022 */       minLength().toString() + ", maxLength=" + 
/* 1023 */       maxLength().toString() + "}";
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonDeserialize
/*      */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*      */   @Generated(from = "ApplicationCommandOptionData", generator = "Immutables")
/*      */   static final class Json
/*      */     implements ApplicationCommandOptionData
/*      */   {
/*      */     int type;
/*      */     
/*      */     boolean typeIsSet;
/*      */     
/*      */     String name;
/*      */     
/* 1040 */     Possible<Optional<Map<String, String>>> nameLocalizations = Possible.absent();
/*      */     
/*      */     String description;
/*      */     
/* 1044 */     Possible<Optional<Map<String, String>>> descriptionLocalizations = Possible.absent();
/*      */ 
/*      */     
/* 1047 */     Possible<Boolean> required = Possible.absent();
/*      */ 
/*      */     
/* 1050 */     Possible<List<ApplicationCommandOptionChoiceData>> choices = Possible.absent();
/*      */ 
/*      */     
/* 1053 */     Possible<List<ApplicationCommandOptionData>> options = Possible.absent();
/*      */ 
/*      */     
/* 1056 */     Possible<Boolean> autocomplete = Possible.absent();
/*      */ 
/*      */     
/* 1059 */     Possible<List<Integer>> channelTypes = Possible.absent();
/*      */ 
/*      */     
/* 1062 */     Possible<Double> minValue = Possible.absent();
/*      */ 
/*      */     
/* 1065 */     Possible<Double> maxValue = Possible.absent();
/*      */ 
/*      */     
/* 1068 */     Possible<Integer> minLength = Possible.absent();
/*      */ 
/*      */     
/* 1071 */     Possible<Integer> maxLength = Possible.absent();
/*      */     
/*      */     @JsonProperty("type")
/*      */     public void setType(int type) {
/* 1075 */       this.type = type;
/* 1076 */       this.typeIsSet = true;
/*      */     }
/*      */     @JsonProperty("name")
/*      */     public void setName(String name) {
/* 1080 */       this.name = name;
/*      */     }
/*      */     @JsonProperty("name_localizations")
/*      */     public void setNameLocalizations(Possible<Optional<Map<String, String>>> nameLocalizations) {
/* 1084 */       this.nameLocalizations = nameLocalizations;
/*      */     }
/*      */     @JsonProperty("description")
/*      */     public void setDescription(String description) {
/* 1088 */       this.description = description;
/*      */     }
/*      */     @JsonProperty("description_localizations")
/*      */     public void setDescriptionLocalizations(Possible<Optional<Map<String, String>>> descriptionLocalizations) {
/* 1092 */       this.descriptionLocalizations = descriptionLocalizations;
/*      */     }
/*      */     @JsonProperty("required")
/*      */     public void setRequired(Possible<Boolean> required) {
/* 1096 */       this.required = required;
/*      */     }
/*      */     @JsonProperty("choices")
/*      */     public void setChoices(Possible<List<ApplicationCommandOptionChoiceData>> choices) {
/* 1100 */       this.choices = choices;
/*      */     }
/*      */     @JsonProperty("options")
/*      */     public void setOptions(Possible<List<ApplicationCommandOptionData>> options) {
/* 1104 */       this.options = options;
/*      */     }
/*      */     @JsonProperty("autocomplete")
/*      */     public void setAutocomplete(Possible<Boolean> autocomplete) {
/* 1108 */       this.autocomplete = autocomplete;
/*      */     }
/*      */     @JsonProperty("channel_types")
/*      */     public void setChannelTypes(Possible<List<Integer>> channelTypes) {
/* 1112 */       this.channelTypes = channelTypes;
/*      */     }
/*      */     @JsonProperty("min_value")
/*      */     public void setMinValue(Possible<Double> minValue) {
/* 1116 */       this.minValue = minValue;
/*      */     }
/*      */     @JsonProperty("max_value")
/*      */     public void setMaxValue(Possible<Double> maxValue) {
/* 1120 */       this.maxValue = maxValue;
/*      */     }
/*      */     @JsonProperty("min_length")
/*      */     public void setMinLength(Possible<Integer> minLength) {
/* 1124 */       this.minLength = minLength;
/*      */     }
/*      */     @JsonProperty("max_length")
/*      */     public void setMaxLength(Possible<Integer> maxLength) {
/* 1128 */       this.maxLength = maxLength;
/*      */     }
/*      */     public int type() {
/* 1131 */       throw new UnsupportedOperationException();
/*      */     } public String name() {
/* 1133 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Optional<Map<String, String>>> nameLocalizations() {
/* 1135 */       throw new UnsupportedOperationException();
/*      */     } public String description() {
/* 1137 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Optional<Map<String, String>>> descriptionLocalizations() {
/* 1139 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Boolean> required() {
/* 1141 */       throw new UnsupportedOperationException();
/*      */     } public Possible<List<ApplicationCommandOptionChoiceData>> choices() {
/* 1143 */       throw new UnsupportedOperationException();
/*      */     } public Possible<List<ApplicationCommandOptionData>> options() {
/* 1145 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Boolean> autocomplete() {
/* 1147 */       throw new UnsupportedOperationException();
/*      */     } public Possible<List<Integer>> channelTypes() {
/* 1149 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Double> minValue() {
/* 1151 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Double> maxValue() {
/* 1153 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Integer> minLength() {
/* 1155 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Integer> maxLength() {
/* 1157 */       throw new UnsupportedOperationException();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*      */   static ImmutableApplicationCommandOptionData fromJson(Json json) {
/* 1168 */     Builder builder = builder();
/* 1169 */     if (json.typeIsSet) {
/* 1170 */       builder.type(json.type);
/*      */     }
/* 1172 */     if (json.name != null) {
/* 1173 */       builder.name(json.name);
/*      */     }
/* 1175 */     if (json.nameLocalizations != null) {
/* 1176 */       builder.nameLocalizations(json.nameLocalizations);
/*      */     }
/* 1178 */     if (json.description != null) {
/* 1179 */       builder.description(json.description);
/*      */     }
/* 1181 */     if (json.descriptionLocalizations != null) {
/* 1182 */       builder.descriptionLocalizations(json.descriptionLocalizations);
/*      */     }
/* 1184 */     if (json.required != null) {
/* 1185 */       builder.required(json.required);
/*      */     }
/* 1187 */     if (json.choices != null) {
/* 1188 */       builder.choices(json.choices);
/*      */     }
/* 1190 */     if (json.options != null) {
/* 1191 */       builder.options(json.options);
/*      */     }
/* 1193 */     if (json.autocomplete != null) {
/* 1194 */       builder.autocomplete(json.autocomplete);
/*      */     }
/* 1196 */     if (json.channelTypes != null) {
/* 1197 */       builder.channelTypes(json.channelTypes);
/*      */     }
/* 1199 */     if (json.minValue != null) {
/* 1200 */       builder.minValue(json.minValue);
/*      */     }
/* 1202 */     if (json.maxValue != null) {
/* 1203 */       builder.maxValue(json.maxValue);
/*      */     }
/* 1205 */     if (json.minLength != null) {
/* 1206 */       builder.minLength(json.minLength);
/*      */     }
/* 1208 */     if (json.maxLength != null) {
/* 1209 */       builder.maxLength(json.maxLength);
/*      */     }
/* 1211 */     return builder.build();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableApplicationCommandOptionData of(int type, String name, Possible<Optional<Map<String, String>>> nameLocalizations, String description, Possible<Optional<Map<String, String>>> descriptionLocalizations, Possible<Boolean> required, Possible<List<ApplicationCommandOptionChoiceData>> choices, Possible<List<ApplicationCommandOptionData>> options, Possible<Boolean> autocomplete, Possible<List<Integer>> channelTypes, Possible<Double> minValue, Possible<Double> maxValue, Possible<Integer> minLength, Possible<Integer> maxLength) {
/* 1233 */     return new ImmutableApplicationCommandOptionData(type, name, nameLocalizations, description, descriptionLocalizations, required, choices, options, autocomplete, channelTypes, minValue, maxValue, minLength, maxLength);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableApplicationCommandOptionData copyOf(ApplicationCommandOptionData instance) {
/* 1244 */     if (instance instanceof ImmutableApplicationCommandOptionData) {
/* 1245 */       return (ImmutableApplicationCommandOptionData)instance;
/*      */     }
/* 1247 */     return builder()
/* 1248 */       .from(instance)
/* 1249 */       .build();
/*      */   }
/*      */   
/*      */   public boolean isNameLocalizationsPresent() {
/* 1253 */     return !this.nameLocalizations_absent;
/*      */   }
/*      */   
/*      */   public Map<String, String> nameLocalizationsOrElse(Map<String, String> defaultValue) {
/* 1257 */     return !this.nameLocalizations_absent ? this.nameLocalizations_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isDescriptionLocalizationsPresent() {
/* 1261 */     return !this.descriptionLocalizations_absent;
/*      */   }
/*      */   
/*      */   public Map<String, String> descriptionLocalizationsOrElse(Map<String, String> defaultValue) {
/* 1265 */     return !this.descriptionLocalizations_absent ? this.descriptionLocalizations_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isRequiredPresent() {
/* 1269 */     return !this.required_absent;
/*      */   }
/*      */   
/*      */   public Boolean requiredOrElse(Boolean defaultValue) {
/* 1273 */     return !this.required_absent ? this.required_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isChoicesPresent() {
/* 1277 */     return !this.choices_absent;
/*      */   }
/*      */   
/*      */   public List<ApplicationCommandOptionChoiceData> choicesOrElse(List<ApplicationCommandOptionChoiceData> defaultValue) {
/* 1281 */     return !this.choices_absent ? this.choices_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isOptionsPresent() {
/* 1285 */     return !this.options_absent;
/*      */   }
/*      */   
/*      */   public List<ApplicationCommandOptionData> optionsOrElse(List<ApplicationCommandOptionData> defaultValue) {
/* 1289 */     return !this.options_absent ? this.options_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isAutocompletePresent() {
/* 1293 */     return !this.autocomplete_absent;
/*      */   }
/*      */   
/*      */   public Boolean autocompleteOrElse(Boolean defaultValue) {
/* 1297 */     return !this.autocomplete_absent ? this.autocomplete_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isChannelTypesPresent() {
/* 1301 */     return !this.channelTypes_absent;
/*      */   }
/*      */   
/*      */   public List<Integer> channelTypesOrElse(List<Integer> defaultValue) {
/* 1305 */     return !this.channelTypes_absent ? this.channelTypes_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isMinValuePresent() {
/* 1309 */     return !this.minValue_absent;
/*      */   }
/*      */   
/*      */   public Double minValueOrElse(Double defaultValue) {
/* 1313 */     return !this.minValue_absent ? this.minValue_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isMaxValuePresent() {
/* 1317 */     return !this.maxValue_absent;
/*      */   }
/*      */   
/*      */   public Double maxValueOrElse(Double defaultValue) {
/* 1321 */     return !this.maxValue_absent ? this.maxValue_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isMinLengthPresent() {
/* 1325 */     return !this.minLength_absent;
/*      */   }
/*      */   
/*      */   public Integer minLengthOrElse(Integer defaultValue) {
/* 1329 */     return !this.minLength_absent ? this.minLength_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isMaxLengthPresent() {
/* 1333 */     return !this.maxLength_absent;
/*      */   }
/*      */   
/*      */   public Integer maxLengthOrElse(Integer defaultValue) {
/* 1337 */     return !this.maxLength_absent ? this.maxLength_value : defaultValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Builder builder() {
/* 1363 */     return new Builder();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   @Generated(from = "ApplicationCommandOptionData", generator = "Immutables")
/*      */   public static final class Builder
/*      */   {
/*      */     private static final long INIT_BIT_TYPE = 1L;
/*      */ 
/*      */     
/*      */     private static final long INIT_BIT_NAME = 2L;
/*      */     
/*      */     private static final long INIT_BIT_DESCRIPTION = 4L;
/*      */     
/* 1378 */     private long initBits = 7L;
/*      */     
/* 1380 */     private Possible<Optional<Map<String, String>>> nameLocalizations_possible = Possible.absent();
/* 1381 */     private Possible<Optional<Map<String, String>>> descriptionLocalizations_possible = Possible.absent();
/* 1382 */     private Possible<Boolean> required_possible = Possible.absent();
/* 1383 */     private List<ApplicationCommandOptionChoiceData> choices_list = null;
/* 1384 */     private List<ApplicationCommandOptionData> options_list = null;
/* 1385 */     private Possible<Boolean> autocomplete_possible = Possible.absent();
/* 1386 */     private List<Integer> channelTypes_list = null;
/* 1387 */     private Possible<Double> minValue_possible = Possible.absent();
/* 1388 */     private Possible<Double> maxValue_possible = Possible.absent();
/* 1389 */     private Possible<Integer> minLength_possible = Possible.absent();
/* 1390 */     private Possible<Integer> maxLength_possible = Possible.absent();
/*      */ 
/*      */ 
/*      */     
/*      */     private int type;
/*      */ 
/*      */ 
/*      */     
/*      */     private String name;
/*      */ 
/*      */     
/*      */     private String description;
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder from(ApplicationCommandOptionData instance) {
/* 1406 */       Objects.requireNonNull(instance, "instance");
/* 1407 */       type(instance.type());
/* 1408 */       name(instance.name());
/* 1409 */       nameLocalizations(instance.nameLocalizations());
/* 1410 */       description(instance.description());
/* 1411 */       descriptionLocalizations(instance.descriptionLocalizations());
/* 1412 */       required(instance.required());
/* 1413 */       choices(instance.choices());
/* 1414 */       options(instance.options());
/* 1415 */       autocomplete(instance.autocomplete());
/* 1416 */       channelTypes(instance.channelTypes());
/* 1417 */       minValue(instance.minValue());
/* 1418 */       maxValue(instance.maxValue());
/* 1419 */       minLength(instance.minLength());
/* 1420 */       maxLength(instance.maxLength());
/* 1421 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("type")
/*      */     public final Builder type(int type) {
/* 1431 */       this.type = type;
/* 1432 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 1433 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("name")
/*      */     public final Builder name(String name) {
/* 1443 */       this.name = Objects.<String>requireNonNull(name, "name");
/* 1444 */       this.initBits &= 0xFFFFFFFFFFFFFFFDL;
/* 1445 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("name_localizations")
/*      */     public Builder nameLocalizations(Possible<Optional<Map<String, String>>> value) {
/* 1450 */       this.nameLocalizations_possible = value;
/* 1451 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public Builder nameLocalizations(@Nullable Map<String, String> value) {
/* 1456 */       this.nameLocalizations_possible = Possible.of(Optional.ofNullable(value));
/* 1457 */       return this;
/*      */     }
/*      */     
/*      */     public Builder nameLocalizationsOrNull(@Nullable Map<String, String> value) {
/* 1461 */       this.nameLocalizations_possible = Possible.of(Optional.ofNullable(value));
/* 1462 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("description")
/*      */     public final Builder description(String description) {
/* 1472 */       this.description = Objects.<String>requireNonNull(description, "description");
/* 1473 */       this.initBits &= 0xFFFFFFFFFFFFFFFBL;
/* 1474 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("description_localizations")
/*      */     public Builder descriptionLocalizations(Possible<Optional<Map<String, String>>> value) {
/* 1479 */       this.descriptionLocalizations_possible = value;
/* 1480 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public Builder descriptionLocalizations(@Nullable Map<String, String> value) {
/* 1485 */       this.descriptionLocalizations_possible = Possible.of(Optional.ofNullable(value));
/* 1486 */       return this;
/*      */     }
/*      */     
/*      */     public Builder descriptionLocalizationsOrNull(@Nullable Map<String, String> value) {
/* 1490 */       this.descriptionLocalizations_possible = Possible.of(Optional.ofNullable(value));
/* 1491 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("required")
/*      */     public Builder required(Possible<Boolean> value) {
/* 1496 */       this.required_possible = value;
/* 1497 */       return this;
/*      */     }
/*      */     
/*      */     public Builder required(Boolean value) {
/* 1501 */       this.required_possible = Possible.of(value);
/* 1502 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addChoice(ApplicationCommandOptionChoiceData element) {
/* 1506 */       choices_getOrCreate().add(element);
/* 1507 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addAllChoices(List<ApplicationCommandOptionChoiceData> elements) {
/* 1511 */       choices_getOrCreate().addAll(elements);
/* 1512 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("choices")
/*      */     public Builder choices(Possible<List<ApplicationCommandOptionChoiceData>> elements) {
/* 1517 */       this.choices_list = null;
/* 1518 */       elements.toOptional().ifPresent(e -> choices_getOrCreate().addAll(e));
/* 1519 */       return this;
/*      */     }
/*      */     
/*      */     public Builder choices(List<ApplicationCommandOptionChoiceData> elements) {
/* 1523 */       this.choices_list = new ArrayList<>(elements);
/* 1524 */       return this;
/*      */     }
/*      */     
/*      */     public Builder choices(Iterable<ApplicationCommandOptionChoiceData> elements) {
/* 1528 */       this.choices_list = (List<ApplicationCommandOptionChoiceData>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/* 1529 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addOption(ApplicationCommandOptionData element) {
/* 1533 */       options_getOrCreate().add(element);
/* 1534 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addAllOptions(List<ApplicationCommandOptionData> elements) {
/* 1538 */       options_getOrCreate().addAll(elements);
/* 1539 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("options")
/*      */     public Builder options(Possible<List<ApplicationCommandOptionData>> elements) {
/* 1544 */       this.options_list = null;
/* 1545 */       elements.toOptional().ifPresent(e -> options_getOrCreate().addAll(e));
/* 1546 */       return this;
/*      */     }
/*      */     
/*      */     public Builder options(List<ApplicationCommandOptionData> elements) {
/* 1550 */       this.options_list = new ArrayList<>(elements);
/* 1551 */       return this;
/*      */     }
/*      */     
/*      */     public Builder options(Iterable<ApplicationCommandOptionData> elements) {
/* 1555 */       this.options_list = (List<ApplicationCommandOptionData>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/* 1556 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("autocomplete")
/*      */     public Builder autocomplete(Possible<Boolean> value) {
/* 1561 */       this.autocomplete_possible = value;
/* 1562 */       return this;
/*      */     }
/*      */     
/*      */     public Builder autocomplete(Boolean value) {
/* 1566 */       this.autocomplete_possible = Possible.of(value);
/* 1567 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addChannelType(Integer element) {
/* 1571 */       channelTypes_getOrCreate().add(element);
/* 1572 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addAllChannelTypes(List<Integer> elements) {
/* 1576 */       channelTypes_getOrCreate().addAll(elements);
/* 1577 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("channel_types")
/*      */     public Builder channelTypes(Possible<List<Integer>> elements) {
/* 1582 */       this.channelTypes_list = null;
/* 1583 */       elements.toOptional().ifPresent(e -> channelTypes_getOrCreate().addAll(e));
/* 1584 */       return this;
/*      */     }
/*      */     
/*      */     public Builder channelTypes(List<Integer> elements) {
/* 1588 */       this.channelTypes_list = new ArrayList<>(elements);
/* 1589 */       return this;
/*      */     }
/*      */     
/*      */     public Builder channelTypes(Iterable<Integer> elements) {
/* 1593 */       this.channelTypes_list = (List<Integer>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/* 1594 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("min_value")
/*      */     public Builder minValue(Possible<Double> value) {
/* 1599 */       this.minValue_possible = value;
/* 1600 */       return this;
/*      */     }
/*      */     
/*      */     public Builder minValue(Double value) {
/* 1604 */       this.minValue_possible = Possible.of(value);
/* 1605 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("max_value")
/*      */     public Builder maxValue(Possible<Double> value) {
/* 1610 */       this.maxValue_possible = value;
/* 1611 */       return this;
/*      */     }
/*      */     
/*      */     public Builder maxValue(Double value) {
/* 1615 */       this.maxValue_possible = Possible.of(value);
/* 1616 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("min_length")
/*      */     public Builder minLength(Possible<Integer> value) {
/* 1621 */       this.minLength_possible = value;
/* 1622 */       return this;
/*      */     }
/*      */     
/*      */     public Builder minLength(Integer value) {
/* 1626 */       this.minLength_possible = Possible.of(value);
/* 1627 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("max_length")
/*      */     public Builder maxLength(Possible<Integer> value) {
/* 1632 */       this.maxLength_possible = value;
/* 1633 */       return this;
/*      */     }
/*      */     
/*      */     public Builder maxLength(Integer value) {
/* 1637 */       this.maxLength_possible = Possible.of(value);
/* 1638 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ImmutableApplicationCommandOptionData build() {
/* 1647 */       if (this.initBits != 0L) {
/* 1648 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*      */       }
/* 1650 */       return new ImmutableApplicationCommandOptionData(null, this.type, this.name, 
/*      */ 
/*      */ 
/*      */           
/* 1654 */           nameLocalizations_build(), this.description, 
/*      */           
/* 1656 */           descriptionLocalizations_build(), 
/* 1657 */           required_build(), 
/* 1658 */           choices_build(), 
/* 1659 */           options_build(), 
/* 1660 */           autocomplete_build(), 
/* 1661 */           channelTypes_build(), 
/* 1662 */           minValue_build(), 
/* 1663 */           maxValue_build(), 
/* 1664 */           minLength_build(), 
/* 1665 */           maxLength_build());
/*      */     }
/*      */     
/*      */     private String formatRequiredAttributesMessage() {
/* 1669 */       List<String> attributes = new ArrayList<>();
/* 1670 */       if ((this.initBits & 0x1L) != 0L) attributes.add("type"); 
/* 1671 */       if ((this.initBits & 0x2L) != 0L) attributes.add("name"); 
/* 1672 */       if ((this.initBits & 0x4L) != 0L) attributes.add("description"); 
/* 1673 */       return "Cannot build ApplicationCommandOptionData, some of required attributes are not set " + attributes;
/*      */     }
/*      */     
/*      */     private Possible<Optional<Map<String, String>>> nameLocalizations_build() {
/* 1677 */       return this.nameLocalizations_possible;
/*      */     }
/*      */     
/*      */     private Possible<Optional<Map<String, String>>> descriptionLocalizations_build() {
/* 1681 */       return this.descriptionLocalizations_possible;
/*      */     }
/*      */     
/*      */     private Possible<Boolean> required_build() {
/* 1685 */       return this.required_possible;
/*      */     }
/*      */     
/*      */     private Possible<List<ApplicationCommandOptionChoiceData>> choices_build() {
/* 1689 */       return (this.choices_list == null) ? Possible.absent() : 
/* 1690 */         Possible.of(this.choices_list);
/*      */     }
/*      */     
/*      */     private List<ApplicationCommandOptionChoiceData> choices_getOrCreate() {
/* 1694 */       if (this.choices_list == null) {
/* 1695 */         this.choices_list = new ArrayList<>();
/*      */       }
/* 1697 */       return this.choices_list;
/*      */     }
/*      */     
/*      */     private Possible<List<ApplicationCommandOptionData>> options_build() {
/* 1701 */       return (this.options_list == null) ? Possible.absent() : 
/* 1702 */         Possible.of(this.options_list);
/*      */     }
/*      */     
/*      */     private List<ApplicationCommandOptionData> options_getOrCreate() {
/* 1706 */       if (this.options_list == null) {
/* 1707 */         this.options_list = new ArrayList<>();
/*      */       }
/* 1709 */       return this.options_list;
/*      */     }
/*      */     
/*      */     private Possible<Boolean> autocomplete_build() {
/* 1713 */       return this.autocomplete_possible;
/*      */     }
/*      */     
/*      */     private Possible<List<Integer>> channelTypes_build() {
/* 1717 */       return (this.channelTypes_list == null) ? Possible.absent() : 
/* 1718 */         Possible.of(this.channelTypes_list);
/*      */     }
/*      */     
/*      */     private List<Integer> channelTypes_getOrCreate() {
/* 1722 */       if (this.channelTypes_list == null) {
/* 1723 */         this.channelTypes_list = new ArrayList<>();
/*      */       }
/* 1725 */       return this.channelTypes_list;
/*      */     }
/*      */     
/*      */     private Possible<Double> minValue_build() {
/* 1729 */       return this.minValue_possible;
/*      */     }
/*      */     
/*      */     private Possible<Double> maxValue_build() {
/* 1733 */       return this.maxValue_possible;
/*      */     }
/*      */     
/*      */     private Possible<Integer> minLength_build() {
/* 1737 */       return this.minLength_possible;
/*      */     }
/*      */     
/*      */     private Possible<Integer> maxLength_build() {
/* 1741 */       return this.maxLength_possible;
/*      */     }
/*      */     
/*      */     private Builder() {}
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableApplicationCommandOptionData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */