/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.Id;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "UnavailableGuildCreateData", generator = "Immutables")
/*     */ public final class ImmutableUnavailableGuildCreateData
/*     */   implements UnavailableGuildCreateData
/*     */ {
/*     */   private final long id_value;
/*     */   private final boolean unavailable;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   
/*     */   private ImmutableUnavailableGuildCreateData(Id id, boolean unavailable) {
/*  30 */     Id id$impl = id;
/*  31 */     this.unavailable = unavailable;
/*  32 */     this.id_value = id$impl.asLong();
/*  33 */     this.initShim = null;
/*     */   }
/*     */   
/*     */   private ImmutableUnavailableGuildCreateData(ImmutableUnavailableGuildCreateData original, Id id, boolean unavailable) {
/*  37 */     Id id$impl = id;
/*  38 */     this.unavailable = unavailable;
/*  39 */     this.id_value = id$impl.asLong();
/*  40 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  46 */   private volatile transient InitShim initShim = new InitShim();
/*     */   
/*     */   @Generated(from = "UnavailableGuildCreateData", generator = "Immutables")
/*     */   private final class InitShim {
/*     */     private String formatInitCycleMessage() {
/*  51 */       List<String> attributes = new ArrayList<>();
/*  52 */       return "Cannot build UnavailableGuildCreateData, attribute initializers form cycle " + attributes;
/*     */     }
/*     */ 
/*     */     
/*     */     private InitShim() {}
/*     */   }
/*     */ 
/*     */   
/*     */   @JsonProperty("id")
/*     */   public Id id() {
/*  62 */     return Id.of(this.id_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("unavailable")
/*     */   public boolean unavailable() {
/*  71 */     return this.unavailable;
/*     */   }
/*     */   
/*     */   public ImmutableUnavailableGuildCreateData withId(long value) {
/*  75 */     Id newValue = Id.of(value);
/*  76 */     return new ImmutableUnavailableGuildCreateData(this, newValue, this.unavailable);
/*     */   }
/*     */   
/*     */   public ImmutableUnavailableGuildCreateData withId(String value) {
/*  80 */     Id newValue = Id.of(value);
/*  81 */     return new ImmutableUnavailableGuildCreateData(this, newValue, this.unavailable);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableUnavailableGuildCreateData withUnavailable(boolean value) {
/*  91 */     if (this.unavailable == value) return this; 
/*  92 */     return new ImmutableUnavailableGuildCreateData(this, id(), value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 101 */     if (this == another) return true; 
/* 102 */     return (another instanceof ImmutableUnavailableGuildCreateData && 
/* 103 */       equalTo(0, (ImmutableUnavailableGuildCreateData)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableUnavailableGuildCreateData another) {
/* 107 */     return (Objects.equals(Long.valueOf(this.id_value), Long.valueOf(another.id_value)) && this.unavailable == another.unavailable);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 117 */     int h = 5381;
/* 118 */     h += (h << 5) + Objects.hashCode(Long.valueOf(this.id_value));
/* 119 */     h += (h << 5) + Boolean.hashCode(this.unavailable);
/* 120 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 129 */     return "UnavailableGuildCreateData{id=" + 
/* 130 */       Objects.toString(Long.valueOf(this.id_value)) + ", unavailable=" + this.unavailable + "}";
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "UnavailableGuildCreateData", generator = "Immutables")
/*     */   static final class Json
/*     */     implements UnavailableGuildCreateData
/*     */   {
/*     */     Id id;
/*     */     
/*     */     boolean unavailable;
/*     */     
/*     */     boolean unavailableIsSet;
/*     */     
/*     */     @JsonProperty("id")
/*     */     public void setId(Id id) {
/* 149 */       this.id = id;
/*     */     }
/*     */     @JsonProperty("unavailable")
/*     */     public void setUnavailable(boolean unavailable) {
/* 153 */       this.unavailable = unavailable;
/* 154 */       this.unavailableIsSet = true;
/*     */     }
/*     */     public Id id() {
/* 157 */       throw new UnsupportedOperationException();
/*     */     } public boolean unavailable() {
/* 159 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableUnavailableGuildCreateData fromJson(Json json) {
/* 170 */     Builder builder = builder();
/* 171 */     if (json.id != null) {
/* 172 */       builder.id(json.id);
/*     */     }
/* 174 */     if (json.unavailableIsSet) {
/* 175 */       builder.unavailable(json.unavailable);
/*     */     }
/* 177 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableUnavailableGuildCreateData of(Id id, boolean unavailable) {
/* 187 */     return new ImmutableUnavailableGuildCreateData(id, unavailable);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableUnavailableGuildCreateData copyOf(UnavailableGuildCreateData instance) {
/* 198 */     if (instance instanceof ImmutableUnavailableGuildCreateData) {
/* 199 */       return (ImmutableUnavailableGuildCreateData)instance;
/*     */     }
/* 201 */     return builder()
/* 202 */       .from(instance)
/* 203 */       .build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 217 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "UnavailableGuildCreateData", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_UNAVAILABLE = 1L;
/*     */ 
/*     */ 
/*     */     
/* 230 */     private long initBits = 1L;
/*     */     
/* 232 */     private Id id_id = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private boolean unavailable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(UnavailableGuildCreateData instance) {
/* 246 */       Objects.requireNonNull(instance, "instance");
/* 247 */       id(instance.id());
/* 248 */       unavailable(instance.unavailable());
/* 249 */       return this;
/*     */     }
/*     */     
/*     */     public Builder id(String value) {
/* 253 */       this.id_id = Id.of(value);
/* 254 */       return this;
/*     */     }
/*     */     
/*     */     public Builder id(long value) {
/* 258 */       this.id_id = Id.of(value);
/* 259 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("id")
/*     */     public Builder id(Id value) {
/* 264 */       this.id_id = value;
/* 265 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("unavailable")
/*     */     public final Builder unavailable(boolean unavailable) {
/* 275 */       this.unavailable = unavailable;
/* 276 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 277 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableUnavailableGuildCreateData build() {
/* 286 */       if (this.initBits != 0L) {
/* 287 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 289 */       return new ImmutableUnavailableGuildCreateData(null, id_build(), this.unavailable);
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 293 */       List<String> attributes = new ArrayList<>();
/* 294 */       if ((this.initBits & 0x1L) != 0L) attributes.add("unavailable"); 
/* 295 */       return "Cannot build UnavailableGuildCreateData, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Id id_build() {
/* 299 */       return this.id_id;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableUnavailableGuildCreateData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */