/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "UserModifyRequest", generator = "Immutables")
/*     */ public final class ImmutableUserModifyRequest
/*     */   implements UserModifyRequest
/*     */ {
/*     */   private final String username_value;
/*     */   private final boolean username_absent;
/*     */   private final String avatar_value;
/*     */   private final boolean avatar_absent;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   
/*     */   private ImmutableUserModifyRequest(Possible<String> username, Possible<String> avatar) {
/*  33 */     Possible<String> username$impl = username;
/*  34 */     Possible<String> avatar$impl = avatar;
/*  35 */     this.username_value = username$impl.toOptional().orElse(null);
/*  36 */     this.username_absent = username$impl.isAbsent();
/*  37 */     this.avatar_value = avatar$impl.toOptional().orElse(null);
/*  38 */     this.avatar_absent = avatar$impl.isAbsent();
/*  39 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ImmutableUserModifyRequest(ImmutableUserModifyRequest original, Possible<String> username, Possible<String> avatar) {
/*  46 */     Possible<String> username$impl = username;
/*  47 */     Possible<String> avatar$impl = avatar;
/*  48 */     this.username_value = username$impl.toOptional().orElse(null);
/*  49 */     this.username_absent = username$impl.isAbsent();
/*  50 */     this.avatar_value = avatar$impl.toOptional().orElse(null);
/*  51 */     this.avatar_absent = avatar$impl.isAbsent();
/*  52 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  58 */   private volatile transient InitShim initShim = new InitShim();
/*     */   
/*     */   @Generated(from = "UserModifyRequest", generator = "Immutables")
/*     */   private final class InitShim {
/*     */     private String formatInitCycleMessage() {
/*  63 */       List<String> attributes = new ArrayList<>();
/*  64 */       return "Cannot build UserModifyRequest, attribute initializers form cycle " + attributes;
/*     */     }
/*     */ 
/*     */     
/*     */     private InitShim() {}
/*     */   }
/*     */ 
/*     */   
/*     */   @JsonProperty("username")
/*     */   public Possible<String> username() {
/*  74 */     return this.username_absent ? Possible.absent() : Possible.of(this.username_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("avatar")
/*     */   public Possible<String> avatar() {
/*  83 */     return this.avatar_absent ? Possible.absent() : Possible.of(this.avatar_value);
/*     */   }
/*     */   
/*     */   public ImmutableUserModifyRequest withUsername(Possible<String> value) {
/*  87 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/*  88 */     return new ImmutableUserModifyRequest(this, newValue, avatar());
/*     */   }
/*     */   
/*     */   public ImmutableUserModifyRequest withUsername(String value) {
/*  92 */     Possible<String> newValue = Possible.of(value);
/*  93 */     return new ImmutableUserModifyRequest(this, newValue, avatar());
/*     */   }
/*     */   
/*     */   public ImmutableUserModifyRequest withAvatar(Possible<String> value) {
/*  97 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/*  98 */     return new ImmutableUserModifyRequest(this, username(), newValue);
/*     */   }
/*     */   
/*     */   public ImmutableUserModifyRequest withAvatar(String value) {
/* 102 */     Possible<String> newValue = Possible.of(value);
/* 103 */     return new ImmutableUserModifyRequest(this, username(), newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 112 */     if (this == another) return true; 
/* 113 */     return (another instanceof ImmutableUserModifyRequest && 
/* 114 */       equalTo(0, (ImmutableUserModifyRequest)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableUserModifyRequest another) {
/* 118 */     return (username().equals(another.username()) && 
/* 119 */       avatar().equals(another.avatar()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 128 */     int h = 5381;
/* 129 */     h += (h << 5) + username().hashCode();
/* 130 */     h += (h << 5) + avatar().hashCode();
/* 131 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 140 */     return "UserModifyRequest{username=" + 
/* 141 */       username().toString() + ", avatar=" + 
/* 142 */       avatar().toString() + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "UserModifyRequest", generator = "Immutables")
/*     */   static final class Json
/*     */     implements UserModifyRequest
/*     */   {
/* 156 */     Possible<String> username = Possible.absent();
/*     */ 
/*     */     
/* 159 */     Possible<String> avatar = Possible.absent();
/*     */     
/*     */     @JsonProperty("username")
/*     */     public void setUsername(Possible<String> username) {
/* 163 */       this.username = username;
/*     */     }
/*     */     @JsonProperty("avatar")
/*     */     public void setAvatar(Possible<String> avatar) {
/* 167 */       this.avatar = avatar;
/*     */     }
/*     */     public Possible<String> username() {
/* 170 */       throw new UnsupportedOperationException();
/*     */     } public Possible<String> avatar() {
/* 172 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableUserModifyRequest fromJson(Json json) {
/* 183 */     Builder builder = builder();
/* 184 */     if (json.username != null) {
/* 185 */       builder.username(json.username);
/*     */     }
/* 187 */     if (json.avatar != null) {
/* 188 */       builder.avatar(json.avatar);
/*     */     }
/* 190 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableUserModifyRequest of(Possible<String> username, Possible<String> avatar) {
/* 200 */     return new ImmutableUserModifyRequest(username, avatar);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableUserModifyRequest copyOf(UserModifyRequest instance) {
/* 211 */     if (instance instanceof ImmutableUserModifyRequest) {
/* 212 */       return (ImmutableUserModifyRequest)instance;
/*     */     }
/* 214 */     return builder()
/* 215 */       .from(instance)
/* 216 */       .build();
/*     */   }
/*     */   
/*     */   public boolean isUsernamePresent() {
/* 220 */     return !this.username_absent;
/*     */   }
/*     */   
/*     */   public String usernameOrElse(String defaultValue) {
/* 224 */     return !this.username_absent ? this.username_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isAvatarPresent() {
/* 228 */     return !this.avatar_absent;
/*     */   }
/*     */   
/*     */   public String avatarOrElse(String defaultValue) {
/* 232 */     return !this.avatar_absent ? this.avatar_value : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 246 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "UserModifyRequest", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/* 258 */     private Possible<String> username_possible = Possible.absent();
/* 259 */     private Possible<String> avatar_possible = Possible.absent();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(UserModifyRequest instance) {
/* 272 */       Objects.requireNonNull(instance, "instance");
/* 273 */       username(instance.username());
/* 274 */       avatar(instance.avatar());
/* 275 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("username")
/*     */     public Builder username(Possible<String> value) {
/* 280 */       this.username_possible = value;
/* 281 */       return this;
/*     */     }
/*     */     
/*     */     public Builder username(String value) {
/* 285 */       this.username_possible = Possible.of(value);
/* 286 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("avatar")
/*     */     public Builder avatar(Possible<String> value) {
/* 291 */       this.avatar_possible = value;
/* 292 */       return this;
/*     */     }
/*     */     
/*     */     public Builder avatar(String value) {
/* 296 */       this.avatar_possible = Possible.of(value);
/* 297 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableUserModifyRequest build() {
/* 306 */       return new ImmutableUserModifyRequest(null, username_build(), avatar_build());
/*     */     }
/*     */     
/*     */     private Possible<String> username_build() {
/* 310 */       return this.username_possible;
/*     */     }
/*     */     
/*     */     private Possible<String> avatar_build() {
/* 314 */       return this.avatar_possible;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableUserModifyRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */