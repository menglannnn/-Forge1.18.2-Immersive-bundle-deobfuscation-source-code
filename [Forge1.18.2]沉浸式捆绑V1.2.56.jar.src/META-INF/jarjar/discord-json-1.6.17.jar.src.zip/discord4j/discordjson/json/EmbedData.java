/*    */ package discord4j.discordjson.json;
/*    */ 
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import java.util.List;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ 
/*    */ @JsonSerialize(as = ImmutableEmbedData.class)
/*    */ @JsonDeserialize(as = ImmutableEmbedData.class)
/*    */ @Immutable
/*    */ public interface EmbedData
/*    */ {
/*    */   static ImmutableEmbedData.Builder builder() {
/* 16 */     return ImmutableEmbedData.builder();
/*    */   }
/*    */   
/*    */   Possible<String> title();
/*    */   
/*    */   Possible<String> type();
/*    */   
/*    */   Possible<String> description();
/*    */   
/*    */   Possible<String> url();
/*    */   
/*    */   Possible<String> timestamp();
/*    */   
/*    */   Possible<Integer> color();
/*    */   
/*    */   Possible<EmbedFooterData> footer();
/*    */   
/*    */   Possible<EmbedImageData> image();
/*    */   
/*    */   Possible<EmbedThumbnailData> thumbnail();
/*    */   
/*    */   Possible<EmbedVideoData> video();
/*    */   
/*    */   Possible<EmbedProviderData> provider();
/*    */   
/*    */   Possible<EmbedAuthorData> author();
/*    */   
/*    */   Possible<List<EmbedFieldData>> fields();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\EmbedData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */