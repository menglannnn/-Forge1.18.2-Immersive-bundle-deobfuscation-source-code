/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.Id;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "OverwriteData", generator = "Immutables")
/*     */ public final class ImmutableOverwriteData
/*     */   implements OverwriteData
/*     */ {
/*     */   private final long id_value;
/*     */   private final int type;
/*     */   private final long allow;
/*     */   private final long deny;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   
/*     */   private ImmutableOverwriteData(Id id, int type, long allow, long deny) {
/*  31 */     Id id$impl = id;
/*  32 */     this.type = type;
/*  33 */     this.allow = allow;
/*  34 */     this.deny = deny;
/*  35 */     this.id_value = id$impl.asLong();
/*  36 */     this.initShim = null;
/*     */   }
/*     */   
/*     */   private ImmutableOverwriteData(ImmutableOverwriteData original, Id id, int type, long allow, long deny) {
/*  40 */     Id id$impl = id;
/*  41 */     this.type = type;
/*  42 */     this.allow = allow;
/*  43 */     this.deny = deny;
/*  44 */     this.id_value = id$impl.asLong();
/*  45 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  51 */   private volatile transient InitShim initShim = new InitShim();
/*     */   
/*     */   @Generated(from = "OverwriteData", generator = "Immutables")
/*     */   private final class InitShim {
/*     */     private String formatInitCycleMessage() {
/*  56 */       List<String> attributes = new ArrayList<>();
/*  57 */       return "Cannot build OverwriteData, attribute initializers form cycle " + attributes;
/*     */     }
/*     */ 
/*     */     
/*     */     private InitShim() {}
/*     */   }
/*     */ 
/*     */   
/*     */   @JsonProperty("id")
/*     */   public Id id() {
/*  67 */     return Id.of(this.id_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("type")
/*     */   public int type() {
/*  76 */     return this.type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("allow")
/*     */   public long allow() {
/*  85 */     return this.allow;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("deny")
/*     */   public long deny() {
/*  94 */     return this.deny;
/*     */   }
/*     */   
/*     */   public ImmutableOverwriteData withId(long value) {
/*  98 */     Id newValue = Id.of(value);
/*  99 */     return new ImmutableOverwriteData(this, newValue, this.type, this.allow, this.deny);
/*     */   }
/*     */   
/*     */   public ImmutableOverwriteData withId(String value) {
/* 103 */     Id newValue = Id.of(value);
/* 104 */     return new ImmutableOverwriteData(this, newValue, this.type, this.allow, this.deny);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableOverwriteData withType(int value) {
/* 114 */     if (this.type == value) return this; 
/* 115 */     return new ImmutableOverwriteData(this, id(), value, this.allow, this.deny);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableOverwriteData withAllow(long value) {
/* 125 */     if (this.allow == value) return this; 
/* 126 */     return new ImmutableOverwriteData(this, id(), this.type, value, this.deny);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableOverwriteData withDeny(long value) {
/* 136 */     if (this.deny == value) return this; 
/* 137 */     return new ImmutableOverwriteData(this, id(), this.type, this.allow, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 146 */     if (this == another) return true; 
/* 147 */     return (another instanceof ImmutableOverwriteData && 
/* 148 */       equalTo(0, (ImmutableOverwriteData)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableOverwriteData another) {
/* 152 */     return (Objects.equals(Long.valueOf(this.id_value), Long.valueOf(another.id_value)) && this.type == another.type && this.allow == another.allow && this.deny == another.deny);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 164 */     int h = 5381;
/* 165 */     h += (h << 5) + Objects.hashCode(Long.valueOf(this.id_value));
/* 166 */     h += (h << 5) + this.type;
/* 167 */     h += (h << 5) + Long.hashCode(this.allow);
/* 168 */     h += (h << 5) + Long.hashCode(this.deny);
/* 169 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 178 */     return "OverwriteData{id=" + 
/* 179 */       Objects.toString(Long.valueOf(this.id_value)) + ", type=" + this.type + ", allow=" + this.allow + ", deny=" + this.deny + "}";
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "OverwriteData", generator = "Immutables")
/*     */   static final class Json
/*     */     implements OverwriteData
/*     */   {
/*     */     Id id;
/*     */     
/*     */     int type;
/*     */     
/*     */     boolean typeIsSet;
/*     */     
/*     */     long allow;
/*     */     
/*     */     boolean allowIsSet;
/*     */     long deny;
/*     */     boolean denyIsSet;
/*     */     
/*     */     @JsonProperty("id")
/*     */     public void setId(Id id) {
/* 204 */       this.id = id;
/*     */     }
/*     */     @JsonProperty("type")
/*     */     public void setType(int type) {
/* 208 */       this.type = type;
/* 209 */       this.typeIsSet = true;
/*     */     }
/*     */     @JsonProperty("allow")
/*     */     public void setAllow(long allow) {
/* 213 */       this.allow = allow;
/* 214 */       this.allowIsSet = true;
/*     */     }
/*     */     @JsonProperty("deny")
/*     */     public void setDeny(long deny) {
/* 218 */       this.deny = deny;
/* 219 */       this.denyIsSet = true;
/*     */     }
/*     */     public Id id() {
/* 222 */       throw new UnsupportedOperationException();
/*     */     } public int type() {
/* 224 */       throw new UnsupportedOperationException();
/*     */     } public long allow() {
/* 226 */       throw new UnsupportedOperationException();
/*     */     } public long deny() {
/* 228 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableOverwriteData fromJson(Json json) {
/* 239 */     Builder builder = builder();
/* 240 */     if (json.id != null) {
/* 241 */       builder.id(json.id);
/*     */     }
/* 243 */     if (json.typeIsSet) {
/* 244 */       builder.type(json.type);
/*     */     }
/* 246 */     if (json.allowIsSet) {
/* 247 */       builder.allow(json.allow);
/*     */     }
/* 249 */     if (json.denyIsSet) {
/* 250 */       builder.deny(json.deny);
/*     */     }
/* 252 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableOverwriteData of(Id id, int type, long allow, long deny) {
/* 264 */     return new ImmutableOverwriteData(id, type, allow, deny);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableOverwriteData copyOf(OverwriteData instance) {
/* 275 */     if (instance instanceof ImmutableOverwriteData) {
/* 276 */       return (ImmutableOverwriteData)instance;
/*     */     }
/* 278 */     return builder()
/* 279 */       .from(instance)
/* 280 */       .build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 296 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "OverwriteData", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_TYPE = 1L;
/*     */ 
/*     */     
/*     */     private static final long INIT_BIT_ALLOW = 2L;
/*     */     
/*     */     private static final long INIT_BIT_DENY = 4L;
/*     */     
/* 311 */     private long initBits = 7L;
/*     */     
/* 313 */     private Id id_id = null;
/*     */ 
/*     */ 
/*     */     
/*     */     private int type;
/*     */ 
/*     */ 
/*     */     
/*     */     private long allow;
/*     */ 
/*     */     
/*     */     private long deny;
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(OverwriteData instance) {
/* 329 */       Objects.requireNonNull(instance, "instance");
/* 330 */       id(instance.id());
/* 331 */       type(instance.type());
/* 332 */       allow(instance.allow());
/* 333 */       deny(instance.deny());
/* 334 */       return this;
/*     */     }
/*     */     
/*     */     public Builder id(String value) {
/* 338 */       this.id_id = Id.of(value);
/* 339 */       return this;
/*     */     }
/*     */     
/*     */     public Builder id(long value) {
/* 343 */       this.id_id = Id.of(value);
/* 344 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("id")
/*     */     public Builder id(Id value) {
/* 349 */       this.id_id = value;
/* 350 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("type")
/*     */     public final Builder type(int type) {
/* 360 */       this.type = type;
/* 361 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 362 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("allow")
/*     */     public final Builder allow(long allow) {
/* 372 */       this.allow = allow;
/* 373 */       this.initBits &= 0xFFFFFFFFFFFFFFFDL;
/* 374 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("deny")
/*     */     public final Builder deny(long deny) {
/* 384 */       this.deny = deny;
/* 385 */       this.initBits &= 0xFFFFFFFFFFFFFFFBL;
/* 386 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableOverwriteData build() {
/* 395 */       if (this.initBits != 0L) {
/* 396 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 398 */       return new ImmutableOverwriteData(null, id_build(), this.type, this.allow, this.deny);
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 402 */       List<String> attributes = new ArrayList<>();
/* 403 */       if ((this.initBits & 0x1L) != 0L) attributes.add("type"); 
/* 404 */       if ((this.initBits & 0x2L) != 0L) attributes.add("allow"); 
/* 405 */       if ((this.initBits & 0x4L) != 0L) attributes.add("deny"); 
/* 406 */       return "Cannot build OverwriteData, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Id id_build() {
/* 410 */       return this.id_id;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableOverwriteData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */