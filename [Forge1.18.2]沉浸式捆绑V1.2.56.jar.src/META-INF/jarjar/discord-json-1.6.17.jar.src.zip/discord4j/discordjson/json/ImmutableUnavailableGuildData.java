/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.Id;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "UnavailableGuildData", generator = "Immutables")
/*     */ public final class ImmutableUnavailableGuildData
/*     */   implements UnavailableGuildData
/*     */ {
/*     */   private final long id_value;
/*     */   private final Boolean unavailable_value;
/*     */   private final boolean unavailable_absent;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   
/*     */   private ImmutableUnavailableGuildData(Id id, Possible<Boolean> unavailable) {
/*  31 */     Id id$impl = id;
/*  32 */     Possible<Boolean> unavailable$impl = unavailable;
/*  33 */     this.id_value = id$impl.asLong();
/*  34 */     this.unavailable_value = unavailable$impl.toOptional().orElse(null);
/*  35 */     this.unavailable_absent = unavailable$impl.isAbsent();
/*  36 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ImmutableUnavailableGuildData(ImmutableUnavailableGuildData original, Id id, Possible<Boolean> unavailable) {
/*  43 */     Id id$impl = id;
/*  44 */     Possible<Boolean> unavailable$impl = unavailable;
/*  45 */     this.id_value = id$impl.asLong();
/*  46 */     this.unavailable_value = unavailable$impl.toOptional().orElse(null);
/*  47 */     this.unavailable_absent = unavailable$impl.isAbsent();
/*  48 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  54 */   private volatile transient InitShim initShim = new InitShim();
/*     */   
/*     */   @Generated(from = "UnavailableGuildData", generator = "Immutables")
/*     */   private final class InitShim {
/*     */     private String formatInitCycleMessage() {
/*  59 */       List<String> attributes = new ArrayList<>();
/*  60 */       return "Cannot build UnavailableGuildData, attribute initializers form cycle " + attributes;
/*     */     }
/*     */ 
/*     */     
/*     */     private InitShim() {}
/*     */   }
/*     */ 
/*     */   
/*     */   @JsonProperty("id")
/*     */   public Id id() {
/*  70 */     return Id.of(this.id_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("unavailable")
/*     */   public Possible<Boolean> unavailable() {
/*  79 */     return this.unavailable_absent ? Possible.absent() : Possible.of(this.unavailable_value);
/*     */   }
/*     */   
/*     */   public ImmutableUnavailableGuildData withId(long value) {
/*  83 */     Id newValue = Id.of(value);
/*  84 */     return new ImmutableUnavailableGuildData(this, newValue, unavailable());
/*     */   }
/*     */   
/*     */   public ImmutableUnavailableGuildData withId(String value) {
/*  88 */     Id newValue = Id.of(value);
/*  89 */     return new ImmutableUnavailableGuildData(this, newValue, unavailable());
/*     */   }
/*     */   
/*     */   public ImmutableUnavailableGuildData withUnavailable(Possible<Boolean> value) {
/*  93 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/*  94 */     return new ImmutableUnavailableGuildData(this, id(), newValue);
/*     */   }
/*     */   
/*     */   public ImmutableUnavailableGuildData withUnavailable(Boolean value) {
/*  98 */     Possible<Boolean> newValue = Possible.of(value);
/*  99 */     return new ImmutableUnavailableGuildData(this, id(), newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 108 */     if (this == another) return true; 
/* 109 */     return (another instanceof ImmutableUnavailableGuildData && 
/* 110 */       equalTo(0, (ImmutableUnavailableGuildData)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableUnavailableGuildData another) {
/* 114 */     return (Objects.equals(Long.valueOf(this.id_value), Long.valueOf(another.id_value)) && 
/* 115 */       unavailable().equals(another.unavailable()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 124 */     int h = 5381;
/* 125 */     h += (h << 5) + Objects.hashCode(Long.valueOf(this.id_value));
/* 126 */     h += (h << 5) + unavailable().hashCode();
/* 127 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 136 */     return "UnavailableGuildData{id=" + 
/* 137 */       Objects.toString(Long.valueOf(this.id_value)) + ", unavailable=" + 
/* 138 */       unavailable().toString() + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "UnavailableGuildData", generator = "Immutables")
/*     */   static final class Json
/*     */     implements UnavailableGuildData
/*     */   {
/*     */     Id id;
/*     */ 
/*     */     
/* 153 */     Possible<Boolean> unavailable = Possible.absent();
/*     */     
/*     */     @JsonProperty("id")
/*     */     public void setId(Id id) {
/* 157 */       this.id = id;
/*     */     }
/*     */     @JsonProperty("unavailable")
/*     */     public void setUnavailable(Possible<Boolean> unavailable) {
/* 161 */       this.unavailable = unavailable;
/*     */     }
/*     */     public Id id() {
/* 164 */       throw new UnsupportedOperationException();
/*     */     } public Possible<Boolean> unavailable() {
/* 166 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableUnavailableGuildData fromJson(Json json) {
/* 177 */     Builder builder = builder();
/* 178 */     if (json.id != null) {
/* 179 */       builder.id(json.id);
/*     */     }
/* 181 */     if (json.unavailable != null) {
/* 182 */       builder.unavailable(json.unavailable);
/*     */     }
/* 184 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableUnavailableGuildData of(Id id, Possible<Boolean> unavailable) {
/* 194 */     return new ImmutableUnavailableGuildData(id, unavailable);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableUnavailableGuildData copyOf(UnavailableGuildData instance) {
/* 205 */     if (instance instanceof ImmutableUnavailableGuildData) {
/* 206 */       return (ImmutableUnavailableGuildData)instance;
/*     */     }
/* 208 */     return builder()
/* 209 */       .from(instance)
/* 210 */       .build();
/*     */   }
/*     */   
/*     */   public boolean isUnavailablePresent() {
/* 214 */     return !this.unavailable_absent;
/*     */   }
/*     */   
/*     */   public Boolean unavailableOrElse(Boolean defaultValue) {
/* 218 */     return !this.unavailable_absent ? this.unavailable_value : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 232 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "UnavailableGuildData", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/* 244 */     private Id id_id = null;
/* 245 */     private Possible<Boolean> unavailable_possible = Possible.absent();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(UnavailableGuildData instance) {
/* 258 */       Objects.requireNonNull(instance, "instance");
/* 259 */       id(instance.id());
/* 260 */       unavailable(instance.unavailable());
/* 261 */       return this;
/*     */     }
/*     */     
/*     */     public Builder id(String value) {
/* 265 */       this.id_id = Id.of(value);
/* 266 */       return this;
/*     */     }
/*     */     
/*     */     public Builder id(long value) {
/* 270 */       this.id_id = Id.of(value);
/* 271 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("id")
/*     */     public Builder id(Id value) {
/* 276 */       this.id_id = value;
/* 277 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("unavailable")
/*     */     public Builder unavailable(Possible<Boolean> value) {
/* 282 */       this.unavailable_possible = value;
/* 283 */       return this;
/*     */     }
/*     */     
/*     */     public Builder unavailable(Boolean value) {
/* 287 */       this.unavailable_possible = Possible.of(value);
/* 288 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableUnavailableGuildData build() {
/* 297 */       return new ImmutableUnavailableGuildData(null, id_build(), unavailable_build());
/*     */     }
/*     */     
/*     */     private Id id_build() {
/* 301 */       return this.id_id;
/*     */     }
/*     */     
/*     */     private Possible<Boolean> unavailable_build() {
/* 305 */       return this.unavailable_possible;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableUnavailableGuildData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */