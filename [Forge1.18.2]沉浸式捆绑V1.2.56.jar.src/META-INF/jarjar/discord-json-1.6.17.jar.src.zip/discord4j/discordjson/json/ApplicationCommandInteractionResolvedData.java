/*    */ package discord4j.discordjson.json;
/*    */ 
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import java.util.Map;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ 
/*    */ @JsonSerialize(as = ImmutableApplicationCommandInteractionResolvedData.class)
/*    */ @JsonDeserialize(as = ImmutableApplicationCommandInteractionResolvedData.class)
/*    */ @Immutable
/*    */ public interface ApplicationCommandInteractionResolvedData
/*    */ {
/*    */   static ImmutableApplicationCommandInteractionResolvedData.Builder builder() {
/* 16 */     return ImmutableApplicationCommandInteractionResolvedData.builder();
/*    */   }
/*    */   
/*    */   Possible<Map<String, UserData>> users();
/*    */   
/*    */   Possible<Map<String, ResolvedMemberData>> members();
/*    */   
/*    */   Possible<Map<String, ResolvedChannelData>> channels();
/*    */   
/*    */   Possible<Map<String, RoleData>> roles();
/*    */   
/*    */   Possible<Map<String, MessageData>> messages();
/*    */   
/*    */   Possible<Map<String, AttachmentData>> attachments();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ApplicationCommandInteractionResolvedData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */