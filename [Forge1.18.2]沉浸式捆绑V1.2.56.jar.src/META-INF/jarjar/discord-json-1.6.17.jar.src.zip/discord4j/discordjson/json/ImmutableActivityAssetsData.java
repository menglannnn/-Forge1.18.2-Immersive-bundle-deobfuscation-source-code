/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "ActivityAssetsData", generator = "Immutables")
/*     */ public final class ImmutableActivityAssetsData
/*     */   implements ActivityAssetsData
/*     */ {
/*     */   private final String largeImage_value;
/*     */   private final boolean largeImage_absent;
/*     */   private final String largeText_value;
/*     */   private final boolean largeText_absent;
/*     */   private final String smallImage_value;
/*     */   private final boolean smallImage_absent;
/*     */   private final String smallText_value;
/*     */   private final boolean smallText_absent;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   
/*     */   private ImmutableActivityAssetsData(Possible<String> largeImage, Possible<String> largeText, Possible<String> smallImage, Possible<String> smallText) {
/*  39 */     Possible<String> largeImage$impl = largeImage;
/*  40 */     Possible<String> largeText$impl = largeText;
/*  41 */     Possible<String> smallImage$impl = smallImage;
/*  42 */     Possible<String> smallText$impl = smallText;
/*  43 */     this.largeImage_value = largeImage$impl.toOptional().orElse(null);
/*  44 */     this.largeImage_absent = largeImage$impl.isAbsent();
/*  45 */     this.largeText_value = largeText$impl.toOptional().orElse(null);
/*  46 */     this.largeText_absent = largeText$impl.isAbsent();
/*  47 */     this.smallImage_value = smallImage$impl.toOptional().orElse(null);
/*  48 */     this.smallImage_absent = smallImage$impl.isAbsent();
/*  49 */     this.smallText_value = smallText$impl.toOptional().orElse(null);
/*  50 */     this.smallText_absent = smallText$impl.isAbsent();
/*  51 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ImmutableActivityAssetsData(ImmutableActivityAssetsData original, Possible<String> largeImage, Possible<String> largeText, Possible<String> smallImage, Possible<String> smallText) {
/*  60 */     Possible<String> largeImage$impl = largeImage;
/*  61 */     Possible<String> largeText$impl = largeText;
/*  62 */     Possible<String> smallImage$impl = smallImage;
/*  63 */     Possible<String> smallText$impl = smallText;
/*  64 */     this.largeImage_value = largeImage$impl.toOptional().orElse(null);
/*  65 */     this.largeImage_absent = largeImage$impl.isAbsent();
/*  66 */     this.largeText_value = largeText$impl.toOptional().orElse(null);
/*  67 */     this.largeText_absent = largeText$impl.isAbsent();
/*  68 */     this.smallImage_value = smallImage$impl.toOptional().orElse(null);
/*  69 */     this.smallImage_absent = smallImage$impl.isAbsent();
/*  70 */     this.smallText_value = smallText$impl.toOptional().orElse(null);
/*  71 */     this.smallText_absent = smallText$impl.isAbsent();
/*  72 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  78 */   private volatile transient InitShim initShim = new InitShim();
/*     */   
/*     */   @Generated(from = "ActivityAssetsData", generator = "Immutables")
/*     */   private final class InitShim {
/*     */     private String formatInitCycleMessage() {
/*  83 */       List<String> attributes = new ArrayList<>();
/*  84 */       return "Cannot build ActivityAssetsData, attribute initializers form cycle " + attributes;
/*     */     }
/*     */ 
/*     */     
/*     */     private InitShim() {}
/*     */   }
/*     */ 
/*     */   
/*     */   @JsonProperty("large_image")
/*     */   public Possible<String> largeImage() {
/*  94 */     return this.largeImage_absent ? Possible.absent() : Possible.of(this.largeImage_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("large_text")
/*     */   public Possible<String> largeText() {
/* 103 */     return this.largeText_absent ? Possible.absent() : Possible.of(this.largeText_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("small_image")
/*     */   public Possible<String> smallImage() {
/* 112 */     return this.smallImage_absent ? Possible.absent() : Possible.of(this.smallImage_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("small_text")
/*     */   public Possible<String> smallText() {
/* 121 */     return this.smallText_absent ? Possible.absent() : Possible.of(this.smallText_value);
/*     */   }
/*     */   
/*     */   public ImmutableActivityAssetsData withLargeImage(Possible<String> value) {
/* 125 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/* 126 */     return new ImmutableActivityAssetsData(this, newValue, largeText(), smallImage(), smallText());
/*     */   }
/*     */   
/*     */   public ImmutableActivityAssetsData withLargeImage(String value) {
/* 130 */     Possible<String> newValue = Possible.of(value);
/* 131 */     return new ImmutableActivityAssetsData(this, newValue, largeText(), smallImage(), smallText());
/*     */   }
/*     */   
/*     */   public ImmutableActivityAssetsData withLargeText(Possible<String> value) {
/* 135 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/* 136 */     return new ImmutableActivityAssetsData(this, largeImage(), newValue, smallImage(), smallText());
/*     */   }
/*     */   
/*     */   public ImmutableActivityAssetsData withLargeText(String value) {
/* 140 */     Possible<String> newValue = Possible.of(value);
/* 141 */     return new ImmutableActivityAssetsData(this, largeImage(), newValue, smallImage(), smallText());
/*     */   }
/*     */   
/*     */   public ImmutableActivityAssetsData withSmallImage(Possible<String> value) {
/* 145 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/* 146 */     return new ImmutableActivityAssetsData(this, largeImage(), largeText(), newValue, smallText());
/*     */   }
/*     */   
/*     */   public ImmutableActivityAssetsData withSmallImage(String value) {
/* 150 */     Possible<String> newValue = Possible.of(value);
/* 151 */     return new ImmutableActivityAssetsData(this, largeImage(), largeText(), newValue, smallText());
/*     */   }
/*     */   
/*     */   public ImmutableActivityAssetsData withSmallText(Possible<String> value) {
/* 155 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/* 156 */     return new ImmutableActivityAssetsData(this, largeImage(), largeText(), smallImage(), newValue);
/*     */   }
/*     */   
/*     */   public ImmutableActivityAssetsData withSmallText(String value) {
/* 160 */     Possible<String> newValue = Possible.of(value);
/* 161 */     return new ImmutableActivityAssetsData(this, largeImage(), largeText(), smallImage(), newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 170 */     if (this == another) return true; 
/* 171 */     return (another instanceof ImmutableActivityAssetsData && 
/* 172 */       equalTo(0, (ImmutableActivityAssetsData)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableActivityAssetsData another) {
/* 176 */     return (largeImage().equals(another.largeImage()) && 
/* 177 */       largeText().equals(another.largeText()) && 
/* 178 */       smallImage().equals(another.smallImage()) && 
/* 179 */       smallText().equals(another.smallText()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 188 */     int h = 5381;
/* 189 */     h += (h << 5) + largeImage().hashCode();
/* 190 */     h += (h << 5) + largeText().hashCode();
/* 191 */     h += (h << 5) + smallImage().hashCode();
/* 192 */     h += (h << 5) + smallText().hashCode();
/* 193 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 202 */     return "ActivityAssetsData{largeImage=" + 
/* 203 */       largeImage().toString() + ", largeText=" + 
/* 204 */       largeText().toString() + ", smallImage=" + 
/* 205 */       smallImage().toString() + ", smallText=" + 
/* 206 */       smallText().toString() + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "ActivityAssetsData", generator = "Immutables")
/*     */   static final class Json
/*     */     implements ActivityAssetsData
/*     */   {
/* 220 */     Possible<String> largeImage = Possible.absent();
/*     */ 
/*     */     
/* 223 */     Possible<String> largeText = Possible.absent();
/*     */ 
/*     */     
/* 226 */     Possible<String> smallImage = Possible.absent();
/*     */ 
/*     */     
/* 229 */     Possible<String> smallText = Possible.absent();
/*     */     
/*     */     @JsonProperty("large_image")
/*     */     public void setLargeImage(Possible<String> largeImage) {
/* 233 */       this.largeImage = largeImage;
/*     */     }
/*     */     @JsonProperty("large_text")
/*     */     public void setLargeText(Possible<String> largeText) {
/* 237 */       this.largeText = largeText;
/*     */     }
/*     */     @JsonProperty("small_image")
/*     */     public void setSmallImage(Possible<String> smallImage) {
/* 241 */       this.smallImage = smallImage;
/*     */     }
/*     */     @JsonProperty("small_text")
/*     */     public void setSmallText(Possible<String> smallText) {
/* 245 */       this.smallText = smallText;
/*     */     }
/*     */     public Possible<String> largeImage() {
/* 248 */       throw new UnsupportedOperationException();
/*     */     } public Possible<String> largeText() {
/* 250 */       throw new UnsupportedOperationException();
/*     */     } public Possible<String> smallImage() {
/* 252 */       throw new UnsupportedOperationException();
/*     */     } public Possible<String> smallText() {
/* 254 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableActivityAssetsData fromJson(Json json) {
/* 265 */     Builder builder = builder();
/* 266 */     if (json.largeImage != null) {
/* 267 */       builder.largeImage(json.largeImage);
/*     */     }
/* 269 */     if (json.largeText != null) {
/* 270 */       builder.largeText(json.largeText);
/*     */     }
/* 272 */     if (json.smallImage != null) {
/* 273 */       builder.smallImage(json.smallImage);
/*     */     }
/* 275 */     if (json.smallText != null) {
/* 276 */       builder.smallText(json.smallText);
/*     */     }
/* 278 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableActivityAssetsData of(Possible<String> largeImage, Possible<String> largeText, Possible<String> smallImage, Possible<String> smallText) {
/* 290 */     return new ImmutableActivityAssetsData(largeImage, largeText, smallImage, smallText);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableActivityAssetsData copyOf(ActivityAssetsData instance) {
/* 301 */     if (instance instanceof ImmutableActivityAssetsData) {
/* 302 */       return (ImmutableActivityAssetsData)instance;
/*     */     }
/* 304 */     return builder()
/* 305 */       .from(instance)
/* 306 */       .build();
/*     */   }
/*     */   
/*     */   public boolean isLargeImagePresent() {
/* 310 */     return !this.largeImage_absent;
/*     */   }
/*     */   
/*     */   public String largeImageOrElse(String defaultValue) {
/* 314 */     return !this.largeImage_absent ? this.largeImage_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isLargeTextPresent() {
/* 318 */     return !this.largeText_absent;
/*     */   }
/*     */   
/*     */   public String largeTextOrElse(String defaultValue) {
/* 322 */     return !this.largeText_absent ? this.largeText_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isSmallImagePresent() {
/* 326 */     return !this.smallImage_absent;
/*     */   }
/*     */   
/*     */   public String smallImageOrElse(String defaultValue) {
/* 330 */     return !this.smallImage_absent ? this.smallImage_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isSmallTextPresent() {
/* 334 */     return !this.smallText_absent;
/*     */   }
/*     */   
/*     */   public String smallTextOrElse(String defaultValue) {
/* 338 */     return !this.smallText_absent ? this.smallText_value : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 354 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "ActivityAssetsData", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/* 366 */     private Possible<String> largeImage_possible = Possible.absent();
/* 367 */     private Possible<String> largeText_possible = Possible.absent();
/* 368 */     private Possible<String> smallImage_possible = Possible.absent();
/* 369 */     private Possible<String> smallText_possible = Possible.absent();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(ActivityAssetsData instance) {
/* 382 */       Objects.requireNonNull(instance, "instance");
/* 383 */       largeImage(instance.largeImage());
/* 384 */       largeText(instance.largeText());
/* 385 */       smallImage(instance.smallImage());
/* 386 */       smallText(instance.smallText());
/* 387 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("large_image")
/*     */     public Builder largeImage(Possible<String> value) {
/* 392 */       this.largeImage_possible = value;
/* 393 */       return this;
/*     */     }
/*     */     
/*     */     public Builder largeImage(String value) {
/* 397 */       this.largeImage_possible = Possible.of(value);
/* 398 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("large_text")
/*     */     public Builder largeText(Possible<String> value) {
/* 403 */       this.largeText_possible = value;
/* 404 */       return this;
/*     */     }
/*     */     
/*     */     public Builder largeText(String value) {
/* 408 */       this.largeText_possible = Possible.of(value);
/* 409 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("small_image")
/*     */     public Builder smallImage(Possible<String> value) {
/* 414 */       this.smallImage_possible = value;
/* 415 */       return this;
/*     */     }
/*     */     
/*     */     public Builder smallImage(String value) {
/* 419 */       this.smallImage_possible = Possible.of(value);
/* 420 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("small_text")
/*     */     public Builder smallText(Possible<String> value) {
/* 425 */       this.smallText_possible = value;
/* 426 */       return this;
/*     */     }
/*     */     
/*     */     public Builder smallText(String value) {
/* 430 */       this.smallText_possible = Possible.of(value);
/* 431 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableActivityAssetsData build() {
/* 440 */       return new ImmutableActivityAssetsData(null, largeImage_build(), largeText_build(), smallImage_build(), smallText_build());
/*     */     }
/*     */     
/*     */     private Possible<String> largeImage_build() {
/* 444 */       return this.largeImage_possible;
/*     */     }
/*     */     
/*     */     private Possible<String> largeText_build() {
/* 448 */       return this.largeText_possible;
/*     */     }
/*     */     
/*     */     private Possible<String> smallImage_build() {
/* 452 */       return this.smallImage_possible;
/*     */     }
/*     */     
/*     */     private Possible<String> smallText_build() {
/* 456 */       return this.smallText_possible;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableActivityAssetsData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */