/*      */ package discord4j.discordjson.json;
/*      */ 
/*      */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*      */ import com.fasterxml.jackson.annotation.JsonCreator;
/*      */ import com.fasterxml.jackson.annotation.JsonProperty;
/*      */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*      */ import discord4j.discordjson.Id;
/*      */ import discord4j.discordjson.possible.Possible;
/*      */ import java.util.ArrayList;
/*      */ import java.util.List;
/*      */ import java.util.Objects;
/*      */ import java.util.Optional;
/*      */ import org.immutables.value.Generated;
/*      */ import reactor.util.annotation.Nullable;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ @Generated(from = "RoleData", generator = "Immutables")
/*      */ public final class ImmutableRoleData
/*      */   implements RoleData
/*      */ {
/*      */   private final long id_value;
/*      */   private final String name;
/*      */   private final int color;
/*      */   private final boolean hoist;
/*      */   private final long permissions;
/*      */   private final boolean mentionable;
/*      */   private final String icon_value;
/*      */   private final boolean icon_absent;
/*      */   private final String unicodeEmoji_value;
/*      */   private final boolean unicodeEmoji_absent;
/*      */   private final RoleTagsData tags_value;
/*      */   private final boolean tags_absent;
/*      */   private final int position;
/*      */   private final boolean managed;
/*      */   private static final byte STAGE_INITIALIZING = -1;
/*      */   private static final byte STAGE_UNINITIALIZED = 0;
/*      */   private static final byte STAGE_INITIALIZED = 1;
/*      */   
/*      */   private ImmutableRoleData(Id id, String name, int color, boolean hoist, long permissions, boolean mentionable, Possible<Optional<String>> icon, Possible<Optional<String>> unicodeEmoji, Possible<RoleTagsData> tags, int position, boolean managed) {
/*   55 */     Id id$impl = id;
/*   56 */     this.name = Objects.<String>requireNonNull(name, "name");
/*   57 */     this.color = color;
/*   58 */     this.hoist = hoist;
/*   59 */     this.permissions = permissions;
/*   60 */     this.mentionable = mentionable;
/*   61 */     Possible<Optional<String>> icon$impl = icon;
/*   62 */     Possible<Optional<String>> unicodeEmoji$impl = unicodeEmoji;
/*   63 */     Possible<RoleTagsData> tags$impl = tags;
/*   64 */     this.position = position;
/*   65 */     this.managed = managed;
/*   66 */     this.id_value = id$impl.asLong();
/*   67 */     this.icon_value = Possible.flatOpt(icon$impl).orElse(null);
/*   68 */     this.icon_absent = icon$impl.isAbsent();
/*   69 */     this.unicodeEmoji_value = Possible.flatOpt(unicodeEmoji$impl).orElse(null);
/*   70 */     this.unicodeEmoji_absent = unicodeEmoji$impl.isAbsent();
/*   71 */     this.tags_value = tags$impl.toOptional().orElse(null);
/*   72 */     this.tags_absent = tags$impl.isAbsent();
/*   73 */     this.initShim = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ImmutableRoleData(ImmutableRoleData original, Id id, String name, int color, boolean hoist, long permissions, boolean mentionable, Possible<Optional<String>> icon, Possible<Optional<String>> unicodeEmoji, Possible<RoleTagsData> tags, int position, boolean managed) {
/*   89 */     Id id$impl = id;
/*   90 */     this.name = name;
/*   91 */     this.color = color;
/*   92 */     this.hoist = hoist;
/*   93 */     this.permissions = permissions;
/*   94 */     this.mentionable = mentionable;
/*   95 */     Possible<Optional<String>> icon$impl = icon;
/*   96 */     Possible<Optional<String>> unicodeEmoji$impl = unicodeEmoji;
/*   97 */     Possible<RoleTagsData> tags$impl = tags;
/*   98 */     this.position = position;
/*   99 */     this.managed = managed;
/*  100 */     this.id_value = id$impl.asLong();
/*  101 */     this.icon_value = Possible.flatOpt(icon$impl).orElse(null);
/*  102 */     this.icon_absent = icon$impl.isAbsent();
/*  103 */     this.unicodeEmoji_value = Possible.flatOpt(unicodeEmoji$impl).orElse(null);
/*  104 */     this.unicodeEmoji_absent = unicodeEmoji$impl.isAbsent();
/*  105 */     this.tags_value = tags$impl.toOptional().orElse(null);
/*  106 */     this.tags_absent = tags$impl.isAbsent();
/*  107 */     this.initShim = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  113 */   private volatile transient InitShim initShim = new InitShim();
/*      */   
/*      */   @Generated(from = "RoleData", generator = "Immutables")
/*      */   private final class InitShim {
/*      */     private String formatInitCycleMessage() {
/*  118 */       List<String> attributes = new ArrayList<>();
/*  119 */       return "Cannot build RoleData, attribute initializers form cycle " + attributes;
/*      */     }
/*      */ 
/*      */     
/*      */     private InitShim() {}
/*      */   }
/*      */ 
/*      */   
/*      */   @JsonProperty("id")
/*      */   public Id id() {
/*  129 */     return Id.of(this.id_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("name")
/*      */   public String name() {
/*  138 */     return this.name;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("color")
/*      */   public int color() {
/*  147 */     return this.color;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("hoist")
/*      */   public boolean hoist() {
/*  156 */     return this.hoist;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("permissions")
/*      */   public long permissions() {
/*  165 */     return this.permissions;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("mentionable")
/*      */   public boolean mentionable() {
/*  174 */     return this.mentionable;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("icon")
/*      */   public Possible<Optional<String>> icon() {
/*  183 */     return this.icon_absent ? Possible.absent() : 
/*  184 */       Possible.of(Optional.ofNullable(this.icon_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("unicode_emoji")
/*      */   public Possible<Optional<String>> unicodeEmoji() {
/*  193 */     return this.unicodeEmoji_absent ? Possible.absent() : 
/*  194 */       Possible.of(Optional.ofNullable(this.unicodeEmoji_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("tags")
/*      */   public Possible<RoleTagsData> tags() {
/*  203 */     return this.tags_absent ? Possible.absent() : Possible.of(this.tags_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("position")
/*      */   public int position() {
/*  212 */     return this.position;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("managed")
/*      */   public boolean managed() {
/*  221 */     return this.managed;
/*      */   }
/*      */   
/*      */   public ImmutableRoleData withId(long value) {
/*  225 */     Id newValue = Id.of(value);
/*  226 */     return new ImmutableRoleData(this, newValue, this.name, this.color, this.hoist, this.permissions, this.mentionable, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  234 */         icon(), 
/*  235 */         unicodeEmoji(), 
/*  236 */         tags(), this.position, this.managed);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutableRoleData withId(String value) {
/*  242 */     Id newValue = Id.of(value);
/*  243 */     return new ImmutableRoleData(this, newValue, this.name, this.color, this.hoist, this.permissions, this.mentionable, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  251 */         icon(), 
/*  252 */         unicodeEmoji(), 
/*  253 */         tags(), this.position, this.managed);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableRoleData withName(String value) {
/*  265 */     String newValue = Objects.<String>requireNonNull(value, "name");
/*  266 */     if (this.name.equals(newValue)) return this; 
/*  267 */     return new ImmutableRoleData(this, 
/*      */         
/*  269 */         id(), newValue, this.color, this.hoist, this.permissions, this.mentionable, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  275 */         icon(), 
/*  276 */         unicodeEmoji(), 
/*  277 */         tags(), this.position, this.managed);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableRoleData withColor(int value) {
/*  289 */     if (this.color == value) return this; 
/*  290 */     return new ImmutableRoleData(this, 
/*      */         
/*  292 */         id(), this.name, value, this.hoist, this.permissions, this.mentionable, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  298 */         icon(), 
/*  299 */         unicodeEmoji(), 
/*  300 */         tags(), this.position, this.managed);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableRoleData withHoist(boolean value) {
/*  312 */     if (this.hoist == value) return this; 
/*  313 */     return new ImmutableRoleData(this, 
/*      */         
/*  315 */         id(), this.name, this.color, value, this.permissions, this.mentionable, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  321 */         icon(), 
/*  322 */         unicodeEmoji(), 
/*  323 */         tags(), this.position, this.managed);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableRoleData withPermissions(long value) {
/*  335 */     if (this.permissions == value) return this; 
/*  336 */     return new ImmutableRoleData(this, 
/*      */         
/*  338 */         id(), this.name, this.color, this.hoist, value, this.mentionable, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  344 */         icon(), 
/*  345 */         unicodeEmoji(), 
/*  346 */         tags(), this.position, this.managed);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableRoleData withMentionable(boolean value) {
/*  358 */     if (this.mentionable == value) return this; 
/*  359 */     return new ImmutableRoleData(this, 
/*      */         
/*  361 */         id(), this.name, this.color, this.hoist, this.permissions, value, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  367 */         icon(), 
/*  368 */         unicodeEmoji(), 
/*  369 */         tags(), this.position, this.managed);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutableRoleData withIcon(Possible<Optional<String>> value) {
/*  375 */     Possible<Optional<String>> newValue = Objects.<Possible<Optional<String>>>requireNonNull(value);
/*  376 */     return new ImmutableRoleData(this, 
/*      */         
/*  378 */         id(), this.name, this.color, this.hoist, this.permissions, this.mentionable, newValue, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  385 */         unicodeEmoji(), 
/*  386 */         tags(), this.position, this.managed);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public ImmutableRoleData withIcon(@Nullable String value) {
/*  393 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/*  394 */     return new ImmutableRoleData(this, 
/*      */         
/*  396 */         id(), this.name, this.color, this.hoist, this.permissions, this.mentionable, newValue, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  403 */         unicodeEmoji(), 
/*  404 */         tags(), this.position, this.managed);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutableRoleData withIconOrNull(@Nullable String value) {
/*  410 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/*  411 */     return new ImmutableRoleData(this, 
/*      */         
/*  413 */         id(), this.name, this.color, this.hoist, this.permissions, this.mentionable, newValue, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  420 */         unicodeEmoji(), 
/*  421 */         tags(), this.position, this.managed);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutableRoleData withUnicodeEmoji(Possible<Optional<String>> value) {
/*  427 */     Possible<Optional<String>> newValue = Objects.<Possible<Optional<String>>>requireNonNull(value);
/*  428 */     return new ImmutableRoleData(this, 
/*      */         
/*  430 */         id(), this.name, this.color, this.hoist, this.permissions, this.mentionable, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  436 */         icon(), newValue, 
/*      */         
/*  438 */         tags(), this.position, this.managed);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public ImmutableRoleData withUnicodeEmoji(@Nullable String value) {
/*  445 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/*  446 */     return new ImmutableRoleData(this, 
/*      */         
/*  448 */         id(), this.name, this.color, this.hoist, this.permissions, this.mentionable, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  454 */         icon(), newValue, 
/*      */         
/*  456 */         tags(), this.position, this.managed);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutableRoleData withUnicodeEmojiOrNull(@Nullable String value) {
/*  462 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/*  463 */     return new ImmutableRoleData(this, 
/*      */         
/*  465 */         id(), this.name, this.color, this.hoist, this.permissions, this.mentionable, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  471 */         icon(), newValue, 
/*      */         
/*  473 */         tags(), this.position, this.managed);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutableRoleData withTags(Possible<RoleTagsData> value) {
/*  479 */     Possible<RoleTagsData> newValue = Objects.<Possible<RoleTagsData>>requireNonNull(value);
/*  480 */     return new ImmutableRoleData(this, 
/*      */         
/*  482 */         id(), this.name, this.color, this.hoist, this.permissions, this.mentionable, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  488 */         icon(), 
/*  489 */         unicodeEmoji(), newValue, this.position, this.managed);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutableRoleData withTags(RoleTagsData value) {
/*  496 */     Possible<RoleTagsData> newValue = Possible.of(value);
/*  497 */     return new ImmutableRoleData(this, 
/*      */         
/*  499 */         id(), this.name, this.color, this.hoist, this.permissions, this.mentionable, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  505 */         icon(), 
/*  506 */         unicodeEmoji(), newValue, this.position, this.managed);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableRoleData withPosition(int value) {
/*  519 */     if (this.position == value) return this; 
/*  520 */     return new ImmutableRoleData(this, 
/*      */         
/*  522 */         id(), this.name, this.color, this.hoist, this.permissions, this.mentionable, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  528 */         icon(), 
/*  529 */         unicodeEmoji(), 
/*  530 */         tags(), value, this.managed);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableRoleData withManaged(boolean value) {
/*  542 */     if (this.managed == value) return this; 
/*  543 */     return new ImmutableRoleData(this, 
/*      */         
/*  545 */         id(), this.name, this.color, this.hoist, this.permissions, this.mentionable, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  551 */         icon(), 
/*  552 */         unicodeEmoji(), 
/*  553 */         tags(), this.position, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean equals(Object another) {
/*  564 */     if (this == another) return true; 
/*  565 */     return (another instanceof ImmutableRoleData && 
/*  566 */       equalTo(0, (ImmutableRoleData)another));
/*      */   }
/*      */   
/*      */   private boolean equalTo(int synthetic, ImmutableRoleData another) {
/*  570 */     return (Objects.equals(Long.valueOf(this.id_value), Long.valueOf(another.id_value)) && this.name
/*  571 */       .equals(another.name) && this.color == another.color && this.hoist == another.hoist && this.permissions == another.permissions && this.mentionable == another.mentionable && 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  576 */       icon().equals(another.icon()) && 
/*  577 */       unicodeEmoji().equals(another.unicodeEmoji()) && 
/*  578 */       tags().equals(another.tags()) && this.position == another.position && this.managed == another.managed);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int hashCode() {
/*  589 */     int h = 5381;
/*  590 */     h += (h << 5) + Objects.hashCode(Long.valueOf(this.id_value));
/*  591 */     h += (h << 5) + this.name.hashCode();
/*  592 */     h += (h << 5) + this.color;
/*  593 */     h += (h << 5) + Boolean.hashCode(this.hoist);
/*  594 */     h += (h << 5) + Long.hashCode(this.permissions);
/*  595 */     h += (h << 5) + Boolean.hashCode(this.mentionable);
/*  596 */     h += (h << 5) + icon().hashCode();
/*  597 */     h += (h << 5) + unicodeEmoji().hashCode();
/*  598 */     h += (h << 5) + tags().hashCode();
/*  599 */     h += (h << 5) + this.position;
/*  600 */     h += (h << 5) + Boolean.hashCode(this.managed);
/*  601 */     return h;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/*  610 */     return "RoleData{id=" + 
/*  611 */       Objects.toString(Long.valueOf(this.id_value)) + ", name=" + this.name + ", color=" + this.color + ", hoist=" + this.hoist + ", permissions=" + this.permissions + ", mentionable=" + this.mentionable + ", icon=" + 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  617 */       icon().toString() + ", unicodeEmoji=" + 
/*  618 */       unicodeEmoji().toString() + ", tags=" + 
/*  619 */       tags().toString() + ", position=" + this.position + ", managed=" + this.managed + "}";
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonDeserialize
/*      */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*      */   @Generated(from = "RoleData", generator = "Immutables")
/*      */   static final class Json
/*      */     implements RoleData
/*      */   {
/*      */     Id id;
/*      */     
/*      */     String name;
/*      */     
/*      */     int color;
/*      */     
/*      */     boolean colorIsSet;
/*      */     
/*      */     boolean hoist;
/*      */     
/*      */     boolean hoistIsSet;
/*      */     long permissions;
/*      */     boolean permissionsIsSet;
/*      */     boolean mentionable;
/*      */     boolean mentionableIsSet;
/*  645 */     Possible<Optional<String>> icon = Possible.absent();
/*      */ 
/*      */     
/*  648 */     Possible<Optional<String>> unicodeEmoji = Possible.absent();
/*      */ 
/*      */     
/*  651 */     Possible<RoleTagsData> tags = Possible.absent();
/*      */     int position;
/*      */     boolean positionIsSet;
/*      */     boolean managed;
/*      */     boolean managedIsSet;
/*      */     
/*      */     @JsonProperty("id")
/*      */     public void setId(Id id) {
/*  659 */       this.id = id;
/*      */     }
/*      */     @JsonProperty("name")
/*      */     public void setName(String name) {
/*  663 */       this.name = name;
/*      */     }
/*      */     @JsonProperty("color")
/*      */     public void setColor(int color) {
/*  667 */       this.color = color;
/*  668 */       this.colorIsSet = true;
/*      */     }
/*      */     @JsonProperty("hoist")
/*      */     public void setHoist(boolean hoist) {
/*  672 */       this.hoist = hoist;
/*  673 */       this.hoistIsSet = true;
/*      */     }
/*      */     @JsonProperty("permissions")
/*      */     public void setPermissions(long permissions) {
/*  677 */       this.permissions = permissions;
/*  678 */       this.permissionsIsSet = true;
/*      */     }
/*      */     @JsonProperty("mentionable")
/*      */     public void setMentionable(boolean mentionable) {
/*  682 */       this.mentionable = mentionable;
/*  683 */       this.mentionableIsSet = true;
/*      */     }
/*      */     @JsonProperty("icon")
/*      */     public void setIcon(Possible<Optional<String>> icon) {
/*  687 */       this.icon = icon;
/*      */     }
/*      */     @JsonProperty("unicode_emoji")
/*      */     public void setUnicodeEmoji(Possible<Optional<String>> unicodeEmoji) {
/*  691 */       this.unicodeEmoji = unicodeEmoji;
/*      */     }
/*      */     @JsonProperty("tags")
/*      */     public void setTags(Possible<RoleTagsData> tags) {
/*  695 */       this.tags = tags;
/*      */     }
/*      */     @JsonProperty("position")
/*      */     public void setPosition(int position) {
/*  699 */       this.position = position;
/*  700 */       this.positionIsSet = true;
/*      */     }
/*      */     @JsonProperty("managed")
/*      */     public void setManaged(boolean managed) {
/*  704 */       this.managed = managed;
/*  705 */       this.managedIsSet = true;
/*      */     }
/*      */     public Id id() {
/*  708 */       throw new UnsupportedOperationException();
/*      */     } public String name() {
/*  710 */       throw new UnsupportedOperationException();
/*      */     } public int color() {
/*  712 */       throw new UnsupportedOperationException();
/*      */     } public boolean hoist() {
/*  714 */       throw new UnsupportedOperationException();
/*      */     } public long permissions() {
/*  716 */       throw new UnsupportedOperationException();
/*      */     } public boolean mentionable() {
/*  718 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Optional<String>> icon() {
/*  720 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Optional<String>> unicodeEmoji() {
/*  722 */       throw new UnsupportedOperationException();
/*      */     } public Possible<RoleTagsData> tags() {
/*  724 */       throw new UnsupportedOperationException();
/*      */     } public int position() {
/*  726 */       throw new UnsupportedOperationException();
/*      */     } public boolean managed() {
/*  728 */       throw new UnsupportedOperationException();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*      */   static ImmutableRoleData fromJson(Json json) {
/*  739 */     Builder builder = builder();
/*  740 */     if (json.id != null) {
/*  741 */       builder.id(json.id);
/*      */     }
/*  743 */     if (json.name != null) {
/*  744 */       builder.name(json.name);
/*      */     }
/*  746 */     if (json.colorIsSet) {
/*  747 */       builder.color(json.color);
/*      */     }
/*  749 */     if (json.hoistIsSet) {
/*  750 */       builder.hoist(json.hoist);
/*      */     }
/*  752 */     if (json.permissionsIsSet) {
/*  753 */       builder.permissions(json.permissions);
/*      */     }
/*  755 */     if (json.mentionableIsSet) {
/*  756 */       builder.mentionable(json.mentionable);
/*      */     }
/*  758 */     if (json.icon != null) {
/*  759 */       builder.icon(json.icon);
/*      */     }
/*  761 */     if (json.unicodeEmoji != null) {
/*  762 */       builder.unicodeEmoji(json.unicodeEmoji);
/*      */     }
/*  764 */     if (json.tags != null) {
/*  765 */       builder.tags(json.tags);
/*      */     }
/*  767 */     if (json.positionIsSet) {
/*  768 */       builder.position(json.position);
/*      */     }
/*  770 */     if (json.managedIsSet) {
/*  771 */       builder.managed(json.managed);
/*      */     }
/*  773 */     return builder.build();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableRoleData of(Id id, String name, int color, boolean hoist, long permissions, boolean mentionable, Possible<Optional<String>> icon, Possible<Optional<String>> unicodeEmoji, Possible<RoleTagsData> tags, int position, boolean managed) {
/*  792 */     return new ImmutableRoleData(id, name, color, hoist, permissions, mentionable, icon, unicodeEmoji, tags, position, managed);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableRoleData copyOf(RoleData instance) {
/*  803 */     if (instance instanceof ImmutableRoleData) {
/*  804 */       return (ImmutableRoleData)instance;
/*      */     }
/*  806 */     return builder()
/*  807 */       .from(instance)
/*  808 */       .build();
/*      */   }
/*      */   
/*      */   public boolean isIconPresent() {
/*  812 */     return !this.icon_absent;
/*      */   }
/*      */   
/*      */   public String iconOrElse(String defaultValue) {
/*  816 */     return !this.icon_absent ? this.icon_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isUnicodeEmojiPresent() {
/*  820 */     return !this.unicodeEmoji_absent;
/*      */   }
/*      */   
/*      */   public String unicodeEmojiOrElse(String defaultValue) {
/*  824 */     return !this.unicodeEmoji_absent ? this.unicodeEmoji_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isTagsPresent() {
/*  828 */     return !this.tags_absent;
/*      */   }
/*      */   
/*      */   public RoleTagsData tagsOrElse(RoleTagsData defaultValue) {
/*  832 */     return !this.tags_absent ? this.tags_value : defaultValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Builder builder() {
/*  855 */     return new Builder();
/*      */   }
/*      */ 
/*      */   
/*      */   @Generated(from = "RoleData", generator = "Immutables")
/*      */   public static final class Builder
/*      */   {
/*      */     private static final long INIT_BIT_NAME = 1L;
/*      */     
/*      */     private static final long INIT_BIT_COLOR = 2L;
/*      */     
/*      */     private static final long INIT_BIT_HOIST = 4L;
/*      */     
/*      */     private static final long INIT_BIT_PERMISSIONS = 8L;
/*      */     
/*      */     private static final long INIT_BIT_MENTIONABLE = 16L;
/*      */     
/*      */     private static final long INIT_BIT_POSITION = 32L;
/*      */     private static final long INIT_BIT_MANAGED = 64L;
/*  874 */     private long initBits = 127L;
/*      */     
/*  876 */     private Id id_id = null;
/*  877 */     private Possible<Optional<String>> icon_possible = Possible.absent();
/*  878 */     private Possible<Optional<String>> unicodeEmoji_possible = Possible.absent();
/*  879 */     private Possible<RoleTagsData> tags_possible = Possible.absent();
/*      */     
/*      */     private String name;
/*      */     
/*      */     private int color;
/*      */     
/*      */     private boolean hoist;
/*      */     
/*      */     private long permissions;
/*      */     
/*      */     private boolean mentionable;
/*      */     
/*      */     private int position;
/*      */     
/*      */     private boolean managed;
/*      */ 
/*      */     
/*      */     public final Builder from(RoleDataFields instance) {
/*  897 */       Objects.requireNonNull(instance, "instance");
/*  898 */       from(instance);
/*  899 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder from(RoleData instance) {
/*  908 */       Objects.requireNonNull(instance, "instance");
/*  909 */       from(instance);
/*  910 */       return this;
/*      */     }
/*      */     
/*      */     private void from(Object object) {
/*  914 */       long bits = 0L;
/*  915 */       if (object instanceof RoleDataFields) {
/*  916 */         RoleDataFields instance = (RoleDataFields)object;
/*  917 */         if ((bits & 0x1L) == 0L) {
/*  918 */           color(instance.color());
/*  919 */           bits |= 0x1L;
/*      */         } 
/*  921 */         if ((bits & 0x2L) == 0L) {
/*  922 */           permissions(instance.permissions());
/*  923 */           bits |= 0x2L;
/*      */         } 
/*  925 */         if ((bits & 0x4L) == 0L) {
/*  926 */           name(instance.name());
/*  927 */           bits |= 0x4L;
/*      */         } 
/*  929 */         if ((bits & 0x8L) == 0L) {
/*  930 */           icon(instance.icon());
/*  931 */           bits |= 0x8L;
/*      */         } 
/*  933 */         if ((bits & 0x10L) == 0L) {
/*  934 */           mentionable(instance.mentionable());
/*  935 */           bits |= 0x10L;
/*      */         } 
/*  937 */         if ((bits & 0x20L) == 0L) {
/*  938 */           id(instance.id());
/*  939 */           bits |= 0x20L;
/*      */         } 
/*  941 */         if ((bits & 0x40L) == 0L) {
/*  942 */           hoist(instance.hoist());
/*  943 */           bits |= 0x40L;
/*      */         } 
/*  945 */         if ((bits & 0x80L) == 0L) {
/*  946 */           unicodeEmoji(instance.unicodeEmoji());
/*  947 */           bits |= 0x80L;
/*      */         } 
/*  949 */         if ((bits & 0x100L) == 0L) {
/*  950 */           tags(instance.tags());
/*  951 */           bits |= 0x100L;
/*      */         } 
/*      */       } 
/*  954 */       if (object instanceof RoleData) {
/*  955 */         RoleData instance = (RoleData)object;
/*  956 */         if ((bits & 0x1L) == 0L) {
/*  957 */           color(instance.color());
/*  958 */           bits |= 0x1L;
/*      */         } 
/*  960 */         if ((bits & 0x2L) == 0L) {
/*  961 */           permissions(instance.permissions());
/*  962 */           bits |= 0x2L;
/*      */         } 
/*  964 */         managed(instance.managed());
/*  965 */         if ((bits & 0x4L) == 0L) {
/*  966 */           name(instance.name());
/*  967 */           bits |= 0x4L;
/*      */         } 
/*  969 */         if ((bits & 0x8L) == 0L) {
/*  970 */           icon(instance.icon());
/*  971 */           bits |= 0x8L;
/*      */         } 
/*  973 */         if ((bits & 0x10L) == 0L) {
/*  974 */           mentionable(instance.mentionable());
/*  975 */           bits |= 0x10L;
/*      */         } 
/*  977 */         if ((bits & 0x20L) == 0L) {
/*  978 */           id(instance.id());
/*  979 */           bits |= 0x20L;
/*      */         } 
/*  981 */         position(instance.position());
/*  982 */         if ((bits & 0x40L) == 0L) {
/*  983 */           hoist(instance.hoist());
/*  984 */           bits |= 0x40L;
/*      */         } 
/*  986 */         if ((bits & 0x80L) == 0L) {
/*  987 */           unicodeEmoji(instance.unicodeEmoji());
/*  988 */           bits |= 0x80L;
/*      */         } 
/*  990 */         if ((bits & 0x100L) == 0L) {
/*  991 */           tags(instance.tags());
/*  992 */           bits |= 0x100L;
/*      */         } 
/*      */       } 
/*      */     }
/*      */     
/*      */     public Builder id(String value) {
/*  998 */       this.id_id = Id.of(value);
/*  999 */       return this;
/*      */     }
/*      */     
/*      */     public Builder id(long value) {
/* 1003 */       this.id_id = Id.of(value);
/* 1004 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("id")
/*      */     public Builder id(Id value) {
/* 1009 */       this.id_id = value;
/* 1010 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("name")
/*      */     public final Builder name(String name) {
/* 1020 */       this.name = Objects.<String>requireNonNull(name, "name");
/* 1021 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 1022 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("color")
/*      */     public final Builder color(int color) {
/* 1032 */       this.color = color;
/* 1033 */       this.initBits &= 0xFFFFFFFFFFFFFFFDL;
/* 1034 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("hoist")
/*      */     public final Builder hoist(boolean hoist) {
/* 1044 */       this.hoist = hoist;
/* 1045 */       this.initBits &= 0xFFFFFFFFFFFFFFFBL;
/* 1046 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("permissions")
/*      */     public final Builder permissions(long permissions) {
/* 1056 */       this.permissions = permissions;
/* 1057 */       this.initBits &= 0xFFFFFFFFFFFFFFF7L;
/* 1058 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("mentionable")
/*      */     public final Builder mentionable(boolean mentionable) {
/* 1068 */       this.mentionable = mentionable;
/* 1069 */       this.initBits &= 0xFFFFFFFFFFFFFFEFL;
/* 1070 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("icon")
/*      */     public Builder icon(Possible<Optional<String>> value) {
/* 1075 */       this.icon_possible = value;
/* 1076 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public Builder icon(@Nullable String value) {
/* 1081 */       this.icon_possible = Possible.of(Optional.ofNullable(value));
/* 1082 */       return this;
/*      */     }
/*      */     
/*      */     public Builder iconOrNull(@Nullable String value) {
/* 1086 */       this.icon_possible = Possible.of(Optional.ofNullable(value));
/* 1087 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("unicode_emoji")
/*      */     public Builder unicodeEmoji(Possible<Optional<String>> value) {
/* 1092 */       this.unicodeEmoji_possible = value;
/* 1093 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public Builder unicodeEmoji(@Nullable String value) {
/* 1098 */       this.unicodeEmoji_possible = Possible.of(Optional.ofNullable(value));
/* 1099 */       return this;
/*      */     }
/*      */     
/*      */     public Builder unicodeEmojiOrNull(@Nullable String value) {
/* 1103 */       this.unicodeEmoji_possible = Possible.of(Optional.ofNullable(value));
/* 1104 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("tags")
/*      */     public Builder tags(Possible<RoleTagsData> value) {
/* 1109 */       this.tags_possible = value;
/* 1110 */       return this;
/*      */     }
/*      */     
/*      */     public Builder tags(RoleTagsData value) {
/* 1114 */       this.tags_possible = Possible.of(value);
/* 1115 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("position")
/*      */     public final Builder position(int position) {
/* 1125 */       this.position = position;
/* 1126 */       this.initBits &= 0xFFFFFFFFFFFFFFDFL;
/* 1127 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("managed")
/*      */     public final Builder managed(boolean managed) {
/* 1137 */       this.managed = managed;
/* 1138 */       this.initBits &= 0xFFFFFFFFFFFFFFBFL;
/* 1139 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ImmutableRoleData build() {
/* 1148 */       if (this.initBits != 0L) {
/* 1149 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*      */       }
/* 1151 */       return new ImmutableRoleData(null, 
/*      */           
/* 1153 */           id_build(), this.name, this.color, this.hoist, this.permissions, this.mentionable, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1159 */           icon_build(), 
/* 1160 */           unicodeEmoji_build(), 
/* 1161 */           tags_build(), this.position, this.managed);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     private String formatRequiredAttributesMessage() {
/* 1167 */       List<String> attributes = new ArrayList<>();
/* 1168 */       if ((this.initBits & 0x1L) != 0L) attributes.add("name"); 
/* 1169 */       if ((this.initBits & 0x2L) != 0L) attributes.add("color"); 
/* 1170 */       if ((this.initBits & 0x4L) != 0L) attributes.add("hoist"); 
/* 1171 */       if ((this.initBits & 0x8L) != 0L) attributes.add("permissions"); 
/* 1172 */       if ((this.initBits & 0x10L) != 0L) attributes.add("mentionable"); 
/* 1173 */       if ((this.initBits & 0x20L) != 0L) attributes.add("position"); 
/* 1174 */       if ((this.initBits & 0x40L) != 0L) attributes.add("managed"); 
/* 1175 */       return "Cannot build RoleData, some of required attributes are not set " + attributes;
/*      */     }
/*      */     
/*      */     private Id id_build() {
/* 1179 */       return this.id_id;
/*      */     }
/*      */     
/*      */     private Possible<Optional<String>> icon_build() {
/* 1183 */       return this.icon_possible;
/*      */     }
/*      */     
/*      */     private Possible<Optional<String>> unicodeEmoji_build() {
/* 1187 */       return this.unicodeEmoji_possible;
/*      */     }
/*      */     
/*      */     private Possible<RoleTagsData> tags_build() {
/* 1191 */       return this.tags_possible;
/*      */     }
/*      */     
/*      */     private Builder() {}
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableRoleData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */