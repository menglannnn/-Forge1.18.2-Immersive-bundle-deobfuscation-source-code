/*      */ package discord4j.discordjson.json;
/*      */ 
/*      */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*      */ import com.fasterxml.jackson.annotation.JsonCreator;
/*      */ import com.fasterxml.jackson.annotation.JsonProperty;
/*      */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*      */ import discord4j.discordjson.Id;
/*      */ import discord4j.discordjson.possible.Possible;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.List;
/*      */ import java.util.Objects;
/*      */ import java.util.stream.Collectors;
/*      */ import java.util.stream.StreamSupport;
/*      */ import org.immutables.value.Generated;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ @Generated(from = "GuildCreateRequest", generator = "Immutables")
/*      */ public final class ImmutableGuildCreateRequest
/*      */   implements GuildCreateRequest
/*      */ {
/*      */   private final String name;
/*      */   private final String region_value;
/*      */   private final boolean region_absent;
/*      */   private final String icon_value;
/*      */   private final boolean icon_absent;
/*      */   private final Integer verificationLevel_value;
/*      */   private final boolean verificationLevel_absent;
/*      */   private final Integer defaultMessageNotifications_value;
/*      */   private final boolean defaultMessageNotifications_absent;
/*      */   private final Integer explicitContentFilter_value;
/*      */   private final boolean explicitContentFilter_absent;
/*      */   private final List<RoleCreateRequest> roles_value;
/*      */   private final boolean roles_absent;
/*      */   private final List<PartialChannelCreateRequest> channels_value;
/*      */   private final boolean channels_absent;
/*      */   private final long afkChannelId_value;
/*      */   private final boolean afkChannelId_absent;
/*      */   private final Integer afkTimeout_value;
/*      */   private final boolean afkTimeout_absent;
/*      */   private final long systemChannelId_value;
/*      */   private final boolean systemChannelId_absent;
/*      */   private final Integer systemChannelFlags_value;
/*      */   private final boolean systemChannelFlags_absent;
/*      */   private static final byte STAGE_INITIALIZING = -1;
/*      */   private static final byte STAGE_UNINITIALIZED = 0;
/*      */   private static final byte STAGE_INITIALIZED = 1;
/*      */   private volatile transient InitShim initShim;
/*      */   
/*      */   private ImmutableGuildCreateRequest(String name, Possible<String> region, Possible<String> icon, Possible<Integer> verificationLevel, Possible<Integer> defaultMessageNotifications, Possible<Integer> explicitContentFilter, Possible<List<RoleCreateRequest>> roles, Possible<List<PartialChannelCreateRequest>> channels, Possible<Id> afkChannelId, Possible<Integer> afkTimeout, Possible<Id> systemChannelId, Possible<Integer> systemChannelFlags) {
/*  165 */     this.initShim = new InitShim(); this.name = Objects.<String>requireNonNull(name, "name"); Possible<String> region$impl = region; Possible<String> icon$impl = icon; Possible<Integer> verificationLevel$impl = verificationLevel; Possible<Integer> defaultMessageNotifications$impl = defaultMessageNotifications; Possible<Integer> explicitContentFilter$impl = explicitContentFilter; Possible<List<RoleCreateRequest>> roles$impl = roles; Possible<List<PartialChannelCreateRequest>> channels$impl = channels; Possible<Id> afkChannelId$impl = afkChannelId; Possible<Integer> afkTimeout$impl = afkTimeout; Possible<Id> systemChannelId$impl = systemChannelId; Possible<Integer> systemChannelFlags$impl = systemChannelFlags; this.region_value = region$impl.toOptional().orElse(null); this.region_absent = region$impl.isAbsent(); this.icon_value = icon$impl.toOptional().orElse(null); this.icon_absent = icon$impl.isAbsent(); this.verificationLevel_value = verificationLevel$impl.toOptional().orElse(null); this.verificationLevel_absent = verificationLevel$impl.isAbsent(); this.defaultMessageNotifications_value = defaultMessageNotifications$impl.toOptional().orElse(null); this.defaultMessageNotifications_absent = defaultMessageNotifications$impl.isAbsent(); this.explicitContentFilter_value = explicitContentFilter$impl.toOptional().orElse(null); this.explicitContentFilter_absent = explicitContentFilter$impl.isAbsent(); this.roles_value = roles$impl.toOptional().orElse(null); this.roles_absent = roles$impl.isAbsent(); this.channels_value = channels$impl.toOptional().orElse(null); this.channels_absent = channels$impl.isAbsent(); this.afkChannelId_value = ((Long)afkChannelId$impl.toOptional().map(Id::asLong).orElse(Long.valueOf(0L))).longValue(); this.afkChannelId_absent = afkChannelId$impl.isAbsent(); this.afkTimeout_value = afkTimeout$impl.toOptional().orElse(null); this.afkTimeout_absent = afkTimeout$impl.isAbsent(); this.systemChannelId_value = ((Long)systemChannelId$impl.toOptional().map(Id::asLong).orElse(Long.valueOf(0L))).longValue(); this.systemChannelId_absent = systemChannelId$impl.isAbsent(); this.systemChannelFlags_value = systemChannelFlags$impl.toOptional().orElse(null); this.systemChannelFlags_absent = systemChannelFlags$impl.isAbsent(); this.initShim = null; } private ImmutableGuildCreateRequest(ImmutableGuildCreateRequest original, String name, Possible<String> region, Possible<String> icon, Possible<Integer> verificationLevel, Possible<Integer> defaultMessageNotifications, Possible<Integer> explicitContentFilter, Possible<List<RoleCreateRequest>> roles, Possible<List<PartialChannelCreateRequest>> channels, Possible<Id> afkChannelId, Possible<Integer> afkTimeout, Possible<Id> systemChannelId, Possible<Integer> systemChannelFlags) { this.initShim = new InitShim(); this.name = name; Possible<String> region$impl = region; Possible<String> icon$impl = icon; Possible<Integer> verificationLevel$impl = verificationLevel; Possible<Integer> defaultMessageNotifications$impl = defaultMessageNotifications; Possible<Integer> explicitContentFilter$impl = explicitContentFilter; Possible<List<RoleCreateRequest>> roles$impl = roles; Possible<List<PartialChannelCreateRequest>> channels$impl = channels; Possible<Id> afkChannelId$impl = afkChannelId; Possible<Integer> afkTimeout$impl = afkTimeout; Possible<Id> systemChannelId$impl = systemChannelId; Possible<Integer> systemChannelFlags$impl = systemChannelFlags; this.region_value = region$impl.toOptional().orElse(null); this.region_absent = region$impl.isAbsent(); this.icon_value = icon$impl.toOptional().orElse(null); this.icon_absent = icon$impl.isAbsent(); this.verificationLevel_value = verificationLevel$impl.toOptional().orElse(null); this.verificationLevel_absent = verificationLevel$impl.isAbsent(); this.defaultMessageNotifications_value = defaultMessageNotifications$impl.toOptional().orElse(null); this.defaultMessageNotifications_absent = defaultMessageNotifications$impl.isAbsent(); this.explicitContentFilter_value = explicitContentFilter$impl.toOptional().orElse(null); this.explicitContentFilter_absent = explicitContentFilter$impl.isAbsent(); this.roles_value = roles$impl.toOptional().orElse(null); this.roles_absent = roles$impl.isAbsent(); this.channels_value = channels$impl.toOptional().orElse(null); this.channels_absent = channels$impl.isAbsent(); this.afkChannelId_value = ((Long)afkChannelId$impl.toOptional().map(Id::asLong).orElse(Long.valueOf(0L))).longValue(); this.afkChannelId_absent = afkChannelId$impl.isAbsent(); this.afkTimeout_value = afkTimeout$impl.toOptional().orElse(null); this.afkTimeout_absent = afkTimeout$impl.isAbsent();
/*      */     this.systemChannelId_value = ((Long)systemChannelId$impl.toOptional().map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*      */     this.systemChannelId_absent = systemChannelId$impl.isAbsent();
/*      */     this.systemChannelFlags_value = systemChannelFlags$impl.toOptional().orElse(null);
/*      */     this.systemChannelFlags_absent = systemChannelFlags$impl.isAbsent();
/*  170 */     this.initShim = null; } @Generated(from = "GuildCreateRequest", generator = "Immutables") private final class InitShim { private InitShim() {} private String formatInitCycleMessage() { List<String> attributes = new ArrayList<>();
/*  171 */       return "Cannot build GuildCreateRequest, attribute initializers form cycle " + attributes; }
/*      */      }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("name")
/*      */   public String name() {
/*  181 */     return this.name;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("region")
/*      */   public Possible<String> region() {
/*  190 */     return this.region_absent ? Possible.absent() : Possible.of(this.region_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("icon")
/*      */   public Possible<String> icon() {
/*  199 */     return this.icon_absent ? Possible.absent() : Possible.of(this.icon_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("verification_level")
/*      */   public Possible<Integer> verificationLevel() {
/*  208 */     return this.verificationLevel_absent ? Possible.absent() : Possible.of(this.verificationLevel_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("default_message_notifications")
/*      */   public Possible<Integer> defaultMessageNotifications() {
/*  217 */     return this.defaultMessageNotifications_absent ? Possible.absent() : Possible.of(this.defaultMessageNotifications_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("explicit_content_filter")
/*      */   public Possible<Integer> explicitContentFilter() {
/*  226 */     return this.explicitContentFilter_absent ? Possible.absent() : Possible.of(this.explicitContentFilter_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("roles")
/*      */   public Possible<List<RoleCreateRequest>> roles() {
/*  235 */     return this.roles_absent ? Possible.absent() : 
/*  236 */       Possible.of(this.roles_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("channels")
/*      */   public Possible<List<PartialChannelCreateRequest>> channels() {
/*  245 */     return this.channels_absent ? Possible.absent() : 
/*  246 */       Possible.of(this.channels_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("afk_channel_id")
/*      */   public Possible<Id> afkChannelId() {
/*  255 */     return this.afkChannelId_absent ? Possible.absent() : 
/*  256 */       Possible.of(Id.of(this.afkChannelId_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("afk_timeout")
/*      */   public Possible<Integer> afkTimeout() {
/*  265 */     return this.afkTimeout_absent ? Possible.absent() : Possible.of(this.afkTimeout_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("system_channel_id")
/*      */   public Possible<Id> systemChannelId() {
/*  274 */     return this.systemChannelId_absent ? Possible.absent() : 
/*  275 */       Possible.of(Id.of(this.systemChannelId_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("system_channel_flags")
/*      */   public Possible<Integer> systemChannelFlags() {
/*  284 */     return this.systemChannelFlags_absent ? Possible.absent() : Possible.of(this.systemChannelFlags_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildCreateRequest withName(String value) {
/*  294 */     String newValue = Objects.<String>requireNonNull(value, "name");
/*  295 */     if (this.name.equals(newValue)) return this; 
/*  296 */     return new ImmutableGuildCreateRequest(this, newValue, 
/*      */ 
/*      */         
/*  299 */         region(), 
/*  300 */         icon(), 
/*  301 */         verificationLevel(), 
/*  302 */         defaultMessageNotifications(), 
/*  303 */         explicitContentFilter(), 
/*  304 */         roles(), 
/*  305 */         channels(), 
/*  306 */         afkChannelId(), 
/*  307 */         afkTimeout(), 
/*  308 */         systemChannelId(), 
/*  309 */         systemChannelFlags());
/*      */   }
/*      */   
/*      */   public ImmutableGuildCreateRequest withRegion(Possible<String> value) {
/*  313 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/*  314 */     return new ImmutableGuildCreateRequest(this, this.name, newValue, 
/*      */ 
/*      */ 
/*      */         
/*  318 */         icon(), 
/*  319 */         verificationLevel(), 
/*  320 */         defaultMessageNotifications(), 
/*  321 */         explicitContentFilter(), 
/*  322 */         roles(), 
/*  323 */         channels(), 
/*  324 */         afkChannelId(), 
/*  325 */         afkTimeout(), 
/*  326 */         systemChannelId(), 
/*  327 */         systemChannelFlags());
/*      */   }
/*      */   
/*      */   public ImmutableGuildCreateRequest withRegion(String value) {
/*  331 */     Possible<String> newValue = Possible.of(value);
/*  332 */     return new ImmutableGuildCreateRequest(this, this.name, newValue, 
/*      */ 
/*      */ 
/*      */         
/*  336 */         icon(), 
/*  337 */         verificationLevel(), 
/*  338 */         defaultMessageNotifications(), 
/*  339 */         explicitContentFilter(), 
/*  340 */         roles(), 
/*  341 */         channels(), 
/*  342 */         afkChannelId(), 
/*  343 */         afkTimeout(), 
/*  344 */         systemChannelId(), 
/*  345 */         systemChannelFlags());
/*      */   }
/*      */   
/*      */   public ImmutableGuildCreateRequest withIcon(Possible<String> value) {
/*  349 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/*  350 */     return new ImmutableGuildCreateRequest(this, this.name, 
/*      */ 
/*      */         
/*  353 */         region(), newValue, 
/*      */         
/*  355 */         verificationLevel(), 
/*  356 */         defaultMessageNotifications(), 
/*  357 */         explicitContentFilter(), 
/*  358 */         roles(), 
/*  359 */         channels(), 
/*  360 */         afkChannelId(), 
/*  361 */         afkTimeout(), 
/*  362 */         systemChannelId(), 
/*  363 */         systemChannelFlags());
/*      */   }
/*      */   
/*      */   public ImmutableGuildCreateRequest withIcon(String value) {
/*  367 */     Possible<String> newValue = Possible.of(value);
/*  368 */     return new ImmutableGuildCreateRequest(this, this.name, 
/*      */ 
/*      */         
/*  371 */         region(), newValue, 
/*      */         
/*  373 */         verificationLevel(), 
/*  374 */         defaultMessageNotifications(), 
/*  375 */         explicitContentFilter(), 
/*  376 */         roles(), 
/*  377 */         channels(), 
/*  378 */         afkChannelId(), 
/*  379 */         afkTimeout(), 
/*  380 */         systemChannelId(), 
/*  381 */         systemChannelFlags());
/*      */   }
/*      */   
/*      */   public ImmutableGuildCreateRequest withVerificationLevel(Possible<Integer> value) {
/*  385 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/*  386 */     return new ImmutableGuildCreateRequest(this, this.name, 
/*      */ 
/*      */         
/*  389 */         region(), 
/*  390 */         icon(), newValue, 
/*      */         
/*  392 */         defaultMessageNotifications(), 
/*  393 */         explicitContentFilter(), 
/*  394 */         roles(), 
/*  395 */         channels(), 
/*  396 */         afkChannelId(), 
/*  397 */         afkTimeout(), 
/*  398 */         systemChannelId(), 
/*  399 */         systemChannelFlags());
/*      */   }
/*      */   
/*      */   public ImmutableGuildCreateRequest withVerificationLevel(Integer value) {
/*  403 */     Possible<Integer> newValue = Possible.of(value);
/*  404 */     return new ImmutableGuildCreateRequest(this, this.name, 
/*      */ 
/*      */         
/*  407 */         region(), 
/*  408 */         icon(), newValue, 
/*      */         
/*  410 */         defaultMessageNotifications(), 
/*  411 */         explicitContentFilter(), 
/*  412 */         roles(), 
/*  413 */         channels(), 
/*  414 */         afkChannelId(), 
/*  415 */         afkTimeout(), 
/*  416 */         systemChannelId(), 
/*  417 */         systemChannelFlags());
/*      */   }
/*      */   
/*      */   public ImmutableGuildCreateRequest withDefaultMessageNotifications(Possible<Integer> value) {
/*  421 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/*  422 */     return new ImmutableGuildCreateRequest(this, this.name, 
/*      */ 
/*      */         
/*  425 */         region(), 
/*  426 */         icon(), 
/*  427 */         verificationLevel(), newValue, 
/*      */         
/*  429 */         explicitContentFilter(), 
/*  430 */         roles(), 
/*  431 */         channels(), 
/*  432 */         afkChannelId(), 
/*  433 */         afkTimeout(), 
/*  434 */         systemChannelId(), 
/*  435 */         systemChannelFlags());
/*      */   }
/*      */   
/*      */   public ImmutableGuildCreateRequest withDefaultMessageNotifications(Integer value) {
/*  439 */     Possible<Integer> newValue = Possible.of(value);
/*  440 */     return new ImmutableGuildCreateRequest(this, this.name, 
/*      */ 
/*      */         
/*  443 */         region(), 
/*  444 */         icon(), 
/*  445 */         verificationLevel(), newValue, 
/*      */         
/*  447 */         explicitContentFilter(), 
/*  448 */         roles(), 
/*  449 */         channels(), 
/*  450 */         afkChannelId(), 
/*  451 */         afkTimeout(), 
/*  452 */         systemChannelId(), 
/*  453 */         systemChannelFlags());
/*      */   }
/*      */   
/*      */   public ImmutableGuildCreateRequest withExplicitContentFilter(Possible<Integer> value) {
/*  457 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/*  458 */     return new ImmutableGuildCreateRequest(this, this.name, 
/*      */ 
/*      */         
/*  461 */         region(), 
/*  462 */         icon(), 
/*  463 */         verificationLevel(), 
/*  464 */         defaultMessageNotifications(), newValue, 
/*      */         
/*  466 */         roles(), 
/*  467 */         channels(), 
/*  468 */         afkChannelId(), 
/*  469 */         afkTimeout(), 
/*  470 */         systemChannelId(), 
/*  471 */         systemChannelFlags());
/*      */   }
/*      */   
/*      */   public ImmutableGuildCreateRequest withExplicitContentFilter(Integer value) {
/*  475 */     Possible<Integer> newValue = Possible.of(value);
/*  476 */     return new ImmutableGuildCreateRequest(this, this.name, 
/*      */ 
/*      */         
/*  479 */         region(), 
/*  480 */         icon(), 
/*  481 */         verificationLevel(), 
/*  482 */         defaultMessageNotifications(), newValue, 
/*      */         
/*  484 */         roles(), 
/*  485 */         channels(), 
/*  486 */         afkChannelId(), 
/*  487 */         afkTimeout(), 
/*  488 */         systemChannelId(), 
/*  489 */         systemChannelFlags());
/*      */   }
/*      */   
/*      */   public ImmutableGuildCreateRequest withRoles(Possible<List<RoleCreateRequest>> possible) {
/*  493 */     Possible<List<RoleCreateRequest>> newValue = Objects.<Possible<List<RoleCreateRequest>>>requireNonNull(possible);
/*  494 */     return new ImmutableGuildCreateRequest(this, this.name, 
/*      */ 
/*      */         
/*  497 */         region(), 
/*  498 */         icon(), 
/*  499 */         verificationLevel(), 
/*  500 */         defaultMessageNotifications(), 
/*  501 */         explicitContentFilter(), newValue, 
/*      */         
/*  503 */         channels(), 
/*  504 */         afkChannelId(), 
/*  505 */         afkTimeout(), 
/*  506 */         systemChannelId(), 
/*  507 */         systemChannelFlags());
/*      */   }
/*      */   
/*      */   public ImmutableGuildCreateRequest withRoles(Iterable<RoleCreateRequest> elements) {
/*  511 */     Possible<List<RoleCreateRequest>> newValue = Possible.of(
/*  512 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/*  513 */     return new ImmutableGuildCreateRequest(this, this.name, 
/*      */ 
/*      */         
/*  516 */         region(), 
/*  517 */         icon(), 
/*  518 */         verificationLevel(), 
/*  519 */         defaultMessageNotifications(), 
/*  520 */         explicitContentFilter(), newValue, 
/*      */         
/*  522 */         channels(), 
/*  523 */         afkChannelId(), 
/*  524 */         afkTimeout(), 
/*  525 */         systemChannelId(), 
/*  526 */         systemChannelFlags());
/*      */   }
/*      */   
/*      */   @SafeVarargs
/*      */   public final ImmutableGuildCreateRequest withRoles(RoleCreateRequest... elements) {
/*  531 */     Possible<List<RoleCreateRequest>> newValue = Possible.of(Arrays.asList(elements));
/*  532 */     return new ImmutableGuildCreateRequest(this, this.name, 
/*      */ 
/*      */         
/*  535 */         region(), 
/*  536 */         icon(), 
/*  537 */         verificationLevel(), 
/*  538 */         defaultMessageNotifications(), 
/*  539 */         explicitContentFilter(), newValue, 
/*      */         
/*  541 */         channels(), 
/*  542 */         afkChannelId(), 
/*  543 */         afkTimeout(), 
/*  544 */         systemChannelId(), 
/*  545 */         systemChannelFlags());
/*      */   }
/*      */   
/*      */   public ImmutableGuildCreateRequest withChannels(Possible<List<PartialChannelCreateRequest>> possible) {
/*  549 */     Possible<List<PartialChannelCreateRequest>> newValue = Objects.<Possible<List<PartialChannelCreateRequest>>>requireNonNull(possible);
/*  550 */     return new ImmutableGuildCreateRequest(this, this.name, 
/*      */ 
/*      */         
/*  553 */         region(), 
/*  554 */         icon(), 
/*  555 */         verificationLevel(), 
/*  556 */         defaultMessageNotifications(), 
/*  557 */         explicitContentFilter(), 
/*  558 */         roles(), newValue, 
/*      */         
/*  560 */         afkChannelId(), 
/*  561 */         afkTimeout(), 
/*  562 */         systemChannelId(), 
/*  563 */         systemChannelFlags());
/*      */   }
/*      */   
/*      */   public ImmutableGuildCreateRequest withChannels(Iterable<PartialChannelCreateRequest> elements) {
/*  567 */     Possible<List<PartialChannelCreateRequest>> newValue = Possible.of(
/*  568 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/*  569 */     return new ImmutableGuildCreateRequest(this, this.name, 
/*      */ 
/*      */         
/*  572 */         region(), 
/*  573 */         icon(), 
/*  574 */         verificationLevel(), 
/*  575 */         defaultMessageNotifications(), 
/*  576 */         explicitContentFilter(), 
/*  577 */         roles(), newValue, 
/*      */         
/*  579 */         afkChannelId(), 
/*  580 */         afkTimeout(), 
/*  581 */         systemChannelId(), 
/*  582 */         systemChannelFlags());
/*      */   }
/*      */   
/*      */   @SafeVarargs
/*      */   public final ImmutableGuildCreateRequest withChannels(PartialChannelCreateRequest... elements) {
/*  587 */     Possible<List<PartialChannelCreateRequest>> newValue = Possible.of(Arrays.asList(elements));
/*  588 */     return new ImmutableGuildCreateRequest(this, this.name, 
/*      */ 
/*      */         
/*  591 */         region(), 
/*  592 */         icon(), 
/*  593 */         verificationLevel(), 
/*  594 */         defaultMessageNotifications(), 
/*  595 */         explicitContentFilter(), 
/*  596 */         roles(), newValue, 
/*      */         
/*  598 */         afkChannelId(), 
/*  599 */         afkTimeout(), 
/*  600 */         systemChannelId(), 
/*  601 */         systemChannelFlags());
/*      */   }
/*      */   
/*      */   public ImmutableGuildCreateRequest withAfkChannelId(Possible<Id> value) {
/*  605 */     Possible<Id> newValue = Objects.<Possible<Id>>requireNonNull(value);
/*  606 */     return new ImmutableGuildCreateRequest(this, this.name, 
/*      */ 
/*      */         
/*  609 */         region(), 
/*  610 */         icon(), 
/*  611 */         verificationLevel(), 
/*  612 */         defaultMessageNotifications(), 
/*  613 */         explicitContentFilter(), 
/*  614 */         roles(), 
/*  615 */         channels(), newValue, 
/*      */         
/*  617 */         afkTimeout(), 
/*  618 */         systemChannelId(), 
/*  619 */         systemChannelFlags());
/*      */   }
/*      */   
/*      */   public ImmutableGuildCreateRequest withAfkChannelId(long value) {
/*  623 */     Possible<Id> newValue = Possible.of(Id.of(value));
/*  624 */     return new ImmutableGuildCreateRequest(this, this.name, 
/*      */ 
/*      */         
/*  627 */         region(), 
/*  628 */         icon(), 
/*  629 */         verificationLevel(), 
/*  630 */         defaultMessageNotifications(), 
/*  631 */         explicitContentFilter(), 
/*  632 */         roles(), 
/*  633 */         channels(), newValue, 
/*      */         
/*  635 */         afkTimeout(), 
/*  636 */         systemChannelId(), 
/*  637 */         systemChannelFlags());
/*      */   }
/*      */   
/*      */   public ImmutableGuildCreateRequest withAfkTimeout(Possible<Integer> value) {
/*  641 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/*  642 */     return new ImmutableGuildCreateRequest(this, this.name, 
/*      */ 
/*      */         
/*  645 */         region(), 
/*  646 */         icon(), 
/*  647 */         verificationLevel(), 
/*  648 */         defaultMessageNotifications(), 
/*  649 */         explicitContentFilter(), 
/*  650 */         roles(), 
/*  651 */         channels(), 
/*  652 */         afkChannelId(), newValue, 
/*      */         
/*  654 */         systemChannelId(), 
/*  655 */         systemChannelFlags());
/*      */   }
/*      */   
/*      */   public ImmutableGuildCreateRequest withAfkTimeout(Integer value) {
/*  659 */     Possible<Integer> newValue = Possible.of(value);
/*  660 */     return new ImmutableGuildCreateRequest(this, this.name, 
/*      */ 
/*      */         
/*  663 */         region(), 
/*  664 */         icon(), 
/*  665 */         verificationLevel(), 
/*  666 */         defaultMessageNotifications(), 
/*  667 */         explicitContentFilter(), 
/*  668 */         roles(), 
/*  669 */         channels(), 
/*  670 */         afkChannelId(), newValue, 
/*      */         
/*  672 */         systemChannelId(), 
/*  673 */         systemChannelFlags());
/*      */   }
/*      */   
/*      */   public ImmutableGuildCreateRequest withSystemChannelId(Possible<Id> value) {
/*  677 */     Possible<Id> newValue = Objects.<Possible<Id>>requireNonNull(value);
/*  678 */     return new ImmutableGuildCreateRequest(this, this.name, 
/*      */ 
/*      */         
/*  681 */         region(), 
/*  682 */         icon(), 
/*  683 */         verificationLevel(), 
/*  684 */         defaultMessageNotifications(), 
/*  685 */         explicitContentFilter(), 
/*  686 */         roles(), 
/*  687 */         channels(), 
/*  688 */         afkChannelId(), 
/*  689 */         afkTimeout(), newValue, 
/*      */         
/*  691 */         systemChannelFlags());
/*      */   }
/*      */   
/*      */   public ImmutableGuildCreateRequest withSystemChannelId(long value) {
/*  695 */     Possible<Id> newValue = Possible.of(Id.of(value));
/*  696 */     return new ImmutableGuildCreateRequest(this, this.name, 
/*      */ 
/*      */         
/*  699 */         region(), 
/*  700 */         icon(), 
/*  701 */         verificationLevel(), 
/*  702 */         defaultMessageNotifications(), 
/*  703 */         explicitContentFilter(), 
/*  704 */         roles(), 
/*  705 */         channels(), 
/*  706 */         afkChannelId(), 
/*  707 */         afkTimeout(), newValue, 
/*      */         
/*  709 */         systemChannelFlags());
/*      */   }
/*      */   
/*      */   public ImmutableGuildCreateRequest withSystemChannelFlags(Possible<Integer> value) {
/*  713 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/*  714 */     return new ImmutableGuildCreateRequest(this, this.name, 
/*      */ 
/*      */         
/*  717 */         region(), 
/*  718 */         icon(), 
/*  719 */         verificationLevel(), 
/*  720 */         defaultMessageNotifications(), 
/*  721 */         explicitContentFilter(), 
/*  722 */         roles(), 
/*  723 */         channels(), 
/*  724 */         afkChannelId(), 
/*  725 */         afkTimeout(), 
/*  726 */         systemChannelId(), newValue);
/*      */   }
/*      */ 
/*      */   
/*      */   public ImmutableGuildCreateRequest withSystemChannelFlags(Integer value) {
/*  731 */     Possible<Integer> newValue = Possible.of(value);
/*  732 */     return new ImmutableGuildCreateRequest(this, this.name, 
/*      */ 
/*      */         
/*  735 */         region(), 
/*  736 */         icon(), 
/*  737 */         verificationLevel(), 
/*  738 */         defaultMessageNotifications(), 
/*  739 */         explicitContentFilter(), 
/*  740 */         roles(), 
/*  741 */         channels(), 
/*  742 */         afkChannelId(), 
/*  743 */         afkTimeout(), 
/*  744 */         systemChannelId(), newValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean equals(Object another) {
/*  754 */     if (this == another) return true; 
/*  755 */     return (another instanceof ImmutableGuildCreateRequest && 
/*  756 */       equalTo(0, (ImmutableGuildCreateRequest)another));
/*      */   }
/*      */   
/*      */   private boolean equalTo(int synthetic, ImmutableGuildCreateRequest another) {
/*  760 */     return (this.name.equals(another.name) && 
/*  761 */       region().equals(another.region()) && 
/*  762 */       icon().equals(another.icon()) && 
/*  763 */       verificationLevel().equals(another.verificationLevel()) && 
/*  764 */       defaultMessageNotifications().equals(another.defaultMessageNotifications()) && 
/*  765 */       explicitContentFilter().equals(another.explicitContentFilter()) && 
/*  766 */       Objects.equals(this.roles_value, another.roles_value) && 
/*  767 */       Objects.equals(this.channels_value, another.channels_value) && 
/*  768 */       afkChannelId().equals(another.afkChannelId()) && 
/*  769 */       afkTimeout().equals(another.afkTimeout()) && 
/*  770 */       systemChannelId().equals(another.systemChannelId()) && 
/*  771 */       systemChannelFlags().equals(another.systemChannelFlags()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int hashCode() {
/*  780 */     int h = 5381;
/*  781 */     h += (h << 5) + this.name.hashCode();
/*  782 */     h += (h << 5) + region().hashCode();
/*  783 */     h += (h << 5) + icon().hashCode();
/*  784 */     h += (h << 5) + verificationLevel().hashCode();
/*  785 */     h += (h << 5) + defaultMessageNotifications().hashCode();
/*  786 */     h += (h << 5) + explicitContentFilter().hashCode();
/*  787 */     h += (h << 5) + Objects.hashCode(this.roles_value);
/*  788 */     h += (h << 5) + Objects.hashCode(this.channels_value);
/*  789 */     h += (h << 5) + afkChannelId().hashCode();
/*  790 */     h += (h << 5) + afkTimeout().hashCode();
/*  791 */     h += (h << 5) + systemChannelId().hashCode();
/*  792 */     h += (h << 5) + systemChannelFlags().hashCode();
/*  793 */     return h;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/*  802 */     return "GuildCreateRequest{name=" + this.name + ", region=" + 
/*      */       
/*  804 */       region().toString() + ", icon=" + 
/*  805 */       icon().toString() + ", verificationLevel=" + 
/*  806 */       verificationLevel().toString() + ", defaultMessageNotifications=" + 
/*  807 */       defaultMessageNotifications().toString() + ", explicitContentFilter=" + 
/*  808 */       explicitContentFilter().toString() + ", roles=" + 
/*  809 */       Objects.toString(this.roles_value) + ", channels=" + 
/*  810 */       Objects.toString(this.channels_value) + ", afkChannelId=" + 
/*  811 */       afkChannelId().toString() + ", afkTimeout=" + 
/*  812 */       afkTimeout().toString() + ", systemChannelId=" + 
/*  813 */       systemChannelId().toString() + ", systemChannelFlags=" + 
/*  814 */       systemChannelFlags().toString() + "}";
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonDeserialize
/*      */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*      */   @Generated(from = "GuildCreateRequest", generator = "Immutables")
/*      */   static final class Json
/*      */     implements GuildCreateRequest
/*      */   {
/*      */     String name;
/*      */ 
/*      */     
/*  829 */     Possible<String> region = Possible.absent();
/*      */ 
/*      */     
/*  832 */     Possible<String> icon = Possible.absent();
/*      */ 
/*      */     
/*  835 */     Possible<Integer> verificationLevel = Possible.absent();
/*      */ 
/*      */     
/*  838 */     Possible<Integer> defaultMessageNotifications = Possible.absent();
/*      */ 
/*      */     
/*  841 */     Possible<Integer> explicitContentFilter = Possible.absent();
/*      */ 
/*      */     
/*  844 */     Possible<List<RoleCreateRequest>> roles = Possible.absent();
/*      */ 
/*      */     
/*  847 */     Possible<List<PartialChannelCreateRequest>> channels = Possible.absent();
/*      */ 
/*      */     
/*  850 */     Possible<Id> afkChannelId = Possible.absent();
/*      */ 
/*      */     
/*  853 */     Possible<Integer> afkTimeout = Possible.absent();
/*      */ 
/*      */     
/*  856 */     Possible<Id> systemChannelId = Possible.absent();
/*      */ 
/*      */     
/*  859 */     Possible<Integer> systemChannelFlags = Possible.absent();
/*      */     
/*      */     @JsonProperty("name")
/*      */     public void setName(String name) {
/*  863 */       this.name = name;
/*      */     }
/*      */     @JsonProperty("region")
/*      */     public void setRegion(Possible<String> region) {
/*  867 */       this.region = region;
/*      */     }
/*      */     @JsonProperty("icon")
/*      */     public void setIcon(Possible<String> icon) {
/*  871 */       this.icon = icon;
/*      */     }
/*      */     @JsonProperty("verification_level")
/*      */     public void setVerificationLevel(Possible<Integer> verificationLevel) {
/*  875 */       this.verificationLevel = verificationLevel;
/*      */     }
/*      */     @JsonProperty("default_message_notifications")
/*      */     public void setDefaultMessageNotifications(Possible<Integer> defaultMessageNotifications) {
/*  879 */       this.defaultMessageNotifications = defaultMessageNotifications;
/*      */     }
/*      */     @JsonProperty("explicit_content_filter")
/*      */     public void setExplicitContentFilter(Possible<Integer> explicitContentFilter) {
/*  883 */       this.explicitContentFilter = explicitContentFilter;
/*      */     }
/*      */     @JsonProperty("roles")
/*      */     public void setRoles(Possible<List<RoleCreateRequest>> roles) {
/*  887 */       this.roles = roles;
/*      */     }
/*      */     @JsonProperty("channels")
/*      */     public void setChannels(Possible<List<PartialChannelCreateRequest>> channels) {
/*  891 */       this.channels = channels;
/*      */     }
/*      */     @JsonProperty("afk_channel_id")
/*      */     public void setAfkChannelId(Possible<Id> afkChannelId) {
/*  895 */       this.afkChannelId = afkChannelId;
/*      */     }
/*      */     @JsonProperty("afk_timeout")
/*      */     public void setAfkTimeout(Possible<Integer> afkTimeout) {
/*  899 */       this.afkTimeout = afkTimeout;
/*      */     }
/*      */     @JsonProperty("system_channel_id")
/*      */     public void setSystemChannelId(Possible<Id> systemChannelId) {
/*  903 */       this.systemChannelId = systemChannelId;
/*      */     }
/*      */     @JsonProperty("system_channel_flags")
/*      */     public void setSystemChannelFlags(Possible<Integer> systemChannelFlags) {
/*  907 */       this.systemChannelFlags = systemChannelFlags;
/*      */     }
/*      */     public String name() {
/*  910 */       throw new UnsupportedOperationException();
/*      */     } public Possible<String> region() {
/*  912 */       throw new UnsupportedOperationException();
/*      */     } public Possible<String> icon() {
/*  914 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Integer> verificationLevel() {
/*  916 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Integer> defaultMessageNotifications() {
/*  918 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Integer> explicitContentFilter() {
/*  920 */       throw new UnsupportedOperationException();
/*      */     } public Possible<List<RoleCreateRequest>> roles() {
/*  922 */       throw new UnsupportedOperationException();
/*      */     } public Possible<List<PartialChannelCreateRequest>> channels() {
/*  924 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Id> afkChannelId() {
/*  926 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Integer> afkTimeout() {
/*  928 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Id> systemChannelId() {
/*  930 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Integer> systemChannelFlags() {
/*  932 */       throw new UnsupportedOperationException();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*      */   static ImmutableGuildCreateRequest fromJson(Json json) {
/*  943 */     Builder builder = builder();
/*  944 */     if (json.name != null) {
/*  945 */       builder.name(json.name);
/*      */     }
/*  947 */     if (json.region != null) {
/*  948 */       builder.region(json.region);
/*      */     }
/*  950 */     if (json.icon != null) {
/*  951 */       builder.icon(json.icon);
/*      */     }
/*  953 */     if (json.verificationLevel != null) {
/*  954 */       builder.verificationLevel(json.verificationLevel);
/*      */     }
/*  956 */     if (json.defaultMessageNotifications != null) {
/*  957 */       builder.defaultMessageNotifications(json.defaultMessageNotifications);
/*      */     }
/*  959 */     if (json.explicitContentFilter != null) {
/*  960 */       builder.explicitContentFilter(json.explicitContentFilter);
/*      */     }
/*  962 */     if (json.roles != null) {
/*  963 */       builder.roles(json.roles);
/*      */     }
/*  965 */     if (json.channels != null) {
/*  966 */       builder.channels(json.channels);
/*      */     }
/*  968 */     if (json.afkChannelId != null) {
/*  969 */       builder.afkChannelId(json.afkChannelId);
/*      */     }
/*  971 */     if (json.afkTimeout != null) {
/*  972 */       builder.afkTimeout(json.afkTimeout);
/*      */     }
/*  974 */     if (json.systemChannelId != null) {
/*  975 */       builder.systemChannelId(json.systemChannelId);
/*      */     }
/*  977 */     if (json.systemChannelFlags != null) {
/*  978 */       builder.systemChannelFlags(json.systemChannelFlags);
/*      */     }
/*  980 */     return builder.build();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableGuildCreateRequest of(String name, Possible<String> region, Possible<String> icon, Possible<Integer> verificationLevel, Possible<Integer> defaultMessageNotifications, Possible<Integer> explicitContentFilter, Possible<List<RoleCreateRequest>> roles, Possible<List<PartialChannelCreateRequest>> channels, Possible<Id> afkChannelId, Possible<Integer> afkTimeout, Possible<Id> systemChannelId, Possible<Integer> systemChannelFlags) {
/* 1000 */     return new ImmutableGuildCreateRequest(name, region, icon, verificationLevel, defaultMessageNotifications, explicitContentFilter, roles, channels, afkChannelId, afkTimeout, systemChannelId, systemChannelFlags);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableGuildCreateRequest copyOf(GuildCreateRequest instance) {
/* 1011 */     if (instance instanceof ImmutableGuildCreateRequest) {
/* 1012 */       return (ImmutableGuildCreateRequest)instance;
/*      */     }
/* 1014 */     return builder()
/* 1015 */       .from(instance)
/* 1016 */       .build();
/*      */   }
/*      */   
/*      */   public boolean isRegionPresent() {
/* 1020 */     return !this.region_absent;
/*      */   }
/*      */   
/*      */   public String regionOrElse(String defaultValue) {
/* 1024 */     return !this.region_absent ? this.region_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isIconPresent() {
/* 1028 */     return !this.icon_absent;
/*      */   }
/*      */   
/*      */   public String iconOrElse(String defaultValue) {
/* 1032 */     return !this.icon_absent ? this.icon_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isVerificationLevelPresent() {
/* 1036 */     return !this.verificationLevel_absent;
/*      */   }
/*      */   
/*      */   public Integer verificationLevelOrElse(Integer defaultValue) {
/* 1040 */     return !this.verificationLevel_absent ? this.verificationLevel_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isDefaultMessageNotificationsPresent() {
/* 1044 */     return !this.defaultMessageNotifications_absent;
/*      */   }
/*      */   
/*      */   public Integer defaultMessageNotificationsOrElse(Integer defaultValue) {
/* 1048 */     return !this.defaultMessageNotifications_absent ? this.defaultMessageNotifications_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isExplicitContentFilterPresent() {
/* 1052 */     return !this.explicitContentFilter_absent;
/*      */   }
/*      */   
/*      */   public Integer explicitContentFilterOrElse(Integer defaultValue) {
/* 1056 */     return !this.explicitContentFilter_absent ? this.explicitContentFilter_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isRolesPresent() {
/* 1060 */     return !this.roles_absent;
/*      */   }
/*      */   
/*      */   public List<RoleCreateRequest> rolesOrElse(List<RoleCreateRequest> defaultValue) {
/* 1064 */     return !this.roles_absent ? this.roles_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isChannelsPresent() {
/* 1068 */     return !this.channels_absent;
/*      */   }
/*      */   
/*      */   public List<PartialChannelCreateRequest> channelsOrElse(List<PartialChannelCreateRequest> defaultValue) {
/* 1072 */     return !this.channels_absent ? this.channels_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isAfkChannelIdPresent() {
/* 1076 */     return !this.afkChannelId_absent;
/*      */   }
/*      */   
/*      */   public long afkChannelIdOrElse(long defaultValue) {
/* 1080 */     return !this.afkChannelId_absent ? this.afkChannelId_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isAfkTimeoutPresent() {
/* 1084 */     return !this.afkTimeout_absent;
/*      */   }
/*      */   
/*      */   public Integer afkTimeoutOrElse(Integer defaultValue) {
/* 1088 */     return !this.afkTimeout_absent ? this.afkTimeout_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isSystemChannelIdPresent() {
/* 1092 */     return !this.systemChannelId_absent;
/*      */   }
/*      */   
/*      */   public long systemChannelIdOrElse(long defaultValue) {
/* 1096 */     return !this.systemChannelId_absent ? this.systemChannelId_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isSystemChannelFlagsPresent() {
/* 1100 */     return !this.systemChannelFlags_absent;
/*      */   }
/*      */   
/*      */   public Integer systemChannelFlagsOrElse(Integer defaultValue) {
/* 1104 */     return !this.systemChannelFlags_absent ? this.systemChannelFlags_value : defaultValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Builder builder() {
/* 1128 */     return new Builder();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Generated(from = "GuildCreateRequest", generator = "Immutables")
/*      */   public static final class Builder
/*      */   {
/*      */     private static final long INIT_BIT_NAME = 1L;
/*      */ 
/*      */ 
/*      */     
/* 1141 */     private long initBits = 1L;
/*      */     
/* 1143 */     private Possible<String> region_possible = Possible.absent();
/* 1144 */     private Possible<String> icon_possible = Possible.absent();
/* 1145 */     private Possible<Integer> verificationLevel_possible = Possible.absent();
/* 1146 */     private Possible<Integer> defaultMessageNotifications_possible = Possible.absent();
/* 1147 */     private Possible<Integer> explicitContentFilter_possible = Possible.absent();
/* 1148 */     private List<RoleCreateRequest> roles_list = null;
/* 1149 */     private List<PartialChannelCreateRequest> channels_list = null;
/* 1150 */     private Possible<Id> afkChannelId_possible = Possible.absent();
/* 1151 */     private Possible<Integer> afkTimeout_possible = Possible.absent();
/* 1152 */     private Possible<Id> systemChannelId_possible = Possible.absent();
/* 1153 */     private Possible<Integer> systemChannelFlags_possible = Possible.absent();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private String name;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder from(GuildCreateRequest instance) {
/* 1167 */       Objects.requireNonNull(instance, "instance");
/* 1168 */       name(instance.name());
/* 1169 */       region(instance.region());
/* 1170 */       icon(instance.icon());
/* 1171 */       verificationLevel(instance.verificationLevel());
/* 1172 */       defaultMessageNotifications(instance.defaultMessageNotifications());
/* 1173 */       explicitContentFilter(instance.explicitContentFilter());
/* 1174 */       roles(instance.roles());
/* 1175 */       channels(instance.channels());
/* 1176 */       afkChannelId(instance.afkChannelId());
/* 1177 */       afkTimeout(instance.afkTimeout());
/* 1178 */       systemChannelId(instance.systemChannelId());
/* 1179 */       systemChannelFlags(instance.systemChannelFlags());
/* 1180 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("name")
/*      */     public final Builder name(String name) {
/* 1190 */       this.name = Objects.<String>requireNonNull(name, "name");
/* 1191 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 1192 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("region")
/*      */     public Builder region(Possible<String> value) {
/* 1197 */       this.region_possible = value;
/* 1198 */       return this;
/*      */     }
/*      */     
/*      */     public Builder region(String value) {
/* 1202 */       this.region_possible = Possible.of(value);
/* 1203 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("icon")
/*      */     public Builder icon(Possible<String> value) {
/* 1208 */       this.icon_possible = value;
/* 1209 */       return this;
/*      */     }
/*      */     
/*      */     public Builder icon(String value) {
/* 1213 */       this.icon_possible = Possible.of(value);
/* 1214 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("verification_level")
/*      */     public Builder verificationLevel(Possible<Integer> value) {
/* 1219 */       this.verificationLevel_possible = value;
/* 1220 */       return this;
/*      */     }
/*      */     
/*      */     public Builder verificationLevel(Integer value) {
/* 1224 */       this.verificationLevel_possible = Possible.of(value);
/* 1225 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("default_message_notifications")
/*      */     public Builder defaultMessageNotifications(Possible<Integer> value) {
/* 1230 */       this.defaultMessageNotifications_possible = value;
/* 1231 */       return this;
/*      */     }
/*      */     
/*      */     public Builder defaultMessageNotifications(Integer value) {
/* 1235 */       this.defaultMessageNotifications_possible = Possible.of(value);
/* 1236 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("explicit_content_filter")
/*      */     public Builder explicitContentFilter(Possible<Integer> value) {
/* 1241 */       this.explicitContentFilter_possible = value;
/* 1242 */       return this;
/*      */     }
/*      */     
/*      */     public Builder explicitContentFilter(Integer value) {
/* 1246 */       this.explicitContentFilter_possible = Possible.of(value);
/* 1247 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addRole(RoleCreateRequest element) {
/* 1251 */       roles_getOrCreate().add(element);
/* 1252 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addAllRoles(List<RoleCreateRequest> elements) {
/* 1256 */       roles_getOrCreate().addAll(elements);
/* 1257 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("roles")
/*      */     public Builder roles(Possible<List<RoleCreateRequest>> elements) {
/* 1262 */       this.roles_list = null;
/* 1263 */       elements.toOptional().ifPresent(e -> roles_getOrCreate().addAll(e));
/* 1264 */       return this;
/*      */     }
/*      */     
/*      */     public Builder roles(List<RoleCreateRequest> elements) {
/* 1268 */       this.roles_list = new ArrayList<>(elements);
/* 1269 */       return this;
/*      */     }
/*      */     
/*      */     public Builder roles(Iterable<RoleCreateRequest> elements) {
/* 1273 */       this.roles_list = (List<RoleCreateRequest>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/* 1274 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addChannel(PartialChannelCreateRequest element) {
/* 1278 */       channels_getOrCreate().add(element);
/* 1279 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addAllChannels(List<PartialChannelCreateRequest> elements) {
/* 1283 */       channels_getOrCreate().addAll(elements);
/* 1284 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("channels")
/*      */     public Builder channels(Possible<List<PartialChannelCreateRequest>> elements) {
/* 1289 */       this.channels_list = null;
/* 1290 */       elements.toOptional().ifPresent(e -> channels_getOrCreate().addAll(e));
/* 1291 */       return this;
/*      */     }
/*      */     
/*      */     public Builder channels(List<PartialChannelCreateRequest> elements) {
/* 1295 */       this.channels_list = new ArrayList<>(elements);
/* 1296 */       return this;
/*      */     }
/*      */     
/*      */     public Builder channels(Iterable<PartialChannelCreateRequest> elements) {
/* 1300 */       this.channels_list = (List<PartialChannelCreateRequest>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/* 1301 */       return this;
/*      */     }
/*      */     
/*      */     public Builder afkChannelId(String value) {
/* 1305 */       this.afkChannelId_possible = Possible.of(Id.of(value));
/* 1306 */       return this;
/*      */     }
/*      */     
/*      */     public Builder afkChannelId(long value) {
/* 1310 */       this.afkChannelId_possible = Possible.of(Id.of(value));
/* 1311 */       return this;
/*      */     }
/*      */     
/*      */     public Builder afkChannelId(Id value) {
/* 1315 */       this.afkChannelId_possible = Possible.of(value);
/* 1316 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("afk_channel_id")
/*      */     public Builder afkChannelId(Possible<Id> value) {
/* 1321 */       this.afkChannelId_possible = value;
/* 1322 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("afk_timeout")
/*      */     public Builder afkTimeout(Possible<Integer> value) {
/* 1327 */       this.afkTimeout_possible = value;
/* 1328 */       return this;
/*      */     }
/*      */     
/*      */     public Builder afkTimeout(Integer value) {
/* 1332 */       this.afkTimeout_possible = Possible.of(value);
/* 1333 */       return this;
/*      */     }
/*      */     
/*      */     public Builder systemChannelId(String value) {
/* 1337 */       this.systemChannelId_possible = Possible.of(Id.of(value));
/* 1338 */       return this;
/*      */     }
/*      */     
/*      */     public Builder systemChannelId(long value) {
/* 1342 */       this.systemChannelId_possible = Possible.of(Id.of(value));
/* 1343 */       return this;
/*      */     }
/*      */     
/*      */     public Builder systemChannelId(Id value) {
/* 1347 */       this.systemChannelId_possible = Possible.of(value);
/* 1348 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("system_channel_id")
/*      */     public Builder systemChannelId(Possible<Id> value) {
/* 1353 */       this.systemChannelId_possible = value;
/* 1354 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("system_channel_flags")
/*      */     public Builder systemChannelFlags(Possible<Integer> value) {
/* 1359 */       this.systemChannelFlags_possible = value;
/* 1360 */       return this;
/*      */     }
/*      */     
/*      */     public Builder systemChannelFlags(Integer value) {
/* 1364 */       this.systemChannelFlags_possible = Possible.of(value);
/* 1365 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ImmutableGuildCreateRequest build() {
/* 1374 */       if (this.initBits != 0L) {
/* 1375 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*      */       }
/* 1377 */       return new ImmutableGuildCreateRequest(null, this.name, 
/*      */ 
/*      */           
/* 1380 */           region_build(), 
/* 1381 */           icon_build(), 
/* 1382 */           verificationLevel_build(), 
/* 1383 */           defaultMessageNotifications_build(), 
/* 1384 */           explicitContentFilter_build(), 
/* 1385 */           roles_build(), 
/* 1386 */           channels_build(), 
/* 1387 */           afkChannelId_build(), 
/* 1388 */           afkTimeout_build(), 
/* 1389 */           systemChannelId_build(), 
/* 1390 */           systemChannelFlags_build());
/*      */     }
/*      */     
/*      */     private String formatRequiredAttributesMessage() {
/* 1394 */       List<String> attributes = new ArrayList<>();
/* 1395 */       if ((this.initBits & 0x1L) != 0L) attributes.add("name"); 
/* 1396 */       return "Cannot build GuildCreateRequest, some of required attributes are not set " + attributes;
/*      */     }
/*      */     
/*      */     private Possible<String> region_build() {
/* 1400 */       return this.region_possible;
/*      */     }
/*      */     
/*      */     private Possible<String> icon_build() {
/* 1404 */       return this.icon_possible;
/*      */     }
/*      */     
/*      */     private Possible<Integer> verificationLevel_build() {
/* 1408 */       return this.verificationLevel_possible;
/*      */     }
/*      */     
/*      */     private Possible<Integer> defaultMessageNotifications_build() {
/* 1412 */       return this.defaultMessageNotifications_possible;
/*      */     }
/*      */     
/*      */     private Possible<Integer> explicitContentFilter_build() {
/* 1416 */       return this.explicitContentFilter_possible;
/*      */     }
/*      */     
/*      */     private Possible<List<RoleCreateRequest>> roles_build() {
/* 1420 */       return (this.roles_list == null) ? Possible.absent() : 
/* 1421 */         Possible.of(this.roles_list);
/*      */     }
/*      */     
/*      */     private List<RoleCreateRequest> roles_getOrCreate() {
/* 1425 */       if (this.roles_list == null) {
/* 1426 */         this.roles_list = new ArrayList<>();
/*      */       }
/* 1428 */       return this.roles_list;
/*      */     }
/*      */     
/*      */     private Possible<List<PartialChannelCreateRequest>> channels_build() {
/* 1432 */       return (this.channels_list == null) ? Possible.absent() : 
/* 1433 */         Possible.of(this.channels_list);
/*      */     }
/*      */     
/*      */     private List<PartialChannelCreateRequest> channels_getOrCreate() {
/* 1437 */       if (this.channels_list == null) {
/* 1438 */         this.channels_list = new ArrayList<>();
/*      */       }
/* 1440 */       return this.channels_list;
/*      */     }
/*      */     
/*      */     private Possible<Id> afkChannelId_build() {
/* 1444 */       return this.afkChannelId_possible;
/*      */     }
/*      */     
/*      */     private Possible<Integer> afkTimeout_build() {
/* 1448 */       return this.afkTimeout_possible;
/*      */     }
/*      */     
/*      */     private Possible<Id> systemChannelId_build() {
/* 1452 */       return this.systemChannelId_possible;
/*      */     }
/*      */     
/*      */     private Possible<Integer> systemChannelFlags_build() {
/* 1456 */       return this.systemChannelFlags_possible;
/*      */     }
/*      */     
/*      */     private Builder() {}
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableGuildCreateRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */