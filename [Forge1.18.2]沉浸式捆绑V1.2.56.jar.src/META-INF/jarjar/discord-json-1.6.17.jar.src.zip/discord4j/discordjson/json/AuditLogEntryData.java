/*    */ package discord4j.discordjson.json;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonProperty;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import discord4j.discordjson.Id;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import java.util.List;
/*    */ import java.util.Optional;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ 
/*    */ @JsonSerialize(as = ImmutableAuditLogEntryData.class)
/*    */ @JsonDeserialize(as = ImmutableAuditLogEntryData.class)
/*    */ @Immutable
/*    */ public interface AuditLogEntryData
/*    */ {
/*    */   static ImmutableAuditLogEntryData.Builder builder() {
/* 19 */     return ImmutableAuditLogEntryData.builder();
/*    */   }
/*    */   
/*    */   @JsonProperty("target_id")
/*    */   Optional<String> targetId();
/*    */   
/*    */   Possible<List<AuditLogChangeData>> changes();
/*    */   
/*    */   @JsonProperty("user_id")
/*    */   Optional<Id> userId();
/*    */   
/*    */   Id id();
/*    */   
/*    */   @JsonProperty("action_type")
/*    */   int actionType();
/*    */   
/*    */   Possible<AuditEntryInfoData> options();
/*    */   
/*    */   Possible<String> reason();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\AuditLogEntryData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */