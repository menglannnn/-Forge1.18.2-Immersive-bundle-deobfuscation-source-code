/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import org.immutables.value.Generated;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "TemplateCreateRequest", generator = "Immutables")
/*     */ public final class ImmutableTemplateCreateRequest
/*     */   implements TemplateCreateRequest
/*     */ {
/*     */   private final String name;
/*     */   private final String description_value;
/*     */   private final boolean description_absent;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   private volatile transient InitShim initShim;
/*     */   
/*     */   private ImmutableTemplateCreateRequest(String name, Possible<Optional<String>> description) {
/*  55 */     this.initShim = new InitShim(); this.name = Objects.<String>requireNonNull(name, "name"); Possible<Optional<String>> description$impl = description; this.description_value = Possible.flatOpt(description$impl).orElse(null); this.description_absent = description$impl.isAbsent(); this.initShim = null; } private ImmutableTemplateCreateRequest(ImmutableTemplateCreateRequest original, String name, Possible<Optional<String>> description) { this.initShim = new InitShim();
/*     */     this.name = name;
/*     */     Possible<Optional<String>> description$impl = description;
/*     */     this.description_value = Possible.flatOpt(description$impl).orElse(null);
/*     */     this.description_absent = description$impl.isAbsent();
/*  60 */     this.initShim = null; } @Generated(from = "TemplateCreateRequest", generator = "Immutables") private final class InitShim { private InitShim() {} private String formatInitCycleMessage() { List<String> attributes = new ArrayList<>();
/*  61 */       return "Cannot build TemplateCreateRequest, attribute initializers form cycle " + attributes; }
/*     */      }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("name")
/*     */   public String name() {
/*  71 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("description")
/*     */   public Possible<Optional<String>> description() {
/*  80 */     return this.description_absent ? Possible.absent() : 
/*  81 */       Possible.of(Optional.ofNullable(this.description_value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableTemplateCreateRequest withName(String value) {
/*  91 */     String newValue = Objects.<String>requireNonNull(value, "name");
/*  92 */     if (this.name.equals(newValue)) return this; 
/*  93 */     return new ImmutableTemplateCreateRequest(this, newValue, description());
/*     */   }
/*     */   
/*     */   public ImmutableTemplateCreateRequest withDescription(Possible<Optional<String>> value) {
/*  97 */     Possible<Optional<String>> newValue = Objects.<Possible<Optional<String>>>requireNonNull(value);
/*  98 */     return new ImmutableTemplateCreateRequest(this, this.name, newValue);
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public ImmutableTemplateCreateRequest withDescription(@Nullable String value) {
/* 103 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/* 104 */     return new ImmutableTemplateCreateRequest(this, this.name, newValue);
/*     */   }
/*     */   
/*     */   public ImmutableTemplateCreateRequest withDescriptionOrNull(@Nullable String value) {
/* 108 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/* 109 */     return new ImmutableTemplateCreateRequest(this, this.name, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 118 */     if (this == another) return true; 
/* 119 */     return (another instanceof ImmutableTemplateCreateRequest && 
/* 120 */       equalTo(0, (ImmutableTemplateCreateRequest)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableTemplateCreateRequest another) {
/* 124 */     return (this.name.equals(another.name) && 
/* 125 */       description().equals(another.description()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 134 */     int h = 5381;
/* 135 */     h += (h << 5) + this.name.hashCode();
/* 136 */     h += (h << 5) + description().hashCode();
/* 137 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 146 */     return "TemplateCreateRequest{name=" + this.name + ", description=" + 
/*     */       
/* 148 */       description().toString() + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "TemplateCreateRequest", generator = "Immutables")
/*     */   static final class Json
/*     */     implements TemplateCreateRequest
/*     */   {
/*     */     String name;
/*     */ 
/*     */     
/* 163 */     Possible<Optional<String>> description = Possible.absent();
/*     */     
/*     */     @JsonProperty("name")
/*     */     public void setName(String name) {
/* 167 */       this.name = name;
/*     */     }
/*     */     @JsonProperty("description")
/*     */     public void setDescription(Possible<Optional<String>> description) {
/* 171 */       this.description = description;
/*     */     }
/*     */     public String name() {
/* 174 */       throw new UnsupportedOperationException();
/*     */     } public Possible<Optional<String>> description() {
/* 176 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableTemplateCreateRequest fromJson(Json json) {
/* 187 */     Builder builder = builder();
/* 188 */     if (json.name != null) {
/* 189 */       builder.name(json.name);
/*     */     }
/* 191 */     if (json.description != null) {
/* 192 */       builder.description(json.description);
/*     */     }
/* 194 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableTemplateCreateRequest of(String name, Possible<Optional<String>> description) {
/* 204 */     return new ImmutableTemplateCreateRequest(name, description);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableTemplateCreateRequest copyOf(TemplateCreateRequest instance) {
/* 215 */     if (instance instanceof ImmutableTemplateCreateRequest) {
/* 216 */       return (ImmutableTemplateCreateRequest)instance;
/*     */     }
/* 218 */     return builder()
/* 219 */       .from(instance)
/* 220 */       .build();
/*     */   }
/*     */   
/*     */   public boolean isDescriptionPresent() {
/* 224 */     return !this.description_absent;
/*     */   }
/*     */   
/*     */   public String descriptionOrElse(String defaultValue) {
/* 228 */     return !this.description_absent ? this.description_value : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 242 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "TemplateCreateRequest", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_NAME = 1L;
/*     */ 
/*     */ 
/*     */     
/* 255 */     private long initBits = 1L;
/*     */     
/* 257 */     private Possible<Optional<String>> description_possible = Possible.absent();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private String name;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(TemplateCreateRequest instance) {
/* 271 */       Objects.requireNonNull(instance, "instance");
/* 272 */       name(instance.name());
/* 273 */       description(instance.description());
/* 274 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("name")
/*     */     public final Builder name(String name) {
/* 284 */       this.name = Objects.<String>requireNonNull(name, "name");
/* 285 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 286 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("description")
/*     */     public Builder description(Possible<Optional<String>> value) {
/* 291 */       this.description_possible = value;
/* 292 */       return this;
/*     */     }
/*     */     
/*     */     @Deprecated
/*     */     public Builder description(@Nullable String value) {
/* 297 */       this.description_possible = Possible.of(Optional.ofNullable(value));
/* 298 */       return this;
/*     */     }
/*     */     
/*     */     public Builder descriptionOrNull(@Nullable String value) {
/* 302 */       this.description_possible = Possible.of(Optional.ofNullable(value));
/* 303 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableTemplateCreateRequest build() {
/* 312 */       if (this.initBits != 0L) {
/* 313 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 315 */       return new ImmutableTemplateCreateRequest(null, this.name, description_build());
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 319 */       List<String> attributes = new ArrayList<>();
/* 320 */       if ((this.initBits & 0x1L) != 0L) attributes.add("name"); 
/* 321 */       return "Cannot build TemplateCreateRequest, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Possible<Optional<String>> description_build() {
/* 325 */       return this.description_possible;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableTemplateCreateRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */