/*      */ package discord4j.discordjson.json;
/*      */ 
/*      */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*      */ import com.fasterxml.jackson.annotation.JsonCreator;
/*      */ import com.fasterxml.jackson.annotation.JsonProperty;
/*      */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*      */ import discord4j.discordjson.Id;
/*      */ import discord4j.discordjson.possible.Possible;
/*      */ import java.util.ArrayList;
/*      */ import java.util.List;
/*      */ import java.util.Objects;
/*      */ import java.util.Optional;
/*      */ import org.immutables.value.Generated;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ @Generated(from = "StickerData", generator = "Immutables")
/*      */ public final class ImmutableStickerData
/*      */   implements StickerData
/*      */ {
/*      */   private final long id_value;
/*      */   private final String name;
/*      */   private final int formatType;
/*      */   private final long packId_value;
/*      */   private final boolean packId_absent;
/*      */   private final String description;
/*      */   private final String tags_value;
/*      */   private final boolean tags_absent;
/*      */   private final String asset_value;
/*      */   private final boolean asset_absent;
/*      */   private final Boolean available_value;
/*      */   private final boolean available_absent;
/*      */   private final int type;
/*      */   private final long guildId_value;
/*      */   private final boolean guildId_absent;
/*      */   private final Integer sortValue_value;
/*      */   private final boolean sortValue_absent;
/*      */   private static final byte STAGE_INITIALIZING = -1;
/*      */   private static final byte STAGE_UNINITIALIZED = 0;
/*      */   private static final byte STAGE_INITIALIZED = 1;
/*      */   
/*      */   private ImmutableStickerData(Id id, String name, int formatType, Possible<Id> packId, Optional<String> description, Possible<String> tags, Possible<String> asset, Possible<Boolean> available, int type, Possible<Id> guildId, Possible<Integer> sortValue) {
/*   57 */     Id id$impl = id;
/*   58 */     this.name = Objects.<String>requireNonNull(name, "name");
/*   59 */     this.formatType = formatType;
/*   60 */     Possible<Id> packId$impl = packId;
/*   61 */     this.description = description.orElse(null);
/*   62 */     Possible<String> tags$impl = tags;
/*   63 */     Possible<String> asset$impl = asset;
/*   64 */     Possible<Boolean> available$impl = available;
/*   65 */     this.type = type;
/*   66 */     Possible<Id> guildId$impl = guildId;
/*   67 */     Possible<Integer> sortValue$impl = sortValue;
/*   68 */     this.id_value = id$impl.asLong();
/*   69 */     this
/*      */       
/*   71 */       .packId_value = ((Long)packId$impl.toOptional().map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*   72 */     this.packId_absent = packId$impl.isAbsent();
/*   73 */     this.tags_value = tags$impl.toOptional().orElse(null);
/*   74 */     this.tags_absent = tags$impl.isAbsent();
/*   75 */     this.asset_value = asset$impl.toOptional().orElse(null);
/*   76 */     this.asset_absent = asset$impl.isAbsent();
/*   77 */     this.available_value = available$impl.toOptional().orElse(null);
/*   78 */     this.available_absent = available$impl.isAbsent();
/*   79 */     this
/*      */       
/*   81 */       .guildId_value = ((Long)guildId$impl.toOptional().map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*   82 */     this.guildId_absent = guildId$impl.isAbsent();
/*   83 */     this.sortValue_value = sortValue$impl.toOptional().orElse(null);
/*   84 */     this.sortValue_absent = sortValue$impl.isAbsent();
/*   85 */     this.initShim = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ImmutableStickerData(ImmutableStickerData original, Id id, String name, int formatType, Possible<Id> packId, String description, Possible<String> tags, Possible<String> asset, Possible<Boolean> available, int type, Possible<Id> guildId, Possible<Integer> sortValue) {
/*  101 */     Id id$impl = id;
/*  102 */     this.name = name;
/*  103 */     this.formatType = formatType;
/*  104 */     Possible<Id> packId$impl = packId;
/*  105 */     this.description = description;
/*  106 */     Possible<String> tags$impl = tags;
/*  107 */     Possible<String> asset$impl = asset;
/*  108 */     Possible<Boolean> available$impl = available;
/*  109 */     this.type = type;
/*  110 */     Possible<Id> guildId$impl = guildId;
/*  111 */     Possible<Integer> sortValue$impl = sortValue;
/*  112 */     this.id_value = id$impl.asLong();
/*  113 */     this
/*      */       
/*  115 */       .packId_value = ((Long)packId$impl.toOptional().map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  116 */     this.packId_absent = packId$impl.isAbsent();
/*  117 */     this.tags_value = tags$impl.toOptional().orElse(null);
/*  118 */     this.tags_absent = tags$impl.isAbsent();
/*  119 */     this.asset_value = asset$impl.toOptional().orElse(null);
/*  120 */     this.asset_absent = asset$impl.isAbsent();
/*  121 */     this.available_value = available$impl.toOptional().orElse(null);
/*  122 */     this.available_absent = available$impl.isAbsent();
/*  123 */     this
/*      */       
/*  125 */       .guildId_value = ((Long)guildId$impl.toOptional().map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  126 */     this.guildId_absent = guildId$impl.isAbsent();
/*  127 */     this.sortValue_value = sortValue$impl.toOptional().orElse(null);
/*  128 */     this.sortValue_absent = sortValue$impl.isAbsent();
/*  129 */     this.initShim = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  135 */   private volatile transient InitShim initShim = new InitShim();
/*      */   
/*      */   @Generated(from = "StickerData", generator = "Immutables")
/*      */   private final class InitShim {
/*      */     private String formatInitCycleMessage() {
/*  140 */       List<String> attributes = new ArrayList<>();
/*  141 */       return "Cannot build StickerData, attribute initializers form cycle " + attributes;
/*      */     }
/*      */ 
/*      */     
/*      */     private InitShim() {}
/*      */   }
/*      */ 
/*      */   
/*      */   @JsonProperty("id")
/*      */   public Id id() {
/*  151 */     return Id.of(this.id_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("name")
/*      */   public String name() {
/*  160 */     return this.name;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("format_type")
/*      */   public int formatType() {
/*  169 */     return this.formatType;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("pack_id")
/*      */   public Possible<Id> packId() {
/*  178 */     return this.packId_absent ? Possible.absent() : 
/*  179 */       Possible.of(Id.of(this.packId_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("description")
/*      */   public Optional<String> description() {
/*  188 */     return Optional.ofNullable(this.description);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("tags")
/*      */   public Possible<String> tags() {
/*  197 */     return this.tags_absent ? Possible.absent() : Possible.of(this.tags_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("asset")
/*      */   @Deprecated
/*      */   public Possible<String> asset() {
/*  207 */     return this.asset_absent ? Possible.absent() : Possible.of(this.asset_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("available")
/*      */   public Possible<Boolean> available() {
/*  216 */     return this.available_absent ? Possible.absent() : Possible.of(this.available_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("type")
/*      */   public int type() {
/*  225 */     return this.type;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("guild_id")
/*      */   public Possible<Id> guildId() {
/*  234 */     return this.guildId_absent ? Possible.absent() : 
/*  235 */       Possible.of(Id.of(this.guildId_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("sort_value")
/*      */   public Possible<Integer> sortValue() {
/*  244 */     return this.sortValue_absent ? Possible.absent() : Possible.of(this.sortValue_value);
/*      */   }
/*      */   
/*      */   public ImmutableStickerData withId(long value) {
/*  248 */     Id newValue = Id.of(value);
/*  249 */     return new ImmutableStickerData(this, newValue, this.name, this.formatType, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  254 */         packId(), this.description, 
/*      */         
/*  256 */         tags(), 
/*  257 */         asset(), 
/*  258 */         available(), this.type, 
/*      */         
/*  260 */         guildId(), 
/*  261 */         sortValue());
/*      */   }
/*      */   
/*      */   public ImmutableStickerData withId(String value) {
/*  265 */     Id newValue = Id.of(value);
/*  266 */     return new ImmutableStickerData(this, newValue, this.name, this.formatType, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  271 */         packId(), this.description, 
/*      */         
/*  273 */         tags(), 
/*  274 */         asset(), 
/*  275 */         available(), this.type, 
/*      */         
/*  277 */         guildId(), 
/*  278 */         sortValue());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableStickerData withName(String value) {
/*  288 */     String newValue = Objects.<String>requireNonNull(value, "name");
/*  289 */     if (this.name.equals(newValue)) return this; 
/*  290 */     return new ImmutableStickerData(this, 
/*      */         
/*  292 */         id(), newValue, this.formatType, 
/*      */ 
/*      */         
/*  295 */         packId(), this.description, 
/*      */         
/*  297 */         tags(), 
/*  298 */         asset(), 
/*  299 */         available(), this.type, 
/*      */         
/*  301 */         guildId(), 
/*  302 */         sortValue());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableStickerData withFormatType(int value) {
/*  312 */     if (this.formatType == value) return this; 
/*  313 */     return new ImmutableStickerData(this, 
/*      */         
/*  315 */         id(), this.name, value, 
/*      */ 
/*      */         
/*  318 */         packId(), this.description, 
/*      */         
/*  320 */         tags(), 
/*  321 */         asset(), 
/*  322 */         available(), this.type, 
/*      */         
/*  324 */         guildId(), 
/*  325 */         sortValue());
/*      */   }
/*      */   
/*      */   public ImmutableStickerData withPackId(Possible<Id> value) {
/*  329 */     Possible<Id> newValue = Objects.<Possible<Id>>requireNonNull(value);
/*  330 */     return new ImmutableStickerData(this, 
/*      */         
/*  332 */         id(), this.name, this.formatType, newValue, this.description, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  337 */         tags(), 
/*  338 */         asset(), 
/*  339 */         available(), this.type, 
/*      */         
/*  341 */         guildId(), 
/*  342 */         sortValue());
/*      */   }
/*      */   
/*      */   public ImmutableStickerData withPackId(long value) {
/*  346 */     Possible<Id> newValue = Possible.of(Id.of(value));
/*  347 */     return new ImmutableStickerData(this, 
/*      */         
/*  349 */         id(), this.name, this.formatType, newValue, this.description, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  354 */         tags(), 
/*  355 */         asset(), 
/*  356 */         available(), this.type, 
/*      */         
/*  358 */         guildId(), 
/*  359 */         sortValue());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableStickerData withDescription(String value) {
/*  368 */     String newValue = Objects.<String>requireNonNull(value, "description");
/*  369 */     if (Objects.equals(this.description, newValue)) return this; 
/*  370 */     return new ImmutableStickerData(this, 
/*      */         
/*  372 */         id(), this.name, this.formatType, 
/*      */ 
/*      */         
/*  375 */         packId(), newValue, 
/*      */         
/*  377 */         tags(), 
/*  378 */         asset(), 
/*  379 */         available(), this.type, 
/*      */         
/*  381 */         guildId(), 
/*  382 */         sortValue());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableStickerData withDescription(Optional<String> optional) {
/*  392 */     String value = optional.orElse(null);
/*  393 */     if (Objects.equals(this.description, value)) return this; 
/*  394 */     return new ImmutableStickerData(this, 
/*      */         
/*  396 */         id(), this.name, this.formatType, 
/*      */ 
/*      */         
/*  399 */         packId(), value, 
/*      */         
/*  401 */         tags(), 
/*  402 */         asset(), 
/*  403 */         available(), this.type, 
/*      */         
/*  405 */         guildId(), 
/*  406 */         sortValue());
/*      */   }
/*      */   
/*      */   public ImmutableStickerData withTags(Possible<String> value) {
/*  410 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/*  411 */     return new ImmutableStickerData(this, 
/*      */         
/*  413 */         id(), this.name, this.formatType, 
/*      */ 
/*      */         
/*  416 */         packId(), this.description, newValue, 
/*      */ 
/*      */         
/*  419 */         asset(), 
/*  420 */         available(), this.type, 
/*      */         
/*  422 */         guildId(), 
/*  423 */         sortValue());
/*      */   }
/*      */   
/*      */   public ImmutableStickerData withTags(String value) {
/*  427 */     Possible<String> newValue = Possible.of(value);
/*  428 */     return new ImmutableStickerData(this, 
/*      */         
/*  430 */         id(), this.name, this.formatType, 
/*      */ 
/*      */         
/*  433 */         packId(), this.description, newValue, 
/*      */ 
/*      */         
/*  436 */         asset(), 
/*  437 */         available(), this.type, 
/*      */         
/*  439 */         guildId(), 
/*  440 */         sortValue());
/*      */   }
/*      */   
/*      */   public ImmutableStickerData withAsset(Possible<String> value) {
/*  444 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/*  445 */     return new ImmutableStickerData(this, 
/*      */         
/*  447 */         id(), this.name, this.formatType, 
/*      */ 
/*      */         
/*  450 */         packId(), this.description, 
/*      */         
/*  452 */         tags(), newValue, 
/*      */         
/*  454 */         available(), this.type, 
/*      */         
/*  456 */         guildId(), 
/*  457 */         sortValue());
/*      */   }
/*      */   
/*      */   public ImmutableStickerData withAsset(String value) {
/*  461 */     Possible<String> newValue = Possible.of(value);
/*  462 */     return new ImmutableStickerData(this, 
/*      */         
/*  464 */         id(), this.name, this.formatType, 
/*      */ 
/*      */         
/*  467 */         packId(), this.description, 
/*      */         
/*  469 */         tags(), newValue, 
/*      */         
/*  471 */         available(), this.type, 
/*      */         
/*  473 */         guildId(), 
/*  474 */         sortValue());
/*      */   }
/*      */   
/*      */   public ImmutableStickerData withAvailable(Possible<Boolean> value) {
/*  478 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/*  479 */     return new ImmutableStickerData(this, 
/*      */         
/*  481 */         id(), this.name, this.formatType, 
/*      */ 
/*      */         
/*  484 */         packId(), this.description, 
/*      */         
/*  486 */         tags(), 
/*  487 */         asset(), newValue, this.type, 
/*      */ 
/*      */         
/*  490 */         guildId(), 
/*  491 */         sortValue());
/*      */   }
/*      */   
/*      */   public ImmutableStickerData withAvailable(Boolean value) {
/*  495 */     Possible<Boolean> newValue = Possible.of(value);
/*  496 */     return new ImmutableStickerData(this, 
/*      */         
/*  498 */         id(), this.name, this.formatType, 
/*      */ 
/*      */         
/*  501 */         packId(), this.description, 
/*      */         
/*  503 */         tags(), 
/*  504 */         asset(), newValue, this.type, 
/*      */ 
/*      */         
/*  507 */         guildId(), 
/*  508 */         sortValue());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableStickerData withType(int value) {
/*  518 */     if (this.type == value) return this; 
/*  519 */     return new ImmutableStickerData(this, 
/*      */         
/*  521 */         id(), this.name, this.formatType, 
/*      */ 
/*      */         
/*  524 */         packId(), this.description, 
/*      */         
/*  526 */         tags(), 
/*  527 */         asset(), 
/*  528 */         available(), value, 
/*      */         
/*  530 */         guildId(), 
/*  531 */         sortValue());
/*      */   }
/*      */   
/*      */   public ImmutableStickerData withGuildId(Possible<Id> value) {
/*  535 */     Possible<Id> newValue = Objects.<Possible<Id>>requireNonNull(value);
/*  536 */     return new ImmutableStickerData(this, 
/*      */         
/*  538 */         id(), this.name, this.formatType, 
/*      */ 
/*      */         
/*  541 */         packId(), this.description, 
/*      */         
/*  543 */         tags(), 
/*  544 */         asset(), 
/*  545 */         available(), this.type, newValue, 
/*      */ 
/*      */         
/*  548 */         sortValue());
/*      */   }
/*      */   
/*      */   public ImmutableStickerData withGuildId(long value) {
/*  552 */     Possible<Id> newValue = Possible.of(Id.of(value));
/*  553 */     return new ImmutableStickerData(this, 
/*      */         
/*  555 */         id(), this.name, this.formatType, 
/*      */ 
/*      */         
/*  558 */         packId(), this.description, 
/*      */         
/*  560 */         tags(), 
/*  561 */         asset(), 
/*  562 */         available(), this.type, newValue, 
/*      */ 
/*      */         
/*  565 */         sortValue());
/*      */   }
/*      */   
/*      */   public ImmutableStickerData withSortValue(Possible<Integer> value) {
/*  569 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/*  570 */     return new ImmutableStickerData(this, 
/*      */         
/*  572 */         id(), this.name, this.formatType, 
/*      */ 
/*      */         
/*  575 */         packId(), this.description, 
/*      */         
/*  577 */         tags(), 
/*  578 */         asset(), 
/*  579 */         available(), this.type, 
/*      */         
/*  581 */         guildId(), newValue);
/*      */   }
/*      */ 
/*      */   
/*      */   public ImmutableStickerData withSortValue(Integer value) {
/*  586 */     Possible<Integer> newValue = Possible.of(value);
/*  587 */     return new ImmutableStickerData(this, 
/*      */         
/*  589 */         id(), this.name, this.formatType, 
/*      */ 
/*      */         
/*  592 */         packId(), this.description, 
/*      */         
/*  594 */         tags(), 
/*  595 */         asset(), 
/*  596 */         available(), this.type, 
/*      */         
/*  598 */         guildId(), newValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean equals(Object another) {
/*  608 */     if (this == another) return true; 
/*  609 */     return (another instanceof ImmutableStickerData && 
/*  610 */       equalTo(0, (ImmutableStickerData)another));
/*      */   }
/*      */   
/*      */   private boolean equalTo(int synthetic, ImmutableStickerData another) {
/*  614 */     return (Objects.equals(Long.valueOf(this.id_value), Long.valueOf(another.id_value)) && this.name
/*  615 */       .equals(another.name) && this.formatType == another.formatType && 
/*      */       
/*  617 */       packId().equals(another.packId()) && 
/*  618 */       Objects.equals(this.description, another.description) && 
/*  619 */       tags().equals(another.tags()) && 
/*  620 */       asset().equals(another.asset()) && 
/*  621 */       available().equals(another.available()) && this.type == another.type && 
/*      */       
/*  623 */       guildId().equals(another.guildId()) && 
/*  624 */       sortValue().equals(another.sortValue()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int hashCode() {
/*  633 */     int h = 5381;
/*  634 */     h += (h << 5) + Objects.hashCode(Long.valueOf(this.id_value));
/*  635 */     h += (h << 5) + this.name.hashCode();
/*  636 */     h += (h << 5) + this.formatType;
/*  637 */     h += (h << 5) + packId().hashCode();
/*  638 */     h += (h << 5) + Objects.hashCode(this.description);
/*  639 */     h += (h << 5) + tags().hashCode();
/*  640 */     h += (h << 5) + asset().hashCode();
/*  641 */     h += (h << 5) + available().hashCode();
/*  642 */     h += (h << 5) + this.type;
/*  643 */     h += (h << 5) + guildId().hashCode();
/*  644 */     h += (h << 5) + sortValue().hashCode();
/*  645 */     return h;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/*  654 */     StringBuilder builder = new StringBuilder("StickerData{");
/*  655 */     builder.append("id=").append(Objects.toString(Long.valueOf(this.id_value)));
/*  656 */     builder.append(", ");
/*  657 */     builder.append("name=").append(this.name);
/*  658 */     builder.append(", ");
/*  659 */     builder.append("formatType=").append(this.formatType);
/*  660 */     builder.append(", ");
/*  661 */     builder.append("packId=").append(packId().toString());
/*  662 */     if (this.description != null) {
/*  663 */       builder.append(", ");
/*  664 */       builder.append("description=").append(this.description);
/*      */     } 
/*  666 */     builder.append(", ");
/*  667 */     builder.append("tags=").append(tags().toString());
/*  668 */     builder.append(", ");
/*  669 */     builder.append("asset=").append(asset().toString());
/*  670 */     builder.append(", ");
/*  671 */     builder.append("available=").append(available().toString());
/*  672 */     builder.append(", ");
/*  673 */     builder.append("type=").append(this.type);
/*  674 */     builder.append(", ");
/*  675 */     builder.append("guildId=").append(guildId().toString());
/*  676 */     builder.append(", ");
/*  677 */     builder.append("sortValue=").append(sortValue().toString());
/*  678 */     return builder.append("}").toString();
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonDeserialize
/*      */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*      */   @Generated(from = "StickerData", generator = "Immutables")
/*      */   static final class Json
/*      */     implements StickerData
/*      */   {
/*      */     Id id;
/*      */     
/*      */     String name;
/*      */     
/*      */     int formatType;
/*      */     boolean formatTypeIsSet;
/*  695 */     Possible<Id> packId = Possible.absent();
/*      */     
/*  697 */     Optional<String> description = Optional.empty();
/*      */     
/*  699 */     Possible<String> tags = Possible.absent();
/*      */ 
/*      */     
/*  702 */     Possible<String> asset = Possible.absent();
/*      */ 
/*      */     
/*  705 */     Possible<Boolean> available = Possible.absent();
/*      */     
/*      */     int type;
/*      */     
/*      */     boolean typeIsSet;
/*  710 */     Possible<Id> guildId = Possible.absent();
/*      */ 
/*      */     
/*  713 */     Possible<Integer> sortValue = Possible.absent();
/*      */     
/*      */     @JsonProperty("id")
/*      */     public void setId(Id id) {
/*  717 */       this.id = id;
/*      */     }
/*      */     @JsonProperty("name")
/*      */     public void setName(String name) {
/*  721 */       this.name = name;
/*      */     }
/*      */     @JsonProperty("format_type")
/*      */     public void setFormatType(int formatType) {
/*  725 */       this.formatType = formatType;
/*  726 */       this.formatTypeIsSet = true;
/*      */     }
/*      */     @JsonProperty("pack_id")
/*      */     public void setPackId(Possible<Id> packId) {
/*  730 */       this.packId = packId;
/*      */     }
/*      */     @JsonProperty("description")
/*      */     public void setDescription(Optional<String> description) {
/*  734 */       this.description = description;
/*      */     }
/*      */     @JsonProperty("tags")
/*      */     public void setTags(Possible<String> tags) {
/*  738 */       this.tags = tags;
/*      */     }
/*      */     @JsonProperty("asset")
/*      */     public void setAsset(Possible<String> asset) {
/*  742 */       this.asset = asset;
/*      */     }
/*      */     @JsonProperty("available")
/*      */     public void setAvailable(Possible<Boolean> available) {
/*  746 */       this.available = available;
/*      */     }
/*      */     @JsonProperty("type")
/*      */     public void setType(int type) {
/*  750 */       this.type = type;
/*  751 */       this.typeIsSet = true;
/*      */     }
/*      */     @JsonProperty("guild_id")
/*      */     public void setGuildId(Possible<Id> guildId) {
/*  755 */       this.guildId = guildId;
/*      */     }
/*      */     @JsonProperty("sort_value")
/*      */     public void setSortValue(Possible<Integer> sortValue) {
/*  759 */       this.sortValue = sortValue;
/*      */     }
/*      */     public Id id() {
/*  762 */       throw new UnsupportedOperationException();
/*      */     } public String name() {
/*  764 */       throw new UnsupportedOperationException();
/*      */     } public int formatType() {
/*  766 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Id> packId() {
/*  768 */       throw new UnsupportedOperationException();
/*      */     } public Optional<String> description() {
/*  770 */       throw new UnsupportedOperationException();
/*      */     } public Possible<String> tags() {
/*  772 */       throw new UnsupportedOperationException();
/*      */     } public Possible<String> asset() {
/*  774 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Boolean> available() {
/*  776 */       throw new UnsupportedOperationException();
/*      */     } public int type() {
/*  778 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Id> guildId() {
/*  780 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Integer> sortValue() {
/*  782 */       throw new UnsupportedOperationException();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*      */   static ImmutableStickerData fromJson(Json json) {
/*  793 */     Builder builder = builder();
/*  794 */     if (json.id != null) {
/*  795 */       builder.id(json.id);
/*      */     }
/*  797 */     if (json.name != null) {
/*  798 */       builder.name(json.name);
/*      */     }
/*  800 */     if (json.formatTypeIsSet) {
/*  801 */       builder.formatType(json.formatType);
/*      */     }
/*  803 */     if (json.packId != null) {
/*  804 */       builder.packId(json.packId);
/*      */     }
/*  806 */     if (json.description != null) {
/*  807 */       builder.description(json.description);
/*      */     }
/*  809 */     if (json.tags != null) {
/*  810 */       builder.tags(json.tags);
/*      */     }
/*  812 */     if (json.asset != null) {
/*  813 */       builder.asset(json.asset);
/*      */     }
/*  815 */     if (json.available != null) {
/*  816 */       builder.available(json.available);
/*      */     }
/*  818 */     if (json.typeIsSet) {
/*  819 */       builder.type(json.type);
/*      */     }
/*  821 */     if (json.guildId != null) {
/*  822 */       builder.guildId(json.guildId);
/*      */     }
/*  824 */     if (json.sortValue != null) {
/*  825 */       builder.sortValue(json.sortValue);
/*      */     }
/*  827 */     return builder.build();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableStickerData of(Id id, String name, int formatType, Possible<Id> packId, Optional<String> description, Possible<String> tags, Possible<String> asset, Possible<Boolean> available, int type, Possible<Id> guildId, Possible<Integer> sortValue) {
/*  846 */     return new ImmutableStickerData(id, name, formatType, packId, description, tags, asset, available, type, guildId, sortValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableStickerData copyOf(StickerData instance) {
/*  857 */     if (instance instanceof ImmutableStickerData) {
/*  858 */       return (ImmutableStickerData)instance;
/*      */     }
/*  860 */     return builder()
/*  861 */       .from(instance)
/*  862 */       .build();
/*      */   }
/*      */   
/*      */   public boolean isPackIdPresent() {
/*  866 */     return !this.packId_absent;
/*      */   }
/*      */   
/*      */   public long packIdOrElse(long defaultValue) {
/*  870 */     return !this.packId_absent ? this.packId_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isTagsPresent() {
/*  874 */     return !this.tags_absent;
/*      */   }
/*      */   
/*      */   public String tagsOrElse(String defaultValue) {
/*  878 */     return !this.tags_absent ? this.tags_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isAssetPresent() {
/*  882 */     return !this.asset_absent;
/*      */   }
/*      */   
/*      */   public String assetOrElse(String defaultValue) {
/*  886 */     return !this.asset_absent ? this.asset_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isAvailablePresent() {
/*  890 */     return !this.available_absent;
/*      */   }
/*      */   
/*      */   public Boolean availableOrElse(Boolean defaultValue) {
/*  894 */     return !this.available_absent ? this.available_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isGuildIdPresent() {
/*  898 */     return !this.guildId_absent;
/*      */   }
/*      */   
/*      */   public long guildIdOrElse(long defaultValue) {
/*  902 */     return !this.guildId_absent ? this.guildId_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isSortValuePresent() {
/*  906 */     return !this.sortValue_absent;
/*      */   }
/*      */   
/*      */   public Integer sortValueOrElse(Integer defaultValue) {
/*  910 */     return !this.sortValue_absent ? this.sortValue_value : defaultValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Builder builder() {
/*  933 */     return new Builder();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   @Generated(from = "StickerData", generator = "Immutables")
/*      */   public static final class Builder
/*      */   {
/*      */     private static final long INIT_BIT_NAME = 1L;
/*      */ 
/*      */     
/*      */     private static final long INIT_BIT_FORMAT_TYPE = 2L;
/*      */     
/*      */     private static final long INIT_BIT_TYPE = 4L;
/*      */     
/*  948 */     private long initBits = 7L;
/*      */     
/*  950 */     private Id id_id = null;
/*  951 */     private Possible<Id> packId_possible = Possible.absent();
/*  952 */     private Possible<String> tags_possible = Possible.absent();
/*  953 */     private Possible<String> asset_possible = Possible.absent();
/*  954 */     private Possible<Boolean> available_possible = Possible.absent();
/*  955 */     private Possible<Id> guildId_possible = Possible.absent();
/*  956 */     private Possible<Integer> sortValue_possible = Possible.absent();
/*      */ 
/*      */     
/*      */     private String name;
/*      */ 
/*      */     
/*      */     private int formatType;
/*      */ 
/*      */     
/*      */     private String description;
/*      */     
/*      */     private int type;
/*      */ 
/*      */     
/*      */     public final Builder from(PartialStickerData instance) {
/*  971 */       Objects.requireNonNull(instance, "instance");
/*  972 */       from(instance);
/*  973 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder from(StickerData instance) {
/*  982 */       Objects.requireNonNull(instance, "instance");
/*  983 */       from(instance);
/*  984 */       return this;
/*      */     }
/*      */     
/*      */     private void from(Object object) {
/*  988 */       long bits = 0L;
/*  989 */       if (object instanceof PartialStickerData) {
/*  990 */         PartialStickerData instance = (PartialStickerData)object;
/*  991 */         if ((bits & 0x1L) == 0L) {
/*  992 */           name(instance.name());
/*  993 */           bits |= 0x1L;
/*      */         } 
/*  995 */         if ((bits & 0x4L) == 0L) {
/*  996 */           formatType(instance.formatType());
/*  997 */           bits |= 0x4L;
/*      */         } 
/*  999 */         if ((bits & 0x2L) == 0L) {
/* 1000 */           id(instance.id());
/* 1001 */           bits |= 0x2L;
/*      */         } 
/*      */       } 
/* 1004 */       if (object instanceof StickerData) {
/* 1005 */         StickerData instance = (StickerData)object;
/* 1006 */         packId(instance.packId());
/* 1007 */         sortValue(instance.sortValue());
/* 1008 */         if ((bits & 0x1L) == 0L) {
/* 1009 */           name(instance.name());
/* 1010 */           bits |= 0x1L;
/*      */         } 
/* 1012 */         available(instance.available());
/* 1013 */         Optional<String> descriptionOptional = instance.description();
/* 1014 */         if (descriptionOptional.isPresent()) {
/* 1015 */           description(descriptionOptional);
/*      */         }
/* 1017 */         if ((bits & 0x2L) == 0L) {
/* 1018 */           id(instance.id());
/* 1019 */           bits |= 0x2L;
/*      */         } 
/* 1021 */         if ((bits & 0x4L) == 0L) {
/* 1022 */           formatType(instance.formatType());
/* 1023 */           bits |= 0x4L;
/*      */         } 
/* 1025 */         asset(instance.asset());
/* 1026 */         type(instance.type());
/* 1027 */         guildId(instance.guildId());
/* 1028 */         tags(instance.tags());
/*      */       } 
/*      */     }
/*      */     
/*      */     public Builder id(String value) {
/* 1033 */       this.id_id = Id.of(value);
/* 1034 */       return this;
/*      */     }
/*      */     
/*      */     public Builder id(long value) {
/* 1038 */       this.id_id = Id.of(value);
/* 1039 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("id")
/*      */     public Builder id(Id value) {
/* 1044 */       this.id_id = value;
/* 1045 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("name")
/*      */     public final Builder name(String name) {
/* 1055 */       this.name = Objects.<String>requireNonNull(name, "name");
/* 1056 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 1057 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("format_type")
/*      */     public final Builder formatType(int formatType) {
/* 1067 */       this.formatType = formatType;
/* 1068 */       this.initBits &= 0xFFFFFFFFFFFFFFFDL;
/* 1069 */       return this;
/*      */     }
/*      */     
/*      */     public Builder packId(String value) {
/* 1073 */       this.packId_possible = Possible.of(Id.of(value));
/* 1074 */       return this;
/*      */     }
/*      */     
/*      */     public Builder packId(long value) {
/* 1078 */       this.packId_possible = Possible.of(Id.of(value));
/* 1079 */       return this;
/*      */     }
/*      */     
/*      */     public Builder packId(Id value) {
/* 1083 */       this.packId_possible = Possible.of(value);
/* 1084 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("pack_id")
/*      */     public Builder packId(Possible<Id> value) {
/* 1089 */       this.packId_possible = value;
/* 1090 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder description(String description) {
/* 1099 */       this.description = Objects.<String>requireNonNull(description, "description");
/* 1100 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("description")
/*      */     public final Builder description(Optional<String> description) {
/* 1110 */       this.description = description.orElse(null);
/* 1111 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("tags")
/*      */     public Builder tags(Possible<String> value) {
/* 1116 */       this.tags_possible = value;
/* 1117 */       return this;
/*      */     }
/*      */     
/*      */     public Builder tags(String value) {
/* 1121 */       this.tags_possible = Possible.of(value);
/* 1122 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("asset")
/*      */     public Builder asset(Possible<String> value) {
/* 1127 */       this.asset_possible = value;
/* 1128 */       return this;
/*      */     }
/*      */     
/*      */     public Builder asset(String value) {
/* 1132 */       this.asset_possible = Possible.of(value);
/* 1133 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("available")
/*      */     public Builder available(Possible<Boolean> value) {
/* 1138 */       this.available_possible = value;
/* 1139 */       return this;
/*      */     }
/*      */     
/*      */     public Builder available(Boolean value) {
/* 1143 */       this.available_possible = Possible.of(value);
/* 1144 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("type")
/*      */     public final Builder type(int type) {
/* 1154 */       this.type = type;
/* 1155 */       this.initBits &= 0xFFFFFFFFFFFFFFFBL;
/* 1156 */       return this;
/*      */     }
/*      */     
/*      */     public Builder guildId(String value) {
/* 1160 */       this.guildId_possible = Possible.of(Id.of(value));
/* 1161 */       return this;
/*      */     }
/*      */     
/*      */     public Builder guildId(long value) {
/* 1165 */       this.guildId_possible = Possible.of(Id.of(value));
/* 1166 */       return this;
/*      */     }
/*      */     
/*      */     public Builder guildId(Id value) {
/* 1170 */       this.guildId_possible = Possible.of(value);
/* 1171 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("guild_id")
/*      */     public Builder guildId(Possible<Id> value) {
/* 1176 */       this.guildId_possible = value;
/* 1177 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("sort_value")
/*      */     public Builder sortValue(Possible<Integer> value) {
/* 1182 */       this.sortValue_possible = value;
/* 1183 */       return this;
/*      */     }
/*      */     
/*      */     public Builder sortValue(Integer value) {
/* 1187 */       this.sortValue_possible = Possible.of(value);
/* 1188 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ImmutableStickerData build() {
/* 1197 */       if (this.initBits != 0L) {
/* 1198 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*      */       }
/* 1200 */       return new ImmutableStickerData(null, 
/*      */           
/* 1202 */           id_build(), this.name, this.formatType, 
/*      */ 
/*      */           
/* 1205 */           packId_build(), this.description, 
/*      */           
/* 1207 */           tags_build(), 
/* 1208 */           asset_build(), 
/* 1209 */           available_build(), this.type, 
/*      */           
/* 1211 */           guildId_build(), 
/* 1212 */           sortValue_build());
/*      */     }
/*      */     
/*      */     private String formatRequiredAttributesMessage() {
/* 1216 */       List<String> attributes = new ArrayList<>();
/* 1217 */       if ((this.initBits & 0x1L) != 0L) attributes.add("name"); 
/* 1218 */       if ((this.initBits & 0x2L) != 0L) attributes.add("formatType"); 
/* 1219 */       if ((this.initBits & 0x4L) != 0L) attributes.add("type"); 
/* 1220 */       return "Cannot build StickerData, some of required attributes are not set " + attributes;
/*      */     }
/*      */     
/*      */     private Id id_build() {
/* 1224 */       return this.id_id;
/*      */     }
/*      */     
/*      */     private Possible<Id> packId_build() {
/* 1228 */       return this.packId_possible;
/*      */     }
/*      */     
/*      */     private Possible<String> tags_build() {
/* 1232 */       return this.tags_possible;
/*      */     }
/*      */     
/*      */     private Possible<String> asset_build() {
/* 1236 */       return this.asset_possible;
/*      */     }
/*      */     
/*      */     private Possible<Boolean> available_build() {
/* 1240 */       return this.available_possible;
/*      */     }
/*      */     
/*      */     private Possible<Id> guildId_build() {
/* 1244 */       return this.guildId_possible;
/*      */     }
/*      */     
/*      */     private Possible<Integer> sortValue_build() {
/* 1248 */       return this.sortValue_possible;
/*      */     }
/*      */     
/*      */     private Builder() {}
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableStickerData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */