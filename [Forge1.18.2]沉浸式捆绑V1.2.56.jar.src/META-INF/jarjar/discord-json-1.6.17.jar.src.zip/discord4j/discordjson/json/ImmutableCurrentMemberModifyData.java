/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "CurrentMemberModifyData", generator = "Immutables")
/*     */ public final class ImmutableCurrentMemberModifyData
/*     */   implements CurrentMemberModifyData
/*     */ {
/*     */   private final String nick;
/*     */   
/*     */   private ImmutableCurrentMemberModifyData(Optional<String> nick) {
/*  27 */     this.nick = nick.orElse(null);
/*     */   }
/*     */   
/*     */   private ImmutableCurrentMemberModifyData(ImmutableCurrentMemberModifyData original, String nick) {
/*  31 */     this.nick = nick;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("nick")
/*     */   public Optional<String> nick() {
/*  40 */     return Optional.ofNullable(this.nick);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableCurrentMemberModifyData withNick(String value) {
/*  49 */     String newValue = Objects.<String>requireNonNull(value, "nick");
/*  50 */     if (Objects.equals(this.nick, newValue)) return this; 
/*  51 */     return new ImmutableCurrentMemberModifyData(this, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableCurrentMemberModifyData withNick(Optional<String> optional) {
/*  61 */     String value = optional.orElse(null);
/*  62 */     if (Objects.equals(this.nick, value)) return this; 
/*  63 */     return new ImmutableCurrentMemberModifyData(this, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/*  72 */     if (this == another) return true; 
/*  73 */     return (another instanceof ImmutableCurrentMemberModifyData && 
/*  74 */       equalTo(0, (ImmutableCurrentMemberModifyData)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableCurrentMemberModifyData another) {
/*  78 */     return Objects.equals(this.nick, another.nick);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  87 */     int h = 5381;
/*  88 */     h += (h << 5) + Objects.hashCode(this.nick);
/*  89 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/*  98 */     StringBuilder builder = new StringBuilder("CurrentMemberModifyData{");
/*  99 */     if (this.nick != null) {
/* 100 */       builder.append("nick=").append(this.nick);
/*     */     }
/* 102 */     return builder.append("}").toString();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "CurrentMemberModifyData", generator = "Immutables")
/*     */   static final class Json
/*     */     implements CurrentMemberModifyData
/*     */   {
/* 114 */     Optional<String> nick = Optional.empty();
/*     */     @JsonProperty("nick")
/*     */     public void setNick(Optional<String> nick) {
/* 117 */       this.nick = nick;
/*     */     }
/*     */     public Optional<String> nick() {
/* 120 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableCurrentMemberModifyData fromJson(Json json) {
/* 131 */     Builder builder = builder();
/* 132 */     if (json.nick != null) {
/* 133 */       builder.nick(json.nick);
/*     */     }
/* 135 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableCurrentMemberModifyData of(Optional<String> nick) {
/* 144 */     return new ImmutableCurrentMemberModifyData(nick);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableCurrentMemberModifyData copyOf(CurrentMemberModifyData instance) {
/* 155 */     if (instance instanceof ImmutableCurrentMemberModifyData) {
/* 156 */       return (ImmutableCurrentMemberModifyData)instance;
/*     */     }
/* 158 */     return builder()
/* 159 */       .from(instance)
/* 160 */       .build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 173 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "CurrentMemberModifyData", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private String nick;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private Builder() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(CurrentMemberModifyData instance) {
/* 198 */       Objects.requireNonNull(instance, "instance");
/* 199 */       Optional<String> nickOptional = instance.nick();
/* 200 */       if (nickOptional.isPresent()) {
/* 201 */         nick(nickOptional);
/*     */       }
/* 203 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder nick(String nick) {
/* 212 */       this.nick = Objects.<String>requireNonNull(nick, "nick");
/* 213 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("nick")
/*     */     public final Builder nick(Optional<String> nick) {
/* 223 */       this.nick = nick.orElse(null);
/* 224 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableCurrentMemberModifyData build() {
/* 233 */       return new ImmutableCurrentMemberModifyData(null, this.nick);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableCurrentMemberModifyData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */