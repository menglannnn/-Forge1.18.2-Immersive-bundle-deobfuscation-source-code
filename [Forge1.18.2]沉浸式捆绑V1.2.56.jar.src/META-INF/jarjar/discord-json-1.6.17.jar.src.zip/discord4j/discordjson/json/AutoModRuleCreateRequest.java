/*    */ package discord4j.discordjson.json;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonProperty;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import discord4j.discordjson.Id;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import java.util.List;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ @JsonSerialize(as = ImmutableAutoModRuleCreateRequest.class)
/*    */ @JsonDeserialize(as = ImmutableAutoModRuleCreateRequest.class)
/*    */ @Immutable
/*    */ public interface AutoModRuleCreateRequest
/*    */ {
/*    */   static ImmutableAutoModRuleCreateRequest.Builder builder() {
/* 17 */     return ImmutableAutoModRuleCreateRequest.builder();
/*    */   }
/*    */   
/*    */   String name();
/*    */   
/*    */   @JsonProperty("event_type")
/*    */   int eventType();
/*    */   
/*    */   @JsonProperty("trigger_type")
/*    */   int triggerType();
/*    */   
/*    */   @JsonProperty("trigger_metadata")
/*    */   Possible<AutoModTriggerMetaData> triggerMetadata();
/*    */   
/*    */   List<AutoModActionData> actions();
/*    */   
/*    */   Possible<Boolean> enabled();
/*    */   
/*    */   @JsonProperty("exempt_roles")
/*    */   Possible<List<Id>> exemptRoles();
/*    */   
/*    */   @JsonProperty("exempt_channels")
/*    */   Possible<List<Id>> exemptChannels();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\AutoModRuleCreateRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */