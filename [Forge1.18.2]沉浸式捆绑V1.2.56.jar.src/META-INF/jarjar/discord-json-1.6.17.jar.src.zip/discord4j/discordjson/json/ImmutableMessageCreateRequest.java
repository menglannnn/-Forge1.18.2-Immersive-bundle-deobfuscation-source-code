/*      */ package discord4j.discordjson.json;
/*      */ 
/*      */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*      */ import com.fasterxml.jackson.annotation.JsonCreator;
/*      */ import com.fasterxml.jackson.annotation.JsonProperty;
/*      */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*      */ import discord4j.discordjson.possible.Possible;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.List;
/*      */ import java.util.Objects;
/*      */ import java.util.stream.Collectors;
/*      */ import java.util.stream.StreamSupport;
/*      */ import org.immutables.value.Generated;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ @Generated(from = "MessageCreateRequest", generator = "Immutables")
/*      */ public final class ImmutableMessageCreateRequest
/*      */   implements MessageCreateRequest
/*      */ {
/*      */   private final String content_value;
/*      */   private final boolean content_absent;
/*      */   private final Boolean tts_value;
/*      */   private final boolean tts_absent;
/*      */   private final AllowedMentionsData allowedMentions_value;
/*      */   private final boolean allowedMentions_absent;
/*      */   private final MessageReferenceData messageReference_value;
/*      */   private final boolean messageReference_absent;
/*      */   private final List<ComponentData> components_value;
/*      */   private final boolean components_absent;
/*      */   private final List<EmbedData> embeds_value;
/*      */   private final boolean embeds_absent;
/*      */   private final Object nonce_value;
/*      */   private final boolean nonce_absent;
/*      */   private final EmbedData embed_value;
/*      */   private final boolean embed_absent;
/*      */   private static final byte STAGE_INITIALIZING = -1;
/*      */   private static final byte STAGE_UNINITIALIZED = 0;
/*      */   private static final byte STAGE_INITIALIZED = 1;
/*      */   
/*      */   private ImmutableMessageCreateRequest(Possible<String> content, Possible<Boolean> tts, Possible<AllowedMentionsData> allowedMentions, Possible<MessageReferenceData> messageReference, Possible<List<ComponentData>> components, Possible<List<EmbedData>> embeds, Possible<Object> nonce, Possible<EmbedData> embed) {
/*   54 */     Possible<String> content$impl = content;
/*   55 */     Possible<Boolean> tts$impl = tts;
/*   56 */     Possible<AllowedMentionsData> allowedMentions$impl = allowedMentions;
/*   57 */     Possible<MessageReferenceData> messageReference$impl = messageReference;
/*   58 */     Possible<List<ComponentData>> components$impl = components;
/*   59 */     Possible<List<EmbedData>> embeds$impl = embeds;
/*   60 */     Possible<Object> nonce$impl = nonce;
/*   61 */     Possible<EmbedData> embed$impl = embed;
/*   62 */     this.content_value = content$impl.toOptional().orElse(null);
/*   63 */     this.content_absent = content$impl.isAbsent();
/*   64 */     this.tts_value = tts$impl.toOptional().orElse(null);
/*   65 */     this.tts_absent = tts$impl.isAbsent();
/*   66 */     this.allowedMentions_value = allowedMentions$impl.toOptional().orElse(null);
/*   67 */     this.allowedMentions_absent = allowedMentions$impl.isAbsent();
/*   68 */     this.messageReference_value = messageReference$impl.toOptional().orElse(null);
/*   69 */     this.messageReference_absent = messageReference$impl.isAbsent();
/*   70 */     this.components_value = components$impl.toOptional().orElse(null);
/*   71 */     this.components_absent = components$impl.isAbsent();
/*   72 */     this.embeds_value = embeds$impl.toOptional().orElse(null);
/*   73 */     this.embeds_absent = embeds$impl.isAbsent();
/*   74 */     this.nonce_value = nonce$impl.toOptional().orElse(null);
/*   75 */     this.nonce_absent = nonce$impl.isAbsent();
/*   76 */     this.embed_value = embed$impl.toOptional().orElse(null);
/*   77 */     this.embed_absent = embed$impl.isAbsent();
/*   78 */     this.initShim = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ImmutableMessageCreateRequest(ImmutableMessageCreateRequest original, Possible<String> content, Possible<Boolean> tts, Possible<AllowedMentionsData> allowedMentions, Possible<MessageReferenceData> messageReference, Possible<List<ComponentData>> components, Possible<List<EmbedData>> embeds, Possible<Object> nonce, Possible<EmbedData> embed) {
/*   91 */     Possible<String> content$impl = content;
/*   92 */     Possible<Boolean> tts$impl = tts;
/*   93 */     Possible<AllowedMentionsData> allowedMentions$impl = allowedMentions;
/*   94 */     Possible<MessageReferenceData> messageReference$impl = messageReference;
/*   95 */     Possible<List<ComponentData>> components$impl = components;
/*   96 */     Possible<List<EmbedData>> embeds$impl = embeds;
/*   97 */     Possible<Object> nonce$impl = nonce;
/*   98 */     Possible<EmbedData> embed$impl = embed;
/*   99 */     this.content_value = content$impl.toOptional().orElse(null);
/*  100 */     this.content_absent = content$impl.isAbsent();
/*  101 */     this.tts_value = tts$impl.toOptional().orElse(null);
/*  102 */     this.tts_absent = tts$impl.isAbsent();
/*  103 */     this.allowedMentions_value = allowedMentions$impl.toOptional().orElse(null);
/*  104 */     this.allowedMentions_absent = allowedMentions$impl.isAbsent();
/*  105 */     this.messageReference_value = messageReference$impl.toOptional().orElse(null);
/*  106 */     this.messageReference_absent = messageReference$impl.isAbsent();
/*  107 */     this.components_value = components$impl.toOptional().orElse(null);
/*  108 */     this.components_absent = components$impl.isAbsent();
/*  109 */     this.embeds_value = embeds$impl.toOptional().orElse(null);
/*  110 */     this.embeds_absent = embeds$impl.isAbsent();
/*  111 */     this.nonce_value = nonce$impl.toOptional().orElse(null);
/*  112 */     this.nonce_absent = nonce$impl.isAbsent();
/*  113 */     this.embed_value = embed$impl.toOptional().orElse(null);
/*  114 */     this.embed_absent = embed$impl.isAbsent();
/*  115 */     this.initShim = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  121 */   private volatile transient InitShim initShim = new InitShim();
/*      */   
/*      */   @Generated(from = "MessageCreateRequest", generator = "Immutables")
/*      */   private final class InitShim {
/*      */     private String formatInitCycleMessage() {
/*  126 */       List<String> attributes = new ArrayList<>();
/*  127 */       return "Cannot build MessageCreateRequest, attribute initializers form cycle " + attributes;
/*      */     }
/*      */ 
/*      */     
/*      */     private InitShim() {}
/*      */   }
/*      */ 
/*      */   
/*      */   @JsonProperty("content")
/*      */   public Possible<String> content() {
/*  137 */     return this.content_absent ? Possible.absent() : Possible.of(this.content_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("tts")
/*      */   public Possible<Boolean> tts() {
/*  146 */     return this.tts_absent ? Possible.absent() : Possible.of(this.tts_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("allowed_mentions")
/*      */   public Possible<AllowedMentionsData> allowedMentions() {
/*  155 */     return this.allowedMentions_absent ? Possible.absent() : Possible.of(this.allowedMentions_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("message_reference")
/*      */   public Possible<MessageReferenceData> messageReference() {
/*  164 */     return this.messageReference_absent ? Possible.absent() : Possible.of(this.messageReference_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("components")
/*      */   public Possible<List<ComponentData>> components() {
/*  173 */     return this.components_absent ? Possible.absent() : 
/*  174 */       Possible.of(this.components_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("embeds")
/*      */   public Possible<List<EmbedData>> embeds() {
/*  183 */     return this.embeds_absent ? Possible.absent() : 
/*  184 */       Possible.of(this.embeds_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("nonce")
/*      */   public Possible<Object> nonce() {
/*  193 */     return this.nonce_absent ? Possible.absent() : Possible.of(this.nonce_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("embed")
/*      */   @Deprecated
/*      */   public Possible<EmbedData> embed() {
/*  203 */     return this.embed_absent ? Possible.absent() : Possible.of(this.embed_value);
/*      */   }
/*      */   
/*      */   public ImmutableMessageCreateRequest withContent(Possible<String> value) {
/*  207 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/*  208 */     return new ImmutableMessageCreateRequest(this, newValue, 
/*      */ 
/*      */         
/*  211 */         tts(), 
/*  212 */         allowedMentions(), 
/*  213 */         messageReference(), 
/*  214 */         components(), 
/*  215 */         embeds(), 
/*  216 */         nonce(), 
/*  217 */         embed());
/*      */   }
/*      */   
/*      */   public ImmutableMessageCreateRequest withContent(String value) {
/*  221 */     Possible<String> newValue = Possible.of(value);
/*  222 */     return new ImmutableMessageCreateRequest(this, newValue, 
/*      */ 
/*      */         
/*  225 */         tts(), 
/*  226 */         allowedMentions(), 
/*  227 */         messageReference(), 
/*  228 */         components(), 
/*  229 */         embeds(), 
/*  230 */         nonce(), 
/*  231 */         embed());
/*      */   }
/*      */   
/*      */   public ImmutableMessageCreateRequest withTts(Possible<Boolean> value) {
/*  235 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/*  236 */     return new ImmutableMessageCreateRequest(this, 
/*      */         
/*  238 */         content(), newValue, 
/*      */         
/*  240 */         allowedMentions(), 
/*  241 */         messageReference(), 
/*  242 */         components(), 
/*  243 */         embeds(), 
/*  244 */         nonce(), 
/*  245 */         embed());
/*      */   }
/*      */   
/*      */   public ImmutableMessageCreateRequest withTts(Boolean value) {
/*  249 */     Possible<Boolean> newValue = Possible.of(value);
/*  250 */     return new ImmutableMessageCreateRequest(this, 
/*      */         
/*  252 */         content(), newValue, 
/*      */         
/*  254 */         allowedMentions(), 
/*  255 */         messageReference(), 
/*  256 */         components(), 
/*  257 */         embeds(), 
/*  258 */         nonce(), 
/*  259 */         embed());
/*      */   }
/*      */   
/*      */   public ImmutableMessageCreateRequest withAllowedMentions(Possible<AllowedMentionsData> value) {
/*  263 */     Possible<AllowedMentionsData> newValue = Objects.<Possible<AllowedMentionsData>>requireNonNull(value);
/*  264 */     return new ImmutableMessageCreateRequest(this, 
/*      */         
/*  266 */         content(), 
/*  267 */         tts(), newValue, 
/*      */         
/*  269 */         messageReference(), 
/*  270 */         components(), 
/*  271 */         embeds(), 
/*  272 */         nonce(), 
/*  273 */         embed());
/*      */   }
/*      */   
/*      */   public ImmutableMessageCreateRequest withAllowedMentions(AllowedMentionsData value) {
/*  277 */     Possible<AllowedMentionsData> newValue = Possible.of(value);
/*  278 */     return new ImmutableMessageCreateRequest(this, 
/*      */         
/*  280 */         content(), 
/*  281 */         tts(), newValue, 
/*      */         
/*  283 */         messageReference(), 
/*  284 */         components(), 
/*  285 */         embeds(), 
/*  286 */         nonce(), 
/*  287 */         embed());
/*      */   }
/*      */   
/*      */   public ImmutableMessageCreateRequest withMessageReference(Possible<MessageReferenceData> value) {
/*  291 */     Possible<MessageReferenceData> newValue = Objects.<Possible<MessageReferenceData>>requireNonNull(value);
/*  292 */     return new ImmutableMessageCreateRequest(this, 
/*      */         
/*  294 */         content(), 
/*  295 */         tts(), 
/*  296 */         allowedMentions(), newValue, 
/*      */         
/*  298 */         components(), 
/*  299 */         embeds(), 
/*  300 */         nonce(), 
/*  301 */         embed());
/*      */   }
/*      */   
/*      */   public ImmutableMessageCreateRequest withMessageReference(MessageReferenceData value) {
/*  305 */     Possible<MessageReferenceData> newValue = Possible.of(value);
/*  306 */     return new ImmutableMessageCreateRequest(this, 
/*      */         
/*  308 */         content(), 
/*  309 */         tts(), 
/*  310 */         allowedMentions(), newValue, 
/*      */         
/*  312 */         components(), 
/*  313 */         embeds(), 
/*  314 */         nonce(), 
/*  315 */         embed());
/*      */   }
/*      */   
/*      */   public ImmutableMessageCreateRequest withComponents(Possible<List<ComponentData>> possible) {
/*  319 */     Possible<List<ComponentData>> newValue = Objects.<Possible<List<ComponentData>>>requireNonNull(possible);
/*  320 */     return new ImmutableMessageCreateRequest(this, 
/*      */         
/*  322 */         content(), 
/*  323 */         tts(), 
/*  324 */         allowedMentions(), 
/*  325 */         messageReference(), newValue, 
/*      */         
/*  327 */         embeds(), 
/*  328 */         nonce(), 
/*  329 */         embed());
/*      */   }
/*      */   
/*      */   public ImmutableMessageCreateRequest withComponents(Iterable<ComponentData> elements) {
/*  333 */     Possible<List<ComponentData>> newValue = Possible.of(
/*  334 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/*  335 */     return new ImmutableMessageCreateRequest(this, 
/*      */         
/*  337 */         content(), 
/*  338 */         tts(), 
/*  339 */         allowedMentions(), 
/*  340 */         messageReference(), newValue, 
/*      */         
/*  342 */         embeds(), 
/*  343 */         nonce(), 
/*  344 */         embed());
/*      */   }
/*      */   
/*      */   @SafeVarargs
/*      */   public final ImmutableMessageCreateRequest withComponents(ComponentData... elements) {
/*  349 */     Possible<List<ComponentData>> newValue = Possible.of(Arrays.asList(elements));
/*  350 */     return new ImmutableMessageCreateRequest(this, 
/*      */         
/*  352 */         content(), 
/*  353 */         tts(), 
/*  354 */         allowedMentions(), 
/*  355 */         messageReference(), newValue, 
/*      */         
/*  357 */         embeds(), 
/*  358 */         nonce(), 
/*  359 */         embed());
/*      */   }
/*      */   
/*      */   public ImmutableMessageCreateRequest withEmbeds(Possible<List<EmbedData>> possible) {
/*  363 */     Possible<List<EmbedData>> newValue = Objects.<Possible<List<EmbedData>>>requireNonNull(possible);
/*  364 */     return new ImmutableMessageCreateRequest(this, 
/*      */         
/*  366 */         content(), 
/*  367 */         tts(), 
/*  368 */         allowedMentions(), 
/*  369 */         messageReference(), 
/*  370 */         components(), newValue, 
/*      */         
/*  372 */         nonce(), 
/*  373 */         embed());
/*      */   }
/*      */   
/*      */   public ImmutableMessageCreateRequest withEmbeds(Iterable<EmbedData> elements) {
/*  377 */     Possible<List<EmbedData>> newValue = Possible.of(
/*  378 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/*  379 */     return new ImmutableMessageCreateRequest(this, 
/*      */         
/*  381 */         content(), 
/*  382 */         tts(), 
/*  383 */         allowedMentions(), 
/*  384 */         messageReference(), 
/*  385 */         components(), newValue, 
/*      */         
/*  387 */         nonce(), 
/*  388 */         embed());
/*      */   }
/*      */   
/*      */   @SafeVarargs
/*      */   public final ImmutableMessageCreateRequest withEmbeds(EmbedData... elements) {
/*  393 */     Possible<List<EmbedData>> newValue = Possible.of(Arrays.asList(elements));
/*  394 */     return new ImmutableMessageCreateRequest(this, 
/*      */         
/*  396 */         content(), 
/*  397 */         tts(), 
/*  398 */         allowedMentions(), 
/*  399 */         messageReference(), 
/*  400 */         components(), newValue, 
/*      */         
/*  402 */         nonce(), 
/*  403 */         embed());
/*      */   }
/*      */   
/*      */   public ImmutableMessageCreateRequest withNonce(Possible<Object> value) {
/*  407 */     Possible<Object> newValue = Objects.<Possible<Object>>requireNonNull(value);
/*  408 */     return new ImmutableMessageCreateRequest(this, 
/*      */         
/*  410 */         content(), 
/*  411 */         tts(), 
/*  412 */         allowedMentions(), 
/*  413 */         messageReference(), 
/*  414 */         components(), 
/*  415 */         embeds(), newValue, 
/*      */         
/*  417 */         embed());
/*      */   }
/*      */   
/*      */   public ImmutableMessageCreateRequest withNonce(Object value) {
/*  421 */     Possible<Object> newValue = Possible.of(value);
/*  422 */     return new ImmutableMessageCreateRequest(this, 
/*      */         
/*  424 */         content(), 
/*  425 */         tts(), 
/*  426 */         allowedMentions(), 
/*  427 */         messageReference(), 
/*  428 */         components(), 
/*  429 */         embeds(), newValue, 
/*      */         
/*  431 */         embed());
/*      */   }
/*      */   
/*      */   public ImmutableMessageCreateRequest withEmbed(Possible<EmbedData> value) {
/*  435 */     Possible<EmbedData> newValue = Objects.<Possible<EmbedData>>requireNonNull(value);
/*  436 */     return new ImmutableMessageCreateRequest(this, 
/*      */         
/*  438 */         content(), 
/*  439 */         tts(), 
/*  440 */         allowedMentions(), 
/*  441 */         messageReference(), 
/*  442 */         components(), 
/*  443 */         embeds(), 
/*  444 */         nonce(), newValue);
/*      */   }
/*      */ 
/*      */   
/*      */   public ImmutableMessageCreateRequest withEmbed(EmbedData value) {
/*  449 */     Possible<EmbedData> newValue = Possible.of(value);
/*  450 */     return new ImmutableMessageCreateRequest(this, 
/*      */         
/*  452 */         content(), 
/*  453 */         tts(), 
/*  454 */         allowedMentions(), 
/*  455 */         messageReference(), 
/*  456 */         components(), 
/*  457 */         embeds(), 
/*  458 */         nonce(), newValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean equals(Object another) {
/*  468 */     if (this == another) return true; 
/*  469 */     return (another instanceof ImmutableMessageCreateRequest && 
/*  470 */       equalTo(0, (ImmutableMessageCreateRequest)another));
/*      */   }
/*      */   
/*      */   private boolean equalTo(int synthetic, ImmutableMessageCreateRequest another) {
/*  474 */     return (content().equals(another.content()) && 
/*  475 */       tts().equals(another.tts()) && 
/*  476 */       allowedMentions().equals(another.allowedMentions()) && 
/*  477 */       messageReference().equals(another.messageReference()) && 
/*  478 */       Objects.equals(this.components_value, another.components_value) && 
/*  479 */       Objects.equals(this.embeds_value, another.embeds_value) && 
/*  480 */       nonce().equals(another.nonce()) && 
/*  481 */       embed().equals(another.embed()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int hashCode() {
/*  490 */     int h = 5381;
/*  491 */     h += (h << 5) + content().hashCode();
/*  492 */     h += (h << 5) + tts().hashCode();
/*  493 */     h += (h << 5) + allowedMentions().hashCode();
/*  494 */     h += (h << 5) + messageReference().hashCode();
/*  495 */     h += (h << 5) + Objects.hashCode(this.components_value);
/*  496 */     h += (h << 5) + Objects.hashCode(this.embeds_value);
/*  497 */     h += (h << 5) + nonce().hashCode();
/*  498 */     h += (h << 5) + embed().hashCode();
/*  499 */     return h;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/*  508 */     return "MessageCreateRequest{content=" + 
/*  509 */       content().toString() + ", tts=" + 
/*  510 */       tts().toString() + ", allowedMentions=" + 
/*  511 */       allowedMentions().toString() + ", messageReference=" + 
/*  512 */       messageReference().toString() + ", components=" + 
/*  513 */       Objects.toString(this.components_value) + ", embeds=" + 
/*  514 */       Objects.toString(this.embeds_value) + ", nonce=" + 
/*  515 */       nonce().toString() + ", embed=" + 
/*  516 */       embed().toString() + "}";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonDeserialize
/*      */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*      */   @Generated(from = "MessageCreateRequest", generator = "Immutables")
/*      */   static final class Json
/*      */     implements MessageCreateRequest
/*      */   {
/*  530 */     Possible<String> content = Possible.absent();
/*      */ 
/*      */     
/*  533 */     Possible<Boolean> tts = Possible.absent();
/*      */ 
/*      */     
/*  536 */     Possible<AllowedMentionsData> allowedMentions = Possible.absent();
/*      */ 
/*      */     
/*  539 */     Possible<MessageReferenceData> messageReference = Possible.absent();
/*      */ 
/*      */     
/*  542 */     Possible<List<ComponentData>> components = Possible.absent();
/*      */ 
/*      */     
/*  545 */     Possible<List<EmbedData>> embeds = Possible.absent();
/*      */ 
/*      */     
/*  548 */     Possible<Object> nonce = Possible.absent();
/*      */ 
/*      */     
/*  551 */     Possible<EmbedData> embed = Possible.absent();
/*      */     
/*      */     @JsonProperty("content")
/*      */     public void setContent(Possible<String> content) {
/*  555 */       this.content = content;
/*      */     }
/*      */     @JsonProperty("tts")
/*      */     public void setTts(Possible<Boolean> tts) {
/*  559 */       this.tts = tts;
/*      */     }
/*      */     @JsonProperty("allowed_mentions")
/*      */     public void setAllowedMentions(Possible<AllowedMentionsData> allowedMentions) {
/*  563 */       this.allowedMentions = allowedMentions;
/*      */     }
/*      */     @JsonProperty("message_reference")
/*      */     public void setMessageReference(Possible<MessageReferenceData> messageReference) {
/*  567 */       this.messageReference = messageReference;
/*      */     }
/*      */     @JsonProperty("components")
/*      */     public void setComponents(Possible<List<ComponentData>> components) {
/*  571 */       this.components = components;
/*      */     }
/*      */     @JsonProperty("embeds")
/*      */     public void setEmbeds(Possible<List<EmbedData>> embeds) {
/*  575 */       this.embeds = embeds;
/*      */     }
/*      */     @JsonProperty("nonce")
/*      */     public void setNonce(Possible<Object> nonce) {
/*  579 */       this.nonce = nonce;
/*      */     }
/*      */     @JsonProperty("embed")
/*      */     public void setEmbed(Possible<EmbedData> embed) {
/*  583 */       this.embed = embed;
/*      */     }
/*      */     public Possible<String> content() {
/*  586 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Boolean> tts() {
/*  588 */       throw new UnsupportedOperationException();
/*      */     } public Possible<AllowedMentionsData> allowedMentions() {
/*  590 */       throw new UnsupportedOperationException();
/*      */     } public Possible<MessageReferenceData> messageReference() {
/*  592 */       throw new UnsupportedOperationException();
/*      */     } public Possible<List<ComponentData>> components() {
/*  594 */       throw new UnsupportedOperationException();
/*      */     } public Possible<List<EmbedData>> embeds() {
/*  596 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Object> nonce() {
/*  598 */       throw new UnsupportedOperationException();
/*      */     } public Possible<EmbedData> embed() {
/*  600 */       throw new UnsupportedOperationException();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*      */   static ImmutableMessageCreateRequest fromJson(Json json) {
/*  611 */     Builder builder = builder();
/*  612 */     if (json.content != null) {
/*  613 */       builder.content(json.content);
/*      */     }
/*  615 */     if (json.tts != null) {
/*  616 */       builder.tts(json.tts);
/*      */     }
/*  618 */     if (json.allowedMentions != null) {
/*  619 */       builder.allowedMentions(json.allowedMentions);
/*      */     }
/*  621 */     if (json.messageReference != null) {
/*  622 */       builder.messageReference(json.messageReference);
/*      */     }
/*  624 */     if (json.components != null) {
/*  625 */       builder.components(json.components);
/*      */     }
/*  627 */     if (json.embeds != null) {
/*  628 */       builder.embeds(json.embeds);
/*      */     }
/*  630 */     if (json.nonce != null) {
/*  631 */       builder.nonce(json.nonce);
/*      */     }
/*  633 */     if (json.embed != null) {
/*  634 */       builder.embed(json.embed);
/*      */     }
/*  636 */     return builder.build();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableMessageCreateRequest of(Possible<String> content, Possible<Boolean> tts, Possible<AllowedMentionsData> allowedMentions, Possible<MessageReferenceData> messageReference, Possible<List<ComponentData>> components, Possible<List<EmbedData>> embeds, Possible<Object> nonce, Possible<EmbedData> embed) {
/*  652 */     return new ImmutableMessageCreateRequest(content, tts, allowedMentions, messageReference, components, embeds, nonce, embed);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableMessageCreateRequest copyOf(MessageCreateRequest instance) {
/*  663 */     if (instance instanceof ImmutableMessageCreateRequest) {
/*  664 */       return (ImmutableMessageCreateRequest)instance;
/*      */     }
/*  666 */     return builder()
/*  667 */       .from(instance)
/*  668 */       .build();
/*      */   }
/*      */   
/*      */   public boolean isContentPresent() {
/*  672 */     return !this.content_absent;
/*      */   }
/*      */   
/*      */   public String contentOrElse(String defaultValue) {
/*  676 */     return !this.content_absent ? this.content_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isTtsPresent() {
/*  680 */     return !this.tts_absent;
/*      */   }
/*      */   
/*      */   public Boolean ttsOrElse(Boolean defaultValue) {
/*  684 */     return !this.tts_absent ? this.tts_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isAllowedMentionsPresent() {
/*  688 */     return !this.allowedMentions_absent;
/*      */   }
/*      */   
/*      */   public AllowedMentionsData allowedMentionsOrElse(AllowedMentionsData defaultValue) {
/*  692 */     return !this.allowedMentions_absent ? this.allowedMentions_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isMessageReferencePresent() {
/*  696 */     return !this.messageReference_absent;
/*      */   }
/*      */   
/*      */   public MessageReferenceData messageReferenceOrElse(MessageReferenceData defaultValue) {
/*  700 */     return !this.messageReference_absent ? this.messageReference_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isComponentsPresent() {
/*  704 */     return !this.components_absent;
/*      */   }
/*      */   
/*      */   public List<ComponentData> componentsOrElse(List<ComponentData> defaultValue) {
/*  708 */     return !this.components_absent ? this.components_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isEmbedsPresent() {
/*  712 */     return !this.embeds_absent;
/*      */   }
/*      */   
/*      */   public List<EmbedData> embedsOrElse(List<EmbedData> defaultValue) {
/*  716 */     return !this.embeds_absent ? this.embeds_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isNoncePresent() {
/*  720 */     return !this.nonce_absent;
/*      */   }
/*      */   
/*      */   public Object nonceOrElse(Object defaultValue) {
/*  724 */     return !this.nonce_absent ? this.nonce_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isEmbedPresent() {
/*  728 */     return !this.embed_absent;
/*      */   }
/*      */   
/*      */   public EmbedData embedOrElse(EmbedData defaultValue) {
/*  732 */     return !this.embed_absent ? this.embed_value : defaultValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Builder builder() {
/*  752 */     return new Builder();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Generated(from = "MessageCreateRequest", generator = "Immutables")
/*      */   public static final class Builder
/*      */   {
/*  764 */     private Possible<String> content_possible = Possible.absent();
/*  765 */     private Possible<Boolean> tts_possible = Possible.absent();
/*  766 */     private Possible<AllowedMentionsData> allowedMentions_possible = Possible.absent();
/*  767 */     private Possible<MessageReferenceData> messageReference_possible = Possible.absent();
/*  768 */     private List<ComponentData> components_list = null;
/*  769 */     private List<EmbedData> embeds_list = null;
/*  770 */     private Possible<Object> nonce_possible = Possible.absent();
/*  771 */     private Possible<EmbedData> embed_possible = Possible.absent();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder from(MessageCreateRequest instance) {
/*  782 */       Objects.requireNonNull(instance, "instance");
/*  783 */       from(instance);
/*  784 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder from(MessageSendRequestBase instance) {
/*  793 */       Objects.requireNonNull(instance, "instance");
/*  794 */       from(instance);
/*  795 */       return this;
/*      */     }
/*      */     
/*      */     private void from(Object object) {
/*  799 */       long bits = 0L;
/*  800 */       if (object instanceof MessageCreateRequest) {
/*  801 */         MessageCreateRequest instance = (MessageCreateRequest)object;
/*  802 */         if ((bits & 0x1L) == 0L) {
/*  803 */           messageReference(instance.messageReference());
/*  804 */           bits |= 0x1L;
/*      */         } 
/*  806 */         if ((bits & 0x2L) == 0L) {
/*  807 */           tts(instance.tts());
/*  808 */           bits |= 0x2L;
/*      */         } 
/*  810 */         if ((bits & 0x4L) == 0L) {
/*  811 */           components(instance.components());
/*  812 */           bits |= 0x4L;
/*      */         } 
/*  814 */         embed(instance.embed());
/*  815 */         if ((bits & 0x8L) == 0L) {
/*  816 */           embeds(instance.embeds());
/*  817 */           bits |= 0x8L;
/*      */         } 
/*  819 */         nonce(instance.nonce());
/*  820 */         if ((bits & 0x10L) == 0L) {
/*  821 */           content(instance.content());
/*  822 */           bits |= 0x10L;
/*      */         } 
/*  824 */         if ((bits & 0x20L) == 0L) {
/*  825 */           allowedMentions(instance.allowedMentions());
/*  826 */           bits |= 0x20L;
/*      */         } 
/*      */       } 
/*  829 */       if (object instanceof MessageSendRequestBase) {
/*  830 */         MessageSendRequestBase instance = (MessageSendRequestBase)object;
/*  831 */         if ((bits & 0x1L) == 0L) {
/*  832 */           messageReference(instance.messageReference());
/*  833 */           bits |= 0x1L;
/*      */         } 
/*  835 */         if ((bits & 0x2L) == 0L) {
/*  836 */           tts(instance.tts());
/*  837 */           bits |= 0x2L;
/*      */         } 
/*  839 */         if ((bits & 0x4L) == 0L) {
/*  840 */           components(instance.components());
/*  841 */           bits |= 0x4L;
/*      */         } 
/*  843 */         if ((bits & 0x8L) == 0L) {
/*  844 */           embeds(instance.embeds());
/*  845 */           bits |= 0x8L;
/*      */         } 
/*  847 */         if ((bits & 0x10L) == 0L) {
/*  848 */           content(instance.content());
/*  849 */           bits |= 0x10L;
/*      */         } 
/*  851 */         if ((bits & 0x20L) == 0L) {
/*  852 */           allowedMentions(instance.allowedMentions());
/*  853 */           bits |= 0x20L;
/*      */         } 
/*      */       } 
/*      */     }
/*      */     
/*      */     @JsonProperty("content")
/*      */     public Builder content(Possible<String> value) {
/*  860 */       this.content_possible = value;
/*  861 */       return this;
/*      */     }
/*      */     
/*      */     public Builder content(String value) {
/*  865 */       this.content_possible = Possible.of(value);
/*  866 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("tts")
/*      */     public Builder tts(Possible<Boolean> value) {
/*  871 */       this.tts_possible = value;
/*  872 */       return this;
/*      */     }
/*      */     
/*      */     public Builder tts(Boolean value) {
/*  876 */       this.tts_possible = Possible.of(value);
/*  877 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("allowed_mentions")
/*      */     public Builder allowedMentions(Possible<AllowedMentionsData> value) {
/*  882 */       this.allowedMentions_possible = value;
/*  883 */       return this;
/*      */     }
/*      */     
/*      */     public Builder allowedMentions(AllowedMentionsData value) {
/*  887 */       this.allowedMentions_possible = Possible.of(value);
/*  888 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("message_reference")
/*      */     public Builder messageReference(Possible<MessageReferenceData> value) {
/*  893 */       this.messageReference_possible = value;
/*  894 */       return this;
/*      */     }
/*      */     
/*      */     public Builder messageReference(MessageReferenceData value) {
/*  898 */       this.messageReference_possible = Possible.of(value);
/*  899 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addComponent(ComponentData element) {
/*  903 */       components_getOrCreate().add(element);
/*  904 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addAllComponents(List<ComponentData> elements) {
/*  908 */       components_getOrCreate().addAll(elements);
/*  909 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("components")
/*      */     public Builder components(Possible<List<ComponentData>> elements) {
/*  914 */       this.components_list = null;
/*  915 */       elements.toOptional().ifPresent(e -> components_getOrCreate().addAll(e));
/*  916 */       return this;
/*      */     }
/*      */     
/*      */     public Builder components(List<ComponentData> elements) {
/*  920 */       this.components_list = new ArrayList<>(elements);
/*  921 */       return this;
/*      */     }
/*      */     
/*      */     public Builder components(Iterable<ComponentData> elements) {
/*  925 */       this.components_list = (List<ComponentData>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/*  926 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addEmbed(EmbedData element) {
/*  930 */       embeds_getOrCreate().add(element);
/*  931 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addAllEmbeds(List<EmbedData> elements) {
/*  935 */       embeds_getOrCreate().addAll(elements);
/*  936 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("embeds")
/*      */     public Builder embeds(Possible<List<EmbedData>> elements) {
/*  941 */       this.embeds_list = null;
/*  942 */       elements.toOptional().ifPresent(e -> embeds_getOrCreate().addAll(e));
/*  943 */       return this;
/*      */     }
/*      */     
/*      */     public Builder embeds(List<EmbedData> elements) {
/*  947 */       this.embeds_list = new ArrayList<>(elements);
/*  948 */       return this;
/*      */     }
/*      */     
/*      */     public Builder embeds(Iterable<EmbedData> elements) {
/*  952 */       this.embeds_list = (List<EmbedData>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/*  953 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("nonce")
/*      */     public Builder nonce(Possible<Object> value) {
/*  958 */       this.nonce_possible = value;
/*  959 */       return this;
/*      */     }
/*      */     
/*      */     public Builder nonce(Object value) {
/*  963 */       this.nonce_possible = Possible.of(value);
/*  964 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("embed")
/*      */     public Builder embed(Possible<EmbedData> value) {
/*  969 */       this.embed_possible = value;
/*  970 */       return this;
/*      */     }
/*      */     
/*      */     public Builder embed(EmbedData value) {
/*  974 */       this.embed_possible = Possible.of(value);
/*  975 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ImmutableMessageCreateRequest build() {
/*  984 */       return new ImmutableMessageCreateRequest(null, 
/*      */           
/*  986 */           content_build(), 
/*  987 */           tts_build(), 
/*  988 */           allowedMentions_build(), 
/*  989 */           messageReference_build(), 
/*  990 */           components_build(), 
/*  991 */           embeds_build(), 
/*  992 */           nonce_build(), 
/*  993 */           embed_build());
/*      */     }
/*      */     
/*      */     private Possible<String> content_build() {
/*  997 */       return this.content_possible;
/*      */     }
/*      */     
/*      */     private Possible<Boolean> tts_build() {
/* 1001 */       return this.tts_possible;
/*      */     }
/*      */     
/*      */     private Possible<AllowedMentionsData> allowedMentions_build() {
/* 1005 */       return this.allowedMentions_possible;
/*      */     }
/*      */     
/*      */     private Possible<MessageReferenceData> messageReference_build() {
/* 1009 */       return this.messageReference_possible;
/*      */     }
/*      */     
/*      */     private Possible<List<ComponentData>> components_build() {
/* 1013 */       return (this.components_list == null) ? Possible.absent() : 
/* 1014 */         Possible.of(this.components_list);
/*      */     }
/*      */     
/*      */     private List<ComponentData> components_getOrCreate() {
/* 1018 */       if (this.components_list == null) {
/* 1019 */         this.components_list = new ArrayList<>();
/*      */       }
/* 1021 */       return this.components_list;
/*      */     }
/*      */     
/*      */     private Possible<List<EmbedData>> embeds_build() {
/* 1025 */       return (this.embeds_list == null) ? Possible.absent() : 
/* 1026 */         Possible.of(this.embeds_list);
/*      */     }
/*      */     
/*      */     private List<EmbedData> embeds_getOrCreate() {
/* 1030 */       if (this.embeds_list == null) {
/* 1031 */         this.embeds_list = new ArrayList<>();
/*      */       }
/* 1033 */       return this.embeds_list;
/*      */     }
/*      */     
/*      */     private Possible<Object> nonce_build() {
/* 1037 */       return this.nonce_possible;
/*      */     }
/*      */     
/*      */     private Possible<EmbedData> embed_build() {
/* 1041 */       return this.embed_possible;
/*      */     }
/*      */     
/*      */     private Builder() {}
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableMessageCreateRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */