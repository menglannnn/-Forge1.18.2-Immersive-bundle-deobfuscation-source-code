/*      */ package discord4j.discordjson.json;
/*      */ 
/*      */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*      */ import com.fasterxml.jackson.annotation.JsonCreator;
/*      */ import com.fasterxml.jackson.annotation.JsonProperty;
/*      */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*      */ import discord4j.discordjson.Id;
/*      */ import discord4j.discordjson.possible.Possible;
/*      */ import java.time.Instant;
/*      */ import java.util.ArrayList;
/*      */ import java.util.List;
/*      */ import java.util.Objects;
/*      */ import java.util.Optional;
/*      */ import org.immutables.value.Generated;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ @Generated(from = "GuildScheduledEventData", generator = "Immutables")
/*      */ public final class ImmutableGuildScheduledEventData
/*      */   implements GuildScheduledEventData
/*      */ {
/*      */   private final long id_value;
/*      */   private final long guildId_value;
/*      */   private final long channelId_value;
/*      */   private final boolean channelId_present;
/*      */   private final long creatorId_value;
/*      */   private final boolean creatorId_present;
/*      */   private final String name;
/*      */   private final String description_value;
/*      */   private final boolean description_absent;
/*      */   private final Instant scheduledStartTime;
/*      */   private final Instant scheduledEndTime;
/*      */   private final int privacyLevel;
/*      */   private final int status;
/*      */   private final int entityType;
/*      */   private final long entityId_value;
/*      */   private final boolean entityId_present;
/*      */   private final GuildScheduledEventEntityMetadataData entityMetadata;
/*      */   private final UserData creator_value;
/*      */   private final boolean creator_absent;
/*      */   private final Integer userCount_value;
/*      */   private final boolean userCount_absent;
/*      */   private static final byte STAGE_INITIALIZING = -1;
/*      */   private static final byte STAGE_UNINITIALIZED = 0;
/*      */   private static final byte STAGE_INITIALIZED = 1;
/*      */   
/*      */   private ImmutableGuildScheduledEventData(Id id, Id guildId, Optional<Id> channelId, Optional<Id> creatorId, String name, Possible<String> description, Instant scheduledStartTime, Optional<? extends Instant> scheduledEndTime, int privacyLevel, int status, int entityType, Optional<Id> entityId, Optional<? extends GuildScheduledEventEntityMetadataData> entityMetadata, Possible<UserData> creator, Possible<Integer> userCount) {
/*   68 */     Id id$impl = id;
/*   69 */     Id guildId$impl = guildId;
/*   70 */     Optional<Id> channelId$impl = channelId;
/*   71 */     Optional<Id> creatorId$impl = creatorId;
/*   72 */     this.name = Objects.<String>requireNonNull(name, "name");
/*   73 */     Possible<String> description$impl = description;
/*   74 */     this.scheduledStartTime = Objects.<Instant>requireNonNull(scheduledStartTime, "scheduledStartTime");
/*   75 */     this.scheduledEndTime = scheduledEndTime.orElse(null);
/*   76 */     this.privacyLevel = privacyLevel;
/*   77 */     this.status = status;
/*   78 */     this.entityType = entityType;
/*   79 */     Optional<Id> entityId$impl = entityId;
/*   80 */     this.entityMetadata = entityMetadata.orElse(null);
/*   81 */     Possible<UserData> creator$impl = creator;
/*   82 */     Possible<Integer> userCount$impl = userCount;
/*   83 */     this.id_value = id$impl.asLong();
/*   84 */     this.guildId_value = guildId$impl.asLong();
/*   85 */     this
/*      */       
/*   87 */       .channelId_value = ((Long)channelId$impl.<Long>map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*   88 */     this.channelId_present = channelId$impl.isPresent();
/*   89 */     this
/*      */       
/*   91 */       .creatorId_value = ((Long)creatorId$impl.<Long>map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*   92 */     this.creatorId_present = creatorId$impl.isPresent();
/*   93 */     this.description_value = description$impl.toOptional().orElse(null);
/*   94 */     this.description_absent = description$impl.isAbsent();
/*   95 */     this
/*      */       
/*   97 */       .entityId_value = ((Long)entityId$impl.<Long>map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*   98 */     this.entityId_present = entityId$impl.isPresent();
/*   99 */     this.creator_value = creator$impl.toOptional().orElse(null);
/*  100 */     this.creator_absent = creator$impl.isAbsent();
/*  101 */     this.userCount_value = userCount$impl.toOptional().orElse(null);
/*  102 */     this.userCount_absent = userCount$impl.isAbsent();
/*  103 */     this.initShim = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ImmutableGuildScheduledEventData(ImmutableGuildScheduledEventData original, Id id, Id guildId, Optional<Id> channelId, Optional<Id> creatorId, String name, Possible<String> description, Instant scheduledStartTime, Instant scheduledEndTime, int privacyLevel, int status, int entityType, Optional<Id> entityId, GuildScheduledEventEntityMetadataData entityMetadata, Possible<UserData> creator, Possible<Integer> userCount) {
/*  123 */     Id id$impl = id;
/*  124 */     Id guildId$impl = guildId;
/*  125 */     Optional<Id> channelId$impl = channelId;
/*  126 */     Optional<Id> creatorId$impl = creatorId;
/*  127 */     this.name = name;
/*  128 */     Possible<String> description$impl = description;
/*  129 */     this.scheduledStartTime = scheduledStartTime;
/*  130 */     this.scheduledEndTime = scheduledEndTime;
/*  131 */     this.privacyLevel = privacyLevel;
/*  132 */     this.status = status;
/*  133 */     this.entityType = entityType;
/*  134 */     Optional<Id> entityId$impl = entityId;
/*  135 */     this.entityMetadata = entityMetadata;
/*  136 */     Possible<UserData> creator$impl = creator;
/*  137 */     Possible<Integer> userCount$impl = userCount;
/*  138 */     this.id_value = id$impl.asLong();
/*  139 */     this.guildId_value = guildId$impl.asLong();
/*  140 */     this
/*      */       
/*  142 */       .channelId_value = ((Long)channelId$impl.<Long>map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  143 */     this.channelId_present = channelId$impl.isPresent();
/*  144 */     this
/*      */       
/*  146 */       .creatorId_value = ((Long)creatorId$impl.<Long>map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  147 */     this.creatorId_present = creatorId$impl.isPresent();
/*  148 */     this.description_value = description$impl.toOptional().orElse(null);
/*  149 */     this.description_absent = description$impl.isAbsent();
/*  150 */     this
/*      */       
/*  152 */       .entityId_value = ((Long)entityId$impl.<Long>map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  153 */     this.entityId_present = entityId$impl.isPresent();
/*  154 */     this.creator_value = creator$impl.toOptional().orElse(null);
/*  155 */     this.creator_absent = creator$impl.isAbsent();
/*  156 */     this.userCount_value = userCount$impl.toOptional().orElse(null);
/*  157 */     this.userCount_absent = userCount$impl.isAbsent();
/*  158 */     this.initShim = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  164 */   private volatile transient InitShim initShim = new InitShim();
/*      */   
/*      */   @Generated(from = "GuildScheduledEventData", generator = "Immutables")
/*      */   private final class InitShim {
/*      */     private String formatInitCycleMessage() {
/*  169 */       List<String> attributes = new ArrayList<>();
/*  170 */       return "Cannot build GuildScheduledEventData, attribute initializers form cycle " + attributes;
/*      */     }
/*      */ 
/*      */     
/*      */     private InitShim() {}
/*      */   }
/*      */ 
/*      */   
/*      */   @JsonProperty("id")
/*      */   public Id id() {
/*  180 */     return Id.of(this.id_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("guild_id")
/*      */   public Id guildId() {
/*  189 */     return Id.of(this.guildId_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("channel_id")
/*      */   public Optional<Id> channelId() {
/*  198 */     return this.channelId_present ? Optional.<Id>of(Id.of(this.channelId_value)) : Optional.<Id>empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("creator_id")
/*      */   public Optional<Id> creatorId() {
/*  207 */     return this.creatorId_present ? Optional.<Id>of(Id.of(this.creatorId_value)) : Optional.<Id>empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("name")
/*      */   public String name() {
/*  216 */     return this.name;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("description")
/*      */   public Possible<String> description() {
/*  225 */     return this.description_absent ? Possible.absent() : Possible.of(this.description_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("scheduled_start_time")
/*      */   public Instant scheduledStartTime() {
/*  234 */     return this.scheduledStartTime;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("scheduled_end_time")
/*      */   public Optional<Instant> scheduledEndTime() {
/*  243 */     return Optional.ofNullable(this.scheduledEndTime);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("privacy_level")
/*      */   public int privacyLevel() {
/*  252 */     return this.privacyLevel;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("status")
/*      */   public int status() {
/*  261 */     return this.status;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("entity_type")
/*      */   public int entityType() {
/*  270 */     return this.entityType;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("entity_id")
/*      */   public Optional<Id> entityId() {
/*  279 */     return this.entityId_present ? Optional.<Id>of(Id.of(this.entityId_value)) : Optional.<Id>empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("entity_metadata")
/*      */   public Optional<GuildScheduledEventEntityMetadataData> entityMetadata() {
/*  288 */     return Optional.ofNullable(this.entityMetadata);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("creator")
/*      */   public Possible<UserData> creator() {
/*  297 */     return this.creator_absent ? Possible.absent() : Possible.of(this.creator_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("user_count")
/*      */   public Possible<Integer> userCount() {
/*  306 */     return this.userCount_absent ? Possible.absent() : Possible.of(this.userCount_value);
/*      */   }
/*      */   
/*      */   public ImmutableGuildScheduledEventData withId(long value) {
/*  310 */     Id newValue = Id.of(value);
/*  311 */     return new ImmutableGuildScheduledEventData(this, newValue, 
/*      */ 
/*      */         
/*  314 */         guildId(), 
/*  315 */         channelId(), 
/*  316 */         creatorId(), this.name, 
/*      */         
/*  318 */         description(), this.scheduledStartTime, this.scheduledEndTime, this.privacyLevel, this.status, this.entityType, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  324 */         entityId(), this.entityMetadata, 
/*      */         
/*  326 */         creator(), 
/*  327 */         userCount());
/*      */   }
/*      */   
/*      */   public ImmutableGuildScheduledEventData withId(String value) {
/*  331 */     Id newValue = Id.of(value);
/*  332 */     return new ImmutableGuildScheduledEventData(this, newValue, 
/*      */ 
/*      */         
/*  335 */         guildId(), 
/*  336 */         channelId(), 
/*  337 */         creatorId(), this.name, 
/*      */         
/*  339 */         description(), this.scheduledStartTime, this.scheduledEndTime, this.privacyLevel, this.status, this.entityType, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  345 */         entityId(), this.entityMetadata, 
/*      */         
/*  347 */         creator(), 
/*  348 */         userCount());
/*      */   }
/*      */   
/*      */   public ImmutableGuildScheduledEventData withGuildId(long value) {
/*  352 */     Id newValue = Id.of(value);
/*  353 */     return new ImmutableGuildScheduledEventData(this, 
/*      */         
/*  355 */         id(), newValue, 
/*      */         
/*  357 */         channelId(), 
/*  358 */         creatorId(), this.name, 
/*      */         
/*  360 */         description(), this.scheduledStartTime, this.scheduledEndTime, this.privacyLevel, this.status, this.entityType, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  366 */         entityId(), this.entityMetadata, 
/*      */         
/*  368 */         creator(), 
/*  369 */         userCount());
/*      */   }
/*      */   
/*      */   public ImmutableGuildScheduledEventData withGuildId(String value) {
/*  373 */     Id newValue = Id.of(value);
/*  374 */     return new ImmutableGuildScheduledEventData(this, 
/*      */         
/*  376 */         id(), newValue, 
/*      */         
/*  378 */         channelId(), 
/*  379 */         creatorId(), this.name, 
/*      */         
/*  381 */         description(), this.scheduledStartTime, this.scheduledEndTime, this.privacyLevel, this.status, this.entityType, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  387 */         entityId(), this.entityMetadata, 
/*      */         
/*  389 */         creator(), 
/*  390 */         userCount());
/*      */   }
/*      */   
/*      */   public ImmutableGuildScheduledEventData withChannelId(Optional<Id> value) {
/*  394 */     Optional<Id> newValue = Objects.<Optional<Id>>requireNonNull(value);
/*  395 */     return new ImmutableGuildScheduledEventData(this, 
/*      */         
/*  397 */         id(), 
/*  398 */         guildId(), newValue, 
/*      */         
/*  400 */         creatorId(), this.name, 
/*      */         
/*  402 */         description(), this.scheduledStartTime, this.scheduledEndTime, this.privacyLevel, this.status, this.entityType, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  408 */         entityId(), this.entityMetadata, 
/*      */         
/*  410 */         creator(), 
/*  411 */         userCount());
/*      */   }
/*      */   
/*      */   public ImmutableGuildScheduledEventData withChannelId(long value) {
/*  415 */     Optional<Id> newValue = Optional.of(Id.of(value));
/*  416 */     return new ImmutableGuildScheduledEventData(this, 
/*      */         
/*  418 */         id(), 
/*  419 */         guildId(), newValue, 
/*      */         
/*  421 */         creatorId(), this.name, 
/*      */         
/*  423 */         description(), this.scheduledStartTime, this.scheduledEndTime, this.privacyLevel, this.status, this.entityType, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  429 */         entityId(), this.entityMetadata, 
/*      */         
/*  431 */         creator(), 
/*  432 */         userCount());
/*      */   }
/*      */   
/*      */   public ImmutableGuildScheduledEventData withCreatorId(Optional<Id> value) {
/*  436 */     Optional<Id> newValue = Objects.<Optional<Id>>requireNonNull(value);
/*  437 */     return new ImmutableGuildScheduledEventData(this, 
/*      */         
/*  439 */         id(), 
/*  440 */         guildId(), 
/*  441 */         channelId(), newValue, this.name, 
/*      */ 
/*      */         
/*  444 */         description(), this.scheduledStartTime, this.scheduledEndTime, this.privacyLevel, this.status, this.entityType, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  450 */         entityId(), this.entityMetadata, 
/*      */         
/*  452 */         creator(), 
/*  453 */         userCount());
/*      */   }
/*      */   
/*      */   public ImmutableGuildScheduledEventData withCreatorId(long value) {
/*  457 */     Optional<Id> newValue = Optional.of(Id.of(value));
/*  458 */     return new ImmutableGuildScheduledEventData(this, 
/*      */         
/*  460 */         id(), 
/*  461 */         guildId(), 
/*  462 */         channelId(), newValue, this.name, 
/*      */ 
/*      */         
/*  465 */         description(), this.scheduledStartTime, this.scheduledEndTime, this.privacyLevel, this.status, this.entityType, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  471 */         entityId(), this.entityMetadata, 
/*      */         
/*  473 */         creator(), 
/*  474 */         userCount());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildScheduledEventData withName(String value) {
/*  484 */     String newValue = Objects.<String>requireNonNull(value, "name");
/*  485 */     if (this.name.equals(newValue)) return this; 
/*  486 */     return new ImmutableGuildScheduledEventData(this, 
/*      */         
/*  488 */         id(), 
/*  489 */         guildId(), 
/*  490 */         channelId(), 
/*  491 */         creatorId(), newValue, 
/*      */         
/*  493 */         description(), this.scheduledStartTime, this.scheduledEndTime, this.privacyLevel, this.status, this.entityType, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  499 */         entityId(), this.entityMetadata, 
/*      */         
/*  501 */         creator(), 
/*  502 */         userCount());
/*      */   }
/*      */   
/*      */   public ImmutableGuildScheduledEventData withDescription(Possible<String> value) {
/*  506 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/*  507 */     return new ImmutableGuildScheduledEventData(this, 
/*      */         
/*  509 */         id(), 
/*  510 */         guildId(), 
/*  511 */         channelId(), 
/*  512 */         creatorId(), this.name, newValue, this.scheduledStartTime, this.scheduledEndTime, this.privacyLevel, this.status, this.entityType, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  520 */         entityId(), this.entityMetadata, 
/*      */         
/*  522 */         creator(), 
/*  523 */         userCount());
/*      */   }
/*      */   
/*      */   public ImmutableGuildScheduledEventData withDescription(String value) {
/*  527 */     Possible<String> newValue = Possible.of(value);
/*  528 */     return new ImmutableGuildScheduledEventData(this, 
/*      */         
/*  530 */         id(), 
/*  531 */         guildId(), 
/*  532 */         channelId(), 
/*  533 */         creatorId(), this.name, newValue, this.scheduledStartTime, this.scheduledEndTime, this.privacyLevel, this.status, this.entityType, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  541 */         entityId(), this.entityMetadata, 
/*      */         
/*  543 */         creator(), 
/*  544 */         userCount());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildScheduledEventData withScheduledStartTime(Instant value) {
/*  554 */     if (this.scheduledStartTime == value) return this; 
/*  555 */     Instant newValue = Objects.<Instant>requireNonNull(value, "scheduledStartTime");
/*  556 */     return new ImmutableGuildScheduledEventData(this, 
/*      */         
/*  558 */         id(), 
/*  559 */         guildId(), 
/*  560 */         channelId(), 
/*  561 */         creatorId(), this.name, 
/*      */         
/*  563 */         description(), newValue, this.scheduledEndTime, this.privacyLevel, this.status, this.entityType, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  569 */         entityId(), this.entityMetadata, 
/*      */         
/*  571 */         creator(), 
/*  572 */         userCount());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildScheduledEventData withScheduledEndTime(Instant value) {
/*  581 */     Instant newValue = Objects.<Instant>requireNonNull(value, "scheduledEndTime");
/*  582 */     if (this.scheduledEndTime == newValue) return this; 
/*  583 */     return new ImmutableGuildScheduledEventData(this, 
/*      */         
/*  585 */         id(), 
/*  586 */         guildId(), 
/*  587 */         channelId(), 
/*  588 */         creatorId(), this.name, 
/*      */         
/*  590 */         description(), this.scheduledStartTime, newValue, this.privacyLevel, this.status, this.entityType, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  596 */         entityId(), this.entityMetadata, 
/*      */         
/*  598 */         creator(), 
/*  599 */         userCount());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildScheduledEventData withScheduledEndTime(Optional<? extends Instant> optional) {
/*  610 */     Instant value = optional.orElse(null);
/*  611 */     if (this.scheduledEndTime == value) return this; 
/*  612 */     return new ImmutableGuildScheduledEventData(this, 
/*      */         
/*  614 */         id(), 
/*  615 */         guildId(), 
/*  616 */         channelId(), 
/*  617 */         creatorId(), this.name, 
/*      */         
/*  619 */         description(), this.scheduledStartTime, value, this.privacyLevel, this.status, this.entityType, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  625 */         entityId(), this.entityMetadata, 
/*      */         
/*  627 */         creator(), 
/*  628 */         userCount());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildScheduledEventData withPrivacyLevel(int value) {
/*  638 */     if (this.privacyLevel == value) return this; 
/*  639 */     return new ImmutableGuildScheduledEventData(this, 
/*      */         
/*  641 */         id(), 
/*  642 */         guildId(), 
/*  643 */         channelId(), 
/*  644 */         creatorId(), this.name, 
/*      */         
/*  646 */         description(), this.scheduledStartTime, this.scheduledEndTime, value, this.status, this.entityType, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  652 */         entityId(), this.entityMetadata, 
/*      */         
/*  654 */         creator(), 
/*  655 */         userCount());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildScheduledEventData withStatus(int value) {
/*  665 */     if (this.status == value) return this; 
/*  666 */     return new ImmutableGuildScheduledEventData(this, 
/*      */         
/*  668 */         id(), 
/*  669 */         guildId(), 
/*  670 */         channelId(), 
/*  671 */         creatorId(), this.name, 
/*      */         
/*  673 */         description(), this.scheduledStartTime, this.scheduledEndTime, this.privacyLevel, value, this.entityType, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  679 */         entityId(), this.entityMetadata, 
/*      */         
/*  681 */         creator(), 
/*  682 */         userCount());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildScheduledEventData withEntityType(int value) {
/*  692 */     if (this.entityType == value) return this; 
/*  693 */     return new ImmutableGuildScheduledEventData(this, 
/*      */         
/*  695 */         id(), 
/*  696 */         guildId(), 
/*  697 */         channelId(), 
/*  698 */         creatorId(), this.name, 
/*      */         
/*  700 */         description(), this.scheduledStartTime, this.scheduledEndTime, this.privacyLevel, this.status, value, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  706 */         entityId(), this.entityMetadata, 
/*      */         
/*  708 */         creator(), 
/*  709 */         userCount());
/*      */   }
/*      */   
/*      */   public ImmutableGuildScheduledEventData withEntityId(Optional<Id> value) {
/*  713 */     Optional<Id> newValue = Objects.<Optional<Id>>requireNonNull(value);
/*  714 */     return new ImmutableGuildScheduledEventData(this, 
/*      */         
/*  716 */         id(), 
/*  717 */         guildId(), 
/*  718 */         channelId(), 
/*  719 */         creatorId(), this.name, 
/*      */         
/*  721 */         description(), this.scheduledStartTime, this.scheduledEndTime, this.privacyLevel, this.status, this.entityType, newValue, this.entityMetadata, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  729 */         creator(), 
/*  730 */         userCount());
/*      */   }
/*      */   
/*      */   public ImmutableGuildScheduledEventData withEntityId(long value) {
/*  734 */     Optional<Id> newValue = Optional.of(Id.of(value));
/*  735 */     return new ImmutableGuildScheduledEventData(this, 
/*      */         
/*  737 */         id(), 
/*  738 */         guildId(), 
/*  739 */         channelId(), 
/*  740 */         creatorId(), this.name, 
/*      */         
/*  742 */         description(), this.scheduledStartTime, this.scheduledEndTime, this.privacyLevel, this.status, this.entityType, newValue, this.entityMetadata, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  750 */         creator(), 
/*  751 */         userCount());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildScheduledEventData withEntityMetadata(GuildScheduledEventEntityMetadataData value) {
/*  760 */     GuildScheduledEventEntityMetadataData newValue = Objects.<GuildScheduledEventEntityMetadataData>requireNonNull(value, "entityMetadata");
/*  761 */     if (this.entityMetadata == newValue) return this; 
/*  762 */     return new ImmutableGuildScheduledEventData(this, 
/*      */         
/*  764 */         id(), 
/*  765 */         guildId(), 
/*  766 */         channelId(), 
/*  767 */         creatorId(), this.name, 
/*      */         
/*  769 */         description(), this.scheduledStartTime, this.scheduledEndTime, this.privacyLevel, this.status, this.entityType, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  775 */         entityId(), newValue, 
/*      */         
/*  777 */         creator(), 
/*  778 */         userCount());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildScheduledEventData withEntityMetadata(Optional<? extends GuildScheduledEventEntityMetadataData> optional) {
/*  789 */     GuildScheduledEventEntityMetadataData value = optional.orElse(null);
/*  790 */     if (this.entityMetadata == value) return this; 
/*  791 */     return new ImmutableGuildScheduledEventData(this, 
/*      */         
/*  793 */         id(), 
/*  794 */         guildId(), 
/*  795 */         channelId(), 
/*  796 */         creatorId(), this.name, 
/*      */         
/*  798 */         description(), this.scheduledStartTime, this.scheduledEndTime, this.privacyLevel, this.status, this.entityType, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  804 */         entityId(), value, 
/*      */         
/*  806 */         creator(), 
/*  807 */         userCount());
/*      */   }
/*      */   
/*      */   public ImmutableGuildScheduledEventData withCreator(Possible<UserData> value) {
/*  811 */     Possible<UserData> newValue = Objects.<Possible<UserData>>requireNonNull(value);
/*  812 */     return new ImmutableGuildScheduledEventData(this, 
/*      */         
/*  814 */         id(), 
/*  815 */         guildId(), 
/*  816 */         channelId(), 
/*  817 */         creatorId(), this.name, 
/*      */         
/*  819 */         description(), this.scheduledStartTime, this.scheduledEndTime, this.privacyLevel, this.status, this.entityType, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  825 */         entityId(), this.entityMetadata, newValue, 
/*      */ 
/*      */         
/*  828 */         userCount());
/*      */   }
/*      */   
/*      */   public ImmutableGuildScheduledEventData withCreator(UserData value) {
/*  832 */     Possible<UserData> newValue = Possible.of(value);
/*  833 */     return new ImmutableGuildScheduledEventData(this, 
/*      */         
/*  835 */         id(), 
/*  836 */         guildId(), 
/*  837 */         channelId(), 
/*  838 */         creatorId(), this.name, 
/*      */         
/*  840 */         description(), this.scheduledStartTime, this.scheduledEndTime, this.privacyLevel, this.status, this.entityType, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  846 */         entityId(), this.entityMetadata, newValue, 
/*      */ 
/*      */         
/*  849 */         userCount());
/*      */   }
/*      */   
/*      */   public ImmutableGuildScheduledEventData withUserCount(Possible<Integer> value) {
/*  853 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/*  854 */     return new ImmutableGuildScheduledEventData(this, 
/*      */         
/*  856 */         id(), 
/*  857 */         guildId(), 
/*  858 */         channelId(), 
/*  859 */         creatorId(), this.name, 
/*      */         
/*  861 */         description(), this.scheduledStartTime, this.scheduledEndTime, this.privacyLevel, this.status, this.entityType, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  867 */         entityId(), this.entityMetadata, 
/*      */         
/*  869 */         creator(), newValue);
/*      */   }
/*      */ 
/*      */   
/*      */   public ImmutableGuildScheduledEventData withUserCount(Integer value) {
/*  874 */     Possible<Integer> newValue = Possible.of(value);
/*  875 */     return new ImmutableGuildScheduledEventData(this, 
/*      */         
/*  877 */         id(), 
/*  878 */         guildId(), 
/*  879 */         channelId(), 
/*  880 */         creatorId(), this.name, 
/*      */         
/*  882 */         description(), this.scheduledStartTime, this.scheduledEndTime, this.privacyLevel, this.status, this.entityType, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  888 */         entityId(), this.entityMetadata, 
/*      */         
/*  890 */         creator(), newValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean equals(Object another) {
/*  900 */     if (this == another) return true; 
/*  901 */     return (another instanceof ImmutableGuildScheduledEventData && 
/*  902 */       equalTo(0, (ImmutableGuildScheduledEventData)another));
/*      */   }
/*      */   
/*      */   private boolean equalTo(int synthetic, ImmutableGuildScheduledEventData another) {
/*  906 */     return (Objects.equals(Long.valueOf(this.id_value), Long.valueOf(another.id_value)) && 
/*  907 */       Objects.equals(Long.valueOf(this.guildId_value), Long.valueOf(another.guildId_value)) && 
/*  908 */       channelId().equals(another.channelId()) && 
/*  909 */       creatorId().equals(another.creatorId()) && this.name
/*  910 */       .equals(another.name) && 
/*  911 */       description().equals(another.description()) && this.scheduledStartTime
/*  912 */       .equals(another.scheduledStartTime) && 
/*  913 */       Objects.equals(this.scheduledEndTime, another.scheduledEndTime) && this.privacyLevel == another.privacyLevel && this.status == another.status && this.entityType == another.entityType && 
/*      */ 
/*      */ 
/*      */       
/*  917 */       entityId().equals(another.entityId()) && 
/*  918 */       Objects.equals(this.entityMetadata, another.entityMetadata) && 
/*  919 */       creator().equals(another.creator()) && 
/*  920 */       userCount().equals(another.userCount()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int hashCode() {
/*  929 */     int h = 5381;
/*  930 */     h += (h << 5) + Objects.hashCode(Long.valueOf(this.id_value));
/*  931 */     h += (h << 5) + Objects.hashCode(Long.valueOf(this.guildId_value));
/*  932 */     h += (h << 5) + channelId().hashCode();
/*  933 */     h += (h << 5) + creatorId().hashCode();
/*  934 */     h += (h << 5) + this.name.hashCode();
/*  935 */     h += (h << 5) + description().hashCode();
/*  936 */     h += (h << 5) + this.scheduledStartTime.hashCode();
/*  937 */     h += (h << 5) + Objects.hashCode(this.scheduledEndTime);
/*  938 */     h += (h << 5) + this.privacyLevel;
/*  939 */     h += (h << 5) + this.status;
/*  940 */     h += (h << 5) + this.entityType;
/*  941 */     h += (h << 5) + entityId().hashCode();
/*  942 */     h += (h << 5) + Objects.hashCode(this.entityMetadata);
/*  943 */     h += (h << 5) + creator().hashCode();
/*  944 */     h += (h << 5) + userCount().hashCode();
/*  945 */     return h;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/*  954 */     StringBuilder builder = new StringBuilder("GuildScheduledEventData{");
/*  955 */     builder.append("id=").append(Objects.toString(Long.valueOf(this.id_value)));
/*  956 */     builder.append(", ");
/*  957 */     builder.append("guildId=").append(Objects.toString(Long.valueOf(this.guildId_value)));
/*  958 */     builder.append(", ");
/*  959 */     builder.append("channelId=").append(channelId().toString());
/*  960 */     builder.append(", ");
/*  961 */     builder.append("creatorId=").append(creatorId().toString());
/*  962 */     builder.append(", ");
/*  963 */     builder.append("name=").append(this.name);
/*  964 */     builder.append(", ");
/*  965 */     builder.append("description=").append(description().toString());
/*  966 */     builder.append(", ");
/*  967 */     builder.append("scheduledStartTime=").append(this.scheduledStartTime);
/*  968 */     if (this.scheduledEndTime != null) {
/*  969 */       builder.append(", ");
/*  970 */       builder.append("scheduledEndTime=").append(this.scheduledEndTime);
/*      */     } 
/*  972 */     builder.append(", ");
/*  973 */     builder.append("privacyLevel=").append(this.privacyLevel);
/*  974 */     builder.append(", ");
/*  975 */     builder.append("status=").append(this.status);
/*  976 */     builder.append(", ");
/*  977 */     builder.append("entityType=").append(this.entityType);
/*  978 */     builder.append(", ");
/*  979 */     builder.append("entityId=").append(entityId().toString());
/*  980 */     if (this.entityMetadata != null) {
/*  981 */       builder.append(", ");
/*  982 */       builder.append("entityMetadata=").append(this.entityMetadata);
/*      */     } 
/*  984 */     builder.append(", ");
/*  985 */     builder.append("creator=").append(creator().toString());
/*  986 */     builder.append(", ");
/*  987 */     builder.append("userCount=").append(userCount().toString());
/*  988 */     return builder.append("}").toString();
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonDeserialize
/*      */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*      */   @Generated(from = "GuildScheduledEventData", generator = "Immutables")
/*      */   static final class Json
/*      */     implements GuildScheduledEventData
/*      */   {
/*      */     Id id;
/*      */     
/*      */     Id guildId;
/*      */     
/* 1003 */     Optional<Id> channelId = Optional.empty();
/*      */ 
/*      */     
/* 1006 */     Optional<Id> creatorId = Optional.empty();
/*      */     
/*      */     String name;
/*      */     
/* 1010 */     Possible<String> description = Possible.absent();
/*      */     
/*      */     Instant scheduledStartTime;
/* 1013 */     Optional<Instant> scheduledEndTime = Optional.empty();
/*      */     
/*      */     int privacyLevel;
/*      */     boolean privacyLevelIsSet;
/*      */     int status;
/*      */     boolean statusIsSet;
/*      */     int entityType;
/*      */     boolean entityTypeIsSet;
/* 1021 */     Optional<Id> entityId = Optional.empty();
/*      */     
/* 1023 */     Optional<GuildScheduledEventEntityMetadataData> entityMetadata = Optional.empty();
/*      */     
/* 1025 */     Possible<UserData> creator = Possible.absent();
/*      */ 
/*      */     
/* 1028 */     Possible<Integer> userCount = Possible.absent();
/*      */     
/*      */     @JsonProperty("id")
/*      */     public void setId(Id id) {
/* 1032 */       this.id = id;
/*      */     }
/*      */     @JsonProperty("guild_id")
/*      */     public void setGuildId(Id guildId) {
/* 1036 */       this.guildId = guildId;
/*      */     }
/*      */     @JsonProperty("channel_id")
/*      */     public void setChannelId(Optional<Id> channelId) {
/* 1040 */       this.channelId = channelId;
/*      */     }
/*      */     @JsonProperty("creator_id")
/*      */     public void setCreatorId(Optional<Id> creatorId) {
/* 1044 */       this.creatorId = creatorId;
/*      */     }
/*      */     @JsonProperty("name")
/*      */     public void setName(String name) {
/* 1048 */       this.name = name;
/*      */     }
/*      */     @JsonProperty("description")
/*      */     public void setDescription(Possible<String> description) {
/* 1052 */       this.description = description;
/*      */     }
/*      */     @JsonProperty("scheduled_start_time")
/*      */     public void setScheduledStartTime(Instant scheduledStartTime) {
/* 1056 */       this.scheduledStartTime = scheduledStartTime;
/*      */     }
/*      */     @JsonProperty("scheduled_end_time")
/*      */     public void setScheduledEndTime(Optional<Instant> scheduledEndTime) {
/* 1060 */       this.scheduledEndTime = scheduledEndTime;
/*      */     }
/*      */     @JsonProperty("privacy_level")
/*      */     public void setPrivacyLevel(int privacyLevel) {
/* 1064 */       this.privacyLevel = privacyLevel;
/* 1065 */       this.privacyLevelIsSet = true;
/*      */     }
/*      */     @JsonProperty("status")
/*      */     public void setStatus(int status) {
/* 1069 */       this.status = status;
/* 1070 */       this.statusIsSet = true;
/*      */     }
/*      */     @JsonProperty("entity_type")
/*      */     public void setEntityType(int entityType) {
/* 1074 */       this.entityType = entityType;
/* 1075 */       this.entityTypeIsSet = true;
/*      */     }
/*      */     @JsonProperty("entity_id")
/*      */     public void setEntityId(Optional<Id> entityId) {
/* 1079 */       this.entityId = entityId;
/*      */     }
/*      */     @JsonProperty("entity_metadata")
/*      */     public void setEntityMetadata(Optional<GuildScheduledEventEntityMetadataData> entityMetadata) {
/* 1083 */       this.entityMetadata = entityMetadata;
/*      */     }
/*      */     @JsonProperty("creator")
/*      */     public void setCreator(Possible<UserData> creator) {
/* 1087 */       this.creator = creator;
/*      */     }
/*      */     @JsonProperty("user_count")
/*      */     public void setUserCount(Possible<Integer> userCount) {
/* 1091 */       this.userCount = userCount;
/*      */     }
/*      */     public Id id() {
/* 1094 */       throw new UnsupportedOperationException();
/*      */     } public Id guildId() {
/* 1096 */       throw new UnsupportedOperationException();
/*      */     } public Optional<Id> channelId() {
/* 1098 */       throw new UnsupportedOperationException();
/*      */     } public Optional<Id> creatorId() {
/* 1100 */       throw new UnsupportedOperationException();
/*      */     } public String name() {
/* 1102 */       throw new UnsupportedOperationException();
/*      */     } public Possible<String> description() {
/* 1104 */       throw new UnsupportedOperationException();
/*      */     } public Instant scheduledStartTime() {
/* 1106 */       throw new UnsupportedOperationException();
/*      */     } public Optional<Instant> scheduledEndTime() {
/* 1108 */       throw new UnsupportedOperationException();
/*      */     } public int privacyLevel() {
/* 1110 */       throw new UnsupportedOperationException();
/*      */     } public int status() {
/* 1112 */       throw new UnsupportedOperationException();
/*      */     } public int entityType() {
/* 1114 */       throw new UnsupportedOperationException();
/*      */     } public Optional<Id> entityId() {
/* 1116 */       throw new UnsupportedOperationException();
/*      */     } public Optional<GuildScheduledEventEntityMetadataData> entityMetadata() {
/* 1118 */       throw new UnsupportedOperationException();
/*      */     } public Possible<UserData> creator() {
/* 1120 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Integer> userCount() {
/* 1122 */       throw new UnsupportedOperationException();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*      */   static ImmutableGuildScheduledEventData fromJson(Json json) {
/* 1133 */     Builder builder = builder();
/* 1134 */     if (json.id != null) {
/* 1135 */       builder.id(json.id);
/*      */     }
/* 1137 */     if (json.guildId != null) {
/* 1138 */       builder.guildId(json.guildId);
/*      */     }
/* 1140 */     if (json.channelId != null) {
/* 1141 */       builder.channelId(json.channelId);
/*      */     }
/* 1143 */     if (json.creatorId != null) {
/* 1144 */       builder.creatorId(json.creatorId);
/*      */     }
/* 1146 */     if (json.name != null) {
/* 1147 */       builder.name(json.name);
/*      */     }
/* 1149 */     if (json.description != null) {
/* 1150 */       builder.description(json.description);
/*      */     }
/* 1152 */     if (json.scheduledStartTime != null) {
/* 1153 */       builder.scheduledStartTime(json.scheduledStartTime);
/*      */     }
/* 1155 */     if (json.scheduledEndTime != null) {
/* 1156 */       builder.scheduledEndTime(json.scheduledEndTime);
/*      */     }
/* 1158 */     if (json.privacyLevelIsSet) {
/* 1159 */       builder.privacyLevel(json.privacyLevel);
/*      */     }
/* 1161 */     if (json.statusIsSet) {
/* 1162 */       builder.status(json.status);
/*      */     }
/* 1164 */     if (json.entityTypeIsSet) {
/* 1165 */       builder.entityType(json.entityType);
/*      */     }
/* 1167 */     if (json.entityId != null) {
/* 1168 */       builder.entityId(json.entityId);
/*      */     }
/* 1170 */     if (json.entityMetadata != null) {
/* 1171 */       builder.entityMetadata(json.entityMetadata);
/*      */     }
/* 1173 */     if (json.creator != null) {
/* 1174 */       builder.creator(json.creator);
/*      */     }
/* 1176 */     if (json.userCount != null) {
/* 1177 */       builder.userCount(json.userCount);
/*      */     }
/* 1179 */     return builder.build();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableGuildScheduledEventData of(Id id, Id guildId, Optional<Id> channelId, Optional<Id> creatorId, String name, Possible<String> description, Instant scheduledStartTime, Optional<? extends Instant> scheduledEndTime, int privacyLevel, int status, int entityType, Optional<Id> entityId, Optional<? extends GuildScheduledEventEntityMetadataData> entityMetadata, Possible<UserData> creator, Possible<Integer> userCount) {
/* 1202 */     return new ImmutableGuildScheduledEventData(id, guildId, channelId, creatorId, name, description, scheduledStartTime, scheduledEndTime, privacyLevel, status, entityType, entityId, entityMetadata, creator, userCount);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableGuildScheduledEventData copyOf(GuildScheduledEventData instance) {
/* 1213 */     if (instance instanceof ImmutableGuildScheduledEventData) {
/* 1214 */       return (ImmutableGuildScheduledEventData)instance;
/*      */     }
/* 1216 */     return builder()
/* 1217 */       .from(instance)
/* 1218 */       .build();
/*      */   }
/*      */   
/*      */   public boolean isChannelIdPresent() {
/* 1222 */     return this.channelId_present;
/*      */   }
/*      */   
/*      */   public long channelIdOrElse(long defaultValue) {
/* 1226 */     return this.channelId_present ? this.channelId_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isCreatorIdPresent() {
/* 1230 */     return this.creatorId_present;
/*      */   }
/*      */   
/*      */   public long creatorIdOrElse(long defaultValue) {
/* 1234 */     return this.creatorId_present ? this.creatorId_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isDescriptionPresent() {
/* 1238 */     return !this.description_absent;
/*      */   }
/*      */   
/*      */   public String descriptionOrElse(String defaultValue) {
/* 1242 */     return !this.description_absent ? this.description_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isEntityIdPresent() {
/* 1246 */     return this.entityId_present;
/*      */   }
/*      */   
/*      */   public long entityIdOrElse(long defaultValue) {
/* 1250 */     return this.entityId_present ? this.entityId_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isCreatorPresent() {
/* 1254 */     return !this.creator_absent;
/*      */   }
/*      */   
/*      */   public UserData creatorOrElse(UserData defaultValue) {
/* 1258 */     return !this.creator_absent ? this.creator_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isUserCountPresent() {
/* 1262 */     return !this.userCount_absent;
/*      */   }
/*      */   
/*      */   public Integer userCountOrElse(Integer defaultValue) {
/* 1266 */     return !this.userCount_absent ? this.userCount_value : defaultValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Builder builder() {
/* 1293 */     return new Builder();
/*      */   }
/*      */ 
/*      */   
/*      */   @Generated(from = "GuildScheduledEventData", generator = "Immutables")
/*      */   public static final class Builder
/*      */   {
/*      */     private static final long INIT_BIT_NAME = 1L;
/*      */     
/*      */     private static final long INIT_BIT_SCHEDULED_START_TIME = 2L;
/*      */     
/*      */     private static final long INIT_BIT_PRIVACY_LEVEL = 4L;
/*      */     
/*      */     private static final long INIT_BIT_STATUS = 8L;
/*      */     
/*      */     private static final long INIT_BIT_ENTITY_TYPE = 16L;
/*      */     
/* 1310 */     private long initBits = 31L;
/*      */     
/* 1312 */     private Id id_id = null;
/* 1313 */     private Id guildId_id = null;
/* 1314 */     private Optional<Id> channelId_optional = Optional.empty();
/* 1315 */     private Optional<Id> creatorId_optional = Optional.empty();
/* 1316 */     private Possible<String> description_possible = Possible.absent();
/* 1317 */     private Optional<Id> entityId_optional = Optional.empty();
/* 1318 */     private Possible<UserData> creator_possible = Possible.absent();
/* 1319 */     private Possible<Integer> userCount_possible = Possible.absent();
/*      */ 
/*      */     
/*      */     private String name;
/*      */ 
/*      */     
/*      */     private Instant scheduledStartTime;
/*      */     
/*      */     private Instant scheduledEndTime;
/*      */     
/*      */     private int privacyLevel;
/*      */     
/*      */     private int status;
/*      */     
/*      */     private int entityType;
/*      */     
/*      */     private GuildScheduledEventEntityMetadataData entityMetadata;
/*      */ 
/*      */     
/*      */     public final Builder from(GuildScheduledEventData instance) {
/* 1339 */       Objects.requireNonNull(instance, "instance");
/* 1340 */       id(instance.id());
/* 1341 */       guildId(instance.guildId());
/* 1342 */       channelId(instance.channelId());
/* 1343 */       creatorId(instance.creatorId());
/* 1344 */       name(instance.name());
/* 1345 */       description(instance.description());
/* 1346 */       scheduledStartTime(instance.scheduledStartTime());
/* 1347 */       Optional<Instant> scheduledEndTimeOptional = instance.scheduledEndTime();
/* 1348 */       if (scheduledEndTimeOptional.isPresent()) {
/* 1349 */         scheduledEndTime(scheduledEndTimeOptional);
/*      */       }
/* 1351 */       privacyLevel(instance.privacyLevel());
/* 1352 */       status(instance.status());
/* 1353 */       entityType(instance.entityType());
/* 1354 */       entityId(instance.entityId());
/* 1355 */       Optional<GuildScheduledEventEntityMetadataData> entityMetadataOptional = instance.entityMetadata();
/* 1356 */       if (entityMetadataOptional.isPresent()) {
/* 1357 */         entityMetadata(entityMetadataOptional);
/*      */       }
/* 1359 */       creator(instance.creator());
/* 1360 */       userCount(instance.userCount());
/* 1361 */       return this;
/*      */     }
/*      */     
/*      */     public Builder id(String value) {
/* 1365 */       this.id_id = Id.of(value);
/* 1366 */       return this;
/*      */     }
/*      */     
/*      */     public Builder id(long value) {
/* 1370 */       this.id_id = Id.of(value);
/* 1371 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("id")
/*      */     public Builder id(Id value) {
/* 1376 */       this.id_id = value;
/* 1377 */       return this;
/*      */     }
/*      */     
/*      */     public Builder guildId(String value) {
/* 1381 */       this.guildId_id = Id.of(value);
/* 1382 */       return this;
/*      */     }
/*      */     
/*      */     public Builder guildId(long value) {
/* 1386 */       this.guildId_id = Id.of(value);
/* 1387 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("guild_id")
/*      */     public Builder guildId(Id value) {
/* 1392 */       this.guildId_id = value;
/* 1393 */       return this;
/*      */     }
/*      */     
/*      */     public Builder channelId(String value) {
/* 1397 */       this.channelId_optional = Optional.of(Id.of(value));
/* 1398 */       return this;
/*      */     }
/*      */     
/*      */     public Builder channelId(long value) {
/* 1402 */       this.channelId_optional = Optional.of(Id.of(value));
/* 1403 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("channel_id")
/*      */     public Builder channelId(Optional<Id> value) {
/* 1408 */       this.channelId_optional = value;
/* 1409 */       return this;
/*      */     }
/*      */     
/*      */     public Builder creatorId(String value) {
/* 1413 */       this.creatorId_optional = Optional.of(Id.of(value));
/* 1414 */       return this;
/*      */     }
/*      */     
/*      */     public Builder creatorId(long value) {
/* 1418 */       this.creatorId_optional = Optional.of(Id.of(value));
/* 1419 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("creator_id")
/*      */     public Builder creatorId(Optional<Id> value) {
/* 1424 */       this.creatorId_optional = value;
/* 1425 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("name")
/*      */     public final Builder name(String name) {
/* 1435 */       this.name = Objects.<String>requireNonNull(name, "name");
/* 1436 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 1437 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("description")
/*      */     public Builder description(Possible<String> value) {
/* 1442 */       this.description_possible = value;
/* 1443 */       return this;
/*      */     }
/*      */     
/*      */     public Builder description(String value) {
/* 1447 */       this.description_possible = Possible.of(value);
/* 1448 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("scheduled_start_time")
/*      */     public final Builder scheduledStartTime(Instant scheduledStartTime) {
/* 1458 */       this.scheduledStartTime = Objects.<Instant>requireNonNull(scheduledStartTime, "scheduledStartTime");
/* 1459 */       this.initBits &= 0xFFFFFFFFFFFFFFFDL;
/* 1460 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder scheduledEndTime(Instant scheduledEndTime) {
/* 1469 */       this.scheduledEndTime = Objects.<Instant>requireNonNull(scheduledEndTime, "scheduledEndTime");
/* 1470 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("scheduled_end_time")
/*      */     public final Builder scheduledEndTime(Optional<? extends Instant> scheduledEndTime) {
/* 1480 */       this.scheduledEndTime = scheduledEndTime.orElse(null);
/* 1481 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("privacy_level")
/*      */     public final Builder privacyLevel(int privacyLevel) {
/* 1491 */       this.privacyLevel = privacyLevel;
/* 1492 */       this.initBits &= 0xFFFFFFFFFFFFFFFBL;
/* 1493 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("status")
/*      */     public final Builder status(int status) {
/* 1503 */       this.status = status;
/* 1504 */       this.initBits &= 0xFFFFFFFFFFFFFFF7L;
/* 1505 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("entity_type")
/*      */     public final Builder entityType(int entityType) {
/* 1515 */       this.entityType = entityType;
/* 1516 */       this.initBits &= 0xFFFFFFFFFFFFFFEFL;
/* 1517 */       return this;
/*      */     }
/*      */     
/*      */     public Builder entityId(String value) {
/* 1521 */       this.entityId_optional = Optional.of(Id.of(value));
/* 1522 */       return this;
/*      */     }
/*      */     
/*      */     public Builder entityId(long value) {
/* 1526 */       this.entityId_optional = Optional.of(Id.of(value));
/* 1527 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("entity_id")
/*      */     public Builder entityId(Optional<Id> value) {
/* 1532 */       this.entityId_optional = value;
/* 1533 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder entityMetadata(GuildScheduledEventEntityMetadataData entityMetadata) {
/* 1542 */       this.entityMetadata = Objects.<GuildScheduledEventEntityMetadataData>requireNonNull(entityMetadata, "entityMetadata");
/* 1543 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("entity_metadata")
/*      */     public final Builder entityMetadata(Optional<? extends GuildScheduledEventEntityMetadataData> entityMetadata) {
/* 1553 */       this.entityMetadata = entityMetadata.orElse(null);
/* 1554 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("creator")
/*      */     public Builder creator(Possible<UserData> value) {
/* 1559 */       this.creator_possible = value;
/* 1560 */       return this;
/*      */     }
/*      */     
/*      */     public Builder creator(UserData value) {
/* 1564 */       this.creator_possible = Possible.of(value);
/* 1565 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("user_count")
/*      */     public Builder userCount(Possible<Integer> value) {
/* 1570 */       this.userCount_possible = value;
/* 1571 */       return this;
/*      */     }
/*      */     
/*      */     public Builder userCount(Integer value) {
/* 1575 */       this.userCount_possible = Possible.of(value);
/* 1576 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ImmutableGuildScheduledEventData build() {
/* 1585 */       if (this.initBits != 0L) {
/* 1586 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*      */       }
/* 1588 */       return new ImmutableGuildScheduledEventData(null, 
/*      */           
/* 1590 */           id_build(), 
/* 1591 */           guildId_build(), 
/* 1592 */           channelId_build(), 
/* 1593 */           creatorId_build(), this.name, 
/*      */           
/* 1595 */           description_build(), this.scheduledStartTime, this.scheduledEndTime, this.privacyLevel, this.status, this.entityType, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1601 */           entityId_build(), this.entityMetadata, 
/*      */           
/* 1603 */           creator_build(), 
/* 1604 */           userCount_build());
/*      */     }
/*      */     
/*      */     private String formatRequiredAttributesMessage() {
/* 1608 */       List<String> attributes = new ArrayList<>();
/* 1609 */       if ((this.initBits & 0x1L) != 0L) attributes.add("name"); 
/* 1610 */       if ((this.initBits & 0x2L) != 0L) attributes.add("scheduledStartTime"); 
/* 1611 */       if ((this.initBits & 0x4L) != 0L) attributes.add("privacyLevel"); 
/* 1612 */       if ((this.initBits & 0x8L) != 0L) attributes.add("status"); 
/* 1613 */       if ((this.initBits & 0x10L) != 0L) attributes.add("entityType"); 
/* 1614 */       return "Cannot build GuildScheduledEventData, some of required attributes are not set " + attributes;
/*      */     }
/*      */     
/*      */     private Id id_build() {
/* 1618 */       return this.id_id;
/*      */     }
/*      */     
/*      */     private Id guildId_build() {
/* 1622 */       return this.guildId_id;
/*      */     }
/*      */     
/*      */     private Optional<Id> channelId_build() {
/* 1626 */       return this.channelId_optional;
/*      */     }
/*      */     
/*      */     private Optional<Id> creatorId_build() {
/* 1630 */       return this.creatorId_optional;
/*      */     }
/*      */     
/*      */     private Possible<String> description_build() {
/* 1634 */       return this.description_possible;
/*      */     }
/*      */     
/*      */     private Optional<Id> entityId_build() {
/* 1638 */       return this.entityId_optional;
/*      */     }
/*      */     
/*      */     private Possible<UserData> creator_build() {
/* 1642 */       return this.creator_possible;
/*      */     }
/*      */     
/*      */     private Possible<Integer> userCount_build() {
/* 1646 */       return this.userCount_possible;
/*      */     }
/*      */     
/*      */     private Builder() {}
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableGuildScheduledEventData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */