/*    */ package discord4j.discordjson.json;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonProperty;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import java.util.List;
/*    */ import java.util.Optional;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ 
/*    */ @JsonSerialize(as = ImmutableChannelModifyRequest.class)
/*    */ @JsonDeserialize(as = ImmutableChannelModifyRequest.class)
/*    */ @Immutable
/*    */ public interface ChannelModifyRequest
/*    */ {
/*    */   static ImmutableChannelModifyRequest.Builder builder() {
/* 18 */     return ImmutableChannelModifyRequest.builder();
/*    */   }
/*    */   
/*    */   Possible<String> name();
/*    */   
/*    */   Possible<Integer> position();
/*    */   
/*    */   Possible<String> topic();
/*    */   
/*    */   Possible<Boolean> nsfw();
/*    */   
/*    */   @JsonProperty("rate_limit_per_user")
/*    */   Possible<Integer> rateLimitPerUser();
/*    */   
/*    */   Possible<Integer> bitrate();
/*    */   
/*    */   @JsonProperty("user_limit")
/*    */   Possible<Integer> userLimit();
/*    */   
/*    */   @JsonProperty("permission_overwrites")
/*    */   Possible<List<OverwriteData>> permissionOverwrites();
/*    */   
/*    */   @JsonProperty("parent_id")
/*    */   Possible<Optional<String>> parentId();
/*    */   
/*    */   @JsonProperty("rtc_region")
/*    */   Possible<Optional<String>> rtcRegion();
/*    */   
/*    */   @JsonProperty("video_quality_mode")
/*    */   Possible<Optional<Integer>> videoQualityMode();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ChannelModifyRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */