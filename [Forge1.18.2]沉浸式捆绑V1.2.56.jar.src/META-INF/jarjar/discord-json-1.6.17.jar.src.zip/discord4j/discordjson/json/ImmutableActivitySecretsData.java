/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "ActivitySecretsData", generator = "Immutables")
/*     */ public final class ImmutableActivitySecretsData
/*     */   implements ActivitySecretsData
/*     */ {
/*     */   private final String join_value;
/*     */   private final boolean join_absent;
/*     */   private final String spectate_value;
/*     */   private final boolean spectate_absent;
/*     */   private final String match_value;
/*     */   private final boolean match_absent;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   
/*     */   private ImmutableActivitySecretsData(Possible<String> join, Possible<String> spectate, Possible<String> match) {
/*  36 */     Possible<String> join$impl = join;
/*  37 */     Possible<String> spectate$impl = spectate;
/*  38 */     Possible<String> match$impl = match;
/*  39 */     this.join_value = join$impl.toOptional().orElse(null);
/*  40 */     this.join_absent = join$impl.isAbsent();
/*  41 */     this.spectate_value = spectate$impl.toOptional().orElse(null);
/*  42 */     this.spectate_absent = spectate$impl.isAbsent();
/*  43 */     this.match_value = match$impl.toOptional().orElse(null);
/*  44 */     this.match_absent = match$impl.isAbsent();
/*  45 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ImmutableActivitySecretsData(ImmutableActivitySecretsData original, Possible<String> join, Possible<String> spectate, Possible<String> match) {
/*  53 */     Possible<String> join$impl = join;
/*  54 */     Possible<String> spectate$impl = spectate;
/*  55 */     Possible<String> match$impl = match;
/*  56 */     this.join_value = join$impl.toOptional().orElse(null);
/*  57 */     this.join_absent = join$impl.isAbsent();
/*  58 */     this.spectate_value = spectate$impl.toOptional().orElse(null);
/*  59 */     this.spectate_absent = spectate$impl.isAbsent();
/*  60 */     this.match_value = match$impl.toOptional().orElse(null);
/*  61 */     this.match_absent = match$impl.isAbsent();
/*  62 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  68 */   private volatile transient InitShim initShim = new InitShim();
/*     */   
/*     */   @Generated(from = "ActivitySecretsData", generator = "Immutables")
/*     */   private final class InitShim {
/*     */     private String formatInitCycleMessage() {
/*  73 */       List<String> attributes = new ArrayList<>();
/*  74 */       return "Cannot build ActivitySecretsData, attribute initializers form cycle " + attributes;
/*     */     }
/*     */ 
/*     */     
/*     */     private InitShim() {}
/*     */   }
/*     */ 
/*     */   
/*     */   @JsonProperty("join")
/*     */   public Possible<String> join() {
/*  84 */     return this.join_absent ? Possible.absent() : Possible.of(this.join_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("spectate")
/*     */   public Possible<String> spectate() {
/*  93 */     return this.spectate_absent ? Possible.absent() : Possible.of(this.spectate_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("match")
/*     */   public Possible<String> match() {
/* 102 */     return this.match_absent ? Possible.absent() : Possible.of(this.match_value);
/*     */   }
/*     */   
/*     */   public ImmutableActivitySecretsData withJoin(Possible<String> value) {
/* 106 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/* 107 */     return new ImmutableActivitySecretsData(this, newValue, spectate(), match());
/*     */   }
/*     */   
/*     */   public ImmutableActivitySecretsData withJoin(String value) {
/* 111 */     Possible<String> newValue = Possible.of(value);
/* 112 */     return new ImmutableActivitySecretsData(this, newValue, spectate(), match());
/*     */   }
/*     */   
/*     */   public ImmutableActivitySecretsData withSpectate(Possible<String> value) {
/* 116 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/* 117 */     return new ImmutableActivitySecretsData(this, join(), newValue, match());
/*     */   }
/*     */   
/*     */   public ImmutableActivitySecretsData withSpectate(String value) {
/* 121 */     Possible<String> newValue = Possible.of(value);
/* 122 */     return new ImmutableActivitySecretsData(this, join(), newValue, match());
/*     */   }
/*     */   
/*     */   public ImmutableActivitySecretsData withMatch(Possible<String> value) {
/* 126 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/* 127 */     return new ImmutableActivitySecretsData(this, join(), spectate(), newValue);
/*     */   }
/*     */   
/*     */   public ImmutableActivitySecretsData withMatch(String value) {
/* 131 */     Possible<String> newValue = Possible.of(value);
/* 132 */     return new ImmutableActivitySecretsData(this, join(), spectate(), newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 141 */     if (this == another) return true; 
/* 142 */     return (another instanceof ImmutableActivitySecretsData && 
/* 143 */       equalTo(0, (ImmutableActivitySecretsData)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableActivitySecretsData another) {
/* 147 */     return (join().equals(another.join()) && 
/* 148 */       spectate().equals(another.spectate()) && 
/* 149 */       match().equals(another.match()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 158 */     int h = 5381;
/* 159 */     h += (h << 5) + join().hashCode();
/* 160 */     h += (h << 5) + spectate().hashCode();
/* 161 */     h += (h << 5) + match().hashCode();
/* 162 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 171 */     return "ActivitySecretsData{join=" + 
/* 172 */       join().toString() + ", spectate=" + 
/* 173 */       spectate().toString() + ", match=" + 
/* 174 */       match().toString() + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "ActivitySecretsData", generator = "Immutables")
/*     */   static final class Json
/*     */     implements ActivitySecretsData
/*     */   {
/* 188 */     Possible<String> join = Possible.absent();
/*     */ 
/*     */     
/* 191 */     Possible<String> spectate = Possible.absent();
/*     */ 
/*     */     
/* 194 */     Possible<String> match = Possible.absent();
/*     */     
/*     */     @JsonProperty("join")
/*     */     public void setJoin(Possible<String> join) {
/* 198 */       this.join = join;
/*     */     }
/*     */     @JsonProperty("spectate")
/*     */     public void setSpectate(Possible<String> spectate) {
/* 202 */       this.spectate = spectate;
/*     */     }
/*     */     @JsonProperty("match")
/*     */     public void setMatch(Possible<String> match) {
/* 206 */       this.match = match;
/*     */     }
/*     */     public Possible<String> join() {
/* 209 */       throw new UnsupportedOperationException();
/*     */     } public Possible<String> spectate() {
/* 211 */       throw new UnsupportedOperationException();
/*     */     } public Possible<String> match() {
/* 213 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableActivitySecretsData fromJson(Json json) {
/* 224 */     Builder builder = builder();
/* 225 */     if (json.join != null) {
/* 226 */       builder.join(json.join);
/*     */     }
/* 228 */     if (json.spectate != null) {
/* 229 */       builder.spectate(json.spectate);
/*     */     }
/* 231 */     if (json.match != null) {
/* 232 */       builder.match(json.match);
/*     */     }
/* 234 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableActivitySecretsData of(Possible<String> join, Possible<String> spectate, Possible<String> match) {
/* 245 */     return new ImmutableActivitySecretsData(join, spectate, match);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableActivitySecretsData copyOf(ActivitySecretsData instance) {
/* 256 */     if (instance instanceof ImmutableActivitySecretsData) {
/* 257 */       return (ImmutableActivitySecretsData)instance;
/*     */     }
/* 259 */     return builder()
/* 260 */       .from(instance)
/* 261 */       .build();
/*     */   }
/*     */   
/*     */   public boolean isJoinPresent() {
/* 265 */     return !this.join_absent;
/*     */   }
/*     */   
/*     */   public String joinOrElse(String defaultValue) {
/* 269 */     return !this.join_absent ? this.join_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isSpectatePresent() {
/* 273 */     return !this.spectate_absent;
/*     */   }
/*     */   
/*     */   public String spectateOrElse(String defaultValue) {
/* 277 */     return !this.spectate_absent ? this.spectate_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isMatchPresent() {
/* 281 */     return !this.match_absent;
/*     */   }
/*     */   
/*     */   public String matchOrElse(String defaultValue) {
/* 285 */     return !this.match_absent ? this.match_value : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 300 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "ActivitySecretsData", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/* 312 */     private Possible<String> join_possible = Possible.absent();
/* 313 */     private Possible<String> spectate_possible = Possible.absent();
/* 314 */     private Possible<String> match_possible = Possible.absent();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(ActivitySecretsData instance) {
/* 327 */       Objects.requireNonNull(instance, "instance");
/* 328 */       join(instance.join());
/* 329 */       spectate(instance.spectate());
/* 330 */       match(instance.match());
/* 331 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("join")
/*     */     public Builder join(Possible<String> value) {
/* 336 */       this.join_possible = value;
/* 337 */       return this;
/*     */     }
/*     */     
/*     */     public Builder join(String value) {
/* 341 */       this.join_possible = Possible.of(value);
/* 342 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("spectate")
/*     */     public Builder spectate(Possible<String> value) {
/* 347 */       this.spectate_possible = value;
/* 348 */       return this;
/*     */     }
/*     */     
/*     */     public Builder spectate(String value) {
/* 352 */       this.spectate_possible = Possible.of(value);
/* 353 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("match")
/*     */     public Builder match(Possible<String> value) {
/* 358 */       this.match_possible = value;
/* 359 */       return this;
/*     */     }
/*     */     
/*     */     public Builder match(String value) {
/* 363 */       this.match_possible = Possible.of(value);
/* 364 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableActivitySecretsData build() {
/* 373 */       return new ImmutableActivitySecretsData(null, join_build(), spectate_build(), match_build());
/*     */     }
/*     */     
/*     */     private Possible<String> join_build() {
/* 377 */       return this.join_possible;
/*     */     }
/*     */     
/*     */     private Possible<String> spectate_build() {
/* 381 */       return this.spectate_possible;
/*     */     }
/*     */     
/*     */     private Possible<String> match_build() {
/* 385 */       return this.match_possible;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableActivitySecretsData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */