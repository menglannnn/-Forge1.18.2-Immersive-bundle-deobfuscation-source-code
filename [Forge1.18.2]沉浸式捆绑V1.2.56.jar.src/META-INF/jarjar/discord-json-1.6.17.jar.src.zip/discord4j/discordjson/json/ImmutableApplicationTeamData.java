/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.Id;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "ApplicationTeamData", generator = "Immutables")
/*     */ public final class ImmutableApplicationTeamData
/*     */   implements ApplicationTeamData
/*     */ {
/*     */   private final String icon;
/*     */   private final long id_value;
/*     */   private final List<ApplicationTeamMemberData> members;
/*     */   private final String name;
/*     */   private final long ownerUserId_value;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   private volatile transient InitShim initShim;
/*     */   
/*     */   private ImmutableApplicationTeamData(Optional<String> icon, Id id, Iterable<? extends ApplicationTeamMemberData> members, String name, Id ownerUserId) {
/*  71 */     this.initShim = new InitShim(); this.icon = icon.orElse(null); Id id$impl = id; this.members = createUnmodifiableList(false, createSafeList(members, true, false)); this.name = Objects.<String>requireNonNull(name, "name"); Id ownerUserId$impl = ownerUserId; this.id_value = id$impl.asLong(); this.ownerUserId_value = ownerUserId$impl.asLong(); this.initShim = null; } private ImmutableApplicationTeamData(ImmutableApplicationTeamData original, String icon, Id id, List<ApplicationTeamMemberData> members, String name, Id ownerUserId) { this.initShim = new InitShim(); this.icon = icon; Id id$impl = id; this.members = members;
/*     */     this.name = name;
/*     */     Id ownerUserId$impl = ownerUserId;
/*     */     this.id_value = id$impl.asLong();
/*     */     this.ownerUserId_value = ownerUserId$impl.asLong();
/*  76 */     this.initShim = null; } @Generated(from = "ApplicationTeamData", generator = "Immutables") private final class InitShim { private InitShim() {} private String formatInitCycleMessage() { List<String> attributes = new ArrayList<>();
/*  77 */       return "Cannot build ApplicationTeamData, attribute initializers form cycle " + attributes; }
/*     */      }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("icon")
/*     */   public Optional<String> icon() {
/*  87 */     return Optional.ofNullable(this.icon);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("id")
/*     */   public Id id() {
/*  96 */     return Id.of(this.id_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("members")
/*     */   public List<ApplicationTeamMemberData> members() {
/* 105 */     return this.members;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("name")
/*     */   public String name() {
/* 114 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("owner_user_id")
/*     */   public Id ownerUserId() {
/* 123 */     return Id.of(this.ownerUserId_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableApplicationTeamData withIcon(String value) {
/* 132 */     String newValue = Objects.<String>requireNonNull(value, "icon");
/* 133 */     if (Objects.equals(this.icon, newValue)) return this; 
/* 134 */     return new ImmutableApplicationTeamData(this, newValue, id(), this.members, this.name, ownerUserId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableApplicationTeamData withIcon(Optional<String> optional) {
/* 144 */     String value = optional.orElse(null);
/* 145 */     if (Objects.equals(this.icon, value)) return this; 
/* 146 */     return new ImmutableApplicationTeamData(this, value, id(), this.members, this.name, ownerUserId());
/*     */   }
/*     */   
/*     */   public ImmutableApplicationTeamData withId(long value) {
/* 150 */     Id newValue = Id.of(value);
/* 151 */     return new ImmutableApplicationTeamData(this, this.icon, newValue, this.members, this.name, ownerUserId());
/*     */   }
/*     */   
/*     */   public ImmutableApplicationTeamData withId(String value) {
/* 155 */     Id newValue = Id.of(value);
/* 156 */     return new ImmutableApplicationTeamData(this, this.icon, newValue, this.members, this.name, ownerUserId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableApplicationTeamData withMembers(ApplicationTeamMemberData... elements) {
/* 165 */     List<ApplicationTeamMemberData> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/* 166 */     return new ImmutableApplicationTeamData(this, this.icon, id(), newValue, this.name, ownerUserId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableApplicationTeamData withMembers(Iterable<? extends ApplicationTeamMemberData> elements) {
/* 176 */     if (this.members == elements) return this; 
/* 177 */     List<ApplicationTeamMemberData> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/* 178 */     return new ImmutableApplicationTeamData(this, this.icon, id(), newValue, this.name, ownerUserId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableApplicationTeamData withName(String value) {
/* 188 */     String newValue = Objects.<String>requireNonNull(value, "name");
/* 189 */     if (this.name.equals(newValue)) return this; 
/* 190 */     return new ImmutableApplicationTeamData(this, this.icon, id(), this.members, newValue, ownerUserId());
/*     */   }
/*     */   
/*     */   public ImmutableApplicationTeamData withOwnerUserId(long value) {
/* 194 */     Id newValue = Id.of(value);
/* 195 */     return new ImmutableApplicationTeamData(this, this.icon, id(), this.members, this.name, newValue);
/*     */   }
/*     */   
/*     */   public ImmutableApplicationTeamData withOwnerUserId(String value) {
/* 199 */     Id newValue = Id.of(value);
/* 200 */     return new ImmutableApplicationTeamData(this, this.icon, id(), this.members, this.name, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 209 */     if (this == another) return true; 
/* 210 */     return (another instanceof ImmutableApplicationTeamData && 
/* 211 */       equalTo(0, (ImmutableApplicationTeamData)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableApplicationTeamData another) {
/* 215 */     return (Objects.equals(this.icon, another.icon) && 
/* 216 */       Objects.equals(Long.valueOf(this.id_value), Long.valueOf(another.id_value)) && this.members
/* 217 */       .equals(another.members) && this.name
/* 218 */       .equals(another.name) && 
/* 219 */       Objects.equals(Long.valueOf(this.ownerUserId_value), Long.valueOf(another.ownerUserId_value)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 228 */     int h = 5381;
/* 229 */     h += (h << 5) + Objects.hashCode(this.icon);
/* 230 */     h += (h << 5) + Objects.hashCode(Long.valueOf(this.id_value));
/* 231 */     h += (h << 5) + this.members.hashCode();
/* 232 */     h += (h << 5) + this.name.hashCode();
/* 233 */     h += (h << 5) + Objects.hashCode(Long.valueOf(this.ownerUserId_value));
/* 234 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 243 */     StringBuilder builder = new StringBuilder("ApplicationTeamData{");
/* 244 */     if (this.icon != null) {
/* 245 */       builder.append("icon=").append(this.icon);
/*     */     }
/* 247 */     if (builder.length() > 20) builder.append(", "); 
/* 248 */     builder.append("id=").append(Objects.toString(Long.valueOf(this.id_value)));
/* 249 */     builder.append(", ");
/* 250 */     builder.append("members=").append(this.members);
/* 251 */     builder.append(", ");
/* 252 */     builder.append("name=").append(this.name);
/* 253 */     builder.append(", ");
/* 254 */     builder.append("ownerUserId=").append(Objects.toString(Long.valueOf(this.ownerUserId_value)));
/* 255 */     return builder.append("}").toString();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "ApplicationTeamData", generator = "Immutables")
/*     */   static final class Json
/*     */     implements ApplicationTeamData
/*     */   {
/* 267 */     Optional<String> icon = Optional.empty();
/*     */     Id id;
/* 269 */     List<ApplicationTeamMemberData> members = Collections.emptyList(); String name;
/*     */     Id ownerUserId;
/*     */     
/*     */     @JsonProperty("icon")
/*     */     public void setIcon(Optional<String> icon) {
/* 274 */       this.icon = icon;
/*     */     }
/*     */     @JsonProperty("id")
/*     */     public void setId(Id id) {
/* 278 */       this.id = id;
/*     */     }
/*     */     @JsonProperty("members")
/*     */     public void setMembers(List<ApplicationTeamMemberData> members) {
/* 282 */       this.members = members;
/*     */     }
/*     */     @JsonProperty("name")
/*     */     public void setName(String name) {
/* 286 */       this.name = name;
/*     */     }
/*     */     @JsonProperty("owner_user_id")
/*     */     public void setOwnerUserId(Id ownerUserId) {
/* 290 */       this.ownerUserId = ownerUserId;
/*     */     }
/*     */     public Optional<String> icon() {
/* 293 */       throw new UnsupportedOperationException();
/*     */     } public Id id() {
/* 295 */       throw new UnsupportedOperationException();
/*     */     } public List<ApplicationTeamMemberData> members() {
/* 297 */       throw new UnsupportedOperationException();
/*     */     } public String name() {
/* 299 */       throw new UnsupportedOperationException();
/*     */     } public Id ownerUserId() {
/* 301 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableApplicationTeamData fromJson(Json json) {
/* 312 */     Builder builder = builder();
/* 313 */     if (json.icon != null) {
/* 314 */       builder.icon(json.icon);
/*     */     }
/* 316 */     if (json.id != null) {
/* 317 */       builder.id(json.id);
/*     */     }
/* 319 */     if (json.members != null) {
/* 320 */       builder.addAllMembers(json.members);
/*     */     }
/* 322 */     if (json.name != null) {
/* 323 */       builder.name(json.name);
/*     */     }
/* 325 */     if (json.ownerUserId != null) {
/* 326 */       builder.ownerUserId(json.ownerUserId);
/*     */     }
/* 328 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableApplicationTeamData of(Optional<String> icon, Id id, List<ApplicationTeamMemberData> members, String name, Id ownerUserId) {
/* 341 */     return of(icon, id, members, name, ownerUserId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableApplicationTeamData of(Optional<String> icon, Id id, Iterable<? extends ApplicationTeamMemberData> members, String name, Id ownerUserId) {
/* 354 */     return new ImmutableApplicationTeamData(icon, id, members, name, ownerUserId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableApplicationTeamData copyOf(ApplicationTeamData instance) {
/* 365 */     if (instance instanceof ImmutableApplicationTeamData) {
/* 366 */       return (ImmutableApplicationTeamData)instance;
/*     */     }
/* 368 */     return builder()
/* 369 */       .from(instance)
/* 370 */       .build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 387 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "ApplicationTeamData", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_NAME = 1L;
/*     */ 
/*     */ 
/*     */     
/* 400 */     private long initBits = 1L;
/*     */     
/* 402 */     private Id id_id = null;
/* 403 */     private Id ownerUserId_id = null;
/*     */     private String icon;
/* 405 */     private List<ApplicationTeamMemberData> members = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private String name;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(ApplicationTeamData instance) {
/* 420 */       Objects.requireNonNull(instance, "instance");
/* 421 */       Optional<String> iconOptional = instance.icon();
/* 422 */       if (iconOptional.isPresent()) {
/* 423 */         icon(iconOptional);
/*     */       }
/* 425 */       id(instance.id());
/* 426 */       addAllMembers(instance.members());
/* 427 */       name(instance.name());
/* 428 */       ownerUserId(instance.ownerUserId());
/* 429 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder icon(String icon) {
/* 438 */       this.icon = Objects.<String>requireNonNull(icon, "icon");
/* 439 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("icon")
/*     */     public final Builder icon(Optional<String> icon) {
/* 449 */       this.icon = icon.orElse(null);
/* 450 */       return this;
/*     */     }
/*     */     
/*     */     public Builder id(String value) {
/* 454 */       this.id_id = Id.of(value);
/* 455 */       return this;
/*     */     }
/*     */     
/*     */     public Builder id(long value) {
/* 459 */       this.id_id = Id.of(value);
/* 460 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("id")
/*     */     public Builder id(Id value) {
/* 465 */       this.id_id = value;
/* 466 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder addMember(ApplicationTeamMemberData element) {
/* 475 */       this.members.add(Objects.<ApplicationTeamMemberData>requireNonNull(element, "members element"));
/* 476 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder addMembers(ApplicationTeamMemberData... elements) {
/* 485 */       for (ApplicationTeamMemberData element : elements) {
/* 486 */         this.members.add(Objects.<ApplicationTeamMemberData>requireNonNull(element, "members element"));
/*     */       }
/* 488 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("members")
/*     */     public final Builder members(Iterable<? extends ApplicationTeamMemberData> elements) {
/* 499 */       this.members.clear();
/* 500 */       return addAllMembers(elements);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder addAllMembers(Iterable<? extends ApplicationTeamMemberData> elements) {
/* 509 */       for (ApplicationTeamMemberData element : elements) {
/* 510 */         this.members.add(Objects.<ApplicationTeamMemberData>requireNonNull(element, "members element"));
/*     */       }
/* 512 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("name")
/*     */     public final Builder name(String name) {
/* 522 */       this.name = Objects.<String>requireNonNull(name, "name");
/* 523 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 524 */       return this;
/*     */     }
/*     */     
/*     */     public Builder ownerUserId(String value) {
/* 528 */       this.ownerUserId_id = Id.of(value);
/* 529 */       return this;
/*     */     }
/*     */     
/*     */     public Builder ownerUserId(long value) {
/* 533 */       this.ownerUserId_id = Id.of(value);
/* 534 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("owner_user_id")
/*     */     public Builder ownerUserId(Id value) {
/* 539 */       this.ownerUserId_id = value;
/* 540 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableApplicationTeamData build() {
/* 549 */       if (this.initBits != 0L) {
/* 550 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 552 */       return new ImmutableApplicationTeamData(null, this.icon, id_build(), ImmutableApplicationTeamData.createUnmodifiableList(true, (List)this.members), this.name, ownerUserId_build());
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 556 */       List<String> attributes = new ArrayList<>();
/* 557 */       if ((this.initBits & 0x1L) != 0L) attributes.add("name"); 
/* 558 */       return "Cannot build ApplicationTeamData, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Id id_build() {
/* 562 */       return this.id_id;
/*     */     }
/*     */     
/*     */     private Id ownerUserId_build() {
/* 566 */       return this.ownerUserId_id;
/*     */     }
/*     */     private Builder() {} }
/*     */   
/*     */   private static <T> List<T> createSafeList(Iterable<? extends T> iterable, boolean checkNulls, boolean skipNulls) {
/*     */     ArrayList<T> list;
/* 572 */     if (iterable instanceof Collection) {
/* 573 */       int size = ((Collection)iterable).size();
/* 574 */       if (size == 0) return Collections.emptyList(); 
/* 575 */       list = new ArrayList<>();
/*     */     } else {
/* 577 */       list = new ArrayList<>();
/*     */     } 
/* 579 */     for (T element : iterable) {
/* 580 */       if (skipNulls && element == null)
/* 581 */         continue;  if (checkNulls) Objects.requireNonNull(element, "element"); 
/* 582 */       list.add(element);
/*     */     } 
/* 584 */     return list;
/*     */   }
/*     */   
/*     */   private static <T> List<T> createUnmodifiableList(boolean clone, List<T> list) {
/* 588 */     switch (list.size()) { case 0:
/* 589 */         return Collections.emptyList();
/* 590 */       case 1: return Collections.singletonList(list.get(0)); }
/*     */     
/* 592 */     if (clone) {
/* 593 */       return Collections.unmodifiableList(new ArrayList<>(list));
/*     */     }
/* 595 */     if (list instanceof ArrayList) {
/* 596 */       ((ArrayList)list).trimToSize();
/*     */     }
/* 598 */     return Collections.unmodifiableList(list);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableApplicationTeamData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */