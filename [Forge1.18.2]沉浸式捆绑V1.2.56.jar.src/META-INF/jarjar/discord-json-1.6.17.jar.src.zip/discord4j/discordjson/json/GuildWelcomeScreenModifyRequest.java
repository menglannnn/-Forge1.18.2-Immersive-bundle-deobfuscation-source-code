/*    */ package discord4j.discordjson.json;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonProperty;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import java.util.List;
/*    */ import java.util.Optional;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ 
/*    */ @JsonSerialize(as = ImmutableGuildWelcomeScreenModifyRequest.class)
/*    */ @JsonDeserialize(as = ImmutableGuildWelcomeScreenModifyRequest.class)
/*    */ @Immutable
/*    */ public interface GuildWelcomeScreenModifyRequest
/*    */ {
/*    */   static ImmutableGuildWelcomeScreenModifyRequest.Builder builder() {
/* 18 */     return ImmutableGuildWelcomeScreenModifyRequest.builder();
/*    */   }
/*    */   
/*    */   Possible<Optional<Boolean>> enabled();
/*    */   
/*    */   @JsonProperty("welcome_channels")
/*    */   Possible<Optional<List<WelcomeScreenChannelData>>> welcomeChannels();
/*    */   
/*    */   Possible<Optional<String>> description();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\GuildWelcomeScreenModifyRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */