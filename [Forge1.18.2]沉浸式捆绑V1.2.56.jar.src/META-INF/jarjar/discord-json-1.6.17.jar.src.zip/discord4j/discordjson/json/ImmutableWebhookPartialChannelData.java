/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "WebhookPartialChannelData", generator = "Immutables")
/*     */ public final class ImmutableWebhookPartialChannelData
/*     */   implements WebhookPartialChannelData
/*     */ {
/*     */   private final String id;
/*     */   private final String name;
/*     */   
/*     */   private ImmutableWebhookPartialChannelData(String id, String name) {
/*  29 */     this.id = Objects.<String>requireNonNull(id, "id");
/*  30 */     this.name = Objects.<String>requireNonNull(name, "name");
/*     */   }
/*     */   
/*     */   private ImmutableWebhookPartialChannelData(ImmutableWebhookPartialChannelData original, String id, String name) {
/*  34 */     this.id = id;
/*  35 */     this.name = name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("id")
/*     */   public String id() {
/*  44 */     return this.id;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("name")
/*     */   public String name() {
/*  53 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableWebhookPartialChannelData withId(String value) {
/*  63 */     String newValue = Objects.<String>requireNonNull(value, "id");
/*  64 */     if (this.id.equals(newValue)) return this; 
/*  65 */     return new ImmutableWebhookPartialChannelData(this, newValue, this.name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableWebhookPartialChannelData withName(String value) {
/*  75 */     String newValue = Objects.<String>requireNonNull(value, "name");
/*  76 */     if (this.name.equals(newValue)) return this; 
/*  77 */     return new ImmutableWebhookPartialChannelData(this, this.id, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/*  86 */     if (this == another) return true; 
/*  87 */     return (another instanceof ImmutableWebhookPartialChannelData && 
/*  88 */       equalTo(0, (ImmutableWebhookPartialChannelData)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableWebhookPartialChannelData another) {
/*  92 */     return (this.id.equals(another.id) && this.name
/*  93 */       .equals(another.name));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 102 */     int h = 5381;
/* 103 */     h += (h << 5) + this.id.hashCode();
/* 104 */     h += (h << 5) + this.name.hashCode();
/* 105 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 114 */     return "WebhookPartialChannelData{id=" + this.id + ", name=" + this.name + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "WebhookPartialChannelData", generator = "Immutables")
/*     */   static final class Json
/*     */     implements WebhookPartialChannelData
/*     */   {
/*     */     String id;
/*     */     
/*     */     String name;
/*     */ 
/*     */     
/*     */     @JsonProperty("id")
/*     */     public void setId(String id) {
/* 133 */       this.id = id;
/*     */     }
/*     */     @JsonProperty("name")
/*     */     public void setName(String name) {
/* 137 */       this.name = name;
/*     */     }
/*     */     public String id() {
/* 140 */       throw new UnsupportedOperationException();
/*     */     } public String name() {
/* 142 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableWebhookPartialChannelData fromJson(Json json) {
/* 153 */     Builder builder = builder();
/* 154 */     if (json.id != null) {
/* 155 */       builder.id(json.id);
/*     */     }
/* 157 */     if (json.name != null) {
/* 158 */       builder.name(json.name);
/*     */     }
/* 160 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableWebhookPartialChannelData of(String id, String name) {
/* 170 */     return new ImmutableWebhookPartialChannelData(id, name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableWebhookPartialChannelData copyOf(WebhookPartialChannelData instance) {
/* 181 */     if (instance instanceof ImmutableWebhookPartialChannelData) {
/* 182 */       return (ImmutableWebhookPartialChannelData)instance;
/*     */     }
/* 184 */     return builder()
/* 185 */       .from(instance)
/* 186 */       .build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 200 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "WebhookPartialChannelData", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_ID = 1L;
/*     */ 
/*     */     
/*     */     private static final long INIT_BIT_NAME = 2L;
/*     */ 
/*     */     
/* 214 */     private long initBits = 3L;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private String id;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private String name;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(WebhookPartialChannelData instance) {
/* 230 */       Objects.requireNonNull(instance, "instance");
/* 231 */       id(instance.id());
/* 232 */       name(instance.name());
/* 233 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("id")
/*     */     public final Builder id(String id) {
/* 243 */       this.id = Objects.<String>requireNonNull(id, "id");
/* 244 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 245 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("name")
/*     */     public final Builder name(String name) {
/* 255 */       this.name = Objects.<String>requireNonNull(name, "name");
/* 256 */       this.initBits &= 0xFFFFFFFFFFFFFFFDL;
/* 257 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableWebhookPartialChannelData build() {
/* 266 */       if (this.initBits != 0L) {
/* 267 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 269 */       return new ImmutableWebhookPartialChannelData(null, this.id, this.name);
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 273 */       List<String> attributes = new ArrayList<>();
/* 274 */       if ((this.initBits & 0x1L) != 0L) attributes.add("id"); 
/* 275 */       if ((this.initBits & 0x2L) != 0L) attributes.add("name"); 
/* 276 */       return "Cannot build WebhookPartialChannelData, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableWebhookPartialChannelData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */