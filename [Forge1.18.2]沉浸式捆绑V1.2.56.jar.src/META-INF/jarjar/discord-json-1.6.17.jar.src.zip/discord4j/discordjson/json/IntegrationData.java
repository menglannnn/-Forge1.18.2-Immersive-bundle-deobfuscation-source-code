/*    */ package discord4j.discordjson.json;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonProperty;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import discord4j.discordjson.Id;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ @JsonSerialize(as = ImmutableIntegrationData.class)
/*    */ @JsonDeserialize(as = ImmutableIntegrationData.class)
/*    */ @Immutable
/*    */ public interface IntegrationData
/*    */ {
/*    */   static ImmutableIntegrationData.Builder builder() {
/* 16 */     return ImmutableIntegrationData.builder();
/*    */   }
/*    */   
/*    */   Id id();
/*    */   
/*    */   String name();
/*    */   
/*    */   String type();
/*    */   
/*    */   Possible<Boolean> enabled();
/*    */   
/*    */   Possible<Boolean> syncing();
/*    */   
/*    */   @JsonProperty("role_id")
/*    */   Possible<Id> roleId();
/*    */   
/*    */   @JsonProperty("enable_emoticons")
/*    */   Possible<Boolean> enableEmoticons();
/*    */   
/*    */   @JsonProperty("expire_behavior")
/*    */   Possible<Integer> expireBehavior();
/*    */   
/*    */   @JsonProperty("expire_grace_period")
/*    */   Possible<Integer> expireGracePeriod();
/*    */   
/*    */   Possible<UserData> user();
/*    */   
/*    */   IntegrationAccountData account();
/*    */   
/*    */   @JsonProperty("synced_at")
/*    */   Possible<String> syncedAt();
/*    */   
/*    */   @JsonProperty("subscriber_count")
/*    */   Possible<Integer> subscriberCount();
/*    */   
/*    */   Possible<Boolean> revoked();
/*    */   
/*    */   Possible<IntegrationApplicationData> application();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\IntegrationData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */