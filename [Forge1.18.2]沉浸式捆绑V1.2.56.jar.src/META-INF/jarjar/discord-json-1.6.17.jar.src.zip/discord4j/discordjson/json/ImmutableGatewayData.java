/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "GatewayData", generator = "Immutables")
/*     */ public final class ImmutableGatewayData
/*     */   implements GatewayData
/*     */ {
/*     */   private final String url;
/*     */   private final Integer shards_value;
/*     */   private final boolean shards_absent;
/*     */   private final SessionStartLimitData sessionStartLimit_value;
/*     */   private final boolean sessionStartLimit_absent;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   private volatile transient InitShim initShim;
/*     */   
/*     */   private ImmutableGatewayData(String url, Possible<Integer> shards, Possible<SessionStartLimitData> sessionStartLimit) {
/*  63 */     this.initShim = new InitShim(); this.url = Objects.<String>requireNonNull(url, "url"); Possible<Integer> shards$impl = shards; Possible<SessionStartLimitData> sessionStartLimit$impl = sessionStartLimit; this.shards_value = shards$impl.toOptional().orElse(null); this.shards_absent = shards$impl.isAbsent(); this.sessionStartLimit_value = sessionStartLimit$impl.toOptional().orElse(null); this.sessionStartLimit_absent = sessionStartLimit$impl.isAbsent(); this.initShim = null; } private ImmutableGatewayData(ImmutableGatewayData original, String url, Possible<Integer> shards, Possible<SessionStartLimitData> sessionStartLimit) { this.initShim = new InitShim(); this.url = url; Possible<Integer> shards$impl = shards; Possible<SessionStartLimitData> sessionStartLimit$impl = sessionStartLimit;
/*     */     this.shards_value = shards$impl.toOptional().orElse(null);
/*     */     this.shards_absent = shards$impl.isAbsent();
/*     */     this.sessionStartLimit_value = sessionStartLimit$impl.toOptional().orElse(null);
/*     */     this.sessionStartLimit_absent = sessionStartLimit$impl.isAbsent();
/*  68 */     this.initShim = null; } @Generated(from = "GatewayData", generator = "Immutables") private final class InitShim { private InitShim() {} private String formatInitCycleMessage() { List<String> attributes = new ArrayList<>();
/*  69 */       return "Cannot build GatewayData, attribute initializers form cycle " + attributes; }
/*     */      }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("url")
/*     */   public String url() {
/*  79 */     return this.url;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("shards")
/*     */   public Possible<Integer> shards() {
/*  88 */     return this.shards_absent ? Possible.absent() : Possible.of(this.shards_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("session_start_limit")
/*     */   public Possible<SessionStartLimitData> sessionStartLimit() {
/*  97 */     return this.sessionStartLimit_absent ? Possible.absent() : Possible.of(this.sessionStartLimit_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableGatewayData withUrl(String value) {
/* 107 */     String newValue = Objects.<String>requireNonNull(value, "url");
/* 108 */     if (this.url.equals(newValue)) return this; 
/* 109 */     return new ImmutableGatewayData(this, newValue, shards(), sessionStartLimit());
/*     */   }
/*     */   
/*     */   public ImmutableGatewayData withShards(Possible<Integer> value) {
/* 113 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/* 114 */     return new ImmutableGatewayData(this, this.url, newValue, sessionStartLimit());
/*     */   }
/*     */   
/*     */   public ImmutableGatewayData withShards(Integer value) {
/* 118 */     Possible<Integer> newValue = Possible.of(value);
/* 119 */     return new ImmutableGatewayData(this, this.url, newValue, sessionStartLimit());
/*     */   }
/*     */   
/*     */   public ImmutableGatewayData withSessionStartLimit(Possible<SessionStartLimitData> value) {
/* 123 */     Possible<SessionStartLimitData> newValue = Objects.<Possible<SessionStartLimitData>>requireNonNull(value);
/* 124 */     return new ImmutableGatewayData(this, this.url, shards(), newValue);
/*     */   }
/*     */   
/*     */   public ImmutableGatewayData withSessionStartLimit(SessionStartLimitData value) {
/* 128 */     Possible<SessionStartLimitData> newValue = Possible.of(value);
/* 129 */     return new ImmutableGatewayData(this, this.url, shards(), newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 138 */     if (this == another) return true; 
/* 139 */     return (another instanceof ImmutableGatewayData && 
/* 140 */       equalTo(0, (ImmutableGatewayData)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableGatewayData another) {
/* 144 */     return (this.url.equals(another.url) && 
/* 145 */       shards().equals(another.shards()) && 
/* 146 */       sessionStartLimit().equals(another.sessionStartLimit()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 155 */     int h = 5381;
/* 156 */     h += (h << 5) + this.url.hashCode();
/* 157 */     h += (h << 5) + shards().hashCode();
/* 158 */     h += (h << 5) + sessionStartLimit().hashCode();
/* 159 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 168 */     return "GatewayData{url=" + this.url + ", shards=" + 
/*     */       
/* 170 */       shards().toString() + ", sessionStartLimit=" + 
/* 171 */       sessionStartLimit().toString() + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "GatewayData", generator = "Immutables")
/*     */   static final class Json
/*     */     implements GatewayData
/*     */   {
/*     */     String url;
/*     */ 
/*     */     
/* 186 */     Possible<Integer> shards = Possible.absent();
/*     */ 
/*     */     
/* 189 */     Possible<SessionStartLimitData> sessionStartLimit = Possible.absent();
/*     */     
/*     */     @JsonProperty("url")
/*     */     public void setUrl(String url) {
/* 193 */       this.url = url;
/*     */     }
/*     */     @JsonProperty("shards")
/*     */     public void setShards(Possible<Integer> shards) {
/* 197 */       this.shards = shards;
/*     */     }
/*     */     @JsonProperty("session_start_limit")
/*     */     public void setSessionStartLimit(Possible<SessionStartLimitData> sessionStartLimit) {
/* 201 */       this.sessionStartLimit = sessionStartLimit;
/*     */     }
/*     */     public String url() {
/* 204 */       throw new UnsupportedOperationException();
/*     */     } public Possible<Integer> shards() {
/* 206 */       throw new UnsupportedOperationException();
/*     */     } public Possible<SessionStartLimitData> sessionStartLimit() {
/* 208 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableGatewayData fromJson(Json json) {
/* 219 */     Builder builder = builder();
/* 220 */     if (json.url != null) {
/* 221 */       builder.url(json.url);
/*     */     }
/* 223 */     if (json.shards != null) {
/* 224 */       builder.shards(json.shards);
/*     */     }
/* 226 */     if (json.sessionStartLimit != null) {
/* 227 */       builder.sessionStartLimit(json.sessionStartLimit);
/*     */     }
/* 229 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableGatewayData of(String url, Possible<Integer> shards, Possible<SessionStartLimitData> sessionStartLimit) {
/* 240 */     return new ImmutableGatewayData(url, shards, sessionStartLimit);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableGatewayData copyOf(GatewayData instance) {
/* 251 */     if (instance instanceof ImmutableGatewayData) {
/* 252 */       return (ImmutableGatewayData)instance;
/*     */     }
/* 254 */     return builder()
/* 255 */       .from(instance)
/* 256 */       .build();
/*     */   }
/*     */   
/*     */   public boolean isShardsPresent() {
/* 260 */     return !this.shards_absent;
/*     */   }
/*     */   
/*     */   public Integer shardsOrElse(Integer defaultValue) {
/* 264 */     return !this.shards_absent ? this.shards_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isSessionStartLimitPresent() {
/* 268 */     return !this.sessionStartLimit_absent;
/*     */   }
/*     */   
/*     */   public SessionStartLimitData sessionStartLimitOrElse(SessionStartLimitData defaultValue) {
/* 272 */     return !this.sessionStartLimit_absent ? this.sessionStartLimit_value : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 287 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "GatewayData", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_URL = 1L;
/*     */ 
/*     */ 
/*     */     
/* 300 */     private long initBits = 1L;
/*     */     
/* 302 */     private Possible<Integer> shards_possible = Possible.absent();
/* 303 */     private Possible<SessionStartLimitData> sessionStartLimit_possible = Possible.absent();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private String url;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(GatewayData instance) {
/* 317 */       Objects.requireNonNull(instance, "instance");
/* 318 */       url(instance.url());
/* 319 */       shards(instance.shards());
/* 320 */       sessionStartLimit(instance.sessionStartLimit());
/* 321 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("url")
/*     */     public final Builder url(String url) {
/* 331 */       this.url = Objects.<String>requireNonNull(url, "url");
/* 332 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 333 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("shards")
/*     */     public Builder shards(Possible<Integer> value) {
/* 338 */       this.shards_possible = value;
/* 339 */       return this;
/*     */     }
/*     */     
/*     */     public Builder shards(Integer value) {
/* 343 */       this.shards_possible = Possible.of(value);
/* 344 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("session_start_limit")
/*     */     public Builder sessionStartLimit(Possible<SessionStartLimitData> value) {
/* 349 */       this.sessionStartLimit_possible = value;
/* 350 */       return this;
/*     */     }
/*     */     
/*     */     public Builder sessionStartLimit(SessionStartLimitData value) {
/* 354 */       this.sessionStartLimit_possible = Possible.of(value);
/* 355 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableGatewayData build() {
/* 364 */       if (this.initBits != 0L) {
/* 365 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 367 */       return new ImmutableGatewayData(null, this.url, shards_build(), sessionStartLimit_build());
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 371 */       List<String> attributes = new ArrayList<>();
/* 372 */       if ((this.initBits & 0x1L) != 0L) attributes.add("url"); 
/* 373 */       return "Cannot build GatewayData, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Possible<Integer> shards_build() {
/* 377 */       return this.shards_possible;
/*     */     }
/*     */     
/*     */     private Possible<SessionStartLimitData> sessionStartLimit_build() {
/* 381 */       return this.sessionStartLimit_possible;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableGatewayData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */