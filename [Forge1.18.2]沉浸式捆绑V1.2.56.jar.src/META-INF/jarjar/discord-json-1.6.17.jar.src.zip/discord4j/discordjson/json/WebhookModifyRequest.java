/*    */ package discord4j.discordjson.json;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonProperty;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ @JsonSerialize(as = ImmutableWebhookModifyRequest.class)
/*    */ @JsonDeserialize(as = ImmutableWebhookModifyRequest.class)
/*    */ @Immutable
/*    */ public interface WebhookModifyRequest
/*    */ {
/*    */   static ImmutableWebhookModifyRequest.Builder builder() {
/* 15 */     return ImmutableWebhookModifyRequest.builder();
/*    */   }
/*    */   
/*    */   Possible<String> name();
/*    */   
/*    */   Possible<String> avatar();
/*    */   
/*    */   @JsonProperty("channel_id")
/*    */   Possible<String> channelId();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\WebhookModifyRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */