/*    */ package discord4j.discordjson.json;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonProperty;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ 
/*    */ @JsonSerialize(as = ImmutableGroupDMCreateRequest.class)
/*    */ @JsonDeserialize(as = ImmutableGroupDMCreateRequest.class)
/*    */ @Immutable
/*    */ public interface GroupDMCreateRequest
/*    */ {
/*    */   static ImmutableGroupDMCreateRequest.Builder builder() {
/* 17 */     return ImmutableGroupDMCreateRequest.builder();
/*    */   }
/*    */   
/*    */   @JsonProperty("access_tokens")
/*    */   List<String> accessTokens();
/*    */   
/*    */   Map<String, String> nicks();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\GroupDMCreateRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */