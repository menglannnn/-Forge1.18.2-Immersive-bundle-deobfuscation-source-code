/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "ReactionData", generator = "Immutables")
/*     */ public final class ImmutableReactionData
/*     */   implements ReactionData
/*     */ {
/*     */   private final int count;
/*     */   private final boolean me;
/*     */   private final EmojiData emoji;
/*     */   
/*     */   private ImmutableReactionData(int count, boolean me, EmojiData emoji) {
/*  29 */     this.count = count;
/*  30 */     this.me = me;
/*  31 */     this.emoji = Objects.<EmojiData>requireNonNull(emoji, "emoji");
/*     */   }
/*     */   
/*     */   private ImmutableReactionData(ImmutableReactionData original, int count, boolean me, EmojiData emoji) {
/*  35 */     this.count = count;
/*  36 */     this.me = me;
/*  37 */     this.emoji = emoji;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("count")
/*     */   public int count() {
/*  46 */     return this.count;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("me")
/*     */   public boolean me() {
/*  55 */     return this.me;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("emoji")
/*     */   public EmojiData emoji() {
/*  64 */     return this.emoji;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableReactionData withCount(int value) {
/*  74 */     if (this.count == value) return this; 
/*  75 */     return new ImmutableReactionData(this, value, this.me, this.emoji);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableReactionData withMe(boolean value) {
/*  85 */     if (this.me == value) return this; 
/*  86 */     return new ImmutableReactionData(this, this.count, value, this.emoji);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableReactionData withEmoji(EmojiData value) {
/*  96 */     if (this.emoji == value) return this; 
/*  97 */     EmojiData newValue = Objects.<EmojiData>requireNonNull(value, "emoji");
/*  98 */     return new ImmutableReactionData(this, this.count, this.me, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 107 */     if (this == another) return true; 
/* 108 */     return (another instanceof ImmutableReactionData && 
/* 109 */       equalTo(0, (ImmutableReactionData)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableReactionData another) {
/* 113 */     return (this.count == another.count && this.me == another.me && this.emoji
/*     */       
/* 115 */       .equals(another.emoji));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 124 */     int h = 5381;
/* 125 */     h += (h << 5) + this.count;
/* 126 */     h += (h << 5) + Boolean.hashCode(this.me);
/* 127 */     h += (h << 5) + this.emoji.hashCode();
/* 128 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 137 */     return "ReactionData{count=" + this.count + ", me=" + this.me + ", emoji=" + this.emoji + "}";
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "ReactionData", generator = "Immutables")
/*     */   static final class Json
/*     */     implements ReactionData
/*     */   {
/*     */     int count;
/*     */     
/*     */     boolean countIsSet;
/*     */     
/*     */     boolean me;
/*     */     
/*     */     boolean meIsSet;
/*     */     
/*     */     EmojiData emoji;
/*     */     
/*     */     @JsonProperty("count")
/*     */     public void setCount(int count) {
/* 160 */       this.count = count;
/* 161 */       this.countIsSet = true;
/*     */     }
/*     */     @JsonProperty("me")
/*     */     public void setMe(boolean me) {
/* 165 */       this.me = me;
/* 166 */       this.meIsSet = true;
/*     */     }
/*     */     @JsonProperty("emoji")
/*     */     public void setEmoji(EmojiData emoji) {
/* 170 */       this.emoji = emoji;
/*     */     }
/*     */     public int count() {
/* 173 */       throw new UnsupportedOperationException();
/*     */     } public boolean me() {
/* 175 */       throw new UnsupportedOperationException();
/*     */     } public EmojiData emoji() {
/* 177 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableReactionData fromJson(Json json) {
/* 188 */     Builder builder = builder();
/* 189 */     if (json.countIsSet) {
/* 190 */       builder.count(json.count);
/*     */     }
/* 192 */     if (json.meIsSet) {
/* 193 */       builder.me(json.me);
/*     */     }
/* 195 */     if (json.emoji != null) {
/* 196 */       builder.emoji(json.emoji);
/*     */     }
/* 198 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableReactionData of(int count, boolean me, EmojiData emoji) {
/* 209 */     return new ImmutableReactionData(count, me, emoji);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableReactionData copyOf(ReactionData instance) {
/* 220 */     if (instance instanceof ImmutableReactionData) {
/* 221 */       return (ImmutableReactionData)instance;
/*     */     }
/* 223 */     return builder()
/* 224 */       .from(instance)
/* 225 */       .build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 240 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "ReactionData", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_COUNT = 1L;
/*     */ 
/*     */     
/*     */     private static final long INIT_BIT_ME = 2L;
/*     */     
/*     */     private static final long INIT_BIT_EMOJI = 4L;
/*     */     
/* 255 */     private long initBits = 7L;
/*     */ 
/*     */ 
/*     */     
/*     */     private int count;
/*     */ 
/*     */ 
/*     */     
/*     */     private boolean me;
/*     */ 
/*     */ 
/*     */     
/*     */     private EmojiData emoji;
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(ReactionData instance) {
/* 272 */       Objects.requireNonNull(instance, "instance");
/* 273 */       count(instance.count());
/* 274 */       me(instance.me());
/* 275 */       emoji(instance.emoji());
/* 276 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("count")
/*     */     public final Builder count(int count) {
/* 286 */       this.count = count;
/* 287 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 288 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("me")
/*     */     public final Builder me(boolean me) {
/* 298 */       this.me = me;
/* 299 */       this.initBits &= 0xFFFFFFFFFFFFFFFDL;
/* 300 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("emoji")
/*     */     public final Builder emoji(EmojiData emoji) {
/* 310 */       this.emoji = Objects.<EmojiData>requireNonNull(emoji, "emoji");
/* 311 */       this.initBits &= 0xFFFFFFFFFFFFFFFBL;
/* 312 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableReactionData build() {
/* 321 */       if (this.initBits != 0L) {
/* 322 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 324 */       return new ImmutableReactionData(null, this.count, this.me, this.emoji);
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 328 */       List<String> attributes = new ArrayList<>();
/* 329 */       if ((this.initBits & 0x1L) != 0L) attributes.add("count"); 
/* 330 */       if ((this.initBits & 0x2L) != 0L) attributes.add("me"); 
/* 331 */       if ((this.initBits & 0x4L) != 0L) attributes.add("emoji"); 
/* 332 */       return "Cannot build ReactionData, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableReactionData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */