package discord4j.discordjson.json;

import com.fasterxml.jackson.annotation.JsonProperty;

public interface GuildNsfwLevelField {
  @JsonProperty("nsfw_level")
  int nsfwLevel();
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\GuildNsfwLevelField.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */