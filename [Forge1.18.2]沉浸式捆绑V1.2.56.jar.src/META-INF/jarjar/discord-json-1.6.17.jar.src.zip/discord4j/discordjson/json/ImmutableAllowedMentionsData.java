/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.stream.StreamSupport;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "AllowedMentionsData", generator = "Immutables")
/*     */ public final class ImmutableAllowedMentionsData
/*     */   implements AllowedMentionsData
/*     */ {
/*     */   private final List<String> parse_value;
/*     */   private final boolean parse_absent;
/*     */   private final List<String> roles_value;
/*     */   private final boolean roles_absent;
/*     */   private final List<String> users_value;
/*     */   private final boolean users_absent;
/*     */   private final Boolean repliedUser_value;
/*     */   private final boolean repliedUser_absent;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   
/*     */   private ImmutableAllowedMentionsData(Possible<List<String>> parse, Possible<List<String>> roles, Possible<List<String>> users, Possible<Boolean> repliedUser) {
/*  42 */     Possible<List<String>> parse$impl = parse;
/*  43 */     Possible<List<String>> roles$impl = roles;
/*  44 */     Possible<List<String>> users$impl = users;
/*  45 */     Possible<Boolean> repliedUser$impl = repliedUser;
/*  46 */     this.parse_value = parse$impl.toOptional().orElse(null);
/*  47 */     this.parse_absent = parse$impl.isAbsent();
/*  48 */     this.roles_value = roles$impl.toOptional().orElse(null);
/*  49 */     this.roles_absent = roles$impl.isAbsent();
/*  50 */     this.users_value = users$impl.toOptional().orElse(null);
/*  51 */     this.users_absent = users$impl.isAbsent();
/*  52 */     this.repliedUser_value = repliedUser$impl.toOptional().orElse(null);
/*  53 */     this.repliedUser_absent = repliedUser$impl.isAbsent();
/*  54 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ImmutableAllowedMentionsData(ImmutableAllowedMentionsData original, Possible<List<String>> parse, Possible<List<String>> roles, Possible<List<String>> users, Possible<Boolean> repliedUser) {
/*  63 */     Possible<List<String>> parse$impl = parse;
/*  64 */     Possible<List<String>> roles$impl = roles;
/*  65 */     Possible<List<String>> users$impl = users;
/*  66 */     Possible<Boolean> repliedUser$impl = repliedUser;
/*  67 */     this.parse_value = parse$impl.toOptional().orElse(null);
/*  68 */     this.parse_absent = parse$impl.isAbsent();
/*  69 */     this.roles_value = roles$impl.toOptional().orElse(null);
/*  70 */     this.roles_absent = roles$impl.isAbsent();
/*  71 */     this.users_value = users$impl.toOptional().orElse(null);
/*  72 */     this.users_absent = users$impl.isAbsent();
/*  73 */     this.repliedUser_value = repliedUser$impl.toOptional().orElse(null);
/*  74 */     this.repliedUser_absent = repliedUser$impl.isAbsent();
/*  75 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  81 */   private volatile transient InitShim initShim = new InitShim();
/*     */   
/*     */   @Generated(from = "AllowedMentionsData", generator = "Immutables")
/*     */   private final class InitShim {
/*     */     private String formatInitCycleMessage() {
/*  86 */       List<String> attributes = new ArrayList<>();
/*  87 */       return "Cannot build AllowedMentionsData, attribute initializers form cycle " + attributes;
/*     */     }
/*     */ 
/*     */     
/*     */     private InitShim() {}
/*     */   }
/*     */ 
/*     */   
/*     */   @JsonProperty("parse")
/*     */   public Possible<List<String>> parse() {
/*  97 */     return this.parse_absent ? Possible.absent() : 
/*  98 */       Possible.of(this.parse_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("roles")
/*     */   public Possible<List<String>> roles() {
/* 107 */     return this.roles_absent ? Possible.absent() : 
/* 108 */       Possible.of(this.roles_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("users")
/*     */   public Possible<List<String>> users() {
/* 117 */     return this.users_absent ? Possible.absent() : 
/* 118 */       Possible.of(this.users_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("replied_user")
/*     */   public Possible<Boolean> repliedUser() {
/* 127 */     return this.repliedUser_absent ? Possible.absent() : Possible.of(this.repliedUser_value);
/*     */   }
/*     */   
/*     */   public ImmutableAllowedMentionsData withParse(Possible<List<String>> possible) {
/* 131 */     Possible<List<String>> newValue = Objects.<Possible<List<String>>>requireNonNull(possible);
/* 132 */     return new ImmutableAllowedMentionsData(this, newValue, roles(), users(), repliedUser());
/*     */   }
/*     */   
/*     */   public ImmutableAllowedMentionsData withParse(Iterable<String> elements) {
/* 136 */     Possible<List<String>> newValue = Possible.of(
/* 137 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/* 138 */     return new ImmutableAllowedMentionsData(this, newValue, roles(), users(), repliedUser());
/*     */   }
/*     */   
/*     */   @SafeVarargs
/*     */   public final ImmutableAllowedMentionsData withParse(String... elements) {
/* 143 */     Possible<List<String>> newValue = Possible.of(Arrays.asList(elements));
/* 144 */     return new ImmutableAllowedMentionsData(this, newValue, roles(), users(), repliedUser());
/*     */   }
/*     */   
/*     */   public ImmutableAllowedMentionsData withRoles(Possible<List<String>> possible) {
/* 148 */     Possible<List<String>> newValue = Objects.<Possible<List<String>>>requireNonNull(possible);
/* 149 */     return new ImmutableAllowedMentionsData(this, parse(), newValue, users(), repliedUser());
/*     */   }
/*     */   
/*     */   public ImmutableAllowedMentionsData withRoles(Iterable<String> elements) {
/* 153 */     Possible<List<String>> newValue = Possible.of(
/* 154 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/* 155 */     return new ImmutableAllowedMentionsData(this, parse(), newValue, users(), repliedUser());
/*     */   }
/*     */   
/*     */   @SafeVarargs
/*     */   public final ImmutableAllowedMentionsData withRoles(String... elements) {
/* 160 */     Possible<List<String>> newValue = Possible.of(Arrays.asList(elements));
/* 161 */     return new ImmutableAllowedMentionsData(this, parse(), newValue, users(), repliedUser());
/*     */   }
/*     */   
/*     */   public ImmutableAllowedMentionsData withUsers(Possible<List<String>> possible) {
/* 165 */     Possible<List<String>> newValue = Objects.<Possible<List<String>>>requireNonNull(possible);
/* 166 */     return new ImmutableAllowedMentionsData(this, parse(), roles(), newValue, repliedUser());
/*     */   }
/*     */   
/*     */   public ImmutableAllowedMentionsData withUsers(Iterable<String> elements) {
/* 170 */     Possible<List<String>> newValue = Possible.of(
/* 171 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/* 172 */     return new ImmutableAllowedMentionsData(this, parse(), roles(), newValue, repliedUser());
/*     */   }
/*     */   
/*     */   @SafeVarargs
/*     */   public final ImmutableAllowedMentionsData withUsers(String... elements) {
/* 177 */     Possible<List<String>> newValue = Possible.of(Arrays.asList(elements));
/* 178 */     return new ImmutableAllowedMentionsData(this, parse(), roles(), newValue, repliedUser());
/*     */   }
/*     */   
/*     */   public ImmutableAllowedMentionsData withRepliedUser(Possible<Boolean> value) {
/* 182 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/* 183 */     return new ImmutableAllowedMentionsData(this, parse(), roles(), users(), newValue);
/*     */   }
/*     */   
/*     */   public ImmutableAllowedMentionsData withRepliedUser(Boolean value) {
/* 187 */     Possible<Boolean> newValue = Possible.of(value);
/* 188 */     return new ImmutableAllowedMentionsData(this, parse(), roles(), users(), newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 197 */     if (this == another) return true; 
/* 198 */     return (another instanceof ImmutableAllowedMentionsData && 
/* 199 */       equalTo(0, (ImmutableAllowedMentionsData)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableAllowedMentionsData another) {
/* 203 */     return (Objects.equals(this.parse_value, another.parse_value) && 
/* 204 */       Objects.equals(this.roles_value, another.roles_value) && 
/* 205 */       Objects.equals(this.users_value, another.users_value) && 
/* 206 */       repliedUser().equals(another.repliedUser()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 215 */     int h = 5381;
/* 216 */     h += (h << 5) + Objects.hashCode(this.parse_value);
/* 217 */     h += (h << 5) + Objects.hashCode(this.roles_value);
/* 218 */     h += (h << 5) + Objects.hashCode(this.users_value);
/* 219 */     h += (h << 5) + repliedUser().hashCode();
/* 220 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 229 */     return "AllowedMentionsData{parse=" + 
/* 230 */       Objects.toString(this.parse_value) + ", roles=" + 
/* 231 */       Objects.toString(this.roles_value) + ", users=" + 
/* 232 */       Objects.toString(this.users_value) + ", repliedUser=" + 
/* 233 */       repliedUser().toString() + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "AllowedMentionsData", generator = "Immutables")
/*     */   static final class Json
/*     */     implements AllowedMentionsData
/*     */   {
/* 247 */     Possible<List<String>> parse = Possible.absent();
/*     */ 
/*     */     
/* 250 */     Possible<List<String>> roles = Possible.absent();
/*     */ 
/*     */     
/* 253 */     Possible<List<String>> users = Possible.absent();
/*     */ 
/*     */     
/* 256 */     Possible<Boolean> repliedUser = Possible.absent();
/*     */     
/*     */     @JsonProperty("parse")
/*     */     public void setParse(Possible<List<String>> parse) {
/* 260 */       this.parse = parse;
/*     */     }
/*     */     @JsonProperty("roles")
/*     */     public void setRoles(Possible<List<String>> roles) {
/* 264 */       this.roles = roles;
/*     */     }
/*     */     @JsonProperty("users")
/*     */     public void setUsers(Possible<List<String>> users) {
/* 268 */       this.users = users;
/*     */     }
/*     */     @JsonProperty("replied_user")
/*     */     public void setRepliedUser(Possible<Boolean> repliedUser) {
/* 272 */       this.repliedUser = repliedUser;
/*     */     }
/*     */     public Possible<List<String>> parse() {
/* 275 */       throw new UnsupportedOperationException();
/*     */     } public Possible<List<String>> roles() {
/* 277 */       throw new UnsupportedOperationException();
/*     */     } public Possible<List<String>> users() {
/* 279 */       throw new UnsupportedOperationException();
/*     */     } public Possible<Boolean> repliedUser() {
/* 281 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableAllowedMentionsData fromJson(Json json) {
/* 292 */     Builder builder = builder();
/* 293 */     if (json.parse != null) {
/* 294 */       builder.parse(json.parse);
/*     */     }
/* 296 */     if (json.roles != null) {
/* 297 */       builder.roles(json.roles);
/*     */     }
/* 299 */     if (json.users != null) {
/* 300 */       builder.users(json.users);
/*     */     }
/* 302 */     if (json.repliedUser != null) {
/* 303 */       builder.repliedUser(json.repliedUser);
/*     */     }
/* 305 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableAllowedMentionsData of(Possible<List<String>> parse, Possible<List<String>> roles, Possible<List<String>> users, Possible<Boolean> repliedUser) {
/* 317 */     return new ImmutableAllowedMentionsData(parse, roles, users, repliedUser);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableAllowedMentionsData copyOf(AllowedMentionsData instance) {
/* 328 */     if (instance instanceof ImmutableAllowedMentionsData) {
/* 329 */       return (ImmutableAllowedMentionsData)instance;
/*     */     }
/* 331 */     return builder()
/* 332 */       .from(instance)
/* 333 */       .build();
/*     */   }
/*     */   
/*     */   public boolean isParsePresent() {
/* 337 */     return !this.parse_absent;
/*     */   }
/*     */   
/*     */   public List<String> parseOrElse(List<String> defaultValue) {
/* 341 */     return !this.parse_absent ? this.parse_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isRolesPresent() {
/* 345 */     return !this.roles_absent;
/*     */   }
/*     */   
/*     */   public List<String> rolesOrElse(List<String> defaultValue) {
/* 349 */     return !this.roles_absent ? this.roles_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isUsersPresent() {
/* 353 */     return !this.users_absent;
/*     */   }
/*     */   
/*     */   public List<String> usersOrElse(List<String> defaultValue) {
/* 357 */     return !this.users_absent ? this.users_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isRepliedUserPresent() {
/* 361 */     return !this.repliedUser_absent;
/*     */   }
/*     */   
/*     */   public Boolean repliedUserOrElse(Boolean defaultValue) {
/* 365 */     return !this.repliedUser_absent ? this.repliedUser_value : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 381 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "AllowedMentionsData", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/* 393 */     private List<String> parse_list = null;
/* 394 */     private List<String> roles_list = null;
/* 395 */     private List<String> users_list = null;
/* 396 */     private Possible<Boolean> repliedUser_possible = Possible.absent();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(AllowedMentionsData instance) {
/* 409 */       Objects.requireNonNull(instance, "instance");
/* 410 */       parse(instance.parse());
/* 411 */       roles(instance.roles());
/* 412 */       users(instance.users());
/* 413 */       repliedUser(instance.repliedUser());
/* 414 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addParse(String element) {
/* 418 */       parse_getOrCreate().add(element);
/* 419 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addAllParse(List<String> elements) {
/* 423 */       parse_getOrCreate().addAll(elements);
/* 424 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("parse")
/*     */     public Builder parse(Possible<List<String>> elements) {
/* 429 */       this.parse_list = null;
/* 430 */       elements.toOptional().ifPresent(e -> parse_getOrCreate().addAll(e));
/* 431 */       return this;
/*     */     }
/*     */     
/*     */     public Builder parse(List<String> elements) {
/* 435 */       this.parse_list = new ArrayList<>(elements);
/* 436 */       return this;
/*     */     }
/*     */     
/*     */     public Builder parse(Iterable<String> elements) {
/* 440 */       this.parse_list = (List<String>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/* 441 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addRole(String element) {
/* 445 */       roles_getOrCreate().add(element);
/* 446 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addAllRoles(List<String> elements) {
/* 450 */       roles_getOrCreate().addAll(elements);
/* 451 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("roles")
/*     */     public Builder roles(Possible<List<String>> elements) {
/* 456 */       this.roles_list = null;
/* 457 */       elements.toOptional().ifPresent(e -> roles_getOrCreate().addAll(e));
/* 458 */       return this;
/*     */     }
/*     */     
/*     */     public Builder roles(List<String> elements) {
/* 462 */       this.roles_list = new ArrayList<>(elements);
/* 463 */       return this;
/*     */     }
/*     */     
/*     */     public Builder roles(Iterable<String> elements) {
/* 467 */       this.roles_list = (List<String>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/* 468 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addUser(String element) {
/* 472 */       users_getOrCreate().add(element);
/* 473 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addAllUsers(List<String> elements) {
/* 477 */       users_getOrCreate().addAll(elements);
/* 478 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("users")
/*     */     public Builder users(Possible<List<String>> elements) {
/* 483 */       this.users_list = null;
/* 484 */       elements.toOptional().ifPresent(e -> users_getOrCreate().addAll(e));
/* 485 */       return this;
/*     */     }
/*     */     
/*     */     public Builder users(List<String> elements) {
/* 489 */       this.users_list = new ArrayList<>(elements);
/* 490 */       return this;
/*     */     }
/*     */     
/*     */     public Builder users(Iterable<String> elements) {
/* 494 */       this.users_list = (List<String>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/* 495 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("replied_user")
/*     */     public Builder repliedUser(Possible<Boolean> value) {
/* 500 */       this.repliedUser_possible = value;
/* 501 */       return this;
/*     */     }
/*     */     
/*     */     public Builder repliedUser(Boolean value) {
/* 505 */       this.repliedUser_possible = Possible.of(value);
/* 506 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableAllowedMentionsData build() {
/* 515 */       return new ImmutableAllowedMentionsData(null, parse_build(), roles_build(), users_build(), repliedUser_build());
/*     */     }
/*     */     
/*     */     private Possible<List<String>> parse_build() {
/* 519 */       return (this.parse_list == null) ? Possible.absent() : 
/* 520 */         Possible.of(this.parse_list);
/*     */     }
/*     */     
/*     */     private List<String> parse_getOrCreate() {
/* 524 */       if (this.parse_list == null) {
/* 525 */         this.parse_list = new ArrayList<>();
/*     */       }
/* 527 */       return this.parse_list;
/*     */     }
/*     */     
/*     */     private Possible<List<String>> roles_build() {
/* 531 */       return (this.roles_list == null) ? Possible.absent() : 
/* 532 */         Possible.of(this.roles_list);
/*     */     }
/*     */     
/*     */     private List<String> roles_getOrCreate() {
/* 536 */       if (this.roles_list == null) {
/* 537 */         this.roles_list = new ArrayList<>();
/*     */       }
/* 539 */       return this.roles_list;
/*     */     }
/*     */     
/*     */     private Possible<List<String>> users_build() {
/* 543 */       return (this.users_list == null) ? Possible.absent() : 
/* 544 */         Possible.of(this.users_list);
/*     */     }
/*     */     
/*     */     private List<String> users_getOrCreate() {
/* 548 */       if (this.users_list == null) {
/* 549 */         this.users_list = new ArrayList<>();
/*     */       }
/* 551 */       return this.users_list;
/*     */     }
/*     */     
/*     */     private Possible<Boolean> repliedUser_build() {
/* 555 */       return this.repliedUser_possible;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableAllowedMentionsData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */