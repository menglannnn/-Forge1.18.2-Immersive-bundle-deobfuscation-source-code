/*      */ package discord4j.discordjson.json;
/*      */ 
/*      */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*      */ import com.fasterxml.jackson.annotation.JsonCreator;
/*      */ import com.fasterxml.jackson.annotation.JsonProperty;
/*      */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*      */ import discord4j.discordjson.Id;
/*      */ import discord4j.discordjson.possible.Possible;
/*      */ import java.util.ArrayList;
/*      */ import java.util.List;
/*      */ import java.util.Objects;
/*      */ import org.immutables.value.Generated;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ @Generated(from = "IntegrationData", generator = "Immutables")
/*      */ public final class ImmutableIntegrationData
/*      */   implements IntegrationData
/*      */ {
/*      */   private final long id_value;
/*      */   private final String name;
/*      */   private final String type;
/*      */   private final Boolean enabled_value;
/*      */   private final boolean enabled_absent;
/*      */   private final Boolean syncing_value;
/*      */   private final boolean syncing_absent;
/*      */   private final long roleId_value;
/*      */   private final boolean roleId_absent;
/*      */   private final Boolean enableEmoticons_value;
/*      */   private final boolean enableEmoticons_absent;
/*      */   private final Integer expireBehavior_value;
/*      */   private final boolean expireBehavior_absent;
/*      */   private final Integer expireGracePeriod_value;
/*      */   private final boolean expireGracePeriod_absent;
/*      */   private final UserData user_value;
/*      */   private final boolean user_absent;
/*      */   private final IntegrationAccountData account;
/*      */   private final String syncedAt_value;
/*      */   private final boolean syncedAt_absent;
/*      */   private final Integer subscriberCount_value;
/*      */   private final boolean subscriberCount_absent;
/*      */   private final Boolean revoked_value;
/*      */   private final boolean revoked_absent;
/*      */   private final IntegrationApplicationData application_value;
/*      */   private final boolean application_absent;
/*      */   private static final byte STAGE_INITIALIZING = -1;
/*      */   private static final byte STAGE_UNINITIALIZED = 0;
/*      */   private static final byte STAGE_INITIALIZED = 1;
/*      */   
/*      */   private ImmutableIntegrationData(Id id, String name, String type, Possible<Boolean> enabled, Possible<Boolean> syncing, Possible<Id> roleId, Possible<Boolean> enableEmoticons, Possible<Integer> expireBehavior, Possible<Integer> expireGracePeriod, Possible<UserData> user, IntegrationAccountData account, Possible<String> syncedAt, Possible<Integer> subscriberCount, Possible<Boolean> revoked, Possible<IntegrationApplicationData> application) {
/*   69 */     Id id$impl = id;
/*   70 */     this.name = Objects.<String>requireNonNull(name, "name");
/*   71 */     this.type = Objects.<String>requireNonNull(type, "type");
/*   72 */     Possible<Boolean> enabled$impl = enabled;
/*   73 */     Possible<Boolean> syncing$impl = syncing;
/*   74 */     Possible<Id> roleId$impl = roleId;
/*   75 */     Possible<Boolean> enableEmoticons$impl = enableEmoticons;
/*   76 */     Possible<Integer> expireBehavior$impl = expireBehavior;
/*   77 */     Possible<Integer> expireGracePeriod$impl = expireGracePeriod;
/*   78 */     Possible<UserData> user$impl = user;
/*   79 */     this.account = Objects.<IntegrationAccountData>requireNonNull(account, "account");
/*   80 */     Possible<String> syncedAt$impl = syncedAt;
/*   81 */     Possible<Integer> subscriberCount$impl = subscriberCount;
/*   82 */     Possible<Boolean> revoked$impl = revoked;
/*   83 */     Possible<IntegrationApplicationData> application$impl = application;
/*   84 */     this.id_value = id$impl.asLong();
/*   85 */     this.enabled_value = enabled$impl.toOptional().orElse(null);
/*   86 */     this.enabled_absent = enabled$impl.isAbsent();
/*   87 */     this.syncing_value = syncing$impl.toOptional().orElse(null);
/*   88 */     this.syncing_absent = syncing$impl.isAbsent();
/*   89 */     this
/*      */       
/*   91 */       .roleId_value = ((Long)roleId$impl.toOptional().map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*   92 */     this.roleId_absent = roleId$impl.isAbsent();
/*   93 */     this.enableEmoticons_value = enableEmoticons$impl.toOptional().orElse(null);
/*   94 */     this.enableEmoticons_absent = enableEmoticons$impl.isAbsent();
/*   95 */     this.expireBehavior_value = expireBehavior$impl.toOptional().orElse(null);
/*   96 */     this.expireBehavior_absent = expireBehavior$impl.isAbsent();
/*   97 */     this.expireGracePeriod_value = expireGracePeriod$impl.toOptional().orElse(null);
/*   98 */     this.expireGracePeriod_absent = expireGracePeriod$impl.isAbsent();
/*   99 */     this.user_value = user$impl.toOptional().orElse(null);
/*  100 */     this.user_absent = user$impl.isAbsent();
/*  101 */     this.syncedAt_value = syncedAt$impl.toOptional().orElse(null);
/*  102 */     this.syncedAt_absent = syncedAt$impl.isAbsent();
/*  103 */     this.subscriberCount_value = subscriberCount$impl.toOptional().orElse(null);
/*  104 */     this.subscriberCount_absent = subscriberCount$impl.isAbsent();
/*  105 */     this.revoked_value = revoked$impl.toOptional().orElse(null);
/*  106 */     this.revoked_absent = revoked$impl.isAbsent();
/*  107 */     this.application_value = application$impl.toOptional().orElse(null);
/*  108 */     this.application_absent = application$impl.isAbsent();
/*  109 */     this.initShim = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ImmutableIntegrationData(ImmutableIntegrationData original, Id id, String name, String type, Possible<Boolean> enabled, Possible<Boolean> syncing, Possible<Id> roleId, Possible<Boolean> enableEmoticons, Possible<Integer> expireBehavior, Possible<Integer> expireGracePeriod, Possible<UserData> user, IntegrationAccountData account, Possible<String> syncedAt, Possible<Integer> subscriberCount, Possible<Boolean> revoked, Possible<IntegrationApplicationData> application) {
/*  129 */     Id id$impl = id;
/*  130 */     this.name = name;
/*  131 */     this.type = type;
/*  132 */     Possible<Boolean> enabled$impl = enabled;
/*  133 */     Possible<Boolean> syncing$impl = syncing;
/*  134 */     Possible<Id> roleId$impl = roleId;
/*  135 */     Possible<Boolean> enableEmoticons$impl = enableEmoticons;
/*  136 */     Possible<Integer> expireBehavior$impl = expireBehavior;
/*  137 */     Possible<Integer> expireGracePeriod$impl = expireGracePeriod;
/*  138 */     Possible<UserData> user$impl = user;
/*  139 */     this.account = account;
/*  140 */     Possible<String> syncedAt$impl = syncedAt;
/*  141 */     Possible<Integer> subscriberCount$impl = subscriberCount;
/*  142 */     Possible<Boolean> revoked$impl = revoked;
/*  143 */     Possible<IntegrationApplicationData> application$impl = application;
/*  144 */     this.id_value = id$impl.asLong();
/*  145 */     this.enabled_value = enabled$impl.toOptional().orElse(null);
/*  146 */     this.enabled_absent = enabled$impl.isAbsent();
/*  147 */     this.syncing_value = syncing$impl.toOptional().orElse(null);
/*  148 */     this.syncing_absent = syncing$impl.isAbsent();
/*  149 */     this
/*      */       
/*  151 */       .roleId_value = ((Long)roleId$impl.toOptional().map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  152 */     this.roleId_absent = roleId$impl.isAbsent();
/*  153 */     this.enableEmoticons_value = enableEmoticons$impl.toOptional().orElse(null);
/*  154 */     this.enableEmoticons_absent = enableEmoticons$impl.isAbsent();
/*  155 */     this.expireBehavior_value = expireBehavior$impl.toOptional().orElse(null);
/*  156 */     this.expireBehavior_absent = expireBehavior$impl.isAbsent();
/*  157 */     this.expireGracePeriod_value = expireGracePeriod$impl.toOptional().orElse(null);
/*  158 */     this.expireGracePeriod_absent = expireGracePeriod$impl.isAbsent();
/*  159 */     this.user_value = user$impl.toOptional().orElse(null);
/*  160 */     this.user_absent = user$impl.isAbsent();
/*  161 */     this.syncedAt_value = syncedAt$impl.toOptional().orElse(null);
/*  162 */     this.syncedAt_absent = syncedAt$impl.isAbsent();
/*  163 */     this.subscriberCount_value = subscriberCount$impl.toOptional().orElse(null);
/*  164 */     this.subscriberCount_absent = subscriberCount$impl.isAbsent();
/*  165 */     this.revoked_value = revoked$impl.toOptional().orElse(null);
/*  166 */     this.revoked_absent = revoked$impl.isAbsent();
/*  167 */     this.application_value = application$impl.toOptional().orElse(null);
/*  168 */     this.application_absent = application$impl.isAbsent();
/*  169 */     this.initShim = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  175 */   private volatile transient InitShim initShim = new InitShim();
/*      */   
/*      */   @Generated(from = "IntegrationData", generator = "Immutables")
/*      */   private final class InitShim {
/*      */     private String formatInitCycleMessage() {
/*  180 */       List<String> attributes = new ArrayList<>();
/*  181 */       return "Cannot build IntegrationData, attribute initializers form cycle " + attributes;
/*      */     }
/*      */ 
/*      */     
/*      */     private InitShim() {}
/*      */   }
/*      */ 
/*      */   
/*      */   @JsonProperty("id")
/*      */   public Id id() {
/*  191 */     return Id.of(this.id_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("name")
/*      */   public String name() {
/*  200 */     return this.name;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("type")
/*      */   public String type() {
/*  209 */     return this.type;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("enabled")
/*      */   public Possible<Boolean> enabled() {
/*  218 */     return this.enabled_absent ? Possible.absent() : Possible.of(this.enabled_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("syncing")
/*      */   public Possible<Boolean> syncing() {
/*  227 */     return this.syncing_absent ? Possible.absent() : Possible.of(this.syncing_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("role_id")
/*      */   public Possible<Id> roleId() {
/*  236 */     return this.roleId_absent ? Possible.absent() : 
/*  237 */       Possible.of(Id.of(this.roleId_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("enable_emoticons")
/*      */   public Possible<Boolean> enableEmoticons() {
/*  246 */     return this.enableEmoticons_absent ? Possible.absent() : Possible.of(this.enableEmoticons_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("expire_behavior")
/*      */   public Possible<Integer> expireBehavior() {
/*  255 */     return this.expireBehavior_absent ? Possible.absent() : Possible.of(this.expireBehavior_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("expire_grace_period")
/*      */   public Possible<Integer> expireGracePeriod() {
/*  264 */     return this.expireGracePeriod_absent ? Possible.absent() : Possible.of(this.expireGracePeriod_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("user")
/*      */   public Possible<UserData> user() {
/*  273 */     return this.user_absent ? Possible.absent() : Possible.of(this.user_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("account")
/*      */   public IntegrationAccountData account() {
/*  282 */     return this.account;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("synced_at")
/*      */   public Possible<String> syncedAt() {
/*  291 */     return this.syncedAt_absent ? Possible.absent() : Possible.of(this.syncedAt_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("subscriber_count")
/*      */   public Possible<Integer> subscriberCount() {
/*  300 */     return this.subscriberCount_absent ? Possible.absent() : Possible.of(this.subscriberCount_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("revoked")
/*      */   public Possible<Boolean> revoked() {
/*  309 */     return this.revoked_absent ? Possible.absent() : Possible.of(this.revoked_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("application")
/*      */   public Possible<IntegrationApplicationData> application() {
/*  318 */     return this.application_absent ? Possible.absent() : Possible.of(this.application_value);
/*      */   }
/*      */   
/*      */   public ImmutableIntegrationData withId(long value) {
/*  322 */     Id newValue = Id.of(value);
/*  323 */     return new ImmutableIntegrationData(this, newValue, this.name, this.type, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  328 */         enabled(), 
/*  329 */         syncing(), 
/*  330 */         roleId(), 
/*  331 */         enableEmoticons(), 
/*  332 */         expireBehavior(), 
/*  333 */         expireGracePeriod(), 
/*  334 */         user(), this.account, 
/*      */         
/*  336 */         syncedAt(), 
/*  337 */         subscriberCount(), 
/*  338 */         revoked(), 
/*  339 */         application());
/*      */   }
/*      */   
/*      */   public ImmutableIntegrationData withId(String value) {
/*  343 */     Id newValue = Id.of(value);
/*  344 */     return new ImmutableIntegrationData(this, newValue, this.name, this.type, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  349 */         enabled(), 
/*  350 */         syncing(), 
/*  351 */         roleId(), 
/*  352 */         enableEmoticons(), 
/*  353 */         expireBehavior(), 
/*  354 */         expireGracePeriod(), 
/*  355 */         user(), this.account, 
/*      */         
/*  357 */         syncedAt(), 
/*  358 */         subscriberCount(), 
/*  359 */         revoked(), 
/*  360 */         application());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableIntegrationData withName(String value) {
/*  370 */     String newValue = Objects.<String>requireNonNull(value, "name");
/*  371 */     if (this.name.equals(newValue)) return this; 
/*  372 */     return new ImmutableIntegrationData(this, 
/*      */         
/*  374 */         id(), newValue, this.type, 
/*      */ 
/*      */         
/*  377 */         enabled(), 
/*  378 */         syncing(), 
/*  379 */         roleId(), 
/*  380 */         enableEmoticons(), 
/*  381 */         expireBehavior(), 
/*  382 */         expireGracePeriod(), 
/*  383 */         user(), this.account, 
/*      */         
/*  385 */         syncedAt(), 
/*  386 */         subscriberCount(), 
/*  387 */         revoked(), 
/*  388 */         application());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableIntegrationData withType(String value) {
/*  398 */     String newValue = Objects.<String>requireNonNull(value, "type");
/*  399 */     if (this.type.equals(newValue)) return this; 
/*  400 */     return new ImmutableIntegrationData(this, 
/*      */         
/*  402 */         id(), this.name, newValue, 
/*      */ 
/*      */         
/*  405 */         enabled(), 
/*  406 */         syncing(), 
/*  407 */         roleId(), 
/*  408 */         enableEmoticons(), 
/*  409 */         expireBehavior(), 
/*  410 */         expireGracePeriod(), 
/*  411 */         user(), this.account, 
/*      */         
/*  413 */         syncedAt(), 
/*  414 */         subscriberCount(), 
/*  415 */         revoked(), 
/*  416 */         application());
/*      */   }
/*      */   
/*      */   public ImmutableIntegrationData withEnabled(Possible<Boolean> value) {
/*  420 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/*  421 */     return new ImmutableIntegrationData(this, 
/*      */         
/*  423 */         id(), this.name, this.type, newValue, 
/*      */ 
/*      */ 
/*      */         
/*  427 */         syncing(), 
/*  428 */         roleId(), 
/*  429 */         enableEmoticons(), 
/*  430 */         expireBehavior(), 
/*  431 */         expireGracePeriod(), 
/*  432 */         user(), this.account, 
/*      */         
/*  434 */         syncedAt(), 
/*  435 */         subscriberCount(), 
/*  436 */         revoked(), 
/*  437 */         application());
/*      */   }
/*      */   
/*      */   public ImmutableIntegrationData withEnabled(Boolean value) {
/*  441 */     Possible<Boolean> newValue = Possible.of(value);
/*  442 */     return new ImmutableIntegrationData(this, 
/*      */         
/*  444 */         id(), this.name, this.type, newValue, 
/*      */ 
/*      */ 
/*      */         
/*  448 */         syncing(), 
/*  449 */         roleId(), 
/*  450 */         enableEmoticons(), 
/*  451 */         expireBehavior(), 
/*  452 */         expireGracePeriod(), 
/*  453 */         user(), this.account, 
/*      */         
/*  455 */         syncedAt(), 
/*  456 */         subscriberCount(), 
/*  457 */         revoked(), 
/*  458 */         application());
/*      */   }
/*      */   
/*      */   public ImmutableIntegrationData withSyncing(Possible<Boolean> value) {
/*  462 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/*  463 */     return new ImmutableIntegrationData(this, 
/*      */         
/*  465 */         id(), this.name, this.type, 
/*      */ 
/*      */         
/*  468 */         enabled(), newValue, 
/*      */         
/*  470 */         roleId(), 
/*  471 */         enableEmoticons(), 
/*  472 */         expireBehavior(), 
/*  473 */         expireGracePeriod(), 
/*  474 */         user(), this.account, 
/*      */         
/*  476 */         syncedAt(), 
/*  477 */         subscriberCount(), 
/*  478 */         revoked(), 
/*  479 */         application());
/*      */   }
/*      */   
/*      */   public ImmutableIntegrationData withSyncing(Boolean value) {
/*  483 */     Possible<Boolean> newValue = Possible.of(value);
/*  484 */     return new ImmutableIntegrationData(this, 
/*      */         
/*  486 */         id(), this.name, this.type, 
/*      */ 
/*      */         
/*  489 */         enabled(), newValue, 
/*      */         
/*  491 */         roleId(), 
/*  492 */         enableEmoticons(), 
/*  493 */         expireBehavior(), 
/*  494 */         expireGracePeriod(), 
/*  495 */         user(), this.account, 
/*      */         
/*  497 */         syncedAt(), 
/*  498 */         subscriberCount(), 
/*  499 */         revoked(), 
/*  500 */         application());
/*      */   }
/*      */   
/*      */   public ImmutableIntegrationData withRoleId(Possible<Id> value) {
/*  504 */     Possible<Id> newValue = Objects.<Possible<Id>>requireNonNull(value);
/*  505 */     return new ImmutableIntegrationData(this, 
/*      */         
/*  507 */         id(), this.name, this.type, 
/*      */ 
/*      */         
/*  510 */         enabled(), 
/*  511 */         syncing(), newValue, 
/*      */         
/*  513 */         enableEmoticons(), 
/*  514 */         expireBehavior(), 
/*  515 */         expireGracePeriod(), 
/*  516 */         user(), this.account, 
/*      */         
/*  518 */         syncedAt(), 
/*  519 */         subscriberCount(), 
/*  520 */         revoked(), 
/*  521 */         application());
/*      */   }
/*      */   
/*      */   public ImmutableIntegrationData withRoleId(long value) {
/*  525 */     Possible<Id> newValue = Possible.of(Id.of(value));
/*  526 */     return new ImmutableIntegrationData(this, 
/*      */         
/*  528 */         id(), this.name, this.type, 
/*      */ 
/*      */         
/*  531 */         enabled(), 
/*  532 */         syncing(), newValue, 
/*      */         
/*  534 */         enableEmoticons(), 
/*  535 */         expireBehavior(), 
/*  536 */         expireGracePeriod(), 
/*  537 */         user(), this.account, 
/*      */         
/*  539 */         syncedAt(), 
/*  540 */         subscriberCount(), 
/*  541 */         revoked(), 
/*  542 */         application());
/*      */   }
/*      */   
/*      */   public ImmutableIntegrationData withEnableEmoticons(Possible<Boolean> value) {
/*  546 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/*  547 */     return new ImmutableIntegrationData(this, 
/*      */         
/*  549 */         id(), this.name, this.type, 
/*      */ 
/*      */         
/*  552 */         enabled(), 
/*  553 */         syncing(), 
/*  554 */         roleId(), newValue, 
/*      */         
/*  556 */         expireBehavior(), 
/*  557 */         expireGracePeriod(), 
/*  558 */         user(), this.account, 
/*      */         
/*  560 */         syncedAt(), 
/*  561 */         subscriberCount(), 
/*  562 */         revoked(), 
/*  563 */         application());
/*      */   }
/*      */   
/*      */   public ImmutableIntegrationData withEnableEmoticons(Boolean value) {
/*  567 */     Possible<Boolean> newValue = Possible.of(value);
/*  568 */     return new ImmutableIntegrationData(this, 
/*      */         
/*  570 */         id(), this.name, this.type, 
/*      */ 
/*      */         
/*  573 */         enabled(), 
/*  574 */         syncing(), 
/*  575 */         roleId(), newValue, 
/*      */         
/*  577 */         expireBehavior(), 
/*  578 */         expireGracePeriod(), 
/*  579 */         user(), this.account, 
/*      */         
/*  581 */         syncedAt(), 
/*  582 */         subscriberCount(), 
/*  583 */         revoked(), 
/*  584 */         application());
/*      */   }
/*      */   
/*      */   public ImmutableIntegrationData withExpireBehavior(Possible<Integer> value) {
/*  588 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/*  589 */     return new ImmutableIntegrationData(this, 
/*      */         
/*  591 */         id(), this.name, this.type, 
/*      */ 
/*      */         
/*  594 */         enabled(), 
/*  595 */         syncing(), 
/*  596 */         roleId(), 
/*  597 */         enableEmoticons(), newValue, 
/*      */         
/*  599 */         expireGracePeriod(), 
/*  600 */         user(), this.account, 
/*      */         
/*  602 */         syncedAt(), 
/*  603 */         subscriberCount(), 
/*  604 */         revoked(), 
/*  605 */         application());
/*      */   }
/*      */   
/*      */   public ImmutableIntegrationData withExpireBehavior(Integer value) {
/*  609 */     Possible<Integer> newValue = Possible.of(value);
/*  610 */     return new ImmutableIntegrationData(this, 
/*      */         
/*  612 */         id(), this.name, this.type, 
/*      */ 
/*      */         
/*  615 */         enabled(), 
/*  616 */         syncing(), 
/*  617 */         roleId(), 
/*  618 */         enableEmoticons(), newValue, 
/*      */         
/*  620 */         expireGracePeriod(), 
/*  621 */         user(), this.account, 
/*      */         
/*  623 */         syncedAt(), 
/*  624 */         subscriberCount(), 
/*  625 */         revoked(), 
/*  626 */         application());
/*      */   }
/*      */   
/*      */   public ImmutableIntegrationData withExpireGracePeriod(Possible<Integer> value) {
/*  630 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/*  631 */     return new ImmutableIntegrationData(this, 
/*      */         
/*  633 */         id(), this.name, this.type, 
/*      */ 
/*      */         
/*  636 */         enabled(), 
/*  637 */         syncing(), 
/*  638 */         roleId(), 
/*  639 */         enableEmoticons(), 
/*  640 */         expireBehavior(), newValue, 
/*      */         
/*  642 */         user(), this.account, 
/*      */         
/*  644 */         syncedAt(), 
/*  645 */         subscriberCount(), 
/*  646 */         revoked(), 
/*  647 */         application());
/*      */   }
/*      */   
/*      */   public ImmutableIntegrationData withExpireGracePeriod(Integer value) {
/*  651 */     Possible<Integer> newValue = Possible.of(value);
/*  652 */     return new ImmutableIntegrationData(this, 
/*      */         
/*  654 */         id(), this.name, this.type, 
/*      */ 
/*      */         
/*  657 */         enabled(), 
/*  658 */         syncing(), 
/*  659 */         roleId(), 
/*  660 */         enableEmoticons(), 
/*  661 */         expireBehavior(), newValue, 
/*      */         
/*  663 */         user(), this.account, 
/*      */         
/*  665 */         syncedAt(), 
/*  666 */         subscriberCount(), 
/*  667 */         revoked(), 
/*  668 */         application());
/*      */   }
/*      */   
/*      */   public ImmutableIntegrationData withUser(Possible<UserData> value) {
/*  672 */     Possible<UserData> newValue = Objects.<Possible<UserData>>requireNonNull(value);
/*  673 */     return new ImmutableIntegrationData(this, 
/*      */         
/*  675 */         id(), this.name, this.type, 
/*      */ 
/*      */         
/*  678 */         enabled(), 
/*  679 */         syncing(), 
/*  680 */         roleId(), 
/*  681 */         enableEmoticons(), 
/*  682 */         expireBehavior(), 
/*  683 */         expireGracePeriod(), newValue, this.account, 
/*      */ 
/*      */         
/*  686 */         syncedAt(), 
/*  687 */         subscriberCount(), 
/*  688 */         revoked(), 
/*  689 */         application());
/*      */   }
/*      */   
/*      */   public ImmutableIntegrationData withUser(UserData value) {
/*  693 */     Possible<UserData> newValue = Possible.of(value);
/*  694 */     return new ImmutableIntegrationData(this, 
/*      */         
/*  696 */         id(), this.name, this.type, 
/*      */ 
/*      */         
/*  699 */         enabled(), 
/*  700 */         syncing(), 
/*  701 */         roleId(), 
/*  702 */         enableEmoticons(), 
/*  703 */         expireBehavior(), 
/*  704 */         expireGracePeriod(), newValue, this.account, 
/*      */ 
/*      */         
/*  707 */         syncedAt(), 
/*  708 */         subscriberCount(), 
/*  709 */         revoked(), 
/*  710 */         application());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableIntegrationData withAccount(IntegrationAccountData value) {
/*  720 */     if (this.account == value) return this; 
/*  721 */     IntegrationAccountData newValue = Objects.<IntegrationAccountData>requireNonNull(value, "account");
/*  722 */     return new ImmutableIntegrationData(this, 
/*      */         
/*  724 */         id(), this.name, this.type, 
/*      */ 
/*      */         
/*  727 */         enabled(), 
/*  728 */         syncing(), 
/*  729 */         roleId(), 
/*  730 */         enableEmoticons(), 
/*  731 */         expireBehavior(), 
/*  732 */         expireGracePeriod(), 
/*  733 */         user(), newValue, 
/*      */         
/*  735 */         syncedAt(), 
/*  736 */         subscriberCount(), 
/*  737 */         revoked(), 
/*  738 */         application());
/*      */   }
/*      */   
/*      */   public ImmutableIntegrationData withSyncedAt(Possible<String> value) {
/*  742 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/*  743 */     return new ImmutableIntegrationData(this, 
/*      */         
/*  745 */         id(), this.name, this.type, 
/*      */ 
/*      */         
/*  748 */         enabled(), 
/*  749 */         syncing(), 
/*  750 */         roleId(), 
/*  751 */         enableEmoticons(), 
/*  752 */         expireBehavior(), 
/*  753 */         expireGracePeriod(), 
/*  754 */         user(), this.account, newValue, 
/*      */ 
/*      */         
/*  757 */         subscriberCount(), 
/*  758 */         revoked(), 
/*  759 */         application());
/*      */   }
/*      */   
/*      */   public ImmutableIntegrationData withSyncedAt(String value) {
/*  763 */     Possible<String> newValue = Possible.of(value);
/*  764 */     return new ImmutableIntegrationData(this, 
/*      */         
/*  766 */         id(), this.name, this.type, 
/*      */ 
/*      */         
/*  769 */         enabled(), 
/*  770 */         syncing(), 
/*  771 */         roleId(), 
/*  772 */         enableEmoticons(), 
/*  773 */         expireBehavior(), 
/*  774 */         expireGracePeriod(), 
/*  775 */         user(), this.account, newValue, 
/*      */ 
/*      */         
/*  778 */         subscriberCount(), 
/*  779 */         revoked(), 
/*  780 */         application());
/*      */   }
/*      */   
/*      */   public ImmutableIntegrationData withSubscriberCount(Possible<Integer> value) {
/*  784 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/*  785 */     return new ImmutableIntegrationData(this, 
/*      */         
/*  787 */         id(), this.name, this.type, 
/*      */ 
/*      */         
/*  790 */         enabled(), 
/*  791 */         syncing(), 
/*  792 */         roleId(), 
/*  793 */         enableEmoticons(), 
/*  794 */         expireBehavior(), 
/*  795 */         expireGracePeriod(), 
/*  796 */         user(), this.account, 
/*      */         
/*  798 */         syncedAt(), newValue, 
/*      */         
/*  800 */         revoked(), 
/*  801 */         application());
/*      */   }
/*      */   
/*      */   public ImmutableIntegrationData withSubscriberCount(Integer value) {
/*  805 */     Possible<Integer> newValue = Possible.of(value);
/*  806 */     return new ImmutableIntegrationData(this, 
/*      */         
/*  808 */         id(), this.name, this.type, 
/*      */ 
/*      */         
/*  811 */         enabled(), 
/*  812 */         syncing(), 
/*  813 */         roleId(), 
/*  814 */         enableEmoticons(), 
/*  815 */         expireBehavior(), 
/*  816 */         expireGracePeriod(), 
/*  817 */         user(), this.account, 
/*      */         
/*  819 */         syncedAt(), newValue, 
/*      */         
/*  821 */         revoked(), 
/*  822 */         application());
/*      */   }
/*      */   
/*      */   public ImmutableIntegrationData withRevoked(Possible<Boolean> value) {
/*  826 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/*  827 */     return new ImmutableIntegrationData(this, 
/*      */         
/*  829 */         id(), this.name, this.type, 
/*      */ 
/*      */         
/*  832 */         enabled(), 
/*  833 */         syncing(), 
/*  834 */         roleId(), 
/*  835 */         enableEmoticons(), 
/*  836 */         expireBehavior(), 
/*  837 */         expireGracePeriod(), 
/*  838 */         user(), this.account, 
/*      */         
/*  840 */         syncedAt(), 
/*  841 */         subscriberCount(), newValue, 
/*      */         
/*  843 */         application());
/*      */   }
/*      */   
/*      */   public ImmutableIntegrationData withRevoked(Boolean value) {
/*  847 */     Possible<Boolean> newValue = Possible.of(value);
/*  848 */     return new ImmutableIntegrationData(this, 
/*      */         
/*  850 */         id(), this.name, this.type, 
/*      */ 
/*      */         
/*  853 */         enabled(), 
/*  854 */         syncing(), 
/*  855 */         roleId(), 
/*  856 */         enableEmoticons(), 
/*  857 */         expireBehavior(), 
/*  858 */         expireGracePeriod(), 
/*  859 */         user(), this.account, 
/*      */         
/*  861 */         syncedAt(), 
/*  862 */         subscriberCount(), newValue, 
/*      */         
/*  864 */         application());
/*      */   }
/*      */   
/*      */   public ImmutableIntegrationData withApplication(Possible<IntegrationApplicationData> value) {
/*  868 */     Possible<IntegrationApplicationData> newValue = Objects.<Possible<IntegrationApplicationData>>requireNonNull(value);
/*  869 */     return new ImmutableIntegrationData(this, 
/*      */         
/*  871 */         id(), this.name, this.type, 
/*      */ 
/*      */         
/*  874 */         enabled(), 
/*  875 */         syncing(), 
/*  876 */         roleId(), 
/*  877 */         enableEmoticons(), 
/*  878 */         expireBehavior(), 
/*  879 */         expireGracePeriod(), 
/*  880 */         user(), this.account, 
/*      */         
/*  882 */         syncedAt(), 
/*  883 */         subscriberCount(), 
/*  884 */         revoked(), newValue);
/*      */   }
/*      */ 
/*      */   
/*      */   public ImmutableIntegrationData withApplication(IntegrationApplicationData value) {
/*  889 */     Possible<IntegrationApplicationData> newValue = Possible.of(value);
/*  890 */     return new ImmutableIntegrationData(this, 
/*      */         
/*  892 */         id(), this.name, this.type, 
/*      */ 
/*      */         
/*  895 */         enabled(), 
/*  896 */         syncing(), 
/*  897 */         roleId(), 
/*  898 */         enableEmoticons(), 
/*  899 */         expireBehavior(), 
/*  900 */         expireGracePeriod(), 
/*  901 */         user(), this.account, 
/*      */         
/*  903 */         syncedAt(), 
/*  904 */         subscriberCount(), 
/*  905 */         revoked(), newValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean equals(Object another) {
/*  915 */     if (this == another) return true; 
/*  916 */     return (another instanceof ImmutableIntegrationData && 
/*  917 */       equalTo(0, (ImmutableIntegrationData)another));
/*      */   }
/*      */   
/*      */   private boolean equalTo(int synthetic, ImmutableIntegrationData another) {
/*  921 */     return (Objects.equals(Long.valueOf(this.id_value), Long.valueOf(another.id_value)) && this.name
/*  922 */       .equals(another.name) && this.type
/*  923 */       .equals(another.type) && 
/*  924 */       enabled().equals(another.enabled()) && 
/*  925 */       syncing().equals(another.syncing()) && 
/*  926 */       roleId().equals(another.roleId()) && 
/*  927 */       enableEmoticons().equals(another.enableEmoticons()) && 
/*  928 */       expireBehavior().equals(another.expireBehavior()) && 
/*  929 */       expireGracePeriod().equals(another.expireGracePeriod()) && 
/*  930 */       user().equals(another.user()) && this.account
/*  931 */       .equals(another.account) && 
/*  932 */       syncedAt().equals(another.syncedAt()) && 
/*  933 */       subscriberCount().equals(another.subscriberCount()) && 
/*  934 */       revoked().equals(another.revoked()) && 
/*  935 */       application().equals(another.application()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int hashCode() {
/*  944 */     int h = 5381;
/*  945 */     h += (h << 5) + Objects.hashCode(Long.valueOf(this.id_value));
/*  946 */     h += (h << 5) + this.name.hashCode();
/*  947 */     h += (h << 5) + this.type.hashCode();
/*  948 */     h += (h << 5) + enabled().hashCode();
/*  949 */     h += (h << 5) + syncing().hashCode();
/*  950 */     h += (h << 5) + roleId().hashCode();
/*  951 */     h += (h << 5) + enableEmoticons().hashCode();
/*  952 */     h += (h << 5) + expireBehavior().hashCode();
/*  953 */     h += (h << 5) + expireGracePeriod().hashCode();
/*  954 */     h += (h << 5) + user().hashCode();
/*  955 */     h += (h << 5) + this.account.hashCode();
/*  956 */     h += (h << 5) + syncedAt().hashCode();
/*  957 */     h += (h << 5) + subscriberCount().hashCode();
/*  958 */     h += (h << 5) + revoked().hashCode();
/*  959 */     h += (h << 5) + application().hashCode();
/*  960 */     return h;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/*  969 */     return "IntegrationData{id=" + 
/*  970 */       Objects.toString(Long.valueOf(this.id_value)) + ", name=" + this.name + ", type=" + this.type + ", enabled=" + 
/*      */ 
/*      */       
/*  973 */       enabled().toString() + ", syncing=" + 
/*  974 */       syncing().toString() + ", roleId=" + 
/*  975 */       roleId().toString() + ", enableEmoticons=" + 
/*  976 */       enableEmoticons().toString() + ", expireBehavior=" + 
/*  977 */       expireBehavior().toString() + ", expireGracePeriod=" + 
/*  978 */       expireGracePeriod().toString() + ", user=" + 
/*  979 */       user().toString() + ", account=" + this.account + ", syncedAt=" + 
/*      */       
/*  981 */       syncedAt().toString() + ", subscriberCount=" + 
/*  982 */       subscriberCount().toString() + ", revoked=" + 
/*  983 */       revoked().toString() + ", application=" + 
/*  984 */       application().toString() + "}";
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonDeserialize
/*      */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*      */   @Generated(from = "IntegrationData", generator = "Immutables")
/*      */   static final class Json
/*      */     implements IntegrationData
/*      */   {
/*      */     Id id;
/*      */     
/*      */     String name;
/*      */     
/*      */     String type;
/*      */     
/* 1001 */     Possible<Boolean> enabled = Possible.absent();
/*      */ 
/*      */     
/* 1004 */     Possible<Boolean> syncing = Possible.absent();
/*      */ 
/*      */     
/* 1007 */     Possible<Id> roleId = Possible.absent();
/*      */ 
/*      */     
/* 1010 */     Possible<Boolean> enableEmoticons = Possible.absent();
/*      */ 
/*      */     
/* 1013 */     Possible<Integer> expireBehavior = Possible.absent();
/*      */ 
/*      */     
/* 1016 */     Possible<Integer> expireGracePeriod = Possible.absent();
/*      */ 
/*      */     
/* 1019 */     Possible<UserData> user = Possible.absent();
/*      */     
/*      */     IntegrationAccountData account;
/*      */     
/* 1023 */     Possible<String> syncedAt = Possible.absent();
/*      */ 
/*      */     
/* 1026 */     Possible<Integer> subscriberCount = Possible.absent();
/*      */ 
/*      */     
/* 1029 */     Possible<Boolean> revoked = Possible.absent();
/*      */ 
/*      */     
/* 1032 */     Possible<IntegrationApplicationData> application = Possible.absent();
/*      */     
/*      */     @JsonProperty("id")
/*      */     public void setId(Id id) {
/* 1036 */       this.id = id;
/*      */     }
/*      */     @JsonProperty("name")
/*      */     public void setName(String name) {
/* 1040 */       this.name = name;
/*      */     }
/*      */     @JsonProperty("type")
/*      */     public void setType(String type) {
/* 1044 */       this.type = type;
/*      */     }
/*      */     @JsonProperty("enabled")
/*      */     public void setEnabled(Possible<Boolean> enabled) {
/* 1048 */       this.enabled = enabled;
/*      */     }
/*      */     @JsonProperty("syncing")
/*      */     public void setSyncing(Possible<Boolean> syncing) {
/* 1052 */       this.syncing = syncing;
/*      */     }
/*      */     @JsonProperty("role_id")
/*      */     public void setRoleId(Possible<Id> roleId) {
/* 1056 */       this.roleId = roleId;
/*      */     }
/*      */     @JsonProperty("enable_emoticons")
/*      */     public void setEnableEmoticons(Possible<Boolean> enableEmoticons) {
/* 1060 */       this.enableEmoticons = enableEmoticons;
/*      */     }
/*      */     @JsonProperty("expire_behavior")
/*      */     public void setExpireBehavior(Possible<Integer> expireBehavior) {
/* 1064 */       this.expireBehavior = expireBehavior;
/*      */     }
/*      */     @JsonProperty("expire_grace_period")
/*      */     public void setExpireGracePeriod(Possible<Integer> expireGracePeriod) {
/* 1068 */       this.expireGracePeriod = expireGracePeriod;
/*      */     }
/*      */     @JsonProperty("user")
/*      */     public void setUser(Possible<UserData> user) {
/* 1072 */       this.user = user;
/*      */     }
/*      */     @JsonProperty("account")
/*      */     public void setAccount(IntegrationAccountData account) {
/* 1076 */       this.account = account;
/*      */     }
/*      */     @JsonProperty("synced_at")
/*      */     public void setSyncedAt(Possible<String> syncedAt) {
/* 1080 */       this.syncedAt = syncedAt;
/*      */     }
/*      */     @JsonProperty("subscriber_count")
/*      */     public void setSubscriberCount(Possible<Integer> subscriberCount) {
/* 1084 */       this.subscriberCount = subscriberCount;
/*      */     }
/*      */     @JsonProperty("revoked")
/*      */     public void setRevoked(Possible<Boolean> revoked) {
/* 1088 */       this.revoked = revoked;
/*      */     }
/*      */     @JsonProperty("application")
/*      */     public void setApplication(Possible<IntegrationApplicationData> application) {
/* 1092 */       this.application = application;
/*      */     }
/*      */     public Id id() {
/* 1095 */       throw new UnsupportedOperationException();
/*      */     } public String name() {
/* 1097 */       throw new UnsupportedOperationException();
/*      */     } public String type() {
/* 1099 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Boolean> enabled() {
/* 1101 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Boolean> syncing() {
/* 1103 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Id> roleId() {
/* 1105 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Boolean> enableEmoticons() {
/* 1107 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Integer> expireBehavior() {
/* 1109 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Integer> expireGracePeriod() {
/* 1111 */       throw new UnsupportedOperationException();
/*      */     } public Possible<UserData> user() {
/* 1113 */       throw new UnsupportedOperationException();
/*      */     } public IntegrationAccountData account() {
/* 1115 */       throw new UnsupportedOperationException();
/*      */     } public Possible<String> syncedAt() {
/* 1117 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Integer> subscriberCount() {
/* 1119 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Boolean> revoked() {
/* 1121 */       throw new UnsupportedOperationException();
/*      */     } public Possible<IntegrationApplicationData> application() {
/* 1123 */       throw new UnsupportedOperationException();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*      */   static ImmutableIntegrationData fromJson(Json json) {
/* 1134 */     Builder builder = builder();
/* 1135 */     if (json.id != null) {
/* 1136 */       builder.id(json.id);
/*      */     }
/* 1138 */     if (json.name != null) {
/* 1139 */       builder.name(json.name);
/*      */     }
/* 1141 */     if (json.type != null) {
/* 1142 */       builder.type(json.type);
/*      */     }
/* 1144 */     if (json.enabled != null) {
/* 1145 */       builder.enabled(json.enabled);
/*      */     }
/* 1147 */     if (json.syncing != null) {
/* 1148 */       builder.syncing(json.syncing);
/*      */     }
/* 1150 */     if (json.roleId != null) {
/* 1151 */       builder.roleId(json.roleId);
/*      */     }
/* 1153 */     if (json.enableEmoticons != null) {
/* 1154 */       builder.enableEmoticons(json.enableEmoticons);
/*      */     }
/* 1156 */     if (json.expireBehavior != null) {
/* 1157 */       builder.expireBehavior(json.expireBehavior);
/*      */     }
/* 1159 */     if (json.expireGracePeriod != null) {
/* 1160 */       builder.expireGracePeriod(json.expireGracePeriod);
/*      */     }
/* 1162 */     if (json.user != null) {
/* 1163 */       builder.user(json.user);
/*      */     }
/* 1165 */     if (json.account != null) {
/* 1166 */       builder.account(json.account);
/*      */     }
/* 1168 */     if (json.syncedAt != null) {
/* 1169 */       builder.syncedAt(json.syncedAt);
/*      */     }
/* 1171 */     if (json.subscriberCount != null) {
/* 1172 */       builder.subscriberCount(json.subscriberCount);
/*      */     }
/* 1174 */     if (json.revoked != null) {
/* 1175 */       builder.revoked(json.revoked);
/*      */     }
/* 1177 */     if (json.application != null) {
/* 1178 */       builder.application(json.application);
/*      */     }
/* 1180 */     return builder.build();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableIntegrationData of(Id id, String name, String type, Possible<Boolean> enabled, Possible<Boolean> syncing, Possible<Id> roleId, Possible<Boolean> enableEmoticons, Possible<Integer> expireBehavior, Possible<Integer> expireGracePeriod, Possible<UserData> user, IntegrationAccountData account, Possible<String> syncedAt, Possible<Integer> subscriberCount, Possible<Boolean> revoked, Possible<IntegrationApplicationData> application) {
/* 1203 */     return new ImmutableIntegrationData(id, name, type, enabled, syncing, roleId, enableEmoticons, expireBehavior, expireGracePeriod, user, account, syncedAt, subscriberCount, revoked, application);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableIntegrationData copyOf(IntegrationData instance) {
/* 1214 */     if (instance instanceof ImmutableIntegrationData) {
/* 1215 */       return (ImmutableIntegrationData)instance;
/*      */     }
/* 1217 */     return builder()
/* 1218 */       .from(instance)
/* 1219 */       .build();
/*      */   }
/*      */   
/*      */   public boolean isEnabledPresent() {
/* 1223 */     return !this.enabled_absent;
/*      */   }
/*      */   
/*      */   public Boolean enabledOrElse(Boolean defaultValue) {
/* 1227 */     return !this.enabled_absent ? this.enabled_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isSyncingPresent() {
/* 1231 */     return !this.syncing_absent;
/*      */   }
/*      */   
/*      */   public Boolean syncingOrElse(Boolean defaultValue) {
/* 1235 */     return !this.syncing_absent ? this.syncing_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isRoleIdPresent() {
/* 1239 */     return !this.roleId_absent;
/*      */   }
/*      */   
/*      */   public long roleIdOrElse(long defaultValue) {
/* 1243 */     return !this.roleId_absent ? this.roleId_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isEnableEmoticonsPresent() {
/* 1247 */     return !this.enableEmoticons_absent;
/*      */   }
/*      */   
/*      */   public Boolean enableEmoticonsOrElse(Boolean defaultValue) {
/* 1251 */     return !this.enableEmoticons_absent ? this.enableEmoticons_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isExpireBehaviorPresent() {
/* 1255 */     return !this.expireBehavior_absent;
/*      */   }
/*      */   
/*      */   public Integer expireBehaviorOrElse(Integer defaultValue) {
/* 1259 */     return !this.expireBehavior_absent ? this.expireBehavior_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isExpireGracePeriodPresent() {
/* 1263 */     return !this.expireGracePeriod_absent;
/*      */   }
/*      */   
/*      */   public Integer expireGracePeriodOrElse(Integer defaultValue) {
/* 1267 */     return !this.expireGracePeriod_absent ? this.expireGracePeriod_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isUserPresent() {
/* 1271 */     return !this.user_absent;
/*      */   }
/*      */   
/*      */   public UserData userOrElse(UserData defaultValue) {
/* 1275 */     return !this.user_absent ? this.user_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isSyncedAtPresent() {
/* 1279 */     return !this.syncedAt_absent;
/*      */   }
/*      */   
/*      */   public String syncedAtOrElse(String defaultValue) {
/* 1283 */     return !this.syncedAt_absent ? this.syncedAt_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isSubscriberCountPresent() {
/* 1287 */     return !this.subscriberCount_absent;
/*      */   }
/*      */   
/*      */   public Integer subscriberCountOrElse(Integer defaultValue) {
/* 1291 */     return !this.subscriberCount_absent ? this.subscriberCount_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isRevokedPresent() {
/* 1295 */     return !this.revoked_absent;
/*      */   }
/*      */   
/*      */   public Boolean revokedOrElse(Boolean defaultValue) {
/* 1299 */     return !this.revoked_absent ? this.revoked_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isApplicationPresent() {
/* 1303 */     return !this.application_absent;
/*      */   }
/*      */   
/*      */   public IntegrationApplicationData applicationOrElse(IntegrationApplicationData defaultValue) {
/* 1307 */     return !this.application_absent ? this.application_value : defaultValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Builder builder() {
/* 1334 */     return new Builder();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   @Generated(from = "IntegrationData", generator = "Immutables")
/*      */   public static final class Builder
/*      */   {
/*      */     private static final long INIT_BIT_NAME = 1L;
/*      */ 
/*      */     
/*      */     private static final long INIT_BIT_TYPE = 2L;
/*      */     
/*      */     private static final long INIT_BIT_ACCOUNT = 4L;
/*      */     
/* 1349 */     private long initBits = 7L;
/*      */     
/* 1351 */     private Id id_id = null;
/* 1352 */     private Possible<Boolean> enabled_possible = Possible.absent();
/* 1353 */     private Possible<Boolean> syncing_possible = Possible.absent();
/* 1354 */     private Possible<Id> roleId_possible = Possible.absent();
/* 1355 */     private Possible<Boolean> enableEmoticons_possible = Possible.absent();
/* 1356 */     private Possible<Integer> expireBehavior_possible = Possible.absent();
/* 1357 */     private Possible<Integer> expireGracePeriod_possible = Possible.absent();
/* 1358 */     private Possible<UserData> user_possible = Possible.absent();
/* 1359 */     private Possible<String> syncedAt_possible = Possible.absent();
/* 1360 */     private Possible<Integer> subscriberCount_possible = Possible.absent();
/* 1361 */     private Possible<Boolean> revoked_possible = Possible.absent();
/* 1362 */     private Possible<IntegrationApplicationData> application_possible = Possible.absent();
/*      */ 
/*      */ 
/*      */     
/*      */     private String name;
/*      */ 
/*      */ 
/*      */     
/*      */     private String type;
/*      */ 
/*      */     
/*      */     private IntegrationAccountData account;
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder from(IntegrationData instance) {
/* 1378 */       Objects.requireNonNull(instance, "instance");
/* 1379 */       id(instance.id());
/* 1380 */       name(instance.name());
/* 1381 */       type(instance.type());
/* 1382 */       enabled(instance.enabled());
/* 1383 */       syncing(instance.syncing());
/* 1384 */       roleId(instance.roleId());
/* 1385 */       enableEmoticons(instance.enableEmoticons());
/* 1386 */       expireBehavior(instance.expireBehavior());
/* 1387 */       expireGracePeriod(instance.expireGracePeriod());
/* 1388 */       user(instance.user());
/* 1389 */       account(instance.account());
/* 1390 */       syncedAt(instance.syncedAt());
/* 1391 */       subscriberCount(instance.subscriberCount());
/* 1392 */       revoked(instance.revoked());
/* 1393 */       application(instance.application());
/* 1394 */       return this;
/*      */     }
/*      */     
/*      */     public Builder id(String value) {
/* 1398 */       this.id_id = Id.of(value);
/* 1399 */       return this;
/*      */     }
/*      */     
/*      */     public Builder id(long value) {
/* 1403 */       this.id_id = Id.of(value);
/* 1404 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("id")
/*      */     public Builder id(Id value) {
/* 1409 */       this.id_id = value;
/* 1410 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("name")
/*      */     public final Builder name(String name) {
/* 1420 */       this.name = Objects.<String>requireNonNull(name, "name");
/* 1421 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 1422 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("type")
/*      */     public final Builder type(String type) {
/* 1432 */       this.type = Objects.<String>requireNonNull(type, "type");
/* 1433 */       this.initBits &= 0xFFFFFFFFFFFFFFFDL;
/* 1434 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("enabled")
/*      */     public Builder enabled(Possible<Boolean> value) {
/* 1439 */       this.enabled_possible = value;
/* 1440 */       return this;
/*      */     }
/*      */     
/*      */     public Builder enabled(Boolean value) {
/* 1444 */       this.enabled_possible = Possible.of(value);
/* 1445 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("syncing")
/*      */     public Builder syncing(Possible<Boolean> value) {
/* 1450 */       this.syncing_possible = value;
/* 1451 */       return this;
/*      */     }
/*      */     
/*      */     public Builder syncing(Boolean value) {
/* 1455 */       this.syncing_possible = Possible.of(value);
/* 1456 */       return this;
/*      */     }
/*      */     
/*      */     public Builder roleId(String value) {
/* 1460 */       this.roleId_possible = Possible.of(Id.of(value));
/* 1461 */       return this;
/*      */     }
/*      */     
/*      */     public Builder roleId(long value) {
/* 1465 */       this.roleId_possible = Possible.of(Id.of(value));
/* 1466 */       return this;
/*      */     }
/*      */     
/*      */     public Builder roleId(Id value) {
/* 1470 */       this.roleId_possible = Possible.of(value);
/* 1471 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("role_id")
/*      */     public Builder roleId(Possible<Id> value) {
/* 1476 */       this.roleId_possible = value;
/* 1477 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("enable_emoticons")
/*      */     public Builder enableEmoticons(Possible<Boolean> value) {
/* 1482 */       this.enableEmoticons_possible = value;
/* 1483 */       return this;
/*      */     }
/*      */     
/*      */     public Builder enableEmoticons(Boolean value) {
/* 1487 */       this.enableEmoticons_possible = Possible.of(value);
/* 1488 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("expire_behavior")
/*      */     public Builder expireBehavior(Possible<Integer> value) {
/* 1493 */       this.expireBehavior_possible = value;
/* 1494 */       return this;
/*      */     }
/*      */     
/*      */     public Builder expireBehavior(Integer value) {
/* 1498 */       this.expireBehavior_possible = Possible.of(value);
/* 1499 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("expire_grace_period")
/*      */     public Builder expireGracePeriod(Possible<Integer> value) {
/* 1504 */       this.expireGracePeriod_possible = value;
/* 1505 */       return this;
/*      */     }
/*      */     
/*      */     public Builder expireGracePeriod(Integer value) {
/* 1509 */       this.expireGracePeriod_possible = Possible.of(value);
/* 1510 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("user")
/*      */     public Builder user(Possible<UserData> value) {
/* 1515 */       this.user_possible = value;
/* 1516 */       return this;
/*      */     }
/*      */     
/*      */     public Builder user(UserData value) {
/* 1520 */       this.user_possible = Possible.of(value);
/* 1521 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("account")
/*      */     public final Builder account(IntegrationAccountData account) {
/* 1531 */       this.account = Objects.<IntegrationAccountData>requireNonNull(account, "account");
/* 1532 */       this.initBits &= 0xFFFFFFFFFFFFFFFBL;
/* 1533 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("synced_at")
/*      */     public Builder syncedAt(Possible<String> value) {
/* 1538 */       this.syncedAt_possible = value;
/* 1539 */       return this;
/*      */     }
/*      */     
/*      */     public Builder syncedAt(String value) {
/* 1543 */       this.syncedAt_possible = Possible.of(value);
/* 1544 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("subscriber_count")
/*      */     public Builder subscriberCount(Possible<Integer> value) {
/* 1549 */       this.subscriberCount_possible = value;
/* 1550 */       return this;
/*      */     }
/*      */     
/*      */     public Builder subscriberCount(Integer value) {
/* 1554 */       this.subscriberCount_possible = Possible.of(value);
/* 1555 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("revoked")
/*      */     public Builder revoked(Possible<Boolean> value) {
/* 1560 */       this.revoked_possible = value;
/* 1561 */       return this;
/*      */     }
/*      */     
/*      */     public Builder revoked(Boolean value) {
/* 1565 */       this.revoked_possible = Possible.of(value);
/* 1566 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("application")
/*      */     public Builder application(Possible<IntegrationApplicationData> value) {
/* 1571 */       this.application_possible = value;
/* 1572 */       return this;
/*      */     }
/*      */     
/*      */     public Builder application(IntegrationApplicationData value) {
/* 1576 */       this.application_possible = Possible.of(value);
/* 1577 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ImmutableIntegrationData build() {
/* 1586 */       if (this.initBits != 0L) {
/* 1587 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*      */       }
/* 1589 */       return new ImmutableIntegrationData(null, 
/*      */           
/* 1591 */           id_build(), this.name, this.type, 
/*      */ 
/*      */           
/* 1594 */           enabled_build(), 
/* 1595 */           syncing_build(), 
/* 1596 */           roleId_build(), 
/* 1597 */           enableEmoticons_build(), 
/* 1598 */           expireBehavior_build(), 
/* 1599 */           expireGracePeriod_build(), 
/* 1600 */           user_build(), this.account, 
/*      */           
/* 1602 */           syncedAt_build(), 
/* 1603 */           subscriberCount_build(), 
/* 1604 */           revoked_build(), 
/* 1605 */           application_build());
/*      */     }
/*      */     
/*      */     private String formatRequiredAttributesMessage() {
/* 1609 */       List<String> attributes = new ArrayList<>();
/* 1610 */       if ((this.initBits & 0x1L) != 0L) attributes.add("name"); 
/* 1611 */       if ((this.initBits & 0x2L) != 0L) attributes.add("type"); 
/* 1612 */       if ((this.initBits & 0x4L) != 0L) attributes.add("account"); 
/* 1613 */       return "Cannot build IntegrationData, some of required attributes are not set " + attributes;
/*      */     }
/*      */     
/*      */     private Id id_build() {
/* 1617 */       return this.id_id;
/*      */     }
/*      */     
/*      */     private Possible<Boolean> enabled_build() {
/* 1621 */       return this.enabled_possible;
/*      */     }
/*      */     
/*      */     private Possible<Boolean> syncing_build() {
/* 1625 */       return this.syncing_possible;
/*      */     }
/*      */     
/*      */     private Possible<Id> roleId_build() {
/* 1629 */       return this.roleId_possible;
/*      */     }
/*      */     
/*      */     private Possible<Boolean> enableEmoticons_build() {
/* 1633 */       return this.enableEmoticons_possible;
/*      */     }
/*      */     
/*      */     private Possible<Integer> expireBehavior_build() {
/* 1637 */       return this.expireBehavior_possible;
/*      */     }
/*      */     
/*      */     private Possible<Integer> expireGracePeriod_build() {
/* 1641 */       return this.expireGracePeriod_possible;
/*      */     }
/*      */     
/*      */     private Possible<UserData> user_build() {
/* 1645 */       return this.user_possible;
/*      */     }
/*      */     
/*      */     private Possible<String> syncedAt_build() {
/* 1649 */       return this.syncedAt_possible;
/*      */     }
/*      */     
/*      */     private Possible<Integer> subscriberCount_build() {
/* 1653 */       return this.subscriberCount_possible;
/*      */     }
/*      */     
/*      */     private Possible<Boolean> revoked_build() {
/* 1657 */       return this.revoked_possible;
/*      */     }
/*      */     
/*      */     private Possible<IntegrationApplicationData> application_build() {
/* 1661 */       return this.application_possible;
/*      */     }
/*      */     
/*      */     private Builder() {}
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableIntegrationData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */