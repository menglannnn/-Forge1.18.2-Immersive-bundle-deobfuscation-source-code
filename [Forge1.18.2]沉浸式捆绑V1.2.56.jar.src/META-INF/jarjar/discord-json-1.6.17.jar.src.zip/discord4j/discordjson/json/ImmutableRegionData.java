/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "RegionData", generator = "Immutables")
/*     */ public final class ImmutableRegionData
/*     */   implements RegionData
/*     */ {
/*     */   private final String id;
/*     */   private final String name;
/*     */   private final Boolean vip_value;
/*     */   private final boolean vip_absent;
/*     */   private final boolean optimal;
/*     */   private final boolean deprecated;
/*     */   private final boolean custom;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   private volatile transient InitShim initShim;
/*     */   
/*     */   private ImmutableRegionData(String id, String name, Possible<Boolean> vip, boolean optimal, boolean deprecated, boolean custom) {
/*  73 */     this.initShim = new InitShim(); this.id = Objects.<String>requireNonNull(id, "id"); this.name = Objects.<String>requireNonNull(name, "name"); Possible<Boolean> vip$impl = vip; this.optimal = optimal; this.deprecated = deprecated; this.custom = custom; this.vip_value = vip$impl.toOptional().orElse(null); this.vip_absent = vip$impl.isAbsent(); this.initShim = null; } private ImmutableRegionData(ImmutableRegionData original, String id, String name, Possible<Boolean> vip, boolean optimal, boolean deprecated, boolean custom) { this.initShim = new InitShim(); this.id = id; this.name = name; Possible<Boolean> vip$impl = vip; this.optimal = optimal;
/*     */     this.deprecated = deprecated;
/*     */     this.custom = custom;
/*     */     this.vip_value = vip$impl.toOptional().orElse(null);
/*     */     this.vip_absent = vip$impl.isAbsent();
/*  78 */     this.initShim = null; } @Generated(from = "RegionData", generator = "Immutables") private final class InitShim { private InitShim() {} private String formatInitCycleMessage() { List<String> attributes = new ArrayList<>();
/*  79 */       return "Cannot build RegionData, attribute initializers form cycle " + attributes; }
/*     */      }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("id")
/*     */   public String id() {
/*  89 */     return this.id;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("name")
/*     */   public String name() {
/*  98 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("vip")
/*     */   public Possible<Boolean> vip() {
/* 107 */     return this.vip_absent ? Possible.absent() : Possible.of(this.vip_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("optimal")
/*     */   public boolean optimal() {
/* 116 */     return this.optimal;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("deprecated")
/*     */   public boolean deprecated() {
/* 125 */     return this.deprecated;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("custom")
/*     */   public boolean custom() {
/* 134 */     return this.custom;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableRegionData withId(String value) {
/* 144 */     String newValue = Objects.<String>requireNonNull(value, "id");
/* 145 */     if (this.id.equals(newValue)) return this; 
/* 146 */     return new ImmutableRegionData(this, newValue, this.name, vip(), this.optimal, this.deprecated, this.custom);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableRegionData withName(String value) {
/* 156 */     String newValue = Objects.<String>requireNonNull(value, "name");
/* 157 */     if (this.name.equals(newValue)) return this; 
/* 158 */     return new ImmutableRegionData(this, this.id, newValue, vip(), this.optimal, this.deprecated, this.custom);
/*     */   }
/*     */   
/*     */   public ImmutableRegionData withVip(Possible<Boolean> value) {
/* 162 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/* 163 */     return new ImmutableRegionData(this, this.id, this.name, newValue, this.optimal, this.deprecated, this.custom);
/*     */   }
/*     */   
/*     */   public ImmutableRegionData withVip(Boolean value) {
/* 167 */     Possible<Boolean> newValue = Possible.of(value);
/* 168 */     return new ImmutableRegionData(this, this.id, this.name, newValue, this.optimal, this.deprecated, this.custom);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableRegionData withOptimal(boolean value) {
/* 178 */     if (this.optimal == value) return this; 
/* 179 */     return new ImmutableRegionData(this, this.id, this.name, vip(), value, this.deprecated, this.custom);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableRegionData withDeprecated(boolean value) {
/* 189 */     if (this.deprecated == value) return this; 
/* 190 */     return new ImmutableRegionData(this, this.id, this.name, vip(), this.optimal, value, this.custom);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableRegionData withCustom(boolean value) {
/* 200 */     if (this.custom == value) return this; 
/* 201 */     return new ImmutableRegionData(this, this.id, this.name, vip(), this.optimal, this.deprecated, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 210 */     if (this == another) return true; 
/* 211 */     return (another instanceof ImmutableRegionData && 
/* 212 */       equalTo(0, (ImmutableRegionData)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableRegionData another) {
/* 216 */     return (this.id.equals(another.id) && this.name
/* 217 */       .equals(another.name) && 
/* 218 */       vip().equals(another.vip()) && this.optimal == another.optimal && this.deprecated == another.deprecated && this.custom == another.custom);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 230 */     int h = 5381;
/* 231 */     h += (h << 5) + this.id.hashCode();
/* 232 */     h += (h << 5) + this.name.hashCode();
/* 233 */     h += (h << 5) + vip().hashCode();
/* 234 */     h += (h << 5) + Boolean.hashCode(this.optimal);
/* 235 */     h += (h << 5) + Boolean.hashCode(this.deprecated);
/* 236 */     h += (h << 5) + Boolean.hashCode(this.custom);
/* 237 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 246 */     return "RegionData{id=" + this.id + ", name=" + this.name + ", vip=" + 
/*     */ 
/*     */       
/* 249 */       vip().toString() + ", optimal=" + this.optimal + ", deprecated=" + this.deprecated + ", custom=" + this.custom + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "RegionData", generator = "Immutables")
/*     */   static final class Json
/*     */     implements RegionData
/*     */   {
/*     */     String id;
/*     */ 
/*     */     
/*     */     String name;
/*     */ 
/*     */     
/* 268 */     Possible<Boolean> vip = Possible.absent();
/*     */     boolean optimal;
/*     */     boolean optimalIsSet;
/*     */     boolean deprecated;
/*     */     boolean deprecatedIsSet;
/*     */     boolean custom;
/*     */     boolean customIsSet;
/*     */     
/*     */     @JsonProperty("id")
/*     */     public void setId(String id) {
/* 278 */       this.id = id;
/*     */     }
/*     */     @JsonProperty("name")
/*     */     public void setName(String name) {
/* 282 */       this.name = name;
/*     */     }
/*     */     @JsonProperty("vip")
/*     */     public void setVip(Possible<Boolean> vip) {
/* 286 */       this.vip = vip;
/*     */     }
/*     */     @JsonProperty("optimal")
/*     */     public void setOptimal(boolean optimal) {
/* 290 */       this.optimal = optimal;
/* 291 */       this.optimalIsSet = true;
/*     */     }
/*     */     @JsonProperty("deprecated")
/*     */     public void setDeprecated(boolean deprecated) {
/* 295 */       this.deprecated = deprecated;
/* 296 */       this.deprecatedIsSet = true;
/*     */     }
/*     */     @JsonProperty("custom")
/*     */     public void setCustom(boolean custom) {
/* 300 */       this.custom = custom;
/* 301 */       this.customIsSet = true;
/*     */     }
/*     */     public String id() {
/* 304 */       throw new UnsupportedOperationException();
/*     */     } public String name() {
/* 306 */       throw new UnsupportedOperationException();
/*     */     } public Possible<Boolean> vip() {
/* 308 */       throw new UnsupportedOperationException();
/*     */     } public boolean optimal() {
/* 310 */       throw new UnsupportedOperationException();
/*     */     } public boolean deprecated() {
/* 312 */       throw new UnsupportedOperationException();
/*     */     } public boolean custom() {
/* 314 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableRegionData fromJson(Json json) {
/* 325 */     Builder builder = builder();
/* 326 */     if (json.id != null) {
/* 327 */       builder.id(json.id);
/*     */     }
/* 329 */     if (json.name != null) {
/* 330 */       builder.name(json.name);
/*     */     }
/* 332 */     if (json.vip != null) {
/* 333 */       builder.vip(json.vip);
/*     */     }
/* 335 */     if (json.optimalIsSet) {
/* 336 */       builder.optimal(json.optimal);
/*     */     }
/* 338 */     if (json.deprecatedIsSet) {
/* 339 */       builder.deprecated(json.deprecated);
/*     */     }
/* 341 */     if (json.customIsSet) {
/* 342 */       builder.custom(json.custom);
/*     */     }
/* 344 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableRegionData of(String id, String name, Possible<Boolean> vip, boolean optimal, boolean deprecated, boolean custom) {
/* 358 */     return new ImmutableRegionData(id, name, vip, optimal, deprecated, custom);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableRegionData copyOf(RegionData instance) {
/* 369 */     if (instance instanceof ImmutableRegionData) {
/* 370 */       return (ImmutableRegionData)instance;
/*     */     }
/* 372 */     return builder()
/* 373 */       .from(instance)
/* 374 */       .build();
/*     */   }
/*     */   
/*     */   public boolean isVipPresent() {
/* 378 */     return !this.vip_absent;
/*     */   }
/*     */   
/*     */   public Boolean vipOrElse(Boolean defaultValue) {
/* 382 */     return !this.vip_absent ? this.vip_value : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 400 */     return new Builder();
/*     */   }
/*     */ 
/*     */   
/*     */   @Generated(from = "RegionData", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_ID = 1L;
/*     */     
/*     */     private static final long INIT_BIT_NAME = 2L;
/*     */     
/*     */     private static final long INIT_BIT_OPTIMAL = 4L;
/*     */     
/*     */     private static final long INIT_BIT_DEPRECATED = 8L;
/*     */     
/*     */     private static final long INIT_BIT_CUSTOM = 16L;
/*     */     
/* 417 */     private long initBits = 31L;
/*     */     
/* 419 */     private Possible<Boolean> vip_possible = Possible.absent();
/*     */ 
/*     */     
/*     */     private String id;
/*     */ 
/*     */     
/*     */     private String name;
/*     */ 
/*     */     
/*     */     private boolean optimal;
/*     */ 
/*     */     
/*     */     private boolean deprecated;
/*     */     
/*     */     private boolean custom;
/*     */ 
/*     */     
/*     */     public final Builder from(RegionData instance) {
/* 437 */       Objects.requireNonNull(instance, "instance");
/* 438 */       id(instance.id());
/* 439 */       name(instance.name());
/* 440 */       vip(instance.vip());
/* 441 */       optimal(instance.optimal());
/* 442 */       deprecated(instance.deprecated());
/* 443 */       custom(instance.custom());
/* 444 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("id")
/*     */     public final Builder id(String id) {
/* 454 */       this.id = Objects.<String>requireNonNull(id, "id");
/* 455 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 456 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("name")
/*     */     public final Builder name(String name) {
/* 466 */       this.name = Objects.<String>requireNonNull(name, "name");
/* 467 */       this.initBits &= 0xFFFFFFFFFFFFFFFDL;
/* 468 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("vip")
/*     */     public Builder vip(Possible<Boolean> value) {
/* 473 */       this.vip_possible = value;
/* 474 */       return this;
/*     */     }
/*     */     
/*     */     public Builder vip(Boolean value) {
/* 478 */       this.vip_possible = Possible.of(value);
/* 479 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("optimal")
/*     */     public final Builder optimal(boolean optimal) {
/* 489 */       this.optimal = optimal;
/* 490 */       this.initBits &= 0xFFFFFFFFFFFFFFFBL;
/* 491 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("deprecated")
/*     */     public final Builder deprecated(boolean deprecated) {
/* 501 */       this.deprecated = deprecated;
/* 502 */       this.initBits &= 0xFFFFFFFFFFFFFFF7L;
/* 503 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("custom")
/*     */     public final Builder custom(boolean custom) {
/* 513 */       this.custom = custom;
/* 514 */       this.initBits &= 0xFFFFFFFFFFFFFFEFL;
/* 515 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableRegionData build() {
/* 524 */       if (this.initBits != 0L) {
/* 525 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 527 */       return new ImmutableRegionData(null, this.id, this.name, vip_build(), this.optimal, this.deprecated, this.custom);
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 531 */       List<String> attributes = new ArrayList<>();
/* 532 */       if ((this.initBits & 0x1L) != 0L) attributes.add("id"); 
/* 533 */       if ((this.initBits & 0x2L) != 0L) attributes.add("name"); 
/* 534 */       if ((this.initBits & 0x4L) != 0L) attributes.add("optimal"); 
/* 535 */       if ((this.initBits & 0x8L) != 0L) attributes.add("deprecated"); 
/* 536 */       if ((this.initBits & 0x10L) != 0L) attributes.add("custom"); 
/* 537 */       return "Cannot build RegionData, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Possible<Boolean> vip_build() {
/* 541 */       return this.vip_possible;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableRegionData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */