/*      */ package discord4j.discordjson.json;
/*      */ 
/*      */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*      */ import com.fasterxml.jackson.annotation.JsonCreator;
/*      */ import com.fasterxml.jackson.annotation.JsonProperty;
/*      */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*      */ import discord4j.discordjson.Id;
/*      */ import discord4j.discordjson.possible.Possible;
/*      */ import java.util.ArrayList;
/*      */ import java.util.List;
/*      */ import java.util.Objects;
/*      */ import java.util.Optional;
/*      */ import java.util.stream.Collectors;
/*      */ import java.util.stream.LongStream;
/*      */ import java.util.stream.StreamSupport;
/*      */ import org.immutables.value.Generated;
/*      */ import reactor.util.annotation.Nullable;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ @Generated(from = "PartialMemberData", generator = "Immutables")
/*      */ public final class ImmutablePartialMemberData
/*      */   implements PartialMemberData
/*      */ {
/*      */   private final String nick_value;
/*      */   private final boolean nick_absent;
/*      */   private final String avatar;
/*      */   private final long[] roles_value;
/*      */   private final String joinedAt;
/*      */   private final String premiumSince_value;
/*      */   private final boolean premiumSince_absent;
/*      */   private final String hoistedRole;
/*      */   private final boolean deaf;
/*      */   private final boolean mute;
/*      */   private final String communicationDisabledUntil_value;
/*      */   private final boolean communicationDisabledUntil_absent;
/*      */   private final long flags;
/*      */   private static final byte STAGE_INITIALIZING = -1;
/*      */   private static final byte STAGE_UNINITIALIZED = 0;
/*      */   private static final byte STAGE_INITIALIZED = 1;
/*      */   
/*      */   private ImmutablePartialMemberData(Possible<Optional<String>> nick, Optional<String> avatar, List<Id> roles, Optional<String> joinedAt, Possible<Optional<String>> premiumSince, Optional<String> hoistedRole, boolean deaf, boolean mute, Possible<Optional<String>> communicationDisabledUntil, long flags) {
/*   56 */     Possible<Optional<String>> nick$impl = nick;
/*   57 */     this.avatar = avatar.orElse(null);
/*   58 */     List<Id> roles$impl = roles;
/*   59 */     this.joinedAt = joinedAt.orElse(null);
/*   60 */     Possible<Optional<String>> premiumSince$impl = premiumSince;
/*   61 */     this.hoistedRole = hoistedRole.orElse(null);
/*   62 */     this.deaf = deaf;
/*   63 */     this.mute = mute;
/*   64 */     Possible<Optional<String>> communicationDisabledUntil$impl = communicationDisabledUntil;
/*   65 */     this.initShim.flags(flags);
/*   66 */     this.nick_value = Possible.flatOpt(nick$impl).orElse(null);
/*   67 */     this.nick_absent = nick$impl.isAbsent();
/*   68 */     this
/*      */       
/*   70 */       .roles_value = roles$impl.stream().mapToLong(Id::asLong).toArray();
/*   71 */     this.premiumSince_value = Possible.flatOpt(premiumSince$impl).orElse(null);
/*   72 */     this.premiumSince_absent = premiumSince$impl.isAbsent();
/*   73 */     this.communicationDisabledUntil_value = Possible.flatOpt(communicationDisabledUntil$impl).orElse(null);
/*   74 */     this.communicationDisabledUntil_absent = communicationDisabledUntil$impl.isAbsent();
/*   75 */     this.flags = this.initShim.flags();
/*   76 */     this.initShim = null;
/*      */   }
/*      */   
/*      */   private ImmutablePartialMemberData(Builder builder) {
/*   80 */     Possible<Optional<String>> nick$impl = builder.nick_build();
/*   81 */     this.avatar = builder.avatar;
/*   82 */     List<Id> roles$impl = builder.roles_build();
/*   83 */     this.joinedAt = builder.joinedAt;
/*   84 */     Possible<Optional<String>> premiumSince$impl = builder.premiumSince_build();
/*   85 */     this.hoistedRole = builder.hoistedRole;
/*   86 */     this.deaf = builder.deaf;
/*   87 */     this.mute = builder.mute;
/*   88 */     Possible<Optional<String>> communicationDisabledUntil$impl = builder.communicationDisabledUntil_build();
/*   89 */     if (builder.flagsIsSet()) {
/*   90 */       this.initShim.flags(builder.flags);
/*      */     }
/*   92 */     this.nick_value = Possible.flatOpt(nick$impl).orElse(null);
/*   93 */     this.nick_absent = nick$impl.isAbsent();
/*   94 */     this
/*      */       
/*   96 */       .roles_value = roles$impl.stream().mapToLong(Id::asLong).toArray();
/*   97 */     this.premiumSince_value = Possible.flatOpt(premiumSince$impl).orElse(null);
/*   98 */     this.premiumSince_absent = premiumSince$impl.isAbsent();
/*   99 */     this.communicationDisabledUntil_value = Possible.flatOpt(communicationDisabledUntil$impl).orElse(null);
/*  100 */     this.communicationDisabledUntil_absent = communicationDisabledUntil$impl.isAbsent();
/*  101 */     this.flags = this.initShim.flags();
/*  102 */     this.initShim = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ImmutablePartialMemberData(ImmutablePartialMemberData original, Possible<Optional<String>> nick, String avatar, List<Id> roles, String joinedAt, Possible<Optional<String>> premiumSince, String hoistedRole, boolean deaf, boolean mute, Possible<Optional<String>> communicationDisabledUntil, long flags) {
/*  117 */     Possible<Optional<String>> nick$impl = nick;
/*  118 */     this.avatar = avatar;
/*  119 */     List<Id> roles$impl = roles;
/*  120 */     this.joinedAt = joinedAt;
/*  121 */     Possible<Optional<String>> premiumSince$impl = premiumSince;
/*  122 */     this.hoistedRole = hoistedRole;
/*  123 */     this.deaf = deaf;
/*  124 */     this.mute = mute;
/*  125 */     Possible<Optional<String>> communicationDisabledUntil$impl = communicationDisabledUntil;
/*  126 */     this.initShim.flags(flags);
/*  127 */     this.nick_value = Possible.flatOpt(nick$impl).orElse(null);
/*  128 */     this.nick_absent = nick$impl.isAbsent();
/*  129 */     this
/*      */       
/*  131 */       .roles_value = roles$impl.stream().mapToLong(Id::asLong).toArray();
/*  132 */     this.premiumSince_value = Possible.flatOpt(premiumSince$impl).orElse(null);
/*  133 */     this.premiumSince_absent = premiumSince$impl.isAbsent();
/*  134 */     this.communicationDisabledUntil_value = Possible.flatOpt(communicationDisabledUntil$impl).orElse(null);
/*  135 */     this.communicationDisabledUntil_absent = communicationDisabledUntil$impl.isAbsent();
/*  136 */     this.flags = this.initShim.flags();
/*  137 */     this.initShim = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  143 */   private volatile transient InitShim initShim = new InitShim();
/*      */   
/*      */   @Generated(from = "PartialMemberData", generator = "Immutables")
/*      */   private final class InitShim {
/*  147 */     private byte flagsBuildStage = 0;
/*      */     private long flags;
/*      */     
/*      */     long flags() {
/*  151 */       if (this.flagsBuildStage == -1) throw new IllegalStateException(formatInitCycleMessage()); 
/*  152 */       if (this.flagsBuildStage == 0) {
/*  153 */         this.flagsBuildStage = -1;
/*  154 */         this.flags = ImmutablePartialMemberData.this.flagsInitialize();
/*  155 */         this.flagsBuildStage = 1;
/*      */       } 
/*  157 */       return this.flags;
/*      */     }
/*      */     
/*      */     void flags(long flags) {
/*  161 */       this.flags = flags;
/*  162 */       this.flagsBuildStage = 1;
/*      */     }
/*      */     private InitShim() {}
/*      */     private String formatInitCycleMessage() {
/*  166 */       List<String> attributes = new ArrayList<>();
/*  167 */       if (this.flagsBuildStage == -1) attributes.add("flags"); 
/*  168 */       return "Cannot build PartialMemberData, attribute initializers form cycle " + attributes;
/*      */     }
/*      */   }
/*      */   
/*      */   private long flagsInitialize() {
/*  173 */     return super.flags();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("nick")
/*      */   public Possible<Optional<String>> nick() {
/*  182 */     return this.nick_absent ? Possible.absent() : 
/*  183 */       Possible.of(Optional.ofNullable(this.nick_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("avatar")
/*      */   public Optional<String> avatar() {
/*  192 */     return Optional.ofNullable(this.avatar);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("roles")
/*      */   public List<Id> roles() {
/*  201 */     return (List<Id>)LongStream.of(this.roles_value)
/*  202 */       .mapToObj(Id::of)
/*  203 */       .collect(Collectors.toList());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("joined_at")
/*      */   public Optional<String> joinedAt() {
/*  212 */     return Optional.ofNullable(this.joinedAt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("premium_since")
/*      */   public Possible<Optional<String>> premiumSince() {
/*  221 */     return this.premiumSince_absent ? Possible.absent() : 
/*  222 */       Possible.of(Optional.ofNullable(this.premiumSince_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("hoisted_role")
/*      */   public Optional<String> hoistedRole() {
/*  231 */     return Optional.ofNullable(this.hoistedRole);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("deaf")
/*      */   public boolean deaf() {
/*  240 */     return this.deaf;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("mute")
/*      */   public boolean mute() {
/*  249 */     return this.mute;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("communication_disabled_until")
/*      */   public Possible<Optional<String>> communicationDisabledUntil() {
/*  258 */     return this.communicationDisabledUntil_absent ? Possible.absent() : 
/*  259 */       Possible.of(Optional.ofNullable(this.communicationDisabledUntil_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("flags")
/*      */   public long flags() {
/*  268 */     InitShim shim = this.initShim;
/*  269 */     return (shim != null) ? 
/*  270 */       shim.flags() : 
/*  271 */       this.flags;
/*      */   }
/*      */   
/*      */   public ImmutablePartialMemberData withNick(Possible<Optional<String>> value) {
/*  275 */     Possible<Optional<String>> newValue = Objects.<Possible<Optional<String>>>requireNonNull(value);
/*  276 */     return new ImmutablePartialMemberData(this, newValue, this.avatar, 
/*      */ 
/*      */ 
/*      */         
/*  280 */         roles(), this.joinedAt, 
/*      */         
/*  282 */         premiumSince(), this.hoistedRole, this.deaf, this.mute, 
/*      */ 
/*      */ 
/*      */         
/*  286 */         communicationDisabledUntil(), this.flags);
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public ImmutablePartialMemberData withNick(@Nullable String value) {
/*  292 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/*  293 */     return new ImmutablePartialMemberData(this, newValue, this.avatar, 
/*      */ 
/*      */ 
/*      */         
/*  297 */         roles(), this.joinedAt, 
/*      */         
/*  299 */         premiumSince(), this.hoistedRole, this.deaf, this.mute, 
/*      */ 
/*      */ 
/*      */         
/*  303 */         communicationDisabledUntil(), this.flags);
/*      */   }
/*      */ 
/*      */   
/*      */   public ImmutablePartialMemberData withNickOrNull(@Nullable String value) {
/*  308 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/*  309 */     return new ImmutablePartialMemberData(this, newValue, this.avatar, 
/*      */ 
/*      */ 
/*      */         
/*  313 */         roles(), this.joinedAt, 
/*      */         
/*  315 */         premiumSince(), this.hoistedRole, this.deaf, this.mute, 
/*      */ 
/*      */ 
/*      */         
/*  319 */         communicationDisabledUntil(), this.flags);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutablePartialMemberData withAvatar(String value) {
/*  329 */     String newValue = Objects.<String>requireNonNull(value, "avatar");
/*  330 */     if (Objects.equals(this.avatar, newValue)) return this; 
/*  331 */     return new ImmutablePartialMemberData(this, 
/*      */         
/*  333 */         nick(), newValue, 
/*      */         
/*  335 */         roles(), this.joinedAt, 
/*      */         
/*  337 */         premiumSince(), this.hoistedRole, this.deaf, this.mute, 
/*      */ 
/*      */ 
/*      */         
/*  341 */         communicationDisabledUntil(), this.flags);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutablePartialMemberData withAvatar(Optional<String> optional) {
/*  352 */     String value = optional.orElse(null);
/*  353 */     if (Objects.equals(this.avatar, value)) return this; 
/*  354 */     return new ImmutablePartialMemberData(this, 
/*      */         
/*  356 */         nick(), value, 
/*      */         
/*  358 */         roles(), this.joinedAt, 
/*      */         
/*  360 */         premiumSince(), this.hoistedRole, this.deaf, this.mute, 
/*      */ 
/*      */ 
/*      */         
/*  364 */         communicationDisabledUntil(), this.flags);
/*      */   }
/*      */ 
/*      */   
/*      */   public ImmutablePartialMemberData withRoles(List<Id> value) {
/*  369 */     List<Id> newValue = value;
/*  370 */     return new ImmutablePartialMemberData(this, 
/*      */         
/*  372 */         nick(), this.avatar, newValue, this.joinedAt, 
/*      */ 
/*      */ 
/*      */         
/*  376 */         premiumSince(), this.hoistedRole, this.deaf, this.mute, 
/*      */ 
/*      */ 
/*      */         
/*  380 */         communicationDisabledUntil(), this.flags);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutablePartialMemberData withJoinedAt(String value) {
/*  390 */     String newValue = Objects.<String>requireNonNull(value, "joinedAt");
/*  391 */     if (Objects.equals(this.joinedAt, newValue)) return this; 
/*  392 */     return new ImmutablePartialMemberData(this, 
/*      */         
/*  394 */         nick(), this.avatar, 
/*      */         
/*  396 */         roles(), newValue, 
/*      */         
/*  398 */         premiumSince(), this.hoistedRole, this.deaf, this.mute, 
/*      */ 
/*      */ 
/*      */         
/*  402 */         communicationDisabledUntil(), this.flags);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutablePartialMemberData withJoinedAt(Optional<String> optional) {
/*  413 */     String value = optional.orElse(null);
/*  414 */     if (Objects.equals(this.joinedAt, value)) return this; 
/*  415 */     return new ImmutablePartialMemberData(this, 
/*      */         
/*  417 */         nick(), this.avatar, 
/*      */         
/*  419 */         roles(), value, 
/*      */         
/*  421 */         premiumSince(), this.hoistedRole, this.deaf, this.mute, 
/*      */ 
/*      */ 
/*      */         
/*  425 */         communicationDisabledUntil(), this.flags);
/*      */   }
/*      */ 
/*      */   
/*      */   public ImmutablePartialMemberData withPremiumSince(Possible<Optional<String>> value) {
/*  430 */     Possible<Optional<String>> newValue = Objects.<Possible<Optional<String>>>requireNonNull(value);
/*  431 */     return new ImmutablePartialMemberData(this, 
/*      */         
/*  433 */         nick(), this.avatar, 
/*      */         
/*  435 */         roles(), this.joinedAt, newValue, this.hoistedRole, this.deaf, this.mute, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  441 */         communicationDisabledUntil(), this.flags);
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public ImmutablePartialMemberData withPremiumSince(@Nullable String value) {
/*  447 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/*  448 */     return new ImmutablePartialMemberData(this, 
/*      */         
/*  450 */         nick(), this.avatar, 
/*      */         
/*  452 */         roles(), this.joinedAt, newValue, this.hoistedRole, this.deaf, this.mute, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  458 */         communicationDisabledUntil(), this.flags);
/*      */   }
/*      */ 
/*      */   
/*      */   public ImmutablePartialMemberData withPremiumSinceOrNull(@Nullable String value) {
/*  463 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/*  464 */     return new ImmutablePartialMemberData(this, 
/*      */         
/*  466 */         nick(), this.avatar, 
/*      */         
/*  468 */         roles(), this.joinedAt, newValue, this.hoistedRole, this.deaf, this.mute, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  474 */         communicationDisabledUntil(), this.flags);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutablePartialMemberData withHoistedRole(String value) {
/*  484 */     String newValue = Objects.<String>requireNonNull(value, "hoistedRole");
/*  485 */     if (Objects.equals(this.hoistedRole, newValue)) return this; 
/*  486 */     return new ImmutablePartialMemberData(this, 
/*      */         
/*  488 */         nick(), this.avatar, 
/*      */         
/*  490 */         roles(), this.joinedAt, 
/*      */         
/*  492 */         premiumSince(), newValue, this.deaf, this.mute, 
/*      */ 
/*      */ 
/*      */         
/*  496 */         communicationDisabledUntil(), this.flags);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutablePartialMemberData withHoistedRole(Optional<String> optional) {
/*  507 */     String value = optional.orElse(null);
/*  508 */     if (Objects.equals(this.hoistedRole, value)) return this; 
/*  509 */     return new ImmutablePartialMemberData(this, 
/*      */         
/*  511 */         nick(), this.avatar, 
/*      */         
/*  513 */         roles(), this.joinedAt, 
/*      */         
/*  515 */         premiumSince(), value, this.deaf, this.mute, 
/*      */ 
/*      */ 
/*      */         
/*  519 */         communicationDisabledUntil(), this.flags);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutablePartialMemberData withDeaf(boolean value) {
/*  530 */     if (this.deaf == value) return this; 
/*  531 */     return new ImmutablePartialMemberData(this, 
/*      */         
/*  533 */         nick(), this.avatar, 
/*      */         
/*  535 */         roles(), this.joinedAt, 
/*      */         
/*  537 */         premiumSince(), this.hoistedRole, value, this.mute, 
/*      */ 
/*      */ 
/*      */         
/*  541 */         communicationDisabledUntil(), this.flags);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutablePartialMemberData withMute(boolean value) {
/*  552 */     if (this.mute == value) return this; 
/*  553 */     return new ImmutablePartialMemberData(this, 
/*      */         
/*  555 */         nick(), this.avatar, 
/*      */         
/*  557 */         roles(), this.joinedAt, 
/*      */         
/*  559 */         premiumSince(), this.hoistedRole, this.deaf, value, 
/*      */ 
/*      */ 
/*      */         
/*  563 */         communicationDisabledUntil(), this.flags);
/*      */   }
/*      */ 
/*      */   
/*      */   public ImmutablePartialMemberData withCommunicationDisabledUntil(Possible<Optional<String>> value) {
/*  568 */     Possible<Optional<String>> newValue = Objects.<Possible<Optional<String>>>requireNonNull(value);
/*  569 */     return new ImmutablePartialMemberData(this, 
/*      */         
/*  571 */         nick(), this.avatar, 
/*      */         
/*  573 */         roles(), this.joinedAt, 
/*      */         
/*  575 */         premiumSince(), this.hoistedRole, this.deaf, this.mute, newValue, this.flags);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public ImmutablePartialMemberData withCommunicationDisabledUntil(@Nullable String value) {
/*  585 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/*  586 */     return new ImmutablePartialMemberData(this, 
/*      */         
/*  588 */         nick(), this.avatar, 
/*      */         
/*  590 */         roles(), this.joinedAt, 
/*      */         
/*  592 */         premiumSince(), this.hoistedRole, this.deaf, this.mute, newValue, this.flags);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutablePartialMemberData withCommunicationDisabledUntilOrNull(@Nullable String value) {
/*  601 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/*  602 */     return new ImmutablePartialMemberData(this, 
/*      */         
/*  604 */         nick(), this.avatar, 
/*      */         
/*  606 */         roles(), this.joinedAt, 
/*      */         
/*  608 */         premiumSince(), this.hoistedRole, this.deaf, this.mute, newValue, this.flags);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutablePartialMemberData withFlags(long value) {
/*  623 */     if (this.flags == value) return this; 
/*  624 */     return new ImmutablePartialMemberData(this, 
/*      */         
/*  626 */         nick(), this.avatar, 
/*      */         
/*  628 */         roles(), this.joinedAt, 
/*      */         
/*  630 */         premiumSince(), this.hoistedRole, this.deaf, this.mute, 
/*      */ 
/*      */ 
/*      */         
/*  634 */         communicationDisabledUntil(), value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean equals(Object another) {
/*  644 */     if (this == another) return true; 
/*  645 */     return (another instanceof ImmutablePartialMemberData && 
/*  646 */       equalTo(0, (ImmutablePartialMemberData)another));
/*      */   }
/*      */   
/*      */   private boolean equalTo(int synthetic, ImmutablePartialMemberData another) {
/*  650 */     return (nick().equals(another.nick()) && 
/*  651 */       Objects.equals(this.avatar, another.avatar) && 
/*  652 */       Objects.equals(this.roles_value, another.roles_value) && 
/*  653 */       Objects.equals(this.joinedAt, another.joinedAt) && 
/*  654 */       premiumSince().equals(another.premiumSince()) && 
/*  655 */       Objects.equals(this.hoistedRole, another.hoistedRole) && this.deaf == another.deaf && this.mute == another.mute && 
/*      */ 
/*      */       
/*  658 */       communicationDisabledUntil().equals(another.communicationDisabledUntil()) && this.flags == another.flags);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int hashCode() {
/*  668 */     int h = 5381;
/*  669 */     h += (h << 5) + nick().hashCode();
/*  670 */     h += (h << 5) + Objects.hashCode(this.avatar);
/*  671 */     h += (h << 5) + Objects.hashCode(this.roles_value);
/*  672 */     h += (h << 5) + Objects.hashCode(this.joinedAt);
/*  673 */     h += (h << 5) + premiumSince().hashCode();
/*  674 */     h += (h << 5) + Objects.hashCode(this.hoistedRole);
/*  675 */     h += (h << 5) + Boolean.hashCode(this.deaf);
/*  676 */     h += (h << 5) + Boolean.hashCode(this.mute);
/*  677 */     h += (h << 5) + communicationDisabledUntil().hashCode();
/*  678 */     h += (h << 5) + Long.hashCode(this.flags);
/*  679 */     return h;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/*  688 */     StringBuilder builder = new StringBuilder("PartialMemberData{");
/*  689 */     builder.append("nick=").append(nick().toString());
/*  690 */     if (this.avatar != null) {
/*  691 */       builder.append(", ");
/*  692 */       builder.append("avatar=").append(this.avatar);
/*      */     } 
/*  694 */     builder.append(", ");
/*  695 */     builder.append("roles=").append(Objects.toString(this.roles_value));
/*  696 */     if (this.joinedAt != null) {
/*  697 */       builder.append(", ");
/*  698 */       builder.append("joinedAt=").append(this.joinedAt);
/*      */     } 
/*  700 */     builder.append(", ");
/*  701 */     builder.append("premiumSince=").append(premiumSince().toString());
/*  702 */     if (this.hoistedRole != null) {
/*  703 */       builder.append(", ");
/*  704 */       builder.append("hoistedRole=").append(this.hoistedRole);
/*      */     } 
/*  706 */     builder.append(", ");
/*  707 */     builder.append("deaf=").append(this.deaf);
/*  708 */     builder.append(", ");
/*  709 */     builder.append("mute=").append(this.mute);
/*  710 */     builder.append(", ");
/*  711 */     builder.append("communicationDisabledUntil=").append(communicationDisabledUntil().toString());
/*  712 */     builder.append(", ");
/*  713 */     builder.append("flags=").append(this.flags);
/*  714 */     return builder.append("}").toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonDeserialize
/*      */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*      */   @Generated(from = "PartialMemberData", generator = "Immutables")
/*      */   static final class Json
/*      */     implements PartialMemberData
/*      */   {
/*  727 */     Possible<Optional<String>> nick = Possible.absent();
/*      */     
/*  729 */     Optional<String> avatar = Optional.empty();
/*      */     List<Id> roles;
/*  731 */     Optional<String> joinedAt = Optional.empty();
/*      */     
/*  733 */     Possible<Optional<String>> premiumSince = Possible.absent();
/*      */     
/*  735 */     Optional<String> hoistedRole = Optional.empty();
/*      */     
/*      */     boolean deaf;
/*      */     boolean deafIsSet;
/*      */     boolean mute;
/*      */     boolean muteIsSet;
/*  741 */     Possible<Optional<String>> communicationDisabledUntil = Possible.absent();
/*      */     long flags;
/*      */     boolean flagsIsSet;
/*      */     
/*      */     @JsonProperty("nick")
/*      */     public void setNick(Possible<Optional<String>> nick) {
/*  747 */       this.nick = nick;
/*      */     }
/*      */     @JsonProperty("avatar")
/*      */     public void setAvatar(Optional<String> avatar) {
/*  751 */       this.avatar = avatar;
/*      */     }
/*      */     @JsonProperty("roles")
/*      */     public void setRoles(List<Id> roles) {
/*  755 */       this.roles = roles;
/*      */     }
/*      */     @JsonProperty("joined_at")
/*      */     public void setJoinedAt(Optional<String> joinedAt) {
/*  759 */       this.joinedAt = joinedAt;
/*      */     }
/*      */     @JsonProperty("premium_since")
/*      */     public void setPremiumSince(Possible<Optional<String>> premiumSince) {
/*  763 */       this.premiumSince = premiumSince;
/*      */     }
/*      */     @JsonProperty("hoisted_role")
/*      */     public void setHoistedRole(Optional<String> hoistedRole) {
/*  767 */       this.hoistedRole = hoistedRole;
/*      */     }
/*      */     @JsonProperty("deaf")
/*      */     public void setDeaf(boolean deaf) {
/*  771 */       this.deaf = deaf;
/*  772 */       this.deafIsSet = true;
/*      */     }
/*      */     @JsonProperty("mute")
/*      */     public void setMute(boolean mute) {
/*  776 */       this.mute = mute;
/*  777 */       this.muteIsSet = true;
/*      */     }
/*      */     @JsonProperty("communication_disabled_until")
/*      */     public void setCommunicationDisabledUntil(Possible<Optional<String>> communicationDisabledUntil) {
/*  781 */       this.communicationDisabledUntil = communicationDisabledUntil;
/*      */     }
/*      */     @JsonProperty("flags")
/*      */     public void setFlags(long flags) {
/*  785 */       this.flags = flags;
/*  786 */       this.flagsIsSet = true;
/*      */     }
/*      */     public Possible<Optional<String>> nick() {
/*  789 */       throw new UnsupportedOperationException();
/*      */     } public Optional<String> avatar() {
/*  791 */       throw new UnsupportedOperationException();
/*      */     } public List<Id> roles() {
/*  793 */       throw new UnsupportedOperationException();
/*      */     } public Optional<String> joinedAt() {
/*  795 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Optional<String>> premiumSince() {
/*  797 */       throw new UnsupportedOperationException();
/*      */     } public Optional<String> hoistedRole() {
/*  799 */       throw new UnsupportedOperationException();
/*      */     } public boolean deaf() {
/*  801 */       throw new UnsupportedOperationException();
/*      */     } public boolean mute() {
/*  803 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Optional<String>> communicationDisabledUntil() {
/*  805 */       throw new UnsupportedOperationException();
/*      */     } public long flags() {
/*  807 */       throw new UnsupportedOperationException();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*      */   static ImmutablePartialMemberData fromJson(Json json) {
/*  818 */     Builder builder = builder();
/*  819 */     if (json.nick != null) {
/*  820 */       builder.nick(json.nick);
/*      */     }
/*  822 */     if (json.avatar != null) {
/*  823 */       builder.avatar(json.avatar);
/*      */     }
/*  825 */     if (json.roles != null) {
/*  826 */       builder.roles(json.roles);
/*      */     }
/*  828 */     if (json.joinedAt != null) {
/*  829 */       builder.joinedAt(json.joinedAt);
/*      */     }
/*  831 */     if (json.premiumSince != null) {
/*  832 */       builder.premiumSince(json.premiumSince);
/*      */     }
/*  834 */     if (json.hoistedRole != null) {
/*  835 */       builder.hoistedRole(json.hoistedRole);
/*      */     }
/*  837 */     if (json.deafIsSet) {
/*  838 */       builder.deaf(json.deaf);
/*      */     }
/*  840 */     if (json.muteIsSet) {
/*  841 */       builder.mute(json.mute);
/*      */     }
/*  843 */     if (json.communicationDisabledUntil != null) {
/*  844 */       builder.communicationDisabledUntil(json.communicationDisabledUntil);
/*      */     }
/*  846 */     if (json.flagsIsSet) {
/*  847 */       builder.flags(json.flags);
/*      */     }
/*  849 */     return builder.build();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutablePartialMemberData of(Possible<Optional<String>> nick, Optional<String> avatar, List<Id> roles, Optional<String> joinedAt, Possible<Optional<String>> premiumSince, Optional<String> hoistedRole, boolean deaf, boolean mute, Possible<Optional<String>> communicationDisabledUntil, long flags) {
/*  867 */     return new ImmutablePartialMemberData(nick, avatar, roles, joinedAt, premiumSince, hoistedRole, deaf, mute, communicationDisabledUntil, flags);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutablePartialMemberData copyOf(PartialMemberData instance) {
/*  878 */     if (instance instanceof ImmutablePartialMemberData) {
/*  879 */       return (ImmutablePartialMemberData)instance;
/*      */     }
/*  881 */     return builder()
/*  882 */       .from(instance)
/*  883 */       .build();
/*      */   }
/*      */   
/*      */   public boolean isNickPresent() {
/*  887 */     return !this.nick_absent;
/*      */   }
/*      */   
/*      */   public String nickOrElse(String defaultValue) {
/*  891 */     return !this.nick_absent ? this.nick_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isPremiumSincePresent() {
/*  895 */     return !this.premiumSince_absent;
/*      */   }
/*      */   
/*      */   public String premiumSinceOrElse(String defaultValue) {
/*  899 */     return !this.premiumSince_absent ? this.premiumSince_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isCommunicationDisabledUntilPresent() {
/*  903 */     return !this.communicationDisabledUntil_absent;
/*      */   }
/*      */   
/*      */   public String communicationDisabledUntilOrElse(String defaultValue) {
/*  907 */     return !this.communicationDisabledUntil_absent ? this.communicationDisabledUntil_value : defaultValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Builder builder() {
/*  929 */     return new Builder();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   @Generated(from = "PartialMemberData", generator = "Immutables")
/*      */   public static final class Builder
/*      */   {
/*      */     private static final long INIT_BIT_DEAF = 1L;
/*      */ 
/*      */     
/*      */     private static final long INIT_BIT_MUTE = 2L;
/*      */     
/*      */     private static final long OPT_BIT_FLAGS = 1L;
/*      */     
/*  944 */     private long initBits = 3L;
/*      */     
/*      */     private long optBits;
/*  947 */     private Possible<Optional<String>> nick_possible = Possible.absent();
/*  948 */     private List<Long> roles_list = null;
/*  949 */     private Possible<Optional<String>> premiumSince_possible = Possible.absent();
/*  950 */     private Possible<Optional<String>> communicationDisabledUntil_possible = Possible.absent();
/*      */ 
/*      */     
/*      */     private String avatar;
/*      */ 
/*      */     
/*      */     private String joinedAt;
/*      */ 
/*      */     
/*      */     private String hoistedRole;
/*      */     
/*      */     private boolean deaf;
/*      */     
/*      */     private boolean mute;
/*      */     
/*      */     private long flags;
/*      */ 
/*      */     
/*      */     public final Builder from(PartialMemberData instance) {
/*  969 */       Objects.requireNonNull(instance, "instance");
/*  970 */       nick(instance.nick());
/*  971 */       Optional<String> avatarOptional = instance.avatar();
/*  972 */       if (avatarOptional.isPresent()) {
/*  973 */         avatar(avatarOptional);
/*      */       }
/*  975 */       roles(instance.roles());
/*  976 */       Optional<String> joinedAtOptional = instance.joinedAt();
/*  977 */       if (joinedAtOptional.isPresent()) {
/*  978 */         joinedAt(joinedAtOptional);
/*      */       }
/*  980 */       premiumSince(instance.premiumSince());
/*  981 */       Optional<String> hoistedRoleOptional = instance.hoistedRole();
/*  982 */       if (hoistedRoleOptional.isPresent()) {
/*  983 */         hoistedRole(hoistedRoleOptional);
/*      */       }
/*  985 */       deaf(instance.deaf());
/*  986 */       mute(instance.mute());
/*  987 */       communicationDisabledUntil(instance.communicationDisabledUntil());
/*  988 */       flags(instance.flags());
/*  989 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("nick")
/*      */     public Builder nick(Possible<Optional<String>> value) {
/*  994 */       this.nick_possible = value;
/*  995 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public Builder nick(@Nullable String value) {
/* 1000 */       this.nick_possible = Possible.of(Optional.ofNullable(value));
/* 1001 */       return this;
/*      */     }
/*      */     
/*      */     public Builder nickOrNull(@Nullable String value) {
/* 1005 */       this.nick_possible = Possible.of(Optional.ofNullable(value));
/* 1006 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder avatar(String avatar) {
/* 1015 */       this.avatar = Objects.<String>requireNonNull(avatar, "avatar");
/* 1016 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("avatar")
/*      */     public final Builder avatar(Optional<String> avatar) {
/* 1026 */       this.avatar = avatar.orElse(null);
/* 1027 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addRole(long element) {
/* 1031 */       roles_getOrCreate().add(Long.valueOf(element));
/* 1032 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addRole(String element) {
/* 1036 */       roles_getOrCreate().add(Long.valueOf(Id.of(element).asLong()));
/* 1037 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addRole(Id element) {
/* 1041 */       roles_getOrCreate().add(Long.valueOf(element.asLong()));
/* 1042 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addAllRoles(List<Long> elements) {
/* 1046 */       roles_getOrCreate().addAll(elements);
/* 1047 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("roles")
/*      */     public Builder roles(List<Id> elements) {
/* 1052 */       this.roles_list = (List<Long>)elements.stream().map(Id::asLong).collect(Collectors.toList());
/* 1053 */       return this;
/*      */     }
/*      */     
/*      */     public Builder roles(Iterable<Id> elements) {
/* 1057 */       this
/*      */         
/* 1059 */         .roles_list = (List<Long>)StreamSupport.stream(elements.spliterator(), false).map(Id::asLong).collect(Collectors.toList());
/* 1060 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder joinedAt(String joinedAt) {
/* 1069 */       this.joinedAt = Objects.<String>requireNonNull(joinedAt, "joinedAt");
/* 1070 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("joined_at")
/*      */     public final Builder joinedAt(Optional<String> joinedAt) {
/* 1080 */       this.joinedAt = joinedAt.orElse(null);
/* 1081 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("premium_since")
/*      */     public Builder premiumSince(Possible<Optional<String>> value) {
/* 1086 */       this.premiumSince_possible = value;
/* 1087 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public Builder premiumSince(@Nullable String value) {
/* 1092 */       this.premiumSince_possible = Possible.of(Optional.ofNullable(value));
/* 1093 */       return this;
/*      */     }
/*      */     
/*      */     public Builder premiumSinceOrNull(@Nullable String value) {
/* 1097 */       this.premiumSince_possible = Possible.of(Optional.ofNullable(value));
/* 1098 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder hoistedRole(String hoistedRole) {
/* 1107 */       this.hoistedRole = Objects.<String>requireNonNull(hoistedRole, "hoistedRole");
/* 1108 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("hoisted_role")
/*      */     public final Builder hoistedRole(Optional<String> hoistedRole) {
/* 1118 */       this.hoistedRole = hoistedRole.orElse(null);
/* 1119 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("deaf")
/*      */     public final Builder deaf(boolean deaf) {
/* 1129 */       this.deaf = deaf;
/* 1130 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 1131 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("mute")
/*      */     public final Builder mute(boolean mute) {
/* 1141 */       this.mute = mute;
/* 1142 */       this.initBits &= 0xFFFFFFFFFFFFFFFDL;
/* 1143 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("communication_disabled_until")
/*      */     public Builder communicationDisabledUntil(Possible<Optional<String>> value) {
/* 1148 */       this.communicationDisabledUntil_possible = value;
/* 1149 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public Builder communicationDisabledUntil(@Nullable String value) {
/* 1154 */       this.communicationDisabledUntil_possible = Possible.of(Optional.ofNullable(value));
/* 1155 */       return this;
/*      */     }
/*      */     
/*      */     public Builder communicationDisabledUntilOrNull(@Nullable String value) {
/* 1159 */       this.communicationDisabledUntil_possible = Possible.of(Optional.ofNullable(value));
/* 1160 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("flags")
/*      */     public final Builder flags(long flags) {
/* 1171 */       this.flags = flags;
/* 1172 */       this.optBits |= 0x1L;
/* 1173 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ImmutablePartialMemberData build() {
/* 1182 */       if (this.initBits != 0L) {
/* 1183 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*      */       }
/* 1185 */       return new ImmutablePartialMemberData(this);
/*      */     }
/*      */     
/*      */     private boolean flagsIsSet() {
/* 1189 */       return ((this.optBits & 0x1L) != 0L);
/*      */     }
/*      */     
/*      */     private String formatRequiredAttributesMessage() {
/* 1193 */       List<String> attributes = new ArrayList<>();
/* 1194 */       if ((this.initBits & 0x1L) != 0L) attributes.add("deaf"); 
/* 1195 */       if ((this.initBits & 0x2L) != 0L) attributes.add("mute"); 
/* 1196 */       return "Cannot build PartialMemberData, some of required attributes are not set " + attributes;
/*      */     }
/*      */     
/*      */     private Possible<Optional<String>> nick_build() {
/* 1200 */       return this.nick_possible;
/*      */     }
/*      */     
/*      */     private List<Id> roles_build() {
/* 1204 */       return (List<Id>)roles_getOrCreate().stream().map(Id::of).collect(Collectors.toList());
/*      */     }
/*      */     
/*      */     private List<Long> roles_getOrCreate() {
/* 1208 */       if (this.roles_list == null) {
/* 1209 */         this.roles_list = new ArrayList<>();
/*      */       }
/* 1211 */       return this.roles_list;
/*      */     }
/*      */     
/*      */     private Possible<Optional<String>> premiumSince_build() {
/* 1215 */       return this.premiumSince_possible;
/*      */     }
/*      */     
/*      */     private Possible<Optional<String>> communicationDisabledUntil_build() {
/* 1219 */       return this.communicationDisabledUntil_possible;
/*      */     }
/*      */     
/*      */     private Builder() {}
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutablePartialMemberData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */