/*      */ package discord4j.discordjson.json;
/*      */ 
/*      */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*      */ import com.fasterxml.jackson.annotation.JsonCreator;
/*      */ import com.fasterxml.jackson.annotation.JsonProperty;
/*      */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*      */ import discord4j.discordjson.Id;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.List;
/*      */ import java.util.Objects;
/*      */ import java.util.stream.Collectors;
/*      */ import java.util.stream.LongStream;
/*      */ import java.util.stream.StreamSupport;
/*      */ import org.immutables.value.Generated;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ @Generated(from = "AutoModRuleData", generator = "Immutables")
/*      */ public final class ImmutableAutoModRuleData
/*      */   implements AutoModRuleData
/*      */ {
/*      */   private final long id_value;
/*      */   private final String name;
/*      */   private final long creatorId_value;
/*      */   private final long guildId_value;
/*      */   private final int eventType;
/*      */   private final int triggerType;
/*      */   private final AutoModTriggerMetaData triggerMetadata;
/*      */   private final List<AutoModActionData> actions;
/*      */   private final boolean enabled;
/*      */   private final long[] exemptRoles_value;
/*      */   private final long[] exemptChannels_value;
/*      */   private static final byte STAGE_INITIALIZING = -1;
/*      */   private static final byte STAGE_UNINITIALIZED = 0;
/*      */   private static final byte STAGE_INITIALIZED = 1;
/*      */   
/*      */   private ImmutableAutoModRuleData(Id id, String name, Id creatorId, Id guildId, int eventType, int triggerType, AutoModTriggerMetaData triggerMetadata, Iterable<? extends AutoModActionData> actions, boolean enabled, List<Id> exemptRoles, List<Id> exemptChannels) {
/*   55 */     Id id$impl = id;
/*   56 */     this.name = Objects.<String>requireNonNull(name, "name");
/*   57 */     Id creatorId$impl = creatorId;
/*   58 */     Id guildId$impl = guildId;
/*   59 */     this.eventType = eventType;
/*   60 */     this.triggerType = triggerType;
/*   61 */     this.triggerMetadata = Objects.<AutoModTriggerMetaData>requireNonNull(triggerMetadata, "triggerMetadata");
/*   62 */     this.actions = createUnmodifiableList(false, createSafeList(actions, true, false));
/*   63 */     this.enabled = enabled;
/*   64 */     List<Id> exemptRoles$impl = exemptRoles;
/*   65 */     List<Id> exemptChannels$impl = exemptChannels;
/*   66 */     this.id_value = id$impl.asLong();
/*   67 */     this.creatorId_value = creatorId$impl.asLong();
/*   68 */     this.guildId_value = guildId$impl.asLong();
/*   69 */     this
/*      */       
/*   71 */       .exemptRoles_value = exemptRoles$impl.stream().mapToLong(Id::asLong).toArray();
/*   72 */     this
/*      */       
/*   74 */       .exemptChannels_value = exemptChannels$impl.stream().mapToLong(Id::asLong).toArray();
/*   75 */     this.initShim = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ImmutableAutoModRuleData(ImmutableAutoModRuleData original, Id id, String name, Id creatorId, Id guildId, int eventType, int triggerType, AutoModTriggerMetaData triggerMetadata, List<AutoModActionData> actions, boolean enabled, List<Id> exemptRoles, List<Id> exemptChannels) {
/*   91 */     Id id$impl = id;
/*   92 */     this.name = name;
/*   93 */     Id creatorId$impl = creatorId;
/*   94 */     Id guildId$impl = guildId;
/*   95 */     this.eventType = eventType;
/*   96 */     this.triggerType = triggerType;
/*   97 */     this.triggerMetadata = triggerMetadata;
/*   98 */     this.actions = actions;
/*   99 */     this.enabled = enabled;
/*  100 */     List<Id> exemptRoles$impl = exemptRoles;
/*  101 */     List<Id> exemptChannels$impl = exemptChannels;
/*  102 */     this.id_value = id$impl.asLong();
/*  103 */     this.creatorId_value = creatorId$impl.asLong();
/*  104 */     this.guildId_value = guildId$impl.asLong();
/*  105 */     this
/*      */       
/*  107 */       .exemptRoles_value = exemptRoles$impl.stream().mapToLong(Id::asLong).toArray();
/*  108 */     this
/*      */       
/*  110 */       .exemptChannels_value = exemptChannels$impl.stream().mapToLong(Id::asLong).toArray();
/*  111 */     this.initShim = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  117 */   private volatile transient InitShim initShim = new InitShim();
/*      */   
/*      */   @Generated(from = "AutoModRuleData", generator = "Immutables")
/*      */   private final class InitShim {
/*      */     private String formatInitCycleMessage() {
/*  122 */       List<String> attributes = new ArrayList<>();
/*  123 */       return "Cannot build AutoModRuleData, attribute initializers form cycle " + attributes;
/*      */     }
/*      */ 
/*      */     
/*      */     private InitShim() {}
/*      */   }
/*      */ 
/*      */   
/*      */   @JsonProperty("id")
/*      */   public Id id() {
/*  133 */     return Id.of(this.id_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("name")
/*      */   public String name() {
/*  142 */     return this.name;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("creator_id")
/*      */   public Id creatorId() {
/*  151 */     return Id.of(this.creatorId_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("guild_id")
/*      */   public Id guildId() {
/*  160 */     return Id.of(this.guildId_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("event_type")
/*      */   public int eventType() {
/*  169 */     return this.eventType;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("trigger_type")
/*      */   public int triggerType() {
/*  178 */     return this.triggerType;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("trigger_metadata")
/*      */   public AutoModTriggerMetaData triggerMetadata() {
/*  187 */     return this.triggerMetadata;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("actions")
/*      */   public List<AutoModActionData> actions() {
/*  196 */     return this.actions;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("enabled")
/*      */   public boolean enabled() {
/*  205 */     return this.enabled;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("exempt_roles")
/*      */   public List<Id> exemptRoles() {
/*  214 */     return (List<Id>)LongStream.of(this.exemptRoles_value)
/*  215 */       .mapToObj(Id::of)
/*  216 */       .collect(Collectors.toList());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("exempt_channels")
/*      */   public List<Id> exemptChannels() {
/*  225 */     return (List<Id>)LongStream.of(this.exemptChannels_value)
/*  226 */       .mapToObj(Id::of)
/*  227 */       .collect(Collectors.toList());
/*      */   }
/*      */   
/*      */   public ImmutableAutoModRuleData withId(long value) {
/*  231 */     Id newValue = Id.of(value);
/*  232 */     return new ImmutableAutoModRuleData(this, newValue, this.name, 
/*      */ 
/*      */ 
/*      */         
/*  236 */         creatorId(), 
/*  237 */         guildId(), this.eventType, this.triggerType, this.triggerMetadata, this.actions, this.enabled, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  243 */         exemptRoles(), 
/*  244 */         exemptChannels());
/*      */   }
/*      */   
/*      */   public ImmutableAutoModRuleData withId(String value) {
/*  248 */     Id newValue = Id.of(value);
/*  249 */     return new ImmutableAutoModRuleData(this, newValue, this.name, 
/*      */ 
/*      */ 
/*      */         
/*  253 */         creatorId(), 
/*  254 */         guildId(), this.eventType, this.triggerType, this.triggerMetadata, this.actions, this.enabled, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  260 */         exemptRoles(), 
/*  261 */         exemptChannels());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableAutoModRuleData withName(String value) {
/*  271 */     String newValue = Objects.<String>requireNonNull(value, "name");
/*  272 */     if (this.name.equals(newValue)) return this; 
/*  273 */     return new ImmutableAutoModRuleData(this, 
/*      */         
/*  275 */         id(), newValue, 
/*      */         
/*  277 */         creatorId(), 
/*  278 */         guildId(), this.eventType, this.triggerType, this.triggerMetadata, this.actions, this.enabled, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  284 */         exemptRoles(), 
/*  285 */         exemptChannels());
/*      */   }
/*      */   
/*      */   public ImmutableAutoModRuleData withCreatorId(long value) {
/*  289 */     Id newValue = Id.of(value);
/*  290 */     return new ImmutableAutoModRuleData(this, 
/*      */         
/*  292 */         id(), this.name, newValue, 
/*      */ 
/*      */         
/*  295 */         guildId(), this.eventType, this.triggerType, this.triggerMetadata, this.actions, this.enabled, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  301 */         exemptRoles(), 
/*  302 */         exemptChannels());
/*      */   }
/*      */   
/*      */   public ImmutableAutoModRuleData withCreatorId(String value) {
/*  306 */     Id newValue = Id.of(value);
/*  307 */     return new ImmutableAutoModRuleData(this, 
/*      */         
/*  309 */         id(), this.name, newValue, 
/*      */ 
/*      */         
/*  312 */         guildId(), this.eventType, this.triggerType, this.triggerMetadata, this.actions, this.enabled, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  318 */         exemptRoles(), 
/*  319 */         exemptChannels());
/*      */   }
/*      */   
/*      */   public ImmutableAutoModRuleData withGuildId(long value) {
/*  323 */     Id newValue = Id.of(value);
/*  324 */     return new ImmutableAutoModRuleData(this, 
/*      */         
/*  326 */         id(), this.name, 
/*      */         
/*  328 */         creatorId(), newValue, this.eventType, this.triggerType, this.triggerMetadata, this.actions, this.enabled, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  335 */         exemptRoles(), 
/*  336 */         exemptChannels());
/*      */   }
/*      */   
/*      */   public ImmutableAutoModRuleData withGuildId(String value) {
/*  340 */     Id newValue = Id.of(value);
/*  341 */     return new ImmutableAutoModRuleData(this, 
/*      */         
/*  343 */         id(), this.name, 
/*      */         
/*  345 */         creatorId(), newValue, this.eventType, this.triggerType, this.triggerMetadata, this.actions, this.enabled, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  352 */         exemptRoles(), 
/*  353 */         exemptChannels());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableAutoModRuleData withEventType(int value) {
/*  363 */     if (this.eventType == value) return this; 
/*  364 */     return new ImmutableAutoModRuleData(this, 
/*      */         
/*  366 */         id(), this.name, 
/*      */         
/*  368 */         creatorId(), 
/*  369 */         guildId(), value, this.triggerType, this.triggerMetadata, this.actions, this.enabled, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  375 */         exemptRoles(), 
/*  376 */         exemptChannels());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableAutoModRuleData withTriggerType(int value) {
/*  386 */     if (this.triggerType == value) return this; 
/*  387 */     return new ImmutableAutoModRuleData(this, 
/*      */         
/*  389 */         id(), this.name, 
/*      */         
/*  391 */         creatorId(), 
/*  392 */         guildId(), this.eventType, value, this.triggerMetadata, this.actions, this.enabled, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  398 */         exemptRoles(), 
/*  399 */         exemptChannels());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableAutoModRuleData withTriggerMetadata(AutoModTriggerMetaData value) {
/*  409 */     if (this.triggerMetadata == value) return this; 
/*  410 */     AutoModTriggerMetaData newValue = Objects.<AutoModTriggerMetaData>requireNonNull(value, "triggerMetadata");
/*  411 */     return new ImmutableAutoModRuleData(this, 
/*      */         
/*  413 */         id(), this.name, 
/*      */         
/*  415 */         creatorId(), 
/*  416 */         guildId(), this.eventType, this.triggerType, newValue, this.actions, this.enabled, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  422 */         exemptRoles(), 
/*  423 */         exemptChannels());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableAutoModRuleData withActions(AutoModActionData... elements) {
/*  432 */     List<AutoModActionData> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/*  433 */     return new ImmutableAutoModRuleData(this, 
/*      */         
/*  435 */         id(), this.name, 
/*      */         
/*  437 */         creatorId(), 
/*  438 */         guildId(), this.eventType, this.triggerType, this.triggerMetadata, newValue, this.enabled, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  444 */         exemptRoles(), 
/*  445 */         exemptChannels());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableAutoModRuleData withActions(Iterable<? extends AutoModActionData> elements) {
/*  455 */     if (this.actions == elements) return this; 
/*  456 */     List<AutoModActionData> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/*  457 */     return new ImmutableAutoModRuleData(this, 
/*      */         
/*  459 */         id(), this.name, 
/*      */         
/*  461 */         creatorId(), 
/*  462 */         guildId(), this.eventType, this.triggerType, this.triggerMetadata, newValue, this.enabled, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  468 */         exemptRoles(), 
/*  469 */         exemptChannels());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableAutoModRuleData withEnabled(boolean value) {
/*  479 */     if (this.enabled == value) return this; 
/*  480 */     return new ImmutableAutoModRuleData(this, 
/*      */         
/*  482 */         id(), this.name, 
/*      */         
/*  484 */         creatorId(), 
/*  485 */         guildId(), this.eventType, this.triggerType, this.triggerMetadata, this.actions, value, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  491 */         exemptRoles(), 
/*  492 */         exemptChannels());
/*      */   }
/*      */   
/*      */   public ImmutableAutoModRuleData withExemptRoles(List<Id> value) {
/*  496 */     List<Id> newValue = value;
/*  497 */     return new ImmutableAutoModRuleData(this, 
/*      */         
/*  499 */         id(), this.name, 
/*      */         
/*  501 */         creatorId(), 
/*  502 */         guildId(), this.eventType, this.triggerType, this.triggerMetadata, this.actions, this.enabled, newValue, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  509 */         exemptChannels());
/*      */   }
/*      */   
/*      */   public ImmutableAutoModRuleData withExemptChannels(List<Id> value) {
/*  513 */     List<Id> newValue = value;
/*  514 */     return new ImmutableAutoModRuleData(this, 
/*      */         
/*  516 */         id(), this.name, 
/*      */         
/*  518 */         creatorId(), 
/*  519 */         guildId(), this.eventType, this.triggerType, this.triggerMetadata, this.actions, this.enabled, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  525 */         exemptRoles(), newValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean equals(Object another) {
/*  535 */     if (this == another) return true; 
/*  536 */     return (another instanceof ImmutableAutoModRuleData && 
/*  537 */       equalTo(0, (ImmutableAutoModRuleData)another));
/*      */   }
/*      */   
/*      */   private boolean equalTo(int synthetic, ImmutableAutoModRuleData another) {
/*  541 */     return (Objects.equals(Long.valueOf(this.id_value), Long.valueOf(another.id_value)) && this.name
/*  542 */       .equals(another.name) && 
/*  543 */       Objects.equals(Long.valueOf(this.creatorId_value), Long.valueOf(another.creatorId_value)) && 
/*  544 */       Objects.equals(Long.valueOf(this.guildId_value), Long.valueOf(another.guildId_value)) && this.eventType == another.eventType && this.triggerType == another.triggerType && this.triggerMetadata
/*      */ 
/*      */       
/*  547 */       .equals(another.triggerMetadata) && this.actions
/*  548 */       .equals(another.actions) && this.enabled == another.enabled && 
/*      */       
/*  550 */       Objects.equals(this.exemptRoles_value, another.exemptRoles_value) && 
/*  551 */       Objects.equals(this.exemptChannels_value, another.exemptChannels_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int hashCode() {
/*  560 */     int h = 5381;
/*  561 */     h += (h << 5) + Objects.hashCode(Long.valueOf(this.id_value));
/*  562 */     h += (h << 5) + this.name.hashCode();
/*  563 */     h += (h << 5) + Objects.hashCode(Long.valueOf(this.creatorId_value));
/*  564 */     h += (h << 5) + Objects.hashCode(Long.valueOf(this.guildId_value));
/*  565 */     h += (h << 5) + this.eventType;
/*  566 */     h += (h << 5) + this.triggerType;
/*  567 */     h += (h << 5) + this.triggerMetadata.hashCode();
/*  568 */     h += (h << 5) + this.actions.hashCode();
/*  569 */     h += (h << 5) + Boolean.hashCode(this.enabled);
/*  570 */     h += (h << 5) + Objects.hashCode(this.exemptRoles_value);
/*  571 */     h += (h << 5) + Objects.hashCode(this.exemptChannels_value);
/*  572 */     return h;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/*  581 */     return "AutoModRuleData{id=" + 
/*  582 */       Objects.toString(Long.valueOf(this.id_value)) + ", name=" + this.name + ", creatorId=" + 
/*      */       
/*  584 */       Objects.toString(Long.valueOf(this.creatorId_value)) + ", guildId=" + 
/*  585 */       Objects.toString(Long.valueOf(this.guildId_value)) + ", eventType=" + this.eventType + ", triggerType=" + this.triggerType + ", triggerMetadata=" + this.triggerMetadata + ", actions=" + this.actions + ", enabled=" + this.enabled + ", exemptRoles=" + 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  591 */       Objects.toString(this.exemptRoles_value) + ", exemptChannels=" + 
/*  592 */       Objects.toString(this.exemptChannels_value) + "}";
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonDeserialize
/*      */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*      */   @Generated(from = "AutoModRuleData", generator = "Immutables")
/*      */   static final class Json
/*      */     implements AutoModRuleData
/*      */   {
/*      */     Id id;
/*      */     
/*      */     String name;
/*      */     
/*      */     Id creatorId;
/*      */     Id guildId;
/*      */     int eventType;
/*      */     boolean eventTypeIsSet;
/*      */     int triggerType;
/*      */     boolean triggerTypeIsSet;
/*      */     AutoModTriggerMetaData triggerMetadata;
/*  614 */     List<AutoModActionData> actions = Collections.emptyList(); boolean enabled;
/*      */     boolean enabledIsSet;
/*      */     List<Id> exemptRoles;
/*      */     List<Id> exemptChannels;
/*      */     
/*      */     @JsonProperty("id")
/*      */     public void setId(Id id) {
/*  621 */       this.id = id;
/*      */     }
/*      */     @JsonProperty("name")
/*      */     public void setName(String name) {
/*  625 */       this.name = name;
/*      */     }
/*      */     @JsonProperty("creator_id")
/*      */     public void setCreatorId(Id creatorId) {
/*  629 */       this.creatorId = creatorId;
/*      */     }
/*      */     @JsonProperty("guild_id")
/*      */     public void setGuildId(Id guildId) {
/*  633 */       this.guildId = guildId;
/*      */     }
/*      */     @JsonProperty("event_type")
/*      */     public void setEventType(int eventType) {
/*  637 */       this.eventType = eventType;
/*  638 */       this.eventTypeIsSet = true;
/*      */     }
/*      */     @JsonProperty("trigger_type")
/*      */     public void setTriggerType(int triggerType) {
/*  642 */       this.triggerType = triggerType;
/*  643 */       this.triggerTypeIsSet = true;
/*      */     }
/*      */     @JsonProperty("trigger_metadata")
/*      */     public void setTriggerMetadata(AutoModTriggerMetaData triggerMetadata) {
/*  647 */       this.triggerMetadata = triggerMetadata;
/*      */     }
/*      */     @JsonProperty("actions")
/*      */     public void setActions(List<AutoModActionData> actions) {
/*  651 */       this.actions = actions;
/*      */     }
/*      */     @JsonProperty("enabled")
/*      */     public void setEnabled(boolean enabled) {
/*  655 */       this.enabled = enabled;
/*  656 */       this.enabledIsSet = true;
/*      */     }
/*      */     @JsonProperty("exempt_roles")
/*      */     public void setExemptRoles(List<Id> exemptRoles) {
/*  660 */       this.exemptRoles = exemptRoles;
/*      */     }
/*      */     @JsonProperty("exempt_channels")
/*      */     public void setExemptChannels(List<Id> exemptChannels) {
/*  664 */       this.exemptChannels = exemptChannels;
/*      */     }
/*      */     public Id id() {
/*  667 */       throw new UnsupportedOperationException();
/*      */     } public String name() {
/*  669 */       throw new UnsupportedOperationException();
/*      */     } public Id creatorId() {
/*  671 */       throw new UnsupportedOperationException();
/*      */     } public Id guildId() {
/*  673 */       throw new UnsupportedOperationException();
/*      */     } public int eventType() {
/*  675 */       throw new UnsupportedOperationException();
/*      */     } public int triggerType() {
/*  677 */       throw new UnsupportedOperationException();
/*      */     } public AutoModTriggerMetaData triggerMetadata() {
/*  679 */       throw new UnsupportedOperationException();
/*      */     } public List<AutoModActionData> actions() {
/*  681 */       throw new UnsupportedOperationException();
/*      */     } public boolean enabled() {
/*  683 */       throw new UnsupportedOperationException();
/*      */     } public List<Id> exemptRoles() {
/*  685 */       throw new UnsupportedOperationException();
/*      */     } public List<Id> exemptChannels() {
/*  687 */       throw new UnsupportedOperationException();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*      */   static ImmutableAutoModRuleData fromJson(Json json) {
/*  698 */     Builder builder = builder();
/*  699 */     if (json.id != null) {
/*  700 */       builder.id(json.id);
/*      */     }
/*  702 */     if (json.name != null) {
/*  703 */       builder.name(json.name);
/*      */     }
/*  705 */     if (json.creatorId != null) {
/*  706 */       builder.creatorId(json.creatorId);
/*      */     }
/*  708 */     if (json.guildId != null) {
/*  709 */       builder.guildId(json.guildId);
/*      */     }
/*  711 */     if (json.eventTypeIsSet) {
/*  712 */       builder.eventType(json.eventType);
/*      */     }
/*  714 */     if (json.triggerTypeIsSet) {
/*  715 */       builder.triggerType(json.triggerType);
/*      */     }
/*  717 */     if (json.triggerMetadata != null) {
/*  718 */       builder.triggerMetadata(json.triggerMetadata);
/*      */     }
/*  720 */     if (json.actions != null) {
/*  721 */       builder.addAllActions(json.actions);
/*      */     }
/*  723 */     if (json.enabledIsSet) {
/*  724 */       builder.enabled(json.enabled);
/*      */     }
/*  726 */     if (json.exemptRoles != null) {
/*  727 */       builder.exemptRoles(json.exemptRoles);
/*      */     }
/*  729 */     if (json.exemptChannels != null) {
/*  730 */       builder.exemptChannels(json.exemptChannels);
/*      */     }
/*  732 */     return builder.build();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableAutoModRuleData of(Id id, String name, Id creatorId, Id guildId, int eventType, int triggerType, AutoModTriggerMetaData triggerMetadata, List<AutoModActionData> actions, boolean enabled, List<Id> exemptRoles, List<Id> exemptChannels) {
/*  751 */     return of(id, name, creatorId, guildId, eventType, triggerType, triggerMetadata, actions, enabled, exemptRoles, exemptChannels);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableAutoModRuleData of(Id id, String name, Id creatorId, Id guildId, int eventType, int triggerType, AutoModTriggerMetaData triggerMetadata, Iterable<? extends AutoModActionData> actions, boolean enabled, List<Id> exemptRoles, List<Id> exemptChannels) {
/*  770 */     return new ImmutableAutoModRuleData(id, name, creatorId, guildId, eventType, triggerType, triggerMetadata, actions, enabled, exemptRoles, exemptChannels);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableAutoModRuleData copyOf(AutoModRuleData instance) {
/*  781 */     if (instance instanceof ImmutableAutoModRuleData) {
/*  782 */       return (ImmutableAutoModRuleData)instance;
/*      */     }
/*  784 */     return builder()
/*  785 */       .from(instance)
/*  786 */       .build();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Builder builder() {
/*  809 */     return new Builder();
/*      */   }
/*      */ 
/*      */   
/*      */   @Generated(from = "AutoModRuleData", generator = "Immutables")
/*      */   public static final class Builder
/*      */   {
/*      */     private static final long INIT_BIT_NAME = 1L;
/*      */     
/*      */     private static final long INIT_BIT_EVENT_TYPE = 2L;
/*      */     
/*      */     private static final long INIT_BIT_TRIGGER_TYPE = 4L;
/*      */     
/*      */     private static final long INIT_BIT_TRIGGER_METADATA = 8L;
/*      */     
/*      */     private static final long INIT_BIT_ENABLED = 16L;
/*      */     
/*  826 */     private long initBits = 31L;
/*      */     
/*  828 */     private Id id_id = null;
/*  829 */     private Id creatorId_id = null;
/*  830 */     private Id guildId_id = null;
/*  831 */     private List<Long> exemptRoles_list = null;
/*  832 */     private List<Long> exemptChannels_list = null;
/*      */     private String name;
/*      */     private int eventType;
/*      */     private int triggerType;
/*      */     private AutoModTriggerMetaData triggerMetadata;
/*  837 */     private List<AutoModActionData> actions = new ArrayList<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private boolean enabled;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder from(AutoModRuleData instance) {
/*  852 */       Objects.requireNonNull(instance, "instance");
/*  853 */       id(instance.id());
/*  854 */       name(instance.name());
/*  855 */       creatorId(instance.creatorId());
/*  856 */       guildId(instance.guildId());
/*  857 */       eventType(instance.eventType());
/*  858 */       triggerType(instance.triggerType());
/*  859 */       triggerMetadata(instance.triggerMetadata());
/*  860 */       addAllActions(instance.actions());
/*  861 */       enabled(instance.enabled());
/*  862 */       exemptRoles(instance.exemptRoles());
/*  863 */       exemptChannels(instance.exemptChannels());
/*  864 */       return this;
/*      */     }
/*      */     
/*      */     public Builder id(String value) {
/*  868 */       this.id_id = Id.of(value);
/*  869 */       return this;
/*      */     }
/*      */     
/*      */     public Builder id(long value) {
/*  873 */       this.id_id = Id.of(value);
/*  874 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("id")
/*      */     public Builder id(Id value) {
/*  879 */       this.id_id = value;
/*  880 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("name")
/*      */     public final Builder name(String name) {
/*  890 */       this.name = Objects.<String>requireNonNull(name, "name");
/*  891 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/*  892 */       return this;
/*      */     }
/*      */     
/*      */     public Builder creatorId(String value) {
/*  896 */       this.creatorId_id = Id.of(value);
/*  897 */       return this;
/*      */     }
/*      */     
/*      */     public Builder creatorId(long value) {
/*  901 */       this.creatorId_id = Id.of(value);
/*  902 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("creator_id")
/*      */     public Builder creatorId(Id value) {
/*  907 */       this.creatorId_id = value;
/*  908 */       return this;
/*      */     }
/*      */     
/*      */     public Builder guildId(String value) {
/*  912 */       this.guildId_id = Id.of(value);
/*  913 */       return this;
/*      */     }
/*      */     
/*      */     public Builder guildId(long value) {
/*  917 */       this.guildId_id = Id.of(value);
/*  918 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("guild_id")
/*      */     public Builder guildId(Id value) {
/*  923 */       this.guildId_id = value;
/*  924 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("event_type")
/*      */     public final Builder eventType(int eventType) {
/*  934 */       this.eventType = eventType;
/*  935 */       this.initBits &= 0xFFFFFFFFFFFFFFFDL;
/*  936 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("trigger_type")
/*      */     public final Builder triggerType(int triggerType) {
/*  946 */       this.triggerType = triggerType;
/*  947 */       this.initBits &= 0xFFFFFFFFFFFFFFFBL;
/*  948 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("trigger_metadata")
/*      */     public final Builder triggerMetadata(AutoModTriggerMetaData triggerMetadata) {
/*  958 */       this.triggerMetadata = Objects.<AutoModTriggerMetaData>requireNonNull(triggerMetadata, "triggerMetadata");
/*  959 */       this.initBits &= 0xFFFFFFFFFFFFFFF7L;
/*  960 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addAction(AutoModActionData element) {
/*  969 */       this.actions.add(Objects.<AutoModActionData>requireNonNull(element, "actions element"));
/*  970 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addActions(AutoModActionData... elements) {
/*  979 */       for (AutoModActionData element : elements) {
/*  980 */         this.actions.add(Objects.<AutoModActionData>requireNonNull(element, "actions element"));
/*      */       }
/*  982 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("actions")
/*      */     public final Builder actions(Iterable<? extends AutoModActionData> elements) {
/*  993 */       this.actions.clear();
/*  994 */       return addAllActions(elements);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addAllActions(Iterable<? extends AutoModActionData> elements) {
/* 1003 */       for (AutoModActionData element : elements) {
/* 1004 */         this.actions.add(Objects.<AutoModActionData>requireNonNull(element, "actions element"));
/*      */       }
/* 1006 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("enabled")
/*      */     public final Builder enabled(boolean enabled) {
/* 1016 */       this.enabled = enabled;
/* 1017 */       this.initBits &= 0xFFFFFFFFFFFFFFEFL;
/* 1018 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addExemptRole(long element) {
/* 1022 */       exemptRoles_getOrCreate().add(Long.valueOf(element));
/* 1023 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addExemptRole(String element) {
/* 1027 */       exemptRoles_getOrCreate().add(Long.valueOf(Id.of(element).asLong()));
/* 1028 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addExemptRole(Id element) {
/* 1032 */       exemptRoles_getOrCreate().add(Long.valueOf(element.asLong()));
/* 1033 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addAllExemptRoles(List<Long> elements) {
/* 1037 */       exemptRoles_getOrCreate().addAll(elements);
/* 1038 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("exempt_roles")
/*      */     public Builder exemptRoles(List<Id> elements) {
/* 1043 */       this.exemptRoles_list = (List<Long>)elements.stream().map(Id::asLong).collect(Collectors.toList());
/* 1044 */       return this;
/*      */     }
/*      */     
/*      */     public Builder exemptRoles(Iterable<Id> elements) {
/* 1048 */       this
/*      */         
/* 1050 */         .exemptRoles_list = (List<Long>)StreamSupport.stream(elements.spliterator(), false).map(Id::asLong).collect(Collectors.toList());
/* 1051 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addExemptChannel(long element) {
/* 1055 */       exemptChannels_getOrCreate().add(Long.valueOf(element));
/* 1056 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addExemptChannel(String element) {
/* 1060 */       exemptChannels_getOrCreate().add(Long.valueOf(Id.of(element).asLong()));
/* 1061 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addExemptChannel(Id element) {
/* 1065 */       exemptChannels_getOrCreate().add(Long.valueOf(element.asLong()));
/* 1066 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addAllExemptChannels(List<Long> elements) {
/* 1070 */       exemptChannels_getOrCreate().addAll(elements);
/* 1071 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("exempt_channels")
/*      */     public Builder exemptChannels(List<Id> elements) {
/* 1076 */       this.exemptChannels_list = (List<Long>)elements.stream().map(Id::asLong).collect(Collectors.toList());
/* 1077 */       return this;
/*      */     }
/*      */     
/*      */     public Builder exemptChannels(Iterable<Id> elements) {
/* 1081 */       this
/*      */         
/* 1083 */         .exemptChannels_list = (List<Long>)StreamSupport.stream(elements.spliterator(), false).map(Id::asLong).collect(Collectors.toList());
/* 1084 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ImmutableAutoModRuleData build() {
/* 1093 */       if (this.initBits != 0L) {
/* 1094 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*      */       }
/* 1096 */       return new ImmutableAutoModRuleData(null, 
/*      */           
/* 1098 */           id_build(), this.name, 
/*      */           
/* 1100 */           creatorId_build(), 
/* 1101 */           guildId_build(), this.eventType, this.triggerType, this.triggerMetadata, ImmutableAutoModRuleData
/*      */ 
/*      */ 
/*      */           
/* 1105 */           .createUnmodifiableList(true, (List)this.actions), this.enabled, 
/*      */           
/* 1107 */           exemptRoles_build(), 
/* 1108 */           exemptChannels_build());
/*      */     }
/*      */     
/*      */     private String formatRequiredAttributesMessage() {
/* 1112 */       List<String> attributes = new ArrayList<>();
/* 1113 */       if ((this.initBits & 0x1L) != 0L) attributes.add("name"); 
/* 1114 */       if ((this.initBits & 0x2L) != 0L) attributes.add("eventType"); 
/* 1115 */       if ((this.initBits & 0x4L) != 0L) attributes.add("triggerType"); 
/* 1116 */       if ((this.initBits & 0x8L) != 0L) attributes.add("triggerMetadata"); 
/* 1117 */       if ((this.initBits & 0x10L) != 0L) attributes.add("enabled"); 
/* 1118 */       return "Cannot build AutoModRuleData, some of required attributes are not set " + attributes;
/*      */     }
/*      */     
/*      */     private Id id_build() {
/* 1122 */       return this.id_id;
/*      */     }
/*      */     
/*      */     private Id creatorId_build() {
/* 1126 */       return this.creatorId_id;
/*      */     }
/*      */     
/*      */     private Id guildId_build() {
/* 1130 */       return this.guildId_id;
/*      */     }
/*      */     
/*      */     private List<Id> exemptRoles_build() {
/* 1134 */       return (List<Id>)exemptRoles_getOrCreate().stream().map(Id::of).collect(Collectors.toList());
/*      */     }
/*      */     
/*      */     private List<Long> exemptRoles_getOrCreate() {
/* 1138 */       if (this.exemptRoles_list == null) {
/* 1139 */         this.exemptRoles_list = new ArrayList<>();
/*      */       }
/* 1141 */       return this.exemptRoles_list;
/*      */     }
/*      */     
/*      */     private List<Id> exemptChannels_build() {
/* 1145 */       return (List<Id>)exemptChannels_getOrCreate().stream().map(Id::of).collect(Collectors.toList());
/*      */     }
/*      */     
/*      */     private List<Long> exemptChannels_getOrCreate() {
/* 1149 */       if (this.exemptChannels_list == null) {
/* 1150 */         this.exemptChannels_list = new ArrayList<>();
/*      */       }
/* 1152 */       return this.exemptChannels_list;
/*      */     }
/*      */     private Builder() {} }
/*      */   
/*      */   private static <T> List<T> createSafeList(Iterable<? extends T> iterable, boolean checkNulls, boolean skipNulls) {
/*      */     ArrayList<T> list;
/* 1158 */     if (iterable instanceof Collection) {
/* 1159 */       int size = ((Collection)iterable).size();
/* 1160 */       if (size == 0) return Collections.emptyList(); 
/* 1161 */       list = new ArrayList<>();
/*      */     } else {
/* 1163 */       list = new ArrayList<>();
/*      */     } 
/* 1165 */     for (T element : iterable) {
/* 1166 */       if (skipNulls && element == null)
/* 1167 */         continue;  if (checkNulls) Objects.requireNonNull(element, "element"); 
/* 1168 */       list.add(element);
/*      */     } 
/* 1170 */     return list;
/*      */   }
/*      */   
/*      */   private static <T> List<T> createUnmodifiableList(boolean clone, List<T> list) {
/* 1174 */     switch (list.size()) { case 0:
/* 1175 */         return Collections.emptyList();
/* 1176 */       case 1: return Collections.singletonList(list.get(0)); }
/*      */     
/* 1178 */     if (clone) {
/* 1179 */       return Collections.unmodifiableList(new ArrayList<>(list));
/*      */     }
/* 1181 */     if (list instanceof ArrayList) {
/* 1182 */       ((ArrayList)list).trimToSize();
/*      */     }
/* 1184 */     return Collections.unmodifiableList(list);
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableAutoModRuleData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */