/*      */ package discord4j.discordjson.json;
/*      */ 
/*      */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*      */ import com.fasterxml.jackson.annotation.JsonCreator;
/*      */ import com.fasterxml.jackson.annotation.JsonProperty;
/*      */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*      */ import discord4j.discordjson.Id;
/*      */ import discord4j.discordjson.possible.Possible;
/*      */ import java.util.ArrayList;
/*      */ import java.util.List;
/*      */ import java.util.Objects;
/*      */ import java.util.Optional;
/*      */ import org.immutables.value.Generated;
/*      */ import reactor.util.annotation.Nullable;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ @Generated(from = "ActivityData", generator = "Immutables")
/*      */ public final class ImmutableActivityData
/*      */   implements ActivityData
/*      */ {
/*      */   private final String name;
/*      */   private final int type;
/*      */   private final String id;
/*      */   private final String url_value;
/*      */   private final boolean url_absent;
/*      */   private final long createdAt;
/*      */   private final ActivityTimestampsData timestamps_value;
/*      */   private final boolean timestamps_absent;
/*      */   private final long applicationId_value;
/*      */   private final boolean applicationId_absent;
/*      */   private final String details_value;
/*      */   private final boolean details_absent;
/*      */   private final String state_value;
/*      */   private final boolean state_absent;
/*      */   private final ActivityEmojiData emoji_value;
/*      */   private final boolean emoji_absent;
/*      */   private final ActivityPartyData party_value;
/*      */   private final boolean party_absent;
/*      */   private final ActivityAssetsData assets_value;
/*      */   private final boolean assets_absent;
/*      */   private final ActivitySecretsData secrets_value;
/*      */   private final boolean secrets_absent;
/*      */   private final Boolean instance_value;
/*      */   private final boolean instance_absent;
/*      */   private final Integer flags_value;
/*      */   private final boolean flags_absent;
/*      */   private static final byte STAGE_INITIALIZING = -1;
/*      */   private static final byte STAGE_UNINITIALIZED = 0;
/*      */   private static final byte STAGE_INITIALIZED = 1;
/*      */   private volatile transient InitShim initShim;
/*      */   
/*      */   private ImmutableActivityData(String name, int type, String id, Possible<Optional<String>> url, long createdAt, Possible<ActivityTimestampsData> timestamps, Possible<Id> applicationId, Possible<Optional<String>> details, Possible<Optional<String>> state, Possible<Optional<ActivityEmojiData>> emoji, Possible<ActivityPartyData> party, Possible<ActivityAssetsData> assets, Possible<ActivitySecretsData> secrets, Possible<Boolean> instance, Possible<Integer> flags) {
/*  175 */     this.initShim = new InitShim(); this.name = Objects.<String>requireNonNull(name, "name"); this.type = type; this.id = Objects.<String>requireNonNull(id, "id"); Possible<Optional<String>> url$impl = url; this.createdAt = createdAt; Possible<ActivityTimestampsData> timestamps$impl = timestamps; Possible<Id> applicationId$impl = applicationId; Possible<Optional<String>> details$impl = details; Possible<Optional<String>> state$impl = state; Possible<Optional<ActivityEmojiData>> emoji$impl = emoji; Possible<ActivityPartyData> party$impl = party; Possible<ActivityAssetsData> assets$impl = assets; Possible<ActivitySecretsData> secrets$impl = secrets; Possible<Boolean> instance$impl = instance; Possible<Integer> flags$impl = flags; this.url_value = Possible.flatOpt(url$impl).orElse(null); this.url_absent = url$impl.isAbsent(); this.timestamps_value = timestamps$impl.toOptional().orElse(null); this.timestamps_absent = timestamps$impl.isAbsent(); this.applicationId_value = ((Long)applicationId$impl.toOptional().map(Id::asLong).orElse(Long.valueOf(0L))).longValue(); this.applicationId_absent = applicationId$impl.isAbsent(); this.details_value = Possible.flatOpt(details$impl).orElse(null); this.details_absent = details$impl.isAbsent(); this.state_value = Possible.flatOpt(state$impl).orElse(null); this.state_absent = state$impl.isAbsent(); this.emoji_value = Possible.flatOpt(emoji$impl).orElse(null); this.emoji_absent = emoji$impl.isAbsent(); this.party_value = party$impl.toOptional().orElse(null); this.party_absent = party$impl.isAbsent(); this.assets_value = assets$impl.toOptional().orElse(null); this.assets_absent = assets$impl.isAbsent(); this.secrets_value = secrets$impl.toOptional().orElse(null); this.secrets_absent = secrets$impl.isAbsent(); this.instance_value = instance$impl.toOptional().orElse(null); this.instance_absent = instance$impl.isAbsent(); this.flags_value = flags$impl.toOptional().orElse(null); this.flags_absent = flags$impl.isAbsent(); this.initShim = null; } private ImmutableActivityData(ImmutableActivityData original, String name, int type, String id, Possible<Optional<String>> url, long createdAt, Possible<ActivityTimestampsData> timestamps, Possible<Id> applicationId, Possible<Optional<String>> details, Possible<Optional<String>> state, Possible<Optional<ActivityEmojiData>> emoji, Possible<ActivityPartyData> party, Possible<ActivityAssetsData> assets, Possible<ActivitySecretsData> secrets, Possible<Boolean> instance, Possible<Integer> flags) { this.initShim = new InitShim(); this.name = name; this.type = type; this.id = id; Possible<Optional<String>> url$impl = url; this.createdAt = createdAt; Possible<ActivityTimestampsData> timestamps$impl = timestamps; Possible<Id> applicationId$impl = applicationId; Possible<Optional<String>> details$impl = details; Possible<Optional<String>> state$impl = state; Possible<Optional<ActivityEmojiData>> emoji$impl = emoji; Possible<ActivityPartyData> party$impl = party; Possible<ActivityAssetsData> assets$impl = assets; Possible<ActivitySecretsData> secrets$impl = secrets; Possible<Boolean> instance$impl = instance; Possible<Integer> flags$impl = flags; this.url_value = Possible.flatOpt(url$impl).orElse(null); this.url_absent = url$impl.isAbsent(); this.timestamps_value = timestamps$impl.toOptional().orElse(null); this.timestamps_absent = timestamps$impl.isAbsent(); this.applicationId_value = ((Long)applicationId$impl.toOptional().map(Id::asLong).orElse(Long.valueOf(0L))).longValue(); this.applicationId_absent = applicationId$impl.isAbsent(); this.details_value = Possible.flatOpt(details$impl).orElse(null); this.details_absent = details$impl.isAbsent(); this.state_value = Possible.flatOpt(state$impl).orElse(null); this.state_absent = state$impl.isAbsent(); this.emoji_value = Possible.flatOpt(emoji$impl).orElse(null); this.emoji_absent = emoji$impl.isAbsent(); this.party_value = party$impl.toOptional().orElse(null); this.party_absent = party$impl.isAbsent(); this.assets_value = assets$impl.toOptional().orElse(null); this.assets_absent = assets$impl.isAbsent(); this.secrets_value = secrets$impl.toOptional().orElse(null); this.secrets_absent = secrets$impl.isAbsent();
/*      */     this.instance_value = instance$impl.toOptional().orElse(null);
/*      */     this.instance_absent = instance$impl.isAbsent();
/*      */     this.flags_value = flags$impl.toOptional().orElse(null);
/*      */     this.flags_absent = flags$impl.isAbsent();
/*  180 */     this.initShim = null; } @Generated(from = "ActivityData", generator = "Immutables") private final class InitShim { private InitShim() {} private String formatInitCycleMessage() { List<String> attributes = new ArrayList<>();
/*  181 */       return "Cannot build ActivityData, attribute initializers form cycle " + attributes; }
/*      */      }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("name")
/*      */   public String name() {
/*  191 */     return this.name;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("type")
/*      */   public int type() {
/*  200 */     return this.type;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("id")
/*      */   public String id() {
/*  209 */     return this.id;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("url")
/*      */   public Possible<Optional<String>> url() {
/*  218 */     return this.url_absent ? Possible.absent() : 
/*  219 */       Possible.of(Optional.ofNullable(this.url_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("created_at")
/*      */   public long createdAt() {
/*  228 */     return this.createdAt;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("timestamps")
/*      */   public Possible<ActivityTimestampsData> timestamps() {
/*  237 */     return this.timestamps_absent ? Possible.absent() : Possible.of(this.timestamps_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("application_id")
/*      */   public Possible<Id> applicationId() {
/*  246 */     return this.applicationId_absent ? Possible.absent() : 
/*  247 */       Possible.of(Id.of(this.applicationId_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("details")
/*      */   public Possible<Optional<String>> details() {
/*  256 */     return this.details_absent ? Possible.absent() : 
/*  257 */       Possible.of(Optional.ofNullable(this.details_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("state")
/*      */   public Possible<Optional<String>> state() {
/*  266 */     return this.state_absent ? Possible.absent() : 
/*  267 */       Possible.of(Optional.ofNullable(this.state_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("emoji")
/*      */   public Possible<Optional<ActivityEmojiData>> emoji() {
/*  276 */     return this.emoji_absent ? Possible.absent() : 
/*  277 */       Possible.of(Optional.ofNullable(this.emoji_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("party")
/*      */   public Possible<ActivityPartyData> party() {
/*  286 */     return this.party_absent ? Possible.absent() : Possible.of(this.party_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("assets")
/*      */   public Possible<ActivityAssetsData> assets() {
/*  295 */     return this.assets_absent ? Possible.absent() : Possible.of(this.assets_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("secrets")
/*      */   public Possible<ActivitySecretsData> secrets() {
/*  304 */     return this.secrets_absent ? Possible.absent() : Possible.of(this.secrets_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("instance")
/*      */   public Possible<Boolean> instance() {
/*  313 */     return this.instance_absent ? Possible.absent() : Possible.of(this.instance_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("flags")
/*      */   public Possible<Integer> flags() {
/*  322 */     return this.flags_absent ? Possible.absent() : Possible.of(this.flags_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableActivityData withName(String value) {
/*  332 */     String newValue = Objects.<String>requireNonNull(value, "name");
/*  333 */     if (this.name.equals(newValue)) return this; 
/*  334 */     return new ImmutableActivityData(this, newValue, this.type, this.id, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  339 */         url(), this.createdAt, 
/*      */         
/*  341 */         timestamps(), 
/*  342 */         applicationId(), 
/*  343 */         details(), 
/*  344 */         state(), 
/*  345 */         emoji(), 
/*  346 */         party(), 
/*  347 */         assets(), 
/*  348 */         secrets(), 
/*  349 */         instance(), 
/*  350 */         flags());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableActivityData withType(int value) {
/*  360 */     if (this.type == value) return this; 
/*  361 */     return new ImmutableActivityData(this, this.name, value, this.id, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  366 */         url(), this.createdAt, 
/*      */         
/*  368 */         timestamps(), 
/*  369 */         applicationId(), 
/*  370 */         details(), 
/*  371 */         state(), 
/*  372 */         emoji(), 
/*  373 */         party(), 
/*  374 */         assets(), 
/*  375 */         secrets(), 
/*  376 */         instance(), 
/*  377 */         flags());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableActivityData withId(String value) {
/*  387 */     String newValue = Objects.<String>requireNonNull(value, "id");
/*  388 */     if (this.id.equals(newValue)) return this; 
/*  389 */     return new ImmutableActivityData(this, this.name, this.type, newValue, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  394 */         url(), this.createdAt, 
/*      */         
/*  396 */         timestamps(), 
/*  397 */         applicationId(), 
/*  398 */         details(), 
/*  399 */         state(), 
/*  400 */         emoji(), 
/*  401 */         party(), 
/*  402 */         assets(), 
/*  403 */         secrets(), 
/*  404 */         instance(), 
/*  405 */         flags());
/*      */   }
/*      */   
/*      */   public ImmutableActivityData withUrl(Possible<Optional<String>> value) {
/*  409 */     Possible<Optional<String>> newValue = Objects.<Possible<Optional<String>>>requireNonNull(value);
/*  410 */     return new ImmutableActivityData(this, this.name, this.type, this.id, newValue, this.createdAt, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  417 */         timestamps(), 
/*  418 */         applicationId(), 
/*  419 */         details(), 
/*  420 */         state(), 
/*  421 */         emoji(), 
/*  422 */         party(), 
/*  423 */         assets(), 
/*  424 */         secrets(), 
/*  425 */         instance(), 
/*  426 */         flags());
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public ImmutableActivityData withUrl(@Nullable String value) {
/*  431 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/*  432 */     return new ImmutableActivityData(this, this.name, this.type, this.id, newValue, this.createdAt, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  439 */         timestamps(), 
/*  440 */         applicationId(), 
/*  441 */         details(), 
/*  442 */         state(), 
/*  443 */         emoji(), 
/*  444 */         party(), 
/*  445 */         assets(), 
/*  446 */         secrets(), 
/*  447 */         instance(), 
/*  448 */         flags());
/*      */   }
/*      */   
/*      */   public ImmutableActivityData withUrlOrNull(@Nullable String value) {
/*  452 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/*  453 */     return new ImmutableActivityData(this, this.name, this.type, this.id, newValue, this.createdAt, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  460 */         timestamps(), 
/*  461 */         applicationId(), 
/*  462 */         details(), 
/*  463 */         state(), 
/*  464 */         emoji(), 
/*  465 */         party(), 
/*  466 */         assets(), 
/*  467 */         secrets(), 
/*  468 */         instance(), 
/*  469 */         flags());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableActivityData withCreatedAt(long value) {
/*  479 */     if (this.createdAt == value) return this; 
/*  480 */     return new ImmutableActivityData(this, this.name, this.type, this.id, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  485 */         url(), value, 
/*      */         
/*  487 */         timestamps(), 
/*  488 */         applicationId(), 
/*  489 */         details(), 
/*  490 */         state(), 
/*  491 */         emoji(), 
/*  492 */         party(), 
/*  493 */         assets(), 
/*  494 */         secrets(), 
/*  495 */         instance(), 
/*  496 */         flags());
/*      */   }
/*      */   
/*      */   public ImmutableActivityData withTimestamps(Possible<ActivityTimestampsData> value) {
/*  500 */     Possible<ActivityTimestampsData> newValue = Objects.<Possible<ActivityTimestampsData>>requireNonNull(value);
/*  501 */     return new ImmutableActivityData(this, this.name, this.type, this.id, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  506 */         url(), this.createdAt, newValue, 
/*      */ 
/*      */         
/*  509 */         applicationId(), 
/*  510 */         details(), 
/*  511 */         state(), 
/*  512 */         emoji(), 
/*  513 */         party(), 
/*  514 */         assets(), 
/*  515 */         secrets(), 
/*  516 */         instance(), 
/*  517 */         flags());
/*      */   }
/*      */   
/*      */   public ImmutableActivityData withTimestamps(ActivityTimestampsData value) {
/*  521 */     Possible<ActivityTimestampsData> newValue = Possible.of(value);
/*  522 */     return new ImmutableActivityData(this, this.name, this.type, this.id, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  527 */         url(), this.createdAt, newValue, 
/*      */ 
/*      */         
/*  530 */         applicationId(), 
/*  531 */         details(), 
/*  532 */         state(), 
/*  533 */         emoji(), 
/*  534 */         party(), 
/*  535 */         assets(), 
/*  536 */         secrets(), 
/*  537 */         instance(), 
/*  538 */         flags());
/*      */   }
/*      */   
/*      */   public ImmutableActivityData withApplicationId(Possible<Id> value) {
/*  542 */     Possible<Id> newValue = Objects.<Possible<Id>>requireNonNull(value);
/*  543 */     return new ImmutableActivityData(this, this.name, this.type, this.id, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  548 */         url(), this.createdAt, 
/*      */         
/*  550 */         timestamps(), newValue, 
/*      */         
/*  552 */         details(), 
/*  553 */         state(), 
/*  554 */         emoji(), 
/*  555 */         party(), 
/*  556 */         assets(), 
/*  557 */         secrets(), 
/*  558 */         instance(), 
/*  559 */         flags());
/*      */   }
/*      */   
/*      */   public ImmutableActivityData withApplicationId(long value) {
/*  563 */     Possible<Id> newValue = Possible.of(Id.of(value));
/*  564 */     return new ImmutableActivityData(this, this.name, this.type, this.id, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  569 */         url(), this.createdAt, 
/*      */         
/*  571 */         timestamps(), newValue, 
/*      */         
/*  573 */         details(), 
/*  574 */         state(), 
/*  575 */         emoji(), 
/*  576 */         party(), 
/*  577 */         assets(), 
/*  578 */         secrets(), 
/*  579 */         instance(), 
/*  580 */         flags());
/*      */   }
/*      */   
/*      */   public ImmutableActivityData withDetails(Possible<Optional<String>> value) {
/*  584 */     Possible<Optional<String>> newValue = Objects.<Possible<Optional<String>>>requireNonNull(value);
/*  585 */     return new ImmutableActivityData(this, this.name, this.type, this.id, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  590 */         url(), this.createdAt, 
/*      */         
/*  592 */         timestamps(), 
/*  593 */         applicationId(), newValue, 
/*      */         
/*  595 */         state(), 
/*  596 */         emoji(), 
/*  597 */         party(), 
/*  598 */         assets(), 
/*  599 */         secrets(), 
/*  600 */         instance(), 
/*  601 */         flags());
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public ImmutableActivityData withDetails(@Nullable String value) {
/*  606 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/*  607 */     return new ImmutableActivityData(this, this.name, this.type, this.id, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  612 */         url(), this.createdAt, 
/*      */         
/*  614 */         timestamps(), 
/*  615 */         applicationId(), newValue, 
/*      */         
/*  617 */         state(), 
/*  618 */         emoji(), 
/*  619 */         party(), 
/*  620 */         assets(), 
/*  621 */         secrets(), 
/*  622 */         instance(), 
/*  623 */         flags());
/*      */   }
/*      */   
/*      */   public ImmutableActivityData withDetailsOrNull(@Nullable String value) {
/*  627 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/*  628 */     return new ImmutableActivityData(this, this.name, this.type, this.id, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  633 */         url(), this.createdAt, 
/*      */         
/*  635 */         timestamps(), 
/*  636 */         applicationId(), newValue, 
/*      */         
/*  638 */         state(), 
/*  639 */         emoji(), 
/*  640 */         party(), 
/*  641 */         assets(), 
/*  642 */         secrets(), 
/*  643 */         instance(), 
/*  644 */         flags());
/*      */   }
/*      */   
/*      */   public ImmutableActivityData withState(Possible<Optional<String>> value) {
/*  648 */     Possible<Optional<String>> newValue = Objects.<Possible<Optional<String>>>requireNonNull(value);
/*  649 */     return new ImmutableActivityData(this, this.name, this.type, this.id, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  654 */         url(), this.createdAt, 
/*      */         
/*  656 */         timestamps(), 
/*  657 */         applicationId(), 
/*  658 */         details(), newValue, 
/*      */         
/*  660 */         emoji(), 
/*  661 */         party(), 
/*  662 */         assets(), 
/*  663 */         secrets(), 
/*  664 */         instance(), 
/*  665 */         flags());
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public ImmutableActivityData withState(@Nullable String value) {
/*  670 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/*  671 */     return new ImmutableActivityData(this, this.name, this.type, this.id, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  676 */         url(), this.createdAt, 
/*      */         
/*  678 */         timestamps(), 
/*  679 */         applicationId(), 
/*  680 */         details(), newValue, 
/*      */         
/*  682 */         emoji(), 
/*  683 */         party(), 
/*  684 */         assets(), 
/*  685 */         secrets(), 
/*  686 */         instance(), 
/*  687 */         flags());
/*      */   }
/*      */   
/*      */   public ImmutableActivityData withStateOrNull(@Nullable String value) {
/*  691 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/*  692 */     return new ImmutableActivityData(this, this.name, this.type, this.id, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  697 */         url(), this.createdAt, 
/*      */         
/*  699 */         timestamps(), 
/*  700 */         applicationId(), 
/*  701 */         details(), newValue, 
/*      */         
/*  703 */         emoji(), 
/*  704 */         party(), 
/*  705 */         assets(), 
/*  706 */         secrets(), 
/*  707 */         instance(), 
/*  708 */         flags());
/*      */   }
/*      */   
/*      */   public ImmutableActivityData withEmoji(Possible<Optional<ActivityEmojiData>> value) {
/*  712 */     Possible<Optional<ActivityEmojiData>> newValue = Objects.<Possible<Optional<ActivityEmojiData>>>requireNonNull(value);
/*  713 */     return new ImmutableActivityData(this, this.name, this.type, this.id, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  718 */         url(), this.createdAt, 
/*      */         
/*  720 */         timestamps(), 
/*  721 */         applicationId(), 
/*  722 */         details(), 
/*  723 */         state(), newValue, 
/*      */         
/*  725 */         party(), 
/*  726 */         assets(), 
/*  727 */         secrets(), 
/*  728 */         instance(), 
/*  729 */         flags());
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public ImmutableActivityData withEmoji(@Nullable ActivityEmojiData value) {
/*  734 */     Possible<Optional<ActivityEmojiData>> newValue = Possible.of(Optional.ofNullable(value));
/*  735 */     return new ImmutableActivityData(this, this.name, this.type, this.id, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  740 */         url(), this.createdAt, 
/*      */         
/*  742 */         timestamps(), 
/*  743 */         applicationId(), 
/*  744 */         details(), 
/*  745 */         state(), newValue, 
/*      */         
/*  747 */         party(), 
/*  748 */         assets(), 
/*  749 */         secrets(), 
/*  750 */         instance(), 
/*  751 */         flags());
/*      */   }
/*      */   
/*      */   public ImmutableActivityData withEmojiOrNull(@Nullable ActivityEmojiData value) {
/*  755 */     Possible<Optional<ActivityEmojiData>> newValue = Possible.of(Optional.ofNullable(value));
/*  756 */     return new ImmutableActivityData(this, this.name, this.type, this.id, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  761 */         url(), this.createdAt, 
/*      */         
/*  763 */         timestamps(), 
/*  764 */         applicationId(), 
/*  765 */         details(), 
/*  766 */         state(), newValue, 
/*      */         
/*  768 */         party(), 
/*  769 */         assets(), 
/*  770 */         secrets(), 
/*  771 */         instance(), 
/*  772 */         flags());
/*      */   }
/*      */   
/*      */   public ImmutableActivityData withParty(Possible<ActivityPartyData> value) {
/*  776 */     Possible<ActivityPartyData> newValue = Objects.<Possible<ActivityPartyData>>requireNonNull(value);
/*  777 */     return new ImmutableActivityData(this, this.name, this.type, this.id, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  782 */         url(), this.createdAt, 
/*      */         
/*  784 */         timestamps(), 
/*  785 */         applicationId(), 
/*  786 */         details(), 
/*  787 */         state(), 
/*  788 */         emoji(), newValue, 
/*      */         
/*  790 */         assets(), 
/*  791 */         secrets(), 
/*  792 */         instance(), 
/*  793 */         flags());
/*      */   }
/*      */   
/*      */   public ImmutableActivityData withParty(ActivityPartyData value) {
/*  797 */     Possible<ActivityPartyData> newValue = Possible.of(value);
/*  798 */     return new ImmutableActivityData(this, this.name, this.type, this.id, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  803 */         url(), this.createdAt, 
/*      */         
/*  805 */         timestamps(), 
/*  806 */         applicationId(), 
/*  807 */         details(), 
/*  808 */         state(), 
/*  809 */         emoji(), newValue, 
/*      */         
/*  811 */         assets(), 
/*  812 */         secrets(), 
/*  813 */         instance(), 
/*  814 */         flags());
/*      */   }
/*      */   
/*      */   public ImmutableActivityData withAssets(Possible<ActivityAssetsData> value) {
/*  818 */     Possible<ActivityAssetsData> newValue = Objects.<Possible<ActivityAssetsData>>requireNonNull(value);
/*  819 */     return new ImmutableActivityData(this, this.name, this.type, this.id, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  824 */         url(), this.createdAt, 
/*      */         
/*  826 */         timestamps(), 
/*  827 */         applicationId(), 
/*  828 */         details(), 
/*  829 */         state(), 
/*  830 */         emoji(), 
/*  831 */         party(), newValue, 
/*      */         
/*  833 */         secrets(), 
/*  834 */         instance(), 
/*  835 */         flags());
/*      */   }
/*      */   
/*      */   public ImmutableActivityData withAssets(ActivityAssetsData value) {
/*  839 */     Possible<ActivityAssetsData> newValue = Possible.of(value);
/*  840 */     return new ImmutableActivityData(this, this.name, this.type, this.id, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  845 */         url(), this.createdAt, 
/*      */         
/*  847 */         timestamps(), 
/*  848 */         applicationId(), 
/*  849 */         details(), 
/*  850 */         state(), 
/*  851 */         emoji(), 
/*  852 */         party(), newValue, 
/*      */         
/*  854 */         secrets(), 
/*  855 */         instance(), 
/*  856 */         flags());
/*      */   }
/*      */   
/*      */   public ImmutableActivityData withSecrets(Possible<ActivitySecretsData> value) {
/*  860 */     Possible<ActivitySecretsData> newValue = Objects.<Possible<ActivitySecretsData>>requireNonNull(value);
/*  861 */     return new ImmutableActivityData(this, this.name, this.type, this.id, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  866 */         url(), this.createdAt, 
/*      */         
/*  868 */         timestamps(), 
/*  869 */         applicationId(), 
/*  870 */         details(), 
/*  871 */         state(), 
/*  872 */         emoji(), 
/*  873 */         party(), 
/*  874 */         assets(), newValue, 
/*      */         
/*  876 */         instance(), 
/*  877 */         flags());
/*      */   }
/*      */   
/*      */   public ImmutableActivityData withSecrets(ActivitySecretsData value) {
/*  881 */     Possible<ActivitySecretsData> newValue = Possible.of(value);
/*  882 */     return new ImmutableActivityData(this, this.name, this.type, this.id, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  887 */         url(), this.createdAt, 
/*      */         
/*  889 */         timestamps(), 
/*  890 */         applicationId(), 
/*  891 */         details(), 
/*  892 */         state(), 
/*  893 */         emoji(), 
/*  894 */         party(), 
/*  895 */         assets(), newValue, 
/*      */         
/*  897 */         instance(), 
/*  898 */         flags());
/*      */   }
/*      */   
/*      */   public ImmutableActivityData withInstance(Possible<Boolean> value) {
/*  902 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/*  903 */     return new ImmutableActivityData(this, this.name, this.type, this.id, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  908 */         url(), this.createdAt, 
/*      */         
/*  910 */         timestamps(), 
/*  911 */         applicationId(), 
/*  912 */         details(), 
/*  913 */         state(), 
/*  914 */         emoji(), 
/*  915 */         party(), 
/*  916 */         assets(), 
/*  917 */         secrets(), newValue, 
/*      */         
/*  919 */         flags());
/*      */   }
/*      */   
/*      */   public ImmutableActivityData withInstance(Boolean value) {
/*  923 */     Possible<Boolean> newValue = Possible.of(value);
/*  924 */     return new ImmutableActivityData(this, this.name, this.type, this.id, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  929 */         url(), this.createdAt, 
/*      */         
/*  931 */         timestamps(), 
/*  932 */         applicationId(), 
/*  933 */         details(), 
/*  934 */         state(), 
/*  935 */         emoji(), 
/*  936 */         party(), 
/*  937 */         assets(), 
/*  938 */         secrets(), newValue, 
/*      */         
/*  940 */         flags());
/*      */   }
/*      */   
/*      */   public ImmutableActivityData withFlags(Possible<Integer> value) {
/*  944 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/*  945 */     return new ImmutableActivityData(this, this.name, this.type, this.id, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  950 */         url(), this.createdAt, 
/*      */         
/*  952 */         timestamps(), 
/*  953 */         applicationId(), 
/*  954 */         details(), 
/*  955 */         state(), 
/*  956 */         emoji(), 
/*  957 */         party(), 
/*  958 */         assets(), 
/*  959 */         secrets(), 
/*  960 */         instance(), newValue);
/*      */   }
/*      */ 
/*      */   
/*      */   public ImmutableActivityData withFlags(Integer value) {
/*  965 */     Possible<Integer> newValue = Possible.of(value);
/*  966 */     return new ImmutableActivityData(this, this.name, this.type, this.id, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  971 */         url(), this.createdAt, 
/*      */         
/*  973 */         timestamps(), 
/*  974 */         applicationId(), 
/*  975 */         details(), 
/*  976 */         state(), 
/*  977 */         emoji(), 
/*  978 */         party(), 
/*  979 */         assets(), 
/*  980 */         secrets(), 
/*  981 */         instance(), newValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean equals(Object another) {
/*  991 */     if (this == another) return true; 
/*  992 */     return (another instanceof ImmutableActivityData && 
/*  993 */       equalTo(0, (ImmutableActivityData)another));
/*      */   }
/*      */   
/*      */   private boolean equalTo(int synthetic, ImmutableActivityData another) {
/*  997 */     return (this.name.equals(another.name) && this.type == another.type && this.id
/*      */       
/*  999 */       .equals(another.id) && 
/* 1000 */       url().equals(another.url()) && this.createdAt == another.createdAt && 
/*      */       
/* 1002 */       timestamps().equals(another.timestamps()) && 
/* 1003 */       applicationId().equals(another.applicationId()) && 
/* 1004 */       details().equals(another.details()) && 
/* 1005 */       state().equals(another.state()) && 
/* 1006 */       emoji().equals(another.emoji()) && 
/* 1007 */       party().equals(another.party()) && 
/* 1008 */       assets().equals(another.assets()) && 
/* 1009 */       secrets().equals(another.secrets()) && 
/* 1010 */       instance().equals(another.instance()) && 
/* 1011 */       flags().equals(another.flags()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int hashCode() {
/* 1020 */     int h = 5381;
/* 1021 */     h += (h << 5) + this.name.hashCode();
/* 1022 */     h += (h << 5) + this.type;
/* 1023 */     h += (h << 5) + this.id.hashCode();
/* 1024 */     h += (h << 5) + url().hashCode();
/* 1025 */     h += (h << 5) + Long.hashCode(this.createdAt);
/* 1026 */     h += (h << 5) + timestamps().hashCode();
/* 1027 */     h += (h << 5) + applicationId().hashCode();
/* 1028 */     h += (h << 5) + details().hashCode();
/* 1029 */     h += (h << 5) + state().hashCode();
/* 1030 */     h += (h << 5) + emoji().hashCode();
/* 1031 */     h += (h << 5) + party().hashCode();
/* 1032 */     h += (h << 5) + assets().hashCode();
/* 1033 */     h += (h << 5) + secrets().hashCode();
/* 1034 */     h += (h << 5) + instance().hashCode();
/* 1035 */     h += (h << 5) + flags().hashCode();
/* 1036 */     return h;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/* 1045 */     return "ActivityData{name=" + this.name + ", type=" + this.type + ", id=" + this.id + ", url=" + 
/*      */ 
/*      */ 
/*      */       
/* 1049 */       url().toString() + ", createdAt=" + this.createdAt + ", timestamps=" + 
/*      */       
/* 1051 */       timestamps().toString() + ", applicationId=" + 
/* 1052 */       applicationId().toString() + ", details=" + 
/* 1053 */       details().toString() + ", state=" + 
/* 1054 */       state().toString() + ", emoji=" + 
/* 1055 */       emoji().toString() + ", party=" + 
/* 1056 */       party().toString() + ", assets=" + 
/* 1057 */       assets().toString() + ", secrets=" + 
/* 1058 */       secrets().toString() + ", instance=" + 
/* 1059 */       instance().toString() + ", flags=" + 
/* 1060 */       flags().toString() + "}";
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonDeserialize
/*      */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*      */   @Generated(from = "ActivityData", generator = "Immutables")
/*      */   static final class Json
/*      */     implements ActivityData
/*      */   {
/*      */     String name;
/*      */     
/*      */     int type;
/*      */     
/*      */     boolean typeIsSet;
/*      */     
/*      */     String id;
/* 1078 */     Possible<Optional<String>> url = Possible.absent();
/*      */     
/*      */     long createdAt;
/*      */     
/*      */     boolean createdAtIsSet;
/* 1083 */     Possible<ActivityTimestampsData> timestamps = Possible.absent();
/*      */ 
/*      */     
/* 1086 */     Possible<Id> applicationId = Possible.absent();
/*      */ 
/*      */     
/* 1089 */     Possible<Optional<String>> details = Possible.absent();
/*      */ 
/*      */     
/* 1092 */     Possible<Optional<String>> state = Possible.absent();
/*      */ 
/*      */     
/* 1095 */     Possible<Optional<ActivityEmojiData>> emoji = Possible.absent();
/*      */ 
/*      */     
/* 1098 */     Possible<ActivityPartyData> party = Possible.absent();
/*      */ 
/*      */     
/* 1101 */     Possible<ActivityAssetsData> assets = Possible.absent();
/*      */ 
/*      */     
/* 1104 */     Possible<ActivitySecretsData> secrets = Possible.absent();
/*      */ 
/*      */     
/* 1107 */     Possible<Boolean> instance = Possible.absent();
/*      */ 
/*      */     
/* 1110 */     Possible<Integer> flags = Possible.absent();
/*      */     
/*      */     @JsonProperty("name")
/*      */     public void setName(String name) {
/* 1114 */       this.name = name;
/*      */     }
/*      */     @JsonProperty("type")
/*      */     public void setType(int type) {
/* 1118 */       this.type = type;
/* 1119 */       this.typeIsSet = true;
/*      */     }
/*      */     @JsonProperty("id")
/*      */     public void setId(String id) {
/* 1123 */       this.id = id;
/*      */     }
/*      */     @JsonProperty("url")
/*      */     public void setUrl(Possible<Optional<String>> url) {
/* 1127 */       this.url = url;
/*      */     }
/*      */     @JsonProperty("created_at")
/*      */     public void setCreatedAt(long createdAt) {
/* 1131 */       this.createdAt = createdAt;
/* 1132 */       this.createdAtIsSet = true;
/*      */     }
/*      */     @JsonProperty("timestamps")
/*      */     public void setTimestamps(Possible<ActivityTimestampsData> timestamps) {
/* 1136 */       this.timestamps = timestamps;
/*      */     }
/*      */     @JsonProperty("application_id")
/*      */     public void setApplicationId(Possible<Id> applicationId) {
/* 1140 */       this.applicationId = applicationId;
/*      */     }
/*      */     @JsonProperty("details")
/*      */     public void setDetails(Possible<Optional<String>> details) {
/* 1144 */       this.details = details;
/*      */     }
/*      */     @JsonProperty("state")
/*      */     public void setState(Possible<Optional<String>> state) {
/* 1148 */       this.state = state;
/*      */     }
/*      */     @JsonProperty("emoji")
/*      */     public void setEmoji(Possible<Optional<ActivityEmojiData>> emoji) {
/* 1152 */       this.emoji = emoji;
/*      */     }
/*      */     @JsonProperty("party")
/*      */     public void setParty(Possible<ActivityPartyData> party) {
/* 1156 */       this.party = party;
/*      */     }
/*      */     @JsonProperty("assets")
/*      */     public void setAssets(Possible<ActivityAssetsData> assets) {
/* 1160 */       this.assets = assets;
/*      */     }
/*      */     @JsonProperty("secrets")
/*      */     public void setSecrets(Possible<ActivitySecretsData> secrets) {
/* 1164 */       this.secrets = secrets;
/*      */     }
/*      */     @JsonProperty("instance")
/*      */     public void setInstance(Possible<Boolean> instance) {
/* 1168 */       this.instance = instance;
/*      */     }
/*      */     @JsonProperty("flags")
/*      */     public void setFlags(Possible<Integer> flags) {
/* 1172 */       this.flags = flags;
/*      */     }
/*      */     public String name() {
/* 1175 */       throw new UnsupportedOperationException();
/*      */     } public int type() {
/* 1177 */       throw new UnsupportedOperationException();
/*      */     } public String id() {
/* 1179 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Optional<String>> url() {
/* 1181 */       throw new UnsupportedOperationException();
/*      */     } public long createdAt() {
/* 1183 */       throw new UnsupportedOperationException();
/*      */     } public Possible<ActivityTimestampsData> timestamps() {
/* 1185 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Id> applicationId() {
/* 1187 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Optional<String>> details() {
/* 1189 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Optional<String>> state() {
/* 1191 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Optional<ActivityEmojiData>> emoji() {
/* 1193 */       throw new UnsupportedOperationException();
/*      */     } public Possible<ActivityPartyData> party() {
/* 1195 */       throw new UnsupportedOperationException();
/*      */     } public Possible<ActivityAssetsData> assets() {
/* 1197 */       throw new UnsupportedOperationException();
/*      */     } public Possible<ActivitySecretsData> secrets() {
/* 1199 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Boolean> instance() {
/* 1201 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Integer> flags() {
/* 1203 */       throw new UnsupportedOperationException();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*      */   static ImmutableActivityData fromJson(Json json) {
/* 1214 */     Builder builder = builder();
/* 1215 */     if (json.name != null) {
/* 1216 */       builder.name(json.name);
/*      */     }
/* 1218 */     if (json.typeIsSet) {
/* 1219 */       builder.type(json.type);
/*      */     }
/* 1221 */     if (json.id != null) {
/* 1222 */       builder.id(json.id);
/*      */     }
/* 1224 */     if (json.url != null) {
/* 1225 */       builder.url(json.url);
/*      */     }
/* 1227 */     if (json.createdAtIsSet) {
/* 1228 */       builder.createdAt(json.createdAt);
/*      */     }
/* 1230 */     if (json.timestamps != null) {
/* 1231 */       builder.timestamps(json.timestamps);
/*      */     }
/* 1233 */     if (json.applicationId != null) {
/* 1234 */       builder.applicationId(json.applicationId);
/*      */     }
/* 1236 */     if (json.details != null) {
/* 1237 */       builder.details(json.details);
/*      */     }
/* 1239 */     if (json.state != null) {
/* 1240 */       builder.state(json.state);
/*      */     }
/* 1242 */     if (json.emoji != null) {
/* 1243 */       builder.emoji(json.emoji);
/*      */     }
/* 1245 */     if (json.party != null) {
/* 1246 */       builder.party(json.party);
/*      */     }
/* 1248 */     if (json.assets != null) {
/* 1249 */       builder.assets(json.assets);
/*      */     }
/* 1251 */     if (json.secrets != null) {
/* 1252 */       builder.secrets(json.secrets);
/*      */     }
/* 1254 */     if (json.instance != null) {
/* 1255 */       builder.instance(json.instance);
/*      */     }
/* 1257 */     if (json.flags != null) {
/* 1258 */       builder.flags(json.flags);
/*      */     }
/* 1260 */     return builder.build();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableActivityData of(String name, int type, String id, Possible<Optional<String>> url, long createdAt, Possible<ActivityTimestampsData> timestamps, Possible<Id> applicationId, Possible<Optional<String>> details, Possible<Optional<String>> state, Possible<Optional<ActivityEmojiData>> emoji, Possible<ActivityPartyData> party, Possible<ActivityAssetsData> assets, Possible<ActivitySecretsData> secrets, Possible<Boolean> instance, Possible<Integer> flags) {
/* 1283 */     return new ImmutableActivityData(name, type, id, url, createdAt, timestamps, applicationId, details, state, emoji, party, assets, secrets, instance, flags);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableActivityData copyOf(ActivityData instance) {
/* 1294 */     if (instance instanceof ImmutableActivityData) {
/* 1295 */       return (ImmutableActivityData)instance;
/*      */     }
/* 1297 */     return builder()
/* 1298 */       .from(instance)
/* 1299 */       .build();
/*      */   }
/*      */   
/*      */   public boolean isUrlPresent() {
/* 1303 */     return !this.url_absent;
/*      */   }
/*      */   
/*      */   public String urlOrElse(String defaultValue) {
/* 1307 */     return !this.url_absent ? this.url_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isTimestampsPresent() {
/* 1311 */     return !this.timestamps_absent;
/*      */   }
/*      */   
/*      */   public ActivityTimestampsData timestampsOrElse(ActivityTimestampsData defaultValue) {
/* 1315 */     return !this.timestamps_absent ? this.timestamps_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isApplicationIdPresent() {
/* 1319 */     return !this.applicationId_absent;
/*      */   }
/*      */   
/*      */   public long applicationIdOrElse(long defaultValue) {
/* 1323 */     return !this.applicationId_absent ? this.applicationId_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isDetailsPresent() {
/* 1327 */     return !this.details_absent;
/*      */   }
/*      */   
/*      */   public String detailsOrElse(String defaultValue) {
/* 1331 */     return !this.details_absent ? this.details_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isStatePresent() {
/* 1335 */     return !this.state_absent;
/*      */   }
/*      */   
/*      */   public String stateOrElse(String defaultValue) {
/* 1339 */     return !this.state_absent ? this.state_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isEmojiPresent() {
/* 1343 */     return !this.emoji_absent;
/*      */   }
/*      */   
/*      */   public ActivityEmojiData emojiOrElse(ActivityEmojiData defaultValue) {
/* 1347 */     return !this.emoji_absent ? this.emoji_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isPartyPresent() {
/* 1351 */     return !this.party_absent;
/*      */   }
/*      */   
/*      */   public ActivityPartyData partyOrElse(ActivityPartyData defaultValue) {
/* 1355 */     return !this.party_absent ? this.party_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isAssetsPresent() {
/* 1359 */     return !this.assets_absent;
/*      */   }
/*      */   
/*      */   public ActivityAssetsData assetsOrElse(ActivityAssetsData defaultValue) {
/* 1363 */     return !this.assets_absent ? this.assets_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isSecretsPresent() {
/* 1367 */     return !this.secrets_absent;
/*      */   }
/*      */   
/*      */   public ActivitySecretsData secretsOrElse(ActivitySecretsData defaultValue) {
/* 1371 */     return !this.secrets_absent ? this.secrets_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isInstancePresent() {
/* 1375 */     return !this.instance_absent;
/*      */   }
/*      */   
/*      */   public Boolean instanceOrElse(Boolean defaultValue) {
/* 1379 */     return !this.instance_absent ? this.instance_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isFlagsPresent() {
/* 1383 */     return !this.flags_absent;
/*      */   }
/*      */   
/*      */   public Integer flagsOrElse(Integer defaultValue) {
/* 1387 */     return !this.flags_absent ? this.flags_value : defaultValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Builder builder() {
/* 1414 */     return new Builder();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   @Generated(from = "ActivityData", generator = "Immutables")
/*      */   public static final class Builder
/*      */   {
/*      */     private static final long INIT_BIT_NAME = 1L;
/*      */     
/*      */     private static final long INIT_BIT_TYPE = 2L;
/*      */     
/*      */     private static final long INIT_BIT_ID = 4L;
/*      */     
/*      */     private static final long INIT_BIT_CREATED_AT = 8L;
/*      */     
/* 1430 */     private long initBits = 15L;
/*      */     
/* 1432 */     private Possible<Optional<String>> url_possible = Possible.absent();
/* 1433 */     private Possible<ActivityTimestampsData> timestamps_possible = Possible.absent();
/* 1434 */     private Possible<Id> applicationId_possible = Possible.absent();
/* 1435 */     private Possible<Optional<String>> details_possible = Possible.absent();
/* 1436 */     private Possible<Optional<String>> state_possible = Possible.absent();
/* 1437 */     private Possible<Optional<ActivityEmojiData>> emoji_possible = Possible.absent();
/* 1438 */     private Possible<ActivityPartyData> party_possible = Possible.absent();
/* 1439 */     private Possible<ActivityAssetsData> assets_possible = Possible.absent();
/* 1440 */     private Possible<ActivitySecretsData> secrets_possible = Possible.absent();
/* 1441 */     private Possible<Boolean> instance_possible = Possible.absent();
/* 1442 */     private Possible<Integer> flags_possible = Possible.absent();
/*      */ 
/*      */     
/*      */     private String name;
/*      */ 
/*      */     
/*      */     private int type;
/*      */ 
/*      */     
/*      */     private String id;
/*      */     
/*      */     private long createdAt;
/*      */ 
/*      */     
/*      */     public final Builder from(ActivityData instance) {
/* 1457 */       Objects.requireNonNull(instance, "instance");
/* 1458 */       from(instance);
/* 1459 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder from(Activity instance) {
/* 1468 */       Objects.requireNonNull(instance, "instance");
/* 1469 */       from(instance);
/* 1470 */       return this;
/*      */     }
/*      */     
/*      */     private void from(Object object) {
/* 1474 */       long bits = 0L;
/* 1475 */       if (object instanceof ActivityData) {
/* 1476 */         ActivityData instance = (ActivityData)object;
/* 1477 */         instance(instance.instance());
/* 1478 */         emoji(instance.emoji());
/* 1479 */         timestamps(instance.timestamps());
/* 1480 */         flags(instance.flags());
/* 1481 */         if ((bits & 0x1L) == 0L) {
/* 1482 */           type(instance.type());
/* 1483 */           bits |= 0x1L;
/*      */         } 
/* 1485 */         secrets(instance.secrets());
/* 1486 */         url(instance.url());
/* 1487 */         createdAt(instance.createdAt());
/* 1488 */         assets(instance.assets());
/* 1489 */         if ((bits & 0x2L) == 0L) {
/* 1490 */           name(instance.name());
/* 1491 */           bits |= 0x2L;
/*      */         } 
/* 1493 */         details(instance.details());
/* 1494 */         id(instance.id());
/* 1495 */         state(instance.state());
/* 1496 */         applicationId(instance.applicationId());
/* 1497 */         party(instance.party());
/*      */       } 
/* 1499 */       if (object instanceof Activity) {
/* 1500 */         Activity instance = (Activity)object;
/* 1501 */         if ((bits & 0x1L) == 0L) {
/* 1502 */           type(instance.type());
/* 1503 */           bits |= 0x1L;
/*      */         } 
/* 1505 */         if ((bits & 0x2L) == 0L) {
/* 1506 */           name(instance.name());
/* 1507 */           bits |= 0x2L;
/*      */         } 
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("name")
/*      */     public final Builder name(String name) {
/* 1519 */       this.name = Objects.<String>requireNonNull(name, "name");
/* 1520 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 1521 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("type")
/*      */     public final Builder type(int type) {
/* 1531 */       this.type = type;
/* 1532 */       this.initBits &= 0xFFFFFFFFFFFFFFFDL;
/* 1533 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("id")
/*      */     public final Builder id(String id) {
/* 1543 */       this.id = Objects.<String>requireNonNull(id, "id");
/* 1544 */       this.initBits &= 0xFFFFFFFFFFFFFFFBL;
/* 1545 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("url")
/*      */     public Builder url(Possible<Optional<String>> value) {
/* 1550 */       this.url_possible = value;
/* 1551 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public Builder url(@Nullable String value) {
/* 1556 */       this.url_possible = Possible.of(Optional.ofNullable(value));
/* 1557 */       return this;
/*      */     }
/*      */     
/*      */     public Builder urlOrNull(@Nullable String value) {
/* 1561 */       this.url_possible = Possible.of(Optional.ofNullable(value));
/* 1562 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("created_at")
/*      */     public final Builder createdAt(long createdAt) {
/* 1572 */       this.createdAt = createdAt;
/* 1573 */       this.initBits &= 0xFFFFFFFFFFFFFFF7L;
/* 1574 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("timestamps")
/*      */     public Builder timestamps(Possible<ActivityTimestampsData> value) {
/* 1579 */       this.timestamps_possible = value;
/* 1580 */       return this;
/*      */     }
/*      */     
/*      */     public Builder timestamps(ActivityTimestampsData value) {
/* 1584 */       this.timestamps_possible = Possible.of(value);
/* 1585 */       return this;
/*      */     }
/*      */     
/*      */     public Builder applicationId(String value) {
/* 1589 */       this.applicationId_possible = Possible.of(Id.of(value));
/* 1590 */       return this;
/*      */     }
/*      */     
/*      */     public Builder applicationId(long value) {
/* 1594 */       this.applicationId_possible = Possible.of(Id.of(value));
/* 1595 */       return this;
/*      */     }
/*      */     
/*      */     public Builder applicationId(Id value) {
/* 1599 */       this.applicationId_possible = Possible.of(value);
/* 1600 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("application_id")
/*      */     public Builder applicationId(Possible<Id> value) {
/* 1605 */       this.applicationId_possible = value;
/* 1606 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("details")
/*      */     public Builder details(Possible<Optional<String>> value) {
/* 1611 */       this.details_possible = value;
/* 1612 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public Builder details(@Nullable String value) {
/* 1617 */       this.details_possible = Possible.of(Optional.ofNullable(value));
/* 1618 */       return this;
/*      */     }
/*      */     
/*      */     public Builder detailsOrNull(@Nullable String value) {
/* 1622 */       this.details_possible = Possible.of(Optional.ofNullable(value));
/* 1623 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("state")
/*      */     public Builder state(Possible<Optional<String>> value) {
/* 1628 */       this.state_possible = value;
/* 1629 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public Builder state(@Nullable String value) {
/* 1634 */       this.state_possible = Possible.of(Optional.ofNullable(value));
/* 1635 */       return this;
/*      */     }
/*      */     
/*      */     public Builder stateOrNull(@Nullable String value) {
/* 1639 */       this.state_possible = Possible.of(Optional.ofNullable(value));
/* 1640 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("emoji")
/*      */     public Builder emoji(Possible<Optional<ActivityEmojiData>> value) {
/* 1645 */       this.emoji_possible = value;
/* 1646 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public Builder emoji(@Nullable ActivityEmojiData value) {
/* 1651 */       this.emoji_possible = Possible.of(Optional.ofNullable(value));
/* 1652 */       return this;
/*      */     }
/*      */     
/*      */     public Builder emojiOrNull(@Nullable ActivityEmojiData value) {
/* 1656 */       this.emoji_possible = Possible.of(Optional.ofNullable(value));
/* 1657 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("party")
/*      */     public Builder party(Possible<ActivityPartyData> value) {
/* 1662 */       this.party_possible = value;
/* 1663 */       return this;
/*      */     }
/*      */     
/*      */     public Builder party(ActivityPartyData value) {
/* 1667 */       this.party_possible = Possible.of(value);
/* 1668 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("assets")
/*      */     public Builder assets(Possible<ActivityAssetsData> value) {
/* 1673 */       this.assets_possible = value;
/* 1674 */       return this;
/*      */     }
/*      */     
/*      */     public Builder assets(ActivityAssetsData value) {
/* 1678 */       this.assets_possible = Possible.of(value);
/* 1679 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("secrets")
/*      */     public Builder secrets(Possible<ActivitySecretsData> value) {
/* 1684 */       this.secrets_possible = value;
/* 1685 */       return this;
/*      */     }
/*      */     
/*      */     public Builder secrets(ActivitySecretsData value) {
/* 1689 */       this.secrets_possible = Possible.of(value);
/* 1690 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("instance")
/*      */     public Builder instance(Possible<Boolean> value) {
/* 1695 */       this.instance_possible = value;
/* 1696 */       return this;
/*      */     }
/*      */     
/*      */     public Builder instance(Boolean value) {
/* 1700 */       this.instance_possible = Possible.of(value);
/* 1701 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("flags")
/*      */     public Builder flags(Possible<Integer> value) {
/* 1706 */       this.flags_possible = value;
/* 1707 */       return this;
/*      */     }
/*      */     
/*      */     public Builder flags(Integer value) {
/* 1711 */       this.flags_possible = Possible.of(value);
/* 1712 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ImmutableActivityData build() {
/* 1721 */       if (this.initBits != 0L) {
/* 1722 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*      */       }
/* 1724 */       return new ImmutableActivityData(null, this.name, this.type, this.id, 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1729 */           url_build(), this.createdAt, 
/*      */           
/* 1731 */           timestamps_build(), 
/* 1732 */           applicationId_build(), 
/* 1733 */           details_build(), 
/* 1734 */           state_build(), 
/* 1735 */           emoji_build(), 
/* 1736 */           party_build(), 
/* 1737 */           assets_build(), 
/* 1738 */           secrets_build(), 
/* 1739 */           instance_build(), 
/* 1740 */           flags_build());
/*      */     }
/*      */     
/*      */     private String formatRequiredAttributesMessage() {
/* 1744 */       List<String> attributes = new ArrayList<>();
/* 1745 */       if ((this.initBits & 0x1L) != 0L) attributes.add("name"); 
/* 1746 */       if ((this.initBits & 0x2L) != 0L) attributes.add("type"); 
/* 1747 */       if ((this.initBits & 0x4L) != 0L) attributes.add("id"); 
/* 1748 */       if ((this.initBits & 0x8L) != 0L) attributes.add("createdAt"); 
/* 1749 */       return "Cannot build ActivityData, some of required attributes are not set " + attributes;
/*      */     }
/*      */     
/*      */     private Possible<Optional<String>> url_build() {
/* 1753 */       return this.url_possible;
/*      */     }
/*      */     
/*      */     private Possible<ActivityTimestampsData> timestamps_build() {
/* 1757 */       return this.timestamps_possible;
/*      */     }
/*      */     
/*      */     private Possible<Id> applicationId_build() {
/* 1761 */       return this.applicationId_possible;
/*      */     }
/*      */     
/*      */     private Possible<Optional<String>> details_build() {
/* 1765 */       return this.details_possible;
/*      */     }
/*      */     
/*      */     private Possible<Optional<String>> state_build() {
/* 1769 */       return this.state_possible;
/*      */     }
/*      */     
/*      */     private Possible<Optional<ActivityEmojiData>> emoji_build() {
/* 1773 */       return this.emoji_possible;
/*      */     }
/*      */     
/*      */     private Possible<ActivityPartyData> party_build() {
/* 1777 */       return this.party_possible;
/*      */     }
/*      */     
/*      */     private Possible<ActivityAssetsData> assets_build() {
/* 1781 */       return this.assets_possible;
/*      */     }
/*      */     
/*      */     private Possible<ActivitySecretsData> secrets_build() {
/* 1785 */       return this.secrets_possible;
/*      */     }
/*      */     
/*      */     private Possible<Boolean> instance_build() {
/* 1789 */       return this.instance_possible;
/*      */     }
/*      */     
/*      */     private Possible<Integer> flags_build() {
/* 1793 */       return this.flags_possible;
/*      */     }
/*      */     
/*      */     private Builder() {}
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableActivityData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */