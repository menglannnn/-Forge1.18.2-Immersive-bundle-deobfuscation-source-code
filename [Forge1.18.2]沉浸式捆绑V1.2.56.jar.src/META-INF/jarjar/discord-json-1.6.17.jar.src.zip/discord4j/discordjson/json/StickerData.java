/*    */ package discord4j.discordjson.json;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonProperty;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import discord4j.discordjson.Id;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import java.util.Optional;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ @JsonSerialize(as = ImmutableStickerData.class)
/*    */ @JsonDeserialize(as = ImmutableStickerData.class)
/*    */ @Immutable
/*    */ public interface StickerData
/*    */   extends PartialStickerData
/*    */ {
/*    */   static ImmutableStickerData.Builder builder() {
/* 18 */     return ImmutableStickerData.builder();
/*    */   }
/*    */   
/*    */   @JsonProperty("pack_id")
/*    */   Possible<Id> packId();
/*    */   
/*    */   Optional<String> description();
/*    */   
/*    */   Possible<String> tags();
/*    */   
/*    */   @Deprecated
/*    */   Possible<String> asset();
/*    */   
/*    */   Possible<Boolean> available();
/*    */   
/*    */   int type();
/*    */   
/*    */   @JsonProperty("guild_id")
/*    */   Possible<Id> guildId();
/*    */   
/*    */   @JsonProperty("sort_value")
/*    */   Possible<Integer> sortValue();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\StickerData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */