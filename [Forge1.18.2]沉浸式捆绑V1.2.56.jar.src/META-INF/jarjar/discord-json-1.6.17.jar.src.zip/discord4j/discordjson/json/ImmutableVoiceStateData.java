/*      */ package discord4j.discordjson.json;
/*      */ 
/*      */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*      */ import com.fasterxml.jackson.annotation.JsonCreator;
/*      */ import com.fasterxml.jackson.annotation.JsonProperty;
/*      */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*      */ import discord4j.discordjson.Id;
/*      */ import discord4j.discordjson.possible.Possible;
/*      */ import java.util.ArrayList;
/*      */ import java.util.List;
/*      */ import java.util.Objects;
/*      */ import java.util.Optional;
/*      */ import org.immutables.value.Generated;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ @Generated(from = "VoiceStateData", generator = "Immutables")
/*      */ public final class ImmutableVoiceStateData
/*      */   implements VoiceStateData
/*      */ {
/*      */   private final long guildId_value;
/*      */   private final boolean guildId_absent;
/*      */   private final long channelId_value;
/*      */   private final boolean channelId_present;
/*      */   private final long userId_value;
/*      */   private final MemberData member_value;
/*      */   private final boolean member_absent;
/*      */   private final String sessionId;
/*      */   private final boolean deaf;
/*      */   private final boolean mute;
/*      */   private final boolean selfDeaf;
/*      */   private final boolean selfMute;
/*      */   private final Boolean selfStream_value;
/*      */   private final boolean selfStream_absent;
/*      */   private final boolean selfVideo;
/*      */   private final boolean suppress;
/*      */   private final String requestToSpeakTimestamp;
/*      */   private static final byte STAGE_INITIALIZING = -1;
/*      */   private static final byte STAGE_UNINITIALIZED = 0;
/*      */   private static final byte STAGE_INITIALIZED = 1;
/*      */   
/*      */   private ImmutableVoiceStateData(Possible<Id> guildId, Optional<Id> channelId, Id userId, Possible<MemberData> member, String sessionId, boolean deaf, boolean mute, boolean selfDeaf, boolean selfMute, Possible<Boolean> selfStream, boolean selfVideo, boolean suppress, Optional<String> requestToSpeakTimestamp) {
/*   59 */     Possible<Id> guildId$impl = guildId;
/*   60 */     Optional<Id> channelId$impl = channelId;
/*   61 */     Id userId$impl = userId;
/*   62 */     Possible<MemberData> member$impl = member;
/*   63 */     this.sessionId = Objects.<String>requireNonNull(sessionId, "sessionId");
/*   64 */     this.deaf = deaf;
/*   65 */     this.mute = mute;
/*   66 */     this.selfDeaf = selfDeaf;
/*   67 */     this.selfMute = selfMute;
/*   68 */     Possible<Boolean> selfStream$impl = selfStream;
/*   69 */     this.selfVideo = selfVideo;
/*   70 */     this.suppress = suppress;
/*   71 */     this.requestToSpeakTimestamp = requestToSpeakTimestamp.orElse(null);
/*   72 */     this
/*      */       
/*   74 */       .guildId_value = ((Long)guildId$impl.toOptional().map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*   75 */     this.guildId_absent = guildId$impl.isAbsent();
/*   76 */     this
/*      */       
/*   78 */       .channelId_value = ((Long)channelId$impl.<Long>map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*   79 */     this.channelId_present = channelId$impl.isPresent();
/*   80 */     this.userId_value = userId$impl.asLong();
/*   81 */     this.member_value = member$impl.toOptional().orElse(null);
/*   82 */     this.member_absent = member$impl.isAbsent();
/*   83 */     this.selfStream_value = selfStream$impl.toOptional().orElse(null);
/*   84 */     this.selfStream_absent = selfStream$impl.isAbsent();
/*   85 */     this.initShim = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ImmutableVoiceStateData(ImmutableVoiceStateData original, Possible<Id> guildId, Optional<Id> channelId, Id userId, Possible<MemberData> member, String sessionId, boolean deaf, boolean mute, boolean selfDeaf, boolean selfMute, Possible<Boolean> selfStream, boolean selfVideo, boolean suppress, String requestToSpeakTimestamp) {
/*  103 */     Possible<Id> guildId$impl = guildId;
/*  104 */     Optional<Id> channelId$impl = channelId;
/*  105 */     Id userId$impl = userId;
/*  106 */     Possible<MemberData> member$impl = member;
/*  107 */     this.sessionId = sessionId;
/*  108 */     this.deaf = deaf;
/*  109 */     this.mute = mute;
/*  110 */     this.selfDeaf = selfDeaf;
/*  111 */     this.selfMute = selfMute;
/*  112 */     Possible<Boolean> selfStream$impl = selfStream;
/*  113 */     this.selfVideo = selfVideo;
/*  114 */     this.suppress = suppress;
/*  115 */     this.requestToSpeakTimestamp = requestToSpeakTimestamp;
/*  116 */     this
/*      */       
/*  118 */       .guildId_value = ((Long)guildId$impl.toOptional().map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  119 */     this.guildId_absent = guildId$impl.isAbsent();
/*  120 */     this
/*      */       
/*  122 */       .channelId_value = ((Long)channelId$impl.<Long>map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  123 */     this.channelId_present = channelId$impl.isPresent();
/*  124 */     this.userId_value = userId$impl.asLong();
/*  125 */     this.member_value = member$impl.toOptional().orElse(null);
/*  126 */     this.member_absent = member$impl.isAbsent();
/*  127 */     this.selfStream_value = selfStream$impl.toOptional().orElse(null);
/*  128 */     this.selfStream_absent = selfStream$impl.isAbsent();
/*  129 */     this.initShim = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  135 */   private volatile transient InitShim initShim = new InitShim();
/*      */   
/*      */   @Generated(from = "VoiceStateData", generator = "Immutables")
/*      */   private final class InitShim {
/*      */     private String formatInitCycleMessage() {
/*  140 */       List<String> attributes = new ArrayList<>();
/*  141 */       return "Cannot build VoiceStateData, attribute initializers form cycle " + attributes;
/*      */     }
/*      */ 
/*      */     
/*      */     private InitShim() {}
/*      */   }
/*      */ 
/*      */   
/*      */   @JsonProperty("guild_id")
/*      */   public Possible<Id> guildId() {
/*  151 */     return this.guildId_absent ? Possible.absent() : 
/*  152 */       Possible.of(Id.of(this.guildId_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("channel_id")
/*      */   public Optional<Id> channelId() {
/*  161 */     return this.channelId_present ? Optional.<Id>of(Id.of(this.channelId_value)) : Optional.<Id>empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("user_id")
/*      */   public Id userId() {
/*  170 */     return Id.of(this.userId_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("member")
/*      */   public Possible<MemberData> member() {
/*  179 */     return this.member_absent ? Possible.absent() : Possible.of(this.member_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("session_id")
/*      */   public String sessionId() {
/*  188 */     return this.sessionId;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("deaf")
/*      */   public boolean deaf() {
/*  197 */     return this.deaf;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("mute")
/*      */   public boolean mute() {
/*  206 */     return this.mute;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("self_deaf")
/*      */   public boolean selfDeaf() {
/*  215 */     return this.selfDeaf;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("self_mute")
/*      */   public boolean selfMute() {
/*  224 */     return this.selfMute;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("self_stream")
/*      */   public Possible<Boolean> selfStream() {
/*  233 */     return this.selfStream_absent ? Possible.absent() : Possible.of(this.selfStream_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("self_video")
/*      */   public boolean selfVideo() {
/*  242 */     return this.selfVideo;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("suppress")
/*      */   public boolean suppress() {
/*  251 */     return this.suppress;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("request_to_speak_timestamp")
/*      */   public Optional<String> requestToSpeakTimestamp() {
/*  260 */     return Optional.ofNullable(this.requestToSpeakTimestamp);
/*      */   }
/*      */   
/*      */   public ImmutableVoiceStateData withGuildId(Possible<Id> value) {
/*  264 */     Possible<Id> newValue = Objects.<Possible<Id>>requireNonNull(value);
/*  265 */     return new ImmutableVoiceStateData(this, newValue, 
/*      */ 
/*      */         
/*  268 */         channelId(), 
/*  269 */         userId(), 
/*  270 */         member(), this.sessionId, this.deaf, this.mute, this.selfDeaf, this.selfMute, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  276 */         selfStream(), this.selfVideo, this.suppress, this.requestToSpeakTimestamp);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutableVoiceStateData withGuildId(long value) {
/*  283 */     Possible<Id> newValue = Possible.of(Id.of(value));
/*  284 */     return new ImmutableVoiceStateData(this, newValue, 
/*      */ 
/*      */         
/*  287 */         channelId(), 
/*  288 */         userId(), 
/*  289 */         member(), this.sessionId, this.deaf, this.mute, this.selfDeaf, this.selfMute, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  295 */         selfStream(), this.selfVideo, this.suppress, this.requestToSpeakTimestamp);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutableVoiceStateData withChannelId(Optional<Id> value) {
/*  302 */     Optional<Id> newValue = Objects.<Optional<Id>>requireNonNull(value);
/*  303 */     return new ImmutableVoiceStateData(this, 
/*      */         
/*  305 */         guildId(), newValue, 
/*      */         
/*  307 */         userId(), 
/*  308 */         member(), this.sessionId, this.deaf, this.mute, this.selfDeaf, this.selfMute, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  314 */         selfStream(), this.selfVideo, this.suppress, this.requestToSpeakTimestamp);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutableVoiceStateData withChannelId(long value) {
/*  321 */     Optional<Id> newValue = Optional.of(Id.of(value));
/*  322 */     return new ImmutableVoiceStateData(this, 
/*      */         
/*  324 */         guildId(), newValue, 
/*      */         
/*  326 */         userId(), 
/*  327 */         member(), this.sessionId, this.deaf, this.mute, this.selfDeaf, this.selfMute, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  333 */         selfStream(), this.selfVideo, this.suppress, this.requestToSpeakTimestamp);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutableVoiceStateData withUserId(long value) {
/*  340 */     Id newValue = Id.of(value);
/*  341 */     return new ImmutableVoiceStateData(this, 
/*      */         
/*  343 */         guildId(), 
/*  344 */         channelId(), newValue, 
/*      */         
/*  346 */         member(), this.sessionId, this.deaf, this.mute, this.selfDeaf, this.selfMute, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  352 */         selfStream(), this.selfVideo, this.suppress, this.requestToSpeakTimestamp);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutableVoiceStateData withUserId(String value) {
/*  359 */     Id newValue = Id.of(value);
/*  360 */     return new ImmutableVoiceStateData(this, 
/*      */         
/*  362 */         guildId(), 
/*  363 */         channelId(), newValue, 
/*      */         
/*  365 */         member(), this.sessionId, this.deaf, this.mute, this.selfDeaf, this.selfMute, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  371 */         selfStream(), this.selfVideo, this.suppress, this.requestToSpeakTimestamp);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutableVoiceStateData withMember(Possible<MemberData> value) {
/*  378 */     Possible<MemberData> newValue = Objects.<Possible<MemberData>>requireNonNull(value);
/*  379 */     return new ImmutableVoiceStateData(this, 
/*      */         
/*  381 */         guildId(), 
/*  382 */         channelId(), 
/*  383 */         userId(), newValue, this.sessionId, this.deaf, this.mute, this.selfDeaf, this.selfMute, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  390 */         selfStream(), this.selfVideo, this.suppress, this.requestToSpeakTimestamp);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutableVoiceStateData withMember(MemberData value) {
/*  397 */     Possible<MemberData> newValue = Possible.of(value);
/*  398 */     return new ImmutableVoiceStateData(this, 
/*      */         
/*  400 */         guildId(), 
/*  401 */         channelId(), 
/*  402 */         userId(), newValue, this.sessionId, this.deaf, this.mute, this.selfDeaf, this.selfMute, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  409 */         selfStream(), this.selfVideo, this.suppress, this.requestToSpeakTimestamp);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableVoiceStateData withSessionId(String value) {
/*  422 */     String newValue = Objects.<String>requireNonNull(value, "sessionId");
/*  423 */     if (this.sessionId.equals(newValue)) return this; 
/*  424 */     return new ImmutableVoiceStateData(this, 
/*      */         
/*  426 */         guildId(), 
/*  427 */         channelId(), 
/*  428 */         userId(), 
/*  429 */         member(), newValue, this.deaf, this.mute, this.selfDeaf, this.selfMute, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  435 */         selfStream(), this.selfVideo, this.suppress, this.requestToSpeakTimestamp);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableVoiceStateData withDeaf(boolean value) {
/*  448 */     if (this.deaf == value) return this; 
/*  449 */     return new ImmutableVoiceStateData(this, 
/*      */         
/*  451 */         guildId(), 
/*  452 */         channelId(), 
/*  453 */         userId(), 
/*  454 */         member(), this.sessionId, value, this.mute, this.selfDeaf, this.selfMute, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  460 */         selfStream(), this.selfVideo, this.suppress, this.requestToSpeakTimestamp);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableVoiceStateData withMute(boolean value) {
/*  473 */     if (this.mute == value) return this; 
/*  474 */     return new ImmutableVoiceStateData(this, 
/*      */         
/*  476 */         guildId(), 
/*  477 */         channelId(), 
/*  478 */         userId(), 
/*  479 */         member(), this.sessionId, this.deaf, value, this.selfDeaf, this.selfMute, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  485 */         selfStream(), this.selfVideo, this.suppress, this.requestToSpeakTimestamp);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableVoiceStateData withSelfDeaf(boolean value) {
/*  498 */     if (this.selfDeaf == value) return this; 
/*  499 */     return new ImmutableVoiceStateData(this, 
/*      */         
/*  501 */         guildId(), 
/*  502 */         channelId(), 
/*  503 */         userId(), 
/*  504 */         member(), this.sessionId, this.deaf, this.mute, value, this.selfMute, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  510 */         selfStream(), this.selfVideo, this.suppress, this.requestToSpeakTimestamp);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableVoiceStateData withSelfMute(boolean value) {
/*  523 */     if (this.selfMute == value) return this; 
/*  524 */     return new ImmutableVoiceStateData(this, 
/*      */         
/*  526 */         guildId(), 
/*  527 */         channelId(), 
/*  528 */         userId(), 
/*  529 */         member(), this.sessionId, this.deaf, this.mute, this.selfDeaf, value, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  535 */         selfStream(), this.selfVideo, this.suppress, this.requestToSpeakTimestamp);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutableVoiceStateData withSelfStream(Possible<Boolean> value) {
/*  542 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/*  543 */     return new ImmutableVoiceStateData(this, 
/*      */         
/*  545 */         guildId(), 
/*  546 */         channelId(), 
/*  547 */         userId(), 
/*  548 */         member(), this.sessionId, this.deaf, this.mute, this.selfDeaf, this.selfMute, newValue, this.selfVideo, this.suppress, this.requestToSpeakTimestamp);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutableVoiceStateData withSelfStream(Boolean value) {
/*  561 */     Possible<Boolean> newValue = Possible.of(value);
/*  562 */     return new ImmutableVoiceStateData(this, 
/*      */         
/*  564 */         guildId(), 
/*  565 */         channelId(), 
/*  566 */         userId(), 
/*  567 */         member(), this.sessionId, this.deaf, this.mute, this.selfDeaf, this.selfMute, newValue, this.selfVideo, this.suppress, this.requestToSpeakTimestamp);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableVoiceStateData withSelfVideo(boolean value) {
/*  586 */     if (this.selfVideo == value) return this; 
/*  587 */     return new ImmutableVoiceStateData(this, 
/*      */         
/*  589 */         guildId(), 
/*  590 */         channelId(), 
/*  591 */         userId(), 
/*  592 */         member(), this.sessionId, this.deaf, this.mute, this.selfDeaf, this.selfMute, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  598 */         selfStream(), value, this.suppress, this.requestToSpeakTimestamp);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableVoiceStateData withSuppress(boolean value) {
/*  611 */     if (this.suppress == value) return this; 
/*  612 */     return new ImmutableVoiceStateData(this, 
/*      */         
/*  614 */         guildId(), 
/*  615 */         channelId(), 
/*  616 */         userId(), 
/*  617 */         member(), this.sessionId, this.deaf, this.mute, this.selfDeaf, this.selfMute, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  623 */         selfStream(), this.selfVideo, value, this.requestToSpeakTimestamp);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableVoiceStateData withRequestToSpeakTimestamp(String value) {
/*  635 */     String newValue = Objects.<String>requireNonNull(value, "requestToSpeakTimestamp");
/*  636 */     if (Objects.equals(this.requestToSpeakTimestamp, newValue)) return this; 
/*  637 */     return new ImmutableVoiceStateData(this, 
/*      */         
/*  639 */         guildId(), 
/*  640 */         channelId(), 
/*  641 */         userId(), 
/*  642 */         member(), this.sessionId, this.deaf, this.mute, this.selfDeaf, this.selfMute, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  648 */         selfStream(), this.selfVideo, this.suppress, newValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableVoiceStateData withRequestToSpeakTimestamp(Optional<String> optional) {
/*  661 */     String value = optional.orElse(null);
/*  662 */     if (Objects.equals(this.requestToSpeakTimestamp, value)) return this; 
/*  663 */     return new ImmutableVoiceStateData(this, 
/*      */         
/*  665 */         guildId(), 
/*  666 */         channelId(), 
/*  667 */         userId(), 
/*  668 */         member(), this.sessionId, this.deaf, this.mute, this.selfDeaf, this.selfMute, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  674 */         selfStream(), this.selfVideo, this.suppress, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean equals(Object another) {
/*  686 */     if (this == another) return true; 
/*  687 */     return (another instanceof ImmutableVoiceStateData && 
/*  688 */       equalTo(0, (ImmutableVoiceStateData)another));
/*      */   }
/*      */   
/*      */   private boolean equalTo(int synthetic, ImmutableVoiceStateData another) {
/*  692 */     return (guildId().equals(another.guildId()) && 
/*  693 */       channelId().equals(another.channelId()) && 
/*  694 */       Objects.equals(Long.valueOf(this.userId_value), Long.valueOf(another.userId_value)) && 
/*  695 */       member().equals(another.member()) && this.sessionId
/*  696 */       .equals(another.sessionId) && this.deaf == another.deaf && this.mute == another.mute && this.selfDeaf == another.selfDeaf && this.selfMute == another.selfMute && 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  701 */       selfStream().equals(another.selfStream()) && this.selfVideo == another.selfVideo && this.suppress == another.suppress && 
/*      */ 
/*      */       
/*  704 */       Objects.equals(this.requestToSpeakTimestamp, another.requestToSpeakTimestamp));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int hashCode() {
/*  713 */     int h = 5381;
/*  714 */     h += (h << 5) + guildId().hashCode();
/*  715 */     h += (h << 5) + channelId().hashCode();
/*  716 */     h += (h << 5) + Objects.hashCode(Long.valueOf(this.userId_value));
/*  717 */     h += (h << 5) + member().hashCode();
/*  718 */     h += (h << 5) + this.sessionId.hashCode();
/*  719 */     h += (h << 5) + Boolean.hashCode(this.deaf);
/*  720 */     h += (h << 5) + Boolean.hashCode(this.mute);
/*  721 */     h += (h << 5) + Boolean.hashCode(this.selfDeaf);
/*  722 */     h += (h << 5) + Boolean.hashCode(this.selfMute);
/*  723 */     h += (h << 5) + selfStream().hashCode();
/*  724 */     h += (h << 5) + Boolean.hashCode(this.selfVideo);
/*  725 */     h += (h << 5) + Boolean.hashCode(this.suppress);
/*  726 */     h += (h << 5) + Objects.hashCode(this.requestToSpeakTimestamp);
/*  727 */     return h;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/*  736 */     StringBuilder builder = new StringBuilder("VoiceStateData{");
/*  737 */     builder.append("guildId=").append(guildId().toString());
/*  738 */     builder.append(", ");
/*  739 */     builder.append("channelId=").append(channelId().toString());
/*  740 */     builder.append(", ");
/*  741 */     builder.append("userId=").append(Objects.toString(Long.valueOf(this.userId_value)));
/*  742 */     builder.append(", ");
/*  743 */     builder.append("member=").append(member().toString());
/*  744 */     builder.append(", ");
/*  745 */     builder.append("sessionId=").append(this.sessionId);
/*  746 */     builder.append(", ");
/*  747 */     builder.append("deaf=").append(this.deaf);
/*  748 */     builder.append(", ");
/*  749 */     builder.append("mute=").append(this.mute);
/*  750 */     builder.append(", ");
/*  751 */     builder.append("selfDeaf=").append(this.selfDeaf);
/*  752 */     builder.append(", ");
/*  753 */     builder.append("selfMute=").append(this.selfMute);
/*  754 */     builder.append(", ");
/*  755 */     builder.append("selfStream=").append(selfStream().toString());
/*  756 */     builder.append(", ");
/*  757 */     builder.append("selfVideo=").append(this.selfVideo);
/*  758 */     builder.append(", ");
/*  759 */     builder.append("suppress=").append(this.suppress);
/*  760 */     if (this.requestToSpeakTimestamp != null) {
/*  761 */       builder.append(", ");
/*  762 */       builder.append("requestToSpeakTimestamp=").append(this.requestToSpeakTimestamp);
/*      */     } 
/*  764 */     return builder.append("}").toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonDeserialize
/*      */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*      */   @Generated(from = "VoiceStateData", generator = "Immutables")
/*      */   static final class Json
/*      */     implements VoiceStateData
/*      */   {
/*  777 */     Possible<Id> guildId = Possible.absent();
/*      */ 
/*      */     
/*  780 */     Optional<Id> channelId = Optional.empty();
/*      */     
/*      */     Id userId;
/*      */     
/*  784 */     Possible<MemberData> member = Possible.absent();
/*      */     
/*      */     String sessionId;
/*      */     
/*      */     boolean deaf;
/*      */     boolean deafIsSet;
/*      */     boolean mute;
/*      */     boolean muteIsSet;
/*      */     boolean selfDeaf;
/*      */     boolean selfDeafIsSet;
/*      */     boolean selfMute;
/*      */     boolean selfMuteIsSet;
/*  796 */     Possible<Boolean> selfStream = Possible.absent();
/*      */     
/*      */     boolean selfVideo;
/*      */     boolean selfVideoIsSet;
/*      */     boolean suppress;
/*      */     boolean suppressIsSet;
/*  802 */     Optional<String> requestToSpeakTimestamp = Optional.empty();
/*      */     @JsonProperty("guild_id")
/*      */     public void setGuildId(Possible<Id> guildId) {
/*  805 */       this.guildId = guildId;
/*      */     }
/*      */     @JsonProperty("channel_id")
/*      */     public void setChannelId(Optional<Id> channelId) {
/*  809 */       this.channelId = channelId;
/*      */     }
/*      */     @JsonProperty("user_id")
/*      */     public void setUserId(Id userId) {
/*  813 */       this.userId = userId;
/*      */     }
/*      */     @JsonProperty("member")
/*      */     public void setMember(Possible<MemberData> member) {
/*  817 */       this.member = member;
/*      */     }
/*      */     @JsonProperty("session_id")
/*      */     public void setSessionId(String sessionId) {
/*  821 */       this.sessionId = sessionId;
/*      */     }
/*      */     @JsonProperty("deaf")
/*      */     public void setDeaf(boolean deaf) {
/*  825 */       this.deaf = deaf;
/*  826 */       this.deafIsSet = true;
/*      */     }
/*      */     @JsonProperty("mute")
/*      */     public void setMute(boolean mute) {
/*  830 */       this.mute = mute;
/*  831 */       this.muteIsSet = true;
/*      */     }
/*      */     @JsonProperty("self_deaf")
/*      */     public void setSelfDeaf(boolean selfDeaf) {
/*  835 */       this.selfDeaf = selfDeaf;
/*  836 */       this.selfDeafIsSet = true;
/*      */     }
/*      */     @JsonProperty("self_mute")
/*      */     public void setSelfMute(boolean selfMute) {
/*  840 */       this.selfMute = selfMute;
/*  841 */       this.selfMuteIsSet = true;
/*      */     }
/*      */     @JsonProperty("self_stream")
/*      */     public void setSelfStream(Possible<Boolean> selfStream) {
/*  845 */       this.selfStream = selfStream;
/*      */     }
/*      */     @JsonProperty("self_video")
/*      */     public void setSelfVideo(boolean selfVideo) {
/*  849 */       this.selfVideo = selfVideo;
/*  850 */       this.selfVideoIsSet = true;
/*      */     }
/*      */     @JsonProperty("suppress")
/*      */     public void setSuppress(boolean suppress) {
/*  854 */       this.suppress = suppress;
/*  855 */       this.suppressIsSet = true;
/*      */     }
/*      */     @JsonProperty("request_to_speak_timestamp")
/*      */     public void setRequestToSpeakTimestamp(Optional<String> requestToSpeakTimestamp) {
/*  859 */       this.requestToSpeakTimestamp = requestToSpeakTimestamp;
/*      */     }
/*      */     public Possible<Id> guildId() {
/*  862 */       throw new UnsupportedOperationException();
/*      */     } public Optional<Id> channelId() {
/*  864 */       throw new UnsupportedOperationException();
/*      */     } public Id userId() {
/*  866 */       throw new UnsupportedOperationException();
/*      */     } public Possible<MemberData> member() {
/*  868 */       throw new UnsupportedOperationException();
/*      */     } public String sessionId() {
/*  870 */       throw new UnsupportedOperationException();
/*      */     } public boolean deaf() {
/*  872 */       throw new UnsupportedOperationException();
/*      */     } public boolean mute() {
/*  874 */       throw new UnsupportedOperationException();
/*      */     } public boolean selfDeaf() {
/*  876 */       throw new UnsupportedOperationException();
/*      */     } public boolean selfMute() {
/*  878 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Boolean> selfStream() {
/*  880 */       throw new UnsupportedOperationException();
/*      */     } public boolean selfVideo() {
/*  882 */       throw new UnsupportedOperationException();
/*      */     } public boolean suppress() {
/*  884 */       throw new UnsupportedOperationException();
/*      */     } public Optional<String> requestToSpeakTimestamp() {
/*  886 */       throw new UnsupportedOperationException();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*      */   static ImmutableVoiceStateData fromJson(Json json) {
/*  897 */     Builder builder = builder();
/*  898 */     if (json.guildId != null) {
/*  899 */       builder.guildId(json.guildId);
/*      */     }
/*  901 */     if (json.channelId != null) {
/*  902 */       builder.channelId(json.channelId);
/*      */     }
/*  904 */     if (json.userId != null) {
/*  905 */       builder.userId(json.userId);
/*      */     }
/*  907 */     if (json.member != null) {
/*  908 */       builder.member(json.member);
/*      */     }
/*  910 */     if (json.sessionId != null) {
/*  911 */       builder.sessionId(json.sessionId);
/*      */     }
/*  913 */     if (json.deafIsSet) {
/*  914 */       builder.deaf(json.deaf);
/*      */     }
/*  916 */     if (json.muteIsSet) {
/*  917 */       builder.mute(json.mute);
/*      */     }
/*  919 */     if (json.selfDeafIsSet) {
/*  920 */       builder.selfDeaf(json.selfDeaf);
/*      */     }
/*  922 */     if (json.selfMuteIsSet) {
/*  923 */       builder.selfMute(json.selfMute);
/*      */     }
/*  925 */     if (json.selfStream != null) {
/*  926 */       builder.selfStream(json.selfStream);
/*      */     }
/*  928 */     if (json.selfVideoIsSet) {
/*  929 */       builder.selfVideo(json.selfVideo);
/*      */     }
/*  931 */     if (json.suppressIsSet) {
/*  932 */       builder.suppress(json.suppress);
/*      */     }
/*  934 */     if (json.requestToSpeakTimestamp != null) {
/*  935 */       builder.requestToSpeakTimestamp(json.requestToSpeakTimestamp);
/*      */     }
/*  937 */     return builder.build();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableVoiceStateData of(Possible<Id> guildId, Optional<Id> channelId, Id userId, Possible<MemberData> member, String sessionId, boolean deaf, boolean mute, boolean selfDeaf, boolean selfMute, Possible<Boolean> selfStream, boolean selfVideo, boolean suppress, Optional<String> requestToSpeakTimestamp) {
/*  958 */     return new ImmutableVoiceStateData(guildId, channelId, userId, member, sessionId, deaf, mute, selfDeaf, selfMute, selfStream, selfVideo, suppress, requestToSpeakTimestamp);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableVoiceStateData copyOf(VoiceStateData instance) {
/*  969 */     if (instance instanceof ImmutableVoiceStateData) {
/*  970 */       return (ImmutableVoiceStateData)instance;
/*      */     }
/*  972 */     return builder()
/*  973 */       .from(instance)
/*  974 */       .build();
/*      */   }
/*      */   
/*      */   public boolean isGuildIdPresent() {
/*  978 */     return !this.guildId_absent;
/*      */   }
/*      */   
/*      */   public long guildIdOrElse(long defaultValue) {
/*  982 */     return !this.guildId_absent ? this.guildId_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isChannelIdPresent() {
/*  986 */     return this.channelId_present;
/*      */   }
/*      */   
/*      */   public long channelIdOrElse(long defaultValue) {
/*  990 */     return this.channelId_present ? this.channelId_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isMemberPresent() {
/*  994 */     return !this.member_absent;
/*      */   }
/*      */   
/*      */   public MemberData memberOrElse(MemberData defaultValue) {
/*  998 */     return !this.member_absent ? this.member_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isSelfStreamPresent() {
/* 1002 */     return !this.selfStream_absent;
/*      */   }
/*      */   
/*      */   public Boolean selfStreamOrElse(Boolean defaultValue) {
/* 1006 */     return !this.selfStream_absent ? this.selfStream_value : defaultValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Builder builder() {
/* 1031 */     return new Builder();
/*      */   }
/*      */ 
/*      */   
/*      */   @Generated(from = "VoiceStateData", generator = "Immutables")
/*      */   public static final class Builder
/*      */   {
/*      */     private static final long INIT_BIT_SESSION_ID = 1L;
/*      */     
/*      */     private static final long INIT_BIT_DEAF = 2L;
/*      */     
/*      */     private static final long INIT_BIT_MUTE = 4L;
/*      */     
/*      */     private static final long INIT_BIT_SELF_DEAF = 8L;
/*      */     
/*      */     private static final long INIT_BIT_SELF_MUTE = 16L;
/*      */     
/*      */     private static final long INIT_BIT_SELF_VIDEO = 32L;
/*      */     private static final long INIT_BIT_SUPPRESS = 64L;
/* 1050 */     private long initBits = 127L;
/*      */     
/* 1052 */     private Possible<Id> guildId_possible = Possible.absent();
/* 1053 */     private Optional<Id> channelId_optional = Optional.empty();
/* 1054 */     private Id userId_id = null;
/* 1055 */     private Possible<MemberData> member_possible = Possible.absent();
/* 1056 */     private Possible<Boolean> selfStream_possible = Possible.absent();
/*      */ 
/*      */     
/*      */     private String sessionId;
/*      */     
/*      */     private boolean deaf;
/*      */     
/*      */     private boolean mute;
/*      */     
/*      */     private boolean selfDeaf;
/*      */     
/*      */     private boolean selfMute;
/*      */     
/*      */     private boolean selfVideo;
/*      */     
/*      */     private boolean suppress;
/*      */     
/*      */     private String requestToSpeakTimestamp;
/*      */ 
/*      */     
/*      */     public final Builder from(VoiceStateData instance) {
/* 1077 */       Objects.requireNonNull(instance, "instance");
/* 1078 */       guildId(instance.guildId());
/* 1079 */       channelId(instance.channelId());
/* 1080 */       userId(instance.userId());
/* 1081 */       member(instance.member());
/* 1082 */       sessionId(instance.sessionId());
/* 1083 */       deaf(instance.deaf());
/* 1084 */       mute(instance.mute());
/* 1085 */       selfDeaf(instance.selfDeaf());
/* 1086 */       selfMute(instance.selfMute());
/* 1087 */       selfStream(instance.selfStream());
/* 1088 */       selfVideo(instance.selfVideo());
/* 1089 */       suppress(instance.suppress());
/* 1090 */       Optional<String> requestToSpeakTimestampOptional = instance.requestToSpeakTimestamp();
/* 1091 */       if (requestToSpeakTimestampOptional.isPresent()) {
/* 1092 */         requestToSpeakTimestamp(requestToSpeakTimestampOptional);
/*      */       }
/* 1094 */       return this;
/*      */     }
/*      */     
/*      */     public Builder guildId(String value) {
/* 1098 */       this.guildId_possible = Possible.of(Id.of(value));
/* 1099 */       return this;
/*      */     }
/*      */     
/*      */     public Builder guildId(long value) {
/* 1103 */       this.guildId_possible = Possible.of(Id.of(value));
/* 1104 */       return this;
/*      */     }
/*      */     
/*      */     public Builder guildId(Id value) {
/* 1108 */       this.guildId_possible = Possible.of(value);
/* 1109 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("guild_id")
/*      */     public Builder guildId(Possible<Id> value) {
/* 1114 */       this.guildId_possible = value;
/* 1115 */       return this;
/*      */     }
/*      */     
/*      */     public Builder channelId(String value) {
/* 1119 */       this.channelId_optional = Optional.of(Id.of(value));
/* 1120 */       return this;
/*      */     }
/*      */     
/*      */     public Builder channelId(long value) {
/* 1124 */       this.channelId_optional = Optional.of(Id.of(value));
/* 1125 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("channel_id")
/*      */     public Builder channelId(Optional<Id> value) {
/* 1130 */       this.channelId_optional = value;
/* 1131 */       return this;
/*      */     }
/*      */     
/*      */     public Builder userId(String value) {
/* 1135 */       this.userId_id = Id.of(value);
/* 1136 */       return this;
/*      */     }
/*      */     
/*      */     public Builder userId(long value) {
/* 1140 */       this.userId_id = Id.of(value);
/* 1141 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("user_id")
/*      */     public Builder userId(Id value) {
/* 1146 */       this.userId_id = value;
/* 1147 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("member")
/*      */     public Builder member(Possible<MemberData> value) {
/* 1152 */       this.member_possible = value;
/* 1153 */       return this;
/*      */     }
/*      */     
/*      */     public Builder member(MemberData value) {
/* 1157 */       this.member_possible = Possible.of(value);
/* 1158 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("session_id")
/*      */     public final Builder sessionId(String sessionId) {
/* 1168 */       this.sessionId = Objects.<String>requireNonNull(sessionId, "sessionId");
/* 1169 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 1170 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("deaf")
/*      */     public final Builder deaf(boolean deaf) {
/* 1180 */       this.deaf = deaf;
/* 1181 */       this.initBits &= 0xFFFFFFFFFFFFFFFDL;
/* 1182 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("mute")
/*      */     public final Builder mute(boolean mute) {
/* 1192 */       this.mute = mute;
/* 1193 */       this.initBits &= 0xFFFFFFFFFFFFFFFBL;
/* 1194 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("self_deaf")
/*      */     public final Builder selfDeaf(boolean selfDeaf) {
/* 1204 */       this.selfDeaf = selfDeaf;
/* 1205 */       this.initBits &= 0xFFFFFFFFFFFFFFF7L;
/* 1206 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("self_mute")
/*      */     public final Builder selfMute(boolean selfMute) {
/* 1216 */       this.selfMute = selfMute;
/* 1217 */       this.initBits &= 0xFFFFFFFFFFFFFFEFL;
/* 1218 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("self_stream")
/*      */     public Builder selfStream(Possible<Boolean> value) {
/* 1223 */       this.selfStream_possible = value;
/* 1224 */       return this;
/*      */     }
/*      */     
/*      */     public Builder selfStream(Boolean value) {
/* 1228 */       this.selfStream_possible = Possible.of(value);
/* 1229 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("self_video")
/*      */     public final Builder selfVideo(boolean selfVideo) {
/* 1239 */       this.selfVideo = selfVideo;
/* 1240 */       this.initBits &= 0xFFFFFFFFFFFFFFDFL;
/* 1241 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("suppress")
/*      */     public final Builder suppress(boolean suppress) {
/* 1251 */       this.suppress = suppress;
/* 1252 */       this.initBits &= 0xFFFFFFFFFFFFFFBFL;
/* 1253 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder requestToSpeakTimestamp(String requestToSpeakTimestamp) {
/* 1262 */       this.requestToSpeakTimestamp = Objects.<String>requireNonNull(requestToSpeakTimestamp, "requestToSpeakTimestamp");
/* 1263 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("request_to_speak_timestamp")
/*      */     public final Builder requestToSpeakTimestamp(Optional<String> requestToSpeakTimestamp) {
/* 1273 */       this.requestToSpeakTimestamp = requestToSpeakTimestamp.orElse(null);
/* 1274 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ImmutableVoiceStateData build() {
/* 1283 */       if (this.initBits != 0L) {
/* 1284 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*      */       }
/* 1286 */       return new ImmutableVoiceStateData(null, 
/*      */           
/* 1288 */           guildId_build(), 
/* 1289 */           channelId_build(), 
/* 1290 */           userId_build(), 
/* 1291 */           member_build(), this.sessionId, this.deaf, this.mute, this.selfDeaf, this.selfMute, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1297 */           selfStream_build(), this.selfVideo, this.suppress, this.requestToSpeakTimestamp);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private String formatRequiredAttributesMessage() {
/* 1304 */       List<String> attributes = new ArrayList<>();
/* 1305 */       if ((this.initBits & 0x1L) != 0L) attributes.add("sessionId"); 
/* 1306 */       if ((this.initBits & 0x2L) != 0L) attributes.add("deaf"); 
/* 1307 */       if ((this.initBits & 0x4L) != 0L) attributes.add("mute"); 
/* 1308 */       if ((this.initBits & 0x8L) != 0L) attributes.add("selfDeaf"); 
/* 1309 */       if ((this.initBits & 0x10L) != 0L) attributes.add("selfMute"); 
/* 1310 */       if ((this.initBits & 0x20L) != 0L) attributes.add("selfVideo"); 
/* 1311 */       if ((this.initBits & 0x40L) != 0L) attributes.add("suppress"); 
/* 1312 */       return "Cannot build VoiceStateData, some of required attributes are not set " + attributes;
/*      */     }
/*      */     
/*      */     private Possible<Id> guildId_build() {
/* 1316 */       return this.guildId_possible;
/*      */     }
/*      */     
/*      */     private Optional<Id> channelId_build() {
/* 1320 */       return this.channelId_optional;
/*      */     }
/*      */     
/*      */     private Id userId_build() {
/* 1324 */       return this.userId_id;
/*      */     }
/*      */     
/*      */     private Possible<MemberData> member_build() {
/* 1328 */       return this.member_possible;
/*      */     }
/*      */     
/*      */     private Possible<Boolean> selfStream_build() {
/* 1332 */       return this.selfStream_possible;
/*      */     }
/*      */     
/*      */     private Builder() {}
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableVoiceStateData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */