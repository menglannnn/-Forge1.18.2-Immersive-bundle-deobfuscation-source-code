/*    */ package discord4j.discordjson.json;
/*    */ 
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import discord4j.discordjson.Id;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import java.util.List;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ @JsonSerialize(as = ImmutableGuildData.class)
/*    */ @JsonDeserialize(as = ImmutableGuildData.class)
/*    */ @Immutable
/*    */ public interface GuildData
/*    */   extends GuildCreateFields
/*    */ {
/*    */   static ImmutableGuildData.Builder builder() {
/* 17 */     return ImmutableGuildData.builder();
/*    */   }
/*    */   
/*    */   List<Id> roles();
/*    */   
/*    */   List<Id> emojis();
/*    */   
/*    */   Possible<List<Id>> stickers();
/*    */   
/*    */   List<Id> members();
/*    */   
/*    */   List<Id> channels();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\GuildData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */