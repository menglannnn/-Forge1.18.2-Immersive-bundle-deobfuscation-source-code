/*    */ package discord4j.discordjson.json;
/*    */ 
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import java.util.Optional;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ @JsonSerialize(as = ImmutableActivityUpdateRequest.class)
/*    */ @JsonDeserialize(as = ImmutableActivityUpdateRequest.class)
/*    */ @Immutable
/*    */ public interface ActivityUpdateRequest
/*    */   extends Activity
/*    */ {
/*    */   static ImmutableActivityUpdateRequest.Builder builder() {
/* 15 */     return ImmutableActivityUpdateRequest.builder();
/*    */   }
/*    */   
/*    */   Optional<String> url();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ActivityUpdateRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */