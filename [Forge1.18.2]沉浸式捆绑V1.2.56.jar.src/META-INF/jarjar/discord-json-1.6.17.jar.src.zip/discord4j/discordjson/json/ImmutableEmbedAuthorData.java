/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "EmbedAuthorData", generator = "Immutables")
/*     */ public final class ImmutableEmbedAuthorData
/*     */   implements EmbedAuthorData
/*     */ {
/*     */   private final String name_value;
/*     */   private final boolean name_absent;
/*     */   private final String url_value;
/*     */   private final boolean url_absent;
/*     */   private final String iconUrl_value;
/*     */   private final boolean iconUrl_absent;
/*     */   private final String proxyIconUrl_value;
/*     */   private final boolean proxyIconUrl_absent;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   
/*     */   private ImmutableEmbedAuthorData(Possible<String> name, Possible<String> url, Possible<String> iconUrl, Possible<String> proxyIconUrl) {
/*  39 */     Possible<String> name$impl = name;
/*  40 */     Possible<String> url$impl = url;
/*  41 */     Possible<String> iconUrl$impl = iconUrl;
/*  42 */     Possible<String> proxyIconUrl$impl = proxyIconUrl;
/*  43 */     this.name_value = name$impl.toOptional().orElse(null);
/*  44 */     this.name_absent = name$impl.isAbsent();
/*  45 */     this.url_value = url$impl.toOptional().orElse(null);
/*  46 */     this.url_absent = url$impl.isAbsent();
/*  47 */     this.iconUrl_value = iconUrl$impl.toOptional().orElse(null);
/*  48 */     this.iconUrl_absent = iconUrl$impl.isAbsent();
/*  49 */     this.proxyIconUrl_value = proxyIconUrl$impl.toOptional().orElse(null);
/*  50 */     this.proxyIconUrl_absent = proxyIconUrl$impl.isAbsent();
/*  51 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ImmutableEmbedAuthorData(ImmutableEmbedAuthorData original, Possible<String> name, Possible<String> url, Possible<String> iconUrl, Possible<String> proxyIconUrl) {
/*  60 */     Possible<String> name$impl = name;
/*  61 */     Possible<String> url$impl = url;
/*  62 */     Possible<String> iconUrl$impl = iconUrl;
/*  63 */     Possible<String> proxyIconUrl$impl = proxyIconUrl;
/*  64 */     this.name_value = name$impl.toOptional().orElse(null);
/*  65 */     this.name_absent = name$impl.isAbsent();
/*  66 */     this.url_value = url$impl.toOptional().orElse(null);
/*  67 */     this.url_absent = url$impl.isAbsent();
/*  68 */     this.iconUrl_value = iconUrl$impl.toOptional().orElse(null);
/*  69 */     this.iconUrl_absent = iconUrl$impl.isAbsent();
/*  70 */     this.proxyIconUrl_value = proxyIconUrl$impl.toOptional().orElse(null);
/*  71 */     this.proxyIconUrl_absent = proxyIconUrl$impl.isAbsent();
/*  72 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  78 */   private volatile transient InitShim initShim = new InitShim();
/*     */   
/*     */   @Generated(from = "EmbedAuthorData", generator = "Immutables")
/*     */   private final class InitShim {
/*     */     private String formatInitCycleMessage() {
/*  83 */       List<String> attributes = new ArrayList<>();
/*  84 */       return "Cannot build EmbedAuthorData, attribute initializers form cycle " + attributes;
/*     */     }
/*     */ 
/*     */     
/*     */     private InitShim() {}
/*     */   }
/*     */ 
/*     */   
/*     */   @JsonProperty("name")
/*     */   public Possible<String> name() {
/*  94 */     return this.name_absent ? Possible.absent() : Possible.of(this.name_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("url")
/*     */   public Possible<String> url() {
/* 103 */     return this.url_absent ? Possible.absent() : Possible.of(this.url_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("icon_url")
/*     */   public Possible<String> iconUrl() {
/* 112 */     return this.iconUrl_absent ? Possible.absent() : Possible.of(this.iconUrl_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("proxy_icon_url")
/*     */   public Possible<String> proxyIconUrl() {
/* 121 */     return this.proxyIconUrl_absent ? Possible.absent() : Possible.of(this.proxyIconUrl_value);
/*     */   }
/*     */   
/*     */   public ImmutableEmbedAuthorData withName(Possible<String> value) {
/* 125 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/* 126 */     return new ImmutableEmbedAuthorData(this, newValue, url(), iconUrl(), proxyIconUrl());
/*     */   }
/*     */   
/*     */   public ImmutableEmbedAuthorData withName(String value) {
/* 130 */     Possible<String> newValue = Possible.of(value);
/* 131 */     return new ImmutableEmbedAuthorData(this, newValue, url(), iconUrl(), proxyIconUrl());
/*     */   }
/*     */   
/*     */   public ImmutableEmbedAuthorData withUrl(Possible<String> value) {
/* 135 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/* 136 */     return new ImmutableEmbedAuthorData(this, name(), newValue, iconUrl(), proxyIconUrl());
/*     */   }
/*     */   
/*     */   public ImmutableEmbedAuthorData withUrl(String value) {
/* 140 */     Possible<String> newValue = Possible.of(value);
/* 141 */     return new ImmutableEmbedAuthorData(this, name(), newValue, iconUrl(), proxyIconUrl());
/*     */   }
/*     */   
/*     */   public ImmutableEmbedAuthorData withIconUrl(Possible<String> value) {
/* 145 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/* 146 */     return new ImmutableEmbedAuthorData(this, name(), url(), newValue, proxyIconUrl());
/*     */   }
/*     */   
/*     */   public ImmutableEmbedAuthorData withIconUrl(String value) {
/* 150 */     Possible<String> newValue = Possible.of(value);
/* 151 */     return new ImmutableEmbedAuthorData(this, name(), url(), newValue, proxyIconUrl());
/*     */   }
/*     */   
/*     */   public ImmutableEmbedAuthorData withProxyIconUrl(Possible<String> value) {
/* 155 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/* 156 */     return new ImmutableEmbedAuthorData(this, name(), url(), iconUrl(), newValue);
/*     */   }
/*     */   
/*     */   public ImmutableEmbedAuthorData withProxyIconUrl(String value) {
/* 160 */     Possible<String> newValue = Possible.of(value);
/* 161 */     return new ImmutableEmbedAuthorData(this, name(), url(), iconUrl(), newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 170 */     if (this == another) return true; 
/* 171 */     return (another instanceof ImmutableEmbedAuthorData && 
/* 172 */       equalTo(0, (ImmutableEmbedAuthorData)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableEmbedAuthorData another) {
/* 176 */     return (name().equals(another.name()) && 
/* 177 */       url().equals(another.url()) && 
/* 178 */       iconUrl().equals(another.iconUrl()) && 
/* 179 */       proxyIconUrl().equals(another.proxyIconUrl()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 188 */     int h = 5381;
/* 189 */     h += (h << 5) + name().hashCode();
/* 190 */     h += (h << 5) + url().hashCode();
/* 191 */     h += (h << 5) + iconUrl().hashCode();
/* 192 */     h += (h << 5) + proxyIconUrl().hashCode();
/* 193 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 202 */     return "EmbedAuthorData{name=" + 
/* 203 */       name().toString() + ", url=" + 
/* 204 */       url().toString() + ", iconUrl=" + 
/* 205 */       iconUrl().toString() + ", proxyIconUrl=" + 
/* 206 */       proxyIconUrl().toString() + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "EmbedAuthorData", generator = "Immutables")
/*     */   static final class Json
/*     */     implements EmbedAuthorData
/*     */   {
/* 220 */     Possible<String> name = Possible.absent();
/*     */ 
/*     */     
/* 223 */     Possible<String> url = Possible.absent();
/*     */ 
/*     */     
/* 226 */     Possible<String> iconUrl = Possible.absent();
/*     */ 
/*     */     
/* 229 */     Possible<String> proxyIconUrl = Possible.absent();
/*     */     
/*     */     @JsonProperty("name")
/*     */     public void setName(Possible<String> name) {
/* 233 */       this.name = name;
/*     */     }
/*     */     @JsonProperty("url")
/*     */     public void setUrl(Possible<String> url) {
/* 237 */       this.url = url;
/*     */     }
/*     */     @JsonProperty("icon_url")
/*     */     public void setIconUrl(Possible<String> iconUrl) {
/* 241 */       this.iconUrl = iconUrl;
/*     */     }
/*     */     @JsonProperty("proxy_icon_url")
/*     */     public void setProxyIconUrl(Possible<String> proxyIconUrl) {
/* 245 */       this.proxyIconUrl = proxyIconUrl;
/*     */     }
/*     */     public Possible<String> name() {
/* 248 */       throw new UnsupportedOperationException();
/*     */     } public Possible<String> url() {
/* 250 */       throw new UnsupportedOperationException();
/*     */     } public Possible<String> iconUrl() {
/* 252 */       throw new UnsupportedOperationException();
/*     */     } public Possible<String> proxyIconUrl() {
/* 254 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableEmbedAuthorData fromJson(Json json) {
/* 265 */     Builder builder = builder();
/* 266 */     if (json.name != null) {
/* 267 */       builder.name(json.name);
/*     */     }
/* 269 */     if (json.url != null) {
/* 270 */       builder.url(json.url);
/*     */     }
/* 272 */     if (json.iconUrl != null) {
/* 273 */       builder.iconUrl(json.iconUrl);
/*     */     }
/* 275 */     if (json.proxyIconUrl != null) {
/* 276 */       builder.proxyIconUrl(json.proxyIconUrl);
/*     */     }
/* 278 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableEmbedAuthorData of(Possible<String> name, Possible<String> url, Possible<String> iconUrl, Possible<String> proxyIconUrl) {
/* 290 */     return new ImmutableEmbedAuthorData(name, url, iconUrl, proxyIconUrl);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableEmbedAuthorData copyOf(EmbedAuthorData instance) {
/* 301 */     if (instance instanceof ImmutableEmbedAuthorData) {
/* 302 */       return (ImmutableEmbedAuthorData)instance;
/*     */     }
/* 304 */     return builder()
/* 305 */       .from(instance)
/* 306 */       .build();
/*     */   }
/*     */   
/*     */   public boolean isNamePresent() {
/* 310 */     return !this.name_absent;
/*     */   }
/*     */   
/*     */   public String nameOrElse(String defaultValue) {
/* 314 */     return !this.name_absent ? this.name_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isUrlPresent() {
/* 318 */     return !this.url_absent;
/*     */   }
/*     */   
/*     */   public String urlOrElse(String defaultValue) {
/* 322 */     return !this.url_absent ? this.url_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isIconUrlPresent() {
/* 326 */     return !this.iconUrl_absent;
/*     */   }
/*     */   
/*     */   public String iconUrlOrElse(String defaultValue) {
/* 330 */     return !this.iconUrl_absent ? this.iconUrl_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isProxyIconUrlPresent() {
/* 334 */     return !this.proxyIconUrl_absent;
/*     */   }
/*     */   
/*     */   public String proxyIconUrlOrElse(String defaultValue) {
/* 338 */     return !this.proxyIconUrl_absent ? this.proxyIconUrl_value : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 354 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "EmbedAuthorData", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/* 366 */     private Possible<String> name_possible = Possible.absent();
/* 367 */     private Possible<String> url_possible = Possible.absent();
/* 368 */     private Possible<String> iconUrl_possible = Possible.absent();
/* 369 */     private Possible<String> proxyIconUrl_possible = Possible.absent();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(EmbedAuthorData instance) {
/* 382 */       Objects.requireNonNull(instance, "instance");
/* 383 */       name(instance.name());
/* 384 */       url(instance.url());
/* 385 */       iconUrl(instance.iconUrl());
/* 386 */       proxyIconUrl(instance.proxyIconUrl());
/* 387 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("name")
/*     */     public Builder name(Possible<String> value) {
/* 392 */       this.name_possible = value;
/* 393 */       return this;
/*     */     }
/*     */     
/*     */     public Builder name(String value) {
/* 397 */       this.name_possible = Possible.of(value);
/* 398 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("url")
/*     */     public Builder url(Possible<String> value) {
/* 403 */       this.url_possible = value;
/* 404 */       return this;
/*     */     }
/*     */     
/*     */     public Builder url(String value) {
/* 408 */       this.url_possible = Possible.of(value);
/* 409 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("icon_url")
/*     */     public Builder iconUrl(Possible<String> value) {
/* 414 */       this.iconUrl_possible = value;
/* 415 */       return this;
/*     */     }
/*     */     
/*     */     public Builder iconUrl(String value) {
/* 419 */       this.iconUrl_possible = Possible.of(value);
/* 420 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("proxy_icon_url")
/*     */     public Builder proxyIconUrl(Possible<String> value) {
/* 425 */       this.proxyIconUrl_possible = value;
/* 426 */       return this;
/*     */     }
/*     */     
/*     */     public Builder proxyIconUrl(String value) {
/* 430 */       this.proxyIconUrl_possible = Possible.of(value);
/* 431 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableEmbedAuthorData build() {
/* 440 */       return new ImmutableEmbedAuthorData(null, name_build(), url_build(), iconUrl_build(), proxyIconUrl_build());
/*     */     }
/*     */     
/*     */     private Possible<String> name_build() {
/* 444 */       return this.name_possible;
/*     */     }
/*     */     
/*     */     private Possible<String> url_build() {
/* 448 */       return this.url_possible;
/*     */     }
/*     */     
/*     */     private Possible<String> iconUrl_build() {
/* 452 */       return this.iconUrl_possible;
/*     */     }
/*     */     
/*     */     private Possible<String> proxyIconUrl_build() {
/* 456 */       return this.proxyIconUrl_possible;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableEmbedAuthorData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */