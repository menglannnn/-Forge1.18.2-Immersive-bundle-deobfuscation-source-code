/*      */ package discord4j.discordjson.json;
/*      */ 
/*      */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*      */ import com.fasterxml.jackson.annotation.JsonCreator;
/*      */ import com.fasterxml.jackson.annotation.JsonProperty;
/*      */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*      */ import discord4j.discordjson.possible.Possible;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.List;
/*      */ import java.util.Objects;
/*      */ import java.util.Optional;
/*      */ import java.util.stream.Collectors;
/*      */ import java.util.stream.StreamSupport;
/*      */ import org.immutables.value.Generated;
/*      */ import reactor.util.annotation.Nullable;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ @Generated(from = "ChannelModifyRequest", generator = "Immutables")
/*      */ public final class ImmutableChannelModifyRequest
/*      */   implements ChannelModifyRequest
/*      */ {
/*      */   private final String name_value;
/*      */   private final boolean name_absent;
/*      */   private final Integer position_value;
/*      */   private final boolean position_absent;
/*      */   private final String topic_value;
/*      */   private final boolean topic_absent;
/*      */   private final Boolean nsfw_value;
/*      */   private final boolean nsfw_absent;
/*      */   private final Integer rateLimitPerUser_value;
/*      */   private final boolean rateLimitPerUser_absent;
/*      */   private final Integer bitrate_value;
/*      */   private final boolean bitrate_absent;
/*      */   private final Integer userLimit_value;
/*      */   private final boolean userLimit_absent;
/*      */   private final List<OverwriteData> permissionOverwrites_value;
/*      */   private final boolean permissionOverwrites_absent;
/*      */   private final String parentId_value;
/*      */   private final boolean parentId_absent;
/*      */   private final String rtcRegion_value;
/*      */   private final boolean rtcRegion_absent;
/*      */   private final Integer videoQualityMode_value;
/*      */   private final boolean videoQualityMode_absent;
/*      */   private static final byte STAGE_INITIALIZING = -1;
/*      */   private static final byte STAGE_UNINITIALIZED = 0;
/*      */   private static final byte STAGE_INITIALIZED = 1;
/*      */   
/*      */   private ImmutableChannelModifyRequest(Possible<String> name, Possible<Integer> position, Possible<String> topic, Possible<Boolean> nsfw, Possible<Integer> rateLimitPerUser, Possible<Integer> bitrate, Possible<Integer> userLimit, Possible<List<OverwriteData>> permissionOverwrites, Possible<Optional<String>> parentId, Possible<Optional<String>> rtcRegion, Possible<Optional<Integer>> videoQualityMode) {
/*   65 */     Possible<String> name$impl = name;
/*   66 */     Possible<Integer> position$impl = position;
/*   67 */     Possible<String> topic$impl = topic;
/*   68 */     Possible<Boolean> nsfw$impl = nsfw;
/*   69 */     Possible<Integer> rateLimitPerUser$impl = rateLimitPerUser;
/*   70 */     Possible<Integer> bitrate$impl = bitrate;
/*   71 */     Possible<Integer> userLimit$impl = userLimit;
/*   72 */     Possible<List<OverwriteData>> permissionOverwrites$impl = permissionOverwrites;
/*   73 */     Possible<Optional<String>> parentId$impl = parentId;
/*   74 */     Possible<Optional<String>> rtcRegion$impl = rtcRegion;
/*   75 */     Possible<Optional<Integer>> videoQualityMode$impl = videoQualityMode;
/*   76 */     this.name_value = name$impl.toOptional().orElse(null);
/*   77 */     this.name_absent = name$impl.isAbsent();
/*   78 */     this.position_value = position$impl.toOptional().orElse(null);
/*   79 */     this.position_absent = position$impl.isAbsent();
/*   80 */     this.topic_value = topic$impl.toOptional().orElse(null);
/*   81 */     this.topic_absent = topic$impl.isAbsent();
/*   82 */     this.nsfw_value = nsfw$impl.toOptional().orElse(null);
/*   83 */     this.nsfw_absent = nsfw$impl.isAbsent();
/*   84 */     this.rateLimitPerUser_value = rateLimitPerUser$impl.toOptional().orElse(null);
/*   85 */     this.rateLimitPerUser_absent = rateLimitPerUser$impl.isAbsent();
/*   86 */     this.bitrate_value = bitrate$impl.toOptional().orElse(null);
/*   87 */     this.bitrate_absent = bitrate$impl.isAbsent();
/*   88 */     this.userLimit_value = userLimit$impl.toOptional().orElse(null);
/*   89 */     this.userLimit_absent = userLimit$impl.isAbsent();
/*   90 */     this.permissionOverwrites_value = permissionOverwrites$impl.toOptional().orElse(null);
/*   91 */     this.permissionOverwrites_absent = permissionOverwrites$impl.isAbsent();
/*   92 */     this.parentId_value = Possible.flatOpt(parentId$impl).orElse(null);
/*   93 */     this.parentId_absent = parentId$impl.isAbsent();
/*   94 */     this.rtcRegion_value = Possible.flatOpt(rtcRegion$impl).orElse(null);
/*   95 */     this.rtcRegion_absent = rtcRegion$impl.isAbsent();
/*   96 */     this.videoQualityMode_value = Possible.flatOpt(videoQualityMode$impl).orElse(null);
/*   97 */     this.videoQualityMode_absent = videoQualityMode$impl.isAbsent();
/*   98 */     this.initShim = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ImmutableChannelModifyRequest(ImmutableChannelModifyRequest original, Possible<String> name, Possible<Integer> position, Possible<String> topic, Possible<Boolean> nsfw, Possible<Integer> rateLimitPerUser, Possible<Integer> bitrate, Possible<Integer> userLimit, Possible<List<OverwriteData>> permissionOverwrites, Possible<Optional<String>> parentId, Possible<Optional<String>> rtcRegion, Possible<Optional<Integer>> videoQualityMode) {
/*  114 */     Possible<String> name$impl = name;
/*  115 */     Possible<Integer> position$impl = position;
/*  116 */     Possible<String> topic$impl = topic;
/*  117 */     Possible<Boolean> nsfw$impl = nsfw;
/*  118 */     Possible<Integer> rateLimitPerUser$impl = rateLimitPerUser;
/*  119 */     Possible<Integer> bitrate$impl = bitrate;
/*  120 */     Possible<Integer> userLimit$impl = userLimit;
/*  121 */     Possible<List<OverwriteData>> permissionOverwrites$impl = permissionOverwrites;
/*  122 */     Possible<Optional<String>> parentId$impl = parentId;
/*  123 */     Possible<Optional<String>> rtcRegion$impl = rtcRegion;
/*  124 */     Possible<Optional<Integer>> videoQualityMode$impl = videoQualityMode;
/*  125 */     this.name_value = name$impl.toOptional().orElse(null);
/*  126 */     this.name_absent = name$impl.isAbsent();
/*  127 */     this.position_value = position$impl.toOptional().orElse(null);
/*  128 */     this.position_absent = position$impl.isAbsent();
/*  129 */     this.topic_value = topic$impl.toOptional().orElse(null);
/*  130 */     this.topic_absent = topic$impl.isAbsent();
/*  131 */     this.nsfw_value = nsfw$impl.toOptional().orElse(null);
/*  132 */     this.nsfw_absent = nsfw$impl.isAbsent();
/*  133 */     this.rateLimitPerUser_value = rateLimitPerUser$impl.toOptional().orElse(null);
/*  134 */     this.rateLimitPerUser_absent = rateLimitPerUser$impl.isAbsent();
/*  135 */     this.bitrate_value = bitrate$impl.toOptional().orElse(null);
/*  136 */     this.bitrate_absent = bitrate$impl.isAbsent();
/*  137 */     this.userLimit_value = userLimit$impl.toOptional().orElse(null);
/*  138 */     this.userLimit_absent = userLimit$impl.isAbsent();
/*  139 */     this.permissionOverwrites_value = permissionOverwrites$impl.toOptional().orElse(null);
/*  140 */     this.permissionOverwrites_absent = permissionOverwrites$impl.isAbsent();
/*  141 */     this.parentId_value = Possible.flatOpt(parentId$impl).orElse(null);
/*  142 */     this.parentId_absent = parentId$impl.isAbsent();
/*  143 */     this.rtcRegion_value = Possible.flatOpt(rtcRegion$impl).orElse(null);
/*  144 */     this.rtcRegion_absent = rtcRegion$impl.isAbsent();
/*  145 */     this.videoQualityMode_value = Possible.flatOpt(videoQualityMode$impl).orElse(null);
/*  146 */     this.videoQualityMode_absent = videoQualityMode$impl.isAbsent();
/*  147 */     this.initShim = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  153 */   private volatile transient InitShim initShim = new InitShim();
/*      */   
/*      */   @Generated(from = "ChannelModifyRequest", generator = "Immutables")
/*      */   private final class InitShim {
/*      */     private String formatInitCycleMessage() {
/*  158 */       List<String> attributes = new ArrayList<>();
/*  159 */       return "Cannot build ChannelModifyRequest, attribute initializers form cycle " + attributes;
/*      */     }
/*      */ 
/*      */     
/*      */     private InitShim() {}
/*      */   }
/*      */ 
/*      */   
/*      */   @JsonProperty("name")
/*      */   public Possible<String> name() {
/*  169 */     return this.name_absent ? Possible.absent() : Possible.of(this.name_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("position")
/*      */   public Possible<Integer> position() {
/*  178 */     return this.position_absent ? Possible.absent() : Possible.of(this.position_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("topic")
/*      */   public Possible<String> topic() {
/*  187 */     return this.topic_absent ? Possible.absent() : Possible.of(this.topic_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("nsfw")
/*      */   public Possible<Boolean> nsfw() {
/*  196 */     return this.nsfw_absent ? Possible.absent() : Possible.of(this.nsfw_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("rate_limit_per_user")
/*      */   public Possible<Integer> rateLimitPerUser() {
/*  205 */     return this.rateLimitPerUser_absent ? Possible.absent() : Possible.of(this.rateLimitPerUser_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("bitrate")
/*      */   public Possible<Integer> bitrate() {
/*  214 */     return this.bitrate_absent ? Possible.absent() : Possible.of(this.bitrate_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("user_limit")
/*      */   public Possible<Integer> userLimit() {
/*  223 */     return this.userLimit_absent ? Possible.absent() : Possible.of(this.userLimit_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("permission_overwrites")
/*      */   public Possible<List<OverwriteData>> permissionOverwrites() {
/*  232 */     return this.permissionOverwrites_absent ? Possible.absent() : 
/*  233 */       Possible.of(this.permissionOverwrites_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("parent_id")
/*      */   public Possible<Optional<String>> parentId() {
/*  242 */     return this.parentId_absent ? Possible.absent() : 
/*  243 */       Possible.of(Optional.ofNullable(this.parentId_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("rtc_region")
/*      */   public Possible<Optional<String>> rtcRegion() {
/*  252 */     return this.rtcRegion_absent ? Possible.absent() : 
/*  253 */       Possible.of(Optional.ofNullable(this.rtcRegion_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("video_quality_mode")
/*      */   public Possible<Optional<Integer>> videoQualityMode() {
/*  262 */     return this.videoQualityMode_absent ? Possible.absent() : 
/*  263 */       Possible.of(Optional.ofNullable(this.videoQualityMode_value));
/*      */   }
/*      */   
/*      */   public ImmutableChannelModifyRequest withName(Possible<String> value) {
/*  267 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/*  268 */     return new ImmutableChannelModifyRequest(this, newValue, 
/*      */ 
/*      */         
/*  271 */         position(), 
/*  272 */         topic(), 
/*  273 */         nsfw(), 
/*  274 */         rateLimitPerUser(), 
/*  275 */         bitrate(), 
/*  276 */         userLimit(), 
/*  277 */         permissionOverwrites(), 
/*  278 */         parentId(), 
/*  279 */         rtcRegion(), 
/*  280 */         videoQualityMode());
/*      */   }
/*      */   
/*      */   public ImmutableChannelModifyRequest withName(String value) {
/*  284 */     Possible<String> newValue = Possible.of(value);
/*  285 */     return new ImmutableChannelModifyRequest(this, newValue, 
/*      */ 
/*      */         
/*  288 */         position(), 
/*  289 */         topic(), 
/*  290 */         nsfw(), 
/*  291 */         rateLimitPerUser(), 
/*  292 */         bitrate(), 
/*  293 */         userLimit(), 
/*  294 */         permissionOverwrites(), 
/*  295 */         parentId(), 
/*  296 */         rtcRegion(), 
/*  297 */         videoQualityMode());
/*      */   }
/*      */   
/*      */   public ImmutableChannelModifyRequest withPosition(Possible<Integer> value) {
/*  301 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/*  302 */     return new ImmutableChannelModifyRequest(this, 
/*      */         
/*  304 */         name(), newValue, 
/*      */         
/*  306 */         topic(), 
/*  307 */         nsfw(), 
/*  308 */         rateLimitPerUser(), 
/*  309 */         bitrate(), 
/*  310 */         userLimit(), 
/*  311 */         permissionOverwrites(), 
/*  312 */         parentId(), 
/*  313 */         rtcRegion(), 
/*  314 */         videoQualityMode());
/*      */   }
/*      */   
/*      */   public ImmutableChannelModifyRequest withPosition(Integer value) {
/*  318 */     Possible<Integer> newValue = Possible.of(value);
/*  319 */     return new ImmutableChannelModifyRequest(this, 
/*      */         
/*  321 */         name(), newValue, 
/*      */         
/*  323 */         topic(), 
/*  324 */         nsfw(), 
/*  325 */         rateLimitPerUser(), 
/*  326 */         bitrate(), 
/*  327 */         userLimit(), 
/*  328 */         permissionOverwrites(), 
/*  329 */         parentId(), 
/*  330 */         rtcRegion(), 
/*  331 */         videoQualityMode());
/*      */   }
/*      */   
/*      */   public ImmutableChannelModifyRequest withTopic(Possible<String> value) {
/*  335 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/*  336 */     return new ImmutableChannelModifyRequest(this, 
/*      */         
/*  338 */         name(), 
/*  339 */         position(), newValue, 
/*      */         
/*  341 */         nsfw(), 
/*  342 */         rateLimitPerUser(), 
/*  343 */         bitrate(), 
/*  344 */         userLimit(), 
/*  345 */         permissionOverwrites(), 
/*  346 */         parentId(), 
/*  347 */         rtcRegion(), 
/*  348 */         videoQualityMode());
/*      */   }
/*      */   
/*      */   public ImmutableChannelModifyRequest withTopic(String value) {
/*  352 */     Possible<String> newValue = Possible.of(value);
/*  353 */     return new ImmutableChannelModifyRequest(this, 
/*      */         
/*  355 */         name(), 
/*  356 */         position(), newValue, 
/*      */         
/*  358 */         nsfw(), 
/*  359 */         rateLimitPerUser(), 
/*  360 */         bitrate(), 
/*  361 */         userLimit(), 
/*  362 */         permissionOverwrites(), 
/*  363 */         parentId(), 
/*  364 */         rtcRegion(), 
/*  365 */         videoQualityMode());
/*      */   }
/*      */   
/*      */   public ImmutableChannelModifyRequest withNsfw(Possible<Boolean> value) {
/*  369 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/*  370 */     return new ImmutableChannelModifyRequest(this, 
/*      */         
/*  372 */         name(), 
/*  373 */         position(), 
/*  374 */         topic(), newValue, 
/*      */         
/*  376 */         rateLimitPerUser(), 
/*  377 */         bitrate(), 
/*  378 */         userLimit(), 
/*  379 */         permissionOverwrites(), 
/*  380 */         parentId(), 
/*  381 */         rtcRegion(), 
/*  382 */         videoQualityMode());
/*      */   }
/*      */   
/*      */   public ImmutableChannelModifyRequest withNsfw(Boolean value) {
/*  386 */     Possible<Boolean> newValue = Possible.of(value);
/*  387 */     return new ImmutableChannelModifyRequest(this, 
/*      */         
/*  389 */         name(), 
/*  390 */         position(), 
/*  391 */         topic(), newValue, 
/*      */         
/*  393 */         rateLimitPerUser(), 
/*  394 */         bitrate(), 
/*  395 */         userLimit(), 
/*  396 */         permissionOverwrites(), 
/*  397 */         parentId(), 
/*  398 */         rtcRegion(), 
/*  399 */         videoQualityMode());
/*      */   }
/*      */   
/*      */   public ImmutableChannelModifyRequest withRateLimitPerUser(Possible<Integer> value) {
/*  403 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/*  404 */     return new ImmutableChannelModifyRequest(this, 
/*      */         
/*  406 */         name(), 
/*  407 */         position(), 
/*  408 */         topic(), 
/*  409 */         nsfw(), newValue, 
/*      */         
/*  411 */         bitrate(), 
/*  412 */         userLimit(), 
/*  413 */         permissionOverwrites(), 
/*  414 */         parentId(), 
/*  415 */         rtcRegion(), 
/*  416 */         videoQualityMode());
/*      */   }
/*      */   
/*      */   public ImmutableChannelModifyRequest withRateLimitPerUser(Integer value) {
/*  420 */     Possible<Integer> newValue = Possible.of(value);
/*  421 */     return new ImmutableChannelModifyRequest(this, 
/*      */         
/*  423 */         name(), 
/*  424 */         position(), 
/*  425 */         topic(), 
/*  426 */         nsfw(), newValue, 
/*      */         
/*  428 */         bitrate(), 
/*  429 */         userLimit(), 
/*  430 */         permissionOverwrites(), 
/*  431 */         parentId(), 
/*  432 */         rtcRegion(), 
/*  433 */         videoQualityMode());
/*      */   }
/*      */   
/*      */   public ImmutableChannelModifyRequest withBitrate(Possible<Integer> value) {
/*  437 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/*  438 */     return new ImmutableChannelModifyRequest(this, 
/*      */         
/*  440 */         name(), 
/*  441 */         position(), 
/*  442 */         topic(), 
/*  443 */         nsfw(), 
/*  444 */         rateLimitPerUser(), newValue, 
/*      */         
/*  446 */         userLimit(), 
/*  447 */         permissionOverwrites(), 
/*  448 */         parentId(), 
/*  449 */         rtcRegion(), 
/*  450 */         videoQualityMode());
/*      */   }
/*      */   
/*      */   public ImmutableChannelModifyRequest withBitrate(Integer value) {
/*  454 */     Possible<Integer> newValue = Possible.of(value);
/*  455 */     return new ImmutableChannelModifyRequest(this, 
/*      */         
/*  457 */         name(), 
/*  458 */         position(), 
/*  459 */         topic(), 
/*  460 */         nsfw(), 
/*  461 */         rateLimitPerUser(), newValue, 
/*      */         
/*  463 */         userLimit(), 
/*  464 */         permissionOverwrites(), 
/*  465 */         parentId(), 
/*  466 */         rtcRegion(), 
/*  467 */         videoQualityMode());
/*      */   }
/*      */   
/*      */   public ImmutableChannelModifyRequest withUserLimit(Possible<Integer> value) {
/*  471 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/*  472 */     return new ImmutableChannelModifyRequest(this, 
/*      */         
/*  474 */         name(), 
/*  475 */         position(), 
/*  476 */         topic(), 
/*  477 */         nsfw(), 
/*  478 */         rateLimitPerUser(), 
/*  479 */         bitrate(), newValue, 
/*      */         
/*  481 */         permissionOverwrites(), 
/*  482 */         parentId(), 
/*  483 */         rtcRegion(), 
/*  484 */         videoQualityMode());
/*      */   }
/*      */   
/*      */   public ImmutableChannelModifyRequest withUserLimit(Integer value) {
/*  488 */     Possible<Integer> newValue = Possible.of(value);
/*  489 */     return new ImmutableChannelModifyRequest(this, 
/*      */         
/*  491 */         name(), 
/*  492 */         position(), 
/*  493 */         topic(), 
/*  494 */         nsfw(), 
/*  495 */         rateLimitPerUser(), 
/*  496 */         bitrate(), newValue, 
/*      */         
/*  498 */         permissionOverwrites(), 
/*  499 */         parentId(), 
/*  500 */         rtcRegion(), 
/*  501 */         videoQualityMode());
/*      */   }
/*      */   
/*      */   public ImmutableChannelModifyRequest withPermissionOverwrites(Possible<List<OverwriteData>> possible) {
/*  505 */     Possible<List<OverwriteData>> newValue = Objects.<Possible<List<OverwriteData>>>requireNonNull(possible);
/*  506 */     return new ImmutableChannelModifyRequest(this, 
/*      */         
/*  508 */         name(), 
/*  509 */         position(), 
/*  510 */         topic(), 
/*  511 */         nsfw(), 
/*  512 */         rateLimitPerUser(), 
/*  513 */         bitrate(), 
/*  514 */         userLimit(), newValue, 
/*      */         
/*  516 */         parentId(), 
/*  517 */         rtcRegion(), 
/*  518 */         videoQualityMode());
/*      */   }
/*      */   
/*      */   public ImmutableChannelModifyRequest withPermissionOverwrites(Iterable<OverwriteData> elements) {
/*  522 */     Possible<List<OverwriteData>> newValue = Possible.of(
/*  523 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/*  524 */     return new ImmutableChannelModifyRequest(this, 
/*      */         
/*  526 */         name(), 
/*  527 */         position(), 
/*  528 */         topic(), 
/*  529 */         nsfw(), 
/*  530 */         rateLimitPerUser(), 
/*  531 */         bitrate(), 
/*  532 */         userLimit(), newValue, 
/*      */         
/*  534 */         parentId(), 
/*  535 */         rtcRegion(), 
/*  536 */         videoQualityMode());
/*      */   }
/*      */   
/*      */   @SafeVarargs
/*      */   public final ImmutableChannelModifyRequest withPermissionOverwrites(OverwriteData... elements) {
/*  541 */     Possible<List<OverwriteData>> newValue = Possible.of(Arrays.asList(elements));
/*  542 */     return new ImmutableChannelModifyRequest(this, 
/*      */         
/*  544 */         name(), 
/*  545 */         position(), 
/*  546 */         topic(), 
/*  547 */         nsfw(), 
/*  548 */         rateLimitPerUser(), 
/*  549 */         bitrate(), 
/*  550 */         userLimit(), newValue, 
/*      */         
/*  552 */         parentId(), 
/*  553 */         rtcRegion(), 
/*  554 */         videoQualityMode());
/*      */   }
/*      */   
/*      */   public ImmutableChannelModifyRequest withParentId(Possible<Optional<String>> value) {
/*  558 */     Possible<Optional<String>> newValue = Objects.<Possible<Optional<String>>>requireNonNull(value);
/*  559 */     return new ImmutableChannelModifyRequest(this, 
/*      */         
/*  561 */         name(), 
/*  562 */         position(), 
/*  563 */         topic(), 
/*  564 */         nsfw(), 
/*  565 */         rateLimitPerUser(), 
/*  566 */         bitrate(), 
/*  567 */         userLimit(), 
/*  568 */         permissionOverwrites(), newValue, 
/*      */         
/*  570 */         rtcRegion(), 
/*  571 */         videoQualityMode());
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public ImmutableChannelModifyRequest withParentId(@Nullable String value) {
/*  576 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/*  577 */     return new ImmutableChannelModifyRequest(this, 
/*      */         
/*  579 */         name(), 
/*  580 */         position(), 
/*  581 */         topic(), 
/*  582 */         nsfw(), 
/*  583 */         rateLimitPerUser(), 
/*  584 */         bitrate(), 
/*  585 */         userLimit(), 
/*  586 */         permissionOverwrites(), newValue, 
/*      */         
/*  588 */         rtcRegion(), 
/*  589 */         videoQualityMode());
/*      */   }
/*      */   
/*      */   public ImmutableChannelModifyRequest withParentIdOrNull(@Nullable String value) {
/*  593 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/*  594 */     return new ImmutableChannelModifyRequest(this, 
/*      */         
/*  596 */         name(), 
/*  597 */         position(), 
/*  598 */         topic(), 
/*  599 */         nsfw(), 
/*  600 */         rateLimitPerUser(), 
/*  601 */         bitrate(), 
/*  602 */         userLimit(), 
/*  603 */         permissionOverwrites(), newValue, 
/*      */         
/*  605 */         rtcRegion(), 
/*  606 */         videoQualityMode());
/*      */   }
/*      */   
/*      */   public ImmutableChannelModifyRequest withRtcRegion(Possible<Optional<String>> value) {
/*  610 */     Possible<Optional<String>> newValue = Objects.<Possible<Optional<String>>>requireNonNull(value);
/*  611 */     return new ImmutableChannelModifyRequest(this, 
/*      */         
/*  613 */         name(), 
/*  614 */         position(), 
/*  615 */         topic(), 
/*  616 */         nsfw(), 
/*  617 */         rateLimitPerUser(), 
/*  618 */         bitrate(), 
/*  619 */         userLimit(), 
/*  620 */         permissionOverwrites(), 
/*  621 */         parentId(), newValue, 
/*      */         
/*  623 */         videoQualityMode());
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public ImmutableChannelModifyRequest withRtcRegion(@Nullable String value) {
/*  628 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/*  629 */     return new ImmutableChannelModifyRequest(this, 
/*      */         
/*  631 */         name(), 
/*  632 */         position(), 
/*  633 */         topic(), 
/*  634 */         nsfw(), 
/*  635 */         rateLimitPerUser(), 
/*  636 */         bitrate(), 
/*  637 */         userLimit(), 
/*  638 */         permissionOverwrites(), 
/*  639 */         parentId(), newValue, 
/*      */         
/*  641 */         videoQualityMode());
/*      */   }
/*      */   
/*      */   public ImmutableChannelModifyRequest withRtcRegionOrNull(@Nullable String value) {
/*  645 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/*  646 */     return new ImmutableChannelModifyRequest(this, 
/*      */         
/*  648 */         name(), 
/*  649 */         position(), 
/*  650 */         topic(), 
/*  651 */         nsfw(), 
/*  652 */         rateLimitPerUser(), 
/*  653 */         bitrate(), 
/*  654 */         userLimit(), 
/*  655 */         permissionOverwrites(), 
/*  656 */         parentId(), newValue, 
/*      */         
/*  658 */         videoQualityMode());
/*      */   }
/*      */   
/*      */   public ImmutableChannelModifyRequest withVideoQualityMode(Possible<Optional<Integer>> value) {
/*  662 */     Possible<Optional<Integer>> newValue = Objects.<Possible<Optional<Integer>>>requireNonNull(value);
/*  663 */     return new ImmutableChannelModifyRequest(this, 
/*      */         
/*  665 */         name(), 
/*  666 */         position(), 
/*  667 */         topic(), 
/*  668 */         nsfw(), 
/*  669 */         rateLimitPerUser(), 
/*  670 */         bitrate(), 
/*  671 */         userLimit(), 
/*  672 */         permissionOverwrites(), 
/*  673 */         parentId(), 
/*  674 */         rtcRegion(), newValue);
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public ImmutableChannelModifyRequest withVideoQualityMode(@Nullable Integer value) {
/*  680 */     Possible<Optional<Integer>> newValue = Possible.of(Optional.ofNullable(value));
/*  681 */     return new ImmutableChannelModifyRequest(this, 
/*      */         
/*  683 */         name(), 
/*  684 */         position(), 
/*  685 */         topic(), 
/*  686 */         nsfw(), 
/*  687 */         rateLimitPerUser(), 
/*  688 */         bitrate(), 
/*  689 */         userLimit(), 
/*  690 */         permissionOverwrites(), 
/*  691 */         parentId(), 
/*  692 */         rtcRegion(), newValue);
/*      */   }
/*      */ 
/*      */   
/*      */   public ImmutableChannelModifyRequest withVideoQualityModeOrNull(@Nullable Integer value) {
/*  697 */     Possible<Optional<Integer>> newValue = Possible.of(Optional.ofNullable(value));
/*  698 */     return new ImmutableChannelModifyRequest(this, 
/*      */         
/*  700 */         name(), 
/*  701 */         position(), 
/*  702 */         topic(), 
/*  703 */         nsfw(), 
/*  704 */         rateLimitPerUser(), 
/*  705 */         bitrate(), 
/*  706 */         userLimit(), 
/*  707 */         permissionOverwrites(), 
/*  708 */         parentId(), 
/*  709 */         rtcRegion(), newValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean equals(Object another) {
/*  719 */     if (this == another) return true; 
/*  720 */     return (another instanceof ImmutableChannelModifyRequest && 
/*  721 */       equalTo(0, (ImmutableChannelModifyRequest)another));
/*      */   }
/*      */   
/*      */   private boolean equalTo(int synthetic, ImmutableChannelModifyRequest another) {
/*  725 */     return (name().equals(another.name()) && 
/*  726 */       position().equals(another.position()) && 
/*  727 */       topic().equals(another.topic()) && 
/*  728 */       nsfw().equals(another.nsfw()) && 
/*  729 */       rateLimitPerUser().equals(another.rateLimitPerUser()) && 
/*  730 */       bitrate().equals(another.bitrate()) && 
/*  731 */       userLimit().equals(another.userLimit()) && 
/*  732 */       Objects.equals(this.permissionOverwrites_value, another.permissionOverwrites_value) && 
/*  733 */       parentId().equals(another.parentId()) && 
/*  734 */       rtcRegion().equals(another.rtcRegion()) && 
/*  735 */       videoQualityMode().equals(another.videoQualityMode()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int hashCode() {
/*  744 */     int h = 5381;
/*  745 */     h += (h << 5) + name().hashCode();
/*  746 */     h += (h << 5) + position().hashCode();
/*  747 */     h += (h << 5) + topic().hashCode();
/*  748 */     h += (h << 5) + nsfw().hashCode();
/*  749 */     h += (h << 5) + rateLimitPerUser().hashCode();
/*  750 */     h += (h << 5) + bitrate().hashCode();
/*  751 */     h += (h << 5) + userLimit().hashCode();
/*  752 */     h += (h << 5) + Objects.hashCode(this.permissionOverwrites_value);
/*  753 */     h += (h << 5) + parentId().hashCode();
/*  754 */     h += (h << 5) + rtcRegion().hashCode();
/*  755 */     h += (h << 5) + videoQualityMode().hashCode();
/*  756 */     return h;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/*  765 */     return "ChannelModifyRequest{name=" + 
/*  766 */       name().toString() + ", position=" + 
/*  767 */       position().toString() + ", topic=" + 
/*  768 */       topic().toString() + ", nsfw=" + 
/*  769 */       nsfw().toString() + ", rateLimitPerUser=" + 
/*  770 */       rateLimitPerUser().toString() + ", bitrate=" + 
/*  771 */       bitrate().toString() + ", userLimit=" + 
/*  772 */       userLimit().toString() + ", permissionOverwrites=" + 
/*  773 */       Objects.toString(this.permissionOverwrites_value) + ", parentId=" + 
/*  774 */       parentId().toString() + ", rtcRegion=" + 
/*  775 */       rtcRegion().toString() + ", videoQualityMode=" + 
/*  776 */       videoQualityMode().toString() + "}";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonDeserialize
/*      */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*      */   @Generated(from = "ChannelModifyRequest", generator = "Immutables")
/*      */   static final class Json
/*      */     implements ChannelModifyRequest
/*      */   {
/*  790 */     Possible<String> name = Possible.absent();
/*      */ 
/*      */     
/*  793 */     Possible<Integer> position = Possible.absent();
/*      */ 
/*      */     
/*  796 */     Possible<String> topic = Possible.absent();
/*      */ 
/*      */     
/*  799 */     Possible<Boolean> nsfw = Possible.absent();
/*      */ 
/*      */     
/*  802 */     Possible<Integer> rateLimitPerUser = Possible.absent();
/*      */ 
/*      */     
/*  805 */     Possible<Integer> bitrate = Possible.absent();
/*      */ 
/*      */     
/*  808 */     Possible<Integer> userLimit = Possible.absent();
/*      */ 
/*      */     
/*  811 */     Possible<List<OverwriteData>> permissionOverwrites = Possible.absent();
/*      */ 
/*      */     
/*  814 */     Possible<Optional<String>> parentId = Possible.absent();
/*      */ 
/*      */     
/*  817 */     Possible<Optional<String>> rtcRegion = Possible.absent();
/*      */ 
/*      */     
/*  820 */     Possible<Optional<Integer>> videoQualityMode = Possible.absent();
/*      */     
/*      */     @JsonProperty("name")
/*      */     public void setName(Possible<String> name) {
/*  824 */       this.name = name;
/*      */     }
/*      */     @JsonProperty("position")
/*      */     public void setPosition(Possible<Integer> position) {
/*  828 */       this.position = position;
/*      */     }
/*      */     @JsonProperty("topic")
/*      */     public void setTopic(Possible<String> topic) {
/*  832 */       this.topic = topic;
/*      */     }
/*      */     @JsonProperty("nsfw")
/*      */     public void setNsfw(Possible<Boolean> nsfw) {
/*  836 */       this.nsfw = nsfw;
/*      */     }
/*      */     @JsonProperty("rate_limit_per_user")
/*      */     public void setRateLimitPerUser(Possible<Integer> rateLimitPerUser) {
/*  840 */       this.rateLimitPerUser = rateLimitPerUser;
/*      */     }
/*      */     @JsonProperty("bitrate")
/*      */     public void setBitrate(Possible<Integer> bitrate) {
/*  844 */       this.bitrate = bitrate;
/*      */     }
/*      */     @JsonProperty("user_limit")
/*      */     public void setUserLimit(Possible<Integer> userLimit) {
/*  848 */       this.userLimit = userLimit;
/*      */     }
/*      */     @JsonProperty("permission_overwrites")
/*      */     public void setPermissionOverwrites(Possible<List<OverwriteData>> permissionOverwrites) {
/*  852 */       this.permissionOverwrites = permissionOverwrites;
/*      */     }
/*      */     @JsonProperty("parent_id")
/*      */     public void setParentId(Possible<Optional<String>> parentId) {
/*  856 */       this.parentId = parentId;
/*      */     }
/*      */     @JsonProperty("rtc_region")
/*      */     public void setRtcRegion(Possible<Optional<String>> rtcRegion) {
/*  860 */       this.rtcRegion = rtcRegion;
/*      */     }
/*      */     @JsonProperty("video_quality_mode")
/*      */     public void setVideoQualityMode(Possible<Optional<Integer>> videoQualityMode) {
/*  864 */       this.videoQualityMode = videoQualityMode;
/*      */     }
/*      */     public Possible<String> name() {
/*  867 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Integer> position() {
/*  869 */       throw new UnsupportedOperationException();
/*      */     } public Possible<String> topic() {
/*  871 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Boolean> nsfw() {
/*  873 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Integer> rateLimitPerUser() {
/*  875 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Integer> bitrate() {
/*  877 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Integer> userLimit() {
/*  879 */       throw new UnsupportedOperationException();
/*      */     } public Possible<List<OverwriteData>> permissionOverwrites() {
/*  881 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Optional<String>> parentId() {
/*  883 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Optional<String>> rtcRegion() {
/*  885 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Optional<Integer>> videoQualityMode() {
/*  887 */       throw new UnsupportedOperationException();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*      */   static ImmutableChannelModifyRequest fromJson(Json json) {
/*  898 */     Builder builder = builder();
/*  899 */     if (json.name != null) {
/*  900 */       builder.name(json.name);
/*      */     }
/*  902 */     if (json.position != null) {
/*  903 */       builder.position(json.position);
/*      */     }
/*  905 */     if (json.topic != null) {
/*  906 */       builder.topic(json.topic);
/*      */     }
/*  908 */     if (json.nsfw != null) {
/*  909 */       builder.nsfw(json.nsfw);
/*      */     }
/*  911 */     if (json.rateLimitPerUser != null) {
/*  912 */       builder.rateLimitPerUser(json.rateLimitPerUser);
/*      */     }
/*  914 */     if (json.bitrate != null) {
/*  915 */       builder.bitrate(json.bitrate);
/*      */     }
/*  917 */     if (json.userLimit != null) {
/*  918 */       builder.userLimit(json.userLimit);
/*      */     }
/*  920 */     if (json.permissionOverwrites != null) {
/*  921 */       builder.permissionOverwrites(json.permissionOverwrites);
/*      */     }
/*  923 */     if (json.parentId != null) {
/*  924 */       builder.parentId(json.parentId);
/*      */     }
/*  926 */     if (json.rtcRegion != null) {
/*  927 */       builder.rtcRegion(json.rtcRegion);
/*      */     }
/*  929 */     if (json.videoQualityMode != null) {
/*  930 */       builder.videoQualityMode(json.videoQualityMode);
/*      */     }
/*  932 */     return builder.build();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableChannelModifyRequest of(Possible<String> name, Possible<Integer> position, Possible<String> topic, Possible<Boolean> nsfw, Possible<Integer> rateLimitPerUser, Possible<Integer> bitrate, Possible<Integer> userLimit, Possible<List<OverwriteData>> permissionOverwrites, Possible<Optional<String>> parentId, Possible<Optional<String>> rtcRegion, Possible<Optional<Integer>> videoQualityMode) {
/*  951 */     return new ImmutableChannelModifyRequest(name, position, topic, nsfw, rateLimitPerUser, bitrate, userLimit, permissionOverwrites, parentId, rtcRegion, videoQualityMode);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableChannelModifyRequest copyOf(ChannelModifyRequest instance) {
/*  962 */     if (instance instanceof ImmutableChannelModifyRequest) {
/*  963 */       return (ImmutableChannelModifyRequest)instance;
/*      */     }
/*  965 */     return builder()
/*  966 */       .from(instance)
/*  967 */       .build();
/*      */   }
/*      */   
/*      */   public boolean isNamePresent() {
/*  971 */     return !this.name_absent;
/*      */   }
/*      */   
/*      */   public String nameOrElse(String defaultValue) {
/*  975 */     return !this.name_absent ? this.name_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isPositionPresent() {
/*  979 */     return !this.position_absent;
/*      */   }
/*      */   
/*      */   public Integer positionOrElse(Integer defaultValue) {
/*  983 */     return !this.position_absent ? this.position_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isTopicPresent() {
/*  987 */     return !this.topic_absent;
/*      */   }
/*      */   
/*      */   public String topicOrElse(String defaultValue) {
/*  991 */     return !this.topic_absent ? this.topic_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isNsfwPresent() {
/*  995 */     return !this.nsfw_absent;
/*      */   }
/*      */   
/*      */   public Boolean nsfwOrElse(Boolean defaultValue) {
/*  999 */     return !this.nsfw_absent ? this.nsfw_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isRateLimitPerUserPresent() {
/* 1003 */     return !this.rateLimitPerUser_absent;
/*      */   }
/*      */   
/*      */   public Integer rateLimitPerUserOrElse(Integer defaultValue) {
/* 1007 */     return !this.rateLimitPerUser_absent ? this.rateLimitPerUser_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isBitratePresent() {
/* 1011 */     return !this.bitrate_absent;
/*      */   }
/*      */   
/*      */   public Integer bitrateOrElse(Integer defaultValue) {
/* 1015 */     return !this.bitrate_absent ? this.bitrate_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isUserLimitPresent() {
/* 1019 */     return !this.userLimit_absent;
/*      */   }
/*      */   
/*      */   public Integer userLimitOrElse(Integer defaultValue) {
/* 1023 */     return !this.userLimit_absent ? this.userLimit_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isPermissionOverwritesPresent() {
/* 1027 */     return !this.permissionOverwrites_absent;
/*      */   }
/*      */   
/*      */   public List<OverwriteData> permissionOverwritesOrElse(List<OverwriteData> defaultValue) {
/* 1031 */     return !this.permissionOverwrites_absent ? this.permissionOverwrites_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isParentIdPresent() {
/* 1035 */     return !this.parentId_absent;
/*      */   }
/*      */   
/*      */   public String parentIdOrElse(String defaultValue) {
/* 1039 */     return !this.parentId_absent ? this.parentId_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isRtcRegionPresent() {
/* 1043 */     return !this.rtcRegion_absent;
/*      */   }
/*      */   
/*      */   public String rtcRegionOrElse(String defaultValue) {
/* 1047 */     return !this.rtcRegion_absent ? this.rtcRegion_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isVideoQualityModePresent() {
/* 1051 */     return !this.videoQualityMode_absent;
/*      */   }
/*      */   
/*      */   public Integer videoQualityModeOrElse(Integer defaultValue) {
/* 1055 */     return !this.videoQualityMode_absent ? this.videoQualityMode_value : defaultValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Builder builder() {
/* 1078 */     return new Builder();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Generated(from = "ChannelModifyRequest", generator = "Immutables")
/*      */   public static final class Builder
/*      */   {
/* 1090 */     private Possible<String> name_possible = Possible.absent();
/* 1091 */     private Possible<Integer> position_possible = Possible.absent();
/* 1092 */     private Possible<String> topic_possible = Possible.absent();
/* 1093 */     private Possible<Boolean> nsfw_possible = Possible.absent();
/* 1094 */     private Possible<Integer> rateLimitPerUser_possible = Possible.absent();
/* 1095 */     private Possible<Integer> bitrate_possible = Possible.absent();
/* 1096 */     private Possible<Integer> userLimit_possible = Possible.absent();
/* 1097 */     private List<OverwriteData> permissionOverwrites_list = null;
/* 1098 */     private Possible<Optional<String>> parentId_possible = Possible.absent();
/* 1099 */     private Possible<Optional<String>> rtcRegion_possible = Possible.absent();
/* 1100 */     private Possible<Optional<Integer>> videoQualityMode_possible = Possible.absent();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder from(ChannelModifyRequest instance) {
/* 1113 */       Objects.requireNonNull(instance, "instance");
/* 1114 */       name(instance.name());
/* 1115 */       position(instance.position());
/* 1116 */       topic(instance.topic());
/* 1117 */       nsfw(instance.nsfw());
/* 1118 */       rateLimitPerUser(instance.rateLimitPerUser());
/* 1119 */       bitrate(instance.bitrate());
/* 1120 */       userLimit(instance.userLimit());
/* 1121 */       permissionOverwrites(instance.permissionOverwrites());
/* 1122 */       parentId(instance.parentId());
/* 1123 */       rtcRegion(instance.rtcRegion());
/* 1124 */       videoQualityMode(instance.videoQualityMode());
/* 1125 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("name")
/*      */     public Builder name(Possible<String> value) {
/* 1130 */       this.name_possible = value;
/* 1131 */       return this;
/*      */     }
/*      */     
/*      */     public Builder name(String value) {
/* 1135 */       this.name_possible = Possible.of(value);
/* 1136 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("position")
/*      */     public Builder position(Possible<Integer> value) {
/* 1141 */       this.position_possible = value;
/* 1142 */       return this;
/*      */     }
/*      */     
/*      */     public Builder position(Integer value) {
/* 1146 */       this.position_possible = Possible.of(value);
/* 1147 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("topic")
/*      */     public Builder topic(Possible<String> value) {
/* 1152 */       this.topic_possible = value;
/* 1153 */       return this;
/*      */     }
/*      */     
/*      */     public Builder topic(String value) {
/* 1157 */       this.topic_possible = Possible.of(value);
/* 1158 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("nsfw")
/*      */     public Builder nsfw(Possible<Boolean> value) {
/* 1163 */       this.nsfw_possible = value;
/* 1164 */       return this;
/*      */     }
/*      */     
/*      */     public Builder nsfw(Boolean value) {
/* 1168 */       this.nsfw_possible = Possible.of(value);
/* 1169 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("rate_limit_per_user")
/*      */     public Builder rateLimitPerUser(Possible<Integer> value) {
/* 1174 */       this.rateLimitPerUser_possible = value;
/* 1175 */       return this;
/*      */     }
/*      */     
/*      */     public Builder rateLimitPerUser(Integer value) {
/* 1179 */       this.rateLimitPerUser_possible = Possible.of(value);
/* 1180 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("bitrate")
/*      */     public Builder bitrate(Possible<Integer> value) {
/* 1185 */       this.bitrate_possible = value;
/* 1186 */       return this;
/*      */     }
/*      */     
/*      */     public Builder bitrate(Integer value) {
/* 1190 */       this.bitrate_possible = Possible.of(value);
/* 1191 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("user_limit")
/*      */     public Builder userLimit(Possible<Integer> value) {
/* 1196 */       this.userLimit_possible = value;
/* 1197 */       return this;
/*      */     }
/*      */     
/*      */     public Builder userLimit(Integer value) {
/* 1201 */       this.userLimit_possible = Possible.of(value);
/* 1202 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addPermissionOverwrite(OverwriteData element) {
/* 1206 */       permissionOverwrites_getOrCreate().add(element);
/* 1207 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addAllPermissionOverwrites(List<OverwriteData> elements) {
/* 1211 */       permissionOverwrites_getOrCreate().addAll(elements);
/* 1212 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("permission_overwrites")
/*      */     public Builder permissionOverwrites(Possible<List<OverwriteData>> elements) {
/* 1217 */       this.permissionOverwrites_list = null;
/* 1218 */       elements.toOptional().ifPresent(e -> permissionOverwrites_getOrCreate().addAll(e));
/* 1219 */       return this;
/*      */     }
/*      */     
/*      */     public Builder permissionOverwrites(List<OverwriteData> elements) {
/* 1223 */       this.permissionOverwrites_list = new ArrayList<>(elements);
/* 1224 */       return this;
/*      */     }
/*      */     
/*      */     public Builder permissionOverwrites(Iterable<OverwriteData> elements) {
/* 1228 */       this.permissionOverwrites_list = (List<OverwriteData>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/* 1229 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("parent_id")
/*      */     public Builder parentId(Possible<Optional<String>> value) {
/* 1234 */       this.parentId_possible = value;
/* 1235 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public Builder parentId(@Nullable String value) {
/* 1240 */       this.parentId_possible = Possible.of(Optional.ofNullable(value));
/* 1241 */       return this;
/*      */     }
/*      */     
/*      */     public Builder parentIdOrNull(@Nullable String value) {
/* 1245 */       this.parentId_possible = Possible.of(Optional.ofNullable(value));
/* 1246 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("rtc_region")
/*      */     public Builder rtcRegion(Possible<Optional<String>> value) {
/* 1251 */       this.rtcRegion_possible = value;
/* 1252 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public Builder rtcRegion(@Nullable String value) {
/* 1257 */       this.rtcRegion_possible = Possible.of(Optional.ofNullable(value));
/* 1258 */       return this;
/*      */     }
/*      */     
/*      */     public Builder rtcRegionOrNull(@Nullable String value) {
/* 1262 */       this.rtcRegion_possible = Possible.of(Optional.ofNullable(value));
/* 1263 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("video_quality_mode")
/*      */     public Builder videoQualityMode(Possible<Optional<Integer>> value) {
/* 1268 */       this.videoQualityMode_possible = value;
/* 1269 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public Builder videoQualityMode(@Nullable Integer value) {
/* 1274 */       this.videoQualityMode_possible = Possible.of(Optional.ofNullable(value));
/* 1275 */       return this;
/*      */     }
/*      */     
/*      */     public Builder videoQualityModeOrNull(@Nullable Integer value) {
/* 1279 */       this.videoQualityMode_possible = Possible.of(Optional.ofNullable(value));
/* 1280 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ImmutableChannelModifyRequest build() {
/* 1289 */       return new ImmutableChannelModifyRequest(null, 
/*      */           
/* 1291 */           name_build(), 
/* 1292 */           position_build(), 
/* 1293 */           topic_build(), 
/* 1294 */           nsfw_build(), 
/* 1295 */           rateLimitPerUser_build(), 
/* 1296 */           bitrate_build(), 
/* 1297 */           userLimit_build(), 
/* 1298 */           permissionOverwrites_build(), 
/* 1299 */           parentId_build(), 
/* 1300 */           rtcRegion_build(), 
/* 1301 */           videoQualityMode_build());
/*      */     }
/*      */     
/*      */     private Possible<String> name_build() {
/* 1305 */       return this.name_possible;
/*      */     }
/*      */     
/*      */     private Possible<Integer> position_build() {
/* 1309 */       return this.position_possible;
/*      */     }
/*      */     
/*      */     private Possible<String> topic_build() {
/* 1313 */       return this.topic_possible;
/*      */     }
/*      */     
/*      */     private Possible<Boolean> nsfw_build() {
/* 1317 */       return this.nsfw_possible;
/*      */     }
/*      */     
/*      */     private Possible<Integer> rateLimitPerUser_build() {
/* 1321 */       return this.rateLimitPerUser_possible;
/*      */     }
/*      */     
/*      */     private Possible<Integer> bitrate_build() {
/* 1325 */       return this.bitrate_possible;
/*      */     }
/*      */     
/*      */     private Possible<Integer> userLimit_build() {
/* 1329 */       return this.userLimit_possible;
/*      */     }
/*      */     
/*      */     private Possible<List<OverwriteData>> permissionOverwrites_build() {
/* 1333 */       return (this.permissionOverwrites_list == null) ? Possible.absent() : 
/* 1334 */         Possible.of(this.permissionOverwrites_list);
/*      */     }
/*      */     
/*      */     private List<OverwriteData> permissionOverwrites_getOrCreate() {
/* 1338 */       if (this.permissionOverwrites_list == null) {
/* 1339 */         this.permissionOverwrites_list = new ArrayList<>();
/*      */       }
/* 1341 */       return this.permissionOverwrites_list;
/*      */     }
/*      */     
/*      */     private Possible<Optional<String>> parentId_build() {
/* 1345 */       return this.parentId_possible;
/*      */     }
/*      */     
/*      */     private Possible<Optional<String>> rtcRegion_build() {
/* 1349 */       return this.rtcRegion_possible;
/*      */     }
/*      */     
/*      */     private Possible<Optional<Integer>> videoQualityMode_build() {
/* 1353 */       return this.videoQualityMode_possible;
/*      */     }
/*      */     
/*      */     private Builder() {}
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableChannelModifyRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */