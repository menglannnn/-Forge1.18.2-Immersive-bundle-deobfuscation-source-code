/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "SelectOptionData", generator = "Immutables")
/*     */ public final class ImmutableSelectOptionData
/*     */   implements SelectOptionData
/*     */ {
/*     */   private final String label;
/*     */   private final String value;
/*     */   private final String description_value;
/*     */   private final boolean description_absent;
/*     */   private final EmojiData emoji_value;
/*     */   private final boolean emoji_absent;
/*     */   private final Boolean isDefault_value;
/*     */   private final boolean isDefault_absent;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   private volatile transient InitShim initShim;
/*     */   
/*     */   private ImmutableSelectOptionData(String label, String value, Possible<String> description, Possible<EmojiData> emoji, Possible<Boolean> isDefault) {
/*  78 */     this.initShim = new InitShim(); this.label = Objects.<String>requireNonNull(label, "label"); this.value = Objects.<String>requireNonNull(value, "value"); Possible<String> description$impl = description; Possible<EmojiData> emoji$impl = emoji; Possible<Boolean> isDefault$impl = isDefault; this.description_value = description$impl.toOptional().orElse(null); this.description_absent = description$impl.isAbsent(); this.emoji_value = emoji$impl.toOptional().orElse(null); this.emoji_absent = emoji$impl.isAbsent(); this.isDefault_value = isDefault$impl.toOptional().orElse(null); this.isDefault_absent = isDefault$impl.isAbsent(); this.initShim = null; } private ImmutableSelectOptionData(ImmutableSelectOptionData original, String label, String value, Possible<String> description, Possible<EmojiData> emoji, Possible<Boolean> isDefault) { this.initShim = new InitShim(); this.label = label; this.value = value; Possible<String> description$impl = description; Possible<EmojiData> emoji$impl = emoji; Possible<Boolean> isDefault$impl = isDefault; this.description_value = description$impl.toOptional().orElse(null); this.description_absent = description$impl.isAbsent();
/*     */     this.emoji_value = emoji$impl.toOptional().orElse(null);
/*     */     this.emoji_absent = emoji$impl.isAbsent();
/*     */     this.isDefault_value = isDefault$impl.toOptional().orElse(null);
/*     */     this.isDefault_absent = isDefault$impl.isAbsent();
/*  83 */     this.initShim = null; } @Generated(from = "SelectOptionData", generator = "Immutables") private final class InitShim { private InitShim() {} private String formatInitCycleMessage() { List<String> attributes = new ArrayList<>();
/*  84 */       return "Cannot build SelectOptionData, attribute initializers form cycle " + attributes; }
/*     */      }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("label")
/*     */   public String label() {
/*  94 */     return this.label;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("value")
/*     */   public String value() {
/* 103 */     return this.value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("description")
/*     */   public Possible<String> description() {
/* 112 */     return this.description_absent ? Possible.absent() : Possible.of(this.description_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("emoji")
/*     */   public Possible<EmojiData> emoji() {
/* 121 */     return this.emoji_absent ? Possible.absent() : Possible.of(this.emoji_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("default")
/*     */   public Possible<Boolean> isDefault() {
/* 130 */     return this.isDefault_absent ? Possible.absent() : Possible.of(this.isDefault_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableSelectOptionData withLabel(String value) {
/* 140 */     String newValue = Objects.<String>requireNonNull(value, "label");
/* 141 */     if (this.label.equals(newValue)) return this; 
/* 142 */     return new ImmutableSelectOptionData(this, newValue, this.value, description(), emoji(), isDefault());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableSelectOptionData withValue(String value) {
/* 152 */     String newValue = Objects.<String>requireNonNull(value, "value");
/* 153 */     if (this.value.equals(newValue)) return this; 
/* 154 */     return new ImmutableSelectOptionData(this, this.label, newValue, description(), emoji(), isDefault());
/*     */   }
/*     */   
/*     */   public ImmutableSelectOptionData withDescription(Possible<String> value) {
/* 158 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/* 159 */     return new ImmutableSelectOptionData(this, this.label, this.value, newValue, emoji(), isDefault());
/*     */   }
/*     */   
/*     */   public ImmutableSelectOptionData withDescription(String value) {
/* 163 */     Possible<String> newValue = Possible.of(value);
/* 164 */     return new ImmutableSelectOptionData(this, this.label, this.value, newValue, emoji(), isDefault());
/*     */   }
/*     */   
/*     */   public ImmutableSelectOptionData withEmoji(Possible<EmojiData> value) {
/* 168 */     Possible<EmojiData> newValue = Objects.<Possible<EmojiData>>requireNonNull(value);
/* 169 */     return new ImmutableSelectOptionData(this, this.label, this.value, description(), newValue, isDefault());
/*     */   }
/*     */   
/*     */   public ImmutableSelectOptionData withEmoji(EmojiData value) {
/* 173 */     Possible<EmojiData> newValue = Possible.of(value);
/* 174 */     return new ImmutableSelectOptionData(this, this.label, this.value, description(), newValue, isDefault());
/*     */   }
/*     */   
/*     */   public ImmutableSelectOptionData withIsDefault(Possible<Boolean> value) {
/* 178 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/* 179 */     return new ImmutableSelectOptionData(this, this.label, this.value, description(), emoji(), newValue);
/*     */   }
/*     */   
/*     */   public ImmutableSelectOptionData withIsDefault(Boolean value) {
/* 183 */     Possible<Boolean> newValue = Possible.of(value);
/* 184 */     return new ImmutableSelectOptionData(this, this.label, this.value, description(), emoji(), newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 193 */     if (this == another) return true; 
/* 194 */     return (another instanceof ImmutableSelectOptionData && 
/* 195 */       equalTo(0, (ImmutableSelectOptionData)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableSelectOptionData another) {
/* 199 */     return (this.label.equals(another.label) && this.value
/* 200 */       .equals(another.value) && 
/* 201 */       description().equals(another.description()) && 
/* 202 */       emoji().equals(another.emoji()) && 
/* 203 */       isDefault().equals(another.isDefault()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 212 */     int h = 5381;
/* 213 */     h += (h << 5) + this.label.hashCode();
/* 214 */     h += (h << 5) + this.value.hashCode();
/* 215 */     h += (h << 5) + description().hashCode();
/* 216 */     h += (h << 5) + emoji().hashCode();
/* 217 */     h += (h << 5) + isDefault().hashCode();
/* 218 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 227 */     return "SelectOptionData{label=" + this.label + ", value=" + this.value + ", description=" + 
/*     */ 
/*     */       
/* 230 */       description().toString() + ", emoji=" + 
/* 231 */       emoji().toString() + ", isDefault=" + 
/* 232 */       isDefault().toString() + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "SelectOptionData", generator = "Immutables")
/*     */   static final class Json
/*     */     implements SelectOptionData
/*     */   {
/*     */     String label;
/*     */     
/*     */     String value;
/*     */     
/* 248 */     Possible<String> description = Possible.absent();
/*     */ 
/*     */     
/* 251 */     Possible<EmojiData> emoji = Possible.absent();
/*     */ 
/*     */     
/* 254 */     Possible<Boolean> isDefault = Possible.absent();
/*     */     
/*     */     @JsonProperty("label")
/*     */     public void setLabel(String label) {
/* 258 */       this.label = label;
/*     */     }
/*     */     @JsonProperty("value")
/*     */     public void setValue(String value) {
/* 262 */       this.value = value;
/*     */     }
/*     */     @JsonProperty("description")
/*     */     public void setDescription(Possible<String> description) {
/* 266 */       this.description = description;
/*     */     }
/*     */     @JsonProperty("emoji")
/*     */     public void setEmoji(Possible<EmojiData> emoji) {
/* 270 */       this.emoji = emoji;
/*     */     }
/*     */     @JsonProperty("default")
/*     */     public void setIsDefault(Possible<Boolean> isDefault) {
/* 274 */       this.isDefault = isDefault;
/*     */     }
/*     */     public String label() {
/* 277 */       throw new UnsupportedOperationException();
/*     */     } public String value() {
/* 279 */       throw new UnsupportedOperationException();
/*     */     } public Possible<String> description() {
/* 281 */       throw new UnsupportedOperationException();
/*     */     } public Possible<EmojiData> emoji() {
/* 283 */       throw new UnsupportedOperationException();
/*     */     } public Possible<Boolean> isDefault() {
/* 285 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableSelectOptionData fromJson(Json json) {
/* 296 */     Builder builder = builder();
/* 297 */     if (json.label != null) {
/* 298 */       builder.label(json.label);
/*     */     }
/* 300 */     if (json.value != null) {
/* 301 */       builder.value(json.value);
/*     */     }
/* 303 */     if (json.description != null) {
/* 304 */       builder.description(json.description);
/*     */     }
/* 306 */     if (json.emoji != null) {
/* 307 */       builder.emoji(json.emoji);
/*     */     }
/* 309 */     if (json.isDefault != null) {
/* 310 */       builder.isDefault(json.isDefault);
/*     */     }
/* 312 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableSelectOptionData of(String label, String value, Possible<String> description, Possible<EmojiData> emoji, Possible<Boolean> isDefault) {
/* 325 */     return new ImmutableSelectOptionData(label, value, description, emoji, isDefault);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableSelectOptionData copyOf(SelectOptionData instance) {
/* 336 */     if (instance instanceof ImmutableSelectOptionData) {
/* 337 */       return (ImmutableSelectOptionData)instance;
/*     */     }
/* 339 */     return builder()
/* 340 */       .from(instance)
/* 341 */       .build();
/*     */   }
/*     */   
/*     */   public boolean isDescriptionPresent() {
/* 345 */     return !this.description_absent;
/*     */   }
/*     */   
/*     */   public String descriptionOrElse(String defaultValue) {
/* 349 */     return !this.description_absent ? this.description_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isEmojiPresent() {
/* 353 */     return !this.emoji_absent;
/*     */   }
/*     */   
/*     */   public EmojiData emojiOrElse(EmojiData defaultValue) {
/* 357 */     return !this.emoji_absent ? this.emoji_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isIsDefaultPresent() {
/* 361 */     return !this.isDefault_absent;
/*     */   }
/*     */   
/*     */   public Boolean isDefaultOrElse(Boolean defaultValue) {
/* 365 */     return !this.isDefault_absent ? this.isDefault_value : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 382 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "SelectOptionData", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_LABEL = 1L;
/*     */ 
/*     */     
/*     */     private static final long INIT_BIT_VALUE = 2L;
/*     */ 
/*     */     
/* 396 */     private long initBits = 3L;
/*     */     
/* 398 */     private Possible<String> description_possible = Possible.absent();
/* 399 */     private Possible<EmojiData> emoji_possible = Possible.absent();
/* 400 */     private Possible<Boolean> isDefault_possible = Possible.absent();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private String label;
/*     */ 
/*     */ 
/*     */     
/*     */     private String value;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(SelectOptionData instance) {
/* 415 */       Objects.requireNonNull(instance, "instance");
/* 416 */       label(instance.label());
/* 417 */       value(instance.value());
/* 418 */       description(instance.description());
/* 419 */       emoji(instance.emoji());
/* 420 */       isDefault(instance.isDefault());
/* 421 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("label")
/*     */     public final Builder label(String label) {
/* 431 */       this.label = Objects.<String>requireNonNull(label, "label");
/* 432 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 433 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("value")
/*     */     public final Builder value(String value) {
/* 443 */       this.value = Objects.<String>requireNonNull(value, "value");
/* 444 */       this.initBits &= 0xFFFFFFFFFFFFFFFDL;
/* 445 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("description")
/*     */     public Builder description(Possible<String> value) {
/* 450 */       this.description_possible = value;
/* 451 */       return this;
/*     */     }
/*     */     
/*     */     public Builder description(String value) {
/* 455 */       this.description_possible = Possible.of(value);
/* 456 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("emoji")
/*     */     public Builder emoji(Possible<EmojiData> value) {
/* 461 */       this.emoji_possible = value;
/* 462 */       return this;
/*     */     }
/*     */     
/*     */     public Builder emoji(EmojiData value) {
/* 466 */       this.emoji_possible = Possible.of(value);
/* 467 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("default")
/*     */     public Builder isDefault(Possible<Boolean> value) {
/* 472 */       this.isDefault_possible = value;
/* 473 */       return this;
/*     */     }
/*     */     
/*     */     public Builder isDefault(Boolean value) {
/* 477 */       this.isDefault_possible = Possible.of(value);
/* 478 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableSelectOptionData build() {
/* 487 */       if (this.initBits != 0L) {
/* 488 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 490 */       return new ImmutableSelectOptionData(null, this.label, this.value, description_build(), emoji_build(), isDefault_build());
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 494 */       List<String> attributes = new ArrayList<>();
/* 495 */       if ((this.initBits & 0x1L) != 0L) attributes.add("label"); 
/* 496 */       if ((this.initBits & 0x2L) != 0L) attributes.add("value"); 
/* 497 */       return "Cannot build SelectOptionData, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Possible<String> description_build() {
/* 501 */       return this.description_possible;
/*     */     }
/*     */     
/*     */     private Possible<EmojiData> emoji_build() {
/* 505 */       return this.emoji_possible;
/*     */     }
/*     */     
/*     */     private Possible<Boolean> isDefault_build() {
/* 509 */       return this.isDefault_possible;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableSelectOptionData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */