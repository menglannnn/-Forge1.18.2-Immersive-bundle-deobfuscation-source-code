/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "ClientStatusData", generator = "Immutables")
/*     */ public final class ImmutableClientStatusData
/*     */   implements ClientStatusData
/*     */ {
/*     */   private final String desktop_value;
/*     */   private final boolean desktop_absent;
/*     */   private final String mobile_value;
/*     */   private final boolean mobile_absent;
/*     */   private final String web_value;
/*     */   private final boolean web_absent;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   
/*     */   private ImmutableClientStatusData(Possible<String> desktop, Possible<String> mobile, Possible<String> web) {
/*  36 */     Possible<String> desktop$impl = desktop;
/*  37 */     Possible<String> mobile$impl = mobile;
/*  38 */     Possible<String> web$impl = web;
/*  39 */     this.desktop_value = desktop$impl.toOptional().orElse(null);
/*  40 */     this.desktop_absent = desktop$impl.isAbsent();
/*  41 */     this.mobile_value = mobile$impl.toOptional().orElse(null);
/*  42 */     this.mobile_absent = mobile$impl.isAbsent();
/*  43 */     this.web_value = web$impl.toOptional().orElse(null);
/*  44 */     this.web_absent = web$impl.isAbsent();
/*  45 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ImmutableClientStatusData(ImmutableClientStatusData original, Possible<String> desktop, Possible<String> mobile, Possible<String> web) {
/*  53 */     Possible<String> desktop$impl = desktop;
/*  54 */     Possible<String> mobile$impl = mobile;
/*  55 */     Possible<String> web$impl = web;
/*  56 */     this.desktop_value = desktop$impl.toOptional().orElse(null);
/*  57 */     this.desktop_absent = desktop$impl.isAbsent();
/*  58 */     this.mobile_value = mobile$impl.toOptional().orElse(null);
/*  59 */     this.mobile_absent = mobile$impl.isAbsent();
/*  60 */     this.web_value = web$impl.toOptional().orElse(null);
/*  61 */     this.web_absent = web$impl.isAbsent();
/*  62 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  68 */   private volatile transient InitShim initShim = new InitShim();
/*     */   
/*     */   @Generated(from = "ClientStatusData", generator = "Immutables")
/*     */   private final class InitShim {
/*     */     private String formatInitCycleMessage() {
/*  73 */       List<String> attributes = new ArrayList<>();
/*  74 */       return "Cannot build ClientStatusData, attribute initializers form cycle " + attributes;
/*     */     }
/*     */ 
/*     */     
/*     */     private InitShim() {}
/*     */   }
/*     */ 
/*     */   
/*     */   @JsonProperty("desktop")
/*     */   public Possible<String> desktop() {
/*  84 */     return this.desktop_absent ? Possible.absent() : Possible.of(this.desktop_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("mobile")
/*     */   public Possible<String> mobile() {
/*  93 */     return this.mobile_absent ? Possible.absent() : Possible.of(this.mobile_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("web")
/*     */   public Possible<String> web() {
/* 102 */     return this.web_absent ? Possible.absent() : Possible.of(this.web_value);
/*     */   }
/*     */   
/*     */   public ImmutableClientStatusData withDesktop(Possible<String> value) {
/* 106 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/* 107 */     return new ImmutableClientStatusData(this, newValue, mobile(), web());
/*     */   }
/*     */   
/*     */   public ImmutableClientStatusData withDesktop(String value) {
/* 111 */     Possible<String> newValue = Possible.of(value);
/* 112 */     return new ImmutableClientStatusData(this, newValue, mobile(), web());
/*     */   }
/*     */   
/*     */   public ImmutableClientStatusData withMobile(Possible<String> value) {
/* 116 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/* 117 */     return new ImmutableClientStatusData(this, desktop(), newValue, web());
/*     */   }
/*     */   
/*     */   public ImmutableClientStatusData withMobile(String value) {
/* 121 */     Possible<String> newValue = Possible.of(value);
/* 122 */     return new ImmutableClientStatusData(this, desktop(), newValue, web());
/*     */   }
/*     */   
/*     */   public ImmutableClientStatusData withWeb(Possible<String> value) {
/* 126 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/* 127 */     return new ImmutableClientStatusData(this, desktop(), mobile(), newValue);
/*     */   }
/*     */   
/*     */   public ImmutableClientStatusData withWeb(String value) {
/* 131 */     Possible<String> newValue = Possible.of(value);
/* 132 */     return new ImmutableClientStatusData(this, desktop(), mobile(), newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 141 */     if (this == another) return true; 
/* 142 */     return (another instanceof ImmutableClientStatusData && 
/* 143 */       equalTo(0, (ImmutableClientStatusData)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableClientStatusData another) {
/* 147 */     return (desktop().equals(another.desktop()) && 
/* 148 */       mobile().equals(another.mobile()) && 
/* 149 */       web().equals(another.web()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 158 */     int h = 5381;
/* 159 */     h += (h << 5) + desktop().hashCode();
/* 160 */     h += (h << 5) + mobile().hashCode();
/* 161 */     h += (h << 5) + web().hashCode();
/* 162 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 171 */     return "ClientStatusData{desktop=" + 
/* 172 */       desktop().toString() + ", mobile=" + 
/* 173 */       mobile().toString() + ", web=" + 
/* 174 */       web().toString() + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "ClientStatusData", generator = "Immutables")
/*     */   static final class Json
/*     */     implements ClientStatusData
/*     */   {
/* 188 */     Possible<String> desktop = Possible.absent();
/*     */ 
/*     */     
/* 191 */     Possible<String> mobile = Possible.absent();
/*     */ 
/*     */     
/* 194 */     Possible<String> web = Possible.absent();
/*     */     
/*     */     @JsonProperty("desktop")
/*     */     public void setDesktop(Possible<String> desktop) {
/* 198 */       this.desktop = desktop;
/*     */     }
/*     */     @JsonProperty("mobile")
/*     */     public void setMobile(Possible<String> mobile) {
/* 202 */       this.mobile = mobile;
/*     */     }
/*     */     @JsonProperty("web")
/*     */     public void setWeb(Possible<String> web) {
/* 206 */       this.web = web;
/*     */     }
/*     */     public Possible<String> desktop() {
/* 209 */       throw new UnsupportedOperationException();
/*     */     } public Possible<String> mobile() {
/* 211 */       throw new UnsupportedOperationException();
/*     */     } public Possible<String> web() {
/* 213 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableClientStatusData fromJson(Json json) {
/* 224 */     Builder builder = builder();
/* 225 */     if (json.desktop != null) {
/* 226 */       builder.desktop(json.desktop);
/*     */     }
/* 228 */     if (json.mobile != null) {
/* 229 */       builder.mobile(json.mobile);
/*     */     }
/* 231 */     if (json.web != null) {
/* 232 */       builder.web(json.web);
/*     */     }
/* 234 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableClientStatusData of(Possible<String> desktop, Possible<String> mobile, Possible<String> web) {
/* 245 */     return new ImmutableClientStatusData(desktop, mobile, web);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableClientStatusData copyOf(ClientStatusData instance) {
/* 256 */     if (instance instanceof ImmutableClientStatusData) {
/* 257 */       return (ImmutableClientStatusData)instance;
/*     */     }
/* 259 */     return builder()
/* 260 */       .from(instance)
/* 261 */       .build();
/*     */   }
/*     */   
/*     */   public boolean isDesktopPresent() {
/* 265 */     return !this.desktop_absent;
/*     */   }
/*     */   
/*     */   public String desktopOrElse(String defaultValue) {
/* 269 */     return !this.desktop_absent ? this.desktop_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isMobilePresent() {
/* 273 */     return !this.mobile_absent;
/*     */   }
/*     */   
/*     */   public String mobileOrElse(String defaultValue) {
/* 277 */     return !this.mobile_absent ? this.mobile_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isWebPresent() {
/* 281 */     return !this.web_absent;
/*     */   }
/*     */   
/*     */   public String webOrElse(String defaultValue) {
/* 285 */     return !this.web_absent ? this.web_value : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 300 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "ClientStatusData", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/* 312 */     private Possible<String> desktop_possible = Possible.absent();
/* 313 */     private Possible<String> mobile_possible = Possible.absent();
/* 314 */     private Possible<String> web_possible = Possible.absent();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(ClientStatusData instance) {
/* 327 */       Objects.requireNonNull(instance, "instance");
/* 328 */       desktop(instance.desktop());
/* 329 */       mobile(instance.mobile());
/* 330 */       web(instance.web());
/* 331 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("desktop")
/*     */     public Builder desktop(Possible<String> value) {
/* 336 */       this.desktop_possible = value;
/* 337 */       return this;
/*     */     }
/*     */     
/*     */     public Builder desktop(String value) {
/* 341 */       this.desktop_possible = Possible.of(value);
/* 342 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("mobile")
/*     */     public Builder mobile(Possible<String> value) {
/* 347 */       this.mobile_possible = value;
/* 348 */       return this;
/*     */     }
/*     */     
/*     */     public Builder mobile(String value) {
/* 352 */       this.mobile_possible = Possible.of(value);
/* 353 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("web")
/*     */     public Builder web(Possible<String> value) {
/* 358 */       this.web_possible = value;
/* 359 */       return this;
/*     */     }
/*     */     
/*     */     public Builder web(String value) {
/* 363 */       this.web_possible = Possible.of(value);
/* 364 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableClientStatusData build() {
/* 373 */       return new ImmutableClientStatusData(null, desktop_build(), mobile_build(), web_build());
/*     */     }
/*     */     
/*     */     private Possible<String> desktop_build() {
/* 377 */       return this.desktop_possible;
/*     */     }
/*     */     
/*     */     private Possible<String> mobile_build() {
/* 381 */       return this.mobile_possible;
/*     */     }
/*     */     
/*     */     private Possible<String> web_build() {
/* 385 */       return this.web_possible;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableClientStatusData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */