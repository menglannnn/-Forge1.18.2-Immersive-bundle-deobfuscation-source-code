/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "ActivityTimestampsData", generator = "Immutables")
/*     */ public final class ImmutableActivityTimestampsData
/*     */   implements ActivityTimestampsData
/*     */ {
/*     */   private final Long start_value;
/*     */   private final boolean start_absent;
/*     */   private final Long end_value;
/*     */   private final boolean end_absent;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   
/*     */   private ImmutableActivityTimestampsData(Possible<Long> start, Possible<Long> end) {
/*  34 */     Possible<Long> start$impl = start;
/*  35 */     Possible<Long> end$impl = end;
/*  36 */     this.start_value = start$impl.toOptional().orElse(null);
/*  37 */     this.start_absent = start$impl.isAbsent();
/*  38 */     this.end_value = end$impl.toOptional().orElse(null);
/*  39 */     this.end_absent = end$impl.isAbsent();
/*  40 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ImmutableActivityTimestampsData(ImmutableActivityTimestampsData original, Possible<Long> start, Possible<Long> end) {
/*  47 */     Possible<Long> start$impl = start;
/*  48 */     Possible<Long> end$impl = end;
/*  49 */     this.start_value = start$impl.toOptional().orElse(null);
/*  50 */     this.start_absent = start$impl.isAbsent();
/*  51 */     this.end_value = end$impl.toOptional().orElse(null);
/*  52 */     this.end_absent = end$impl.isAbsent();
/*  53 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  59 */   private volatile transient InitShim initShim = new InitShim();
/*     */   
/*     */   @Generated(from = "ActivityTimestampsData", generator = "Immutables")
/*     */   private final class InitShim {
/*     */     private String formatInitCycleMessage() {
/*  64 */       List<String> attributes = new ArrayList<>();
/*  65 */       return "Cannot build ActivityTimestampsData, attribute initializers form cycle " + attributes;
/*     */     }
/*     */ 
/*     */     
/*     */     private InitShim() {}
/*     */   }
/*     */ 
/*     */   
/*     */   @JsonProperty("start")
/*     */   public Possible<Long> start() {
/*  75 */     return this.start_absent ? Possible.absent() : Possible.of(this.start_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("end")
/*     */   public Possible<Long> end() {
/*  84 */     return this.end_absent ? Possible.absent() : Possible.of(this.end_value);
/*     */   }
/*     */   
/*     */   public ImmutableActivityTimestampsData withStart(Possible<Long> value) {
/*  88 */     Possible<Long> newValue = Objects.<Possible<Long>>requireNonNull(value);
/*  89 */     return new ImmutableActivityTimestampsData(this, newValue, end());
/*     */   }
/*     */   
/*     */   public ImmutableActivityTimestampsData withStart(Long value) {
/*  93 */     Possible<Long> newValue = Possible.of(value);
/*  94 */     return new ImmutableActivityTimestampsData(this, newValue, end());
/*     */   }
/*     */   
/*     */   public ImmutableActivityTimestampsData withEnd(Possible<Long> value) {
/*  98 */     Possible<Long> newValue = Objects.<Possible<Long>>requireNonNull(value);
/*  99 */     return new ImmutableActivityTimestampsData(this, start(), newValue);
/*     */   }
/*     */   
/*     */   public ImmutableActivityTimestampsData withEnd(Long value) {
/* 103 */     Possible<Long> newValue = Possible.of(value);
/* 104 */     return new ImmutableActivityTimestampsData(this, start(), newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 113 */     if (this == another) return true; 
/* 114 */     return (another instanceof ImmutableActivityTimestampsData && 
/* 115 */       equalTo(0, (ImmutableActivityTimestampsData)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableActivityTimestampsData another) {
/* 119 */     return (start().equals(another.start()) && 
/* 120 */       end().equals(another.end()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 129 */     int h = 5381;
/* 130 */     h += (h << 5) + start().hashCode();
/* 131 */     h += (h << 5) + end().hashCode();
/* 132 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 141 */     return "ActivityTimestampsData{start=" + 
/* 142 */       start().toString() + ", end=" + 
/* 143 */       end().toString() + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "ActivityTimestampsData", generator = "Immutables")
/*     */   static final class Json
/*     */     implements ActivityTimestampsData
/*     */   {
/* 157 */     Possible<Long> start = Possible.absent();
/*     */ 
/*     */     
/* 160 */     Possible<Long> end = Possible.absent();
/*     */     
/*     */     @JsonProperty("start")
/*     */     public void setStart(Possible<Long> start) {
/* 164 */       this.start = start;
/*     */     }
/*     */     @JsonProperty("end")
/*     */     public void setEnd(Possible<Long> end) {
/* 168 */       this.end = end;
/*     */     }
/*     */     public Possible<Long> start() {
/* 171 */       throw new UnsupportedOperationException();
/*     */     } public Possible<Long> end() {
/* 173 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableActivityTimestampsData fromJson(Json json) {
/* 184 */     Builder builder = builder();
/* 185 */     if (json.start != null) {
/* 186 */       builder.start(json.start);
/*     */     }
/* 188 */     if (json.end != null) {
/* 189 */       builder.end(json.end);
/*     */     }
/* 191 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableActivityTimestampsData of(Possible<Long> start, Possible<Long> end) {
/* 201 */     return new ImmutableActivityTimestampsData(start, end);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableActivityTimestampsData copyOf(ActivityTimestampsData instance) {
/* 212 */     if (instance instanceof ImmutableActivityTimestampsData) {
/* 213 */       return (ImmutableActivityTimestampsData)instance;
/*     */     }
/* 215 */     return builder()
/* 216 */       .from(instance)
/* 217 */       .build();
/*     */   }
/*     */   
/*     */   public boolean isStartPresent() {
/* 221 */     return !this.start_absent;
/*     */   }
/*     */   
/*     */   public Long startOrElse(Long defaultValue) {
/* 225 */     return !this.start_absent ? this.start_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isEndPresent() {
/* 229 */     return !this.end_absent;
/*     */   }
/*     */   
/*     */   public Long endOrElse(Long defaultValue) {
/* 233 */     return !this.end_absent ? this.end_value : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 247 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "ActivityTimestampsData", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/* 259 */     private Possible<Long> start_possible = Possible.absent();
/* 260 */     private Possible<Long> end_possible = Possible.absent();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(ActivityTimestampsData instance) {
/* 273 */       Objects.requireNonNull(instance, "instance");
/* 274 */       start(instance.start());
/* 275 */       end(instance.end());
/* 276 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("start")
/*     */     public Builder start(Possible<Long> value) {
/* 281 */       this.start_possible = value;
/* 282 */       return this;
/*     */     }
/*     */     
/*     */     public Builder start(Long value) {
/* 286 */       this.start_possible = Possible.of(value);
/* 287 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("end")
/*     */     public Builder end(Possible<Long> value) {
/* 292 */       this.end_possible = value;
/* 293 */       return this;
/*     */     }
/*     */     
/*     */     public Builder end(Long value) {
/* 297 */       this.end_possible = Possible.of(value);
/* 298 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableActivityTimestampsData build() {
/* 307 */       return new ImmutableActivityTimestampsData(null, start_build(), end_build());
/*     */     }
/*     */     
/*     */     private Possible<Long> start_build() {
/* 311 */       return this.start_possible;
/*     */     }
/*     */     
/*     */     private Possible<Long> end_build() {
/* 315 */       return this.end_possible;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableActivityTimestampsData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */