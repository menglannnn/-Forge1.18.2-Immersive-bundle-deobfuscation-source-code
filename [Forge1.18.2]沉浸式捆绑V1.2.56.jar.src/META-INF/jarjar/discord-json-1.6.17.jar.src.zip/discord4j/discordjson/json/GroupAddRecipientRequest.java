/*    */ package discord4j.discordjson.json;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonProperty;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ @JsonSerialize(as = ImmutableGroupAddRecipientRequest.class)
/*    */ @JsonDeserialize(as = ImmutableGroupAddRecipientRequest.class)
/*    */ @Immutable
/*    */ public interface GroupAddRecipientRequest
/*    */ {
/*    */   static ImmutableGroupAddRecipientRequest.Builder builder() {
/* 14 */     return ImmutableGroupAddRecipientRequest.builder();
/*    */   }
/*    */   
/*    */   @JsonProperty("access_token")
/*    */   String accessToken();
/*    */   
/*    */   String nick();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\GroupAddRecipientRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */