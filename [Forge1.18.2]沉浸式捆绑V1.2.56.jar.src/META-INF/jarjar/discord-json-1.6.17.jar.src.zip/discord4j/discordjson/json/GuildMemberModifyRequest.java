/*    */ package discord4j.discordjson.json;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonProperty;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import java.util.List;
/*    */ import java.util.Optional;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ 
/*    */ @JsonSerialize(as = ImmutableGuildMemberModifyRequest.class)
/*    */ @JsonDeserialize(as = ImmutableGuildMemberModifyRequest.class)
/*    */ @Immutable
/*    */ public interface GuildMemberModifyRequest
/*    */ {
/*    */   static ImmutableGuildMemberModifyRequest.Builder builder() {
/* 18 */     return ImmutableGuildMemberModifyRequest.builder();
/*    */   }
/*    */   
/*    */   Possible<Optional<String>> nick();
/*    */   
/*    */   Possible<List<String>> roles();
/*    */   
/*    */   Possible<Boolean> mute();
/*    */   
/*    */   Possible<Boolean> deaf();
/*    */   
/*    */   @JsonProperty("channel_id")
/*    */   Possible<Optional<String>> channelId();
/*    */   
/*    */   @JsonProperty("communication_disabled_until")
/*    */   Possible<Optional<String>> communicationDisabledUntil();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\GuildMemberModifyRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */