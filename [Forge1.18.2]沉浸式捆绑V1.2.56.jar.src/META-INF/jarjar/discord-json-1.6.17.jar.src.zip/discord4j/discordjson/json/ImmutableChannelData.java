/*      */ package discord4j.discordjson.json;
/*      */ 
/*      */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*      */ import com.fasterxml.jackson.annotation.JsonCreator;
/*      */ import com.fasterxml.jackson.annotation.JsonProperty;
/*      */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*      */ import discord4j.discordjson.Id;
/*      */ import discord4j.discordjson.possible.Possible;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.List;
/*      */ import java.util.Objects;
/*      */ import java.util.Optional;
/*      */ import java.util.stream.Collectors;
/*      */ import java.util.stream.StreamSupport;
/*      */ import org.immutables.value.Generated;
/*      */ import reactor.util.annotation.Nullable;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ @Generated(from = "ChannelData", generator = "Immutables")
/*      */ public final class ImmutableChannelData
/*      */   implements ChannelData
/*      */ {
/*      */   private final long id_value;
/*      */   private final int type;
/*      */   private final long guildId_value;
/*      */   private final boolean guildId_absent;
/*      */   private final Integer position_value;
/*      */   private final boolean position_absent;
/*      */   private final List<OverwriteData> permissionOverwrites_value;
/*      */   private final boolean permissionOverwrites_absent;
/*      */   private final String name_value;
/*      */   private final boolean name_absent;
/*      */   private final String topic_value;
/*      */   private final boolean topic_absent;
/*      */   private final Boolean nsfw_value;
/*      */   private final boolean nsfw_absent;
/*      */   private final long lastMessageId_value;
/*      */   private final boolean lastMessageId_absent;
/*      */   private final boolean lastMessageId_isNull;
/*      */   private final Integer bitrate_value;
/*      */   private final boolean bitrate_absent;
/*      */   private final Integer userLimit_value;
/*      */   private final boolean userLimit_absent;
/*      */   private final Integer rateLimitPerUser_value;
/*      */   private final boolean rateLimitPerUser_absent;
/*      */   private final List<UserData> recipients_value;
/*      */   private final boolean recipients_absent;
/*      */   private final String icon_value;
/*      */   private final boolean icon_absent;
/*      */   private final long ownerId_value;
/*      */   private final boolean ownerId_absent;
/*      */   private final long applicationId_value;
/*      */   private final boolean applicationId_absent;
/*      */   private final long parentId_value;
/*      */   private final boolean parentId_absent;
/*      */   private final boolean parentId_isNull;
/*      */   private final String lastPinTimestamp_value;
/*      */   private final boolean lastPinTimestamp_absent;
/*      */   private final String rtcRegion_value;
/*      */   private final boolean rtcRegion_absent;
/*      */   private final Integer videoQualityMode_value;
/*      */   private final boolean videoQualityMode_absent;
/*      */   private static final byte STAGE_INITIALIZING = -1;
/*      */   private static final byte STAGE_UNINITIALIZED = 0;
/*      */   private static final byte STAGE_INITIALIZED = 1;
/*      */   
/*      */   private ImmutableChannelData(Id id, int type, Possible<Id> guildId, Possible<Integer> position, Possible<List<OverwriteData>> permissionOverwrites, Possible<String> name, Possible<Optional<String>> topic, Possible<Boolean> nsfw, Possible<Optional<Id>> lastMessageId, Possible<Integer> bitrate, Possible<Integer> userLimit, Possible<Integer> rateLimitPerUser, Possible<List<UserData>> recipients, Possible<Optional<String>> icon, Possible<Id> ownerId, Possible<Id> applicationId, Possible<Optional<Id>> parentId, Possible<Optional<String>> lastPinTimestamp, Possible<Optional<String>> rtcRegion, Possible<Integer> videoQualityMode) {
/*   93 */     Id id$impl = id;
/*   94 */     this.type = type;
/*   95 */     Possible<Id> guildId$impl = guildId;
/*   96 */     Possible<Integer> position$impl = position;
/*   97 */     Possible<List<OverwriteData>> permissionOverwrites$impl = permissionOverwrites;
/*   98 */     Possible<String> name$impl = name;
/*   99 */     Possible<Optional<String>> topic$impl = topic;
/*  100 */     Possible<Boolean> nsfw$impl = nsfw;
/*  101 */     Possible<Optional<Id>> lastMessageId$impl = lastMessageId;
/*  102 */     Possible<Integer> bitrate$impl = bitrate;
/*  103 */     Possible<Integer> userLimit$impl = userLimit;
/*  104 */     Possible<Integer> rateLimitPerUser$impl = rateLimitPerUser;
/*  105 */     Possible<List<UserData>> recipients$impl = recipients;
/*  106 */     Possible<Optional<String>> icon$impl = icon;
/*  107 */     Possible<Id> ownerId$impl = ownerId;
/*  108 */     Possible<Id> applicationId$impl = applicationId;
/*  109 */     Possible<Optional<Id>> parentId$impl = parentId;
/*  110 */     Possible<Optional<String>> lastPinTimestamp$impl = lastPinTimestamp;
/*  111 */     Possible<Optional<String>> rtcRegion$impl = rtcRegion;
/*  112 */     Possible<Integer> videoQualityMode$impl = videoQualityMode;
/*  113 */     this.id_value = id$impl.asLong();
/*  114 */     this
/*      */       
/*  116 */       .guildId_value = ((Long)guildId$impl.toOptional().map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  117 */     this.guildId_absent = guildId$impl.isAbsent();
/*  118 */     this.position_value = position$impl.toOptional().orElse(null);
/*  119 */     this.position_absent = position$impl.isAbsent();
/*  120 */     this.permissionOverwrites_value = permissionOverwrites$impl.toOptional().orElse(null);
/*  121 */     this.permissionOverwrites_absent = permissionOverwrites$impl.isAbsent();
/*  122 */     this.name_value = name$impl.toOptional().orElse(null);
/*  123 */     this.name_absent = name$impl.isAbsent();
/*  124 */     this.topic_value = Possible.flatOpt(topic$impl).orElse(null);
/*  125 */     this.topic_absent = topic$impl.isAbsent();
/*  126 */     this.nsfw_value = nsfw$impl.toOptional().orElse(null);
/*  127 */     this.nsfw_absent = nsfw$impl.isAbsent();
/*  128 */     this
/*      */       
/*  130 */       .lastMessageId_value = ((Long)Possible.flatOpt(lastMessageId$impl).map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  131 */     this.lastMessageId_absent = lastMessageId$impl.isAbsent();
/*  132 */     this.lastMessageId_isNull = (!lastMessageId$impl.isAbsent() && !((Optional)lastMessageId$impl.get()).isPresent());
/*  133 */     this.bitrate_value = bitrate$impl.toOptional().orElse(null);
/*  134 */     this.bitrate_absent = bitrate$impl.isAbsent();
/*  135 */     this.userLimit_value = userLimit$impl.toOptional().orElse(null);
/*  136 */     this.userLimit_absent = userLimit$impl.isAbsent();
/*  137 */     this.rateLimitPerUser_value = rateLimitPerUser$impl.toOptional().orElse(null);
/*  138 */     this.rateLimitPerUser_absent = rateLimitPerUser$impl.isAbsent();
/*  139 */     this.recipients_value = recipients$impl.toOptional().orElse(null);
/*  140 */     this.recipients_absent = recipients$impl.isAbsent();
/*  141 */     this.icon_value = Possible.flatOpt(icon$impl).orElse(null);
/*  142 */     this.icon_absent = icon$impl.isAbsent();
/*  143 */     this
/*      */       
/*  145 */       .ownerId_value = ((Long)ownerId$impl.toOptional().map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  146 */     this.ownerId_absent = ownerId$impl.isAbsent();
/*  147 */     this
/*      */       
/*  149 */       .applicationId_value = ((Long)applicationId$impl.toOptional().map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  150 */     this.applicationId_absent = applicationId$impl.isAbsent();
/*  151 */     this
/*      */       
/*  153 */       .parentId_value = ((Long)Possible.flatOpt(parentId$impl).map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  154 */     this.parentId_absent = parentId$impl.isAbsent();
/*  155 */     this.parentId_isNull = (!parentId$impl.isAbsent() && !((Optional)parentId$impl.get()).isPresent());
/*  156 */     this.lastPinTimestamp_value = Possible.flatOpt(lastPinTimestamp$impl).orElse(null);
/*  157 */     this.lastPinTimestamp_absent = lastPinTimestamp$impl.isAbsent();
/*  158 */     this.rtcRegion_value = Possible.flatOpt(rtcRegion$impl).orElse(null);
/*  159 */     this.rtcRegion_absent = rtcRegion$impl.isAbsent();
/*  160 */     this.videoQualityMode_value = videoQualityMode$impl.toOptional().orElse(null);
/*  161 */     this.videoQualityMode_absent = videoQualityMode$impl.isAbsent();
/*  162 */     this.initShim = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ImmutableChannelData(ImmutableChannelData original, Id id, int type, Possible<Id> guildId, Possible<Integer> position, Possible<List<OverwriteData>> permissionOverwrites, Possible<String> name, Possible<Optional<String>> topic, Possible<Boolean> nsfw, Possible<Optional<Id>> lastMessageId, Possible<Integer> bitrate, Possible<Integer> userLimit, Possible<Integer> rateLimitPerUser, Possible<List<UserData>> recipients, Possible<Optional<String>> icon, Possible<Id> ownerId, Possible<Id> applicationId, Possible<Optional<Id>> parentId, Possible<Optional<String>> lastPinTimestamp, Possible<Optional<String>> rtcRegion, Possible<Integer> videoQualityMode) {
/*  187 */     Id id$impl = id;
/*  188 */     this.type = type;
/*  189 */     Possible<Id> guildId$impl = guildId;
/*  190 */     Possible<Integer> position$impl = position;
/*  191 */     Possible<List<OverwriteData>> permissionOverwrites$impl = permissionOverwrites;
/*  192 */     Possible<String> name$impl = name;
/*  193 */     Possible<Optional<String>> topic$impl = topic;
/*  194 */     Possible<Boolean> nsfw$impl = nsfw;
/*  195 */     Possible<Optional<Id>> lastMessageId$impl = lastMessageId;
/*  196 */     Possible<Integer> bitrate$impl = bitrate;
/*  197 */     Possible<Integer> userLimit$impl = userLimit;
/*  198 */     Possible<Integer> rateLimitPerUser$impl = rateLimitPerUser;
/*  199 */     Possible<List<UserData>> recipients$impl = recipients;
/*  200 */     Possible<Optional<String>> icon$impl = icon;
/*  201 */     Possible<Id> ownerId$impl = ownerId;
/*  202 */     Possible<Id> applicationId$impl = applicationId;
/*  203 */     Possible<Optional<Id>> parentId$impl = parentId;
/*  204 */     Possible<Optional<String>> lastPinTimestamp$impl = lastPinTimestamp;
/*  205 */     Possible<Optional<String>> rtcRegion$impl = rtcRegion;
/*  206 */     Possible<Integer> videoQualityMode$impl = videoQualityMode;
/*  207 */     this.id_value = id$impl.asLong();
/*  208 */     this
/*      */       
/*  210 */       .guildId_value = ((Long)guildId$impl.toOptional().map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  211 */     this.guildId_absent = guildId$impl.isAbsent();
/*  212 */     this.position_value = position$impl.toOptional().orElse(null);
/*  213 */     this.position_absent = position$impl.isAbsent();
/*  214 */     this.permissionOverwrites_value = permissionOverwrites$impl.toOptional().orElse(null);
/*  215 */     this.permissionOverwrites_absent = permissionOverwrites$impl.isAbsent();
/*  216 */     this.name_value = name$impl.toOptional().orElse(null);
/*  217 */     this.name_absent = name$impl.isAbsent();
/*  218 */     this.topic_value = Possible.flatOpt(topic$impl).orElse(null);
/*  219 */     this.topic_absent = topic$impl.isAbsent();
/*  220 */     this.nsfw_value = nsfw$impl.toOptional().orElse(null);
/*  221 */     this.nsfw_absent = nsfw$impl.isAbsent();
/*  222 */     this
/*      */       
/*  224 */       .lastMessageId_value = ((Long)Possible.flatOpt(lastMessageId$impl).map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  225 */     this.lastMessageId_absent = lastMessageId$impl.isAbsent();
/*  226 */     this.lastMessageId_isNull = (!lastMessageId$impl.isAbsent() && !((Optional)lastMessageId$impl.get()).isPresent());
/*  227 */     this.bitrate_value = bitrate$impl.toOptional().orElse(null);
/*  228 */     this.bitrate_absent = bitrate$impl.isAbsent();
/*  229 */     this.userLimit_value = userLimit$impl.toOptional().orElse(null);
/*  230 */     this.userLimit_absent = userLimit$impl.isAbsent();
/*  231 */     this.rateLimitPerUser_value = rateLimitPerUser$impl.toOptional().orElse(null);
/*  232 */     this.rateLimitPerUser_absent = rateLimitPerUser$impl.isAbsent();
/*  233 */     this.recipients_value = recipients$impl.toOptional().orElse(null);
/*  234 */     this.recipients_absent = recipients$impl.isAbsent();
/*  235 */     this.icon_value = Possible.flatOpt(icon$impl).orElse(null);
/*  236 */     this.icon_absent = icon$impl.isAbsent();
/*  237 */     this
/*      */       
/*  239 */       .ownerId_value = ((Long)ownerId$impl.toOptional().map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  240 */     this.ownerId_absent = ownerId$impl.isAbsent();
/*  241 */     this
/*      */       
/*  243 */       .applicationId_value = ((Long)applicationId$impl.toOptional().map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  244 */     this.applicationId_absent = applicationId$impl.isAbsent();
/*  245 */     this
/*      */       
/*  247 */       .parentId_value = ((Long)Possible.flatOpt(parentId$impl).map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  248 */     this.parentId_absent = parentId$impl.isAbsent();
/*  249 */     this.parentId_isNull = (!parentId$impl.isAbsent() && !((Optional)parentId$impl.get()).isPresent());
/*  250 */     this.lastPinTimestamp_value = Possible.flatOpt(lastPinTimestamp$impl).orElse(null);
/*  251 */     this.lastPinTimestamp_absent = lastPinTimestamp$impl.isAbsent();
/*  252 */     this.rtcRegion_value = Possible.flatOpt(rtcRegion$impl).orElse(null);
/*  253 */     this.rtcRegion_absent = rtcRegion$impl.isAbsent();
/*  254 */     this.videoQualityMode_value = videoQualityMode$impl.toOptional().orElse(null);
/*  255 */     this.videoQualityMode_absent = videoQualityMode$impl.isAbsent();
/*  256 */     this.initShim = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  262 */   private volatile transient InitShim initShim = new InitShim();
/*      */   
/*      */   @Generated(from = "ChannelData", generator = "Immutables")
/*      */   private final class InitShim {
/*      */     private String formatInitCycleMessage() {
/*  267 */       List<String> attributes = new ArrayList<>();
/*  268 */       return "Cannot build ChannelData, attribute initializers form cycle " + attributes;
/*      */     }
/*      */ 
/*      */     
/*      */     private InitShim() {}
/*      */   }
/*      */ 
/*      */   
/*      */   @JsonProperty("id")
/*      */   public Id id() {
/*  278 */     return Id.of(this.id_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("type")
/*      */   public int type() {
/*  287 */     return this.type;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("guild_id")
/*      */   public Possible<Id> guildId() {
/*  296 */     return this.guildId_absent ? Possible.absent() : 
/*  297 */       Possible.of(Id.of(this.guildId_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("position")
/*      */   public Possible<Integer> position() {
/*  306 */     return this.position_absent ? Possible.absent() : Possible.of(this.position_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("permission_overwrites")
/*      */   public Possible<List<OverwriteData>> permissionOverwrites() {
/*  315 */     return this.permissionOverwrites_absent ? Possible.absent() : 
/*  316 */       Possible.of(this.permissionOverwrites_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("name")
/*      */   public Possible<String> name() {
/*  325 */     return this.name_absent ? Possible.absent() : Possible.of(this.name_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("topic")
/*      */   public Possible<Optional<String>> topic() {
/*  334 */     return this.topic_absent ? Possible.absent() : 
/*  335 */       Possible.of(Optional.ofNullable(this.topic_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("nsfw")
/*      */   public Possible<Boolean> nsfw() {
/*  344 */     return this.nsfw_absent ? Possible.absent() : Possible.of(this.nsfw_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("last_message_id")
/*      */   public Possible<Optional<Id>> lastMessageId() {
/*  353 */     if (this.lastMessageId_absent)
/*  354 */       return Possible.absent(); 
/*  355 */     if (this.lastMessageId_isNull) {
/*  356 */       return Possible.of(Optional.empty());
/*      */     }
/*  358 */     return Possible.of(Optional.of(Id.of(this.lastMessageId_value)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("bitrate")
/*      */   public Possible<Integer> bitrate() {
/*  368 */     return this.bitrate_absent ? Possible.absent() : Possible.of(this.bitrate_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("user_limit")
/*      */   public Possible<Integer> userLimit() {
/*  377 */     return this.userLimit_absent ? Possible.absent() : Possible.of(this.userLimit_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("rate_limit_per_user")
/*      */   public Possible<Integer> rateLimitPerUser() {
/*  386 */     return this.rateLimitPerUser_absent ? Possible.absent() : Possible.of(this.rateLimitPerUser_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("recipients")
/*      */   public Possible<List<UserData>> recipients() {
/*  395 */     return this.recipients_absent ? Possible.absent() : 
/*  396 */       Possible.of(this.recipients_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("icon")
/*      */   public Possible<Optional<String>> icon() {
/*  405 */     return this.icon_absent ? Possible.absent() : 
/*  406 */       Possible.of(Optional.ofNullable(this.icon_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("owner_id")
/*      */   public Possible<Id> ownerId() {
/*  415 */     return this.ownerId_absent ? Possible.absent() : 
/*  416 */       Possible.of(Id.of(this.ownerId_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("application_id")
/*      */   public Possible<Id> applicationId() {
/*  425 */     return this.applicationId_absent ? Possible.absent() : 
/*  426 */       Possible.of(Id.of(this.applicationId_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("parent_id")
/*      */   public Possible<Optional<Id>> parentId() {
/*  435 */     if (this.parentId_absent)
/*  436 */       return Possible.absent(); 
/*  437 */     if (this.parentId_isNull) {
/*  438 */       return Possible.of(Optional.empty());
/*      */     }
/*  440 */     return Possible.of(Optional.of(Id.of(this.parentId_value)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("last_pin_timestamp")
/*      */   public Possible<Optional<String>> lastPinTimestamp() {
/*  450 */     return this.lastPinTimestamp_absent ? Possible.absent() : 
/*  451 */       Possible.of(Optional.ofNullable(this.lastPinTimestamp_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("rtc_region")
/*      */   public Possible<Optional<String>> rtcRegion() {
/*  460 */     return this.rtcRegion_absent ? Possible.absent() : 
/*  461 */       Possible.of(Optional.ofNullable(this.rtcRegion_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("video_quality_mode")
/*      */   public Possible<Integer> videoQualityMode() {
/*  470 */     return this.videoQualityMode_absent ? Possible.absent() : Possible.of(this.videoQualityMode_value);
/*      */   }
/*      */   
/*      */   public ImmutableChannelData withId(long value) {
/*  474 */     Id newValue = Id.of(value);
/*  475 */     return new ImmutableChannelData(this, newValue, this.type, 
/*      */ 
/*      */ 
/*      */         
/*  479 */         guildId(), 
/*  480 */         position(), 
/*  481 */         permissionOverwrites(), 
/*  482 */         name(), 
/*  483 */         topic(), 
/*  484 */         nsfw(), 
/*  485 */         lastMessageId(), 
/*  486 */         bitrate(), 
/*  487 */         userLimit(), 
/*  488 */         rateLimitPerUser(), 
/*  489 */         recipients(), 
/*  490 */         icon(), 
/*  491 */         ownerId(), 
/*  492 */         applicationId(), 
/*  493 */         parentId(), 
/*  494 */         lastPinTimestamp(), 
/*  495 */         rtcRegion(), 
/*  496 */         videoQualityMode());
/*      */   }
/*      */   
/*      */   public ImmutableChannelData withId(String value) {
/*  500 */     Id newValue = Id.of(value);
/*  501 */     return new ImmutableChannelData(this, newValue, this.type, 
/*      */ 
/*      */ 
/*      */         
/*  505 */         guildId(), 
/*  506 */         position(), 
/*  507 */         permissionOverwrites(), 
/*  508 */         name(), 
/*  509 */         topic(), 
/*  510 */         nsfw(), 
/*  511 */         lastMessageId(), 
/*  512 */         bitrate(), 
/*  513 */         userLimit(), 
/*  514 */         rateLimitPerUser(), 
/*  515 */         recipients(), 
/*  516 */         icon(), 
/*  517 */         ownerId(), 
/*  518 */         applicationId(), 
/*  519 */         parentId(), 
/*  520 */         lastPinTimestamp(), 
/*  521 */         rtcRegion(), 
/*  522 */         videoQualityMode());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableChannelData withType(int value) {
/*  532 */     if (this.type == value) return this; 
/*  533 */     return new ImmutableChannelData(this, 
/*      */         
/*  535 */         id(), value, 
/*      */         
/*  537 */         guildId(), 
/*  538 */         position(), 
/*  539 */         permissionOverwrites(), 
/*  540 */         name(), 
/*  541 */         topic(), 
/*  542 */         nsfw(), 
/*  543 */         lastMessageId(), 
/*  544 */         bitrate(), 
/*  545 */         userLimit(), 
/*  546 */         rateLimitPerUser(), 
/*  547 */         recipients(), 
/*  548 */         icon(), 
/*  549 */         ownerId(), 
/*  550 */         applicationId(), 
/*  551 */         parentId(), 
/*  552 */         lastPinTimestamp(), 
/*  553 */         rtcRegion(), 
/*  554 */         videoQualityMode());
/*      */   }
/*      */   
/*      */   public ImmutableChannelData withGuildId(Possible<Id> value) {
/*  558 */     Possible<Id> newValue = Objects.<Possible<Id>>requireNonNull(value);
/*  559 */     return new ImmutableChannelData(this, 
/*      */         
/*  561 */         id(), this.type, newValue, 
/*      */ 
/*      */         
/*  564 */         position(), 
/*  565 */         permissionOverwrites(), 
/*  566 */         name(), 
/*  567 */         topic(), 
/*  568 */         nsfw(), 
/*  569 */         lastMessageId(), 
/*  570 */         bitrate(), 
/*  571 */         userLimit(), 
/*  572 */         rateLimitPerUser(), 
/*  573 */         recipients(), 
/*  574 */         icon(), 
/*  575 */         ownerId(), 
/*  576 */         applicationId(), 
/*  577 */         parentId(), 
/*  578 */         lastPinTimestamp(), 
/*  579 */         rtcRegion(), 
/*  580 */         videoQualityMode());
/*      */   }
/*      */   
/*      */   public ImmutableChannelData withGuildId(long value) {
/*  584 */     Possible<Id> newValue = Possible.of(Id.of(value));
/*  585 */     return new ImmutableChannelData(this, 
/*      */         
/*  587 */         id(), this.type, newValue, 
/*      */ 
/*      */         
/*  590 */         position(), 
/*  591 */         permissionOverwrites(), 
/*  592 */         name(), 
/*  593 */         topic(), 
/*  594 */         nsfw(), 
/*  595 */         lastMessageId(), 
/*  596 */         bitrate(), 
/*  597 */         userLimit(), 
/*  598 */         rateLimitPerUser(), 
/*  599 */         recipients(), 
/*  600 */         icon(), 
/*  601 */         ownerId(), 
/*  602 */         applicationId(), 
/*  603 */         parentId(), 
/*  604 */         lastPinTimestamp(), 
/*  605 */         rtcRegion(), 
/*  606 */         videoQualityMode());
/*      */   }
/*      */   
/*      */   public ImmutableChannelData withPosition(Possible<Integer> value) {
/*  610 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/*  611 */     return new ImmutableChannelData(this, 
/*      */         
/*  613 */         id(), this.type, 
/*      */         
/*  615 */         guildId(), newValue, 
/*      */         
/*  617 */         permissionOverwrites(), 
/*  618 */         name(), 
/*  619 */         topic(), 
/*  620 */         nsfw(), 
/*  621 */         lastMessageId(), 
/*  622 */         bitrate(), 
/*  623 */         userLimit(), 
/*  624 */         rateLimitPerUser(), 
/*  625 */         recipients(), 
/*  626 */         icon(), 
/*  627 */         ownerId(), 
/*  628 */         applicationId(), 
/*  629 */         parentId(), 
/*  630 */         lastPinTimestamp(), 
/*  631 */         rtcRegion(), 
/*  632 */         videoQualityMode());
/*      */   }
/*      */   
/*      */   public ImmutableChannelData withPosition(Integer value) {
/*  636 */     Possible<Integer> newValue = Possible.of(value);
/*  637 */     return new ImmutableChannelData(this, 
/*      */         
/*  639 */         id(), this.type, 
/*      */         
/*  641 */         guildId(), newValue, 
/*      */         
/*  643 */         permissionOverwrites(), 
/*  644 */         name(), 
/*  645 */         topic(), 
/*  646 */         nsfw(), 
/*  647 */         lastMessageId(), 
/*  648 */         bitrate(), 
/*  649 */         userLimit(), 
/*  650 */         rateLimitPerUser(), 
/*  651 */         recipients(), 
/*  652 */         icon(), 
/*  653 */         ownerId(), 
/*  654 */         applicationId(), 
/*  655 */         parentId(), 
/*  656 */         lastPinTimestamp(), 
/*  657 */         rtcRegion(), 
/*  658 */         videoQualityMode());
/*      */   }
/*      */   
/*      */   public ImmutableChannelData withPermissionOverwrites(Possible<List<OverwriteData>> possible) {
/*  662 */     Possible<List<OverwriteData>> newValue = Objects.<Possible<List<OverwriteData>>>requireNonNull(possible);
/*  663 */     return new ImmutableChannelData(this, 
/*      */         
/*  665 */         id(), this.type, 
/*      */         
/*  667 */         guildId(), 
/*  668 */         position(), newValue, 
/*      */         
/*  670 */         name(), 
/*  671 */         topic(), 
/*  672 */         nsfw(), 
/*  673 */         lastMessageId(), 
/*  674 */         bitrate(), 
/*  675 */         userLimit(), 
/*  676 */         rateLimitPerUser(), 
/*  677 */         recipients(), 
/*  678 */         icon(), 
/*  679 */         ownerId(), 
/*  680 */         applicationId(), 
/*  681 */         parentId(), 
/*  682 */         lastPinTimestamp(), 
/*  683 */         rtcRegion(), 
/*  684 */         videoQualityMode());
/*      */   }
/*      */   
/*      */   public ImmutableChannelData withPermissionOverwrites(Iterable<OverwriteData> elements) {
/*  688 */     Possible<List<OverwriteData>> newValue = Possible.of(
/*  689 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/*  690 */     return new ImmutableChannelData(this, 
/*      */         
/*  692 */         id(), this.type, 
/*      */         
/*  694 */         guildId(), 
/*  695 */         position(), newValue, 
/*      */         
/*  697 */         name(), 
/*  698 */         topic(), 
/*  699 */         nsfw(), 
/*  700 */         lastMessageId(), 
/*  701 */         bitrate(), 
/*  702 */         userLimit(), 
/*  703 */         rateLimitPerUser(), 
/*  704 */         recipients(), 
/*  705 */         icon(), 
/*  706 */         ownerId(), 
/*  707 */         applicationId(), 
/*  708 */         parentId(), 
/*  709 */         lastPinTimestamp(), 
/*  710 */         rtcRegion(), 
/*  711 */         videoQualityMode());
/*      */   }
/*      */   
/*      */   @SafeVarargs
/*      */   public final ImmutableChannelData withPermissionOverwrites(OverwriteData... elements) {
/*  716 */     Possible<List<OverwriteData>> newValue = Possible.of(Arrays.asList(elements));
/*  717 */     return new ImmutableChannelData(this, 
/*      */         
/*  719 */         id(), this.type, 
/*      */         
/*  721 */         guildId(), 
/*  722 */         position(), newValue, 
/*      */         
/*  724 */         name(), 
/*  725 */         topic(), 
/*  726 */         nsfw(), 
/*  727 */         lastMessageId(), 
/*  728 */         bitrate(), 
/*  729 */         userLimit(), 
/*  730 */         rateLimitPerUser(), 
/*  731 */         recipients(), 
/*  732 */         icon(), 
/*  733 */         ownerId(), 
/*  734 */         applicationId(), 
/*  735 */         parentId(), 
/*  736 */         lastPinTimestamp(), 
/*  737 */         rtcRegion(), 
/*  738 */         videoQualityMode());
/*      */   }
/*      */   
/*      */   public ImmutableChannelData withName(Possible<String> value) {
/*  742 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/*  743 */     return new ImmutableChannelData(this, 
/*      */         
/*  745 */         id(), this.type, 
/*      */         
/*  747 */         guildId(), 
/*  748 */         position(), 
/*  749 */         permissionOverwrites(), newValue, 
/*      */         
/*  751 */         topic(), 
/*  752 */         nsfw(), 
/*  753 */         lastMessageId(), 
/*  754 */         bitrate(), 
/*  755 */         userLimit(), 
/*  756 */         rateLimitPerUser(), 
/*  757 */         recipients(), 
/*  758 */         icon(), 
/*  759 */         ownerId(), 
/*  760 */         applicationId(), 
/*  761 */         parentId(), 
/*  762 */         lastPinTimestamp(), 
/*  763 */         rtcRegion(), 
/*  764 */         videoQualityMode());
/*      */   }
/*      */   
/*      */   public ImmutableChannelData withName(String value) {
/*  768 */     Possible<String> newValue = Possible.of(value);
/*  769 */     return new ImmutableChannelData(this, 
/*      */         
/*  771 */         id(), this.type, 
/*      */         
/*  773 */         guildId(), 
/*  774 */         position(), 
/*  775 */         permissionOverwrites(), newValue, 
/*      */         
/*  777 */         topic(), 
/*  778 */         nsfw(), 
/*  779 */         lastMessageId(), 
/*  780 */         bitrate(), 
/*  781 */         userLimit(), 
/*  782 */         rateLimitPerUser(), 
/*  783 */         recipients(), 
/*  784 */         icon(), 
/*  785 */         ownerId(), 
/*  786 */         applicationId(), 
/*  787 */         parentId(), 
/*  788 */         lastPinTimestamp(), 
/*  789 */         rtcRegion(), 
/*  790 */         videoQualityMode());
/*      */   }
/*      */   
/*      */   public ImmutableChannelData withTopic(Possible<Optional<String>> value) {
/*  794 */     Possible<Optional<String>> newValue = Objects.<Possible<Optional<String>>>requireNonNull(value);
/*  795 */     return new ImmutableChannelData(this, 
/*      */         
/*  797 */         id(), this.type, 
/*      */         
/*  799 */         guildId(), 
/*  800 */         position(), 
/*  801 */         permissionOverwrites(), 
/*  802 */         name(), newValue, 
/*      */         
/*  804 */         nsfw(), 
/*  805 */         lastMessageId(), 
/*  806 */         bitrate(), 
/*  807 */         userLimit(), 
/*  808 */         rateLimitPerUser(), 
/*  809 */         recipients(), 
/*  810 */         icon(), 
/*  811 */         ownerId(), 
/*  812 */         applicationId(), 
/*  813 */         parentId(), 
/*  814 */         lastPinTimestamp(), 
/*  815 */         rtcRegion(), 
/*  816 */         videoQualityMode());
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public ImmutableChannelData withTopic(@Nullable String value) {
/*  821 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/*  822 */     return new ImmutableChannelData(this, 
/*      */         
/*  824 */         id(), this.type, 
/*      */         
/*  826 */         guildId(), 
/*  827 */         position(), 
/*  828 */         permissionOverwrites(), 
/*  829 */         name(), newValue, 
/*      */         
/*  831 */         nsfw(), 
/*  832 */         lastMessageId(), 
/*  833 */         bitrate(), 
/*  834 */         userLimit(), 
/*  835 */         rateLimitPerUser(), 
/*  836 */         recipients(), 
/*  837 */         icon(), 
/*  838 */         ownerId(), 
/*  839 */         applicationId(), 
/*  840 */         parentId(), 
/*  841 */         lastPinTimestamp(), 
/*  842 */         rtcRegion(), 
/*  843 */         videoQualityMode());
/*      */   }
/*      */   
/*      */   public ImmutableChannelData withTopicOrNull(@Nullable String value) {
/*  847 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/*  848 */     return new ImmutableChannelData(this, 
/*      */         
/*  850 */         id(), this.type, 
/*      */         
/*  852 */         guildId(), 
/*  853 */         position(), 
/*  854 */         permissionOverwrites(), 
/*  855 */         name(), newValue, 
/*      */         
/*  857 */         nsfw(), 
/*  858 */         lastMessageId(), 
/*  859 */         bitrate(), 
/*  860 */         userLimit(), 
/*  861 */         rateLimitPerUser(), 
/*  862 */         recipients(), 
/*  863 */         icon(), 
/*  864 */         ownerId(), 
/*  865 */         applicationId(), 
/*  866 */         parentId(), 
/*  867 */         lastPinTimestamp(), 
/*  868 */         rtcRegion(), 
/*  869 */         videoQualityMode());
/*      */   }
/*      */   
/*      */   public ImmutableChannelData withNsfw(Possible<Boolean> value) {
/*  873 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/*  874 */     return new ImmutableChannelData(this, 
/*      */         
/*  876 */         id(), this.type, 
/*      */         
/*  878 */         guildId(), 
/*  879 */         position(), 
/*  880 */         permissionOverwrites(), 
/*  881 */         name(), 
/*  882 */         topic(), newValue, 
/*      */         
/*  884 */         lastMessageId(), 
/*  885 */         bitrate(), 
/*  886 */         userLimit(), 
/*  887 */         rateLimitPerUser(), 
/*  888 */         recipients(), 
/*  889 */         icon(), 
/*  890 */         ownerId(), 
/*  891 */         applicationId(), 
/*  892 */         parentId(), 
/*  893 */         lastPinTimestamp(), 
/*  894 */         rtcRegion(), 
/*  895 */         videoQualityMode());
/*      */   }
/*      */   
/*      */   public ImmutableChannelData withNsfw(Boolean value) {
/*  899 */     Possible<Boolean> newValue = Possible.of(value);
/*  900 */     return new ImmutableChannelData(this, 
/*      */         
/*  902 */         id(), this.type, 
/*      */         
/*  904 */         guildId(), 
/*  905 */         position(), 
/*  906 */         permissionOverwrites(), 
/*  907 */         name(), 
/*  908 */         topic(), newValue, 
/*      */         
/*  910 */         lastMessageId(), 
/*  911 */         bitrate(), 
/*  912 */         userLimit(), 
/*  913 */         rateLimitPerUser(), 
/*  914 */         recipients(), 
/*  915 */         icon(), 
/*  916 */         ownerId(), 
/*  917 */         applicationId(), 
/*  918 */         parentId(), 
/*  919 */         lastPinTimestamp(), 
/*  920 */         rtcRegion(), 
/*  921 */         videoQualityMode());
/*      */   }
/*      */   
/*      */   public ImmutableChannelData withLastMessageId(Possible<Optional<Id>> value) {
/*  925 */     Possible<Optional<Id>> newValue = Objects.<Possible<Optional<Id>>>requireNonNull(value);
/*  926 */     return new ImmutableChannelData(this, 
/*      */         
/*  928 */         id(), this.type, 
/*      */         
/*  930 */         guildId(), 
/*  931 */         position(), 
/*  932 */         permissionOverwrites(), 
/*  933 */         name(), 
/*  934 */         topic(), 
/*  935 */         nsfw(), newValue, 
/*      */         
/*  937 */         bitrate(), 
/*  938 */         userLimit(), 
/*  939 */         rateLimitPerUser(), 
/*  940 */         recipients(), 
/*  941 */         icon(), 
/*  942 */         ownerId(), 
/*  943 */         applicationId(), 
/*  944 */         parentId(), 
/*  945 */         lastPinTimestamp(), 
/*  946 */         rtcRegion(), 
/*  947 */         videoQualityMode());
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public ImmutableChannelData withLastMessageId(@Nullable Long value) {
/*  953 */     Possible<Optional<Id>> newValue = (value == null) ? Possible.of(Optional.empty()) : Possible.of(Optional.of(Id.of(value.longValue())));
/*  954 */     return new ImmutableChannelData(this, 
/*      */         
/*  956 */         id(), this.type, 
/*      */         
/*  958 */         guildId(), 
/*  959 */         position(), 
/*  960 */         permissionOverwrites(), 
/*  961 */         name(), 
/*  962 */         topic(), 
/*  963 */         nsfw(), newValue, 
/*      */         
/*  965 */         bitrate(), 
/*  966 */         userLimit(), 
/*  967 */         rateLimitPerUser(), 
/*  968 */         recipients(), 
/*  969 */         icon(), 
/*  970 */         ownerId(), 
/*  971 */         applicationId(), 
/*  972 */         parentId(), 
/*  973 */         lastPinTimestamp(), 
/*  974 */         rtcRegion(), 
/*  975 */         videoQualityMode());
/*      */   }
/*      */ 
/*      */   
/*      */   public ImmutableChannelData withLastMessageIdOrNull(@Nullable Long value) {
/*  980 */     Possible<Optional<Id>> newValue = (value == null) ? Possible.of(Optional.empty()) : Possible.of(Optional.of(Id.of(value.longValue())));
/*  981 */     return new ImmutableChannelData(this, 
/*      */         
/*  983 */         id(), this.type, 
/*      */         
/*  985 */         guildId(), 
/*  986 */         position(), 
/*  987 */         permissionOverwrites(), 
/*  988 */         name(), 
/*  989 */         topic(), 
/*  990 */         nsfw(), newValue, 
/*      */         
/*  992 */         bitrate(), 
/*  993 */         userLimit(), 
/*  994 */         rateLimitPerUser(), 
/*  995 */         recipients(), 
/*  996 */         icon(), 
/*  997 */         ownerId(), 
/*  998 */         applicationId(), 
/*  999 */         parentId(), 
/* 1000 */         lastPinTimestamp(), 
/* 1001 */         rtcRegion(), 
/* 1002 */         videoQualityMode());
/*      */   }
/*      */   
/*      */   public ImmutableChannelData withBitrate(Possible<Integer> value) {
/* 1006 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/* 1007 */     return new ImmutableChannelData(this, 
/*      */         
/* 1009 */         id(), this.type, 
/*      */         
/* 1011 */         guildId(), 
/* 1012 */         position(), 
/* 1013 */         permissionOverwrites(), 
/* 1014 */         name(), 
/* 1015 */         topic(), 
/* 1016 */         nsfw(), 
/* 1017 */         lastMessageId(), newValue, 
/*      */         
/* 1019 */         userLimit(), 
/* 1020 */         rateLimitPerUser(), 
/* 1021 */         recipients(), 
/* 1022 */         icon(), 
/* 1023 */         ownerId(), 
/* 1024 */         applicationId(), 
/* 1025 */         parentId(), 
/* 1026 */         lastPinTimestamp(), 
/* 1027 */         rtcRegion(), 
/* 1028 */         videoQualityMode());
/*      */   }
/*      */   
/*      */   public ImmutableChannelData withBitrate(Integer value) {
/* 1032 */     Possible<Integer> newValue = Possible.of(value);
/* 1033 */     return new ImmutableChannelData(this, 
/*      */         
/* 1035 */         id(), this.type, 
/*      */         
/* 1037 */         guildId(), 
/* 1038 */         position(), 
/* 1039 */         permissionOverwrites(), 
/* 1040 */         name(), 
/* 1041 */         topic(), 
/* 1042 */         nsfw(), 
/* 1043 */         lastMessageId(), newValue, 
/*      */         
/* 1045 */         userLimit(), 
/* 1046 */         rateLimitPerUser(), 
/* 1047 */         recipients(), 
/* 1048 */         icon(), 
/* 1049 */         ownerId(), 
/* 1050 */         applicationId(), 
/* 1051 */         parentId(), 
/* 1052 */         lastPinTimestamp(), 
/* 1053 */         rtcRegion(), 
/* 1054 */         videoQualityMode());
/*      */   }
/*      */   
/*      */   public ImmutableChannelData withUserLimit(Possible<Integer> value) {
/* 1058 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/* 1059 */     return new ImmutableChannelData(this, 
/*      */         
/* 1061 */         id(), this.type, 
/*      */         
/* 1063 */         guildId(), 
/* 1064 */         position(), 
/* 1065 */         permissionOverwrites(), 
/* 1066 */         name(), 
/* 1067 */         topic(), 
/* 1068 */         nsfw(), 
/* 1069 */         lastMessageId(), 
/* 1070 */         bitrate(), newValue, 
/*      */         
/* 1072 */         rateLimitPerUser(), 
/* 1073 */         recipients(), 
/* 1074 */         icon(), 
/* 1075 */         ownerId(), 
/* 1076 */         applicationId(), 
/* 1077 */         parentId(), 
/* 1078 */         lastPinTimestamp(), 
/* 1079 */         rtcRegion(), 
/* 1080 */         videoQualityMode());
/*      */   }
/*      */   
/*      */   public ImmutableChannelData withUserLimit(Integer value) {
/* 1084 */     Possible<Integer> newValue = Possible.of(value);
/* 1085 */     return new ImmutableChannelData(this, 
/*      */         
/* 1087 */         id(), this.type, 
/*      */         
/* 1089 */         guildId(), 
/* 1090 */         position(), 
/* 1091 */         permissionOverwrites(), 
/* 1092 */         name(), 
/* 1093 */         topic(), 
/* 1094 */         nsfw(), 
/* 1095 */         lastMessageId(), 
/* 1096 */         bitrate(), newValue, 
/*      */         
/* 1098 */         rateLimitPerUser(), 
/* 1099 */         recipients(), 
/* 1100 */         icon(), 
/* 1101 */         ownerId(), 
/* 1102 */         applicationId(), 
/* 1103 */         parentId(), 
/* 1104 */         lastPinTimestamp(), 
/* 1105 */         rtcRegion(), 
/* 1106 */         videoQualityMode());
/*      */   }
/*      */   
/*      */   public ImmutableChannelData withRateLimitPerUser(Possible<Integer> value) {
/* 1110 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/* 1111 */     return new ImmutableChannelData(this, 
/*      */         
/* 1113 */         id(), this.type, 
/*      */         
/* 1115 */         guildId(), 
/* 1116 */         position(), 
/* 1117 */         permissionOverwrites(), 
/* 1118 */         name(), 
/* 1119 */         topic(), 
/* 1120 */         nsfw(), 
/* 1121 */         lastMessageId(), 
/* 1122 */         bitrate(), 
/* 1123 */         userLimit(), newValue, 
/*      */         
/* 1125 */         recipients(), 
/* 1126 */         icon(), 
/* 1127 */         ownerId(), 
/* 1128 */         applicationId(), 
/* 1129 */         parentId(), 
/* 1130 */         lastPinTimestamp(), 
/* 1131 */         rtcRegion(), 
/* 1132 */         videoQualityMode());
/*      */   }
/*      */   
/*      */   public ImmutableChannelData withRateLimitPerUser(Integer value) {
/* 1136 */     Possible<Integer> newValue = Possible.of(value);
/* 1137 */     return new ImmutableChannelData(this, 
/*      */         
/* 1139 */         id(), this.type, 
/*      */         
/* 1141 */         guildId(), 
/* 1142 */         position(), 
/* 1143 */         permissionOverwrites(), 
/* 1144 */         name(), 
/* 1145 */         topic(), 
/* 1146 */         nsfw(), 
/* 1147 */         lastMessageId(), 
/* 1148 */         bitrate(), 
/* 1149 */         userLimit(), newValue, 
/*      */         
/* 1151 */         recipients(), 
/* 1152 */         icon(), 
/* 1153 */         ownerId(), 
/* 1154 */         applicationId(), 
/* 1155 */         parentId(), 
/* 1156 */         lastPinTimestamp(), 
/* 1157 */         rtcRegion(), 
/* 1158 */         videoQualityMode());
/*      */   }
/*      */   
/*      */   public ImmutableChannelData withRecipients(Possible<List<UserData>> possible) {
/* 1162 */     Possible<List<UserData>> newValue = Objects.<Possible<List<UserData>>>requireNonNull(possible);
/* 1163 */     return new ImmutableChannelData(this, 
/*      */         
/* 1165 */         id(), this.type, 
/*      */         
/* 1167 */         guildId(), 
/* 1168 */         position(), 
/* 1169 */         permissionOverwrites(), 
/* 1170 */         name(), 
/* 1171 */         topic(), 
/* 1172 */         nsfw(), 
/* 1173 */         lastMessageId(), 
/* 1174 */         bitrate(), 
/* 1175 */         userLimit(), 
/* 1176 */         rateLimitPerUser(), newValue, 
/*      */         
/* 1178 */         icon(), 
/* 1179 */         ownerId(), 
/* 1180 */         applicationId(), 
/* 1181 */         parentId(), 
/* 1182 */         lastPinTimestamp(), 
/* 1183 */         rtcRegion(), 
/* 1184 */         videoQualityMode());
/*      */   }
/*      */   
/*      */   public ImmutableChannelData withRecipients(Iterable<UserData> elements) {
/* 1188 */     Possible<List<UserData>> newValue = Possible.of(
/* 1189 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/* 1190 */     return new ImmutableChannelData(this, 
/*      */         
/* 1192 */         id(), this.type, 
/*      */         
/* 1194 */         guildId(), 
/* 1195 */         position(), 
/* 1196 */         permissionOverwrites(), 
/* 1197 */         name(), 
/* 1198 */         topic(), 
/* 1199 */         nsfw(), 
/* 1200 */         lastMessageId(), 
/* 1201 */         bitrate(), 
/* 1202 */         userLimit(), 
/* 1203 */         rateLimitPerUser(), newValue, 
/*      */         
/* 1205 */         icon(), 
/* 1206 */         ownerId(), 
/* 1207 */         applicationId(), 
/* 1208 */         parentId(), 
/* 1209 */         lastPinTimestamp(), 
/* 1210 */         rtcRegion(), 
/* 1211 */         videoQualityMode());
/*      */   }
/*      */   
/*      */   @SafeVarargs
/*      */   public final ImmutableChannelData withRecipients(UserData... elements) {
/* 1216 */     Possible<List<UserData>> newValue = Possible.of(Arrays.asList(elements));
/* 1217 */     return new ImmutableChannelData(this, 
/*      */         
/* 1219 */         id(), this.type, 
/*      */         
/* 1221 */         guildId(), 
/* 1222 */         position(), 
/* 1223 */         permissionOverwrites(), 
/* 1224 */         name(), 
/* 1225 */         topic(), 
/* 1226 */         nsfw(), 
/* 1227 */         lastMessageId(), 
/* 1228 */         bitrate(), 
/* 1229 */         userLimit(), 
/* 1230 */         rateLimitPerUser(), newValue, 
/*      */         
/* 1232 */         icon(), 
/* 1233 */         ownerId(), 
/* 1234 */         applicationId(), 
/* 1235 */         parentId(), 
/* 1236 */         lastPinTimestamp(), 
/* 1237 */         rtcRegion(), 
/* 1238 */         videoQualityMode());
/*      */   }
/*      */   
/*      */   public ImmutableChannelData withIcon(Possible<Optional<String>> value) {
/* 1242 */     Possible<Optional<String>> newValue = Objects.<Possible<Optional<String>>>requireNonNull(value);
/* 1243 */     return new ImmutableChannelData(this, 
/*      */         
/* 1245 */         id(), this.type, 
/*      */         
/* 1247 */         guildId(), 
/* 1248 */         position(), 
/* 1249 */         permissionOverwrites(), 
/* 1250 */         name(), 
/* 1251 */         topic(), 
/* 1252 */         nsfw(), 
/* 1253 */         lastMessageId(), 
/* 1254 */         bitrate(), 
/* 1255 */         userLimit(), 
/* 1256 */         rateLimitPerUser(), 
/* 1257 */         recipients(), newValue, 
/*      */         
/* 1259 */         ownerId(), 
/* 1260 */         applicationId(), 
/* 1261 */         parentId(), 
/* 1262 */         lastPinTimestamp(), 
/* 1263 */         rtcRegion(), 
/* 1264 */         videoQualityMode());
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public ImmutableChannelData withIcon(@Nullable String value) {
/* 1269 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/* 1270 */     return new ImmutableChannelData(this, 
/*      */         
/* 1272 */         id(), this.type, 
/*      */         
/* 1274 */         guildId(), 
/* 1275 */         position(), 
/* 1276 */         permissionOverwrites(), 
/* 1277 */         name(), 
/* 1278 */         topic(), 
/* 1279 */         nsfw(), 
/* 1280 */         lastMessageId(), 
/* 1281 */         bitrate(), 
/* 1282 */         userLimit(), 
/* 1283 */         rateLimitPerUser(), 
/* 1284 */         recipients(), newValue, 
/*      */         
/* 1286 */         ownerId(), 
/* 1287 */         applicationId(), 
/* 1288 */         parentId(), 
/* 1289 */         lastPinTimestamp(), 
/* 1290 */         rtcRegion(), 
/* 1291 */         videoQualityMode());
/*      */   }
/*      */   
/*      */   public ImmutableChannelData withIconOrNull(@Nullable String value) {
/* 1295 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/* 1296 */     return new ImmutableChannelData(this, 
/*      */         
/* 1298 */         id(), this.type, 
/*      */         
/* 1300 */         guildId(), 
/* 1301 */         position(), 
/* 1302 */         permissionOverwrites(), 
/* 1303 */         name(), 
/* 1304 */         topic(), 
/* 1305 */         nsfw(), 
/* 1306 */         lastMessageId(), 
/* 1307 */         bitrate(), 
/* 1308 */         userLimit(), 
/* 1309 */         rateLimitPerUser(), 
/* 1310 */         recipients(), newValue, 
/*      */         
/* 1312 */         ownerId(), 
/* 1313 */         applicationId(), 
/* 1314 */         parentId(), 
/* 1315 */         lastPinTimestamp(), 
/* 1316 */         rtcRegion(), 
/* 1317 */         videoQualityMode());
/*      */   }
/*      */   
/*      */   public ImmutableChannelData withOwnerId(Possible<Id> value) {
/* 1321 */     Possible<Id> newValue = Objects.<Possible<Id>>requireNonNull(value);
/* 1322 */     return new ImmutableChannelData(this, 
/*      */         
/* 1324 */         id(), this.type, 
/*      */         
/* 1326 */         guildId(), 
/* 1327 */         position(), 
/* 1328 */         permissionOverwrites(), 
/* 1329 */         name(), 
/* 1330 */         topic(), 
/* 1331 */         nsfw(), 
/* 1332 */         lastMessageId(), 
/* 1333 */         bitrate(), 
/* 1334 */         userLimit(), 
/* 1335 */         rateLimitPerUser(), 
/* 1336 */         recipients(), 
/* 1337 */         icon(), newValue, 
/*      */         
/* 1339 */         applicationId(), 
/* 1340 */         parentId(), 
/* 1341 */         lastPinTimestamp(), 
/* 1342 */         rtcRegion(), 
/* 1343 */         videoQualityMode());
/*      */   }
/*      */   
/*      */   public ImmutableChannelData withOwnerId(long value) {
/* 1347 */     Possible<Id> newValue = Possible.of(Id.of(value));
/* 1348 */     return new ImmutableChannelData(this, 
/*      */         
/* 1350 */         id(), this.type, 
/*      */         
/* 1352 */         guildId(), 
/* 1353 */         position(), 
/* 1354 */         permissionOverwrites(), 
/* 1355 */         name(), 
/* 1356 */         topic(), 
/* 1357 */         nsfw(), 
/* 1358 */         lastMessageId(), 
/* 1359 */         bitrate(), 
/* 1360 */         userLimit(), 
/* 1361 */         rateLimitPerUser(), 
/* 1362 */         recipients(), 
/* 1363 */         icon(), newValue, 
/*      */         
/* 1365 */         applicationId(), 
/* 1366 */         parentId(), 
/* 1367 */         lastPinTimestamp(), 
/* 1368 */         rtcRegion(), 
/* 1369 */         videoQualityMode());
/*      */   }
/*      */   
/*      */   public ImmutableChannelData withApplicationId(Possible<Id> value) {
/* 1373 */     Possible<Id> newValue = Objects.<Possible<Id>>requireNonNull(value);
/* 1374 */     return new ImmutableChannelData(this, 
/*      */         
/* 1376 */         id(), this.type, 
/*      */         
/* 1378 */         guildId(), 
/* 1379 */         position(), 
/* 1380 */         permissionOverwrites(), 
/* 1381 */         name(), 
/* 1382 */         topic(), 
/* 1383 */         nsfw(), 
/* 1384 */         lastMessageId(), 
/* 1385 */         bitrate(), 
/* 1386 */         userLimit(), 
/* 1387 */         rateLimitPerUser(), 
/* 1388 */         recipients(), 
/* 1389 */         icon(), 
/* 1390 */         ownerId(), newValue, 
/*      */         
/* 1392 */         parentId(), 
/* 1393 */         lastPinTimestamp(), 
/* 1394 */         rtcRegion(), 
/* 1395 */         videoQualityMode());
/*      */   }
/*      */   
/*      */   public ImmutableChannelData withApplicationId(long value) {
/* 1399 */     Possible<Id> newValue = Possible.of(Id.of(value));
/* 1400 */     return new ImmutableChannelData(this, 
/*      */         
/* 1402 */         id(), this.type, 
/*      */         
/* 1404 */         guildId(), 
/* 1405 */         position(), 
/* 1406 */         permissionOverwrites(), 
/* 1407 */         name(), 
/* 1408 */         topic(), 
/* 1409 */         nsfw(), 
/* 1410 */         lastMessageId(), 
/* 1411 */         bitrate(), 
/* 1412 */         userLimit(), 
/* 1413 */         rateLimitPerUser(), 
/* 1414 */         recipients(), 
/* 1415 */         icon(), 
/* 1416 */         ownerId(), newValue, 
/*      */         
/* 1418 */         parentId(), 
/* 1419 */         lastPinTimestamp(), 
/* 1420 */         rtcRegion(), 
/* 1421 */         videoQualityMode());
/*      */   }
/*      */   
/*      */   public ImmutableChannelData withParentId(Possible<Optional<Id>> value) {
/* 1425 */     Possible<Optional<Id>> newValue = Objects.<Possible<Optional<Id>>>requireNonNull(value);
/* 1426 */     return new ImmutableChannelData(this, 
/*      */         
/* 1428 */         id(), this.type, 
/*      */         
/* 1430 */         guildId(), 
/* 1431 */         position(), 
/* 1432 */         permissionOverwrites(), 
/* 1433 */         name(), 
/* 1434 */         topic(), 
/* 1435 */         nsfw(), 
/* 1436 */         lastMessageId(), 
/* 1437 */         bitrate(), 
/* 1438 */         userLimit(), 
/* 1439 */         rateLimitPerUser(), 
/* 1440 */         recipients(), 
/* 1441 */         icon(), 
/* 1442 */         ownerId(), 
/* 1443 */         applicationId(), newValue, 
/*      */         
/* 1445 */         lastPinTimestamp(), 
/* 1446 */         rtcRegion(), 
/* 1447 */         videoQualityMode());
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public ImmutableChannelData withParentId(@Nullable Long value) {
/* 1453 */     Possible<Optional<Id>> newValue = (value == null) ? Possible.of(Optional.empty()) : Possible.of(Optional.of(Id.of(value.longValue())));
/* 1454 */     return new ImmutableChannelData(this, 
/*      */         
/* 1456 */         id(), this.type, 
/*      */         
/* 1458 */         guildId(), 
/* 1459 */         position(), 
/* 1460 */         permissionOverwrites(), 
/* 1461 */         name(), 
/* 1462 */         topic(), 
/* 1463 */         nsfw(), 
/* 1464 */         lastMessageId(), 
/* 1465 */         bitrate(), 
/* 1466 */         userLimit(), 
/* 1467 */         rateLimitPerUser(), 
/* 1468 */         recipients(), 
/* 1469 */         icon(), 
/* 1470 */         ownerId(), 
/* 1471 */         applicationId(), newValue, 
/*      */         
/* 1473 */         lastPinTimestamp(), 
/* 1474 */         rtcRegion(), 
/* 1475 */         videoQualityMode());
/*      */   }
/*      */ 
/*      */   
/*      */   public ImmutableChannelData withParentIdOrNull(@Nullable Long value) {
/* 1480 */     Possible<Optional<Id>> newValue = (value == null) ? Possible.of(Optional.empty()) : Possible.of(Optional.of(Id.of(value.longValue())));
/* 1481 */     return new ImmutableChannelData(this, 
/*      */         
/* 1483 */         id(), this.type, 
/*      */         
/* 1485 */         guildId(), 
/* 1486 */         position(), 
/* 1487 */         permissionOverwrites(), 
/* 1488 */         name(), 
/* 1489 */         topic(), 
/* 1490 */         nsfw(), 
/* 1491 */         lastMessageId(), 
/* 1492 */         bitrate(), 
/* 1493 */         userLimit(), 
/* 1494 */         rateLimitPerUser(), 
/* 1495 */         recipients(), 
/* 1496 */         icon(), 
/* 1497 */         ownerId(), 
/* 1498 */         applicationId(), newValue, 
/*      */         
/* 1500 */         lastPinTimestamp(), 
/* 1501 */         rtcRegion(), 
/* 1502 */         videoQualityMode());
/*      */   }
/*      */   
/*      */   public ImmutableChannelData withLastPinTimestamp(Possible<Optional<String>> value) {
/* 1506 */     Possible<Optional<String>> newValue = Objects.<Possible<Optional<String>>>requireNonNull(value);
/* 1507 */     return new ImmutableChannelData(this, 
/*      */         
/* 1509 */         id(), this.type, 
/*      */         
/* 1511 */         guildId(), 
/* 1512 */         position(), 
/* 1513 */         permissionOverwrites(), 
/* 1514 */         name(), 
/* 1515 */         topic(), 
/* 1516 */         nsfw(), 
/* 1517 */         lastMessageId(), 
/* 1518 */         bitrate(), 
/* 1519 */         userLimit(), 
/* 1520 */         rateLimitPerUser(), 
/* 1521 */         recipients(), 
/* 1522 */         icon(), 
/* 1523 */         ownerId(), 
/* 1524 */         applicationId(), 
/* 1525 */         parentId(), newValue, 
/*      */         
/* 1527 */         rtcRegion(), 
/* 1528 */         videoQualityMode());
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public ImmutableChannelData withLastPinTimestamp(@Nullable String value) {
/* 1533 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/* 1534 */     return new ImmutableChannelData(this, 
/*      */         
/* 1536 */         id(), this.type, 
/*      */         
/* 1538 */         guildId(), 
/* 1539 */         position(), 
/* 1540 */         permissionOverwrites(), 
/* 1541 */         name(), 
/* 1542 */         topic(), 
/* 1543 */         nsfw(), 
/* 1544 */         lastMessageId(), 
/* 1545 */         bitrate(), 
/* 1546 */         userLimit(), 
/* 1547 */         rateLimitPerUser(), 
/* 1548 */         recipients(), 
/* 1549 */         icon(), 
/* 1550 */         ownerId(), 
/* 1551 */         applicationId(), 
/* 1552 */         parentId(), newValue, 
/*      */         
/* 1554 */         rtcRegion(), 
/* 1555 */         videoQualityMode());
/*      */   }
/*      */   
/*      */   public ImmutableChannelData withLastPinTimestampOrNull(@Nullable String value) {
/* 1559 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/* 1560 */     return new ImmutableChannelData(this, 
/*      */         
/* 1562 */         id(), this.type, 
/*      */         
/* 1564 */         guildId(), 
/* 1565 */         position(), 
/* 1566 */         permissionOverwrites(), 
/* 1567 */         name(), 
/* 1568 */         topic(), 
/* 1569 */         nsfw(), 
/* 1570 */         lastMessageId(), 
/* 1571 */         bitrate(), 
/* 1572 */         userLimit(), 
/* 1573 */         rateLimitPerUser(), 
/* 1574 */         recipients(), 
/* 1575 */         icon(), 
/* 1576 */         ownerId(), 
/* 1577 */         applicationId(), 
/* 1578 */         parentId(), newValue, 
/*      */         
/* 1580 */         rtcRegion(), 
/* 1581 */         videoQualityMode());
/*      */   }
/*      */   
/*      */   public ImmutableChannelData withRtcRegion(Possible<Optional<String>> value) {
/* 1585 */     Possible<Optional<String>> newValue = Objects.<Possible<Optional<String>>>requireNonNull(value);
/* 1586 */     return new ImmutableChannelData(this, 
/*      */         
/* 1588 */         id(), this.type, 
/*      */         
/* 1590 */         guildId(), 
/* 1591 */         position(), 
/* 1592 */         permissionOverwrites(), 
/* 1593 */         name(), 
/* 1594 */         topic(), 
/* 1595 */         nsfw(), 
/* 1596 */         lastMessageId(), 
/* 1597 */         bitrate(), 
/* 1598 */         userLimit(), 
/* 1599 */         rateLimitPerUser(), 
/* 1600 */         recipients(), 
/* 1601 */         icon(), 
/* 1602 */         ownerId(), 
/* 1603 */         applicationId(), 
/* 1604 */         parentId(), 
/* 1605 */         lastPinTimestamp(), newValue, 
/*      */         
/* 1607 */         videoQualityMode());
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public ImmutableChannelData withRtcRegion(@Nullable String value) {
/* 1612 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/* 1613 */     return new ImmutableChannelData(this, 
/*      */         
/* 1615 */         id(), this.type, 
/*      */         
/* 1617 */         guildId(), 
/* 1618 */         position(), 
/* 1619 */         permissionOverwrites(), 
/* 1620 */         name(), 
/* 1621 */         topic(), 
/* 1622 */         nsfw(), 
/* 1623 */         lastMessageId(), 
/* 1624 */         bitrate(), 
/* 1625 */         userLimit(), 
/* 1626 */         rateLimitPerUser(), 
/* 1627 */         recipients(), 
/* 1628 */         icon(), 
/* 1629 */         ownerId(), 
/* 1630 */         applicationId(), 
/* 1631 */         parentId(), 
/* 1632 */         lastPinTimestamp(), newValue, 
/*      */         
/* 1634 */         videoQualityMode());
/*      */   }
/*      */   
/*      */   public ImmutableChannelData withRtcRegionOrNull(@Nullable String value) {
/* 1638 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/* 1639 */     return new ImmutableChannelData(this, 
/*      */         
/* 1641 */         id(), this.type, 
/*      */         
/* 1643 */         guildId(), 
/* 1644 */         position(), 
/* 1645 */         permissionOverwrites(), 
/* 1646 */         name(), 
/* 1647 */         topic(), 
/* 1648 */         nsfw(), 
/* 1649 */         lastMessageId(), 
/* 1650 */         bitrate(), 
/* 1651 */         userLimit(), 
/* 1652 */         rateLimitPerUser(), 
/* 1653 */         recipients(), 
/* 1654 */         icon(), 
/* 1655 */         ownerId(), 
/* 1656 */         applicationId(), 
/* 1657 */         parentId(), 
/* 1658 */         lastPinTimestamp(), newValue, 
/*      */         
/* 1660 */         videoQualityMode());
/*      */   }
/*      */   
/*      */   public ImmutableChannelData withVideoQualityMode(Possible<Integer> value) {
/* 1664 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/* 1665 */     return new ImmutableChannelData(this, 
/*      */         
/* 1667 */         id(), this.type, 
/*      */         
/* 1669 */         guildId(), 
/* 1670 */         position(), 
/* 1671 */         permissionOverwrites(), 
/* 1672 */         name(), 
/* 1673 */         topic(), 
/* 1674 */         nsfw(), 
/* 1675 */         lastMessageId(), 
/* 1676 */         bitrate(), 
/* 1677 */         userLimit(), 
/* 1678 */         rateLimitPerUser(), 
/* 1679 */         recipients(), 
/* 1680 */         icon(), 
/* 1681 */         ownerId(), 
/* 1682 */         applicationId(), 
/* 1683 */         parentId(), 
/* 1684 */         lastPinTimestamp(), 
/* 1685 */         rtcRegion(), newValue);
/*      */   }
/*      */ 
/*      */   
/*      */   public ImmutableChannelData withVideoQualityMode(Integer value) {
/* 1690 */     Possible<Integer> newValue = Possible.of(value);
/* 1691 */     return new ImmutableChannelData(this, 
/*      */         
/* 1693 */         id(), this.type, 
/*      */         
/* 1695 */         guildId(), 
/* 1696 */         position(), 
/* 1697 */         permissionOverwrites(), 
/* 1698 */         name(), 
/* 1699 */         topic(), 
/* 1700 */         nsfw(), 
/* 1701 */         lastMessageId(), 
/* 1702 */         bitrate(), 
/* 1703 */         userLimit(), 
/* 1704 */         rateLimitPerUser(), 
/* 1705 */         recipients(), 
/* 1706 */         icon(), 
/* 1707 */         ownerId(), 
/* 1708 */         applicationId(), 
/* 1709 */         parentId(), 
/* 1710 */         lastPinTimestamp(), 
/* 1711 */         rtcRegion(), newValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean equals(Object another) {
/* 1721 */     if (this == another) return true; 
/* 1722 */     return (another instanceof ImmutableChannelData && 
/* 1723 */       equalTo(0, (ImmutableChannelData)another));
/*      */   }
/*      */   
/*      */   private boolean equalTo(int synthetic, ImmutableChannelData another) {
/* 1727 */     return (Objects.equals(Long.valueOf(this.id_value), Long.valueOf(another.id_value)) && this.type == another.type && 
/*      */       
/* 1729 */       guildId().equals(another.guildId()) && 
/* 1730 */       position().equals(another.position()) && 
/* 1731 */       Objects.equals(this.permissionOverwrites_value, another.permissionOverwrites_value) && 
/* 1732 */       name().equals(another.name()) && 
/* 1733 */       topic().equals(another.topic()) && 
/* 1734 */       nsfw().equals(another.nsfw()) && 
/* 1735 */       lastMessageId().equals(another.lastMessageId()) && 
/* 1736 */       bitrate().equals(another.bitrate()) && 
/* 1737 */       userLimit().equals(another.userLimit()) && 
/* 1738 */       rateLimitPerUser().equals(another.rateLimitPerUser()) && 
/* 1739 */       Objects.equals(this.recipients_value, another.recipients_value) && 
/* 1740 */       icon().equals(another.icon()) && 
/* 1741 */       ownerId().equals(another.ownerId()) && 
/* 1742 */       applicationId().equals(another.applicationId()) && 
/* 1743 */       parentId().equals(another.parentId()) && 
/* 1744 */       lastPinTimestamp().equals(another.lastPinTimestamp()) && 
/* 1745 */       rtcRegion().equals(another.rtcRegion()) && 
/* 1746 */       videoQualityMode().equals(another.videoQualityMode()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int hashCode() {
/* 1755 */     int h = 5381;
/* 1756 */     h += (h << 5) + Objects.hashCode(Long.valueOf(this.id_value));
/* 1757 */     h += (h << 5) + this.type;
/* 1758 */     h += (h << 5) + guildId().hashCode();
/* 1759 */     h += (h << 5) + position().hashCode();
/* 1760 */     h += (h << 5) + Objects.hashCode(this.permissionOverwrites_value);
/* 1761 */     h += (h << 5) + name().hashCode();
/* 1762 */     h += (h << 5) + topic().hashCode();
/* 1763 */     h += (h << 5) + nsfw().hashCode();
/* 1764 */     h += (h << 5) + lastMessageId().hashCode();
/* 1765 */     h += (h << 5) + bitrate().hashCode();
/* 1766 */     h += (h << 5) + userLimit().hashCode();
/* 1767 */     h += (h << 5) + rateLimitPerUser().hashCode();
/* 1768 */     h += (h << 5) + Objects.hashCode(this.recipients_value);
/* 1769 */     h += (h << 5) + icon().hashCode();
/* 1770 */     h += (h << 5) + ownerId().hashCode();
/* 1771 */     h += (h << 5) + applicationId().hashCode();
/* 1772 */     h += (h << 5) + parentId().hashCode();
/* 1773 */     h += (h << 5) + lastPinTimestamp().hashCode();
/* 1774 */     h += (h << 5) + rtcRegion().hashCode();
/* 1775 */     h += (h << 5) + videoQualityMode().hashCode();
/* 1776 */     return h;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/* 1785 */     return "ChannelData{id=" + 
/* 1786 */       Objects.toString(Long.valueOf(this.id_value)) + ", type=" + this.type + ", guildId=" + 
/*      */       
/* 1788 */       guildId().toString() + ", position=" + 
/* 1789 */       position().toString() + ", permissionOverwrites=" + 
/* 1790 */       Objects.toString(this.permissionOverwrites_value) + ", name=" + 
/* 1791 */       name().toString() + ", topic=" + 
/* 1792 */       topic().toString() + ", nsfw=" + 
/* 1793 */       nsfw().toString() + ", lastMessageId=" + 
/* 1794 */       lastMessageId().toString() + ", bitrate=" + 
/* 1795 */       bitrate().toString() + ", userLimit=" + 
/* 1796 */       userLimit().toString() + ", rateLimitPerUser=" + 
/* 1797 */       rateLimitPerUser().toString() + ", recipients=" + 
/* 1798 */       Objects.toString(this.recipients_value) + ", icon=" + 
/* 1799 */       icon().toString() + ", ownerId=" + 
/* 1800 */       ownerId().toString() + ", applicationId=" + 
/* 1801 */       applicationId().toString() + ", parentId=" + 
/* 1802 */       parentId().toString() + ", lastPinTimestamp=" + 
/* 1803 */       lastPinTimestamp().toString() + ", rtcRegion=" + 
/* 1804 */       rtcRegion().toString() + ", videoQualityMode=" + 
/* 1805 */       videoQualityMode().toString() + "}";
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonDeserialize
/*      */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*      */   @Generated(from = "ChannelData", generator = "Immutables")
/*      */   static final class Json
/*      */     implements ChannelData
/*      */   {
/*      */     Id id;
/*      */     
/*      */     int type;
/*      */     
/*      */     boolean typeIsSet;
/*      */     
/* 1822 */     Possible<Id> guildId = Possible.absent();
/*      */ 
/*      */     
/* 1825 */     Possible<Integer> position = Possible.absent();
/*      */ 
/*      */     
/* 1828 */     Possible<List<OverwriteData>> permissionOverwrites = Possible.absent();
/*      */ 
/*      */     
/* 1831 */     Possible<String> name = Possible.absent();
/*      */ 
/*      */     
/* 1834 */     Possible<Optional<String>> topic = Possible.absent();
/*      */ 
/*      */     
/* 1837 */     Possible<Boolean> nsfw = Possible.absent();
/*      */ 
/*      */     
/* 1840 */     Possible<Optional<Id>> lastMessageId = Possible.absent();
/*      */ 
/*      */     
/* 1843 */     Possible<Integer> bitrate = Possible.absent();
/*      */ 
/*      */     
/* 1846 */     Possible<Integer> userLimit = Possible.absent();
/*      */ 
/*      */     
/* 1849 */     Possible<Integer> rateLimitPerUser = Possible.absent();
/*      */ 
/*      */     
/* 1852 */     Possible<List<UserData>> recipients = Possible.absent();
/*      */ 
/*      */     
/* 1855 */     Possible<Optional<String>> icon = Possible.absent();
/*      */ 
/*      */     
/* 1858 */     Possible<Id> ownerId = Possible.absent();
/*      */ 
/*      */     
/* 1861 */     Possible<Id> applicationId = Possible.absent();
/*      */ 
/*      */     
/* 1864 */     Possible<Optional<Id>> parentId = Possible.absent();
/*      */ 
/*      */     
/* 1867 */     Possible<Optional<String>> lastPinTimestamp = Possible.absent();
/*      */ 
/*      */     
/* 1870 */     Possible<Optional<String>> rtcRegion = Possible.absent();
/*      */ 
/*      */     
/* 1873 */     Possible<Integer> videoQualityMode = Possible.absent();
/*      */     
/*      */     @JsonProperty("id")
/*      */     public void setId(Id id) {
/* 1877 */       this.id = id;
/*      */     }
/*      */     @JsonProperty("type")
/*      */     public void setType(int type) {
/* 1881 */       this.type = type;
/* 1882 */       this.typeIsSet = true;
/*      */     }
/*      */     @JsonProperty("guild_id")
/*      */     public void setGuildId(Possible<Id> guildId) {
/* 1886 */       this.guildId = guildId;
/*      */     }
/*      */     @JsonProperty("position")
/*      */     public void setPosition(Possible<Integer> position) {
/* 1890 */       this.position = position;
/*      */     }
/*      */     @JsonProperty("permission_overwrites")
/*      */     public void setPermissionOverwrites(Possible<List<OverwriteData>> permissionOverwrites) {
/* 1894 */       this.permissionOverwrites = permissionOverwrites;
/*      */     }
/*      */     @JsonProperty("name")
/*      */     public void setName(Possible<String> name) {
/* 1898 */       this.name = name;
/*      */     }
/*      */     @JsonProperty("topic")
/*      */     public void setTopic(Possible<Optional<String>> topic) {
/* 1902 */       this.topic = topic;
/*      */     }
/*      */     @JsonProperty("nsfw")
/*      */     public void setNsfw(Possible<Boolean> nsfw) {
/* 1906 */       this.nsfw = nsfw;
/*      */     }
/*      */     @JsonProperty("last_message_id")
/*      */     public void setLastMessageId(Possible<Optional<Id>> lastMessageId) {
/* 1910 */       this.lastMessageId = lastMessageId;
/*      */     }
/*      */     @JsonProperty("bitrate")
/*      */     public void setBitrate(Possible<Integer> bitrate) {
/* 1914 */       this.bitrate = bitrate;
/*      */     }
/*      */     @JsonProperty("user_limit")
/*      */     public void setUserLimit(Possible<Integer> userLimit) {
/* 1918 */       this.userLimit = userLimit;
/*      */     }
/*      */     @JsonProperty("rate_limit_per_user")
/*      */     public void setRateLimitPerUser(Possible<Integer> rateLimitPerUser) {
/* 1922 */       this.rateLimitPerUser = rateLimitPerUser;
/*      */     }
/*      */     @JsonProperty("recipients")
/*      */     public void setRecipients(Possible<List<UserData>> recipients) {
/* 1926 */       this.recipients = recipients;
/*      */     }
/*      */     @JsonProperty("icon")
/*      */     public void setIcon(Possible<Optional<String>> icon) {
/* 1930 */       this.icon = icon;
/*      */     }
/*      */     @JsonProperty("owner_id")
/*      */     public void setOwnerId(Possible<Id> ownerId) {
/* 1934 */       this.ownerId = ownerId;
/*      */     }
/*      */     @JsonProperty("application_id")
/*      */     public void setApplicationId(Possible<Id> applicationId) {
/* 1938 */       this.applicationId = applicationId;
/*      */     }
/*      */     @JsonProperty("parent_id")
/*      */     public void setParentId(Possible<Optional<Id>> parentId) {
/* 1942 */       this.parentId = parentId;
/*      */     }
/*      */     @JsonProperty("last_pin_timestamp")
/*      */     public void setLastPinTimestamp(Possible<Optional<String>> lastPinTimestamp) {
/* 1946 */       this.lastPinTimestamp = lastPinTimestamp;
/*      */     }
/*      */     @JsonProperty("rtc_region")
/*      */     public void setRtcRegion(Possible<Optional<String>> rtcRegion) {
/* 1950 */       this.rtcRegion = rtcRegion;
/*      */     }
/*      */     @JsonProperty("video_quality_mode")
/*      */     public void setVideoQualityMode(Possible<Integer> videoQualityMode) {
/* 1954 */       this.videoQualityMode = videoQualityMode;
/*      */     }
/*      */     public Id id() {
/* 1957 */       throw new UnsupportedOperationException();
/*      */     } public int type() {
/* 1959 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Id> guildId() {
/* 1961 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Integer> position() {
/* 1963 */       throw new UnsupportedOperationException();
/*      */     } public Possible<List<OverwriteData>> permissionOverwrites() {
/* 1965 */       throw new UnsupportedOperationException();
/*      */     } public Possible<String> name() {
/* 1967 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Optional<String>> topic() {
/* 1969 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Boolean> nsfw() {
/* 1971 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Optional<Id>> lastMessageId() {
/* 1973 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Integer> bitrate() {
/* 1975 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Integer> userLimit() {
/* 1977 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Integer> rateLimitPerUser() {
/* 1979 */       throw new UnsupportedOperationException();
/*      */     } public Possible<List<UserData>> recipients() {
/* 1981 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Optional<String>> icon() {
/* 1983 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Id> ownerId() {
/* 1985 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Id> applicationId() {
/* 1987 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Optional<Id>> parentId() {
/* 1989 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Optional<String>> lastPinTimestamp() {
/* 1991 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Optional<String>> rtcRegion() {
/* 1993 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Integer> videoQualityMode() {
/* 1995 */       throw new UnsupportedOperationException();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*      */   static ImmutableChannelData fromJson(Json json) {
/* 2006 */     Builder builder = builder();
/* 2007 */     if (json.id != null) {
/* 2008 */       builder.id(json.id);
/*      */     }
/* 2010 */     if (json.typeIsSet) {
/* 2011 */       builder.type(json.type);
/*      */     }
/* 2013 */     if (json.guildId != null) {
/* 2014 */       builder.guildId(json.guildId);
/*      */     }
/* 2016 */     if (json.position != null) {
/* 2017 */       builder.position(json.position);
/*      */     }
/* 2019 */     if (json.permissionOverwrites != null) {
/* 2020 */       builder.permissionOverwrites(json.permissionOverwrites);
/*      */     }
/* 2022 */     if (json.name != null) {
/* 2023 */       builder.name(json.name);
/*      */     }
/* 2025 */     if (json.topic != null) {
/* 2026 */       builder.topic(json.topic);
/*      */     }
/* 2028 */     if (json.nsfw != null) {
/* 2029 */       builder.nsfw(json.nsfw);
/*      */     }
/* 2031 */     if (json.lastMessageId != null) {
/* 2032 */       builder.lastMessageId(json.lastMessageId);
/*      */     }
/* 2034 */     if (json.bitrate != null) {
/* 2035 */       builder.bitrate(json.bitrate);
/*      */     }
/* 2037 */     if (json.userLimit != null) {
/* 2038 */       builder.userLimit(json.userLimit);
/*      */     }
/* 2040 */     if (json.rateLimitPerUser != null) {
/* 2041 */       builder.rateLimitPerUser(json.rateLimitPerUser);
/*      */     }
/* 2043 */     if (json.recipients != null) {
/* 2044 */       builder.recipients(json.recipients);
/*      */     }
/* 2046 */     if (json.icon != null) {
/* 2047 */       builder.icon(json.icon);
/*      */     }
/* 2049 */     if (json.ownerId != null) {
/* 2050 */       builder.ownerId(json.ownerId);
/*      */     }
/* 2052 */     if (json.applicationId != null) {
/* 2053 */       builder.applicationId(json.applicationId);
/*      */     }
/* 2055 */     if (json.parentId != null) {
/* 2056 */       builder.parentId(json.parentId);
/*      */     }
/* 2058 */     if (json.lastPinTimestamp != null) {
/* 2059 */       builder.lastPinTimestamp(json.lastPinTimestamp);
/*      */     }
/* 2061 */     if (json.rtcRegion != null) {
/* 2062 */       builder.rtcRegion(json.rtcRegion);
/*      */     }
/* 2064 */     if (json.videoQualityMode != null) {
/* 2065 */       builder.videoQualityMode(json.videoQualityMode);
/*      */     }
/* 2067 */     return builder.build();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableChannelData of(Id id, int type, Possible<Id> guildId, Possible<Integer> position, Possible<List<OverwriteData>> permissionOverwrites, Possible<String> name, Possible<Optional<String>> topic, Possible<Boolean> nsfw, Possible<Optional<Id>> lastMessageId, Possible<Integer> bitrate, Possible<Integer> userLimit, Possible<Integer> rateLimitPerUser, Possible<List<UserData>> recipients, Possible<Optional<String>> icon, Possible<Id> ownerId, Possible<Id> applicationId, Possible<Optional<Id>> parentId, Possible<Optional<String>> lastPinTimestamp, Possible<Optional<String>> rtcRegion, Possible<Integer> videoQualityMode) {
/* 2095 */     return new ImmutableChannelData(id, type, guildId, position, permissionOverwrites, name, topic, nsfw, lastMessageId, bitrate, userLimit, rateLimitPerUser, recipients, icon, ownerId, applicationId, parentId, lastPinTimestamp, rtcRegion, videoQualityMode);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableChannelData copyOf(ChannelData instance) {
/* 2106 */     if (instance instanceof ImmutableChannelData) {
/* 2107 */       return (ImmutableChannelData)instance;
/*      */     }
/* 2109 */     return builder()
/* 2110 */       .from(instance)
/* 2111 */       .build();
/*      */   }
/*      */   
/*      */   public boolean isGuildIdPresent() {
/* 2115 */     return !this.guildId_absent;
/*      */   }
/*      */   
/*      */   public long guildIdOrElse(long defaultValue) {
/* 2119 */     return !this.guildId_absent ? this.guildId_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isPositionPresent() {
/* 2123 */     return !this.position_absent;
/*      */   }
/*      */   
/*      */   public Integer positionOrElse(Integer defaultValue) {
/* 2127 */     return !this.position_absent ? this.position_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isPermissionOverwritesPresent() {
/* 2131 */     return !this.permissionOverwrites_absent;
/*      */   }
/*      */   
/*      */   public List<OverwriteData> permissionOverwritesOrElse(List<OverwriteData> defaultValue) {
/* 2135 */     return !this.permissionOverwrites_absent ? this.permissionOverwrites_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isNamePresent() {
/* 2139 */     return !this.name_absent;
/*      */   }
/*      */   
/*      */   public String nameOrElse(String defaultValue) {
/* 2143 */     return !this.name_absent ? this.name_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isTopicPresent() {
/* 2147 */     return !this.topic_absent;
/*      */   }
/*      */   
/*      */   public String topicOrElse(String defaultValue) {
/* 2151 */     return !this.topic_absent ? this.topic_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isNsfwPresent() {
/* 2155 */     return !this.nsfw_absent;
/*      */   }
/*      */   
/*      */   public Boolean nsfwOrElse(Boolean defaultValue) {
/* 2159 */     return !this.nsfw_absent ? this.nsfw_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isLastMessageIdPresent() {
/* 2163 */     return !this.lastMessageId_absent;
/*      */   }
/*      */   
/*      */   public long lastMessageIdOrElse(long defaultValue) {
/* 2167 */     return !this.lastMessageId_absent ? this.lastMessageId_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isBitratePresent() {
/* 2171 */     return !this.bitrate_absent;
/*      */   }
/*      */   
/*      */   public Integer bitrateOrElse(Integer defaultValue) {
/* 2175 */     return !this.bitrate_absent ? this.bitrate_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isUserLimitPresent() {
/* 2179 */     return !this.userLimit_absent;
/*      */   }
/*      */   
/*      */   public Integer userLimitOrElse(Integer defaultValue) {
/* 2183 */     return !this.userLimit_absent ? this.userLimit_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isRateLimitPerUserPresent() {
/* 2187 */     return !this.rateLimitPerUser_absent;
/*      */   }
/*      */   
/*      */   public Integer rateLimitPerUserOrElse(Integer defaultValue) {
/* 2191 */     return !this.rateLimitPerUser_absent ? this.rateLimitPerUser_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isRecipientsPresent() {
/* 2195 */     return !this.recipients_absent;
/*      */   }
/*      */   
/*      */   public List<UserData> recipientsOrElse(List<UserData> defaultValue) {
/* 2199 */     return !this.recipients_absent ? this.recipients_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isIconPresent() {
/* 2203 */     return !this.icon_absent;
/*      */   }
/*      */   
/*      */   public String iconOrElse(String defaultValue) {
/* 2207 */     return !this.icon_absent ? this.icon_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isOwnerIdPresent() {
/* 2211 */     return !this.ownerId_absent;
/*      */   }
/*      */   
/*      */   public long ownerIdOrElse(long defaultValue) {
/* 2215 */     return !this.ownerId_absent ? this.ownerId_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isApplicationIdPresent() {
/* 2219 */     return !this.applicationId_absent;
/*      */   }
/*      */   
/*      */   public long applicationIdOrElse(long defaultValue) {
/* 2223 */     return !this.applicationId_absent ? this.applicationId_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isParentIdPresent() {
/* 2227 */     return !this.parentId_absent;
/*      */   }
/*      */   
/*      */   public long parentIdOrElse(long defaultValue) {
/* 2231 */     return !this.parentId_absent ? this.parentId_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isLastPinTimestampPresent() {
/* 2235 */     return !this.lastPinTimestamp_absent;
/*      */   }
/*      */   
/*      */   public String lastPinTimestampOrElse(String defaultValue) {
/* 2239 */     return !this.lastPinTimestamp_absent ? this.lastPinTimestamp_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isRtcRegionPresent() {
/* 2243 */     return !this.rtcRegion_absent;
/*      */   }
/*      */   
/*      */   public String rtcRegionOrElse(String defaultValue) {
/* 2247 */     return !this.rtcRegion_absent ? this.rtcRegion_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isVideoQualityModePresent() {
/* 2251 */     return !this.videoQualityMode_absent;
/*      */   }
/*      */   
/*      */   public Integer videoQualityModeOrElse(Integer defaultValue) {
/* 2255 */     return !this.videoQualityMode_absent ? this.videoQualityMode_value : defaultValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Builder builder() {
/* 2287 */     return new Builder();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Generated(from = "ChannelData", generator = "Immutables")
/*      */   public static final class Builder
/*      */   {
/*      */     private static final long INIT_BIT_TYPE = 1L;
/*      */ 
/*      */ 
/*      */     
/* 2300 */     private long initBits = 1L;
/*      */     
/* 2302 */     private Id id_id = null;
/* 2303 */     private Possible<Id> guildId_possible = Possible.absent();
/* 2304 */     private Possible<Integer> position_possible = Possible.absent();
/* 2305 */     private List<OverwriteData> permissionOverwrites_list = null;
/* 2306 */     private Possible<String> name_possible = Possible.absent();
/* 2307 */     private Possible<Optional<String>> topic_possible = Possible.absent();
/* 2308 */     private Possible<Boolean> nsfw_possible = Possible.absent();
/* 2309 */     private Possible<Optional<Id>> lastMessageId_possible = Possible.absent();
/* 2310 */     private Possible<Integer> bitrate_possible = Possible.absent();
/* 2311 */     private Possible<Integer> userLimit_possible = Possible.absent();
/* 2312 */     private Possible<Integer> rateLimitPerUser_possible = Possible.absent();
/* 2313 */     private List<UserData> recipients_list = null;
/* 2314 */     private Possible<Optional<String>> icon_possible = Possible.absent();
/* 2315 */     private Possible<Id> ownerId_possible = Possible.absent();
/* 2316 */     private Possible<Id> applicationId_possible = Possible.absent();
/* 2317 */     private Possible<Optional<Id>> parentId_possible = Possible.absent();
/* 2318 */     private Possible<Optional<String>> lastPinTimestamp_possible = Possible.absent();
/* 2319 */     private Possible<Optional<String>> rtcRegion_possible = Possible.absent();
/* 2320 */     private Possible<Integer> videoQualityMode_possible = Possible.absent();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private int type;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder from(ChannelData instance) {
/* 2334 */       Objects.requireNonNull(instance, "instance");
/* 2335 */       id(instance.id());
/* 2336 */       type(instance.type());
/* 2337 */       guildId(instance.guildId());
/* 2338 */       position(instance.position());
/* 2339 */       permissionOverwrites(instance.permissionOverwrites());
/* 2340 */       name(instance.name());
/* 2341 */       topic(instance.topic());
/* 2342 */       nsfw(instance.nsfw());
/* 2343 */       lastMessageId(instance.lastMessageId());
/* 2344 */       bitrate(instance.bitrate());
/* 2345 */       userLimit(instance.userLimit());
/* 2346 */       rateLimitPerUser(instance.rateLimitPerUser());
/* 2347 */       recipients(instance.recipients());
/* 2348 */       icon(instance.icon());
/* 2349 */       ownerId(instance.ownerId());
/* 2350 */       applicationId(instance.applicationId());
/* 2351 */       parentId(instance.parentId());
/* 2352 */       lastPinTimestamp(instance.lastPinTimestamp());
/* 2353 */       rtcRegion(instance.rtcRegion());
/* 2354 */       videoQualityMode(instance.videoQualityMode());
/* 2355 */       return this;
/*      */     }
/*      */     
/*      */     public Builder id(String value) {
/* 2359 */       this.id_id = Id.of(value);
/* 2360 */       return this;
/*      */     }
/*      */     
/*      */     public Builder id(long value) {
/* 2364 */       this.id_id = Id.of(value);
/* 2365 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("id")
/*      */     public Builder id(Id value) {
/* 2370 */       this.id_id = value;
/* 2371 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("type")
/*      */     public final Builder type(int type) {
/* 2381 */       this.type = type;
/* 2382 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 2383 */       return this;
/*      */     }
/*      */     
/*      */     public Builder guildId(String value) {
/* 2387 */       this.guildId_possible = Possible.of(Id.of(value));
/* 2388 */       return this;
/*      */     }
/*      */     
/*      */     public Builder guildId(long value) {
/* 2392 */       this.guildId_possible = Possible.of(Id.of(value));
/* 2393 */       return this;
/*      */     }
/*      */     
/*      */     public Builder guildId(Id value) {
/* 2397 */       this.guildId_possible = Possible.of(value);
/* 2398 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("guild_id")
/*      */     public Builder guildId(Possible<Id> value) {
/* 2403 */       this.guildId_possible = value;
/* 2404 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("position")
/*      */     public Builder position(Possible<Integer> value) {
/* 2409 */       this.position_possible = value;
/* 2410 */       return this;
/*      */     }
/*      */     
/*      */     public Builder position(Integer value) {
/* 2414 */       this.position_possible = Possible.of(value);
/* 2415 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addPermissionOverwrite(OverwriteData element) {
/* 2419 */       permissionOverwrites_getOrCreate().add(element);
/* 2420 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addAllPermissionOverwrites(List<OverwriteData> elements) {
/* 2424 */       permissionOverwrites_getOrCreate().addAll(elements);
/* 2425 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("permission_overwrites")
/*      */     public Builder permissionOverwrites(Possible<List<OverwriteData>> elements) {
/* 2430 */       this.permissionOverwrites_list = null;
/* 2431 */       elements.toOptional().ifPresent(e -> permissionOverwrites_getOrCreate().addAll(e));
/* 2432 */       return this;
/*      */     }
/*      */     
/*      */     public Builder permissionOverwrites(List<OverwriteData> elements) {
/* 2436 */       this.permissionOverwrites_list = new ArrayList<>(elements);
/* 2437 */       return this;
/*      */     }
/*      */     
/*      */     public Builder permissionOverwrites(Iterable<OverwriteData> elements) {
/* 2441 */       this.permissionOverwrites_list = (List<OverwriteData>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/* 2442 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("name")
/*      */     public Builder name(Possible<String> value) {
/* 2447 */       this.name_possible = value;
/* 2448 */       return this;
/*      */     }
/*      */     
/*      */     public Builder name(String value) {
/* 2452 */       this.name_possible = Possible.of(value);
/* 2453 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("topic")
/*      */     public Builder topic(Possible<Optional<String>> value) {
/* 2458 */       this.topic_possible = value;
/* 2459 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public Builder topic(@Nullable String value) {
/* 2464 */       this.topic_possible = Possible.of(Optional.ofNullable(value));
/* 2465 */       return this;
/*      */     }
/*      */     
/*      */     public Builder topicOrNull(@Nullable String value) {
/* 2469 */       this.topic_possible = Possible.of(Optional.ofNullable(value));
/* 2470 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("nsfw")
/*      */     public Builder nsfw(Possible<Boolean> value) {
/* 2475 */       this.nsfw_possible = value;
/* 2476 */       return this;
/*      */     }
/*      */     
/*      */     public Builder nsfw(Boolean value) {
/* 2480 */       this.nsfw_possible = Possible.of(value);
/* 2481 */       return this;
/*      */     }
/*      */     
/*      */     public Builder lastMessageId(String value) {
/* 2485 */       this.lastMessageId_possible = Possible.of(Optional.of(Id.of(value)));
/* 2486 */       return this;
/*      */     }
/*      */     
/*      */     public Builder lastMessageId(long value) {
/* 2490 */       this.lastMessageId_possible = Possible.of(Optional.of(Id.of(value)));
/* 2491 */       return this;
/*      */     }
/*      */     
/*      */     public Builder lastMessageId(Id value) {
/* 2495 */       this.lastMessageId_possible = Possible.of(Optional.of(value));
/* 2496 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("last_message_id")
/*      */     public Builder lastMessageId(Possible<Optional<Id>> value) {
/* 2501 */       this.lastMessageId_possible = value;
/* 2502 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("bitrate")
/*      */     public Builder bitrate(Possible<Integer> value) {
/* 2507 */       this.bitrate_possible = value;
/* 2508 */       return this;
/*      */     }
/*      */     
/*      */     public Builder bitrate(Integer value) {
/* 2512 */       this.bitrate_possible = Possible.of(value);
/* 2513 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("user_limit")
/*      */     public Builder userLimit(Possible<Integer> value) {
/* 2518 */       this.userLimit_possible = value;
/* 2519 */       return this;
/*      */     }
/*      */     
/*      */     public Builder userLimit(Integer value) {
/* 2523 */       this.userLimit_possible = Possible.of(value);
/* 2524 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("rate_limit_per_user")
/*      */     public Builder rateLimitPerUser(Possible<Integer> value) {
/* 2529 */       this.rateLimitPerUser_possible = value;
/* 2530 */       return this;
/*      */     }
/*      */     
/*      */     public Builder rateLimitPerUser(Integer value) {
/* 2534 */       this.rateLimitPerUser_possible = Possible.of(value);
/* 2535 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addRecipient(UserData element) {
/* 2539 */       recipients_getOrCreate().add(element);
/* 2540 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addAllRecipients(List<UserData> elements) {
/* 2544 */       recipients_getOrCreate().addAll(elements);
/* 2545 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("recipients")
/*      */     public Builder recipients(Possible<List<UserData>> elements) {
/* 2550 */       this.recipients_list = null;
/* 2551 */       elements.toOptional().ifPresent(e -> recipients_getOrCreate().addAll(e));
/* 2552 */       return this;
/*      */     }
/*      */     
/*      */     public Builder recipients(List<UserData> elements) {
/* 2556 */       this.recipients_list = new ArrayList<>(elements);
/* 2557 */       return this;
/*      */     }
/*      */     
/*      */     public Builder recipients(Iterable<UserData> elements) {
/* 2561 */       this.recipients_list = (List<UserData>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/* 2562 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("icon")
/*      */     public Builder icon(Possible<Optional<String>> value) {
/* 2567 */       this.icon_possible = value;
/* 2568 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public Builder icon(@Nullable String value) {
/* 2573 */       this.icon_possible = Possible.of(Optional.ofNullable(value));
/* 2574 */       return this;
/*      */     }
/*      */     
/*      */     public Builder iconOrNull(@Nullable String value) {
/* 2578 */       this.icon_possible = Possible.of(Optional.ofNullable(value));
/* 2579 */       return this;
/*      */     }
/*      */     
/*      */     public Builder ownerId(String value) {
/* 2583 */       this.ownerId_possible = Possible.of(Id.of(value));
/* 2584 */       return this;
/*      */     }
/*      */     
/*      */     public Builder ownerId(long value) {
/* 2588 */       this.ownerId_possible = Possible.of(Id.of(value));
/* 2589 */       return this;
/*      */     }
/*      */     
/*      */     public Builder ownerId(Id value) {
/* 2593 */       this.ownerId_possible = Possible.of(value);
/* 2594 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("owner_id")
/*      */     public Builder ownerId(Possible<Id> value) {
/* 2599 */       this.ownerId_possible = value;
/* 2600 */       return this;
/*      */     }
/*      */     
/*      */     public Builder applicationId(String value) {
/* 2604 */       this.applicationId_possible = Possible.of(Id.of(value));
/* 2605 */       return this;
/*      */     }
/*      */     
/*      */     public Builder applicationId(long value) {
/* 2609 */       this.applicationId_possible = Possible.of(Id.of(value));
/* 2610 */       return this;
/*      */     }
/*      */     
/*      */     public Builder applicationId(Id value) {
/* 2614 */       this.applicationId_possible = Possible.of(value);
/* 2615 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("application_id")
/*      */     public Builder applicationId(Possible<Id> value) {
/* 2620 */       this.applicationId_possible = value;
/* 2621 */       return this;
/*      */     }
/*      */     
/*      */     public Builder parentId(String value) {
/* 2625 */       this.parentId_possible = Possible.of(Optional.of(Id.of(value)));
/* 2626 */       return this;
/*      */     }
/*      */     
/*      */     public Builder parentId(long value) {
/* 2630 */       this.parentId_possible = Possible.of(Optional.of(Id.of(value)));
/* 2631 */       return this;
/*      */     }
/*      */     
/*      */     public Builder parentId(Id value) {
/* 2635 */       this.parentId_possible = Possible.of(Optional.of(value));
/* 2636 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("parent_id")
/*      */     public Builder parentId(Possible<Optional<Id>> value) {
/* 2641 */       this.parentId_possible = value;
/* 2642 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("last_pin_timestamp")
/*      */     public Builder lastPinTimestamp(Possible<Optional<String>> value) {
/* 2647 */       this.lastPinTimestamp_possible = value;
/* 2648 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public Builder lastPinTimestamp(@Nullable String value) {
/* 2653 */       this.lastPinTimestamp_possible = Possible.of(Optional.ofNullable(value));
/* 2654 */       return this;
/*      */     }
/*      */     
/*      */     public Builder lastPinTimestampOrNull(@Nullable String value) {
/* 2658 */       this.lastPinTimestamp_possible = Possible.of(Optional.ofNullable(value));
/* 2659 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("rtc_region")
/*      */     public Builder rtcRegion(Possible<Optional<String>> value) {
/* 2664 */       this.rtcRegion_possible = value;
/* 2665 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public Builder rtcRegion(@Nullable String value) {
/* 2670 */       this.rtcRegion_possible = Possible.of(Optional.ofNullable(value));
/* 2671 */       return this;
/*      */     }
/*      */     
/*      */     public Builder rtcRegionOrNull(@Nullable String value) {
/* 2675 */       this.rtcRegion_possible = Possible.of(Optional.ofNullable(value));
/* 2676 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("video_quality_mode")
/*      */     public Builder videoQualityMode(Possible<Integer> value) {
/* 2681 */       this.videoQualityMode_possible = value;
/* 2682 */       return this;
/*      */     }
/*      */     
/*      */     public Builder videoQualityMode(Integer value) {
/* 2686 */       this.videoQualityMode_possible = Possible.of(value);
/* 2687 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ImmutableChannelData build() {
/* 2696 */       if (this.initBits != 0L) {
/* 2697 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*      */       }
/* 2699 */       return new ImmutableChannelData(null, 
/*      */           
/* 2701 */           id_build(), this.type, 
/*      */           
/* 2703 */           guildId_build(), 
/* 2704 */           position_build(), 
/* 2705 */           permissionOverwrites_build(), 
/* 2706 */           name_build(), 
/* 2707 */           topic_build(), 
/* 2708 */           nsfw_build(), 
/* 2709 */           lastMessageId_build(), 
/* 2710 */           bitrate_build(), 
/* 2711 */           userLimit_build(), 
/* 2712 */           rateLimitPerUser_build(), 
/* 2713 */           recipients_build(), 
/* 2714 */           icon_build(), 
/* 2715 */           ownerId_build(), 
/* 2716 */           applicationId_build(), 
/* 2717 */           parentId_build(), 
/* 2718 */           lastPinTimestamp_build(), 
/* 2719 */           rtcRegion_build(), 
/* 2720 */           videoQualityMode_build());
/*      */     }
/*      */     
/*      */     private String formatRequiredAttributesMessage() {
/* 2724 */       List<String> attributes = new ArrayList<>();
/* 2725 */       if ((this.initBits & 0x1L) != 0L) attributes.add("type"); 
/* 2726 */       return "Cannot build ChannelData, some of required attributes are not set " + attributes;
/*      */     }
/*      */     
/*      */     private Id id_build() {
/* 2730 */       return this.id_id;
/*      */     }
/*      */     
/*      */     private Possible<Id> guildId_build() {
/* 2734 */       return this.guildId_possible;
/*      */     }
/*      */     
/*      */     private Possible<Integer> position_build() {
/* 2738 */       return this.position_possible;
/*      */     }
/*      */     
/*      */     private Possible<List<OverwriteData>> permissionOverwrites_build() {
/* 2742 */       return (this.permissionOverwrites_list == null) ? Possible.absent() : 
/* 2743 */         Possible.of(this.permissionOverwrites_list);
/*      */     }
/*      */     
/*      */     private List<OverwriteData> permissionOverwrites_getOrCreate() {
/* 2747 */       if (this.permissionOverwrites_list == null) {
/* 2748 */         this.permissionOverwrites_list = new ArrayList<>();
/*      */       }
/* 2750 */       return this.permissionOverwrites_list;
/*      */     }
/*      */     
/*      */     private Possible<String> name_build() {
/* 2754 */       return this.name_possible;
/*      */     }
/*      */     
/*      */     private Possible<Optional<String>> topic_build() {
/* 2758 */       return this.topic_possible;
/*      */     }
/*      */     
/*      */     private Possible<Boolean> nsfw_build() {
/* 2762 */       return this.nsfw_possible;
/*      */     }
/*      */     
/*      */     private Possible<Optional<Id>> lastMessageId_build() {
/* 2766 */       return this.lastMessageId_possible;
/*      */     }
/*      */     
/*      */     private Possible<Integer> bitrate_build() {
/* 2770 */       return this.bitrate_possible;
/*      */     }
/*      */     
/*      */     private Possible<Integer> userLimit_build() {
/* 2774 */       return this.userLimit_possible;
/*      */     }
/*      */     
/*      */     private Possible<Integer> rateLimitPerUser_build() {
/* 2778 */       return this.rateLimitPerUser_possible;
/*      */     }
/*      */     
/*      */     private Possible<List<UserData>> recipients_build() {
/* 2782 */       return (this.recipients_list == null) ? Possible.absent() : 
/* 2783 */         Possible.of(this.recipients_list);
/*      */     }
/*      */     
/*      */     private List<UserData> recipients_getOrCreate() {
/* 2787 */       if (this.recipients_list == null) {
/* 2788 */         this.recipients_list = new ArrayList<>();
/*      */       }
/* 2790 */       return this.recipients_list;
/*      */     }
/*      */     
/*      */     private Possible<Optional<String>> icon_build() {
/* 2794 */       return this.icon_possible;
/*      */     }
/*      */     
/*      */     private Possible<Id> ownerId_build() {
/* 2798 */       return this.ownerId_possible;
/*      */     }
/*      */     
/*      */     private Possible<Id> applicationId_build() {
/* 2802 */       return this.applicationId_possible;
/*      */     }
/*      */     
/*      */     private Possible<Optional<Id>> parentId_build() {
/* 2806 */       return this.parentId_possible;
/*      */     }
/*      */     
/*      */     private Possible<Optional<String>> lastPinTimestamp_build() {
/* 2810 */       return this.lastPinTimestamp_possible;
/*      */     }
/*      */     
/*      */     private Possible<Optional<String>> rtcRegion_build() {
/* 2814 */       return this.rtcRegion_possible;
/*      */     }
/*      */     
/*      */     private Possible<Integer> videoQualityMode_build() {
/* 2818 */       return this.videoQualityMode_possible;
/*      */     }
/*      */     
/*      */     private Builder() {}
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableChannelData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */