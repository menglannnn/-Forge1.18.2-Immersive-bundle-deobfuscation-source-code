/*      */ package discord4j.discordjson.json;
/*      */ 
/*      */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*      */ import com.fasterxml.jackson.annotation.JsonCreator;
/*      */ import com.fasterxml.jackson.annotation.JsonProperty;
/*      */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*      */ import discord4j.discordjson.Id;
/*      */ import discord4j.discordjson.possible.Possible;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.List;
/*      */ import java.util.Objects;
/*      */ import java.util.stream.Collectors;
/*      */ import java.util.stream.StreamSupport;
/*      */ import org.immutables.value.Generated;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ @Generated(from = "AutoModRuleCreateRequest", generator = "Immutables")
/*      */ public final class ImmutableAutoModRuleCreateRequest
/*      */   implements AutoModRuleCreateRequest
/*      */ {
/*      */   private final String name;
/*      */   private final int eventType;
/*      */   private final int triggerType;
/*      */   private final AutoModTriggerMetaData triggerMetadata_value;
/*      */   private final boolean triggerMetadata_absent;
/*      */   private final List<AutoModActionData> actions;
/*      */   private final Boolean enabled_value;
/*      */   private final boolean enabled_absent;
/*      */   private final List<Id> exemptRoles_value;
/*      */   private final boolean exemptRoles_absent;
/*      */   private final List<Id> exemptChannels_value;
/*      */   private final boolean exemptChannels_absent;
/*      */   private static final byte STAGE_INITIALIZING = -1;
/*      */   private static final byte STAGE_UNINITIALIZED = 0;
/*      */   private static final byte STAGE_INITIALIZED = 1;
/*      */   private volatile transient InitShim initShim;
/*      */   
/*      */   private ImmutableAutoModRuleCreateRequest(String name, int eventType, int triggerType, Possible<AutoModTriggerMetaData> triggerMetadata, Iterable<? extends AutoModActionData> actions, Possible<Boolean> enabled, Possible<List<Id>> exemptRoles, Possible<List<Id>> exemptChannels) {
/*  105 */     this.initShim = new InitShim(); this.name = Objects.<String>requireNonNull(name, "name"); this.eventType = eventType; this.triggerType = triggerType; Possible<AutoModTriggerMetaData> triggerMetadata$impl = triggerMetadata; this.actions = createUnmodifiableList(false, createSafeList(actions, true, false)); Possible<Boolean> enabled$impl = enabled; Possible<List<Id>> exemptRoles$impl = exemptRoles; Possible<List<Id>> exemptChannels$impl = exemptChannels; this.triggerMetadata_value = triggerMetadata$impl.toOptional().orElse(null); this.triggerMetadata_absent = triggerMetadata$impl.isAbsent(); this.enabled_value = enabled$impl.toOptional().orElse(null); this.enabled_absent = enabled$impl.isAbsent(); this.exemptRoles_value = exemptRoles$impl.toOptional().orElse(null); this.exemptRoles_absent = exemptRoles$impl.isAbsent(); this.exemptChannels_value = exemptChannels$impl.toOptional().orElse(null); this.exemptChannels_absent = exemptChannels$impl.isAbsent(); this.initShim = null; } private ImmutableAutoModRuleCreateRequest(ImmutableAutoModRuleCreateRequest original, String name, int eventType, int triggerType, Possible<AutoModTriggerMetaData> triggerMetadata, List<AutoModActionData> actions, Possible<Boolean> enabled, Possible<List<Id>> exemptRoles, Possible<List<Id>> exemptChannels) { this.initShim = new InitShim(); this.name = name; this.eventType = eventType; this.triggerType = triggerType; Possible<AutoModTriggerMetaData> triggerMetadata$impl = triggerMetadata; this.actions = actions; Possible<Boolean> enabled$impl = enabled; Possible<List<Id>> exemptRoles$impl = exemptRoles; Possible<List<Id>> exemptChannels$impl = exemptChannels; this.triggerMetadata_value = triggerMetadata$impl.toOptional().orElse(null); this.triggerMetadata_absent = triggerMetadata$impl.isAbsent(); this.enabled_value = enabled$impl.toOptional().orElse(null); this.enabled_absent = enabled$impl.isAbsent();
/*      */     this.exemptRoles_value = exemptRoles$impl.toOptional().orElse(null);
/*      */     this.exemptRoles_absent = exemptRoles$impl.isAbsent();
/*      */     this.exemptChannels_value = exemptChannels$impl.toOptional().orElse(null);
/*      */     this.exemptChannels_absent = exemptChannels$impl.isAbsent();
/*  110 */     this.initShim = null; } @Generated(from = "AutoModRuleCreateRequest", generator = "Immutables") private final class InitShim { private InitShim() {} private String formatInitCycleMessage() { List<String> attributes = new ArrayList<>();
/*  111 */       return "Cannot build AutoModRuleCreateRequest, attribute initializers form cycle " + attributes; }
/*      */      }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("name")
/*      */   public String name() {
/*  121 */     return this.name;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("event_type")
/*      */   public int eventType() {
/*  130 */     return this.eventType;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("trigger_type")
/*      */   public int triggerType() {
/*  139 */     return this.triggerType;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("trigger_metadata")
/*      */   public Possible<AutoModTriggerMetaData> triggerMetadata() {
/*  148 */     return this.triggerMetadata_absent ? Possible.absent() : Possible.of(this.triggerMetadata_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("actions")
/*      */   public List<AutoModActionData> actions() {
/*  157 */     return this.actions;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("enabled")
/*      */   public Possible<Boolean> enabled() {
/*  166 */     return this.enabled_absent ? Possible.absent() : Possible.of(this.enabled_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("exempt_roles")
/*      */   public Possible<List<Id>> exemptRoles() {
/*  175 */     return this.exemptRoles_absent ? Possible.absent() : 
/*  176 */       Possible.of(this.exemptRoles_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("exempt_channels")
/*      */   public Possible<List<Id>> exemptChannels() {
/*  185 */     return this.exemptChannels_absent ? Possible.absent() : 
/*  186 */       Possible.of(this.exemptChannels_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableAutoModRuleCreateRequest withName(String value) {
/*  196 */     String newValue = Objects.<String>requireNonNull(value, "name");
/*  197 */     if (this.name.equals(newValue)) return this; 
/*  198 */     return new ImmutableAutoModRuleCreateRequest(this, newValue, this.eventType, this.triggerType, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  203 */         triggerMetadata(), this.actions, 
/*      */         
/*  205 */         enabled(), 
/*  206 */         exemptRoles(), 
/*  207 */         exemptChannels());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableAutoModRuleCreateRequest withEventType(int value) {
/*  217 */     if (this.eventType == value) return this; 
/*  218 */     return new ImmutableAutoModRuleCreateRequest(this, this.name, value, this.triggerType, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  223 */         triggerMetadata(), this.actions, 
/*      */         
/*  225 */         enabled(), 
/*  226 */         exemptRoles(), 
/*  227 */         exemptChannels());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableAutoModRuleCreateRequest withTriggerType(int value) {
/*  237 */     if (this.triggerType == value) return this; 
/*  238 */     return new ImmutableAutoModRuleCreateRequest(this, this.name, this.eventType, value, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  243 */         triggerMetadata(), this.actions, 
/*      */         
/*  245 */         enabled(), 
/*  246 */         exemptRoles(), 
/*  247 */         exemptChannels());
/*      */   }
/*      */   
/*      */   public ImmutableAutoModRuleCreateRequest withTriggerMetadata(Possible<AutoModTriggerMetaData> value) {
/*  251 */     Possible<AutoModTriggerMetaData> newValue = Objects.<Possible<AutoModTriggerMetaData>>requireNonNull(value);
/*  252 */     return new ImmutableAutoModRuleCreateRequest(this, this.name, this.eventType, this.triggerType, newValue, this.actions, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  259 */         enabled(), 
/*  260 */         exemptRoles(), 
/*  261 */         exemptChannels());
/*      */   }
/*      */   
/*      */   public ImmutableAutoModRuleCreateRequest withTriggerMetadata(AutoModTriggerMetaData value) {
/*  265 */     Possible<AutoModTriggerMetaData> newValue = Possible.of(value);
/*  266 */     return new ImmutableAutoModRuleCreateRequest(this, this.name, this.eventType, this.triggerType, newValue, this.actions, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  273 */         enabled(), 
/*  274 */         exemptRoles(), 
/*  275 */         exemptChannels());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableAutoModRuleCreateRequest withActions(AutoModActionData... elements) {
/*  284 */     List<AutoModActionData> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/*  285 */     return new ImmutableAutoModRuleCreateRequest(this, this.name, this.eventType, this.triggerType, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  290 */         triggerMetadata(), newValue, 
/*      */         
/*  292 */         enabled(), 
/*  293 */         exemptRoles(), 
/*  294 */         exemptChannels());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableAutoModRuleCreateRequest withActions(Iterable<? extends AutoModActionData> elements) {
/*  304 */     if (this.actions == elements) return this; 
/*  305 */     List<AutoModActionData> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/*  306 */     return new ImmutableAutoModRuleCreateRequest(this, this.name, this.eventType, this.triggerType, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  311 */         triggerMetadata(), newValue, 
/*      */         
/*  313 */         enabled(), 
/*  314 */         exemptRoles(), 
/*  315 */         exemptChannels());
/*      */   }
/*      */   
/*      */   public ImmutableAutoModRuleCreateRequest withEnabled(Possible<Boolean> value) {
/*  319 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/*  320 */     return new ImmutableAutoModRuleCreateRequest(this, this.name, this.eventType, this.triggerType, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  325 */         triggerMetadata(), this.actions, newValue, 
/*      */ 
/*      */         
/*  328 */         exemptRoles(), 
/*  329 */         exemptChannels());
/*      */   }
/*      */   
/*      */   public ImmutableAutoModRuleCreateRequest withEnabled(Boolean value) {
/*  333 */     Possible<Boolean> newValue = Possible.of(value);
/*  334 */     return new ImmutableAutoModRuleCreateRequest(this, this.name, this.eventType, this.triggerType, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  339 */         triggerMetadata(), this.actions, newValue, 
/*      */ 
/*      */         
/*  342 */         exemptRoles(), 
/*  343 */         exemptChannels());
/*      */   }
/*      */   
/*      */   public ImmutableAutoModRuleCreateRequest withExemptRoles(Possible<List<Id>> possible) {
/*  347 */     Possible<List<Id>> newValue = Objects.<Possible<List<Id>>>requireNonNull(possible);
/*  348 */     return new ImmutableAutoModRuleCreateRequest(this, this.name, this.eventType, this.triggerType, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  353 */         triggerMetadata(), this.actions, 
/*      */         
/*  355 */         enabled(), newValue, 
/*      */         
/*  357 */         exemptChannels());
/*      */   }
/*      */   
/*      */   public ImmutableAutoModRuleCreateRequest withExemptRoles(Iterable<Id> elements) {
/*  361 */     Possible<List<Id>> newValue = Possible.of(
/*  362 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/*  363 */     return new ImmutableAutoModRuleCreateRequest(this, this.name, this.eventType, this.triggerType, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  368 */         triggerMetadata(), this.actions, 
/*      */         
/*  370 */         enabled(), newValue, 
/*      */         
/*  372 */         exemptChannels());
/*      */   }
/*      */   
/*      */   @SafeVarargs
/*      */   public final ImmutableAutoModRuleCreateRequest withExemptRoles(Id... elements) {
/*  377 */     Possible<List<Id>> newValue = Possible.of(Arrays.asList(elements));
/*  378 */     return new ImmutableAutoModRuleCreateRequest(this, this.name, this.eventType, this.triggerType, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  383 */         triggerMetadata(), this.actions, 
/*      */         
/*  385 */         enabled(), newValue, 
/*      */         
/*  387 */         exemptChannels());
/*      */   }
/*      */   
/*      */   public ImmutableAutoModRuleCreateRequest withExemptChannels(Possible<List<Id>> possible) {
/*  391 */     Possible<List<Id>> newValue = Objects.<Possible<List<Id>>>requireNonNull(possible);
/*  392 */     return new ImmutableAutoModRuleCreateRequest(this, this.name, this.eventType, this.triggerType, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  397 */         triggerMetadata(), this.actions, 
/*      */         
/*  399 */         enabled(), 
/*  400 */         exemptRoles(), newValue);
/*      */   }
/*      */ 
/*      */   
/*      */   public ImmutableAutoModRuleCreateRequest withExemptChannels(Iterable<Id> elements) {
/*  405 */     Possible<List<Id>> newValue = Possible.of(
/*  406 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/*  407 */     return new ImmutableAutoModRuleCreateRequest(this, this.name, this.eventType, this.triggerType, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  412 */         triggerMetadata(), this.actions, 
/*      */         
/*  414 */         enabled(), 
/*  415 */         exemptRoles(), newValue);
/*      */   }
/*      */ 
/*      */   
/*      */   @SafeVarargs
/*      */   public final ImmutableAutoModRuleCreateRequest withExemptChannels(Id... elements) {
/*  421 */     Possible<List<Id>> newValue = Possible.of(Arrays.asList(elements));
/*  422 */     return new ImmutableAutoModRuleCreateRequest(this, this.name, this.eventType, this.triggerType, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  427 */         triggerMetadata(), this.actions, 
/*      */         
/*  429 */         enabled(), 
/*  430 */         exemptRoles(), newValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean equals(Object another) {
/*  440 */     if (this == another) return true; 
/*  441 */     return (another instanceof ImmutableAutoModRuleCreateRequest && 
/*  442 */       equalTo(0, (ImmutableAutoModRuleCreateRequest)another));
/*      */   }
/*      */   
/*      */   private boolean equalTo(int synthetic, ImmutableAutoModRuleCreateRequest another) {
/*  446 */     return (this.name.equals(another.name) && this.eventType == another.eventType && this.triggerType == another.triggerType && 
/*      */ 
/*      */       
/*  449 */       triggerMetadata().equals(another.triggerMetadata()) && this.actions
/*  450 */       .equals(another.actions) && 
/*  451 */       enabled().equals(another.enabled()) && 
/*  452 */       Objects.equals(this.exemptRoles_value, another.exemptRoles_value) && 
/*  453 */       Objects.equals(this.exemptChannels_value, another.exemptChannels_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int hashCode() {
/*  462 */     int h = 5381;
/*  463 */     h += (h << 5) + this.name.hashCode();
/*  464 */     h += (h << 5) + this.eventType;
/*  465 */     h += (h << 5) + this.triggerType;
/*  466 */     h += (h << 5) + triggerMetadata().hashCode();
/*  467 */     h += (h << 5) + this.actions.hashCode();
/*  468 */     h += (h << 5) + enabled().hashCode();
/*  469 */     h += (h << 5) + Objects.hashCode(this.exemptRoles_value);
/*  470 */     h += (h << 5) + Objects.hashCode(this.exemptChannels_value);
/*  471 */     return h;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/*  480 */     return "AutoModRuleCreateRequest{name=" + this.name + ", eventType=" + this.eventType + ", triggerType=" + this.triggerType + ", triggerMetadata=" + 
/*      */ 
/*      */ 
/*      */       
/*  484 */       triggerMetadata().toString() + ", actions=" + this.actions + ", enabled=" + 
/*      */       
/*  486 */       enabled().toString() + ", exemptRoles=" + 
/*  487 */       Objects.toString(this.exemptRoles_value) + ", exemptChannels=" + 
/*  488 */       Objects.toString(this.exemptChannels_value) + "}";
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonDeserialize
/*      */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*      */   @Generated(from = "AutoModRuleCreateRequest", generator = "Immutables")
/*      */   static final class Json
/*      */     implements AutoModRuleCreateRequest
/*      */   {
/*      */     String name;
/*      */     
/*      */     int eventType;
/*      */     
/*      */     boolean eventTypeIsSet;
/*      */     
/*      */     int triggerType;
/*      */     boolean triggerTypeIsSet;
/*  507 */     Possible<AutoModTriggerMetaData> triggerMetadata = Possible.absent();
/*      */     
/*  509 */     List<AutoModActionData> actions = Collections.emptyList();
/*      */     
/*  511 */     Possible<Boolean> enabled = Possible.absent();
/*      */ 
/*      */     
/*  514 */     Possible<List<Id>> exemptRoles = Possible.absent();
/*      */ 
/*      */     
/*  517 */     Possible<List<Id>> exemptChannels = Possible.absent();
/*      */     
/*      */     @JsonProperty("name")
/*      */     public void setName(String name) {
/*  521 */       this.name = name;
/*      */     }
/*      */     @JsonProperty("event_type")
/*      */     public void setEventType(int eventType) {
/*  525 */       this.eventType = eventType;
/*  526 */       this.eventTypeIsSet = true;
/*      */     }
/*      */     @JsonProperty("trigger_type")
/*      */     public void setTriggerType(int triggerType) {
/*  530 */       this.triggerType = triggerType;
/*  531 */       this.triggerTypeIsSet = true;
/*      */     }
/*      */     @JsonProperty("trigger_metadata")
/*      */     public void setTriggerMetadata(Possible<AutoModTriggerMetaData> triggerMetadata) {
/*  535 */       this.triggerMetadata = triggerMetadata;
/*      */     }
/*      */     @JsonProperty("actions")
/*      */     public void setActions(List<AutoModActionData> actions) {
/*  539 */       this.actions = actions;
/*      */     }
/*      */     @JsonProperty("enabled")
/*      */     public void setEnabled(Possible<Boolean> enabled) {
/*  543 */       this.enabled = enabled;
/*      */     }
/*      */     @JsonProperty("exempt_roles")
/*      */     public void setExemptRoles(Possible<List<Id>> exemptRoles) {
/*  547 */       this.exemptRoles = exemptRoles;
/*      */     }
/*      */     @JsonProperty("exempt_channels")
/*      */     public void setExemptChannels(Possible<List<Id>> exemptChannels) {
/*  551 */       this.exemptChannels = exemptChannels;
/*      */     }
/*      */     public String name() {
/*  554 */       throw new UnsupportedOperationException();
/*      */     } public int eventType() {
/*  556 */       throw new UnsupportedOperationException();
/*      */     } public int triggerType() {
/*  558 */       throw new UnsupportedOperationException();
/*      */     } public Possible<AutoModTriggerMetaData> triggerMetadata() {
/*  560 */       throw new UnsupportedOperationException();
/*      */     } public List<AutoModActionData> actions() {
/*  562 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Boolean> enabled() {
/*  564 */       throw new UnsupportedOperationException();
/*      */     } public Possible<List<Id>> exemptRoles() {
/*  566 */       throw new UnsupportedOperationException();
/*      */     } public Possible<List<Id>> exemptChannels() {
/*  568 */       throw new UnsupportedOperationException();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*      */   static ImmutableAutoModRuleCreateRequest fromJson(Json json) {
/*  579 */     Builder builder = builder();
/*  580 */     if (json.name != null) {
/*  581 */       builder.name(json.name);
/*      */     }
/*  583 */     if (json.eventTypeIsSet) {
/*  584 */       builder.eventType(json.eventType);
/*      */     }
/*  586 */     if (json.triggerTypeIsSet) {
/*  587 */       builder.triggerType(json.triggerType);
/*      */     }
/*  589 */     if (json.triggerMetadata != null) {
/*  590 */       builder.triggerMetadata(json.triggerMetadata);
/*      */     }
/*  592 */     if (json.actions != null) {
/*  593 */       builder.addAllActions(json.actions);
/*      */     }
/*  595 */     if (json.enabled != null) {
/*  596 */       builder.enabled(json.enabled);
/*      */     }
/*  598 */     if (json.exemptRoles != null) {
/*  599 */       builder.exemptRoles(json.exemptRoles);
/*      */     }
/*  601 */     if (json.exemptChannels != null) {
/*  602 */       builder.exemptChannels(json.exemptChannels);
/*      */     }
/*  604 */     return builder.build();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableAutoModRuleCreateRequest of(String name, int eventType, int triggerType, Possible<AutoModTriggerMetaData> triggerMetadata, List<AutoModActionData> actions, Possible<Boolean> enabled, Possible<List<Id>> exemptRoles, Possible<List<Id>> exemptChannels) {
/*  620 */     return of(name, eventType, triggerType, triggerMetadata, actions, enabled, exemptRoles, exemptChannels);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableAutoModRuleCreateRequest of(String name, int eventType, int triggerType, Possible<AutoModTriggerMetaData> triggerMetadata, Iterable<? extends AutoModActionData> actions, Possible<Boolean> enabled, Possible<List<Id>> exemptRoles, Possible<List<Id>> exemptChannels) {
/*  636 */     return new ImmutableAutoModRuleCreateRequest(name, eventType, triggerType, triggerMetadata, actions, enabled, exemptRoles, exemptChannels);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableAutoModRuleCreateRequest copyOf(AutoModRuleCreateRequest instance) {
/*  647 */     if (instance instanceof ImmutableAutoModRuleCreateRequest) {
/*  648 */       return (ImmutableAutoModRuleCreateRequest)instance;
/*      */     }
/*  650 */     return builder()
/*  651 */       .from(instance)
/*  652 */       .build();
/*      */   }
/*      */   
/*      */   public boolean isTriggerMetadataPresent() {
/*  656 */     return !this.triggerMetadata_absent;
/*      */   }
/*      */   
/*      */   public AutoModTriggerMetaData triggerMetadataOrElse(AutoModTriggerMetaData defaultValue) {
/*  660 */     return !this.triggerMetadata_absent ? this.triggerMetadata_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isEnabledPresent() {
/*  664 */     return !this.enabled_absent;
/*      */   }
/*      */   
/*      */   public Boolean enabledOrElse(Boolean defaultValue) {
/*  668 */     return !this.enabled_absent ? this.enabled_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isExemptRolesPresent() {
/*  672 */     return !this.exemptRoles_absent;
/*      */   }
/*      */   
/*      */   public List<Id> exemptRolesOrElse(List<Id> defaultValue) {
/*  676 */     return !this.exemptRoles_absent ? this.exemptRoles_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isExemptChannelsPresent() {
/*  680 */     return !this.exemptChannels_absent;
/*      */   }
/*      */   
/*      */   public List<Id> exemptChannelsOrElse(List<Id> defaultValue) {
/*  684 */     return !this.exemptChannels_absent ? this.exemptChannels_value : defaultValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Builder builder() {
/*  704 */     return new Builder();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   @Generated(from = "AutoModRuleCreateRequest", generator = "Immutables")
/*      */   public static final class Builder
/*      */   {
/*      */     private static final long INIT_BIT_NAME = 1L;
/*      */ 
/*      */     
/*      */     private static final long INIT_BIT_EVENT_TYPE = 2L;
/*      */     
/*      */     private static final long INIT_BIT_TRIGGER_TYPE = 4L;
/*      */     
/*  719 */     private long initBits = 7L;
/*      */     
/*  721 */     private Possible<AutoModTriggerMetaData> triggerMetadata_possible = Possible.absent();
/*  722 */     private Possible<Boolean> enabled_possible = Possible.absent();
/*  723 */     private List<Id> exemptRoles_list = null;
/*  724 */     private List<Id> exemptChannels_list = null;
/*      */     private String name;
/*      */     private int eventType;
/*      */     private int triggerType;
/*  728 */     private List<AutoModActionData> actions = new ArrayList<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder from(AutoModRuleCreateRequest instance) {
/*  742 */       Objects.requireNonNull(instance, "instance");
/*  743 */       name(instance.name());
/*  744 */       eventType(instance.eventType());
/*  745 */       triggerType(instance.triggerType());
/*  746 */       triggerMetadata(instance.triggerMetadata());
/*  747 */       addAllActions(instance.actions());
/*  748 */       enabled(instance.enabled());
/*  749 */       exemptRoles(instance.exemptRoles());
/*  750 */       exemptChannels(instance.exemptChannels());
/*  751 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("name")
/*      */     public final Builder name(String name) {
/*  761 */       this.name = Objects.<String>requireNonNull(name, "name");
/*  762 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/*  763 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("event_type")
/*      */     public final Builder eventType(int eventType) {
/*  773 */       this.eventType = eventType;
/*  774 */       this.initBits &= 0xFFFFFFFFFFFFFFFDL;
/*  775 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("trigger_type")
/*      */     public final Builder triggerType(int triggerType) {
/*  785 */       this.triggerType = triggerType;
/*  786 */       this.initBits &= 0xFFFFFFFFFFFFFFFBL;
/*  787 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("trigger_metadata")
/*      */     public Builder triggerMetadata(Possible<AutoModTriggerMetaData> value) {
/*  792 */       this.triggerMetadata_possible = value;
/*  793 */       return this;
/*      */     }
/*      */     
/*      */     public Builder triggerMetadata(AutoModTriggerMetaData value) {
/*  797 */       this.triggerMetadata_possible = Possible.of(value);
/*  798 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addAction(AutoModActionData element) {
/*  807 */       this.actions.add(Objects.<AutoModActionData>requireNonNull(element, "actions element"));
/*  808 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addActions(AutoModActionData... elements) {
/*  817 */       for (AutoModActionData element : elements) {
/*  818 */         this.actions.add(Objects.<AutoModActionData>requireNonNull(element, "actions element"));
/*      */       }
/*  820 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("actions")
/*      */     public final Builder actions(Iterable<? extends AutoModActionData> elements) {
/*  831 */       this.actions.clear();
/*  832 */       return addAllActions(elements);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addAllActions(Iterable<? extends AutoModActionData> elements) {
/*  841 */       for (AutoModActionData element : elements) {
/*  842 */         this.actions.add(Objects.<AutoModActionData>requireNonNull(element, "actions element"));
/*      */       }
/*  844 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("enabled")
/*      */     public Builder enabled(Possible<Boolean> value) {
/*  849 */       this.enabled_possible = value;
/*  850 */       return this;
/*      */     }
/*      */     
/*      */     public Builder enabled(Boolean value) {
/*  854 */       this.enabled_possible = Possible.of(value);
/*  855 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addExemptRole(Id element) {
/*  859 */       exemptRoles_getOrCreate().add(element);
/*  860 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addAllExemptRoles(List<Id> elements) {
/*  864 */       exemptRoles_getOrCreate().addAll(elements);
/*  865 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("exempt_roles")
/*      */     public Builder exemptRoles(Possible<List<Id>> elements) {
/*  870 */       this.exemptRoles_list = null;
/*  871 */       elements.toOptional().ifPresent(e -> exemptRoles_getOrCreate().addAll(e));
/*  872 */       return this;
/*      */     }
/*      */     
/*      */     public Builder exemptRoles(List<Id> elements) {
/*  876 */       this.exemptRoles_list = new ArrayList<>(elements);
/*  877 */       return this;
/*      */     }
/*      */     
/*      */     public Builder exemptRoles(Iterable<Id> elements) {
/*  881 */       this.exemptRoles_list = (List<Id>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/*  882 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addExemptChannel(Id element) {
/*  886 */       exemptChannels_getOrCreate().add(element);
/*  887 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addAllExemptChannels(List<Id> elements) {
/*  891 */       exemptChannels_getOrCreate().addAll(elements);
/*  892 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("exempt_channels")
/*      */     public Builder exemptChannels(Possible<List<Id>> elements) {
/*  897 */       this.exemptChannels_list = null;
/*  898 */       elements.toOptional().ifPresent(e -> exemptChannels_getOrCreate().addAll(e));
/*  899 */       return this;
/*      */     }
/*      */     
/*      */     public Builder exemptChannels(List<Id> elements) {
/*  903 */       this.exemptChannels_list = new ArrayList<>(elements);
/*  904 */       return this;
/*      */     }
/*      */     
/*      */     public Builder exemptChannels(Iterable<Id> elements) {
/*  908 */       this.exemptChannels_list = (List<Id>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/*  909 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ImmutableAutoModRuleCreateRequest build() {
/*  918 */       if (this.initBits != 0L) {
/*  919 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*      */       }
/*  921 */       return new ImmutableAutoModRuleCreateRequest(null, this.name, this.eventType, this.triggerType, 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  926 */           triggerMetadata_build(), ImmutableAutoModRuleCreateRequest
/*  927 */           .createUnmodifiableList(true, (List)this.actions), 
/*  928 */           enabled_build(), 
/*  929 */           exemptRoles_build(), 
/*  930 */           exemptChannels_build());
/*      */     }
/*      */     
/*      */     private String formatRequiredAttributesMessage() {
/*  934 */       List<String> attributes = new ArrayList<>();
/*  935 */       if ((this.initBits & 0x1L) != 0L) attributes.add("name"); 
/*  936 */       if ((this.initBits & 0x2L) != 0L) attributes.add("eventType"); 
/*  937 */       if ((this.initBits & 0x4L) != 0L) attributes.add("triggerType"); 
/*  938 */       return "Cannot build AutoModRuleCreateRequest, some of required attributes are not set " + attributes;
/*      */     }
/*      */     
/*      */     private Possible<AutoModTriggerMetaData> triggerMetadata_build() {
/*  942 */       return this.triggerMetadata_possible;
/*      */     }
/*      */     
/*      */     private Possible<Boolean> enabled_build() {
/*  946 */       return this.enabled_possible;
/*      */     }
/*      */     
/*      */     private Possible<List<Id>> exemptRoles_build() {
/*  950 */       return (this.exemptRoles_list == null) ? Possible.absent() : 
/*  951 */         Possible.of(this.exemptRoles_list);
/*      */     }
/*      */     
/*      */     private List<Id> exemptRoles_getOrCreate() {
/*  955 */       if (this.exemptRoles_list == null) {
/*  956 */         this.exemptRoles_list = new ArrayList<>();
/*      */       }
/*  958 */       return this.exemptRoles_list;
/*      */     }
/*      */     
/*      */     private Possible<List<Id>> exemptChannels_build() {
/*  962 */       return (this.exemptChannels_list == null) ? Possible.absent() : 
/*  963 */         Possible.of(this.exemptChannels_list);
/*      */     }
/*      */     
/*      */     private List<Id> exemptChannels_getOrCreate() {
/*  967 */       if (this.exemptChannels_list == null) {
/*  968 */         this.exemptChannels_list = new ArrayList<>();
/*      */       }
/*  970 */       return this.exemptChannels_list;
/*      */     }
/*      */     private Builder() {} }
/*      */   
/*      */   private static <T> List<T> createSafeList(Iterable<? extends T> iterable, boolean checkNulls, boolean skipNulls) {
/*      */     ArrayList<T> list;
/*  976 */     if (iterable instanceof Collection) {
/*  977 */       int size = ((Collection)iterable).size();
/*  978 */       if (size == 0) return Collections.emptyList(); 
/*  979 */       list = new ArrayList<>();
/*      */     } else {
/*  981 */       list = new ArrayList<>();
/*      */     } 
/*  983 */     for (T element : iterable) {
/*  984 */       if (skipNulls && element == null)
/*  985 */         continue;  if (checkNulls) Objects.requireNonNull(element, "element"); 
/*  986 */       list.add(element);
/*      */     } 
/*  988 */     return list;
/*      */   }
/*      */   
/*      */   private static <T> List<T> createUnmodifiableList(boolean clone, List<T> list) {
/*  992 */     switch (list.size()) { case 0:
/*  993 */         return Collections.emptyList();
/*  994 */       case 1: return Collections.singletonList(list.get(0)); }
/*      */     
/*  996 */     if (clone) {
/*  997 */       return Collections.unmodifiableList(new ArrayList<>(list));
/*      */     }
/*  999 */     if (list instanceof ArrayList) {
/* 1000 */       ((ArrayList)list).trimToSize();
/*      */     }
/* 1002 */     return Collections.unmodifiableList(list);
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableAutoModRuleCreateRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */