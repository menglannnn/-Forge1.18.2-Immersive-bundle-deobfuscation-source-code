/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.Id;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.stream.LongStream;
/*     */ import java.util.stream.StreamSupport;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "OnboardingData", generator = "Immutables")
/*     */ public final class ImmutableOnboardingData
/*     */   implements OnboardingData
/*     */ {
/*     */   private final long guildId_value;
/*     */   private final List<OnboardingPromptData> prompts;
/*     */   private final long[] defaultChannelIds_value;
/*     */   private final boolean enabled;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   
/*     */   private ImmutableOnboardingData(Id guildId, Iterable<? extends OnboardingPromptData> prompts, List<Id> defaultChannelIds, boolean enabled) {
/*  41 */     Id guildId$impl = guildId;
/*  42 */     this.prompts = createUnmodifiableList(false, createSafeList(prompts, true, false));
/*  43 */     List<Id> defaultChannelIds$impl = defaultChannelIds;
/*  44 */     this.enabled = enabled;
/*  45 */     this.guildId_value = guildId$impl.asLong();
/*  46 */     this
/*     */       
/*  48 */       .defaultChannelIds_value = defaultChannelIds$impl.stream().mapToLong(Id::asLong).toArray();
/*  49 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ImmutableOnboardingData(ImmutableOnboardingData original, Id guildId, List<OnboardingPromptData> prompts, List<Id> defaultChannelIds, boolean enabled) {
/*  58 */     Id guildId$impl = guildId;
/*  59 */     this.prompts = prompts;
/*  60 */     List<Id> defaultChannelIds$impl = defaultChannelIds;
/*  61 */     this.enabled = enabled;
/*  62 */     this.guildId_value = guildId$impl.asLong();
/*  63 */     this
/*     */       
/*  65 */       .defaultChannelIds_value = defaultChannelIds$impl.stream().mapToLong(Id::asLong).toArray();
/*  66 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  72 */   private volatile transient InitShim initShim = new InitShim();
/*     */   
/*     */   @Generated(from = "OnboardingData", generator = "Immutables")
/*     */   private final class InitShim {
/*     */     private String formatInitCycleMessage() {
/*  77 */       List<String> attributes = new ArrayList<>();
/*  78 */       return "Cannot build OnboardingData, attribute initializers form cycle " + attributes;
/*     */     }
/*     */ 
/*     */     
/*     */     private InitShim() {}
/*     */   }
/*     */ 
/*     */   
/*     */   @JsonProperty("guild_id")
/*     */   public Id guildId() {
/*  88 */     return Id.of(this.guildId_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("prompts")
/*     */   public List<OnboardingPromptData> prompts() {
/*  97 */     return this.prompts;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("default_channel_ids")
/*     */   public List<Id> defaultChannelIds() {
/* 106 */     return (List<Id>)LongStream.of(this.defaultChannelIds_value)
/* 107 */       .mapToObj(Id::of)
/* 108 */       .collect(Collectors.toList());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("enabled")
/*     */   public boolean enabled() {
/* 117 */     return this.enabled;
/*     */   }
/*     */   
/*     */   public ImmutableOnboardingData withGuildId(long value) {
/* 121 */     Id newValue = Id.of(value);
/* 122 */     return new ImmutableOnboardingData(this, newValue, this.prompts, defaultChannelIds(), this.enabled);
/*     */   }
/*     */   
/*     */   public ImmutableOnboardingData withGuildId(String value) {
/* 126 */     Id newValue = Id.of(value);
/* 127 */     return new ImmutableOnboardingData(this, newValue, this.prompts, defaultChannelIds(), this.enabled);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableOnboardingData withPrompts(OnboardingPromptData... elements) {
/* 136 */     List<OnboardingPromptData> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/* 137 */     return new ImmutableOnboardingData(this, guildId(), newValue, defaultChannelIds(), this.enabled);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableOnboardingData withPrompts(Iterable<? extends OnboardingPromptData> elements) {
/* 147 */     if (this.prompts == elements) return this; 
/* 148 */     List<OnboardingPromptData> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/* 149 */     return new ImmutableOnboardingData(this, guildId(), newValue, defaultChannelIds(), this.enabled);
/*     */   }
/*     */   
/*     */   public ImmutableOnboardingData withDefaultChannelIds(List<Id> value) {
/* 153 */     List<Id> newValue = value;
/* 154 */     return new ImmutableOnboardingData(this, guildId(), this.prompts, newValue, this.enabled);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableOnboardingData withEnabled(boolean value) {
/* 164 */     if (this.enabled == value) return this; 
/* 165 */     return new ImmutableOnboardingData(this, guildId(), this.prompts, defaultChannelIds(), value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 174 */     if (this == another) return true; 
/* 175 */     return (another instanceof ImmutableOnboardingData && 
/* 176 */       equalTo(0, (ImmutableOnboardingData)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableOnboardingData another) {
/* 180 */     return (Objects.equals(Long.valueOf(this.guildId_value), Long.valueOf(another.guildId_value)) && this.prompts
/* 181 */       .equals(another.prompts) && 
/* 182 */       Objects.equals(this.defaultChannelIds_value, another.defaultChannelIds_value) && this.enabled == another.enabled);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 192 */     int h = 5381;
/* 193 */     h += (h << 5) + Objects.hashCode(Long.valueOf(this.guildId_value));
/* 194 */     h += (h << 5) + this.prompts.hashCode();
/* 195 */     h += (h << 5) + Objects.hashCode(this.defaultChannelIds_value);
/* 196 */     h += (h << 5) + Boolean.hashCode(this.enabled);
/* 197 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 206 */     return "OnboardingData{guildId=" + 
/* 207 */       Objects.toString(Long.valueOf(this.guildId_value)) + ", prompts=" + this.prompts + ", defaultChannelIds=" + 
/*     */       
/* 209 */       Objects.toString(this.defaultChannelIds_value) + ", enabled=" + this.enabled + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "OnboardingData", generator = "Immutables")
/*     */   static final class Json
/*     */     implements OnboardingData
/*     */   {
/*     */     Id guildId;
/*     */ 
/*     */     
/* 224 */     List<OnboardingPromptData> prompts = Collections.emptyList(); List<Id> defaultChannelIds;
/*     */     boolean enabled;
/*     */     boolean enabledIsSet;
/*     */     
/*     */     @JsonProperty("guild_id")
/*     */     public void setGuildId(Id guildId) {
/* 230 */       this.guildId = guildId;
/*     */     }
/*     */     @JsonProperty("prompts")
/*     */     public void setPrompts(List<OnboardingPromptData> prompts) {
/* 234 */       this.prompts = prompts;
/*     */     }
/*     */     @JsonProperty("default_channel_ids")
/*     */     public void setDefaultChannelIds(List<Id> defaultChannelIds) {
/* 238 */       this.defaultChannelIds = defaultChannelIds;
/*     */     }
/*     */     @JsonProperty("enabled")
/*     */     public void setEnabled(boolean enabled) {
/* 242 */       this.enabled = enabled;
/* 243 */       this.enabledIsSet = true;
/*     */     }
/*     */     public Id guildId() {
/* 246 */       throw new UnsupportedOperationException();
/*     */     } public List<OnboardingPromptData> prompts() {
/* 248 */       throw new UnsupportedOperationException();
/*     */     } public List<Id> defaultChannelIds() {
/* 250 */       throw new UnsupportedOperationException();
/*     */     } public boolean enabled() {
/* 252 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableOnboardingData fromJson(Json json) {
/* 263 */     Builder builder = builder();
/* 264 */     if (json.guildId != null) {
/* 265 */       builder.guildId(json.guildId);
/*     */     }
/* 267 */     if (json.prompts != null) {
/* 268 */       builder.addAllPrompts(json.prompts);
/*     */     }
/* 270 */     if (json.defaultChannelIds != null) {
/* 271 */       builder.defaultChannelIds(json.defaultChannelIds);
/*     */     }
/* 273 */     if (json.enabledIsSet) {
/* 274 */       builder.enabled(json.enabled);
/*     */     }
/* 276 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableOnboardingData of(Id guildId, List<OnboardingPromptData> prompts, List<Id> defaultChannelIds, boolean enabled) {
/* 288 */     return of(guildId, prompts, defaultChannelIds, enabled);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableOnboardingData of(Id guildId, Iterable<? extends OnboardingPromptData> prompts, List<Id> defaultChannelIds, boolean enabled) {
/* 300 */     return new ImmutableOnboardingData(guildId, prompts, defaultChannelIds, enabled);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableOnboardingData copyOf(OnboardingData instance) {
/* 311 */     if (instance instanceof ImmutableOnboardingData) {
/* 312 */       return (ImmutableOnboardingData)instance;
/*     */     }
/* 314 */     return builder()
/* 315 */       .from(instance)
/* 316 */       .build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 332 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "OnboardingData", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_ENABLED = 1L;
/*     */ 
/*     */ 
/*     */     
/* 345 */     private long initBits = 1L;
/*     */     
/* 347 */     private Id guildId_id = null;
/* 348 */     private List<Long> defaultChannelIds_list = null;
/* 349 */     private List<OnboardingPromptData> prompts = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private boolean enabled;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(OnboardingData instance) {
/* 364 */       Objects.requireNonNull(instance, "instance");
/* 365 */       guildId(instance.guildId());
/* 366 */       addAllPrompts(instance.prompts());
/* 367 */       defaultChannelIds(instance.defaultChannelIds());
/* 368 */       enabled(instance.enabled());
/* 369 */       return this;
/*     */     }
/*     */     
/*     */     public Builder guildId(String value) {
/* 373 */       this.guildId_id = Id.of(value);
/* 374 */       return this;
/*     */     }
/*     */     
/*     */     public Builder guildId(long value) {
/* 378 */       this.guildId_id = Id.of(value);
/* 379 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("guild_id")
/*     */     public Builder guildId(Id value) {
/* 384 */       this.guildId_id = value;
/* 385 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder addPrompt(OnboardingPromptData element) {
/* 394 */       this.prompts.add(Objects.<OnboardingPromptData>requireNonNull(element, "prompts element"));
/* 395 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder addPrompts(OnboardingPromptData... elements) {
/* 404 */       for (OnboardingPromptData element : elements) {
/* 405 */         this.prompts.add(Objects.<OnboardingPromptData>requireNonNull(element, "prompts element"));
/*     */       }
/* 407 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("prompts")
/*     */     public final Builder prompts(Iterable<? extends OnboardingPromptData> elements) {
/* 418 */       this.prompts.clear();
/* 419 */       return addAllPrompts(elements);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder addAllPrompts(Iterable<? extends OnboardingPromptData> elements) {
/* 428 */       for (OnboardingPromptData element : elements) {
/* 429 */         this.prompts.add(Objects.<OnboardingPromptData>requireNonNull(element, "prompts element"));
/*     */       }
/* 431 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addDefaultChannelId(long element) {
/* 435 */       defaultChannelIds_getOrCreate().add(Long.valueOf(element));
/* 436 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addDefaultChannelId(String element) {
/* 440 */       defaultChannelIds_getOrCreate().add(Long.valueOf(Id.of(element).asLong()));
/* 441 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addDefaultChannelId(Id element) {
/* 445 */       defaultChannelIds_getOrCreate().add(Long.valueOf(element.asLong()));
/* 446 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addAllDefaultChannelIds(List<Long> elements) {
/* 450 */       defaultChannelIds_getOrCreate().addAll(elements);
/* 451 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("default_channel_ids")
/*     */     public Builder defaultChannelIds(List<Id> elements) {
/* 456 */       this.defaultChannelIds_list = (List<Long>)elements.stream().map(Id::asLong).collect(Collectors.toList());
/* 457 */       return this;
/*     */     }
/*     */     
/*     */     public Builder defaultChannelIds(Iterable<Id> elements) {
/* 461 */       this
/*     */         
/* 463 */         .defaultChannelIds_list = (List<Long>)StreamSupport.stream(elements.spliterator(), false).map(Id::asLong).collect(Collectors.toList());
/* 464 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("enabled")
/*     */     public final Builder enabled(boolean enabled) {
/* 474 */       this.enabled = enabled;
/* 475 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 476 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableOnboardingData build() {
/* 485 */       if (this.initBits != 0L) {
/* 486 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 488 */       return new ImmutableOnboardingData(null, 
/*     */           
/* 490 */           guildId_build(), ImmutableOnboardingData
/* 491 */           .createUnmodifiableList(true, (List)this.prompts), 
/* 492 */           defaultChannelIds_build(), this.enabled);
/*     */     }
/*     */ 
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 497 */       List<String> attributes = new ArrayList<>();
/* 498 */       if ((this.initBits & 0x1L) != 0L) attributes.add("enabled"); 
/* 499 */       return "Cannot build OnboardingData, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Id guildId_build() {
/* 503 */       return this.guildId_id;
/*     */     }
/*     */     
/*     */     private List<Id> defaultChannelIds_build() {
/* 507 */       return (List<Id>)defaultChannelIds_getOrCreate().stream().map(Id::of).collect(Collectors.toList());
/*     */     }
/*     */     
/*     */     private List<Long> defaultChannelIds_getOrCreate() {
/* 511 */       if (this.defaultChannelIds_list == null) {
/* 512 */         this.defaultChannelIds_list = new ArrayList<>();
/*     */       }
/* 514 */       return this.defaultChannelIds_list;
/*     */     }
/*     */     private Builder() {} }
/*     */   
/*     */   private static <T> List<T> createSafeList(Iterable<? extends T> iterable, boolean checkNulls, boolean skipNulls) {
/*     */     ArrayList<T> list;
/* 520 */     if (iterable instanceof Collection) {
/* 521 */       int size = ((Collection)iterable).size();
/* 522 */       if (size == 0) return Collections.emptyList(); 
/* 523 */       list = new ArrayList<>();
/*     */     } else {
/* 525 */       list = new ArrayList<>();
/*     */     } 
/* 527 */     for (T element : iterable) {
/* 528 */       if (skipNulls && element == null)
/* 529 */         continue;  if (checkNulls) Objects.requireNonNull(element, "element"); 
/* 530 */       list.add(element);
/*     */     } 
/* 532 */     return list;
/*     */   }
/*     */   
/*     */   private static <T> List<T> createUnmodifiableList(boolean clone, List<T> list) {
/* 536 */     switch (list.size()) { case 0:
/* 537 */         return Collections.emptyList();
/* 538 */       case 1: return Collections.singletonList(list.get(0)); }
/*     */     
/* 540 */     if (clone) {
/* 541 */       return Collections.unmodifiableList(new ArrayList<>(list));
/*     */     }
/* 543 */     if (list instanceof ArrayList) {
/* 544 */       ((ArrayList)list).trimToSize();
/*     */     }
/* 546 */     return Collections.unmodifiableList(list);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableOnboardingData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */