/*    */ package discord4j.discordjson.json;
/*    */ 
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import java.util.List;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ 
/*    */ @JsonSerialize(as = ImmutableGuildEmojiCreateRequest.class)
/*    */ @JsonDeserialize(as = ImmutableGuildEmojiCreateRequest.class)
/*    */ @Immutable
/*    */ public interface GuildEmojiCreateRequest
/*    */ {
/*    */   static ImmutableGuildEmojiCreateRequest.Builder builder() {
/* 15 */     return ImmutableGuildEmojiCreateRequest.builder();
/*    */   }
/*    */   
/*    */   String name();
/*    */   
/*    */   String image();
/*    */   
/*    */   List<String> roles();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\GuildEmojiCreateRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */