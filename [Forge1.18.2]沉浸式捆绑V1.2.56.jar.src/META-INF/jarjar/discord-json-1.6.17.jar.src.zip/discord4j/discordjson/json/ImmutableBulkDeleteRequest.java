/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "BulkDeleteRequest", generator = "Immutables")
/*     */ public final class ImmutableBulkDeleteRequest
/*     */   implements BulkDeleteRequest
/*     */ {
/*     */   private final List<String> messages;
/*     */   
/*     */   private ImmutableBulkDeleteRequest(Iterable<String> messages) {
/*  30 */     this.messages = createUnmodifiableList(false, createSafeList(messages, true, false));
/*     */   }
/*     */   
/*     */   private ImmutableBulkDeleteRequest(ImmutableBulkDeleteRequest original, List<String> messages) {
/*  34 */     this.messages = messages;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("messages")
/*     */   public List<String> messages() {
/*  43 */     return this.messages;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableBulkDeleteRequest withMessages(String... elements) {
/*  52 */     List<String> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/*  53 */     return new ImmutableBulkDeleteRequest(this, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableBulkDeleteRequest withMessages(Iterable<String> elements) {
/*  63 */     if (this.messages == elements) return this; 
/*  64 */     List<String> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/*  65 */     return new ImmutableBulkDeleteRequest(this, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/*  74 */     if (this == another) return true; 
/*  75 */     return (another instanceof ImmutableBulkDeleteRequest && 
/*  76 */       equalTo(0, (ImmutableBulkDeleteRequest)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableBulkDeleteRequest another) {
/*  80 */     return this.messages.equals(another.messages);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  89 */     int h = 5381;
/*  90 */     h += (h << 5) + this.messages.hashCode();
/*  91 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 100 */     return "BulkDeleteRequest{messages=" + this.messages + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "BulkDeleteRequest", generator = "Immutables")
/*     */   static final class Json
/*     */     implements BulkDeleteRequest
/*     */   {
/* 114 */     List<String> messages = Collections.emptyList();
/*     */     @JsonProperty("messages")
/*     */     public void setMessages(List<String> messages) {
/* 117 */       this.messages = messages;
/*     */     }
/*     */     public List<String> messages() {
/* 120 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableBulkDeleteRequest fromJson(Json json) {
/* 131 */     Builder builder = builder();
/* 132 */     if (json.messages != null) {
/* 133 */       builder.addAllMessages(json.messages);
/*     */     }
/* 135 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableBulkDeleteRequest of(List<String> messages) {
/* 144 */     return of(messages);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableBulkDeleteRequest of(Iterable<String> messages) {
/* 153 */     return new ImmutableBulkDeleteRequest(messages);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableBulkDeleteRequest copyOf(BulkDeleteRequest instance) {
/* 164 */     if (instance instanceof ImmutableBulkDeleteRequest) {
/* 165 */       return (ImmutableBulkDeleteRequest)instance;
/*     */     }
/* 167 */     return builder()
/* 168 */       .from(instance)
/* 169 */       .build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 182 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "BulkDeleteRequest", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/* 194 */     private List<String> messages = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(BulkDeleteRequest instance) {
/* 208 */       Objects.requireNonNull(instance, "instance");
/* 209 */       addAllMessages(instance.messages());
/* 210 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder addMessage(String element) {
/* 219 */       this.messages.add(Objects.<String>requireNonNull(element, "messages element"));
/* 220 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder addMessages(String... elements) {
/* 229 */       for (String element : elements) {
/* 230 */         this.messages.add(Objects.<String>requireNonNull(element, "messages element"));
/*     */       }
/* 232 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("messages")
/*     */     public final Builder messages(Iterable<String> elements) {
/* 243 */       this.messages.clear();
/* 244 */       return addAllMessages(elements);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder addAllMessages(Iterable<String> elements) {
/* 253 */       for (String element : elements) {
/* 254 */         this.messages.add(Objects.<String>requireNonNull(element, "messages element"));
/*     */       }
/* 256 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private Builder() {}
/*     */ 
/*     */     
/*     */     public ImmutableBulkDeleteRequest build() {
/* 265 */       return new ImmutableBulkDeleteRequest(null, ImmutableBulkDeleteRequest.createUnmodifiableList(true, (List)this.messages));
/*     */     }
/*     */   }
/*     */   
/*     */   private static <T> List<T> createSafeList(Iterable<? extends T> iterable, boolean checkNulls, boolean skipNulls) {
/*     */     ArrayList<T> list;
/* 271 */     if (iterable instanceof Collection) {
/* 272 */       int size = ((Collection)iterable).size();
/* 273 */       if (size == 0) return Collections.emptyList(); 
/* 274 */       list = new ArrayList<>();
/*     */     } else {
/* 276 */       list = new ArrayList<>();
/*     */     } 
/* 278 */     for (T element : iterable) {
/* 279 */       if (skipNulls && element == null)
/* 280 */         continue;  if (checkNulls) Objects.requireNonNull(element, "element"); 
/* 281 */       list.add(element);
/*     */     } 
/* 283 */     return list;
/*     */   }
/*     */   
/*     */   private static <T> List<T> createUnmodifiableList(boolean clone, List<T> list) {
/* 287 */     switch (list.size()) { case 0:
/* 288 */         return Collections.emptyList();
/* 289 */       case 1: return Collections.singletonList(list.get(0)); }
/*     */     
/* 291 */     if (clone) {
/* 292 */       return Collections.unmodifiableList(new ArrayList<>(list));
/*     */     }
/* 294 */     if (list instanceof ArrayList) {
/* 295 */       ((ArrayList)list).trimToSize();
/*     */     }
/* 297 */     return Collections.unmodifiableList(list);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableBulkDeleteRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */