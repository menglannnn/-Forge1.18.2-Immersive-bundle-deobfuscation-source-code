/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.stream.StreamSupport;
/*     */ import org.immutables.value.Generated;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "WebhookMessageEditRequest", generator = "Immutables")
/*     */ public final class ImmutableWebhookMessageEditRequest
/*     */   implements WebhookMessageEditRequest
/*     */ {
/*     */   private final String content_value;
/*     */   private final boolean content_absent;
/*     */   private final List<EmbedData> embeds_value;
/*     */   private final boolean embeds_absent;
/*     */   private final AllowedMentionsData allowedMentions_value;
/*     */   private final boolean allowedMentions_absent;
/*     */   private final List<AttachmentData> attachments_value;
/*     */   private final boolean attachments_absent;
/*     */   private final List<ComponentData> components_value;
/*     */   private final boolean components_absent;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   
/*     */   private ImmutableWebhookMessageEditRequest(Possible<Optional<String>> content, Possible<Optional<List<EmbedData>>> embeds, Possible<Optional<AllowedMentionsData>> allowedMentions, Possible<Optional<List<AttachmentData>>> attachments, Possible<List<ComponentData>> components) {
/*  45 */     Possible<Optional<String>> content$impl = content;
/*  46 */     Possible<Optional<List<EmbedData>>> embeds$impl = embeds;
/*  47 */     Possible<Optional<AllowedMentionsData>> allowedMentions$impl = allowedMentions;
/*  48 */     Possible<Optional<List<AttachmentData>>> attachments$impl = attachments;
/*  49 */     Possible<List<ComponentData>> components$impl = components;
/*  50 */     this.content_value = Possible.flatOpt(content$impl).orElse(null);
/*  51 */     this.content_absent = content$impl.isAbsent();
/*  52 */     this.embeds_value = Possible.flatOpt(embeds$impl).orElse(null);
/*  53 */     this.embeds_absent = embeds$impl.isAbsent();
/*  54 */     this.allowedMentions_value = Possible.flatOpt(allowedMentions$impl).orElse(null);
/*  55 */     this.allowedMentions_absent = allowedMentions$impl.isAbsent();
/*  56 */     this.attachments_value = Possible.flatOpt(attachments$impl).orElse(null);
/*  57 */     this.attachments_absent = attachments$impl.isAbsent();
/*  58 */     this.components_value = components$impl.toOptional().orElse(null);
/*  59 */     this.components_absent = components$impl.isAbsent();
/*  60 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ImmutableWebhookMessageEditRequest(ImmutableWebhookMessageEditRequest original, Possible<Optional<String>> content, Possible<Optional<List<EmbedData>>> embeds, Possible<Optional<AllowedMentionsData>> allowedMentions, Possible<Optional<List<AttachmentData>>> attachments, Possible<List<ComponentData>> components) {
/*  70 */     Possible<Optional<String>> content$impl = content;
/*  71 */     Possible<Optional<List<EmbedData>>> embeds$impl = embeds;
/*  72 */     Possible<Optional<AllowedMentionsData>> allowedMentions$impl = allowedMentions;
/*  73 */     Possible<Optional<List<AttachmentData>>> attachments$impl = attachments;
/*  74 */     Possible<List<ComponentData>> components$impl = components;
/*  75 */     this.content_value = Possible.flatOpt(content$impl).orElse(null);
/*  76 */     this.content_absent = content$impl.isAbsent();
/*  77 */     this.embeds_value = Possible.flatOpt(embeds$impl).orElse(null);
/*  78 */     this.embeds_absent = embeds$impl.isAbsent();
/*  79 */     this.allowedMentions_value = Possible.flatOpt(allowedMentions$impl).orElse(null);
/*  80 */     this.allowedMentions_absent = allowedMentions$impl.isAbsent();
/*  81 */     this.attachments_value = Possible.flatOpt(attachments$impl).orElse(null);
/*  82 */     this.attachments_absent = attachments$impl.isAbsent();
/*  83 */     this.components_value = components$impl.toOptional().orElse(null);
/*  84 */     this.components_absent = components$impl.isAbsent();
/*  85 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  91 */   private volatile transient InitShim initShim = new InitShim();
/*     */   
/*     */   @Generated(from = "WebhookMessageEditRequest", generator = "Immutables")
/*     */   private final class InitShim {
/*     */     private String formatInitCycleMessage() {
/*  96 */       List<String> attributes = new ArrayList<>();
/*  97 */       return "Cannot build WebhookMessageEditRequest, attribute initializers form cycle " + attributes;
/*     */     }
/*     */ 
/*     */     
/*     */     private InitShim() {}
/*     */   }
/*     */ 
/*     */   
/*     */   @JsonProperty("content")
/*     */   public Possible<Optional<String>> content() {
/* 107 */     return this.content_absent ? Possible.absent() : 
/* 108 */       Possible.of(Optional.ofNullable(this.content_value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("embeds")
/*     */   public Possible<Optional<List<EmbedData>>> embeds() {
/* 117 */     return this.embeds_absent ? Possible.absent() : 
/* 118 */       Possible.of(Optional.ofNullable(this.embeds_value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("allowed_mentions")
/*     */   public Possible<Optional<AllowedMentionsData>> allowedMentions() {
/* 127 */     return this.allowedMentions_absent ? Possible.absent() : 
/* 128 */       Possible.of(Optional.ofNullable(this.allowedMentions_value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("attachments")
/*     */   public Possible<Optional<List<AttachmentData>>> attachments() {
/* 137 */     return this.attachments_absent ? Possible.absent() : 
/* 138 */       Possible.of(Optional.ofNullable(this.attachments_value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("components")
/*     */   public Possible<List<ComponentData>> components() {
/* 147 */     return this.components_absent ? Possible.absent() : 
/* 148 */       Possible.of(this.components_value);
/*     */   }
/*     */   
/*     */   public ImmutableWebhookMessageEditRequest withContent(Possible<Optional<String>> value) {
/* 152 */     Possible<Optional<String>> newValue = Objects.<Possible<Optional<String>>>requireNonNull(value);
/* 153 */     return new ImmutableWebhookMessageEditRequest(this, newValue, embeds(), allowedMentions(), attachments(), components());
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public ImmutableWebhookMessageEditRequest withContent(@Nullable String value) {
/* 158 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/* 159 */     return new ImmutableWebhookMessageEditRequest(this, newValue, embeds(), allowedMentions(), attachments(), components());
/*     */   }
/*     */   
/*     */   public ImmutableWebhookMessageEditRequest withContentOrNull(@Nullable String value) {
/* 163 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/* 164 */     return new ImmutableWebhookMessageEditRequest(this, newValue, embeds(), allowedMentions(), attachments(), components());
/*     */   }
/*     */   
/*     */   public ImmutableWebhookMessageEditRequest withEmbeds(Possible<Optional<List<EmbedData>>> possible) {
/* 168 */     Possible<Optional<List<EmbedData>>> newValue = Objects.<Possible<Optional<List<EmbedData>>>>requireNonNull(possible);
/* 169 */     return new ImmutableWebhookMessageEditRequest(this, content(), newValue, allowedMentions(), attachments(), components());
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public ImmutableWebhookMessageEditRequest withEmbeds(@Nullable Iterable<EmbedData> elements) {
/* 174 */     Possible<Optional<List<EmbedData>>> newValue = Possible.of(Optional.<Iterable<EmbedData>>ofNullable(elements)
/* 175 */         .map(els -> (List)StreamSupport.stream(els.spliterator(), false).collect(Collectors.toList())));
/* 176 */     return new ImmutableWebhookMessageEditRequest(this, content(), newValue, allowedMentions(), attachments(), components());
/*     */   }
/*     */   
/*     */   public ImmutableWebhookMessageEditRequest withEmbedsOrNull(@Nullable Iterable<EmbedData> elements) {
/* 180 */     Possible<Optional<List<EmbedData>>> newValue = Possible.of(Optional.<Iterable<EmbedData>>ofNullable(elements)
/* 181 */         .map(els -> (List)StreamSupport.stream(els.spliterator(), false).collect(Collectors.toList())));
/* 182 */     return new ImmutableWebhookMessageEditRequest(this, content(), newValue, allowedMentions(), attachments(), components());
/*     */   }
/*     */   
/*     */   @SafeVarargs
/*     */   public final ImmutableWebhookMessageEditRequest withEmbeds(EmbedData... elements) {
/* 187 */     Possible<Optional<List<EmbedData>>> newValue = Possible.of(Optional.of(Arrays.asList(elements)));
/* 188 */     return new ImmutableWebhookMessageEditRequest(this, content(), newValue, allowedMentions(), attachments(), components());
/*     */   }
/*     */   
/*     */   public ImmutableWebhookMessageEditRequest withAllowedMentions(Possible<Optional<AllowedMentionsData>> value) {
/* 192 */     Possible<Optional<AllowedMentionsData>> newValue = Objects.<Possible<Optional<AllowedMentionsData>>>requireNonNull(value);
/* 193 */     return new ImmutableWebhookMessageEditRequest(this, content(), embeds(), newValue, attachments(), components());
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public ImmutableWebhookMessageEditRequest withAllowedMentions(@Nullable AllowedMentionsData value) {
/* 198 */     Possible<Optional<AllowedMentionsData>> newValue = Possible.of(Optional.ofNullable(value));
/* 199 */     return new ImmutableWebhookMessageEditRequest(this, content(), embeds(), newValue, attachments(), components());
/*     */   }
/*     */   
/*     */   public ImmutableWebhookMessageEditRequest withAllowedMentionsOrNull(@Nullable AllowedMentionsData value) {
/* 203 */     Possible<Optional<AllowedMentionsData>> newValue = Possible.of(Optional.ofNullable(value));
/* 204 */     return new ImmutableWebhookMessageEditRequest(this, content(), embeds(), newValue, attachments(), components());
/*     */   }
/*     */   
/*     */   public ImmutableWebhookMessageEditRequest withAttachments(Possible<Optional<List<AttachmentData>>> possible) {
/* 208 */     Possible<Optional<List<AttachmentData>>> newValue = Objects.<Possible<Optional<List<AttachmentData>>>>requireNonNull(possible);
/* 209 */     return new ImmutableWebhookMessageEditRequest(this, content(), embeds(), allowedMentions(), newValue, components());
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public ImmutableWebhookMessageEditRequest withAttachments(@Nullable Iterable<AttachmentData> elements) {
/* 214 */     Possible<Optional<List<AttachmentData>>> newValue = Possible.of(Optional.<Iterable<AttachmentData>>ofNullable(elements)
/* 215 */         .map(els -> (List)StreamSupport.stream(els.spliterator(), false).collect(Collectors.toList())));
/* 216 */     return new ImmutableWebhookMessageEditRequest(this, content(), embeds(), allowedMentions(), newValue, components());
/*     */   }
/*     */   
/*     */   public ImmutableWebhookMessageEditRequest withAttachmentsOrNull(@Nullable Iterable<AttachmentData> elements) {
/* 220 */     Possible<Optional<List<AttachmentData>>> newValue = Possible.of(Optional.<Iterable<AttachmentData>>ofNullable(elements)
/* 221 */         .map(els -> (List)StreamSupport.stream(els.spliterator(), false).collect(Collectors.toList())));
/* 222 */     return new ImmutableWebhookMessageEditRequest(this, content(), embeds(), allowedMentions(), newValue, components());
/*     */   }
/*     */   
/*     */   @SafeVarargs
/*     */   public final ImmutableWebhookMessageEditRequest withAttachments(AttachmentData... elements) {
/* 227 */     Possible<Optional<List<AttachmentData>>> newValue = Possible.of(Optional.of(Arrays.asList(elements)));
/* 228 */     return new ImmutableWebhookMessageEditRequest(this, content(), embeds(), allowedMentions(), newValue, components());
/*     */   }
/*     */   
/*     */   public ImmutableWebhookMessageEditRequest withComponents(Possible<List<ComponentData>> possible) {
/* 232 */     Possible<List<ComponentData>> newValue = Objects.<Possible<List<ComponentData>>>requireNonNull(possible);
/* 233 */     return new ImmutableWebhookMessageEditRequest(this, content(), embeds(), allowedMentions(), attachments(), newValue);
/*     */   }
/*     */   
/*     */   public ImmutableWebhookMessageEditRequest withComponents(Iterable<ComponentData> elements) {
/* 237 */     Possible<List<ComponentData>> newValue = Possible.of(
/* 238 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/* 239 */     return new ImmutableWebhookMessageEditRequest(this, content(), embeds(), allowedMentions(), attachments(), newValue);
/*     */   }
/*     */   
/*     */   @SafeVarargs
/*     */   public final ImmutableWebhookMessageEditRequest withComponents(ComponentData... elements) {
/* 244 */     Possible<List<ComponentData>> newValue = Possible.of(Arrays.asList(elements));
/* 245 */     return new ImmutableWebhookMessageEditRequest(this, content(), embeds(), allowedMentions(), attachments(), newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 254 */     if (this == another) return true; 
/* 255 */     return (another instanceof ImmutableWebhookMessageEditRequest && 
/* 256 */       equalTo(0, (ImmutableWebhookMessageEditRequest)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableWebhookMessageEditRequest another) {
/* 260 */     return (content().equals(another.content()) && 
/* 261 */       Objects.equals(this.embeds_value, another.embeds_value) && 
/* 262 */       allowedMentions().equals(another.allowedMentions()) && 
/* 263 */       Objects.equals(this.attachments_value, another.attachments_value) && 
/* 264 */       Objects.equals(this.components_value, another.components_value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 273 */     int h = 5381;
/* 274 */     h += (h << 5) + content().hashCode();
/* 275 */     h += (h << 5) + Objects.hashCode(this.embeds_value);
/* 276 */     h += (h << 5) + allowedMentions().hashCode();
/* 277 */     h += (h << 5) + Objects.hashCode(this.attachments_value);
/* 278 */     h += (h << 5) + Objects.hashCode(this.components_value);
/* 279 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 288 */     return "WebhookMessageEditRequest{content=" + 
/* 289 */       content().toString() + ", embeds=" + 
/* 290 */       Objects.toString(this.embeds_value) + ", allowedMentions=" + 
/* 291 */       allowedMentions().toString() + ", attachments=" + 
/* 292 */       Objects.toString(this.attachments_value) + ", components=" + 
/* 293 */       Objects.toString(this.components_value) + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "WebhookMessageEditRequest", generator = "Immutables")
/*     */   static final class Json
/*     */     implements WebhookMessageEditRequest
/*     */   {
/* 307 */     Possible<Optional<String>> content = Possible.absent();
/*     */ 
/*     */     
/* 310 */     Possible<Optional<List<EmbedData>>> embeds = Possible.absent();
/*     */ 
/*     */     
/* 313 */     Possible<Optional<AllowedMentionsData>> allowedMentions = Possible.absent();
/*     */ 
/*     */     
/* 316 */     Possible<Optional<List<AttachmentData>>> attachments = Possible.absent();
/*     */ 
/*     */     
/* 319 */     Possible<List<ComponentData>> components = Possible.absent();
/*     */     
/*     */     @JsonProperty("content")
/*     */     public void setContent(Possible<Optional<String>> content) {
/* 323 */       this.content = content;
/*     */     }
/*     */     @JsonProperty("embeds")
/*     */     public void setEmbeds(Possible<Optional<List<EmbedData>>> embeds) {
/* 327 */       this.embeds = embeds;
/*     */     }
/*     */     @JsonProperty("allowed_mentions")
/*     */     public void setAllowedMentions(Possible<Optional<AllowedMentionsData>> allowedMentions) {
/* 331 */       this.allowedMentions = allowedMentions;
/*     */     }
/*     */     @JsonProperty("attachments")
/*     */     public void setAttachments(Possible<Optional<List<AttachmentData>>> attachments) {
/* 335 */       this.attachments = attachments;
/*     */     }
/*     */     @JsonProperty("components")
/*     */     public void setComponents(Possible<List<ComponentData>> components) {
/* 339 */       this.components = components;
/*     */     }
/*     */     public Possible<Optional<String>> content() {
/* 342 */       throw new UnsupportedOperationException();
/*     */     } public Possible<Optional<List<EmbedData>>> embeds() {
/* 344 */       throw new UnsupportedOperationException();
/*     */     } public Possible<Optional<AllowedMentionsData>> allowedMentions() {
/* 346 */       throw new UnsupportedOperationException();
/*     */     } public Possible<Optional<List<AttachmentData>>> attachments() {
/* 348 */       throw new UnsupportedOperationException();
/*     */     } public Possible<List<ComponentData>> components() {
/* 350 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableWebhookMessageEditRequest fromJson(Json json) {
/* 361 */     Builder builder = builder();
/* 362 */     if (json.content != null) {
/* 363 */       builder.content(json.content);
/*     */     }
/* 365 */     if (json.embeds != null) {
/* 366 */       builder.embeds(json.embeds);
/*     */     }
/* 368 */     if (json.allowedMentions != null) {
/* 369 */       builder.allowedMentions(json.allowedMentions);
/*     */     }
/* 371 */     if (json.attachments != null) {
/* 372 */       builder.attachments(json.attachments);
/*     */     }
/* 374 */     if (json.components != null) {
/* 375 */       builder.components(json.components);
/*     */     }
/* 377 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableWebhookMessageEditRequest of(Possible<Optional<String>> content, Possible<Optional<List<EmbedData>>> embeds, Possible<Optional<AllowedMentionsData>> allowedMentions, Possible<Optional<List<AttachmentData>>> attachments, Possible<List<ComponentData>> components) {
/* 390 */     return new ImmutableWebhookMessageEditRequest(content, embeds, allowedMentions, attachments, components);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableWebhookMessageEditRequest copyOf(WebhookMessageEditRequest instance) {
/* 401 */     if (instance instanceof ImmutableWebhookMessageEditRequest) {
/* 402 */       return (ImmutableWebhookMessageEditRequest)instance;
/*     */     }
/* 404 */     return builder()
/* 405 */       .from(instance)
/* 406 */       .build();
/*     */   }
/*     */   
/*     */   public boolean isContentPresent() {
/* 410 */     return !this.content_absent;
/*     */   }
/*     */   
/*     */   public String contentOrElse(String defaultValue) {
/* 414 */     return !this.content_absent ? this.content_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isEmbedsPresent() {
/* 418 */     return !this.embeds_absent;
/*     */   }
/*     */   
/*     */   public List<EmbedData> embedsOrElse(List<EmbedData> defaultValue) {
/* 422 */     return !this.embeds_absent ? this.embeds_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isAllowedMentionsPresent() {
/* 426 */     return !this.allowedMentions_absent;
/*     */   }
/*     */   
/*     */   public AllowedMentionsData allowedMentionsOrElse(AllowedMentionsData defaultValue) {
/* 430 */     return !this.allowedMentions_absent ? this.allowedMentions_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isAttachmentsPresent() {
/* 434 */     return !this.attachments_absent;
/*     */   }
/*     */   
/*     */   public List<AttachmentData> attachmentsOrElse(List<AttachmentData> defaultValue) {
/* 438 */     return !this.attachments_absent ? this.attachments_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isComponentsPresent() {
/* 442 */     return !this.components_absent;
/*     */   }
/*     */   
/*     */   public List<ComponentData> componentsOrElse(List<ComponentData> defaultValue) {
/* 446 */     return !this.components_absent ? this.components_value : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 463 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "WebhookMessageEditRequest", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/* 475 */     private Possible<Optional<String>> content_possible = Possible.absent();
/* 476 */     private List<EmbedData> embeds_list = null;
/*     */     private boolean embeds_explicitNull;
/* 478 */     private Possible<Optional<AllowedMentionsData>> allowedMentions_possible = Possible.absent();
/* 479 */     private List<AttachmentData> attachments_list = null;
/*     */     private boolean attachments_explicitNull;
/* 481 */     private List<ComponentData> components_list = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(WebhookMessageEditRequest instance) {
/* 494 */       Objects.requireNonNull(instance, "instance");
/* 495 */       content(instance.content());
/* 496 */       embeds(instance.embeds());
/* 497 */       allowedMentions(instance.allowedMentions());
/* 498 */       attachments(instance.attachments());
/* 499 */       components(instance.components());
/* 500 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("content")
/*     */     public Builder content(Possible<Optional<String>> value) {
/* 505 */       this.content_possible = value;
/* 506 */       return this;
/*     */     }
/*     */     
/*     */     @Deprecated
/*     */     public Builder content(@Nullable String value) {
/* 511 */       this.content_possible = Possible.of(Optional.ofNullable(value));
/* 512 */       return this;
/*     */     }
/*     */     
/*     */     public Builder contentOrNull(@Nullable String value) {
/* 516 */       this.content_possible = Possible.of(Optional.ofNullable(value));
/* 517 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addEmbed(EmbedData element) {
/* 521 */       embeds_getOrCreate().add(element);
/* 522 */       this.embeds_explicitNull = false;
/* 523 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addAllEmbeds(List<EmbedData> elements) {
/* 527 */       embeds_getOrCreate().addAll(elements);
/* 528 */       this.embeds_explicitNull = false;
/* 529 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("embeds")
/*     */     public Builder embeds(Possible<Optional<List<EmbedData>>> elements) {
/* 534 */       this.embeds_list = null;
/* 535 */       this.embeds_explicitNull = false;
/* 536 */       elements.toOptional().ifPresent(e -> {
/*     */             if (e.isPresent()) {
/*     */               embeds_getOrCreate().addAll(e.get());
/*     */             } else {
/*     */               this.embeds_explicitNull = true;
/*     */             } 
/*     */           });
/* 543 */       return this;
/*     */     }
/*     */     
/*     */     public Builder embeds(List<EmbedData> elements) {
/* 547 */       this.embeds_list = new ArrayList<>(elements);
/* 548 */       this.embeds_explicitNull = false;
/* 549 */       return this;
/*     */     }
/*     */     
/*     */     @Deprecated
/*     */     public Builder embeds(@Nullable Iterable<EmbedData> elements) {
/* 554 */       if (elements == null) {
/* 555 */         this.embeds_list = null;
/* 556 */         this.embeds_explicitNull = true;
/*     */       } else {
/* 558 */         this.embeds_list = (List<EmbedData>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/* 559 */         this.embeds_explicitNull = false;
/*     */       } 
/* 561 */       return this;
/*     */     }
/*     */     
/*     */     public Builder embedsOrNull(@Nullable Iterable<EmbedData> elements) {
/* 565 */       if (elements == null) {
/* 566 */         this.embeds_list = null;
/* 567 */         this.embeds_explicitNull = true;
/*     */       } else {
/* 569 */         this.embeds_list = (List<EmbedData>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/* 570 */         this.embeds_explicitNull = false;
/*     */       } 
/* 572 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("allowed_mentions")
/*     */     public Builder allowedMentions(Possible<Optional<AllowedMentionsData>> value) {
/* 577 */       this.allowedMentions_possible = value;
/* 578 */       return this;
/*     */     }
/*     */     
/*     */     @Deprecated
/*     */     public Builder allowedMentions(@Nullable AllowedMentionsData value) {
/* 583 */       this.allowedMentions_possible = Possible.of(Optional.ofNullable(value));
/* 584 */       return this;
/*     */     }
/*     */     
/*     */     public Builder allowedMentionsOrNull(@Nullable AllowedMentionsData value) {
/* 588 */       this.allowedMentions_possible = Possible.of(Optional.ofNullable(value));
/* 589 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addAttachment(AttachmentData element) {
/* 593 */       attachments_getOrCreate().add(element);
/* 594 */       this.attachments_explicitNull = false;
/* 595 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addAllAttachments(List<AttachmentData> elements) {
/* 599 */       attachments_getOrCreate().addAll(elements);
/* 600 */       this.attachments_explicitNull = false;
/* 601 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("attachments")
/*     */     public Builder attachments(Possible<Optional<List<AttachmentData>>> elements) {
/* 606 */       this.attachments_list = null;
/* 607 */       this.attachments_explicitNull = false;
/* 608 */       elements.toOptional().ifPresent(e -> {
/*     */             if (e.isPresent()) {
/*     */               attachments_getOrCreate().addAll(e.get());
/*     */             } else {
/*     */               this.attachments_explicitNull = true;
/*     */             } 
/*     */           });
/* 615 */       return this;
/*     */     }
/*     */     
/*     */     public Builder attachments(List<AttachmentData> elements) {
/* 619 */       this.attachments_list = new ArrayList<>(elements);
/* 620 */       this.attachments_explicitNull = false;
/* 621 */       return this;
/*     */     }
/*     */     
/*     */     @Deprecated
/*     */     public Builder attachments(@Nullable Iterable<AttachmentData> elements) {
/* 626 */       if (elements == null) {
/* 627 */         this.attachments_list = null;
/* 628 */         this.attachments_explicitNull = true;
/*     */       } else {
/* 630 */         this.attachments_list = (List<AttachmentData>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/* 631 */         this.attachments_explicitNull = false;
/*     */       } 
/* 633 */       return this;
/*     */     }
/*     */     
/*     */     public Builder attachmentsOrNull(@Nullable Iterable<AttachmentData> elements) {
/* 637 */       if (elements == null) {
/* 638 */         this.attachments_list = null;
/* 639 */         this.attachments_explicitNull = true;
/*     */       } else {
/* 641 */         this.attachments_list = (List<AttachmentData>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/* 642 */         this.attachments_explicitNull = false;
/*     */       } 
/* 644 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addComponent(ComponentData element) {
/* 648 */       components_getOrCreate().add(element);
/* 649 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addAllComponents(List<ComponentData> elements) {
/* 653 */       components_getOrCreate().addAll(elements);
/* 654 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("components")
/*     */     public Builder components(Possible<List<ComponentData>> elements) {
/* 659 */       this.components_list = null;
/* 660 */       elements.toOptional().ifPresent(e -> components_getOrCreate().addAll(e));
/* 661 */       return this;
/*     */     }
/*     */     
/*     */     public Builder components(List<ComponentData> elements) {
/* 665 */       this.components_list = new ArrayList<>(elements);
/* 666 */       return this;
/*     */     }
/*     */     
/*     */     public Builder components(Iterable<ComponentData> elements) {
/* 670 */       this.components_list = (List<ComponentData>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/* 671 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableWebhookMessageEditRequest build() {
/* 680 */       return new ImmutableWebhookMessageEditRequest(null, 
/*     */           
/* 682 */           content_build(), 
/* 683 */           embeds_build(), 
/* 684 */           allowedMentions_build(), 
/* 685 */           attachments_build(), 
/* 686 */           components_build());
/*     */     }
/*     */     
/*     */     private Possible<Optional<String>> content_build() {
/* 690 */       return this.content_possible;
/*     */     }
/*     */     
/*     */     private Possible<Optional<List<EmbedData>>> embeds_build() {
/* 694 */       return (this.embeds_list == null && !this.embeds_explicitNull) ? Possible.absent() : 
/* 695 */         Possible.of(Optional.ofNullable(this.embeds_list));
/*     */     }
/*     */     
/*     */     private List<EmbedData> embeds_getOrCreate() {
/* 699 */       if (this.embeds_list == null) {
/* 700 */         this.embeds_list = new ArrayList<>();
/*     */       }
/* 702 */       return this.embeds_list;
/*     */     }
/*     */     
/*     */     private Possible<Optional<AllowedMentionsData>> allowedMentions_build() {
/* 706 */       return this.allowedMentions_possible;
/*     */     }
/*     */     
/*     */     private Possible<Optional<List<AttachmentData>>> attachments_build() {
/* 710 */       return (this.attachments_list == null && !this.attachments_explicitNull) ? Possible.absent() : 
/* 711 */         Possible.of(Optional.ofNullable(this.attachments_list));
/*     */     }
/*     */     
/*     */     private List<AttachmentData> attachments_getOrCreate() {
/* 715 */       if (this.attachments_list == null) {
/* 716 */         this.attachments_list = new ArrayList<>();
/*     */       }
/* 718 */       return this.attachments_list;
/*     */     }
/*     */     
/*     */     private Possible<List<ComponentData>> components_build() {
/* 722 */       return (this.components_list == null) ? Possible.absent() : 
/* 723 */         Possible.of(this.components_list);
/*     */     }
/*     */     
/*     */     private List<ComponentData> components_getOrCreate() {
/* 727 */       if (this.components_list == null) {
/* 728 */         this.components_list = new ArrayList<>();
/*     */       }
/* 730 */       return this.components_list;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableWebhookMessageEditRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */