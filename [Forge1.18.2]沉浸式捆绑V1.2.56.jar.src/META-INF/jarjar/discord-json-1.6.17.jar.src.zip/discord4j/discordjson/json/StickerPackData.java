/*    */ package discord4j.discordjson.json;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonProperty;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import discord4j.discordjson.Id;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import java.util.List;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ @JsonSerialize(as = ImmutableStickerData.class)
/*    */ @JsonDeserialize(as = ImmutableStickerData.class)
/*    */ @Immutable
/*    */ public interface StickerPackData
/*    */ {
/*    */   static ImmutableStickerData.Builder builder() {
/* 17 */     return ImmutableStickerData.builder();
/*    */   }
/*    */   
/*    */   Id id();
/*    */   
/*    */   Possible<List<StickerData>> stickers();
/*    */   
/*    */   String name();
/*    */   
/*    */   String description();
/*    */   
/*    */   @JsonProperty("sku_id")
/*    */   Id skuId();
/*    */   
/*    */   @JsonProperty("cover_sticker_id")
/*    */   Possible<Id> coverStickerId();
/*    */   
/*    */   @JsonProperty("banner_asset_id")
/*    */   Possible<Id> bannerAssetId();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\StickerPackData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */