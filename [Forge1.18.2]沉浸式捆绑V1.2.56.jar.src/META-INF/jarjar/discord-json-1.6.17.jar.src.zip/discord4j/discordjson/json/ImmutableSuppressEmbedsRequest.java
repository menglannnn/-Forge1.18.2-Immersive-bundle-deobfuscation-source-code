/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "SuppressEmbedsRequest", generator = "Immutables")
/*     */ public final class ImmutableSuppressEmbedsRequest
/*     */   implements SuppressEmbedsRequest
/*     */ {
/*     */   private final boolean suppress;
/*     */   
/*     */   private ImmutableSuppressEmbedsRequest(boolean suppress) {
/*  27 */     this.suppress = suppress;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("suppress")
/*     */   public boolean suppress() {
/*  36 */     return this.suppress;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableSuppressEmbedsRequest withSuppress(boolean value) {
/*  46 */     if (this.suppress == value) return this; 
/*  47 */     return new ImmutableSuppressEmbedsRequest(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/*  56 */     if (this == another) return true; 
/*  57 */     return (another instanceof ImmutableSuppressEmbedsRequest && 
/*  58 */       equalTo(0, (ImmutableSuppressEmbedsRequest)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableSuppressEmbedsRequest another) {
/*  62 */     return (this.suppress == another.suppress);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  71 */     int h = 5381;
/*  72 */     h += (h << 5) + Boolean.hashCode(this.suppress);
/*  73 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/*  82 */     return "SuppressEmbedsRequest{suppress=" + this.suppress + "}";
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "SuppressEmbedsRequest", generator = "Immutables")
/*     */   static final class Json
/*     */     implements SuppressEmbedsRequest
/*     */   {
/*     */     boolean suppress;
/*     */     
/*     */     boolean suppressIsSet;
/*     */ 
/*     */     
/*     */     @JsonProperty("suppress")
/*     */     public void setSuppress(boolean suppress) {
/* 100 */       this.suppress = suppress;
/* 101 */       this.suppressIsSet = true;
/*     */     }
/*     */     public boolean suppress() {
/* 104 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableSuppressEmbedsRequest fromJson(Json json) {
/* 115 */     Builder builder = builder();
/* 116 */     if (json.suppressIsSet) {
/* 117 */       builder.suppress(json.suppress);
/*     */     }
/* 119 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableSuppressEmbedsRequest of(boolean suppress) {
/* 128 */     return new ImmutableSuppressEmbedsRequest(suppress);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableSuppressEmbedsRequest copyOf(SuppressEmbedsRequest instance) {
/* 139 */     if (instance instanceof ImmutableSuppressEmbedsRequest) {
/* 140 */       return (ImmutableSuppressEmbedsRequest)instance;
/*     */     }
/* 142 */     return builder()
/* 143 */       .from(instance)
/* 144 */       .build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 157 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "SuppressEmbedsRequest", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_SUPPRESS = 1L;
/*     */ 
/*     */ 
/*     */     
/* 170 */     private long initBits = 1L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private boolean suppress;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(SuppressEmbedsRequest instance) {
/* 185 */       Objects.requireNonNull(instance, "instance");
/* 186 */       suppress(instance.suppress());
/* 187 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("suppress")
/*     */     public final Builder suppress(boolean suppress) {
/* 197 */       this.suppress = suppress;
/* 198 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 199 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableSuppressEmbedsRequest build() {
/* 208 */       if (this.initBits != 0L) {
/* 209 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 211 */       return new ImmutableSuppressEmbedsRequest(this.suppress);
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 215 */       List<String> attributes = new ArrayList<>();
/* 216 */       if ((this.initBits & 0x1L) != 0L) attributes.add("suppress"); 
/* 217 */       return "Cannot build SuppressEmbedsRequest, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableSuppressEmbedsRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */