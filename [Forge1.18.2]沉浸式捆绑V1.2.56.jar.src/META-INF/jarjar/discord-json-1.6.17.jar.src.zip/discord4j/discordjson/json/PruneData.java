/*    */ package discord4j.discordjson.json;
/*    */ 
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import java.util.Optional;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ 
/*    */ @JsonSerialize(as = ImmutablePruneData.class)
/*    */ @JsonDeserialize(as = ImmutablePruneData.class)
/*    */ @Immutable
/*    */ public interface PruneData
/*    */ {
/*    */   static ImmutablePruneData.Builder builder() {
/* 15 */     return ImmutablePruneData.builder();
/*    */   }
/*    */   
/*    */   Optional<Integer> pruned();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\PruneData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */