/*    */ package discord4j.discordjson.json;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonProperty;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import java.util.Optional;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ @JsonSerialize(as = ImmutableRoleCreateRequest.class)
/*    */ @JsonDeserialize(as = ImmutableRoleCreateRequest.class)
/*    */ @Immutable
/*    */ public interface RoleCreateRequest
/*    */ {
/*    */   static ImmutableRoleCreateRequest.Builder builder() {
/* 16 */     return ImmutableRoleCreateRequest.builder();
/*    */   }
/*    */   
/*    */   Possible<String> name();
/*    */   
/*    */   Possible<Long> permissions();
/*    */   
/*    */   Possible<Integer> color();
/*    */   
/*    */   Possible<Boolean> hoist();
/*    */   
/*    */   Possible<Boolean> mentionable();
/*    */   
/*    */   Possible<Optional<String>> icon();
/*    */   
/*    */   @JsonProperty("unicode_emoji")
/*    */   Possible<Optional<String>> unicodeEmoji();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\RoleCreateRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */