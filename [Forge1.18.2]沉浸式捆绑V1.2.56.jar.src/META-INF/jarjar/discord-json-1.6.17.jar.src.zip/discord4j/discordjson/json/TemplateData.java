/*    */ package discord4j.discordjson.json;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonProperty;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import discord4j.discordjson.Id;
/*    */ import java.util.Optional;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ 
/*    */ @JsonSerialize(as = ImmutableTemplateData.class)
/*    */ @JsonDeserialize(as = ImmutableTemplateData.class)
/*    */ @Immutable
/*    */ public interface TemplateData
/*    */ {
/*    */   static ImmutableTemplateData.Builder builder() {
/* 17 */     return ImmutableTemplateData.builder();
/*    */   }
/*    */   
/*    */   String code();
/*    */   
/*    */   String name();
/*    */   
/*    */   Optional<String> description();
/*    */   
/*    */   @JsonProperty("usage_count")
/*    */   int usageCount();
/*    */   
/*    */   @JsonProperty("creator_id")
/*    */   Id creatorId();
/*    */   
/*    */   UserData creator();
/*    */   
/*    */   @JsonProperty("created_at")
/*    */   String createdAt();
/*    */   
/*    */   @JsonProperty("updated_at")
/*    */   String updatedAt();
/*    */   
/*    */   @JsonProperty("source_guild_id")
/*    */   Id sourceGuildId();
/*    */   
/*    */   @JsonProperty("serialized_source_guild")
/*    */   SerializedSourceGuildData serializedSourceGuild();
/*    */   
/*    */   @JsonProperty("is_dirty")
/*    */   Optional<Boolean> isDirty();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\TemplateData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */