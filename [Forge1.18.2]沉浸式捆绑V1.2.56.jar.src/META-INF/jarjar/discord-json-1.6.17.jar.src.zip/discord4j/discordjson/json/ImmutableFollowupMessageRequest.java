/*      */ package discord4j.discordjson.json;
/*      */ 
/*      */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*      */ import com.fasterxml.jackson.annotation.JsonCreator;
/*      */ import com.fasterxml.jackson.annotation.JsonProperty;
/*      */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*      */ import discord4j.discordjson.possible.Possible;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.List;
/*      */ import java.util.Objects;
/*      */ import java.util.stream.Collectors;
/*      */ import java.util.stream.StreamSupport;
/*      */ import org.immutables.value.Generated;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ @Generated(from = "FollowupMessageRequest", generator = "Immutables")
/*      */ public final class ImmutableFollowupMessageRequest
/*      */   implements FollowupMessageRequest
/*      */ {
/*      */   private final String content_value;
/*      */   private final boolean content_absent;
/*      */   private final Boolean tts_value;
/*      */   private final boolean tts_absent;
/*      */   private final AllowedMentionsData allowedMentions_value;
/*      */   private final boolean allowedMentions_absent;
/*      */   private final MessageReferenceData messageReference_value;
/*      */   private final boolean messageReference_absent;
/*      */   private final List<ComponentData> components_value;
/*      */   private final boolean components_absent;
/*      */   private final List<EmbedData> embeds_value;
/*      */   private final boolean embeds_absent;
/*      */   private final String username_value;
/*      */   private final boolean username_absent;
/*      */   private final String avatarUrl_value;
/*      */   private final boolean avatarUrl_absent;
/*      */   private final Integer flags_value;
/*      */   private final boolean flags_absent;
/*      */   private static final byte STAGE_INITIALIZING = -1;
/*      */   private static final byte STAGE_UNINITIALIZED = 0;
/*      */   private static final byte STAGE_INITIALIZED = 1;
/*      */   
/*      */   private ImmutableFollowupMessageRequest(Possible<String> content, Possible<Boolean> tts, Possible<AllowedMentionsData> allowedMentions, Possible<MessageReferenceData> messageReference, Possible<List<ComponentData>> components, Possible<List<EmbedData>> embeds, Possible<String> username, Possible<String> avatarUrl, Possible<Integer> flags) {
/*   58 */     Possible<String> content$impl = content;
/*   59 */     Possible<Boolean> tts$impl = tts;
/*   60 */     Possible<AllowedMentionsData> allowedMentions$impl = allowedMentions;
/*   61 */     Possible<MessageReferenceData> messageReference$impl = messageReference;
/*   62 */     Possible<List<ComponentData>> components$impl = components;
/*   63 */     Possible<List<EmbedData>> embeds$impl = embeds;
/*   64 */     Possible<String> username$impl = username;
/*   65 */     Possible<String> avatarUrl$impl = avatarUrl;
/*   66 */     Possible<Integer> flags$impl = flags;
/*   67 */     this.content_value = content$impl.toOptional().orElse(null);
/*   68 */     this.content_absent = content$impl.isAbsent();
/*   69 */     this.tts_value = tts$impl.toOptional().orElse(null);
/*   70 */     this.tts_absent = tts$impl.isAbsent();
/*   71 */     this.allowedMentions_value = allowedMentions$impl.toOptional().orElse(null);
/*   72 */     this.allowedMentions_absent = allowedMentions$impl.isAbsent();
/*   73 */     this.messageReference_value = messageReference$impl.toOptional().orElse(null);
/*   74 */     this.messageReference_absent = messageReference$impl.isAbsent();
/*   75 */     this.components_value = components$impl.toOptional().orElse(null);
/*   76 */     this.components_absent = components$impl.isAbsent();
/*   77 */     this.embeds_value = embeds$impl.toOptional().orElse(null);
/*   78 */     this.embeds_absent = embeds$impl.isAbsent();
/*   79 */     this.username_value = username$impl.toOptional().orElse(null);
/*   80 */     this.username_absent = username$impl.isAbsent();
/*   81 */     this.avatarUrl_value = avatarUrl$impl.toOptional().orElse(null);
/*   82 */     this.avatarUrl_absent = avatarUrl$impl.isAbsent();
/*   83 */     this.flags_value = flags$impl.toOptional().orElse(null);
/*   84 */     this.flags_absent = flags$impl.isAbsent();
/*   85 */     this.initShim = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ImmutableFollowupMessageRequest(ImmutableFollowupMessageRequest original, Possible<String> content, Possible<Boolean> tts, Possible<AllowedMentionsData> allowedMentions, Possible<MessageReferenceData> messageReference, Possible<List<ComponentData>> components, Possible<List<EmbedData>> embeds, Possible<String> username, Possible<String> avatarUrl, Possible<Integer> flags) {
/*   99 */     Possible<String> content$impl = content;
/*  100 */     Possible<Boolean> tts$impl = tts;
/*  101 */     Possible<AllowedMentionsData> allowedMentions$impl = allowedMentions;
/*  102 */     Possible<MessageReferenceData> messageReference$impl = messageReference;
/*  103 */     Possible<List<ComponentData>> components$impl = components;
/*  104 */     Possible<List<EmbedData>> embeds$impl = embeds;
/*  105 */     Possible<String> username$impl = username;
/*  106 */     Possible<String> avatarUrl$impl = avatarUrl;
/*  107 */     Possible<Integer> flags$impl = flags;
/*  108 */     this.content_value = content$impl.toOptional().orElse(null);
/*  109 */     this.content_absent = content$impl.isAbsent();
/*  110 */     this.tts_value = tts$impl.toOptional().orElse(null);
/*  111 */     this.tts_absent = tts$impl.isAbsent();
/*  112 */     this.allowedMentions_value = allowedMentions$impl.toOptional().orElse(null);
/*  113 */     this.allowedMentions_absent = allowedMentions$impl.isAbsent();
/*  114 */     this.messageReference_value = messageReference$impl.toOptional().orElse(null);
/*  115 */     this.messageReference_absent = messageReference$impl.isAbsent();
/*  116 */     this.components_value = components$impl.toOptional().orElse(null);
/*  117 */     this.components_absent = components$impl.isAbsent();
/*  118 */     this.embeds_value = embeds$impl.toOptional().orElse(null);
/*  119 */     this.embeds_absent = embeds$impl.isAbsent();
/*  120 */     this.username_value = username$impl.toOptional().orElse(null);
/*  121 */     this.username_absent = username$impl.isAbsent();
/*  122 */     this.avatarUrl_value = avatarUrl$impl.toOptional().orElse(null);
/*  123 */     this.avatarUrl_absent = avatarUrl$impl.isAbsent();
/*  124 */     this.flags_value = flags$impl.toOptional().orElse(null);
/*  125 */     this.flags_absent = flags$impl.isAbsent();
/*  126 */     this.initShim = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  132 */   private volatile transient InitShim initShim = new InitShim();
/*      */   
/*      */   @Generated(from = "FollowupMessageRequest", generator = "Immutables")
/*      */   private final class InitShim {
/*      */     private String formatInitCycleMessage() {
/*  137 */       List<String> attributes = new ArrayList<>();
/*  138 */       return "Cannot build FollowupMessageRequest, attribute initializers form cycle " + attributes;
/*      */     }
/*      */ 
/*      */     
/*      */     private InitShim() {}
/*      */   }
/*      */ 
/*      */   
/*      */   @JsonProperty("content")
/*      */   public Possible<String> content() {
/*  148 */     return this.content_absent ? Possible.absent() : Possible.of(this.content_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("tts")
/*      */   public Possible<Boolean> tts() {
/*  157 */     return this.tts_absent ? Possible.absent() : Possible.of(this.tts_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("allowed_mentions")
/*      */   public Possible<AllowedMentionsData> allowedMentions() {
/*  166 */     return this.allowedMentions_absent ? Possible.absent() : Possible.of(this.allowedMentions_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("message_reference")
/*      */   public Possible<MessageReferenceData> messageReference() {
/*  175 */     return this.messageReference_absent ? Possible.absent() : Possible.of(this.messageReference_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("components")
/*      */   public Possible<List<ComponentData>> components() {
/*  184 */     return this.components_absent ? Possible.absent() : 
/*  185 */       Possible.of(this.components_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("embeds")
/*      */   public Possible<List<EmbedData>> embeds() {
/*  194 */     return this.embeds_absent ? Possible.absent() : 
/*  195 */       Possible.of(this.embeds_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("username")
/*      */   public Possible<String> username() {
/*  204 */     return this.username_absent ? Possible.absent() : Possible.of(this.username_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("avatar_url")
/*      */   public Possible<String> avatarUrl() {
/*  213 */     return this.avatarUrl_absent ? Possible.absent() : Possible.of(this.avatarUrl_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("flags")
/*      */   public Possible<Integer> flags() {
/*  222 */     return this.flags_absent ? Possible.absent() : Possible.of(this.flags_value);
/*      */   }
/*      */   
/*      */   public ImmutableFollowupMessageRequest withContent(Possible<String> value) {
/*  226 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/*  227 */     return new ImmutableFollowupMessageRequest(this, newValue, 
/*      */ 
/*      */         
/*  230 */         tts(), 
/*  231 */         allowedMentions(), 
/*  232 */         messageReference(), 
/*  233 */         components(), 
/*  234 */         embeds(), 
/*  235 */         username(), 
/*  236 */         avatarUrl(), 
/*  237 */         flags());
/*      */   }
/*      */   
/*      */   public ImmutableFollowupMessageRequest withContent(String value) {
/*  241 */     Possible<String> newValue = Possible.of(value);
/*  242 */     return new ImmutableFollowupMessageRequest(this, newValue, 
/*      */ 
/*      */         
/*  245 */         tts(), 
/*  246 */         allowedMentions(), 
/*  247 */         messageReference(), 
/*  248 */         components(), 
/*  249 */         embeds(), 
/*  250 */         username(), 
/*  251 */         avatarUrl(), 
/*  252 */         flags());
/*      */   }
/*      */   
/*      */   public ImmutableFollowupMessageRequest withTts(Possible<Boolean> value) {
/*  256 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/*  257 */     return new ImmutableFollowupMessageRequest(this, 
/*      */         
/*  259 */         content(), newValue, 
/*      */         
/*  261 */         allowedMentions(), 
/*  262 */         messageReference(), 
/*  263 */         components(), 
/*  264 */         embeds(), 
/*  265 */         username(), 
/*  266 */         avatarUrl(), 
/*  267 */         flags());
/*      */   }
/*      */   
/*      */   public ImmutableFollowupMessageRequest withTts(Boolean value) {
/*  271 */     Possible<Boolean> newValue = Possible.of(value);
/*  272 */     return new ImmutableFollowupMessageRequest(this, 
/*      */         
/*  274 */         content(), newValue, 
/*      */         
/*  276 */         allowedMentions(), 
/*  277 */         messageReference(), 
/*  278 */         components(), 
/*  279 */         embeds(), 
/*  280 */         username(), 
/*  281 */         avatarUrl(), 
/*  282 */         flags());
/*      */   }
/*      */   
/*      */   public ImmutableFollowupMessageRequest withAllowedMentions(Possible<AllowedMentionsData> value) {
/*  286 */     Possible<AllowedMentionsData> newValue = Objects.<Possible<AllowedMentionsData>>requireNonNull(value);
/*  287 */     return new ImmutableFollowupMessageRequest(this, 
/*      */         
/*  289 */         content(), 
/*  290 */         tts(), newValue, 
/*      */         
/*  292 */         messageReference(), 
/*  293 */         components(), 
/*  294 */         embeds(), 
/*  295 */         username(), 
/*  296 */         avatarUrl(), 
/*  297 */         flags());
/*      */   }
/*      */   
/*      */   public ImmutableFollowupMessageRequest withAllowedMentions(AllowedMentionsData value) {
/*  301 */     Possible<AllowedMentionsData> newValue = Possible.of(value);
/*  302 */     return new ImmutableFollowupMessageRequest(this, 
/*      */         
/*  304 */         content(), 
/*  305 */         tts(), newValue, 
/*      */         
/*  307 */         messageReference(), 
/*  308 */         components(), 
/*  309 */         embeds(), 
/*  310 */         username(), 
/*  311 */         avatarUrl(), 
/*  312 */         flags());
/*      */   }
/*      */   
/*      */   public ImmutableFollowupMessageRequest withMessageReference(Possible<MessageReferenceData> value) {
/*  316 */     Possible<MessageReferenceData> newValue = Objects.<Possible<MessageReferenceData>>requireNonNull(value);
/*  317 */     return new ImmutableFollowupMessageRequest(this, 
/*      */         
/*  319 */         content(), 
/*  320 */         tts(), 
/*  321 */         allowedMentions(), newValue, 
/*      */         
/*  323 */         components(), 
/*  324 */         embeds(), 
/*  325 */         username(), 
/*  326 */         avatarUrl(), 
/*  327 */         flags());
/*      */   }
/*      */   
/*      */   public ImmutableFollowupMessageRequest withMessageReference(MessageReferenceData value) {
/*  331 */     Possible<MessageReferenceData> newValue = Possible.of(value);
/*  332 */     return new ImmutableFollowupMessageRequest(this, 
/*      */         
/*  334 */         content(), 
/*  335 */         tts(), 
/*  336 */         allowedMentions(), newValue, 
/*      */         
/*  338 */         components(), 
/*  339 */         embeds(), 
/*  340 */         username(), 
/*  341 */         avatarUrl(), 
/*  342 */         flags());
/*      */   }
/*      */   
/*      */   public ImmutableFollowupMessageRequest withComponents(Possible<List<ComponentData>> possible) {
/*  346 */     Possible<List<ComponentData>> newValue = Objects.<Possible<List<ComponentData>>>requireNonNull(possible);
/*  347 */     return new ImmutableFollowupMessageRequest(this, 
/*      */         
/*  349 */         content(), 
/*  350 */         tts(), 
/*  351 */         allowedMentions(), 
/*  352 */         messageReference(), newValue, 
/*      */         
/*  354 */         embeds(), 
/*  355 */         username(), 
/*  356 */         avatarUrl(), 
/*  357 */         flags());
/*      */   }
/*      */   
/*      */   public ImmutableFollowupMessageRequest withComponents(Iterable<ComponentData> elements) {
/*  361 */     Possible<List<ComponentData>> newValue = Possible.of(
/*  362 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/*  363 */     return new ImmutableFollowupMessageRequest(this, 
/*      */         
/*  365 */         content(), 
/*  366 */         tts(), 
/*  367 */         allowedMentions(), 
/*  368 */         messageReference(), newValue, 
/*      */         
/*  370 */         embeds(), 
/*  371 */         username(), 
/*  372 */         avatarUrl(), 
/*  373 */         flags());
/*      */   }
/*      */   
/*      */   @SafeVarargs
/*      */   public final ImmutableFollowupMessageRequest withComponents(ComponentData... elements) {
/*  378 */     Possible<List<ComponentData>> newValue = Possible.of(Arrays.asList(elements));
/*  379 */     return new ImmutableFollowupMessageRequest(this, 
/*      */         
/*  381 */         content(), 
/*  382 */         tts(), 
/*  383 */         allowedMentions(), 
/*  384 */         messageReference(), newValue, 
/*      */         
/*  386 */         embeds(), 
/*  387 */         username(), 
/*  388 */         avatarUrl(), 
/*  389 */         flags());
/*      */   }
/*      */   
/*      */   public ImmutableFollowupMessageRequest withEmbeds(Possible<List<EmbedData>> possible) {
/*  393 */     Possible<List<EmbedData>> newValue = Objects.<Possible<List<EmbedData>>>requireNonNull(possible);
/*  394 */     return new ImmutableFollowupMessageRequest(this, 
/*      */         
/*  396 */         content(), 
/*  397 */         tts(), 
/*  398 */         allowedMentions(), 
/*  399 */         messageReference(), 
/*  400 */         components(), newValue, 
/*      */         
/*  402 */         username(), 
/*  403 */         avatarUrl(), 
/*  404 */         flags());
/*      */   }
/*      */   
/*      */   public ImmutableFollowupMessageRequest withEmbeds(Iterable<EmbedData> elements) {
/*  408 */     Possible<List<EmbedData>> newValue = Possible.of(
/*  409 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/*  410 */     return new ImmutableFollowupMessageRequest(this, 
/*      */         
/*  412 */         content(), 
/*  413 */         tts(), 
/*  414 */         allowedMentions(), 
/*  415 */         messageReference(), 
/*  416 */         components(), newValue, 
/*      */         
/*  418 */         username(), 
/*  419 */         avatarUrl(), 
/*  420 */         flags());
/*      */   }
/*      */   
/*      */   @SafeVarargs
/*      */   public final ImmutableFollowupMessageRequest withEmbeds(EmbedData... elements) {
/*  425 */     Possible<List<EmbedData>> newValue = Possible.of(Arrays.asList(elements));
/*  426 */     return new ImmutableFollowupMessageRequest(this, 
/*      */         
/*  428 */         content(), 
/*  429 */         tts(), 
/*  430 */         allowedMentions(), 
/*  431 */         messageReference(), 
/*  432 */         components(), newValue, 
/*      */         
/*  434 */         username(), 
/*  435 */         avatarUrl(), 
/*  436 */         flags());
/*      */   }
/*      */   
/*      */   public ImmutableFollowupMessageRequest withUsername(Possible<String> value) {
/*  440 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/*  441 */     return new ImmutableFollowupMessageRequest(this, 
/*      */         
/*  443 */         content(), 
/*  444 */         tts(), 
/*  445 */         allowedMentions(), 
/*  446 */         messageReference(), 
/*  447 */         components(), 
/*  448 */         embeds(), newValue, 
/*      */         
/*  450 */         avatarUrl(), 
/*  451 */         flags());
/*      */   }
/*      */   
/*      */   public ImmutableFollowupMessageRequest withUsername(String value) {
/*  455 */     Possible<String> newValue = Possible.of(value);
/*  456 */     return new ImmutableFollowupMessageRequest(this, 
/*      */         
/*  458 */         content(), 
/*  459 */         tts(), 
/*  460 */         allowedMentions(), 
/*  461 */         messageReference(), 
/*  462 */         components(), 
/*  463 */         embeds(), newValue, 
/*      */         
/*  465 */         avatarUrl(), 
/*  466 */         flags());
/*      */   }
/*      */   
/*      */   public ImmutableFollowupMessageRequest withAvatarUrl(Possible<String> value) {
/*  470 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/*  471 */     return new ImmutableFollowupMessageRequest(this, 
/*      */         
/*  473 */         content(), 
/*  474 */         tts(), 
/*  475 */         allowedMentions(), 
/*  476 */         messageReference(), 
/*  477 */         components(), 
/*  478 */         embeds(), 
/*  479 */         username(), newValue, 
/*      */         
/*  481 */         flags());
/*      */   }
/*      */   
/*      */   public ImmutableFollowupMessageRequest withAvatarUrl(String value) {
/*  485 */     Possible<String> newValue = Possible.of(value);
/*  486 */     return new ImmutableFollowupMessageRequest(this, 
/*      */         
/*  488 */         content(), 
/*  489 */         tts(), 
/*  490 */         allowedMentions(), 
/*  491 */         messageReference(), 
/*  492 */         components(), 
/*  493 */         embeds(), 
/*  494 */         username(), newValue, 
/*      */         
/*  496 */         flags());
/*      */   }
/*      */   
/*      */   public ImmutableFollowupMessageRequest withFlags(Possible<Integer> value) {
/*  500 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/*  501 */     return new ImmutableFollowupMessageRequest(this, 
/*      */         
/*  503 */         content(), 
/*  504 */         tts(), 
/*  505 */         allowedMentions(), 
/*  506 */         messageReference(), 
/*  507 */         components(), 
/*  508 */         embeds(), 
/*  509 */         username(), 
/*  510 */         avatarUrl(), newValue);
/*      */   }
/*      */ 
/*      */   
/*      */   public ImmutableFollowupMessageRequest withFlags(Integer value) {
/*  515 */     Possible<Integer> newValue = Possible.of(value);
/*  516 */     return new ImmutableFollowupMessageRequest(this, 
/*      */         
/*  518 */         content(), 
/*  519 */         tts(), 
/*  520 */         allowedMentions(), 
/*  521 */         messageReference(), 
/*  522 */         components(), 
/*  523 */         embeds(), 
/*  524 */         username(), 
/*  525 */         avatarUrl(), newValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean equals(Object another) {
/*  535 */     if (this == another) return true; 
/*  536 */     return (another instanceof ImmutableFollowupMessageRequest && 
/*  537 */       equalTo(0, (ImmutableFollowupMessageRequest)another));
/*      */   }
/*      */   
/*      */   private boolean equalTo(int synthetic, ImmutableFollowupMessageRequest another) {
/*  541 */     return (content().equals(another.content()) && 
/*  542 */       tts().equals(another.tts()) && 
/*  543 */       allowedMentions().equals(another.allowedMentions()) && 
/*  544 */       messageReference().equals(another.messageReference()) && 
/*  545 */       Objects.equals(this.components_value, another.components_value) && 
/*  546 */       Objects.equals(this.embeds_value, another.embeds_value) && 
/*  547 */       username().equals(another.username()) && 
/*  548 */       avatarUrl().equals(another.avatarUrl()) && 
/*  549 */       flags().equals(another.flags()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int hashCode() {
/*  558 */     int h = 5381;
/*  559 */     h += (h << 5) + content().hashCode();
/*  560 */     h += (h << 5) + tts().hashCode();
/*  561 */     h += (h << 5) + allowedMentions().hashCode();
/*  562 */     h += (h << 5) + messageReference().hashCode();
/*  563 */     h += (h << 5) + Objects.hashCode(this.components_value);
/*  564 */     h += (h << 5) + Objects.hashCode(this.embeds_value);
/*  565 */     h += (h << 5) + username().hashCode();
/*  566 */     h += (h << 5) + avatarUrl().hashCode();
/*  567 */     h += (h << 5) + flags().hashCode();
/*  568 */     return h;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/*  577 */     return "FollowupMessageRequest{content=" + 
/*  578 */       content().toString() + ", tts=" + 
/*  579 */       tts().toString() + ", allowedMentions=" + 
/*  580 */       allowedMentions().toString() + ", messageReference=" + 
/*  581 */       messageReference().toString() + ", components=" + 
/*  582 */       Objects.toString(this.components_value) + ", embeds=" + 
/*  583 */       Objects.toString(this.embeds_value) + ", username=" + 
/*  584 */       username().toString() + ", avatarUrl=" + 
/*  585 */       avatarUrl().toString() + ", flags=" + 
/*  586 */       flags().toString() + "}";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonDeserialize
/*      */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*      */   @Generated(from = "FollowupMessageRequest", generator = "Immutables")
/*      */   static final class Json
/*      */     implements FollowupMessageRequest
/*      */   {
/*  600 */     Possible<String> content = Possible.absent();
/*      */ 
/*      */     
/*  603 */     Possible<Boolean> tts = Possible.absent();
/*      */ 
/*      */     
/*  606 */     Possible<AllowedMentionsData> allowedMentions = Possible.absent();
/*      */ 
/*      */     
/*  609 */     Possible<MessageReferenceData> messageReference = Possible.absent();
/*      */ 
/*      */     
/*  612 */     Possible<List<ComponentData>> components = Possible.absent();
/*      */ 
/*      */     
/*  615 */     Possible<List<EmbedData>> embeds = Possible.absent();
/*      */ 
/*      */     
/*  618 */     Possible<String> username = Possible.absent();
/*      */ 
/*      */     
/*  621 */     Possible<String> avatarUrl = Possible.absent();
/*      */ 
/*      */     
/*  624 */     Possible<Integer> flags = Possible.absent();
/*      */     
/*      */     @JsonProperty("content")
/*      */     public void setContent(Possible<String> content) {
/*  628 */       this.content = content;
/*      */     }
/*      */     @JsonProperty("tts")
/*      */     public void setTts(Possible<Boolean> tts) {
/*  632 */       this.tts = tts;
/*      */     }
/*      */     @JsonProperty("allowed_mentions")
/*      */     public void setAllowedMentions(Possible<AllowedMentionsData> allowedMentions) {
/*  636 */       this.allowedMentions = allowedMentions;
/*      */     }
/*      */     @JsonProperty("message_reference")
/*      */     public void setMessageReference(Possible<MessageReferenceData> messageReference) {
/*  640 */       this.messageReference = messageReference;
/*      */     }
/*      */     @JsonProperty("components")
/*      */     public void setComponents(Possible<List<ComponentData>> components) {
/*  644 */       this.components = components;
/*      */     }
/*      */     @JsonProperty("embeds")
/*      */     public void setEmbeds(Possible<List<EmbedData>> embeds) {
/*  648 */       this.embeds = embeds;
/*      */     }
/*      */     @JsonProperty("username")
/*      */     public void setUsername(Possible<String> username) {
/*  652 */       this.username = username;
/*      */     }
/*      */     @JsonProperty("avatar_url")
/*      */     public void setAvatarUrl(Possible<String> avatarUrl) {
/*  656 */       this.avatarUrl = avatarUrl;
/*      */     }
/*      */     @JsonProperty("flags")
/*      */     public void setFlags(Possible<Integer> flags) {
/*  660 */       this.flags = flags;
/*      */     }
/*      */     public Possible<String> content() {
/*  663 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Boolean> tts() {
/*  665 */       throw new UnsupportedOperationException();
/*      */     } public Possible<AllowedMentionsData> allowedMentions() {
/*  667 */       throw new UnsupportedOperationException();
/*      */     } public Possible<MessageReferenceData> messageReference() {
/*  669 */       throw new UnsupportedOperationException();
/*      */     } public Possible<List<ComponentData>> components() {
/*  671 */       throw new UnsupportedOperationException();
/*      */     } public Possible<List<EmbedData>> embeds() {
/*  673 */       throw new UnsupportedOperationException();
/*      */     } public Possible<String> username() {
/*  675 */       throw new UnsupportedOperationException();
/*      */     } public Possible<String> avatarUrl() {
/*  677 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Integer> flags() {
/*  679 */       throw new UnsupportedOperationException();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*      */   static ImmutableFollowupMessageRequest fromJson(Json json) {
/*  690 */     Builder builder = builder();
/*  691 */     if (json.content != null) {
/*  692 */       builder.content(json.content);
/*      */     }
/*  694 */     if (json.tts != null) {
/*  695 */       builder.tts(json.tts);
/*      */     }
/*  697 */     if (json.allowedMentions != null) {
/*  698 */       builder.allowedMentions(json.allowedMentions);
/*      */     }
/*  700 */     if (json.messageReference != null) {
/*  701 */       builder.messageReference(json.messageReference);
/*      */     }
/*  703 */     if (json.components != null) {
/*  704 */       builder.components(json.components);
/*      */     }
/*  706 */     if (json.embeds != null) {
/*  707 */       builder.embeds(json.embeds);
/*      */     }
/*  709 */     if (json.username != null) {
/*  710 */       builder.username(json.username);
/*      */     }
/*  712 */     if (json.avatarUrl != null) {
/*  713 */       builder.avatarUrl(json.avatarUrl);
/*      */     }
/*  715 */     if (json.flags != null) {
/*  716 */       builder.flags(json.flags);
/*      */     }
/*  718 */     return builder.build();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableFollowupMessageRequest of(Possible<String> content, Possible<Boolean> tts, Possible<AllowedMentionsData> allowedMentions, Possible<MessageReferenceData> messageReference, Possible<List<ComponentData>> components, Possible<List<EmbedData>> embeds, Possible<String> username, Possible<String> avatarUrl, Possible<Integer> flags) {
/*  735 */     return new ImmutableFollowupMessageRequest(content, tts, allowedMentions, messageReference, components, embeds, username, avatarUrl, flags);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableFollowupMessageRequest copyOf(FollowupMessageRequest instance) {
/*  746 */     if (instance instanceof ImmutableFollowupMessageRequest) {
/*  747 */       return (ImmutableFollowupMessageRequest)instance;
/*      */     }
/*  749 */     return builder()
/*  750 */       .from(instance)
/*  751 */       .build();
/*      */   }
/*      */   
/*      */   public boolean isContentPresent() {
/*  755 */     return !this.content_absent;
/*      */   }
/*      */   
/*      */   public String contentOrElse(String defaultValue) {
/*  759 */     return !this.content_absent ? this.content_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isTtsPresent() {
/*  763 */     return !this.tts_absent;
/*      */   }
/*      */   
/*      */   public Boolean ttsOrElse(Boolean defaultValue) {
/*  767 */     return !this.tts_absent ? this.tts_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isAllowedMentionsPresent() {
/*  771 */     return !this.allowedMentions_absent;
/*      */   }
/*      */   
/*      */   public AllowedMentionsData allowedMentionsOrElse(AllowedMentionsData defaultValue) {
/*  775 */     return !this.allowedMentions_absent ? this.allowedMentions_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isMessageReferencePresent() {
/*  779 */     return !this.messageReference_absent;
/*      */   }
/*      */   
/*      */   public MessageReferenceData messageReferenceOrElse(MessageReferenceData defaultValue) {
/*  783 */     return !this.messageReference_absent ? this.messageReference_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isComponentsPresent() {
/*  787 */     return !this.components_absent;
/*      */   }
/*      */   
/*      */   public List<ComponentData> componentsOrElse(List<ComponentData> defaultValue) {
/*  791 */     return !this.components_absent ? this.components_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isEmbedsPresent() {
/*  795 */     return !this.embeds_absent;
/*      */   }
/*      */   
/*      */   public List<EmbedData> embedsOrElse(List<EmbedData> defaultValue) {
/*  799 */     return !this.embeds_absent ? this.embeds_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isUsernamePresent() {
/*  803 */     return !this.username_absent;
/*      */   }
/*      */   
/*      */   public String usernameOrElse(String defaultValue) {
/*  807 */     return !this.username_absent ? this.username_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isAvatarUrlPresent() {
/*  811 */     return !this.avatarUrl_absent;
/*      */   }
/*      */   
/*      */   public String avatarUrlOrElse(String defaultValue) {
/*  815 */     return !this.avatarUrl_absent ? this.avatarUrl_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isFlagsPresent() {
/*  819 */     return !this.flags_absent;
/*      */   }
/*      */   
/*      */   public Integer flagsOrElse(Integer defaultValue) {
/*  823 */     return !this.flags_absent ? this.flags_value : defaultValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Builder builder() {
/*  844 */     return new Builder();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Generated(from = "FollowupMessageRequest", generator = "Immutables")
/*      */   public static final class Builder
/*      */   {
/*  856 */     private Possible<String> content_possible = Possible.absent();
/*  857 */     private Possible<Boolean> tts_possible = Possible.absent();
/*  858 */     private Possible<AllowedMentionsData> allowedMentions_possible = Possible.absent();
/*  859 */     private Possible<MessageReferenceData> messageReference_possible = Possible.absent();
/*  860 */     private List<ComponentData> components_list = null;
/*  861 */     private List<EmbedData> embeds_list = null;
/*  862 */     private Possible<String> username_possible = Possible.absent();
/*  863 */     private Possible<String> avatarUrl_possible = Possible.absent();
/*  864 */     private Possible<Integer> flags_possible = Possible.absent();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder from(FollowupMessageRequest instance) {
/*  875 */       Objects.requireNonNull(instance, "instance");
/*  876 */       from(instance);
/*  877 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder from(WebhookExecuteRequest instance) {
/*  886 */       Objects.requireNonNull(instance, "instance");
/*  887 */       from(instance);
/*  888 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder from(MessageSendRequestBase instance) {
/*  897 */       Objects.requireNonNull(instance, "instance");
/*  898 */       from(instance);
/*  899 */       return this;
/*      */     }
/*      */     
/*      */     private void from(Object object) {
/*  903 */       long bits = 0L;
/*  904 */       if (object instanceof FollowupMessageRequest) {
/*  905 */         FollowupMessageRequest instance = (FollowupMessageRequest)object;
/*  906 */         if ((bits & 0x1L) == 0L) {
/*  907 */           messageReference(instance.messageReference());
/*  908 */           bits |= 0x1L;
/*      */         } 
/*  910 */         if ((bits & 0x2L) == 0L) {
/*  911 */           tts(instance.tts());
/*  912 */           bits |= 0x2L;
/*      */         } 
/*  914 */         if ((bits & 0x4L) == 0L) {
/*  915 */           components(instance.components());
/*  916 */           bits |= 0x4L;
/*      */         } 
/*  918 */         if ((bits & 0x8L) == 0L) {
/*  919 */           avatarUrl(instance.avatarUrl());
/*  920 */           bits |= 0x8L;
/*      */         } 
/*  922 */         flags(instance.flags());
/*  923 */         if ((bits & 0x10L) == 0L) {
/*  924 */           embeds(instance.embeds());
/*  925 */           bits |= 0x10L;
/*      */         } 
/*  927 */         if ((bits & 0x20L) == 0L) {
/*  928 */           content(instance.content());
/*  929 */           bits |= 0x20L;
/*      */         } 
/*  931 */         if ((bits & 0x40L) == 0L) {
/*  932 */           allowedMentions(instance.allowedMentions());
/*  933 */           bits |= 0x40L;
/*      */         } 
/*  935 */         if ((bits & 0x80L) == 0L) {
/*  936 */           username(instance.username());
/*  937 */           bits |= 0x80L;
/*      */         } 
/*      */       } 
/*  940 */       if (object instanceof WebhookExecuteRequest) {
/*  941 */         WebhookExecuteRequest instance = (WebhookExecuteRequest)object;
/*  942 */         if ((bits & 0x1L) == 0L) {
/*  943 */           messageReference(instance.messageReference());
/*  944 */           bits |= 0x1L;
/*      */         } 
/*  946 */         if ((bits & 0x2L) == 0L) {
/*  947 */           tts(instance.tts());
/*  948 */           bits |= 0x2L;
/*      */         } 
/*  950 */         if ((bits & 0x4L) == 0L) {
/*  951 */           components(instance.components());
/*  952 */           bits |= 0x4L;
/*      */         } 
/*  954 */         if ((bits & 0x8L) == 0L) {
/*  955 */           avatarUrl(instance.avatarUrl());
/*  956 */           bits |= 0x8L;
/*      */         } 
/*  958 */         if ((bits & 0x10L) == 0L) {
/*  959 */           embeds(instance.embeds());
/*  960 */           bits |= 0x10L;
/*      */         } 
/*  962 */         if ((bits & 0x20L) == 0L) {
/*  963 */           content(instance.content());
/*  964 */           bits |= 0x20L;
/*      */         } 
/*  966 */         if ((bits & 0x40L) == 0L) {
/*  967 */           allowedMentions(instance.allowedMentions());
/*  968 */           bits |= 0x40L;
/*      */         } 
/*  970 */         if ((bits & 0x80L) == 0L) {
/*  971 */           username(instance.username());
/*  972 */           bits |= 0x80L;
/*      */         } 
/*      */       } 
/*  975 */       if (object instanceof MessageSendRequestBase) {
/*  976 */         MessageSendRequestBase instance = (MessageSendRequestBase)object;
/*  977 */         if ((bits & 0x1L) == 0L) {
/*  978 */           messageReference(instance.messageReference());
/*  979 */           bits |= 0x1L;
/*      */         } 
/*  981 */         if ((bits & 0x2L) == 0L) {
/*  982 */           tts(instance.tts());
/*  983 */           bits |= 0x2L;
/*      */         } 
/*  985 */         if ((bits & 0x4L) == 0L) {
/*  986 */           components(instance.components());
/*  987 */           bits |= 0x4L;
/*      */         } 
/*  989 */         if ((bits & 0x10L) == 0L) {
/*  990 */           embeds(instance.embeds());
/*  991 */           bits |= 0x10L;
/*      */         } 
/*  993 */         if ((bits & 0x20L) == 0L) {
/*  994 */           content(instance.content());
/*  995 */           bits |= 0x20L;
/*      */         } 
/*  997 */         if ((bits & 0x40L) == 0L) {
/*  998 */           allowedMentions(instance.allowedMentions());
/*  999 */           bits |= 0x40L;
/*      */         } 
/*      */       } 
/*      */     }
/*      */     
/*      */     @JsonProperty("content")
/*      */     public Builder content(Possible<String> value) {
/* 1006 */       this.content_possible = value;
/* 1007 */       return this;
/*      */     }
/*      */     
/*      */     public Builder content(String value) {
/* 1011 */       this.content_possible = Possible.of(value);
/* 1012 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("tts")
/*      */     public Builder tts(Possible<Boolean> value) {
/* 1017 */       this.tts_possible = value;
/* 1018 */       return this;
/*      */     }
/*      */     
/*      */     public Builder tts(Boolean value) {
/* 1022 */       this.tts_possible = Possible.of(value);
/* 1023 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("allowed_mentions")
/*      */     public Builder allowedMentions(Possible<AllowedMentionsData> value) {
/* 1028 */       this.allowedMentions_possible = value;
/* 1029 */       return this;
/*      */     }
/*      */     
/*      */     public Builder allowedMentions(AllowedMentionsData value) {
/* 1033 */       this.allowedMentions_possible = Possible.of(value);
/* 1034 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("message_reference")
/*      */     public Builder messageReference(Possible<MessageReferenceData> value) {
/* 1039 */       this.messageReference_possible = value;
/* 1040 */       return this;
/*      */     }
/*      */     
/*      */     public Builder messageReference(MessageReferenceData value) {
/* 1044 */       this.messageReference_possible = Possible.of(value);
/* 1045 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addComponent(ComponentData element) {
/* 1049 */       components_getOrCreate().add(element);
/* 1050 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addAllComponents(List<ComponentData> elements) {
/* 1054 */       components_getOrCreate().addAll(elements);
/* 1055 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("components")
/*      */     public Builder components(Possible<List<ComponentData>> elements) {
/* 1060 */       this.components_list = null;
/* 1061 */       elements.toOptional().ifPresent(e -> components_getOrCreate().addAll(e));
/* 1062 */       return this;
/*      */     }
/*      */     
/*      */     public Builder components(List<ComponentData> elements) {
/* 1066 */       this.components_list = new ArrayList<>(elements);
/* 1067 */       return this;
/*      */     }
/*      */     
/*      */     public Builder components(Iterable<ComponentData> elements) {
/* 1071 */       this.components_list = (List<ComponentData>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/* 1072 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addEmbed(EmbedData element) {
/* 1076 */       embeds_getOrCreate().add(element);
/* 1077 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addAllEmbeds(List<EmbedData> elements) {
/* 1081 */       embeds_getOrCreate().addAll(elements);
/* 1082 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("embeds")
/*      */     public Builder embeds(Possible<List<EmbedData>> elements) {
/* 1087 */       this.embeds_list = null;
/* 1088 */       elements.toOptional().ifPresent(e -> embeds_getOrCreate().addAll(e));
/* 1089 */       return this;
/*      */     }
/*      */     
/*      */     public Builder embeds(List<EmbedData> elements) {
/* 1093 */       this.embeds_list = new ArrayList<>(elements);
/* 1094 */       return this;
/*      */     }
/*      */     
/*      */     public Builder embeds(Iterable<EmbedData> elements) {
/* 1098 */       this.embeds_list = (List<EmbedData>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/* 1099 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("username")
/*      */     public Builder username(Possible<String> value) {
/* 1104 */       this.username_possible = value;
/* 1105 */       return this;
/*      */     }
/*      */     
/*      */     public Builder username(String value) {
/* 1109 */       this.username_possible = Possible.of(value);
/* 1110 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("avatar_url")
/*      */     public Builder avatarUrl(Possible<String> value) {
/* 1115 */       this.avatarUrl_possible = value;
/* 1116 */       return this;
/*      */     }
/*      */     
/*      */     public Builder avatarUrl(String value) {
/* 1120 */       this.avatarUrl_possible = Possible.of(value);
/* 1121 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("flags")
/*      */     public Builder flags(Possible<Integer> value) {
/* 1126 */       this.flags_possible = value;
/* 1127 */       return this;
/*      */     }
/*      */     
/*      */     public Builder flags(Integer value) {
/* 1131 */       this.flags_possible = Possible.of(value);
/* 1132 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ImmutableFollowupMessageRequest build() {
/* 1141 */       return new ImmutableFollowupMessageRequest(null, 
/*      */           
/* 1143 */           content_build(), 
/* 1144 */           tts_build(), 
/* 1145 */           allowedMentions_build(), 
/* 1146 */           messageReference_build(), 
/* 1147 */           components_build(), 
/* 1148 */           embeds_build(), 
/* 1149 */           username_build(), 
/* 1150 */           avatarUrl_build(), 
/* 1151 */           flags_build());
/*      */     }
/*      */     
/*      */     private Possible<String> content_build() {
/* 1155 */       return this.content_possible;
/*      */     }
/*      */     
/*      */     private Possible<Boolean> tts_build() {
/* 1159 */       return this.tts_possible;
/*      */     }
/*      */     
/*      */     private Possible<AllowedMentionsData> allowedMentions_build() {
/* 1163 */       return this.allowedMentions_possible;
/*      */     }
/*      */     
/*      */     private Possible<MessageReferenceData> messageReference_build() {
/* 1167 */       return this.messageReference_possible;
/*      */     }
/*      */     
/*      */     private Possible<List<ComponentData>> components_build() {
/* 1171 */       return (this.components_list == null) ? Possible.absent() : 
/* 1172 */         Possible.of(this.components_list);
/*      */     }
/*      */     
/*      */     private List<ComponentData> components_getOrCreate() {
/* 1176 */       if (this.components_list == null) {
/* 1177 */         this.components_list = new ArrayList<>();
/*      */       }
/* 1179 */       return this.components_list;
/*      */     }
/*      */     
/*      */     private Possible<List<EmbedData>> embeds_build() {
/* 1183 */       return (this.embeds_list == null) ? Possible.absent() : 
/* 1184 */         Possible.of(this.embeds_list);
/*      */     }
/*      */     
/*      */     private List<EmbedData> embeds_getOrCreate() {
/* 1188 */       if (this.embeds_list == null) {
/* 1189 */         this.embeds_list = new ArrayList<>();
/*      */       }
/* 1191 */       return this.embeds_list;
/*      */     }
/*      */     
/*      */     private Possible<String> username_build() {
/* 1195 */       return this.username_possible;
/*      */     }
/*      */     
/*      */     private Possible<String> avatarUrl_build() {
/* 1199 */       return this.avatarUrl_possible;
/*      */     }
/*      */     
/*      */     private Possible<Integer> flags_build() {
/* 1203 */       return this.flags_possible;
/*      */     }
/*      */     
/*      */     private Builder() {}
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableFollowupMessageRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */