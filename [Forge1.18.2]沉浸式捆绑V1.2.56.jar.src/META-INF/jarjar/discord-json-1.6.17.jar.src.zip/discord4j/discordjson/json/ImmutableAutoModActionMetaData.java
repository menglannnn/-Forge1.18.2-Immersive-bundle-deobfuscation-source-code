/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.Id;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "AutoModActionMetaData", generator = "Immutables")
/*     */ public final class ImmutableAutoModActionMetaData
/*     */   implements AutoModActionMetaData
/*     */ {
/*     */   private final long channelId_value;
/*     */   private final boolean channelId_absent;
/*     */   private final Integer duration_value;
/*     */   private final boolean duration_absent;
/*     */   private final String customMessage_value;
/*     */   private final boolean customMessage_absent;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   
/*     */   private ImmutableAutoModActionMetaData(Possible<Id> channelId, Possible<Integer> duration, Possible<String> customMessage) {
/*  37 */     Possible<Id> channelId$impl = channelId;
/*  38 */     Possible<Integer> duration$impl = duration;
/*  39 */     Possible<String> customMessage$impl = customMessage;
/*  40 */     this
/*     */       
/*  42 */       .channelId_value = ((Long)channelId$impl.toOptional().map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  43 */     this.channelId_absent = channelId$impl.isAbsent();
/*  44 */     this.duration_value = duration$impl.toOptional().orElse(null);
/*  45 */     this.duration_absent = duration$impl.isAbsent();
/*  46 */     this.customMessage_value = customMessage$impl.toOptional().orElse(null);
/*  47 */     this.customMessage_absent = customMessage$impl.isAbsent();
/*  48 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ImmutableAutoModActionMetaData(ImmutableAutoModActionMetaData original, Possible<Id> channelId, Possible<Integer> duration, Possible<String> customMessage) {
/*  56 */     Possible<Id> channelId$impl = channelId;
/*  57 */     Possible<Integer> duration$impl = duration;
/*  58 */     Possible<String> customMessage$impl = customMessage;
/*  59 */     this
/*     */       
/*  61 */       .channelId_value = ((Long)channelId$impl.toOptional().map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  62 */     this.channelId_absent = channelId$impl.isAbsent();
/*  63 */     this.duration_value = duration$impl.toOptional().orElse(null);
/*  64 */     this.duration_absent = duration$impl.isAbsent();
/*  65 */     this.customMessage_value = customMessage$impl.toOptional().orElse(null);
/*  66 */     this.customMessage_absent = customMessage$impl.isAbsent();
/*  67 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  73 */   private volatile transient InitShim initShim = new InitShim();
/*     */   
/*     */   @Generated(from = "AutoModActionMetaData", generator = "Immutables")
/*     */   private final class InitShim {
/*     */     private String formatInitCycleMessage() {
/*  78 */       List<String> attributes = new ArrayList<>();
/*  79 */       return "Cannot build AutoModActionMetaData, attribute initializers form cycle " + attributes;
/*     */     }
/*     */ 
/*     */     
/*     */     private InitShim() {}
/*     */   }
/*     */ 
/*     */   
/*     */   @JsonProperty("channel_id")
/*     */   public Possible<Id> channelId() {
/*  89 */     return this.channelId_absent ? Possible.absent() : 
/*  90 */       Possible.of(Id.of(this.channelId_value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("duration_seconds")
/*     */   public Possible<Integer> duration() {
/*  99 */     return this.duration_absent ? Possible.absent() : Possible.of(this.duration_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("custom_message")
/*     */   public Possible<String> customMessage() {
/* 108 */     return this.customMessage_absent ? Possible.absent() : Possible.of(this.customMessage_value);
/*     */   }
/*     */   
/*     */   public ImmutableAutoModActionMetaData withChannelId(Possible<Id> value) {
/* 112 */     Possible<Id> newValue = Objects.<Possible<Id>>requireNonNull(value);
/* 113 */     return new ImmutableAutoModActionMetaData(this, newValue, duration(), customMessage());
/*     */   }
/*     */   
/*     */   public ImmutableAutoModActionMetaData withChannelId(long value) {
/* 117 */     Possible<Id> newValue = Possible.of(Id.of(value));
/* 118 */     return new ImmutableAutoModActionMetaData(this, newValue, duration(), customMessage());
/*     */   }
/*     */   
/*     */   public ImmutableAutoModActionMetaData withDuration(Possible<Integer> value) {
/* 122 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/* 123 */     return new ImmutableAutoModActionMetaData(this, channelId(), newValue, customMessage());
/*     */   }
/*     */   
/*     */   public ImmutableAutoModActionMetaData withDuration(Integer value) {
/* 127 */     Possible<Integer> newValue = Possible.of(value);
/* 128 */     return new ImmutableAutoModActionMetaData(this, channelId(), newValue, customMessage());
/*     */   }
/*     */   
/*     */   public ImmutableAutoModActionMetaData withCustomMessage(Possible<String> value) {
/* 132 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/* 133 */     return new ImmutableAutoModActionMetaData(this, channelId(), duration(), newValue);
/*     */   }
/*     */   
/*     */   public ImmutableAutoModActionMetaData withCustomMessage(String value) {
/* 137 */     Possible<String> newValue = Possible.of(value);
/* 138 */     return new ImmutableAutoModActionMetaData(this, channelId(), duration(), newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 147 */     if (this == another) return true; 
/* 148 */     return (another instanceof ImmutableAutoModActionMetaData && 
/* 149 */       equalTo(0, (ImmutableAutoModActionMetaData)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableAutoModActionMetaData another) {
/* 153 */     return (channelId().equals(another.channelId()) && 
/* 154 */       duration().equals(another.duration()) && 
/* 155 */       customMessage().equals(another.customMessage()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 164 */     int h = 5381;
/* 165 */     h += (h << 5) + channelId().hashCode();
/* 166 */     h += (h << 5) + duration().hashCode();
/* 167 */     h += (h << 5) + customMessage().hashCode();
/* 168 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 177 */     return "AutoModActionMetaData{channelId=" + 
/* 178 */       channelId().toString() + ", duration=" + 
/* 179 */       duration().toString() + ", customMessage=" + 
/* 180 */       customMessage().toString() + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "AutoModActionMetaData", generator = "Immutables")
/*     */   static final class Json
/*     */     implements AutoModActionMetaData
/*     */   {
/* 194 */     Possible<Id> channelId = Possible.absent();
/*     */ 
/*     */     
/* 197 */     Possible<Integer> duration = Possible.absent();
/*     */ 
/*     */     
/* 200 */     Possible<String> customMessage = Possible.absent();
/*     */     
/*     */     @JsonProperty("channel_id")
/*     */     public void setChannelId(Possible<Id> channelId) {
/* 204 */       this.channelId = channelId;
/*     */     }
/*     */     @JsonProperty("duration_seconds")
/*     */     public void setDuration(Possible<Integer> duration) {
/* 208 */       this.duration = duration;
/*     */     }
/*     */     @JsonProperty("custom_message")
/*     */     public void setCustomMessage(Possible<String> customMessage) {
/* 212 */       this.customMessage = customMessage;
/*     */     }
/*     */     public Possible<Id> channelId() {
/* 215 */       throw new UnsupportedOperationException();
/*     */     } public Possible<Integer> duration() {
/* 217 */       throw new UnsupportedOperationException();
/*     */     } public Possible<String> customMessage() {
/* 219 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableAutoModActionMetaData fromJson(Json json) {
/* 230 */     Builder builder = builder();
/* 231 */     if (json.channelId != null) {
/* 232 */       builder.channelId(json.channelId);
/*     */     }
/* 234 */     if (json.duration != null) {
/* 235 */       builder.duration(json.duration);
/*     */     }
/* 237 */     if (json.customMessage != null) {
/* 238 */       builder.customMessage(json.customMessage);
/*     */     }
/* 240 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableAutoModActionMetaData of(Possible<Id> channelId, Possible<Integer> duration, Possible<String> customMessage) {
/* 251 */     return new ImmutableAutoModActionMetaData(channelId, duration, customMessage);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableAutoModActionMetaData copyOf(AutoModActionMetaData instance) {
/* 262 */     if (instance instanceof ImmutableAutoModActionMetaData) {
/* 263 */       return (ImmutableAutoModActionMetaData)instance;
/*     */     }
/* 265 */     return builder()
/* 266 */       .from(instance)
/* 267 */       .build();
/*     */   }
/*     */   
/*     */   public boolean isChannelIdPresent() {
/* 271 */     return !this.channelId_absent;
/*     */   }
/*     */   
/*     */   public long channelIdOrElse(long defaultValue) {
/* 275 */     return !this.channelId_absent ? this.channelId_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isDurationPresent() {
/* 279 */     return !this.duration_absent;
/*     */   }
/*     */   
/*     */   public Integer durationOrElse(Integer defaultValue) {
/* 283 */     return !this.duration_absent ? this.duration_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isCustomMessagePresent() {
/* 287 */     return !this.customMessage_absent;
/*     */   }
/*     */   
/*     */   public String customMessageOrElse(String defaultValue) {
/* 291 */     return !this.customMessage_absent ? this.customMessage_value : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 306 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "AutoModActionMetaData", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/* 318 */     private Possible<Id> channelId_possible = Possible.absent();
/* 319 */     private Possible<Integer> duration_possible = Possible.absent();
/* 320 */     private Possible<String> customMessage_possible = Possible.absent();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(AutoModActionMetaData instance) {
/* 333 */       Objects.requireNonNull(instance, "instance");
/* 334 */       channelId(instance.channelId());
/* 335 */       duration(instance.duration());
/* 336 */       customMessage(instance.customMessage());
/* 337 */       return this;
/*     */     }
/*     */     
/*     */     public Builder channelId(String value) {
/* 341 */       this.channelId_possible = Possible.of(Id.of(value));
/* 342 */       return this;
/*     */     }
/*     */     
/*     */     public Builder channelId(long value) {
/* 346 */       this.channelId_possible = Possible.of(Id.of(value));
/* 347 */       return this;
/*     */     }
/*     */     
/*     */     public Builder channelId(Id value) {
/* 351 */       this.channelId_possible = Possible.of(value);
/* 352 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("channel_id")
/*     */     public Builder channelId(Possible<Id> value) {
/* 357 */       this.channelId_possible = value;
/* 358 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("duration_seconds")
/*     */     public Builder duration(Possible<Integer> value) {
/* 363 */       this.duration_possible = value;
/* 364 */       return this;
/*     */     }
/*     */     
/*     */     public Builder duration(Integer value) {
/* 368 */       this.duration_possible = Possible.of(value);
/* 369 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("custom_message")
/*     */     public Builder customMessage(Possible<String> value) {
/* 374 */       this.customMessage_possible = value;
/* 375 */       return this;
/*     */     }
/*     */     
/*     */     public Builder customMessage(String value) {
/* 379 */       this.customMessage_possible = Possible.of(value);
/* 380 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableAutoModActionMetaData build() {
/* 389 */       return new ImmutableAutoModActionMetaData(null, channelId_build(), duration_build(), customMessage_build());
/*     */     }
/*     */     
/*     */     private Possible<Id> channelId_build() {
/* 393 */       return this.channelId_possible;
/*     */     }
/*     */     
/*     */     private Possible<Integer> duration_build() {
/* 397 */       return this.duration_possible;
/*     */     }
/*     */     
/*     */     private Possible<String> customMessage_build() {
/* 401 */       return this.customMessage_possible;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableAutoModActionMetaData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */