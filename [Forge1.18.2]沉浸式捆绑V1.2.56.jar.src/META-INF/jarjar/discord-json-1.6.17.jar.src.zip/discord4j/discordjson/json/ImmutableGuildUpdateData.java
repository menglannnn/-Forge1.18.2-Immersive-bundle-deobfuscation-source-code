/*      */ package discord4j.discordjson.json;
/*      */ 
/*      */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*      */ import com.fasterxml.jackson.annotation.JsonCreator;
/*      */ import com.fasterxml.jackson.annotation.JsonProperty;
/*      */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*      */ import discord4j.discordjson.Id;
/*      */ import discord4j.discordjson.possible.Possible;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.List;
/*      */ import java.util.Objects;
/*      */ import java.util.Optional;
/*      */ import java.util.OptionalInt;
/*      */ import java.util.stream.Collectors;
/*      */ import java.util.stream.StreamSupport;
/*      */ import org.immutables.value.Generated;
/*      */ import reactor.util.annotation.Nullable;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ @Generated(from = "GuildUpdateData", generator = "Immutables")
/*      */ public final class ImmutableGuildUpdateData
/*      */   implements GuildUpdateData
/*      */ {
/*      */   private final long id_value;
/*      */   private final String name;
/*      */   private final String icon;
/*      */   private final String splash;
/*      */   private final String discoverySplash;
/*      */   private final Boolean owner_value;
/*      */   private final boolean owner_absent;
/*      */   private final Long permissions_value;
/*      */   private final boolean permissions_absent;
/*      */   private final long afkChannelId_value;
/*      */   private final boolean afkChannelId_present;
/*      */   private final Boolean embedEnabled_value;
/*      */   private final boolean embedEnabled_absent;
/*      */   private final long embedChannelId_value;
/*      */   private final boolean embedChannelId_absent;
/*      */   private final boolean embedChannelId_isNull;
/*      */   private final List<String> features;
/*      */   private final long applicationId_value;
/*      */   private final boolean applicationId_present;
/*      */   private final Boolean widgetEnabled_value;
/*      */   private final boolean widgetEnabled_absent;
/*      */   private final long widgetChannelId_value;
/*      */   private final boolean widgetChannelId_absent;
/*      */   private final boolean widgetChannelId_isNull;
/*      */   private final long systemChannelId_value;
/*      */   private final boolean systemChannelId_present;
/*      */   private final Integer systemChannelFlags;
/*      */   private final long rulesChannelId_value;
/*      */   private final boolean rulesChannelId_present;
/*      */   private final Integer maxPresences_value;
/*      */   private final boolean maxPresences_absent;
/*      */   private final Integer maxMembers_value;
/*      */   private final boolean maxMembers_absent;
/*      */   private final String vanityUrlCode;
/*      */   private final String description;
/*      */   private final String banner;
/*      */   private final Integer premiumSubscriptionCount_value;
/*      */   private final boolean premiumSubscriptionCount_absent;
/*      */   private final long publicUpdatesChannelId_value;
/*      */   private final boolean publicUpdatesChannelId_present;
/*      */   private final Integer maxVideoChannelUsers_value;
/*      */   private final boolean maxVideoChannelUsers_absent;
/*      */   private final Integer approximateMemberCount_value;
/*      */   private final boolean approximateMemberCount_absent;
/*      */   private final Integer approximatePresenceCount_value;
/*      */   private final boolean approximatePresenceCount_absent;
/*      */   private final WelcomeScreenData welcomeScreen_value;
/*      */   private final boolean welcomeScreen_absent;
/*      */   private final Boolean nsfw_value;
/*      */   private final boolean nsfw_absent;
/*      */   private final long safetyAlertsChannelId_value;
/*      */   private final boolean safetyAlertsChannelId_present;
/*      */   private final int verificationLevel;
/*      */   private final int nsfwLevel;
/*      */   private final long ownerId_value;
/*      */   private final String region_value;
/*      */   private final boolean region_absent;
/*      */   private final int afkTimeout;
/*      */   private final int defaultMessageNotifications;
/*      */   private final int explicitContentFilter;
/*      */   private final int mfaLevel;
/*      */   private final int premiumTier;
/*      */   private final String preferredLocale;
/*      */   private final List<RoleData> roles;
/*      */   private final List<EmojiData> emojis;
/*      */   private final List<StickerData> stickers_value;
/*      */   private final boolean stickers_absent;
/*      */   private static final byte STAGE_INITIALIZING = -1;
/*      */   private static final byte STAGE_UNINITIALIZED = 0;
/*      */   private static final byte STAGE_INITIALIZED = 1;
/*      */   
/*      */   private ImmutableGuildUpdateData(Id id, String name, Optional<String> icon, Optional<String> splash, Optional<String> discoverySplash, Possible<Boolean> owner, Possible<Long> permissions, Optional<Id> afkChannelId, Possible<Boolean> embedEnabled, Possible<Optional<Id>> embedChannelId, Iterable<String> features, Optional<Id> applicationId, Possible<Boolean> widgetEnabled, Possible<Optional<Id>> widgetChannelId, Optional<Id> systemChannelId, OptionalInt systemChannelFlags, Optional<Id> rulesChannelId, Possible<Optional<Integer>> maxPresences, Possible<Integer> maxMembers, Optional<String> vanityUrlCode, Optional<String> description, Optional<String> banner, Possible<Integer> premiumSubscriptionCount, Optional<Id> publicUpdatesChannelId, Possible<Integer> maxVideoChannelUsers, Possible<Integer> approximateMemberCount, Possible<Integer> approximatePresenceCount, Possible<WelcomeScreenData> welcomeScreen, Possible<Boolean> nsfw, Optional<Id> safetyAlertsChannelId, int verificationLevel, int nsfwLevel, Id ownerId, Possible<Optional<String>> region, int afkTimeout, int defaultMessageNotifications, int explicitContentFilter, int mfaLevel, int premiumTier, String preferredLocale, Iterable<? extends RoleData> roles, Iterable<? extends EmojiData> emojis, Possible<List<StickerData>> stickers) {
/*  146 */     Id id$impl = id;
/*  147 */     this.name = Objects.<String>requireNonNull(name, "name");
/*  148 */     this.icon = icon.orElse(null);
/*  149 */     this.splash = splash.orElse(null);
/*  150 */     this.discoverySplash = discoverySplash.orElse(null);
/*  151 */     Possible<Boolean> owner$impl = owner;
/*  152 */     Possible<Long> permissions$impl = permissions;
/*  153 */     Optional<Id> afkChannelId$impl = afkChannelId;
/*  154 */     Possible<Boolean> embedEnabled$impl = embedEnabled;
/*  155 */     Possible<Optional<Id>> embedChannelId$impl = embedChannelId;
/*  156 */     this.features = createUnmodifiableList(false, createSafeList(features, true, false));
/*  157 */     Optional<Id> applicationId$impl = applicationId;
/*  158 */     Possible<Boolean> widgetEnabled$impl = widgetEnabled;
/*  159 */     Possible<Optional<Id>> widgetChannelId$impl = widgetChannelId;
/*  160 */     Optional<Id> systemChannelId$impl = systemChannelId;
/*  161 */     this.systemChannelFlags = systemChannelFlags.isPresent() ? Integer.valueOf(systemChannelFlags.getAsInt()) : null;
/*  162 */     Optional<Id> rulesChannelId$impl = rulesChannelId;
/*  163 */     Possible<Optional<Integer>> maxPresences$impl = maxPresences;
/*  164 */     Possible<Integer> maxMembers$impl = maxMembers;
/*  165 */     this.vanityUrlCode = vanityUrlCode.orElse(null);
/*  166 */     this.description = description.orElse(null);
/*  167 */     this.banner = banner.orElse(null);
/*  168 */     Possible<Integer> premiumSubscriptionCount$impl = premiumSubscriptionCount;
/*  169 */     Optional<Id> publicUpdatesChannelId$impl = publicUpdatesChannelId;
/*  170 */     Possible<Integer> maxVideoChannelUsers$impl = maxVideoChannelUsers;
/*  171 */     Possible<Integer> approximateMemberCount$impl = approximateMemberCount;
/*  172 */     Possible<Integer> approximatePresenceCount$impl = approximatePresenceCount;
/*  173 */     Possible<WelcomeScreenData> welcomeScreen$impl = welcomeScreen;
/*  174 */     Possible<Boolean> nsfw$impl = nsfw;
/*  175 */     Optional<Id> safetyAlertsChannelId$impl = safetyAlertsChannelId;
/*  176 */     this.verificationLevel = verificationLevel;
/*  177 */     this.nsfwLevel = nsfwLevel;
/*  178 */     Id ownerId$impl = ownerId;
/*  179 */     Possible<Optional<String>> region$impl = region;
/*  180 */     this.afkTimeout = afkTimeout;
/*  181 */     this.defaultMessageNotifications = defaultMessageNotifications;
/*  182 */     this.explicitContentFilter = explicitContentFilter;
/*  183 */     this.mfaLevel = mfaLevel;
/*  184 */     this.premiumTier = premiumTier;
/*  185 */     this.preferredLocale = Objects.<String>requireNonNull(preferredLocale, "preferredLocale");
/*  186 */     this.roles = createUnmodifiableList(false, createSafeList(roles, true, false));
/*  187 */     this.emojis = createUnmodifiableList(false, createSafeList(emojis, true, false));
/*  188 */     Possible<List<StickerData>> stickers$impl = stickers;
/*  189 */     this.id_value = id$impl.asLong();
/*  190 */     this.owner_value = owner$impl.toOptional().orElse(null);
/*  191 */     this.owner_absent = owner$impl.isAbsent();
/*  192 */     this.permissions_value = permissions$impl.toOptional().orElse(null);
/*  193 */     this.permissions_absent = permissions$impl.isAbsent();
/*  194 */     this
/*      */       
/*  196 */       .afkChannelId_value = ((Long)afkChannelId$impl.<Long>map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  197 */     this.afkChannelId_present = afkChannelId$impl.isPresent();
/*  198 */     this.embedEnabled_value = embedEnabled$impl.toOptional().orElse(null);
/*  199 */     this.embedEnabled_absent = embedEnabled$impl.isAbsent();
/*  200 */     this
/*      */       
/*  202 */       .embedChannelId_value = ((Long)Possible.flatOpt(embedChannelId$impl).map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  203 */     this.embedChannelId_absent = embedChannelId$impl.isAbsent();
/*  204 */     this.embedChannelId_isNull = (!embedChannelId$impl.isAbsent() && !((Optional)embedChannelId$impl.get()).isPresent());
/*  205 */     this
/*      */       
/*  207 */       .applicationId_value = ((Long)applicationId$impl.<Long>map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  208 */     this.applicationId_present = applicationId$impl.isPresent();
/*  209 */     this.widgetEnabled_value = widgetEnabled$impl.toOptional().orElse(null);
/*  210 */     this.widgetEnabled_absent = widgetEnabled$impl.isAbsent();
/*  211 */     this
/*      */       
/*  213 */       .widgetChannelId_value = ((Long)Possible.flatOpt(widgetChannelId$impl).map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  214 */     this.widgetChannelId_absent = widgetChannelId$impl.isAbsent();
/*  215 */     this.widgetChannelId_isNull = (!widgetChannelId$impl.isAbsent() && !((Optional)widgetChannelId$impl.get()).isPresent());
/*  216 */     this
/*      */       
/*  218 */       .systemChannelId_value = ((Long)systemChannelId$impl.<Long>map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  219 */     this.systemChannelId_present = systemChannelId$impl.isPresent();
/*  220 */     this
/*      */       
/*  222 */       .rulesChannelId_value = ((Long)rulesChannelId$impl.<Long>map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  223 */     this.rulesChannelId_present = rulesChannelId$impl.isPresent();
/*  224 */     this.maxPresences_value = Possible.flatOpt(maxPresences$impl).orElse(null);
/*  225 */     this.maxPresences_absent = maxPresences$impl.isAbsent();
/*  226 */     this.maxMembers_value = maxMembers$impl.toOptional().orElse(null);
/*  227 */     this.maxMembers_absent = maxMembers$impl.isAbsent();
/*  228 */     this.premiumSubscriptionCount_value = premiumSubscriptionCount$impl.toOptional().orElse(null);
/*  229 */     this.premiumSubscriptionCount_absent = premiumSubscriptionCount$impl.isAbsent();
/*  230 */     this
/*      */       
/*  232 */       .publicUpdatesChannelId_value = ((Long)publicUpdatesChannelId$impl.<Long>map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  233 */     this.publicUpdatesChannelId_present = publicUpdatesChannelId$impl.isPresent();
/*  234 */     this.maxVideoChannelUsers_value = maxVideoChannelUsers$impl.toOptional().orElse(null);
/*  235 */     this.maxVideoChannelUsers_absent = maxVideoChannelUsers$impl.isAbsent();
/*  236 */     this.approximateMemberCount_value = approximateMemberCount$impl.toOptional().orElse(null);
/*  237 */     this.approximateMemberCount_absent = approximateMemberCount$impl.isAbsent();
/*  238 */     this.approximatePresenceCount_value = approximatePresenceCount$impl.toOptional().orElse(null);
/*  239 */     this.approximatePresenceCount_absent = approximatePresenceCount$impl.isAbsent();
/*  240 */     this.welcomeScreen_value = welcomeScreen$impl.toOptional().orElse(null);
/*  241 */     this.welcomeScreen_absent = welcomeScreen$impl.isAbsent();
/*  242 */     this.nsfw_value = nsfw$impl.toOptional().orElse(null);
/*  243 */     this.nsfw_absent = nsfw$impl.isAbsent();
/*  244 */     this
/*      */       
/*  246 */       .safetyAlertsChannelId_value = ((Long)safetyAlertsChannelId$impl.<Long>map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  247 */     this.safetyAlertsChannelId_present = safetyAlertsChannelId$impl.isPresent();
/*  248 */     this.ownerId_value = ownerId$impl.asLong();
/*  249 */     this.region_value = Possible.flatOpt(region$impl).orElse(null);
/*  250 */     this.region_absent = region$impl.isAbsent();
/*  251 */     this.stickers_value = stickers$impl.toOptional().orElse(null);
/*  252 */     this.stickers_absent = stickers$impl.isAbsent();
/*  253 */     this.initShim = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ImmutableGuildUpdateData(ImmutableGuildUpdateData original, Id id, String name, String icon, String splash, String discoverySplash, Possible<Boolean> owner, Possible<Long> permissions, Optional<Id> afkChannelId, Possible<Boolean> embedEnabled, Possible<Optional<Id>> embedChannelId, List<String> features, Optional<Id> applicationId, Possible<Boolean> widgetEnabled, Possible<Optional<Id>> widgetChannelId, Optional<Id> systemChannelId, Integer systemChannelFlags, Optional<Id> rulesChannelId, Possible<Optional<Integer>> maxPresences, Possible<Integer> maxMembers, String vanityUrlCode, String description, String banner, Possible<Integer> premiumSubscriptionCount, Optional<Id> publicUpdatesChannelId, Possible<Integer> maxVideoChannelUsers, Possible<Integer> approximateMemberCount, Possible<Integer> approximatePresenceCount, Possible<WelcomeScreenData> welcomeScreen, Possible<Boolean> nsfw, Optional<Id> safetyAlertsChannelId, int verificationLevel, int nsfwLevel, Id ownerId, Possible<Optional<String>> region, int afkTimeout, int defaultMessageNotifications, int explicitContentFilter, int mfaLevel, int premiumTier, String preferredLocale, List<RoleData> roles, List<EmojiData> emojis, Possible<List<StickerData>> stickers) {
/*  301 */     Id id$impl = id;
/*  302 */     this.name = name;
/*  303 */     this.icon = icon;
/*  304 */     this.splash = splash;
/*  305 */     this.discoverySplash = discoverySplash;
/*  306 */     Possible<Boolean> owner$impl = owner;
/*  307 */     Possible<Long> permissions$impl = permissions;
/*  308 */     Optional<Id> afkChannelId$impl = afkChannelId;
/*  309 */     Possible<Boolean> embedEnabled$impl = embedEnabled;
/*  310 */     Possible<Optional<Id>> embedChannelId$impl = embedChannelId;
/*  311 */     this.features = features;
/*  312 */     Optional<Id> applicationId$impl = applicationId;
/*  313 */     Possible<Boolean> widgetEnabled$impl = widgetEnabled;
/*  314 */     Possible<Optional<Id>> widgetChannelId$impl = widgetChannelId;
/*  315 */     Optional<Id> systemChannelId$impl = systemChannelId;
/*  316 */     this.systemChannelFlags = systemChannelFlags;
/*  317 */     Optional<Id> rulesChannelId$impl = rulesChannelId;
/*  318 */     Possible<Optional<Integer>> maxPresences$impl = maxPresences;
/*  319 */     Possible<Integer> maxMembers$impl = maxMembers;
/*  320 */     this.vanityUrlCode = vanityUrlCode;
/*  321 */     this.description = description;
/*  322 */     this.banner = banner;
/*  323 */     Possible<Integer> premiumSubscriptionCount$impl = premiumSubscriptionCount;
/*  324 */     Optional<Id> publicUpdatesChannelId$impl = publicUpdatesChannelId;
/*  325 */     Possible<Integer> maxVideoChannelUsers$impl = maxVideoChannelUsers;
/*  326 */     Possible<Integer> approximateMemberCount$impl = approximateMemberCount;
/*  327 */     Possible<Integer> approximatePresenceCount$impl = approximatePresenceCount;
/*  328 */     Possible<WelcomeScreenData> welcomeScreen$impl = welcomeScreen;
/*  329 */     Possible<Boolean> nsfw$impl = nsfw;
/*  330 */     Optional<Id> safetyAlertsChannelId$impl = safetyAlertsChannelId;
/*  331 */     this.verificationLevel = verificationLevel;
/*  332 */     this.nsfwLevel = nsfwLevel;
/*  333 */     Id ownerId$impl = ownerId;
/*  334 */     Possible<Optional<String>> region$impl = region;
/*  335 */     this.afkTimeout = afkTimeout;
/*  336 */     this.defaultMessageNotifications = defaultMessageNotifications;
/*  337 */     this.explicitContentFilter = explicitContentFilter;
/*  338 */     this.mfaLevel = mfaLevel;
/*  339 */     this.premiumTier = premiumTier;
/*  340 */     this.preferredLocale = preferredLocale;
/*  341 */     this.roles = roles;
/*  342 */     this.emojis = emojis;
/*  343 */     Possible<List<StickerData>> stickers$impl = stickers;
/*  344 */     this.id_value = id$impl.asLong();
/*  345 */     this.owner_value = owner$impl.toOptional().orElse(null);
/*  346 */     this.owner_absent = owner$impl.isAbsent();
/*  347 */     this.permissions_value = permissions$impl.toOptional().orElse(null);
/*  348 */     this.permissions_absent = permissions$impl.isAbsent();
/*  349 */     this
/*      */       
/*  351 */       .afkChannelId_value = ((Long)afkChannelId$impl.<Long>map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  352 */     this.afkChannelId_present = afkChannelId$impl.isPresent();
/*  353 */     this.embedEnabled_value = embedEnabled$impl.toOptional().orElse(null);
/*  354 */     this.embedEnabled_absent = embedEnabled$impl.isAbsent();
/*  355 */     this
/*      */       
/*  357 */       .embedChannelId_value = ((Long)Possible.flatOpt(embedChannelId$impl).map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  358 */     this.embedChannelId_absent = embedChannelId$impl.isAbsent();
/*  359 */     this.embedChannelId_isNull = (!embedChannelId$impl.isAbsent() && !((Optional)embedChannelId$impl.get()).isPresent());
/*  360 */     this
/*      */       
/*  362 */       .applicationId_value = ((Long)applicationId$impl.<Long>map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  363 */     this.applicationId_present = applicationId$impl.isPresent();
/*  364 */     this.widgetEnabled_value = widgetEnabled$impl.toOptional().orElse(null);
/*  365 */     this.widgetEnabled_absent = widgetEnabled$impl.isAbsent();
/*  366 */     this
/*      */       
/*  368 */       .widgetChannelId_value = ((Long)Possible.flatOpt(widgetChannelId$impl).map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  369 */     this.widgetChannelId_absent = widgetChannelId$impl.isAbsent();
/*  370 */     this.widgetChannelId_isNull = (!widgetChannelId$impl.isAbsent() && !((Optional)widgetChannelId$impl.get()).isPresent());
/*  371 */     this
/*      */       
/*  373 */       .systemChannelId_value = ((Long)systemChannelId$impl.<Long>map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  374 */     this.systemChannelId_present = systemChannelId$impl.isPresent();
/*  375 */     this
/*      */       
/*  377 */       .rulesChannelId_value = ((Long)rulesChannelId$impl.<Long>map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  378 */     this.rulesChannelId_present = rulesChannelId$impl.isPresent();
/*  379 */     this.maxPresences_value = Possible.flatOpt(maxPresences$impl).orElse(null);
/*  380 */     this.maxPresences_absent = maxPresences$impl.isAbsent();
/*  381 */     this.maxMembers_value = maxMembers$impl.toOptional().orElse(null);
/*  382 */     this.maxMembers_absent = maxMembers$impl.isAbsent();
/*  383 */     this.premiumSubscriptionCount_value = premiumSubscriptionCount$impl.toOptional().orElse(null);
/*  384 */     this.premiumSubscriptionCount_absent = premiumSubscriptionCount$impl.isAbsent();
/*  385 */     this
/*      */       
/*  387 */       .publicUpdatesChannelId_value = ((Long)publicUpdatesChannelId$impl.<Long>map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  388 */     this.publicUpdatesChannelId_present = publicUpdatesChannelId$impl.isPresent();
/*  389 */     this.maxVideoChannelUsers_value = maxVideoChannelUsers$impl.toOptional().orElse(null);
/*  390 */     this.maxVideoChannelUsers_absent = maxVideoChannelUsers$impl.isAbsent();
/*  391 */     this.approximateMemberCount_value = approximateMemberCount$impl.toOptional().orElse(null);
/*  392 */     this.approximateMemberCount_absent = approximateMemberCount$impl.isAbsent();
/*  393 */     this.approximatePresenceCount_value = approximatePresenceCount$impl.toOptional().orElse(null);
/*  394 */     this.approximatePresenceCount_absent = approximatePresenceCount$impl.isAbsent();
/*  395 */     this.welcomeScreen_value = welcomeScreen$impl.toOptional().orElse(null);
/*  396 */     this.welcomeScreen_absent = welcomeScreen$impl.isAbsent();
/*  397 */     this.nsfw_value = nsfw$impl.toOptional().orElse(null);
/*  398 */     this.nsfw_absent = nsfw$impl.isAbsent();
/*  399 */     this
/*      */       
/*  401 */       .safetyAlertsChannelId_value = ((Long)safetyAlertsChannelId$impl.<Long>map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  402 */     this.safetyAlertsChannelId_present = safetyAlertsChannelId$impl.isPresent();
/*  403 */     this.ownerId_value = ownerId$impl.asLong();
/*  404 */     this.region_value = Possible.flatOpt(region$impl).orElse(null);
/*  405 */     this.region_absent = region$impl.isAbsent();
/*  406 */     this.stickers_value = stickers$impl.toOptional().orElse(null);
/*  407 */     this.stickers_absent = stickers$impl.isAbsent();
/*  408 */     this.initShim = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  414 */   private volatile transient InitShim initShim = new InitShim();
/*      */   
/*      */   @Generated(from = "GuildUpdateData", generator = "Immutables")
/*      */   private final class InitShim {
/*      */     private String formatInitCycleMessage() {
/*  419 */       List<String> attributes = new ArrayList<>();
/*  420 */       return "Cannot build GuildUpdateData, attribute initializers form cycle " + attributes;
/*      */     }
/*      */ 
/*      */     
/*      */     private InitShim() {}
/*      */   }
/*      */ 
/*      */   
/*      */   @JsonProperty("id")
/*      */   public Id id() {
/*  430 */     return Id.of(this.id_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("name")
/*      */   public String name() {
/*  439 */     return this.name;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("icon")
/*      */   public Optional<String> icon() {
/*  448 */     return Optional.ofNullable(this.icon);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("splash")
/*      */   public Optional<String> splash() {
/*  457 */     return Optional.ofNullable(this.splash);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("discovery_splash")
/*      */   public Optional<String> discoverySplash() {
/*  466 */     return Optional.ofNullable(this.discoverySplash);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("owner")
/*      */   public Possible<Boolean> owner() {
/*  475 */     return this.owner_absent ? Possible.absent() : Possible.of(this.owner_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("permissions")
/*      */   public Possible<Long> permissions() {
/*  484 */     return this.permissions_absent ? Possible.absent() : Possible.of(this.permissions_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("afk_channel_id")
/*      */   public Optional<Id> afkChannelId() {
/*  493 */     return this.afkChannelId_present ? Optional.<Id>of(Id.of(this.afkChannelId_value)) : Optional.<Id>empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("embed_enabled")
/*      */   @Deprecated
/*      */   public Possible<Boolean> embedEnabled() {
/*  503 */     return this.embedEnabled_absent ? Possible.absent() : Possible.of(this.embedEnabled_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("embed_channel_id")
/*      */   @Deprecated
/*      */   public Possible<Optional<Id>> embedChannelId() {
/*  513 */     if (this.embedChannelId_absent)
/*  514 */       return Possible.absent(); 
/*  515 */     if (this.embedChannelId_isNull) {
/*  516 */       return Possible.of(Optional.empty());
/*      */     }
/*  518 */     return Possible.of(Optional.of(Id.of(this.embedChannelId_value)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("features")
/*      */   public List<String> features() {
/*  528 */     return this.features;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("application_id")
/*      */   public Optional<Id> applicationId() {
/*  537 */     return this.applicationId_present ? Optional.<Id>of(Id.of(this.applicationId_value)) : Optional.<Id>empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("widget_enabled")
/*      */   public Possible<Boolean> widgetEnabled() {
/*  546 */     return this.widgetEnabled_absent ? Possible.absent() : Possible.of(this.widgetEnabled_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("widget_channel_id")
/*      */   public Possible<Optional<Id>> widgetChannelId() {
/*  555 */     if (this.widgetChannelId_absent)
/*  556 */       return Possible.absent(); 
/*  557 */     if (this.widgetChannelId_isNull) {
/*  558 */       return Possible.of(Optional.empty());
/*      */     }
/*  560 */     return Possible.of(Optional.of(Id.of(this.widgetChannelId_value)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("system_channel_id")
/*      */   public Optional<Id> systemChannelId() {
/*  570 */     return this.systemChannelId_present ? Optional.<Id>of(Id.of(this.systemChannelId_value)) : Optional.<Id>empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("system_channel_flags")
/*      */   public OptionalInt systemChannelFlags() {
/*  579 */     return (this.systemChannelFlags != null) ? 
/*  580 */       OptionalInt.of(this.systemChannelFlags.intValue()) : 
/*  581 */       OptionalInt.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("rules_channel_id")
/*      */   public Optional<Id> rulesChannelId() {
/*  590 */     return this.rulesChannelId_present ? Optional.<Id>of(Id.of(this.rulesChannelId_value)) : Optional.<Id>empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("max_presences")
/*      */   public Possible<Optional<Integer>> maxPresences() {
/*  599 */     return this.maxPresences_absent ? Possible.absent() : 
/*  600 */       Possible.of(Optional.ofNullable(this.maxPresences_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("max_members")
/*      */   public Possible<Integer> maxMembers() {
/*  609 */     return this.maxMembers_absent ? Possible.absent() : Possible.of(this.maxMembers_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("vanity_url_code")
/*      */   public Optional<String> vanityUrlCode() {
/*  618 */     return Optional.ofNullable(this.vanityUrlCode);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("description")
/*      */   public Optional<String> description() {
/*  627 */     return Optional.ofNullable(this.description);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("banner")
/*      */   public Optional<String> banner() {
/*  636 */     return Optional.ofNullable(this.banner);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("premium_subscription_count")
/*      */   public Possible<Integer> premiumSubscriptionCount() {
/*  645 */     return this.premiumSubscriptionCount_absent ? Possible.absent() : Possible.of(this.premiumSubscriptionCount_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("public_updates_channel_id")
/*      */   public Optional<Id> publicUpdatesChannelId() {
/*  654 */     return this.publicUpdatesChannelId_present ? Optional.<Id>of(Id.of(this.publicUpdatesChannelId_value)) : Optional.<Id>empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("max_video_channel_users")
/*      */   public Possible<Integer> maxVideoChannelUsers() {
/*  663 */     return this.maxVideoChannelUsers_absent ? Possible.absent() : Possible.of(this.maxVideoChannelUsers_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("approximate_member_count")
/*      */   public Possible<Integer> approximateMemberCount() {
/*  672 */     return this.approximateMemberCount_absent ? Possible.absent() : Possible.of(this.approximateMemberCount_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("approximate_presence_count")
/*      */   public Possible<Integer> approximatePresenceCount() {
/*  681 */     return this.approximatePresenceCount_absent ? Possible.absent() : Possible.of(this.approximatePresenceCount_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("welcome_screen")
/*      */   public Possible<WelcomeScreenData> welcomeScreen() {
/*  690 */     return this.welcomeScreen_absent ? Possible.absent() : Possible.of(this.welcomeScreen_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("nsfw")
/*      */   @Deprecated
/*      */   public Possible<Boolean> nsfw() {
/*  700 */     return this.nsfw_absent ? Possible.absent() : Possible.of(this.nsfw_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("safety_alerts_channel_id")
/*      */   public Optional<Id> safetyAlertsChannelId() {
/*  709 */     return this.safetyAlertsChannelId_present ? Optional.<Id>of(Id.of(this.safetyAlertsChannelId_value)) : Optional.<Id>empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("verification_level")
/*      */   public int verificationLevel() {
/*  718 */     return this.verificationLevel;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("nsfw_level")
/*      */   public int nsfwLevel() {
/*  727 */     return this.nsfwLevel;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("owner_id")
/*      */   public Id ownerId() {
/*  736 */     return Id.of(this.ownerId_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("region")
/*      */   public Possible<Optional<String>> region() {
/*  745 */     return this.region_absent ? Possible.absent() : 
/*  746 */       Possible.of(Optional.ofNullable(this.region_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("afk_timeout")
/*      */   public int afkTimeout() {
/*  755 */     return this.afkTimeout;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("default_message_notifications")
/*      */   public int defaultMessageNotifications() {
/*  764 */     return this.defaultMessageNotifications;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("explicit_content_filter")
/*      */   public int explicitContentFilter() {
/*  773 */     return this.explicitContentFilter;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("mfa_level")
/*      */   public int mfaLevel() {
/*  782 */     return this.mfaLevel;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("premium_tier")
/*      */   public int premiumTier() {
/*  791 */     return this.premiumTier;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("preferred_locale")
/*      */   public String preferredLocale() {
/*  800 */     return this.preferredLocale;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("roles")
/*      */   public List<RoleData> roles() {
/*  809 */     return this.roles;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("emojis")
/*      */   public List<EmojiData> emojis() {
/*  818 */     return this.emojis;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("stickers")
/*      */   public Possible<List<StickerData>> stickers() {
/*  827 */     return this.stickers_absent ? Possible.absent() : 
/*  828 */       Possible.of(this.stickers_value);
/*      */   }
/*      */   
/*      */   public ImmutableGuildUpdateData withId(long value) {
/*  832 */     Id newValue = Id.of(value);
/*  833 */     return new ImmutableGuildUpdateData(this, newValue, this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  840 */         owner(), 
/*  841 */         permissions(), 
/*  842 */         afkChannelId(), 
/*  843 */         embedEnabled(), 
/*  844 */         embedChannelId(), this.features, 
/*      */         
/*  846 */         applicationId(), 
/*  847 */         widgetEnabled(), 
/*  848 */         widgetChannelId(), 
/*  849 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/*  851 */         rulesChannelId(), 
/*  852 */         maxPresences(), 
/*  853 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/*  857 */         premiumSubscriptionCount(), 
/*  858 */         publicUpdatesChannelId(), 
/*  859 */         maxVideoChannelUsers(), 
/*  860 */         approximateMemberCount(), 
/*  861 */         approximatePresenceCount(), 
/*  862 */         welcomeScreen(), 
/*  863 */         nsfw(), 
/*  864 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/*  867 */         ownerId(), 
/*  868 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  877 */         stickers());
/*      */   }
/*      */   
/*      */   public ImmutableGuildUpdateData withId(String value) {
/*  881 */     Id newValue = Id.of(value);
/*  882 */     return new ImmutableGuildUpdateData(this, newValue, this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  889 */         owner(), 
/*  890 */         permissions(), 
/*  891 */         afkChannelId(), 
/*  892 */         embedEnabled(), 
/*  893 */         embedChannelId(), this.features, 
/*      */         
/*  895 */         applicationId(), 
/*  896 */         widgetEnabled(), 
/*  897 */         widgetChannelId(), 
/*  898 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/*  900 */         rulesChannelId(), 
/*  901 */         maxPresences(), 
/*  902 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/*  906 */         premiumSubscriptionCount(), 
/*  907 */         publicUpdatesChannelId(), 
/*  908 */         maxVideoChannelUsers(), 
/*  909 */         approximateMemberCount(), 
/*  910 */         approximatePresenceCount(), 
/*  911 */         welcomeScreen(), 
/*  912 */         nsfw(), 
/*  913 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/*  916 */         ownerId(), 
/*  917 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  926 */         stickers());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildUpdateData withName(String value) {
/*  936 */     String newValue = Objects.<String>requireNonNull(value, "name");
/*  937 */     if (this.name.equals(newValue)) return this; 
/*  938 */     return new ImmutableGuildUpdateData(this, 
/*      */         
/*  940 */         id(), newValue, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  945 */         owner(), 
/*  946 */         permissions(), 
/*  947 */         afkChannelId(), 
/*  948 */         embedEnabled(), 
/*  949 */         embedChannelId(), this.features, 
/*      */         
/*  951 */         applicationId(), 
/*  952 */         widgetEnabled(), 
/*  953 */         widgetChannelId(), 
/*  954 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/*  956 */         rulesChannelId(), 
/*  957 */         maxPresences(), 
/*  958 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/*  962 */         premiumSubscriptionCount(), 
/*  963 */         publicUpdatesChannelId(), 
/*  964 */         maxVideoChannelUsers(), 
/*  965 */         approximateMemberCount(), 
/*  966 */         approximatePresenceCount(), 
/*  967 */         welcomeScreen(), 
/*  968 */         nsfw(), 
/*  969 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/*  972 */         ownerId(), 
/*  973 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  982 */         stickers());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildUpdateData withIcon(String value) {
/*  991 */     String newValue = Objects.<String>requireNonNull(value, "icon");
/*  992 */     if (Objects.equals(this.icon, newValue)) return this; 
/*  993 */     return new ImmutableGuildUpdateData(this, 
/*      */         
/*  995 */         id(), this.name, newValue, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1000 */         owner(), 
/* 1001 */         permissions(), 
/* 1002 */         afkChannelId(), 
/* 1003 */         embedEnabled(), 
/* 1004 */         embedChannelId(), this.features, 
/*      */         
/* 1006 */         applicationId(), 
/* 1007 */         widgetEnabled(), 
/* 1008 */         widgetChannelId(), 
/* 1009 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 1011 */         rulesChannelId(), 
/* 1012 */         maxPresences(), 
/* 1013 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1017 */         premiumSubscriptionCount(), 
/* 1018 */         publicUpdatesChannelId(), 
/* 1019 */         maxVideoChannelUsers(), 
/* 1020 */         approximateMemberCount(), 
/* 1021 */         approximatePresenceCount(), 
/* 1022 */         welcomeScreen(), 
/* 1023 */         nsfw(), 
/* 1024 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 1027 */         ownerId(), 
/* 1028 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1037 */         stickers());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildUpdateData withIcon(Optional<String> optional) {
/* 1047 */     String value = optional.orElse(null);
/* 1048 */     if (Objects.equals(this.icon, value)) return this; 
/* 1049 */     return new ImmutableGuildUpdateData(this, 
/*      */         
/* 1051 */         id(), this.name, value, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1056 */         owner(), 
/* 1057 */         permissions(), 
/* 1058 */         afkChannelId(), 
/* 1059 */         embedEnabled(), 
/* 1060 */         embedChannelId(), this.features, 
/*      */         
/* 1062 */         applicationId(), 
/* 1063 */         widgetEnabled(), 
/* 1064 */         widgetChannelId(), 
/* 1065 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 1067 */         rulesChannelId(), 
/* 1068 */         maxPresences(), 
/* 1069 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1073 */         premiumSubscriptionCount(), 
/* 1074 */         publicUpdatesChannelId(), 
/* 1075 */         maxVideoChannelUsers(), 
/* 1076 */         approximateMemberCount(), 
/* 1077 */         approximatePresenceCount(), 
/* 1078 */         welcomeScreen(), 
/* 1079 */         nsfw(), 
/* 1080 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 1083 */         ownerId(), 
/* 1084 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1093 */         stickers());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildUpdateData withSplash(String value) {
/* 1102 */     String newValue = Objects.<String>requireNonNull(value, "splash");
/* 1103 */     if (Objects.equals(this.splash, newValue)) return this; 
/* 1104 */     return new ImmutableGuildUpdateData(this, 
/*      */         
/* 1106 */         id(), this.name, this.icon, newValue, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1111 */         owner(), 
/* 1112 */         permissions(), 
/* 1113 */         afkChannelId(), 
/* 1114 */         embedEnabled(), 
/* 1115 */         embedChannelId(), this.features, 
/*      */         
/* 1117 */         applicationId(), 
/* 1118 */         widgetEnabled(), 
/* 1119 */         widgetChannelId(), 
/* 1120 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 1122 */         rulesChannelId(), 
/* 1123 */         maxPresences(), 
/* 1124 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1128 */         premiumSubscriptionCount(), 
/* 1129 */         publicUpdatesChannelId(), 
/* 1130 */         maxVideoChannelUsers(), 
/* 1131 */         approximateMemberCount(), 
/* 1132 */         approximatePresenceCount(), 
/* 1133 */         welcomeScreen(), 
/* 1134 */         nsfw(), 
/* 1135 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 1138 */         ownerId(), 
/* 1139 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1148 */         stickers());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildUpdateData withSplash(Optional<String> optional) {
/* 1158 */     String value = optional.orElse(null);
/* 1159 */     if (Objects.equals(this.splash, value)) return this; 
/* 1160 */     return new ImmutableGuildUpdateData(this, 
/*      */         
/* 1162 */         id(), this.name, this.icon, value, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1167 */         owner(), 
/* 1168 */         permissions(), 
/* 1169 */         afkChannelId(), 
/* 1170 */         embedEnabled(), 
/* 1171 */         embedChannelId(), this.features, 
/*      */         
/* 1173 */         applicationId(), 
/* 1174 */         widgetEnabled(), 
/* 1175 */         widgetChannelId(), 
/* 1176 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 1178 */         rulesChannelId(), 
/* 1179 */         maxPresences(), 
/* 1180 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1184 */         premiumSubscriptionCount(), 
/* 1185 */         publicUpdatesChannelId(), 
/* 1186 */         maxVideoChannelUsers(), 
/* 1187 */         approximateMemberCount(), 
/* 1188 */         approximatePresenceCount(), 
/* 1189 */         welcomeScreen(), 
/* 1190 */         nsfw(), 
/* 1191 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 1194 */         ownerId(), 
/* 1195 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1204 */         stickers());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildUpdateData withDiscoverySplash(String value) {
/* 1213 */     String newValue = Objects.<String>requireNonNull(value, "discoverySplash");
/* 1214 */     if (Objects.equals(this.discoverySplash, newValue)) return this; 
/* 1215 */     return new ImmutableGuildUpdateData(this, 
/*      */         
/* 1217 */         id(), this.name, this.icon, this.splash, newValue, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1222 */         owner(), 
/* 1223 */         permissions(), 
/* 1224 */         afkChannelId(), 
/* 1225 */         embedEnabled(), 
/* 1226 */         embedChannelId(), this.features, 
/*      */         
/* 1228 */         applicationId(), 
/* 1229 */         widgetEnabled(), 
/* 1230 */         widgetChannelId(), 
/* 1231 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 1233 */         rulesChannelId(), 
/* 1234 */         maxPresences(), 
/* 1235 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1239 */         premiumSubscriptionCount(), 
/* 1240 */         publicUpdatesChannelId(), 
/* 1241 */         maxVideoChannelUsers(), 
/* 1242 */         approximateMemberCount(), 
/* 1243 */         approximatePresenceCount(), 
/* 1244 */         welcomeScreen(), 
/* 1245 */         nsfw(), 
/* 1246 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 1249 */         ownerId(), 
/* 1250 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1259 */         stickers());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildUpdateData withDiscoverySplash(Optional<String> optional) {
/* 1269 */     String value = optional.orElse(null);
/* 1270 */     if (Objects.equals(this.discoverySplash, value)) return this; 
/* 1271 */     return new ImmutableGuildUpdateData(this, 
/*      */         
/* 1273 */         id(), this.name, this.icon, this.splash, value, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1278 */         owner(), 
/* 1279 */         permissions(), 
/* 1280 */         afkChannelId(), 
/* 1281 */         embedEnabled(), 
/* 1282 */         embedChannelId(), this.features, 
/*      */         
/* 1284 */         applicationId(), 
/* 1285 */         widgetEnabled(), 
/* 1286 */         widgetChannelId(), 
/* 1287 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 1289 */         rulesChannelId(), 
/* 1290 */         maxPresences(), 
/* 1291 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1295 */         premiumSubscriptionCount(), 
/* 1296 */         publicUpdatesChannelId(), 
/* 1297 */         maxVideoChannelUsers(), 
/* 1298 */         approximateMemberCount(), 
/* 1299 */         approximatePresenceCount(), 
/* 1300 */         welcomeScreen(), 
/* 1301 */         nsfw(), 
/* 1302 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 1305 */         ownerId(), 
/* 1306 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1315 */         stickers());
/*      */   }
/*      */   
/*      */   public ImmutableGuildUpdateData withOwner(Possible<Boolean> value) {
/* 1319 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/* 1320 */     return new ImmutableGuildUpdateData(this, 
/*      */         
/* 1322 */         id(), this.name, this.icon, this.splash, this.discoverySplash, newValue, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1328 */         permissions(), 
/* 1329 */         afkChannelId(), 
/* 1330 */         embedEnabled(), 
/* 1331 */         embedChannelId(), this.features, 
/*      */         
/* 1333 */         applicationId(), 
/* 1334 */         widgetEnabled(), 
/* 1335 */         widgetChannelId(), 
/* 1336 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 1338 */         rulesChannelId(), 
/* 1339 */         maxPresences(), 
/* 1340 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1344 */         premiumSubscriptionCount(), 
/* 1345 */         publicUpdatesChannelId(), 
/* 1346 */         maxVideoChannelUsers(), 
/* 1347 */         approximateMemberCount(), 
/* 1348 */         approximatePresenceCount(), 
/* 1349 */         welcomeScreen(), 
/* 1350 */         nsfw(), 
/* 1351 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 1354 */         ownerId(), 
/* 1355 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1364 */         stickers());
/*      */   }
/*      */   
/*      */   public ImmutableGuildUpdateData withOwner(Boolean value) {
/* 1368 */     Possible<Boolean> newValue = Possible.of(value);
/* 1369 */     return new ImmutableGuildUpdateData(this, 
/*      */         
/* 1371 */         id(), this.name, this.icon, this.splash, this.discoverySplash, newValue, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1377 */         permissions(), 
/* 1378 */         afkChannelId(), 
/* 1379 */         embedEnabled(), 
/* 1380 */         embedChannelId(), this.features, 
/*      */         
/* 1382 */         applicationId(), 
/* 1383 */         widgetEnabled(), 
/* 1384 */         widgetChannelId(), 
/* 1385 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 1387 */         rulesChannelId(), 
/* 1388 */         maxPresences(), 
/* 1389 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1393 */         premiumSubscriptionCount(), 
/* 1394 */         publicUpdatesChannelId(), 
/* 1395 */         maxVideoChannelUsers(), 
/* 1396 */         approximateMemberCount(), 
/* 1397 */         approximatePresenceCount(), 
/* 1398 */         welcomeScreen(), 
/* 1399 */         nsfw(), 
/* 1400 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 1403 */         ownerId(), 
/* 1404 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1413 */         stickers());
/*      */   }
/*      */   
/*      */   public ImmutableGuildUpdateData withPermissions(Possible<Long> value) {
/* 1417 */     Possible<Long> newValue = Objects.<Possible<Long>>requireNonNull(value);
/* 1418 */     return new ImmutableGuildUpdateData(this, 
/*      */         
/* 1420 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1425 */         owner(), newValue, 
/*      */         
/* 1427 */         afkChannelId(), 
/* 1428 */         embedEnabled(), 
/* 1429 */         embedChannelId(), this.features, 
/*      */         
/* 1431 */         applicationId(), 
/* 1432 */         widgetEnabled(), 
/* 1433 */         widgetChannelId(), 
/* 1434 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 1436 */         rulesChannelId(), 
/* 1437 */         maxPresences(), 
/* 1438 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1442 */         premiumSubscriptionCount(), 
/* 1443 */         publicUpdatesChannelId(), 
/* 1444 */         maxVideoChannelUsers(), 
/* 1445 */         approximateMemberCount(), 
/* 1446 */         approximatePresenceCount(), 
/* 1447 */         welcomeScreen(), 
/* 1448 */         nsfw(), 
/* 1449 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 1452 */         ownerId(), 
/* 1453 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1462 */         stickers());
/*      */   }
/*      */   
/*      */   public ImmutableGuildUpdateData withPermissions(Long value) {
/* 1466 */     Possible<Long> newValue = Possible.of(value);
/* 1467 */     return new ImmutableGuildUpdateData(this, 
/*      */         
/* 1469 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1474 */         owner(), newValue, 
/*      */         
/* 1476 */         afkChannelId(), 
/* 1477 */         embedEnabled(), 
/* 1478 */         embedChannelId(), this.features, 
/*      */         
/* 1480 */         applicationId(), 
/* 1481 */         widgetEnabled(), 
/* 1482 */         widgetChannelId(), 
/* 1483 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 1485 */         rulesChannelId(), 
/* 1486 */         maxPresences(), 
/* 1487 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1491 */         premiumSubscriptionCount(), 
/* 1492 */         publicUpdatesChannelId(), 
/* 1493 */         maxVideoChannelUsers(), 
/* 1494 */         approximateMemberCount(), 
/* 1495 */         approximatePresenceCount(), 
/* 1496 */         welcomeScreen(), 
/* 1497 */         nsfw(), 
/* 1498 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 1501 */         ownerId(), 
/* 1502 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1511 */         stickers());
/*      */   }
/*      */   
/*      */   public ImmutableGuildUpdateData withAfkChannelId(Optional<Id> value) {
/* 1515 */     Optional<Id> newValue = Objects.<Optional<Id>>requireNonNull(value);
/* 1516 */     return new ImmutableGuildUpdateData(this, 
/*      */         
/* 1518 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1523 */         owner(), 
/* 1524 */         permissions(), newValue, 
/*      */         
/* 1526 */         embedEnabled(), 
/* 1527 */         embedChannelId(), this.features, 
/*      */         
/* 1529 */         applicationId(), 
/* 1530 */         widgetEnabled(), 
/* 1531 */         widgetChannelId(), 
/* 1532 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 1534 */         rulesChannelId(), 
/* 1535 */         maxPresences(), 
/* 1536 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1540 */         premiumSubscriptionCount(), 
/* 1541 */         publicUpdatesChannelId(), 
/* 1542 */         maxVideoChannelUsers(), 
/* 1543 */         approximateMemberCount(), 
/* 1544 */         approximatePresenceCount(), 
/* 1545 */         welcomeScreen(), 
/* 1546 */         nsfw(), 
/* 1547 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 1550 */         ownerId(), 
/* 1551 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1560 */         stickers());
/*      */   }
/*      */   
/*      */   public ImmutableGuildUpdateData withAfkChannelId(long value) {
/* 1564 */     Optional<Id> newValue = Optional.of(Id.of(value));
/* 1565 */     return new ImmutableGuildUpdateData(this, 
/*      */         
/* 1567 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1572 */         owner(), 
/* 1573 */         permissions(), newValue, 
/*      */         
/* 1575 */         embedEnabled(), 
/* 1576 */         embedChannelId(), this.features, 
/*      */         
/* 1578 */         applicationId(), 
/* 1579 */         widgetEnabled(), 
/* 1580 */         widgetChannelId(), 
/* 1581 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 1583 */         rulesChannelId(), 
/* 1584 */         maxPresences(), 
/* 1585 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1589 */         premiumSubscriptionCount(), 
/* 1590 */         publicUpdatesChannelId(), 
/* 1591 */         maxVideoChannelUsers(), 
/* 1592 */         approximateMemberCount(), 
/* 1593 */         approximatePresenceCount(), 
/* 1594 */         welcomeScreen(), 
/* 1595 */         nsfw(), 
/* 1596 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 1599 */         ownerId(), 
/* 1600 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1609 */         stickers());
/*      */   }
/*      */   
/*      */   public ImmutableGuildUpdateData withEmbedEnabled(Possible<Boolean> value) {
/* 1613 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/* 1614 */     return new ImmutableGuildUpdateData(this, 
/*      */         
/* 1616 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1621 */         owner(), 
/* 1622 */         permissions(), 
/* 1623 */         afkChannelId(), newValue, 
/*      */         
/* 1625 */         embedChannelId(), this.features, 
/*      */         
/* 1627 */         applicationId(), 
/* 1628 */         widgetEnabled(), 
/* 1629 */         widgetChannelId(), 
/* 1630 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 1632 */         rulesChannelId(), 
/* 1633 */         maxPresences(), 
/* 1634 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1638 */         premiumSubscriptionCount(), 
/* 1639 */         publicUpdatesChannelId(), 
/* 1640 */         maxVideoChannelUsers(), 
/* 1641 */         approximateMemberCount(), 
/* 1642 */         approximatePresenceCount(), 
/* 1643 */         welcomeScreen(), 
/* 1644 */         nsfw(), 
/* 1645 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 1648 */         ownerId(), 
/* 1649 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1658 */         stickers());
/*      */   }
/*      */   
/*      */   public ImmutableGuildUpdateData withEmbedEnabled(Boolean value) {
/* 1662 */     Possible<Boolean> newValue = Possible.of(value);
/* 1663 */     return new ImmutableGuildUpdateData(this, 
/*      */         
/* 1665 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1670 */         owner(), 
/* 1671 */         permissions(), 
/* 1672 */         afkChannelId(), newValue, 
/*      */         
/* 1674 */         embedChannelId(), this.features, 
/*      */         
/* 1676 */         applicationId(), 
/* 1677 */         widgetEnabled(), 
/* 1678 */         widgetChannelId(), 
/* 1679 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 1681 */         rulesChannelId(), 
/* 1682 */         maxPresences(), 
/* 1683 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1687 */         premiumSubscriptionCount(), 
/* 1688 */         publicUpdatesChannelId(), 
/* 1689 */         maxVideoChannelUsers(), 
/* 1690 */         approximateMemberCount(), 
/* 1691 */         approximatePresenceCount(), 
/* 1692 */         welcomeScreen(), 
/* 1693 */         nsfw(), 
/* 1694 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 1697 */         ownerId(), 
/* 1698 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1707 */         stickers());
/*      */   }
/*      */   
/*      */   public ImmutableGuildUpdateData withEmbedChannelId(Possible<Optional<Id>> value) {
/* 1711 */     Possible<Optional<Id>> newValue = Objects.<Possible<Optional<Id>>>requireNonNull(value);
/* 1712 */     return new ImmutableGuildUpdateData(this, 
/*      */         
/* 1714 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1719 */         owner(), 
/* 1720 */         permissions(), 
/* 1721 */         afkChannelId(), 
/* 1722 */         embedEnabled(), newValue, this.features, 
/*      */ 
/*      */         
/* 1725 */         applicationId(), 
/* 1726 */         widgetEnabled(), 
/* 1727 */         widgetChannelId(), 
/* 1728 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 1730 */         rulesChannelId(), 
/* 1731 */         maxPresences(), 
/* 1732 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1736 */         premiumSubscriptionCount(), 
/* 1737 */         publicUpdatesChannelId(), 
/* 1738 */         maxVideoChannelUsers(), 
/* 1739 */         approximateMemberCount(), 
/* 1740 */         approximatePresenceCount(), 
/* 1741 */         welcomeScreen(), 
/* 1742 */         nsfw(), 
/* 1743 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 1746 */         ownerId(), 
/* 1747 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1756 */         stickers());
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public ImmutableGuildUpdateData withEmbedChannelId(@Nullable Long value) {
/* 1762 */     Possible<Optional<Id>> newValue = (value == null) ? Possible.of(Optional.empty()) : Possible.of(Optional.of(Id.of(value.longValue())));
/* 1763 */     return new ImmutableGuildUpdateData(this, 
/*      */         
/* 1765 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1770 */         owner(), 
/* 1771 */         permissions(), 
/* 1772 */         afkChannelId(), 
/* 1773 */         embedEnabled(), newValue, this.features, 
/*      */ 
/*      */         
/* 1776 */         applicationId(), 
/* 1777 */         widgetEnabled(), 
/* 1778 */         widgetChannelId(), 
/* 1779 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 1781 */         rulesChannelId(), 
/* 1782 */         maxPresences(), 
/* 1783 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1787 */         premiumSubscriptionCount(), 
/* 1788 */         publicUpdatesChannelId(), 
/* 1789 */         maxVideoChannelUsers(), 
/* 1790 */         approximateMemberCount(), 
/* 1791 */         approximatePresenceCount(), 
/* 1792 */         welcomeScreen(), 
/* 1793 */         nsfw(), 
/* 1794 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 1797 */         ownerId(), 
/* 1798 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1807 */         stickers());
/*      */   }
/*      */ 
/*      */   
/*      */   public ImmutableGuildUpdateData withEmbedChannelIdOrNull(@Nullable Long value) {
/* 1812 */     Possible<Optional<Id>> newValue = (value == null) ? Possible.of(Optional.empty()) : Possible.of(Optional.of(Id.of(value.longValue())));
/* 1813 */     return new ImmutableGuildUpdateData(this, 
/*      */         
/* 1815 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1820 */         owner(), 
/* 1821 */         permissions(), 
/* 1822 */         afkChannelId(), 
/* 1823 */         embedEnabled(), newValue, this.features, 
/*      */ 
/*      */         
/* 1826 */         applicationId(), 
/* 1827 */         widgetEnabled(), 
/* 1828 */         widgetChannelId(), 
/* 1829 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 1831 */         rulesChannelId(), 
/* 1832 */         maxPresences(), 
/* 1833 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1837 */         premiumSubscriptionCount(), 
/* 1838 */         publicUpdatesChannelId(), 
/* 1839 */         maxVideoChannelUsers(), 
/* 1840 */         approximateMemberCount(), 
/* 1841 */         approximatePresenceCount(), 
/* 1842 */         welcomeScreen(), 
/* 1843 */         nsfw(), 
/* 1844 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 1847 */         ownerId(), 
/* 1848 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1857 */         stickers());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildUpdateData withFeatures(String... elements) {
/* 1866 */     List<String> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/* 1867 */     return new ImmutableGuildUpdateData(this, 
/*      */         
/* 1869 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1874 */         owner(), 
/* 1875 */         permissions(), 
/* 1876 */         afkChannelId(), 
/* 1877 */         embedEnabled(), 
/* 1878 */         embedChannelId(), newValue, 
/*      */         
/* 1880 */         applicationId(), 
/* 1881 */         widgetEnabled(), 
/* 1882 */         widgetChannelId(), 
/* 1883 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 1885 */         rulesChannelId(), 
/* 1886 */         maxPresences(), 
/* 1887 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1891 */         premiumSubscriptionCount(), 
/* 1892 */         publicUpdatesChannelId(), 
/* 1893 */         maxVideoChannelUsers(), 
/* 1894 */         approximateMemberCount(), 
/* 1895 */         approximatePresenceCount(), 
/* 1896 */         welcomeScreen(), 
/* 1897 */         nsfw(), 
/* 1898 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 1901 */         ownerId(), 
/* 1902 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1911 */         stickers());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildUpdateData withFeatures(Iterable<String> elements) {
/* 1921 */     if (this.features == elements) return this; 
/* 1922 */     List<String> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/* 1923 */     return new ImmutableGuildUpdateData(this, 
/*      */         
/* 1925 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1930 */         owner(), 
/* 1931 */         permissions(), 
/* 1932 */         afkChannelId(), 
/* 1933 */         embedEnabled(), 
/* 1934 */         embedChannelId(), newValue, 
/*      */         
/* 1936 */         applicationId(), 
/* 1937 */         widgetEnabled(), 
/* 1938 */         widgetChannelId(), 
/* 1939 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 1941 */         rulesChannelId(), 
/* 1942 */         maxPresences(), 
/* 1943 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1947 */         premiumSubscriptionCount(), 
/* 1948 */         publicUpdatesChannelId(), 
/* 1949 */         maxVideoChannelUsers(), 
/* 1950 */         approximateMemberCount(), 
/* 1951 */         approximatePresenceCount(), 
/* 1952 */         welcomeScreen(), 
/* 1953 */         nsfw(), 
/* 1954 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 1957 */         ownerId(), 
/* 1958 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1967 */         stickers());
/*      */   }
/*      */   
/*      */   public ImmutableGuildUpdateData withApplicationId(Optional<Id> value) {
/* 1971 */     Optional<Id> newValue = Objects.<Optional<Id>>requireNonNull(value);
/* 1972 */     return new ImmutableGuildUpdateData(this, 
/*      */         
/* 1974 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1979 */         owner(), 
/* 1980 */         permissions(), 
/* 1981 */         afkChannelId(), 
/* 1982 */         embedEnabled(), 
/* 1983 */         embedChannelId(), this.features, newValue, 
/*      */ 
/*      */         
/* 1986 */         widgetEnabled(), 
/* 1987 */         widgetChannelId(), 
/* 1988 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 1990 */         rulesChannelId(), 
/* 1991 */         maxPresences(), 
/* 1992 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1996 */         premiumSubscriptionCount(), 
/* 1997 */         publicUpdatesChannelId(), 
/* 1998 */         maxVideoChannelUsers(), 
/* 1999 */         approximateMemberCount(), 
/* 2000 */         approximatePresenceCount(), 
/* 2001 */         welcomeScreen(), 
/* 2002 */         nsfw(), 
/* 2003 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 2006 */         ownerId(), 
/* 2007 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2016 */         stickers());
/*      */   }
/*      */   
/*      */   public ImmutableGuildUpdateData withApplicationId(long value) {
/* 2020 */     Optional<Id> newValue = Optional.of(Id.of(value));
/* 2021 */     return new ImmutableGuildUpdateData(this, 
/*      */         
/* 2023 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2028 */         owner(), 
/* 2029 */         permissions(), 
/* 2030 */         afkChannelId(), 
/* 2031 */         embedEnabled(), 
/* 2032 */         embedChannelId(), this.features, newValue, 
/*      */ 
/*      */         
/* 2035 */         widgetEnabled(), 
/* 2036 */         widgetChannelId(), 
/* 2037 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 2039 */         rulesChannelId(), 
/* 2040 */         maxPresences(), 
/* 2041 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 2045 */         premiumSubscriptionCount(), 
/* 2046 */         publicUpdatesChannelId(), 
/* 2047 */         maxVideoChannelUsers(), 
/* 2048 */         approximateMemberCount(), 
/* 2049 */         approximatePresenceCount(), 
/* 2050 */         welcomeScreen(), 
/* 2051 */         nsfw(), 
/* 2052 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 2055 */         ownerId(), 
/* 2056 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2065 */         stickers());
/*      */   }
/*      */   
/*      */   public ImmutableGuildUpdateData withWidgetEnabled(Possible<Boolean> value) {
/* 2069 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/* 2070 */     return new ImmutableGuildUpdateData(this, 
/*      */         
/* 2072 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2077 */         owner(), 
/* 2078 */         permissions(), 
/* 2079 */         afkChannelId(), 
/* 2080 */         embedEnabled(), 
/* 2081 */         embedChannelId(), this.features, 
/*      */         
/* 2083 */         applicationId(), newValue, 
/*      */         
/* 2085 */         widgetChannelId(), 
/* 2086 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 2088 */         rulesChannelId(), 
/* 2089 */         maxPresences(), 
/* 2090 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 2094 */         premiumSubscriptionCount(), 
/* 2095 */         publicUpdatesChannelId(), 
/* 2096 */         maxVideoChannelUsers(), 
/* 2097 */         approximateMemberCount(), 
/* 2098 */         approximatePresenceCount(), 
/* 2099 */         welcomeScreen(), 
/* 2100 */         nsfw(), 
/* 2101 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 2104 */         ownerId(), 
/* 2105 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2114 */         stickers());
/*      */   }
/*      */   
/*      */   public ImmutableGuildUpdateData withWidgetEnabled(Boolean value) {
/* 2118 */     Possible<Boolean> newValue = Possible.of(value);
/* 2119 */     return new ImmutableGuildUpdateData(this, 
/*      */         
/* 2121 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2126 */         owner(), 
/* 2127 */         permissions(), 
/* 2128 */         afkChannelId(), 
/* 2129 */         embedEnabled(), 
/* 2130 */         embedChannelId(), this.features, 
/*      */         
/* 2132 */         applicationId(), newValue, 
/*      */         
/* 2134 */         widgetChannelId(), 
/* 2135 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 2137 */         rulesChannelId(), 
/* 2138 */         maxPresences(), 
/* 2139 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 2143 */         premiumSubscriptionCount(), 
/* 2144 */         publicUpdatesChannelId(), 
/* 2145 */         maxVideoChannelUsers(), 
/* 2146 */         approximateMemberCount(), 
/* 2147 */         approximatePresenceCount(), 
/* 2148 */         welcomeScreen(), 
/* 2149 */         nsfw(), 
/* 2150 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 2153 */         ownerId(), 
/* 2154 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2163 */         stickers());
/*      */   }
/*      */   
/*      */   public ImmutableGuildUpdateData withWidgetChannelId(Possible<Optional<Id>> value) {
/* 2167 */     Possible<Optional<Id>> newValue = Objects.<Possible<Optional<Id>>>requireNonNull(value);
/* 2168 */     return new ImmutableGuildUpdateData(this, 
/*      */         
/* 2170 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2175 */         owner(), 
/* 2176 */         permissions(), 
/* 2177 */         afkChannelId(), 
/* 2178 */         embedEnabled(), 
/* 2179 */         embedChannelId(), this.features, 
/*      */         
/* 2181 */         applicationId(), 
/* 2182 */         widgetEnabled(), newValue, 
/*      */         
/* 2184 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 2186 */         rulesChannelId(), 
/* 2187 */         maxPresences(), 
/* 2188 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 2192 */         premiumSubscriptionCount(), 
/* 2193 */         publicUpdatesChannelId(), 
/* 2194 */         maxVideoChannelUsers(), 
/* 2195 */         approximateMemberCount(), 
/* 2196 */         approximatePresenceCount(), 
/* 2197 */         welcomeScreen(), 
/* 2198 */         nsfw(), 
/* 2199 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 2202 */         ownerId(), 
/* 2203 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2212 */         stickers());
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public ImmutableGuildUpdateData withWidgetChannelId(@Nullable Long value) {
/* 2218 */     Possible<Optional<Id>> newValue = (value == null) ? Possible.of(Optional.empty()) : Possible.of(Optional.of(Id.of(value.longValue())));
/* 2219 */     return new ImmutableGuildUpdateData(this, 
/*      */         
/* 2221 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2226 */         owner(), 
/* 2227 */         permissions(), 
/* 2228 */         afkChannelId(), 
/* 2229 */         embedEnabled(), 
/* 2230 */         embedChannelId(), this.features, 
/*      */         
/* 2232 */         applicationId(), 
/* 2233 */         widgetEnabled(), newValue, 
/*      */         
/* 2235 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 2237 */         rulesChannelId(), 
/* 2238 */         maxPresences(), 
/* 2239 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 2243 */         premiumSubscriptionCount(), 
/* 2244 */         publicUpdatesChannelId(), 
/* 2245 */         maxVideoChannelUsers(), 
/* 2246 */         approximateMemberCount(), 
/* 2247 */         approximatePresenceCount(), 
/* 2248 */         welcomeScreen(), 
/* 2249 */         nsfw(), 
/* 2250 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 2253 */         ownerId(), 
/* 2254 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2263 */         stickers());
/*      */   }
/*      */ 
/*      */   
/*      */   public ImmutableGuildUpdateData withWidgetChannelIdOrNull(@Nullable Long value) {
/* 2268 */     Possible<Optional<Id>> newValue = (value == null) ? Possible.of(Optional.empty()) : Possible.of(Optional.of(Id.of(value.longValue())));
/* 2269 */     return new ImmutableGuildUpdateData(this, 
/*      */         
/* 2271 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2276 */         owner(), 
/* 2277 */         permissions(), 
/* 2278 */         afkChannelId(), 
/* 2279 */         embedEnabled(), 
/* 2280 */         embedChannelId(), this.features, 
/*      */         
/* 2282 */         applicationId(), 
/* 2283 */         widgetEnabled(), newValue, 
/*      */         
/* 2285 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 2287 */         rulesChannelId(), 
/* 2288 */         maxPresences(), 
/* 2289 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 2293 */         premiumSubscriptionCount(), 
/* 2294 */         publicUpdatesChannelId(), 
/* 2295 */         maxVideoChannelUsers(), 
/* 2296 */         approximateMemberCount(), 
/* 2297 */         approximatePresenceCount(), 
/* 2298 */         welcomeScreen(), 
/* 2299 */         nsfw(), 
/* 2300 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 2303 */         ownerId(), 
/* 2304 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2313 */         stickers());
/*      */   }
/*      */   
/*      */   public ImmutableGuildUpdateData withSystemChannelId(Optional<Id> value) {
/* 2317 */     Optional<Id> newValue = Objects.<Optional<Id>>requireNonNull(value);
/* 2318 */     return new ImmutableGuildUpdateData(this, 
/*      */         
/* 2320 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2325 */         owner(), 
/* 2326 */         permissions(), 
/* 2327 */         afkChannelId(), 
/* 2328 */         embedEnabled(), 
/* 2329 */         embedChannelId(), this.features, 
/*      */         
/* 2331 */         applicationId(), 
/* 2332 */         widgetEnabled(), 
/* 2333 */         widgetChannelId(), newValue, this.systemChannelFlags, 
/*      */ 
/*      */         
/* 2336 */         rulesChannelId(), 
/* 2337 */         maxPresences(), 
/* 2338 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 2342 */         premiumSubscriptionCount(), 
/* 2343 */         publicUpdatesChannelId(), 
/* 2344 */         maxVideoChannelUsers(), 
/* 2345 */         approximateMemberCount(), 
/* 2346 */         approximatePresenceCount(), 
/* 2347 */         welcomeScreen(), 
/* 2348 */         nsfw(), 
/* 2349 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 2352 */         ownerId(), 
/* 2353 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2362 */         stickers());
/*      */   }
/*      */   
/*      */   public ImmutableGuildUpdateData withSystemChannelId(long value) {
/* 2366 */     Optional<Id> newValue = Optional.of(Id.of(value));
/* 2367 */     return new ImmutableGuildUpdateData(this, 
/*      */         
/* 2369 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2374 */         owner(), 
/* 2375 */         permissions(), 
/* 2376 */         afkChannelId(), 
/* 2377 */         embedEnabled(), 
/* 2378 */         embedChannelId(), this.features, 
/*      */         
/* 2380 */         applicationId(), 
/* 2381 */         widgetEnabled(), 
/* 2382 */         widgetChannelId(), newValue, this.systemChannelFlags, 
/*      */ 
/*      */         
/* 2385 */         rulesChannelId(), 
/* 2386 */         maxPresences(), 
/* 2387 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 2391 */         premiumSubscriptionCount(), 
/* 2392 */         publicUpdatesChannelId(), 
/* 2393 */         maxVideoChannelUsers(), 
/* 2394 */         approximateMemberCount(), 
/* 2395 */         approximatePresenceCount(), 
/* 2396 */         welcomeScreen(), 
/* 2397 */         nsfw(), 
/* 2398 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 2401 */         ownerId(), 
/* 2402 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2411 */         stickers());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildUpdateData withSystemChannelFlags(int value) {
/* 2420 */     Integer newValue = Integer.valueOf(value);
/* 2421 */     if (Objects.equals(this.systemChannelFlags, newValue)) return this; 
/* 2422 */     return new ImmutableGuildUpdateData(this, 
/*      */         
/* 2424 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2429 */         owner(), 
/* 2430 */         permissions(), 
/* 2431 */         afkChannelId(), 
/* 2432 */         embedEnabled(), 
/* 2433 */         embedChannelId(), this.features, 
/*      */         
/* 2435 */         applicationId(), 
/* 2436 */         widgetEnabled(), 
/* 2437 */         widgetChannelId(), 
/* 2438 */         systemChannelId(), newValue, 
/*      */         
/* 2440 */         rulesChannelId(), 
/* 2441 */         maxPresences(), 
/* 2442 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 2446 */         premiumSubscriptionCount(), 
/* 2447 */         publicUpdatesChannelId(), 
/* 2448 */         maxVideoChannelUsers(), 
/* 2449 */         approximateMemberCount(), 
/* 2450 */         approximatePresenceCount(), 
/* 2451 */         welcomeScreen(), 
/* 2452 */         nsfw(), 
/* 2453 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 2456 */         ownerId(), 
/* 2457 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2466 */         stickers());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildUpdateData withSystemChannelFlags(OptionalInt optional) {
/* 2476 */     Integer value = optional.isPresent() ? Integer.valueOf(optional.getAsInt()) : null;
/* 2477 */     if (Objects.equals(this.systemChannelFlags, value)) return this; 
/* 2478 */     return new ImmutableGuildUpdateData(this, 
/*      */         
/* 2480 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2485 */         owner(), 
/* 2486 */         permissions(), 
/* 2487 */         afkChannelId(), 
/* 2488 */         embedEnabled(), 
/* 2489 */         embedChannelId(), this.features, 
/*      */         
/* 2491 */         applicationId(), 
/* 2492 */         widgetEnabled(), 
/* 2493 */         widgetChannelId(), 
/* 2494 */         systemChannelId(), value, 
/*      */         
/* 2496 */         rulesChannelId(), 
/* 2497 */         maxPresences(), 
/* 2498 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 2502 */         premiumSubscriptionCount(), 
/* 2503 */         publicUpdatesChannelId(), 
/* 2504 */         maxVideoChannelUsers(), 
/* 2505 */         approximateMemberCount(), 
/* 2506 */         approximatePresenceCount(), 
/* 2507 */         welcomeScreen(), 
/* 2508 */         nsfw(), 
/* 2509 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 2512 */         ownerId(), 
/* 2513 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2522 */         stickers());
/*      */   }
/*      */   
/*      */   public ImmutableGuildUpdateData withRulesChannelId(Optional<Id> value) {
/* 2526 */     Optional<Id> newValue = Objects.<Optional<Id>>requireNonNull(value);
/* 2527 */     return new ImmutableGuildUpdateData(this, 
/*      */         
/* 2529 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2534 */         owner(), 
/* 2535 */         permissions(), 
/* 2536 */         afkChannelId(), 
/* 2537 */         embedEnabled(), 
/* 2538 */         embedChannelId(), this.features, 
/*      */         
/* 2540 */         applicationId(), 
/* 2541 */         widgetEnabled(), 
/* 2542 */         widgetChannelId(), 
/* 2543 */         systemChannelId(), this.systemChannelFlags, newValue, 
/*      */ 
/*      */         
/* 2546 */         maxPresences(), 
/* 2547 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 2551 */         premiumSubscriptionCount(), 
/* 2552 */         publicUpdatesChannelId(), 
/* 2553 */         maxVideoChannelUsers(), 
/* 2554 */         approximateMemberCount(), 
/* 2555 */         approximatePresenceCount(), 
/* 2556 */         welcomeScreen(), 
/* 2557 */         nsfw(), 
/* 2558 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 2561 */         ownerId(), 
/* 2562 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2571 */         stickers());
/*      */   }
/*      */   
/*      */   public ImmutableGuildUpdateData withRulesChannelId(long value) {
/* 2575 */     Optional<Id> newValue = Optional.of(Id.of(value));
/* 2576 */     return new ImmutableGuildUpdateData(this, 
/*      */         
/* 2578 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2583 */         owner(), 
/* 2584 */         permissions(), 
/* 2585 */         afkChannelId(), 
/* 2586 */         embedEnabled(), 
/* 2587 */         embedChannelId(), this.features, 
/*      */         
/* 2589 */         applicationId(), 
/* 2590 */         widgetEnabled(), 
/* 2591 */         widgetChannelId(), 
/* 2592 */         systemChannelId(), this.systemChannelFlags, newValue, 
/*      */ 
/*      */         
/* 2595 */         maxPresences(), 
/* 2596 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 2600 */         premiumSubscriptionCount(), 
/* 2601 */         publicUpdatesChannelId(), 
/* 2602 */         maxVideoChannelUsers(), 
/* 2603 */         approximateMemberCount(), 
/* 2604 */         approximatePresenceCount(), 
/* 2605 */         welcomeScreen(), 
/* 2606 */         nsfw(), 
/* 2607 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 2610 */         ownerId(), 
/* 2611 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2620 */         stickers());
/*      */   }
/*      */   
/*      */   public ImmutableGuildUpdateData withMaxPresences(Possible<Optional<Integer>> value) {
/* 2624 */     Possible<Optional<Integer>> newValue = Objects.<Possible<Optional<Integer>>>requireNonNull(value);
/* 2625 */     return new ImmutableGuildUpdateData(this, 
/*      */         
/* 2627 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2632 */         owner(), 
/* 2633 */         permissions(), 
/* 2634 */         afkChannelId(), 
/* 2635 */         embedEnabled(), 
/* 2636 */         embedChannelId(), this.features, 
/*      */         
/* 2638 */         applicationId(), 
/* 2639 */         widgetEnabled(), 
/* 2640 */         widgetChannelId(), 
/* 2641 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 2643 */         rulesChannelId(), newValue, 
/*      */         
/* 2645 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 2649 */         premiumSubscriptionCount(), 
/* 2650 */         publicUpdatesChannelId(), 
/* 2651 */         maxVideoChannelUsers(), 
/* 2652 */         approximateMemberCount(), 
/* 2653 */         approximatePresenceCount(), 
/* 2654 */         welcomeScreen(), 
/* 2655 */         nsfw(), 
/* 2656 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 2659 */         ownerId(), 
/* 2660 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2669 */         stickers());
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public ImmutableGuildUpdateData withMaxPresences(@Nullable Integer value) {
/* 2674 */     Possible<Optional<Integer>> newValue = Possible.of(Optional.ofNullable(value));
/* 2675 */     return new ImmutableGuildUpdateData(this, 
/*      */         
/* 2677 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2682 */         owner(), 
/* 2683 */         permissions(), 
/* 2684 */         afkChannelId(), 
/* 2685 */         embedEnabled(), 
/* 2686 */         embedChannelId(), this.features, 
/*      */         
/* 2688 */         applicationId(), 
/* 2689 */         widgetEnabled(), 
/* 2690 */         widgetChannelId(), 
/* 2691 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 2693 */         rulesChannelId(), newValue, 
/*      */         
/* 2695 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 2699 */         premiumSubscriptionCount(), 
/* 2700 */         publicUpdatesChannelId(), 
/* 2701 */         maxVideoChannelUsers(), 
/* 2702 */         approximateMemberCount(), 
/* 2703 */         approximatePresenceCount(), 
/* 2704 */         welcomeScreen(), 
/* 2705 */         nsfw(), 
/* 2706 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 2709 */         ownerId(), 
/* 2710 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2719 */         stickers());
/*      */   }
/*      */   
/*      */   public ImmutableGuildUpdateData withMaxPresencesOrNull(@Nullable Integer value) {
/* 2723 */     Possible<Optional<Integer>> newValue = Possible.of(Optional.ofNullable(value));
/* 2724 */     return new ImmutableGuildUpdateData(this, 
/*      */         
/* 2726 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2731 */         owner(), 
/* 2732 */         permissions(), 
/* 2733 */         afkChannelId(), 
/* 2734 */         embedEnabled(), 
/* 2735 */         embedChannelId(), this.features, 
/*      */         
/* 2737 */         applicationId(), 
/* 2738 */         widgetEnabled(), 
/* 2739 */         widgetChannelId(), 
/* 2740 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 2742 */         rulesChannelId(), newValue, 
/*      */         
/* 2744 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 2748 */         premiumSubscriptionCount(), 
/* 2749 */         publicUpdatesChannelId(), 
/* 2750 */         maxVideoChannelUsers(), 
/* 2751 */         approximateMemberCount(), 
/* 2752 */         approximatePresenceCount(), 
/* 2753 */         welcomeScreen(), 
/* 2754 */         nsfw(), 
/* 2755 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 2758 */         ownerId(), 
/* 2759 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2768 */         stickers());
/*      */   }
/*      */   
/*      */   public ImmutableGuildUpdateData withMaxMembers(Possible<Integer> value) {
/* 2772 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/* 2773 */     return new ImmutableGuildUpdateData(this, 
/*      */         
/* 2775 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2780 */         owner(), 
/* 2781 */         permissions(), 
/* 2782 */         afkChannelId(), 
/* 2783 */         embedEnabled(), 
/* 2784 */         embedChannelId(), this.features, 
/*      */         
/* 2786 */         applicationId(), 
/* 2787 */         widgetEnabled(), 
/* 2788 */         widgetChannelId(), 
/* 2789 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 2791 */         rulesChannelId(), 
/* 2792 */         maxPresences(), newValue, this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2797 */         premiumSubscriptionCount(), 
/* 2798 */         publicUpdatesChannelId(), 
/* 2799 */         maxVideoChannelUsers(), 
/* 2800 */         approximateMemberCount(), 
/* 2801 */         approximatePresenceCount(), 
/* 2802 */         welcomeScreen(), 
/* 2803 */         nsfw(), 
/* 2804 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 2807 */         ownerId(), 
/* 2808 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2817 */         stickers());
/*      */   }
/*      */   
/*      */   public ImmutableGuildUpdateData withMaxMembers(Integer value) {
/* 2821 */     Possible<Integer> newValue = Possible.of(value);
/* 2822 */     return new ImmutableGuildUpdateData(this, 
/*      */         
/* 2824 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2829 */         owner(), 
/* 2830 */         permissions(), 
/* 2831 */         afkChannelId(), 
/* 2832 */         embedEnabled(), 
/* 2833 */         embedChannelId(), this.features, 
/*      */         
/* 2835 */         applicationId(), 
/* 2836 */         widgetEnabled(), 
/* 2837 */         widgetChannelId(), 
/* 2838 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 2840 */         rulesChannelId(), 
/* 2841 */         maxPresences(), newValue, this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2846 */         premiumSubscriptionCount(), 
/* 2847 */         publicUpdatesChannelId(), 
/* 2848 */         maxVideoChannelUsers(), 
/* 2849 */         approximateMemberCount(), 
/* 2850 */         approximatePresenceCount(), 
/* 2851 */         welcomeScreen(), 
/* 2852 */         nsfw(), 
/* 2853 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 2856 */         ownerId(), 
/* 2857 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2866 */         stickers());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildUpdateData withVanityUrlCode(String value) {
/* 2875 */     String newValue = Objects.<String>requireNonNull(value, "vanityUrlCode");
/* 2876 */     if (Objects.equals(this.vanityUrlCode, newValue)) return this; 
/* 2877 */     return new ImmutableGuildUpdateData(this, 
/*      */         
/* 2879 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2884 */         owner(), 
/* 2885 */         permissions(), 
/* 2886 */         afkChannelId(), 
/* 2887 */         embedEnabled(), 
/* 2888 */         embedChannelId(), this.features, 
/*      */         
/* 2890 */         applicationId(), 
/* 2891 */         widgetEnabled(), 
/* 2892 */         widgetChannelId(), 
/* 2893 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 2895 */         rulesChannelId(), 
/* 2896 */         maxPresences(), 
/* 2897 */         maxMembers(), newValue, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 2901 */         premiumSubscriptionCount(), 
/* 2902 */         publicUpdatesChannelId(), 
/* 2903 */         maxVideoChannelUsers(), 
/* 2904 */         approximateMemberCount(), 
/* 2905 */         approximatePresenceCount(), 
/* 2906 */         welcomeScreen(), 
/* 2907 */         nsfw(), 
/* 2908 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 2911 */         ownerId(), 
/* 2912 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2921 */         stickers());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildUpdateData withVanityUrlCode(Optional<String> optional) {
/* 2931 */     String value = optional.orElse(null);
/* 2932 */     if (Objects.equals(this.vanityUrlCode, value)) return this; 
/* 2933 */     return new ImmutableGuildUpdateData(this, 
/*      */         
/* 2935 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2940 */         owner(), 
/* 2941 */         permissions(), 
/* 2942 */         afkChannelId(), 
/* 2943 */         embedEnabled(), 
/* 2944 */         embedChannelId(), this.features, 
/*      */         
/* 2946 */         applicationId(), 
/* 2947 */         widgetEnabled(), 
/* 2948 */         widgetChannelId(), 
/* 2949 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 2951 */         rulesChannelId(), 
/* 2952 */         maxPresences(), 
/* 2953 */         maxMembers(), value, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 2957 */         premiumSubscriptionCount(), 
/* 2958 */         publicUpdatesChannelId(), 
/* 2959 */         maxVideoChannelUsers(), 
/* 2960 */         approximateMemberCount(), 
/* 2961 */         approximatePresenceCount(), 
/* 2962 */         welcomeScreen(), 
/* 2963 */         nsfw(), 
/* 2964 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 2967 */         ownerId(), 
/* 2968 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2977 */         stickers());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildUpdateData withDescription(String value) {
/* 2986 */     String newValue = Objects.<String>requireNonNull(value, "description");
/* 2987 */     if (Objects.equals(this.description, newValue)) return this; 
/* 2988 */     return new ImmutableGuildUpdateData(this, 
/*      */         
/* 2990 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2995 */         owner(), 
/* 2996 */         permissions(), 
/* 2997 */         afkChannelId(), 
/* 2998 */         embedEnabled(), 
/* 2999 */         embedChannelId(), this.features, 
/*      */         
/* 3001 */         applicationId(), 
/* 3002 */         widgetEnabled(), 
/* 3003 */         widgetChannelId(), 
/* 3004 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 3006 */         rulesChannelId(), 
/* 3007 */         maxPresences(), 
/* 3008 */         maxMembers(), this.vanityUrlCode, newValue, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 3012 */         premiumSubscriptionCount(), 
/* 3013 */         publicUpdatesChannelId(), 
/* 3014 */         maxVideoChannelUsers(), 
/* 3015 */         approximateMemberCount(), 
/* 3016 */         approximatePresenceCount(), 
/* 3017 */         welcomeScreen(), 
/* 3018 */         nsfw(), 
/* 3019 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 3022 */         ownerId(), 
/* 3023 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3032 */         stickers());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildUpdateData withDescription(Optional<String> optional) {
/* 3042 */     String value = optional.orElse(null);
/* 3043 */     if (Objects.equals(this.description, value)) return this; 
/* 3044 */     return new ImmutableGuildUpdateData(this, 
/*      */         
/* 3046 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3051 */         owner(), 
/* 3052 */         permissions(), 
/* 3053 */         afkChannelId(), 
/* 3054 */         embedEnabled(), 
/* 3055 */         embedChannelId(), this.features, 
/*      */         
/* 3057 */         applicationId(), 
/* 3058 */         widgetEnabled(), 
/* 3059 */         widgetChannelId(), 
/* 3060 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 3062 */         rulesChannelId(), 
/* 3063 */         maxPresences(), 
/* 3064 */         maxMembers(), this.vanityUrlCode, value, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 3068 */         premiumSubscriptionCount(), 
/* 3069 */         publicUpdatesChannelId(), 
/* 3070 */         maxVideoChannelUsers(), 
/* 3071 */         approximateMemberCount(), 
/* 3072 */         approximatePresenceCount(), 
/* 3073 */         welcomeScreen(), 
/* 3074 */         nsfw(), 
/* 3075 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 3078 */         ownerId(), 
/* 3079 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3088 */         stickers());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildUpdateData withBanner(String value) {
/* 3097 */     String newValue = Objects.<String>requireNonNull(value, "banner");
/* 3098 */     if (Objects.equals(this.banner, newValue)) return this; 
/* 3099 */     return new ImmutableGuildUpdateData(this, 
/*      */         
/* 3101 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3106 */         owner(), 
/* 3107 */         permissions(), 
/* 3108 */         afkChannelId(), 
/* 3109 */         embedEnabled(), 
/* 3110 */         embedChannelId(), this.features, 
/*      */         
/* 3112 */         applicationId(), 
/* 3113 */         widgetEnabled(), 
/* 3114 */         widgetChannelId(), 
/* 3115 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 3117 */         rulesChannelId(), 
/* 3118 */         maxPresences(), 
/* 3119 */         maxMembers(), this.vanityUrlCode, this.description, newValue, 
/*      */ 
/*      */ 
/*      */         
/* 3123 */         premiumSubscriptionCount(), 
/* 3124 */         publicUpdatesChannelId(), 
/* 3125 */         maxVideoChannelUsers(), 
/* 3126 */         approximateMemberCount(), 
/* 3127 */         approximatePresenceCount(), 
/* 3128 */         welcomeScreen(), 
/* 3129 */         nsfw(), 
/* 3130 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 3133 */         ownerId(), 
/* 3134 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3143 */         stickers());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildUpdateData withBanner(Optional<String> optional) {
/* 3153 */     String value = optional.orElse(null);
/* 3154 */     if (Objects.equals(this.banner, value)) return this; 
/* 3155 */     return new ImmutableGuildUpdateData(this, 
/*      */         
/* 3157 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3162 */         owner(), 
/* 3163 */         permissions(), 
/* 3164 */         afkChannelId(), 
/* 3165 */         embedEnabled(), 
/* 3166 */         embedChannelId(), this.features, 
/*      */         
/* 3168 */         applicationId(), 
/* 3169 */         widgetEnabled(), 
/* 3170 */         widgetChannelId(), 
/* 3171 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 3173 */         rulesChannelId(), 
/* 3174 */         maxPresences(), 
/* 3175 */         maxMembers(), this.vanityUrlCode, this.description, value, 
/*      */ 
/*      */ 
/*      */         
/* 3179 */         premiumSubscriptionCount(), 
/* 3180 */         publicUpdatesChannelId(), 
/* 3181 */         maxVideoChannelUsers(), 
/* 3182 */         approximateMemberCount(), 
/* 3183 */         approximatePresenceCount(), 
/* 3184 */         welcomeScreen(), 
/* 3185 */         nsfw(), 
/* 3186 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 3189 */         ownerId(), 
/* 3190 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3199 */         stickers());
/*      */   }
/*      */   
/*      */   public ImmutableGuildUpdateData withPremiumSubscriptionCount(Possible<Integer> value) {
/* 3203 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/* 3204 */     return new ImmutableGuildUpdateData(this, 
/*      */         
/* 3206 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3211 */         owner(), 
/* 3212 */         permissions(), 
/* 3213 */         afkChannelId(), 
/* 3214 */         embedEnabled(), 
/* 3215 */         embedChannelId(), this.features, 
/*      */         
/* 3217 */         applicationId(), 
/* 3218 */         widgetEnabled(), 
/* 3219 */         widgetChannelId(), 
/* 3220 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 3222 */         rulesChannelId(), 
/* 3223 */         maxPresences(), 
/* 3224 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, newValue, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3229 */         publicUpdatesChannelId(), 
/* 3230 */         maxVideoChannelUsers(), 
/* 3231 */         approximateMemberCount(), 
/* 3232 */         approximatePresenceCount(), 
/* 3233 */         welcomeScreen(), 
/* 3234 */         nsfw(), 
/* 3235 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 3238 */         ownerId(), 
/* 3239 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3248 */         stickers());
/*      */   }
/*      */   
/*      */   public ImmutableGuildUpdateData withPremiumSubscriptionCount(Integer value) {
/* 3252 */     Possible<Integer> newValue = Possible.of(value);
/* 3253 */     return new ImmutableGuildUpdateData(this, 
/*      */         
/* 3255 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3260 */         owner(), 
/* 3261 */         permissions(), 
/* 3262 */         afkChannelId(), 
/* 3263 */         embedEnabled(), 
/* 3264 */         embedChannelId(), this.features, 
/*      */         
/* 3266 */         applicationId(), 
/* 3267 */         widgetEnabled(), 
/* 3268 */         widgetChannelId(), 
/* 3269 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 3271 */         rulesChannelId(), 
/* 3272 */         maxPresences(), 
/* 3273 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, newValue, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3278 */         publicUpdatesChannelId(), 
/* 3279 */         maxVideoChannelUsers(), 
/* 3280 */         approximateMemberCount(), 
/* 3281 */         approximatePresenceCount(), 
/* 3282 */         welcomeScreen(), 
/* 3283 */         nsfw(), 
/* 3284 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 3287 */         ownerId(), 
/* 3288 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3297 */         stickers());
/*      */   }
/*      */   
/*      */   public ImmutableGuildUpdateData withPublicUpdatesChannelId(Optional<Id> value) {
/* 3301 */     Optional<Id> newValue = Objects.<Optional<Id>>requireNonNull(value);
/* 3302 */     return new ImmutableGuildUpdateData(this, 
/*      */         
/* 3304 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3309 */         owner(), 
/* 3310 */         permissions(), 
/* 3311 */         afkChannelId(), 
/* 3312 */         embedEnabled(), 
/* 3313 */         embedChannelId(), this.features, 
/*      */         
/* 3315 */         applicationId(), 
/* 3316 */         widgetEnabled(), 
/* 3317 */         widgetChannelId(), 
/* 3318 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 3320 */         rulesChannelId(), 
/* 3321 */         maxPresences(), 
/* 3322 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 3326 */         premiumSubscriptionCount(), newValue, 
/*      */         
/* 3328 */         maxVideoChannelUsers(), 
/* 3329 */         approximateMemberCount(), 
/* 3330 */         approximatePresenceCount(), 
/* 3331 */         welcomeScreen(), 
/* 3332 */         nsfw(), 
/* 3333 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 3336 */         ownerId(), 
/* 3337 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3346 */         stickers());
/*      */   }
/*      */   
/*      */   public ImmutableGuildUpdateData withPublicUpdatesChannelId(long value) {
/* 3350 */     Optional<Id> newValue = Optional.of(Id.of(value));
/* 3351 */     return new ImmutableGuildUpdateData(this, 
/*      */         
/* 3353 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3358 */         owner(), 
/* 3359 */         permissions(), 
/* 3360 */         afkChannelId(), 
/* 3361 */         embedEnabled(), 
/* 3362 */         embedChannelId(), this.features, 
/*      */         
/* 3364 */         applicationId(), 
/* 3365 */         widgetEnabled(), 
/* 3366 */         widgetChannelId(), 
/* 3367 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 3369 */         rulesChannelId(), 
/* 3370 */         maxPresences(), 
/* 3371 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 3375 */         premiumSubscriptionCount(), newValue, 
/*      */         
/* 3377 */         maxVideoChannelUsers(), 
/* 3378 */         approximateMemberCount(), 
/* 3379 */         approximatePresenceCount(), 
/* 3380 */         welcomeScreen(), 
/* 3381 */         nsfw(), 
/* 3382 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 3385 */         ownerId(), 
/* 3386 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3395 */         stickers());
/*      */   }
/*      */   
/*      */   public ImmutableGuildUpdateData withMaxVideoChannelUsers(Possible<Integer> value) {
/* 3399 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/* 3400 */     return new ImmutableGuildUpdateData(this, 
/*      */         
/* 3402 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3407 */         owner(), 
/* 3408 */         permissions(), 
/* 3409 */         afkChannelId(), 
/* 3410 */         embedEnabled(), 
/* 3411 */         embedChannelId(), this.features, 
/*      */         
/* 3413 */         applicationId(), 
/* 3414 */         widgetEnabled(), 
/* 3415 */         widgetChannelId(), 
/* 3416 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 3418 */         rulesChannelId(), 
/* 3419 */         maxPresences(), 
/* 3420 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 3424 */         premiumSubscriptionCount(), 
/* 3425 */         publicUpdatesChannelId(), newValue, 
/*      */         
/* 3427 */         approximateMemberCount(), 
/* 3428 */         approximatePresenceCount(), 
/* 3429 */         welcomeScreen(), 
/* 3430 */         nsfw(), 
/* 3431 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 3434 */         ownerId(), 
/* 3435 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3444 */         stickers());
/*      */   }
/*      */   
/*      */   public ImmutableGuildUpdateData withMaxVideoChannelUsers(Integer value) {
/* 3448 */     Possible<Integer> newValue = Possible.of(value);
/* 3449 */     return new ImmutableGuildUpdateData(this, 
/*      */         
/* 3451 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3456 */         owner(), 
/* 3457 */         permissions(), 
/* 3458 */         afkChannelId(), 
/* 3459 */         embedEnabled(), 
/* 3460 */         embedChannelId(), this.features, 
/*      */         
/* 3462 */         applicationId(), 
/* 3463 */         widgetEnabled(), 
/* 3464 */         widgetChannelId(), 
/* 3465 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 3467 */         rulesChannelId(), 
/* 3468 */         maxPresences(), 
/* 3469 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 3473 */         premiumSubscriptionCount(), 
/* 3474 */         publicUpdatesChannelId(), newValue, 
/*      */         
/* 3476 */         approximateMemberCount(), 
/* 3477 */         approximatePresenceCount(), 
/* 3478 */         welcomeScreen(), 
/* 3479 */         nsfw(), 
/* 3480 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 3483 */         ownerId(), 
/* 3484 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3493 */         stickers());
/*      */   }
/*      */   
/*      */   public ImmutableGuildUpdateData withApproximateMemberCount(Possible<Integer> value) {
/* 3497 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/* 3498 */     return new ImmutableGuildUpdateData(this, 
/*      */         
/* 3500 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3505 */         owner(), 
/* 3506 */         permissions(), 
/* 3507 */         afkChannelId(), 
/* 3508 */         embedEnabled(), 
/* 3509 */         embedChannelId(), this.features, 
/*      */         
/* 3511 */         applicationId(), 
/* 3512 */         widgetEnabled(), 
/* 3513 */         widgetChannelId(), 
/* 3514 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 3516 */         rulesChannelId(), 
/* 3517 */         maxPresences(), 
/* 3518 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 3522 */         premiumSubscriptionCount(), 
/* 3523 */         publicUpdatesChannelId(), 
/* 3524 */         maxVideoChannelUsers(), newValue, 
/*      */         
/* 3526 */         approximatePresenceCount(), 
/* 3527 */         welcomeScreen(), 
/* 3528 */         nsfw(), 
/* 3529 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 3532 */         ownerId(), 
/* 3533 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3542 */         stickers());
/*      */   }
/*      */   
/*      */   public ImmutableGuildUpdateData withApproximateMemberCount(Integer value) {
/* 3546 */     Possible<Integer> newValue = Possible.of(value);
/* 3547 */     return new ImmutableGuildUpdateData(this, 
/*      */         
/* 3549 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3554 */         owner(), 
/* 3555 */         permissions(), 
/* 3556 */         afkChannelId(), 
/* 3557 */         embedEnabled(), 
/* 3558 */         embedChannelId(), this.features, 
/*      */         
/* 3560 */         applicationId(), 
/* 3561 */         widgetEnabled(), 
/* 3562 */         widgetChannelId(), 
/* 3563 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 3565 */         rulesChannelId(), 
/* 3566 */         maxPresences(), 
/* 3567 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 3571 */         premiumSubscriptionCount(), 
/* 3572 */         publicUpdatesChannelId(), 
/* 3573 */         maxVideoChannelUsers(), newValue, 
/*      */         
/* 3575 */         approximatePresenceCount(), 
/* 3576 */         welcomeScreen(), 
/* 3577 */         nsfw(), 
/* 3578 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 3581 */         ownerId(), 
/* 3582 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3591 */         stickers());
/*      */   }
/*      */   
/*      */   public ImmutableGuildUpdateData withApproximatePresenceCount(Possible<Integer> value) {
/* 3595 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/* 3596 */     return new ImmutableGuildUpdateData(this, 
/*      */         
/* 3598 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3603 */         owner(), 
/* 3604 */         permissions(), 
/* 3605 */         afkChannelId(), 
/* 3606 */         embedEnabled(), 
/* 3607 */         embedChannelId(), this.features, 
/*      */         
/* 3609 */         applicationId(), 
/* 3610 */         widgetEnabled(), 
/* 3611 */         widgetChannelId(), 
/* 3612 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 3614 */         rulesChannelId(), 
/* 3615 */         maxPresences(), 
/* 3616 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 3620 */         premiumSubscriptionCount(), 
/* 3621 */         publicUpdatesChannelId(), 
/* 3622 */         maxVideoChannelUsers(), 
/* 3623 */         approximateMemberCount(), newValue, 
/*      */         
/* 3625 */         welcomeScreen(), 
/* 3626 */         nsfw(), 
/* 3627 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 3630 */         ownerId(), 
/* 3631 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3640 */         stickers());
/*      */   }
/*      */   
/*      */   public ImmutableGuildUpdateData withApproximatePresenceCount(Integer value) {
/* 3644 */     Possible<Integer> newValue = Possible.of(value);
/* 3645 */     return new ImmutableGuildUpdateData(this, 
/*      */         
/* 3647 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3652 */         owner(), 
/* 3653 */         permissions(), 
/* 3654 */         afkChannelId(), 
/* 3655 */         embedEnabled(), 
/* 3656 */         embedChannelId(), this.features, 
/*      */         
/* 3658 */         applicationId(), 
/* 3659 */         widgetEnabled(), 
/* 3660 */         widgetChannelId(), 
/* 3661 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 3663 */         rulesChannelId(), 
/* 3664 */         maxPresences(), 
/* 3665 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 3669 */         premiumSubscriptionCount(), 
/* 3670 */         publicUpdatesChannelId(), 
/* 3671 */         maxVideoChannelUsers(), 
/* 3672 */         approximateMemberCount(), newValue, 
/*      */         
/* 3674 */         welcomeScreen(), 
/* 3675 */         nsfw(), 
/* 3676 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 3679 */         ownerId(), 
/* 3680 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3689 */         stickers());
/*      */   }
/*      */   
/*      */   public ImmutableGuildUpdateData withWelcomeScreen(Possible<WelcomeScreenData> value) {
/* 3693 */     Possible<WelcomeScreenData> newValue = Objects.<Possible<WelcomeScreenData>>requireNonNull(value);
/* 3694 */     return new ImmutableGuildUpdateData(this, 
/*      */         
/* 3696 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3701 */         owner(), 
/* 3702 */         permissions(), 
/* 3703 */         afkChannelId(), 
/* 3704 */         embedEnabled(), 
/* 3705 */         embedChannelId(), this.features, 
/*      */         
/* 3707 */         applicationId(), 
/* 3708 */         widgetEnabled(), 
/* 3709 */         widgetChannelId(), 
/* 3710 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 3712 */         rulesChannelId(), 
/* 3713 */         maxPresences(), 
/* 3714 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 3718 */         premiumSubscriptionCount(), 
/* 3719 */         publicUpdatesChannelId(), 
/* 3720 */         maxVideoChannelUsers(), 
/* 3721 */         approximateMemberCount(), 
/* 3722 */         approximatePresenceCount(), newValue, 
/*      */         
/* 3724 */         nsfw(), 
/* 3725 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 3728 */         ownerId(), 
/* 3729 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3738 */         stickers());
/*      */   }
/*      */   
/*      */   public ImmutableGuildUpdateData withWelcomeScreen(WelcomeScreenData value) {
/* 3742 */     Possible<WelcomeScreenData> newValue = Possible.of(value);
/* 3743 */     return new ImmutableGuildUpdateData(this, 
/*      */         
/* 3745 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3750 */         owner(), 
/* 3751 */         permissions(), 
/* 3752 */         afkChannelId(), 
/* 3753 */         embedEnabled(), 
/* 3754 */         embedChannelId(), this.features, 
/*      */         
/* 3756 */         applicationId(), 
/* 3757 */         widgetEnabled(), 
/* 3758 */         widgetChannelId(), 
/* 3759 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 3761 */         rulesChannelId(), 
/* 3762 */         maxPresences(), 
/* 3763 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 3767 */         premiumSubscriptionCount(), 
/* 3768 */         publicUpdatesChannelId(), 
/* 3769 */         maxVideoChannelUsers(), 
/* 3770 */         approximateMemberCount(), 
/* 3771 */         approximatePresenceCount(), newValue, 
/*      */         
/* 3773 */         nsfw(), 
/* 3774 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 3777 */         ownerId(), 
/* 3778 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3787 */         stickers());
/*      */   }
/*      */   
/*      */   public ImmutableGuildUpdateData withNsfw(Possible<Boolean> value) {
/* 3791 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/* 3792 */     return new ImmutableGuildUpdateData(this, 
/*      */         
/* 3794 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3799 */         owner(), 
/* 3800 */         permissions(), 
/* 3801 */         afkChannelId(), 
/* 3802 */         embedEnabled(), 
/* 3803 */         embedChannelId(), this.features, 
/*      */         
/* 3805 */         applicationId(), 
/* 3806 */         widgetEnabled(), 
/* 3807 */         widgetChannelId(), 
/* 3808 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 3810 */         rulesChannelId(), 
/* 3811 */         maxPresences(), 
/* 3812 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 3816 */         premiumSubscriptionCount(), 
/* 3817 */         publicUpdatesChannelId(), 
/* 3818 */         maxVideoChannelUsers(), 
/* 3819 */         approximateMemberCount(), 
/* 3820 */         approximatePresenceCount(), 
/* 3821 */         welcomeScreen(), newValue, 
/*      */         
/* 3823 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 3826 */         ownerId(), 
/* 3827 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3836 */         stickers());
/*      */   }
/*      */   
/*      */   public ImmutableGuildUpdateData withNsfw(Boolean value) {
/* 3840 */     Possible<Boolean> newValue = Possible.of(value);
/* 3841 */     return new ImmutableGuildUpdateData(this, 
/*      */         
/* 3843 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3848 */         owner(), 
/* 3849 */         permissions(), 
/* 3850 */         afkChannelId(), 
/* 3851 */         embedEnabled(), 
/* 3852 */         embedChannelId(), this.features, 
/*      */         
/* 3854 */         applicationId(), 
/* 3855 */         widgetEnabled(), 
/* 3856 */         widgetChannelId(), 
/* 3857 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 3859 */         rulesChannelId(), 
/* 3860 */         maxPresences(), 
/* 3861 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 3865 */         premiumSubscriptionCount(), 
/* 3866 */         publicUpdatesChannelId(), 
/* 3867 */         maxVideoChannelUsers(), 
/* 3868 */         approximateMemberCount(), 
/* 3869 */         approximatePresenceCount(), 
/* 3870 */         welcomeScreen(), newValue, 
/*      */         
/* 3872 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 3875 */         ownerId(), 
/* 3876 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3885 */         stickers());
/*      */   }
/*      */   
/*      */   public ImmutableGuildUpdateData withSafetyAlertsChannelId(Optional<Id> value) {
/* 3889 */     Optional<Id> newValue = Objects.<Optional<Id>>requireNonNull(value);
/* 3890 */     return new ImmutableGuildUpdateData(this, 
/*      */         
/* 3892 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3897 */         owner(), 
/* 3898 */         permissions(), 
/* 3899 */         afkChannelId(), 
/* 3900 */         embedEnabled(), 
/* 3901 */         embedChannelId(), this.features, 
/*      */         
/* 3903 */         applicationId(), 
/* 3904 */         widgetEnabled(), 
/* 3905 */         widgetChannelId(), 
/* 3906 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 3908 */         rulesChannelId(), 
/* 3909 */         maxPresences(), 
/* 3910 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 3914 */         premiumSubscriptionCount(), 
/* 3915 */         publicUpdatesChannelId(), 
/* 3916 */         maxVideoChannelUsers(), 
/* 3917 */         approximateMemberCount(), 
/* 3918 */         approximatePresenceCount(), 
/* 3919 */         welcomeScreen(), 
/* 3920 */         nsfw(), newValue, this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */ 
/*      */         
/* 3924 */         ownerId(), 
/* 3925 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3934 */         stickers());
/*      */   }
/*      */   
/*      */   public ImmutableGuildUpdateData withSafetyAlertsChannelId(long value) {
/* 3938 */     Optional<Id> newValue = Optional.of(Id.of(value));
/* 3939 */     return new ImmutableGuildUpdateData(this, 
/*      */         
/* 3941 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3946 */         owner(), 
/* 3947 */         permissions(), 
/* 3948 */         afkChannelId(), 
/* 3949 */         embedEnabled(), 
/* 3950 */         embedChannelId(), this.features, 
/*      */         
/* 3952 */         applicationId(), 
/* 3953 */         widgetEnabled(), 
/* 3954 */         widgetChannelId(), 
/* 3955 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 3957 */         rulesChannelId(), 
/* 3958 */         maxPresences(), 
/* 3959 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 3963 */         premiumSubscriptionCount(), 
/* 3964 */         publicUpdatesChannelId(), 
/* 3965 */         maxVideoChannelUsers(), 
/* 3966 */         approximateMemberCount(), 
/* 3967 */         approximatePresenceCount(), 
/* 3968 */         welcomeScreen(), 
/* 3969 */         nsfw(), newValue, this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */ 
/*      */         
/* 3973 */         ownerId(), 
/* 3974 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3983 */         stickers());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildUpdateData withVerificationLevel(int value) {
/* 3993 */     if (this.verificationLevel == value) return this; 
/* 3994 */     return new ImmutableGuildUpdateData(this, 
/*      */         
/* 3996 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4001 */         owner(), 
/* 4002 */         permissions(), 
/* 4003 */         afkChannelId(), 
/* 4004 */         embedEnabled(), 
/* 4005 */         embedChannelId(), this.features, 
/*      */         
/* 4007 */         applicationId(), 
/* 4008 */         widgetEnabled(), 
/* 4009 */         widgetChannelId(), 
/* 4010 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 4012 */         rulesChannelId(), 
/* 4013 */         maxPresences(), 
/* 4014 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 4018 */         premiumSubscriptionCount(), 
/* 4019 */         publicUpdatesChannelId(), 
/* 4020 */         maxVideoChannelUsers(), 
/* 4021 */         approximateMemberCount(), 
/* 4022 */         approximatePresenceCount(), 
/* 4023 */         welcomeScreen(), 
/* 4024 */         nsfw(), 
/* 4025 */         safetyAlertsChannelId(), value, this.nsfwLevel, 
/*      */ 
/*      */         
/* 4028 */         ownerId(), 
/* 4029 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4038 */         stickers());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildUpdateData withNsfwLevel(int value) {
/* 4048 */     if (this.nsfwLevel == value) return this; 
/* 4049 */     return new ImmutableGuildUpdateData(this, 
/*      */         
/* 4051 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4056 */         owner(), 
/* 4057 */         permissions(), 
/* 4058 */         afkChannelId(), 
/* 4059 */         embedEnabled(), 
/* 4060 */         embedChannelId(), this.features, 
/*      */         
/* 4062 */         applicationId(), 
/* 4063 */         widgetEnabled(), 
/* 4064 */         widgetChannelId(), 
/* 4065 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 4067 */         rulesChannelId(), 
/* 4068 */         maxPresences(), 
/* 4069 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 4073 */         premiumSubscriptionCount(), 
/* 4074 */         publicUpdatesChannelId(), 
/* 4075 */         maxVideoChannelUsers(), 
/* 4076 */         approximateMemberCount(), 
/* 4077 */         approximatePresenceCount(), 
/* 4078 */         welcomeScreen(), 
/* 4079 */         nsfw(), 
/* 4080 */         safetyAlertsChannelId(), this.verificationLevel, value, 
/*      */ 
/*      */         
/* 4083 */         ownerId(), 
/* 4084 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4093 */         stickers());
/*      */   }
/*      */   
/*      */   public ImmutableGuildUpdateData withOwnerId(long value) {
/* 4097 */     Id newValue = Id.of(value);
/* 4098 */     return new ImmutableGuildUpdateData(this, 
/*      */         
/* 4100 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4105 */         owner(), 
/* 4106 */         permissions(), 
/* 4107 */         afkChannelId(), 
/* 4108 */         embedEnabled(), 
/* 4109 */         embedChannelId(), this.features, 
/*      */         
/* 4111 */         applicationId(), 
/* 4112 */         widgetEnabled(), 
/* 4113 */         widgetChannelId(), 
/* 4114 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 4116 */         rulesChannelId(), 
/* 4117 */         maxPresences(), 
/* 4118 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 4122 */         premiumSubscriptionCount(), 
/* 4123 */         publicUpdatesChannelId(), 
/* 4124 */         maxVideoChannelUsers(), 
/* 4125 */         approximateMemberCount(), 
/* 4126 */         approximatePresenceCount(), 
/* 4127 */         welcomeScreen(), 
/* 4128 */         nsfw(), 
/* 4129 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, newValue, 
/*      */ 
/*      */ 
/*      */         
/* 4133 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4142 */         stickers());
/*      */   }
/*      */   
/*      */   public ImmutableGuildUpdateData withOwnerId(String value) {
/* 4146 */     Id newValue = Id.of(value);
/* 4147 */     return new ImmutableGuildUpdateData(this, 
/*      */         
/* 4149 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4154 */         owner(), 
/* 4155 */         permissions(), 
/* 4156 */         afkChannelId(), 
/* 4157 */         embedEnabled(), 
/* 4158 */         embedChannelId(), this.features, 
/*      */         
/* 4160 */         applicationId(), 
/* 4161 */         widgetEnabled(), 
/* 4162 */         widgetChannelId(), 
/* 4163 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 4165 */         rulesChannelId(), 
/* 4166 */         maxPresences(), 
/* 4167 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 4171 */         premiumSubscriptionCount(), 
/* 4172 */         publicUpdatesChannelId(), 
/* 4173 */         maxVideoChannelUsers(), 
/* 4174 */         approximateMemberCount(), 
/* 4175 */         approximatePresenceCount(), 
/* 4176 */         welcomeScreen(), 
/* 4177 */         nsfw(), 
/* 4178 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, newValue, 
/*      */ 
/*      */ 
/*      */         
/* 4182 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4191 */         stickers());
/*      */   }
/*      */   
/*      */   public ImmutableGuildUpdateData withRegion(Possible<Optional<String>> value) {
/* 4195 */     Possible<Optional<String>> newValue = Objects.<Possible<Optional<String>>>requireNonNull(value);
/* 4196 */     return new ImmutableGuildUpdateData(this, 
/*      */         
/* 4198 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4203 */         owner(), 
/* 4204 */         permissions(), 
/* 4205 */         afkChannelId(), 
/* 4206 */         embedEnabled(), 
/* 4207 */         embedChannelId(), this.features, 
/*      */         
/* 4209 */         applicationId(), 
/* 4210 */         widgetEnabled(), 
/* 4211 */         widgetChannelId(), 
/* 4212 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 4214 */         rulesChannelId(), 
/* 4215 */         maxPresences(), 
/* 4216 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 4220 */         premiumSubscriptionCount(), 
/* 4221 */         publicUpdatesChannelId(), 
/* 4222 */         maxVideoChannelUsers(), 
/* 4223 */         approximateMemberCount(), 
/* 4224 */         approximatePresenceCount(), 
/* 4225 */         welcomeScreen(), 
/* 4226 */         nsfw(), 
/* 4227 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 4230 */         ownerId(), newValue, this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4240 */         stickers());
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public ImmutableGuildUpdateData withRegion(@Nullable String value) {
/* 4245 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/* 4246 */     return new ImmutableGuildUpdateData(this, 
/*      */         
/* 4248 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4253 */         owner(), 
/* 4254 */         permissions(), 
/* 4255 */         afkChannelId(), 
/* 4256 */         embedEnabled(), 
/* 4257 */         embedChannelId(), this.features, 
/*      */         
/* 4259 */         applicationId(), 
/* 4260 */         widgetEnabled(), 
/* 4261 */         widgetChannelId(), 
/* 4262 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 4264 */         rulesChannelId(), 
/* 4265 */         maxPresences(), 
/* 4266 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 4270 */         premiumSubscriptionCount(), 
/* 4271 */         publicUpdatesChannelId(), 
/* 4272 */         maxVideoChannelUsers(), 
/* 4273 */         approximateMemberCount(), 
/* 4274 */         approximatePresenceCount(), 
/* 4275 */         welcomeScreen(), 
/* 4276 */         nsfw(), 
/* 4277 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 4280 */         ownerId(), newValue, this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4290 */         stickers());
/*      */   }
/*      */   
/*      */   public ImmutableGuildUpdateData withRegionOrNull(@Nullable String value) {
/* 4294 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/* 4295 */     return new ImmutableGuildUpdateData(this, 
/*      */         
/* 4297 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4302 */         owner(), 
/* 4303 */         permissions(), 
/* 4304 */         afkChannelId(), 
/* 4305 */         embedEnabled(), 
/* 4306 */         embedChannelId(), this.features, 
/*      */         
/* 4308 */         applicationId(), 
/* 4309 */         widgetEnabled(), 
/* 4310 */         widgetChannelId(), 
/* 4311 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 4313 */         rulesChannelId(), 
/* 4314 */         maxPresences(), 
/* 4315 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 4319 */         premiumSubscriptionCount(), 
/* 4320 */         publicUpdatesChannelId(), 
/* 4321 */         maxVideoChannelUsers(), 
/* 4322 */         approximateMemberCount(), 
/* 4323 */         approximatePresenceCount(), 
/* 4324 */         welcomeScreen(), 
/* 4325 */         nsfw(), 
/* 4326 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 4329 */         ownerId(), newValue, this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4339 */         stickers());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildUpdateData withAfkTimeout(int value) {
/* 4349 */     if (this.afkTimeout == value) return this; 
/* 4350 */     return new ImmutableGuildUpdateData(this, 
/*      */         
/* 4352 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4357 */         owner(), 
/* 4358 */         permissions(), 
/* 4359 */         afkChannelId(), 
/* 4360 */         embedEnabled(), 
/* 4361 */         embedChannelId(), this.features, 
/*      */         
/* 4363 */         applicationId(), 
/* 4364 */         widgetEnabled(), 
/* 4365 */         widgetChannelId(), 
/* 4366 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 4368 */         rulesChannelId(), 
/* 4369 */         maxPresences(), 
/* 4370 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 4374 */         premiumSubscriptionCount(), 
/* 4375 */         publicUpdatesChannelId(), 
/* 4376 */         maxVideoChannelUsers(), 
/* 4377 */         approximateMemberCount(), 
/* 4378 */         approximatePresenceCount(), 
/* 4379 */         welcomeScreen(), 
/* 4380 */         nsfw(), 
/* 4381 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 4384 */         ownerId(), 
/* 4385 */         region(), value, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4394 */         stickers());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildUpdateData withDefaultMessageNotifications(int value) {
/* 4404 */     if (this.defaultMessageNotifications == value) return this; 
/* 4405 */     return new ImmutableGuildUpdateData(this, 
/*      */         
/* 4407 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4412 */         owner(), 
/* 4413 */         permissions(), 
/* 4414 */         afkChannelId(), 
/* 4415 */         embedEnabled(), 
/* 4416 */         embedChannelId(), this.features, 
/*      */         
/* 4418 */         applicationId(), 
/* 4419 */         widgetEnabled(), 
/* 4420 */         widgetChannelId(), 
/* 4421 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 4423 */         rulesChannelId(), 
/* 4424 */         maxPresences(), 
/* 4425 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 4429 */         premiumSubscriptionCount(), 
/* 4430 */         publicUpdatesChannelId(), 
/* 4431 */         maxVideoChannelUsers(), 
/* 4432 */         approximateMemberCount(), 
/* 4433 */         approximatePresenceCount(), 
/* 4434 */         welcomeScreen(), 
/* 4435 */         nsfw(), 
/* 4436 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 4439 */         ownerId(), 
/* 4440 */         region(), this.afkTimeout, value, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4449 */         stickers());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildUpdateData withExplicitContentFilter(int value) {
/* 4459 */     if (this.explicitContentFilter == value) return this; 
/* 4460 */     return new ImmutableGuildUpdateData(this, 
/*      */         
/* 4462 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4467 */         owner(), 
/* 4468 */         permissions(), 
/* 4469 */         afkChannelId(), 
/* 4470 */         embedEnabled(), 
/* 4471 */         embedChannelId(), this.features, 
/*      */         
/* 4473 */         applicationId(), 
/* 4474 */         widgetEnabled(), 
/* 4475 */         widgetChannelId(), 
/* 4476 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 4478 */         rulesChannelId(), 
/* 4479 */         maxPresences(), 
/* 4480 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 4484 */         premiumSubscriptionCount(), 
/* 4485 */         publicUpdatesChannelId(), 
/* 4486 */         maxVideoChannelUsers(), 
/* 4487 */         approximateMemberCount(), 
/* 4488 */         approximatePresenceCount(), 
/* 4489 */         welcomeScreen(), 
/* 4490 */         nsfw(), 
/* 4491 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 4494 */         ownerId(), 
/* 4495 */         region(), this.afkTimeout, this.defaultMessageNotifications, value, this.mfaLevel, this.premiumTier, this.preferredLocale, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4504 */         stickers());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildUpdateData withMfaLevel(int value) {
/* 4514 */     if (this.mfaLevel == value) return this; 
/* 4515 */     return new ImmutableGuildUpdateData(this, 
/*      */         
/* 4517 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4522 */         owner(), 
/* 4523 */         permissions(), 
/* 4524 */         afkChannelId(), 
/* 4525 */         embedEnabled(), 
/* 4526 */         embedChannelId(), this.features, 
/*      */         
/* 4528 */         applicationId(), 
/* 4529 */         widgetEnabled(), 
/* 4530 */         widgetChannelId(), 
/* 4531 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 4533 */         rulesChannelId(), 
/* 4534 */         maxPresences(), 
/* 4535 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 4539 */         premiumSubscriptionCount(), 
/* 4540 */         publicUpdatesChannelId(), 
/* 4541 */         maxVideoChannelUsers(), 
/* 4542 */         approximateMemberCount(), 
/* 4543 */         approximatePresenceCount(), 
/* 4544 */         welcomeScreen(), 
/* 4545 */         nsfw(), 
/* 4546 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 4549 */         ownerId(), 
/* 4550 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, value, this.premiumTier, this.preferredLocale, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4559 */         stickers());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildUpdateData withPremiumTier(int value) {
/* 4569 */     if (this.premiumTier == value) return this; 
/* 4570 */     return new ImmutableGuildUpdateData(this, 
/*      */         
/* 4572 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4577 */         owner(), 
/* 4578 */         permissions(), 
/* 4579 */         afkChannelId(), 
/* 4580 */         embedEnabled(), 
/* 4581 */         embedChannelId(), this.features, 
/*      */         
/* 4583 */         applicationId(), 
/* 4584 */         widgetEnabled(), 
/* 4585 */         widgetChannelId(), 
/* 4586 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 4588 */         rulesChannelId(), 
/* 4589 */         maxPresences(), 
/* 4590 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 4594 */         premiumSubscriptionCount(), 
/* 4595 */         publicUpdatesChannelId(), 
/* 4596 */         maxVideoChannelUsers(), 
/* 4597 */         approximateMemberCount(), 
/* 4598 */         approximatePresenceCount(), 
/* 4599 */         welcomeScreen(), 
/* 4600 */         nsfw(), 
/* 4601 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 4604 */         ownerId(), 
/* 4605 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, value, this.preferredLocale, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4614 */         stickers());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildUpdateData withPreferredLocale(String value) {
/* 4624 */     String newValue = Objects.<String>requireNonNull(value, "preferredLocale");
/* 4625 */     if (this.preferredLocale.equals(newValue)) return this; 
/* 4626 */     return new ImmutableGuildUpdateData(this, 
/*      */         
/* 4628 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4633 */         owner(), 
/* 4634 */         permissions(), 
/* 4635 */         afkChannelId(), 
/* 4636 */         embedEnabled(), 
/* 4637 */         embedChannelId(), this.features, 
/*      */         
/* 4639 */         applicationId(), 
/* 4640 */         widgetEnabled(), 
/* 4641 */         widgetChannelId(), 
/* 4642 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 4644 */         rulesChannelId(), 
/* 4645 */         maxPresences(), 
/* 4646 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 4650 */         premiumSubscriptionCount(), 
/* 4651 */         publicUpdatesChannelId(), 
/* 4652 */         maxVideoChannelUsers(), 
/* 4653 */         approximateMemberCount(), 
/* 4654 */         approximatePresenceCount(), 
/* 4655 */         welcomeScreen(), 
/* 4656 */         nsfw(), 
/* 4657 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 4660 */         ownerId(), 
/* 4661 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, newValue, this.roles, this.emojis, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4670 */         stickers());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildUpdateData withRoles(RoleData... elements) {
/* 4679 */     List<RoleData> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/* 4680 */     return new ImmutableGuildUpdateData(this, 
/*      */         
/* 4682 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4687 */         owner(), 
/* 4688 */         permissions(), 
/* 4689 */         afkChannelId(), 
/* 4690 */         embedEnabled(), 
/* 4691 */         embedChannelId(), this.features, 
/*      */         
/* 4693 */         applicationId(), 
/* 4694 */         widgetEnabled(), 
/* 4695 */         widgetChannelId(), 
/* 4696 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 4698 */         rulesChannelId(), 
/* 4699 */         maxPresences(), 
/* 4700 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 4704 */         premiumSubscriptionCount(), 
/* 4705 */         publicUpdatesChannelId(), 
/* 4706 */         maxVideoChannelUsers(), 
/* 4707 */         approximateMemberCount(), 
/* 4708 */         approximatePresenceCount(), 
/* 4709 */         welcomeScreen(), 
/* 4710 */         nsfw(), 
/* 4711 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 4714 */         ownerId(), 
/* 4715 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, newValue, this.emojis, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4724 */         stickers());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildUpdateData withRoles(Iterable<? extends RoleData> elements) {
/* 4734 */     if (this.roles == elements) return this; 
/* 4735 */     List<RoleData> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/* 4736 */     return new ImmutableGuildUpdateData(this, 
/*      */         
/* 4738 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4743 */         owner(), 
/* 4744 */         permissions(), 
/* 4745 */         afkChannelId(), 
/* 4746 */         embedEnabled(), 
/* 4747 */         embedChannelId(), this.features, 
/*      */         
/* 4749 */         applicationId(), 
/* 4750 */         widgetEnabled(), 
/* 4751 */         widgetChannelId(), 
/* 4752 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 4754 */         rulesChannelId(), 
/* 4755 */         maxPresences(), 
/* 4756 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 4760 */         premiumSubscriptionCount(), 
/* 4761 */         publicUpdatesChannelId(), 
/* 4762 */         maxVideoChannelUsers(), 
/* 4763 */         approximateMemberCount(), 
/* 4764 */         approximatePresenceCount(), 
/* 4765 */         welcomeScreen(), 
/* 4766 */         nsfw(), 
/* 4767 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 4770 */         ownerId(), 
/* 4771 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, newValue, this.emojis, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4780 */         stickers());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildUpdateData withEmojis(EmojiData... elements) {
/* 4789 */     List<EmojiData> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/* 4790 */     return new ImmutableGuildUpdateData(this, 
/*      */         
/* 4792 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4797 */         owner(), 
/* 4798 */         permissions(), 
/* 4799 */         afkChannelId(), 
/* 4800 */         embedEnabled(), 
/* 4801 */         embedChannelId(), this.features, 
/*      */         
/* 4803 */         applicationId(), 
/* 4804 */         widgetEnabled(), 
/* 4805 */         widgetChannelId(), 
/* 4806 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 4808 */         rulesChannelId(), 
/* 4809 */         maxPresences(), 
/* 4810 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 4814 */         premiumSubscriptionCount(), 
/* 4815 */         publicUpdatesChannelId(), 
/* 4816 */         maxVideoChannelUsers(), 
/* 4817 */         approximateMemberCount(), 
/* 4818 */         approximatePresenceCount(), 
/* 4819 */         welcomeScreen(), 
/* 4820 */         nsfw(), 
/* 4821 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 4824 */         ownerId(), 
/* 4825 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.roles, newValue, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4834 */         stickers());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildUpdateData withEmojis(Iterable<? extends EmojiData> elements) {
/* 4844 */     if (this.emojis == elements) return this; 
/* 4845 */     List<EmojiData> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/* 4846 */     return new ImmutableGuildUpdateData(this, 
/*      */         
/* 4848 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4853 */         owner(), 
/* 4854 */         permissions(), 
/* 4855 */         afkChannelId(), 
/* 4856 */         embedEnabled(), 
/* 4857 */         embedChannelId(), this.features, 
/*      */         
/* 4859 */         applicationId(), 
/* 4860 */         widgetEnabled(), 
/* 4861 */         widgetChannelId(), 
/* 4862 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 4864 */         rulesChannelId(), 
/* 4865 */         maxPresences(), 
/* 4866 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 4870 */         premiumSubscriptionCount(), 
/* 4871 */         publicUpdatesChannelId(), 
/* 4872 */         maxVideoChannelUsers(), 
/* 4873 */         approximateMemberCount(), 
/* 4874 */         approximatePresenceCount(), 
/* 4875 */         welcomeScreen(), 
/* 4876 */         nsfw(), 
/* 4877 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 4880 */         ownerId(), 
/* 4881 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.roles, newValue, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4890 */         stickers());
/*      */   }
/*      */   
/*      */   public ImmutableGuildUpdateData withStickers(Possible<List<StickerData>> possible) {
/* 4894 */     Possible<List<StickerData>> newValue = Objects.<Possible<List<StickerData>>>requireNonNull(possible);
/* 4895 */     return new ImmutableGuildUpdateData(this, 
/*      */         
/* 4897 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4902 */         owner(), 
/* 4903 */         permissions(), 
/* 4904 */         afkChannelId(), 
/* 4905 */         embedEnabled(), 
/* 4906 */         embedChannelId(), this.features, 
/*      */         
/* 4908 */         applicationId(), 
/* 4909 */         widgetEnabled(), 
/* 4910 */         widgetChannelId(), 
/* 4911 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 4913 */         rulesChannelId(), 
/* 4914 */         maxPresences(), 
/* 4915 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 4919 */         premiumSubscriptionCount(), 
/* 4920 */         publicUpdatesChannelId(), 
/* 4921 */         maxVideoChannelUsers(), 
/* 4922 */         approximateMemberCount(), 
/* 4923 */         approximatePresenceCount(), 
/* 4924 */         welcomeScreen(), 
/* 4925 */         nsfw(), 
/* 4926 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 4929 */         ownerId(), 
/* 4930 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.roles, this.emojis, newValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutableGuildUpdateData withStickers(Iterable<StickerData> elements) {
/* 4943 */     Possible<List<StickerData>> newValue = Possible.of(
/* 4944 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/* 4945 */     return new ImmutableGuildUpdateData(this, 
/*      */         
/* 4947 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4952 */         owner(), 
/* 4953 */         permissions(), 
/* 4954 */         afkChannelId(), 
/* 4955 */         embedEnabled(), 
/* 4956 */         embedChannelId(), this.features, 
/*      */         
/* 4958 */         applicationId(), 
/* 4959 */         widgetEnabled(), 
/* 4960 */         widgetChannelId(), 
/* 4961 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 4963 */         rulesChannelId(), 
/* 4964 */         maxPresences(), 
/* 4965 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 4969 */         premiumSubscriptionCount(), 
/* 4970 */         publicUpdatesChannelId(), 
/* 4971 */         maxVideoChannelUsers(), 
/* 4972 */         approximateMemberCount(), 
/* 4973 */         approximatePresenceCount(), 
/* 4974 */         welcomeScreen(), 
/* 4975 */         nsfw(), 
/* 4976 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 4979 */         ownerId(), 
/* 4980 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.roles, this.emojis, newValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @SafeVarargs
/*      */   public final ImmutableGuildUpdateData withStickers(StickerData... elements) {
/* 4994 */     Possible<List<StickerData>> newValue = Possible.of(Arrays.asList(elements));
/* 4995 */     return new ImmutableGuildUpdateData(this, 
/*      */         
/* 4997 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 5002 */         owner(), 
/* 5003 */         permissions(), 
/* 5004 */         afkChannelId(), 
/* 5005 */         embedEnabled(), 
/* 5006 */         embedChannelId(), this.features, 
/*      */         
/* 5008 */         applicationId(), 
/* 5009 */         widgetEnabled(), 
/* 5010 */         widgetChannelId(), 
/* 5011 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 5013 */         rulesChannelId(), 
/* 5014 */         maxPresences(), 
/* 5015 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 5019 */         premiumSubscriptionCount(), 
/* 5020 */         publicUpdatesChannelId(), 
/* 5021 */         maxVideoChannelUsers(), 
/* 5022 */         approximateMemberCount(), 
/* 5023 */         approximatePresenceCount(), 
/* 5024 */         welcomeScreen(), 
/* 5025 */         nsfw(), 
/* 5026 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */         
/* 5029 */         ownerId(), 
/* 5030 */         region(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, this.roles, this.emojis, newValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean equals(Object another) {
/* 5048 */     if (this == another) return true; 
/* 5049 */     return (another instanceof ImmutableGuildUpdateData && 
/* 5050 */       equalTo(0, (ImmutableGuildUpdateData)another));
/*      */   }
/*      */   
/*      */   private boolean equalTo(int synthetic, ImmutableGuildUpdateData another) {
/* 5054 */     return (Objects.equals(Long.valueOf(this.id_value), Long.valueOf(another.id_value)) && this.name
/* 5055 */       .equals(another.name) && 
/* 5056 */       Objects.equals(this.icon, another.icon) && 
/* 5057 */       Objects.equals(this.splash, another.splash) && 
/* 5058 */       Objects.equals(this.discoverySplash, another.discoverySplash) && 
/* 5059 */       owner().equals(another.owner()) && 
/* 5060 */       permissions().equals(another.permissions()) && 
/* 5061 */       afkChannelId().equals(another.afkChannelId()) && 
/* 5062 */       embedEnabled().equals(another.embedEnabled()) && 
/* 5063 */       embedChannelId().equals(another.embedChannelId()) && this.features
/* 5064 */       .equals(another.features) && 
/* 5065 */       applicationId().equals(another.applicationId()) && 
/* 5066 */       widgetEnabled().equals(another.widgetEnabled()) && 
/* 5067 */       widgetChannelId().equals(another.widgetChannelId()) && 
/* 5068 */       systemChannelId().equals(another.systemChannelId()) && 
/* 5069 */       Objects.equals(this.systemChannelFlags, another.systemChannelFlags) && 
/* 5070 */       rulesChannelId().equals(another.rulesChannelId()) && 
/* 5071 */       maxPresences().equals(another.maxPresences()) && 
/* 5072 */       maxMembers().equals(another.maxMembers()) && 
/* 5073 */       Objects.equals(this.vanityUrlCode, another.vanityUrlCode) && 
/* 5074 */       Objects.equals(this.description, another.description) && 
/* 5075 */       Objects.equals(this.banner, another.banner) && 
/* 5076 */       premiumSubscriptionCount().equals(another.premiumSubscriptionCount()) && 
/* 5077 */       publicUpdatesChannelId().equals(another.publicUpdatesChannelId()) && 
/* 5078 */       maxVideoChannelUsers().equals(another.maxVideoChannelUsers()) && 
/* 5079 */       approximateMemberCount().equals(another.approximateMemberCount()) && 
/* 5080 */       approximatePresenceCount().equals(another.approximatePresenceCount()) && 
/* 5081 */       welcomeScreen().equals(another.welcomeScreen()) && 
/* 5082 */       nsfw().equals(another.nsfw()) && 
/* 5083 */       safetyAlertsChannelId().equals(another.safetyAlertsChannelId()) && this.verificationLevel == another.verificationLevel && this.nsfwLevel == another.nsfwLevel && 
/*      */ 
/*      */       
/* 5086 */       Objects.equals(Long.valueOf(this.ownerId_value), Long.valueOf(another.ownerId_value)) && 
/* 5087 */       region().equals(another.region()) && this.afkTimeout == another.afkTimeout && this.defaultMessageNotifications == another.defaultMessageNotifications && this.explicitContentFilter == another.explicitContentFilter && this.mfaLevel == another.mfaLevel && this.premiumTier == another.premiumTier && this.preferredLocale
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 5093 */       .equals(another.preferredLocale) && this.roles
/* 5094 */       .equals(another.roles) && this.emojis
/* 5095 */       .equals(another.emojis) && 
/* 5096 */       Objects.equals(this.stickers_value, another.stickers_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int hashCode() {
/* 5105 */     int h = 5381;
/* 5106 */     h += (h << 5) + Objects.hashCode(Long.valueOf(this.id_value));
/* 5107 */     h += (h << 5) + this.name.hashCode();
/* 5108 */     h += (h << 5) + Objects.hashCode(this.icon);
/* 5109 */     h += (h << 5) + Objects.hashCode(this.splash);
/* 5110 */     h += (h << 5) + Objects.hashCode(this.discoverySplash);
/* 5111 */     h += (h << 5) + owner().hashCode();
/* 5112 */     h += (h << 5) + permissions().hashCode();
/* 5113 */     h += (h << 5) + afkChannelId().hashCode();
/* 5114 */     h += (h << 5) + embedEnabled().hashCode();
/* 5115 */     h += (h << 5) + embedChannelId().hashCode();
/* 5116 */     h += (h << 5) + this.features.hashCode();
/* 5117 */     h += (h << 5) + applicationId().hashCode();
/* 5118 */     h += (h << 5) + widgetEnabled().hashCode();
/* 5119 */     h += (h << 5) + widgetChannelId().hashCode();
/* 5120 */     h += (h << 5) + systemChannelId().hashCode();
/* 5121 */     h += (h << 5) + Objects.hashCode(this.systemChannelFlags);
/* 5122 */     h += (h << 5) + rulesChannelId().hashCode();
/* 5123 */     h += (h << 5) + maxPresences().hashCode();
/* 5124 */     h += (h << 5) + maxMembers().hashCode();
/* 5125 */     h += (h << 5) + Objects.hashCode(this.vanityUrlCode);
/* 5126 */     h += (h << 5) + Objects.hashCode(this.description);
/* 5127 */     h += (h << 5) + Objects.hashCode(this.banner);
/* 5128 */     h += (h << 5) + premiumSubscriptionCount().hashCode();
/* 5129 */     h += (h << 5) + publicUpdatesChannelId().hashCode();
/* 5130 */     h += (h << 5) + maxVideoChannelUsers().hashCode();
/* 5131 */     h += (h << 5) + approximateMemberCount().hashCode();
/* 5132 */     h += (h << 5) + approximatePresenceCount().hashCode();
/* 5133 */     h += (h << 5) + welcomeScreen().hashCode();
/* 5134 */     h += (h << 5) + nsfw().hashCode();
/* 5135 */     h += (h << 5) + safetyAlertsChannelId().hashCode();
/* 5136 */     h += (h << 5) + this.verificationLevel;
/* 5137 */     h += (h << 5) + this.nsfwLevel;
/* 5138 */     h += (h << 5) + Objects.hashCode(Long.valueOf(this.ownerId_value));
/* 5139 */     h += (h << 5) + region().hashCode();
/* 5140 */     h += (h << 5) + this.afkTimeout;
/* 5141 */     h += (h << 5) + this.defaultMessageNotifications;
/* 5142 */     h += (h << 5) + this.explicitContentFilter;
/* 5143 */     h += (h << 5) + this.mfaLevel;
/* 5144 */     h += (h << 5) + this.premiumTier;
/* 5145 */     h += (h << 5) + this.preferredLocale.hashCode();
/* 5146 */     h += (h << 5) + this.roles.hashCode();
/* 5147 */     h += (h << 5) + this.emojis.hashCode();
/* 5148 */     h += (h << 5) + Objects.hashCode(this.stickers_value);
/* 5149 */     return h;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/* 5158 */     StringBuilder builder = new StringBuilder("GuildUpdateData{");
/* 5159 */     builder.append("id=").append(Objects.toString(Long.valueOf(this.id_value)));
/* 5160 */     builder.append(", ");
/* 5161 */     builder.append("name=").append(this.name);
/* 5162 */     if (this.icon != null) {
/* 5163 */       builder.append(", ");
/* 5164 */       builder.append("icon=").append(this.icon);
/*      */     } 
/* 5166 */     if (this.splash != null) {
/* 5167 */       builder.append(", ");
/* 5168 */       builder.append("splash=").append(this.splash);
/*      */     } 
/* 5170 */     if (this.discoverySplash != null) {
/* 5171 */       builder.append(", ");
/* 5172 */       builder.append("discoverySplash=").append(this.discoverySplash);
/*      */     } 
/* 5174 */     builder.append(", ");
/* 5175 */     builder.append("owner=").append(owner().toString());
/* 5176 */     builder.append(", ");
/* 5177 */     builder.append("permissions=").append(permissions().toString());
/* 5178 */     builder.append(", ");
/* 5179 */     builder.append("afkChannelId=").append(afkChannelId().toString());
/* 5180 */     builder.append(", ");
/* 5181 */     builder.append("embedEnabled=").append(embedEnabled().toString());
/* 5182 */     builder.append(", ");
/* 5183 */     builder.append("embedChannelId=").append(embedChannelId().toString());
/* 5184 */     builder.append(", ");
/* 5185 */     builder.append("features=").append(this.features);
/* 5186 */     builder.append(", ");
/* 5187 */     builder.append("applicationId=").append(applicationId().toString());
/* 5188 */     builder.append(", ");
/* 5189 */     builder.append("widgetEnabled=").append(widgetEnabled().toString());
/* 5190 */     builder.append(", ");
/* 5191 */     builder.append("widgetChannelId=").append(widgetChannelId().toString());
/* 5192 */     builder.append(", ");
/* 5193 */     builder.append("systemChannelId=").append(systemChannelId().toString());
/* 5194 */     if (this.systemChannelFlags != null) {
/* 5195 */       builder.append(", ");
/* 5196 */       builder.append("systemChannelFlags=").append(this.systemChannelFlags);
/*      */     } 
/* 5198 */     builder.append(", ");
/* 5199 */     builder.append("rulesChannelId=").append(rulesChannelId().toString());
/* 5200 */     builder.append(", ");
/* 5201 */     builder.append("maxPresences=").append(maxPresences().toString());
/* 5202 */     builder.append(", ");
/* 5203 */     builder.append("maxMembers=").append(maxMembers().toString());
/* 5204 */     if (this.vanityUrlCode != null) {
/* 5205 */       builder.append(", ");
/* 5206 */       builder.append("vanityUrlCode=").append(this.vanityUrlCode);
/*      */     } 
/* 5208 */     if (this.description != null) {
/* 5209 */       builder.append(", ");
/* 5210 */       builder.append("description=").append(this.description);
/*      */     } 
/* 5212 */     if (this.banner != null) {
/* 5213 */       builder.append(", ");
/* 5214 */       builder.append("banner=").append(this.banner);
/*      */     } 
/* 5216 */     builder.append(", ");
/* 5217 */     builder.append("premiumSubscriptionCount=").append(premiumSubscriptionCount().toString());
/* 5218 */     builder.append(", ");
/* 5219 */     builder.append("publicUpdatesChannelId=").append(publicUpdatesChannelId().toString());
/* 5220 */     builder.append(", ");
/* 5221 */     builder.append("maxVideoChannelUsers=").append(maxVideoChannelUsers().toString());
/* 5222 */     builder.append(", ");
/* 5223 */     builder.append("approximateMemberCount=").append(approximateMemberCount().toString());
/* 5224 */     builder.append(", ");
/* 5225 */     builder.append("approximatePresenceCount=").append(approximatePresenceCount().toString());
/* 5226 */     builder.append(", ");
/* 5227 */     builder.append("welcomeScreen=").append(welcomeScreen().toString());
/* 5228 */     builder.append(", ");
/* 5229 */     builder.append("nsfw=").append(nsfw().toString());
/* 5230 */     builder.append(", ");
/* 5231 */     builder.append("safetyAlertsChannelId=").append(safetyAlertsChannelId().toString());
/* 5232 */     builder.append(", ");
/* 5233 */     builder.append("verificationLevel=").append(this.verificationLevel);
/* 5234 */     builder.append(", ");
/* 5235 */     builder.append("nsfwLevel=").append(this.nsfwLevel);
/* 5236 */     builder.append(", ");
/* 5237 */     builder.append("ownerId=").append(Objects.toString(Long.valueOf(this.ownerId_value)));
/* 5238 */     builder.append(", ");
/* 5239 */     builder.append("region=").append(region().toString());
/* 5240 */     builder.append(", ");
/* 5241 */     builder.append("afkTimeout=").append(this.afkTimeout);
/* 5242 */     builder.append(", ");
/* 5243 */     builder.append("defaultMessageNotifications=").append(this.defaultMessageNotifications);
/* 5244 */     builder.append(", ");
/* 5245 */     builder.append("explicitContentFilter=").append(this.explicitContentFilter);
/* 5246 */     builder.append(", ");
/* 5247 */     builder.append("mfaLevel=").append(this.mfaLevel);
/* 5248 */     builder.append(", ");
/* 5249 */     builder.append("premiumTier=").append(this.premiumTier);
/* 5250 */     builder.append(", ");
/* 5251 */     builder.append("preferredLocale=").append(this.preferredLocale);
/* 5252 */     builder.append(", ");
/* 5253 */     builder.append("roles=").append(this.roles);
/* 5254 */     builder.append(", ");
/* 5255 */     builder.append("emojis=").append(this.emojis);
/* 5256 */     builder.append(", ");
/* 5257 */     builder.append("stickers=").append(Objects.toString(this.stickers_value));
/* 5258 */     return builder.append("}").toString();
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonDeserialize
/*      */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*      */   @Generated(from = "GuildUpdateData", generator = "Immutables")
/*      */   static final class Json
/*      */     implements GuildUpdateData
/*      */   {
/*      */     Id id;
/*      */     
/*      */     String name;
/* 5272 */     Optional<String> icon = Optional.empty();
/* 5273 */     Optional<String> splash = Optional.empty();
/* 5274 */     Optional<String> discoverySplash = Optional.empty();
/*      */     
/* 5276 */     Possible<Boolean> owner = Possible.absent();
/*      */ 
/*      */     
/* 5279 */     Possible<Long> permissions = Possible.absent();
/*      */ 
/*      */     
/* 5282 */     Optional<Id> afkChannelId = Optional.empty();
/*      */ 
/*      */     
/* 5285 */     Possible<Boolean> embedEnabled = Possible.absent();
/*      */ 
/*      */     
/* 5288 */     Possible<Optional<Id>> embedChannelId = Possible.absent();
/*      */     
/* 5290 */     List<String> features = Collections.emptyList();
/*      */     
/* 5292 */     Optional<Id> applicationId = Optional.empty();
/*      */ 
/*      */     
/* 5295 */     Possible<Boolean> widgetEnabled = Possible.absent();
/*      */ 
/*      */     
/* 5298 */     Possible<Optional<Id>> widgetChannelId = Possible.absent();
/*      */ 
/*      */     
/* 5301 */     Optional<Id> systemChannelId = Optional.empty();
/*      */     
/* 5303 */     OptionalInt systemChannelFlags = OptionalInt.empty();
/*      */     
/* 5305 */     Optional<Id> rulesChannelId = Optional.empty();
/*      */ 
/*      */     
/* 5308 */     Possible<Optional<Integer>> maxPresences = Possible.absent();
/*      */ 
/*      */     
/* 5311 */     Possible<Integer> maxMembers = Possible.absent();
/*      */     
/* 5313 */     Optional<String> vanityUrlCode = Optional.empty();
/* 5314 */     Optional<String> description = Optional.empty();
/* 5315 */     Optional<String> banner = Optional.empty();
/*      */     
/* 5317 */     Possible<Integer> premiumSubscriptionCount = Possible.absent();
/*      */ 
/*      */     
/* 5320 */     Optional<Id> publicUpdatesChannelId = Optional.empty();
/*      */ 
/*      */     
/* 5323 */     Possible<Integer> maxVideoChannelUsers = Possible.absent();
/*      */ 
/*      */     
/* 5326 */     Possible<Integer> approximateMemberCount = Possible.absent();
/*      */ 
/*      */     
/* 5329 */     Possible<Integer> approximatePresenceCount = Possible.absent();
/*      */ 
/*      */     
/* 5332 */     Possible<WelcomeScreenData> welcomeScreen = Possible.absent();
/*      */ 
/*      */     
/* 5335 */     Possible<Boolean> nsfw = Possible.absent();
/*      */ 
/*      */     
/* 5338 */     Optional<Id> safetyAlertsChannelId = Optional.empty();
/*      */     
/*      */     int verificationLevel;
/*      */     
/*      */     boolean verificationLevelIsSet;
/*      */     int nsfwLevel;
/*      */     boolean nsfwLevelIsSet;
/*      */     Id ownerId;
/* 5346 */     Possible<Optional<String>> region = Possible.absent();
/*      */     
/*      */     int afkTimeout;
/*      */     boolean afkTimeoutIsSet;
/*      */     int defaultMessageNotifications;
/*      */     boolean defaultMessageNotificationsIsSet;
/*      */     int explicitContentFilter;
/*      */     boolean explicitContentFilterIsSet;
/*      */     int mfaLevel;
/*      */     boolean mfaLevelIsSet;
/*      */     int premiumTier;
/*      */     boolean premiumTierIsSet;
/*      */     String preferredLocale;
/* 5359 */     List<RoleData> roles = Collections.emptyList();
/* 5360 */     List<EmojiData> emojis = Collections.emptyList();
/*      */     
/* 5362 */     Possible<List<StickerData>> stickers = Possible.absent();
/*      */     
/*      */     @JsonProperty("id")
/*      */     public void setId(Id id) {
/* 5366 */       this.id = id;
/*      */     }
/*      */     @JsonProperty("name")
/*      */     public void setName(String name) {
/* 5370 */       this.name = name;
/*      */     }
/*      */     @JsonProperty("icon")
/*      */     public void setIcon(Optional<String> icon) {
/* 5374 */       this.icon = icon;
/*      */     }
/*      */     @JsonProperty("splash")
/*      */     public void setSplash(Optional<String> splash) {
/* 5378 */       this.splash = splash;
/*      */     }
/*      */     @JsonProperty("discovery_splash")
/*      */     public void setDiscoverySplash(Optional<String> discoverySplash) {
/* 5382 */       this.discoverySplash = discoverySplash;
/*      */     }
/*      */     @JsonProperty("owner")
/*      */     public void setOwner(Possible<Boolean> owner) {
/* 5386 */       this.owner = owner;
/*      */     }
/*      */     @JsonProperty("permissions")
/*      */     public void setPermissions(Possible<Long> permissions) {
/* 5390 */       this.permissions = permissions;
/*      */     }
/*      */     @JsonProperty("afk_channel_id")
/*      */     public void setAfkChannelId(Optional<Id> afkChannelId) {
/* 5394 */       this.afkChannelId = afkChannelId;
/*      */     }
/*      */     @JsonProperty("embed_enabled")
/*      */     public void setEmbedEnabled(Possible<Boolean> embedEnabled) {
/* 5398 */       this.embedEnabled = embedEnabled;
/*      */     }
/*      */     @JsonProperty("embed_channel_id")
/*      */     public void setEmbedChannelId(Possible<Optional<Id>> embedChannelId) {
/* 5402 */       this.embedChannelId = embedChannelId;
/*      */     }
/*      */     @JsonProperty("features")
/*      */     public void setFeatures(List<String> features) {
/* 5406 */       this.features = features;
/*      */     }
/*      */     @JsonProperty("application_id")
/*      */     public void setApplicationId(Optional<Id> applicationId) {
/* 5410 */       this.applicationId = applicationId;
/*      */     }
/*      */     @JsonProperty("widget_enabled")
/*      */     public void setWidgetEnabled(Possible<Boolean> widgetEnabled) {
/* 5414 */       this.widgetEnabled = widgetEnabled;
/*      */     }
/*      */     @JsonProperty("widget_channel_id")
/*      */     public void setWidgetChannelId(Possible<Optional<Id>> widgetChannelId) {
/* 5418 */       this.widgetChannelId = widgetChannelId;
/*      */     }
/*      */     @JsonProperty("system_channel_id")
/*      */     public void setSystemChannelId(Optional<Id> systemChannelId) {
/* 5422 */       this.systemChannelId = systemChannelId;
/*      */     }
/*      */     @JsonProperty("system_channel_flags")
/*      */     public void setSystemChannelFlags(OptionalInt systemChannelFlags) {
/* 5426 */       this.systemChannelFlags = systemChannelFlags;
/*      */     }
/*      */     @JsonProperty("rules_channel_id")
/*      */     public void setRulesChannelId(Optional<Id> rulesChannelId) {
/* 5430 */       this.rulesChannelId = rulesChannelId;
/*      */     }
/*      */     @JsonProperty("max_presences")
/*      */     public void setMaxPresences(Possible<Optional<Integer>> maxPresences) {
/* 5434 */       this.maxPresences = maxPresences;
/*      */     }
/*      */     @JsonProperty("max_members")
/*      */     public void setMaxMembers(Possible<Integer> maxMembers) {
/* 5438 */       this.maxMembers = maxMembers;
/*      */     }
/*      */     @JsonProperty("vanity_url_code")
/*      */     public void setVanityUrlCode(Optional<String> vanityUrlCode) {
/* 5442 */       this.vanityUrlCode = vanityUrlCode;
/*      */     }
/*      */     @JsonProperty("description")
/*      */     public void setDescription(Optional<String> description) {
/* 5446 */       this.description = description;
/*      */     }
/*      */     @JsonProperty("banner")
/*      */     public void setBanner(Optional<String> banner) {
/* 5450 */       this.banner = banner;
/*      */     }
/*      */     @JsonProperty("premium_subscription_count")
/*      */     public void setPremiumSubscriptionCount(Possible<Integer> premiumSubscriptionCount) {
/* 5454 */       this.premiumSubscriptionCount = premiumSubscriptionCount;
/*      */     }
/*      */     @JsonProperty("public_updates_channel_id")
/*      */     public void setPublicUpdatesChannelId(Optional<Id> publicUpdatesChannelId) {
/* 5458 */       this.publicUpdatesChannelId = publicUpdatesChannelId;
/*      */     }
/*      */     @JsonProperty("max_video_channel_users")
/*      */     public void setMaxVideoChannelUsers(Possible<Integer> maxVideoChannelUsers) {
/* 5462 */       this.maxVideoChannelUsers = maxVideoChannelUsers;
/*      */     }
/*      */     @JsonProperty("approximate_member_count")
/*      */     public void setApproximateMemberCount(Possible<Integer> approximateMemberCount) {
/* 5466 */       this.approximateMemberCount = approximateMemberCount;
/*      */     }
/*      */     @JsonProperty("approximate_presence_count")
/*      */     public void setApproximatePresenceCount(Possible<Integer> approximatePresenceCount) {
/* 5470 */       this.approximatePresenceCount = approximatePresenceCount;
/*      */     }
/*      */     @JsonProperty("welcome_screen")
/*      */     public void setWelcomeScreen(Possible<WelcomeScreenData> welcomeScreen) {
/* 5474 */       this.welcomeScreen = welcomeScreen;
/*      */     }
/*      */     @JsonProperty("nsfw")
/*      */     public void setNsfw(Possible<Boolean> nsfw) {
/* 5478 */       this.nsfw = nsfw;
/*      */     }
/*      */     @JsonProperty("safety_alerts_channel_id")
/*      */     public void setSafetyAlertsChannelId(Optional<Id> safetyAlertsChannelId) {
/* 5482 */       this.safetyAlertsChannelId = safetyAlertsChannelId;
/*      */     }
/*      */     @JsonProperty("verification_level")
/*      */     public void setVerificationLevel(int verificationLevel) {
/* 5486 */       this.verificationLevel = verificationLevel;
/* 5487 */       this.verificationLevelIsSet = true;
/*      */     }
/*      */     @JsonProperty("nsfw_level")
/*      */     public void setNsfwLevel(int nsfwLevel) {
/* 5491 */       this.nsfwLevel = nsfwLevel;
/* 5492 */       this.nsfwLevelIsSet = true;
/*      */     }
/*      */     @JsonProperty("owner_id")
/*      */     public void setOwnerId(Id ownerId) {
/* 5496 */       this.ownerId = ownerId;
/*      */     }
/*      */     @JsonProperty("region")
/*      */     public void setRegion(Possible<Optional<String>> region) {
/* 5500 */       this.region = region;
/*      */     }
/*      */     @JsonProperty("afk_timeout")
/*      */     public void setAfkTimeout(int afkTimeout) {
/* 5504 */       this.afkTimeout = afkTimeout;
/* 5505 */       this.afkTimeoutIsSet = true;
/*      */     }
/*      */     @JsonProperty("default_message_notifications")
/*      */     public void setDefaultMessageNotifications(int defaultMessageNotifications) {
/* 5509 */       this.defaultMessageNotifications = defaultMessageNotifications;
/* 5510 */       this.defaultMessageNotificationsIsSet = true;
/*      */     }
/*      */     @JsonProperty("explicit_content_filter")
/*      */     public void setExplicitContentFilter(int explicitContentFilter) {
/* 5514 */       this.explicitContentFilter = explicitContentFilter;
/* 5515 */       this.explicitContentFilterIsSet = true;
/*      */     }
/*      */     @JsonProperty("mfa_level")
/*      */     public void setMfaLevel(int mfaLevel) {
/* 5519 */       this.mfaLevel = mfaLevel;
/* 5520 */       this.mfaLevelIsSet = true;
/*      */     }
/*      */     @JsonProperty("premium_tier")
/*      */     public void setPremiumTier(int premiumTier) {
/* 5524 */       this.premiumTier = premiumTier;
/* 5525 */       this.premiumTierIsSet = true;
/*      */     }
/*      */     @JsonProperty("preferred_locale")
/*      */     public void setPreferredLocale(String preferredLocale) {
/* 5529 */       this.preferredLocale = preferredLocale;
/*      */     }
/*      */     @JsonProperty("roles")
/*      */     public void setRoles(List<RoleData> roles) {
/* 5533 */       this.roles = roles;
/*      */     }
/*      */     @JsonProperty("emojis")
/*      */     public void setEmojis(List<EmojiData> emojis) {
/* 5537 */       this.emojis = emojis;
/*      */     }
/*      */     @JsonProperty("stickers")
/*      */     public void setStickers(Possible<List<StickerData>> stickers) {
/* 5541 */       this.stickers = stickers;
/*      */     }
/*      */     public Id id() {
/* 5544 */       throw new UnsupportedOperationException();
/*      */     } public String name() {
/* 5546 */       throw new UnsupportedOperationException();
/*      */     } public Optional<String> icon() {
/* 5548 */       throw new UnsupportedOperationException();
/*      */     } public Optional<String> splash() {
/* 5550 */       throw new UnsupportedOperationException();
/*      */     } public Optional<String> discoverySplash() {
/* 5552 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Boolean> owner() {
/* 5554 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Long> permissions() {
/* 5556 */       throw new UnsupportedOperationException();
/*      */     } public Optional<Id> afkChannelId() {
/* 5558 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Boolean> embedEnabled() {
/* 5560 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Optional<Id>> embedChannelId() {
/* 5562 */       throw new UnsupportedOperationException();
/*      */     } public List<String> features() {
/* 5564 */       throw new UnsupportedOperationException();
/*      */     } public Optional<Id> applicationId() {
/* 5566 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Boolean> widgetEnabled() {
/* 5568 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Optional<Id>> widgetChannelId() {
/* 5570 */       throw new UnsupportedOperationException();
/*      */     } public Optional<Id> systemChannelId() {
/* 5572 */       throw new UnsupportedOperationException();
/*      */     } public OptionalInt systemChannelFlags() {
/* 5574 */       throw new UnsupportedOperationException();
/*      */     } public Optional<Id> rulesChannelId() {
/* 5576 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Optional<Integer>> maxPresences() {
/* 5578 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Integer> maxMembers() {
/* 5580 */       throw new UnsupportedOperationException();
/*      */     } public Optional<String> vanityUrlCode() {
/* 5582 */       throw new UnsupportedOperationException();
/*      */     } public Optional<String> description() {
/* 5584 */       throw new UnsupportedOperationException();
/*      */     } public Optional<String> banner() {
/* 5586 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Integer> premiumSubscriptionCount() {
/* 5588 */       throw new UnsupportedOperationException();
/*      */     } public Optional<Id> publicUpdatesChannelId() {
/* 5590 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Integer> maxVideoChannelUsers() {
/* 5592 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Integer> approximateMemberCount() {
/* 5594 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Integer> approximatePresenceCount() {
/* 5596 */       throw new UnsupportedOperationException();
/*      */     } public Possible<WelcomeScreenData> welcomeScreen() {
/* 5598 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Boolean> nsfw() {
/* 5600 */       throw new UnsupportedOperationException();
/*      */     } public Optional<Id> safetyAlertsChannelId() {
/* 5602 */       throw new UnsupportedOperationException();
/*      */     } public int verificationLevel() {
/* 5604 */       throw new UnsupportedOperationException();
/*      */     } public int nsfwLevel() {
/* 5606 */       throw new UnsupportedOperationException();
/*      */     } public Id ownerId() {
/* 5608 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Optional<String>> region() {
/* 5610 */       throw new UnsupportedOperationException();
/*      */     } public int afkTimeout() {
/* 5612 */       throw new UnsupportedOperationException();
/*      */     } public int defaultMessageNotifications() {
/* 5614 */       throw new UnsupportedOperationException();
/*      */     } public int explicitContentFilter() {
/* 5616 */       throw new UnsupportedOperationException();
/*      */     } public int mfaLevel() {
/* 5618 */       throw new UnsupportedOperationException();
/*      */     } public int premiumTier() {
/* 5620 */       throw new UnsupportedOperationException();
/*      */     } public String preferredLocale() {
/* 5622 */       throw new UnsupportedOperationException();
/*      */     } public List<RoleData> roles() {
/* 5624 */       throw new UnsupportedOperationException();
/*      */     } public List<EmojiData> emojis() {
/* 5626 */       throw new UnsupportedOperationException();
/*      */     } public Possible<List<StickerData>> stickers() {
/* 5628 */       throw new UnsupportedOperationException();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*      */   static ImmutableGuildUpdateData fromJson(Json json) {
/* 5639 */     Builder builder = builder();
/* 5640 */     if (json.id != null) {
/* 5641 */       builder.id(json.id);
/*      */     }
/* 5643 */     if (json.name != null) {
/* 5644 */       builder.name(json.name);
/*      */     }
/* 5646 */     if (json.icon != null) {
/* 5647 */       builder.icon(json.icon);
/*      */     }
/* 5649 */     if (json.splash != null) {
/* 5650 */       builder.splash(json.splash);
/*      */     }
/* 5652 */     if (json.discoverySplash != null) {
/* 5653 */       builder.discoverySplash(json.discoverySplash);
/*      */     }
/* 5655 */     if (json.owner != null) {
/* 5656 */       builder.owner(json.owner);
/*      */     }
/* 5658 */     if (json.permissions != null) {
/* 5659 */       builder.permissions(json.permissions);
/*      */     }
/* 5661 */     if (json.afkChannelId != null) {
/* 5662 */       builder.afkChannelId(json.afkChannelId);
/*      */     }
/* 5664 */     if (json.embedEnabled != null) {
/* 5665 */       builder.embedEnabled(json.embedEnabled);
/*      */     }
/* 5667 */     if (json.embedChannelId != null) {
/* 5668 */       builder.embedChannelId(json.embedChannelId);
/*      */     }
/* 5670 */     if (json.features != null) {
/* 5671 */       builder.addAllFeatures(json.features);
/*      */     }
/* 5673 */     if (json.applicationId != null) {
/* 5674 */       builder.applicationId(json.applicationId);
/*      */     }
/* 5676 */     if (json.widgetEnabled != null) {
/* 5677 */       builder.widgetEnabled(json.widgetEnabled);
/*      */     }
/* 5679 */     if (json.widgetChannelId != null) {
/* 5680 */       builder.widgetChannelId(json.widgetChannelId);
/*      */     }
/* 5682 */     if (json.systemChannelId != null) {
/* 5683 */       builder.systemChannelId(json.systemChannelId);
/*      */     }
/* 5685 */     if (json.systemChannelFlags != null) {
/* 5686 */       builder.systemChannelFlags(json.systemChannelFlags);
/*      */     }
/* 5688 */     if (json.rulesChannelId != null) {
/* 5689 */       builder.rulesChannelId(json.rulesChannelId);
/*      */     }
/* 5691 */     if (json.maxPresences != null) {
/* 5692 */       builder.maxPresences(json.maxPresences);
/*      */     }
/* 5694 */     if (json.maxMembers != null) {
/* 5695 */       builder.maxMembers(json.maxMembers);
/*      */     }
/* 5697 */     if (json.vanityUrlCode != null) {
/* 5698 */       builder.vanityUrlCode(json.vanityUrlCode);
/*      */     }
/* 5700 */     if (json.description != null) {
/* 5701 */       builder.description(json.description);
/*      */     }
/* 5703 */     if (json.banner != null) {
/* 5704 */       builder.banner(json.banner);
/*      */     }
/* 5706 */     if (json.premiumSubscriptionCount != null) {
/* 5707 */       builder.premiumSubscriptionCount(json.premiumSubscriptionCount);
/*      */     }
/* 5709 */     if (json.publicUpdatesChannelId != null) {
/* 5710 */       builder.publicUpdatesChannelId(json.publicUpdatesChannelId);
/*      */     }
/* 5712 */     if (json.maxVideoChannelUsers != null) {
/* 5713 */       builder.maxVideoChannelUsers(json.maxVideoChannelUsers);
/*      */     }
/* 5715 */     if (json.approximateMemberCount != null) {
/* 5716 */       builder.approximateMemberCount(json.approximateMemberCount);
/*      */     }
/* 5718 */     if (json.approximatePresenceCount != null) {
/* 5719 */       builder.approximatePresenceCount(json.approximatePresenceCount);
/*      */     }
/* 5721 */     if (json.welcomeScreen != null) {
/* 5722 */       builder.welcomeScreen(json.welcomeScreen);
/*      */     }
/* 5724 */     if (json.nsfw != null) {
/* 5725 */       builder.nsfw(json.nsfw);
/*      */     }
/* 5727 */     if (json.safetyAlertsChannelId != null) {
/* 5728 */       builder.safetyAlertsChannelId(json.safetyAlertsChannelId);
/*      */     }
/* 5730 */     if (json.verificationLevelIsSet) {
/* 5731 */       builder.verificationLevel(json.verificationLevel);
/*      */     }
/* 5733 */     if (json.nsfwLevelIsSet) {
/* 5734 */       builder.nsfwLevel(json.nsfwLevel);
/*      */     }
/* 5736 */     if (json.ownerId != null) {
/* 5737 */       builder.ownerId(json.ownerId);
/*      */     }
/* 5739 */     if (json.region != null) {
/* 5740 */       builder.region(json.region);
/*      */     }
/* 5742 */     if (json.afkTimeoutIsSet) {
/* 5743 */       builder.afkTimeout(json.afkTimeout);
/*      */     }
/* 5745 */     if (json.defaultMessageNotificationsIsSet) {
/* 5746 */       builder.defaultMessageNotifications(json.defaultMessageNotifications);
/*      */     }
/* 5748 */     if (json.explicitContentFilterIsSet) {
/* 5749 */       builder.explicitContentFilter(json.explicitContentFilter);
/*      */     }
/* 5751 */     if (json.mfaLevelIsSet) {
/* 5752 */       builder.mfaLevel(json.mfaLevel);
/*      */     }
/* 5754 */     if (json.premiumTierIsSet) {
/* 5755 */       builder.premiumTier(json.premiumTier);
/*      */     }
/* 5757 */     if (json.preferredLocale != null) {
/* 5758 */       builder.preferredLocale(json.preferredLocale);
/*      */     }
/* 5760 */     if (json.roles != null) {
/* 5761 */       builder.addAllRoles(json.roles);
/*      */     }
/* 5763 */     if (json.emojis != null) {
/* 5764 */       builder.addAllEmojis(json.emojis);
/*      */     }
/* 5766 */     if (json.stickers != null) {
/* 5767 */       builder.stickers(json.stickers);
/*      */     }
/* 5769 */     return builder.build();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableGuildUpdateData of(Id id, String name, Optional<String> icon, Optional<String> splash, Optional<String> discoverySplash, Possible<Boolean> owner, Possible<Long> permissions, Optional<Id> afkChannelId, Possible<Boolean> embedEnabled, Possible<Optional<Id>> embedChannelId, List<String> features, Optional<Id> applicationId, Possible<Boolean> widgetEnabled, Possible<Optional<Id>> widgetChannelId, Optional<Id> systemChannelId, OptionalInt systemChannelFlags, Optional<Id> rulesChannelId, Possible<Optional<Integer>> maxPresences, Possible<Integer> maxMembers, Optional<String> vanityUrlCode, Optional<String> description, Optional<String> banner, Possible<Integer> premiumSubscriptionCount, Optional<Id> publicUpdatesChannelId, Possible<Integer> maxVideoChannelUsers, Possible<Integer> approximateMemberCount, Possible<Integer> approximatePresenceCount, Possible<WelcomeScreenData> welcomeScreen, Possible<Boolean> nsfw, Optional<Id> safetyAlertsChannelId, int verificationLevel, int nsfwLevel, Id ownerId, Possible<Optional<String>> region, int afkTimeout, int defaultMessageNotifications, int explicitContentFilter, int mfaLevel, int premiumTier, String preferredLocale, List<RoleData> roles, List<EmojiData> emojis, Possible<List<StickerData>> stickers) {
/* 5820 */     return of(id, name, icon, splash, discoverySplash, owner, permissions, afkChannelId, embedEnabled, embedChannelId, features, applicationId, widgetEnabled, widgetChannelId, systemChannelId, systemChannelFlags, rulesChannelId, maxPresences, maxMembers, vanityUrlCode, description, banner, premiumSubscriptionCount, publicUpdatesChannelId, maxVideoChannelUsers, approximateMemberCount, approximatePresenceCount, welcomeScreen, nsfw, safetyAlertsChannelId, verificationLevel, nsfwLevel, ownerId, region, afkTimeout, defaultMessageNotifications, explicitContentFilter, mfaLevel, premiumTier, preferredLocale, roles, emojis, stickers);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableGuildUpdateData of(Id id, String name, Optional<String> icon, Optional<String> splash, Optional<String> discoverySplash, Possible<Boolean> owner, Possible<Long> permissions, Optional<Id> afkChannelId, Possible<Boolean> embedEnabled, Possible<Optional<Id>> embedChannelId, Iterable<String> features, Optional<Id> applicationId, Possible<Boolean> widgetEnabled, Possible<Optional<Id>> widgetChannelId, Optional<Id> systemChannelId, OptionalInt systemChannelFlags, Optional<Id> rulesChannelId, Possible<Optional<Integer>> maxPresences, Possible<Integer> maxMembers, Optional<String> vanityUrlCode, Optional<String> description, Optional<String> banner, Possible<Integer> premiumSubscriptionCount, Optional<Id> publicUpdatesChannelId, Possible<Integer> maxVideoChannelUsers, Possible<Integer> approximateMemberCount, Possible<Integer> approximatePresenceCount, Possible<WelcomeScreenData> welcomeScreen, Possible<Boolean> nsfw, Optional<Id> safetyAlertsChannelId, int verificationLevel, int nsfwLevel, Id ownerId, Possible<Optional<String>> region, int afkTimeout, int defaultMessageNotifications, int explicitContentFilter, int mfaLevel, int premiumTier, String preferredLocale, Iterable<? extends RoleData> roles, Iterable<? extends EmojiData> emojis, Possible<List<StickerData>> stickers) {
/* 5871 */     return new ImmutableGuildUpdateData(id, name, icon, splash, discoverySplash, owner, permissions, afkChannelId, embedEnabled, embedChannelId, features, applicationId, widgetEnabled, widgetChannelId, systemChannelId, systemChannelFlags, rulesChannelId, maxPresences, maxMembers, vanityUrlCode, description, banner, premiumSubscriptionCount, publicUpdatesChannelId, maxVideoChannelUsers, approximateMemberCount, approximatePresenceCount, welcomeScreen, nsfw, safetyAlertsChannelId, verificationLevel, nsfwLevel, ownerId, region, afkTimeout, defaultMessageNotifications, explicitContentFilter, mfaLevel, premiumTier, preferredLocale, roles, emojis, stickers);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableGuildUpdateData copyOf(GuildUpdateData instance) {
/* 5882 */     if (instance instanceof ImmutableGuildUpdateData) {
/* 5883 */       return (ImmutableGuildUpdateData)instance;
/*      */     }
/* 5885 */     return builder()
/* 5886 */       .from(instance)
/* 5887 */       .build();
/*      */   }
/*      */   
/*      */   public boolean isOwnerPresent() {
/* 5891 */     return !this.owner_absent;
/*      */   }
/*      */   
/*      */   public Boolean ownerOrElse(Boolean defaultValue) {
/* 5895 */     return !this.owner_absent ? this.owner_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isPermissionsPresent() {
/* 5899 */     return !this.permissions_absent;
/*      */   }
/*      */   
/*      */   public Long permissionsOrElse(Long defaultValue) {
/* 5903 */     return !this.permissions_absent ? this.permissions_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isAfkChannelIdPresent() {
/* 5907 */     return this.afkChannelId_present;
/*      */   }
/*      */   
/*      */   public long afkChannelIdOrElse(long defaultValue) {
/* 5911 */     return this.afkChannelId_present ? this.afkChannelId_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isEmbedEnabledPresent() {
/* 5915 */     return !this.embedEnabled_absent;
/*      */   }
/*      */   
/*      */   public Boolean embedEnabledOrElse(Boolean defaultValue) {
/* 5919 */     return !this.embedEnabled_absent ? this.embedEnabled_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isEmbedChannelIdPresent() {
/* 5923 */     return !this.embedChannelId_absent;
/*      */   }
/*      */   
/*      */   public long embedChannelIdOrElse(long defaultValue) {
/* 5927 */     return !this.embedChannelId_absent ? this.embedChannelId_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isApplicationIdPresent() {
/* 5931 */     return this.applicationId_present;
/*      */   }
/*      */   
/*      */   public long applicationIdOrElse(long defaultValue) {
/* 5935 */     return this.applicationId_present ? this.applicationId_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isWidgetEnabledPresent() {
/* 5939 */     return !this.widgetEnabled_absent;
/*      */   }
/*      */   
/*      */   public Boolean widgetEnabledOrElse(Boolean defaultValue) {
/* 5943 */     return !this.widgetEnabled_absent ? this.widgetEnabled_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isWidgetChannelIdPresent() {
/* 5947 */     return !this.widgetChannelId_absent;
/*      */   }
/*      */   
/*      */   public long widgetChannelIdOrElse(long defaultValue) {
/* 5951 */     return !this.widgetChannelId_absent ? this.widgetChannelId_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isSystemChannelIdPresent() {
/* 5955 */     return this.systemChannelId_present;
/*      */   }
/*      */   
/*      */   public long systemChannelIdOrElse(long defaultValue) {
/* 5959 */     return this.systemChannelId_present ? this.systemChannelId_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isRulesChannelIdPresent() {
/* 5963 */     return this.rulesChannelId_present;
/*      */   }
/*      */   
/*      */   public long rulesChannelIdOrElse(long defaultValue) {
/* 5967 */     return this.rulesChannelId_present ? this.rulesChannelId_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isMaxPresencesPresent() {
/* 5971 */     return !this.maxPresences_absent;
/*      */   }
/*      */   
/*      */   public Integer maxPresencesOrElse(Integer defaultValue) {
/* 5975 */     return !this.maxPresences_absent ? this.maxPresences_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isMaxMembersPresent() {
/* 5979 */     return !this.maxMembers_absent;
/*      */   }
/*      */   
/*      */   public Integer maxMembersOrElse(Integer defaultValue) {
/* 5983 */     return !this.maxMembers_absent ? this.maxMembers_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isPremiumSubscriptionCountPresent() {
/* 5987 */     return !this.premiumSubscriptionCount_absent;
/*      */   }
/*      */   
/*      */   public Integer premiumSubscriptionCountOrElse(Integer defaultValue) {
/* 5991 */     return !this.premiumSubscriptionCount_absent ? this.premiumSubscriptionCount_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isPublicUpdatesChannelIdPresent() {
/* 5995 */     return this.publicUpdatesChannelId_present;
/*      */   }
/*      */   
/*      */   public long publicUpdatesChannelIdOrElse(long defaultValue) {
/* 5999 */     return this.publicUpdatesChannelId_present ? this.publicUpdatesChannelId_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isMaxVideoChannelUsersPresent() {
/* 6003 */     return !this.maxVideoChannelUsers_absent;
/*      */   }
/*      */   
/*      */   public Integer maxVideoChannelUsersOrElse(Integer defaultValue) {
/* 6007 */     return !this.maxVideoChannelUsers_absent ? this.maxVideoChannelUsers_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isApproximateMemberCountPresent() {
/* 6011 */     return !this.approximateMemberCount_absent;
/*      */   }
/*      */   
/*      */   public Integer approximateMemberCountOrElse(Integer defaultValue) {
/* 6015 */     return !this.approximateMemberCount_absent ? this.approximateMemberCount_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isApproximatePresenceCountPresent() {
/* 6019 */     return !this.approximatePresenceCount_absent;
/*      */   }
/*      */   
/*      */   public Integer approximatePresenceCountOrElse(Integer defaultValue) {
/* 6023 */     return !this.approximatePresenceCount_absent ? this.approximatePresenceCount_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isWelcomeScreenPresent() {
/* 6027 */     return !this.welcomeScreen_absent;
/*      */   }
/*      */   
/*      */   public WelcomeScreenData welcomeScreenOrElse(WelcomeScreenData defaultValue) {
/* 6031 */     return !this.welcomeScreen_absent ? this.welcomeScreen_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isNsfwPresent() {
/* 6035 */     return !this.nsfw_absent;
/*      */   }
/*      */   
/*      */   public Boolean nsfwOrElse(Boolean defaultValue) {
/* 6039 */     return !this.nsfw_absent ? this.nsfw_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isSafetyAlertsChannelIdPresent() {
/* 6043 */     return this.safetyAlertsChannelId_present;
/*      */   }
/*      */   
/*      */   public long safetyAlertsChannelIdOrElse(long defaultValue) {
/* 6047 */     return this.safetyAlertsChannelId_present ? this.safetyAlertsChannelId_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isRegionPresent() {
/* 6051 */     return !this.region_absent;
/*      */   }
/*      */   
/*      */   public String regionOrElse(String defaultValue) {
/* 6055 */     return !this.region_absent ? this.region_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isStickersPresent() {
/* 6059 */     return !this.stickers_absent;
/*      */   }
/*      */   
/*      */   public List<StickerData> stickersOrElse(List<StickerData> defaultValue) {
/* 6063 */     return !this.stickers_absent ? this.stickers_value : defaultValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Builder builder() {
/* 6118 */     return new Builder();
/*      */   }
/*      */ 
/*      */   
/*      */   @Generated(from = "GuildUpdateData", generator = "Immutables")
/*      */   public static final class Builder
/*      */   {
/*      */     private static final long INIT_BIT_NAME = 1L;
/*      */     
/*      */     private static final long INIT_BIT_VERIFICATION_LEVEL = 2L;
/*      */     
/*      */     private static final long INIT_BIT_NSFW_LEVEL = 4L;
/*      */     
/*      */     private static final long INIT_BIT_AFK_TIMEOUT = 8L;
/*      */     
/*      */     private static final long INIT_BIT_DEFAULT_MESSAGE_NOTIFICATIONS = 16L;
/*      */     
/*      */     private static final long INIT_BIT_EXPLICIT_CONTENT_FILTER = 32L;
/*      */     private static final long INIT_BIT_MFA_LEVEL = 64L;
/*      */     private static final long INIT_BIT_PREMIUM_TIER = 128L;
/*      */     private static final long INIT_BIT_PREFERRED_LOCALE = 256L;
/* 6139 */     private long initBits = 511L;
/*      */     
/* 6141 */     private Id id_id = null;
/* 6142 */     private Possible<Boolean> owner_possible = Possible.absent();
/* 6143 */     private Possible<Long> permissions_possible = Possible.absent();
/* 6144 */     private Optional<Id> afkChannelId_optional = Optional.empty();
/* 6145 */     private Possible<Boolean> embedEnabled_possible = Possible.absent();
/* 6146 */     private Possible<Optional<Id>> embedChannelId_possible = Possible.absent();
/* 6147 */     private Optional<Id> applicationId_optional = Optional.empty();
/* 6148 */     private Possible<Boolean> widgetEnabled_possible = Possible.absent();
/* 6149 */     private Possible<Optional<Id>> widgetChannelId_possible = Possible.absent();
/* 6150 */     private Optional<Id> systemChannelId_optional = Optional.empty();
/* 6151 */     private Optional<Id> rulesChannelId_optional = Optional.empty();
/* 6152 */     private Possible<Optional<Integer>> maxPresences_possible = Possible.absent();
/* 6153 */     private Possible<Integer> maxMembers_possible = Possible.absent();
/* 6154 */     private Possible<Integer> premiumSubscriptionCount_possible = Possible.absent();
/* 6155 */     private Optional<Id> publicUpdatesChannelId_optional = Optional.empty();
/* 6156 */     private Possible<Integer> maxVideoChannelUsers_possible = Possible.absent();
/* 6157 */     private Possible<Integer> approximateMemberCount_possible = Possible.absent();
/* 6158 */     private Possible<Integer> approximatePresenceCount_possible = Possible.absent();
/* 6159 */     private Possible<WelcomeScreenData> welcomeScreen_possible = Possible.absent();
/* 6160 */     private Possible<Boolean> nsfw_possible = Possible.absent();
/* 6161 */     private Optional<Id> safetyAlertsChannelId_optional = Optional.empty();
/* 6162 */     private Id ownerId_id = null;
/* 6163 */     private Possible<Optional<String>> region_possible = Possible.absent();
/* 6164 */     private List<StickerData> stickers_list = null;
/*      */     private String name;
/*      */     private String icon;
/*      */     private String splash;
/*      */     private String discoverySplash;
/* 6169 */     private List<String> features = new ArrayList<>();
/*      */     private Integer systemChannelFlags;
/*      */     private String vanityUrlCode;
/*      */     private String description;
/*      */     private String banner;
/*      */     private int verificationLevel;
/*      */     private int nsfwLevel;
/*      */     private int afkTimeout;
/*      */     private int defaultMessageNotifications;
/*      */     private int explicitContentFilter;
/*      */     private int mfaLevel;
/*      */     private int premiumTier;
/*      */     private String preferredLocale;
/* 6182 */     private List<RoleData> roles = new ArrayList<>();
/* 6183 */     private List<EmojiData> emojis = new ArrayList<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder from(GuildFields instance) {
/* 6194 */       Objects.requireNonNull(instance, "instance");
/* 6195 */       from(instance);
/* 6196 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder from(GuildUpdateData instance) {
/* 6205 */       Objects.requireNonNull(instance, "instance");
/* 6206 */       from(instance);
/* 6207 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder from(GuildUpdateFields instance) {
/* 6216 */       Objects.requireNonNull(instance, "instance");
/* 6217 */       from(instance);
/* 6218 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder from(GuildNsfwLevelField instance) {
/* 6227 */       Objects.requireNonNull(instance, "instance");
/* 6228 */       from(instance);
/* 6229 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder from(GuildVerificationLevelField instance) {
/* 6238 */       Objects.requireNonNull(instance, "instance");
/* 6239 */       from(instance);
/* 6240 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder from(GuildRolesEmojisStickersFields instance) {
/* 6249 */       Objects.requireNonNull(instance, "instance");
/* 6250 */       from(instance);
/* 6251 */       return this;
/*      */     }
/*      */     
/*      */     private void from(Object object) {
/* 6255 */       long bits = 0L;
/* 6256 */       if (object instanceof GuildFields) {
/* 6257 */         GuildFields instance = (GuildFields)object;
/* 6258 */         if ((bits & 0x2L) == 0L) {
/* 6259 */           Optional<String> vanityUrlCodeOptional = instance.vanityUrlCode();
/* 6260 */           if (vanityUrlCodeOptional.isPresent()) {
/* 6261 */             vanityUrlCode(vanityUrlCodeOptional);
/*      */           }
/* 6263 */           bits |= 0x2L;
/*      */         } 
/* 6265 */         if ((bits & 0x20L) == 0L) {
/* 6266 */           Optional<String> iconOptional = instance.icon();
/* 6267 */           if (iconOptional.isPresent()) {
/* 6268 */             icon(iconOptional);
/*      */           }
/* 6270 */           bits |= 0x20L;
/*      */         } 
/* 6272 */         if ((bits & 0x80L) == 0L) {
/* 6273 */           Optional<String> descriptionOptional = instance.description();
/* 6274 */           if (descriptionOptional.isPresent()) {
/* 6275 */             description(descriptionOptional);
/*      */           }
/* 6277 */           bits |= 0x80L;
/*      */         } 
/* 6279 */         if ((bits & 0x100L) == 0L) {
/* 6280 */           afkChannelId(instance.afkChannelId());
/* 6281 */           bits |= 0x100L;
/*      */         } 
/* 6283 */         if ((bits & 0x400L) == 0L) {
/* 6284 */           addAllFeatures(instance.features());
/* 6285 */           bits |= 0x400L;
/*      */         } 
/* 6287 */         if ((bits & 0x800L) == 0L) {
/* 6288 */           maxMembers(instance.maxMembers());
/* 6289 */           bits |= 0x800L;
/*      */         } 
/* 6291 */         if ((bits & 0x1000L) == 0L) {
/* 6292 */           permissions(instance.permissions());
/* 6293 */           bits |= 0x1000L;
/*      */         } 
/* 6295 */         if ((bits & 0x2000L) == 0L) {
/* 6296 */           publicUpdatesChannelId(instance.publicUpdatesChannelId());
/* 6297 */           bits |= 0x2000L;
/*      */         } 
/* 6299 */         if ((bits & 0x8000L) == 0L) {
/* 6300 */           id(instance.id());
/* 6301 */           bits |= 0x8000L;
/*      */         } 
/* 6303 */         if ((bits & 0x10000L) == 0L) {
/* 6304 */           safetyAlertsChannelId(instance.safetyAlertsChannelId());
/* 6305 */           bits |= 0x10000L;
/*      */         } 
/* 6307 */         if ((bits & 0x20000L) == 0L) {
/* 6308 */           systemChannelId(instance.systemChannelId());
/* 6309 */           bits |= 0x20000L;
/*      */         } 
/* 6311 */         if ((bits & 0x80000L) == 0L) {
/* 6312 */           owner(instance.owner());
/* 6313 */           bits |= 0x80000L;
/*      */         } 
/* 6315 */         if ((bits & 0x200000L) == 0L) {
/* 6316 */           Optional<String> discoverySplashOptional = instance.discoverySplash();
/* 6317 */           if (discoverySplashOptional.isPresent()) {
/* 6318 */             discoverySplash(discoverySplashOptional);
/*      */           }
/* 6320 */           bits |= 0x200000L;
/*      */         } 
/* 6322 */         if ((bits & 0x400000L) == 0L) {
/* 6323 */           approximateMemberCount(instance.approximateMemberCount());
/* 6324 */           bits |= 0x400000L;
/*      */         } 
/* 6326 */         if ((bits & 0x1000000L) == 0L) {
/* 6327 */           maxPresences(instance.maxPresences());
/* 6328 */           bits |= 0x1000000L;
/*      */         } 
/* 6330 */         if ((bits & 0x2000000L) == 0L) {
/* 6331 */           welcomeScreen(instance.welcomeScreen());
/* 6332 */           bits |= 0x2000000L;
/*      */         } 
/* 6334 */         if ((bits & 0x4000000L) == 0L) {
/* 6335 */           rulesChannelId(instance.rulesChannelId());
/* 6336 */           bits |= 0x4000000L;
/*      */         } 
/* 6338 */         if ((bits & 0x8000000L) == 0L) {
/* 6339 */           nsfw(instance.nsfw());
/* 6340 */           bits |= 0x8000000L;
/*      */         } 
/* 6342 */         if ((bits & 0x10000000L) == 0L) {
/* 6343 */           widgetChannelId(instance.widgetChannelId());
/* 6344 */           bits |= 0x10000000L;
/*      */         } 
/* 6346 */         if ((bits & 0x20000000L) == 0L) {
/* 6347 */           Optional<String> bannerOptional = instance.banner();
/* 6348 */           if (bannerOptional.isPresent()) {
/* 6349 */             banner(bannerOptional);
/*      */           }
/* 6351 */           bits |= 0x20000000L;
/*      */         } 
/* 6353 */         if ((bits & 0x40000000L) == 0L) {
/* 6354 */           widgetEnabled(instance.widgetEnabled());
/* 6355 */           bits |= 0x40000000L;
/*      */         } 
/* 6357 */         if ((bits & 0x80000000L) == 0L) {
/* 6358 */           embedChannelId(instance.embedChannelId());
/* 6359 */           bits |= 0x80000000L;
/*      */         } 
/* 6361 */         if ((bits & 0x100000000L) == 0L) {
/* 6362 */           OptionalInt systemChannelFlagsOptional = instance.systemChannelFlags();
/* 6363 */           if (systemChannelFlagsOptional.isPresent()) {
/* 6364 */             systemChannelFlags(systemChannelFlagsOptional);
/*      */           }
/* 6366 */           bits |= 0x100000000L;
/*      */         } 
/* 6368 */         if ((bits & 0x200000000L) == 0L) {
/* 6369 */           maxVideoChannelUsers(instance.maxVideoChannelUsers());
/* 6370 */           bits |= 0x200000000L;
/*      */         } 
/* 6372 */         if ((bits & 0x800000000L) == 0L) {
/* 6373 */           name(instance.name());
/* 6374 */           bits |= 0x800000000L;
/*      */         } 
/* 6376 */         if ((bits & 0x1000000000L) == 0L) {
/* 6377 */           premiumSubscriptionCount(instance.premiumSubscriptionCount());
/* 6378 */           bits |= 0x1000000000L;
/*      */         } 
/* 6380 */         if ((bits & 0x2000000000L) == 0L) {
/* 6381 */           embedEnabled(instance.embedEnabled());
/* 6382 */           bits |= 0x2000000000L;
/*      */         } 
/* 6384 */         if ((bits & 0x4000000000L) == 0L) {
/* 6385 */           approximatePresenceCount(instance.approximatePresenceCount());
/* 6386 */           bits |= 0x4000000000L;
/*      */         } 
/* 6388 */         if ((bits & 0x8000000000L) == 0L) {
/* 6389 */           applicationId(instance.applicationId());
/* 6390 */           bits |= 0x8000000000L;
/*      */         } 
/* 6392 */         if ((bits & 0x40000000000L) == 0L) {
/* 6393 */           Optional<String> splashOptional = instance.splash();
/* 6394 */           if (splashOptional.isPresent()) {
/* 6395 */             splash(splashOptional);
/*      */           }
/* 6397 */           bits |= 0x40000000000L;
/*      */         } 
/*      */       } 
/* 6400 */       if (object instanceof GuildUpdateData) {
/* 6401 */         GuildUpdateData instance = (GuildUpdateData)object;
/* 6402 */         if ((bits & 0x1L) == 0L) {
/* 6403 */           explicitContentFilter(instance.explicitContentFilter());
/* 6404 */           bits |= 0x1L;
/*      */         } 
/* 6406 */         if ((bits & 0x2L) == 0L) {
/* 6407 */           Optional<String> vanityUrlCodeOptional = instance.vanityUrlCode();
/* 6408 */           if (vanityUrlCodeOptional.isPresent()) {
/* 6409 */             vanityUrlCode(vanityUrlCodeOptional);
/*      */           }
/* 6411 */           bits |= 0x2L;
/*      */         } 
/* 6413 */         if ((bits & 0x4L) == 0L) {
/* 6414 */           afkTimeout(instance.afkTimeout());
/* 6415 */           bits |= 0x4L;
/*      */         } 
/* 6417 */         if ((bits & 0x8L) == 0L) {
/* 6418 */           premiumTier(instance.premiumTier());
/* 6419 */           bits |= 0x8L;
/*      */         } 
/* 6421 */         if ((bits & 0x10L) == 0L) {
/* 6422 */           addAllRoles(instance.roles());
/* 6423 */           bits |= 0x10L;
/*      */         } 
/* 6425 */         if ((bits & 0x20L) == 0L) {
/* 6426 */           Optional<String> iconOptional = instance.icon();
/* 6427 */           if (iconOptional.isPresent()) {
/* 6428 */             icon(iconOptional);
/*      */           }
/* 6430 */           bits |= 0x20L;
/*      */         } 
/* 6432 */         if ((bits & 0x40L) == 0L) {
/* 6433 */           verificationLevel(instance.verificationLevel());
/* 6434 */           bits |= 0x40L;
/*      */         } 
/* 6436 */         if ((bits & 0x80L) == 0L) {
/* 6437 */           Optional<String> descriptionOptional = instance.description();
/* 6438 */           if (descriptionOptional.isPresent()) {
/* 6439 */             description(descriptionOptional);
/*      */           }
/* 6441 */           bits |= 0x80L;
/*      */         } 
/* 6443 */         if ((bits & 0x100L) == 0L) {
/* 6444 */           afkChannelId(instance.afkChannelId());
/* 6445 */           bits |= 0x100L;
/*      */         } 
/* 6447 */         if ((bits & 0x200L) == 0L) {
/* 6448 */           ownerId(instance.ownerId());
/* 6449 */           bits |= 0x200L;
/*      */         } 
/* 6451 */         if ((bits & 0x400L) == 0L) {
/* 6452 */           addAllFeatures(instance.features());
/* 6453 */           bits |= 0x400L;
/*      */         } 
/* 6455 */         if ((bits & 0x800L) == 0L) {
/* 6456 */           maxMembers(instance.maxMembers());
/* 6457 */           bits |= 0x800L;
/*      */         } 
/* 6459 */         if ((bits & 0x1000L) == 0L) {
/* 6460 */           permissions(instance.permissions());
/* 6461 */           bits |= 0x1000L;
/*      */         } 
/* 6463 */         if ((bits & 0x2000L) == 0L) {
/* 6464 */           publicUpdatesChannelId(instance.publicUpdatesChannelId());
/* 6465 */           bits |= 0x2000L;
/*      */         } 
/* 6467 */         if ((bits & 0x4000L) == 0L) {
/* 6468 */           stickers(instance.stickers());
/* 6469 */           bits |= 0x4000L;
/*      */         } 
/* 6471 */         if ((bits & 0x8000L) == 0L) {
/* 6472 */           id(instance.id());
/* 6473 */           bits |= 0x8000L;
/*      */         } 
/* 6475 */         if ((bits & 0x10000L) == 0L) {
/* 6476 */           safetyAlertsChannelId(instance.safetyAlertsChannelId());
/* 6477 */           bits |= 0x10000L;
/*      */         } 
/* 6479 */         if ((bits & 0x20000L) == 0L) {
/* 6480 */           systemChannelId(instance.systemChannelId());
/* 6481 */           bits |= 0x20000L;
/*      */         } 
/* 6483 */         if ((bits & 0x40000L) == 0L) {
/* 6484 */           preferredLocale(instance.preferredLocale());
/* 6485 */           bits |= 0x40000L;
/*      */         } 
/* 6487 */         if ((bits & 0x80000L) == 0L) {
/* 6488 */           owner(instance.owner());
/* 6489 */           bits |= 0x80000L;
/*      */         } 
/* 6491 */         if ((bits & 0x100000L) == 0L) {
/* 6492 */           addAllEmojis(instance.emojis());
/* 6493 */           bits |= 0x100000L;
/*      */         } 
/* 6495 */         if ((bits & 0x200000L) == 0L) {
/* 6496 */           Optional<String> discoverySplashOptional = instance.discoverySplash();
/* 6497 */           if (discoverySplashOptional.isPresent()) {
/* 6498 */             discoverySplash(discoverySplashOptional);
/*      */           }
/* 6500 */           bits |= 0x200000L;
/*      */         } 
/* 6502 */         if ((bits & 0x400000L) == 0L) {
/* 6503 */           approximateMemberCount(instance.approximateMemberCount());
/* 6504 */           bits |= 0x400000L;
/*      */         } 
/* 6506 */         if ((bits & 0x800000L) == 0L) {
/* 6507 */           defaultMessageNotifications(instance.defaultMessageNotifications());
/* 6508 */           bits |= 0x800000L;
/*      */         } 
/* 6510 */         if ((bits & 0x1000000L) == 0L) {
/* 6511 */           maxPresences(instance.maxPresences());
/* 6512 */           bits |= 0x1000000L;
/*      */         } 
/* 6514 */         if ((bits & 0x2000000L) == 0L) {
/* 6515 */           welcomeScreen(instance.welcomeScreen());
/* 6516 */           bits |= 0x2000000L;
/*      */         } 
/* 6518 */         if ((bits & 0x4000000L) == 0L) {
/* 6519 */           rulesChannelId(instance.rulesChannelId());
/* 6520 */           bits |= 0x4000000L;
/*      */         } 
/* 6522 */         if ((bits & 0x8000000L) == 0L) {
/* 6523 */           nsfw(instance.nsfw());
/* 6524 */           bits |= 0x8000000L;
/*      */         } 
/* 6526 */         if ((bits & 0x10000000L) == 0L) {
/* 6527 */           widgetChannelId(instance.widgetChannelId());
/* 6528 */           bits |= 0x10000000L;
/*      */         } 
/* 6530 */         if ((bits & 0x20000000L) == 0L) {
/* 6531 */           Optional<String> bannerOptional = instance.banner();
/* 6532 */           if (bannerOptional.isPresent()) {
/* 6533 */             banner(bannerOptional);
/*      */           }
/* 6535 */           bits |= 0x20000000L;
/*      */         } 
/* 6537 */         if ((bits & 0x40000000L) == 0L) {
/* 6538 */           widgetEnabled(instance.widgetEnabled());
/* 6539 */           bits |= 0x40000000L;
/*      */         } 
/* 6541 */         if ((bits & 0x80000000L) == 0L) {
/* 6542 */           embedChannelId(instance.embedChannelId());
/* 6543 */           bits |= 0x80000000L;
/*      */         } 
/* 6545 */         if ((bits & 0x100000000L) == 0L) {
/* 6546 */           OptionalInt systemChannelFlagsOptional = instance.systemChannelFlags();
/* 6547 */           if (systemChannelFlagsOptional.isPresent()) {
/* 6548 */             systemChannelFlags(systemChannelFlagsOptional);
/*      */           }
/* 6550 */           bits |= 0x100000000L;
/*      */         } 
/* 6552 */         if ((bits & 0x200000000L) == 0L) {
/* 6553 */           maxVideoChannelUsers(instance.maxVideoChannelUsers());
/* 6554 */           bits |= 0x200000000L;
/*      */         } 
/* 6556 */         if ((bits & 0x400000000L) == 0L) {
/* 6557 */           nsfwLevel(instance.nsfwLevel());
/* 6558 */           bits |= 0x400000000L;
/*      */         } 
/* 6560 */         if ((bits & 0x800000000L) == 0L) {
/* 6561 */           name(instance.name());
/* 6562 */           bits |= 0x800000000L;
/*      */         } 
/* 6564 */         if ((bits & 0x1000000000L) == 0L) {
/* 6565 */           premiumSubscriptionCount(instance.premiumSubscriptionCount());
/* 6566 */           bits |= 0x1000000000L;
/*      */         } 
/* 6568 */         if ((bits & 0x2000000000L) == 0L) {
/* 6569 */           embedEnabled(instance.embedEnabled());
/* 6570 */           bits |= 0x2000000000L;
/*      */         } 
/* 6572 */         if ((bits & 0x4000000000L) == 0L) {
/* 6573 */           approximatePresenceCount(instance.approximatePresenceCount());
/* 6574 */           bits |= 0x4000000000L;
/*      */         } 
/* 6576 */         if ((bits & 0x8000000000L) == 0L) {
/* 6577 */           applicationId(instance.applicationId());
/* 6578 */           bits |= 0x8000000000L;
/*      */         } 
/* 6580 */         if ((bits & 0x10000000000L) == 0L) {
/* 6581 */           region(instance.region());
/* 6582 */           bits |= 0x10000000000L;
/*      */         } 
/* 6584 */         if ((bits & 0x20000000000L) == 0L) {
/* 6585 */           mfaLevel(instance.mfaLevel());
/* 6586 */           bits |= 0x20000000000L;
/*      */         } 
/* 6588 */         if ((bits & 0x40000000000L) == 0L) {
/* 6589 */           Optional<String> splashOptional = instance.splash();
/* 6590 */           if (splashOptional.isPresent()) {
/* 6591 */             splash(splashOptional);
/*      */           }
/* 6593 */           bits |= 0x40000000000L;
/*      */         } 
/*      */       } 
/* 6596 */       if (object instanceof GuildUpdateFields) {
/* 6597 */         GuildUpdateFields instance = (GuildUpdateFields)object;
/* 6598 */         if ((bits & 0x1L) == 0L) {
/* 6599 */           explicitContentFilter(instance.explicitContentFilter());
/* 6600 */           bits |= 0x1L;
/*      */         } 
/* 6602 */         if ((bits & 0x2L) == 0L) {
/* 6603 */           Optional<String> vanityUrlCodeOptional = instance.vanityUrlCode();
/* 6604 */           if (vanityUrlCodeOptional.isPresent()) {
/* 6605 */             vanityUrlCode(vanityUrlCodeOptional);
/*      */           }
/* 6607 */           bits |= 0x2L;
/*      */         } 
/* 6609 */         if ((bits & 0x4L) == 0L) {
/* 6610 */           afkTimeout(instance.afkTimeout());
/* 6611 */           bits |= 0x4L;
/*      */         } 
/* 6613 */         if ((bits & 0x8L) == 0L) {
/* 6614 */           premiumTier(instance.premiumTier());
/* 6615 */           bits |= 0x8L;
/*      */         } 
/* 6617 */         if ((bits & 0x20L) == 0L) {
/* 6618 */           Optional<String> iconOptional = instance.icon();
/* 6619 */           if (iconOptional.isPresent()) {
/* 6620 */             icon(iconOptional);
/*      */           }
/* 6622 */           bits |= 0x20L;
/*      */         } 
/* 6624 */         if ((bits & 0x40L) == 0L) {
/* 6625 */           verificationLevel(instance.verificationLevel());
/* 6626 */           bits |= 0x40L;
/*      */         } 
/* 6628 */         if ((bits & 0x80L) == 0L) {
/* 6629 */           Optional<String> descriptionOptional = instance.description();
/* 6630 */           if (descriptionOptional.isPresent()) {
/* 6631 */             description(descriptionOptional);
/*      */           }
/* 6633 */           bits |= 0x80L;
/*      */         } 
/* 6635 */         if ((bits & 0x100L) == 0L) {
/* 6636 */           afkChannelId(instance.afkChannelId());
/* 6637 */           bits |= 0x100L;
/*      */         } 
/* 6639 */         if ((bits & 0x200L) == 0L) {
/* 6640 */           ownerId(instance.ownerId());
/* 6641 */           bits |= 0x200L;
/*      */         } 
/* 6643 */         if ((bits & 0x400L) == 0L) {
/* 6644 */           addAllFeatures(instance.features());
/* 6645 */           bits |= 0x400L;
/*      */         } 
/* 6647 */         if ((bits & 0x800L) == 0L) {
/* 6648 */           maxMembers(instance.maxMembers());
/* 6649 */           bits |= 0x800L;
/*      */         } 
/* 6651 */         if ((bits & 0x1000L) == 0L) {
/* 6652 */           permissions(instance.permissions());
/* 6653 */           bits |= 0x1000L;
/*      */         } 
/* 6655 */         if ((bits & 0x2000L) == 0L) {
/* 6656 */           publicUpdatesChannelId(instance.publicUpdatesChannelId());
/* 6657 */           bits |= 0x2000L;
/*      */         } 
/* 6659 */         if ((bits & 0x8000L) == 0L) {
/* 6660 */           id(instance.id());
/* 6661 */           bits |= 0x8000L;
/*      */         } 
/* 6663 */         if ((bits & 0x10000L) == 0L) {
/* 6664 */           safetyAlertsChannelId(instance.safetyAlertsChannelId());
/* 6665 */           bits |= 0x10000L;
/*      */         } 
/* 6667 */         if ((bits & 0x20000L) == 0L) {
/* 6668 */           systemChannelId(instance.systemChannelId());
/* 6669 */           bits |= 0x20000L;
/*      */         } 
/* 6671 */         if ((bits & 0x40000L) == 0L) {
/* 6672 */           preferredLocale(instance.preferredLocale());
/* 6673 */           bits |= 0x40000L;
/*      */         } 
/* 6675 */         if ((bits & 0x80000L) == 0L) {
/* 6676 */           owner(instance.owner());
/* 6677 */           bits |= 0x80000L;
/*      */         } 
/* 6679 */         if ((bits & 0x200000L) == 0L) {
/* 6680 */           Optional<String> discoverySplashOptional = instance.discoverySplash();
/* 6681 */           if (discoverySplashOptional.isPresent()) {
/* 6682 */             discoverySplash(discoverySplashOptional);
/*      */           }
/* 6684 */           bits |= 0x200000L;
/*      */         } 
/* 6686 */         if ((bits & 0x400000L) == 0L) {
/* 6687 */           approximateMemberCount(instance.approximateMemberCount());
/* 6688 */           bits |= 0x400000L;
/*      */         } 
/* 6690 */         if ((bits & 0x800000L) == 0L) {
/* 6691 */           defaultMessageNotifications(instance.defaultMessageNotifications());
/* 6692 */           bits |= 0x800000L;
/*      */         } 
/* 6694 */         if ((bits & 0x1000000L) == 0L) {
/* 6695 */           maxPresences(instance.maxPresences());
/* 6696 */           bits |= 0x1000000L;
/*      */         } 
/* 6698 */         if ((bits & 0x2000000L) == 0L) {
/* 6699 */           welcomeScreen(instance.welcomeScreen());
/* 6700 */           bits |= 0x2000000L;
/*      */         } 
/* 6702 */         if ((bits & 0x4000000L) == 0L) {
/* 6703 */           rulesChannelId(instance.rulesChannelId());
/* 6704 */           bits |= 0x4000000L;
/*      */         } 
/* 6706 */         if ((bits & 0x8000000L) == 0L) {
/* 6707 */           nsfw(instance.nsfw());
/* 6708 */           bits |= 0x8000000L;
/*      */         } 
/* 6710 */         if ((bits & 0x10000000L) == 0L) {
/* 6711 */           widgetChannelId(instance.widgetChannelId());
/* 6712 */           bits |= 0x10000000L;
/*      */         } 
/* 6714 */         if ((bits & 0x20000000L) == 0L) {
/* 6715 */           Optional<String> bannerOptional = instance.banner();
/* 6716 */           if (bannerOptional.isPresent()) {
/* 6717 */             banner(bannerOptional);
/*      */           }
/* 6719 */           bits |= 0x20000000L;
/*      */         } 
/* 6721 */         if ((bits & 0x40000000L) == 0L) {
/* 6722 */           widgetEnabled(instance.widgetEnabled());
/* 6723 */           bits |= 0x40000000L;
/*      */         } 
/* 6725 */         if ((bits & 0x80000000L) == 0L) {
/* 6726 */           embedChannelId(instance.embedChannelId());
/* 6727 */           bits |= 0x80000000L;
/*      */         } 
/* 6729 */         if ((bits & 0x100000000L) == 0L) {
/* 6730 */           OptionalInt systemChannelFlagsOptional = instance.systemChannelFlags();
/* 6731 */           if (systemChannelFlagsOptional.isPresent()) {
/* 6732 */             systemChannelFlags(systemChannelFlagsOptional);
/*      */           }
/* 6734 */           bits |= 0x100000000L;
/*      */         } 
/* 6736 */         if ((bits & 0x200000000L) == 0L) {
/* 6737 */           maxVideoChannelUsers(instance.maxVideoChannelUsers());
/* 6738 */           bits |= 0x200000000L;
/*      */         } 
/* 6740 */         if ((bits & 0x400000000L) == 0L) {
/* 6741 */           nsfwLevel(instance.nsfwLevel());
/* 6742 */           bits |= 0x400000000L;
/*      */         } 
/* 6744 */         if ((bits & 0x800000000L) == 0L) {
/* 6745 */           name(instance.name());
/* 6746 */           bits |= 0x800000000L;
/*      */         } 
/* 6748 */         if ((bits & 0x1000000000L) == 0L) {
/* 6749 */           premiumSubscriptionCount(instance.premiumSubscriptionCount());
/* 6750 */           bits |= 0x1000000000L;
/*      */         } 
/* 6752 */         if ((bits & 0x2000000000L) == 0L) {
/* 6753 */           embedEnabled(instance.embedEnabled());
/* 6754 */           bits |= 0x2000000000L;
/*      */         } 
/* 6756 */         if ((bits & 0x4000000000L) == 0L) {
/* 6757 */           approximatePresenceCount(instance.approximatePresenceCount());
/* 6758 */           bits |= 0x4000000000L;
/*      */         } 
/* 6760 */         if ((bits & 0x8000000000L) == 0L) {
/* 6761 */           applicationId(instance.applicationId());
/* 6762 */           bits |= 0x8000000000L;
/*      */         } 
/* 6764 */         if ((bits & 0x10000000000L) == 0L) {
/* 6765 */           region(instance.region());
/* 6766 */           bits |= 0x10000000000L;
/*      */         } 
/* 6768 */         if ((bits & 0x20000000000L) == 0L) {
/* 6769 */           mfaLevel(instance.mfaLevel());
/* 6770 */           bits |= 0x20000000000L;
/*      */         } 
/* 6772 */         if ((bits & 0x40000000000L) == 0L) {
/* 6773 */           Optional<String> splashOptional = instance.splash();
/* 6774 */           if (splashOptional.isPresent()) {
/* 6775 */             splash(splashOptional);
/*      */           }
/* 6777 */           bits |= 0x40000000000L;
/*      */         } 
/*      */       } 
/* 6780 */       if (object instanceof GuildNsfwLevelField) {
/* 6781 */         GuildNsfwLevelField instance = (GuildNsfwLevelField)object;
/* 6782 */         if ((bits & 0x400000000L) == 0L) {
/* 6783 */           nsfwLevel(instance.nsfwLevel());
/* 6784 */           bits |= 0x400000000L;
/*      */         } 
/*      */       } 
/* 6787 */       if (object instanceof GuildVerificationLevelField) {
/* 6788 */         GuildVerificationLevelField instance = (GuildVerificationLevelField)object;
/* 6789 */         if ((bits & 0x40L) == 0L) {
/* 6790 */           verificationLevel(instance.verificationLevel());
/* 6791 */           bits |= 0x40L;
/*      */         } 
/*      */       } 
/* 6794 */       if (object instanceof GuildRolesEmojisStickersFields) {
/* 6795 */         GuildRolesEmojisStickersFields instance = (GuildRolesEmojisStickersFields)object;
/* 6796 */         if ((bits & 0x100000L) == 0L) {
/* 6797 */           addAllEmojis(instance.emojis());
/* 6798 */           bits |= 0x100000L;
/*      */         } 
/* 6800 */         if ((bits & 0x4000L) == 0L) {
/* 6801 */           stickers(instance.stickers());
/* 6802 */           bits |= 0x4000L;
/*      */         } 
/* 6804 */         if ((bits & 0x10L) == 0L) {
/* 6805 */           addAllRoles(instance.roles());
/* 6806 */           bits |= 0x10L;
/*      */         } 
/*      */       } 
/*      */     }
/*      */     
/*      */     public Builder id(String value) {
/* 6812 */       this.id_id = Id.of(value);
/* 6813 */       return this;
/*      */     }
/*      */     
/*      */     public Builder id(long value) {
/* 6817 */       this.id_id = Id.of(value);
/* 6818 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("id")
/*      */     public Builder id(Id value) {
/* 6823 */       this.id_id = value;
/* 6824 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("name")
/*      */     public final Builder name(String name) {
/* 6834 */       this.name = Objects.<String>requireNonNull(name, "name");
/* 6835 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 6836 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder icon(String icon) {
/* 6845 */       this.icon = Objects.<String>requireNonNull(icon, "icon");
/* 6846 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("icon")
/*      */     public final Builder icon(Optional<String> icon) {
/* 6856 */       this.icon = icon.orElse(null);
/* 6857 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder splash(String splash) {
/* 6866 */       this.splash = Objects.<String>requireNonNull(splash, "splash");
/* 6867 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("splash")
/*      */     public final Builder splash(Optional<String> splash) {
/* 6877 */       this.splash = splash.orElse(null);
/* 6878 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder discoverySplash(String discoverySplash) {
/* 6887 */       this.discoverySplash = Objects.<String>requireNonNull(discoverySplash, "discoverySplash");
/* 6888 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("discovery_splash")
/*      */     public final Builder discoverySplash(Optional<String> discoverySplash) {
/* 6898 */       this.discoverySplash = discoverySplash.orElse(null);
/* 6899 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("owner")
/*      */     public Builder owner(Possible<Boolean> value) {
/* 6904 */       this.owner_possible = value;
/* 6905 */       return this;
/*      */     }
/*      */     
/*      */     public Builder owner(Boolean value) {
/* 6909 */       this.owner_possible = Possible.of(value);
/* 6910 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("permissions")
/*      */     public Builder permissions(Possible<Long> value) {
/* 6915 */       this.permissions_possible = value;
/* 6916 */       return this;
/*      */     }
/*      */     
/*      */     public Builder permissions(Long value) {
/* 6920 */       this.permissions_possible = Possible.of(value);
/* 6921 */       return this;
/*      */     }
/*      */     
/*      */     public Builder afkChannelId(String value) {
/* 6925 */       this.afkChannelId_optional = Optional.of(Id.of(value));
/* 6926 */       return this;
/*      */     }
/*      */     
/*      */     public Builder afkChannelId(long value) {
/* 6930 */       this.afkChannelId_optional = Optional.of(Id.of(value));
/* 6931 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("afk_channel_id")
/*      */     public Builder afkChannelId(Optional<Id> value) {
/* 6936 */       this.afkChannelId_optional = value;
/* 6937 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("embed_enabled")
/*      */     public Builder embedEnabled(Possible<Boolean> value) {
/* 6942 */       this.embedEnabled_possible = value;
/* 6943 */       return this;
/*      */     }
/*      */     
/*      */     public Builder embedEnabled(Boolean value) {
/* 6947 */       this.embedEnabled_possible = Possible.of(value);
/* 6948 */       return this;
/*      */     }
/*      */     
/*      */     public Builder embedChannelId(String value) {
/* 6952 */       this.embedChannelId_possible = Possible.of(Optional.of(Id.of(value)));
/* 6953 */       return this;
/*      */     }
/*      */     
/*      */     public Builder embedChannelId(long value) {
/* 6957 */       this.embedChannelId_possible = Possible.of(Optional.of(Id.of(value)));
/* 6958 */       return this;
/*      */     }
/*      */     
/*      */     public Builder embedChannelId(Id value) {
/* 6962 */       this.embedChannelId_possible = Possible.of(Optional.of(value));
/* 6963 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("embed_channel_id")
/*      */     public Builder embedChannelId(Possible<Optional<Id>> value) {
/* 6968 */       this.embedChannelId_possible = value;
/* 6969 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addFeature(String element) {
/* 6978 */       this.features.add(Objects.<String>requireNonNull(element, "features element"));
/* 6979 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addFeatures(String... elements) {
/* 6988 */       for (String element : elements) {
/* 6989 */         this.features.add(Objects.<String>requireNonNull(element, "features element"));
/*      */       }
/* 6991 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("features")
/*      */     public final Builder features(Iterable<String> elements) {
/* 7002 */       this.features.clear();
/* 7003 */       return addAllFeatures(elements);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addAllFeatures(Iterable<String> elements) {
/* 7012 */       for (String element : elements) {
/* 7013 */         this.features.add(Objects.<String>requireNonNull(element, "features element"));
/*      */       }
/* 7015 */       return this;
/*      */     }
/*      */     
/*      */     public Builder applicationId(String value) {
/* 7019 */       this.applicationId_optional = Optional.of(Id.of(value));
/* 7020 */       return this;
/*      */     }
/*      */     
/*      */     public Builder applicationId(long value) {
/* 7024 */       this.applicationId_optional = Optional.of(Id.of(value));
/* 7025 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("application_id")
/*      */     public Builder applicationId(Optional<Id> value) {
/* 7030 */       this.applicationId_optional = value;
/* 7031 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("widget_enabled")
/*      */     public Builder widgetEnabled(Possible<Boolean> value) {
/* 7036 */       this.widgetEnabled_possible = value;
/* 7037 */       return this;
/*      */     }
/*      */     
/*      */     public Builder widgetEnabled(Boolean value) {
/* 7041 */       this.widgetEnabled_possible = Possible.of(value);
/* 7042 */       return this;
/*      */     }
/*      */     
/*      */     public Builder widgetChannelId(String value) {
/* 7046 */       this.widgetChannelId_possible = Possible.of(Optional.of(Id.of(value)));
/* 7047 */       return this;
/*      */     }
/*      */     
/*      */     public Builder widgetChannelId(long value) {
/* 7051 */       this.widgetChannelId_possible = Possible.of(Optional.of(Id.of(value)));
/* 7052 */       return this;
/*      */     }
/*      */     
/*      */     public Builder widgetChannelId(Id value) {
/* 7056 */       this.widgetChannelId_possible = Possible.of(Optional.of(value));
/* 7057 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("widget_channel_id")
/*      */     public Builder widgetChannelId(Possible<Optional<Id>> value) {
/* 7062 */       this.widgetChannelId_possible = value;
/* 7063 */       return this;
/*      */     }
/*      */     
/*      */     public Builder systemChannelId(String value) {
/* 7067 */       this.systemChannelId_optional = Optional.of(Id.of(value));
/* 7068 */       return this;
/*      */     }
/*      */     
/*      */     public Builder systemChannelId(long value) {
/* 7072 */       this.systemChannelId_optional = Optional.of(Id.of(value));
/* 7073 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("system_channel_id")
/*      */     public Builder systemChannelId(Optional<Id> value) {
/* 7078 */       this.systemChannelId_optional = value;
/* 7079 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder systemChannelFlags(int systemChannelFlags) {
/* 7088 */       this.systemChannelFlags = Integer.valueOf(systemChannelFlags);
/* 7089 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("system_channel_flags")
/*      */     public final Builder systemChannelFlags(OptionalInt systemChannelFlags) {
/* 7099 */       this.systemChannelFlags = systemChannelFlags.isPresent() ? Integer.valueOf(systemChannelFlags.getAsInt()) : null;
/* 7100 */       return this;
/*      */     }
/*      */     
/*      */     public Builder rulesChannelId(String value) {
/* 7104 */       this.rulesChannelId_optional = Optional.of(Id.of(value));
/* 7105 */       return this;
/*      */     }
/*      */     
/*      */     public Builder rulesChannelId(long value) {
/* 7109 */       this.rulesChannelId_optional = Optional.of(Id.of(value));
/* 7110 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("rules_channel_id")
/*      */     public Builder rulesChannelId(Optional<Id> value) {
/* 7115 */       this.rulesChannelId_optional = value;
/* 7116 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("max_presences")
/*      */     public Builder maxPresences(Possible<Optional<Integer>> value) {
/* 7121 */       this.maxPresences_possible = value;
/* 7122 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public Builder maxPresences(@Nullable Integer value) {
/* 7127 */       this.maxPresences_possible = Possible.of(Optional.ofNullable(value));
/* 7128 */       return this;
/*      */     }
/*      */     
/*      */     public Builder maxPresencesOrNull(@Nullable Integer value) {
/* 7132 */       this.maxPresences_possible = Possible.of(Optional.ofNullable(value));
/* 7133 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("max_members")
/*      */     public Builder maxMembers(Possible<Integer> value) {
/* 7138 */       this.maxMembers_possible = value;
/* 7139 */       return this;
/*      */     }
/*      */     
/*      */     public Builder maxMembers(Integer value) {
/* 7143 */       this.maxMembers_possible = Possible.of(value);
/* 7144 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder vanityUrlCode(String vanityUrlCode) {
/* 7153 */       this.vanityUrlCode = Objects.<String>requireNonNull(vanityUrlCode, "vanityUrlCode");
/* 7154 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("vanity_url_code")
/*      */     public final Builder vanityUrlCode(Optional<String> vanityUrlCode) {
/* 7164 */       this.vanityUrlCode = vanityUrlCode.orElse(null);
/* 7165 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder description(String description) {
/* 7174 */       this.description = Objects.<String>requireNonNull(description, "description");
/* 7175 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("description")
/*      */     public final Builder description(Optional<String> description) {
/* 7185 */       this.description = description.orElse(null);
/* 7186 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder banner(String banner) {
/* 7195 */       this.banner = Objects.<String>requireNonNull(banner, "banner");
/* 7196 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("banner")
/*      */     public final Builder banner(Optional<String> banner) {
/* 7206 */       this.banner = banner.orElse(null);
/* 7207 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("premium_subscription_count")
/*      */     public Builder premiumSubscriptionCount(Possible<Integer> value) {
/* 7212 */       this.premiumSubscriptionCount_possible = value;
/* 7213 */       return this;
/*      */     }
/*      */     
/*      */     public Builder premiumSubscriptionCount(Integer value) {
/* 7217 */       this.premiumSubscriptionCount_possible = Possible.of(value);
/* 7218 */       return this;
/*      */     }
/*      */     
/*      */     public Builder publicUpdatesChannelId(String value) {
/* 7222 */       this.publicUpdatesChannelId_optional = Optional.of(Id.of(value));
/* 7223 */       return this;
/*      */     }
/*      */     
/*      */     public Builder publicUpdatesChannelId(long value) {
/* 7227 */       this.publicUpdatesChannelId_optional = Optional.of(Id.of(value));
/* 7228 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("public_updates_channel_id")
/*      */     public Builder publicUpdatesChannelId(Optional<Id> value) {
/* 7233 */       this.publicUpdatesChannelId_optional = value;
/* 7234 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("max_video_channel_users")
/*      */     public Builder maxVideoChannelUsers(Possible<Integer> value) {
/* 7239 */       this.maxVideoChannelUsers_possible = value;
/* 7240 */       return this;
/*      */     }
/*      */     
/*      */     public Builder maxVideoChannelUsers(Integer value) {
/* 7244 */       this.maxVideoChannelUsers_possible = Possible.of(value);
/* 7245 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("approximate_member_count")
/*      */     public Builder approximateMemberCount(Possible<Integer> value) {
/* 7250 */       this.approximateMemberCount_possible = value;
/* 7251 */       return this;
/*      */     }
/*      */     
/*      */     public Builder approximateMemberCount(Integer value) {
/* 7255 */       this.approximateMemberCount_possible = Possible.of(value);
/* 7256 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("approximate_presence_count")
/*      */     public Builder approximatePresenceCount(Possible<Integer> value) {
/* 7261 */       this.approximatePresenceCount_possible = value;
/* 7262 */       return this;
/*      */     }
/*      */     
/*      */     public Builder approximatePresenceCount(Integer value) {
/* 7266 */       this.approximatePresenceCount_possible = Possible.of(value);
/* 7267 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("welcome_screen")
/*      */     public Builder welcomeScreen(Possible<WelcomeScreenData> value) {
/* 7272 */       this.welcomeScreen_possible = value;
/* 7273 */       return this;
/*      */     }
/*      */     
/*      */     public Builder welcomeScreen(WelcomeScreenData value) {
/* 7277 */       this.welcomeScreen_possible = Possible.of(value);
/* 7278 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("nsfw")
/*      */     public Builder nsfw(Possible<Boolean> value) {
/* 7283 */       this.nsfw_possible = value;
/* 7284 */       return this;
/*      */     }
/*      */     
/*      */     public Builder nsfw(Boolean value) {
/* 7288 */       this.nsfw_possible = Possible.of(value);
/* 7289 */       return this;
/*      */     }
/*      */     
/*      */     public Builder safetyAlertsChannelId(String value) {
/* 7293 */       this.safetyAlertsChannelId_optional = Optional.of(Id.of(value));
/* 7294 */       return this;
/*      */     }
/*      */     
/*      */     public Builder safetyAlertsChannelId(long value) {
/* 7298 */       this.safetyAlertsChannelId_optional = Optional.of(Id.of(value));
/* 7299 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("safety_alerts_channel_id")
/*      */     public Builder safetyAlertsChannelId(Optional<Id> value) {
/* 7304 */       this.safetyAlertsChannelId_optional = value;
/* 7305 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("verification_level")
/*      */     public final Builder verificationLevel(int verificationLevel) {
/* 7315 */       this.verificationLevel = verificationLevel;
/* 7316 */       this.initBits &= 0xFFFFFFFFFFFFFFFDL;
/* 7317 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("nsfw_level")
/*      */     public final Builder nsfwLevel(int nsfwLevel) {
/* 7327 */       this.nsfwLevel = nsfwLevel;
/* 7328 */       this.initBits &= 0xFFFFFFFFFFFFFFFBL;
/* 7329 */       return this;
/*      */     }
/*      */     
/*      */     public Builder ownerId(String value) {
/* 7333 */       this.ownerId_id = Id.of(value);
/* 7334 */       return this;
/*      */     }
/*      */     
/*      */     public Builder ownerId(long value) {
/* 7338 */       this.ownerId_id = Id.of(value);
/* 7339 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("owner_id")
/*      */     public Builder ownerId(Id value) {
/* 7344 */       this.ownerId_id = value;
/* 7345 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("region")
/*      */     public Builder region(Possible<Optional<String>> value) {
/* 7350 */       this.region_possible = value;
/* 7351 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public Builder region(@Nullable String value) {
/* 7356 */       this.region_possible = Possible.of(Optional.ofNullable(value));
/* 7357 */       return this;
/*      */     }
/*      */     
/*      */     public Builder regionOrNull(@Nullable String value) {
/* 7361 */       this.region_possible = Possible.of(Optional.ofNullable(value));
/* 7362 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("afk_timeout")
/*      */     public final Builder afkTimeout(int afkTimeout) {
/* 7372 */       this.afkTimeout = afkTimeout;
/* 7373 */       this.initBits &= 0xFFFFFFFFFFFFFFF7L;
/* 7374 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("default_message_notifications")
/*      */     public final Builder defaultMessageNotifications(int defaultMessageNotifications) {
/* 7384 */       this.defaultMessageNotifications = defaultMessageNotifications;
/* 7385 */       this.initBits &= 0xFFFFFFFFFFFFFFEFL;
/* 7386 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("explicit_content_filter")
/*      */     public final Builder explicitContentFilter(int explicitContentFilter) {
/* 7396 */       this.explicitContentFilter = explicitContentFilter;
/* 7397 */       this.initBits &= 0xFFFFFFFFFFFFFFDFL;
/* 7398 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("mfa_level")
/*      */     public final Builder mfaLevel(int mfaLevel) {
/* 7408 */       this.mfaLevel = mfaLevel;
/* 7409 */       this.initBits &= 0xFFFFFFFFFFFFFFBFL;
/* 7410 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("premium_tier")
/*      */     public final Builder premiumTier(int premiumTier) {
/* 7420 */       this.premiumTier = premiumTier;
/* 7421 */       this.initBits &= 0xFFFFFFFFFFFFFF7FL;
/* 7422 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("preferred_locale")
/*      */     public final Builder preferredLocale(String preferredLocale) {
/* 7432 */       this.preferredLocale = Objects.<String>requireNonNull(preferredLocale, "preferredLocale");
/* 7433 */       this.initBits &= 0xFFFFFFFFFFFFFEFFL;
/* 7434 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addRole(RoleData element) {
/* 7443 */       this.roles.add(Objects.<RoleData>requireNonNull(element, "roles element"));
/* 7444 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addRoles(RoleData... elements) {
/* 7453 */       for (RoleData element : elements) {
/* 7454 */         this.roles.add(Objects.<RoleData>requireNonNull(element, "roles element"));
/*      */       }
/* 7456 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("roles")
/*      */     public final Builder roles(Iterable<? extends RoleData> elements) {
/* 7467 */       this.roles.clear();
/* 7468 */       return addAllRoles(elements);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addAllRoles(Iterable<? extends RoleData> elements) {
/* 7477 */       for (RoleData element : elements) {
/* 7478 */         this.roles.add(Objects.<RoleData>requireNonNull(element, "roles element"));
/*      */       }
/* 7480 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addEmoji(EmojiData element) {
/* 7489 */       this.emojis.add(Objects.<EmojiData>requireNonNull(element, "emojis element"));
/* 7490 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addEmojis(EmojiData... elements) {
/* 7499 */       for (EmojiData element : elements) {
/* 7500 */         this.emojis.add(Objects.<EmojiData>requireNonNull(element, "emojis element"));
/*      */       }
/* 7502 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("emojis")
/*      */     public final Builder emojis(Iterable<? extends EmojiData> elements) {
/* 7513 */       this.emojis.clear();
/* 7514 */       return addAllEmojis(elements);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addAllEmojis(Iterable<? extends EmojiData> elements) {
/* 7523 */       for (EmojiData element : elements) {
/* 7524 */         this.emojis.add(Objects.<EmojiData>requireNonNull(element, "emojis element"));
/*      */       }
/* 7526 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addSticker(StickerData element) {
/* 7530 */       stickers_getOrCreate().add(element);
/* 7531 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addAllStickers(List<StickerData> elements) {
/* 7535 */       stickers_getOrCreate().addAll(elements);
/* 7536 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("stickers")
/*      */     public Builder stickers(Possible<List<StickerData>> elements) {
/* 7541 */       this.stickers_list = null;
/* 7542 */       elements.toOptional().ifPresent(e -> stickers_getOrCreate().addAll(e));
/* 7543 */       return this;
/*      */     }
/*      */     
/*      */     public Builder stickers(List<StickerData> elements) {
/* 7547 */       this.stickers_list = new ArrayList<>(elements);
/* 7548 */       return this;
/*      */     }
/*      */     
/*      */     public Builder stickers(Iterable<StickerData> elements) {
/* 7552 */       this.stickers_list = (List<StickerData>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/* 7553 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ImmutableGuildUpdateData build() {
/* 7562 */       if (this.initBits != 0L) {
/* 7563 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*      */       }
/* 7565 */       return new ImmutableGuildUpdateData(null, 
/*      */           
/* 7567 */           id_build(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 7572 */           owner_build(), 
/* 7573 */           permissions_build(), 
/* 7574 */           afkChannelId_build(), 
/* 7575 */           embedEnabled_build(), 
/* 7576 */           embedChannelId_build(), ImmutableGuildUpdateData
/* 7577 */           .createUnmodifiableList(true, (List)this.features), 
/* 7578 */           applicationId_build(), 
/* 7579 */           widgetEnabled_build(), 
/* 7580 */           widgetChannelId_build(), 
/* 7581 */           systemChannelId_build(), this.systemChannelFlags, 
/*      */           
/* 7583 */           rulesChannelId_build(), 
/* 7584 */           maxPresences_build(), 
/* 7585 */           maxMembers_build(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */           
/* 7589 */           premiumSubscriptionCount_build(), 
/* 7590 */           publicUpdatesChannelId_build(), 
/* 7591 */           maxVideoChannelUsers_build(), 
/* 7592 */           approximateMemberCount_build(), 
/* 7593 */           approximatePresenceCount_build(), 
/* 7594 */           welcomeScreen_build(), 
/* 7595 */           nsfw_build(), 
/* 7596 */           safetyAlertsChannelId_build(), this.verificationLevel, this.nsfwLevel, 
/*      */ 
/*      */           
/* 7599 */           ownerId_build(), 
/* 7600 */           region_build(), this.afkTimeout, this.defaultMessageNotifications, this.explicitContentFilter, this.mfaLevel, this.premiumTier, this.preferredLocale, ImmutableGuildUpdateData
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 7607 */           .createUnmodifiableList(true, (List)this.roles), ImmutableGuildUpdateData
/* 7608 */           .createUnmodifiableList(true, (List)this.emojis), 
/* 7609 */           stickers_build());
/*      */     }
/*      */     
/*      */     private String formatRequiredAttributesMessage() {
/* 7613 */       List<String> attributes = new ArrayList<>();
/* 7614 */       if ((this.initBits & 0x1L) != 0L) attributes.add("name"); 
/* 7615 */       if ((this.initBits & 0x2L) != 0L) attributes.add("verificationLevel"); 
/* 7616 */       if ((this.initBits & 0x4L) != 0L) attributes.add("nsfwLevel"); 
/* 7617 */       if ((this.initBits & 0x8L) != 0L) attributes.add("afkTimeout"); 
/* 7618 */       if ((this.initBits & 0x10L) != 0L) attributes.add("defaultMessageNotifications"); 
/* 7619 */       if ((this.initBits & 0x20L) != 0L) attributes.add("explicitContentFilter"); 
/* 7620 */       if ((this.initBits & 0x40L) != 0L) attributes.add("mfaLevel"); 
/* 7621 */       if ((this.initBits & 0x80L) != 0L) attributes.add("premiumTier"); 
/* 7622 */       if ((this.initBits & 0x100L) != 0L) attributes.add("preferredLocale"); 
/* 7623 */       return "Cannot build GuildUpdateData, some of required attributes are not set " + attributes;
/*      */     }
/*      */     
/*      */     private Id id_build() {
/* 7627 */       return this.id_id;
/*      */     }
/*      */     
/*      */     private Possible<Boolean> owner_build() {
/* 7631 */       return this.owner_possible;
/*      */     }
/*      */     
/*      */     private Possible<Long> permissions_build() {
/* 7635 */       return this.permissions_possible;
/*      */     }
/*      */     
/*      */     private Optional<Id> afkChannelId_build() {
/* 7639 */       return this.afkChannelId_optional;
/*      */     }
/*      */     
/*      */     private Possible<Boolean> embedEnabled_build() {
/* 7643 */       return this.embedEnabled_possible;
/*      */     }
/*      */     
/*      */     private Possible<Optional<Id>> embedChannelId_build() {
/* 7647 */       return this.embedChannelId_possible;
/*      */     }
/*      */     
/*      */     private Optional<Id> applicationId_build() {
/* 7651 */       return this.applicationId_optional;
/*      */     }
/*      */     
/*      */     private Possible<Boolean> widgetEnabled_build() {
/* 7655 */       return this.widgetEnabled_possible;
/*      */     }
/*      */     
/*      */     private Possible<Optional<Id>> widgetChannelId_build() {
/* 7659 */       return this.widgetChannelId_possible;
/*      */     }
/*      */     
/*      */     private Optional<Id> systemChannelId_build() {
/* 7663 */       return this.systemChannelId_optional;
/*      */     }
/*      */     
/*      */     private Optional<Id> rulesChannelId_build() {
/* 7667 */       return this.rulesChannelId_optional;
/*      */     }
/*      */     
/*      */     private Possible<Optional<Integer>> maxPresences_build() {
/* 7671 */       return this.maxPresences_possible;
/*      */     }
/*      */     
/*      */     private Possible<Integer> maxMembers_build() {
/* 7675 */       return this.maxMembers_possible;
/*      */     }
/*      */     
/*      */     private Possible<Integer> premiumSubscriptionCount_build() {
/* 7679 */       return this.premiumSubscriptionCount_possible;
/*      */     }
/*      */     
/*      */     private Optional<Id> publicUpdatesChannelId_build() {
/* 7683 */       return this.publicUpdatesChannelId_optional;
/*      */     }
/*      */     
/*      */     private Possible<Integer> maxVideoChannelUsers_build() {
/* 7687 */       return this.maxVideoChannelUsers_possible;
/*      */     }
/*      */     
/*      */     private Possible<Integer> approximateMemberCount_build() {
/* 7691 */       return this.approximateMemberCount_possible;
/*      */     }
/*      */     
/*      */     private Possible<Integer> approximatePresenceCount_build() {
/* 7695 */       return this.approximatePresenceCount_possible;
/*      */     }
/*      */     
/*      */     private Possible<WelcomeScreenData> welcomeScreen_build() {
/* 7699 */       return this.welcomeScreen_possible;
/*      */     }
/*      */     
/*      */     private Possible<Boolean> nsfw_build() {
/* 7703 */       return this.nsfw_possible;
/*      */     }
/*      */     
/*      */     private Optional<Id> safetyAlertsChannelId_build() {
/* 7707 */       return this.safetyAlertsChannelId_optional;
/*      */     }
/*      */     
/*      */     private Id ownerId_build() {
/* 7711 */       return this.ownerId_id;
/*      */     }
/*      */     
/*      */     private Possible<Optional<String>> region_build() {
/* 7715 */       return this.region_possible;
/*      */     }
/*      */     
/*      */     private Possible<List<StickerData>> stickers_build() {
/* 7719 */       return (this.stickers_list == null) ? Possible.absent() : 
/* 7720 */         Possible.of(this.stickers_list);
/*      */     }
/*      */     
/*      */     private List<StickerData> stickers_getOrCreate() {
/* 7724 */       if (this.stickers_list == null) {
/* 7725 */         this.stickers_list = new ArrayList<>();
/*      */       }
/* 7727 */       return this.stickers_list;
/*      */     }
/*      */     private Builder() {} }
/*      */   
/*      */   private static <T> List<T> createSafeList(Iterable<? extends T> iterable, boolean checkNulls, boolean skipNulls) {
/*      */     ArrayList<T> list;
/* 7733 */     if (iterable instanceof Collection) {
/* 7734 */       int size = ((Collection)iterable).size();
/* 7735 */       if (size == 0) return Collections.emptyList(); 
/* 7736 */       list = new ArrayList<>();
/*      */     } else {
/* 7738 */       list = new ArrayList<>();
/*      */     } 
/* 7740 */     for (T element : iterable) {
/* 7741 */       if (skipNulls && element == null)
/* 7742 */         continue;  if (checkNulls) Objects.requireNonNull(element, "element"); 
/* 7743 */       list.add(element);
/*      */     } 
/* 7745 */     return list;
/*      */   }
/*      */   
/*      */   private static <T> List<T> createUnmodifiableList(boolean clone, List<T> list) {
/* 7749 */     switch (list.size()) { case 0:
/* 7750 */         return Collections.emptyList();
/* 7751 */       case 1: return Collections.singletonList(list.get(0)); }
/*      */     
/* 7753 */     if (clone) {
/* 7754 */       return Collections.unmodifiableList(new ArrayList<>(list));
/*      */     }
/* 7756 */     if (list instanceof ArrayList) {
/* 7757 */       ((ArrayList)list).trimToSize();
/*      */     }
/* 7759 */     return Collections.unmodifiableList(list);
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableGuildUpdateData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */