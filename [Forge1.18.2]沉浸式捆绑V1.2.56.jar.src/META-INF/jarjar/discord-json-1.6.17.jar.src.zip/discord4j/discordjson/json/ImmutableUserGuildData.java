/*      */ package discord4j.discordjson.json;
/*      */ 
/*      */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*      */ import com.fasterxml.jackson.annotation.JsonCreator;
/*      */ import com.fasterxml.jackson.annotation.JsonProperty;
/*      */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*      */ import discord4j.discordjson.Id;
/*      */ import discord4j.discordjson.possible.Possible;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.List;
/*      */ import java.util.Objects;
/*      */ import java.util.Optional;
/*      */ import java.util.OptionalInt;
/*      */ import org.immutables.value.Generated;
/*      */ import reactor.util.annotation.Nullable;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ @Generated(from = "UserGuildData", generator = "Immutables")
/*      */ public final class ImmutableUserGuildData
/*      */   implements UserGuildData
/*      */ {
/*      */   private final long id_value;
/*      */   private final String name;
/*      */   private final String icon;
/*      */   private final String splash;
/*      */   private final String discoverySplash;
/*      */   private final Boolean owner_value;
/*      */   private final boolean owner_absent;
/*      */   private final Long permissions_value;
/*      */   private final boolean permissions_absent;
/*      */   private final long afkChannelId_value;
/*      */   private final boolean afkChannelId_present;
/*      */   private final Boolean embedEnabled_value;
/*      */   private final boolean embedEnabled_absent;
/*      */   private final long embedChannelId_value;
/*      */   private final boolean embedChannelId_absent;
/*      */   private final boolean embedChannelId_isNull;
/*      */   private final List<String> features;
/*      */   private final long applicationId_value;
/*      */   private final boolean applicationId_present;
/*      */   private final Boolean widgetEnabled_value;
/*      */   private final boolean widgetEnabled_absent;
/*      */   private final long widgetChannelId_value;
/*      */   private final boolean widgetChannelId_absent;
/*      */   private final boolean widgetChannelId_isNull;
/*      */   private final long systemChannelId_value;
/*      */   private final boolean systemChannelId_present;
/*      */   private final Integer systemChannelFlags;
/*      */   private final long rulesChannelId_value;
/*      */   private final boolean rulesChannelId_present;
/*      */   private final Integer maxPresences_value;
/*      */   private final boolean maxPresences_absent;
/*      */   private final Integer maxMembers_value;
/*      */   private final boolean maxMembers_absent;
/*      */   private final String vanityUrlCode;
/*      */   private final String description;
/*      */   private final String banner;
/*      */   private final Integer premiumSubscriptionCount_value;
/*      */   private final boolean premiumSubscriptionCount_absent;
/*      */   private final long publicUpdatesChannelId_value;
/*      */   private final boolean publicUpdatesChannelId_present;
/*      */   private final Integer maxVideoChannelUsers_value;
/*      */   private final boolean maxVideoChannelUsers_absent;
/*      */   private final Integer approximateMemberCount_value;
/*      */   private final boolean approximateMemberCount_absent;
/*      */   private final Integer approximatePresenceCount_value;
/*      */   private final boolean approximatePresenceCount_absent;
/*      */   private final WelcomeScreenData welcomeScreen_value;
/*      */   private final boolean welcomeScreen_absent;
/*      */   private final Boolean nsfw_value;
/*      */   private final boolean nsfw_absent;
/*      */   private final long safetyAlertsChannelId_value;
/*      */   private final boolean safetyAlertsChannelId_present;
/*      */   private static final byte STAGE_INITIALIZING = -1;
/*      */   private static final byte STAGE_UNINITIALIZED = 0;
/*      */   private static final byte STAGE_INITIALIZED = 1;
/*      */   
/*      */   private ImmutableUserGuildData(Id id, String name, Optional<String> icon, Optional<String> splash, Optional<String> discoverySplash, Possible<Boolean> owner, Possible<Long> permissions, Optional<Id> afkChannelId, Possible<Boolean> embedEnabled, Possible<Optional<Id>> embedChannelId, Iterable<String> features, Optional<Id> applicationId, Possible<Boolean> widgetEnabled, Possible<Optional<Id>> widgetChannelId, Optional<Id> systemChannelId, OptionalInt systemChannelFlags, Optional<Id> rulesChannelId, Possible<Optional<Integer>> maxPresences, Possible<Integer> maxMembers, Optional<String> vanityUrlCode, Optional<String> description, Optional<String> banner, Possible<Integer> premiumSubscriptionCount, Optional<Id> publicUpdatesChannelId, Possible<Integer> maxVideoChannelUsers, Possible<Integer> approximateMemberCount, Possible<Integer> approximatePresenceCount, Possible<WelcomeScreenData> welcomeScreen, Possible<Boolean> nsfw, Optional<Id> safetyAlertsChannelId) {
/*  116 */     Id id$impl = id;
/*  117 */     this.name = Objects.<String>requireNonNull(name, "name");
/*  118 */     this.icon = icon.orElse(null);
/*  119 */     this.splash = splash.orElse(null);
/*  120 */     this.discoverySplash = discoverySplash.orElse(null);
/*  121 */     Possible<Boolean> owner$impl = owner;
/*  122 */     Possible<Long> permissions$impl = permissions;
/*  123 */     Optional<Id> afkChannelId$impl = afkChannelId;
/*  124 */     Possible<Boolean> embedEnabled$impl = embedEnabled;
/*  125 */     Possible<Optional<Id>> embedChannelId$impl = embedChannelId;
/*  126 */     this.features = createUnmodifiableList(false, createSafeList(features, true, false));
/*  127 */     Optional<Id> applicationId$impl = applicationId;
/*  128 */     Possible<Boolean> widgetEnabled$impl = widgetEnabled;
/*  129 */     Possible<Optional<Id>> widgetChannelId$impl = widgetChannelId;
/*  130 */     Optional<Id> systemChannelId$impl = systemChannelId;
/*  131 */     this.systemChannelFlags = systemChannelFlags.isPresent() ? Integer.valueOf(systemChannelFlags.getAsInt()) : null;
/*  132 */     Optional<Id> rulesChannelId$impl = rulesChannelId;
/*  133 */     Possible<Optional<Integer>> maxPresences$impl = maxPresences;
/*  134 */     Possible<Integer> maxMembers$impl = maxMembers;
/*  135 */     this.vanityUrlCode = vanityUrlCode.orElse(null);
/*  136 */     this.description = description.orElse(null);
/*  137 */     this.banner = banner.orElse(null);
/*  138 */     Possible<Integer> premiumSubscriptionCount$impl = premiumSubscriptionCount;
/*  139 */     Optional<Id> publicUpdatesChannelId$impl = publicUpdatesChannelId;
/*  140 */     Possible<Integer> maxVideoChannelUsers$impl = maxVideoChannelUsers;
/*  141 */     Possible<Integer> approximateMemberCount$impl = approximateMemberCount;
/*  142 */     Possible<Integer> approximatePresenceCount$impl = approximatePresenceCount;
/*  143 */     Possible<WelcomeScreenData> welcomeScreen$impl = welcomeScreen;
/*  144 */     Possible<Boolean> nsfw$impl = nsfw;
/*  145 */     Optional<Id> safetyAlertsChannelId$impl = safetyAlertsChannelId;
/*  146 */     this.id_value = id$impl.asLong();
/*  147 */     this.owner_value = owner$impl.toOptional().orElse(null);
/*  148 */     this.owner_absent = owner$impl.isAbsent();
/*  149 */     this.permissions_value = permissions$impl.toOptional().orElse(null);
/*  150 */     this.permissions_absent = permissions$impl.isAbsent();
/*  151 */     this
/*      */       
/*  153 */       .afkChannelId_value = ((Long)afkChannelId$impl.<Long>map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  154 */     this.afkChannelId_present = afkChannelId$impl.isPresent();
/*  155 */     this.embedEnabled_value = embedEnabled$impl.toOptional().orElse(null);
/*  156 */     this.embedEnabled_absent = embedEnabled$impl.isAbsent();
/*  157 */     this
/*      */       
/*  159 */       .embedChannelId_value = ((Long)Possible.flatOpt(embedChannelId$impl).map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  160 */     this.embedChannelId_absent = embedChannelId$impl.isAbsent();
/*  161 */     this.embedChannelId_isNull = (!embedChannelId$impl.isAbsent() && !((Optional)embedChannelId$impl.get()).isPresent());
/*  162 */     this
/*      */       
/*  164 */       .applicationId_value = ((Long)applicationId$impl.<Long>map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  165 */     this.applicationId_present = applicationId$impl.isPresent();
/*  166 */     this.widgetEnabled_value = widgetEnabled$impl.toOptional().orElse(null);
/*  167 */     this.widgetEnabled_absent = widgetEnabled$impl.isAbsent();
/*  168 */     this
/*      */       
/*  170 */       .widgetChannelId_value = ((Long)Possible.flatOpt(widgetChannelId$impl).map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  171 */     this.widgetChannelId_absent = widgetChannelId$impl.isAbsent();
/*  172 */     this.widgetChannelId_isNull = (!widgetChannelId$impl.isAbsent() && !((Optional)widgetChannelId$impl.get()).isPresent());
/*  173 */     this
/*      */       
/*  175 */       .systemChannelId_value = ((Long)systemChannelId$impl.<Long>map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  176 */     this.systemChannelId_present = systemChannelId$impl.isPresent();
/*  177 */     this
/*      */       
/*  179 */       .rulesChannelId_value = ((Long)rulesChannelId$impl.<Long>map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  180 */     this.rulesChannelId_present = rulesChannelId$impl.isPresent();
/*  181 */     this.maxPresences_value = Possible.flatOpt(maxPresences$impl).orElse(null);
/*  182 */     this.maxPresences_absent = maxPresences$impl.isAbsent();
/*  183 */     this.maxMembers_value = maxMembers$impl.toOptional().orElse(null);
/*  184 */     this.maxMembers_absent = maxMembers$impl.isAbsent();
/*  185 */     this.premiumSubscriptionCount_value = premiumSubscriptionCount$impl.toOptional().orElse(null);
/*  186 */     this.premiumSubscriptionCount_absent = premiumSubscriptionCount$impl.isAbsent();
/*  187 */     this
/*      */       
/*  189 */       .publicUpdatesChannelId_value = ((Long)publicUpdatesChannelId$impl.<Long>map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  190 */     this.publicUpdatesChannelId_present = publicUpdatesChannelId$impl.isPresent();
/*  191 */     this.maxVideoChannelUsers_value = maxVideoChannelUsers$impl.toOptional().orElse(null);
/*  192 */     this.maxVideoChannelUsers_absent = maxVideoChannelUsers$impl.isAbsent();
/*  193 */     this.approximateMemberCount_value = approximateMemberCount$impl.toOptional().orElse(null);
/*  194 */     this.approximateMemberCount_absent = approximateMemberCount$impl.isAbsent();
/*  195 */     this.approximatePresenceCount_value = approximatePresenceCount$impl.toOptional().orElse(null);
/*  196 */     this.approximatePresenceCount_absent = approximatePresenceCount$impl.isAbsent();
/*  197 */     this.welcomeScreen_value = welcomeScreen$impl.toOptional().orElse(null);
/*  198 */     this.welcomeScreen_absent = welcomeScreen$impl.isAbsent();
/*  199 */     this.nsfw_value = nsfw$impl.toOptional().orElse(null);
/*  200 */     this.nsfw_absent = nsfw$impl.isAbsent();
/*  201 */     this
/*      */       
/*  203 */       .safetyAlertsChannelId_value = ((Long)safetyAlertsChannelId$impl.<Long>map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  204 */     this.safetyAlertsChannelId_present = safetyAlertsChannelId$impl.isPresent();
/*  205 */     this.initShim = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ImmutableUserGuildData(ImmutableUserGuildData original, Id id, String name, String icon, String splash, String discoverySplash, Possible<Boolean> owner, Possible<Long> permissions, Optional<Id> afkChannelId, Possible<Boolean> embedEnabled, Possible<Optional<Id>> embedChannelId, List<String> features, Optional<Id> applicationId, Possible<Boolean> widgetEnabled, Possible<Optional<Id>> widgetChannelId, Optional<Id> systemChannelId, Integer systemChannelFlags, Optional<Id> rulesChannelId, Possible<Optional<Integer>> maxPresences, Possible<Integer> maxMembers, String vanityUrlCode, String description, String banner, Possible<Integer> premiumSubscriptionCount, Optional<Id> publicUpdatesChannelId, Possible<Integer> maxVideoChannelUsers, Possible<Integer> approximateMemberCount, Possible<Integer> approximatePresenceCount, Possible<WelcomeScreenData> welcomeScreen, Possible<Boolean> nsfw, Optional<Id> safetyAlertsChannelId) {
/*  240 */     Id id$impl = id;
/*  241 */     this.name = name;
/*  242 */     this.icon = icon;
/*  243 */     this.splash = splash;
/*  244 */     this.discoverySplash = discoverySplash;
/*  245 */     Possible<Boolean> owner$impl = owner;
/*  246 */     Possible<Long> permissions$impl = permissions;
/*  247 */     Optional<Id> afkChannelId$impl = afkChannelId;
/*  248 */     Possible<Boolean> embedEnabled$impl = embedEnabled;
/*  249 */     Possible<Optional<Id>> embedChannelId$impl = embedChannelId;
/*  250 */     this.features = features;
/*  251 */     Optional<Id> applicationId$impl = applicationId;
/*  252 */     Possible<Boolean> widgetEnabled$impl = widgetEnabled;
/*  253 */     Possible<Optional<Id>> widgetChannelId$impl = widgetChannelId;
/*  254 */     Optional<Id> systemChannelId$impl = systemChannelId;
/*  255 */     this.systemChannelFlags = systemChannelFlags;
/*  256 */     Optional<Id> rulesChannelId$impl = rulesChannelId;
/*  257 */     Possible<Optional<Integer>> maxPresences$impl = maxPresences;
/*  258 */     Possible<Integer> maxMembers$impl = maxMembers;
/*  259 */     this.vanityUrlCode = vanityUrlCode;
/*  260 */     this.description = description;
/*  261 */     this.banner = banner;
/*  262 */     Possible<Integer> premiumSubscriptionCount$impl = premiumSubscriptionCount;
/*  263 */     Optional<Id> publicUpdatesChannelId$impl = publicUpdatesChannelId;
/*  264 */     Possible<Integer> maxVideoChannelUsers$impl = maxVideoChannelUsers;
/*  265 */     Possible<Integer> approximateMemberCount$impl = approximateMemberCount;
/*  266 */     Possible<Integer> approximatePresenceCount$impl = approximatePresenceCount;
/*  267 */     Possible<WelcomeScreenData> welcomeScreen$impl = welcomeScreen;
/*  268 */     Possible<Boolean> nsfw$impl = nsfw;
/*  269 */     Optional<Id> safetyAlertsChannelId$impl = safetyAlertsChannelId;
/*  270 */     this.id_value = id$impl.asLong();
/*  271 */     this.owner_value = owner$impl.toOptional().orElse(null);
/*  272 */     this.owner_absent = owner$impl.isAbsent();
/*  273 */     this.permissions_value = permissions$impl.toOptional().orElse(null);
/*  274 */     this.permissions_absent = permissions$impl.isAbsent();
/*  275 */     this
/*      */       
/*  277 */       .afkChannelId_value = ((Long)afkChannelId$impl.<Long>map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  278 */     this.afkChannelId_present = afkChannelId$impl.isPresent();
/*  279 */     this.embedEnabled_value = embedEnabled$impl.toOptional().orElse(null);
/*  280 */     this.embedEnabled_absent = embedEnabled$impl.isAbsent();
/*  281 */     this
/*      */       
/*  283 */       .embedChannelId_value = ((Long)Possible.flatOpt(embedChannelId$impl).map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  284 */     this.embedChannelId_absent = embedChannelId$impl.isAbsent();
/*  285 */     this.embedChannelId_isNull = (!embedChannelId$impl.isAbsent() && !((Optional)embedChannelId$impl.get()).isPresent());
/*  286 */     this
/*      */       
/*  288 */       .applicationId_value = ((Long)applicationId$impl.<Long>map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  289 */     this.applicationId_present = applicationId$impl.isPresent();
/*  290 */     this.widgetEnabled_value = widgetEnabled$impl.toOptional().orElse(null);
/*  291 */     this.widgetEnabled_absent = widgetEnabled$impl.isAbsent();
/*  292 */     this
/*      */       
/*  294 */       .widgetChannelId_value = ((Long)Possible.flatOpt(widgetChannelId$impl).map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  295 */     this.widgetChannelId_absent = widgetChannelId$impl.isAbsent();
/*  296 */     this.widgetChannelId_isNull = (!widgetChannelId$impl.isAbsent() && !((Optional)widgetChannelId$impl.get()).isPresent());
/*  297 */     this
/*      */       
/*  299 */       .systemChannelId_value = ((Long)systemChannelId$impl.<Long>map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  300 */     this.systemChannelId_present = systemChannelId$impl.isPresent();
/*  301 */     this
/*      */       
/*  303 */       .rulesChannelId_value = ((Long)rulesChannelId$impl.<Long>map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  304 */     this.rulesChannelId_present = rulesChannelId$impl.isPresent();
/*  305 */     this.maxPresences_value = Possible.flatOpt(maxPresences$impl).orElse(null);
/*  306 */     this.maxPresences_absent = maxPresences$impl.isAbsent();
/*  307 */     this.maxMembers_value = maxMembers$impl.toOptional().orElse(null);
/*  308 */     this.maxMembers_absent = maxMembers$impl.isAbsent();
/*  309 */     this.premiumSubscriptionCount_value = premiumSubscriptionCount$impl.toOptional().orElse(null);
/*  310 */     this.premiumSubscriptionCount_absent = premiumSubscriptionCount$impl.isAbsent();
/*  311 */     this
/*      */       
/*  313 */       .publicUpdatesChannelId_value = ((Long)publicUpdatesChannelId$impl.<Long>map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  314 */     this.publicUpdatesChannelId_present = publicUpdatesChannelId$impl.isPresent();
/*  315 */     this.maxVideoChannelUsers_value = maxVideoChannelUsers$impl.toOptional().orElse(null);
/*  316 */     this.maxVideoChannelUsers_absent = maxVideoChannelUsers$impl.isAbsent();
/*  317 */     this.approximateMemberCount_value = approximateMemberCount$impl.toOptional().orElse(null);
/*  318 */     this.approximateMemberCount_absent = approximateMemberCount$impl.isAbsent();
/*  319 */     this.approximatePresenceCount_value = approximatePresenceCount$impl.toOptional().orElse(null);
/*  320 */     this.approximatePresenceCount_absent = approximatePresenceCount$impl.isAbsent();
/*  321 */     this.welcomeScreen_value = welcomeScreen$impl.toOptional().orElse(null);
/*  322 */     this.welcomeScreen_absent = welcomeScreen$impl.isAbsent();
/*  323 */     this.nsfw_value = nsfw$impl.toOptional().orElse(null);
/*  324 */     this.nsfw_absent = nsfw$impl.isAbsent();
/*  325 */     this
/*      */       
/*  327 */       .safetyAlertsChannelId_value = ((Long)safetyAlertsChannelId$impl.<Long>map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  328 */     this.safetyAlertsChannelId_present = safetyAlertsChannelId$impl.isPresent();
/*  329 */     this.initShim = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  335 */   private volatile transient InitShim initShim = new InitShim();
/*      */   
/*      */   @Generated(from = "UserGuildData", generator = "Immutables")
/*      */   private final class InitShim {
/*      */     private String formatInitCycleMessage() {
/*  340 */       List<String> attributes = new ArrayList<>();
/*  341 */       return "Cannot build UserGuildData, attribute initializers form cycle " + attributes;
/*      */     }
/*      */ 
/*      */     
/*      */     private InitShim() {}
/*      */   }
/*      */ 
/*      */   
/*      */   @JsonProperty("id")
/*      */   public Id id() {
/*  351 */     return Id.of(this.id_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("name")
/*      */   public String name() {
/*  360 */     return this.name;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("icon")
/*      */   public Optional<String> icon() {
/*  369 */     return Optional.ofNullable(this.icon);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("splash")
/*      */   public Optional<String> splash() {
/*  378 */     return Optional.ofNullable(this.splash);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("discovery_splash")
/*      */   public Optional<String> discoverySplash() {
/*  387 */     return Optional.ofNullable(this.discoverySplash);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("owner")
/*      */   public Possible<Boolean> owner() {
/*  396 */     return this.owner_absent ? Possible.absent() : Possible.of(this.owner_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("permissions")
/*      */   public Possible<Long> permissions() {
/*  405 */     return this.permissions_absent ? Possible.absent() : Possible.of(this.permissions_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("afk_channel_id")
/*      */   public Optional<Id> afkChannelId() {
/*  414 */     return this.afkChannelId_present ? Optional.<Id>of(Id.of(this.afkChannelId_value)) : Optional.<Id>empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("embed_enabled")
/*      */   @Deprecated
/*      */   public Possible<Boolean> embedEnabled() {
/*  424 */     return this.embedEnabled_absent ? Possible.absent() : Possible.of(this.embedEnabled_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("embed_channel_id")
/*      */   @Deprecated
/*      */   public Possible<Optional<Id>> embedChannelId() {
/*  434 */     if (this.embedChannelId_absent)
/*  435 */       return Possible.absent(); 
/*  436 */     if (this.embedChannelId_isNull) {
/*  437 */       return Possible.of(Optional.empty());
/*      */     }
/*  439 */     return Possible.of(Optional.of(Id.of(this.embedChannelId_value)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("features")
/*      */   public List<String> features() {
/*  449 */     return this.features;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("application_id")
/*      */   public Optional<Id> applicationId() {
/*  458 */     return this.applicationId_present ? Optional.<Id>of(Id.of(this.applicationId_value)) : Optional.<Id>empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("widget_enabled")
/*      */   public Possible<Boolean> widgetEnabled() {
/*  467 */     return this.widgetEnabled_absent ? Possible.absent() : Possible.of(this.widgetEnabled_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("widget_channel_id")
/*      */   public Possible<Optional<Id>> widgetChannelId() {
/*  476 */     if (this.widgetChannelId_absent)
/*  477 */       return Possible.absent(); 
/*  478 */     if (this.widgetChannelId_isNull) {
/*  479 */       return Possible.of(Optional.empty());
/*      */     }
/*  481 */     return Possible.of(Optional.of(Id.of(this.widgetChannelId_value)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("system_channel_id")
/*      */   public Optional<Id> systemChannelId() {
/*  491 */     return this.systemChannelId_present ? Optional.<Id>of(Id.of(this.systemChannelId_value)) : Optional.<Id>empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("system_channel_flags")
/*      */   public OptionalInt systemChannelFlags() {
/*  500 */     return (this.systemChannelFlags != null) ? 
/*  501 */       OptionalInt.of(this.systemChannelFlags.intValue()) : 
/*  502 */       OptionalInt.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("rules_channel_id")
/*      */   public Optional<Id> rulesChannelId() {
/*  511 */     return this.rulesChannelId_present ? Optional.<Id>of(Id.of(this.rulesChannelId_value)) : Optional.<Id>empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("max_presences")
/*      */   public Possible<Optional<Integer>> maxPresences() {
/*  520 */     return this.maxPresences_absent ? Possible.absent() : 
/*  521 */       Possible.of(Optional.ofNullable(this.maxPresences_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("max_members")
/*      */   public Possible<Integer> maxMembers() {
/*  530 */     return this.maxMembers_absent ? Possible.absent() : Possible.of(this.maxMembers_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("vanity_url_code")
/*      */   public Optional<String> vanityUrlCode() {
/*  539 */     return Optional.ofNullable(this.vanityUrlCode);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("description")
/*      */   public Optional<String> description() {
/*  548 */     return Optional.ofNullable(this.description);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("banner")
/*      */   public Optional<String> banner() {
/*  557 */     return Optional.ofNullable(this.banner);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("premium_subscription_count")
/*      */   public Possible<Integer> premiumSubscriptionCount() {
/*  566 */     return this.premiumSubscriptionCount_absent ? Possible.absent() : Possible.of(this.premiumSubscriptionCount_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("public_updates_channel_id")
/*      */   public Optional<Id> publicUpdatesChannelId() {
/*  575 */     return this.publicUpdatesChannelId_present ? Optional.<Id>of(Id.of(this.publicUpdatesChannelId_value)) : Optional.<Id>empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("max_video_channel_users")
/*      */   public Possible<Integer> maxVideoChannelUsers() {
/*  584 */     return this.maxVideoChannelUsers_absent ? Possible.absent() : Possible.of(this.maxVideoChannelUsers_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("approximate_member_count")
/*      */   public Possible<Integer> approximateMemberCount() {
/*  593 */     return this.approximateMemberCount_absent ? Possible.absent() : Possible.of(this.approximateMemberCount_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("approximate_presence_count")
/*      */   public Possible<Integer> approximatePresenceCount() {
/*  602 */     return this.approximatePresenceCount_absent ? Possible.absent() : Possible.of(this.approximatePresenceCount_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("welcome_screen")
/*      */   public Possible<WelcomeScreenData> welcomeScreen() {
/*  611 */     return this.welcomeScreen_absent ? Possible.absent() : Possible.of(this.welcomeScreen_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("nsfw")
/*      */   @Deprecated
/*      */   public Possible<Boolean> nsfw() {
/*  621 */     return this.nsfw_absent ? Possible.absent() : Possible.of(this.nsfw_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("safety_alerts_channel_id")
/*      */   public Optional<Id> safetyAlertsChannelId() {
/*  630 */     return this.safetyAlertsChannelId_present ? Optional.<Id>of(Id.of(this.safetyAlertsChannelId_value)) : Optional.<Id>empty();
/*      */   }
/*      */   
/*      */   public ImmutableUserGuildData withId(long value) {
/*  634 */     Id newValue = Id.of(value);
/*  635 */     return new ImmutableUserGuildData(this, newValue, this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  642 */         owner(), 
/*  643 */         permissions(), 
/*  644 */         afkChannelId(), 
/*  645 */         embedEnabled(), 
/*  646 */         embedChannelId(), this.features, 
/*      */         
/*  648 */         applicationId(), 
/*  649 */         widgetEnabled(), 
/*  650 */         widgetChannelId(), 
/*  651 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/*  653 */         rulesChannelId(), 
/*  654 */         maxPresences(), 
/*  655 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/*  659 */         premiumSubscriptionCount(), 
/*  660 */         publicUpdatesChannelId(), 
/*  661 */         maxVideoChannelUsers(), 
/*  662 */         approximateMemberCount(), 
/*  663 */         approximatePresenceCount(), 
/*  664 */         welcomeScreen(), 
/*  665 */         nsfw(), 
/*  666 */         safetyAlertsChannelId());
/*      */   }
/*      */   
/*      */   public ImmutableUserGuildData withId(String value) {
/*  670 */     Id newValue = Id.of(value);
/*  671 */     return new ImmutableUserGuildData(this, newValue, this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  678 */         owner(), 
/*  679 */         permissions(), 
/*  680 */         afkChannelId(), 
/*  681 */         embedEnabled(), 
/*  682 */         embedChannelId(), this.features, 
/*      */         
/*  684 */         applicationId(), 
/*  685 */         widgetEnabled(), 
/*  686 */         widgetChannelId(), 
/*  687 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/*  689 */         rulesChannelId(), 
/*  690 */         maxPresences(), 
/*  691 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/*  695 */         premiumSubscriptionCount(), 
/*  696 */         publicUpdatesChannelId(), 
/*  697 */         maxVideoChannelUsers(), 
/*  698 */         approximateMemberCount(), 
/*  699 */         approximatePresenceCount(), 
/*  700 */         welcomeScreen(), 
/*  701 */         nsfw(), 
/*  702 */         safetyAlertsChannelId());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableUserGuildData withName(String value) {
/*  712 */     String newValue = Objects.<String>requireNonNull(value, "name");
/*  713 */     if (this.name.equals(newValue)) return this; 
/*  714 */     return new ImmutableUserGuildData(this, 
/*      */         
/*  716 */         id(), newValue, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  721 */         owner(), 
/*  722 */         permissions(), 
/*  723 */         afkChannelId(), 
/*  724 */         embedEnabled(), 
/*  725 */         embedChannelId(), this.features, 
/*      */         
/*  727 */         applicationId(), 
/*  728 */         widgetEnabled(), 
/*  729 */         widgetChannelId(), 
/*  730 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/*  732 */         rulesChannelId(), 
/*  733 */         maxPresences(), 
/*  734 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/*  738 */         premiumSubscriptionCount(), 
/*  739 */         publicUpdatesChannelId(), 
/*  740 */         maxVideoChannelUsers(), 
/*  741 */         approximateMemberCount(), 
/*  742 */         approximatePresenceCount(), 
/*  743 */         welcomeScreen(), 
/*  744 */         nsfw(), 
/*  745 */         safetyAlertsChannelId());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableUserGuildData withIcon(String value) {
/*  754 */     String newValue = Objects.<String>requireNonNull(value, "icon");
/*  755 */     if (Objects.equals(this.icon, newValue)) return this; 
/*  756 */     return new ImmutableUserGuildData(this, 
/*      */         
/*  758 */         id(), this.name, newValue, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  763 */         owner(), 
/*  764 */         permissions(), 
/*  765 */         afkChannelId(), 
/*  766 */         embedEnabled(), 
/*  767 */         embedChannelId(), this.features, 
/*      */         
/*  769 */         applicationId(), 
/*  770 */         widgetEnabled(), 
/*  771 */         widgetChannelId(), 
/*  772 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/*  774 */         rulesChannelId(), 
/*  775 */         maxPresences(), 
/*  776 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/*  780 */         premiumSubscriptionCount(), 
/*  781 */         publicUpdatesChannelId(), 
/*  782 */         maxVideoChannelUsers(), 
/*  783 */         approximateMemberCount(), 
/*  784 */         approximatePresenceCount(), 
/*  785 */         welcomeScreen(), 
/*  786 */         nsfw(), 
/*  787 */         safetyAlertsChannelId());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableUserGuildData withIcon(Optional<String> optional) {
/*  797 */     String value = optional.orElse(null);
/*  798 */     if (Objects.equals(this.icon, value)) return this; 
/*  799 */     return new ImmutableUserGuildData(this, 
/*      */         
/*  801 */         id(), this.name, value, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  806 */         owner(), 
/*  807 */         permissions(), 
/*  808 */         afkChannelId(), 
/*  809 */         embedEnabled(), 
/*  810 */         embedChannelId(), this.features, 
/*      */         
/*  812 */         applicationId(), 
/*  813 */         widgetEnabled(), 
/*  814 */         widgetChannelId(), 
/*  815 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/*  817 */         rulesChannelId(), 
/*  818 */         maxPresences(), 
/*  819 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/*  823 */         premiumSubscriptionCount(), 
/*  824 */         publicUpdatesChannelId(), 
/*  825 */         maxVideoChannelUsers(), 
/*  826 */         approximateMemberCount(), 
/*  827 */         approximatePresenceCount(), 
/*  828 */         welcomeScreen(), 
/*  829 */         nsfw(), 
/*  830 */         safetyAlertsChannelId());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableUserGuildData withSplash(String value) {
/*  839 */     String newValue = Objects.<String>requireNonNull(value, "splash");
/*  840 */     if (Objects.equals(this.splash, newValue)) return this; 
/*  841 */     return new ImmutableUserGuildData(this, 
/*      */         
/*  843 */         id(), this.name, this.icon, newValue, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  848 */         owner(), 
/*  849 */         permissions(), 
/*  850 */         afkChannelId(), 
/*  851 */         embedEnabled(), 
/*  852 */         embedChannelId(), this.features, 
/*      */         
/*  854 */         applicationId(), 
/*  855 */         widgetEnabled(), 
/*  856 */         widgetChannelId(), 
/*  857 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/*  859 */         rulesChannelId(), 
/*  860 */         maxPresences(), 
/*  861 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/*  865 */         premiumSubscriptionCount(), 
/*  866 */         publicUpdatesChannelId(), 
/*  867 */         maxVideoChannelUsers(), 
/*  868 */         approximateMemberCount(), 
/*  869 */         approximatePresenceCount(), 
/*  870 */         welcomeScreen(), 
/*  871 */         nsfw(), 
/*  872 */         safetyAlertsChannelId());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableUserGuildData withSplash(Optional<String> optional) {
/*  882 */     String value = optional.orElse(null);
/*  883 */     if (Objects.equals(this.splash, value)) return this; 
/*  884 */     return new ImmutableUserGuildData(this, 
/*      */         
/*  886 */         id(), this.name, this.icon, value, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  891 */         owner(), 
/*  892 */         permissions(), 
/*  893 */         afkChannelId(), 
/*  894 */         embedEnabled(), 
/*  895 */         embedChannelId(), this.features, 
/*      */         
/*  897 */         applicationId(), 
/*  898 */         widgetEnabled(), 
/*  899 */         widgetChannelId(), 
/*  900 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/*  902 */         rulesChannelId(), 
/*  903 */         maxPresences(), 
/*  904 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/*  908 */         premiumSubscriptionCount(), 
/*  909 */         publicUpdatesChannelId(), 
/*  910 */         maxVideoChannelUsers(), 
/*  911 */         approximateMemberCount(), 
/*  912 */         approximatePresenceCount(), 
/*  913 */         welcomeScreen(), 
/*  914 */         nsfw(), 
/*  915 */         safetyAlertsChannelId());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableUserGuildData withDiscoverySplash(String value) {
/*  924 */     String newValue = Objects.<String>requireNonNull(value, "discoverySplash");
/*  925 */     if (Objects.equals(this.discoverySplash, newValue)) return this; 
/*  926 */     return new ImmutableUserGuildData(this, 
/*      */         
/*  928 */         id(), this.name, this.icon, this.splash, newValue, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  933 */         owner(), 
/*  934 */         permissions(), 
/*  935 */         afkChannelId(), 
/*  936 */         embedEnabled(), 
/*  937 */         embedChannelId(), this.features, 
/*      */         
/*  939 */         applicationId(), 
/*  940 */         widgetEnabled(), 
/*  941 */         widgetChannelId(), 
/*  942 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/*  944 */         rulesChannelId(), 
/*  945 */         maxPresences(), 
/*  946 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/*  950 */         premiumSubscriptionCount(), 
/*  951 */         publicUpdatesChannelId(), 
/*  952 */         maxVideoChannelUsers(), 
/*  953 */         approximateMemberCount(), 
/*  954 */         approximatePresenceCount(), 
/*  955 */         welcomeScreen(), 
/*  956 */         nsfw(), 
/*  957 */         safetyAlertsChannelId());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableUserGuildData withDiscoverySplash(Optional<String> optional) {
/*  967 */     String value = optional.orElse(null);
/*  968 */     if (Objects.equals(this.discoverySplash, value)) return this; 
/*  969 */     return new ImmutableUserGuildData(this, 
/*      */         
/*  971 */         id(), this.name, this.icon, this.splash, value, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  976 */         owner(), 
/*  977 */         permissions(), 
/*  978 */         afkChannelId(), 
/*  979 */         embedEnabled(), 
/*  980 */         embedChannelId(), this.features, 
/*      */         
/*  982 */         applicationId(), 
/*  983 */         widgetEnabled(), 
/*  984 */         widgetChannelId(), 
/*  985 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/*  987 */         rulesChannelId(), 
/*  988 */         maxPresences(), 
/*  989 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/*  993 */         premiumSubscriptionCount(), 
/*  994 */         publicUpdatesChannelId(), 
/*  995 */         maxVideoChannelUsers(), 
/*  996 */         approximateMemberCount(), 
/*  997 */         approximatePresenceCount(), 
/*  998 */         welcomeScreen(), 
/*  999 */         nsfw(), 
/* 1000 */         safetyAlertsChannelId());
/*      */   }
/*      */   
/*      */   public ImmutableUserGuildData withOwner(Possible<Boolean> value) {
/* 1004 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/* 1005 */     return new ImmutableUserGuildData(this, 
/*      */         
/* 1007 */         id(), this.name, this.icon, this.splash, this.discoverySplash, newValue, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1013 */         permissions(), 
/* 1014 */         afkChannelId(), 
/* 1015 */         embedEnabled(), 
/* 1016 */         embedChannelId(), this.features, 
/*      */         
/* 1018 */         applicationId(), 
/* 1019 */         widgetEnabled(), 
/* 1020 */         widgetChannelId(), 
/* 1021 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 1023 */         rulesChannelId(), 
/* 1024 */         maxPresences(), 
/* 1025 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1029 */         premiumSubscriptionCount(), 
/* 1030 */         publicUpdatesChannelId(), 
/* 1031 */         maxVideoChannelUsers(), 
/* 1032 */         approximateMemberCount(), 
/* 1033 */         approximatePresenceCount(), 
/* 1034 */         welcomeScreen(), 
/* 1035 */         nsfw(), 
/* 1036 */         safetyAlertsChannelId());
/*      */   }
/*      */   
/*      */   public ImmutableUserGuildData withOwner(Boolean value) {
/* 1040 */     Possible<Boolean> newValue = Possible.of(value);
/* 1041 */     return new ImmutableUserGuildData(this, 
/*      */         
/* 1043 */         id(), this.name, this.icon, this.splash, this.discoverySplash, newValue, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1049 */         permissions(), 
/* 1050 */         afkChannelId(), 
/* 1051 */         embedEnabled(), 
/* 1052 */         embedChannelId(), this.features, 
/*      */         
/* 1054 */         applicationId(), 
/* 1055 */         widgetEnabled(), 
/* 1056 */         widgetChannelId(), 
/* 1057 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 1059 */         rulesChannelId(), 
/* 1060 */         maxPresences(), 
/* 1061 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1065 */         premiumSubscriptionCount(), 
/* 1066 */         publicUpdatesChannelId(), 
/* 1067 */         maxVideoChannelUsers(), 
/* 1068 */         approximateMemberCount(), 
/* 1069 */         approximatePresenceCount(), 
/* 1070 */         welcomeScreen(), 
/* 1071 */         nsfw(), 
/* 1072 */         safetyAlertsChannelId());
/*      */   }
/*      */   
/*      */   public ImmutableUserGuildData withPermissions(Possible<Long> value) {
/* 1076 */     Possible<Long> newValue = Objects.<Possible<Long>>requireNonNull(value);
/* 1077 */     return new ImmutableUserGuildData(this, 
/*      */         
/* 1079 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1084 */         owner(), newValue, 
/*      */         
/* 1086 */         afkChannelId(), 
/* 1087 */         embedEnabled(), 
/* 1088 */         embedChannelId(), this.features, 
/*      */         
/* 1090 */         applicationId(), 
/* 1091 */         widgetEnabled(), 
/* 1092 */         widgetChannelId(), 
/* 1093 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 1095 */         rulesChannelId(), 
/* 1096 */         maxPresences(), 
/* 1097 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1101 */         premiumSubscriptionCount(), 
/* 1102 */         publicUpdatesChannelId(), 
/* 1103 */         maxVideoChannelUsers(), 
/* 1104 */         approximateMemberCount(), 
/* 1105 */         approximatePresenceCount(), 
/* 1106 */         welcomeScreen(), 
/* 1107 */         nsfw(), 
/* 1108 */         safetyAlertsChannelId());
/*      */   }
/*      */   
/*      */   public ImmutableUserGuildData withPermissions(Long value) {
/* 1112 */     Possible<Long> newValue = Possible.of(value);
/* 1113 */     return new ImmutableUserGuildData(this, 
/*      */         
/* 1115 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1120 */         owner(), newValue, 
/*      */         
/* 1122 */         afkChannelId(), 
/* 1123 */         embedEnabled(), 
/* 1124 */         embedChannelId(), this.features, 
/*      */         
/* 1126 */         applicationId(), 
/* 1127 */         widgetEnabled(), 
/* 1128 */         widgetChannelId(), 
/* 1129 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 1131 */         rulesChannelId(), 
/* 1132 */         maxPresences(), 
/* 1133 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1137 */         premiumSubscriptionCount(), 
/* 1138 */         publicUpdatesChannelId(), 
/* 1139 */         maxVideoChannelUsers(), 
/* 1140 */         approximateMemberCount(), 
/* 1141 */         approximatePresenceCount(), 
/* 1142 */         welcomeScreen(), 
/* 1143 */         nsfw(), 
/* 1144 */         safetyAlertsChannelId());
/*      */   }
/*      */   
/*      */   public ImmutableUserGuildData withAfkChannelId(Optional<Id> value) {
/* 1148 */     Optional<Id> newValue = Objects.<Optional<Id>>requireNonNull(value);
/* 1149 */     return new ImmutableUserGuildData(this, 
/*      */         
/* 1151 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1156 */         owner(), 
/* 1157 */         permissions(), newValue, 
/*      */         
/* 1159 */         embedEnabled(), 
/* 1160 */         embedChannelId(), this.features, 
/*      */         
/* 1162 */         applicationId(), 
/* 1163 */         widgetEnabled(), 
/* 1164 */         widgetChannelId(), 
/* 1165 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 1167 */         rulesChannelId(), 
/* 1168 */         maxPresences(), 
/* 1169 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1173 */         premiumSubscriptionCount(), 
/* 1174 */         publicUpdatesChannelId(), 
/* 1175 */         maxVideoChannelUsers(), 
/* 1176 */         approximateMemberCount(), 
/* 1177 */         approximatePresenceCount(), 
/* 1178 */         welcomeScreen(), 
/* 1179 */         nsfw(), 
/* 1180 */         safetyAlertsChannelId());
/*      */   }
/*      */   
/*      */   public ImmutableUserGuildData withAfkChannelId(long value) {
/* 1184 */     Optional<Id> newValue = Optional.of(Id.of(value));
/* 1185 */     return new ImmutableUserGuildData(this, 
/*      */         
/* 1187 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1192 */         owner(), 
/* 1193 */         permissions(), newValue, 
/*      */         
/* 1195 */         embedEnabled(), 
/* 1196 */         embedChannelId(), this.features, 
/*      */         
/* 1198 */         applicationId(), 
/* 1199 */         widgetEnabled(), 
/* 1200 */         widgetChannelId(), 
/* 1201 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 1203 */         rulesChannelId(), 
/* 1204 */         maxPresences(), 
/* 1205 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1209 */         premiumSubscriptionCount(), 
/* 1210 */         publicUpdatesChannelId(), 
/* 1211 */         maxVideoChannelUsers(), 
/* 1212 */         approximateMemberCount(), 
/* 1213 */         approximatePresenceCount(), 
/* 1214 */         welcomeScreen(), 
/* 1215 */         nsfw(), 
/* 1216 */         safetyAlertsChannelId());
/*      */   }
/*      */   
/*      */   public ImmutableUserGuildData withEmbedEnabled(Possible<Boolean> value) {
/* 1220 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/* 1221 */     return new ImmutableUserGuildData(this, 
/*      */         
/* 1223 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1228 */         owner(), 
/* 1229 */         permissions(), 
/* 1230 */         afkChannelId(), newValue, 
/*      */         
/* 1232 */         embedChannelId(), this.features, 
/*      */         
/* 1234 */         applicationId(), 
/* 1235 */         widgetEnabled(), 
/* 1236 */         widgetChannelId(), 
/* 1237 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 1239 */         rulesChannelId(), 
/* 1240 */         maxPresences(), 
/* 1241 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1245 */         premiumSubscriptionCount(), 
/* 1246 */         publicUpdatesChannelId(), 
/* 1247 */         maxVideoChannelUsers(), 
/* 1248 */         approximateMemberCount(), 
/* 1249 */         approximatePresenceCount(), 
/* 1250 */         welcomeScreen(), 
/* 1251 */         nsfw(), 
/* 1252 */         safetyAlertsChannelId());
/*      */   }
/*      */   
/*      */   public ImmutableUserGuildData withEmbedEnabled(Boolean value) {
/* 1256 */     Possible<Boolean> newValue = Possible.of(value);
/* 1257 */     return new ImmutableUserGuildData(this, 
/*      */         
/* 1259 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1264 */         owner(), 
/* 1265 */         permissions(), 
/* 1266 */         afkChannelId(), newValue, 
/*      */         
/* 1268 */         embedChannelId(), this.features, 
/*      */         
/* 1270 */         applicationId(), 
/* 1271 */         widgetEnabled(), 
/* 1272 */         widgetChannelId(), 
/* 1273 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 1275 */         rulesChannelId(), 
/* 1276 */         maxPresences(), 
/* 1277 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1281 */         premiumSubscriptionCount(), 
/* 1282 */         publicUpdatesChannelId(), 
/* 1283 */         maxVideoChannelUsers(), 
/* 1284 */         approximateMemberCount(), 
/* 1285 */         approximatePresenceCount(), 
/* 1286 */         welcomeScreen(), 
/* 1287 */         nsfw(), 
/* 1288 */         safetyAlertsChannelId());
/*      */   }
/*      */   
/*      */   public ImmutableUserGuildData withEmbedChannelId(Possible<Optional<Id>> value) {
/* 1292 */     Possible<Optional<Id>> newValue = Objects.<Possible<Optional<Id>>>requireNonNull(value);
/* 1293 */     return new ImmutableUserGuildData(this, 
/*      */         
/* 1295 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1300 */         owner(), 
/* 1301 */         permissions(), 
/* 1302 */         afkChannelId(), 
/* 1303 */         embedEnabled(), newValue, this.features, 
/*      */ 
/*      */         
/* 1306 */         applicationId(), 
/* 1307 */         widgetEnabled(), 
/* 1308 */         widgetChannelId(), 
/* 1309 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 1311 */         rulesChannelId(), 
/* 1312 */         maxPresences(), 
/* 1313 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1317 */         premiumSubscriptionCount(), 
/* 1318 */         publicUpdatesChannelId(), 
/* 1319 */         maxVideoChannelUsers(), 
/* 1320 */         approximateMemberCount(), 
/* 1321 */         approximatePresenceCount(), 
/* 1322 */         welcomeScreen(), 
/* 1323 */         nsfw(), 
/* 1324 */         safetyAlertsChannelId());
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public ImmutableUserGuildData withEmbedChannelId(@Nullable Long value) {
/* 1330 */     Possible<Optional<Id>> newValue = (value == null) ? Possible.of(Optional.empty()) : Possible.of(Optional.of(Id.of(value.longValue())));
/* 1331 */     return new ImmutableUserGuildData(this, 
/*      */         
/* 1333 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1338 */         owner(), 
/* 1339 */         permissions(), 
/* 1340 */         afkChannelId(), 
/* 1341 */         embedEnabled(), newValue, this.features, 
/*      */ 
/*      */         
/* 1344 */         applicationId(), 
/* 1345 */         widgetEnabled(), 
/* 1346 */         widgetChannelId(), 
/* 1347 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 1349 */         rulesChannelId(), 
/* 1350 */         maxPresences(), 
/* 1351 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1355 */         premiumSubscriptionCount(), 
/* 1356 */         publicUpdatesChannelId(), 
/* 1357 */         maxVideoChannelUsers(), 
/* 1358 */         approximateMemberCount(), 
/* 1359 */         approximatePresenceCount(), 
/* 1360 */         welcomeScreen(), 
/* 1361 */         nsfw(), 
/* 1362 */         safetyAlertsChannelId());
/*      */   }
/*      */ 
/*      */   
/*      */   public ImmutableUserGuildData withEmbedChannelIdOrNull(@Nullable Long value) {
/* 1367 */     Possible<Optional<Id>> newValue = (value == null) ? Possible.of(Optional.empty()) : Possible.of(Optional.of(Id.of(value.longValue())));
/* 1368 */     return new ImmutableUserGuildData(this, 
/*      */         
/* 1370 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1375 */         owner(), 
/* 1376 */         permissions(), 
/* 1377 */         afkChannelId(), 
/* 1378 */         embedEnabled(), newValue, this.features, 
/*      */ 
/*      */         
/* 1381 */         applicationId(), 
/* 1382 */         widgetEnabled(), 
/* 1383 */         widgetChannelId(), 
/* 1384 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 1386 */         rulesChannelId(), 
/* 1387 */         maxPresences(), 
/* 1388 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1392 */         premiumSubscriptionCount(), 
/* 1393 */         publicUpdatesChannelId(), 
/* 1394 */         maxVideoChannelUsers(), 
/* 1395 */         approximateMemberCount(), 
/* 1396 */         approximatePresenceCount(), 
/* 1397 */         welcomeScreen(), 
/* 1398 */         nsfw(), 
/* 1399 */         safetyAlertsChannelId());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableUserGuildData withFeatures(String... elements) {
/* 1408 */     List<String> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/* 1409 */     return new ImmutableUserGuildData(this, 
/*      */         
/* 1411 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1416 */         owner(), 
/* 1417 */         permissions(), 
/* 1418 */         afkChannelId(), 
/* 1419 */         embedEnabled(), 
/* 1420 */         embedChannelId(), newValue, 
/*      */         
/* 1422 */         applicationId(), 
/* 1423 */         widgetEnabled(), 
/* 1424 */         widgetChannelId(), 
/* 1425 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 1427 */         rulesChannelId(), 
/* 1428 */         maxPresences(), 
/* 1429 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1433 */         premiumSubscriptionCount(), 
/* 1434 */         publicUpdatesChannelId(), 
/* 1435 */         maxVideoChannelUsers(), 
/* 1436 */         approximateMemberCount(), 
/* 1437 */         approximatePresenceCount(), 
/* 1438 */         welcomeScreen(), 
/* 1439 */         nsfw(), 
/* 1440 */         safetyAlertsChannelId());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableUserGuildData withFeatures(Iterable<String> elements) {
/* 1450 */     if (this.features == elements) return this; 
/* 1451 */     List<String> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/* 1452 */     return new ImmutableUserGuildData(this, 
/*      */         
/* 1454 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1459 */         owner(), 
/* 1460 */         permissions(), 
/* 1461 */         afkChannelId(), 
/* 1462 */         embedEnabled(), 
/* 1463 */         embedChannelId(), newValue, 
/*      */         
/* 1465 */         applicationId(), 
/* 1466 */         widgetEnabled(), 
/* 1467 */         widgetChannelId(), 
/* 1468 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 1470 */         rulesChannelId(), 
/* 1471 */         maxPresences(), 
/* 1472 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1476 */         premiumSubscriptionCount(), 
/* 1477 */         publicUpdatesChannelId(), 
/* 1478 */         maxVideoChannelUsers(), 
/* 1479 */         approximateMemberCount(), 
/* 1480 */         approximatePresenceCount(), 
/* 1481 */         welcomeScreen(), 
/* 1482 */         nsfw(), 
/* 1483 */         safetyAlertsChannelId());
/*      */   }
/*      */   
/*      */   public ImmutableUserGuildData withApplicationId(Optional<Id> value) {
/* 1487 */     Optional<Id> newValue = Objects.<Optional<Id>>requireNonNull(value);
/* 1488 */     return new ImmutableUserGuildData(this, 
/*      */         
/* 1490 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1495 */         owner(), 
/* 1496 */         permissions(), 
/* 1497 */         afkChannelId(), 
/* 1498 */         embedEnabled(), 
/* 1499 */         embedChannelId(), this.features, newValue, 
/*      */ 
/*      */         
/* 1502 */         widgetEnabled(), 
/* 1503 */         widgetChannelId(), 
/* 1504 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 1506 */         rulesChannelId(), 
/* 1507 */         maxPresences(), 
/* 1508 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1512 */         premiumSubscriptionCount(), 
/* 1513 */         publicUpdatesChannelId(), 
/* 1514 */         maxVideoChannelUsers(), 
/* 1515 */         approximateMemberCount(), 
/* 1516 */         approximatePresenceCount(), 
/* 1517 */         welcomeScreen(), 
/* 1518 */         nsfw(), 
/* 1519 */         safetyAlertsChannelId());
/*      */   }
/*      */   
/*      */   public ImmutableUserGuildData withApplicationId(long value) {
/* 1523 */     Optional<Id> newValue = Optional.of(Id.of(value));
/* 1524 */     return new ImmutableUserGuildData(this, 
/*      */         
/* 1526 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1531 */         owner(), 
/* 1532 */         permissions(), 
/* 1533 */         afkChannelId(), 
/* 1534 */         embedEnabled(), 
/* 1535 */         embedChannelId(), this.features, newValue, 
/*      */ 
/*      */         
/* 1538 */         widgetEnabled(), 
/* 1539 */         widgetChannelId(), 
/* 1540 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 1542 */         rulesChannelId(), 
/* 1543 */         maxPresences(), 
/* 1544 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1548 */         premiumSubscriptionCount(), 
/* 1549 */         publicUpdatesChannelId(), 
/* 1550 */         maxVideoChannelUsers(), 
/* 1551 */         approximateMemberCount(), 
/* 1552 */         approximatePresenceCount(), 
/* 1553 */         welcomeScreen(), 
/* 1554 */         nsfw(), 
/* 1555 */         safetyAlertsChannelId());
/*      */   }
/*      */   
/*      */   public ImmutableUserGuildData withWidgetEnabled(Possible<Boolean> value) {
/* 1559 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/* 1560 */     return new ImmutableUserGuildData(this, 
/*      */         
/* 1562 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1567 */         owner(), 
/* 1568 */         permissions(), 
/* 1569 */         afkChannelId(), 
/* 1570 */         embedEnabled(), 
/* 1571 */         embedChannelId(), this.features, 
/*      */         
/* 1573 */         applicationId(), newValue, 
/*      */         
/* 1575 */         widgetChannelId(), 
/* 1576 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 1578 */         rulesChannelId(), 
/* 1579 */         maxPresences(), 
/* 1580 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1584 */         premiumSubscriptionCount(), 
/* 1585 */         publicUpdatesChannelId(), 
/* 1586 */         maxVideoChannelUsers(), 
/* 1587 */         approximateMemberCount(), 
/* 1588 */         approximatePresenceCount(), 
/* 1589 */         welcomeScreen(), 
/* 1590 */         nsfw(), 
/* 1591 */         safetyAlertsChannelId());
/*      */   }
/*      */   
/*      */   public ImmutableUserGuildData withWidgetEnabled(Boolean value) {
/* 1595 */     Possible<Boolean> newValue = Possible.of(value);
/* 1596 */     return new ImmutableUserGuildData(this, 
/*      */         
/* 1598 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1603 */         owner(), 
/* 1604 */         permissions(), 
/* 1605 */         afkChannelId(), 
/* 1606 */         embedEnabled(), 
/* 1607 */         embedChannelId(), this.features, 
/*      */         
/* 1609 */         applicationId(), newValue, 
/*      */         
/* 1611 */         widgetChannelId(), 
/* 1612 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 1614 */         rulesChannelId(), 
/* 1615 */         maxPresences(), 
/* 1616 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1620 */         premiumSubscriptionCount(), 
/* 1621 */         publicUpdatesChannelId(), 
/* 1622 */         maxVideoChannelUsers(), 
/* 1623 */         approximateMemberCount(), 
/* 1624 */         approximatePresenceCount(), 
/* 1625 */         welcomeScreen(), 
/* 1626 */         nsfw(), 
/* 1627 */         safetyAlertsChannelId());
/*      */   }
/*      */   
/*      */   public ImmutableUserGuildData withWidgetChannelId(Possible<Optional<Id>> value) {
/* 1631 */     Possible<Optional<Id>> newValue = Objects.<Possible<Optional<Id>>>requireNonNull(value);
/* 1632 */     return new ImmutableUserGuildData(this, 
/*      */         
/* 1634 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1639 */         owner(), 
/* 1640 */         permissions(), 
/* 1641 */         afkChannelId(), 
/* 1642 */         embedEnabled(), 
/* 1643 */         embedChannelId(), this.features, 
/*      */         
/* 1645 */         applicationId(), 
/* 1646 */         widgetEnabled(), newValue, 
/*      */         
/* 1648 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 1650 */         rulesChannelId(), 
/* 1651 */         maxPresences(), 
/* 1652 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1656 */         premiumSubscriptionCount(), 
/* 1657 */         publicUpdatesChannelId(), 
/* 1658 */         maxVideoChannelUsers(), 
/* 1659 */         approximateMemberCount(), 
/* 1660 */         approximatePresenceCount(), 
/* 1661 */         welcomeScreen(), 
/* 1662 */         nsfw(), 
/* 1663 */         safetyAlertsChannelId());
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public ImmutableUserGuildData withWidgetChannelId(@Nullable Long value) {
/* 1669 */     Possible<Optional<Id>> newValue = (value == null) ? Possible.of(Optional.empty()) : Possible.of(Optional.of(Id.of(value.longValue())));
/* 1670 */     return new ImmutableUserGuildData(this, 
/*      */         
/* 1672 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1677 */         owner(), 
/* 1678 */         permissions(), 
/* 1679 */         afkChannelId(), 
/* 1680 */         embedEnabled(), 
/* 1681 */         embedChannelId(), this.features, 
/*      */         
/* 1683 */         applicationId(), 
/* 1684 */         widgetEnabled(), newValue, 
/*      */         
/* 1686 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 1688 */         rulesChannelId(), 
/* 1689 */         maxPresences(), 
/* 1690 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1694 */         premiumSubscriptionCount(), 
/* 1695 */         publicUpdatesChannelId(), 
/* 1696 */         maxVideoChannelUsers(), 
/* 1697 */         approximateMemberCount(), 
/* 1698 */         approximatePresenceCount(), 
/* 1699 */         welcomeScreen(), 
/* 1700 */         nsfw(), 
/* 1701 */         safetyAlertsChannelId());
/*      */   }
/*      */ 
/*      */   
/*      */   public ImmutableUserGuildData withWidgetChannelIdOrNull(@Nullable Long value) {
/* 1706 */     Possible<Optional<Id>> newValue = (value == null) ? Possible.of(Optional.empty()) : Possible.of(Optional.of(Id.of(value.longValue())));
/* 1707 */     return new ImmutableUserGuildData(this, 
/*      */         
/* 1709 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1714 */         owner(), 
/* 1715 */         permissions(), 
/* 1716 */         afkChannelId(), 
/* 1717 */         embedEnabled(), 
/* 1718 */         embedChannelId(), this.features, 
/*      */         
/* 1720 */         applicationId(), 
/* 1721 */         widgetEnabled(), newValue, 
/*      */         
/* 1723 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 1725 */         rulesChannelId(), 
/* 1726 */         maxPresences(), 
/* 1727 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1731 */         premiumSubscriptionCount(), 
/* 1732 */         publicUpdatesChannelId(), 
/* 1733 */         maxVideoChannelUsers(), 
/* 1734 */         approximateMemberCount(), 
/* 1735 */         approximatePresenceCount(), 
/* 1736 */         welcomeScreen(), 
/* 1737 */         nsfw(), 
/* 1738 */         safetyAlertsChannelId());
/*      */   }
/*      */   
/*      */   public ImmutableUserGuildData withSystemChannelId(Optional<Id> value) {
/* 1742 */     Optional<Id> newValue = Objects.<Optional<Id>>requireNonNull(value);
/* 1743 */     return new ImmutableUserGuildData(this, 
/*      */         
/* 1745 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1750 */         owner(), 
/* 1751 */         permissions(), 
/* 1752 */         afkChannelId(), 
/* 1753 */         embedEnabled(), 
/* 1754 */         embedChannelId(), this.features, 
/*      */         
/* 1756 */         applicationId(), 
/* 1757 */         widgetEnabled(), 
/* 1758 */         widgetChannelId(), newValue, this.systemChannelFlags, 
/*      */ 
/*      */         
/* 1761 */         rulesChannelId(), 
/* 1762 */         maxPresences(), 
/* 1763 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1767 */         premiumSubscriptionCount(), 
/* 1768 */         publicUpdatesChannelId(), 
/* 1769 */         maxVideoChannelUsers(), 
/* 1770 */         approximateMemberCount(), 
/* 1771 */         approximatePresenceCount(), 
/* 1772 */         welcomeScreen(), 
/* 1773 */         nsfw(), 
/* 1774 */         safetyAlertsChannelId());
/*      */   }
/*      */   
/*      */   public ImmutableUserGuildData withSystemChannelId(long value) {
/* 1778 */     Optional<Id> newValue = Optional.of(Id.of(value));
/* 1779 */     return new ImmutableUserGuildData(this, 
/*      */         
/* 1781 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1786 */         owner(), 
/* 1787 */         permissions(), 
/* 1788 */         afkChannelId(), 
/* 1789 */         embedEnabled(), 
/* 1790 */         embedChannelId(), this.features, 
/*      */         
/* 1792 */         applicationId(), 
/* 1793 */         widgetEnabled(), 
/* 1794 */         widgetChannelId(), newValue, this.systemChannelFlags, 
/*      */ 
/*      */         
/* 1797 */         rulesChannelId(), 
/* 1798 */         maxPresences(), 
/* 1799 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1803 */         premiumSubscriptionCount(), 
/* 1804 */         publicUpdatesChannelId(), 
/* 1805 */         maxVideoChannelUsers(), 
/* 1806 */         approximateMemberCount(), 
/* 1807 */         approximatePresenceCount(), 
/* 1808 */         welcomeScreen(), 
/* 1809 */         nsfw(), 
/* 1810 */         safetyAlertsChannelId());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableUserGuildData withSystemChannelFlags(int value) {
/* 1819 */     Integer newValue = Integer.valueOf(value);
/* 1820 */     if (Objects.equals(this.systemChannelFlags, newValue)) return this; 
/* 1821 */     return new ImmutableUserGuildData(this, 
/*      */         
/* 1823 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1828 */         owner(), 
/* 1829 */         permissions(), 
/* 1830 */         afkChannelId(), 
/* 1831 */         embedEnabled(), 
/* 1832 */         embedChannelId(), this.features, 
/*      */         
/* 1834 */         applicationId(), 
/* 1835 */         widgetEnabled(), 
/* 1836 */         widgetChannelId(), 
/* 1837 */         systemChannelId(), newValue, 
/*      */         
/* 1839 */         rulesChannelId(), 
/* 1840 */         maxPresences(), 
/* 1841 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1845 */         premiumSubscriptionCount(), 
/* 1846 */         publicUpdatesChannelId(), 
/* 1847 */         maxVideoChannelUsers(), 
/* 1848 */         approximateMemberCount(), 
/* 1849 */         approximatePresenceCount(), 
/* 1850 */         welcomeScreen(), 
/* 1851 */         nsfw(), 
/* 1852 */         safetyAlertsChannelId());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableUserGuildData withSystemChannelFlags(OptionalInt optional) {
/* 1862 */     Integer value = optional.isPresent() ? Integer.valueOf(optional.getAsInt()) : null;
/* 1863 */     if (Objects.equals(this.systemChannelFlags, value)) return this; 
/* 1864 */     return new ImmutableUserGuildData(this, 
/*      */         
/* 1866 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1871 */         owner(), 
/* 1872 */         permissions(), 
/* 1873 */         afkChannelId(), 
/* 1874 */         embedEnabled(), 
/* 1875 */         embedChannelId(), this.features, 
/*      */         
/* 1877 */         applicationId(), 
/* 1878 */         widgetEnabled(), 
/* 1879 */         widgetChannelId(), 
/* 1880 */         systemChannelId(), value, 
/*      */         
/* 1882 */         rulesChannelId(), 
/* 1883 */         maxPresences(), 
/* 1884 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1888 */         premiumSubscriptionCount(), 
/* 1889 */         publicUpdatesChannelId(), 
/* 1890 */         maxVideoChannelUsers(), 
/* 1891 */         approximateMemberCount(), 
/* 1892 */         approximatePresenceCount(), 
/* 1893 */         welcomeScreen(), 
/* 1894 */         nsfw(), 
/* 1895 */         safetyAlertsChannelId());
/*      */   }
/*      */   
/*      */   public ImmutableUserGuildData withRulesChannelId(Optional<Id> value) {
/* 1899 */     Optional<Id> newValue = Objects.<Optional<Id>>requireNonNull(value);
/* 1900 */     return new ImmutableUserGuildData(this, 
/*      */         
/* 1902 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1907 */         owner(), 
/* 1908 */         permissions(), 
/* 1909 */         afkChannelId(), 
/* 1910 */         embedEnabled(), 
/* 1911 */         embedChannelId(), this.features, 
/*      */         
/* 1913 */         applicationId(), 
/* 1914 */         widgetEnabled(), 
/* 1915 */         widgetChannelId(), 
/* 1916 */         systemChannelId(), this.systemChannelFlags, newValue, 
/*      */ 
/*      */         
/* 1919 */         maxPresences(), 
/* 1920 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1924 */         premiumSubscriptionCount(), 
/* 1925 */         publicUpdatesChannelId(), 
/* 1926 */         maxVideoChannelUsers(), 
/* 1927 */         approximateMemberCount(), 
/* 1928 */         approximatePresenceCount(), 
/* 1929 */         welcomeScreen(), 
/* 1930 */         nsfw(), 
/* 1931 */         safetyAlertsChannelId());
/*      */   }
/*      */   
/*      */   public ImmutableUserGuildData withRulesChannelId(long value) {
/* 1935 */     Optional<Id> newValue = Optional.of(Id.of(value));
/* 1936 */     return new ImmutableUserGuildData(this, 
/*      */         
/* 1938 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1943 */         owner(), 
/* 1944 */         permissions(), 
/* 1945 */         afkChannelId(), 
/* 1946 */         embedEnabled(), 
/* 1947 */         embedChannelId(), this.features, 
/*      */         
/* 1949 */         applicationId(), 
/* 1950 */         widgetEnabled(), 
/* 1951 */         widgetChannelId(), 
/* 1952 */         systemChannelId(), this.systemChannelFlags, newValue, 
/*      */ 
/*      */         
/* 1955 */         maxPresences(), 
/* 1956 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1960 */         premiumSubscriptionCount(), 
/* 1961 */         publicUpdatesChannelId(), 
/* 1962 */         maxVideoChannelUsers(), 
/* 1963 */         approximateMemberCount(), 
/* 1964 */         approximatePresenceCount(), 
/* 1965 */         welcomeScreen(), 
/* 1966 */         nsfw(), 
/* 1967 */         safetyAlertsChannelId());
/*      */   }
/*      */   
/*      */   public ImmutableUserGuildData withMaxPresences(Possible<Optional<Integer>> value) {
/* 1971 */     Possible<Optional<Integer>> newValue = Objects.<Possible<Optional<Integer>>>requireNonNull(value);
/* 1972 */     return new ImmutableUserGuildData(this, 
/*      */         
/* 1974 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1979 */         owner(), 
/* 1980 */         permissions(), 
/* 1981 */         afkChannelId(), 
/* 1982 */         embedEnabled(), 
/* 1983 */         embedChannelId(), this.features, 
/*      */         
/* 1985 */         applicationId(), 
/* 1986 */         widgetEnabled(), 
/* 1987 */         widgetChannelId(), 
/* 1988 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 1990 */         rulesChannelId(), newValue, 
/*      */         
/* 1992 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1996 */         premiumSubscriptionCount(), 
/* 1997 */         publicUpdatesChannelId(), 
/* 1998 */         maxVideoChannelUsers(), 
/* 1999 */         approximateMemberCount(), 
/* 2000 */         approximatePresenceCount(), 
/* 2001 */         welcomeScreen(), 
/* 2002 */         nsfw(), 
/* 2003 */         safetyAlertsChannelId());
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public ImmutableUserGuildData withMaxPresences(@Nullable Integer value) {
/* 2008 */     Possible<Optional<Integer>> newValue = Possible.of(Optional.ofNullable(value));
/* 2009 */     return new ImmutableUserGuildData(this, 
/*      */         
/* 2011 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2016 */         owner(), 
/* 2017 */         permissions(), 
/* 2018 */         afkChannelId(), 
/* 2019 */         embedEnabled(), 
/* 2020 */         embedChannelId(), this.features, 
/*      */         
/* 2022 */         applicationId(), 
/* 2023 */         widgetEnabled(), 
/* 2024 */         widgetChannelId(), 
/* 2025 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 2027 */         rulesChannelId(), newValue, 
/*      */         
/* 2029 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 2033 */         premiumSubscriptionCount(), 
/* 2034 */         publicUpdatesChannelId(), 
/* 2035 */         maxVideoChannelUsers(), 
/* 2036 */         approximateMemberCount(), 
/* 2037 */         approximatePresenceCount(), 
/* 2038 */         welcomeScreen(), 
/* 2039 */         nsfw(), 
/* 2040 */         safetyAlertsChannelId());
/*      */   }
/*      */   
/*      */   public ImmutableUserGuildData withMaxPresencesOrNull(@Nullable Integer value) {
/* 2044 */     Possible<Optional<Integer>> newValue = Possible.of(Optional.ofNullable(value));
/* 2045 */     return new ImmutableUserGuildData(this, 
/*      */         
/* 2047 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2052 */         owner(), 
/* 2053 */         permissions(), 
/* 2054 */         afkChannelId(), 
/* 2055 */         embedEnabled(), 
/* 2056 */         embedChannelId(), this.features, 
/*      */         
/* 2058 */         applicationId(), 
/* 2059 */         widgetEnabled(), 
/* 2060 */         widgetChannelId(), 
/* 2061 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 2063 */         rulesChannelId(), newValue, 
/*      */         
/* 2065 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 2069 */         premiumSubscriptionCount(), 
/* 2070 */         publicUpdatesChannelId(), 
/* 2071 */         maxVideoChannelUsers(), 
/* 2072 */         approximateMemberCount(), 
/* 2073 */         approximatePresenceCount(), 
/* 2074 */         welcomeScreen(), 
/* 2075 */         nsfw(), 
/* 2076 */         safetyAlertsChannelId());
/*      */   }
/*      */   
/*      */   public ImmutableUserGuildData withMaxMembers(Possible<Integer> value) {
/* 2080 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/* 2081 */     return new ImmutableUserGuildData(this, 
/*      */         
/* 2083 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2088 */         owner(), 
/* 2089 */         permissions(), 
/* 2090 */         afkChannelId(), 
/* 2091 */         embedEnabled(), 
/* 2092 */         embedChannelId(), this.features, 
/*      */         
/* 2094 */         applicationId(), 
/* 2095 */         widgetEnabled(), 
/* 2096 */         widgetChannelId(), 
/* 2097 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 2099 */         rulesChannelId(), 
/* 2100 */         maxPresences(), newValue, this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2105 */         premiumSubscriptionCount(), 
/* 2106 */         publicUpdatesChannelId(), 
/* 2107 */         maxVideoChannelUsers(), 
/* 2108 */         approximateMemberCount(), 
/* 2109 */         approximatePresenceCount(), 
/* 2110 */         welcomeScreen(), 
/* 2111 */         nsfw(), 
/* 2112 */         safetyAlertsChannelId());
/*      */   }
/*      */   
/*      */   public ImmutableUserGuildData withMaxMembers(Integer value) {
/* 2116 */     Possible<Integer> newValue = Possible.of(value);
/* 2117 */     return new ImmutableUserGuildData(this, 
/*      */         
/* 2119 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2124 */         owner(), 
/* 2125 */         permissions(), 
/* 2126 */         afkChannelId(), 
/* 2127 */         embedEnabled(), 
/* 2128 */         embedChannelId(), this.features, 
/*      */         
/* 2130 */         applicationId(), 
/* 2131 */         widgetEnabled(), 
/* 2132 */         widgetChannelId(), 
/* 2133 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 2135 */         rulesChannelId(), 
/* 2136 */         maxPresences(), newValue, this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2141 */         premiumSubscriptionCount(), 
/* 2142 */         publicUpdatesChannelId(), 
/* 2143 */         maxVideoChannelUsers(), 
/* 2144 */         approximateMemberCount(), 
/* 2145 */         approximatePresenceCount(), 
/* 2146 */         welcomeScreen(), 
/* 2147 */         nsfw(), 
/* 2148 */         safetyAlertsChannelId());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableUserGuildData withVanityUrlCode(String value) {
/* 2157 */     String newValue = Objects.<String>requireNonNull(value, "vanityUrlCode");
/* 2158 */     if (Objects.equals(this.vanityUrlCode, newValue)) return this; 
/* 2159 */     return new ImmutableUserGuildData(this, 
/*      */         
/* 2161 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2166 */         owner(), 
/* 2167 */         permissions(), 
/* 2168 */         afkChannelId(), 
/* 2169 */         embedEnabled(), 
/* 2170 */         embedChannelId(), this.features, 
/*      */         
/* 2172 */         applicationId(), 
/* 2173 */         widgetEnabled(), 
/* 2174 */         widgetChannelId(), 
/* 2175 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 2177 */         rulesChannelId(), 
/* 2178 */         maxPresences(), 
/* 2179 */         maxMembers(), newValue, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 2183 */         premiumSubscriptionCount(), 
/* 2184 */         publicUpdatesChannelId(), 
/* 2185 */         maxVideoChannelUsers(), 
/* 2186 */         approximateMemberCount(), 
/* 2187 */         approximatePresenceCount(), 
/* 2188 */         welcomeScreen(), 
/* 2189 */         nsfw(), 
/* 2190 */         safetyAlertsChannelId());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableUserGuildData withVanityUrlCode(Optional<String> optional) {
/* 2200 */     String value = optional.orElse(null);
/* 2201 */     if (Objects.equals(this.vanityUrlCode, value)) return this; 
/* 2202 */     return new ImmutableUserGuildData(this, 
/*      */         
/* 2204 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2209 */         owner(), 
/* 2210 */         permissions(), 
/* 2211 */         afkChannelId(), 
/* 2212 */         embedEnabled(), 
/* 2213 */         embedChannelId(), this.features, 
/*      */         
/* 2215 */         applicationId(), 
/* 2216 */         widgetEnabled(), 
/* 2217 */         widgetChannelId(), 
/* 2218 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 2220 */         rulesChannelId(), 
/* 2221 */         maxPresences(), 
/* 2222 */         maxMembers(), value, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 2226 */         premiumSubscriptionCount(), 
/* 2227 */         publicUpdatesChannelId(), 
/* 2228 */         maxVideoChannelUsers(), 
/* 2229 */         approximateMemberCount(), 
/* 2230 */         approximatePresenceCount(), 
/* 2231 */         welcomeScreen(), 
/* 2232 */         nsfw(), 
/* 2233 */         safetyAlertsChannelId());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableUserGuildData withDescription(String value) {
/* 2242 */     String newValue = Objects.<String>requireNonNull(value, "description");
/* 2243 */     if (Objects.equals(this.description, newValue)) return this; 
/* 2244 */     return new ImmutableUserGuildData(this, 
/*      */         
/* 2246 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2251 */         owner(), 
/* 2252 */         permissions(), 
/* 2253 */         afkChannelId(), 
/* 2254 */         embedEnabled(), 
/* 2255 */         embedChannelId(), this.features, 
/*      */         
/* 2257 */         applicationId(), 
/* 2258 */         widgetEnabled(), 
/* 2259 */         widgetChannelId(), 
/* 2260 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 2262 */         rulesChannelId(), 
/* 2263 */         maxPresences(), 
/* 2264 */         maxMembers(), this.vanityUrlCode, newValue, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 2268 */         premiumSubscriptionCount(), 
/* 2269 */         publicUpdatesChannelId(), 
/* 2270 */         maxVideoChannelUsers(), 
/* 2271 */         approximateMemberCount(), 
/* 2272 */         approximatePresenceCount(), 
/* 2273 */         welcomeScreen(), 
/* 2274 */         nsfw(), 
/* 2275 */         safetyAlertsChannelId());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableUserGuildData withDescription(Optional<String> optional) {
/* 2285 */     String value = optional.orElse(null);
/* 2286 */     if (Objects.equals(this.description, value)) return this; 
/* 2287 */     return new ImmutableUserGuildData(this, 
/*      */         
/* 2289 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2294 */         owner(), 
/* 2295 */         permissions(), 
/* 2296 */         afkChannelId(), 
/* 2297 */         embedEnabled(), 
/* 2298 */         embedChannelId(), this.features, 
/*      */         
/* 2300 */         applicationId(), 
/* 2301 */         widgetEnabled(), 
/* 2302 */         widgetChannelId(), 
/* 2303 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 2305 */         rulesChannelId(), 
/* 2306 */         maxPresences(), 
/* 2307 */         maxMembers(), this.vanityUrlCode, value, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 2311 */         premiumSubscriptionCount(), 
/* 2312 */         publicUpdatesChannelId(), 
/* 2313 */         maxVideoChannelUsers(), 
/* 2314 */         approximateMemberCount(), 
/* 2315 */         approximatePresenceCount(), 
/* 2316 */         welcomeScreen(), 
/* 2317 */         nsfw(), 
/* 2318 */         safetyAlertsChannelId());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableUserGuildData withBanner(String value) {
/* 2327 */     String newValue = Objects.<String>requireNonNull(value, "banner");
/* 2328 */     if (Objects.equals(this.banner, newValue)) return this; 
/* 2329 */     return new ImmutableUserGuildData(this, 
/*      */         
/* 2331 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2336 */         owner(), 
/* 2337 */         permissions(), 
/* 2338 */         afkChannelId(), 
/* 2339 */         embedEnabled(), 
/* 2340 */         embedChannelId(), this.features, 
/*      */         
/* 2342 */         applicationId(), 
/* 2343 */         widgetEnabled(), 
/* 2344 */         widgetChannelId(), 
/* 2345 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 2347 */         rulesChannelId(), 
/* 2348 */         maxPresences(), 
/* 2349 */         maxMembers(), this.vanityUrlCode, this.description, newValue, 
/*      */ 
/*      */ 
/*      */         
/* 2353 */         premiumSubscriptionCount(), 
/* 2354 */         publicUpdatesChannelId(), 
/* 2355 */         maxVideoChannelUsers(), 
/* 2356 */         approximateMemberCount(), 
/* 2357 */         approximatePresenceCount(), 
/* 2358 */         welcomeScreen(), 
/* 2359 */         nsfw(), 
/* 2360 */         safetyAlertsChannelId());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableUserGuildData withBanner(Optional<String> optional) {
/* 2370 */     String value = optional.orElse(null);
/* 2371 */     if (Objects.equals(this.banner, value)) return this; 
/* 2372 */     return new ImmutableUserGuildData(this, 
/*      */         
/* 2374 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2379 */         owner(), 
/* 2380 */         permissions(), 
/* 2381 */         afkChannelId(), 
/* 2382 */         embedEnabled(), 
/* 2383 */         embedChannelId(), this.features, 
/*      */         
/* 2385 */         applicationId(), 
/* 2386 */         widgetEnabled(), 
/* 2387 */         widgetChannelId(), 
/* 2388 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 2390 */         rulesChannelId(), 
/* 2391 */         maxPresences(), 
/* 2392 */         maxMembers(), this.vanityUrlCode, this.description, value, 
/*      */ 
/*      */ 
/*      */         
/* 2396 */         premiumSubscriptionCount(), 
/* 2397 */         publicUpdatesChannelId(), 
/* 2398 */         maxVideoChannelUsers(), 
/* 2399 */         approximateMemberCount(), 
/* 2400 */         approximatePresenceCount(), 
/* 2401 */         welcomeScreen(), 
/* 2402 */         nsfw(), 
/* 2403 */         safetyAlertsChannelId());
/*      */   }
/*      */   
/*      */   public ImmutableUserGuildData withPremiumSubscriptionCount(Possible<Integer> value) {
/* 2407 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/* 2408 */     return new ImmutableUserGuildData(this, 
/*      */         
/* 2410 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2415 */         owner(), 
/* 2416 */         permissions(), 
/* 2417 */         afkChannelId(), 
/* 2418 */         embedEnabled(), 
/* 2419 */         embedChannelId(), this.features, 
/*      */         
/* 2421 */         applicationId(), 
/* 2422 */         widgetEnabled(), 
/* 2423 */         widgetChannelId(), 
/* 2424 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 2426 */         rulesChannelId(), 
/* 2427 */         maxPresences(), 
/* 2428 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, newValue, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2433 */         publicUpdatesChannelId(), 
/* 2434 */         maxVideoChannelUsers(), 
/* 2435 */         approximateMemberCount(), 
/* 2436 */         approximatePresenceCount(), 
/* 2437 */         welcomeScreen(), 
/* 2438 */         nsfw(), 
/* 2439 */         safetyAlertsChannelId());
/*      */   }
/*      */   
/*      */   public ImmutableUserGuildData withPremiumSubscriptionCount(Integer value) {
/* 2443 */     Possible<Integer> newValue = Possible.of(value);
/* 2444 */     return new ImmutableUserGuildData(this, 
/*      */         
/* 2446 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2451 */         owner(), 
/* 2452 */         permissions(), 
/* 2453 */         afkChannelId(), 
/* 2454 */         embedEnabled(), 
/* 2455 */         embedChannelId(), this.features, 
/*      */         
/* 2457 */         applicationId(), 
/* 2458 */         widgetEnabled(), 
/* 2459 */         widgetChannelId(), 
/* 2460 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 2462 */         rulesChannelId(), 
/* 2463 */         maxPresences(), 
/* 2464 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, newValue, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2469 */         publicUpdatesChannelId(), 
/* 2470 */         maxVideoChannelUsers(), 
/* 2471 */         approximateMemberCount(), 
/* 2472 */         approximatePresenceCount(), 
/* 2473 */         welcomeScreen(), 
/* 2474 */         nsfw(), 
/* 2475 */         safetyAlertsChannelId());
/*      */   }
/*      */   
/*      */   public ImmutableUserGuildData withPublicUpdatesChannelId(Optional<Id> value) {
/* 2479 */     Optional<Id> newValue = Objects.<Optional<Id>>requireNonNull(value);
/* 2480 */     return new ImmutableUserGuildData(this, 
/*      */         
/* 2482 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2487 */         owner(), 
/* 2488 */         permissions(), 
/* 2489 */         afkChannelId(), 
/* 2490 */         embedEnabled(), 
/* 2491 */         embedChannelId(), this.features, 
/*      */         
/* 2493 */         applicationId(), 
/* 2494 */         widgetEnabled(), 
/* 2495 */         widgetChannelId(), 
/* 2496 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 2498 */         rulesChannelId(), 
/* 2499 */         maxPresences(), 
/* 2500 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 2504 */         premiumSubscriptionCount(), newValue, 
/*      */         
/* 2506 */         maxVideoChannelUsers(), 
/* 2507 */         approximateMemberCount(), 
/* 2508 */         approximatePresenceCount(), 
/* 2509 */         welcomeScreen(), 
/* 2510 */         nsfw(), 
/* 2511 */         safetyAlertsChannelId());
/*      */   }
/*      */   
/*      */   public ImmutableUserGuildData withPublicUpdatesChannelId(long value) {
/* 2515 */     Optional<Id> newValue = Optional.of(Id.of(value));
/* 2516 */     return new ImmutableUserGuildData(this, 
/*      */         
/* 2518 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2523 */         owner(), 
/* 2524 */         permissions(), 
/* 2525 */         afkChannelId(), 
/* 2526 */         embedEnabled(), 
/* 2527 */         embedChannelId(), this.features, 
/*      */         
/* 2529 */         applicationId(), 
/* 2530 */         widgetEnabled(), 
/* 2531 */         widgetChannelId(), 
/* 2532 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 2534 */         rulesChannelId(), 
/* 2535 */         maxPresences(), 
/* 2536 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 2540 */         premiumSubscriptionCount(), newValue, 
/*      */         
/* 2542 */         maxVideoChannelUsers(), 
/* 2543 */         approximateMemberCount(), 
/* 2544 */         approximatePresenceCount(), 
/* 2545 */         welcomeScreen(), 
/* 2546 */         nsfw(), 
/* 2547 */         safetyAlertsChannelId());
/*      */   }
/*      */   
/*      */   public ImmutableUserGuildData withMaxVideoChannelUsers(Possible<Integer> value) {
/* 2551 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/* 2552 */     return new ImmutableUserGuildData(this, 
/*      */         
/* 2554 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2559 */         owner(), 
/* 2560 */         permissions(), 
/* 2561 */         afkChannelId(), 
/* 2562 */         embedEnabled(), 
/* 2563 */         embedChannelId(), this.features, 
/*      */         
/* 2565 */         applicationId(), 
/* 2566 */         widgetEnabled(), 
/* 2567 */         widgetChannelId(), 
/* 2568 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 2570 */         rulesChannelId(), 
/* 2571 */         maxPresences(), 
/* 2572 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 2576 */         premiumSubscriptionCount(), 
/* 2577 */         publicUpdatesChannelId(), newValue, 
/*      */         
/* 2579 */         approximateMemberCount(), 
/* 2580 */         approximatePresenceCount(), 
/* 2581 */         welcomeScreen(), 
/* 2582 */         nsfw(), 
/* 2583 */         safetyAlertsChannelId());
/*      */   }
/*      */   
/*      */   public ImmutableUserGuildData withMaxVideoChannelUsers(Integer value) {
/* 2587 */     Possible<Integer> newValue = Possible.of(value);
/* 2588 */     return new ImmutableUserGuildData(this, 
/*      */         
/* 2590 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2595 */         owner(), 
/* 2596 */         permissions(), 
/* 2597 */         afkChannelId(), 
/* 2598 */         embedEnabled(), 
/* 2599 */         embedChannelId(), this.features, 
/*      */         
/* 2601 */         applicationId(), 
/* 2602 */         widgetEnabled(), 
/* 2603 */         widgetChannelId(), 
/* 2604 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 2606 */         rulesChannelId(), 
/* 2607 */         maxPresences(), 
/* 2608 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 2612 */         premiumSubscriptionCount(), 
/* 2613 */         publicUpdatesChannelId(), newValue, 
/*      */         
/* 2615 */         approximateMemberCount(), 
/* 2616 */         approximatePresenceCount(), 
/* 2617 */         welcomeScreen(), 
/* 2618 */         nsfw(), 
/* 2619 */         safetyAlertsChannelId());
/*      */   }
/*      */   
/*      */   public ImmutableUserGuildData withApproximateMemberCount(Possible<Integer> value) {
/* 2623 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/* 2624 */     return new ImmutableUserGuildData(this, 
/*      */         
/* 2626 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2631 */         owner(), 
/* 2632 */         permissions(), 
/* 2633 */         afkChannelId(), 
/* 2634 */         embedEnabled(), 
/* 2635 */         embedChannelId(), this.features, 
/*      */         
/* 2637 */         applicationId(), 
/* 2638 */         widgetEnabled(), 
/* 2639 */         widgetChannelId(), 
/* 2640 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 2642 */         rulesChannelId(), 
/* 2643 */         maxPresences(), 
/* 2644 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 2648 */         premiumSubscriptionCount(), 
/* 2649 */         publicUpdatesChannelId(), 
/* 2650 */         maxVideoChannelUsers(), newValue, 
/*      */         
/* 2652 */         approximatePresenceCount(), 
/* 2653 */         welcomeScreen(), 
/* 2654 */         nsfw(), 
/* 2655 */         safetyAlertsChannelId());
/*      */   }
/*      */   
/*      */   public ImmutableUserGuildData withApproximateMemberCount(Integer value) {
/* 2659 */     Possible<Integer> newValue = Possible.of(value);
/* 2660 */     return new ImmutableUserGuildData(this, 
/*      */         
/* 2662 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2667 */         owner(), 
/* 2668 */         permissions(), 
/* 2669 */         afkChannelId(), 
/* 2670 */         embedEnabled(), 
/* 2671 */         embedChannelId(), this.features, 
/*      */         
/* 2673 */         applicationId(), 
/* 2674 */         widgetEnabled(), 
/* 2675 */         widgetChannelId(), 
/* 2676 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 2678 */         rulesChannelId(), 
/* 2679 */         maxPresences(), 
/* 2680 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 2684 */         premiumSubscriptionCount(), 
/* 2685 */         publicUpdatesChannelId(), 
/* 2686 */         maxVideoChannelUsers(), newValue, 
/*      */         
/* 2688 */         approximatePresenceCount(), 
/* 2689 */         welcomeScreen(), 
/* 2690 */         nsfw(), 
/* 2691 */         safetyAlertsChannelId());
/*      */   }
/*      */   
/*      */   public ImmutableUserGuildData withApproximatePresenceCount(Possible<Integer> value) {
/* 2695 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/* 2696 */     return new ImmutableUserGuildData(this, 
/*      */         
/* 2698 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2703 */         owner(), 
/* 2704 */         permissions(), 
/* 2705 */         afkChannelId(), 
/* 2706 */         embedEnabled(), 
/* 2707 */         embedChannelId(), this.features, 
/*      */         
/* 2709 */         applicationId(), 
/* 2710 */         widgetEnabled(), 
/* 2711 */         widgetChannelId(), 
/* 2712 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 2714 */         rulesChannelId(), 
/* 2715 */         maxPresences(), 
/* 2716 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 2720 */         premiumSubscriptionCount(), 
/* 2721 */         publicUpdatesChannelId(), 
/* 2722 */         maxVideoChannelUsers(), 
/* 2723 */         approximateMemberCount(), newValue, 
/*      */         
/* 2725 */         welcomeScreen(), 
/* 2726 */         nsfw(), 
/* 2727 */         safetyAlertsChannelId());
/*      */   }
/*      */   
/*      */   public ImmutableUserGuildData withApproximatePresenceCount(Integer value) {
/* 2731 */     Possible<Integer> newValue = Possible.of(value);
/* 2732 */     return new ImmutableUserGuildData(this, 
/*      */         
/* 2734 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2739 */         owner(), 
/* 2740 */         permissions(), 
/* 2741 */         afkChannelId(), 
/* 2742 */         embedEnabled(), 
/* 2743 */         embedChannelId(), this.features, 
/*      */         
/* 2745 */         applicationId(), 
/* 2746 */         widgetEnabled(), 
/* 2747 */         widgetChannelId(), 
/* 2748 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 2750 */         rulesChannelId(), 
/* 2751 */         maxPresences(), 
/* 2752 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 2756 */         premiumSubscriptionCount(), 
/* 2757 */         publicUpdatesChannelId(), 
/* 2758 */         maxVideoChannelUsers(), 
/* 2759 */         approximateMemberCount(), newValue, 
/*      */         
/* 2761 */         welcomeScreen(), 
/* 2762 */         nsfw(), 
/* 2763 */         safetyAlertsChannelId());
/*      */   }
/*      */   
/*      */   public ImmutableUserGuildData withWelcomeScreen(Possible<WelcomeScreenData> value) {
/* 2767 */     Possible<WelcomeScreenData> newValue = Objects.<Possible<WelcomeScreenData>>requireNonNull(value);
/* 2768 */     return new ImmutableUserGuildData(this, 
/*      */         
/* 2770 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2775 */         owner(), 
/* 2776 */         permissions(), 
/* 2777 */         afkChannelId(), 
/* 2778 */         embedEnabled(), 
/* 2779 */         embedChannelId(), this.features, 
/*      */         
/* 2781 */         applicationId(), 
/* 2782 */         widgetEnabled(), 
/* 2783 */         widgetChannelId(), 
/* 2784 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 2786 */         rulesChannelId(), 
/* 2787 */         maxPresences(), 
/* 2788 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 2792 */         premiumSubscriptionCount(), 
/* 2793 */         publicUpdatesChannelId(), 
/* 2794 */         maxVideoChannelUsers(), 
/* 2795 */         approximateMemberCount(), 
/* 2796 */         approximatePresenceCount(), newValue, 
/*      */         
/* 2798 */         nsfw(), 
/* 2799 */         safetyAlertsChannelId());
/*      */   }
/*      */   
/*      */   public ImmutableUserGuildData withWelcomeScreen(WelcomeScreenData value) {
/* 2803 */     Possible<WelcomeScreenData> newValue = Possible.of(value);
/* 2804 */     return new ImmutableUserGuildData(this, 
/*      */         
/* 2806 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2811 */         owner(), 
/* 2812 */         permissions(), 
/* 2813 */         afkChannelId(), 
/* 2814 */         embedEnabled(), 
/* 2815 */         embedChannelId(), this.features, 
/*      */         
/* 2817 */         applicationId(), 
/* 2818 */         widgetEnabled(), 
/* 2819 */         widgetChannelId(), 
/* 2820 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 2822 */         rulesChannelId(), 
/* 2823 */         maxPresences(), 
/* 2824 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 2828 */         premiumSubscriptionCount(), 
/* 2829 */         publicUpdatesChannelId(), 
/* 2830 */         maxVideoChannelUsers(), 
/* 2831 */         approximateMemberCount(), 
/* 2832 */         approximatePresenceCount(), newValue, 
/*      */         
/* 2834 */         nsfw(), 
/* 2835 */         safetyAlertsChannelId());
/*      */   }
/*      */   
/*      */   public ImmutableUserGuildData withNsfw(Possible<Boolean> value) {
/* 2839 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/* 2840 */     return new ImmutableUserGuildData(this, 
/*      */         
/* 2842 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2847 */         owner(), 
/* 2848 */         permissions(), 
/* 2849 */         afkChannelId(), 
/* 2850 */         embedEnabled(), 
/* 2851 */         embedChannelId(), this.features, 
/*      */         
/* 2853 */         applicationId(), 
/* 2854 */         widgetEnabled(), 
/* 2855 */         widgetChannelId(), 
/* 2856 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 2858 */         rulesChannelId(), 
/* 2859 */         maxPresences(), 
/* 2860 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 2864 */         premiumSubscriptionCount(), 
/* 2865 */         publicUpdatesChannelId(), 
/* 2866 */         maxVideoChannelUsers(), 
/* 2867 */         approximateMemberCount(), 
/* 2868 */         approximatePresenceCount(), 
/* 2869 */         welcomeScreen(), newValue, 
/*      */         
/* 2871 */         safetyAlertsChannelId());
/*      */   }
/*      */   
/*      */   public ImmutableUserGuildData withNsfw(Boolean value) {
/* 2875 */     Possible<Boolean> newValue = Possible.of(value);
/* 2876 */     return new ImmutableUserGuildData(this, 
/*      */         
/* 2878 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2883 */         owner(), 
/* 2884 */         permissions(), 
/* 2885 */         afkChannelId(), 
/* 2886 */         embedEnabled(), 
/* 2887 */         embedChannelId(), this.features, 
/*      */         
/* 2889 */         applicationId(), 
/* 2890 */         widgetEnabled(), 
/* 2891 */         widgetChannelId(), 
/* 2892 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 2894 */         rulesChannelId(), 
/* 2895 */         maxPresences(), 
/* 2896 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 2900 */         premiumSubscriptionCount(), 
/* 2901 */         publicUpdatesChannelId(), 
/* 2902 */         maxVideoChannelUsers(), 
/* 2903 */         approximateMemberCount(), 
/* 2904 */         approximatePresenceCount(), 
/* 2905 */         welcomeScreen(), newValue, 
/*      */         
/* 2907 */         safetyAlertsChannelId());
/*      */   }
/*      */   
/*      */   public ImmutableUserGuildData withSafetyAlertsChannelId(Optional<Id> value) {
/* 2911 */     Optional<Id> newValue = Objects.<Optional<Id>>requireNonNull(value);
/* 2912 */     return new ImmutableUserGuildData(this, 
/*      */         
/* 2914 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2919 */         owner(), 
/* 2920 */         permissions(), 
/* 2921 */         afkChannelId(), 
/* 2922 */         embedEnabled(), 
/* 2923 */         embedChannelId(), this.features, 
/*      */         
/* 2925 */         applicationId(), 
/* 2926 */         widgetEnabled(), 
/* 2927 */         widgetChannelId(), 
/* 2928 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 2930 */         rulesChannelId(), 
/* 2931 */         maxPresences(), 
/* 2932 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 2936 */         premiumSubscriptionCount(), 
/* 2937 */         publicUpdatesChannelId(), 
/* 2938 */         maxVideoChannelUsers(), 
/* 2939 */         approximateMemberCount(), 
/* 2940 */         approximatePresenceCount(), 
/* 2941 */         welcomeScreen(), 
/* 2942 */         nsfw(), newValue);
/*      */   }
/*      */ 
/*      */   
/*      */   public ImmutableUserGuildData withSafetyAlertsChannelId(long value) {
/* 2947 */     Optional<Id> newValue = Optional.of(Id.of(value));
/* 2948 */     return new ImmutableUserGuildData(this, 
/*      */         
/* 2950 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2955 */         owner(), 
/* 2956 */         permissions(), 
/* 2957 */         afkChannelId(), 
/* 2958 */         embedEnabled(), 
/* 2959 */         embedChannelId(), this.features, 
/*      */         
/* 2961 */         applicationId(), 
/* 2962 */         widgetEnabled(), 
/* 2963 */         widgetChannelId(), 
/* 2964 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 2966 */         rulesChannelId(), 
/* 2967 */         maxPresences(), 
/* 2968 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 2972 */         premiumSubscriptionCount(), 
/* 2973 */         publicUpdatesChannelId(), 
/* 2974 */         maxVideoChannelUsers(), 
/* 2975 */         approximateMemberCount(), 
/* 2976 */         approximatePresenceCount(), 
/* 2977 */         welcomeScreen(), 
/* 2978 */         nsfw(), newValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean equals(Object another) {
/* 2988 */     if (this == another) return true; 
/* 2989 */     return (another instanceof ImmutableUserGuildData && 
/* 2990 */       equalTo(0, (ImmutableUserGuildData)another));
/*      */   }
/*      */   
/*      */   private boolean equalTo(int synthetic, ImmutableUserGuildData another) {
/* 2994 */     return (Objects.equals(Long.valueOf(this.id_value), Long.valueOf(another.id_value)) && this.name
/* 2995 */       .equals(another.name) && 
/* 2996 */       Objects.equals(this.icon, another.icon) && 
/* 2997 */       Objects.equals(this.splash, another.splash) && 
/* 2998 */       Objects.equals(this.discoverySplash, another.discoverySplash) && 
/* 2999 */       owner().equals(another.owner()) && 
/* 3000 */       permissions().equals(another.permissions()) && 
/* 3001 */       afkChannelId().equals(another.afkChannelId()) && 
/* 3002 */       embedEnabled().equals(another.embedEnabled()) && 
/* 3003 */       embedChannelId().equals(another.embedChannelId()) && this.features
/* 3004 */       .equals(another.features) && 
/* 3005 */       applicationId().equals(another.applicationId()) && 
/* 3006 */       widgetEnabled().equals(another.widgetEnabled()) && 
/* 3007 */       widgetChannelId().equals(another.widgetChannelId()) && 
/* 3008 */       systemChannelId().equals(another.systemChannelId()) && 
/* 3009 */       Objects.equals(this.systemChannelFlags, another.systemChannelFlags) && 
/* 3010 */       rulesChannelId().equals(another.rulesChannelId()) && 
/* 3011 */       maxPresences().equals(another.maxPresences()) && 
/* 3012 */       maxMembers().equals(another.maxMembers()) && 
/* 3013 */       Objects.equals(this.vanityUrlCode, another.vanityUrlCode) && 
/* 3014 */       Objects.equals(this.description, another.description) && 
/* 3015 */       Objects.equals(this.banner, another.banner) && 
/* 3016 */       premiumSubscriptionCount().equals(another.premiumSubscriptionCount()) && 
/* 3017 */       publicUpdatesChannelId().equals(another.publicUpdatesChannelId()) && 
/* 3018 */       maxVideoChannelUsers().equals(another.maxVideoChannelUsers()) && 
/* 3019 */       approximateMemberCount().equals(another.approximateMemberCount()) && 
/* 3020 */       approximatePresenceCount().equals(another.approximatePresenceCount()) && 
/* 3021 */       welcomeScreen().equals(another.welcomeScreen()) && 
/* 3022 */       nsfw().equals(another.nsfw()) && 
/* 3023 */       safetyAlertsChannelId().equals(another.safetyAlertsChannelId()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int hashCode() {
/* 3032 */     int h = 5381;
/* 3033 */     h += (h << 5) + Objects.hashCode(Long.valueOf(this.id_value));
/* 3034 */     h += (h << 5) + this.name.hashCode();
/* 3035 */     h += (h << 5) + Objects.hashCode(this.icon);
/* 3036 */     h += (h << 5) + Objects.hashCode(this.splash);
/* 3037 */     h += (h << 5) + Objects.hashCode(this.discoverySplash);
/* 3038 */     h += (h << 5) + owner().hashCode();
/* 3039 */     h += (h << 5) + permissions().hashCode();
/* 3040 */     h += (h << 5) + afkChannelId().hashCode();
/* 3041 */     h += (h << 5) + embedEnabled().hashCode();
/* 3042 */     h += (h << 5) + embedChannelId().hashCode();
/* 3043 */     h += (h << 5) + this.features.hashCode();
/* 3044 */     h += (h << 5) + applicationId().hashCode();
/* 3045 */     h += (h << 5) + widgetEnabled().hashCode();
/* 3046 */     h += (h << 5) + widgetChannelId().hashCode();
/* 3047 */     h += (h << 5) + systemChannelId().hashCode();
/* 3048 */     h += (h << 5) + Objects.hashCode(this.systemChannelFlags);
/* 3049 */     h += (h << 5) + rulesChannelId().hashCode();
/* 3050 */     h += (h << 5) + maxPresences().hashCode();
/* 3051 */     h += (h << 5) + maxMembers().hashCode();
/* 3052 */     h += (h << 5) + Objects.hashCode(this.vanityUrlCode);
/* 3053 */     h += (h << 5) + Objects.hashCode(this.description);
/* 3054 */     h += (h << 5) + Objects.hashCode(this.banner);
/* 3055 */     h += (h << 5) + premiumSubscriptionCount().hashCode();
/* 3056 */     h += (h << 5) + publicUpdatesChannelId().hashCode();
/* 3057 */     h += (h << 5) + maxVideoChannelUsers().hashCode();
/* 3058 */     h += (h << 5) + approximateMemberCount().hashCode();
/* 3059 */     h += (h << 5) + approximatePresenceCount().hashCode();
/* 3060 */     h += (h << 5) + welcomeScreen().hashCode();
/* 3061 */     h += (h << 5) + nsfw().hashCode();
/* 3062 */     h += (h << 5) + safetyAlertsChannelId().hashCode();
/* 3063 */     return h;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/* 3072 */     StringBuilder builder = new StringBuilder("UserGuildData{");
/* 3073 */     builder.append("id=").append(Objects.toString(Long.valueOf(this.id_value)));
/* 3074 */     builder.append(", ");
/* 3075 */     builder.append("name=").append(this.name);
/* 3076 */     if (this.icon != null) {
/* 3077 */       builder.append(", ");
/* 3078 */       builder.append("icon=").append(this.icon);
/*      */     } 
/* 3080 */     if (this.splash != null) {
/* 3081 */       builder.append(", ");
/* 3082 */       builder.append("splash=").append(this.splash);
/*      */     } 
/* 3084 */     if (this.discoverySplash != null) {
/* 3085 */       builder.append(", ");
/* 3086 */       builder.append("discoverySplash=").append(this.discoverySplash);
/*      */     } 
/* 3088 */     builder.append(", ");
/* 3089 */     builder.append("owner=").append(owner().toString());
/* 3090 */     builder.append(", ");
/* 3091 */     builder.append("permissions=").append(permissions().toString());
/* 3092 */     builder.append(", ");
/* 3093 */     builder.append("afkChannelId=").append(afkChannelId().toString());
/* 3094 */     builder.append(", ");
/* 3095 */     builder.append("embedEnabled=").append(embedEnabled().toString());
/* 3096 */     builder.append(", ");
/* 3097 */     builder.append("embedChannelId=").append(embedChannelId().toString());
/* 3098 */     builder.append(", ");
/* 3099 */     builder.append("features=").append(this.features);
/* 3100 */     builder.append(", ");
/* 3101 */     builder.append("applicationId=").append(applicationId().toString());
/* 3102 */     builder.append(", ");
/* 3103 */     builder.append("widgetEnabled=").append(widgetEnabled().toString());
/* 3104 */     builder.append(", ");
/* 3105 */     builder.append("widgetChannelId=").append(widgetChannelId().toString());
/* 3106 */     builder.append(", ");
/* 3107 */     builder.append("systemChannelId=").append(systemChannelId().toString());
/* 3108 */     if (this.systemChannelFlags != null) {
/* 3109 */       builder.append(", ");
/* 3110 */       builder.append("systemChannelFlags=").append(this.systemChannelFlags);
/*      */     } 
/* 3112 */     builder.append(", ");
/* 3113 */     builder.append("rulesChannelId=").append(rulesChannelId().toString());
/* 3114 */     builder.append(", ");
/* 3115 */     builder.append("maxPresences=").append(maxPresences().toString());
/* 3116 */     builder.append(", ");
/* 3117 */     builder.append("maxMembers=").append(maxMembers().toString());
/* 3118 */     if (this.vanityUrlCode != null) {
/* 3119 */       builder.append(", ");
/* 3120 */       builder.append("vanityUrlCode=").append(this.vanityUrlCode);
/*      */     } 
/* 3122 */     if (this.description != null) {
/* 3123 */       builder.append(", ");
/* 3124 */       builder.append("description=").append(this.description);
/*      */     } 
/* 3126 */     if (this.banner != null) {
/* 3127 */       builder.append(", ");
/* 3128 */       builder.append("banner=").append(this.banner);
/*      */     } 
/* 3130 */     builder.append(", ");
/* 3131 */     builder.append("premiumSubscriptionCount=").append(premiumSubscriptionCount().toString());
/* 3132 */     builder.append(", ");
/* 3133 */     builder.append("publicUpdatesChannelId=").append(publicUpdatesChannelId().toString());
/* 3134 */     builder.append(", ");
/* 3135 */     builder.append("maxVideoChannelUsers=").append(maxVideoChannelUsers().toString());
/* 3136 */     builder.append(", ");
/* 3137 */     builder.append("approximateMemberCount=").append(approximateMemberCount().toString());
/* 3138 */     builder.append(", ");
/* 3139 */     builder.append("approximatePresenceCount=").append(approximatePresenceCount().toString());
/* 3140 */     builder.append(", ");
/* 3141 */     builder.append("welcomeScreen=").append(welcomeScreen().toString());
/* 3142 */     builder.append(", ");
/* 3143 */     builder.append("nsfw=").append(nsfw().toString());
/* 3144 */     builder.append(", ");
/* 3145 */     builder.append("safetyAlertsChannelId=").append(safetyAlertsChannelId().toString());
/* 3146 */     return builder.append("}").toString();
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonDeserialize
/*      */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*      */   @Generated(from = "UserGuildData", generator = "Immutables")
/*      */   static final class Json
/*      */     implements UserGuildData
/*      */   {
/*      */     Id id;
/*      */     
/*      */     String name;
/* 3160 */     Optional<String> icon = Optional.empty();
/* 3161 */     Optional<String> splash = Optional.empty();
/* 3162 */     Optional<String> discoverySplash = Optional.empty();
/*      */     
/* 3164 */     Possible<Boolean> owner = Possible.absent();
/*      */ 
/*      */     
/* 3167 */     Possible<Long> permissions = Possible.absent();
/*      */ 
/*      */     
/* 3170 */     Optional<Id> afkChannelId = Optional.empty();
/*      */ 
/*      */     
/* 3173 */     Possible<Boolean> embedEnabled = Possible.absent();
/*      */ 
/*      */     
/* 3176 */     Possible<Optional<Id>> embedChannelId = Possible.absent();
/*      */     
/* 3178 */     List<String> features = Collections.emptyList();
/*      */     
/* 3180 */     Optional<Id> applicationId = Optional.empty();
/*      */ 
/*      */     
/* 3183 */     Possible<Boolean> widgetEnabled = Possible.absent();
/*      */ 
/*      */     
/* 3186 */     Possible<Optional<Id>> widgetChannelId = Possible.absent();
/*      */ 
/*      */     
/* 3189 */     Optional<Id> systemChannelId = Optional.empty();
/*      */     
/* 3191 */     OptionalInt systemChannelFlags = OptionalInt.empty();
/*      */     
/* 3193 */     Optional<Id> rulesChannelId = Optional.empty();
/*      */ 
/*      */     
/* 3196 */     Possible<Optional<Integer>> maxPresences = Possible.absent();
/*      */ 
/*      */     
/* 3199 */     Possible<Integer> maxMembers = Possible.absent();
/*      */     
/* 3201 */     Optional<String> vanityUrlCode = Optional.empty();
/* 3202 */     Optional<String> description = Optional.empty();
/* 3203 */     Optional<String> banner = Optional.empty();
/*      */     
/* 3205 */     Possible<Integer> premiumSubscriptionCount = Possible.absent();
/*      */ 
/*      */     
/* 3208 */     Optional<Id> publicUpdatesChannelId = Optional.empty();
/*      */ 
/*      */     
/* 3211 */     Possible<Integer> maxVideoChannelUsers = Possible.absent();
/*      */ 
/*      */     
/* 3214 */     Possible<Integer> approximateMemberCount = Possible.absent();
/*      */ 
/*      */     
/* 3217 */     Possible<Integer> approximatePresenceCount = Possible.absent();
/*      */ 
/*      */     
/* 3220 */     Possible<WelcomeScreenData> welcomeScreen = Possible.absent();
/*      */ 
/*      */     
/* 3223 */     Possible<Boolean> nsfw = Possible.absent();
/*      */ 
/*      */     
/* 3226 */     Optional<Id> safetyAlertsChannelId = Optional.empty();
/*      */     
/*      */     @JsonProperty("id")
/*      */     public void setId(Id id) {
/* 3230 */       this.id = id;
/*      */     }
/*      */     @JsonProperty("name")
/*      */     public void setName(String name) {
/* 3234 */       this.name = name;
/*      */     }
/*      */     @JsonProperty("icon")
/*      */     public void setIcon(Optional<String> icon) {
/* 3238 */       this.icon = icon;
/*      */     }
/*      */     @JsonProperty("splash")
/*      */     public void setSplash(Optional<String> splash) {
/* 3242 */       this.splash = splash;
/*      */     }
/*      */     @JsonProperty("discovery_splash")
/*      */     public void setDiscoverySplash(Optional<String> discoverySplash) {
/* 3246 */       this.discoverySplash = discoverySplash;
/*      */     }
/*      */     @JsonProperty("owner")
/*      */     public void setOwner(Possible<Boolean> owner) {
/* 3250 */       this.owner = owner;
/*      */     }
/*      */     @JsonProperty("permissions")
/*      */     public void setPermissions(Possible<Long> permissions) {
/* 3254 */       this.permissions = permissions;
/*      */     }
/*      */     @JsonProperty("afk_channel_id")
/*      */     public void setAfkChannelId(Optional<Id> afkChannelId) {
/* 3258 */       this.afkChannelId = afkChannelId;
/*      */     }
/*      */     @JsonProperty("embed_enabled")
/*      */     public void setEmbedEnabled(Possible<Boolean> embedEnabled) {
/* 3262 */       this.embedEnabled = embedEnabled;
/*      */     }
/*      */     @JsonProperty("embed_channel_id")
/*      */     public void setEmbedChannelId(Possible<Optional<Id>> embedChannelId) {
/* 3266 */       this.embedChannelId = embedChannelId;
/*      */     }
/*      */     @JsonProperty("features")
/*      */     public void setFeatures(List<String> features) {
/* 3270 */       this.features = features;
/*      */     }
/*      */     @JsonProperty("application_id")
/*      */     public void setApplicationId(Optional<Id> applicationId) {
/* 3274 */       this.applicationId = applicationId;
/*      */     }
/*      */     @JsonProperty("widget_enabled")
/*      */     public void setWidgetEnabled(Possible<Boolean> widgetEnabled) {
/* 3278 */       this.widgetEnabled = widgetEnabled;
/*      */     }
/*      */     @JsonProperty("widget_channel_id")
/*      */     public void setWidgetChannelId(Possible<Optional<Id>> widgetChannelId) {
/* 3282 */       this.widgetChannelId = widgetChannelId;
/*      */     }
/*      */     @JsonProperty("system_channel_id")
/*      */     public void setSystemChannelId(Optional<Id> systemChannelId) {
/* 3286 */       this.systemChannelId = systemChannelId;
/*      */     }
/*      */     @JsonProperty("system_channel_flags")
/*      */     public void setSystemChannelFlags(OptionalInt systemChannelFlags) {
/* 3290 */       this.systemChannelFlags = systemChannelFlags;
/*      */     }
/*      */     @JsonProperty("rules_channel_id")
/*      */     public void setRulesChannelId(Optional<Id> rulesChannelId) {
/* 3294 */       this.rulesChannelId = rulesChannelId;
/*      */     }
/*      */     @JsonProperty("max_presences")
/*      */     public void setMaxPresences(Possible<Optional<Integer>> maxPresences) {
/* 3298 */       this.maxPresences = maxPresences;
/*      */     }
/*      */     @JsonProperty("max_members")
/*      */     public void setMaxMembers(Possible<Integer> maxMembers) {
/* 3302 */       this.maxMembers = maxMembers;
/*      */     }
/*      */     @JsonProperty("vanity_url_code")
/*      */     public void setVanityUrlCode(Optional<String> vanityUrlCode) {
/* 3306 */       this.vanityUrlCode = vanityUrlCode;
/*      */     }
/*      */     @JsonProperty("description")
/*      */     public void setDescription(Optional<String> description) {
/* 3310 */       this.description = description;
/*      */     }
/*      */     @JsonProperty("banner")
/*      */     public void setBanner(Optional<String> banner) {
/* 3314 */       this.banner = banner;
/*      */     }
/*      */     @JsonProperty("premium_subscription_count")
/*      */     public void setPremiumSubscriptionCount(Possible<Integer> premiumSubscriptionCount) {
/* 3318 */       this.premiumSubscriptionCount = premiumSubscriptionCount;
/*      */     }
/*      */     @JsonProperty("public_updates_channel_id")
/*      */     public void setPublicUpdatesChannelId(Optional<Id> publicUpdatesChannelId) {
/* 3322 */       this.publicUpdatesChannelId = publicUpdatesChannelId;
/*      */     }
/*      */     @JsonProperty("max_video_channel_users")
/*      */     public void setMaxVideoChannelUsers(Possible<Integer> maxVideoChannelUsers) {
/* 3326 */       this.maxVideoChannelUsers = maxVideoChannelUsers;
/*      */     }
/*      */     @JsonProperty("approximate_member_count")
/*      */     public void setApproximateMemberCount(Possible<Integer> approximateMemberCount) {
/* 3330 */       this.approximateMemberCount = approximateMemberCount;
/*      */     }
/*      */     @JsonProperty("approximate_presence_count")
/*      */     public void setApproximatePresenceCount(Possible<Integer> approximatePresenceCount) {
/* 3334 */       this.approximatePresenceCount = approximatePresenceCount;
/*      */     }
/*      */     @JsonProperty("welcome_screen")
/*      */     public void setWelcomeScreen(Possible<WelcomeScreenData> welcomeScreen) {
/* 3338 */       this.welcomeScreen = welcomeScreen;
/*      */     }
/*      */     @JsonProperty("nsfw")
/*      */     public void setNsfw(Possible<Boolean> nsfw) {
/* 3342 */       this.nsfw = nsfw;
/*      */     }
/*      */     @JsonProperty("safety_alerts_channel_id")
/*      */     public void setSafetyAlertsChannelId(Optional<Id> safetyAlertsChannelId) {
/* 3346 */       this.safetyAlertsChannelId = safetyAlertsChannelId;
/*      */     }
/*      */     public Id id() {
/* 3349 */       throw new UnsupportedOperationException();
/*      */     } public String name() {
/* 3351 */       throw new UnsupportedOperationException();
/*      */     } public Optional<String> icon() {
/* 3353 */       throw new UnsupportedOperationException();
/*      */     } public Optional<String> splash() {
/* 3355 */       throw new UnsupportedOperationException();
/*      */     } public Optional<String> discoverySplash() {
/* 3357 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Boolean> owner() {
/* 3359 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Long> permissions() {
/* 3361 */       throw new UnsupportedOperationException();
/*      */     } public Optional<Id> afkChannelId() {
/* 3363 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Boolean> embedEnabled() {
/* 3365 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Optional<Id>> embedChannelId() {
/* 3367 */       throw new UnsupportedOperationException();
/*      */     } public List<String> features() {
/* 3369 */       throw new UnsupportedOperationException();
/*      */     } public Optional<Id> applicationId() {
/* 3371 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Boolean> widgetEnabled() {
/* 3373 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Optional<Id>> widgetChannelId() {
/* 3375 */       throw new UnsupportedOperationException();
/*      */     } public Optional<Id> systemChannelId() {
/* 3377 */       throw new UnsupportedOperationException();
/*      */     } public OptionalInt systemChannelFlags() {
/* 3379 */       throw new UnsupportedOperationException();
/*      */     } public Optional<Id> rulesChannelId() {
/* 3381 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Optional<Integer>> maxPresences() {
/* 3383 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Integer> maxMembers() {
/* 3385 */       throw new UnsupportedOperationException();
/*      */     } public Optional<String> vanityUrlCode() {
/* 3387 */       throw new UnsupportedOperationException();
/*      */     } public Optional<String> description() {
/* 3389 */       throw new UnsupportedOperationException();
/*      */     } public Optional<String> banner() {
/* 3391 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Integer> premiumSubscriptionCount() {
/* 3393 */       throw new UnsupportedOperationException();
/*      */     } public Optional<Id> publicUpdatesChannelId() {
/* 3395 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Integer> maxVideoChannelUsers() {
/* 3397 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Integer> approximateMemberCount() {
/* 3399 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Integer> approximatePresenceCount() {
/* 3401 */       throw new UnsupportedOperationException();
/*      */     } public Possible<WelcomeScreenData> welcomeScreen() {
/* 3403 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Boolean> nsfw() {
/* 3405 */       throw new UnsupportedOperationException();
/*      */     } public Optional<Id> safetyAlertsChannelId() {
/* 3407 */       throw new UnsupportedOperationException();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*      */   static ImmutableUserGuildData fromJson(Json json) {
/* 3418 */     Builder builder = builder();
/* 3419 */     if (json.id != null) {
/* 3420 */       builder.id(json.id);
/*      */     }
/* 3422 */     if (json.name != null) {
/* 3423 */       builder.name(json.name);
/*      */     }
/* 3425 */     if (json.icon != null) {
/* 3426 */       builder.icon(json.icon);
/*      */     }
/* 3428 */     if (json.splash != null) {
/* 3429 */       builder.splash(json.splash);
/*      */     }
/* 3431 */     if (json.discoverySplash != null) {
/* 3432 */       builder.discoverySplash(json.discoverySplash);
/*      */     }
/* 3434 */     if (json.owner != null) {
/* 3435 */       builder.owner(json.owner);
/*      */     }
/* 3437 */     if (json.permissions != null) {
/* 3438 */       builder.permissions(json.permissions);
/*      */     }
/* 3440 */     if (json.afkChannelId != null) {
/* 3441 */       builder.afkChannelId(json.afkChannelId);
/*      */     }
/* 3443 */     if (json.embedEnabled != null) {
/* 3444 */       builder.embedEnabled(json.embedEnabled);
/*      */     }
/* 3446 */     if (json.embedChannelId != null) {
/* 3447 */       builder.embedChannelId(json.embedChannelId);
/*      */     }
/* 3449 */     if (json.features != null) {
/* 3450 */       builder.addAllFeatures(json.features);
/*      */     }
/* 3452 */     if (json.applicationId != null) {
/* 3453 */       builder.applicationId(json.applicationId);
/*      */     }
/* 3455 */     if (json.widgetEnabled != null) {
/* 3456 */       builder.widgetEnabled(json.widgetEnabled);
/*      */     }
/* 3458 */     if (json.widgetChannelId != null) {
/* 3459 */       builder.widgetChannelId(json.widgetChannelId);
/*      */     }
/* 3461 */     if (json.systemChannelId != null) {
/* 3462 */       builder.systemChannelId(json.systemChannelId);
/*      */     }
/* 3464 */     if (json.systemChannelFlags != null) {
/* 3465 */       builder.systemChannelFlags(json.systemChannelFlags);
/*      */     }
/* 3467 */     if (json.rulesChannelId != null) {
/* 3468 */       builder.rulesChannelId(json.rulesChannelId);
/*      */     }
/* 3470 */     if (json.maxPresences != null) {
/* 3471 */       builder.maxPresences(json.maxPresences);
/*      */     }
/* 3473 */     if (json.maxMembers != null) {
/* 3474 */       builder.maxMembers(json.maxMembers);
/*      */     }
/* 3476 */     if (json.vanityUrlCode != null) {
/* 3477 */       builder.vanityUrlCode(json.vanityUrlCode);
/*      */     }
/* 3479 */     if (json.description != null) {
/* 3480 */       builder.description(json.description);
/*      */     }
/* 3482 */     if (json.banner != null) {
/* 3483 */       builder.banner(json.banner);
/*      */     }
/* 3485 */     if (json.premiumSubscriptionCount != null) {
/* 3486 */       builder.premiumSubscriptionCount(json.premiumSubscriptionCount);
/*      */     }
/* 3488 */     if (json.publicUpdatesChannelId != null) {
/* 3489 */       builder.publicUpdatesChannelId(json.publicUpdatesChannelId);
/*      */     }
/* 3491 */     if (json.maxVideoChannelUsers != null) {
/* 3492 */       builder.maxVideoChannelUsers(json.maxVideoChannelUsers);
/*      */     }
/* 3494 */     if (json.approximateMemberCount != null) {
/* 3495 */       builder.approximateMemberCount(json.approximateMemberCount);
/*      */     }
/* 3497 */     if (json.approximatePresenceCount != null) {
/* 3498 */       builder.approximatePresenceCount(json.approximatePresenceCount);
/*      */     }
/* 3500 */     if (json.welcomeScreen != null) {
/* 3501 */       builder.welcomeScreen(json.welcomeScreen);
/*      */     }
/* 3503 */     if (json.nsfw != null) {
/* 3504 */       builder.nsfw(json.nsfw);
/*      */     }
/* 3506 */     if (json.safetyAlertsChannelId != null) {
/* 3507 */       builder.safetyAlertsChannelId(json.safetyAlertsChannelId);
/*      */     }
/* 3509 */     return builder.build();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableUserGuildData of(Id id, String name, Optional<String> icon, Optional<String> splash, Optional<String> discoverySplash, Possible<Boolean> owner, Possible<Long> permissions, Optional<Id> afkChannelId, Possible<Boolean> embedEnabled, Possible<Optional<Id>> embedChannelId, List<String> features, Optional<Id> applicationId, Possible<Boolean> widgetEnabled, Possible<Optional<Id>> widgetChannelId, Optional<Id> systemChannelId, OptionalInt systemChannelFlags, Optional<Id> rulesChannelId, Possible<Optional<Integer>> maxPresences, Possible<Integer> maxMembers, Optional<String> vanityUrlCode, Optional<String> description, Optional<String> banner, Possible<Integer> premiumSubscriptionCount, Optional<Id> publicUpdatesChannelId, Possible<Integer> maxVideoChannelUsers, Possible<Integer> approximateMemberCount, Possible<Integer> approximatePresenceCount, Possible<WelcomeScreenData> welcomeScreen, Possible<Boolean> nsfw, Optional<Id> safetyAlertsChannelId) {
/* 3547 */     return of(id, name, icon, splash, discoverySplash, owner, permissions, afkChannelId, embedEnabled, embedChannelId, features, applicationId, widgetEnabled, widgetChannelId, systemChannelId, systemChannelFlags, rulesChannelId, maxPresences, maxMembers, vanityUrlCode, description, banner, premiumSubscriptionCount, publicUpdatesChannelId, maxVideoChannelUsers, approximateMemberCount, approximatePresenceCount, welcomeScreen, nsfw, safetyAlertsChannelId);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableUserGuildData of(Id id, String name, Optional<String> icon, Optional<String> splash, Optional<String> discoverySplash, Possible<Boolean> owner, Possible<Long> permissions, Optional<Id> afkChannelId, Possible<Boolean> embedEnabled, Possible<Optional<Id>> embedChannelId, Iterable<String> features, Optional<Id> applicationId, Possible<Boolean> widgetEnabled, Possible<Optional<Id>> widgetChannelId, Optional<Id> systemChannelId, OptionalInt systemChannelFlags, Optional<Id> rulesChannelId, Possible<Optional<Integer>> maxPresences, Possible<Integer> maxMembers, Optional<String> vanityUrlCode, Optional<String> description, Optional<String> banner, Possible<Integer> premiumSubscriptionCount, Optional<Id> publicUpdatesChannelId, Possible<Integer> maxVideoChannelUsers, Possible<Integer> approximateMemberCount, Possible<Integer> approximatePresenceCount, Possible<WelcomeScreenData> welcomeScreen, Possible<Boolean> nsfw, Optional<Id> safetyAlertsChannelId) {
/* 3585 */     return new ImmutableUserGuildData(id, name, icon, splash, discoverySplash, owner, permissions, afkChannelId, embedEnabled, embedChannelId, features, applicationId, widgetEnabled, widgetChannelId, systemChannelId, systemChannelFlags, rulesChannelId, maxPresences, maxMembers, vanityUrlCode, description, banner, premiumSubscriptionCount, publicUpdatesChannelId, maxVideoChannelUsers, approximateMemberCount, approximatePresenceCount, welcomeScreen, nsfw, safetyAlertsChannelId);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableUserGuildData copyOf(UserGuildData instance) {
/* 3596 */     if (instance instanceof ImmutableUserGuildData) {
/* 3597 */       return (ImmutableUserGuildData)instance;
/*      */     }
/* 3599 */     return builder()
/* 3600 */       .from(instance)
/* 3601 */       .build();
/*      */   }
/*      */   
/*      */   public boolean isOwnerPresent() {
/* 3605 */     return !this.owner_absent;
/*      */   }
/*      */   
/*      */   public Boolean ownerOrElse(Boolean defaultValue) {
/* 3609 */     return !this.owner_absent ? this.owner_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isPermissionsPresent() {
/* 3613 */     return !this.permissions_absent;
/*      */   }
/*      */   
/*      */   public Long permissionsOrElse(Long defaultValue) {
/* 3617 */     return !this.permissions_absent ? this.permissions_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isAfkChannelIdPresent() {
/* 3621 */     return this.afkChannelId_present;
/*      */   }
/*      */   
/*      */   public long afkChannelIdOrElse(long defaultValue) {
/* 3625 */     return this.afkChannelId_present ? this.afkChannelId_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isEmbedEnabledPresent() {
/* 3629 */     return !this.embedEnabled_absent;
/*      */   }
/*      */   
/*      */   public Boolean embedEnabledOrElse(Boolean defaultValue) {
/* 3633 */     return !this.embedEnabled_absent ? this.embedEnabled_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isEmbedChannelIdPresent() {
/* 3637 */     return !this.embedChannelId_absent;
/*      */   }
/*      */   
/*      */   public long embedChannelIdOrElse(long defaultValue) {
/* 3641 */     return !this.embedChannelId_absent ? this.embedChannelId_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isApplicationIdPresent() {
/* 3645 */     return this.applicationId_present;
/*      */   }
/*      */   
/*      */   public long applicationIdOrElse(long defaultValue) {
/* 3649 */     return this.applicationId_present ? this.applicationId_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isWidgetEnabledPresent() {
/* 3653 */     return !this.widgetEnabled_absent;
/*      */   }
/*      */   
/*      */   public Boolean widgetEnabledOrElse(Boolean defaultValue) {
/* 3657 */     return !this.widgetEnabled_absent ? this.widgetEnabled_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isWidgetChannelIdPresent() {
/* 3661 */     return !this.widgetChannelId_absent;
/*      */   }
/*      */   
/*      */   public long widgetChannelIdOrElse(long defaultValue) {
/* 3665 */     return !this.widgetChannelId_absent ? this.widgetChannelId_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isSystemChannelIdPresent() {
/* 3669 */     return this.systemChannelId_present;
/*      */   }
/*      */   
/*      */   public long systemChannelIdOrElse(long defaultValue) {
/* 3673 */     return this.systemChannelId_present ? this.systemChannelId_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isRulesChannelIdPresent() {
/* 3677 */     return this.rulesChannelId_present;
/*      */   }
/*      */   
/*      */   public long rulesChannelIdOrElse(long defaultValue) {
/* 3681 */     return this.rulesChannelId_present ? this.rulesChannelId_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isMaxPresencesPresent() {
/* 3685 */     return !this.maxPresences_absent;
/*      */   }
/*      */   
/*      */   public Integer maxPresencesOrElse(Integer defaultValue) {
/* 3689 */     return !this.maxPresences_absent ? this.maxPresences_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isMaxMembersPresent() {
/* 3693 */     return !this.maxMembers_absent;
/*      */   }
/*      */   
/*      */   public Integer maxMembersOrElse(Integer defaultValue) {
/* 3697 */     return !this.maxMembers_absent ? this.maxMembers_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isPremiumSubscriptionCountPresent() {
/* 3701 */     return !this.premiumSubscriptionCount_absent;
/*      */   }
/*      */   
/*      */   public Integer premiumSubscriptionCountOrElse(Integer defaultValue) {
/* 3705 */     return !this.premiumSubscriptionCount_absent ? this.premiumSubscriptionCount_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isPublicUpdatesChannelIdPresent() {
/* 3709 */     return this.publicUpdatesChannelId_present;
/*      */   }
/*      */   
/*      */   public long publicUpdatesChannelIdOrElse(long defaultValue) {
/* 3713 */     return this.publicUpdatesChannelId_present ? this.publicUpdatesChannelId_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isMaxVideoChannelUsersPresent() {
/* 3717 */     return !this.maxVideoChannelUsers_absent;
/*      */   }
/*      */   
/*      */   public Integer maxVideoChannelUsersOrElse(Integer defaultValue) {
/* 3721 */     return !this.maxVideoChannelUsers_absent ? this.maxVideoChannelUsers_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isApproximateMemberCountPresent() {
/* 3725 */     return !this.approximateMemberCount_absent;
/*      */   }
/*      */   
/*      */   public Integer approximateMemberCountOrElse(Integer defaultValue) {
/* 3729 */     return !this.approximateMemberCount_absent ? this.approximateMemberCount_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isApproximatePresenceCountPresent() {
/* 3733 */     return !this.approximatePresenceCount_absent;
/*      */   }
/*      */   
/*      */   public Integer approximatePresenceCountOrElse(Integer defaultValue) {
/* 3737 */     return !this.approximatePresenceCount_absent ? this.approximatePresenceCount_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isWelcomeScreenPresent() {
/* 3741 */     return !this.welcomeScreen_absent;
/*      */   }
/*      */   
/*      */   public WelcomeScreenData welcomeScreenOrElse(WelcomeScreenData defaultValue) {
/* 3745 */     return !this.welcomeScreen_absent ? this.welcomeScreen_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isNsfwPresent() {
/* 3749 */     return !this.nsfw_absent;
/*      */   }
/*      */   
/*      */   public Boolean nsfwOrElse(Boolean defaultValue) {
/* 3753 */     return !this.nsfw_absent ? this.nsfw_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isSafetyAlertsChannelIdPresent() {
/* 3757 */     return this.safetyAlertsChannelId_present;
/*      */   }
/*      */   
/*      */   public long safetyAlertsChannelIdOrElse(long defaultValue) {
/* 3761 */     return this.safetyAlertsChannelId_present ? this.safetyAlertsChannelId_value : defaultValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Builder builder() {
/* 3803 */     return new Builder();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Generated(from = "UserGuildData", generator = "Immutables")
/*      */   public static final class Builder
/*      */   {
/*      */     private static final long INIT_BIT_NAME = 1L;
/*      */ 
/*      */ 
/*      */     
/* 3816 */     private long initBits = 1L;
/*      */     
/* 3818 */     private Id id_id = null;
/* 3819 */     private Possible<Boolean> owner_possible = Possible.absent();
/* 3820 */     private Possible<Long> permissions_possible = Possible.absent();
/* 3821 */     private Optional<Id> afkChannelId_optional = Optional.empty();
/* 3822 */     private Possible<Boolean> embedEnabled_possible = Possible.absent();
/* 3823 */     private Possible<Optional<Id>> embedChannelId_possible = Possible.absent();
/* 3824 */     private Optional<Id> applicationId_optional = Optional.empty();
/* 3825 */     private Possible<Boolean> widgetEnabled_possible = Possible.absent();
/* 3826 */     private Possible<Optional<Id>> widgetChannelId_possible = Possible.absent();
/* 3827 */     private Optional<Id> systemChannelId_optional = Optional.empty();
/* 3828 */     private Optional<Id> rulesChannelId_optional = Optional.empty();
/* 3829 */     private Possible<Optional<Integer>> maxPresences_possible = Possible.absent();
/* 3830 */     private Possible<Integer> maxMembers_possible = Possible.absent();
/* 3831 */     private Possible<Integer> premiumSubscriptionCount_possible = Possible.absent();
/* 3832 */     private Optional<Id> publicUpdatesChannelId_optional = Optional.empty();
/* 3833 */     private Possible<Integer> maxVideoChannelUsers_possible = Possible.absent();
/* 3834 */     private Possible<Integer> approximateMemberCount_possible = Possible.absent();
/* 3835 */     private Possible<Integer> approximatePresenceCount_possible = Possible.absent();
/* 3836 */     private Possible<WelcomeScreenData> welcomeScreen_possible = Possible.absent();
/* 3837 */     private Possible<Boolean> nsfw_possible = Possible.absent();
/* 3838 */     private Optional<Id> safetyAlertsChannelId_optional = Optional.empty();
/*      */     private String name;
/*      */     private String icon;
/*      */     private String splash;
/*      */     private String discoverySplash;
/* 3843 */     private List<String> features = new ArrayList<>();
/*      */ 
/*      */     
/*      */     private Integer systemChannelFlags;
/*      */ 
/*      */     
/*      */     private String vanityUrlCode;
/*      */ 
/*      */     
/*      */     private String description;
/*      */     
/*      */     private String banner;
/*      */ 
/*      */     
/*      */     public final Builder from(GuildFields instance) {
/* 3858 */       Objects.requireNonNull(instance, "instance");
/* 3859 */       from(instance);
/* 3860 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder from(UserGuildData instance) {
/* 3869 */       Objects.requireNonNull(instance, "instance");
/* 3870 */       from(instance);
/* 3871 */       return this;
/*      */     }
/*      */     
/*      */     private void from(Object object) {
/* 3875 */       long bits = 0L;
/* 3876 */       if (object instanceof GuildFields) {
/* 3877 */         GuildFields instance = (GuildFields)object;
/* 3878 */         if ((bits & 0x1L) == 0L) {
/* 3879 */           Optional<String> vanityUrlCodeOptional = instance.vanityUrlCode();
/* 3880 */           if (vanityUrlCodeOptional.isPresent()) {
/* 3881 */             vanityUrlCode(vanityUrlCodeOptional);
/*      */           }
/* 3883 */           bits |= 0x1L;
/*      */         } 
/* 3885 */         if ((bits & 0x2L) == 0L) {
/* 3886 */           Optional<String> iconOptional = instance.icon();
/* 3887 */           if (iconOptional.isPresent()) {
/* 3888 */             icon(iconOptional);
/*      */           }
/* 3890 */           bits |= 0x2L;
/*      */         } 
/* 3892 */         if ((bits & 0x4L) == 0L) {
/* 3893 */           Optional<String> descriptionOptional = instance.description();
/* 3894 */           if (descriptionOptional.isPresent()) {
/* 3895 */             description(descriptionOptional);
/*      */           }
/* 3897 */           bits |= 0x4L;
/*      */         } 
/* 3899 */         if ((bits & 0x8L) == 0L) {
/* 3900 */           afkChannelId(instance.afkChannelId());
/* 3901 */           bits |= 0x8L;
/*      */         } 
/* 3903 */         if ((bits & 0x10L) == 0L) {
/* 3904 */           addAllFeatures(instance.features());
/* 3905 */           bits |= 0x10L;
/*      */         } 
/* 3907 */         if ((bits & 0x20L) == 0L) {
/* 3908 */           maxMembers(instance.maxMembers());
/* 3909 */           bits |= 0x20L;
/*      */         } 
/* 3911 */         if ((bits & 0x40L) == 0L) {
/* 3912 */           permissions(instance.permissions());
/* 3913 */           bits |= 0x40L;
/*      */         } 
/* 3915 */         if ((bits & 0x80L) == 0L) {
/* 3916 */           publicUpdatesChannelId(instance.publicUpdatesChannelId());
/* 3917 */           bits |= 0x80L;
/*      */         } 
/* 3919 */         if ((bits & 0x100L) == 0L) {
/* 3920 */           id(instance.id());
/* 3921 */           bits |= 0x100L;
/*      */         } 
/* 3923 */         if ((bits & 0x200L) == 0L) {
/* 3924 */           safetyAlertsChannelId(instance.safetyAlertsChannelId());
/* 3925 */           bits |= 0x200L;
/*      */         } 
/* 3927 */         if ((bits & 0x400L) == 0L) {
/* 3928 */           systemChannelId(instance.systemChannelId());
/* 3929 */           bits |= 0x400L;
/*      */         } 
/* 3931 */         if ((bits & 0x800L) == 0L) {
/* 3932 */           owner(instance.owner());
/* 3933 */           bits |= 0x800L;
/*      */         } 
/* 3935 */         if ((bits & 0x1000L) == 0L) {
/* 3936 */           Optional<String> discoverySplashOptional = instance.discoverySplash();
/* 3937 */           if (discoverySplashOptional.isPresent()) {
/* 3938 */             discoverySplash(discoverySplashOptional);
/*      */           }
/* 3940 */           bits |= 0x1000L;
/*      */         } 
/* 3942 */         if ((bits & 0x2000L) == 0L) {
/* 3943 */           approximateMemberCount(instance.approximateMemberCount());
/* 3944 */           bits |= 0x2000L;
/*      */         } 
/* 3946 */         if ((bits & 0x4000L) == 0L) {
/* 3947 */           maxPresences(instance.maxPresences());
/* 3948 */           bits |= 0x4000L;
/*      */         } 
/* 3950 */         if ((bits & 0x8000L) == 0L) {
/* 3951 */           welcomeScreen(instance.welcomeScreen());
/* 3952 */           bits |= 0x8000L;
/*      */         } 
/* 3954 */         if ((bits & 0x10000L) == 0L) {
/* 3955 */           rulesChannelId(instance.rulesChannelId());
/* 3956 */           bits |= 0x10000L;
/*      */         } 
/* 3958 */         if ((bits & 0x20000L) == 0L) {
/* 3959 */           nsfw(instance.nsfw());
/* 3960 */           bits |= 0x20000L;
/*      */         } 
/* 3962 */         if ((bits & 0x40000L) == 0L) {
/* 3963 */           widgetChannelId(instance.widgetChannelId());
/* 3964 */           bits |= 0x40000L;
/*      */         } 
/* 3966 */         if ((bits & 0x80000L) == 0L) {
/* 3967 */           Optional<String> bannerOptional = instance.banner();
/* 3968 */           if (bannerOptional.isPresent()) {
/* 3969 */             banner(bannerOptional);
/*      */           }
/* 3971 */           bits |= 0x80000L;
/*      */         } 
/* 3973 */         if ((bits & 0x100000L) == 0L) {
/* 3974 */           widgetEnabled(instance.widgetEnabled());
/* 3975 */           bits |= 0x100000L;
/*      */         } 
/* 3977 */         if ((bits & 0x200000L) == 0L) {
/* 3978 */           embedChannelId(instance.embedChannelId());
/* 3979 */           bits |= 0x200000L;
/*      */         } 
/* 3981 */         if ((bits & 0x400000L) == 0L) {
/* 3982 */           OptionalInt systemChannelFlagsOptional = instance.systemChannelFlags();
/* 3983 */           if (systemChannelFlagsOptional.isPresent()) {
/* 3984 */             systemChannelFlags(systemChannelFlagsOptional);
/*      */           }
/* 3986 */           bits |= 0x400000L;
/*      */         } 
/* 3988 */         if ((bits & 0x800000L) == 0L) {
/* 3989 */           maxVideoChannelUsers(instance.maxVideoChannelUsers());
/* 3990 */           bits |= 0x800000L;
/*      */         } 
/* 3992 */         if ((bits & 0x1000000L) == 0L) {
/* 3993 */           name(instance.name());
/* 3994 */           bits |= 0x1000000L;
/*      */         } 
/* 3996 */         if ((bits & 0x2000000L) == 0L) {
/* 3997 */           premiumSubscriptionCount(instance.premiumSubscriptionCount());
/* 3998 */           bits |= 0x2000000L;
/*      */         } 
/* 4000 */         if ((bits & 0x4000000L) == 0L) {
/* 4001 */           embedEnabled(instance.embedEnabled());
/* 4002 */           bits |= 0x4000000L;
/*      */         } 
/* 4004 */         if ((bits & 0x8000000L) == 0L) {
/* 4005 */           approximatePresenceCount(instance.approximatePresenceCount());
/* 4006 */           bits |= 0x8000000L;
/*      */         } 
/* 4008 */         if ((bits & 0x10000000L) == 0L) {
/* 4009 */           applicationId(instance.applicationId());
/* 4010 */           bits |= 0x10000000L;
/*      */         } 
/* 4012 */         if ((bits & 0x20000000L) == 0L) {
/* 4013 */           Optional<String> splashOptional = instance.splash();
/* 4014 */           if (splashOptional.isPresent()) {
/* 4015 */             splash(splashOptional);
/*      */           }
/* 4017 */           bits |= 0x20000000L;
/*      */         } 
/*      */       } 
/* 4020 */       if (object instanceof UserGuildData) {
/* 4021 */         UserGuildData instance = (UserGuildData)object;
/* 4022 */         if ((bits & 0x1L) == 0L) {
/* 4023 */           Optional<String> vanityUrlCodeOptional = instance.vanityUrlCode();
/* 4024 */           if (vanityUrlCodeOptional.isPresent()) {
/* 4025 */             vanityUrlCode(vanityUrlCodeOptional);
/*      */           }
/* 4027 */           bits |= 0x1L;
/*      */         } 
/* 4029 */         if ((bits & 0x2L) == 0L) {
/* 4030 */           Optional<String> iconOptional = instance.icon();
/* 4031 */           if (iconOptional.isPresent()) {
/* 4032 */             icon(iconOptional);
/*      */           }
/* 4034 */           bits |= 0x2L;
/*      */         } 
/* 4036 */         if ((bits & 0x4L) == 0L) {
/* 4037 */           Optional<String> descriptionOptional = instance.description();
/* 4038 */           if (descriptionOptional.isPresent()) {
/* 4039 */             description(descriptionOptional);
/*      */           }
/* 4041 */           bits |= 0x4L;
/*      */         } 
/* 4043 */         if ((bits & 0x8L) == 0L) {
/* 4044 */           afkChannelId(instance.afkChannelId());
/* 4045 */           bits |= 0x8L;
/*      */         } 
/* 4047 */         if ((bits & 0x10L) == 0L) {
/* 4048 */           addAllFeatures(instance.features());
/* 4049 */           bits |= 0x10L;
/*      */         } 
/* 4051 */         if ((bits & 0x20L) == 0L) {
/* 4052 */           maxMembers(instance.maxMembers());
/* 4053 */           bits |= 0x20L;
/*      */         } 
/* 4055 */         if ((bits & 0x40L) == 0L) {
/* 4056 */           permissions(instance.permissions());
/* 4057 */           bits |= 0x40L;
/*      */         } 
/* 4059 */         if ((bits & 0x80L) == 0L) {
/* 4060 */           publicUpdatesChannelId(instance.publicUpdatesChannelId());
/* 4061 */           bits |= 0x80L;
/*      */         } 
/* 4063 */         if ((bits & 0x100L) == 0L) {
/* 4064 */           id(instance.id());
/* 4065 */           bits |= 0x100L;
/*      */         } 
/* 4067 */         if ((bits & 0x200L) == 0L) {
/* 4068 */           safetyAlertsChannelId(instance.safetyAlertsChannelId());
/* 4069 */           bits |= 0x200L;
/*      */         } 
/* 4071 */         if ((bits & 0x400L) == 0L) {
/* 4072 */           systemChannelId(instance.systemChannelId());
/* 4073 */           bits |= 0x400L;
/*      */         } 
/* 4075 */         if ((bits & 0x800L) == 0L) {
/* 4076 */           owner(instance.owner());
/* 4077 */           bits |= 0x800L;
/*      */         } 
/* 4079 */         if ((bits & 0x1000L) == 0L) {
/* 4080 */           Optional<String> discoverySplashOptional = instance.discoverySplash();
/* 4081 */           if (discoverySplashOptional.isPresent()) {
/* 4082 */             discoverySplash(discoverySplashOptional);
/*      */           }
/* 4084 */           bits |= 0x1000L;
/*      */         } 
/* 4086 */         if ((bits & 0x2000L) == 0L) {
/* 4087 */           approximateMemberCount(instance.approximateMemberCount());
/* 4088 */           bits |= 0x2000L;
/*      */         } 
/* 4090 */         if ((bits & 0x4000L) == 0L) {
/* 4091 */           maxPresences(instance.maxPresences());
/* 4092 */           bits |= 0x4000L;
/*      */         } 
/* 4094 */         if ((bits & 0x8000L) == 0L) {
/* 4095 */           welcomeScreen(instance.welcomeScreen());
/* 4096 */           bits |= 0x8000L;
/*      */         } 
/* 4098 */         if ((bits & 0x10000L) == 0L) {
/* 4099 */           rulesChannelId(instance.rulesChannelId());
/* 4100 */           bits |= 0x10000L;
/*      */         } 
/* 4102 */         if ((bits & 0x20000L) == 0L) {
/* 4103 */           nsfw(instance.nsfw());
/* 4104 */           bits |= 0x20000L;
/*      */         } 
/* 4106 */         if ((bits & 0x40000L) == 0L) {
/* 4107 */           widgetChannelId(instance.widgetChannelId());
/* 4108 */           bits |= 0x40000L;
/*      */         } 
/* 4110 */         if ((bits & 0x80000L) == 0L) {
/* 4111 */           Optional<String> bannerOptional = instance.banner();
/* 4112 */           if (bannerOptional.isPresent()) {
/* 4113 */             banner(bannerOptional);
/*      */           }
/* 4115 */           bits |= 0x80000L;
/*      */         } 
/* 4117 */         if ((bits & 0x100000L) == 0L) {
/* 4118 */           widgetEnabled(instance.widgetEnabled());
/* 4119 */           bits |= 0x100000L;
/*      */         } 
/* 4121 */         if ((bits & 0x200000L) == 0L) {
/* 4122 */           embedChannelId(instance.embedChannelId());
/* 4123 */           bits |= 0x200000L;
/*      */         } 
/* 4125 */         if ((bits & 0x400000L) == 0L) {
/* 4126 */           OptionalInt systemChannelFlagsOptional = instance.systemChannelFlags();
/* 4127 */           if (systemChannelFlagsOptional.isPresent()) {
/* 4128 */             systemChannelFlags(systemChannelFlagsOptional);
/*      */           }
/* 4130 */           bits |= 0x400000L;
/*      */         } 
/* 4132 */         if ((bits & 0x800000L) == 0L) {
/* 4133 */           maxVideoChannelUsers(instance.maxVideoChannelUsers());
/* 4134 */           bits |= 0x800000L;
/*      */         } 
/* 4136 */         if ((bits & 0x1000000L) == 0L) {
/* 4137 */           name(instance.name());
/* 4138 */           bits |= 0x1000000L;
/*      */         } 
/* 4140 */         if ((bits & 0x2000000L) == 0L) {
/* 4141 */           premiumSubscriptionCount(instance.premiumSubscriptionCount());
/* 4142 */           bits |= 0x2000000L;
/*      */         } 
/* 4144 */         if ((bits & 0x4000000L) == 0L) {
/* 4145 */           embedEnabled(instance.embedEnabled());
/* 4146 */           bits |= 0x4000000L;
/*      */         } 
/* 4148 */         if ((bits & 0x8000000L) == 0L) {
/* 4149 */           approximatePresenceCount(instance.approximatePresenceCount());
/* 4150 */           bits |= 0x8000000L;
/*      */         } 
/* 4152 */         if ((bits & 0x10000000L) == 0L) {
/* 4153 */           applicationId(instance.applicationId());
/* 4154 */           bits |= 0x10000000L;
/*      */         } 
/* 4156 */         if ((bits & 0x20000000L) == 0L) {
/* 4157 */           Optional<String> splashOptional = instance.splash();
/* 4158 */           if (splashOptional.isPresent()) {
/* 4159 */             splash(splashOptional);
/*      */           }
/* 4161 */           bits |= 0x20000000L;
/*      */         } 
/*      */       } 
/*      */     }
/*      */     
/*      */     public Builder id(String value) {
/* 4167 */       this.id_id = Id.of(value);
/* 4168 */       return this;
/*      */     }
/*      */     
/*      */     public Builder id(long value) {
/* 4172 */       this.id_id = Id.of(value);
/* 4173 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("id")
/*      */     public Builder id(Id value) {
/* 4178 */       this.id_id = value;
/* 4179 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("name")
/*      */     public final Builder name(String name) {
/* 4189 */       this.name = Objects.<String>requireNonNull(name, "name");
/* 4190 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 4191 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder icon(String icon) {
/* 4200 */       this.icon = Objects.<String>requireNonNull(icon, "icon");
/* 4201 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("icon")
/*      */     public final Builder icon(Optional<String> icon) {
/* 4211 */       this.icon = icon.orElse(null);
/* 4212 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder splash(String splash) {
/* 4221 */       this.splash = Objects.<String>requireNonNull(splash, "splash");
/* 4222 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("splash")
/*      */     public final Builder splash(Optional<String> splash) {
/* 4232 */       this.splash = splash.orElse(null);
/* 4233 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder discoverySplash(String discoverySplash) {
/* 4242 */       this.discoverySplash = Objects.<String>requireNonNull(discoverySplash, "discoverySplash");
/* 4243 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("discovery_splash")
/*      */     public final Builder discoverySplash(Optional<String> discoverySplash) {
/* 4253 */       this.discoverySplash = discoverySplash.orElse(null);
/* 4254 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("owner")
/*      */     public Builder owner(Possible<Boolean> value) {
/* 4259 */       this.owner_possible = value;
/* 4260 */       return this;
/*      */     }
/*      */     
/*      */     public Builder owner(Boolean value) {
/* 4264 */       this.owner_possible = Possible.of(value);
/* 4265 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("permissions")
/*      */     public Builder permissions(Possible<Long> value) {
/* 4270 */       this.permissions_possible = value;
/* 4271 */       return this;
/*      */     }
/*      */     
/*      */     public Builder permissions(Long value) {
/* 4275 */       this.permissions_possible = Possible.of(value);
/* 4276 */       return this;
/*      */     }
/*      */     
/*      */     public Builder afkChannelId(String value) {
/* 4280 */       this.afkChannelId_optional = Optional.of(Id.of(value));
/* 4281 */       return this;
/*      */     }
/*      */     
/*      */     public Builder afkChannelId(long value) {
/* 4285 */       this.afkChannelId_optional = Optional.of(Id.of(value));
/* 4286 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("afk_channel_id")
/*      */     public Builder afkChannelId(Optional<Id> value) {
/* 4291 */       this.afkChannelId_optional = value;
/* 4292 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("embed_enabled")
/*      */     public Builder embedEnabled(Possible<Boolean> value) {
/* 4297 */       this.embedEnabled_possible = value;
/* 4298 */       return this;
/*      */     }
/*      */     
/*      */     public Builder embedEnabled(Boolean value) {
/* 4302 */       this.embedEnabled_possible = Possible.of(value);
/* 4303 */       return this;
/*      */     }
/*      */     
/*      */     public Builder embedChannelId(String value) {
/* 4307 */       this.embedChannelId_possible = Possible.of(Optional.of(Id.of(value)));
/* 4308 */       return this;
/*      */     }
/*      */     
/*      */     public Builder embedChannelId(long value) {
/* 4312 */       this.embedChannelId_possible = Possible.of(Optional.of(Id.of(value)));
/* 4313 */       return this;
/*      */     }
/*      */     
/*      */     public Builder embedChannelId(Id value) {
/* 4317 */       this.embedChannelId_possible = Possible.of(Optional.of(value));
/* 4318 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("embed_channel_id")
/*      */     public Builder embedChannelId(Possible<Optional<Id>> value) {
/* 4323 */       this.embedChannelId_possible = value;
/* 4324 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addFeature(String element) {
/* 4333 */       this.features.add(Objects.<String>requireNonNull(element, "features element"));
/* 4334 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addFeatures(String... elements) {
/* 4343 */       for (String element : elements) {
/* 4344 */         this.features.add(Objects.<String>requireNonNull(element, "features element"));
/*      */       }
/* 4346 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("features")
/*      */     public final Builder features(Iterable<String> elements) {
/* 4357 */       this.features.clear();
/* 4358 */       return addAllFeatures(elements);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addAllFeatures(Iterable<String> elements) {
/* 4367 */       for (String element : elements) {
/* 4368 */         this.features.add(Objects.<String>requireNonNull(element, "features element"));
/*      */       }
/* 4370 */       return this;
/*      */     }
/*      */     
/*      */     public Builder applicationId(String value) {
/* 4374 */       this.applicationId_optional = Optional.of(Id.of(value));
/* 4375 */       return this;
/*      */     }
/*      */     
/*      */     public Builder applicationId(long value) {
/* 4379 */       this.applicationId_optional = Optional.of(Id.of(value));
/* 4380 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("application_id")
/*      */     public Builder applicationId(Optional<Id> value) {
/* 4385 */       this.applicationId_optional = value;
/* 4386 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("widget_enabled")
/*      */     public Builder widgetEnabled(Possible<Boolean> value) {
/* 4391 */       this.widgetEnabled_possible = value;
/* 4392 */       return this;
/*      */     }
/*      */     
/*      */     public Builder widgetEnabled(Boolean value) {
/* 4396 */       this.widgetEnabled_possible = Possible.of(value);
/* 4397 */       return this;
/*      */     }
/*      */     
/*      */     public Builder widgetChannelId(String value) {
/* 4401 */       this.widgetChannelId_possible = Possible.of(Optional.of(Id.of(value)));
/* 4402 */       return this;
/*      */     }
/*      */     
/*      */     public Builder widgetChannelId(long value) {
/* 4406 */       this.widgetChannelId_possible = Possible.of(Optional.of(Id.of(value)));
/* 4407 */       return this;
/*      */     }
/*      */     
/*      */     public Builder widgetChannelId(Id value) {
/* 4411 */       this.widgetChannelId_possible = Possible.of(Optional.of(value));
/* 4412 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("widget_channel_id")
/*      */     public Builder widgetChannelId(Possible<Optional<Id>> value) {
/* 4417 */       this.widgetChannelId_possible = value;
/* 4418 */       return this;
/*      */     }
/*      */     
/*      */     public Builder systemChannelId(String value) {
/* 4422 */       this.systemChannelId_optional = Optional.of(Id.of(value));
/* 4423 */       return this;
/*      */     }
/*      */     
/*      */     public Builder systemChannelId(long value) {
/* 4427 */       this.systemChannelId_optional = Optional.of(Id.of(value));
/* 4428 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("system_channel_id")
/*      */     public Builder systemChannelId(Optional<Id> value) {
/* 4433 */       this.systemChannelId_optional = value;
/* 4434 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder systemChannelFlags(int systemChannelFlags) {
/* 4443 */       this.systemChannelFlags = Integer.valueOf(systemChannelFlags);
/* 4444 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("system_channel_flags")
/*      */     public final Builder systemChannelFlags(OptionalInt systemChannelFlags) {
/* 4454 */       this.systemChannelFlags = systemChannelFlags.isPresent() ? Integer.valueOf(systemChannelFlags.getAsInt()) : null;
/* 4455 */       return this;
/*      */     }
/*      */     
/*      */     public Builder rulesChannelId(String value) {
/* 4459 */       this.rulesChannelId_optional = Optional.of(Id.of(value));
/* 4460 */       return this;
/*      */     }
/*      */     
/*      */     public Builder rulesChannelId(long value) {
/* 4464 */       this.rulesChannelId_optional = Optional.of(Id.of(value));
/* 4465 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("rules_channel_id")
/*      */     public Builder rulesChannelId(Optional<Id> value) {
/* 4470 */       this.rulesChannelId_optional = value;
/* 4471 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("max_presences")
/*      */     public Builder maxPresences(Possible<Optional<Integer>> value) {
/* 4476 */       this.maxPresences_possible = value;
/* 4477 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public Builder maxPresences(@Nullable Integer value) {
/* 4482 */       this.maxPresences_possible = Possible.of(Optional.ofNullable(value));
/* 4483 */       return this;
/*      */     }
/*      */     
/*      */     public Builder maxPresencesOrNull(@Nullable Integer value) {
/* 4487 */       this.maxPresences_possible = Possible.of(Optional.ofNullable(value));
/* 4488 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("max_members")
/*      */     public Builder maxMembers(Possible<Integer> value) {
/* 4493 */       this.maxMembers_possible = value;
/* 4494 */       return this;
/*      */     }
/*      */     
/*      */     public Builder maxMembers(Integer value) {
/* 4498 */       this.maxMembers_possible = Possible.of(value);
/* 4499 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder vanityUrlCode(String vanityUrlCode) {
/* 4508 */       this.vanityUrlCode = Objects.<String>requireNonNull(vanityUrlCode, "vanityUrlCode");
/* 4509 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("vanity_url_code")
/*      */     public final Builder vanityUrlCode(Optional<String> vanityUrlCode) {
/* 4519 */       this.vanityUrlCode = vanityUrlCode.orElse(null);
/* 4520 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder description(String description) {
/* 4529 */       this.description = Objects.<String>requireNonNull(description, "description");
/* 4530 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("description")
/*      */     public final Builder description(Optional<String> description) {
/* 4540 */       this.description = description.orElse(null);
/* 4541 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder banner(String banner) {
/* 4550 */       this.banner = Objects.<String>requireNonNull(banner, "banner");
/* 4551 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("banner")
/*      */     public final Builder banner(Optional<String> banner) {
/* 4561 */       this.banner = banner.orElse(null);
/* 4562 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("premium_subscription_count")
/*      */     public Builder premiumSubscriptionCount(Possible<Integer> value) {
/* 4567 */       this.premiumSubscriptionCount_possible = value;
/* 4568 */       return this;
/*      */     }
/*      */     
/*      */     public Builder premiumSubscriptionCount(Integer value) {
/* 4572 */       this.premiumSubscriptionCount_possible = Possible.of(value);
/* 4573 */       return this;
/*      */     }
/*      */     
/*      */     public Builder publicUpdatesChannelId(String value) {
/* 4577 */       this.publicUpdatesChannelId_optional = Optional.of(Id.of(value));
/* 4578 */       return this;
/*      */     }
/*      */     
/*      */     public Builder publicUpdatesChannelId(long value) {
/* 4582 */       this.publicUpdatesChannelId_optional = Optional.of(Id.of(value));
/* 4583 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("public_updates_channel_id")
/*      */     public Builder publicUpdatesChannelId(Optional<Id> value) {
/* 4588 */       this.publicUpdatesChannelId_optional = value;
/* 4589 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("max_video_channel_users")
/*      */     public Builder maxVideoChannelUsers(Possible<Integer> value) {
/* 4594 */       this.maxVideoChannelUsers_possible = value;
/* 4595 */       return this;
/*      */     }
/*      */     
/*      */     public Builder maxVideoChannelUsers(Integer value) {
/* 4599 */       this.maxVideoChannelUsers_possible = Possible.of(value);
/* 4600 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("approximate_member_count")
/*      */     public Builder approximateMemberCount(Possible<Integer> value) {
/* 4605 */       this.approximateMemberCount_possible = value;
/* 4606 */       return this;
/*      */     }
/*      */     
/*      */     public Builder approximateMemberCount(Integer value) {
/* 4610 */       this.approximateMemberCount_possible = Possible.of(value);
/* 4611 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("approximate_presence_count")
/*      */     public Builder approximatePresenceCount(Possible<Integer> value) {
/* 4616 */       this.approximatePresenceCount_possible = value;
/* 4617 */       return this;
/*      */     }
/*      */     
/*      */     public Builder approximatePresenceCount(Integer value) {
/* 4621 */       this.approximatePresenceCount_possible = Possible.of(value);
/* 4622 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("welcome_screen")
/*      */     public Builder welcomeScreen(Possible<WelcomeScreenData> value) {
/* 4627 */       this.welcomeScreen_possible = value;
/* 4628 */       return this;
/*      */     }
/*      */     
/*      */     public Builder welcomeScreen(WelcomeScreenData value) {
/* 4632 */       this.welcomeScreen_possible = Possible.of(value);
/* 4633 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("nsfw")
/*      */     public Builder nsfw(Possible<Boolean> value) {
/* 4638 */       this.nsfw_possible = value;
/* 4639 */       return this;
/*      */     }
/*      */     
/*      */     public Builder nsfw(Boolean value) {
/* 4643 */       this.nsfw_possible = Possible.of(value);
/* 4644 */       return this;
/*      */     }
/*      */     
/*      */     public Builder safetyAlertsChannelId(String value) {
/* 4648 */       this.safetyAlertsChannelId_optional = Optional.of(Id.of(value));
/* 4649 */       return this;
/*      */     }
/*      */     
/*      */     public Builder safetyAlertsChannelId(long value) {
/* 4653 */       this.safetyAlertsChannelId_optional = Optional.of(Id.of(value));
/* 4654 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("safety_alerts_channel_id")
/*      */     public Builder safetyAlertsChannelId(Optional<Id> value) {
/* 4659 */       this.safetyAlertsChannelId_optional = value;
/* 4660 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ImmutableUserGuildData build() {
/* 4669 */       if (this.initBits != 0L) {
/* 4670 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*      */       }
/* 4672 */       return new ImmutableUserGuildData(null, 
/*      */           
/* 4674 */           id_build(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 4679 */           owner_build(), 
/* 4680 */           permissions_build(), 
/* 4681 */           afkChannelId_build(), 
/* 4682 */           embedEnabled_build(), 
/* 4683 */           embedChannelId_build(), ImmutableUserGuildData
/* 4684 */           .createUnmodifiableList(true, (List)this.features), 
/* 4685 */           applicationId_build(), 
/* 4686 */           widgetEnabled_build(), 
/* 4687 */           widgetChannelId_build(), 
/* 4688 */           systemChannelId_build(), this.systemChannelFlags, 
/*      */           
/* 4690 */           rulesChannelId_build(), 
/* 4691 */           maxPresences_build(), 
/* 4692 */           maxMembers_build(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */           
/* 4696 */           premiumSubscriptionCount_build(), 
/* 4697 */           publicUpdatesChannelId_build(), 
/* 4698 */           maxVideoChannelUsers_build(), 
/* 4699 */           approximateMemberCount_build(), 
/* 4700 */           approximatePresenceCount_build(), 
/* 4701 */           welcomeScreen_build(), 
/* 4702 */           nsfw_build(), 
/* 4703 */           safetyAlertsChannelId_build());
/*      */     }
/*      */     
/*      */     private String formatRequiredAttributesMessage() {
/* 4707 */       List<String> attributes = new ArrayList<>();
/* 4708 */       if ((this.initBits & 0x1L) != 0L) attributes.add("name"); 
/* 4709 */       return "Cannot build UserGuildData, some of required attributes are not set " + attributes;
/*      */     }
/*      */     
/*      */     private Id id_build() {
/* 4713 */       return this.id_id;
/*      */     }
/*      */     
/*      */     private Possible<Boolean> owner_build() {
/* 4717 */       return this.owner_possible;
/*      */     }
/*      */     
/*      */     private Possible<Long> permissions_build() {
/* 4721 */       return this.permissions_possible;
/*      */     }
/*      */     
/*      */     private Optional<Id> afkChannelId_build() {
/* 4725 */       return this.afkChannelId_optional;
/*      */     }
/*      */     
/*      */     private Possible<Boolean> embedEnabled_build() {
/* 4729 */       return this.embedEnabled_possible;
/*      */     }
/*      */     
/*      */     private Possible<Optional<Id>> embedChannelId_build() {
/* 4733 */       return this.embedChannelId_possible;
/*      */     }
/*      */     
/*      */     private Optional<Id> applicationId_build() {
/* 4737 */       return this.applicationId_optional;
/*      */     }
/*      */     
/*      */     private Possible<Boolean> widgetEnabled_build() {
/* 4741 */       return this.widgetEnabled_possible;
/*      */     }
/*      */     
/*      */     private Possible<Optional<Id>> widgetChannelId_build() {
/* 4745 */       return this.widgetChannelId_possible;
/*      */     }
/*      */     
/*      */     private Optional<Id> systemChannelId_build() {
/* 4749 */       return this.systemChannelId_optional;
/*      */     }
/*      */     
/*      */     private Optional<Id> rulesChannelId_build() {
/* 4753 */       return this.rulesChannelId_optional;
/*      */     }
/*      */     
/*      */     private Possible<Optional<Integer>> maxPresences_build() {
/* 4757 */       return this.maxPresences_possible;
/*      */     }
/*      */     
/*      */     private Possible<Integer> maxMembers_build() {
/* 4761 */       return this.maxMembers_possible;
/*      */     }
/*      */     
/*      */     private Possible<Integer> premiumSubscriptionCount_build() {
/* 4765 */       return this.premiumSubscriptionCount_possible;
/*      */     }
/*      */     
/*      */     private Optional<Id> publicUpdatesChannelId_build() {
/* 4769 */       return this.publicUpdatesChannelId_optional;
/*      */     }
/*      */     
/*      */     private Possible<Integer> maxVideoChannelUsers_build() {
/* 4773 */       return this.maxVideoChannelUsers_possible;
/*      */     }
/*      */     
/*      */     private Possible<Integer> approximateMemberCount_build() {
/* 4777 */       return this.approximateMemberCount_possible;
/*      */     }
/*      */     
/*      */     private Possible<Integer> approximatePresenceCount_build() {
/* 4781 */       return this.approximatePresenceCount_possible;
/*      */     }
/*      */     
/*      */     private Possible<WelcomeScreenData> welcomeScreen_build() {
/* 4785 */       return this.welcomeScreen_possible;
/*      */     }
/*      */     
/*      */     private Possible<Boolean> nsfw_build() {
/* 4789 */       return this.nsfw_possible;
/*      */     }
/*      */     
/*      */     private Optional<Id> safetyAlertsChannelId_build() {
/* 4793 */       return this.safetyAlertsChannelId_optional;
/*      */     }
/*      */     private Builder() {} }
/*      */   
/*      */   private static <T> List<T> createSafeList(Iterable<? extends T> iterable, boolean checkNulls, boolean skipNulls) {
/*      */     ArrayList<T> list;
/* 4799 */     if (iterable instanceof Collection) {
/* 4800 */       int size = ((Collection)iterable).size();
/* 4801 */       if (size == 0) return Collections.emptyList(); 
/* 4802 */       list = new ArrayList<>();
/*      */     } else {
/* 4804 */       list = new ArrayList<>();
/*      */     } 
/* 4806 */     for (T element : iterable) {
/* 4807 */       if (skipNulls && element == null)
/* 4808 */         continue;  if (checkNulls) Objects.requireNonNull(element, "element"); 
/* 4809 */       list.add(element);
/*      */     } 
/* 4811 */     return list;
/*      */   }
/*      */   
/*      */   private static <T> List<T> createUnmodifiableList(boolean clone, List<T> list) {
/* 4815 */     switch (list.size()) { case 0:
/* 4816 */         return Collections.emptyList();
/* 4817 */       case 1: return Collections.singletonList(list.get(0)); }
/*      */     
/* 4819 */     if (clone) {
/* 4820 */       return Collections.unmodifiableList(new ArrayList<>(list));
/*      */     }
/* 4822 */     if (list instanceof ArrayList) {
/* 4823 */       ((ArrayList)list).trimToSize();
/*      */     }
/* 4825 */     return Collections.unmodifiableList(list);
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableUserGuildData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */