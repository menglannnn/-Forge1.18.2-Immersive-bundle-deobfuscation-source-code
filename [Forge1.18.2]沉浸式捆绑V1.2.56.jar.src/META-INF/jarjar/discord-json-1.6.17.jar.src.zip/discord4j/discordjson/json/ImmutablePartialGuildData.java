/*      */ package discord4j.discordjson.json;
/*      */ 
/*      */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*      */ import com.fasterxml.jackson.annotation.JsonCreator;
/*      */ import com.fasterxml.jackson.annotation.JsonProperty;
/*      */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*      */ import discord4j.discordjson.Id;
/*      */ import discord4j.discordjson.possible.Possible;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.List;
/*      */ import java.util.Objects;
/*      */ import java.util.Optional;
/*      */ import java.util.OptionalInt;
/*      */ import org.immutables.value.Generated;
/*      */ import reactor.util.annotation.Nullable;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ @Generated(from = "PartialGuildData", generator = "Immutables")
/*      */ public final class ImmutablePartialGuildData
/*      */   implements PartialGuildData
/*      */ {
/*      */   private final long id_value;
/*      */   private final String name;
/*      */   private final String icon;
/*      */   private final String splash;
/*      */   private final String discoverySplash;
/*      */   private final Boolean owner_value;
/*      */   private final boolean owner_absent;
/*      */   private final Long permissions_value;
/*      */   private final boolean permissions_absent;
/*      */   private final long afkChannelId_value;
/*      */   private final boolean afkChannelId_present;
/*      */   private final Boolean embedEnabled_value;
/*      */   private final boolean embedEnabled_absent;
/*      */   private final long embedChannelId_value;
/*      */   private final boolean embedChannelId_absent;
/*      */   private final boolean embedChannelId_isNull;
/*      */   private final List<String> features;
/*      */   private final long applicationId_value;
/*      */   private final boolean applicationId_present;
/*      */   private final Boolean widgetEnabled_value;
/*      */   private final boolean widgetEnabled_absent;
/*      */   private final long widgetChannelId_value;
/*      */   private final boolean widgetChannelId_absent;
/*      */   private final boolean widgetChannelId_isNull;
/*      */   private final long systemChannelId_value;
/*      */   private final boolean systemChannelId_present;
/*      */   private final Integer systemChannelFlags;
/*      */   private final long rulesChannelId_value;
/*      */   private final boolean rulesChannelId_present;
/*      */   private final Integer maxPresences_value;
/*      */   private final boolean maxPresences_absent;
/*      */   private final Integer maxMembers_value;
/*      */   private final boolean maxMembers_absent;
/*      */   private final String vanityUrlCode;
/*      */   private final String description;
/*      */   private final String banner;
/*      */   private final Integer premiumSubscriptionCount_value;
/*      */   private final boolean premiumSubscriptionCount_absent;
/*      */   private final long publicUpdatesChannelId_value;
/*      */   private final boolean publicUpdatesChannelId_present;
/*      */   private final Integer maxVideoChannelUsers_value;
/*      */   private final boolean maxVideoChannelUsers_absent;
/*      */   private final Integer approximateMemberCount_value;
/*      */   private final boolean approximateMemberCount_absent;
/*      */   private final Integer approximatePresenceCount_value;
/*      */   private final boolean approximatePresenceCount_absent;
/*      */   private final WelcomeScreenData welcomeScreen_value;
/*      */   private final boolean welcomeScreen_absent;
/*      */   private final Boolean nsfw_value;
/*      */   private final boolean nsfw_absent;
/*      */   private final long safetyAlertsChannelId_value;
/*      */   private final boolean safetyAlertsChannelId_present;
/*      */   private final int verificationLevel;
/*      */   private final int nsfwLevel;
/*      */   private static final byte STAGE_INITIALIZING = -1;
/*      */   private static final byte STAGE_UNINITIALIZED = 0;
/*      */   private static final byte STAGE_INITIALIZED = 1;
/*      */   
/*      */   private ImmutablePartialGuildData(Id id, String name, Optional<String> icon, Optional<String> splash, Optional<String> discoverySplash, Possible<Boolean> owner, Possible<Long> permissions, Optional<Id> afkChannelId, Possible<Boolean> embedEnabled, Possible<Optional<Id>> embedChannelId, Iterable<String> features, Optional<Id> applicationId, Possible<Boolean> widgetEnabled, Possible<Optional<Id>> widgetChannelId, Optional<Id> systemChannelId, OptionalInt systemChannelFlags, Optional<Id> rulesChannelId, Possible<Optional<Integer>> maxPresences, Possible<Integer> maxMembers, Optional<String> vanityUrlCode, Optional<String> description, Optional<String> banner, Possible<Integer> premiumSubscriptionCount, Optional<Id> publicUpdatesChannelId, Possible<Integer> maxVideoChannelUsers, Possible<Integer> approximateMemberCount, Possible<Integer> approximatePresenceCount, Possible<WelcomeScreenData> welcomeScreen, Possible<Boolean> nsfw, Optional<Id> safetyAlertsChannelId, int verificationLevel, int nsfwLevel) {
/*  120 */     Id id$impl = id;
/*  121 */     this.name = Objects.<String>requireNonNull(name, "name");
/*  122 */     this.icon = icon.orElse(null);
/*  123 */     this.splash = splash.orElse(null);
/*  124 */     this.discoverySplash = discoverySplash.orElse(null);
/*  125 */     Possible<Boolean> owner$impl = owner;
/*  126 */     Possible<Long> permissions$impl = permissions;
/*  127 */     Optional<Id> afkChannelId$impl = afkChannelId;
/*  128 */     Possible<Boolean> embedEnabled$impl = embedEnabled;
/*  129 */     Possible<Optional<Id>> embedChannelId$impl = embedChannelId;
/*  130 */     this.features = createUnmodifiableList(false, createSafeList(features, true, false));
/*  131 */     Optional<Id> applicationId$impl = applicationId;
/*  132 */     Possible<Boolean> widgetEnabled$impl = widgetEnabled;
/*  133 */     Possible<Optional<Id>> widgetChannelId$impl = widgetChannelId;
/*  134 */     Optional<Id> systemChannelId$impl = systemChannelId;
/*  135 */     this.systemChannelFlags = systemChannelFlags.isPresent() ? Integer.valueOf(systemChannelFlags.getAsInt()) : null;
/*  136 */     Optional<Id> rulesChannelId$impl = rulesChannelId;
/*  137 */     Possible<Optional<Integer>> maxPresences$impl = maxPresences;
/*  138 */     Possible<Integer> maxMembers$impl = maxMembers;
/*  139 */     this.vanityUrlCode = vanityUrlCode.orElse(null);
/*  140 */     this.description = description.orElse(null);
/*  141 */     this.banner = banner.orElse(null);
/*  142 */     Possible<Integer> premiumSubscriptionCount$impl = premiumSubscriptionCount;
/*  143 */     Optional<Id> publicUpdatesChannelId$impl = publicUpdatesChannelId;
/*  144 */     Possible<Integer> maxVideoChannelUsers$impl = maxVideoChannelUsers;
/*  145 */     Possible<Integer> approximateMemberCount$impl = approximateMemberCount;
/*  146 */     Possible<Integer> approximatePresenceCount$impl = approximatePresenceCount;
/*  147 */     Possible<WelcomeScreenData> welcomeScreen$impl = welcomeScreen;
/*  148 */     Possible<Boolean> nsfw$impl = nsfw;
/*  149 */     Optional<Id> safetyAlertsChannelId$impl = safetyAlertsChannelId;
/*  150 */     this.verificationLevel = verificationLevel;
/*  151 */     this.nsfwLevel = nsfwLevel;
/*  152 */     this.id_value = id$impl.asLong();
/*  153 */     this.owner_value = owner$impl.toOptional().orElse(null);
/*  154 */     this.owner_absent = owner$impl.isAbsent();
/*  155 */     this.permissions_value = permissions$impl.toOptional().orElse(null);
/*  156 */     this.permissions_absent = permissions$impl.isAbsent();
/*  157 */     this
/*      */       
/*  159 */       .afkChannelId_value = ((Long)afkChannelId$impl.<Long>map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  160 */     this.afkChannelId_present = afkChannelId$impl.isPresent();
/*  161 */     this.embedEnabled_value = embedEnabled$impl.toOptional().orElse(null);
/*  162 */     this.embedEnabled_absent = embedEnabled$impl.isAbsent();
/*  163 */     this
/*      */       
/*  165 */       .embedChannelId_value = ((Long)Possible.flatOpt(embedChannelId$impl).map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  166 */     this.embedChannelId_absent = embedChannelId$impl.isAbsent();
/*  167 */     this.embedChannelId_isNull = (!embedChannelId$impl.isAbsent() && !((Optional)embedChannelId$impl.get()).isPresent());
/*  168 */     this
/*      */       
/*  170 */       .applicationId_value = ((Long)applicationId$impl.<Long>map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  171 */     this.applicationId_present = applicationId$impl.isPresent();
/*  172 */     this.widgetEnabled_value = widgetEnabled$impl.toOptional().orElse(null);
/*  173 */     this.widgetEnabled_absent = widgetEnabled$impl.isAbsent();
/*  174 */     this
/*      */       
/*  176 */       .widgetChannelId_value = ((Long)Possible.flatOpt(widgetChannelId$impl).map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  177 */     this.widgetChannelId_absent = widgetChannelId$impl.isAbsent();
/*  178 */     this.widgetChannelId_isNull = (!widgetChannelId$impl.isAbsent() && !((Optional)widgetChannelId$impl.get()).isPresent());
/*  179 */     this
/*      */       
/*  181 */       .systemChannelId_value = ((Long)systemChannelId$impl.<Long>map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  182 */     this.systemChannelId_present = systemChannelId$impl.isPresent();
/*  183 */     this
/*      */       
/*  185 */       .rulesChannelId_value = ((Long)rulesChannelId$impl.<Long>map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  186 */     this.rulesChannelId_present = rulesChannelId$impl.isPresent();
/*  187 */     this.maxPresences_value = Possible.flatOpt(maxPresences$impl).orElse(null);
/*  188 */     this.maxPresences_absent = maxPresences$impl.isAbsent();
/*  189 */     this.maxMembers_value = maxMembers$impl.toOptional().orElse(null);
/*  190 */     this.maxMembers_absent = maxMembers$impl.isAbsent();
/*  191 */     this.premiumSubscriptionCount_value = premiumSubscriptionCount$impl.toOptional().orElse(null);
/*  192 */     this.premiumSubscriptionCount_absent = premiumSubscriptionCount$impl.isAbsent();
/*  193 */     this
/*      */       
/*  195 */       .publicUpdatesChannelId_value = ((Long)publicUpdatesChannelId$impl.<Long>map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  196 */     this.publicUpdatesChannelId_present = publicUpdatesChannelId$impl.isPresent();
/*  197 */     this.maxVideoChannelUsers_value = maxVideoChannelUsers$impl.toOptional().orElse(null);
/*  198 */     this.maxVideoChannelUsers_absent = maxVideoChannelUsers$impl.isAbsent();
/*  199 */     this.approximateMemberCount_value = approximateMemberCount$impl.toOptional().orElse(null);
/*  200 */     this.approximateMemberCount_absent = approximateMemberCount$impl.isAbsent();
/*  201 */     this.approximatePresenceCount_value = approximatePresenceCount$impl.toOptional().orElse(null);
/*  202 */     this.approximatePresenceCount_absent = approximatePresenceCount$impl.isAbsent();
/*  203 */     this.welcomeScreen_value = welcomeScreen$impl.toOptional().orElse(null);
/*  204 */     this.welcomeScreen_absent = welcomeScreen$impl.isAbsent();
/*  205 */     this.nsfw_value = nsfw$impl.toOptional().orElse(null);
/*  206 */     this.nsfw_absent = nsfw$impl.isAbsent();
/*  207 */     this
/*      */       
/*  209 */       .safetyAlertsChannelId_value = ((Long)safetyAlertsChannelId$impl.<Long>map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  210 */     this.safetyAlertsChannelId_present = safetyAlertsChannelId$impl.isPresent();
/*  211 */     this.initShim = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ImmutablePartialGuildData(ImmutablePartialGuildData original, Id id, String name, String icon, String splash, String discoverySplash, Possible<Boolean> owner, Possible<Long> permissions, Optional<Id> afkChannelId, Possible<Boolean> embedEnabled, Possible<Optional<Id>> embedChannelId, List<String> features, Optional<Id> applicationId, Possible<Boolean> widgetEnabled, Possible<Optional<Id>> widgetChannelId, Optional<Id> systemChannelId, Integer systemChannelFlags, Optional<Id> rulesChannelId, Possible<Optional<Integer>> maxPresences, Possible<Integer> maxMembers, String vanityUrlCode, String description, String banner, Possible<Integer> premiumSubscriptionCount, Optional<Id> publicUpdatesChannelId, Possible<Integer> maxVideoChannelUsers, Possible<Integer> approximateMemberCount, Possible<Integer> approximatePresenceCount, Possible<WelcomeScreenData> welcomeScreen, Possible<Boolean> nsfw, Optional<Id> safetyAlertsChannelId, int verificationLevel, int nsfwLevel) {
/*  248 */     Id id$impl = id;
/*  249 */     this.name = name;
/*  250 */     this.icon = icon;
/*  251 */     this.splash = splash;
/*  252 */     this.discoverySplash = discoverySplash;
/*  253 */     Possible<Boolean> owner$impl = owner;
/*  254 */     Possible<Long> permissions$impl = permissions;
/*  255 */     Optional<Id> afkChannelId$impl = afkChannelId;
/*  256 */     Possible<Boolean> embedEnabled$impl = embedEnabled;
/*  257 */     Possible<Optional<Id>> embedChannelId$impl = embedChannelId;
/*  258 */     this.features = features;
/*  259 */     Optional<Id> applicationId$impl = applicationId;
/*  260 */     Possible<Boolean> widgetEnabled$impl = widgetEnabled;
/*  261 */     Possible<Optional<Id>> widgetChannelId$impl = widgetChannelId;
/*  262 */     Optional<Id> systemChannelId$impl = systemChannelId;
/*  263 */     this.systemChannelFlags = systemChannelFlags;
/*  264 */     Optional<Id> rulesChannelId$impl = rulesChannelId;
/*  265 */     Possible<Optional<Integer>> maxPresences$impl = maxPresences;
/*  266 */     Possible<Integer> maxMembers$impl = maxMembers;
/*  267 */     this.vanityUrlCode = vanityUrlCode;
/*  268 */     this.description = description;
/*  269 */     this.banner = banner;
/*  270 */     Possible<Integer> premiumSubscriptionCount$impl = premiumSubscriptionCount;
/*  271 */     Optional<Id> publicUpdatesChannelId$impl = publicUpdatesChannelId;
/*  272 */     Possible<Integer> maxVideoChannelUsers$impl = maxVideoChannelUsers;
/*  273 */     Possible<Integer> approximateMemberCount$impl = approximateMemberCount;
/*  274 */     Possible<Integer> approximatePresenceCount$impl = approximatePresenceCount;
/*  275 */     Possible<WelcomeScreenData> welcomeScreen$impl = welcomeScreen;
/*  276 */     Possible<Boolean> nsfw$impl = nsfw;
/*  277 */     Optional<Id> safetyAlertsChannelId$impl = safetyAlertsChannelId;
/*  278 */     this.verificationLevel = verificationLevel;
/*  279 */     this.nsfwLevel = nsfwLevel;
/*  280 */     this.id_value = id$impl.asLong();
/*  281 */     this.owner_value = owner$impl.toOptional().orElse(null);
/*  282 */     this.owner_absent = owner$impl.isAbsent();
/*  283 */     this.permissions_value = permissions$impl.toOptional().orElse(null);
/*  284 */     this.permissions_absent = permissions$impl.isAbsent();
/*  285 */     this
/*      */       
/*  287 */       .afkChannelId_value = ((Long)afkChannelId$impl.<Long>map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  288 */     this.afkChannelId_present = afkChannelId$impl.isPresent();
/*  289 */     this.embedEnabled_value = embedEnabled$impl.toOptional().orElse(null);
/*  290 */     this.embedEnabled_absent = embedEnabled$impl.isAbsent();
/*  291 */     this
/*      */       
/*  293 */       .embedChannelId_value = ((Long)Possible.flatOpt(embedChannelId$impl).map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  294 */     this.embedChannelId_absent = embedChannelId$impl.isAbsent();
/*  295 */     this.embedChannelId_isNull = (!embedChannelId$impl.isAbsent() && !((Optional)embedChannelId$impl.get()).isPresent());
/*  296 */     this
/*      */       
/*  298 */       .applicationId_value = ((Long)applicationId$impl.<Long>map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  299 */     this.applicationId_present = applicationId$impl.isPresent();
/*  300 */     this.widgetEnabled_value = widgetEnabled$impl.toOptional().orElse(null);
/*  301 */     this.widgetEnabled_absent = widgetEnabled$impl.isAbsent();
/*  302 */     this
/*      */       
/*  304 */       .widgetChannelId_value = ((Long)Possible.flatOpt(widgetChannelId$impl).map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  305 */     this.widgetChannelId_absent = widgetChannelId$impl.isAbsent();
/*  306 */     this.widgetChannelId_isNull = (!widgetChannelId$impl.isAbsent() && !((Optional)widgetChannelId$impl.get()).isPresent());
/*  307 */     this
/*      */       
/*  309 */       .systemChannelId_value = ((Long)systemChannelId$impl.<Long>map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  310 */     this.systemChannelId_present = systemChannelId$impl.isPresent();
/*  311 */     this
/*      */       
/*  313 */       .rulesChannelId_value = ((Long)rulesChannelId$impl.<Long>map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  314 */     this.rulesChannelId_present = rulesChannelId$impl.isPresent();
/*  315 */     this.maxPresences_value = Possible.flatOpt(maxPresences$impl).orElse(null);
/*  316 */     this.maxPresences_absent = maxPresences$impl.isAbsent();
/*  317 */     this.maxMembers_value = maxMembers$impl.toOptional().orElse(null);
/*  318 */     this.maxMembers_absent = maxMembers$impl.isAbsent();
/*  319 */     this.premiumSubscriptionCount_value = premiumSubscriptionCount$impl.toOptional().orElse(null);
/*  320 */     this.premiumSubscriptionCount_absent = premiumSubscriptionCount$impl.isAbsent();
/*  321 */     this
/*      */       
/*  323 */       .publicUpdatesChannelId_value = ((Long)publicUpdatesChannelId$impl.<Long>map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  324 */     this.publicUpdatesChannelId_present = publicUpdatesChannelId$impl.isPresent();
/*  325 */     this.maxVideoChannelUsers_value = maxVideoChannelUsers$impl.toOptional().orElse(null);
/*  326 */     this.maxVideoChannelUsers_absent = maxVideoChannelUsers$impl.isAbsent();
/*  327 */     this.approximateMemberCount_value = approximateMemberCount$impl.toOptional().orElse(null);
/*  328 */     this.approximateMemberCount_absent = approximateMemberCount$impl.isAbsent();
/*  329 */     this.approximatePresenceCount_value = approximatePresenceCount$impl.toOptional().orElse(null);
/*  330 */     this.approximatePresenceCount_absent = approximatePresenceCount$impl.isAbsent();
/*  331 */     this.welcomeScreen_value = welcomeScreen$impl.toOptional().orElse(null);
/*  332 */     this.welcomeScreen_absent = welcomeScreen$impl.isAbsent();
/*  333 */     this.nsfw_value = nsfw$impl.toOptional().orElse(null);
/*  334 */     this.nsfw_absent = nsfw$impl.isAbsent();
/*  335 */     this
/*      */       
/*  337 */       .safetyAlertsChannelId_value = ((Long)safetyAlertsChannelId$impl.<Long>map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  338 */     this.safetyAlertsChannelId_present = safetyAlertsChannelId$impl.isPresent();
/*  339 */     this.initShim = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  345 */   private volatile transient InitShim initShim = new InitShim();
/*      */   
/*      */   @Generated(from = "PartialGuildData", generator = "Immutables")
/*      */   private final class InitShim {
/*      */     private String formatInitCycleMessage() {
/*  350 */       List<String> attributes = new ArrayList<>();
/*  351 */       return "Cannot build PartialGuildData, attribute initializers form cycle " + attributes;
/*      */     }
/*      */ 
/*      */     
/*      */     private InitShim() {}
/*      */   }
/*      */ 
/*      */   
/*      */   @JsonProperty("id")
/*      */   public Id id() {
/*  361 */     return Id.of(this.id_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("name")
/*      */   public String name() {
/*  370 */     return this.name;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("icon")
/*      */   public Optional<String> icon() {
/*  379 */     return Optional.ofNullable(this.icon);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("splash")
/*      */   public Optional<String> splash() {
/*  388 */     return Optional.ofNullable(this.splash);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("discovery_splash")
/*      */   public Optional<String> discoverySplash() {
/*  397 */     return Optional.ofNullable(this.discoverySplash);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("owner")
/*      */   public Possible<Boolean> owner() {
/*  406 */     return this.owner_absent ? Possible.absent() : Possible.of(this.owner_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("permissions")
/*      */   public Possible<Long> permissions() {
/*  415 */     return this.permissions_absent ? Possible.absent() : Possible.of(this.permissions_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("afk_channel_id")
/*      */   public Optional<Id> afkChannelId() {
/*  424 */     return this.afkChannelId_present ? Optional.<Id>of(Id.of(this.afkChannelId_value)) : Optional.<Id>empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("embed_enabled")
/*      */   @Deprecated
/*      */   public Possible<Boolean> embedEnabled() {
/*  434 */     return this.embedEnabled_absent ? Possible.absent() : Possible.of(this.embedEnabled_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("embed_channel_id")
/*      */   @Deprecated
/*      */   public Possible<Optional<Id>> embedChannelId() {
/*  444 */     if (this.embedChannelId_absent)
/*  445 */       return Possible.absent(); 
/*  446 */     if (this.embedChannelId_isNull) {
/*  447 */       return Possible.of(Optional.empty());
/*      */     }
/*  449 */     return Possible.of(Optional.of(Id.of(this.embedChannelId_value)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("features")
/*      */   public List<String> features() {
/*  459 */     return this.features;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("application_id")
/*      */   public Optional<Id> applicationId() {
/*  468 */     return this.applicationId_present ? Optional.<Id>of(Id.of(this.applicationId_value)) : Optional.<Id>empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("widget_enabled")
/*      */   public Possible<Boolean> widgetEnabled() {
/*  477 */     return this.widgetEnabled_absent ? Possible.absent() : Possible.of(this.widgetEnabled_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("widget_channel_id")
/*      */   public Possible<Optional<Id>> widgetChannelId() {
/*  486 */     if (this.widgetChannelId_absent)
/*  487 */       return Possible.absent(); 
/*  488 */     if (this.widgetChannelId_isNull) {
/*  489 */       return Possible.of(Optional.empty());
/*      */     }
/*  491 */     return Possible.of(Optional.of(Id.of(this.widgetChannelId_value)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("system_channel_id")
/*      */   public Optional<Id> systemChannelId() {
/*  501 */     return this.systemChannelId_present ? Optional.<Id>of(Id.of(this.systemChannelId_value)) : Optional.<Id>empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("system_channel_flags")
/*      */   public OptionalInt systemChannelFlags() {
/*  510 */     return (this.systemChannelFlags != null) ? 
/*  511 */       OptionalInt.of(this.systemChannelFlags.intValue()) : 
/*  512 */       OptionalInt.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("rules_channel_id")
/*      */   public Optional<Id> rulesChannelId() {
/*  521 */     return this.rulesChannelId_present ? Optional.<Id>of(Id.of(this.rulesChannelId_value)) : Optional.<Id>empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("max_presences")
/*      */   public Possible<Optional<Integer>> maxPresences() {
/*  530 */     return this.maxPresences_absent ? Possible.absent() : 
/*  531 */       Possible.of(Optional.ofNullable(this.maxPresences_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("max_members")
/*      */   public Possible<Integer> maxMembers() {
/*  540 */     return this.maxMembers_absent ? Possible.absent() : Possible.of(this.maxMembers_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("vanity_url_code")
/*      */   public Optional<String> vanityUrlCode() {
/*  549 */     return Optional.ofNullable(this.vanityUrlCode);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("description")
/*      */   public Optional<String> description() {
/*  558 */     return Optional.ofNullable(this.description);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("banner")
/*      */   public Optional<String> banner() {
/*  567 */     return Optional.ofNullable(this.banner);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("premium_subscription_count")
/*      */   public Possible<Integer> premiumSubscriptionCount() {
/*  576 */     return this.premiumSubscriptionCount_absent ? Possible.absent() : Possible.of(this.premiumSubscriptionCount_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("public_updates_channel_id")
/*      */   public Optional<Id> publicUpdatesChannelId() {
/*  585 */     return this.publicUpdatesChannelId_present ? Optional.<Id>of(Id.of(this.publicUpdatesChannelId_value)) : Optional.<Id>empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("max_video_channel_users")
/*      */   public Possible<Integer> maxVideoChannelUsers() {
/*  594 */     return this.maxVideoChannelUsers_absent ? Possible.absent() : Possible.of(this.maxVideoChannelUsers_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("approximate_member_count")
/*      */   public Possible<Integer> approximateMemberCount() {
/*  603 */     return this.approximateMemberCount_absent ? Possible.absent() : Possible.of(this.approximateMemberCount_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("approximate_presence_count")
/*      */   public Possible<Integer> approximatePresenceCount() {
/*  612 */     return this.approximatePresenceCount_absent ? Possible.absent() : Possible.of(this.approximatePresenceCount_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("welcome_screen")
/*      */   public Possible<WelcomeScreenData> welcomeScreen() {
/*  621 */     return this.welcomeScreen_absent ? Possible.absent() : Possible.of(this.welcomeScreen_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("nsfw")
/*      */   @Deprecated
/*      */   public Possible<Boolean> nsfw() {
/*  631 */     return this.nsfw_absent ? Possible.absent() : Possible.of(this.nsfw_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("safety_alerts_channel_id")
/*      */   public Optional<Id> safetyAlertsChannelId() {
/*  640 */     return this.safetyAlertsChannelId_present ? Optional.<Id>of(Id.of(this.safetyAlertsChannelId_value)) : Optional.<Id>empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("verification_level")
/*      */   public int verificationLevel() {
/*  649 */     return this.verificationLevel;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("nsfw_level")
/*      */   public int nsfwLevel() {
/*  658 */     return this.nsfwLevel;
/*      */   }
/*      */   
/*      */   public ImmutablePartialGuildData withId(long value) {
/*  662 */     Id newValue = Id.of(value);
/*  663 */     return new ImmutablePartialGuildData(this, newValue, this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  670 */         owner(), 
/*  671 */         permissions(), 
/*  672 */         afkChannelId(), 
/*  673 */         embedEnabled(), 
/*  674 */         embedChannelId(), this.features, 
/*      */         
/*  676 */         applicationId(), 
/*  677 */         widgetEnabled(), 
/*  678 */         widgetChannelId(), 
/*  679 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/*  681 */         rulesChannelId(), 
/*  682 */         maxPresences(), 
/*  683 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/*  687 */         premiumSubscriptionCount(), 
/*  688 */         publicUpdatesChannelId(), 
/*  689 */         maxVideoChannelUsers(), 
/*  690 */         approximateMemberCount(), 
/*  691 */         approximatePresenceCount(), 
/*  692 */         welcomeScreen(), 
/*  693 */         nsfw(), 
/*  694 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutablePartialGuildData withId(String value) {
/*  700 */     Id newValue = Id.of(value);
/*  701 */     return new ImmutablePartialGuildData(this, newValue, this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  708 */         owner(), 
/*  709 */         permissions(), 
/*  710 */         afkChannelId(), 
/*  711 */         embedEnabled(), 
/*  712 */         embedChannelId(), this.features, 
/*      */         
/*  714 */         applicationId(), 
/*  715 */         widgetEnabled(), 
/*  716 */         widgetChannelId(), 
/*  717 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/*  719 */         rulesChannelId(), 
/*  720 */         maxPresences(), 
/*  721 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/*  725 */         premiumSubscriptionCount(), 
/*  726 */         publicUpdatesChannelId(), 
/*  727 */         maxVideoChannelUsers(), 
/*  728 */         approximateMemberCount(), 
/*  729 */         approximatePresenceCount(), 
/*  730 */         welcomeScreen(), 
/*  731 */         nsfw(), 
/*  732 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutablePartialGuildData withName(String value) {
/*  744 */     String newValue = Objects.<String>requireNonNull(value, "name");
/*  745 */     if (this.name.equals(newValue)) return this; 
/*  746 */     return new ImmutablePartialGuildData(this, 
/*      */         
/*  748 */         id(), newValue, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  753 */         owner(), 
/*  754 */         permissions(), 
/*  755 */         afkChannelId(), 
/*  756 */         embedEnabled(), 
/*  757 */         embedChannelId(), this.features, 
/*      */         
/*  759 */         applicationId(), 
/*  760 */         widgetEnabled(), 
/*  761 */         widgetChannelId(), 
/*  762 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/*  764 */         rulesChannelId(), 
/*  765 */         maxPresences(), 
/*  766 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/*  770 */         premiumSubscriptionCount(), 
/*  771 */         publicUpdatesChannelId(), 
/*  772 */         maxVideoChannelUsers(), 
/*  773 */         approximateMemberCount(), 
/*  774 */         approximatePresenceCount(), 
/*  775 */         welcomeScreen(), 
/*  776 */         nsfw(), 
/*  777 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutablePartialGuildData withIcon(String value) {
/*  788 */     String newValue = Objects.<String>requireNonNull(value, "icon");
/*  789 */     if (Objects.equals(this.icon, newValue)) return this; 
/*  790 */     return new ImmutablePartialGuildData(this, 
/*      */         
/*  792 */         id(), this.name, newValue, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  797 */         owner(), 
/*  798 */         permissions(), 
/*  799 */         afkChannelId(), 
/*  800 */         embedEnabled(), 
/*  801 */         embedChannelId(), this.features, 
/*      */         
/*  803 */         applicationId(), 
/*  804 */         widgetEnabled(), 
/*  805 */         widgetChannelId(), 
/*  806 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/*  808 */         rulesChannelId(), 
/*  809 */         maxPresences(), 
/*  810 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/*  814 */         premiumSubscriptionCount(), 
/*  815 */         publicUpdatesChannelId(), 
/*  816 */         maxVideoChannelUsers(), 
/*  817 */         approximateMemberCount(), 
/*  818 */         approximatePresenceCount(), 
/*  819 */         welcomeScreen(), 
/*  820 */         nsfw(), 
/*  821 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutablePartialGuildData withIcon(Optional<String> optional) {
/*  833 */     String value = optional.orElse(null);
/*  834 */     if (Objects.equals(this.icon, value)) return this; 
/*  835 */     return new ImmutablePartialGuildData(this, 
/*      */         
/*  837 */         id(), this.name, value, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  842 */         owner(), 
/*  843 */         permissions(), 
/*  844 */         afkChannelId(), 
/*  845 */         embedEnabled(), 
/*  846 */         embedChannelId(), this.features, 
/*      */         
/*  848 */         applicationId(), 
/*  849 */         widgetEnabled(), 
/*  850 */         widgetChannelId(), 
/*  851 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/*  853 */         rulesChannelId(), 
/*  854 */         maxPresences(), 
/*  855 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/*  859 */         premiumSubscriptionCount(), 
/*  860 */         publicUpdatesChannelId(), 
/*  861 */         maxVideoChannelUsers(), 
/*  862 */         approximateMemberCount(), 
/*  863 */         approximatePresenceCount(), 
/*  864 */         welcomeScreen(), 
/*  865 */         nsfw(), 
/*  866 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutablePartialGuildData withSplash(String value) {
/*  877 */     String newValue = Objects.<String>requireNonNull(value, "splash");
/*  878 */     if (Objects.equals(this.splash, newValue)) return this; 
/*  879 */     return new ImmutablePartialGuildData(this, 
/*      */         
/*  881 */         id(), this.name, this.icon, newValue, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  886 */         owner(), 
/*  887 */         permissions(), 
/*  888 */         afkChannelId(), 
/*  889 */         embedEnabled(), 
/*  890 */         embedChannelId(), this.features, 
/*      */         
/*  892 */         applicationId(), 
/*  893 */         widgetEnabled(), 
/*  894 */         widgetChannelId(), 
/*  895 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/*  897 */         rulesChannelId(), 
/*  898 */         maxPresences(), 
/*  899 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/*  903 */         premiumSubscriptionCount(), 
/*  904 */         publicUpdatesChannelId(), 
/*  905 */         maxVideoChannelUsers(), 
/*  906 */         approximateMemberCount(), 
/*  907 */         approximatePresenceCount(), 
/*  908 */         welcomeScreen(), 
/*  909 */         nsfw(), 
/*  910 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutablePartialGuildData withSplash(Optional<String> optional) {
/*  922 */     String value = optional.orElse(null);
/*  923 */     if (Objects.equals(this.splash, value)) return this; 
/*  924 */     return new ImmutablePartialGuildData(this, 
/*      */         
/*  926 */         id(), this.name, this.icon, value, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  931 */         owner(), 
/*  932 */         permissions(), 
/*  933 */         afkChannelId(), 
/*  934 */         embedEnabled(), 
/*  935 */         embedChannelId(), this.features, 
/*      */         
/*  937 */         applicationId(), 
/*  938 */         widgetEnabled(), 
/*  939 */         widgetChannelId(), 
/*  940 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/*  942 */         rulesChannelId(), 
/*  943 */         maxPresences(), 
/*  944 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/*  948 */         premiumSubscriptionCount(), 
/*  949 */         publicUpdatesChannelId(), 
/*  950 */         maxVideoChannelUsers(), 
/*  951 */         approximateMemberCount(), 
/*  952 */         approximatePresenceCount(), 
/*  953 */         welcomeScreen(), 
/*  954 */         nsfw(), 
/*  955 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutablePartialGuildData withDiscoverySplash(String value) {
/*  966 */     String newValue = Objects.<String>requireNonNull(value, "discoverySplash");
/*  967 */     if (Objects.equals(this.discoverySplash, newValue)) return this; 
/*  968 */     return new ImmutablePartialGuildData(this, 
/*      */         
/*  970 */         id(), this.name, this.icon, this.splash, newValue, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  975 */         owner(), 
/*  976 */         permissions(), 
/*  977 */         afkChannelId(), 
/*  978 */         embedEnabled(), 
/*  979 */         embedChannelId(), this.features, 
/*      */         
/*  981 */         applicationId(), 
/*  982 */         widgetEnabled(), 
/*  983 */         widgetChannelId(), 
/*  984 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/*  986 */         rulesChannelId(), 
/*  987 */         maxPresences(), 
/*  988 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/*  992 */         premiumSubscriptionCount(), 
/*  993 */         publicUpdatesChannelId(), 
/*  994 */         maxVideoChannelUsers(), 
/*  995 */         approximateMemberCount(), 
/*  996 */         approximatePresenceCount(), 
/*  997 */         welcomeScreen(), 
/*  998 */         nsfw(), 
/*  999 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutablePartialGuildData withDiscoverySplash(Optional<String> optional) {
/* 1011 */     String value = optional.orElse(null);
/* 1012 */     if (Objects.equals(this.discoverySplash, value)) return this; 
/* 1013 */     return new ImmutablePartialGuildData(this, 
/*      */         
/* 1015 */         id(), this.name, this.icon, this.splash, value, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1020 */         owner(), 
/* 1021 */         permissions(), 
/* 1022 */         afkChannelId(), 
/* 1023 */         embedEnabled(), 
/* 1024 */         embedChannelId(), this.features, 
/*      */         
/* 1026 */         applicationId(), 
/* 1027 */         widgetEnabled(), 
/* 1028 */         widgetChannelId(), 
/* 1029 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 1031 */         rulesChannelId(), 
/* 1032 */         maxPresences(), 
/* 1033 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1037 */         premiumSubscriptionCount(), 
/* 1038 */         publicUpdatesChannelId(), 
/* 1039 */         maxVideoChannelUsers(), 
/* 1040 */         approximateMemberCount(), 
/* 1041 */         approximatePresenceCount(), 
/* 1042 */         welcomeScreen(), 
/* 1043 */         nsfw(), 
/* 1044 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutablePartialGuildData withOwner(Possible<Boolean> value) {
/* 1050 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/* 1051 */     return new ImmutablePartialGuildData(this, 
/*      */         
/* 1053 */         id(), this.name, this.icon, this.splash, this.discoverySplash, newValue, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1059 */         permissions(), 
/* 1060 */         afkChannelId(), 
/* 1061 */         embedEnabled(), 
/* 1062 */         embedChannelId(), this.features, 
/*      */         
/* 1064 */         applicationId(), 
/* 1065 */         widgetEnabled(), 
/* 1066 */         widgetChannelId(), 
/* 1067 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 1069 */         rulesChannelId(), 
/* 1070 */         maxPresences(), 
/* 1071 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1075 */         premiumSubscriptionCount(), 
/* 1076 */         publicUpdatesChannelId(), 
/* 1077 */         maxVideoChannelUsers(), 
/* 1078 */         approximateMemberCount(), 
/* 1079 */         approximatePresenceCount(), 
/* 1080 */         welcomeScreen(), 
/* 1081 */         nsfw(), 
/* 1082 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutablePartialGuildData withOwner(Boolean value) {
/* 1088 */     Possible<Boolean> newValue = Possible.of(value);
/* 1089 */     return new ImmutablePartialGuildData(this, 
/*      */         
/* 1091 */         id(), this.name, this.icon, this.splash, this.discoverySplash, newValue, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1097 */         permissions(), 
/* 1098 */         afkChannelId(), 
/* 1099 */         embedEnabled(), 
/* 1100 */         embedChannelId(), this.features, 
/*      */         
/* 1102 */         applicationId(), 
/* 1103 */         widgetEnabled(), 
/* 1104 */         widgetChannelId(), 
/* 1105 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 1107 */         rulesChannelId(), 
/* 1108 */         maxPresences(), 
/* 1109 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1113 */         premiumSubscriptionCount(), 
/* 1114 */         publicUpdatesChannelId(), 
/* 1115 */         maxVideoChannelUsers(), 
/* 1116 */         approximateMemberCount(), 
/* 1117 */         approximatePresenceCount(), 
/* 1118 */         welcomeScreen(), 
/* 1119 */         nsfw(), 
/* 1120 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutablePartialGuildData withPermissions(Possible<Long> value) {
/* 1126 */     Possible<Long> newValue = Objects.<Possible<Long>>requireNonNull(value);
/* 1127 */     return new ImmutablePartialGuildData(this, 
/*      */         
/* 1129 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1134 */         owner(), newValue, 
/*      */         
/* 1136 */         afkChannelId(), 
/* 1137 */         embedEnabled(), 
/* 1138 */         embedChannelId(), this.features, 
/*      */         
/* 1140 */         applicationId(), 
/* 1141 */         widgetEnabled(), 
/* 1142 */         widgetChannelId(), 
/* 1143 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 1145 */         rulesChannelId(), 
/* 1146 */         maxPresences(), 
/* 1147 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1151 */         premiumSubscriptionCount(), 
/* 1152 */         publicUpdatesChannelId(), 
/* 1153 */         maxVideoChannelUsers(), 
/* 1154 */         approximateMemberCount(), 
/* 1155 */         approximatePresenceCount(), 
/* 1156 */         welcomeScreen(), 
/* 1157 */         nsfw(), 
/* 1158 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutablePartialGuildData withPermissions(Long value) {
/* 1164 */     Possible<Long> newValue = Possible.of(value);
/* 1165 */     return new ImmutablePartialGuildData(this, 
/*      */         
/* 1167 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1172 */         owner(), newValue, 
/*      */         
/* 1174 */         afkChannelId(), 
/* 1175 */         embedEnabled(), 
/* 1176 */         embedChannelId(), this.features, 
/*      */         
/* 1178 */         applicationId(), 
/* 1179 */         widgetEnabled(), 
/* 1180 */         widgetChannelId(), 
/* 1181 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 1183 */         rulesChannelId(), 
/* 1184 */         maxPresences(), 
/* 1185 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1189 */         premiumSubscriptionCount(), 
/* 1190 */         publicUpdatesChannelId(), 
/* 1191 */         maxVideoChannelUsers(), 
/* 1192 */         approximateMemberCount(), 
/* 1193 */         approximatePresenceCount(), 
/* 1194 */         welcomeScreen(), 
/* 1195 */         nsfw(), 
/* 1196 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutablePartialGuildData withAfkChannelId(Optional<Id> value) {
/* 1202 */     Optional<Id> newValue = Objects.<Optional<Id>>requireNonNull(value);
/* 1203 */     return new ImmutablePartialGuildData(this, 
/*      */         
/* 1205 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1210 */         owner(), 
/* 1211 */         permissions(), newValue, 
/*      */         
/* 1213 */         embedEnabled(), 
/* 1214 */         embedChannelId(), this.features, 
/*      */         
/* 1216 */         applicationId(), 
/* 1217 */         widgetEnabled(), 
/* 1218 */         widgetChannelId(), 
/* 1219 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 1221 */         rulesChannelId(), 
/* 1222 */         maxPresences(), 
/* 1223 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1227 */         premiumSubscriptionCount(), 
/* 1228 */         publicUpdatesChannelId(), 
/* 1229 */         maxVideoChannelUsers(), 
/* 1230 */         approximateMemberCount(), 
/* 1231 */         approximatePresenceCount(), 
/* 1232 */         welcomeScreen(), 
/* 1233 */         nsfw(), 
/* 1234 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutablePartialGuildData withAfkChannelId(long value) {
/* 1240 */     Optional<Id> newValue = Optional.of(Id.of(value));
/* 1241 */     return new ImmutablePartialGuildData(this, 
/*      */         
/* 1243 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1248 */         owner(), 
/* 1249 */         permissions(), newValue, 
/*      */         
/* 1251 */         embedEnabled(), 
/* 1252 */         embedChannelId(), this.features, 
/*      */         
/* 1254 */         applicationId(), 
/* 1255 */         widgetEnabled(), 
/* 1256 */         widgetChannelId(), 
/* 1257 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 1259 */         rulesChannelId(), 
/* 1260 */         maxPresences(), 
/* 1261 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1265 */         premiumSubscriptionCount(), 
/* 1266 */         publicUpdatesChannelId(), 
/* 1267 */         maxVideoChannelUsers(), 
/* 1268 */         approximateMemberCount(), 
/* 1269 */         approximatePresenceCount(), 
/* 1270 */         welcomeScreen(), 
/* 1271 */         nsfw(), 
/* 1272 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutablePartialGuildData withEmbedEnabled(Possible<Boolean> value) {
/* 1278 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/* 1279 */     return new ImmutablePartialGuildData(this, 
/*      */         
/* 1281 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1286 */         owner(), 
/* 1287 */         permissions(), 
/* 1288 */         afkChannelId(), newValue, 
/*      */         
/* 1290 */         embedChannelId(), this.features, 
/*      */         
/* 1292 */         applicationId(), 
/* 1293 */         widgetEnabled(), 
/* 1294 */         widgetChannelId(), 
/* 1295 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 1297 */         rulesChannelId(), 
/* 1298 */         maxPresences(), 
/* 1299 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1303 */         premiumSubscriptionCount(), 
/* 1304 */         publicUpdatesChannelId(), 
/* 1305 */         maxVideoChannelUsers(), 
/* 1306 */         approximateMemberCount(), 
/* 1307 */         approximatePresenceCount(), 
/* 1308 */         welcomeScreen(), 
/* 1309 */         nsfw(), 
/* 1310 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutablePartialGuildData withEmbedEnabled(Boolean value) {
/* 1316 */     Possible<Boolean> newValue = Possible.of(value);
/* 1317 */     return new ImmutablePartialGuildData(this, 
/*      */         
/* 1319 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1324 */         owner(), 
/* 1325 */         permissions(), 
/* 1326 */         afkChannelId(), newValue, 
/*      */         
/* 1328 */         embedChannelId(), this.features, 
/*      */         
/* 1330 */         applicationId(), 
/* 1331 */         widgetEnabled(), 
/* 1332 */         widgetChannelId(), 
/* 1333 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 1335 */         rulesChannelId(), 
/* 1336 */         maxPresences(), 
/* 1337 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1341 */         premiumSubscriptionCount(), 
/* 1342 */         publicUpdatesChannelId(), 
/* 1343 */         maxVideoChannelUsers(), 
/* 1344 */         approximateMemberCount(), 
/* 1345 */         approximatePresenceCount(), 
/* 1346 */         welcomeScreen(), 
/* 1347 */         nsfw(), 
/* 1348 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutablePartialGuildData withEmbedChannelId(Possible<Optional<Id>> value) {
/* 1354 */     Possible<Optional<Id>> newValue = Objects.<Possible<Optional<Id>>>requireNonNull(value);
/* 1355 */     return new ImmutablePartialGuildData(this, 
/*      */         
/* 1357 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1362 */         owner(), 
/* 1363 */         permissions(), 
/* 1364 */         afkChannelId(), 
/* 1365 */         embedEnabled(), newValue, this.features, 
/*      */ 
/*      */         
/* 1368 */         applicationId(), 
/* 1369 */         widgetEnabled(), 
/* 1370 */         widgetChannelId(), 
/* 1371 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 1373 */         rulesChannelId(), 
/* 1374 */         maxPresences(), 
/* 1375 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1379 */         premiumSubscriptionCount(), 
/* 1380 */         publicUpdatesChannelId(), 
/* 1381 */         maxVideoChannelUsers(), 
/* 1382 */         approximateMemberCount(), 
/* 1383 */         approximatePresenceCount(), 
/* 1384 */         welcomeScreen(), 
/* 1385 */         nsfw(), 
/* 1386 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public ImmutablePartialGuildData withEmbedChannelId(@Nullable Long value) {
/* 1394 */     Possible<Optional<Id>> newValue = (value == null) ? Possible.of(Optional.empty()) : Possible.of(Optional.of(Id.of(value.longValue())));
/* 1395 */     return new ImmutablePartialGuildData(this, 
/*      */         
/* 1397 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1402 */         owner(), 
/* 1403 */         permissions(), 
/* 1404 */         afkChannelId(), 
/* 1405 */         embedEnabled(), newValue, this.features, 
/*      */ 
/*      */         
/* 1408 */         applicationId(), 
/* 1409 */         widgetEnabled(), 
/* 1410 */         widgetChannelId(), 
/* 1411 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 1413 */         rulesChannelId(), 
/* 1414 */         maxPresences(), 
/* 1415 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1419 */         premiumSubscriptionCount(), 
/* 1420 */         publicUpdatesChannelId(), 
/* 1421 */         maxVideoChannelUsers(), 
/* 1422 */         approximateMemberCount(), 
/* 1423 */         approximatePresenceCount(), 
/* 1424 */         welcomeScreen(), 
/* 1425 */         nsfw(), 
/* 1426 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutablePartialGuildData withEmbedChannelIdOrNull(@Nullable Long value) {
/* 1433 */     Possible<Optional<Id>> newValue = (value == null) ? Possible.of(Optional.empty()) : Possible.of(Optional.of(Id.of(value.longValue())));
/* 1434 */     return new ImmutablePartialGuildData(this, 
/*      */         
/* 1436 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1441 */         owner(), 
/* 1442 */         permissions(), 
/* 1443 */         afkChannelId(), 
/* 1444 */         embedEnabled(), newValue, this.features, 
/*      */ 
/*      */         
/* 1447 */         applicationId(), 
/* 1448 */         widgetEnabled(), 
/* 1449 */         widgetChannelId(), 
/* 1450 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 1452 */         rulesChannelId(), 
/* 1453 */         maxPresences(), 
/* 1454 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1458 */         premiumSubscriptionCount(), 
/* 1459 */         publicUpdatesChannelId(), 
/* 1460 */         maxVideoChannelUsers(), 
/* 1461 */         approximateMemberCount(), 
/* 1462 */         approximatePresenceCount(), 
/* 1463 */         welcomeScreen(), 
/* 1464 */         nsfw(), 
/* 1465 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutablePartialGuildData withFeatures(String... elements) {
/* 1476 */     List<String> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/* 1477 */     return new ImmutablePartialGuildData(this, 
/*      */         
/* 1479 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1484 */         owner(), 
/* 1485 */         permissions(), 
/* 1486 */         afkChannelId(), 
/* 1487 */         embedEnabled(), 
/* 1488 */         embedChannelId(), newValue, 
/*      */         
/* 1490 */         applicationId(), 
/* 1491 */         widgetEnabled(), 
/* 1492 */         widgetChannelId(), 
/* 1493 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 1495 */         rulesChannelId(), 
/* 1496 */         maxPresences(), 
/* 1497 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1501 */         premiumSubscriptionCount(), 
/* 1502 */         publicUpdatesChannelId(), 
/* 1503 */         maxVideoChannelUsers(), 
/* 1504 */         approximateMemberCount(), 
/* 1505 */         approximatePresenceCount(), 
/* 1506 */         welcomeScreen(), 
/* 1507 */         nsfw(), 
/* 1508 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutablePartialGuildData withFeatures(Iterable<String> elements) {
/* 1520 */     if (this.features == elements) return this; 
/* 1521 */     List<String> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/* 1522 */     return new ImmutablePartialGuildData(this, 
/*      */         
/* 1524 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1529 */         owner(), 
/* 1530 */         permissions(), 
/* 1531 */         afkChannelId(), 
/* 1532 */         embedEnabled(), 
/* 1533 */         embedChannelId(), newValue, 
/*      */         
/* 1535 */         applicationId(), 
/* 1536 */         widgetEnabled(), 
/* 1537 */         widgetChannelId(), 
/* 1538 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 1540 */         rulesChannelId(), 
/* 1541 */         maxPresences(), 
/* 1542 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1546 */         premiumSubscriptionCount(), 
/* 1547 */         publicUpdatesChannelId(), 
/* 1548 */         maxVideoChannelUsers(), 
/* 1549 */         approximateMemberCount(), 
/* 1550 */         approximatePresenceCount(), 
/* 1551 */         welcomeScreen(), 
/* 1552 */         nsfw(), 
/* 1553 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutablePartialGuildData withApplicationId(Optional<Id> value) {
/* 1559 */     Optional<Id> newValue = Objects.<Optional<Id>>requireNonNull(value);
/* 1560 */     return new ImmutablePartialGuildData(this, 
/*      */         
/* 1562 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1567 */         owner(), 
/* 1568 */         permissions(), 
/* 1569 */         afkChannelId(), 
/* 1570 */         embedEnabled(), 
/* 1571 */         embedChannelId(), this.features, newValue, 
/*      */ 
/*      */         
/* 1574 */         widgetEnabled(), 
/* 1575 */         widgetChannelId(), 
/* 1576 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 1578 */         rulesChannelId(), 
/* 1579 */         maxPresences(), 
/* 1580 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1584 */         premiumSubscriptionCount(), 
/* 1585 */         publicUpdatesChannelId(), 
/* 1586 */         maxVideoChannelUsers(), 
/* 1587 */         approximateMemberCount(), 
/* 1588 */         approximatePresenceCount(), 
/* 1589 */         welcomeScreen(), 
/* 1590 */         nsfw(), 
/* 1591 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutablePartialGuildData withApplicationId(long value) {
/* 1597 */     Optional<Id> newValue = Optional.of(Id.of(value));
/* 1598 */     return new ImmutablePartialGuildData(this, 
/*      */         
/* 1600 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1605 */         owner(), 
/* 1606 */         permissions(), 
/* 1607 */         afkChannelId(), 
/* 1608 */         embedEnabled(), 
/* 1609 */         embedChannelId(), this.features, newValue, 
/*      */ 
/*      */         
/* 1612 */         widgetEnabled(), 
/* 1613 */         widgetChannelId(), 
/* 1614 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 1616 */         rulesChannelId(), 
/* 1617 */         maxPresences(), 
/* 1618 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1622 */         premiumSubscriptionCount(), 
/* 1623 */         publicUpdatesChannelId(), 
/* 1624 */         maxVideoChannelUsers(), 
/* 1625 */         approximateMemberCount(), 
/* 1626 */         approximatePresenceCount(), 
/* 1627 */         welcomeScreen(), 
/* 1628 */         nsfw(), 
/* 1629 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutablePartialGuildData withWidgetEnabled(Possible<Boolean> value) {
/* 1635 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/* 1636 */     return new ImmutablePartialGuildData(this, 
/*      */         
/* 1638 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1643 */         owner(), 
/* 1644 */         permissions(), 
/* 1645 */         afkChannelId(), 
/* 1646 */         embedEnabled(), 
/* 1647 */         embedChannelId(), this.features, 
/*      */         
/* 1649 */         applicationId(), newValue, 
/*      */         
/* 1651 */         widgetChannelId(), 
/* 1652 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 1654 */         rulesChannelId(), 
/* 1655 */         maxPresences(), 
/* 1656 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1660 */         premiumSubscriptionCount(), 
/* 1661 */         publicUpdatesChannelId(), 
/* 1662 */         maxVideoChannelUsers(), 
/* 1663 */         approximateMemberCount(), 
/* 1664 */         approximatePresenceCount(), 
/* 1665 */         welcomeScreen(), 
/* 1666 */         nsfw(), 
/* 1667 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutablePartialGuildData withWidgetEnabled(Boolean value) {
/* 1673 */     Possible<Boolean> newValue = Possible.of(value);
/* 1674 */     return new ImmutablePartialGuildData(this, 
/*      */         
/* 1676 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1681 */         owner(), 
/* 1682 */         permissions(), 
/* 1683 */         afkChannelId(), 
/* 1684 */         embedEnabled(), 
/* 1685 */         embedChannelId(), this.features, 
/*      */         
/* 1687 */         applicationId(), newValue, 
/*      */         
/* 1689 */         widgetChannelId(), 
/* 1690 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 1692 */         rulesChannelId(), 
/* 1693 */         maxPresences(), 
/* 1694 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1698 */         premiumSubscriptionCount(), 
/* 1699 */         publicUpdatesChannelId(), 
/* 1700 */         maxVideoChannelUsers(), 
/* 1701 */         approximateMemberCount(), 
/* 1702 */         approximatePresenceCount(), 
/* 1703 */         welcomeScreen(), 
/* 1704 */         nsfw(), 
/* 1705 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutablePartialGuildData withWidgetChannelId(Possible<Optional<Id>> value) {
/* 1711 */     Possible<Optional<Id>> newValue = Objects.<Possible<Optional<Id>>>requireNonNull(value);
/* 1712 */     return new ImmutablePartialGuildData(this, 
/*      */         
/* 1714 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1719 */         owner(), 
/* 1720 */         permissions(), 
/* 1721 */         afkChannelId(), 
/* 1722 */         embedEnabled(), 
/* 1723 */         embedChannelId(), this.features, 
/*      */         
/* 1725 */         applicationId(), 
/* 1726 */         widgetEnabled(), newValue, 
/*      */         
/* 1728 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 1730 */         rulesChannelId(), 
/* 1731 */         maxPresences(), 
/* 1732 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1736 */         premiumSubscriptionCount(), 
/* 1737 */         publicUpdatesChannelId(), 
/* 1738 */         maxVideoChannelUsers(), 
/* 1739 */         approximateMemberCount(), 
/* 1740 */         approximatePresenceCount(), 
/* 1741 */         welcomeScreen(), 
/* 1742 */         nsfw(), 
/* 1743 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public ImmutablePartialGuildData withWidgetChannelId(@Nullable Long value) {
/* 1751 */     Possible<Optional<Id>> newValue = (value == null) ? Possible.of(Optional.empty()) : Possible.of(Optional.of(Id.of(value.longValue())));
/* 1752 */     return new ImmutablePartialGuildData(this, 
/*      */         
/* 1754 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1759 */         owner(), 
/* 1760 */         permissions(), 
/* 1761 */         afkChannelId(), 
/* 1762 */         embedEnabled(), 
/* 1763 */         embedChannelId(), this.features, 
/*      */         
/* 1765 */         applicationId(), 
/* 1766 */         widgetEnabled(), newValue, 
/*      */         
/* 1768 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 1770 */         rulesChannelId(), 
/* 1771 */         maxPresences(), 
/* 1772 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1776 */         premiumSubscriptionCount(), 
/* 1777 */         publicUpdatesChannelId(), 
/* 1778 */         maxVideoChannelUsers(), 
/* 1779 */         approximateMemberCount(), 
/* 1780 */         approximatePresenceCount(), 
/* 1781 */         welcomeScreen(), 
/* 1782 */         nsfw(), 
/* 1783 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutablePartialGuildData withWidgetChannelIdOrNull(@Nullable Long value) {
/* 1790 */     Possible<Optional<Id>> newValue = (value == null) ? Possible.of(Optional.empty()) : Possible.of(Optional.of(Id.of(value.longValue())));
/* 1791 */     return new ImmutablePartialGuildData(this, 
/*      */         
/* 1793 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1798 */         owner(), 
/* 1799 */         permissions(), 
/* 1800 */         afkChannelId(), 
/* 1801 */         embedEnabled(), 
/* 1802 */         embedChannelId(), this.features, 
/*      */         
/* 1804 */         applicationId(), 
/* 1805 */         widgetEnabled(), newValue, 
/*      */         
/* 1807 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 1809 */         rulesChannelId(), 
/* 1810 */         maxPresences(), 
/* 1811 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1815 */         premiumSubscriptionCount(), 
/* 1816 */         publicUpdatesChannelId(), 
/* 1817 */         maxVideoChannelUsers(), 
/* 1818 */         approximateMemberCount(), 
/* 1819 */         approximatePresenceCount(), 
/* 1820 */         welcomeScreen(), 
/* 1821 */         nsfw(), 
/* 1822 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutablePartialGuildData withSystemChannelId(Optional<Id> value) {
/* 1828 */     Optional<Id> newValue = Objects.<Optional<Id>>requireNonNull(value);
/* 1829 */     return new ImmutablePartialGuildData(this, 
/*      */         
/* 1831 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1836 */         owner(), 
/* 1837 */         permissions(), 
/* 1838 */         afkChannelId(), 
/* 1839 */         embedEnabled(), 
/* 1840 */         embedChannelId(), this.features, 
/*      */         
/* 1842 */         applicationId(), 
/* 1843 */         widgetEnabled(), 
/* 1844 */         widgetChannelId(), newValue, this.systemChannelFlags, 
/*      */ 
/*      */         
/* 1847 */         rulesChannelId(), 
/* 1848 */         maxPresences(), 
/* 1849 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1853 */         premiumSubscriptionCount(), 
/* 1854 */         publicUpdatesChannelId(), 
/* 1855 */         maxVideoChannelUsers(), 
/* 1856 */         approximateMemberCount(), 
/* 1857 */         approximatePresenceCount(), 
/* 1858 */         welcomeScreen(), 
/* 1859 */         nsfw(), 
/* 1860 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutablePartialGuildData withSystemChannelId(long value) {
/* 1866 */     Optional<Id> newValue = Optional.of(Id.of(value));
/* 1867 */     return new ImmutablePartialGuildData(this, 
/*      */         
/* 1869 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1874 */         owner(), 
/* 1875 */         permissions(), 
/* 1876 */         afkChannelId(), 
/* 1877 */         embedEnabled(), 
/* 1878 */         embedChannelId(), this.features, 
/*      */         
/* 1880 */         applicationId(), 
/* 1881 */         widgetEnabled(), 
/* 1882 */         widgetChannelId(), newValue, this.systemChannelFlags, 
/*      */ 
/*      */         
/* 1885 */         rulesChannelId(), 
/* 1886 */         maxPresences(), 
/* 1887 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1891 */         premiumSubscriptionCount(), 
/* 1892 */         publicUpdatesChannelId(), 
/* 1893 */         maxVideoChannelUsers(), 
/* 1894 */         approximateMemberCount(), 
/* 1895 */         approximatePresenceCount(), 
/* 1896 */         welcomeScreen(), 
/* 1897 */         nsfw(), 
/* 1898 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutablePartialGuildData withSystemChannelFlags(int value) {
/* 1909 */     Integer newValue = Integer.valueOf(value);
/* 1910 */     if (Objects.equals(this.systemChannelFlags, newValue)) return this; 
/* 1911 */     return new ImmutablePartialGuildData(this, 
/*      */         
/* 1913 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1918 */         owner(), 
/* 1919 */         permissions(), 
/* 1920 */         afkChannelId(), 
/* 1921 */         embedEnabled(), 
/* 1922 */         embedChannelId(), this.features, 
/*      */         
/* 1924 */         applicationId(), 
/* 1925 */         widgetEnabled(), 
/* 1926 */         widgetChannelId(), 
/* 1927 */         systemChannelId(), newValue, 
/*      */         
/* 1929 */         rulesChannelId(), 
/* 1930 */         maxPresences(), 
/* 1931 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1935 */         premiumSubscriptionCount(), 
/* 1936 */         publicUpdatesChannelId(), 
/* 1937 */         maxVideoChannelUsers(), 
/* 1938 */         approximateMemberCount(), 
/* 1939 */         approximatePresenceCount(), 
/* 1940 */         welcomeScreen(), 
/* 1941 */         nsfw(), 
/* 1942 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutablePartialGuildData withSystemChannelFlags(OptionalInt optional) {
/* 1954 */     Integer value = optional.isPresent() ? Integer.valueOf(optional.getAsInt()) : null;
/* 1955 */     if (Objects.equals(this.systemChannelFlags, value)) return this; 
/* 1956 */     return new ImmutablePartialGuildData(this, 
/*      */         
/* 1958 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1963 */         owner(), 
/* 1964 */         permissions(), 
/* 1965 */         afkChannelId(), 
/* 1966 */         embedEnabled(), 
/* 1967 */         embedChannelId(), this.features, 
/*      */         
/* 1969 */         applicationId(), 
/* 1970 */         widgetEnabled(), 
/* 1971 */         widgetChannelId(), 
/* 1972 */         systemChannelId(), value, 
/*      */         
/* 1974 */         rulesChannelId(), 
/* 1975 */         maxPresences(), 
/* 1976 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 1980 */         premiumSubscriptionCount(), 
/* 1981 */         publicUpdatesChannelId(), 
/* 1982 */         maxVideoChannelUsers(), 
/* 1983 */         approximateMemberCount(), 
/* 1984 */         approximatePresenceCount(), 
/* 1985 */         welcomeScreen(), 
/* 1986 */         nsfw(), 
/* 1987 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutablePartialGuildData withRulesChannelId(Optional<Id> value) {
/* 1993 */     Optional<Id> newValue = Objects.<Optional<Id>>requireNonNull(value);
/* 1994 */     return new ImmutablePartialGuildData(this, 
/*      */         
/* 1996 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2001 */         owner(), 
/* 2002 */         permissions(), 
/* 2003 */         afkChannelId(), 
/* 2004 */         embedEnabled(), 
/* 2005 */         embedChannelId(), this.features, 
/*      */         
/* 2007 */         applicationId(), 
/* 2008 */         widgetEnabled(), 
/* 2009 */         widgetChannelId(), 
/* 2010 */         systemChannelId(), this.systemChannelFlags, newValue, 
/*      */ 
/*      */         
/* 2013 */         maxPresences(), 
/* 2014 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 2018 */         premiumSubscriptionCount(), 
/* 2019 */         publicUpdatesChannelId(), 
/* 2020 */         maxVideoChannelUsers(), 
/* 2021 */         approximateMemberCount(), 
/* 2022 */         approximatePresenceCount(), 
/* 2023 */         welcomeScreen(), 
/* 2024 */         nsfw(), 
/* 2025 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutablePartialGuildData withRulesChannelId(long value) {
/* 2031 */     Optional<Id> newValue = Optional.of(Id.of(value));
/* 2032 */     return new ImmutablePartialGuildData(this, 
/*      */         
/* 2034 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2039 */         owner(), 
/* 2040 */         permissions(), 
/* 2041 */         afkChannelId(), 
/* 2042 */         embedEnabled(), 
/* 2043 */         embedChannelId(), this.features, 
/*      */         
/* 2045 */         applicationId(), 
/* 2046 */         widgetEnabled(), 
/* 2047 */         widgetChannelId(), 
/* 2048 */         systemChannelId(), this.systemChannelFlags, newValue, 
/*      */ 
/*      */         
/* 2051 */         maxPresences(), 
/* 2052 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 2056 */         premiumSubscriptionCount(), 
/* 2057 */         publicUpdatesChannelId(), 
/* 2058 */         maxVideoChannelUsers(), 
/* 2059 */         approximateMemberCount(), 
/* 2060 */         approximatePresenceCount(), 
/* 2061 */         welcomeScreen(), 
/* 2062 */         nsfw(), 
/* 2063 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutablePartialGuildData withMaxPresences(Possible<Optional<Integer>> value) {
/* 2069 */     Possible<Optional<Integer>> newValue = Objects.<Possible<Optional<Integer>>>requireNonNull(value);
/* 2070 */     return new ImmutablePartialGuildData(this, 
/*      */         
/* 2072 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2077 */         owner(), 
/* 2078 */         permissions(), 
/* 2079 */         afkChannelId(), 
/* 2080 */         embedEnabled(), 
/* 2081 */         embedChannelId(), this.features, 
/*      */         
/* 2083 */         applicationId(), 
/* 2084 */         widgetEnabled(), 
/* 2085 */         widgetChannelId(), 
/* 2086 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 2088 */         rulesChannelId(), newValue, 
/*      */         
/* 2090 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 2094 */         premiumSubscriptionCount(), 
/* 2095 */         publicUpdatesChannelId(), 
/* 2096 */         maxVideoChannelUsers(), 
/* 2097 */         approximateMemberCount(), 
/* 2098 */         approximatePresenceCount(), 
/* 2099 */         welcomeScreen(), 
/* 2100 */         nsfw(), 
/* 2101 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public ImmutablePartialGuildData withMaxPresences(@Nullable Integer value) {
/* 2108 */     Possible<Optional<Integer>> newValue = Possible.of(Optional.ofNullable(value));
/* 2109 */     return new ImmutablePartialGuildData(this, 
/*      */         
/* 2111 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2116 */         owner(), 
/* 2117 */         permissions(), 
/* 2118 */         afkChannelId(), 
/* 2119 */         embedEnabled(), 
/* 2120 */         embedChannelId(), this.features, 
/*      */         
/* 2122 */         applicationId(), 
/* 2123 */         widgetEnabled(), 
/* 2124 */         widgetChannelId(), 
/* 2125 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 2127 */         rulesChannelId(), newValue, 
/*      */         
/* 2129 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 2133 */         premiumSubscriptionCount(), 
/* 2134 */         publicUpdatesChannelId(), 
/* 2135 */         maxVideoChannelUsers(), 
/* 2136 */         approximateMemberCount(), 
/* 2137 */         approximatePresenceCount(), 
/* 2138 */         welcomeScreen(), 
/* 2139 */         nsfw(), 
/* 2140 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutablePartialGuildData withMaxPresencesOrNull(@Nullable Integer value) {
/* 2146 */     Possible<Optional<Integer>> newValue = Possible.of(Optional.ofNullable(value));
/* 2147 */     return new ImmutablePartialGuildData(this, 
/*      */         
/* 2149 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2154 */         owner(), 
/* 2155 */         permissions(), 
/* 2156 */         afkChannelId(), 
/* 2157 */         embedEnabled(), 
/* 2158 */         embedChannelId(), this.features, 
/*      */         
/* 2160 */         applicationId(), 
/* 2161 */         widgetEnabled(), 
/* 2162 */         widgetChannelId(), 
/* 2163 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 2165 */         rulesChannelId(), newValue, 
/*      */         
/* 2167 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 2171 */         premiumSubscriptionCount(), 
/* 2172 */         publicUpdatesChannelId(), 
/* 2173 */         maxVideoChannelUsers(), 
/* 2174 */         approximateMemberCount(), 
/* 2175 */         approximatePresenceCount(), 
/* 2176 */         welcomeScreen(), 
/* 2177 */         nsfw(), 
/* 2178 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutablePartialGuildData withMaxMembers(Possible<Integer> value) {
/* 2184 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/* 2185 */     return new ImmutablePartialGuildData(this, 
/*      */         
/* 2187 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2192 */         owner(), 
/* 2193 */         permissions(), 
/* 2194 */         afkChannelId(), 
/* 2195 */         embedEnabled(), 
/* 2196 */         embedChannelId(), this.features, 
/*      */         
/* 2198 */         applicationId(), 
/* 2199 */         widgetEnabled(), 
/* 2200 */         widgetChannelId(), 
/* 2201 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 2203 */         rulesChannelId(), 
/* 2204 */         maxPresences(), newValue, this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2209 */         premiumSubscriptionCount(), 
/* 2210 */         publicUpdatesChannelId(), 
/* 2211 */         maxVideoChannelUsers(), 
/* 2212 */         approximateMemberCount(), 
/* 2213 */         approximatePresenceCount(), 
/* 2214 */         welcomeScreen(), 
/* 2215 */         nsfw(), 
/* 2216 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutablePartialGuildData withMaxMembers(Integer value) {
/* 2222 */     Possible<Integer> newValue = Possible.of(value);
/* 2223 */     return new ImmutablePartialGuildData(this, 
/*      */         
/* 2225 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2230 */         owner(), 
/* 2231 */         permissions(), 
/* 2232 */         afkChannelId(), 
/* 2233 */         embedEnabled(), 
/* 2234 */         embedChannelId(), this.features, 
/*      */         
/* 2236 */         applicationId(), 
/* 2237 */         widgetEnabled(), 
/* 2238 */         widgetChannelId(), 
/* 2239 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 2241 */         rulesChannelId(), 
/* 2242 */         maxPresences(), newValue, this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2247 */         premiumSubscriptionCount(), 
/* 2248 */         publicUpdatesChannelId(), 
/* 2249 */         maxVideoChannelUsers(), 
/* 2250 */         approximateMemberCount(), 
/* 2251 */         approximatePresenceCount(), 
/* 2252 */         welcomeScreen(), 
/* 2253 */         nsfw(), 
/* 2254 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutablePartialGuildData withVanityUrlCode(String value) {
/* 2265 */     String newValue = Objects.<String>requireNonNull(value, "vanityUrlCode");
/* 2266 */     if (Objects.equals(this.vanityUrlCode, newValue)) return this; 
/* 2267 */     return new ImmutablePartialGuildData(this, 
/*      */         
/* 2269 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2274 */         owner(), 
/* 2275 */         permissions(), 
/* 2276 */         afkChannelId(), 
/* 2277 */         embedEnabled(), 
/* 2278 */         embedChannelId(), this.features, 
/*      */         
/* 2280 */         applicationId(), 
/* 2281 */         widgetEnabled(), 
/* 2282 */         widgetChannelId(), 
/* 2283 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 2285 */         rulesChannelId(), 
/* 2286 */         maxPresences(), 
/* 2287 */         maxMembers(), newValue, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 2291 */         premiumSubscriptionCount(), 
/* 2292 */         publicUpdatesChannelId(), 
/* 2293 */         maxVideoChannelUsers(), 
/* 2294 */         approximateMemberCount(), 
/* 2295 */         approximatePresenceCount(), 
/* 2296 */         welcomeScreen(), 
/* 2297 */         nsfw(), 
/* 2298 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutablePartialGuildData withVanityUrlCode(Optional<String> optional) {
/* 2310 */     String value = optional.orElse(null);
/* 2311 */     if (Objects.equals(this.vanityUrlCode, value)) return this; 
/* 2312 */     return new ImmutablePartialGuildData(this, 
/*      */         
/* 2314 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2319 */         owner(), 
/* 2320 */         permissions(), 
/* 2321 */         afkChannelId(), 
/* 2322 */         embedEnabled(), 
/* 2323 */         embedChannelId(), this.features, 
/*      */         
/* 2325 */         applicationId(), 
/* 2326 */         widgetEnabled(), 
/* 2327 */         widgetChannelId(), 
/* 2328 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 2330 */         rulesChannelId(), 
/* 2331 */         maxPresences(), 
/* 2332 */         maxMembers(), value, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 2336 */         premiumSubscriptionCount(), 
/* 2337 */         publicUpdatesChannelId(), 
/* 2338 */         maxVideoChannelUsers(), 
/* 2339 */         approximateMemberCount(), 
/* 2340 */         approximatePresenceCount(), 
/* 2341 */         welcomeScreen(), 
/* 2342 */         nsfw(), 
/* 2343 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutablePartialGuildData withDescription(String value) {
/* 2354 */     String newValue = Objects.<String>requireNonNull(value, "description");
/* 2355 */     if (Objects.equals(this.description, newValue)) return this; 
/* 2356 */     return new ImmutablePartialGuildData(this, 
/*      */         
/* 2358 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2363 */         owner(), 
/* 2364 */         permissions(), 
/* 2365 */         afkChannelId(), 
/* 2366 */         embedEnabled(), 
/* 2367 */         embedChannelId(), this.features, 
/*      */         
/* 2369 */         applicationId(), 
/* 2370 */         widgetEnabled(), 
/* 2371 */         widgetChannelId(), 
/* 2372 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 2374 */         rulesChannelId(), 
/* 2375 */         maxPresences(), 
/* 2376 */         maxMembers(), this.vanityUrlCode, newValue, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 2380 */         premiumSubscriptionCount(), 
/* 2381 */         publicUpdatesChannelId(), 
/* 2382 */         maxVideoChannelUsers(), 
/* 2383 */         approximateMemberCount(), 
/* 2384 */         approximatePresenceCount(), 
/* 2385 */         welcomeScreen(), 
/* 2386 */         nsfw(), 
/* 2387 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutablePartialGuildData withDescription(Optional<String> optional) {
/* 2399 */     String value = optional.orElse(null);
/* 2400 */     if (Objects.equals(this.description, value)) return this; 
/* 2401 */     return new ImmutablePartialGuildData(this, 
/*      */         
/* 2403 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2408 */         owner(), 
/* 2409 */         permissions(), 
/* 2410 */         afkChannelId(), 
/* 2411 */         embedEnabled(), 
/* 2412 */         embedChannelId(), this.features, 
/*      */         
/* 2414 */         applicationId(), 
/* 2415 */         widgetEnabled(), 
/* 2416 */         widgetChannelId(), 
/* 2417 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 2419 */         rulesChannelId(), 
/* 2420 */         maxPresences(), 
/* 2421 */         maxMembers(), this.vanityUrlCode, value, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 2425 */         premiumSubscriptionCount(), 
/* 2426 */         publicUpdatesChannelId(), 
/* 2427 */         maxVideoChannelUsers(), 
/* 2428 */         approximateMemberCount(), 
/* 2429 */         approximatePresenceCount(), 
/* 2430 */         welcomeScreen(), 
/* 2431 */         nsfw(), 
/* 2432 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutablePartialGuildData withBanner(String value) {
/* 2443 */     String newValue = Objects.<String>requireNonNull(value, "banner");
/* 2444 */     if (Objects.equals(this.banner, newValue)) return this; 
/* 2445 */     return new ImmutablePartialGuildData(this, 
/*      */         
/* 2447 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2452 */         owner(), 
/* 2453 */         permissions(), 
/* 2454 */         afkChannelId(), 
/* 2455 */         embedEnabled(), 
/* 2456 */         embedChannelId(), this.features, 
/*      */         
/* 2458 */         applicationId(), 
/* 2459 */         widgetEnabled(), 
/* 2460 */         widgetChannelId(), 
/* 2461 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 2463 */         rulesChannelId(), 
/* 2464 */         maxPresences(), 
/* 2465 */         maxMembers(), this.vanityUrlCode, this.description, newValue, 
/*      */ 
/*      */ 
/*      */         
/* 2469 */         premiumSubscriptionCount(), 
/* 2470 */         publicUpdatesChannelId(), 
/* 2471 */         maxVideoChannelUsers(), 
/* 2472 */         approximateMemberCount(), 
/* 2473 */         approximatePresenceCount(), 
/* 2474 */         welcomeScreen(), 
/* 2475 */         nsfw(), 
/* 2476 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutablePartialGuildData withBanner(Optional<String> optional) {
/* 2488 */     String value = optional.orElse(null);
/* 2489 */     if (Objects.equals(this.banner, value)) return this; 
/* 2490 */     return new ImmutablePartialGuildData(this, 
/*      */         
/* 2492 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2497 */         owner(), 
/* 2498 */         permissions(), 
/* 2499 */         afkChannelId(), 
/* 2500 */         embedEnabled(), 
/* 2501 */         embedChannelId(), this.features, 
/*      */         
/* 2503 */         applicationId(), 
/* 2504 */         widgetEnabled(), 
/* 2505 */         widgetChannelId(), 
/* 2506 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 2508 */         rulesChannelId(), 
/* 2509 */         maxPresences(), 
/* 2510 */         maxMembers(), this.vanityUrlCode, this.description, value, 
/*      */ 
/*      */ 
/*      */         
/* 2514 */         premiumSubscriptionCount(), 
/* 2515 */         publicUpdatesChannelId(), 
/* 2516 */         maxVideoChannelUsers(), 
/* 2517 */         approximateMemberCount(), 
/* 2518 */         approximatePresenceCount(), 
/* 2519 */         welcomeScreen(), 
/* 2520 */         nsfw(), 
/* 2521 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutablePartialGuildData withPremiumSubscriptionCount(Possible<Integer> value) {
/* 2527 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/* 2528 */     return new ImmutablePartialGuildData(this, 
/*      */         
/* 2530 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2535 */         owner(), 
/* 2536 */         permissions(), 
/* 2537 */         afkChannelId(), 
/* 2538 */         embedEnabled(), 
/* 2539 */         embedChannelId(), this.features, 
/*      */         
/* 2541 */         applicationId(), 
/* 2542 */         widgetEnabled(), 
/* 2543 */         widgetChannelId(), 
/* 2544 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 2546 */         rulesChannelId(), 
/* 2547 */         maxPresences(), 
/* 2548 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, newValue, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2553 */         publicUpdatesChannelId(), 
/* 2554 */         maxVideoChannelUsers(), 
/* 2555 */         approximateMemberCount(), 
/* 2556 */         approximatePresenceCount(), 
/* 2557 */         welcomeScreen(), 
/* 2558 */         nsfw(), 
/* 2559 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutablePartialGuildData withPremiumSubscriptionCount(Integer value) {
/* 2565 */     Possible<Integer> newValue = Possible.of(value);
/* 2566 */     return new ImmutablePartialGuildData(this, 
/*      */         
/* 2568 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2573 */         owner(), 
/* 2574 */         permissions(), 
/* 2575 */         afkChannelId(), 
/* 2576 */         embedEnabled(), 
/* 2577 */         embedChannelId(), this.features, 
/*      */         
/* 2579 */         applicationId(), 
/* 2580 */         widgetEnabled(), 
/* 2581 */         widgetChannelId(), 
/* 2582 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 2584 */         rulesChannelId(), 
/* 2585 */         maxPresences(), 
/* 2586 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, newValue, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2591 */         publicUpdatesChannelId(), 
/* 2592 */         maxVideoChannelUsers(), 
/* 2593 */         approximateMemberCount(), 
/* 2594 */         approximatePresenceCount(), 
/* 2595 */         welcomeScreen(), 
/* 2596 */         nsfw(), 
/* 2597 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutablePartialGuildData withPublicUpdatesChannelId(Optional<Id> value) {
/* 2603 */     Optional<Id> newValue = Objects.<Optional<Id>>requireNonNull(value);
/* 2604 */     return new ImmutablePartialGuildData(this, 
/*      */         
/* 2606 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2611 */         owner(), 
/* 2612 */         permissions(), 
/* 2613 */         afkChannelId(), 
/* 2614 */         embedEnabled(), 
/* 2615 */         embedChannelId(), this.features, 
/*      */         
/* 2617 */         applicationId(), 
/* 2618 */         widgetEnabled(), 
/* 2619 */         widgetChannelId(), 
/* 2620 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 2622 */         rulesChannelId(), 
/* 2623 */         maxPresences(), 
/* 2624 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 2628 */         premiumSubscriptionCount(), newValue, 
/*      */         
/* 2630 */         maxVideoChannelUsers(), 
/* 2631 */         approximateMemberCount(), 
/* 2632 */         approximatePresenceCount(), 
/* 2633 */         welcomeScreen(), 
/* 2634 */         nsfw(), 
/* 2635 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutablePartialGuildData withPublicUpdatesChannelId(long value) {
/* 2641 */     Optional<Id> newValue = Optional.of(Id.of(value));
/* 2642 */     return new ImmutablePartialGuildData(this, 
/*      */         
/* 2644 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2649 */         owner(), 
/* 2650 */         permissions(), 
/* 2651 */         afkChannelId(), 
/* 2652 */         embedEnabled(), 
/* 2653 */         embedChannelId(), this.features, 
/*      */         
/* 2655 */         applicationId(), 
/* 2656 */         widgetEnabled(), 
/* 2657 */         widgetChannelId(), 
/* 2658 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 2660 */         rulesChannelId(), 
/* 2661 */         maxPresences(), 
/* 2662 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 2666 */         premiumSubscriptionCount(), newValue, 
/*      */         
/* 2668 */         maxVideoChannelUsers(), 
/* 2669 */         approximateMemberCount(), 
/* 2670 */         approximatePresenceCount(), 
/* 2671 */         welcomeScreen(), 
/* 2672 */         nsfw(), 
/* 2673 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutablePartialGuildData withMaxVideoChannelUsers(Possible<Integer> value) {
/* 2679 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/* 2680 */     return new ImmutablePartialGuildData(this, 
/*      */         
/* 2682 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2687 */         owner(), 
/* 2688 */         permissions(), 
/* 2689 */         afkChannelId(), 
/* 2690 */         embedEnabled(), 
/* 2691 */         embedChannelId(), this.features, 
/*      */         
/* 2693 */         applicationId(), 
/* 2694 */         widgetEnabled(), 
/* 2695 */         widgetChannelId(), 
/* 2696 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 2698 */         rulesChannelId(), 
/* 2699 */         maxPresences(), 
/* 2700 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 2704 */         premiumSubscriptionCount(), 
/* 2705 */         publicUpdatesChannelId(), newValue, 
/*      */         
/* 2707 */         approximateMemberCount(), 
/* 2708 */         approximatePresenceCount(), 
/* 2709 */         welcomeScreen(), 
/* 2710 */         nsfw(), 
/* 2711 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutablePartialGuildData withMaxVideoChannelUsers(Integer value) {
/* 2717 */     Possible<Integer> newValue = Possible.of(value);
/* 2718 */     return new ImmutablePartialGuildData(this, 
/*      */         
/* 2720 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2725 */         owner(), 
/* 2726 */         permissions(), 
/* 2727 */         afkChannelId(), 
/* 2728 */         embedEnabled(), 
/* 2729 */         embedChannelId(), this.features, 
/*      */         
/* 2731 */         applicationId(), 
/* 2732 */         widgetEnabled(), 
/* 2733 */         widgetChannelId(), 
/* 2734 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 2736 */         rulesChannelId(), 
/* 2737 */         maxPresences(), 
/* 2738 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 2742 */         premiumSubscriptionCount(), 
/* 2743 */         publicUpdatesChannelId(), newValue, 
/*      */         
/* 2745 */         approximateMemberCount(), 
/* 2746 */         approximatePresenceCount(), 
/* 2747 */         welcomeScreen(), 
/* 2748 */         nsfw(), 
/* 2749 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutablePartialGuildData withApproximateMemberCount(Possible<Integer> value) {
/* 2755 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/* 2756 */     return new ImmutablePartialGuildData(this, 
/*      */         
/* 2758 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2763 */         owner(), 
/* 2764 */         permissions(), 
/* 2765 */         afkChannelId(), 
/* 2766 */         embedEnabled(), 
/* 2767 */         embedChannelId(), this.features, 
/*      */         
/* 2769 */         applicationId(), 
/* 2770 */         widgetEnabled(), 
/* 2771 */         widgetChannelId(), 
/* 2772 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 2774 */         rulesChannelId(), 
/* 2775 */         maxPresences(), 
/* 2776 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 2780 */         premiumSubscriptionCount(), 
/* 2781 */         publicUpdatesChannelId(), 
/* 2782 */         maxVideoChannelUsers(), newValue, 
/*      */         
/* 2784 */         approximatePresenceCount(), 
/* 2785 */         welcomeScreen(), 
/* 2786 */         nsfw(), 
/* 2787 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutablePartialGuildData withApproximateMemberCount(Integer value) {
/* 2793 */     Possible<Integer> newValue = Possible.of(value);
/* 2794 */     return new ImmutablePartialGuildData(this, 
/*      */         
/* 2796 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2801 */         owner(), 
/* 2802 */         permissions(), 
/* 2803 */         afkChannelId(), 
/* 2804 */         embedEnabled(), 
/* 2805 */         embedChannelId(), this.features, 
/*      */         
/* 2807 */         applicationId(), 
/* 2808 */         widgetEnabled(), 
/* 2809 */         widgetChannelId(), 
/* 2810 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 2812 */         rulesChannelId(), 
/* 2813 */         maxPresences(), 
/* 2814 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 2818 */         premiumSubscriptionCount(), 
/* 2819 */         publicUpdatesChannelId(), 
/* 2820 */         maxVideoChannelUsers(), newValue, 
/*      */         
/* 2822 */         approximatePresenceCount(), 
/* 2823 */         welcomeScreen(), 
/* 2824 */         nsfw(), 
/* 2825 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutablePartialGuildData withApproximatePresenceCount(Possible<Integer> value) {
/* 2831 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/* 2832 */     return new ImmutablePartialGuildData(this, 
/*      */         
/* 2834 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2839 */         owner(), 
/* 2840 */         permissions(), 
/* 2841 */         afkChannelId(), 
/* 2842 */         embedEnabled(), 
/* 2843 */         embedChannelId(), this.features, 
/*      */         
/* 2845 */         applicationId(), 
/* 2846 */         widgetEnabled(), 
/* 2847 */         widgetChannelId(), 
/* 2848 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 2850 */         rulesChannelId(), 
/* 2851 */         maxPresences(), 
/* 2852 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 2856 */         premiumSubscriptionCount(), 
/* 2857 */         publicUpdatesChannelId(), 
/* 2858 */         maxVideoChannelUsers(), 
/* 2859 */         approximateMemberCount(), newValue, 
/*      */         
/* 2861 */         welcomeScreen(), 
/* 2862 */         nsfw(), 
/* 2863 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutablePartialGuildData withApproximatePresenceCount(Integer value) {
/* 2869 */     Possible<Integer> newValue = Possible.of(value);
/* 2870 */     return new ImmutablePartialGuildData(this, 
/*      */         
/* 2872 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2877 */         owner(), 
/* 2878 */         permissions(), 
/* 2879 */         afkChannelId(), 
/* 2880 */         embedEnabled(), 
/* 2881 */         embedChannelId(), this.features, 
/*      */         
/* 2883 */         applicationId(), 
/* 2884 */         widgetEnabled(), 
/* 2885 */         widgetChannelId(), 
/* 2886 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 2888 */         rulesChannelId(), 
/* 2889 */         maxPresences(), 
/* 2890 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 2894 */         premiumSubscriptionCount(), 
/* 2895 */         publicUpdatesChannelId(), 
/* 2896 */         maxVideoChannelUsers(), 
/* 2897 */         approximateMemberCount(), newValue, 
/*      */         
/* 2899 */         welcomeScreen(), 
/* 2900 */         nsfw(), 
/* 2901 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutablePartialGuildData withWelcomeScreen(Possible<WelcomeScreenData> value) {
/* 2907 */     Possible<WelcomeScreenData> newValue = Objects.<Possible<WelcomeScreenData>>requireNonNull(value);
/* 2908 */     return new ImmutablePartialGuildData(this, 
/*      */         
/* 2910 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2915 */         owner(), 
/* 2916 */         permissions(), 
/* 2917 */         afkChannelId(), 
/* 2918 */         embedEnabled(), 
/* 2919 */         embedChannelId(), this.features, 
/*      */         
/* 2921 */         applicationId(), 
/* 2922 */         widgetEnabled(), 
/* 2923 */         widgetChannelId(), 
/* 2924 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 2926 */         rulesChannelId(), 
/* 2927 */         maxPresences(), 
/* 2928 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 2932 */         premiumSubscriptionCount(), 
/* 2933 */         publicUpdatesChannelId(), 
/* 2934 */         maxVideoChannelUsers(), 
/* 2935 */         approximateMemberCount(), 
/* 2936 */         approximatePresenceCount(), newValue, 
/*      */         
/* 2938 */         nsfw(), 
/* 2939 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutablePartialGuildData withWelcomeScreen(WelcomeScreenData value) {
/* 2945 */     Possible<WelcomeScreenData> newValue = Possible.of(value);
/* 2946 */     return new ImmutablePartialGuildData(this, 
/*      */         
/* 2948 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2953 */         owner(), 
/* 2954 */         permissions(), 
/* 2955 */         afkChannelId(), 
/* 2956 */         embedEnabled(), 
/* 2957 */         embedChannelId(), this.features, 
/*      */         
/* 2959 */         applicationId(), 
/* 2960 */         widgetEnabled(), 
/* 2961 */         widgetChannelId(), 
/* 2962 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 2964 */         rulesChannelId(), 
/* 2965 */         maxPresences(), 
/* 2966 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 2970 */         premiumSubscriptionCount(), 
/* 2971 */         publicUpdatesChannelId(), 
/* 2972 */         maxVideoChannelUsers(), 
/* 2973 */         approximateMemberCount(), 
/* 2974 */         approximatePresenceCount(), newValue, 
/*      */         
/* 2976 */         nsfw(), 
/* 2977 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutablePartialGuildData withNsfw(Possible<Boolean> value) {
/* 2983 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/* 2984 */     return new ImmutablePartialGuildData(this, 
/*      */         
/* 2986 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2991 */         owner(), 
/* 2992 */         permissions(), 
/* 2993 */         afkChannelId(), 
/* 2994 */         embedEnabled(), 
/* 2995 */         embedChannelId(), this.features, 
/*      */         
/* 2997 */         applicationId(), 
/* 2998 */         widgetEnabled(), 
/* 2999 */         widgetChannelId(), 
/* 3000 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 3002 */         rulesChannelId(), 
/* 3003 */         maxPresences(), 
/* 3004 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 3008 */         premiumSubscriptionCount(), 
/* 3009 */         publicUpdatesChannelId(), 
/* 3010 */         maxVideoChannelUsers(), 
/* 3011 */         approximateMemberCount(), 
/* 3012 */         approximatePresenceCount(), 
/* 3013 */         welcomeScreen(), newValue, 
/*      */         
/* 3015 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutablePartialGuildData withNsfw(Boolean value) {
/* 3021 */     Possible<Boolean> newValue = Possible.of(value);
/* 3022 */     return new ImmutablePartialGuildData(this, 
/*      */         
/* 3024 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3029 */         owner(), 
/* 3030 */         permissions(), 
/* 3031 */         afkChannelId(), 
/* 3032 */         embedEnabled(), 
/* 3033 */         embedChannelId(), this.features, 
/*      */         
/* 3035 */         applicationId(), 
/* 3036 */         widgetEnabled(), 
/* 3037 */         widgetChannelId(), 
/* 3038 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 3040 */         rulesChannelId(), 
/* 3041 */         maxPresences(), 
/* 3042 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 3046 */         premiumSubscriptionCount(), 
/* 3047 */         publicUpdatesChannelId(), 
/* 3048 */         maxVideoChannelUsers(), 
/* 3049 */         approximateMemberCount(), 
/* 3050 */         approximatePresenceCount(), 
/* 3051 */         welcomeScreen(), newValue, 
/*      */         
/* 3053 */         safetyAlertsChannelId(), this.verificationLevel, this.nsfwLevel);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutablePartialGuildData withSafetyAlertsChannelId(Optional<Id> value) {
/* 3059 */     Optional<Id> newValue = Objects.<Optional<Id>>requireNonNull(value);
/* 3060 */     return new ImmutablePartialGuildData(this, 
/*      */         
/* 3062 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3067 */         owner(), 
/* 3068 */         permissions(), 
/* 3069 */         afkChannelId(), 
/* 3070 */         embedEnabled(), 
/* 3071 */         embedChannelId(), this.features, 
/*      */         
/* 3073 */         applicationId(), 
/* 3074 */         widgetEnabled(), 
/* 3075 */         widgetChannelId(), 
/* 3076 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 3078 */         rulesChannelId(), 
/* 3079 */         maxPresences(), 
/* 3080 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 3084 */         premiumSubscriptionCount(), 
/* 3085 */         publicUpdatesChannelId(), 
/* 3086 */         maxVideoChannelUsers(), 
/* 3087 */         approximateMemberCount(), 
/* 3088 */         approximatePresenceCount(), 
/* 3089 */         welcomeScreen(), 
/* 3090 */         nsfw(), newValue, this.verificationLevel, this.nsfwLevel);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutablePartialGuildData withSafetyAlertsChannelId(long value) {
/* 3097 */     Optional<Id> newValue = Optional.of(Id.of(value));
/* 3098 */     return new ImmutablePartialGuildData(this, 
/*      */         
/* 3100 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3105 */         owner(), 
/* 3106 */         permissions(), 
/* 3107 */         afkChannelId(), 
/* 3108 */         embedEnabled(), 
/* 3109 */         embedChannelId(), this.features, 
/*      */         
/* 3111 */         applicationId(), 
/* 3112 */         widgetEnabled(), 
/* 3113 */         widgetChannelId(), 
/* 3114 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 3116 */         rulesChannelId(), 
/* 3117 */         maxPresences(), 
/* 3118 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 3122 */         premiumSubscriptionCount(), 
/* 3123 */         publicUpdatesChannelId(), 
/* 3124 */         maxVideoChannelUsers(), 
/* 3125 */         approximateMemberCount(), 
/* 3126 */         approximatePresenceCount(), 
/* 3127 */         welcomeScreen(), 
/* 3128 */         nsfw(), newValue, this.verificationLevel, this.nsfwLevel);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutablePartialGuildData withVerificationLevel(int value) {
/* 3141 */     if (this.verificationLevel == value) return this; 
/* 3142 */     return new ImmutablePartialGuildData(this, 
/*      */         
/* 3144 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3149 */         owner(), 
/* 3150 */         permissions(), 
/* 3151 */         afkChannelId(), 
/* 3152 */         embedEnabled(), 
/* 3153 */         embedChannelId(), this.features, 
/*      */         
/* 3155 */         applicationId(), 
/* 3156 */         widgetEnabled(), 
/* 3157 */         widgetChannelId(), 
/* 3158 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 3160 */         rulesChannelId(), 
/* 3161 */         maxPresences(), 
/* 3162 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 3166 */         premiumSubscriptionCount(), 
/* 3167 */         publicUpdatesChannelId(), 
/* 3168 */         maxVideoChannelUsers(), 
/* 3169 */         approximateMemberCount(), 
/* 3170 */         approximatePresenceCount(), 
/* 3171 */         welcomeScreen(), 
/* 3172 */         nsfw(), 
/* 3173 */         safetyAlertsChannelId(), value, this.nsfwLevel);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutablePartialGuildData withNsfwLevel(int value) {
/* 3185 */     if (this.nsfwLevel == value) return this; 
/* 3186 */     return new ImmutablePartialGuildData(this, 
/*      */         
/* 3188 */         id(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3193 */         owner(), 
/* 3194 */         permissions(), 
/* 3195 */         afkChannelId(), 
/* 3196 */         embedEnabled(), 
/* 3197 */         embedChannelId(), this.features, 
/*      */         
/* 3199 */         applicationId(), 
/* 3200 */         widgetEnabled(), 
/* 3201 */         widgetChannelId(), 
/* 3202 */         systemChannelId(), this.systemChannelFlags, 
/*      */         
/* 3204 */         rulesChannelId(), 
/* 3205 */         maxPresences(), 
/* 3206 */         maxMembers(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */         
/* 3210 */         premiumSubscriptionCount(), 
/* 3211 */         publicUpdatesChannelId(), 
/* 3212 */         maxVideoChannelUsers(), 
/* 3213 */         approximateMemberCount(), 
/* 3214 */         approximatePresenceCount(), 
/* 3215 */         welcomeScreen(), 
/* 3216 */         nsfw(), 
/* 3217 */         safetyAlertsChannelId(), this.verificationLevel, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean equals(Object another) {
/* 3228 */     if (this == another) return true; 
/* 3229 */     return (another instanceof ImmutablePartialGuildData && 
/* 3230 */       equalTo(0, (ImmutablePartialGuildData)another));
/*      */   }
/*      */   
/*      */   private boolean equalTo(int synthetic, ImmutablePartialGuildData another) {
/* 3234 */     return (Objects.equals(Long.valueOf(this.id_value), Long.valueOf(another.id_value)) && this.name
/* 3235 */       .equals(another.name) && 
/* 3236 */       Objects.equals(this.icon, another.icon) && 
/* 3237 */       Objects.equals(this.splash, another.splash) && 
/* 3238 */       Objects.equals(this.discoverySplash, another.discoverySplash) && 
/* 3239 */       owner().equals(another.owner()) && 
/* 3240 */       permissions().equals(another.permissions()) && 
/* 3241 */       afkChannelId().equals(another.afkChannelId()) && 
/* 3242 */       embedEnabled().equals(another.embedEnabled()) && 
/* 3243 */       embedChannelId().equals(another.embedChannelId()) && this.features
/* 3244 */       .equals(another.features) && 
/* 3245 */       applicationId().equals(another.applicationId()) && 
/* 3246 */       widgetEnabled().equals(another.widgetEnabled()) && 
/* 3247 */       widgetChannelId().equals(another.widgetChannelId()) && 
/* 3248 */       systemChannelId().equals(another.systemChannelId()) && 
/* 3249 */       Objects.equals(this.systemChannelFlags, another.systemChannelFlags) && 
/* 3250 */       rulesChannelId().equals(another.rulesChannelId()) && 
/* 3251 */       maxPresences().equals(another.maxPresences()) && 
/* 3252 */       maxMembers().equals(another.maxMembers()) && 
/* 3253 */       Objects.equals(this.vanityUrlCode, another.vanityUrlCode) && 
/* 3254 */       Objects.equals(this.description, another.description) && 
/* 3255 */       Objects.equals(this.banner, another.banner) && 
/* 3256 */       premiumSubscriptionCount().equals(another.premiumSubscriptionCount()) && 
/* 3257 */       publicUpdatesChannelId().equals(another.publicUpdatesChannelId()) && 
/* 3258 */       maxVideoChannelUsers().equals(another.maxVideoChannelUsers()) && 
/* 3259 */       approximateMemberCount().equals(another.approximateMemberCount()) && 
/* 3260 */       approximatePresenceCount().equals(another.approximatePresenceCount()) && 
/* 3261 */       welcomeScreen().equals(another.welcomeScreen()) && 
/* 3262 */       nsfw().equals(another.nsfw()) && 
/* 3263 */       safetyAlertsChannelId().equals(another.safetyAlertsChannelId()) && this.verificationLevel == another.verificationLevel && this.nsfwLevel == another.nsfwLevel);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int hashCode() {
/* 3274 */     int h = 5381;
/* 3275 */     h += (h << 5) + Objects.hashCode(Long.valueOf(this.id_value));
/* 3276 */     h += (h << 5) + this.name.hashCode();
/* 3277 */     h += (h << 5) + Objects.hashCode(this.icon);
/* 3278 */     h += (h << 5) + Objects.hashCode(this.splash);
/* 3279 */     h += (h << 5) + Objects.hashCode(this.discoverySplash);
/* 3280 */     h += (h << 5) + owner().hashCode();
/* 3281 */     h += (h << 5) + permissions().hashCode();
/* 3282 */     h += (h << 5) + afkChannelId().hashCode();
/* 3283 */     h += (h << 5) + embedEnabled().hashCode();
/* 3284 */     h += (h << 5) + embedChannelId().hashCode();
/* 3285 */     h += (h << 5) + this.features.hashCode();
/* 3286 */     h += (h << 5) + applicationId().hashCode();
/* 3287 */     h += (h << 5) + widgetEnabled().hashCode();
/* 3288 */     h += (h << 5) + widgetChannelId().hashCode();
/* 3289 */     h += (h << 5) + systemChannelId().hashCode();
/* 3290 */     h += (h << 5) + Objects.hashCode(this.systemChannelFlags);
/* 3291 */     h += (h << 5) + rulesChannelId().hashCode();
/* 3292 */     h += (h << 5) + maxPresences().hashCode();
/* 3293 */     h += (h << 5) + maxMembers().hashCode();
/* 3294 */     h += (h << 5) + Objects.hashCode(this.vanityUrlCode);
/* 3295 */     h += (h << 5) + Objects.hashCode(this.description);
/* 3296 */     h += (h << 5) + Objects.hashCode(this.banner);
/* 3297 */     h += (h << 5) + premiumSubscriptionCount().hashCode();
/* 3298 */     h += (h << 5) + publicUpdatesChannelId().hashCode();
/* 3299 */     h += (h << 5) + maxVideoChannelUsers().hashCode();
/* 3300 */     h += (h << 5) + approximateMemberCount().hashCode();
/* 3301 */     h += (h << 5) + approximatePresenceCount().hashCode();
/* 3302 */     h += (h << 5) + welcomeScreen().hashCode();
/* 3303 */     h += (h << 5) + nsfw().hashCode();
/* 3304 */     h += (h << 5) + safetyAlertsChannelId().hashCode();
/* 3305 */     h += (h << 5) + this.verificationLevel;
/* 3306 */     h += (h << 5) + this.nsfwLevel;
/* 3307 */     return h;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/* 3316 */     StringBuilder builder = new StringBuilder("PartialGuildData{");
/* 3317 */     builder.append("id=").append(Objects.toString(Long.valueOf(this.id_value)));
/* 3318 */     builder.append(", ");
/* 3319 */     builder.append("name=").append(this.name);
/* 3320 */     if (this.icon != null) {
/* 3321 */       builder.append(", ");
/* 3322 */       builder.append("icon=").append(this.icon);
/*      */     } 
/* 3324 */     if (this.splash != null) {
/* 3325 */       builder.append(", ");
/* 3326 */       builder.append("splash=").append(this.splash);
/*      */     } 
/* 3328 */     if (this.discoverySplash != null) {
/* 3329 */       builder.append(", ");
/* 3330 */       builder.append("discoverySplash=").append(this.discoverySplash);
/*      */     } 
/* 3332 */     builder.append(", ");
/* 3333 */     builder.append("owner=").append(owner().toString());
/* 3334 */     builder.append(", ");
/* 3335 */     builder.append("permissions=").append(permissions().toString());
/* 3336 */     builder.append(", ");
/* 3337 */     builder.append("afkChannelId=").append(afkChannelId().toString());
/* 3338 */     builder.append(", ");
/* 3339 */     builder.append("embedEnabled=").append(embedEnabled().toString());
/* 3340 */     builder.append(", ");
/* 3341 */     builder.append("embedChannelId=").append(embedChannelId().toString());
/* 3342 */     builder.append(", ");
/* 3343 */     builder.append("features=").append(this.features);
/* 3344 */     builder.append(", ");
/* 3345 */     builder.append("applicationId=").append(applicationId().toString());
/* 3346 */     builder.append(", ");
/* 3347 */     builder.append("widgetEnabled=").append(widgetEnabled().toString());
/* 3348 */     builder.append(", ");
/* 3349 */     builder.append("widgetChannelId=").append(widgetChannelId().toString());
/* 3350 */     builder.append(", ");
/* 3351 */     builder.append("systemChannelId=").append(systemChannelId().toString());
/* 3352 */     if (this.systemChannelFlags != null) {
/* 3353 */       builder.append(", ");
/* 3354 */       builder.append("systemChannelFlags=").append(this.systemChannelFlags);
/*      */     } 
/* 3356 */     builder.append(", ");
/* 3357 */     builder.append("rulesChannelId=").append(rulesChannelId().toString());
/* 3358 */     builder.append(", ");
/* 3359 */     builder.append("maxPresences=").append(maxPresences().toString());
/* 3360 */     builder.append(", ");
/* 3361 */     builder.append("maxMembers=").append(maxMembers().toString());
/* 3362 */     if (this.vanityUrlCode != null) {
/* 3363 */       builder.append(", ");
/* 3364 */       builder.append("vanityUrlCode=").append(this.vanityUrlCode);
/*      */     } 
/* 3366 */     if (this.description != null) {
/* 3367 */       builder.append(", ");
/* 3368 */       builder.append("description=").append(this.description);
/*      */     } 
/* 3370 */     if (this.banner != null) {
/* 3371 */       builder.append(", ");
/* 3372 */       builder.append("banner=").append(this.banner);
/*      */     } 
/* 3374 */     builder.append(", ");
/* 3375 */     builder.append("premiumSubscriptionCount=").append(premiumSubscriptionCount().toString());
/* 3376 */     builder.append(", ");
/* 3377 */     builder.append("publicUpdatesChannelId=").append(publicUpdatesChannelId().toString());
/* 3378 */     builder.append(", ");
/* 3379 */     builder.append("maxVideoChannelUsers=").append(maxVideoChannelUsers().toString());
/* 3380 */     builder.append(", ");
/* 3381 */     builder.append("approximateMemberCount=").append(approximateMemberCount().toString());
/* 3382 */     builder.append(", ");
/* 3383 */     builder.append("approximatePresenceCount=").append(approximatePresenceCount().toString());
/* 3384 */     builder.append(", ");
/* 3385 */     builder.append("welcomeScreen=").append(welcomeScreen().toString());
/* 3386 */     builder.append(", ");
/* 3387 */     builder.append("nsfw=").append(nsfw().toString());
/* 3388 */     builder.append(", ");
/* 3389 */     builder.append("safetyAlertsChannelId=").append(safetyAlertsChannelId().toString());
/* 3390 */     builder.append(", ");
/* 3391 */     builder.append("verificationLevel=").append(this.verificationLevel);
/* 3392 */     builder.append(", ");
/* 3393 */     builder.append("nsfwLevel=").append(this.nsfwLevel);
/* 3394 */     return builder.append("}").toString();
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonDeserialize
/*      */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*      */   @Generated(from = "PartialGuildData", generator = "Immutables")
/*      */   static final class Json
/*      */     implements PartialGuildData
/*      */   {
/*      */     Id id;
/*      */     
/*      */     String name;
/* 3408 */     Optional<String> icon = Optional.empty();
/* 3409 */     Optional<String> splash = Optional.empty();
/* 3410 */     Optional<String> discoverySplash = Optional.empty();
/*      */     
/* 3412 */     Possible<Boolean> owner = Possible.absent();
/*      */ 
/*      */     
/* 3415 */     Possible<Long> permissions = Possible.absent();
/*      */ 
/*      */     
/* 3418 */     Optional<Id> afkChannelId = Optional.empty();
/*      */ 
/*      */     
/* 3421 */     Possible<Boolean> embedEnabled = Possible.absent();
/*      */ 
/*      */     
/* 3424 */     Possible<Optional<Id>> embedChannelId = Possible.absent();
/*      */     
/* 3426 */     List<String> features = Collections.emptyList();
/*      */     
/* 3428 */     Optional<Id> applicationId = Optional.empty();
/*      */ 
/*      */     
/* 3431 */     Possible<Boolean> widgetEnabled = Possible.absent();
/*      */ 
/*      */     
/* 3434 */     Possible<Optional<Id>> widgetChannelId = Possible.absent();
/*      */ 
/*      */     
/* 3437 */     Optional<Id> systemChannelId = Optional.empty();
/*      */     
/* 3439 */     OptionalInt systemChannelFlags = OptionalInt.empty();
/*      */     
/* 3441 */     Optional<Id> rulesChannelId = Optional.empty();
/*      */ 
/*      */     
/* 3444 */     Possible<Optional<Integer>> maxPresences = Possible.absent();
/*      */ 
/*      */     
/* 3447 */     Possible<Integer> maxMembers = Possible.absent();
/*      */     
/* 3449 */     Optional<String> vanityUrlCode = Optional.empty();
/* 3450 */     Optional<String> description = Optional.empty();
/* 3451 */     Optional<String> banner = Optional.empty();
/*      */     
/* 3453 */     Possible<Integer> premiumSubscriptionCount = Possible.absent();
/*      */ 
/*      */     
/* 3456 */     Optional<Id> publicUpdatesChannelId = Optional.empty();
/*      */ 
/*      */     
/* 3459 */     Possible<Integer> maxVideoChannelUsers = Possible.absent();
/*      */ 
/*      */     
/* 3462 */     Possible<Integer> approximateMemberCount = Possible.absent();
/*      */ 
/*      */     
/* 3465 */     Possible<Integer> approximatePresenceCount = Possible.absent();
/*      */ 
/*      */     
/* 3468 */     Possible<WelcomeScreenData> welcomeScreen = Possible.absent();
/*      */ 
/*      */     
/* 3471 */     Possible<Boolean> nsfw = Possible.absent();
/*      */ 
/*      */     
/* 3474 */     Optional<Id> safetyAlertsChannelId = Optional.empty();
/*      */     int verificationLevel;
/*      */     boolean verificationLevelIsSet;
/*      */     int nsfwLevel;
/*      */     boolean nsfwLevelIsSet;
/*      */     
/*      */     @JsonProperty("id")
/*      */     public void setId(Id id) {
/* 3482 */       this.id = id;
/*      */     }
/*      */     @JsonProperty("name")
/*      */     public void setName(String name) {
/* 3486 */       this.name = name;
/*      */     }
/*      */     @JsonProperty("icon")
/*      */     public void setIcon(Optional<String> icon) {
/* 3490 */       this.icon = icon;
/*      */     }
/*      */     @JsonProperty("splash")
/*      */     public void setSplash(Optional<String> splash) {
/* 3494 */       this.splash = splash;
/*      */     }
/*      */     @JsonProperty("discovery_splash")
/*      */     public void setDiscoverySplash(Optional<String> discoverySplash) {
/* 3498 */       this.discoverySplash = discoverySplash;
/*      */     }
/*      */     @JsonProperty("owner")
/*      */     public void setOwner(Possible<Boolean> owner) {
/* 3502 */       this.owner = owner;
/*      */     }
/*      */     @JsonProperty("permissions")
/*      */     public void setPermissions(Possible<Long> permissions) {
/* 3506 */       this.permissions = permissions;
/*      */     }
/*      */     @JsonProperty("afk_channel_id")
/*      */     public void setAfkChannelId(Optional<Id> afkChannelId) {
/* 3510 */       this.afkChannelId = afkChannelId;
/*      */     }
/*      */     @JsonProperty("embed_enabled")
/*      */     public void setEmbedEnabled(Possible<Boolean> embedEnabled) {
/* 3514 */       this.embedEnabled = embedEnabled;
/*      */     }
/*      */     @JsonProperty("embed_channel_id")
/*      */     public void setEmbedChannelId(Possible<Optional<Id>> embedChannelId) {
/* 3518 */       this.embedChannelId = embedChannelId;
/*      */     }
/*      */     @JsonProperty("features")
/*      */     public void setFeatures(List<String> features) {
/* 3522 */       this.features = features;
/*      */     }
/*      */     @JsonProperty("application_id")
/*      */     public void setApplicationId(Optional<Id> applicationId) {
/* 3526 */       this.applicationId = applicationId;
/*      */     }
/*      */     @JsonProperty("widget_enabled")
/*      */     public void setWidgetEnabled(Possible<Boolean> widgetEnabled) {
/* 3530 */       this.widgetEnabled = widgetEnabled;
/*      */     }
/*      */     @JsonProperty("widget_channel_id")
/*      */     public void setWidgetChannelId(Possible<Optional<Id>> widgetChannelId) {
/* 3534 */       this.widgetChannelId = widgetChannelId;
/*      */     }
/*      */     @JsonProperty("system_channel_id")
/*      */     public void setSystemChannelId(Optional<Id> systemChannelId) {
/* 3538 */       this.systemChannelId = systemChannelId;
/*      */     }
/*      */     @JsonProperty("system_channel_flags")
/*      */     public void setSystemChannelFlags(OptionalInt systemChannelFlags) {
/* 3542 */       this.systemChannelFlags = systemChannelFlags;
/*      */     }
/*      */     @JsonProperty("rules_channel_id")
/*      */     public void setRulesChannelId(Optional<Id> rulesChannelId) {
/* 3546 */       this.rulesChannelId = rulesChannelId;
/*      */     }
/*      */     @JsonProperty("max_presences")
/*      */     public void setMaxPresences(Possible<Optional<Integer>> maxPresences) {
/* 3550 */       this.maxPresences = maxPresences;
/*      */     }
/*      */     @JsonProperty("max_members")
/*      */     public void setMaxMembers(Possible<Integer> maxMembers) {
/* 3554 */       this.maxMembers = maxMembers;
/*      */     }
/*      */     @JsonProperty("vanity_url_code")
/*      */     public void setVanityUrlCode(Optional<String> vanityUrlCode) {
/* 3558 */       this.vanityUrlCode = vanityUrlCode;
/*      */     }
/*      */     @JsonProperty("description")
/*      */     public void setDescription(Optional<String> description) {
/* 3562 */       this.description = description;
/*      */     }
/*      */     @JsonProperty("banner")
/*      */     public void setBanner(Optional<String> banner) {
/* 3566 */       this.banner = banner;
/*      */     }
/*      */     @JsonProperty("premium_subscription_count")
/*      */     public void setPremiumSubscriptionCount(Possible<Integer> premiumSubscriptionCount) {
/* 3570 */       this.premiumSubscriptionCount = premiumSubscriptionCount;
/*      */     }
/*      */     @JsonProperty("public_updates_channel_id")
/*      */     public void setPublicUpdatesChannelId(Optional<Id> publicUpdatesChannelId) {
/* 3574 */       this.publicUpdatesChannelId = publicUpdatesChannelId;
/*      */     }
/*      */     @JsonProperty("max_video_channel_users")
/*      */     public void setMaxVideoChannelUsers(Possible<Integer> maxVideoChannelUsers) {
/* 3578 */       this.maxVideoChannelUsers = maxVideoChannelUsers;
/*      */     }
/*      */     @JsonProperty("approximate_member_count")
/*      */     public void setApproximateMemberCount(Possible<Integer> approximateMemberCount) {
/* 3582 */       this.approximateMemberCount = approximateMemberCount;
/*      */     }
/*      */     @JsonProperty("approximate_presence_count")
/*      */     public void setApproximatePresenceCount(Possible<Integer> approximatePresenceCount) {
/* 3586 */       this.approximatePresenceCount = approximatePresenceCount;
/*      */     }
/*      */     @JsonProperty("welcome_screen")
/*      */     public void setWelcomeScreen(Possible<WelcomeScreenData> welcomeScreen) {
/* 3590 */       this.welcomeScreen = welcomeScreen;
/*      */     }
/*      */     @JsonProperty("nsfw")
/*      */     public void setNsfw(Possible<Boolean> nsfw) {
/* 3594 */       this.nsfw = nsfw;
/*      */     }
/*      */     @JsonProperty("safety_alerts_channel_id")
/*      */     public void setSafetyAlertsChannelId(Optional<Id> safetyAlertsChannelId) {
/* 3598 */       this.safetyAlertsChannelId = safetyAlertsChannelId;
/*      */     }
/*      */     @JsonProperty("verification_level")
/*      */     public void setVerificationLevel(int verificationLevel) {
/* 3602 */       this.verificationLevel = verificationLevel;
/* 3603 */       this.verificationLevelIsSet = true;
/*      */     }
/*      */     @JsonProperty("nsfw_level")
/*      */     public void setNsfwLevel(int nsfwLevel) {
/* 3607 */       this.nsfwLevel = nsfwLevel;
/* 3608 */       this.nsfwLevelIsSet = true;
/*      */     }
/*      */     public Id id() {
/* 3611 */       throw new UnsupportedOperationException();
/*      */     } public String name() {
/* 3613 */       throw new UnsupportedOperationException();
/*      */     } public Optional<String> icon() {
/* 3615 */       throw new UnsupportedOperationException();
/*      */     } public Optional<String> splash() {
/* 3617 */       throw new UnsupportedOperationException();
/*      */     } public Optional<String> discoverySplash() {
/* 3619 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Boolean> owner() {
/* 3621 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Long> permissions() {
/* 3623 */       throw new UnsupportedOperationException();
/*      */     } public Optional<Id> afkChannelId() {
/* 3625 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Boolean> embedEnabled() {
/* 3627 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Optional<Id>> embedChannelId() {
/* 3629 */       throw new UnsupportedOperationException();
/*      */     } public List<String> features() {
/* 3631 */       throw new UnsupportedOperationException();
/*      */     } public Optional<Id> applicationId() {
/* 3633 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Boolean> widgetEnabled() {
/* 3635 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Optional<Id>> widgetChannelId() {
/* 3637 */       throw new UnsupportedOperationException();
/*      */     } public Optional<Id> systemChannelId() {
/* 3639 */       throw new UnsupportedOperationException();
/*      */     } public OptionalInt systemChannelFlags() {
/* 3641 */       throw new UnsupportedOperationException();
/*      */     } public Optional<Id> rulesChannelId() {
/* 3643 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Optional<Integer>> maxPresences() {
/* 3645 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Integer> maxMembers() {
/* 3647 */       throw new UnsupportedOperationException();
/*      */     } public Optional<String> vanityUrlCode() {
/* 3649 */       throw new UnsupportedOperationException();
/*      */     } public Optional<String> description() {
/* 3651 */       throw new UnsupportedOperationException();
/*      */     } public Optional<String> banner() {
/* 3653 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Integer> premiumSubscriptionCount() {
/* 3655 */       throw new UnsupportedOperationException();
/*      */     } public Optional<Id> publicUpdatesChannelId() {
/* 3657 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Integer> maxVideoChannelUsers() {
/* 3659 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Integer> approximateMemberCount() {
/* 3661 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Integer> approximatePresenceCount() {
/* 3663 */       throw new UnsupportedOperationException();
/*      */     } public Possible<WelcomeScreenData> welcomeScreen() {
/* 3665 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Boolean> nsfw() {
/* 3667 */       throw new UnsupportedOperationException();
/*      */     } public Optional<Id> safetyAlertsChannelId() {
/* 3669 */       throw new UnsupportedOperationException();
/*      */     } public int verificationLevel() {
/* 3671 */       throw new UnsupportedOperationException();
/*      */     } public int nsfwLevel() {
/* 3673 */       throw new UnsupportedOperationException();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*      */   static ImmutablePartialGuildData fromJson(Json json) {
/* 3684 */     Builder builder = builder();
/* 3685 */     if (json.id != null) {
/* 3686 */       builder.id(json.id);
/*      */     }
/* 3688 */     if (json.name != null) {
/* 3689 */       builder.name(json.name);
/*      */     }
/* 3691 */     if (json.icon != null) {
/* 3692 */       builder.icon(json.icon);
/*      */     }
/* 3694 */     if (json.splash != null) {
/* 3695 */       builder.splash(json.splash);
/*      */     }
/* 3697 */     if (json.discoverySplash != null) {
/* 3698 */       builder.discoverySplash(json.discoverySplash);
/*      */     }
/* 3700 */     if (json.owner != null) {
/* 3701 */       builder.owner(json.owner);
/*      */     }
/* 3703 */     if (json.permissions != null) {
/* 3704 */       builder.permissions(json.permissions);
/*      */     }
/* 3706 */     if (json.afkChannelId != null) {
/* 3707 */       builder.afkChannelId(json.afkChannelId);
/*      */     }
/* 3709 */     if (json.embedEnabled != null) {
/* 3710 */       builder.embedEnabled(json.embedEnabled);
/*      */     }
/* 3712 */     if (json.embedChannelId != null) {
/* 3713 */       builder.embedChannelId(json.embedChannelId);
/*      */     }
/* 3715 */     if (json.features != null) {
/* 3716 */       builder.addAllFeatures(json.features);
/*      */     }
/* 3718 */     if (json.applicationId != null) {
/* 3719 */       builder.applicationId(json.applicationId);
/*      */     }
/* 3721 */     if (json.widgetEnabled != null) {
/* 3722 */       builder.widgetEnabled(json.widgetEnabled);
/*      */     }
/* 3724 */     if (json.widgetChannelId != null) {
/* 3725 */       builder.widgetChannelId(json.widgetChannelId);
/*      */     }
/* 3727 */     if (json.systemChannelId != null) {
/* 3728 */       builder.systemChannelId(json.systemChannelId);
/*      */     }
/* 3730 */     if (json.systemChannelFlags != null) {
/* 3731 */       builder.systemChannelFlags(json.systemChannelFlags);
/*      */     }
/* 3733 */     if (json.rulesChannelId != null) {
/* 3734 */       builder.rulesChannelId(json.rulesChannelId);
/*      */     }
/* 3736 */     if (json.maxPresences != null) {
/* 3737 */       builder.maxPresences(json.maxPresences);
/*      */     }
/* 3739 */     if (json.maxMembers != null) {
/* 3740 */       builder.maxMembers(json.maxMembers);
/*      */     }
/* 3742 */     if (json.vanityUrlCode != null) {
/* 3743 */       builder.vanityUrlCode(json.vanityUrlCode);
/*      */     }
/* 3745 */     if (json.description != null) {
/* 3746 */       builder.description(json.description);
/*      */     }
/* 3748 */     if (json.banner != null) {
/* 3749 */       builder.banner(json.banner);
/*      */     }
/* 3751 */     if (json.premiumSubscriptionCount != null) {
/* 3752 */       builder.premiumSubscriptionCount(json.premiumSubscriptionCount);
/*      */     }
/* 3754 */     if (json.publicUpdatesChannelId != null) {
/* 3755 */       builder.publicUpdatesChannelId(json.publicUpdatesChannelId);
/*      */     }
/* 3757 */     if (json.maxVideoChannelUsers != null) {
/* 3758 */       builder.maxVideoChannelUsers(json.maxVideoChannelUsers);
/*      */     }
/* 3760 */     if (json.approximateMemberCount != null) {
/* 3761 */       builder.approximateMemberCount(json.approximateMemberCount);
/*      */     }
/* 3763 */     if (json.approximatePresenceCount != null) {
/* 3764 */       builder.approximatePresenceCount(json.approximatePresenceCount);
/*      */     }
/* 3766 */     if (json.welcomeScreen != null) {
/* 3767 */       builder.welcomeScreen(json.welcomeScreen);
/*      */     }
/* 3769 */     if (json.nsfw != null) {
/* 3770 */       builder.nsfw(json.nsfw);
/*      */     }
/* 3772 */     if (json.safetyAlertsChannelId != null) {
/* 3773 */       builder.safetyAlertsChannelId(json.safetyAlertsChannelId);
/*      */     }
/* 3775 */     if (json.verificationLevelIsSet) {
/* 3776 */       builder.verificationLevel(json.verificationLevel);
/*      */     }
/* 3778 */     if (json.nsfwLevelIsSet) {
/* 3779 */       builder.nsfwLevel(json.nsfwLevel);
/*      */     }
/* 3781 */     return builder.build();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutablePartialGuildData of(Id id, String name, Optional<String> icon, Optional<String> splash, Optional<String> discoverySplash, Possible<Boolean> owner, Possible<Long> permissions, Optional<Id> afkChannelId, Possible<Boolean> embedEnabled, Possible<Optional<Id>> embedChannelId, List<String> features, Optional<Id> applicationId, Possible<Boolean> widgetEnabled, Possible<Optional<Id>> widgetChannelId, Optional<Id> systemChannelId, OptionalInt systemChannelFlags, Optional<Id> rulesChannelId, Possible<Optional<Integer>> maxPresences, Possible<Integer> maxMembers, Optional<String> vanityUrlCode, Optional<String> description, Optional<String> banner, Possible<Integer> premiumSubscriptionCount, Optional<Id> publicUpdatesChannelId, Possible<Integer> maxVideoChannelUsers, Possible<Integer> approximateMemberCount, Possible<Integer> approximatePresenceCount, Possible<WelcomeScreenData> welcomeScreen, Possible<Boolean> nsfw, Optional<Id> safetyAlertsChannelId, int verificationLevel, int nsfwLevel) {
/* 3821 */     return of(id, name, icon, splash, discoverySplash, owner, permissions, afkChannelId, embedEnabled, embedChannelId, features, applicationId, widgetEnabled, widgetChannelId, systemChannelId, systemChannelFlags, rulesChannelId, maxPresences, maxMembers, vanityUrlCode, description, banner, premiumSubscriptionCount, publicUpdatesChannelId, maxVideoChannelUsers, approximateMemberCount, approximatePresenceCount, welcomeScreen, nsfw, safetyAlertsChannelId, verificationLevel, nsfwLevel);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutablePartialGuildData of(Id id, String name, Optional<String> icon, Optional<String> splash, Optional<String> discoverySplash, Possible<Boolean> owner, Possible<Long> permissions, Optional<Id> afkChannelId, Possible<Boolean> embedEnabled, Possible<Optional<Id>> embedChannelId, Iterable<String> features, Optional<Id> applicationId, Possible<Boolean> widgetEnabled, Possible<Optional<Id>> widgetChannelId, Optional<Id> systemChannelId, OptionalInt systemChannelFlags, Optional<Id> rulesChannelId, Possible<Optional<Integer>> maxPresences, Possible<Integer> maxMembers, Optional<String> vanityUrlCode, Optional<String> description, Optional<String> banner, Possible<Integer> premiumSubscriptionCount, Optional<Id> publicUpdatesChannelId, Possible<Integer> maxVideoChannelUsers, Possible<Integer> approximateMemberCount, Possible<Integer> approximatePresenceCount, Possible<WelcomeScreenData> welcomeScreen, Possible<Boolean> nsfw, Optional<Id> safetyAlertsChannelId, int verificationLevel, int nsfwLevel) {
/* 3861 */     return new ImmutablePartialGuildData(id, name, icon, splash, discoverySplash, owner, permissions, afkChannelId, embedEnabled, embedChannelId, features, applicationId, widgetEnabled, widgetChannelId, systemChannelId, systemChannelFlags, rulesChannelId, maxPresences, maxMembers, vanityUrlCode, description, banner, premiumSubscriptionCount, publicUpdatesChannelId, maxVideoChannelUsers, approximateMemberCount, approximatePresenceCount, welcomeScreen, nsfw, safetyAlertsChannelId, verificationLevel, nsfwLevel);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutablePartialGuildData copyOf(PartialGuildData instance) {
/* 3872 */     if (instance instanceof ImmutablePartialGuildData) {
/* 3873 */       return (ImmutablePartialGuildData)instance;
/*      */     }
/* 3875 */     return builder()
/* 3876 */       .from(instance)
/* 3877 */       .build();
/*      */   }
/*      */   
/*      */   public boolean isOwnerPresent() {
/* 3881 */     return !this.owner_absent;
/*      */   }
/*      */   
/*      */   public Boolean ownerOrElse(Boolean defaultValue) {
/* 3885 */     return !this.owner_absent ? this.owner_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isPermissionsPresent() {
/* 3889 */     return !this.permissions_absent;
/*      */   }
/*      */   
/*      */   public Long permissionsOrElse(Long defaultValue) {
/* 3893 */     return !this.permissions_absent ? this.permissions_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isAfkChannelIdPresent() {
/* 3897 */     return this.afkChannelId_present;
/*      */   }
/*      */   
/*      */   public long afkChannelIdOrElse(long defaultValue) {
/* 3901 */     return this.afkChannelId_present ? this.afkChannelId_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isEmbedEnabledPresent() {
/* 3905 */     return !this.embedEnabled_absent;
/*      */   }
/*      */   
/*      */   public Boolean embedEnabledOrElse(Boolean defaultValue) {
/* 3909 */     return !this.embedEnabled_absent ? this.embedEnabled_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isEmbedChannelIdPresent() {
/* 3913 */     return !this.embedChannelId_absent;
/*      */   }
/*      */   
/*      */   public long embedChannelIdOrElse(long defaultValue) {
/* 3917 */     return !this.embedChannelId_absent ? this.embedChannelId_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isApplicationIdPresent() {
/* 3921 */     return this.applicationId_present;
/*      */   }
/*      */   
/*      */   public long applicationIdOrElse(long defaultValue) {
/* 3925 */     return this.applicationId_present ? this.applicationId_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isWidgetEnabledPresent() {
/* 3929 */     return !this.widgetEnabled_absent;
/*      */   }
/*      */   
/*      */   public Boolean widgetEnabledOrElse(Boolean defaultValue) {
/* 3933 */     return !this.widgetEnabled_absent ? this.widgetEnabled_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isWidgetChannelIdPresent() {
/* 3937 */     return !this.widgetChannelId_absent;
/*      */   }
/*      */   
/*      */   public long widgetChannelIdOrElse(long defaultValue) {
/* 3941 */     return !this.widgetChannelId_absent ? this.widgetChannelId_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isSystemChannelIdPresent() {
/* 3945 */     return this.systemChannelId_present;
/*      */   }
/*      */   
/*      */   public long systemChannelIdOrElse(long defaultValue) {
/* 3949 */     return this.systemChannelId_present ? this.systemChannelId_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isRulesChannelIdPresent() {
/* 3953 */     return this.rulesChannelId_present;
/*      */   }
/*      */   
/*      */   public long rulesChannelIdOrElse(long defaultValue) {
/* 3957 */     return this.rulesChannelId_present ? this.rulesChannelId_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isMaxPresencesPresent() {
/* 3961 */     return !this.maxPresences_absent;
/*      */   }
/*      */   
/*      */   public Integer maxPresencesOrElse(Integer defaultValue) {
/* 3965 */     return !this.maxPresences_absent ? this.maxPresences_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isMaxMembersPresent() {
/* 3969 */     return !this.maxMembers_absent;
/*      */   }
/*      */   
/*      */   public Integer maxMembersOrElse(Integer defaultValue) {
/* 3973 */     return !this.maxMembers_absent ? this.maxMembers_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isPremiumSubscriptionCountPresent() {
/* 3977 */     return !this.premiumSubscriptionCount_absent;
/*      */   }
/*      */   
/*      */   public Integer premiumSubscriptionCountOrElse(Integer defaultValue) {
/* 3981 */     return !this.premiumSubscriptionCount_absent ? this.premiumSubscriptionCount_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isPublicUpdatesChannelIdPresent() {
/* 3985 */     return this.publicUpdatesChannelId_present;
/*      */   }
/*      */   
/*      */   public long publicUpdatesChannelIdOrElse(long defaultValue) {
/* 3989 */     return this.publicUpdatesChannelId_present ? this.publicUpdatesChannelId_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isMaxVideoChannelUsersPresent() {
/* 3993 */     return !this.maxVideoChannelUsers_absent;
/*      */   }
/*      */   
/*      */   public Integer maxVideoChannelUsersOrElse(Integer defaultValue) {
/* 3997 */     return !this.maxVideoChannelUsers_absent ? this.maxVideoChannelUsers_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isApproximateMemberCountPresent() {
/* 4001 */     return !this.approximateMemberCount_absent;
/*      */   }
/*      */   
/*      */   public Integer approximateMemberCountOrElse(Integer defaultValue) {
/* 4005 */     return !this.approximateMemberCount_absent ? this.approximateMemberCount_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isApproximatePresenceCountPresent() {
/* 4009 */     return !this.approximatePresenceCount_absent;
/*      */   }
/*      */   
/*      */   public Integer approximatePresenceCountOrElse(Integer defaultValue) {
/* 4013 */     return !this.approximatePresenceCount_absent ? this.approximatePresenceCount_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isWelcomeScreenPresent() {
/* 4017 */     return !this.welcomeScreen_absent;
/*      */   }
/*      */   
/*      */   public WelcomeScreenData welcomeScreenOrElse(WelcomeScreenData defaultValue) {
/* 4021 */     return !this.welcomeScreen_absent ? this.welcomeScreen_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isNsfwPresent() {
/* 4025 */     return !this.nsfw_absent;
/*      */   }
/*      */   
/*      */   public Boolean nsfwOrElse(Boolean defaultValue) {
/* 4029 */     return !this.nsfw_absent ? this.nsfw_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isSafetyAlertsChannelIdPresent() {
/* 4033 */     return this.safetyAlertsChannelId_present;
/*      */   }
/*      */   
/*      */   public long safetyAlertsChannelIdOrElse(long defaultValue) {
/* 4037 */     return this.safetyAlertsChannelId_present ? this.safetyAlertsChannelId_value : defaultValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Builder builder() {
/* 4081 */     return new Builder();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   @Generated(from = "PartialGuildData", generator = "Immutables")
/*      */   public static final class Builder
/*      */   {
/*      */     private static final long INIT_BIT_NAME = 1L;
/*      */ 
/*      */     
/*      */     private static final long INIT_BIT_VERIFICATION_LEVEL = 2L;
/*      */     
/*      */     private static final long INIT_BIT_NSFW_LEVEL = 4L;
/*      */     
/* 4096 */     private long initBits = 7L;
/*      */     
/* 4098 */     private Id id_id = null;
/* 4099 */     private Possible<Boolean> owner_possible = Possible.absent();
/* 4100 */     private Possible<Long> permissions_possible = Possible.absent();
/* 4101 */     private Optional<Id> afkChannelId_optional = Optional.empty();
/* 4102 */     private Possible<Boolean> embedEnabled_possible = Possible.absent();
/* 4103 */     private Possible<Optional<Id>> embedChannelId_possible = Possible.absent();
/* 4104 */     private Optional<Id> applicationId_optional = Optional.empty();
/* 4105 */     private Possible<Boolean> widgetEnabled_possible = Possible.absent();
/* 4106 */     private Possible<Optional<Id>> widgetChannelId_possible = Possible.absent();
/* 4107 */     private Optional<Id> systemChannelId_optional = Optional.empty();
/* 4108 */     private Optional<Id> rulesChannelId_optional = Optional.empty();
/* 4109 */     private Possible<Optional<Integer>> maxPresences_possible = Possible.absent();
/* 4110 */     private Possible<Integer> maxMembers_possible = Possible.absent();
/* 4111 */     private Possible<Integer> premiumSubscriptionCount_possible = Possible.absent();
/* 4112 */     private Optional<Id> publicUpdatesChannelId_optional = Optional.empty();
/* 4113 */     private Possible<Integer> maxVideoChannelUsers_possible = Possible.absent();
/* 4114 */     private Possible<Integer> approximateMemberCount_possible = Possible.absent();
/* 4115 */     private Possible<Integer> approximatePresenceCount_possible = Possible.absent();
/* 4116 */     private Possible<WelcomeScreenData> welcomeScreen_possible = Possible.absent();
/* 4117 */     private Possible<Boolean> nsfw_possible = Possible.absent();
/* 4118 */     private Optional<Id> safetyAlertsChannelId_optional = Optional.empty();
/*      */     private String name;
/*      */     private String icon;
/*      */     private String splash;
/*      */     private String discoverySplash;
/* 4123 */     private List<String> features = new ArrayList<>();
/*      */ 
/*      */     
/*      */     private Integer systemChannelFlags;
/*      */     
/*      */     private String vanityUrlCode;
/*      */     
/*      */     private String description;
/*      */     
/*      */     private String banner;
/*      */     
/*      */     private int verificationLevel;
/*      */     
/*      */     private int nsfwLevel;
/*      */ 
/*      */     
/*      */     public final Builder from(GuildFields instance) {
/* 4140 */       Objects.requireNonNull(instance, "instance");
/* 4141 */       from(instance);
/* 4142 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder from(GuildNsfwLevelField instance) {
/* 4151 */       Objects.requireNonNull(instance, "instance");
/* 4152 */       from(instance);
/* 4153 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder from(GuildVerificationLevelField instance) {
/* 4162 */       Objects.requireNonNull(instance, "instance");
/* 4163 */       from(instance);
/* 4164 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder from(PartialGuildData instance) {
/* 4173 */       Objects.requireNonNull(instance, "instance");
/* 4174 */       from(instance);
/* 4175 */       return this;
/*      */     }
/*      */     
/*      */     private void from(Object object) {
/* 4179 */       long bits = 0L;
/* 4180 */       if (object instanceof GuildFields) {
/* 4181 */         GuildFields instance = (GuildFields)object;
/* 4182 */         if ((bits & 0x1L) == 0L) {
/* 4183 */           Optional<String> vanityUrlCodeOptional = instance.vanityUrlCode();
/* 4184 */           if (vanityUrlCodeOptional.isPresent()) {
/* 4185 */             vanityUrlCode(vanityUrlCodeOptional);
/*      */           }
/* 4187 */           bits |= 0x1L;
/*      */         } 
/* 4189 */         if ((bits & 0x2L) == 0L) {
/* 4190 */           Optional<String> iconOptional = instance.icon();
/* 4191 */           if (iconOptional.isPresent()) {
/* 4192 */             icon(iconOptional);
/*      */           }
/* 4194 */           bits |= 0x2L;
/*      */         } 
/* 4196 */         if ((bits & 0x8L) == 0L) {
/* 4197 */           Optional<String> descriptionOptional = instance.description();
/* 4198 */           if (descriptionOptional.isPresent()) {
/* 4199 */             description(descriptionOptional);
/*      */           }
/* 4201 */           bits |= 0x8L;
/*      */         } 
/* 4203 */         if ((bits & 0x10L) == 0L) {
/* 4204 */           afkChannelId(instance.afkChannelId());
/* 4205 */           bits |= 0x10L;
/*      */         } 
/* 4207 */         if ((bits & 0x20L) == 0L) {
/* 4208 */           addAllFeatures(instance.features());
/* 4209 */           bits |= 0x20L;
/*      */         } 
/* 4211 */         if ((bits & 0x40L) == 0L) {
/* 4212 */           maxMembers(instance.maxMembers());
/* 4213 */           bits |= 0x40L;
/*      */         } 
/* 4215 */         if ((bits & 0x80L) == 0L) {
/* 4216 */           permissions(instance.permissions());
/* 4217 */           bits |= 0x80L;
/*      */         } 
/* 4219 */         if ((bits & 0x100L) == 0L) {
/* 4220 */           publicUpdatesChannelId(instance.publicUpdatesChannelId());
/* 4221 */           bits |= 0x100L;
/*      */         } 
/* 4223 */         if ((bits & 0x200L) == 0L) {
/* 4224 */           id(instance.id());
/* 4225 */           bits |= 0x200L;
/*      */         } 
/* 4227 */         if ((bits & 0x400L) == 0L) {
/* 4228 */           safetyAlertsChannelId(instance.safetyAlertsChannelId());
/* 4229 */           bits |= 0x400L;
/*      */         } 
/* 4231 */         if ((bits & 0x800L) == 0L) {
/* 4232 */           systemChannelId(instance.systemChannelId());
/* 4233 */           bits |= 0x800L;
/*      */         } 
/* 4235 */         if ((bits & 0x1000L) == 0L) {
/* 4236 */           owner(instance.owner());
/* 4237 */           bits |= 0x1000L;
/*      */         } 
/* 4239 */         if ((bits & 0x2000L) == 0L) {
/* 4240 */           Optional<String> discoverySplashOptional = instance.discoverySplash();
/* 4241 */           if (discoverySplashOptional.isPresent()) {
/* 4242 */             discoverySplash(discoverySplashOptional);
/*      */           }
/* 4244 */           bits |= 0x2000L;
/*      */         } 
/* 4246 */         if ((bits & 0x4000L) == 0L) {
/* 4247 */           approximateMemberCount(instance.approximateMemberCount());
/* 4248 */           bits |= 0x4000L;
/*      */         } 
/* 4250 */         if ((bits & 0x8000L) == 0L) {
/* 4251 */           maxPresences(instance.maxPresences());
/* 4252 */           bits |= 0x8000L;
/*      */         } 
/* 4254 */         if ((bits & 0x10000L) == 0L) {
/* 4255 */           welcomeScreen(instance.welcomeScreen());
/* 4256 */           bits |= 0x10000L;
/*      */         } 
/* 4258 */         if ((bits & 0x20000L) == 0L) {
/* 4259 */           rulesChannelId(instance.rulesChannelId());
/* 4260 */           bits |= 0x20000L;
/*      */         } 
/* 4262 */         if ((bits & 0x40000L) == 0L) {
/* 4263 */           nsfw(instance.nsfw());
/* 4264 */           bits |= 0x40000L;
/*      */         } 
/* 4266 */         if ((bits & 0x80000L) == 0L) {
/* 4267 */           widgetChannelId(instance.widgetChannelId());
/* 4268 */           bits |= 0x80000L;
/*      */         } 
/* 4270 */         if ((bits & 0x100000L) == 0L) {
/* 4271 */           Optional<String> bannerOptional = instance.banner();
/* 4272 */           if (bannerOptional.isPresent()) {
/* 4273 */             banner(bannerOptional);
/*      */           }
/* 4275 */           bits |= 0x100000L;
/*      */         } 
/* 4277 */         if ((bits & 0x200000L) == 0L) {
/* 4278 */           widgetEnabled(instance.widgetEnabled());
/* 4279 */           bits |= 0x200000L;
/*      */         } 
/* 4281 */         if ((bits & 0x400000L) == 0L) {
/* 4282 */           embedChannelId(instance.embedChannelId());
/* 4283 */           bits |= 0x400000L;
/*      */         } 
/* 4285 */         if ((bits & 0x800000L) == 0L) {
/* 4286 */           OptionalInt systemChannelFlagsOptional = instance.systemChannelFlags();
/* 4287 */           if (systemChannelFlagsOptional.isPresent()) {
/* 4288 */             systemChannelFlags(systemChannelFlagsOptional);
/*      */           }
/* 4290 */           bits |= 0x800000L;
/*      */         } 
/* 4292 */         if ((bits & 0x1000000L) == 0L) {
/* 4293 */           maxVideoChannelUsers(instance.maxVideoChannelUsers());
/* 4294 */           bits |= 0x1000000L;
/*      */         } 
/* 4296 */         if ((bits & 0x4000000L) == 0L) {
/* 4297 */           name(instance.name());
/* 4298 */           bits |= 0x4000000L;
/*      */         } 
/* 4300 */         if ((bits & 0x8000000L) == 0L) {
/* 4301 */           premiumSubscriptionCount(instance.premiumSubscriptionCount());
/* 4302 */           bits |= 0x8000000L;
/*      */         } 
/* 4304 */         if ((bits & 0x10000000L) == 0L) {
/* 4305 */           embedEnabled(instance.embedEnabled());
/* 4306 */           bits |= 0x10000000L;
/*      */         } 
/* 4308 */         if ((bits & 0x20000000L) == 0L) {
/* 4309 */           approximatePresenceCount(instance.approximatePresenceCount());
/* 4310 */           bits |= 0x20000000L;
/*      */         } 
/* 4312 */         if ((bits & 0x40000000L) == 0L) {
/* 4313 */           applicationId(instance.applicationId());
/* 4314 */           bits |= 0x40000000L;
/*      */         } 
/* 4316 */         if ((bits & 0x80000000L) == 0L) {
/* 4317 */           Optional<String> splashOptional = instance.splash();
/* 4318 */           if (splashOptional.isPresent()) {
/* 4319 */             splash(splashOptional);
/*      */           }
/* 4321 */           bits |= 0x80000000L;
/*      */         } 
/*      */       } 
/* 4324 */       if (object instanceof GuildNsfwLevelField) {
/* 4325 */         GuildNsfwLevelField instance = (GuildNsfwLevelField)object;
/* 4326 */         if ((bits & 0x2000000L) == 0L) {
/* 4327 */           nsfwLevel(instance.nsfwLevel());
/* 4328 */           bits |= 0x2000000L;
/*      */         } 
/*      */       } 
/* 4331 */       if (object instanceof GuildVerificationLevelField) {
/* 4332 */         GuildVerificationLevelField instance = (GuildVerificationLevelField)object;
/* 4333 */         if ((bits & 0x4L) == 0L) {
/* 4334 */           verificationLevel(instance.verificationLevel());
/* 4335 */           bits |= 0x4L;
/*      */         } 
/*      */       } 
/* 4338 */       if (object instanceof PartialGuildData) {
/* 4339 */         PartialGuildData instance = (PartialGuildData)object;
/* 4340 */         if ((bits & 0x1L) == 0L) {
/* 4341 */           Optional<String> vanityUrlCodeOptional = instance.vanityUrlCode();
/* 4342 */           if (vanityUrlCodeOptional.isPresent()) {
/* 4343 */             vanityUrlCode(vanityUrlCodeOptional);
/*      */           }
/* 4345 */           bits |= 0x1L;
/*      */         } 
/* 4347 */         if ((bits & 0x2L) == 0L) {
/* 4348 */           Optional<String> iconOptional = instance.icon();
/* 4349 */           if (iconOptional.isPresent()) {
/* 4350 */             icon(iconOptional);
/*      */           }
/* 4352 */           bits |= 0x2L;
/*      */         } 
/* 4354 */         if ((bits & 0x4L) == 0L) {
/* 4355 */           verificationLevel(instance.verificationLevel());
/* 4356 */           bits |= 0x4L;
/*      */         } 
/* 4358 */         if ((bits & 0x8L) == 0L) {
/* 4359 */           Optional<String> descriptionOptional = instance.description();
/* 4360 */           if (descriptionOptional.isPresent()) {
/* 4361 */             description(descriptionOptional);
/*      */           }
/* 4363 */           bits |= 0x8L;
/*      */         } 
/* 4365 */         if ((bits & 0x10L) == 0L) {
/* 4366 */           afkChannelId(instance.afkChannelId());
/* 4367 */           bits |= 0x10L;
/*      */         } 
/* 4369 */         if ((bits & 0x20L) == 0L) {
/* 4370 */           addAllFeatures(instance.features());
/* 4371 */           bits |= 0x20L;
/*      */         } 
/* 4373 */         if ((bits & 0x40L) == 0L) {
/* 4374 */           maxMembers(instance.maxMembers());
/* 4375 */           bits |= 0x40L;
/*      */         } 
/* 4377 */         if ((bits & 0x80L) == 0L) {
/* 4378 */           permissions(instance.permissions());
/* 4379 */           bits |= 0x80L;
/*      */         } 
/* 4381 */         if ((bits & 0x100L) == 0L) {
/* 4382 */           publicUpdatesChannelId(instance.publicUpdatesChannelId());
/* 4383 */           bits |= 0x100L;
/*      */         } 
/* 4385 */         if ((bits & 0x200L) == 0L) {
/* 4386 */           id(instance.id());
/* 4387 */           bits |= 0x200L;
/*      */         } 
/* 4389 */         if ((bits & 0x400L) == 0L) {
/* 4390 */           safetyAlertsChannelId(instance.safetyAlertsChannelId());
/* 4391 */           bits |= 0x400L;
/*      */         } 
/* 4393 */         if ((bits & 0x800L) == 0L) {
/* 4394 */           systemChannelId(instance.systemChannelId());
/* 4395 */           bits |= 0x800L;
/*      */         } 
/* 4397 */         if ((bits & 0x1000L) == 0L) {
/* 4398 */           owner(instance.owner());
/* 4399 */           bits |= 0x1000L;
/*      */         } 
/* 4401 */         if ((bits & 0x2000L) == 0L) {
/* 4402 */           Optional<String> discoverySplashOptional = instance.discoverySplash();
/* 4403 */           if (discoverySplashOptional.isPresent()) {
/* 4404 */             discoverySplash(discoverySplashOptional);
/*      */           }
/* 4406 */           bits |= 0x2000L;
/*      */         } 
/* 4408 */         if ((bits & 0x4000L) == 0L) {
/* 4409 */           approximateMemberCount(instance.approximateMemberCount());
/* 4410 */           bits |= 0x4000L;
/*      */         } 
/* 4412 */         if ((bits & 0x8000L) == 0L) {
/* 4413 */           maxPresences(instance.maxPresences());
/* 4414 */           bits |= 0x8000L;
/*      */         } 
/* 4416 */         if ((bits & 0x10000L) == 0L) {
/* 4417 */           welcomeScreen(instance.welcomeScreen());
/* 4418 */           bits |= 0x10000L;
/*      */         } 
/* 4420 */         if ((bits & 0x20000L) == 0L) {
/* 4421 */           rulesChannelId(instance.rulesChannelId());
/* 4422 */           bits |= 0x20000L;
/*      */         } 
/* 4424 */         if ((bits & 0x40000L) == 0L) {
/* 4425 */           nsfw(instance.nsfw());
/* 4426 */           bits |= 0x40000L;
/*      */         } 
/* 4428 */         if ((bits & 0x80000L) == 0L) {
/* 4429 */           widgetChannelId(instance.widgetChannelId());
/* 4430 */           bits |= 0x80000L;
/*      */         } 
/* 4432 */         if ((bits & 0x100000L) == 0L) {
/* 4433 */           Optional<String> bannerOptional = instance.banner();
/* 4434 */           if (bannerOptional.isPresent()) {
/* 4435 */             banner(bannerOptional);
/*      */           }
/* 4437 */           bits |= 0x100000L;
/*      */         } 
/* 4439 */         if ((bits & 0x200000L) == 0L) {
/* 4440 */           widgetEnabled(instance.widgetEnabled());
/* 4441 */           bits |= 0x200000L;
/*      */         } 
/* 4443 */         if ((bits & 0x400000L) == 0L) {
/* 4444 */           embedChannelId(instance.embedChannelId());
/* 4445 */           bits |= 0x400000L;
/*      */         } 
/* 4447 */         if ((bits & 0x800000L) == 0L) {
/* 4448 */           OptionalInt systemChannelFlagsOptional = instance.systemChannelFlags();
/* 4449 */           if (systemChannelFlagsOptional.isPresent()) {
/* 4450 */             systemChannelFlags(systemChannelFlagsOptional);
/*      */           }
/* 4452 */           bits |= 0x800000L;
/*      */         } 
/* 4454 */         if ((bits & 0x1000000L) == 0L) {
/* 4455 */           maxVideoChannelUsers(instance.maxVideoChannelUsers());
/* 4456 */           bits |= 0x1000000L;
/*      */         } 
/* 4458 */         if ((bits & 0x2000000L) == 0L) {
/* 4459 */           nsfwLevel(instance.nsfwLevel());
/* 4460 */           bits |= 0x2000000L;
/*      */         } 
/* 4462 */         if ((bits & 0x4000000L) == 0L) {
/* 4463 */           name(instance.name());
/* 4464 */           bits |= 0x4000000L;
/*      */         } 
/* 4466 */         if ((bits & 0x8000000L) == 0L) {
/* 4467 */           premiumSubscriptionCount(instance.premiumSubscriptionCount());
/* 4468 */           bits |= 0x8000000L;
/*      */         } 
/* 4470 */         if ((bits & 0x10000000L) == 0L) {
/* 4471 */           embedEnabled(instance.embedEnabled());
/* 4472 */           bits |= 0x10000000L;
/*      */         } 
/* 4474 */         if ((bits & 0x20000000L) == 0L) {
/* 4475 */           approximatePresenceCount(instance.approximatePresenceCount());
/* 4476 */           bits |= 0x20000000L;
/*      */         } 
/* 4478 */         if ((bits & 0x40000000L) == 0L) {
/* 4479 */           applicationId(instance.applicationId());
/* 4480 */           bits |= 0x40000000L;
/*      */         } 
/* 4482 */         if ((bits & 0x80000000L) == 0L) {
/* 4483 */           Optional<String> splashOptional = instance.splash();
/* 4484 */           if (splashOptional.isPresent()) {
/* 4485 */             splash(splashOptional);
/*      */           }
/* 4487 */           bits |= 0x80000000L;
/*      */         } 
/*      */       } 
/*      */     }
/*      */     
/*      */     public Builder id(String value) {
/* 4493 */       this.id_id = Id.of(value);
/* 4494 */       return this;
/*      */     }
/*      */     
/*      */     public Builder id(long value) {
/* 4498 */       this.id_id = Id.of(value);
/* 4499 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("id")
/*      */     public Builder id(Id value) {
/* 4504 */       this.id_id = value;
/* 4505 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("name")
/*      */     public final Builder name(String name) {
/* 4515 */       this.name = Objects.<String>requireNonNull(name, "name");
/* 4516 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 4517 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder icon(String icon) {
/* 4526 */       this.icon = Objects.<String>requireNonNull(icon, "icon");
/* 4527 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("icon")
/*      */     public final Builder icon(Optional<String> icon) {
/* 4537 */       this.icon = icon.orElse(null);
/* 4538 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder splash(String splash) {
/* 4547 */       this.splash = Objects.<String>requireNonNull(splash, "splash");
/* 4548 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("splash")
/*      */     public final Builder splash(Optional<String> splash) {
/* 4558 */       this.splash = splash.orElse(null);
/* 4559 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder discoverySplash(String discoverySplash) {
/* 4568 */       this.discoverySplash = Objects.<String>requireNonNull(discoverySplash, "discoverySplash");
/* 4569 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("discovery_splash")
/*      */     public final Builder discoverySplash(Optional<String> discoverySplash) {
/* 4579 */       this.discoverySplash = discoverySplash.orElse(null);
/* 4580 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("owner")
/*      */     public Builder owner(Possible<Boolean> value) {
/* 4585 */       this.owner_possible = value;
/* 4586 */       return this;
/*      */     }
/*      */     
/*      */     public Builder owner(Boolean value) {
/* 4590 */       this.owner_possible = Possible.of(value);
/* 4591 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("permissions")
/*      */     public Builder permissions(Possible<Long> value) {
/* 4596 */       this.permissions_possible = value;
/* 4597 */       return this;
/*      */     }
/*      */     
/*      */     public Builder permissions(Long value) {
/* 4601 */       this.permissions_possible = Possible.of(value);
/* 4602 */       return this;
/*      */     }
/*      */     
/*      */     public Builder afkChannelId(String value) {
/* 4606 */       this.afkChannelId_optional = Optional.of(Id.of(value));
/* 4607 */       return this;
/*      */     }
/*      */     
/*      */     public Builder afkChannelId(long value) {
/* 4611 */       this.afkChannelId_optional = Optional.of(Id.of(value));
/* 4612 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("afk_channel_id")
/*      */     public Builder afkChannelId(Optional<Id> value) {
/* 4617 */       this.afkChannelId_optional = value;
/* 4618 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("embed_enabled")
/*      */     public Builder embedEnabled(Possible<Boolean> value) {
/* 4623 */       this.embedEnabled_possible = value;
/* 4624 */       return this;
/*      */     }
/*      */     
/*      */     public Builder embedEnabled(Boolean value) {
/* 4628 */       this.embedEnabled_possible = Possible.of(value);
/* 4629 */       return this;
/*      */     }
/*      */     
/*      */     public Builder embedChannelId(String value) {
/* 4633 */       this.embedChannelId_possible = Possible.of(Optional.of(Id.of(value)));
/* 4634 */       return this;
/*      */     }
/*      */     
/*      */     public Builder embedChannelId(long value) {
/* 4638 */       this.embedChannelId_possible = Possible.of(Optional.of(Id.of(value)));
/* 4639 */       return this;
/*      */     }
/*      */     
/*      */     public Builder embedChannelId(Id value) {
/* 4643 */       this.embedChannelId_possible = Possible.of(Optional.of(value));
/* 4644 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("embed_channel_id")
/*      */     public Builder embedChannelId(Possible<Optional<Id>> value) {
/* 4649 */       this.embedChannelId_possible = value;
/* 4650 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addFeature(String element) {
/* 4659 */       this.features.add(Objects.<String>requireNonNull(element, "features element"));
/* 4660 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addFeatures(String... elements) {
/* 4669 */       for (String element : elements) {
/* 4670 */         this.features.add(Objects.<String>requireNonNull(element, "features element"));
/*      */       }
/* 4672 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("features")
/*      */     public final Builder features(Iterable<String> elements) {
/* 4683 */       this.features.clear();
/* 4684 */       return addAllFeatures(elements);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addAllFeatures(Iterable<String> elements) {
/* 4693 */       for (String element : elements) {
/* 4694 */         this.features.add(Objects.<String>requireNonNull(element, "features element"));
/*      */       }
/* 4696 */       return this;
/*      */     }
/*      */     
/*      */     public Builder applicationId(String value) {
/* 4700 */       this.applicationId_optional = Optional.of(Id.of(value));
/* 4701 */       return this;
/*      */     }
/*      */     
/*      */     public Builder applicationId(long value) {
/* 4705 */       this.applicationId_optional = Optional.of(Id.of(value));
/* 4706 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("application_id")
/*      */     public Builder applicationId(Optional<Id> value) {
/* 4711 */       this.applicationId_optional = value;
/* 4712 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("widget_enabled")
/*      */     public Builder widgetEnabled(Possible<Boolean> value) {
/* 4717 */       this.widgetEnabled_possible = value;
/* 4718 */       return this;
/*      */     }
/*      */     
/*      */     public Builder widgetEnabled(Boolean value) {
/* 4722 */       this.widgetEnabled_possible = Possible.of(value);
/* 4723 */       return this;
/*      */     }
/*      */     
/*      */     public Builder widgetChannelId(String value) {
/* 4727 */       this.widgetChannelId_possible = Possible.of(Optional.of(Id.of(value)));
/* 4728 */       return this;
/*      */     }
/*      */     
/*      */     public Builder widgetChannelId(long value) {
/* 4732 */       this.widgetChannelId_possible = Possible.of(Optional.of(Id.of(value)));
/* 4733 */       return this;
/*      */     }
/*      */     
/*      */     public Builder widgetChannelId(Id value) {
/* 4737 */       this.widgetChannelId_possible = Possible.of(Optional.of(value));
/* 4738 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("widget_channel_id")
/*      */     public Builder widgetChannelId(Possible<Optional<Id>> value) {
/* 4743 */       this.widgetChannelId_possible = value;
/* 4744 */       return this;
/*      */     }
/*      */     
/*      */     public Builder systemChannelId(String value) {
/* 4748 */       this.systemChannelId_optional = Optional.of(Id.of(value));
/* 4749 */       return this;
/*      */     }
/*      */     
/*      */     public Builder systemChannelId(long value) {
/* 4753 */       this.systemChannelId_optional = Optional.of(Id.of(value));
/* 4754 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("system_channel_id")
/*      */     public Builder systemChannelId(Optional<Id> value) {
/* 4759 */       this.systemChannelId_optional = value;
/* 4760 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder systemChannelFlags(int systemChannelFlags) {
/* 4769 */       this.systemChannelFlags = Integer.valueOf(systemChannelFlags);
/* 4770 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("system_channel_flags")
/*      */     public final Builder systemChannelFlags(OptionalInt systemChannelFlags) {
/* 4780 */       this.systemChannelFlags = systemChannelFlags.isPresent() ? Integer.valueOf(systemChannelFlags.getAsInt()) : null;
/* 4781 */       return this;
/*      */     }
/*      */     
/*      */     public Builder rulesChannelId(String value) {
/* 4785 */       this.rulesChannelId_optional = Optional.of(Id.of(value));
/* 4786 */       return this;
/*      */     }
/*      */     
/*      */     public Builder rulesChannelId(long value) {
/* 4790 */       this.rulesChannelId_optional = Optional.of(Id.of(value));
/* 4791 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("rules_channel_id")
/*      */     public Builder rulesChannelId(Optional<Id> value) {
/* 4796 */       this.rulesChannelId_optional = value;
/* 4797 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("max_presences")
/*      */     public Builder maxPresences(Possible<Optional<Integer>> value) {
/* 4802 */       this.maxPresences_possible = value;
/* 4803 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public Builder maxPresences(@Nullable Integer value) {
/* 4808 */       this.maxPresences_possible = Possible.of(Optional.ofNullable(value));
/* 4809 */       return this;
/*      */     }
/*      */     
/*      */     public Builder maxPresencesOrNull(@Nullable Integer value) {
/* 4813 */       this.maxPresences_possible = Possible.of(Optional.ofNullable(value));
/* 4814 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("max_members")
/*      */     public Builder maxMembers(Possible<Integer> value) {
/* 4819 */       this.maxMembers_possible = value;
/* 4820 */       return this;
/*      */     }
/*      */     
/*      */     public Builder maxMembers(Integer value) {
/* 4824 */       this.maxMembers_possible = Possible.of(value);
/* 4825 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder vanityUrlCode(String vanityUrlCode) {
/* 4834 */       this.vanityUrlCode = Objects.<String>requireNonNull(vanityUrlCode, "vanityUrlCode");
/* 4835 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("vanity_url_code")
/*      */     public final Builder vanityUrlCode(Optional<String> vanityUrlCode) {
/* 4845 */       this.vanityUrlCode = vanityUrlCode.orElse(null);
/* 4846 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder description(String description) {
/* 4855 */       this.description = Objects.<String>requireNonNull(description, "description");
/* 4856 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("description")
/*      */     public final Builder description(Optional<String> description) {
/* 4866 */       this.description = description.orElse(null);
/* 4867 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder banner(String banner) {
/* 4876 */       this.banner = Objects.<String>requireNonNull(banner, "banner");
/* 4877 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("banner")
/*      */     public final Builder banner(Optional<String> banner) {
/* 4887 */       this.banner = banner.orElse(null);
/* 4888 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("premium_subscription_count")
/*      */     public Builder premiumSubscriptionCount(Possible<Integer> value) {
/* 4893 */       this.premiumSubscriptionCount_possible = value;
/* 4894 */       return this;
/*      */     }
/*      */     
/*      */     public Builder premiumSubscriptionCount(Integer value) {
/* 4898 */       this.premiumSubscriptionCount_possible = Possible.of(value);
/* 4899 */       return this;
/*      */     }
/*      */     
/*      */     public Builder publicUpdatesChannelId(String value) {
/* 4903 */       this.publicUpdatesChannelId_optional = Optional.of(Id.of(value));
/* 4904 */       return this;
/*      */     }
/*      */     
/*      */     public Builder publicUpdatesChannelId(long value) {
/* 4908 */       this.publicUpdatesChannelId_optional = Optional.of(Id.of(value));
/* 4909 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("public_updates_channel_id")
/*      */     public Builder publicUpdatesChannelId(Optional<Id> value) {
/* 4914 */       this.publicUpdatesChannelId_optional = value;
/* 4915 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("max_video_channel_users")
/*      */     public Builder maxVideoChannelUsers(Possible<Integer> value) {
/* 4920 */       this.maxVideoChannelUsers_possible = value;
/* 4921 */       return this;
/*      */     }
/*      */     
/*      */     public Builder maxVideoChannelUsers(Integer value) {
/* 4925 */       this.maxVideoChannelUsers_possible = Possible.of(value);
/* 4926 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("approximate_member_count")
/*      */     public Builder approximateMemberCount(Possible<Integer> value) {
/* 4931 */       this.approximateMemberCount_possible = value;
/* 4932 */       return this;
/*      */     }
/*      */     
/*      */     public Builder approximateMemberCount(Integer value) {
/* 4936 */       this.approximateMemberCount_possible = Possible.of(value);
/* 4937 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("approximate_presence_count")
/*      */     public Builder approximatePresenceCount(Possible<Integer> value) {
/* 4942 */       this.approximatePresenceCount_possible = value;
/* 4943 */       return this;
/*      */     }
/*      */     
/*      */     public Builder approximatePresenceCount(Integer value) {
/* 4947 */       this.approximatePresenceCount_possible = Possible.of(value);
/* 4948 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("welcome_screen")
/*      */     public Builder welcomeScreen(Possible<WelcomeScreenData> value) {
/* 4953 */       this.welcomeScreen_possible = value;
/* 4954 */       return this;
/*      */     }
/*      */     
/*      */     public Builder welcomeScreen(WelcomeScreenData value) {
/* 4958 */       this.welcomeScreen_possible = Possible.of(value);
/* 4959 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("nsfw")
/*      */     public Builder nsfw(Possible<Boolean> value) {
/* 4964 */       this.nsfw_possible = value;
/* 4965 */       return this;
/*      */     }
/*      */     
/*      */     public Builder nsfw(Boolean value) {
/* 4969 */       this.nsfw_possible = Possible.of(value);
/* 4970 */       return this;
/*      */     }
/*      */     
/*      */     public Builder safetyAlertsChannelId(String value) {
/* 4974 */       this.safetyAlertsChannelId_optional = Optional.of(Id.of(value));
/* 4975 */       return this;
/*      */     }
/*      */     
/*      */     public Builder safetyAlertsChannelId(long value) {
/* 4979 */       this.safetyAlertsChannelId_optional = Optional.of(Id.of(value));
/* 4980 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("safety_alerts_channel_id")
/*      */     public Builder safetyAlertsChannelId(Optional<Id> value) {
/* 4985 */       this.safetyAlertsChannelId_optional = value;
/* 4986 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("verification_level")
/*      */     public final Builder verificationLevel(int verificationLevel) {
/* 4996 */       this.verificationLevel = verificationLevel;
/* 4997 */       this.initBits &= 0xFFFFFFFFFFFFFFFDL;
/* 4998 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("nsfw_level")
/*      */     public final Builder nsfwLevel(int nsfwLevel) {
/* 5008 */       this.nsfwLevel = nsfwLevel;
/* 5009 */       this.initBits &= 0xFFFFFFFFFFFFFFFBL;
/* 5010 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ImmutablePartialGuildData build() {
/* 5019 */       if (this.initBits != 0L) {
/* 5020 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*      */       }
/* 5022 */       return new ImmutablePartialGuildData(null, 
/*      */           
/* 5024 */           id_build(), this.name, this.icon, this.splash, this.discoverySplash, 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 5029 */           owner_build(), 
/* 5030 */           permissions_build(), 
/* 5031 */           afkChannelId_build(), 
/* 5032 */           embedEnabled_build(), 
/* 5033 */           embedChannelId_build(), ImmutablePartialGuildData
/* 5034 */           .createUnmodifiableList(true, (List)this.features), 
/* 5035 */           applicationId_build(), 
/* 5036 */           widgetEnabled_build(), 
/* 5037 */           widgetChannelId_build(), 
/* 5038 */           systemChannelId_build(), this.systemChannelFlags, 
/*      */           
/* 5040 */           rulesChannelId_build(), 
/* 5041 */           maxPresences_build(), 
/* 5042 */           maxMembers_build(), this.vanityUrlCode, this.description, this.banner, 
/*      */ 
/*      */ 
/*      */           
/* 5046 */           premiumSubscriptionCount_build(), 
/* 5047 */           publicUpdatesChannelId_build(), 
/* 5048 */           maxVideoChannelUsers_build(), 
/* 5049 */           approximateMemberCount_build(), 
/* 5050 */           approximatePresenceCount_build(), 
/* 5051 */           welcomeScreen_build(), 
/* 5052 */           nsfw_build(), 
/* 5053 */           safetyAlertsChannelId_build(), this.verificationLevel, this.nsfwLevel);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     private String formatRequiredAttributesMessage() {
/* 5059 */       List<String> attributes = new ArrayList<>();
/* 5060 */       if ((this.initBits & 0x1L) != 0L) attributes.add("name"); 
/* 5061 */       if ((this.initBits & 0x2L) != 0L) attributes.add("verificationLevel"); 
/* 5062 */       if ((this.initBits & 0x4L) != 0L) attributes.add("nsfwLevel"); 
/* 5063 */       return "Cannot build PartialGuildData, some of required attributes are not set " + attributes;
/*      */     }
/*      */     
/*      */     private Id id_build() {
/* 5067 */       return this.id_id;
/*      */     }
/*      */     
/*      */     private Possible<Boolean> owner_build() {
/* 5071 */       return this.owner_possible;
/*      */     }
/*      */     
/*      */     private Possible<Long> permissions_build() {
/* 5075 */       return this.permissions_possible;
/*      */     }
/*      */     
/*      */     private Optional<Id> afkChannelId_build() {
/* 5079 */       return this.afkChannelId_optional;
/*      */     }
/*      */     
/*      */     private Possible<Boolean> embedEnabled_build() {
/* 5083 */       return this.embedEnabled_possible;
/*      */     }
/*      */     
/*      */     private Possible<Optional<Id>> embedChannelId_build() {
/* 5087 */       return this.embedChannelId_possible;
/*      */     }
/*      */     
/*      */     private Optional<Id> applicationId_build() {
/* 5091 */       return this.applicationId_optional;
/*      */     }
/*      */     
/*      */     private Possible<Boolean> widgetEnabled_build() {
/* 5095 */       return this.widgetEnabled_possible;
/*      */     }
/*      */     
/*      */     private Possible<Optional<Id>> widgetChannelId_build() {
/* 5099 */       return this.widgetChannelId_possible;
/*      */     }
/*      */     
/*      */     private Optional<Id> systemChannelId_build() {
/* 5103 */       return this.systemChannelId_optional;
/*      */     }
/*      */     
/*      */     private Optional<Id> rulesChannelId_build() {
/* 5107 */       return this.rulesChannelId_optional;
/*      */     }
/*      */     
/*      */     private Possible<Optional<Integer>> maxPresences_build() {
/* 5111 */       return this.maxPresences_possible;
/*      */     }
/*      */     
/*      */     private Possible<Integer> maxMembers_build() {
/* 5115 */       return this.maxMembers_possible;
/*      */     }
/*      */     
/*      */     private Possible<Integer> premiumSubscriptionCount_build() {
/* 5119 */       return this.premiumSubscriptionCount_possible;
/*      */     }
/*      */     
/*      */     private Optional<Id> publicUpdatesChannelId_build() {
/* 5123 */       return this.publicUpdatesChannelId_optional;
/*      */     }
/*      */     
/*      */     private Possible<Integer> maxVideoChannelUsers_build() {
/* 5127 */       return this.maxVideoChannelUsers_possible;
/*      */     }
/*      */     
/*      */     private Possible<Integer> approximateMemberCount_build() {
/* 5131 */       return this.approximateMemberCount_possible;
/*      */     }
/*      */     
/*      */     private Possible<Integer> approximatePresenceCount_build() {
/* 5135 */       return this.approximatePresenceCount_possible;
/*      */     }
/*      */     
/*      */     private Possible<WelcomeScreenData> welcomeScreen_build() {
/* 5139 */       return this.welcomeScreen_possible;
/*      */     }
/*      */     
/*      */     private Possible<Boolean> nsfw_build() {
/* 5143 */       return this.nsfw_possible;
/*      */     }
/*      */     
/*      */     private Optional<Id> safetyAlertsChannelId_build() {
/* 5147 */       return this.safetyAlertsChannelId_optional;
/*      */     }
/*      */     private Builder() {} }
/*      */   
/*      */   private static <T> List<T> createSafeList(Iterable<? extends T> iterable, boolean checkNulls, boolean skipNulls) {
/*      */     ArrayList<T> list;
/* 5153 */     if (iterable instanceof Collection) {
/* 5154 */       int size = ((Collection)iterable).size();
/* 5155 */       if (size == 0) return Collections.emptyList(); 
/* 5156 */       list = new ArrayList<>();
/*      */     } else {
/* 5158 */       list = new ArrayList<>();
/*      */     } 
/* 5160 */     for (T element : iterable) {
/* 5161 */       if (skipNulls && element == null)
/* 5162 */         continue;  if (checkNulls) Objects.requireNonNull(element, "element"); 
/* 5163 */       list.add(element);
/*      */     } 
/* 5165 */     return list;
/*      */   }
/*      */   
/*      */   private static <T> List<T> createUnmodifiableList(boolean clone, List<T> list) {
/* 5169 */     switch (list.size()) { case 0:
/* 5170 */         return Collections.emptyList();
/* 5171 */       case 1: return Collections.singletonList(list.get(0)); }
/*      */     
/* 5173 */     if (clone) {
/* 5174 */       return Collections.unmodifiableList(new ArrayList<>(list));
/*      */     }
/* 5176 */     if (list instanceof ArrayList) {
/* 5177 */       ((ArrayList)list).trimToSize();
/*      */     }
/* 5179 */     return Collections.unmodifiableList(list);
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutablePartialGuildData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */