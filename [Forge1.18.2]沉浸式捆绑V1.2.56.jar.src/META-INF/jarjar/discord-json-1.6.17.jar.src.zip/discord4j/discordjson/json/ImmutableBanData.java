/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "BanData", generator = "Immutables")
/*     */ public final class ImmutableBanData
/*     */   implements BanData
/*     */ {
/*     */   private final String reason;
/*     */   private final UserData user;
/*     */   
/*     */   private ImmutableBanData(Optional<String> reason, UserData user) {
/*  29 */     this.reason = reason.orElse(null);
/*  30 */     this.user = Objects.<UserData>requireNonNull(user, "user");
/*     */   }
/*     */   
/*     */   private ImmutableBanData(ImmutableBanData original, String reason, UserData user) {
/*  34 */     this.reason = reason;
/*  35 */     this.user = user;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("reason")
/*     */   public Optional<String> reason() {
/*  44 */     return Optional.ofNullable(this.reason);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("user")
/*     */   public UserData user() {
/*  53 */     return this.user;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableBanData withReason(String value) {
/*  62 */     String newValue = Objects.<String>requireNonNull(value, "reason");
/*  63 */     if (Objects.equals(this.reason, newValue)) return this; 
/*  64 */     return new ImmutableBanData(this, newValue, this.user);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableBanData withReason(Optional<String> optional) {
/*  74 */     String value = optional.orElse(null);
/*  75 */     if (Objects.equals(this.reason, value)) return this; 
/*  76 */     return new ImmutableBanData(this, value, this.user);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableBanData withUser(UserData value) {
/*  86 */     if (this.user == value) return this; 
/*  87 */     UserData newValue = Objects.<UserData>requireNonNull(value, "user");
/*  88 */     return new ImmutableBanData(this, this.reason, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/*  97 */     if (this == another) return true; 
/*  98 */     return (another instanceof ImmutableBanData && 
/*  99 */       equalTo(0, (ImmutableBanData)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableBanData another) {
/* 103 */     return (Objects.equals(this.reason, another.reason) && this.user
/* 104 */       .equals(another.user));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 113 */     int h = 5381;
/* 114 */     h += (h << 5) + Objects.hashCode(this.reason);
/* 115 */     h += (h << 5) + this.user.hashCode();
/* 116 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 125 */     StringBuilder builder = new StringBuilder("BanData{");
/* 126 */     if (this.reason != null) {
/* 127 */       builder.append("reason=").append(this.reason);
/*     */     }
/* 129 */     if (builder.length() > 8) builder.append(", "); 
/* 130 */     builder.append("user=").append(this.user);
/* 131 */     return builder.append("}").toString();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "BanData", generator = "Immutables")
/*     */   static final class Json
/*     */     implements BanData
/*     */   {
/* 143 */     Optional<String> reason = Optional.empty(); UserData user;
/*     */     
/*     */     @JsonProperty("reason")
/*     */     public void setReason(Optional<String> reason) {
/* 147 */       this.reason = reason;
/*     */     }
/*     */     @JsonProperty("user")
/*     */     public void setUser(UserData user) {
/* 151 */       this.user = user;
/*     */     }
/*     */     public Optional<String> reason() {
/* 154 */       throw new UnsupportedOperationException();
/*     */     } public UserData user() {
/* 156 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableBanData fromJson(Json json) {
/* 167 */     Builder builder = builder();
/* 168 */     if (json.reason != null) {
/* 169 */       builder.reason(json.reason);
/*     */     }
/* 171 */     if (json.user != null) {
/* 172 */       builder.user(json.user);
/*     */     }
/* 174 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableBanData of(Optional<String> reason, UserData user) {
/* 184 */     return new ImmutableBanData(reason, user);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableBanData copyOf(BanData instance) {
/* 195 */     if (instance instanceof ImmutableBanData) {
/* 196 */       return (ImmutableBanData)instance;
/*     */     }
/* 198 */     return builder()
/* 199 */       .from(instance)
/* 200 */       .build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 214 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "BanData", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_USER = 1L;
/*     */ 
/*     */ 
/*     */     
/* 227 */     private long initBits = 1L;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private String reason;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private UserData user;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(BanData instance) {
/* 243 */       Objects.requireNonNull(instance, "instance");
/* 244 */       Optional<String> reasonOptional = instance.reason();
/* 245 */       if (reasonOptional.isPresent()) {
/* 246 */         reason(reasonOptional);
/*     */       }
/* 248 */       user(instance.user());
/* 249 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder reason(String reason) {
/* 258 */       this.reason = Objects.<String>requireNonNull(reason, "reason");
/* 259 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("reason")
/*     */     public final Builder reason(Optional<String> reason) {
/* 269 */       this.reason = reason.orElse(null);
/* 270 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("user")
/*     */     public final Builder user(UserData user) {
/* 280 */       this.user = Objects.<UserData>requireNonNull(user, "user");
/* 281 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 282 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableBanData build() {
/* 291 */       if (this.initBits != 0L) {
/* 292 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 294 */       return new ImmutableBanData(null, this.reason, this.user);
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 298 */       List<String> attributes = new ArrayList<>();
/* 299 */       if ((this.initBits & 0x1L) != 0L) attributes.add("user"); 
/* 300 */       return "Cannot build BanData, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableBanData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */