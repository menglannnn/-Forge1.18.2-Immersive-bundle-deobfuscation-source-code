/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "AuthorizationCodeGrantRequest", generator = "Immutables")
/*     */ public final class ImmutableAuthorizationCodeGrantRequest
/*     */   extends AuthorizationCodeGrantRequest
/*     */ {
/*     */   private final long clientId;
/*     */   private final String clientSecret;
/*     */   private final String code;
/*     */   private final String redirectUri;
/*     */   
/*     */   private ImmutableAuthorizationCodeGrantRequest(long clientId, String clientSecret, String code, String redirectUri) {
/*  27 */     this.clientId = clientId;
/*  28 */     this.clientSecret = Objects.<String>requireNonNull(clientSecret, "clientSecret");
/*  29 */     this.code = Objects.<String>requireNonNull(code, "code");
/*  30 */     this.redirectUri = Objects.<String>requireNonNull(redirectUri, "redirectUri");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ImmutableAuthorizationCodeGrantRequest(ImmutableAuthorizationCodeGrantRequest original, long clientId, String clientSecret, String code, String redirectUri) {
/*  39 */     this.clientId = clientId;
/*  40 */     this.clientSecret = clientSecret;
/*  41 */     this.code = code;
/*  42 */     this.redirectUri = redirectUri;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long clientId() {
/*  50 */     return this.clientId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String clientSecret() {
/*  58 */     return this.clientSecret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String code() {
/*  66 */     return this.code;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String redirectUri() {
/*  74 */     return this.redirectUri;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableAuthorizationCodeGrantRequest withClientId(long value) {
/*  84 */     if (this.clientId == value) return this; 
/*  85 */     return new ImmutableAuthorizationCodeGrantRequest(this, value, this.clientSecret, this.code, this.redirectUri);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableAuthorizationCodeGrantRequest withClientSecret(String value) {
/*  95 */     String newValue = Objects.<String>requireNonNull(value, "clientSecret");
/*  96 */     if (this.clientSecret.equals(newValue)) return this; 
/*  97 */     return new ImmutableAuthorizationCodeGrantRequest(this, this.clientId, newValue, this.code, this.redirectUri);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableAuthorizationCodeGrantRequest withCode(String value) {
/* 107 */     String newValue = Objects.<String>requireNonNull(value, "code");
/* 108 */     if (this.code.equals(newValue)) return this; 
/* 109 */     return new ImmutableAuthorizationCodeGrantRequest(this, this.clientId, this.clientSecret, newValue, this.redirectUri);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableAuthorizationCodeGrantRequest withRedirectUri(String value) {
/* 119 */     String newValue = Objects.<String>requireNonNull(value, "redirectUri");
/* 120 */     if (this.redirectUri.equals(newValue)) return this; 
/* 121 */     return new ImmutableAuthorizationCodeGrantRequest(this, this.clientId, this.clientSecret, this.code, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 130 */     if (this == another) return true; 
/* 131 */     return (another instanceof ImmutableAuthorizationCodeGrantRequest && 
/* 132 */       equalTo(0, (ImmutableAuthorizationCodeGrantRequest)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableAuthorizationCodeGrantRequest another) {
/* 136 */     return (this.clientId == another.clientId && this.clientSecret
/* 137 */       .equals(another.clientSecret) && this.code
/* 138 */       .equals(another.code) && this.redirectUri
/* 139 */       .equals(another.redirectUri));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 148 */     int h = 5381;
/* 149 */     h += (h << 5) + Long.hashCode(this.clientId);
/* 150 */     h += (h << 5) + this.clientSecret.hashCode();
/* 151 */     h += (h << 5) + this.code.hashCode();
/* 152 */     h += (h << 5) + this.redirectUri.hashCode();
/* 153 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableAuthorizationCodeGrantRequest of(long clientId, String clientSecret, String code, String redirectUri) {
/* 165 */     return new ImmutableAuthorizationCodeGrantRequest(clientId, clientSecret, code, redirectUri);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableAuthorizationCodeGrantRequest copyOf(AuthorizationCodeGrantRequest instance) {
/* 176 */     if (instance instanceof ImmutableAuthorizationCodeGrantRequest) {
/* 177 */       return (ImmutableAuthorizationCodeGrantRequest)instance;
/*     */     }
/* 179 */     return builder()
/* 180 */       .from(instance)
/* 181 */       .build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 197 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "AuthorizationCodeGrantRequest", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_CLIENT_ID = 1L;
/*     */     
/*     */     private static final long INIT_BIT_CLIENT_SECRET = 2L;
/*     */     
/*     */     private static final long INIT_BIT_CODE = 4L;
/*     */     
/*     */     private static final long INIT_BIT_REDIRECT_URI = 8L;
/*     */     
/* 213 */     private long initBits = 15L;
/*     */ 
/*     */ 
/*     */     
/*     */     private long clientId;
/*     */ 
/*     */     
/*     */     private String clientSecret;
/*     */ 
/*     */     
/*     */     private String code;
/*     */ 
/*     */     
/*     */     private String redirectUri;
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(AuthorizationCodeGrantRequest instance) {
/* 231 */       Objects.requireNonNull(instance, "instance");
/* 232 */       clientId(instance.clientId());
/* 233 */       clientSecret(instance.clientSecret());
/* 234 */       code(instance.code());
/* 235 */       redirectUri(instance.redirectUri());
/* 236 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder clientId(long clientId) {
/* 245 */       this.clientId = clientId;
/* 246 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 247 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder clientSecret(String clientSecret) {
/* 256 */       this.clientSecret = Objects.<String>requireNonNull(clientSecret, "clientSecret");
/* 257 */       this.initBits &= 0xFFFFFFFFFFFFFFFDL;
/* 258 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder code(String code) {
/* 267 */       this.code = Objects.<String>requireNonNull(code, "code");
/* 268 */       this.initBits &= 0xFFFFFFFFFFFFFFFBL;
/* 269 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder redirectUri(String redirectUri) {
/* 278 */       this.redirectUri = Objects.<String>requireNonNull(redirectUri, "redirectUri");
/* 279 */       this.initBits &= 0xFFFFFFFFFFFFFFF7L;
/* 280 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableAuthorizationCodeGrantRequest build() {
/* 289 */       if (this.initBits != 0L) {
/* 290 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 292 */       return new ImmutableAuthorizationCodeGrantRequest(null, this.clientId, this.clientSecret, this.code, this.redirectUri);
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 296 */       List<String> attributes = new ArrayList<>();
/* 297 */       if ((this.initBits & 0x1L) != 0L) attributes.add("clientId"); 
/* 298 */       if ((this.initBits & 0x2L) != 0L) attributes.add("clientSecret"); 
/* 299 */       if ((this.initBits & 0x4L) != 0L) attributes.add("code"); 
/* 300 */       if ((this.initBits & 0x8L) != 0L) attributes.add("redirectUri"); 
/* 301 */       return "Cannot build AuthorizationCodeGrantRequest, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableAuthorizationCodeGrantRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */