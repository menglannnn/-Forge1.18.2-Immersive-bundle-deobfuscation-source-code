/*    */ package discord4j.discordjson.json;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonProperty;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ @JsonSerialize(as = ImmutableEmbedVideoData.class)
/*    */ @JsonDeserialize(as = ImmutableEmbedVideoData.class)
/*    */ @Immutable
/*    */ public interface EmbedVideoData
/*    */ {
/*    */   static ImmutableEmbedVideoData.Builder builder() {
/* 15 */     return ImmutableEmbedVideoData.builder();
/*    */   }
/*    */   
/*    */   Possible<String> url();
/*    */   
/*    */   @JsonProperty("proxy_url")
/*    */   Possible<String> proxyUrl();
/*    */   
/*    */   Possible<Integer> height();
/*    */   
/*    */   Possible<Integer> width();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\EmbedVideoData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */