/*    */ package discord4j.discordjson.json;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonProperty;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ @JsonSerialize(as = ImmutableActivityAssetsData.class)
/*    */ @JsonDeserialize(as = ImmutableActivityAssetsData.class)
/*    */ @Immutable
/*    */ public interface ActivityAssetsData
/*    */ {
/*    */   static ImmutableActivityAssetsData.Builder builder() {
/* 15 */     return ImmutableActivityAssetsData.builder();
/*    */   }
/*    */   
/*    */   @JsonProperty("large_image")
/*    */   Possible<String> largeImage();
/*    */   
/*    */   @JsonProperty("large_text")
/*    */   Possible<String> largeText();
/*    */   
/*    */   @JsonProperty("small_image")
/*    */   Possible<String> smallImage();
/*    */   
/*    */   @JsonProperty("small_text")
/*    */   Possible<String> smallText();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ActivityAssetsData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */