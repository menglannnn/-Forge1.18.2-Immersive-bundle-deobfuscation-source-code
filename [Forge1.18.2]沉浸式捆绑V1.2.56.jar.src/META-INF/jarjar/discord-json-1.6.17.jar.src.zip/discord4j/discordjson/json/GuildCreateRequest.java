/*    */ package discord4j.discordjson.json;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonProperty;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import discord4j.discordjson.Id;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import java.util.List;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ 
/*    */ 
/*    */ @JsonSerialize(as = ImmutableGuildCreateRequest.class)
/*    */ @JsonDeserialize(as = ImmutableGuildCreateRequest.class)
/*    */ @Immutable
/*    */ public interface GuildCreateRequest
/*    */ {
/*    */   static ImmutableGuildCreateRequest.Builder builder() {
/* 19 */     return ImmutableGuildCreateRequest.builder();
/*    */   }
/*    */   
/*    */   String name();
/*    */   
/*    */   Possible<String> region();
/*    */   
/*    */   Possible<String> icon();
/*    */   
/*    */   @JsonProperty("verification_level")
/*    */   Possible<Integer> verificationLevel();
/*    */   
/*    */   @JsonProperty("default_message_notifications")
/*    */   Possible<Integer> defaultMessageNotifications();
/*    */   
/*    */   @JsonProperty("explicit_content_filter")
/*    */   Possible<Integer> explicitContentFilter();
/*    */   
/*    */   Possible<List<RoleCreateRequest>> roles();
/*    */   
/*    */   Possible<List<PartialChannelCreateRequest>> channels();
/*    */   
/*    */   @JsonProperty("afk_channel_id")
/*    */   Possible<Id> afkChannelId();
/*    */   
/*    */   @JsonProperty("afk_timeout")
/*    */   Possible<Integer> afkTimeout();
/*    */   
/*    */   @JsonProperty("system_channel_id")
/*    */   Possible<Id> systemChannelId();
/*    */   
/*    */   @JsonProperty("system_channel_flags")
/*    */   Possible<Integer> systemChannelFlags();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\GuildCreateRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */