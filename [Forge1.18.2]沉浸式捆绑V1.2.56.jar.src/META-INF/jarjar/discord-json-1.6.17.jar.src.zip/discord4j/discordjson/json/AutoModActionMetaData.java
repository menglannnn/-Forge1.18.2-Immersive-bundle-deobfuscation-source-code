/*    */ package discord4j.discordjson.json;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonProperty;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import discord4j.discordjson.Id;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ @JsonSerialize(as = ImmutableAutoModActionMetaData.class)
/*    */ @JsonDeserialize(as = ImmutableAutoModActionMetaData.class)
/*    */ @Immutable
/*    */ public interface AutoModActionMetaData
/*    */ {
/*    */   static ImmutableAutoModActionMetaData.Builder builder() {
/* 16 */     return ImmutableAutoModActionMetaData.builder();
/*    */   }
/*    */   
/*    */   @JsonProperty("channel_id")
/*    */   Possible<Id> channelId();
/*    */   
/*    */   @JsonProperty("duration_seconds")
/*    */   Possible<Integer> duration();
/*    */   
/*    */   @JsonProperty("custom_message")
/*    */   Possible<String> customMessage();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\AutoModActionMetaData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */