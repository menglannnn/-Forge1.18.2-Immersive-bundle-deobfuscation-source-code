/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "AccessTokenData", generator = "Immutables")
/*     */ public final class ImmutableAccessTokenData
/*     */   implements AccessTokenData
/*     */ {
/*     */   private final String accessToken;
/*     */   private final String tokenType;
/*     */   private final long expiresIn;
/*     */   private final GuildUpdateData guild_value;
/*     */   private final boolean guild_absent;
/*     */   private final String refreshToken_value;
/*     */   private final boolean refreshToken_absent;
/*     */   private final String scope;
/*     */   private final WebhookData webhook_value;
/*     */   private final boolean webhook_absent;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   private volatile transient InitShim initShim;
/*     */   
/*     */   private ImmutableAccessTokenData(String accessToken, String tokenType, long expiresIn, Possible<GuildUpdateData> guild, Possible<String> refreshToken, String scope, Possible<WebhookData> webhook) {
/*  88 */     this.initShim = new InitShim(); this.accessToken = Objects.<String>requireNonNull(accessToken, "accessToken"); this.tokenType = Objects.<String>requireNonNull(tokenType, "tokenType"); this.expiresIn = expiresIn; Possible<GuildUpdateData> guild$impl = guild; Possible<String> refreshToken$impl = refreshToken; this.scope = Objects.<String>requireNonNull(scope, "scope"); Possible<WebhookData> webhook$impl = webhook; this.guild_value = guild$impl.toOptional().orElse(null); this.guild_absent = guild$impl.isAbsent(); this.refreshToken_value = refreshToken$impl.toOptional().orElse(null); this.refreshToken_absent = refreshToken$impl.isAbsent(); this.webhook_value = webhook$impl.toOptional().orElse(null); this.webhook_absent = webhook$impl.isAbsent(); this.initShim = null; } private ImmutableAccessTokenData(ImmutableAccessTokenData original, String accessToken, String tokenType, long expiresIn, Possible<GuildUpdateData> guild, Possible<String> refreshToken, String scope, Possible<WebhookData> webhook) { this.initShim = new InitShim(); this.accessToken = accessToken; this.tokenType = tokenType; this.expiresIn = expiresIn; Possible<GuildUpdateData> guild$impl = guild; Possible<String> refreshToken$impl = refreshToken; this.scope = scope; Possible<WebhookData> webhook$impl = webhook; this.guild_value = guild$impl.toOptional().orElse(null); this.guild_absent = guild$impl.isAbsent();
/*     */     this.refreshToken_value = refreshToken$impl.toOptional().orElse(null);
/*     */     this.refreshToken_absent = refreshToken$impl.isAbsent();
/*     */     this.webhook_value = webhook$impl.toOptional().orElse(null);
/*     */     this.webhook_absent = webhook$impl.isAbsent();
/*  93 */     this.initShim = null; } @Generated(from = "AccessTokenData", generator = "Immutables") private final class InitShim { private InitShim() {} private String formatInitCycleMessage() { List<String> attributes = new ArrayList<>();
/*  94 */       return "Cannot build AccessTokenData, attribute initializers form cycle " + attributes; }
/*     */      }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("access_token")
/*     */   public String accessToken() {
/* 104 */     return this.accessToken;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("token_type")
/*     */   public String tokenType() {
/* 113 */     return this.tokenType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("expires_in")
/*     */   public long expiresIn() {
/* 122 */     return this.expiresIn;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("guild")
/*     */   public Possible<GuildUpdateData> guild() {
/* 131 */     return this.guild_absent ? Possible.absent() : Possible.of(this.guild_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("refresh_token")
/*     */   public Possible<String> refreshToken() {
/* 140 */     return this.refreshToken_absent ? Possible.absent() : Possible.of(this.refreshToken_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("scope")
/*     */   public String scope() {
/* 149 */     return this.scope;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("webhook")
/*     */   public Possible<WebhookData> webhook() {
/* 158 */     return this.webhook_absent ? Possible.absent() : Possible.of(this.webhook_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableAccessTokenData withAccessToken(String value) {
/* 168 */     String newValue = Objects.<String>requireNonNull(value, "accessToken");
/* 169 */     if (this.accessToken.equals(newValue)) return this; 
/* 170 */     return new ImmutableAccessTokenData(this, newValue, this.tokenType, this.expiresIn, 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 175 */         guild(), 
/* 176 */         refreshToken(), this.scope, 
/*     */         
/* 178 */         webhook());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableAccessTokenData withTokenType(String value) {
/* 188 */     String newValue = Objects.<String>requireNonNull(value, "tokenType");
/* 189 */     if (this.tokenType.equals(newValue)) return this; 
/* 190 */     return new ImmutableAccessTokenData(this, this.accessToken, newValue, this.expiresIn, 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 195 */         guild(), 
/* 196 */         refreshToken(), this.scope, 
/*     */         
/* 198 */         webhook());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableAccessTokenData withExpiresIn(long value) {
/* 208 */     if (this.expiresIn == value) return this; 
/* 209 */     return new ImmutableAccessTokenData(this, this.accessToken, this.tokenType, value, 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 214 */         guild(), 
/* 215 */         refreshToken(), this.scope, 
/*     */         
/* 217 */         webhook());
/*     */   }
/*     */   
/*     */   public ImmutableAccessTokenData withGuild(Possible<GuildUpdateData> value) {
/* 221 */     Possible<GuildUpdateData> newValue = Objects.<Possible<GuildUpdateData>>requireNonNull(value);
/* 222 */     return new ImmutableAccessTokenData(this, this.accessToken, this.tokenType, this.expiresIn, newValue, 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 228 */         refreshToken(), this.scope, 
/*     */         
/* 230 */         webhook());
/*     */   }
/*     */   
/*     */   public ImmutableAccessTokenData withGuild(GuildUpdateData value) {
/* 234 */     Possible<GuildUpdateData> newValue = Possible.of(value);
/* 235 */     return new ImmutableAccessTokenData(this, this.accessToken, this.tokenType, this.expiresIn, newValue, 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 241 */         refreshToken(), this.scope, 
/*     */         
/* 243 */         webhook());
/*     */   }
/*     */   
/*     */   public ImmutableAccessTokenData withRefreshToken(Possible<String> value) {
/* 247 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/* 248 */     return new ImmutableAccessTokenData(this, this.accessToken, this.tokenType, this.expiresIn, 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 253 */         guild(), newValue, this.scope, 
/*     */ 
/*     */         
/* 256 */         webhook());
/*     */   }
/*     */   
/*     */   public ImmutableAccessTokenData withRefreshToken(String value) {
/* 260 */     Possible<String> newValue = Possible.of(value);
/* 261 */     return new ImmutableAccessTokenData(this, this.accessToken, this.tokenType, this.expiresIn, 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 266 */         guild(), newValue, this.scope, 
/*     */ 
/*     */         
/* 269 */         webhook());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableAccessTokenData withScope(String value) {
/* 279 */     String newValue = Objects.<String>requireNonNull(value, "scope");
/* 280 */     if (this.scope.equals(newValue)) return this; 
/* 281 */     return new ImmutableAccessTokenData(this, this.accessToken, this.tokenType, this.expiresIn, 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 286 */         guild(), 
/* 287 */         refreshToken(), newValue, 
/*     */         
/* 289 */         webhook());
/*     */   }
/*     */   
/*     */   public ImmutableAccessTokenData withWebhook(Possible<WebhookData> value) {
/* 293 */     Possible<WebhookData> newValue = Objects.<Possible<WebhookData>>requireNonNull(value);
/* 294 */     return new ImmutableAccessTokenData(this, this.accessToken, this.tokenType, this.expiresIn, 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 299 */         guild(), 
/* 300 */         refreshToken(), this.scope, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ImmutableAccessTokenData withWebhook(WebhookData value) {
/* 306 */     Possible<WebhookData> newValue = Possible.of(value);
/* 307 */     return new ImmutableAccessTokenData(this, this.accessToken, this.tokenType, this.expiresIn, 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 312 */         guild(), 
/* 313 */         refreshToken(), this.scope, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 324 */     if (this == another) return true; 
/* 325 */     return (another instanceof ImmutableAccessTokenData && 
/* 326 */       equalTo(0, (ImmutableAccessTokenData)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableAccessTokenData another) {
/* 330 */     return (this.accessToken.equals(another.accessToken) && this.tokenType
/* 331 */       .equals(another.tokenType) && this.expiresIn == another.expiresIn && 
/*     */       
/* 333 */       guild().equals(another.guild()) && 
/* 334 */       refreshToken().equals(another.refreshToken()) && this.scope
/* 335 */       .equals(another.scope) && 
/* 336 */       webhook().equals(another.webhook()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 345 */     int h = 5381;
/* 346 */     h += (h << 5) + this.accessToken.hashCode();
/* 347 */     h += (h << 5) + this.tokenType.hashCode();
/* 348 */     h += (h << 5) + Long.hashCode(this.expiresIn);
/* 349 */     h += (h << 5) + guild().hashCode();
/* 350 */     h += (h << 5) + refreshToken().hashCode();
/* 351 */     h += (h << 5) + this.scope.hashCode();
/* 352 */     h += (h << 5) + webhook().hashCode();
/* 353 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 362 */     return "AccessTokenData{accessToken=" + this.accessToken + ", tokenType=" + this.tokenType + ", expiresIn=" + this.expiresIn + ", guild=" + 
/*     */ 
/*     */ 
/*     */       
/* 366 */       guild().toString() + ", refreshToken=" + 
/* 367 */       refreshToken().toString() + ", scope=" + this.scope + ", webhook=" + 
/*     */       
/* 369 */       webhook().toString() + "}";
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "AccessTokenData", generator = "Immutables")
/*     */   static final class Json
/*     */     implements AccessTokenData
/*     */   {
/*     */     String accessToken;
/*     */     
/*     */     String tokenType;
/*     */     
/*     */     long expiresIn;
/*     */     
/*     */     boolean expiresInIsSet;
/* 387 */     Possible<GuildUpdateData> guild = Possible.absent();
/*     */ 
/*     */     
/* 390 */     Possible<String> refreshToken = Possible.absent();
/*     */     
/*     */     String scope;
/*     */     
/* 394 */     Possible<WebhookData> webhook = Possible.absent();
/*     */     
/*     */     @JsonProperty("access_token")
/*     */     public void setAccessToken(String accessToken) {
/* 398 */       this.accessToken = accessToken;
/*     */     }
/*     */     @JsonProperty("token_type")
/*     */     public void setTokenType(String tokenType) {
/* 402 */       this.tokenType = tokenType;
/*     */     }
/*     */     @JsonProperty("expires_in")
/*     */     public void setExpiresIn(long expiresIn) {
/* 406 */       this.expiresIn = expiresIn;
/* 407 */       this.expiresInIsSet = true;
/*     */     }
/*     */     @JsonProperty("guild")
/*     */     public void setGuild(Possible<GuildUpdateData> guild) {
/* 411 */       this.guild = guild;
/*     */     }
/*     */     @JsonProperty("refresh_token")
/*     */     public void setRefreshToken(Possible<String> refreshToken) {
/* 415 */       this.refreshToken = refreshToken;
/*     */     }
/*     */     @JsonProperty("scope")
/*     */     public void setScope(String scope) {
/* 419 */       this.scope = scope;
/*     */     }
/*     */     @JsonProperty("webhook")
/*     */     public void setWebhook(Possible<WebhookData> webhook) {
/* 423 */       this.webhook = webhook;
/*     */     }
/*     */     public String accessToken() {
/* 426 */       throw new UnsupportedOperationException();
/*     */     } public String tokenType() {
/* 428 */       throw new UnsupportedOperationException();
/*     */     } public long expiresIn() {
/* 430 */       throw new UnsupportedOperationException();
/*     */     } public Possible<GuildUpdateData> guild() {
/* 432 */       throw new UnsupportedOperationException();
/*     */     } public Possible<String> refreshToken() {
/* 434 */       throw new UnsupportedOperationException();
/*     */     } public String scope() {
/* 436 */       throw new UnsupportedOperationException();
/*     */     } public Possible<WebhookData> webhook() {
/* 438 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableAccessTokenData fromJson(Json json) {
/* 449 */     Builder builder = builder();
/* 450 */     if (json.accessToken != null) {
/* 451 */       builder.accessToken(json.accessToken);
/*     */     }
/* 453 */     if (json.tokenType != null) {
/* 454 */       builder.tokenType(json.tokenType);
/*     */     }
/* 456 */     if (json.expiresInIsSet) {
/* 457 */       builder.expiresIn(json.expiresIn);
/*     */     }
/* 459 */     if (json.guild != null) {
/* 460 */       builder.guild(json.guild);
/*     */     }
/* 462 */     if (json.refreshToken != null) {
/* 463 */       builder.refreshToken(json.refreshToken);
/*     */     }
/* 465 */     if (json.scope != null) {
/* 466 */       builder.scope(json.scope);
/*     */     }
/* 468 */     if (json.webhook != null) {
/* 469 */       builder.webhook(json.webhook);
/*     */     }
/* 471 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableAccessTokenData of(String accessToken, String tokenType, long expiresIn, Possible<GuildUpdateData> guild, Possible<String> refreshToken, String scope, Possible<WebhookData> webhook) {
/* 486 */     return new ImmutableAccessTokenData(accessToken, tokenType, expiresIn, guild, refreshToken, scope, webhook);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableAccessTokenData copyOf(AccessTokenData instance) {
/* 497 */     if (instance instanceof ImmutableAccessTokenData) {
/* 498 */       return (ImmutableAccessTokenData)instance;
/*     */     }
/* 500 */     return builder()
/* 501 */       .from(instance)
/* 502 */       .build();
/*     */   }
/*     */   
/*     */   public boolean isGuildPresent() {
/* 506 */     return !this.guild_absent;
/*     */   }
/*     */   
/*     */   public GuildUpdateData guildOrElse(GuildUpdateData defaultValue) {
/* 510 */     return !this.guild_absent ? this.guild_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isRefreshTokenPresent() {
/* 514 */     return !this.refreshToken_absent;
/*     */   }
/*     */   
/*     */   public String refreshTokenOrElse(String defaultValue) {
/* 518 */     return !this.refreshToken_absent ? this.refreshToken_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isWebhookPresent() {
/* 522 */     return !this.webhook_absent;
/*     */   }
/*     */   
/*     */   public WebhookData webhookOrElse(WebhookData defaultValue) {
/* 526 */     return !this.webhook_absent ? this.webhook_value : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 545 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "AccessTokenData", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_ACCESS_TOKEN = 1L;
/*     */     
/*     */     private static final long INIT_BIT_TOKEN_TYPE = 2L;
/*     */     
/*     */     private static final long INIT_BIT_EXPIRES_IN = 4L;
/*     */     
/*     */     private static final long INIT_BIT_SCOPE = 8L;
/*     */     
/* 561 */     private long initBits = 15L;
/*     */     
/* 563 */     private Possible<GuildUpdateData> guild_possible = Possible.absent();
/* 564 */     private Possible<String> refreshToken_possible = Possible.absent();
/* 565 */     private Possible<WebhookData> webhook_possible = Possible.absent();
/*     */ 
/*     */     
/*     */     private String accessToken;
/*     */ 
/*     */     
/*     */     private String tokenType;
/*     */ 
/*     */     
/*     */     private long expiresIn;
/*     */ 
/*     */     
/*     */     private String scope;
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(AccessTokenData instance) {
/* 582 */       Objects.requireNonNull(instance, "instance");
/* 583 */       accessToken(instance.accessToken());
/* 584 */       tokenType(instance.tokenType());
/* 585 */       expiresIn(instance.expiresIn());
/* 586 */       guild(instance.guild());
/* 587 */       refreshToken(instance.refreshToken());
/* 588 */       scope(instance.scope());
/* 589 */       webhook(instance.webhook());
/* 590 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("access_token")
/*     */     public final Builder accessToken(String accessToken) {
/* 600 */       this.accessToken = Objects.<String>requireNonNull(accessToken, "accessToken");
/* 601 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 602 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("token_type")
/*     */     public final Builder tokenType(String tokenType) {
/* 612 */       this.tokenType = Objects.<String>requireNonNull(tokenType, "tokenType");
/* 613 */       this.initBits &= 0xFFFFFFFFFFFFFFFDL;
/* 614 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("expires_in")
/*     */     public final Builder expiresIn(long expiresIn) {
/* 624 */       this.expiresIn = expiresIn;
/* 625 */       this.initBits &= 0xFFFFFFFFFFFFFFFBL;
/* 626 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("guild")
/*     */     public Builder guild(Possible<GuildUpdateData> value) {
/* 631 */       this.guild_possible = value;
/* 632 */       return this;
/*     */     }
/*     */     
/*     */     public Builder guild(GuildUpdateData value) {
/* 636 */       this.guild_possible = Possible.of(value);
/* 637 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("refresh_token")
/*     */     public Builder refreshToken(Possible<String> value) {
/* 642 */       this.refreshToken_possible = value;
/* 643 */       return this;
/*     */     }
/*     */     
/*     */     public Builder refreshToken(String value) {
/* 647 */       this.refreshToken_possible = Possible.of(value);
/* 648 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("scope")
/*     */     public final Builder scope(String scope) {
/* 658 */       this.scope = Objects.<String>requireNonNull(scope, "scope");
/* 659 */       this.initBits &= 0xFFFFFFFFFFFFFFF7L;
/* 660 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("webhook")
/*     */     public Builder webhook(Possible<WebhookData> value) {
/* 665 */       this.webhook_possible = value;
/* 666 */       return this;
/*     */     }
/*     */     
/*     */     public Builder webhook(WebhookData value) {
/* 670 */       this.webhook_possible = Possible.of(value);
/* 671 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableAccessTokenData build() {
/* 680 */       if (this.initBits != 0L) {
/* 681 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 683 */       return new ImmutableAccessTokenData(null, this.accessToken, this.tokenType, this.expiresIn, 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 688 */           guild_build(), 
/* 689 */           refreshToken_build(), this.scope, 
/*     */           
/* 691 */           webhook_build());
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 695 */       List<String> attributes = new ArrayList<>();
/* 696 */       if ((this.initBits & 0x1L) != 0L) attributes.add("accessToken"); 
/* 697 */       if ((this.initBits & 0x2L) != 0L) attributes.add("tokenType"); 
/* 698 */       if ((this.initBits & 0x4L) != 0L) attributes.add("expiresIn"); 
/* 699 */       if ((this.initBits & 0x8L) != 0L) attributes.add("scope"); 
/* 700 */       return "Cannot build AccessTokenData, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Possible<GuildUpdateData> guild_build() {
/* 704 */       return this.guild_possible;
/*     */     }
/*     */     
/*     */     private Possible<String> refreshToken_build() {
/* 708 */       return this.refreshToken_possible;
/*     */     }
/*     */     
/*     */     private Possible<WebhookData> webhook_build() {
/* 712 */       return this.webhook_possible;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableAccessTokenData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */