/*    */ package discord4j.discordjson.json;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonProperty;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import discord4j.discordjson.Id;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import java.util.List;
/*    */ import java.util.Optional;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ 
/*    */ @JsonSerialize(as = ImmutableEmojiData.class)
/*    */ @JsonDeserialize(as = ImmutableEmojiData.class)
/*    */ @Immutable
/*    */ public interface EmojiData
/*    */ {
/*    */   static ImmutableEmojiData.Builder builder() {
/* 19 */     return ImmutableEmojiData.builder();
/*    */   }
/*    */   
/*    */   Optional<Id> id();
/*    */   
/*    */   Optional<String> name();
/*    */   
/*    */   Possible<List<String>> roles();
/*    */   
/*    */   Possible<UserData> user();
/*    */   
/*    */   @JsonProperty("require_colons")
/*    */   Possible<Boolean> requireColons();
/*    */   
/*    */   Possible<Boolean> managed();
/*    */   
/*    */   Possible<Boolean> available();
/*    */   
/*    */   Possible<Boolean> animated();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\EmojiData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */