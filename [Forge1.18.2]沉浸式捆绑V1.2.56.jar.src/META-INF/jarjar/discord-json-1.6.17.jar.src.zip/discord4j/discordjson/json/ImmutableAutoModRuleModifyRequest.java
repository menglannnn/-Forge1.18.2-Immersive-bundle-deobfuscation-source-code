/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.Id;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.stream.LongStream;
/*     */ import java.util.stream.StreamSupport;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "AutoModRuleModifyRequest", generator = "Immutables")
/*     */ public final class ImmutableAutoModRuleModifyRequest
/*     */   implements AutoModRuleModifyRequest
/*     */ {
/*     */   private final String name;
/*     */   private final int eventType;
/*     */   private final AutoModTriggerMetaData triggerMetadata_value;
/*     */   private final boolean triggerMetadata_absent;
/*     */   private final List<AutoModActionData> actions;
/*     */   private final boolean enabled;
/*     */   private final long[] exemptRoles_value;
/*     */   private final long[] exemptChannels_value;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   private volatile transient InitShim initShim;
/*     */   
/*     */   private ImmutableAutoModRuleModifyRequest(String name, int eventType, Possible<AutoModTriggerMetaData> triggerMetadata, Iterable<? extends AutoModActionData> actions, boolean enabled, List<Id> exemptRoles, List<Id> exemptChannels) {
/*  98 */     this.initShim = new InitShim(); this.name = Objects.<String>requireNonNull(name, "name"); this.eventType = eventType; Possible<AutoModTriggerMetaData> triggerMetadata$impl = triggerMetadata; this.actions = createUnmodifiableList(false, createSafeList(actions, true, false)); this.enabled = enabled; List<Id> exemptRoles$impl = exemptRoles; List<Id> exemptChannels$impl = exemptChannels; this.triggerMetadata_value = triggerMetadata$impl.toOptional().orElse(null); this.triggerMetadata_absent = triggerMetadata$impl.isAbsent(); this.exemptRoles_value = exemptRoles$impl.stream().mapToLong(Id::asLong).toArray(); this.exemptChannels_value = exemptChannels$impl.stream().mapToLong(Id::asLong).toArray(); this.initShim = null; } private ImmutableAutoModRuleModifyRequest(ImmutableAutoModRuleModifyRequest original, String name, int eventType, Possible<AutoModTriggerMetaData> triggerMetadata, List<AutoModActionData> actions, boolean enabled, List<Id> exemptRoles, List<Id> exemptChannels) { this.initShim = new InitShim(); this.name = name; this.eventType = eventType; Possible<AutoModTriggerMetaData> triggerMetadata$impl = triggerMetadata; this.actions = actions; this.enabled = enabled; List<Id> exemptRoles$impl = exemptRoles; List<Id> exemptChannels$impl = exemptChannels;
/*     */     this.triggerMetadata_value = triggerMetadata$impl.toOptional().orElse(null);
/*     */     this.triggerMetadata_absent = triggerMetadata$impl.isAbsent();
/*     */     this.exemptRoles_value = exemptRoles$impl.stream().mapToLong(Id::asLong).toArray();
/*     */     this.exemptChannels_value = exemptChannels$impl.stream().mapToLong(Id::asLong).toArray();
/* 103 */     this.initShim = null; } @Generated(from = "AutoModRuleModifyRequest", generator = "Immutables") private final class InitShim { private InitShim() {} private String formatInitCycleMessage() { List<String> attributes = new ArrayList<>();
/* 104 */       return "Cannot build AutoModRuleModifyRequest, attribute initializers form cycle " + attributes; }
/*     */      }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("name")
/*     */   public String name() {
/* 114 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("event_type")
/*     */   public int eventType() {
/* 123 */     return this.eventType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("trigger_metadata")
/*     */   public Possible<AutoModTriggerMetaData> triggerMetadata() {
/* 132 */     return this.triggerMetadata_absent ? Possible.absent() : Possible.of(this.triggerMetadata_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("actions")
/*     */   public List<AutoModActionData> actions() {
/* 141 */     return this.actions;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("enabled")
/*     */   public boolean enabled() {
/* 150 */     return this.enabled;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("exempt_roles")
/*     */   public List<Id> exemptRoles() {
/* 159 */     return (List<Id>)LongStream.of(this.exemptRoles_value)
/* 160 */       .mapToObj(Id::of)
/* 161 */       .collect(Collectors.toList());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("exempt_channels")
/*     */   public List<Id> exemptChannels() {
/* 170 */     return (List<Id>)LongStream.of(this.exemptChannels_value)
/* 171 */       .mapToObj(Id::of)
/* 172 */       .collect(Collectors.toList());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableAutoModRuleModifyRequest withName(String value) {
/* 182 */     String newValue = Objects.<String>requireNonNull(value, "name");
/* 183 */     if (this.name.equals(newValue)) return this; 
/* 184 */     return new ImmutableAutoModRuleModifyRequest(this, newValue, this.eventType, 
/*     */ 
/*     */ 
/*     */         
/* 188 */         triggerMetadata(), this.actions, this.enabled, 
/*     */ 
/*     */         
/* 191 */         exemptRoles(), 
/* 192 */         exemptChannels());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableAutoModRuleModifyRequest withEventType(int value) {
/* 202 */     if (this.eventType == value) return this; 
/* 203 */     return new ImmutableAutoModRuleModifyRequest(this, this.name, value, 
/*     */ 
/*     */ 
/*     */         
/* 207 */         triggerMetadata(), this.actions, this.enabled, 
/*     */ 
/*     */         
/* 210 */         exemptRoles(), 
/* 211 */         exemptChannels());
/*     */   }
/*     */   
/*     */   public ImmutableAutoModRuleModifyRequest withTriggerMetadata(Possible<AutoModTriggerMetaData> value) {
/* 215 */     Possible<AutoModTriggerMetaData> newValue = Objects.<Possible<AutoModTriggerMetaData>>requireNonNull(value);
/* 216 */     return new ImmutableAutoModRuleModifyRequest(this, this.name, this.eventType, newValue, this.actions, this.enabled, 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 223 */         exemptRoles(), 
/* 224 */         exemptChannels());
/*     */   }
/*     */   
/*     */   public ImmutableAutoModRuleModifyRequest withTriggerMetadata(AutoModTriggerMetaData value) {
/* 228 */     Possible<AutoModTriggerMetaData> newValue = Possible.of(value);
/* 229 */     return new ImmutableAutoModRuleModifyRequest(this, this.name, this.eventType, newValue, this.actions, this.enabled, 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 236 */         exemptRoles(), 
/* 237 */         exemptChannels());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableAutoModRuleModifyRequest withActions(AutoModActionData... elements) {
/* 246 */     List<AutoModActionData> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/* 247 */     return new ImmutableAutoModRuleModifyRequest(this, this.name, this.eventType, 
/*     */ 
/*     */ 
/*     */         
/* 251 */         triggerMetadata(), newValue, this.enabled, 
/*     */ 
/*     */         
/* 254 */         exemptRoles(), 
/* 255 */         exemptChannels());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableAutoModRuleModifyRequest withActions(Iterable<? extends AutoModActionData> elements) {
/* 265 */     if (this.actions == elements) return this; 
/* 266 */     List<AutoModActionData> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/* 267 */     return new ImmutableAutoModRuleModifyRequest(this, this.name, this.eventType, 
/*     */ 
/*     */ 
/*     */         
/* 271 */         triggerMetadata(), newValue, this.enabled, 
/*     */ 
/*     */         
/* 274 */         exemptRoles(), 
/* 275 */         exemptChannels());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableAutoModRuleModifyRequest withEnabled(boolean value) {
/* 285 */     if (this.enabled == value) return this; 
/* 286 */     return new ImmutableAutoModRuleModifyRequest(this, this.name, this.eventType, 
/*     */ 
/*     */ 
/*     */         
/* 290 */         triggerMetadata(), this.actions, value, 
/*     */ 
/*     */         
/* 293 */         exemptRoles(), 
/* 294 */         exemptChannels());
/*     */   }
/*     */   
/*     */   public ImmutableAutoModRuleModifyRequest withExemptRoles(List<Id> value) {
/* 298 */     List<Id> newValue = value;
/* 299 */     return new ImmutableAutoModRuleModifyRequest(this, this.name, this.eventType, 
/*     */ 
/*     */ 
/*     */         
/* 303 */         triggerMetadata(), this.actions, this.enabled, newValue, 
/*     */ 
/*     */ 
/*     */         
/* 307 */         exemptChannels());
/*     */   }
/*     */   
/*     */   public ImmutableAutoModRuleModifyRequest withExemptChannels(List<Id> value) {
/* 311 */     List<Id> newValue = value;
/* 312 */     return new ImmutableAutoModRuleModifyRequest(this, this.name, this.eventType, 
/*     */ 
/*     */ 
/*     */         
/* 316 */         triggerMetadata(), this.actions, this.enabled, 
/*     */ 
/*     */         
/* 319 */         exemptRoles(), newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 329 */     if (this == another) return true; 
/* 330 */     return (another instanceof ImmutableAutoModRuleModifyRequest && 
/* 331 */       equalTo(0, (ImmutableAutoModRuleModifyRequest)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableAutoModRuleModifyRequest another) {
/* 335 */     return (this.name.equals(another.name) && this.eventType == another.eventType && 
/*     */       
/* 337 */       triggerMetadata().equals(another.triggerMetadata()) && this.actions
/* 338 */       .equals(another.actions) && this.enabled == another.enabled && 
/*     */       
/* 340 */       Objects.equals(this.exemptRoles_value, another.exemptRoles_value) && 
/* 341 */       Objects.equals(this.exemptChannels_value, another.exemptChannels_value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 350 */     int h = 5381;
/* 351 */     h += (h << 5) + this.name.hashCode();
/* 352 */     h += (h << 5) + this.eventType;
/* 353 */     h += (h << 5) + triggerMetadata().hashCode();
/* 354 */     h += (h << 5) + this.actions.hashCode();
/* 355 */     h += (h << 5) + Boolean.hashCode(this.enabled);
/* 356 */     h += (h << 5) + Objects.hashCode(this.exemptRoles_value);
/* 357 */     h += (h << 5) + Objects.hashCode(this.exemptChannels_value);
/* 358 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 367 */     return "AutoModRuleModifyRequest{name=" + this.name + ", eventType=" + this.eventType + ", triggerMetadata=" + 
/*     */ 
/*     */       
/* 370 */       triggerMetadata().toString() + ", actions=" + this.actions + ", enabled=" + this.enabled + ", exemptRoles=" + 
/*     */ 
/*     */       
/* 373 */       Objects.toString(this.exemptRoles_value) + ", exemptChannels=" + 
/* 374 */       Objects.toString(this.exemptChannels_value) + "}";
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "AutoModRuleModifyRequest", generator = "Immutables")
/*     */   static final class Json
/*     */     implements AutoModRuleModifyRequest
/*     */   {
/*     */     String name;
/*     */     
/*     */     int eventType;
/*     */     
/*     */     boolean eventTypeIsSet;
/*     */     
/* 391 */     Possible<AutoModTriggerMetaData> triggerMetadata = Possible.absent();
/*     */     
/* 393 */     List<AutoModActionData> actions = Collections.emptyList(); boolean enabled;
/*     */     boolean enabledIsSet;
/*     */     List<Id> exemptRoles;
/*     */     List<Id> exemptChannels;
/*     */     
/*     */     @JsonProperty("name")
/*     */     public void setName(String name) {
/* 400 */       this.name = name;
/*     */     }
/*     */     @JsonProperty("event_type")
/*     */     public void setEventType(int eventType) {
/* 404 */       this.eventType = eventType;
/* 405 */       this.eventTypeIsSet = true;
/*     */     }
/*     */     @JsonProperty("trigger_metadata")
/*     */     public void setTriggerMetadata(Possible<AutoModTriggerMetaData> triggerMetadata) {
/* 409 */       this.triggerMetadata = triggerMetadata;
/*     */     }
/*     */     @JsonProperty("actions")
/*     */     public void setActions(List<AutoModActionData> actions) {
/* 413 */       this.actions = actions;
/*     */     }
/*     */     @JsonProperty("enabled")
/*     */     public void setEnabled(boolean enabled) {
/* 417 */       this.enabled = enabled;
/* 418 */       this.enabledIsSet = true;
/*     */     }
/*     */     @JsonProperty("exempt_roles")
/*     */     public void setExemptRoles(List<Id> exemptRoles) {
/* 422 */       this.exemptRoles = exemptRoles;
/*     */     }
/*     */     @JsonProperty("exempt_channels")
/*     */     public void setExemptChannels(List<Id> exemptChannels) {
/* 426 */       this.exemptChannels = exemptChannels;
/*     */     }
/*     */     public String name() {
/* 429 */       throw new UnsupportedOperationException();
/*     */     } public int eventType() {
/* 431 */       throw new UnsupportedOperationException();
/*     */     } public Possible<AutoModTriggerMetaData> triggerMetadata() {
/* 433 */       throw new UnsupportedOperationException();
/*     */     } public List<AutoModActionData> actions() {
/* 435 */       throw new UnsupportedOperationException();
/*     */     } public boolean enabled() {
/* 437 */       throw new UnsupportedOperationException();
/*     */     } public List<Id> exemptRoles() {
/* 439 */       throw new UnsupportedOperationException();
/*     */     } public List<Id> exemptChannels() {
/* 441 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableAutoModRuleModifyRequest fromJson(Json json) {
/* 452 */     Builder builder = builder();
/* 453 */     if (json.name != null) {
/* 454 */       builder.name(json.name);
/*     */     }
/* 456 */     if (json.eventTypeIsSet) {
/* 457 */       builder.eventType(json.eventType);
/*     */     }
/* 459 */     if (json.triggerMetadata != null) {
/* 460 */       builder.triggerMetadata(json.triggerMetadata);
/*     */     }
/* 462 */     if (json.actions != null) {
/* 463 */       builder.addAllActions(json.actions);
/*     */     }
/* 465 */     if (json.enabledIsSet) {
/* 466 */       builder.enabled(json.enabled);
/*     */     }
/* 468 */     if (json.exemptRoles != null) {
/* 469 */       builder.exemptRoles(json.exemptRoles);
/*     */     }
/* 471 */     if (json.exemptChannels != null) {
/* 472 */       builder.exemptChannels(json.exemptChannels);
/*     */     }
/* 474 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableAutoModRuleModifyRequest of(String name, int eventType, Possible<AutoModTriggerMetaData> triggerMetadata, List<AutoModActionData> actions, boolean enabled, List<Id> exemptRoles, List<Id> exemptChannels) {
/* 489 */     return of(name, eventType, triggerMetadata, actions, enabled, exemptRoles, exemptChannels);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableAutoModRuleModifyRequest of(String name, int eventType, Possible<AutoModTriggerMetaData> triggerMetadata, Iterable<? extends AutoModActionData> actions, boolean enabled, List<Id> exemptRoles, List<Id> exemptChannels) {
/* 504 */     return new ImmutableAutoModRuleModifyRequest(name, eventType, triggerMetadata, actions, enabled, exemptRoles, exemptChannels);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableAutoModRuleModifyRequest copyOf(AutoModRuleModifyRequest instance) {
/* 515 */     if (instance instanceof ImmutableAutoModRuleModifyRequest) {
/* 516 */       return (ImmutableAutoModRuleModifyRequest)instance;
/*     */     }
/* 518 */     return builder()
/* 519 */       .from(instance)
/* 520 */       .build();
/*     */   }
/*     */   
/*     */   public boolean isTriggerMetadataPresent() {
/* 524 */     return !this.triggerMetadata_absent;
/*     */   }
/*     */   
/*     */   public AutoModTriggerMetaData triggerMetadataOrElse(AutoModTriggerMetaData defaultValue) {
/* 528 */     return !this.triggerMetadata_absent ? this.triggerMetadata_value : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 547 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "AutoModRuleModifyRequest", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_NAME = 1L;
/*     */ 
/*     */     
/*     */     private static final long INIT_BIT_EVENT_TYPE = 2L;
/*     */     
/*     */     private static final long INIT_BIT_ENABLED = 4L;
/*     */     
/* 562 */     private long initBits = 7L;
/*     */     
/* 564 */     private Possible<AutoModTriggerMetaData> triggerMetadata_possible = Possible.absent();
/* 565 */     private List<Long> exemptRoles_list = null;
/* 566 */     private List<Long> exemptChannels_list = null;
/*     */     private String name;
/*     */     private int eventType;
/* 569 */     private List<AutoModActionData> actions = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private boolean enabled;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(AutoModRuleModifyRequest instance) {
/* 584 */       Objects.requireNonNull(instance, "instance");
/* 585 */       name(instance.name());
/* 586 */       eventType(instance.eventType());
/* 587 */       triggerMetadata(instance.triggerMetadata());
/* 588 */       addAllActions(instance.actions());
/* 589 */       enabled(instance.enabled());
/* 590 */       exemptRoles(instance.exemptRoles());
/* 591 */       exemptChannels(instance.exemptChannels());
/* 592 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("name")
/*     */     public final Builder name(String name) {
/* 602 */       this.name = Objects.<String>requireNonNull(name, "name");
/* 603 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 604 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("event_type")
/*     */     public final Builder eventType(int eventType) {
/* 614 */       this.eventType = eventType;
/* 615 */       this.initBits &= 0xFFFFFFFFFFFFFFFDL;
/* 616 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("trigger_metadata")
/*     */     public Builder triggerMetadata(Possible<AutoModTriggerMetaData> value) {
/* 621 */       this.triggerMetadata_possible = value;
/* 622 */       return this;
/*     */     }
/*     */     
/*     */     public Builder triggerMetadata(AutoModTriggerMetaData value) {
/* 626 */       this.triggerMetadata_possible = Possible.of(value);
/* 627 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder addAction(AutoModActionData element) {
/* 636 */       this.actions.add(Objects.<AutoModActionData>requireNonNull(element, "actions element"));
/* 637 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder addActions(AutoModActionData... elements) {
/* 646 */       for (AutoModActionData element : elements) {
/* 647 */         this.actions.add(Objects.<AutoModActionData>requireNonNull(element, "actions element"));
/*     */       }
/* 649 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("actions")
/*     */     public final Builder actions(Iterable<? extends AutoModActionData> elements) {
/* 660 */       this.actions.clear();
/* 661 */       return addAllActions(elements);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder addAllActions(Iterable<? extends AutoModActionData> elements) {
/* 670 */       for (AutoModActionData element : elements) {
/* 671 */         this.actions.add(Objects.<AutoModActionData>requireNonNull(element, "actions element"));
/*     */       }
/* 673 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("enabled")
/*     */     public final Builder enabled(boolean enabled) {
/* 683 */       this.enabled = enabled;
/* 684 */       this.initBits &= 0xFFFFFFFFFFFFFFFBL;
/* 685 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addExemptRole(long element) {
/* 689 */       exemptRoles_getOrCreate().add(Long.valueOf(element));
/* 690 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addExemptRole(String element) {
/* 694 */       exemptRoles_getOrCreate().add(Long.valueOf(Id.of(element).asLong()));
/* 695 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addExemptRole(Id element) {
/* 699 */       exemptRoles_getOrCreate().add(Long.valueOf(element.asLong()));
/* 700 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addAllExemptRoles(List<Long> elements) {
/* 704 */       exemptRoles_getOrCreate().addAll(elements);
/* 705 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("exempt_roles")
/*     */     public Builder exemptRoles(List<Id> elements) {
/* 710 */       this.exemptRoles_list = (List<Long>)elements.stream().map(Id::asLong).collect(Collectors.toList());
/* 711 */       return this;
/*     */     }
/*     */     
/*     */     public Builder exemptRoles(Iterable<Id> elements) {
/* 715 */       this
/*     */         
/* 717 */         .exemptRoles_list = (List<Long>)StreamSupport.stream(elements.spliterator(), false).map(Id::asLong).collect(Collectors.toList());
/* 718 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addExemptChannel(long element) {
/* 722 */       exemptChannels_getOrCreate().add(Long.valueOf(element));
/* 723 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addExemptChannel(String element) {
/* 727 */       exemptChannels_getOrCreate().add(Long.valueOf(Id.of(element).asLong()));
/* 728 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addExemptChannel(Id element) {
/* 732 */       exemptChannels_getOrCreate().add(Long.valueOf(element.asLong()));
/* 733 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addAllExemptChannels(List<Long> elements) {
/* 737 */       exemptChannels_getOrCreate().addAll(elements);
/* 738 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("exempt_channels")
/*     */     public Builder exemptChannels(List<Id> elements) {
/* 743 */       this.exemptChannels_list = (List<Long>)elements.stream().map(Id::asLong).collect(Collectors.toList());
/* 744 */       return this;
/*     */     }
/*     */     
/*     */     public Builder exemptChannels(Iterable<Id> elements) {
/* 748 */       this
/*     */         
/* 750 */         .exemptChannels_list = (List<Long>)StreamSupport.stream(elements.spliterator(), false).map(Id::asLong).collect(Collectors.toList());
/* 751 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableAutoModRuleModifyRequest build() {
/* 760 */       if (this.initBits != 0L) {
/* 761 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 763 */       return new ImmutableAutoModRuleModifyRequest(null, this.name, this.eventType, 
/*     */ 
/*     */ 
/*     */           
/* 767 */           triggerMetadata_build(), ImmutableAutoModRuleModifyRequest
/* 768 */           .createUnmodifiableList(true, (List)this.actions), this.enabled, 
/*     */           
/* 770 */           exemptRoles_build(), 
/* 771 */           exemptChannels_build());
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 775 */       List<String> attributes = new ArrayList<>();
/* 776 */       if ((this.initBits & 0x1L) != 0L) attributes.add("name"); 
/* 777 */       if ((this.initBits & 0x2L) != 0L) attributes.add("eventType"); 
/* 778 */       if ((this.initBits & 0x4L) != 0L) attributes.add("enabled"); 
/* 779 */       return "Cannot build AutoModRuleModifyRequest, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Possible<AutoModTriggerMetaData> triggerMetadata_build() {
/* 783 */       return this.triggerMetadata_possible;
/*     */     }
/*     */     
/*     */     private List<Id> exemptRoles_build() {
/* 787 */       return (List<Id>)exemptRoles_getOrCreate().stream().map(Id::of).collect(Collectors.toList());
/*     */     }
/*     */     
/*     */     private List<Long> exemptRoles_getOrCreate() {
/* 791 */       if (this.exemptRoles_list == null) {
/* 792 */         this.exemptRoles_list = new ArrayList<>();
/*     */       }
/* 794 */       return this.exemptRoles_list;
/*     */     }
/*     */     
/*     */     private List<Id> exemptChannels_build() {
/* 798 */       return (List<Id>)exemptChannels_getOrCreate().stream().map(Id::of).collect(Collectors.toList());
/*     */     }
/*     */     
/*     */     private List<Long> exemptChannels_getOrCreate() {
/* 802 */       if (this.exemptChannels_list == null) {
/* 803 */         this.exemptChannels_list = new ArrayList<>();
/*     */       }
/* 805 */       return this.exemptChannels_list;
/*     */     }
/*     */     private Builder() {} }
/*     */   
/*     */   private static <T> List<T> createSafeList(Iterable<? extends T> iterable, boolean checkNulls, boolean skipNulls) {
/*     */     ArrayList<T> list;
/* 811 */     if (iterable instanceof Collection) {
/* 812 */       int size = ((Collection)iterable).size();
/* 813 */       if (size == 0) return Collections.emptyList(); 
/* 814 */       list = new ArrayList<>();
/*     */     } else {
/* 816 */       list = new ArrayList<>();
/*     */     } 
/* 818 */     for (T element : iterable) {
/* 819 */       if (skipNulls && element == null)
/* 820 */         continue;  if (checkNulls) Objects.requireNonNull(element, "element"); 
/* 821 */       list.add(element);
/*     */     } 
/* 823 */     return list;
/*     */   }
/*     */   
/*     */   private static <T> List<T> createUnmodifiableList(boolean clone, List<T> list) {
/* 827 */     switch (list.size()) { case 0:
/* 828 */         return Collections.emptyList();
/* 829 */       case 1: return Collections.singletonList(list.get(0)); }
/*     */     
/* 831 */     if (clone) {
/* 832 */       return Collections.unmodifiableList(new ArrayList<>(list));
/*     */     }
/* 834 */     if (list instanceof ArrayList) {
/* 835 */       ((ArrayList)list).trimToSize();
/*     */     }
/* 837 */     return Collections.unmodifiableList(list);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableAutoModRuleModifyRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */