/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "InteractionResponseData", generator = "Immutables")
/*     */ public final class ImmutableInteractionResponseData
/*     */   implements InteractionResponseData
/*     */ {
/*     */   private final int type;
/*     */   private final InteractionApplicationCommandCallbackData data_value;
/*     */   private final boolean data_absent;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   private volatile transient InitShim initShim;
/*     */   
/*     */   private ImmutableInteractionResponseData(int type, Possible<InteractionApplicationCommandCallbackData> data) {
/*  54 */     this.initShim = new InitShim(); this.type = type; Possible<InteractionApplicationCommandCallbackData> data$impl = data; this.data_value = data$impl.toOptional().orElse(null); this.data_absent = data$impl.isAbsent(); this.initShim = null; } private ImmutableInteractionResponseData(ImmutableInteractionResponseData original, int type, Possible<InteractionApplicationCommandCallbackData> data) { this.initShim = new InitShim();
/*     */     this.type = type;
/*     */     Possible<InteractionApplicationCommandCallbackData> data$impl = data;
/*     */     this.data_value = data$impl.toOptional().orElse(null);
/*     */     this.data_absent = data$impl.isAbsent();
/*  59 */     this.initShim = null; } @Generated(from = "InteractionResponseData", generator = "Immutables") private final class InitShim { private InitShim() {} private String formatInitCycleMessage() { List<String> attributes = new ArrayList<>();
/*  60 */       return "Cannot build InteractionResponseData, attribute initializers form cycle " + attributes; }
/*     */      }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("type")
/*     */   public int type() {
/*  70 */     return this.type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("data")
/*     */   public Possible<InteractionApplicationCommandCallbackData> data() {
/*  79 */     return this.data_absent ? Possible.absent() : Possible.of(this.data_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableInteractionResponseData withType(int value) {
/*  89 */     if (this.type == value) return this; 
/*  90 */     return new ImmutableInteractionResponseData(this, value, data());
/*     */   }
/*     */   
/*     */   public ImmutableInteractionResponseData withData(Possible<InteractionApplicationCommandCallbackData> value) {
/*  94 */     Possible<InteractionApplicationCommandCallbackData> newValue = Objects.<Possible<InteractionApplicationCommandCallbackData>>requireNonNull(value);
/*  95 */     return new ImmutableInteractionResponseData(this, this.type, newValue);
/*     */   }
/*     */   
/*     */   public ImmutableInteractionResponseData withData(InteractionApplicationCommandCallbackData value) {
/*  99 */     Possible<InteractionApplicationCommandCallbackData> newValue = Possible.of(value);
/* 100 */     return new ImmutableInteractionResponseData(this, this.type, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 109 */     if (this == another) return true; 
/* 110 */     return (another instanceof ImmutableInteractionResponseData && 
/* 111 */       equalTo(0, (ImmutableInteractionResponseData)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableInteractionResponseData another) {
/* 115 */     return (this.type == another.type && 
/* 116 */       data().equals(another.data()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 125 */     int h = 5381;
/* 126 */     h += (h << 5) + this.type;
/* 127 */     h += (h << 5) + data().hashCode();
/* 128 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 137 */     return "InteractionResponseData{type=" + this.type + ", data=" + 
/*     */       
/* 139 */       data().toString() + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "InteractionResponseData", generator = "Immutables")
/*     */   static final class Json
/*     */     implements InteractionResponseData
/*     */   {
/*     */     int type;
/*     */     
/*     */     boolean typeIsSet;
/*     */     
/* 155 */     Possible<InteractionApplicationCommandCallbackData> data = Possible.absent();
/*     */     
/*     */     @JsonProperty("type")
/*     */     public void setType(int type) {
/* 159 */       this.type = type;
/* 160 */       this.typeIsSet = true;
/*     */     }
/*     */     @JsonProperty("data")
/*     */     public void setData(Possible<InteractionApplicationCommandCallbackData> data) {
/* 164 */       this.data = data;
/*     */     }
/*     */     public int type() {
/* 167 */       throw new UnsupportedOperationException();
/*     */     } public Possible<InteractionApplicationCommandCallbackData> data() {
/* 169 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableInteractionResponseData fromJson(Json json) {
/* 180 */     Builder builder = builder();
/* 181 */     if (json.typeIsSet) {
/* 182 */       builder.type(json.type);
/*     */     }
/* 184 */     if (json.data != null) {
/* 185 */       builder.data(json.data);
/*     */     }
/* 187 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableInteractionResponseData of(int type, Possible<InteractionApplicationCommandCallbackData> data) {
/* 197 */     return new ImmutableInteractionResponseData(type, data);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableInteractionResponseData copyOf(InteractionResponseData instance) {
/* 208 */     if (instance instanceof ImmutableInteractionResponseData) {
/* 209 */       return (ImmutableInteractionResponseData)instance;
/*     */     }
/* 211 */     return builder()
/* 212 */       .from(instance)
/* 213 */       .build();
/*     */   }
/*     */   
/*     */   public boolean isDataPresent() {
/* 217 */     return !this.data_absent;
/*     */   }
/*     */   
/*     */   public InteractionApplicationCommandCallbackData dataOrElse(InteractionApplicationCommandCallbackData defaultValue) {
/* 221 */     return !this.data_absent ? this.data_value : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 235 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "InteractionResponseData", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_TYPE = 1L;
/*     */ 
/*     */ 
/*     */     
/* 248 */     private long initBits = 1L;
/*     */     
/* 250 */     private Possible<InteractionApplicationCommandCallbackData> data_possible = Possible.absent();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private int type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(InteractionResponseData instance) {
/* 264 */       Objects.requireNonNull(instance, "instance");
/* 265 */       type(instance.type());
/* 266 */       data(instance.data());
/* 267 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("type")
/*     */     public final Builder type(int type) {
/* 277 */       this.type = type;
/* 278 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 279 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("data")
/*     */     public Builder data(Possible<InteractionApplicationCommandCallbackData> value) {
/* 284 */       this.data_possible = value;
/* 285 */       return this;
/*     */     }
/*     */     
/*     */     public Builder data(InteractionApplicationCommandCallbackData value) {
/* 289 */       this.data_possible = Possible.of(value);
/* 290 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableInteractionResponseData build() {
/* 299 */       if (this.initBits != 0L) {
/* 300 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 302 */       return new ImmutableInteractionResponseData(null, this.type, data_build());
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 306 */       List<String> attributes = new ArrayList<>();
/* 307 */       if ((this.initBits & 0x1L) != 0L) attributes.add("type"); 
/* 308 */       return "Cannot build InteractionResponseData, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Possible<InteractionApplicationCommandCallbackData> data_build() {
/* 312 */       return this.data_possible;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableInteractionResponseData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */