/*    */ package discord4j.discordjson.json;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonProperty;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import discord4j.discordjson.Id;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import java.util.Optional;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ @JsonSerialize(as = ImmutableActivityData.class)
/*    */ @JsonDeserialize(as = ImmutableActivityData.class)
/*    */ @Immutable
/*    */ public interface ActivityData
/*    */   extends Activity
/*    */ {
/*    */   static ImmutableActivityData.Builder builder() {
/* 18 */     return ImmutableActivityData.builder();
/*    */   }
/*    */   
/*    */   String id();
/*    */   
/*    */   Possible<Optional<String>> url();
/*    */   
/*    */   @JsonProperty("created_at")
/*    */   long createdAt();
/*    */   
/*    */   Possible<ActivityTimestampsData> timestamps();
/*    */   
/*    */   @JsonProperty("application_id")
/*    */   Possible<Id> applicationId();
/*    */   
/*    */   Possible<Optional<String>> details();
/*    */   
/*    */   Possible<Optional<String>> state();
/*    */   
/*    */   Possible<Optional<ActivityEmojiData>> emoji();
/*    */   
/*    */   Possible<ActivityPartyData> party();
/*    */   
/*    */   Possible<ActivityAssetsData> assets();
/*    */   
/*    */   Possible<ActivitySecretsData> secrets();
/*    */   
/*    */   Possible<Boolean> instance();
/*    */   
/*    */   Possible<Integer> flags();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ActivityData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */