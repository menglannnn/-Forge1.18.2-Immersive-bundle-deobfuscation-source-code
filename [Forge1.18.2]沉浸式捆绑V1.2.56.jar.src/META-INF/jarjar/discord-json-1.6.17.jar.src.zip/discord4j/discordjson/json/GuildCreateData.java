/*    */ package discord4j.discordjson.json;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonProperty;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import java.util.List;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ @JsonSerialize(as = ImmutableGuildCreateData.class)
/*    */ @JsonDeserialize(as = ImmutableGuildCreateData.class)
/*    */ @Immutable
/*    */ public interface GuildCreateData
/*    */   extends GuildCreateFields, GuildRolesEmojisStickersFields
/*    */ {
/*    */   static ImmutableGuildCreateData.Builder builder() {
/* 16 */     return ImmutableGuildCreateData.builder();
/*    */   }
/*    */   
/*    */   @JsonProperty("voice_states")
/*    */   List<VoiceStateData> voiceStates();
/*    */   
/*    */   List<MemberData> members();
/*    */   
/*    */   List<ChannelData> channels();
/*    */   
/*    */   List<PresenceData> presences();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\GuildCreateData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */