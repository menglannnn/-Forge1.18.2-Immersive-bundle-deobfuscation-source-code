/*    */ package discord4j.discordjson.json;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonProperty;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import discord4j.discordjson.Id;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import java.time.Instant;
/*    */ import java.util.Optional;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ 
/*    */ 
/*    */ @JsonSerialize(as = ImmutableGuildScheduledEventData.class)
/*    */ @JsonDeserialize(as = ImmutableGuildScheduledEventData.class)
/*    */ @Immutable
/*    */ public interface GuildScheduledEventData
/*    */ {
/*    */   static ImmutableGuildScheduledEventData.Builder builder() {
/* 20 */     return ImmutableGuildScheduledEventData.builder();
/*    */   }
/*    */   
/*    */   Id id();
/*    */   
/*    */   @JsonProperty("guild_id")
/*    */   Id guildId();
/*    */   
/*    */   @JsonProperty("channel_id")
/*    */   Optional<Id> channelId();
/*    */   
/*    */   @JsonProperty("creator_id")
/*    */   Optional<Id> creatorId();
/*    */   
/*    */   String name();
/*    */   
/*    */   Possible<String> description();
/*    */   
/*    */   @JsonProperty("scheduled_start_time")
/*    */   Instant scheduledStartTime();
/*    */   
/*    */   @JsonProperty("scheduled_end_time")
/*    */   Optional<Instant> scheduledEndTime();
/*    */   
/*    */   @JsonProperty("privacy_level")
/*    */   int privacyLevel();
/*    */   
/*    */   int status();
/*    */   
/*    */   @JsonProperty("entity_type")
/*    */   int entityType();
/*    */   
/*    */   @JsonProperty("entity_id")
/*    */   Optional<Id> entityId();
/*    */   
/*    */   @JsonProperty("entity_metadata")
/*    */   Optional<GuildScheduledEventEntityMetadataData> entityMetadata();
/*    */   
/*    */   Possible<UserData> creator();
/*    */   
/*    */   @JsonProperty("user_count")
/*    */   Possible<Integer> userCount();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\GuildScheduledEventData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */