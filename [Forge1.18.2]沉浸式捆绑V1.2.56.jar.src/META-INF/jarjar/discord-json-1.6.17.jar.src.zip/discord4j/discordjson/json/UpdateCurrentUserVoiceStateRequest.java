/*    */ package discord4j.discordjson.json;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonProperty;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import java.util.Optional;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ 
/*    */ @JsonSerialize(as = ImmutableUpdateCurrentUserVoiceStateRequest.class)
/*    */ @JsonDeserialize(as = ImmutableUpdateCurrentUserVoiceStateRequest.class)
/*    */ @Immutable
/*    */ public interface UpdateCurrentUserVoiceStateRequest
/*    */ {
/*    */   static ImmutableUpdateCurrentUserVoiceStateRequest.Builder builder() {
/* 17 */     return ImmutableUpdateCurrentUserVoiceStateRequest.builder();
/*    */   }
/*    */   
/*    */   @JsonProperty("channel_id")
/*    */   String channelId();
/*    */   
/*    */   Possible<Boolean> suppress();
/*    */   
/*    */   @JsonProperty("request_to_speak_timestamp")
/*    */   Possible<Optional<String>> requestToSpeakTimestamp();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\UpdateCurrentUserVoiceStateRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */