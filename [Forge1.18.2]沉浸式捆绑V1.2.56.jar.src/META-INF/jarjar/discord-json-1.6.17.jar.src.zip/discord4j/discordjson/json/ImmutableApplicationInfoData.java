/*      */ package discord4j.discordjson.json;
/*      */ 
/*      */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*      */ import com.fasterxml.jackson.annotation.JsonCreator;
/*      */ import com.fasterxml.jackson.annotation.JsonProperty;
/*      */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*      */ import discord4j.discordjson.Id;
/*      */ import discord4j.discordjson.possible.Possible;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.List;
/*      */ import java.util.Objects;
/*      */ import java.util.Optional;
/*      */ import java.util.stream.Collectors;
/*      */ import java.util.stream.StreamSupport;
/*      */ import org.immutables.value.Generated;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ @Generated(from = "ApplicationInfoData", generator = "Immutables")
/*      */ public final class ImmutableApplicationInfoData
/*      */   implements ApplicationInfoData
/*      */ {
/*      */   private final long id_value;
/*      */   private final String name;
/*      */   private final String icon;
/*      */   private final String description;
/*      */   private final List<String> rpcOrigins_value;
/*      */   private final boolean rpcOrigins_absent;
/*      */   private final boolean botPublic;
/*      */   private final boolean botRequireCodeGrant;
/*      */   private final String termsOfServiceUrl_value;
/*      */   private final boolean termsOfServiceUrl_absent;
/*      */   private final String privacyPolicyUrl_value;
/*      */   private final boolean privacyPolicyUrl_absent;
/*      */   private final UserData owner;
/*      */   private final String summary;
/*      */   private final String verifyKey;
/*      */   private final ApplicationTeamData team;
/*      */   private final long guildId_value;
/*      */   private final boolean guildId_absent;
/*      */   private final long primarySkuId_value;
/*      */   private final boolean primarySkuId_absent;
/*      */   private final String slug_value;
/*      */   private final boolean slug_absent;
/*      */   private final String coverImage_value;
/*      */   private final boolean coverImage_absent;
/*      */   private final Integer flags_value;
/*      */   private final boolean flags_absent;
/*      */   private static final byte STAGE_INITIALIZING = -1;
/*      */   private static final byte STAGE_UNINITIALIZED = 0;
/*      */   private static final byte STAGE_INITIALIZED = 1;
/*      */   
/*      */   private ImmutableApplicationInfoData(Id id, String name, Optional<String> icon, String description, Possible<List<String>> rpcOrigins, boolean botPublic, boolean botRequireCodeGrant, Possible<String> termsOfServiceUrl, Possible<String> privacyPolicyUrl, UserData owner, String summary, String verifyKey, Optional<? extends ApplicationTeamData> team, Possible<Id> guildId, Possible<Id> primarySkuId, Possible<String> slug, Possible<String> coverImage, Possible<Integer> flags) {
/*   77 */     Id id$impl = id;
/*   78 */     this.name = Objects.<String>requireNonNull(name, "name");
/*   79 */     this.icon = icon.orElse(null);
/*   80 */     this.description = Objects.<String>requireNonNull(description, "description");
/*   81 */     Possible<List<String>> rpcOrigins$impl = rpcOrigins;
/*   82 */     this.botPublic = botPublic;
/*   83 */     this.botRequireCodeGrant = botRequireCodeGrant;
/*   84 */     Possible<String> termsOfServiceUrl$impl = termsOfServiceUrl;
/*   85 */     Possible<String> privacyPolicyUrl$impl = privacyPolicyUrl;
/*   86 */     this.owner = Objects.<UserData>requireNonNull(owner, "owner");
/*   87 */     this.summary = Objects.<String>requireNonNull(summary, "summary");
/*   88 */     this.verifyKey = Objects.<String>requireNonNull(verifyKey, "verifyKey");
/*   89 */     this.team = team.orElse(null);
/*   90 */     Possible<Id> guildId$impl = guildId;
/*   91 */     Possible<Id> primarySkuId$impl = primarySkuId;
/*   92 */     Possible<String> slug$impl = slug;
/*   93 */     Possible<String> coverImage$impl = coverImage;
/*   94 */     Possible<Integer> flags$impl = flags;
/*   95 */     this.id_value = id$impl.asLong();
/*   96 */     this.rpcOrigins_value = rpcOrigins$impl.toOptional().orElse(null);
/*   97 */     this.rpcOrigins_absent = rpcOrigins$impl.isAbsent();
/*   98 */     this.termsOfServiceUrl_value = termsOfServiceUrl$impl.toOptional().orElse(null);
/*   99 */     this.termsOfServiceUrl_absent = termsOfServiceUrl$impl.isAbsent();
/*  100 */     this.privacyPolicyUrl_value = privacyPolicyUrl$impl.toOptional().orElse(null);
/*  101 */     this.privacyPolicyUrl_absent = privacyPolicyUrl$impl.isAbsent();
/*  102 */     this
/*      */       
/*  104 */       .guildId_value = ((Long)guildId$impl.toOptional().map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  105 */     this.guildId_absent = guildId$impl.isAbsent();
/*  106 */     this
/*      */       
/*  108 */       .primarySkuId_value = ((Long)primarySkuId$impl.toOptional().map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  109 */     this.primarySkuId_absent = primarySkuId$impl.isAbsent();
/*  110 */     this.slug_value = slug$impl.toOptional().orElse(null);
/*  111 */     this.slug_absent = slug$impl.isAbsent();
/*  112 */     this.coverImage_value = coverImage$impl.toOptional().orElse(null);
/*  113 */     this.coverImage_absent = coverImage$impl.isAbsent();
/*  114 */     this.flags_value = flags$impl.toOptional().orElse(null);
/*  115 */     this.flags_absent = flags$impl.isAbsent();
/*  116 */     this.initShim = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ImmutableApplicationInfoData(ImmutableApplicationInfoData original, Id id, String name, String icon, String description, Possible<List<String>> rpcOrigins, boolean botPublic, boolean botRequireCodeGrant, Possible<String> termsOfServiceUrl, Possible<String> privacyPolicyUrl, UserData owner, String summary, String verifyKey, ApplicationTeamData team, Possible<Id> guildId, Possible<Id> primarySkuId, Possible<String> slug, Possible<String> coverImage, Possible<Integer> flags) {
/*  139 */     Id id$impl = id;
/*  140 */     this.name = name;
/*  141 */     this.icon = icon;
/*  142 */     this.description = description;
/*  143 */     Possible<List<String>> rpcOrigins$impl = rpcOrigins;
/*  144 */     this.botPublic = botPublic;
/*  145 */     this.botRequireCodeGrant = botRequireCodeGrant;
/*  146 */     Possible<String> termsOfServiceUrl$impl = termsOfServiceUrl;
/*  147 */     Possible<String> privacyPolicyUrl$impl = privacyPolicyUrl;
/*  148 */     this.owner = owner;
/*  149 */     this.summary = summary;
/*  150 */     this.verifyKey = verifyKey;
/*  151 */     this.team = team;
/*  152 */     Possible<Id> guildId$impl = guildId;
/*  153 */     Possible<Id> primarySkuId$impl = primarySkuId;
/*  154 */     Possible<String> slug$impl = slug;
/*  155 */     Possible<String> coverImage$impl = coverImage;
/*  156 */     Possible<Integer> flags$impl = flags;
/*  157 */     this.id_value = id$impl.asLong();
/*  158 */     this.rpcOrigins_value = rpcOrigins$impl.toOptional().orElse(null);
/*  159 */     this.rpcOrigins_absent = rpcOrigins$impl.isAbsent();
/*  160 */     this.termsOfServiceUrl_value = termsOfServiceUrl$impl.toOptional().orElse(null);
/*  161 */     this.termsOfServiceUrl_absent = termsOfServiceUrl$impl.isAbsent();
/*  162 */     this.privacyPolicyUrl_value = privacyPolicyUrl$impl.toOptional().orElse(null);
/*  163 */     this.privacyPolicyUrl_absent = privacyPolicyUrl$impl.isAbsent();
/*  164 */     this
/*      */       
/*  166 */       .guildId_value = ((Long)guildId$impl.toOptional().map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  167 */     this.guildId_absent = guildId$impl.isAbsent();
/*  168 */     this
/*      */       
/*  170 */       .primarySkuId_value = ((Long)primarySkuId$impl.toOptional().map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  171 */     this.primarySkuId_absent = primarySkuId$impl.isAbsent();
/*  172 */     this.slug_value = slug$impl.toOptional().orElse(null);
/*  173 */     this.slug_absent = slug$impl.isAbsent();
/*  174 */     this.coverImage_value = coverImage$impl.toOptional().orElse(null);
/*  175 */     this.coverImage_absent = coverImage$impl.isAbsent();
/*  176 */     this.flags_value = flags$impl.toOptional().orElse(null);
/*  177 */     this.flags_absent = flags$impl.isAbsent();
/*  178 */     this.initShim = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  184 */   private volatile transient InitShim initShim = new InitShim();
/*      */   
/*      */   @Generated(from = "ApplicationInfoData", generator = "Immutables")
/*      */   private final class InitShim {
/*      */     private String formatInitCycleMessage() {
/*  189 */       List<String> attributes = new ArrayList<>();
/*  190 */       return "Cannot build ApplicationInfoData, attribute initializers form cycle " + attributes;
/*      */     }
/*      */ 
/*      */     
/*      */     private InitShim() {}
/*      */   }
/*      */ 
/*      */   
/*      */   @JsonProperty("id")
/*      */   public Id id() {
/*  200 */     return Id.of(this.id_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("name")
/*      */   public String name() {
/*  209 */     return this.name;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("icon")
/*      */   public Optional<String> icon() {
/*  218 */     return Optional.ofNullable(this.icon);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("description")
/*      */   public String description() {
/*  227 */     return this.description;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("rpc_origins")
/*      */   public Possible<List<String>> rpcOrigins() {
/*  236 */     return this.rpcOrigins_absent ? Possible.absent() : 
/*  237 */       Possible.of(this.rpcOrigins_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("bot_public")
/*      */   public boolean botPublic() {
/*  246 */     return this.botPublic;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("bot_require_code_grant")
/*      */   public boolean botRequireCodeGrant() {
/*  255 */     return this.botRequireCodeGrant;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("terms_of_service_url")
/*      */   public Possible<String> termsOfServiceUrl() {
/*  264 */     return this.termsOfServiceUrl_absent ? Possible.absent() : Possible.of(this.termsOfServiceUrl_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("privacy_policy_url")
/*      */   public Possible<String> privacyPolicyUrl() {
/*  273 */     return this.privacyPolicyUrl_absent ? Possible.absent() : Possible.of(this.privacyPolicyUrl_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("owner")
/*      */   public UserData owner() {
/*  282 */     return this.owner;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("summary")
/*      */   public String summary() {
/*  291 */     return this.summary;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("verify_key")
/*      */   public String verifyKey() {
/*  300 */     return this.verifyKey;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("team")
/*      */   public Optional<ApplicationTeamData> team() {
/*  309 */     return Optional.ofNullable(this.team);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("guild_id")
/*      */   public Possible<Id> guildId() {
/*  318 */     return this.guildId_absent ? Possible.absent() : 
/*  319 */       Possible.of(Id.of(this.guildId_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("primary_sku_id")
/*      */   public Possible<Id> primarySkuId() {
/*  328 */     return this.primarySkuId_absent ? Possible.absent() : 
/*  329 */       Possible.of(Id.of(this.primarySkuId_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("slug")
/*      */   public Possible<String> slug() {
/*  338 */     return this.slug_absent ? Possible.absent() : Possible.of(this.slug_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("cover_image")
/*      */   public Possible<String> coverImage() {
/*  347 */     return this.coverImage_absent ? Possible.absent() : Possible.of(this.coverImage_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("flags")
/*      */   public Possible<Integer> flags() {
/*  356 */     return this.flags_absent ? Possible.absent() : Possible.of(this.flags_value);
/*      */   }
/*      */   
/*      */   public ImmutableApplicationInfoData withId(long value) {
/*  360 */     Id newValue = Id.of(value);
/*  361 */     return new ImmutableApplicationInfoData(this, newValue, this.name, this.icon, this.description, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  367 */         rpcOrigins(), this.botPublic, this.botRequireCodeGrant, 
/*      */ 
/*      */         
/*  370 */         termsOfServiceUrl(), 
/*  371 */         privacyPolicyUrl(), this.owner, this.summary, this.verifyKey, this.team, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  376 */         guildId(), 
/*  377 */         primarySkuId(), 
/*  378 */         slug(), 
/*  379 */         coverImage(), 
/*  380 */         flags());
/*      */   }
/*      */   
/*      */   public ImmutableApplicationInfoData withId(String value) {
/*  384 */     Id newValue = Id.of(value);
/*  385 */     return new ImmutableApplicationInfoData(this, newValue, this.name, this.icon, this.description, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  391 */         rpcOrigins(), this.botPublic, this.botRequireCodeGrant, 
/*      */ 
/*      */         
/*  394 */         termsOfServiceUrl(), 
/*  395 */         privacyPolicyUrl(), this.owner, this.summary, this.verifyKey, this.team, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  400 */         guildId(), 
/*  401 */         primarySkuId(), 
/*  402 */         slug(), 
/*  403 */         coverImage(), 
/*  404 */         flags());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableApplicationInfoData withName(String value) {
/*  414 */     String newValue = Objects.<String>requireNonNull(value, "name");
/*  415 */     if (this.name.equals(newValue)) return this; 
/*  416 */     return new ImmutableApplicationInfoData(this, 
/*      */         
/*  418 */         id(), newValue, this.icon, this.description, 
/*      */ 
/*      */ 
/*      */         
/*  422 */         rpcOrigins(), this.botPublic, this.botRequireCodeGrant, 
/*      */ 
/*      */         
/*  425 */         termsOfServiceUrl(), 
/*  426 */         privacyPolicyUrl(), this.owner, this.summary, this.verifyKey, this.team, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  431 */         guildId(), 
/*  432 */         primarySkuId(), 
/*  433 */         slug(), 
/*  434 */         coverImage(), 
/*  435 */         flags());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableApplicationInfoData withIcon(String value) {
/*  444 */     String newValue = Objects.<String>requireNonNull(value, "icon");
/*  445 */     if (Objects.equals(this.icon, newValue)) return this; 
/*  446 */     return new ImmutableApplicationInfoData(this, 
/*      */         
/*  448 */         id(), this.name, newValue, this.description, 
/*      */ 
/*      */ 
/*      */         
/*  452 */         rpcOrigins(), this.botPublic, this.botRequireCodeGrant, 
/*      */ 
/*      */         
/*  455 */         termsOfServiceUrl(), 
/*  456 */         privacyPolicyUrl(), this.owner, this.summary, this.verifyKey, this.team, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  461 */         guildId(), 
/*  462 */         primarySkuId(), 
/*  463 */         slug(), 
/*  464 */         coverImage(), 
/*  465 */         flags());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableApplicationInfoData withIcon(Optional<String> optional) {
/*  475 */     String value = optional.orElse(null);
/*  476 */     if (Objects.equals(this.icon, value)) return this; 
/*  477 */     return new ImmutableApplicationInfoData(this, 
/*      */         
/*  479 */         id(), this.name, value, this.description, 
/*      */ 
/*      */ 
/*      */         
/*  483 */         rpcOrigins(), this.botPublic, this.botRequireCodeGrant, 
/*      */ 
/*      */         
/*  486 */         termsOfServiceUrl(), 
/*  487 */         privacyPolicyUrl(), this.owner, this.summary, this.verifyKey, this.team, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  492 */         guildId(), 
/*  493 */         primarySkuId(), 
/*  494 */         slug(), 
/*  495 */         coverImage(), 
/*  496 */         flags());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableApplicationInfoData withDescription(String value) {
/*  506 */     String newValue = Objects.<String>requireNonNull(value, "description");
/*  507 */     if (this.description.equals(newValue)) return this; 
/*  508 */     return new ImmutableApplicationInfoData(this, 
/*      */         
/*  510 */         id(), this.name, this.icon, newValue, 
/*      */ 
/*      */ 
/*      */         
/*  514 */         rpcOrigins(), this.botPublic, this.botRequireCodeGrant, 
/*      */ 
/*      */         
/*  517 */         termsOfServiceUrl(), 
/*  518 */         privacyPolicyUrl(), this.owner, this.summary, this.verifyKey, this.team, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  523 */         guildId(), 
/*  524 */         primarySkuId(), 
/*  525 */         slug(), 
/*  526 */         coverImage(), 
/*  527 */         flags());
/*      */   }
/*      */   
/*      */   public ImmutableApplicationInfoData withRpcOrigins(Possible<List<String>> possible) {
/*  531 */     Possible<List<String>> newValue = Objects.<Possible<List<String>>>requireNonNull(possible);
/*  532 */     return new ImmutableApplicationInfoData(this, 
/*      */         
/*  534 */         id(), this.name, this.icon, this.description, newValue, this.botPublic, this.botRequireCodeGrant, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  541 */         termsOfServiceUrl(), 
/*  542 */         privacyPolicyUrl(), this.owner, this.summary, this.verifyKey, this.team, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  547 */         guildId(), 
/*  548 */         primarySkuId(), 
/*  549 */         slug(), 
/*  550 */         coverImage(), 
/*  551 */         flags());
/*      */   }
/*      */   
/*      */   public ImmutableApplicationInfoData withRpcOrigins(Iterable<String> elements) {
/*  555 */     Possible<List<String>> newValue = Possible.of(
/*  556 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/*  557 */     return new ImmutableApplicationInfoData(this, 
/*      */         
/*  559 */         id(), this.name, this.icon, this.description, newValue, this.botPublic, this.botRequireCodeGrant, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  566 */         termsOfServiceUrl(), 
/*  567 */         privacyPolicyUrl(), this.owner, this.summary, this.verifyKey, this.team, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  572 */         guildId(), 
/*  573 */         primarySkuId(), 
/*  574 */         slug(), 
/*  575 */         coverImage(), 
/*  576 */         flags());
/*      */   }
/*      */   
/*      */   @SafeVarargs
/*      */   public final ImmutableApplicationInfoData withRpcOrigins(String... elements) {
/*  581 */     Possible<List<String>> newValue = Possible.of(Arrays.asList(elements));
/*  582 */     return new ImmutableApplicationInfoData(this, 
/*      */         
/*  584 */         id(), this.name, this.icon, this.description, newValue, this.botPublic, this.botRequireCodeGrant, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  591 */         termsOfServiceUrl(), 
/*  592 */         privacyPolicyUrl(), this.owner, this.summary, this.verifyKey, this.team, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  597 */         guildId(), 
/*  598 */         primarySkuId(), 
/*  599 */         slug(), 
/*  600 */         coverImage(), 
/*  601 */         flags());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableApplicationInfoData withBotPublic(boolean value) {
/*  611 */     if (this.botPublic == value) return this; 
/*  612 */     return new ImmutableApplicationInfoData(this, 
/*      */         
/*  614 */         id(), this.name, this.icon, this.description, 
/*      */ 
/*      */ 
/*      */         
/*  618 */         rpcOrigins(), value, this.botRequireCodeGrant, 
/*      */ 
/*      */         
/*  621 */         termsOfServiceUrl(), 
/*  622 */         privacyPolicyUrl(), this.owner, this.summary, this.verifyKey, this.team, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  627 */         guildId(), 
/*  628 */         primarySkuId(), 
/*  629 */         slug(), 
/*  630 */         coverImage(), 
/*  631 */         flags());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableApplicationInfoData withBotRequireCodeGrant(boolean value) {
/*  641 */     if (this.botRequireCodeGrant == value) return this; 
/*  642 */     return new ImmutableApplicationInfoData(this, 
/*      */         
/*  644 */         id(), this.name, this.icon, this.description, 
/*      */ 
/*      */ 
/*      */         
/*  648 */         rpcOrigins(), this.botPublic, value, 
/*      */ 
/*      */         
/*  651 */         termsOfServiceUrl(), 
/*  652 */         privacyPolicyUrl(), this.owner, this.summary, this.verifyKey, this.team, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  657 */         guildId(), 
/*  658 */         primarySkuId(), 
/*  659 */         slug(), 
/*  660 */         coverImage(), 
/*  661 */         flags());
/*      */   }
/*      */   
/*      */   public ImmutableApplicationInfoData withTermsOfServiceUrl(Possible<String> value) {
/*  665 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/*  666 */     return new ImmutableApplicationInfoData(this, 
/*      */         
/*  668 */         id(), this.name, this.icon, this.description, 
/*      */ 
/*      */ 
/*      */         
/*  672 */         rpcOrigins(), this.botPublic, this.botRequireCodeGrant, newValue, 
/*      */ 
/*      */ 
/*      */         
/*  676 */         privacyPolicyUrl(), this.owner, this.summary, this.verifyKey, this.team, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  681 */         guildId(), 
/*  682 */         primarySkuId(), 
/*  683 */         slug(), 
/*  684 */         coverImage(), 
/*  685 */         flags());
/*      */   }
/*      */   
/*      */   public ImmutableApplicationInfoData withTermsOfServiceUrl(String value) {
/*  689 */     Possible<String> newValue = Possible.of(value);
/*  690 */     return new ImmutableApplicationInfoData(this, 
/*      */         
/*  692 */         id(), this.name, this.icon, this.description, 
/*      */ 
/*      */ 
/*      */         
/*  696 */         rpcOrigins(), this.botPublic, this.botRequireCodeGrant, newValue, 
/*      */ 
/*      */ 
/*      */         
/*  700 */         privacyPolicyUrl(), this.owner, this.summary, this.verifyKey, this.team, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  705 */         guildId(), 
/*  706 */         primarySkuId(), 
/*  707 */         slug(), 
/*  708 */         coverImage(), 
/*  709 */         flags());
/*      */   }
/*      */   
/*      */   public ImmutableApplicationInfoData withPrivacyPolicyUrl(Possible<String> value) {
/*  713 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/*  714 */     return new ImmutableApplicationInfoData(this, 
/*      */         
/*  716 */         id(), this.name, this.icon, this.description, 
/*      */ 
/*      */ 
/*      */         
/*  720 */         rpcOrigins(), this.botPublic, this.botRequireCodeGrant, 
/*      */ 
/*      */         
/*  723 */         termsOfServiceUrl(), newValue, this.owner, this.summary, this.verifyKey, this.team, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  729 */         guildId(), 
/*  730 */         primarySkuId(), 
/*  731 */         slug(), 
/*  732 */         coverImage(), 
/*  733 */         flags());
/*      */   }
/*      */   
/*      */   public ImmutableApplicationInfoData withPrivacyPolicyUrl(String value) {
/*  737 */     Possible<String> newValue = Possible.of(value);
/*  738 */     return new ImmutableApplicationInfoData(this, 
/*      */         
/*  740 */         id(), this.name, this.icon, this.description, 
/*      */ 
/*      */ 
/*      */         
/*  744 */         rpcOrigins(), this.botPublic, this.botRequireCodeGrant, 
/*      */ 
/*      */         
/*  747 */         termsOfServiceUrl(), newValue, this.owner, this.summary, this.verifyKey, this.team, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  753 */         guildId(), 
/*  754 */         primarySkuId(), 
/*  755 */         slug(), 
/*  756 */         coverImage(), 
/*  757 */         flags());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableApplicationInfoData withOwner(UserData value) {
/*  767 */     if (this.owner == value) return this; 
/*  768 */     UserData newValue = Objects.<UserData>requireNonNull(value, "owner");
/*  769 */     return new ImmutableApplicationInfoData(this, 
/*      */         
/*  771 */         id(), this.name, this.icon, this.description, 
/*      */ 
/*      */ 
/*      */         
/*  775 */         rpcOrigins(), this.botPublic, this.botRequireCodeGrant, 
/*      */ 
/*      */         
/*  778 */         termsOfServiceUrl(), 
/*  779 */         privacyPolicyUrl(), newValue, this.summary, this.verifyKey, this.team, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  784 */         guildId(), 
/*  785 */         primarySkuId(), 
/*  786 */         slug(), 
/*  787 */         coverImage(), 
/*  788 */         flags());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableApplicationInfoData withSummary(String value) {
/*  798 */     String newValue = Objects.<String>requireNonNull(value, "summary");
/*  799 */     if (this.summary.equals(newValue)) return this; 
/*  800 */     return new ImmutableApplicationInfoData(this, 
/*      */         
/*  802 */         id(), this.name, this.icon, this.description, 
/*      */ 
/*      */ 
/*      */         
/*  806 */         rpcOrigins(), this.botPublic, this.botRequireCodeGrant, 
/*      */ 
/*      */         
/*  809 */         termsOfServiceUrl(), 
/*  810 */         privacyPolicyUrl(), this.owner, newValue, this.verifyKey, this.team, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  815 */         guildId(), 
/*  816 */         primarySkuId(), 
/*  817 */         slug(), 
/*  818 */         coverImage(), 
/*  819 */         flags());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableApplicationInfoData withVerifyKey(String value) {
/*  829 */     String newValue = Objects.<String>requireNonNull(value, "verifyKey");
/*  830 */     if (this.verifyKey.equals(newValue)) return this; 
/*  831 */     return new ImmutableApplicationInfoData(this, 
/*      */         
/*  833 */         id(), this.name, this.icon, this.description, 
/*      */ 
/*      */ 
/*      */         
/*  837 */         rpcOrigins(), this.botPublic, this.botRequireCodeGrant, 
/*      */ 
/*      */         
/*  840 */         termsOfServiceUrl(), 
/*  841 */         privacyPolicyUrl(), this.owner, this.summary, newValue, this.team, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  846 */         guildId(), 
/*  847 */         primarySkuId(), 
/*  848 */         slug(), 
/*  849 */         coverImage(), 
/*  850 */         flags());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableApplicationInfoData withTeam(ApplicationTeamData value) {
/*  859 */     ApplicationTeamData newValue = Objects.<ApplicationTeamData>requireNonNull(value, "team");
/*  860 */     if (this.team == newValue) return this; 
/*  861 */     return new ImmutableApplicationInfoData(this, 
/*      */         
/*  863 */         id(), this.name, this.icon, this.description, 
/*      */ 
/*      */ 
/*      */         
/*  867 */         rpcOrigins(), this.botPublic, this.botRequireCodeGrant, 
/*      */ 
/*      */         
/*  870 */         termsOfServiceUrl(), 
/*  871 */         privacyPolicyUrl(), this.owner, this.summary, this.verifyKey, newValue, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  876 */         guildId(), 
/*  877 */         primarySkuId(), 
/*  878 */         slug(), 
/*  879 */         coverImage(), 
/*  880 */         flags());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableApplicationInfoData withTeam(Optional<? extends ApplicationTeamData> optional) {
/*  891 */     ApplicationTeamData value = optional.orElse(null);
/*  892 */     if (this.team == value) return this; 
/*  893 */     return new ImmutableApplicationInfoData(this, 
/*      */         
/*  895 */         id(), this.name, this.icon, this.description, 
/*      */ 
/*      */ 
/*      */         
/*  899 */         rpcOrigins(), this.botPublic, this.botRequireCodeGrant, 
/*      */ 
/*      */         
/*  902 */         termsOfServiceUrl(), 
/*  903 */         privacyPolicyUrl(), this.owner, this.summary, this.verifyKey, value, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  908 */         guildId(), 
/*  909 */         primarySkuId(), 
/*  910 */         slug(), 
/*  911 */         coverImage(), 
/*  912 */         flags());
/*      */   }
/*      */   
/*      */   public ImmutableApplicationInfoData withGuildId(Possible<Id> value) {
/*  916 */     Possible<Id> newValue = Objects.<Possible<Id>>requireNonNull(value);
/*  917 */     return new ImmutableApplicationInfoData(this, 
/*      */         
/*  919 */         id(), this.name, this.icon, this.description, 
/*      */ 
/*      */ 
/*      */         
/*  923 */         rpcOrigins(), this.botPublic, this.botRequireCodeGrant, 
/*      */ 
/*      */         
/*  926 */         termsOfServiceUrl(), 
/*  927 */         privacyPolicyUrl(), this.owner, this.summary, this.verifyKey, this.team, newValue, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  933 */         primarySkuId(), 
/*  934 */         slug(), 
/*  935 */         coverImage(), 
/*  936 */         flags());
/*      */   }
/*      */   
/*      */   public ImmutableApplicationInfoData withGuildId(long value) {
/*  940 */     Possible<Id> newValue = Possible.of(Id.of(value));
/*  941 */     return new ImmutableApplicationInfoData(this, 
/*      */         
/*  943 */         id(), this.name, this.icon, this.description, 
/*      */ 
/*      */ 
/*      */         
/*  947 */         rpcOrigins(), this.botPublic, this.botRequireCodeGrant, 
/*      */ 
/*      */         
/*  950 */         termsOfServiceUrl(), 
/*  951 */         privacyPolicyUrl(), this.owner, this.summary, this.verifyKey, this.team, newValue, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  957 */         primarySkuId(), 
/*  958 */         slug(), 
/*  959 */         coverImage(), 
/*  960 */         flags());
/*      */   }
/*      */   
/*      */   public ImmutableApplicationInfoData withPrimarySkuId(Possible<Id> value) {
/*  964 */     Possible<Id> newValue = Objects.<Possible<Id>>requireNonNull(value);
/*  965 */     return new ImmutableApplicationInfoData(this, 
/*      */         
/*  967 */         id(), this.name, this.icon, this.description, 
/*      */ 
/*      */ 
/*      */         
/*  971 */         rpcOrigins(), this.botPublic, this.botRequireCodeGrant, 
/*      */ 
/*      */         
/*  974 */         termsOfServiceUrl(), 
/*  975 */         privacyPolicyUrl(), this.owner, this.summary, this.verifyKey, this.team, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  980 */         guildId(), newValue, 
/*      */         
/*  982 */         slug(), 
/*  983 */         coverImage(), 
/*  984 */         flags());
/*      */   }
/*      */   
/*      */   public ImmutableApplicationInfoData withPrimarySkuId(long value) {
/*  988 */     Possible<Id> newValue = Possible.of(Id.of(value));
/*  989 */     return new ImmutableApplicationInfoData(this, 
/*      */         
/*  991 */         id(), this.name, this.icon, this.description, 
/*      */ 
/*      */ 
/*      */         
/*  995 */         rpcOrigins(), this.botPublic, this.botRequireCodeGrant, 
/*      */ 
/*      */         
/*  998 */         termsOfServiceUrl(), 
/*  999 */         privacyPolicyUrl(), this.owner, this.summary, this.verifyKey, this.team, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1004 */         guildId(), newValue, 
/*      */         
/* 1006 */         slug(), 
/* 1007 */         coverImage(), 
/* 1008 */         flags());
/*      */   }
/*      */   
/*      */   public ImmutableApplicationInfoData withSlug(Possible<String> value) {
/* 1012 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/* 1013 */     return new ImmutableApplicationInfoData(this, 
/*      */         
/* 1015 */         id(), this.name, this.icon, this.description, 
/*      */ 
/*      */ 
/*      */         
/* 1019 */         rpcOrigins(), this.botPublic, this.botRequireCodeGrant, 
/*      */ 
/*      */         
/* 1022 */         termsOfServiceUrl(), 
/* 1023 */         privacyPolicyUrl(), this.owner, this.summary, this.verifyKey, this.team, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1028 */         guildId(), 
/* 1029 */         primarySkuId(), newValue, 
/*      */         
/* 1031 */         coverImage(), 
/* 1032 */         flags());
/*      */   }
/*      */   
/*      */   public ImmutableApplicationInfoData withSlug(String value) {
/* 1036 */     Possible<String> newValue = Possible.of(value);
/* 1037 */     return new ImmutableApplicationInfoData(this, 
/*      */         
/* 1039 */         id(), this.name, this.icon, this.description, 
/*      */ 
/*      */ 
/*      */         
/* 1043 */         rpcOrigins(), this.botPublic, this.botRequireCodeGrant, 
/*      */ 
/*      */         
/* 1046 */         termsOfServiceUrl(), 
/* 1047 */         privacyPolicyUrl(), this.owner, this.summary, this.verifyKey, this.team, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1052 */         guildId(), 
/* 1053 */         primarySkuId(), newValue, 
/*      */         
/* 1055 */         coverImage(), 
/* 1056 */         flags());
/*      */   }
/*      */   
/*      */   public ImmutableApplicationInfoData withCoverImage(Possible<String> value) {
/* 1060 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/* 1061 */     return new ImmutableApplicationInfoData(this, 
/*      */         
/* 1063 */         id(), this.name, this.icon, this.description, 
/*      */ 
/*      */ 
/*      */         
/* 1067 */         rpcOrigins(), this.botPublic, this.botRequireCodeGrant, 
/*      */ 
/*      */         
/* 1070 */         termsOfServiceUrl(), 
/* 1071 */         privacyPolicyUrl(), this.owner, this.summary, this.verifyKey, this.team, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1076 */         guildId(), 
/* 1077 */         primarySkuId(), 
/* 1078 */         slug(), newValue, 
/*      */         
/* 1080 */         flags());
/*      */   }
/*      */   
/*      */   public ImmutableApplicationInfoData withCoverImage(String value) {
/* 1084 */     Possible<String> newValue = Possible.of(value);
/* 1085 */     return new ImmutableApplicationInfoData(this, 
/*      */         
/* 1087 */         id(), this.name, this.icon, this.description, 
/*      */ 
/*      */ 
/*      */         
/* 1091 */         rpcOrigins(), this.botPublic, this.botRequireCodeGrant, 
/*      */ 
/*      */         
/* 1094 */         termsOfServiceUrl(), 
/* 1095 */         privacyPolicyUrl(), this.owner, this.summary, this.verifyKey, this.team, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1100 */         guildId(), 
/* 1101 */         primarySkuId(), 
/* 1102 */         slug(), newValue, 
/*      */         
/* 1104 */         flags());
/*      */   }
/*      */   
/*      */   public ImmutableApplicationInfoData withFlags(Possible<Integer> value) {
/* 1108 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/* 1109 */     return new ImmutableApplicationInfoData(this, 
/*      */         
/* 1111 */         id(), this.name, this.icon, this.description, 
/*      */ 
/*      */ 
/*      */         
/* 1115 */         rpcOrigins(), this.botPublic, this.botRequireCodeGrant, 
/*      */ 
/*      */         
/* 1118 */         termsOfServiceUrl(), 
/* 1119 */         privacyPolicyUrl(), this.owner, this.summary, this.verifyKey, this.team, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1124 */         guildId(), 
/* 1125 */         primarySkuId(), 
/* 1126 */         slug(), 
/* 1127 */         coverImage(), newValue);
/*      */   }
/*      */ 
/*      */   
/*      */   public ImmutableApplicationInfoData withFlags(Integer value) {
/* 1132 */     Possible<Integer> newValue = Possible.of(value);
/* 1133 */     return new ImmutableApplicationInfoData(this, 
/*      */         
/* 1135 */         id(), this.name, this.icon, this.description, 
/*      */ 
/*      */ 
/*      */         
/* 1139 */         rpcOrigins(), this.botPublic, this.botRequireCodeGrant, 
/*      */ 
/*      */         
/* 1142 */         termsOfServiceUrl(), 
/* 1143 */         privacyPolicyUrl(), this.owner, this.summary, this.verifyKey, this.team, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1148 */         guildId(), 
/* 1149 */         primarySkuId(), 
/* 1150 */         slug(), 
/* 1151 */         coverImage(), newValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean equals(Object another) {
/* 1161 */     if (this == another) return true; 
/* 1162 */     return (another instanceof ImmutableApplicationInfoData && 
/* 1163 */       equalTo(0, (ImmutableApplicationInfoData)another));
/*      */   }
/*      */   
/*      */   private boolean equalTo(int synthetic, ImmutableApplicationInfoData another) {
/* 1167 */     return (Objects.equals(Long.valueOf(this.id_value), Long.valueOf(another.id_value)) && this.name
/* 1168 */       .equals(another.name) && 
/* 1169 */       Objects.equals(this.icon, another.icon) && this.description
/* 1170 */       .equals(another.description) && 
/* 1171 */       Objects.equals(this.rpcOrigins_value, another.rpcOrigins_value) && this.botPublic == another.botPublic && this.botRequireCodeGrant == another.botRequireCodeGrant && 
/*      */ 
/*      */       
/* 1174 */       termsOfServiceUrl().equals(another.termsOfServiceUrl()) && 
/* 1175 */       privacyPolicyUrl().equals(another.privacyPolicyUrl()) && this.owner
/* 1176 */       .equals(another.owner) && this.summary
/* 1177 */       .equals(another.summary) && this.verifyKey
/* 1178 */       .equals(another.verifyKey) && 
/* 1179 */       Objects.equals(this.team, another.team) && 
/* 1180 */       guildId().equals(another.guildId()) && 
/* 1181 */       primarySkuId().equals(another.primarySkuId()) && 
/* 1182 */       slug().equals(another.slug()) && 
/* 1183 */       coverImage().equals(another.coverImage()) && 
/* 1184 */       flags().equals(another.flags()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int hashCode() {
/* 1193 */     int h = 5381;
/* 1194 */     h += (h << 5) + Objects.hashCode(Long.valueOf(this.id_value));
/* 1195 */     h += (h << 5) + this.name.hashCode();
/* 1196 */     h += (h << 5) + Objects.hashCode(this.icon);
/* 1197 */     h += (h << 5) + this.description.hashCode();
/* 1198 */     h += (h << 5) + Objects.hashCode(this.rpcOrigins_value);
/* 1199 */     h += (h << 5) + Boolean.hashCode(this.botPublic);
/* 1200 */     h += (h << 5) + Boolean.hashCode(this.botRequireCodeGrant);
/* 1201 */     h += (h << 5) + termsOfServiceUrl().hashCode();
/* 1202 */     h += (h << 5) + privacyPolicyUrl().hashCode();
/* 1203 */     h += (h << 5) + this.owner.hashCode();
/* 1204 */     h += (h << 5) + this.summary.hashCode();
/* 1205 */     h += (h << 5) + this.verifyKey.hashCode();
/* 1206 */     h += (h << 5) + Objects.hashCode(this.team);
/* 1207 */     h += (h << 5) + guildId().hashCode();
/* 1208 */     h += (h << 5) + primarySkuId().hashCode();
/* 1209 */     h += (h << 5) + slug().hashCode();
/* 1210 */     h += (h << 5) + coverImage().hashCode();
/* 1211 */     h += (h << 5) + flags().hashCode();
/* 1212 */     return h;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/* 1221 */     StringBuilder builder = new StringBuilder("ApplicationInfoData{");
/* 1222 */     builder.append("id=").append(Objects.toString(Long.valueOf(this.id_value)));
/* 1223 */     builder.append(", ");
/* 1224 */     builder.append("name=").append(this.name);
/* 1225 */     if (this.icon != null) {
/* 1226 */       builder.append(", ");
/* 1227 */       builder.append("icon=").append(this.icon);
/*      */     } 
/* 1229 */     builder.append(", ");
/* 1230 */     builder.append("description=").append(this.description);
/* 1231 */     builder.append(", ");
/* 1232 */     builder.append("rpcOrigins=").append(Objects.toString(this.rpcOrigins_value));
/* 1233 */     builder.append(", ");
/* 1234 */     builder.append("botPublic=").append(this.botPublic);
/* 1235 */     builder.append(", ");
/* 1236 */     builder.append("botRequireCodeGrant=").append(this.botRequireCodeGrant);
/* 1237 */     builder.append(", ");
/* 1238 */     builder.append("termsOfServiceUrl=").append(termsOfServiceUrl().toString());
/* 1239 */     builder.append(", ");
/* 1240 */     builder.append("privacyPolicyUrl=").append(privacyPolicyUrl().toString());
/* 1241 */     builder.append(", ");
/* 1242 */     builder.append("owner=").append(this.owner);
/* 1243 */     builder.append(", ");
/* 1244 */     builder.append("summary=").append(this.summary);
/* 1245 */     builder.append(", ");
/* 1246 */     builder.append("verifyKey=").append(this.verifyKey);
/* 1247 */     if (this.team != null) {
/* 1248 */       builder.append(", ");
/* 1249 */       builder.append("team=").append(this.team);
/*      */     } 
/* 1251 */     builder.append(", ");
/* 1252 */     builder.append("guildId=").append(guildId().toString());
/* 1253 */     builder.append(", ");
/* 1254 */     builder.append("primarySkuId=").append(primarySkuId().toString());
/* 1255 */     builder.append(", ");
/* 1256 */     builder.append("slug=").append(slug().toString());
/* 1257 */     builder.append(", ");
/* 1258 */     builder.append("coverImage=").append(coverImage().toString());
/* 1259 */     builder.append(", ");
/* 1260 */     builder.append("flags=").append(flags().toString());
/* 1261 */     return builder.append("}").toString();
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonDeserialize
/*      */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*      */   @Generated(from = "ApplicationInfoData", generator = "Immutables")
/*      */   static final class Json
/*      */     implements ApplicationInfoData
/*      */   {
/*      */     Id id;
/*      */     
/*      */     String name;
/* 1275 */     Optional<String> icon = Optional.empty();
/*      */     
/*      */     String description;
/* 1278 */     Possible<List<String>> rpcOrigins = Possible.absent();
/*      */     
/*      */     boolean botPublic;
/*      */     
/*      */     boolean botPublicIsSet;
/*      */     boolean botRequireCodeGrant;
/*      */     boolean botRequireCodeGrantIsSet;
/* 1285 */     Possible<String> termsOfServiceUrl = Possible.absent();
/*      */ 
/*      */     
/* 1288 */     Possible<String> privacyPolicyUrl = Possible.absent();
/*      */     
/*      */     UserData owner;
/*      */     String summary;
/*      */     String verifyKey;
/* 1293 */     Optional<ApplicationTeamData> team = Optional.empty();
/*      */     
/* 1295 */     Possible<Id> guildId = Possible.absent();
/*      */ 
/*      */     
/* 1298 */     Possible<Id> primarySkuId = Possible.absent();
/*      */ 
/*      */     
/* 1301 */     Possible<String> slug = Possible.absent();
/*      */ 
/*      */     
/* 1304 */     Possible<String> coverImage = Possible.absent();
/*      */ 
/*      */     
/* 1307 */     Possible<Integer> flags = Possible.absent();
/*      */     
/*      */     @JsonProperty("id")
/*      */     public void setId(Id id) {
/* 1311 */       this.id = id;
/*      */     }
/*      */     @JsonProperty("name")
/*      */     public void setName(String name) {
/* 1315 */       this.name = name;
/*      */     }
/*      */     @JsonProperty("icon")
/*      */     public void setIcon(Optional<String> icon) {
/* 1319 */       this.icon = icon;
/*      */     }
/*      */     @JsonProperty("description")
/*      */     public void setDescription(String description) {
/* 1323 */       this.description = description;
/*      */     }
/*      */     @JsonProperty("rpc_origins")
/*      */     public void setRpcOrigins(Possible<List<String>> rpcOrigins) {
/* 1327 */       this.rpcOrigins = rpcOrigins;
/*      */     }
/*      */     @JsonProperty("bot_public")
/*      */     public void setBotPublic(boolean botPublic) {
/* 1331 */       this.botPublic = botPublic;
/* 1332 */       this.botPublicIsSet = true;
/*      */     }
/*      */     @JsonProperty("bot_require_code_grant")
/*      */     public void setBotRequireCodeGrant(boolean botRequireCodeGrant) {
/* 1336 */       this.botRequireCodeGrant = botRequireCodeGrant;
/* 1337 */       this.botRequireCodeGrantIsSet = true;
/*      */     }
/*      */     @JsonProperty("terms_of_service_url")
/*      */     public void setTermsOfServiceUrl(Possible<String> termsOfServiceUrl) {
/* 1341 */       this.termsOfServiceUrl = termsOfServiceUrl;
/*      */     }
/*      */     @JsonProperty("privacy_policy_url")
/*      */     public void setPrivacyPolicyUrl(Possible<String> privacyPolicyUrl) {
/* 1345 */       this.privacyPolicyUrl = privacyPolicyUrl;
/*      */     }
/*      */     @JsonProperty("owner")
/*      */     public void setOwner(UserData owner) {
/* 1349 */       this.owner = owner;
/*      */     }
/*      */     @JsonProperty("summary")
/*      */     public void setSummary(String summary) {
/* 1353 */       this.summary = summary;
/*      */     }
/*      */     @JsonProperty("verify_key")
/*      */     public void setVerifyKey(String verifyKey) {
/* 1357 */       this.verifyKey = verifyKey;
/*      */     }
/*      */     @JsonProperty("team")
/*      */     public void setTeam(Optional<ApplicationTeamData> team) {
/* 1361 */       this.team = team;
/*      */     }
/*      */     @JsonProperty("guild_id")
/*      */     public void setGuildId(Possible<Id> guildId) {
/* 1365 */       this.guildId = guildId;
/*      */     }
/*      */     @JsonProperty("primary_sku_id")
/*      */     public void setPrimarySkuId(Possible<Id> primarySkuId) {
/* 1369 */       this.primarySkuId = primarySkuId;
/*      */     }
/*      */     @JsonProperty("slug")
/*      */     public void setSlug(Possible<String> slug) {
/* 1373 */       this.slug = slug;
/*      */     }
/*      */     @JsonProperty("cover_image")
/*      */     public void setCoverImage(Possible<String> coverImage) {
/* 1377 */       this.coverImage = coverImage;
/*      */     }
/*      */     @JsonProperty("flags")
/*      */     public void setFlags(Possible<Integer> flags) {
/* 1381 */       this.flags = flags;
/*      */     }
/*      */     public Id id() {
/* 1384 */       throw new UnsupportedOperationException();
/*      */     } public String name() {
/* 1386 */       throw new UnsupportedOperationException();
/*      */     } public Optional<String> icon() {
/* 1388 */       throw new UnsupportedOperationException();
/*      */     } public String description() {
/* 1390 */       throw new UnsupportedOperationException();
/*      */     } public Possible<List<String>> rpcOrigins() {
/* 1392 */       throw new UnsupportedOperationException();
/*      */     } public boolean botPublic() {
/* 1394 */       throw new UnsupportedOperationException();
/*      */     } public boolean botRequireCodeGrant() {
/* 1396 */       throw new UnsupportedOperationException();
/*      */     } public Possible<String> termsOfServiceUrl() {
/* 1398 */       throw new UnsupportedOperationException();
/*      */     } public Possible<String> privacyPolicyUrl() {
/* 1400 */       throw new UnsupportedOperationException();
/*      */     } public UserData owner() {
/* 1402 */       throw new UnsupportedOperationException();
/*      */     } public String summary() {
/* 1404 */       throw new UnsupportedOperationException();
/*      */     } public String verifyKey() {
/* 1406 */       throw new UnsupportedOperationException();
/*      */     } public Optional<ApplicationTeamData> team() {
/* 1408 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Id> guildId() {
/* 1410 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Id> primarySkuId() {
/* 1412 */       throw new UnsupportedOperationException();
/*      */     } public Possible<String> slug() {
/* 1414 */       throw new UnsupportedOperationException();
/*      */     } public Possible<String> coverImage() {
/* 1416 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Integer> flags() {
/* 1418 */       throw new UnsupportedOperationException();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*      */   static ImmutableApplicationInfoData fromJson(Json json) {
/* 1429 */     Builder builder = builder();
/* 1430 */     if (json.id != null) {
/* 1431 */       builder.id(json.id);
/*      */     }
/* 1433 */     if (json.name != null) {
/* 1434 */       builder.name(json.name);
/*      */     }
/* 1436 */     if (json.icon != null) {
/* 1437 */       builder.icon(json.icon);
/*      */     }
/* 1439 */     if (json.description != null) {
/* 1440 */       builder.description(json.description);
/*      */     }
/* 1442 */     if (json.rpcOrigins != null) {
/* 1443 */       builder.rpcOrigins(json.rpcOrigins);
/*      */     }
/* 1445 */     if (json.botPublicIsSet) {
/* 1446 */       builder.botPublic(json.botPublic);
/*      */     }
/* 1448 */     if (json.botRequireCodeGrantIsSet) {
/* 1449 */       builder.botRequireCodeGrant(json.botRequireCodeGrant);
/*      */     }
/* 1451 */     if (json.termsOfServiceUrl != null) {
/* 1452 */       builder.termsOfServiceUrl(json.termsOfServiceUrl);
/*      */     }
/* 1454 */     if (json.privacyPolicyUrl != null) {
/* 1455 */       builder.privacyPolicyUrl(json.privacyPolicyUrl);
/*      */     }
/* 1457 */     if (json.owner != null) {
/* 1458 */       builder.owner(json.owner);
/*      */     }
/* 1460 */     if (json.summary != null) {
/* 1461 */       builder.summary(json.summary);
/*      */     }
/* 1463 */     if (json.verifyKey != null) {
/* 1464 */       builder.verifyKey(json.verifyKey);
/*      */     }
/* 1466 */     if (json.team != null) {
/* 1467 */       builder.team(json.team);
/*      */     }
/* 1469 */     if (json.guildId != null) {
/* 1470 */       builder.guildId(json.guildId);
/*      */     }
/* 1472 */     if (json.primarySkuId != null) {
/* 1473 */       builder.primarySkuId(json.primarySkuId);
/*      */     }
/* 1475 */     if (json.slug != null) {
/* 1476 */       builder.slug(json.slug);
/*      */     }
/* 1478 */     if (json.coverImage != null) {
/* 1479 */       builder.coverImage(json.coverImage);
/*      */     }
/* 1481 */     if (json.flags != null) {
/* 1482 */       builder.flags(json.flags);
/*      */     }
/* 1484 */     return builder.build();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableApplicationInfoData of(Id id, String name, Optional<String> icon, String description, Possible<List<String>> rpcOrigins, boolean botPublic, boolean botRequireCodeGrant, Possible<String> termsOfServiceUrl, Possible<String> privacyPolicyUrl, UserData owner, String summary, String verifyKey, Optional<? extends ApplicationTeamData> team, Possible<Id> guildId, Possible<Id> primarySkuId, Possible<String> slug, Possible<String> coverImage, Possible<Integer> flags) {
/* 1510 */     return new ImmutableApplicationInfoData(id, name, icon, description, rpcOrigins, botPublic, botRequireCodeGrant, termsOfServiceUrl, privacyPolicyUrl, owner, summary, verifyKey, team, guildId, primarySkuId, slug, coverImage, flags);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableApplicationInfoData copyOf(ApplicationInfoData instance) {
/* 1521 */     if (instance instanceof ImmutableApplicationInfoData) {
/* 1522 */       return (ImmutableApplicationInfoData)instance;
/*      */     }
/* 1524 */     return builder()
/* 1525 */       .from(instance)
/* 1526 */       .build();
/*      */   }
/*      */   
/*      */   public boolean isRpcOriginsPresent() {
/* 1530 */     return !this.rpcOrigins_absent;
/*      */   }
/*      */   
/*      */   public List<String> rpcOriginsOrElse(List<String> defaultValue) {
/* 1534 */     return !this.rpcOrigins_absent ? this.rpcOrigins_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isTermsOfServiceUrlPresent() {
/* 1538 */     return !this.termsOfServiceUrl_absent;
/*      */   }
/*      */   
/*      */   public String termsOfServiceUrlOrElse(String defaultValue) {
/* 1542 */     return !this.termsOfServiceUrl_absent ? this.termsOfServiceUrl_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isPrivacyPolicyUrlPresent() {
/* 1546 */     return !this.privacyPolicyUrl_absent;
/*      */   }
/*      */   
/*      */   public String privacyPolicyUrlOrElse(String defaultValue) {
/* 1550 */     return !this.privacyPolicyUrl_absent ? this.privacyPolicyUrl_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isGuildIdPresent() {
/* 1554 */     return !this.guildId_absent;
/*      */   }
/*      */   
/*      */   public long guildIdOrElse(long defaultValue) {
/* 1558 */     return !this.guildId_absent ? this.guildId_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isPrimarySkuIdPresent() {
/* 1562 */     return !this.primarySkuId_absent;
/*      */   }
/*      */   
/*      */   public long primarySkuIdOrElse(long defaultValue) {
/* 1566 */     return !this.primarySkuId_absent ? this.primarySkuId_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isSlugPresent() {
/* 1570 */     return !this.slug_absent;
/*      */   }
/*      */   
/*      */   public String slugOrElse(String defaultValue) {
/* 1574 */     return !this.slug_absent ? this.slug_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isCoverImagePresent() {
/* 1578 */     return !this.coverImage_absent;
/*      */   }
/*      */   
/*      */   public String coverImageOrElse(String defaultValue) {
/* 1582 */     return !this.coverImage_absent ? this.coverImage_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isFlagsPresent() {
/* 1586 */     return !this.flags_absent;
/*      */   }
/*      */   
/*      */   public Integer flagsOrElse(Integer defaultValue) {
/* 1590 */     return !this.flags_absent ? this.flags_value : defaultValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Builder builder() {
/* 1620 */     return new Builder();
/*      */   }
/*      */ 
/*      */   
/*      */   @Generated(from = "ApplicationInfoData", generator = "Immutables")
/*      */   public static final class Builder
/*      */   {
/*      */     private static final long INIT_BIT_NAME = 1L;
/*      */     
/*      */     private static final long INIT_BIT_DESCRIPTION = 2L;
/*      */     
/*      */     private static final long INIT_BIT_BOT_PUBLIC = 4L;
/*      */     
/*      */     private static final long INIT_BIT_BOT_REQUIRE_CODE_GRANT = 8L;
/*      */     
/*      */     private static final long INIT_BIT_OWNER = 16L;
/*      */     
/*      */     private static final long INIT_BIT_SUMMARY = 32L;
/*      */     private static final long INIT_BIT_VERIFY_KEY = 64L;
/* 1639 */     private long initBits = 127L;
/*      */     
/* 1641 */     private Id id_id = null;
/* 1642 */     private List<String> rpcOrigins_list = null;
/* 1643 */     private Possible<String> termsOfServiceUrl_possible = Possible.absent();
/* 1644 */     private Possible<String> privacyPolicyUrl_possible = Possible.absent();
/* 1645 */     private Possible<Id> guildId_possible = Possible.absent();
/* 1646 */     private Possible<Id> primarySkuId_possible = Possible.absent();
/* 1647 */     private Possible<String> slug_possible = Possible.absent();
/* 1648 */     private Possible<String> coverImage_possible = Possible.absent();
/* 1649 */     private Possible<Integer> flags_possible = Possible.absent();
/*      */     
/*      */     private String name;
/*      */     
/*      */     private String icon;
/*      */     
/*      */     private String description;
/*      */     
/*      */     private boolean botPublic;
/*      */     
/*      */     private boolean botRequireCodeGrant;
/*      */     
/*      */     private UserData owner;
/*      */     
/*      */     private String summary;
/*      */     
/*      */     private String verifyKey;
/*      */     
/*      */     private ApplicationTeamData team;
/*      */ 
/*      */     
/*      */     public final Builder from(ApplicationInfoData instance) {
/* 1671 */       Objects.requireNonNull(instance, "instance");
/* 1672 */       id(instance.id());
/* 1673 */       name(instance.name());
/* 1674 */       Optional<String> iconOptional = instance.icon();
/* 1675 */       if (iconOptional.isPresent()) {
/* 1676 */         icon(iconOptional);
/*      */       }
/* 1678 */       description(instance.description());
/* 1679 */       rpcOrigins(instance.rpcOrigins());
/* 1680 */       botPublic(instance.botPublic());
/* 1681 */       botRequireCodeGrant(instance.botRequireCodeGrant());
/* 1682 */       termsOfServiceUrl(instance.termsOfServiceUrl());
/* 1683 */       privacyPolicyUrl(instance.privacyPolicyUrl());
/* 1684 */       owner(instance.owner());
/* 1685 */       summary(instance.summary());
/* 1686 */       verifyKey(instance.verifyKey());
/* 1687 */       Optional<ApplicationTeamData> teamOptional = instance.team();
/* 1688 */       if (teamOptional.isPresent()) {
/* 1689 */         team(teamOptional);
/*      */       }
/* 1691 */       guildId(instance.guildId());
/* 1692 */       primarySkuId(instance.primarySkuId());
/* 1693 */       slug(instance.slug());
/* 1694 */       coverImage(instance.coverImage());
/* 1695 */       flags(instance.flags());
/* 1696 */       return this;
/*      */     }
/*      */     
/*      */     public Builder id(String value) {
/* 1700 */       this.id_id = Id.of(value);
/* 1701 */       return this;
/*      */     }
/*      */     
/*      */     public Builder id(long value) {
/* 1705 */       this.id_id = Id.of(value);
/* 1706 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("id")
/*      */     public Builder id(Id value) {
/* 1711 */       this.id_id = value;
/* 1712 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("name")
/*      */     public final Builder name(String name) {
/* 1722 */       this.name = Objects.<String>requireNonNull(name, "name");
/* 1723 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 1724 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder icon(String icon) {
/* 1733 */       this.icon = Objects.<String>requireNonNull(icon, "icon");
/* 1734 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("icon")
/*      */     public final Builder icon(Optional<String> icon) {
/* 1744 */       this.icon = icon.orElse(null);
/* 1745 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("description")
/*      */     public final Builder description(String description) {
/* 1755 */       this.description = Objects.<String>requireNonNull(description, "description");
/* 1756 */       this.initBits &= 0xFFFFFFFFFFFFFFFDL;
/* 1757 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addRpcOrigin(String element) {
/* 1761 */       rpcOrigins_getOrCreate().add(element);
/* 1762 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addAllRpcOrigins(List<String> elements) {
/* 1766 */       rpcOrigins_getOrCreate().addAll(elements);
/* 1767 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("rpc_origins")
/*      */     public Builder rpcOrigins(Possible<List<String>> elements) {
/* 1772 */       this.rpcOrigins_list = null;
/* 1773 */       elements.toOptional().ifPresent(e -> rpcOrigins_getOrCreate().addAll(e));
/* 1774 */       return this;
/*      */     }
/*      */     
/*      */     public Builder rpcOrigins(List<String> elements) {
/* 1778 */       this.rpcOrigins_list = new ArrayList<>(elements);
/* 1779 */       return this;
/*      */     }
/*      */     
/*      */     public Builder rpcOrigins(Iterable<String> elements) {
/* 1783 */       this.rpcOrigins_list = (List<String>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/* 1784 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("bot_public")
/*      */     public final Builder botPublic(boolean botPublic) {
/* 1794 */       this.botPublic = botPublic;
/* 1795 */       this.initBits &= 0xFFFFFFFFFFFFFFFBL;
/* 1796 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("bot_require_code_grant")
/*      */     public final Builder botRequireCodeGrant(boolean botRequireCodeGrant) {
/* 1806 */       this.botRequireCodeGrant = botRequireCodeGrant;
/* 1807 */       this.initBits &= 0xFFFFFFFFFFFFFFF7L;
/* 1808 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("terms_of_service_url")
/*      */     public Builder termsOfServiceUrl(Possible<String> value) {
/* 1813 */       this.termsOfServiceUrl_possible = value;
/* 1814 */       return this;
/*      */     }
/*      */     
/*      */     public Builder termsOfServiceUrl(String value) {
/* 1818 */       this.termsOfServiceUrl_possible = Possible.of(value);
/* 1819 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("privacy_policy_url")
/*      */     public Builder privacyPolicyUrl(Possible<String> value) {
/* 1824 */       this.privacyPolicyUrl_possible = value;
/* 1825 */       return this;
/*      */     }
/*      */     
/*      */     public Builder privacyPolicyUrl(String value) {
/* 1829 */       this.privacyPolicyUrl_possible = Possible.of(value);
/* 1830 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("owner")
/*      */     public final Builder owner(UserData owner) {
/* 1840 */       this.owner = Objects.<UserData>requireNonNull(owner, "owner");
/* 1841 */       this.initBits &= 0xFFFFFFFFFFFFFFEFL;
/* 1842 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("summary")
/*      */     public final Builder summary(String summary) {
/* 1852 */       this.summary = Objects.<String>requireNonNull(summary, "summary");
/* 1853 */       this.initBits &= 0xFFFFFFFFFFFFFFDFL;
/* 1854 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("verify_key")
/*      */     public final Builder verifyKey(String verifyKey) {
/* 1864 */       this.verifyKey = Objects.<String>requireNonNull(verifyKey, "verifyKey");
/* 1865 */       this.initBits &= 0xFFFFFFFFFFFFFFBFL;
/* 1866 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder team(ApplicationTeamData team) {
/* 1875 */       this.team = Objects.<ApplicationTeamData>requireNonNull(team, "team");
/* 1876 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("team")
/*      */     public final Builder team(Optional<? extends ApplicationTeamData> team) {
/* 1886 */       this.team = team.orElse(null);
/* 1887 */       return this;
/*      */     }
/*      */     
/*      */     public Builder guildId(String value) {
/* 1891 */       this.guildId_possible = Possible.of(Id.of(value));
/* 1892 */       return this;
/*      */     }
/*      */     
/*      */     public Builder guildId(long value) {
/* 1896 */       this.guildId_possible = Possible.of(Id.of(value));
/* 1897 */       return this;
/*      */     }
/*      */     
/*      */     public Builder guildId(Id value) {
/* 1901 */       this.guildId_possible = Possible.of(value);
/* 1902 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("guild_id")
/*      */     public Builder guildId(Possible<Id> value) {
/* 1907 */       this.guildId_possible = value;
/* 1908 */       return this;
/*      */     }
/*      */     
/*      */     public Builder primarySkuId(String value) {
/* 1912 */       this.primarySkuId_possible = Possible.of(Id.of(value));
/* 1913 */       return this;
/*      */     }
/*      */     
/*      */     public Builder primarySkuId(long value) {
/* 1917 */       this.primarySkuId_possible = Possible.of(Id.of(value));
/* 1918 */       return this;
/*      */     }
/*      */     
/*      */     public Builder primarySkuId(Id value) {
/* 1922 */       this.primarySkuId_possible = Possible.of(value);
/* 1923 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("primary_sku_id")
/*      */     public Builder primarySkuId(Possible<Id> value) {
/* 1928 */       this.primarySkuId_possible = value;
/* 1929 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("slug")
/*      */     public Builder slug(Possible<String> value) {
/* 1934 */       this.slug_possible = value;
/* 1935 */       return this;
/*      */     }
/*      */     
/*      */     public Builder slug(String value) {
/* 1939 */       this.slug_possible = Possible.of(value);
/* 1940 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("cover_image")
/*      */     public Builder coverImage(Possible<String> value) {
/* 1945 */       this.coverImage_possible = value;
/* 1946 */       return this;
/*      */     }
/*      */     
/*      */     public Builder coverImage(String value) {
/* 1950 */       this.coverImage_possible = Possible.of(value);
/* 1951 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("flags")
/*      */     public Builder flags(Possible<Integer> value) {
/* 1956 */       this.flags_possible = value;
/* 1957 */       return this;
/*      */     }
/*      */     
/*      */     public Builder flags(Integer value) {
/* 1961 */       this.flags_possible = Possible.of(value);
/* 1962 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ImmutableApplicationInfoData build() {
/* 1971 */       if (this.initBits != 0L) {
/* 1972 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*      */       }
/* 1974 */       return new ImmutableApplicationInfoData(null, 
/*      */           
/* 1976 */           id_build(), this.name, this.icon, this.description, 
/*      */ 
/*      */ 
/*      */           
/* 1980 */           rpcOrigins_build(), this.botPublic, this.botRequireCodeGrant, 
/*      */ 
/*      */           
/* 1983 */           termsOfServiceUrl_build(), 
/* 1984 */           privacyPolicyUrl_build(), this.owner, this.summary, this.verifyKey, this.team, 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1989 */           guildId_build(), 
/* 1990 */           primarySkuId_build(), 
/* 1991 */           slug_build(), 
/* 1992 */           coverImage_build(), 
/* 1993 */           flags_build());
/*      */     }
/*      */     
/*      */     private String formatRequiredAttributesMessage() {
/* 1997 */       List<String> attributes = new ArrayList<>();
/* 1998 */       if ((this.initBits & 0x1L) != 0L) attributes.add("name"); 
/* 1999 */       if ((this.initBits & 0x2L) != 0L) attributes.add("description"); 
/* 2000 */       if ((this.initBits & 0x4L) != 0L) attributes.add("botPublic"); 
/* 2001 */       if ((this.initBits & 0x8L) != 0L) attributes.add("botRequireCodeGrant"); 
/* 2002 */       if ((this.initBits & 0x10L) != 0L) attributes.add("owner"); 
/* 2003 */       if ((this.initBits & 0x20L) != 0L) attributes.add("summary"); 
/* 2004 */       if ((this.initBits & 0x40L) != 0L) attributes.add("verifyKey"); 
/* 2005 */       return "Cannot build ApplicationInfoData, some of required attributes are not set " + attributes;
/*      */     }
/*      */     
/*      */     private Id id_build() {
/* 2009 */       return this.id_id;
/*      */     }
/*      */     
/*      */     private Possible<List<String>> rpcOrigins_build() {
/* 2013 */       return (this.rpcOrigins_list == null) ? Possible.absent() : 
/* 2014 */         Possible.of(this.rpcOrigins_list);
/*      */     }
/*      */     
/*      */     private List<String> rpcOrigins_getOrCreate() {
/* 2018 */       if (this.rpcOrigins_list == null) {
/* 2019 */         this.rpcOrigins_list = new ArrayList<>();
/*      */       }
/* 2021 */       return this.rpcOrigins_list;
/*      */     }
/*      */     
/*      */     private Possible<String> termsOfServiceUrl_build() {
/* 2025 */       return this.termsOfServiceUrl_possible;
/*      */     }
/*      */     
/*      */     private Possible<String> privacyPolicyUrl_build() {
/* 2029 */       return this.privacyPolicyUrl_possible;
/*      */     }
/*      */     
/*      */     private Possible<Id> guildId_build() {
/* 2033 */       return this.guildId_possible;
/*      */     }
/*      */     
/*      */     private Possible<Id> primarySkuId_build() {
/* 2037 */       return this.primarySkuId_possible;
/*      */     }
/*      */     
/*      */     private Possible<String> slug_build() {
/* 2041 */       return this.slug_possible;
/*      */     }
/*      */     
/*      */     private Possible<String> coverImage_build() {
/* 2045 */       return this.coverImage_possible;
/*      */     }
/*      */     
/*      */     private Possible<Integer> flags_build() {
/* 2049 */       return this.flags_possible;
/*      */     }
/*      */     
/*      */     private Builder() {}
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableApplicationInfoData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */