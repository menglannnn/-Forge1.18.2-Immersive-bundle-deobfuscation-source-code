/*    */ package discord4j.discordjson.json;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonProperty;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import java.util.List;
/*    */ import java.util.Optional;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ 
/*    */ @JsonSerialize(as = ImmutableWelcomeScreenData.class)
/*    */ @JsonDeserialize(as = ImmutableWelcomeScreenData.class)
/*    */ @Immutable
/*    */ public interface WelcomeScreenData
/*    */ {
/*    */   static ImmutableWelcomeScreenData.Builder builder() {
/* 17 */     return ImmutableWelcomeScreenData.builder();
/*    */   }
/*    */   
/*    */   Optional<String> description();
/*    */   
/*    */   @JsonProperty("welcome_channels")
/*    */   List<WelcomeScreenChannelData> welcomeChannels();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\WelcomeScreenData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */