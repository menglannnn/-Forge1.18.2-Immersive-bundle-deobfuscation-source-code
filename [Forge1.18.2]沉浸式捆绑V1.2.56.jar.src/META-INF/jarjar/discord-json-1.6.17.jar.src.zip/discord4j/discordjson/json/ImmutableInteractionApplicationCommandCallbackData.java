/*      */ package discord4j.discordjson.json;
/*      */ 
/*      */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*      */ import com.fasterxml.jackson.annotation.JsonCreator;
/*      */ import com.fasterxml.jackson.annotation.JsonProperty;
/*      */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*      */ import discord4j.discordjson.possible.Possible;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.List;
/*      */ import java.util.Objects;
/*      */ import java.util.stream.Collectors;
/*      */ import java.util.stream.StreamSupport;
/*      */ import org.immutables.value.Generated;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ @Generated(from = "InteractionApplicationCommandCallbackData", generator = "Immutables")
/*      */ public final class ImmutableInteractionApplicationCommandCallbackData
/*      */   implements InteractionApplicationCommandCallbackData
/*      */ {
/*      */   private final Boolean tts_value;
/*      */   private final boolean tts_absent;
/*      */   private final String content_value;
/*      */   private final boolean content_absent;
/*      */   private final List<EmbedData> embeds_value;
/*      */   private final boolean embeds_absent;
/*      */   private final AllowedMentionsData allowedMentions_value;
/*      */   private final boolean allowedMentions_absent;
/*      */   private final Integer flags_value;
/*      */   private final boolean flags_absent;
/*      */   private final List<ComponentData> components_value;
/*      */   private final boolean components_absent;
/*      */   private final List<ApplicationCommandOptionChoiceData> choices_value;
/*      */   private final boolean choices_absent;
/*      */   private final String customId_value;
/*      */   private final boolean customId_absent;
/*      */   private final String title_value;
/*      */   private final boolean title_absent;
/*      */   private static final byte STAGE_INITIALIZING = -1;
/*      */   private static final byte STAGE_UNINITIALIZED = 0;
/*      */   private static final byte STAGE_INITIALIZED = 1;
/*      */   
/*      */   private ImmutableInteractionApplicationCommandCallbackData(Possible<Boolean> tts, Possible<String> content, Possible<List<EmbedData>> embeds, Possible<AllowedMentionsData> allowedMentions, Possible<Integer> flags, Possible<List<ComponentData>> components, Possible<List<ApplicationCommandOptionChoiceData>> choices, Possible<String> customId, Possible<String> title) {
/*   58 */     Possible<Boolean> tts$impl = tts;
/*   59 */     Possible<String> content$impl = content;
/*   60 */     Possible<List<EmbedData>> embeds$impl = embeds;
/*   61 */     Possible<AllowedMentionsData> allowedMentions$impl = allowedMentions;
/*   62 */     Possible<Integer> flags$impl = flags;
/*   63 */     Possible<List<ComponentData>> components$impl = components;
/*   64 */     Possible<List<ApplicationCommandOptionChoiceData>> choices$impl = choices;
/*   65 */     Possible<String> customId$impl = customId;
/*   66 */     Possible<String> title$impl = title;
/*   67 */     this.tts_value = tts$impl.toOptional().orElse(null);
/*   68 */     this.tts_absent = tts$impl.isAbsent();
/*   69 */     this.content_value = content$impl.toOptional().orElse(null);
/*   70 */     this.content_absent = content$impl.isAbsent();
/*   71 */     this.embeds_value = embeds$impl.toOptional().orElse(null);
/*   72 */     this.embeds_absent = embeds$impl.isAbsent();
/*   73 */     this.allowedMentions_value = allowedMentions$impl.toOptional().orElse(null);
/*   74 */     this.allowedMentions_absent = allowedMentions$impl.isAbsent();
/*   75 */     this.flags_value = flags$impl.toOptional().orElse(null);
/*   76 */     this.flags_absent = flags$impl.isAbsent();
/*   77 */     this.components_value = components$impl.toOptional().orElse(null);
/*   78 */     this.components_absent = components$impl.isAbsent();
/*   79 */     this.choices_value = choices$impl.toOptional().orElse(null);
/*   80 */     this.choices_absent = choices$impl.isAbsent();
/*   81 */     this.customId_value = customId$impl.toOptional().orElse(null);
/*   82 */     this.customId_absent = customId$impl.isAbsent();
/*   83 */     this.title_value = title$impl.toOptional().orElse(null);
/*   84 */     this.title_absent = title$impl.isAbsent();
/*   85 */     this.initShim = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ImmutableInteractionApplicationCommandCallbackData(ImmutableInteractionApplicationCommandCallbackData original, Possible<Boolean> tts, Possible<String> content, Possible<List<EmbedData>> embeds, Possible<AllowedMentionsData> allowedMentions, Possible<Integer> flags, Possible<List<ComponentData>> components, Possible<List<ApplicationCommandOptionChoiceData>> choices, Possible<String> customId, Possible<String> title) {
/*   99 */     Possible<Boolean> tts$impl = tts;
/*  100 */     Possible<String> content$impl = content;
/*  101 */     Possible<List<EmbedData>> embeds$impl = embeds;
/*  102 */     Possible<AllowedMentionsData> allowedMentions$impl = allowedMentions;
/*  103 */     Possible<Integer> flags$impl = flags;
/*  104 */     Possible<List<ComponentData>> components$impl = components;
/*  105 */     Possible<List<ApplicationCommandOptionChoiceData>> choices$impl = choices;
/*  106 */     Possible<String> customId$impl = customId;
/*  107 */     Possible<String> title$impl = title;
/*  108 */     this.tts_value = tts$impl.toOptional().orElse(null);
/*  109 */     this.tts_absent = tts$impl.isAbsent();
/*  110 */     this.content_value = content$impl.toOptional().orElse(null);
/*  111 */     this.content_absent = content$impl.isAbsent();
/*  112 */     this.embeds_value = embeds$impl.toOptional().orElse(null);
/*  113 */     this.embeds_absent = embeds$impl.isAbsent();
/*  114 */     this.allowedMentions_value = allowedMentions$impl.toOptional().orElse(null);
/*  115 */     this.allowedMentions_absent = allowedMentions$impl.isAbsent();
/*  116 */     this.flags_value = flags$impl.toOptional().orElse(null);
/*  117 */     this.flags_absent = flags$impl.isAbsent();
/*  118 */     this.components_value = components$impl.toOptional().orElse(null);
/*  119 */     this.components_absent = components$impl.isAbsent();
/*  120 */     this.choices_value = choices$impl.toOptional().orElse(null);
/*  121 */     this.choices_absent = choices$impl.isAbsent();
/*  122 */     this.customId_value = customId$impl.toOptional().orElse(null);
/*  123 */     this.customId_absent = customId$impl.isAbsent();
/*  124 */     this.title_value = title$impl.toOptional().orElse(null);
/*  125 */     this.title_absent = title$impl.isAbsent();
/*  126 */     this.initShim = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  132 */   private volatile transient InitShim initShim = new InitShim();
/*      */   
/*      */   @Generated(from = "InteractionApplicationCommandCallbackData", generator = "Immutables")
/*      */   private final class InitShim {
/*      */     private String formatInitCycleMessage() {
/*  137 */       List<String> attributes = new ArrayList<>();
/*  138 */       return "Cannot build InteractionApplicationCommandCallbackData, attribute initializers form cycle " + attributes;
/*      */     }
/*      */ 
/*      */     
/*      */     private InitShim() {}
/*      */   }
/*      */ 
/*      */   
/*      */   @JsonProperty("tts")
/*      */   public Possible<Boolean> tts() {
/*  148 */     return this.tts_absent ? Possible.absent() : Possible.of(this.tts_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("content")
/*      */   public Possible<String> content() {
/*  157 */     return this.content_absent ? Possible.absent() : Possible.of(this.content_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("embeds")
/*      */   public Possible<List<EmbedData>> embeds() {
/*  166 */     return this.embeds_absent ? Possible.absent() : 
/*  167 */       Possible.of(this.embeds_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("allowed_mentions")
/*      */   public Possible<AllowedMentionsData> allowedMentions() {
/*  176 */     return this.allowedMentions_absent ? Possible.absent() : Possible.of(this.allowedMentions_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("flags")
/*      */   public Possible<Integer> flags() {
/*  185 */     return this.flags_absent ? Possible.absent() : Possible.of(this.flags_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("components")
/*      */   public Possible<List<ComponentData>> components() {
/*  194 */     return this.components_absent ? Possible.absent() : 
/*  195 */       Possible.of(this.components_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("choices")
/*      */   public Possible<List<ApplicationCommandOptionChoiceData>> choices() {
/*  207 */     return this.choices_absent ? Possible.absent() : 
/*  208 */       Possible.of(this.choices_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("custom_id")
/*      */   public Possible<String> customId() {
/*  217 */     return this.customId_absent ? Possible.absent() : Possible.of(this.customId_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("title")
/*      */   public Possible<String> title() {
/*  226 */     return this.title_absent ? Possible.absent() : Possible.of(this.title_value);
/*      */   }
/*      */   
/*      */   public ImmutableInteractionApplicationCommandCallbackData withTts(Possible<Boolean> value) {
/*  230 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/*  231 */     return new ImmutableInteractionApplicationCommandCallbackData(this, newValue, 
/*      */ 
/*      */         
/*  234 */         content(), 
/*  235 */         embeds(), 
/*  236 */         allowedMentions(), 
/*  237 */         flags(), 
/*  238 */         components(), 
/*  239 */         choices(), 
/*  240 */         customId(), 
/*  241 */         title());
/*      */   }
/*      */   
/*      */   public ImmutableInteractionApplicationCommandCallbackData withTts(Boolean value) {
/*  245 */     Possible<Boolean> newValue = Possible.of(value);
/*  246 */     return new ImmutableInteractionApplicationCommandCallbackData(this, newValue, 
/*      */ 
/*      */         
/*  249 */         content(), 
/*  250 */         embeds(), 
/*  251 */         allowedMentions(), 
/*  252 */         flags(), 
/*  253 */         components(), 
/*  254 */         choices(), 
/*  255 */         customId(), 
/*  256 */         title());
/*      */   }
/*      */   
/*      */   public ImmutableInteractionApplicationCommandCallbackData withContent(Possible<String> value) {
/*  260 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/*  261 */     return new ImmutableInteractionApplicationCommandCallbackData(this, 
/*      */         
/*  263 */         tts(), newValue, 
/*      */         
/*  265 */         embeds(), 
/*  266 */         allowedMentions(), 
/*  267 */         flags(), 
/*  268 */         components(), 
/*  269 */         choices(), 
/*  270 */         customId(), 
/*  271 */         title());
/*      */   }
/*      */   
/*      */   public ImmutableInteractionApplicationCommandCallbackData withContent(String value) {
/*  275 */     Possible<String> newValue = Possible.of(value);
/*  276 */     return new ImmutableInteractionApplicationCommandCallbackData(this, 
/*      */         
/*  278 */         tts(), newValue, 
/*      */         
/*  280 */         embeds(), 
/*  281 */         allowedMentions(), 
/*  282 */         flags(), 
/*  283 */         components(), 
/*  284 */         choices(), 
/*  285 */         customId(), 
/*  286 */         title());
/*      */   }
/*      */   
/*      */   public ImmutableInteractionApplicationCommandCallbackData withEmbeds(Possible<List<EmbedData>> possible) {
/*  290 */     Possible<List<EmbedData>> newValue = Objects.<Possible<List<EmbedData>>>requireNonNull(possible);
/*  291 */     return new ImmutableInteractionApplicationCommandCallbackData(this, 
/*      */         
/*  293 */         tts(), 
/*  294 */         content(), newValue, 
/*      */         
/*  296 */         allowedMentions(), 
/*  297 */         flags(), 
/*  298 */         components(), 
/*  299 */         choices(), 
/*  300 */         customId(), 
/*  301 */         title());
/*      */   }
/*      */   
/*      */   public ImmutableInteractionApplicationCommandCallbackData withEmbeds(Iterable<EmbedData> elements) {
/*  305 */     Possible<List<EmbedData>> newValue = Possible.of(
/*  306 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/*  307 */     return new ImmutableInteractionApplicationCommandCallbackData(this, 
/*      */         
/*  309 */         tts(), 
/*  310 */         content(), newValue, 
/*      */         
/*  312 */         allowedMentions(), 
/*  313 */         flags(), 
/*  314 */         components(), 
/*  315 */         choices(), 
/*  316 */         customId(), 
/*  317 */         title());
/*      */   }
/*      */   
/*      */   @SafeVarargs
/*      */   public final ImmutableInteractionApplicationCommandCallbackData withEmbeds(EmbedData... elements) {
/*  322 */     Possible<List<EmbedData>> newValue = Possible.of(Arrays.asList(elements));
/*  323 */     return new ImmutableInteractionApplicationCommandCallbackData(this, 
/*      */         
/*  325 */         tts(), 
/*  326 */         content(), newValue, 
/*      */         
/*  328 */         allowedMentions(), 
/*  329 */         flags(), 
/*  330 */         components(), 
/*  331 */         choices(), 
/*  332 */         customId(), 
/*  333 */         title());
/*      */   }
/*      */   
/*      */   public ImmutableInteractionApplicationCommandCallbackData withAllowedMentions(Possible<AllowedMentionsData> value) {
/*  337 */     Possible<AllowedMentionsData> newValue = Objects.<Possible<AllowedMentionsData>>requireNonNull(value);
/*  338 */     return new ImmutableInteractionApplicationCommandCallbackData(this, 
/*      */         
/*  340 */         tts(), 
/*  341 */         content(), 
/*  342 */         embeds(), newValue, 
/*      */         
/*  344 */         flags(), 
/*  345 */         components(), 
/*  346 */         choices(), 
/*  347 */         customId(), 
/*  348 */         title());
/*      */   }
/*      */   
/*      */   public ImmutableInteractionApplicationCommandCallbackData withAllowedMentions(AllowedMentionsData value) {
/*  352 */     Possible<AllowedMentionsData> newValue = Possible.of(value);
/*  353 */     return new ImmutableInteractionApplicationCommandCallbackData(this, 
/*      */         
/*  355 */         tts(), 
/*  356 */         content(), 
/*  357 */         embeds(), newValue, 
/*      */         
/*  359 */         flags(), 
/*  360 */         components(), 
/*  361 */         choices(), 
/*  362 */         customId(), 
/*  363 */         title());
/*      */   }
/*      */   
/*      */   public ImmutableInteractionApplicationCommandCallbackData withFlags(Possible<Integer> value) {
/*  367 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/*  368 */     return new ImmutableInteractionApplicationCommandCallbackData(this, 
/*      */         
/*  370 */         tts(), 
/*  371 */         content(), 
/*  372 */         embeds(), 
/*  373 */         allowedMentions(), newValue, 
/*      */         
/*  375 */         components(), 
/*  376 */         choices(), 
/*  377 */         customId(), 
/*  378 */         title());
/*      */   }
/*      */   
/*      */   public ImmutableInteractionApplicationCommandCallbackData withFlags(Integer value) {
/*  382 */     Possible<Integer> newValue = Possible.of(value);
/*  383 */     return new ImmutableInteractionApplicationCommandCallbackData(this, 
/*      */         
/*  385 */         tts(), 
/*  386 */         content(), 
/*  387 */         embeds(), 
/*  388 */         allowedMentions(), newValue, 
/*      */         
/*  390 */         components(), 
/*  391 */         choices(), 
/*  392 */         customId(), 
/*  393 */         title());
/*      */   }
/*      */   
/*      */   public ImmutableInteractionApplicationCommandCallbackData withComponents(Possible<List<ComponentData>> possible) {
/*  397 */     Possible<List<ComponentData>> newValue = Objects.<Possible<List<ComponentData>>>requireNonNull(possible);
/*  398 */     return new ImmutableInteractionApplicationCommandCallbackData(this, 
/*      */         
/*  400 */         tts(), 
/*  401 */         content(), 
/*  402 */         embeds(), 
/*  403 */         allowedMentions(), 
/*  404 */         flags(), newValue, 
/*      */         
/*  406 */         choices(), 
/*  407 */         customId(), 
/*  408 */         title());
/*      */   }
/*      */   
/*      */   public ImmutableInteractionApplicationCommandCallbackData withComponents(Iterable<ComponentData> elements) {
/*  412 */     Possible<List<ComponentData>> newValue = Possible.of(
/*  413 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/*  414 */     return new ImmutableInteractionApplicationCommandCallbackData(this, 
/*      */         
/*  416 */         tts(), 
/*  417 */         content(), 
/*  418 */         embeds(), 
/*  419 */         allowedMentions(), 
/*  420 */         flags(), newValue, 
/*      */         
/*  422 */         choices(), 
/*  423 */         customId(), 
/*  424 */         title());
/*      */   }
/*      */   
/*      */   @SafeVarargs
/*      */   public final ImmutableInteractionApplicationCommandCallbackData withComponents(ComponentData... elements) {
/*  429 */     Possible<List<ComponentData>> newValue = Possible.of(Arrays.asList(elements));
/*  430 */     return new ImmutableInteractionApplicationCommandCallbackData(this, 
/*      */         
/*  432 */         tts(), 
/*  433 */         content(), 
/*  434 */         embeds(), 
/*  435 */         allowedMentions(), 
/*  436 */         flags(), newValue, 
/*      */         
/*  438 */         choices(), 
/*  439 */         customId(), 
/*  440 */         title());
/*      */   }
/*      */   
/*      */   public ImmutableInteractionApplicationCommandCallbackData withChoices(Possible<List<ApplicationCommandOptionChoiceData>> possible) {
/*  444 */     Possible<List<ApplicationCommandOptionChoiceData>> newValue = Objects.<Possible<List<ApplicationCommandOptionChoiceData>>>requireNonNull(possible);
/*  445 */     return new ImmutableInteractionApplicationCommandCallbackData(this, 
/*      */         
/*  447 */         tts(), 
/*  448 */         content(), 
/*  449 */         embeds(), 
/*  450 */         allowedMentions(), 
/*  451 */         flags(), 
/*  452 */         components(), newValue, 
/*      */         
/*  454 */         customId(), 
/*  455 */         title());
/*      */   }
/*      */   
/*      */   public ImmutableInteractionApplicationCommandCallbackData withChoices(Iterable<ApplicationCommandOptionChoiceData> elements) {
/*  459 */     Possible<List<ApplicationCommandOptionChoiceData>> newValue = Possible.of(
/*  460 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/*  461 */     return new ImmutableInteractionApplicationCommandCallbackData(this, 
/*      */         
/*  463 */         tts(), 
/*  464 */         content(), 
/*  465 */         embeds(), 
/*  466 */         allowedMentions(), 
/*  467 */         flags(), 
/*  468 */         components(), newValue, 
/*      */         
/*  470 */         customId(), 
/*  471 */         title());
/*      */   }
/*      */   
/*      */   @SafeVarargs
/*      */   public final ImmutableInteractionApplicationCommandCallbackData withChoices(ApplicationCommandOptionChoiceData... elements) {
/*  476 */     Possible<List<ApplicationCommandOptionChoiceData>> newValue = Possible.of(Arrays.asList(elements));
/*  477 */     return new ImmutableInteractionApplicationCommandCallbackData(this, 
/*      */         
/*  479 */         tts(), 
/*  480 */         content(), 
/*  481 */         embeds(), 
/*  482 */         allowedMentions(), 
/*  483 */         flags(), 
/*  484 */         components(), newValue, 
/*      */         
/*  486 */         customId(), 
/*  487 */         title());
/*      */   }
/*      */   
/*      */   public ImmutableInteractionApplicationCommandCallbackData withCustomId(Possible<String> value) {
/*  491 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/*  492 */     return new ImmutableInteractionApplicationCommandCallbackData(this, 
/*      */         
/*  494 */         tts(), 
/*  495 */         content(), 
/*  496 */         embeds(), 
/*  497 */         allowedMentions(), 
/*  498 */         flags(), 
/*  499 */         components(), 
/*  500 */         choices(), newValue, 
/*      */         
/*  502 */         title());
/*      */   }
/*      */   
/*      */   public ImmutableInteractionApplicationCommandCallbackData withCustomId(String value) {
/*  506 */     Possible<String> newValue = Possible.of(value);
/*  507 */     return new ImmutableInteractionApplicationCommandCallbackData(this, 
/*      */         
/*  509 */         tts(), 
/*  510 */         content(), 
/*  511 */         embeds(), 
/*  512 */         allowedMentions(), 
/*  513 */         flags(), 
/*  514 */         components(), 
/*  515 */         choices(), newValue, 
/*      */         
/*  517 */         title());
/*      */   }
/*      */   
/*      */   public ImmutableInteractionApplicationCommandCallbackData withTitle(Possible<String> value) {
/*  521 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/*  522 */     return new ImmutableInteractionApplicationCommandCallbackData(this, 
/*      */         
/*  524 */         tts(), 
/*  525 */         content(), 
/*  526 */         embeds(), 
/*  527 */         allowedMentions(), 
/*  528 */         flags(), 
/*  529 */         components(), 
/*  530 */         choices(), 
/*  531 */         customId(), newValue);
/*      */   }
/*      */ 
/*      */   
/*      */   public ImmutableInteractionApplicationCommandCallbackData withTitle(String value) {
/*  536 */     Possible<String> newValue = Possible.of(value);
/*  537 */     return new ImmutableInteractionApplicationCommandCallbackData(this, 
/*      */         
/*  539 */         tts(), 
/*  540 */         content(), 
/*  541 */         embeds(), 
/*  542 */         allowedMentions(), 
/*  543 */         flags(), 
/*  544 */         components(), 
/*  545 */         choices(), 
/*  546 */         customId(), newValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean equals(Object another) {
/*  556 */     if (this == another) return true; 
/*  557 */     return (another instanceof ImmutableInteractionApplicationCommandCallbackData && 
/*  558 */       equalTo(0, (ImmutableInteractionApplicationCommandCallbackData)another));
/*      */   }
/*      */   
/*      */   private boolean equalTo(int synthetic, ImmutableInteractionApplicationCommandCallbackData another) {
/*  562 */     return (tts().equals(another.tts()) && 
/*  563 */       content().equals(another.content()) && 
/*  564 */       Objects.equals(this.embeds_value, another.embeds_value) && 
/*  565 */       allowedMentions().equals(another.allowedMentions()) && 
/*  566 */       flags().equals(another.flags()) && 
/*  567 */       Objects.equals(this.components_value, another.components_value) && 
/*  568 */       Objects.equals(this.choices_value, another.choices_value) && 
/*  569 */       customId().equals(another.customId()) && 
/*  570 */       title().equals(another.title()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int hashCode() {
/*  579 */     int h = 5381;
/*  580 */     h += (h << 5) + tts().hashCode();
/*  581 */     h += (h << 5) + content().hashCode();
/*  582 */     h += (h << 5) + Objects.hashCode(this.embeds_value);
/*  583 */     h += (h << 5) + allowedMentions().hashCode();
/*  584 */     h += (h << 5) + flags().hashCode();
/*  585 */     h += (h << 5) + Objects.hashCode(this.components_value);
/*  586 */     h += (h << 5) + Objects.hashCode(this.choices_value);
/*  587 */     h += (h << 5) + customId().hashCode();
/*  588 */     h += (h << 5) + title().hashCode();
/*  589 */     return h;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/*  598 */     return "InteractionApplicationCommandCallbackData{tts=" + 
/*  599 */       tts().toString() + ", content=" + 
/*  600 */       content().toString() + ", embeds=" + 
/*  601 */       Objects.toString(this.embeds_value) + ", allowedMentions=" + 
/*  602 */       allowedMentions().toString() + ", flags=" + 
/*  603 */       flags().toString() + ", components=" + 
/*  604 */       Objects.toString(this.components_value) + ", choices=" + 
/*  605 */       Objects.toString(this.choices_value) + ", customId=" + 
/*  606 */       customId().toString() + ", title=" + 
/*  607 */       title().toString() + "}";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonDeserialize
/*      */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*      */   @Generated(from = "InteractionApplicationCommandCallbackData", generator = "Immutables")
/*      */   static final class Json
/*      */     implements InteractionApplicationCommandCallbackData
/*      */   {
/*  621 */     Possible<Boolean> tts = Possible.absent();
/*      */ 
/*      */     
/*  624 */     Possible<String> content = Possible.absent();
/*      */ 
/*      */     
/*  627 */     Possible<List<EmbedData>> embeds = Possible.absent();
/*      */ 
/*      */     
/*  630 */     Possible<AllowedMentionsData> allowedMentions = Possible.absent();
/*      */ 
/*      */     
/*  633 */     Possible<Integer> flags = Possible.absent();
/*      */ 
/*      */     
/*  636 */     Possible<List<ComponentData>> components = Possible.absent();
/*      */ 
/*      */     
/*  639 */     Possible<List<ApplicationCommandOptionChoiceData>> choices = Possible.absent();
/*      */ 
/*      */     
/*  642 */     Possible<String> customId = Possible.absent();
/*      */ 
/*      */     
/*  645 */     Possible<String> title = Possible.absent();
/*      */     
/*      */     @JsonProperty("tts")
/*      */     public void setTts(Possible<Boolean> tts) {
/*  649 */       this.tts = tts;
/*      */     }
/*      */     @JsonProperty("content")
/*      */     public void setContent(Possible<String> content) {
/*  653 */       this.content = content;
/*      */     }
/*      */     @JsonProperty("embeds")
/*      */     public void setEmbeds(Possible<List<EmbedData>> embeds) {
/*  657 */       this.embeds = embeds;
/*      */     }
/*      */     @JsonProperty("allowed_mentions")
/*      */     public void setAllowedMentions(Possible<AllowedMentionsData> allowedMentions) {
/*  661 */       this.allowedMentions = allowedMentions;
/*      */     }
/*      */     @JsonProperty("flags")
/*      */     public void setFlags(Possible<Integer> flags) {
/*  665 */       this.flags = flags;
/*      */     }
/*      */     @JsonProperty("components")
/*      */     public void setComponents(Possible<List<ComponentData>> components) {
/*  669 */       this.components = components;
/*      */     }
/*      */     @JsonProperty("choices")
/*      */     public void setChoices(Possible<List<ApplicationCommandOptionChoiceData>> choices) {
/*  673 */       this.choices = choices;
/*      */     }
/*      */     @JsonProperty("custom_id")
/*      */     public void setCustomId(Possible<String> customId) {
/*  677 */       this.customId = customId;
/*      */     }
/*      */     @JsonProperty("title")
/*      */     public void setTitle(Possible<String> title) {
/*  681 */       this.title = title;
/*      */     }
/*      */     public Possible<Boolean> tts() {
/*  684 */       throw new UnsupportedOperationException();
/*      */     } public Possible<String> content() {
/*  686 */       throw new UnsupportedOperationException();
/*      */     } public Possible<List<EmbedData>> embeds() {
/*  688 */       throw new UnsupportedOperationException();
/*      */     } public Possible<AllowedMentionsData> allowedMentions() {
/*  690 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Integer> flags() {
/*  692 */       throw new UnsupportedOperationException();
/*      */     } public Possible<List<ComponentData>> components() {
/*  694 */       throw new UnsupportedOperationException();
/*      */     } public Possible<List<ApplicationCommandOptionChoiceData>> choices() {
/*  696 */       throw new UnsupportedOperationException();
/*      */     } public Possible<String> customId() {
/*  698 */       throw new UnsupportedOperationException();
/*      */     } public Possible<String> title() {
/*  700 */       throw new UnsupportedOperationException();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*      */   static ImmutableInteractionApplicationCommandCallbackData fromJson(Json json) {
/*  711 */     Builder builder = builder();
/*  712 */     if (json.tts != null) {
/*  713 */       builder.tts(json.tts);
/*      */     }
/*  715 */     if (json.content != null) {
/*  716 */       builder.content(json.content);
/*      */     }
/*  718 */     if (json.embeds != null) {
/*  719 */       builder.embeds(json.embeds);
/*      */     }
/*  721 */     if (json.allowedMentions != null) {
/*  722 */       builder.allowedMentions(json.allowedMentions);
/*      */     }
/*  724 */     if (json.flags != null) {
/*  725 */       builder.flags(json.flags);
/*      */     }
/*  727 */     if (json.components != null) {
/*  728 */       builder.components(json.components);
/*      */     }
/*  730 */     if (json.choices != null) {
/*  731 */       builder.choices(json.choices);
/*      */     }
/*  733 */     if (json.customId != null) {
/*  734 */       builder.customId(json.customId);
/*      */     }
/*  736 */     if (json.title != null) {
/*  737 */       builder.title(json.title);
/*      */     }
/*  739 */     return builder.build();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableInteractionApplicationCommandCallbackData of(Possible<Boolean> tts, Possible<String> content, Possible<List<EmbedData>> embeds, Possible<AllowedMentionsData> allowedMentions, Possible<Integer> flags, Possible<List<ComponentData>> components, Possible<List<ApplicationCommandOptionChoiceData>> choices, Possible<String> customId, Possible<String> title) {
/*  756 */     return new ImmutableInteractionApplicationCommandCallbackData(tts, content, embeds, allowedMentions, flags, components, choices, customId, title);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableInteractionApplicationCommandCallbackData copyOf(InteractionApplicationCommandCallbackData instance) {
/*  767 */     if (instance instanceof ImmutableInteractionApplicationCommandCallbackData) {
/*  768 */       return (ImmutableInteractionApplicationCommandCallbackData)instance;
/*      */     }
/*  770 */     return builder()
/*  771 */       .from(instance)
/*  772 */       .build();
/*      */   }
/*      */   
/*      */   public boolean isTtsPresent() {
/*  776 */     return !this.tts_absent;
/*      */   }
/*      */   
/*      */   public Boolean ttsOrElse(Boolean defaultValue) {
/*  780 */     return !this.tts_absent ? this.tts_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isContentPresent() {
/*  784 */     return !this.content_absent;
/*      */   }
/*      */   
/*      */   public String contentOrElse(String defaultValue) {
/*  788 */     return !this.content_absent ? this.content_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isEmbedsPresent() {
/*  792 */     return !this.embeds_absent;
/*      */   }
/*      */   
/*      */   public List<EmbedData> embedsOrElse(List<EmbedData> defaultValue) {
/*  796 */     return !this.embeds_absent ? this.embeds_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isAllowedMentionsPresent() {
/*  800 */     return !this.allowedMentions_absent;
/*      */   }
/*      */   
/*      */   public AllowedMentionsData allowedMentionsOrElse(AllowedMentionsData defaultValue) {
/*  804 */     return !this.allowedMentions_absent ? this.allowedMentions_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isFlagsPresent() {
/*  808 */     return !this.flags_absent;
/*      */   }
/*      */   
/*      */   public Integer flagsOrElse(Integer defaultValue) {
/*  812 */     return !this.flags_absent ? this.flags_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isComponentsPresent() {
/*  816 */     return !this.components_absent;
/*      */   }
/*      */   
/*      */   public List<ComponentData> componentsOrElse(List<ComponentData> defaultValue) {
/*  820 */     return !this.components_absent ? this.components_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isChoicesPresent() {
/*  824 */     return !this.choices_absent;
/*      */   }
/*      */   
/*      */   public List<ApplicationCommandOptionChoiceData> choicesOrElse(List<ApplicationCommandOptionChoiceData> defaultValue) {
/*  828 */     return !this.choices_absent ? this.choices_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isCustomIdPresent() {
/*  832 */     return !this.customId_absent;
/*      */   }
/*      */   
/*      */   public String customIdOrElse(String defaultValue) {
/*  836 */     return !this.customId_absent ? this.customId_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isTitlePresent() {
/*  840 */     return !this.title_absent;
/*      */   }
/*      */   
/*      */   public String titleOrElse(String defaultValue) {
/*  844 */     return !this.title_absent ? this.title_value : defaultValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Builder builder() {
/*  865 */     return new Builder();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Generated(from = "InteractionApplicationCommandCallbackData", generator = "Immutables")
/*      */   public static final class Builder
/*      */   {
/*  877 */     private Possible<Boolean> tts_possible = Possible.absent();
/*  878 */     private Possible<String> content_possible = Possible.absent();
/*  879 */     private List<EmbedData> embeds_list = null;
/*  880 */     private Possible<AllowedMentionsData> allowedMentions_possible = Possible.absent();
/*  881 */     private Possible<Integer> flags_possible = Possible.absent();
/*  882 */     private List<ComponentData> components_list = null;
/*  883 */     private List<ApplicationCommandOptionChoiceData> choices_list = null;
/*  884 */     private Possible<String> customId_possible = Possible.absent();
/*  885 */     private Possible<String> title_possible = Possible.absent();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder from(InteractionApplicationCommandCallbackData instance) {
/*  898 */       Objects.requireNonNull(instance, "instance");
/*  899 */       tts(instance.tts());
/*  900 */       content(instance.content());
/*  901 */       embeds(instance.embeds());
/*  902 */       allowedMentions(instance.allowedMentions());
/*  903 */       flags(instance.flags());
/*  904 */       components(instance.components());
/*  905 */       choices(instance.choices());
/*  906 */       customId(instance.customId());
/*  907 */       title(instance.title());
/*  908 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("tts")
/*      */     public Builder tts(Possible<Boolean> value) {
/*  913 */       this.tts_possible = value;
/*  914 */       return this;
/*      */     }
/*      */     
/*      */     public Builder tts(Boolean value) {
/*  918 */       this.tts_possible = Possible.of(value);
/*  919 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("content")
/*      */     public Builder content(Possible<String> value) {
/*  924 */       this.content_possible = value;
/*  925 */       return this;
/*      */     }
/*      */     
/*      */     public Builder content(String value) {
/*  929 */       this.content_possible = Possible.of(value);
/*  930 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addEmbed(EmbedData element) {
/*  934 */       embeds_getOrCreate().add(element);
/*  935 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addAllEmbeds(List<EmbedData> elements) {
/*  939 */       embeds_getOrCreate().addAll(elements);
/*  940 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("embeds")
/*      */     public Builder embeds(Possible<List<EmbedData>> elements) {
/*  945 */       this.embeds_list = null;
/*  946 */       elements.toOptional().ifPresent(e -> embeds_getOrCreate().addAll(e));
/*  947 */       return this;
/*      */     }
/*      */     
/*      */     public Builder embeds(List<EmbedData> elements) {
/*  951 */       this.embeds_list = new ArrayList<>(elements);
/*  952 */       return this;
/*      */     }
/*      */     
/*      */     public Builder embeds(Iterable<EmbedData> elements) {
/*  956 */       this.embeds_list = (List<EmbedData>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/*  957 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("allowed_mentions")
/*      */     public Builder allowedMentions(Possible<AllowedMentionsData> value) {
/*  962 */       this.allowedMentions_possible = value;
/*  963 */       return this;
/*      */     }
/*      */     
/*      */     public Builder allowedMentions(AllowedMentionsData value) {
/*  967 */       this.allowedMentions_possible = Possible.of(value);
/*  968 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("flags")
/*      */     public Builder flags(Possible<Integer> value) {
/*  973 */       this.flags_possible = value;
/*  974 */       return this;
/*      */     }
/*      */     
/*      */     public Builder flags(Integer value) {
/*  978 */       this.flags_possible = Possible.of(value);
/*  979 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addComponent(ComponentData element) {
/*  983 */       components_getOrCreate().add(element);
/*  984 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addAllComponents(List<ComponentData> elements) {
/*  988 */       components_getOrCreate().addAll(elements);
/*  989 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("components")
/*      */     public Builder components(Possible<List<ComponentData>> elements) {
/*  994 */       this.components_list = null;
/*  995 */       elements.toOptional().ifPresent(e -> components_getOrCreate().addAll(e));
/*  996 */       return this;
/*      */     }
/*      */     
/*      */     public Builder components(List<ComponentData> elements) {
/* 1000 */       this.components_list = new ArrayList<>(elements);
/* 1001 */       return this;
/*      */     }
/*      */     
/*      */     public Builder components(Iterable<ComponentData> elements) {
/* 1005 */       this.components_list = (List<ComponentData>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/* 1006 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addChoice(ApplicationCommandOptionChoiceData element) {
/* 1010 */       choices_getOrCreate().add(element);
/* 1011 */       return this;
/*      */     }
/*      */     
/*      */     public Builder addAllChoices(List<ApplicationCommandOptionChoiceData> elements) {
/* 1015 */       choices_getOrCreate().addAll(elements);
/* 1016 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("choices")
/*      */     public Builder choices(Possible<List<ApplicationCommandOptionChoiceData>> elements) {
/* 1021 */       this.choices_list = null;
/* 1022 */       elements.toOptional().ifPresent(e -> choices_getOrCreate().addAll(e));
/* 1023 */       return this;
/*      */     }
/*      */     
/*      */     public Builder choices(List<ApplicationCommandOptionChoiceData> elements) {
/* 1027 */       this.choices_list = new ArrayList<>(elements);
/* 1028 */       return this;
/*      */     }
/*      */     
/*      */     public Builder choices(Iterable<ApplicationCommandOptionChoiceData> elements) {
/* 1032 */       this.choices_list = (List<ApplicationCommandOptionChoiceData>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/* 1033 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("custom_id")
/*      */     public Builder customId(Possible<String> value) {
/* 1038 */       this.customId_possible = value;
/* 1039 */       return this;
/*      */     }
/*      */     
/*      */     public Builder customId(String value) {
/* 1043 */       this.customId_possible = Possible.of(value);
/* 1044 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("title")
/*      */     public Builder title(Possible<String> value) {
/* 1049 */       this.title_possible = value;
/* 1050 */       return this;
/*      */     }
/*      */     
/*      */     public Builder title(String value) {
/* 1054 */       this.title_possible = Possible.of(value);
/* 1055 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ImmutableInteractionApplicationCommandCallbackData build() {
/* 1064 */       return new ImmutableInteractionApplicationCommandCallbackData(null, 
/*      */           
/* 1066 */           tts_build(), 
/* 1067 */           content_build(), 
/* 1068 */           embeds_build(), 
/* 1069 */           allowedMentions_build(), 
/* 1070 */           flags_build(), 
/* 1071 */           components_build(), 
/* 1072 */           choices_build(), 
/* 1073 */           customId_build(), 
/* 1074 */           title_build());
/*      */     }
/*      */     
/*      */     private Possible<Boolean> tts_build() {
/* 1078 */       return this.tts_possible;
/*      */     }
/*      */     
/*      */     private Possible<String> content_build() {
/* 1082 */       return this.content_possible;
/*      */     }
/*      */     
/*      */     private Possible<List<EmbedData>> embeds_build() {
/* 1086 */       return (this.embeds_list == null) ? Possible.absent() : 
/* 1087 */         Possible.of(this.embeds_list);
/*      */     }
/*      */     
/*      */     private List<EmbedData> embeds_getOrCreate() {
/* 1091 */       if (this.embeds_list == null) {
/* 1092 */         this.embeds_list = new ArrayList<>();
/*      */       }
/* 1094 */       return this.embeds_list;
/*      */     }
/*      */     
/*      */     private Possible<AllowedMentionsData> allowedMentions_build() {
/* 1098 */       return this.allowedMentions_possible;
/*      */     }
/*      */     
/*      */     private Possible<Integer> flags_build() {
/* 1102 */       return this.flags_possible;
/*      */     }
/*      */     
/*      */     private Possible<List<ComponentData>> components_build() {
/* 1106 */       return (this.components_list == null) ? Possible.absent() : 
/* 1107 */         Possible.of(this.components_list);
/*      */     }
/*      */     
/*      */     private List<ComponentData> components_getOrCreate() {
/* 1111 */       if (this.components_list == null) {
/* 1112 */         this.components_list = new ArrayList<>();
/*      */       }
/* 1114 */       return this.components_list;
/*      */     }
/*      */     
/*      */     private Possible<List<ApplicationCommandOptionChoiceData>> choices_build() {
/* 1118 */       return (this.choices_list == null) ? Possible.absent() : 
/* 1119 */         Possible.of(this.choices_list);
/*      */     }
/*      */     
/*      */     private List<ApplicationCommandOptionChoiceData> choices_getOrCreate() {
/* 1123 */       if (this.choices_list == null) {
/* 1124 */         this.choices_list = new ArrayList<>();
/*      */       }
/* 1126 */       return this.choices_list;
/*      */     }
/*      */     
/*      */     private Possible<String> customId_build() {
/* 1130 */       return this.customId_possible;
/*      */     }
/*      */     
/*      */     private Possible<String> title_build() {
/* 1134 */       return this.title_possible;
/*      */     }
/*      */     
/*      */     private Builder() {}
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableInteractionApplicationCommandCallbackData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */