/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.Id;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "IntegrationApplicationData", generator = "Immutables")
/*     */ public final class ImmutableIntegrationApplicationData
/*     */   implements IntegrationApplicationData
/*     */ {
/*     */   private final long id_value;
/*     */   private final String name;
/*     */   private final String icon;
/*     */   private final String description;
/*     */   private final String summary;
/*     */   private final UserData bot_value;
/*     */   private final boolean bot_absent;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   
/*     */   private ImmutableIntegrationApplicationData(Id id, String name, Optional<String> icon, String description, String summary, Possible<UserData> bot) {
/*  43 */     Id id$impl = id;
/*  44 */     this.name = Objects.<String>requireNonNull(name, "name");
/*  45 */     this.icon = icon.orElse(null);
/*  46 */     this.description = Objects.<String>requireNonNull(description, "description");
/*  47 */     this.summary = Objects.<String>requireNonNull(summary, "summary");
/*  48 */     Possible<UserData> bot$impl = bot;
/*  49 */     this.id_value = id$impl.asLong();
/*  50 */     this.bot_value = bot$impl.toOptional().orElse(null);
/*  51 */     this.bot_absent = bot$impl.isAbsent();
/*  52 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ImmutableIntegrationApplicationData(ImmutableIntegrationApplicationData original, Id id, String name, String icon, String description, String summary, Possible<UserData> bot) {
/*  63 */     Id id$impl = id;
/*  64 */     this.name = name;
/*  65 */     this.icon = icon;
/*  66 */     this.description = description;
/*  67 */     this.summary = summary;
/*  68 */     Possible<UserData> bot$impl = bot;
/*  69 */     this.id_value = id$impl.asLong();
/*  70 */     this.bot_value = bot$impl.toOptional().orElse(null);
/*  71 */     this.bot_absent = bot$impl.isAbsent();
/*  72 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  78 */   private volatile transient InitShim initShim = new InitShim();
/*     */   
/*     */   @Generated(from = "IntegrationApplicationData", generator = "Immutables")
/*     */   private final class InitShim {
/*     */     private String formatInitCycleMessage() {
/*  83 */       List<String> attributes = new ArrayList<>();
/*  84 */       return "Cannot build IntegrationApplicationData, attribute initializers form cycle " + attributes;
/*     */     }
/*     */ 
/*     */     
/*     */     private InitShim() {}
/*     */   }
/*     */ 
/*     */   
/*     */   @JsonProperty("id")
/*     */   public Id id() {
/*  94 */     return Id.of(this.id_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("name")
/*     */   public String name() {
/* 103 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("icon")
/*     */   public Optional<String> icon() {
/* 112 */     return Optional.ofNullable(this.icon);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("description")
/*     */   public String description() {
/* 121 */     return this.description;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("summary")
/*     */   public String summary() {
/* 130 */     return this.summary;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("bot")
/*     */   public Possible<UserData> bot() {
/* 139 */     return this.bot_absent ? Possible.absent() : Possible.of(this.bot_value);
/*     */   }
/*     */   
/*     */   public ImmutableIntegrationApplicationData withId(long value) {
/* 143 */     Id newValue = Id.of(value);
/* 144 */     return new ImmutableIntegrationApplicationData(this, newValue, this.name, this.icon, this.description, this.summary, bot());
/*     */   }
/*     */   
/*     */   public ImmutableIntegrationApplicationData withId(String value) {
/* 148 */     Id newValue = Id.of(value);
/* 149 */     return new ImmutableIntegrationApplicationData(this, newValue, this.name, this.icon, this.description, this.summary, bot());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableIntegrationApplicationData withName(String value) {
/* 159 */     String newValue = Objects.<String>requireNonNull(value, "name");
/* 160 */     if (this.name.equals(newValue)) return this; 
/* 161 */     return new ImmutableIntegrationApplicationData(this, id(), newValue, this.icon, this.description, this.summary, bot());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableIntegrationApplicationData withIcon(String value) {
/* 170 */     String newValue = Objects.<String>requireNonNull(value, "icon");
/* 171 */     if (Objects.equals(this.icon, newValue)) return this; 
/* 172 */     return new ImmutableIntegrationApplicationData(this, id(), this.name, newValue, this.description, this.summary, bot());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableIntegrationApplicationData withIcon(Optional<String> optional) {
/* 182 */     String value = optional.orElse(null);
/* 183 */     if (Objects.equals(this.icon, value)) return this; 
/* 184 */     return new ImmutableIntegrationApplicationData(this, id(), this.name, value, this.description, this.summary, bot());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableIntegrationApplicationData withDescription(String value) {
/* 194 */     String newValue = Objects.<String>requireNonNull(value, "description");
/* 195 */     if (this.description.equals(newValue)) return this; 
/* 196 */     return new ImmutableIntegrationApplicationData(this, id(), this.name, this.icon, newValue, this.summary, bot());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableIntegrationApplicationData withSummary(String value) {
/* 206 */     String newValue = Objects.<String>requireNonNull(value, "summary");
/* 207 */     if (this.summary.equals(newValue)) return this; 
/* 208 */     return new ImmutableIntegrationApplicationData(this, id(), this.name, this.icon, this.description, newValue, bot());
/*     */   }
/*     */   
/*     */   public ImmutableIntegrationApplicationData withBot(Possible<UserData> value) {
/* 212 */     Possible<UserData> newValue = Objects.<Possible<UserData>>requireNonNull(value);
/* 213 */     return new ImmutableIntegrationApplicationData(this, id(), this.name, this.icon, this.description, this.summary, newValue);
/*     */   }
/*     */   
/*     */   public ImmutableIntegrationApplicationData withBot(UserData value) {
/* 217 */     Possible<UserData> newValue = Possible.of(value);
/* 218 */     return new ImmutableIntegrationApplicationData(this, id(), this.name, this.icon, this.description, this.summary, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 227 */     if (this == another) return true; 
/* 228 */     return (another instanceof ImmutableIntegrationApplicationData && 
/* 229 */       equalTo(0, (ImmutableIntegrationApplicationData)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableIntegrationApplicationData another) {
/* 233 */     return (Objects.equals(Long.valueOf(this.id_value), Long.valueOf(another.id_value)) && this.name
/* 234 */       .equals(another.name) && 
/* 235 */       Objects.equals(this.icon, another.icon) && this.description
/* 236 */       .equals(another.description) && this.summary
/* 237 */       .equals(another.summary) && 
/* 238 */       bot().equals(another.bot()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 247 */     int h = 5381;
/* 248 */     h += (h << 5) + Objects.hashCode(Long.valueOf(this.id_value));
/* 249 */     h += (h << 5) + this.name.hashCode();
/* 250 */     h += (h << 5) + Objects.hashCode(this.icon);
/* 251 */     h += (h << 5) + this.description.hashCode();
/* 252 */     h += (h << 5) + this.summary.hashCode();
/* 253 */     h += (h << 5) + bot().hashCode();
/* 254 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 263 */     StringBuilder builder = new StringBuilder("IntegrationApplicationData{");
/* 264 */     builder.append("id=").append(Objects.toString(Long.valueOf(this.id_value)));
/* 265 */     builder.append(", ");
/* 266 */     builder.append("name=").append(this.name);
/* 267 */     if (this.icon != null) {
/* 268 */       builder.append(", ");
/* 269 */       builder.append("icon=").append(this.icon);
/*     */     } 
/* 271 */     builder.append(", ");
/* 272 */     builder.append("description=").append(this.description);
/* 273 */     builder.append(", ");
/* 274 */     builder.append("summary=").append(this.summary);
/* 275 */     builder.append(", ");
/* 276 */     builder.append("bot=").append(bot().toString());
/* 277 */     return builder.append("}").toString();
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "IntegrationApplicationData", generator = "Immutables")
/*     */   static final class Json
/*     */     implements IntegrationApplicationData
/*     */   {
/*     */     Id id;
/*     */     
/*     */     String name;
/* 291 */     Optional<String> icon = Optional.empty();
/*     */     
/*     */     String description;
/*     */     String summary;
/* 295 */     Possible<UserData> bot = Possible.absent();
/*     */     
/*     */     @JsonProperty("id")
/*     */     public void setId(Id id) {
/* 299 */       this.id = id;
/*     */     }
/*     */     @JsonProperty("name")
/*     */     public void setName(String name) {
/* 303 */       this.name = name;
/*     */     }
/*     */     @JsonProperty("icon")
/*     */     public void setIcon(Optional<String> icon) {
/* 307 */       this.icon = icon;
/*     */     }
/*     */     @JsonProperty("description")
/*     */     public void setDescription(String description) {
/* 311 */       this.description = description;
/*     */     }
/*     */     @JsonProperty("summary")
/*     */     public void setSummary(String summary) {
/* 315 */       this.summary = summary;
/*     */     }
/*     */     @JsonProperty("bot")
/*     */     public void setBot(Possible<UserData> bot) {
/* 319 */       this.bot = bot;
/*     */     }
/*     */     public Id id() {
/* 322 */       throw new UnsupportedOperationException();
/*     */     } public String name() {
/* 324 */       throw new UnsupportedOperationException();
/*     */     } public Optional<String> icon() {
/* 326 */       throw new UnsupportedOperationException();
/*     */     } public String description() {
/* 328 */       throw new UnsupportedOperationException();
/*     */     } public String summary() {
/* 330 */       throw new UnsupportedOperationException();
/*     */     } public Possible<UserData> bot() {
/* 332 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableIntegrationApplicationData fromJson(Json json) {
/* 343 */     Builder builder = builder();
/* 344 */     if (json.id != null) {
/* 345 */       builder.id(json.id);
/*     */     }
/* 347 */     if (json.name != null) {
/* 348 */       builder.name(json.name);
/*     */     }
/* 350 */     if (json.icon != null) {
/* 351 */       builder.icon(json.icon);
/*     */     }
/* 353 */     if (json.description != null) {
/* 354 */       builder.description(json.description);
/*     */     }
/* 356 */     if (json.summary != null) {
/* 357 */       builder.summary(json.summary);
/*     */     }
/* 359 */     if (json.bot != null) {
/* 360 */       builder.bot(json.bot);
/*     */     }
/* 362 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableIntegrationApplicationData of(Id id, String name, Optional<String> icon, String description, String summary, Possible<UserData> bot) {
/* 376 */     return new ImmutableIntegrationApplicationData(id, name, icon, description, summary, bot);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableIntegrationApplicationData copyOf(IntegrationApplicationData instance) {
/* 387 */     if (instance instanceof ImmutableIntegrationApplicationData) {
/* 388 */       return (ImmutableIntegrationApplicationData)instance;
/*     */     }
/* 390 */     return builder()
/* 391 */       .from(instance)
/* 392 */       .build();
/*     */   }
/*     */   
/*     */   public boolean isBotPresent() {
/* 396 */     return !this.bot_absent;
/*     */   }
/*     */   
/*     */   public UserData botOrElse(UserData defaultValue) {
/* 400 */     return !this.bot_absent ? this.bot_value : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 418 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "IntegrationApplicationData", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_NAME = 1L;
/*     */ 
/*     */     
/*     */     private static final long INIT_BIT_DESCRIPTION = 2L;
/*     */     
/*     */     private static final long INIT_BIT_SUMMARY = 4L;
/*     */     
/* 433 */     private long initBits = 7L;
/*     */     
/* 435 */     private Id id_id = null;
/* 436 */     private Possible<UserData> bot_possible = Possible.absent();
/*     */ 
/*     */     
/*     */     private String name;
/*     */ 
/*     */     
/*     */     private String icon;
/*     */ 
/*     */     
/*     */     private String description;
/*     */ 
/*     */     
/*     */     private String summary;
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(IntegrationApplicationData instance) {
/* 453 */       Objects.requireNonNull(instance, "instance");
/* 454 */       id(instance.id());
/* 455 */       name(instance.name());
/* 456 */       Optional<String> iconOptional = instance.icon();
/* 457 */       if (iconOptional.isPresent()) {
/* 458 */         icon(iconOptional);
/*     */       }
/* 460 */       description(instance.description());
/* 461 */       summary(instance.summary());
/* 462 */       bot(instance.bot());
/* 463 */       return this;
/*     */     }
/*     */     
/*     */     public Builder id(String value) {
/* 467 */       this.id_id = Id.of(value);
/* 468 */       return this;
/*     */     }
/*     */     
/*     */     public Builder id(long value) {
/* 472 */       this.id_id = Id.of(value);
/* 473 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("id")
/*     */     public Builder id(Id value) {
/* 478 */       this.id_id = value;
/* 479 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("name")
/*     */     public final Builder name(String name) {
/* 489 */       this.name = Objects.<String>requireNonNull(name, "name");
/* 490 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 491 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder icon(String icon) {
/* 500 */       this.icon = Objects.<String>requireNonNull(icon, "icon");
/* 501 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("icon")
/*     */     public final Builder icon(Optional<String> icon) {
/* 511 */       this.icon = icon.orElse(null);
/* 512 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("description")
/*     */     public final Builder description(String description) {
/* 522 */       this.description = Objects.<String>requireNonNull(description, "description");
/* 523 */       this.initBits &= 0xFFFFFFFFFFFFFFFDL;
/* 524 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("summary")
/*     */     public final Builder summary(String summary) {
/* 534 */       this.summary = Objects.<String>requireNonNull(summary, "summary");
/* 535 */       this.initBits &= 0xFFFFFFFFFFFFFFFBL;
/* 536 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("bot")
/*     */     public Builder bot(Possible<UserData> value) {
/* 541 */       this.bot_possible = value;
/* 542 */       return this;
/*     */     }
/*     */     
/*     */     public Builder bot(UserData value) {
/* 546 */       this.bot_possible = Possible.of(value);
/* 547 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableIntegrationApplicationData build() {
/* 556 */       if (this.initBits != 0L) {
/* 557 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 559 */       return new ImmutableIntegrationApplicationData(null, id_build(), this.name, this.icon, this.description, this.summary, bot_build());
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 563 */       List<String> attributes = new ArrayList<>();
/* 564 */       if ((this.initBits & 0x1L) != 0L) attributes.add("name"); 
/* 565 */       if ((this.initBits & 0x2L) != 0L) attributes.add("description"); 
/* 566 */       if ((this.initBits & 0x4L) != 0L) attributes.add("summary"); 
/* 567 */       return "Cannot build IntegrationApplicationData, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Id id_build() {
/* 571 */       return this.id_id;
/*     */     }
/*     */     
/*     */     private Possible<UserData> bot_build() {
/* 575 */       return this.bot_possible;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableIntegrationApplicationData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */