/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.Id;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.stream.StreamSupport;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "AuditLogEntryData", generator = "Immutables")
/*     */ public final class ImmutableAuditLogEntryData
/*     */   implements AuditLogEntryData
/*     */ {
/*     */   private final String targetId;
/*     */   private final List<AuditLogChangeData> changes_value;
/*     */   private final boolean changes_absent;
/*     */   private final long userId_value;
/*     */   private final boolean userId_present;
/*     */   private final long id_value;
/*     */   private final int actionType;
/*     */   private final AuditEntryInfoData options_value;
/*     */   private final boolean options_absent;
/*     */   private final String reason_value;
/*     */   private final boolean reason_absent;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   private volatile transient InitShim initShim;
/*     */   
/*     */   private ImmutableAuditLogEntryData(Optional<String> targetId, Possible<List<AuditLogChangeData>> changes, Optional<Id> userId, Id id, int actionType, Possible<AuditEntryInfoData> options, Possible<String> reason) {
/* 104 */     this.initShim = new InitShim(); this.targetId = targetId.orElse(null); Possible<List<AuditLogChangeData>> changes$impl = changes; Optional<Id> userId$impl = userId; Id id$impl = id; this.actionType = actionType; Possible<AuditEntryInfoData> options$impl = options; Possible<String> reason$impl = reason; this.changes_value = changes$impl.toOptional().orElse(null); this.changes_absent = changes$impl.isAbsent(); this.userId_value = ((Long)userId$impl.<Long>map(Id::asLong).orElse(Long.valueOf(0L))).longValue(); this.userId_present = userId$impl.isPresent(); this.id_value = id$impl.asLong(); this.options_value = options$impl.toOptional().orElse(null); this.options_absent = options$impl.isAbsent(); this.reason_value = reason$impl.toOptional().orElse(null); this.reason_absent = reason$impl.isAbsent(); this.initShim = null; } private ImmutableAuditLogEntryData(ImmutableAuditLogEntryData original, String targetId, Possible<List<AuditLogChangeData>> changes, Optional<Id> userId, Id id, int actionType, Possible<AuditEntryInfoData> options, Possible<String> reason) { this.initShim = new InitShim(); this.targetId = targetId; Possible<List<AuditLogChangeData>> changes$impl = changes; Optional<Id> userId$impl = userId; Id id$impl = id; this.actionType = actionType; Possible<AuditEntryInfoData> options$impl = options; Possible<String> reason$impl = reason; this.changes_value = changes$impl.toOptional().orElse(null); this.changes_absent = changes$impl.isAbsent(); this.userId_value = ((Long)userId$impl.<Long>map(Id::asLong).orElse(Long.valueOf(0L))).longValue(); this.userId_present = userId$impl.isPresent(); this.id_value = id$impl.asLong();
/*     */     this.options_value = options$impl.toOptional().orElse(null);
/*     */     this.options_absent = options$impl.isAbsent();
/*     */     this.reason_value = reason$impl.toOptional().orElse(null);
/*     */     this.reason_absent = reason$impl.isAbsent();
/* 109 */     this.initShim = null; } @Generated(from = "AuditLogEntryData", generator = "Immutables") private final class InitShim { private InitShim() {} private String formatInitCycleMessage() { List<String> attributes = new ArrayList<>();
/* 110 */       return "Cannot build AuditLogEntryData, attribute initializers form cycle " + attributes; }
/*     */      }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("target_id")
/*     */   public Optional<String> targetId() {
/* 120 */     return Optional.ofNullable(this.targetId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("changes")
/*     */   public Possible<List<AuditLogChangeData>> changes() {
/* 129 */     return this.changes_absent ? Possible.absent() : 
/* 130 */       Possible.of(this.changes_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("user_id")
/*     */   public Optional<Id> userId() {
/* 139 */     return this.userId_present ? Optional.<Id>of(Id.of(this.userId_value)) : Optional.<Id>empty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("id")
/*     */   public Id id() {
/* 148 */     return Id.of(this.id_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("action_type")
/*     */   public int actionType() {
/* 157 */     return this.actionType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("options")
/*     */   public Possible<AuditEntryInfoData> options() {
/* 166 */     return this.options_absent ? Possible.absent() : Possible.of(this.options_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("reason")
/*     */   public Possible<String> reason() {
/* 175 */     return this.reason_absent ? Possible.absent() : Possible.of(this.reason_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableAuditLogEntryData withTargetId(String value) {
/* 184 */     String newValue = Objects.<String>requireNonNull(value, "targetId");
/* 185 */     if (Objects.equals(this.targetId, newValue)) return this; 
/* 186 */     return new ImmutableAuditLogEntryData(this, newValue, 
/*     */ 
/*     */         
/* 189 */         changes(), 
/* 190 */         userId(), 
/* 191 */         id(), this.actionType, 
/*     */         
/* 193 */         options(), 
/* 194 */         reason());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableAuditLogEntryData withTargetId(Optional<String> optional) {
/* 204 */     String value = optional.orElse(null);
/* 205 */     if (Objects.equals(this.targetId, value)) return this; 
/* 206 */     return new ImmutableAuditLogEntryData(this, value, 
/*     */ 
/*     */         
/* 209 */         changes(), 
/* 210 */         userId(), 
/* 211 */         id(), this.actionType, 
/*     */         
/* 213 */         options(), 
/* 214 */         reason());
/*     */   }
/*     */   
/*     */   public ImmutableAuditLogEntryData withChanges(Possible<List<AuditLogChangeData>> possible) {
/* 218 */     Possible<List<AuditLogChangeData>> newValue = Objects.<Possible<List<AuditLogChangeData>>>requireNonNull(possible);
/* 219 */     return new ImmutableAuditLogEntryData(this, this.targetId, newValue, 
/*     */ 
/*     */ 
/*     */         
/* 223 */         userId(), 
/* 224 */         id(), this.actionType, 
/*     */         
/* 226 */         options(), 
/* 227 */         reason());
/*     */   }
/*     */   
/*     */   public ImmutableAuditLogEntryData withChanges(Iterable<AuditLogChangeData> elements) {
/* 231 */     Possible<List<AuditLogChangeData>> newValue = Possible.of(
/* 232 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/* 233 */     return new ImmutableAuditLogEntryData(this, this.targetId, newValue, 
/*     */ 
/*     */ 
/*     */         
/* 237 */         userId(), 
/* 238 */         id(), this.actionType, 
/*     */         
/* 240 */         options(), 
/* 241 */         reason());
/*     */   }
/*     */   
/*     */   @SafeVarargs
/*     */   public final ImmutableAuditLogEntryData withChanges(AuditLogChangeData... elements) {
/* 246 */     Possible<List<AuditLogChangeData>> newValue = Possible.of(Arrays.asList(elements));
/* 247 */     return new ImmutableAuditLogEntryData(this, this.targetId, newValue, 
/*     */ 
/*     */ 
/*     */         
/* 251 */         userId(), 
/* 252 */         id(), this.actionType, 
/*     */         
/* 254 */         options(), 
/* 255 */         reason());
/*     */   }
/*     */   
/*     */   public ImmutableAuditLogEntryData withUserId(Optional<Id> value) {
/* 259 */     Optional<Id> newValue = Objects.<Optional<Id>>requireNonNull(value);
/* 260 */     return new ImmutableAuditLogEntryData(this, this.targetId, 
/*     */ 
/*     */         
/* 263 */         changes(), newValue, 
/*     */         
/* 265 */         id(), this.actionType, 
/*     */         
/* 267 */         options(), 
/* 268 */         reason());
/*     */   }
/*     */   
/*     */   public ImmutableAuditLogEntryData withUserId(long value) {
/* 272 */     Optional<Id> newValue = Optional.of(Id.of(value));
/* 273 */     return new ImmutableAuditLogEntryData(this, this.targetId, 
/*     */ 
/*     */         
/* 276 */         changes(), newValue, 
/*     */         
/* 278 */         id(), this.actionType, 
/*     */         
/* 280 */         options(), 
/* 281 */         reason());
/*     */   }
/*     */   
/*     */   public ImmutableAuditLogEntryData withId(long value) {
/* 285 */     Id newValue = Id.of(value);
/* 286 */     return new ImmutableAuditLogEntryData(this, this.targetId, 
/*     */ 
/*     */         
/* 289 */         changes(), 
/* 290 */         userId(), newValue, this.actionType, 
/*     */ 
/*     */         
/* 293 */         options(), 
/* 294 */         reason());
/*     */   }
/*     */   
/*     */   public ImmutableAuditLogEntryData withId(String value) {
/* 298 */     Id newValue = Id.of(value);
/* 299 */     return new ImmutableAuditLogEntryData(this, this.targetId, 
/*     */ 
/*     */         
/* 302 */         changes(), 
/* 303 */         userId(), newValue, this.actionType, 
/*     */ 
/*     */         
/* 306 */         options(), 
/* 307 */         reason());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableAuditLogEntryData withActionType(int value) {
/* 317 */     if (this.actionType == value) return this; 
/* 318 */     return new ImmutableAuditLogEntryData(this, this.targetId, 
/*     */ 
/*     */         
/* 321 */         changes(), 
/* 322 */         userId(), 
/* 323 */         id(), value, 
/*     */         
/* 325 */         options(), 
/* 326 */         reason());
/*     */   }
/*     */   
/*     */   public ImmutableAuditLogEntryData withOptions(Possible<AuditEntryInfoData> value) {
/* 330 */     Possible<AuditEntryInfoData> newValue = Objects.<Possible<AuditEntryInfoData>>requireNonNull(value);
/* 331 */     return new ImmutableAuditLogEntryData(this, this.targetId, 
/*     */ 
/*     */         
/* 334 */         changes(), 
/* 335 */         userId(), 
/* 336 */         id(), this.actionType, newValue, 
/*     */ 
/*     */         
/* 339 */         reason());
/*     */   }
/*     */   
/*     */   public ImmutableAuditLogEntryData withOptions(AuditEntryInfoData value) {
/* 343 */     Possible<AuditEntryInfoData> newValue = Possible.of(value);
/* 344 */     return new ImmutableAuditLogEntryData(this, this.targetId, 
/*     */ 
/*     */         
/* 347 */         changes(), 
/* 348 */         userId(), 
/* 349 */         id(), this.actionType, newValue, 
/*     */ 
/*     */         
/* 352 */         reason());
/*     */   }
/*     */   
/*     */   public ImmutableAuditLogEntryData withReason(Possible<String> value) {
/* 356 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/* 357 */     return new ImmutableAuditLogEntryData(this, this.targetId, 
/*     */ 
/*     */         
/* 360 */         changes(), 
/* 361 */         userId(), 
/* 362 */         id(), this.actionType, 
/*     */         
/* 364 */         options(), newValue);
/*     */   }
/*     */ 
/*     */   
/*     */   public ImmutableAuditLogEntryData withReason(String value) {
/* 369 */     Possible<String> newValue = Possible.of(value);
/* 370 */     return new ImmutableAuditLogEntryData(this, this.targetId, 
/*     */ 
/*     */         
/* 373 */         changes(), 
/* 374 */         userId(), 
/* 375 */         id(), this.actionType, 
/*     */         
/* 377 */         options(), newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 387 */     if (this == another) return true; 
/* 388 */     return (another instanceof ImmutableAuditLogEntryData && 
/* 389 */       equalTo(0, (ImmutableAuditLogEntryData)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableAuditLogEntryData another) {
/* 393 */     return (Objects.equals(this.targetId, another.targetId) && 
/* 394 */       Objects.equals(this.changes_value, another.changes_value) && 
/* 395 */       userId().equals(another.userId()) && 
/* 396 */       Objects.equals(Long.valueOf(this.id_value), Long.valueOf(another.id_value)) && this.actionType == another.actionType && 
/*     */       
/* 398 */       options().equals(another.options()) && 
/* 399 */       reason().equals(another.reason()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 408 */     int h = 5381;
/* 409 */     h += (h << 5) + Objects.hashCode(this.targetId);
/* 410 */     h += (h << 5) + Objects.hashCode(this.changes_value);
/* 411 */     h += (h << 5) + userId().hashCode();
/* 412 */     h += (h << 5) + Objects.hashCode(Long.valueOf(this.id_value));
/* 413 */     h += (h << 5) + this.actionType;
/* 414 */     h += (h << 5) + options().hashCode();
/* 415 */     h += (h << 5) + reason().hashCode();
/* 416 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 425 */     StringBuilder builder = new StringBuilder("AuditLogEntryData{");
/* 426 */     if (this.targetId != null) {
/* 427 */       builder.append("targetId=").append(this.targetId);
/*     */     }
/* 429 */     if (builder.length() > 18) builder.append(", "); 
/* 430 */     builder.append("changes=").append(Objects.toString(this.changes_value));
/* 431 */     builder.append(", ");
/* 432 */     builder.append("userId=").append(userId().toString());
/* 433 */     builder.append(", ");
/* 434 */     builder.append("id=").append(Objects.toString(Long.valueOf(this.id_value)));
/* 435 */     builder.append(", ");
/* 436 */     builder.append("actionType=").append(this.actionType);
/* 437 */     builder.append(", ");
/* 438 */     builder.append("options=").append(options().toString());
/* 439 */     builder.append(", ");
/* 440 */     builder.append("reason=").append(reason().toString());
/* 441 */     return builder.append("}").toString();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "AuditLogEntryData", generator = "Immutables")
/*     */   static final class Json
/*     */     implements AuditLogEntryData
/*     */   {
/* 453 */     Optional<String> targetId = Optional.empty();
/*     */     
/* 455 */     Possible<List<AuditLogChangeData>> changes = Possible.absent();
/*     */ 
/*     */     
/* 458 */     Optional<Id> userId = Optional.empty();
/*     */     
/*     */     Id id;
/*     */     
/*     */     int actionType;
/*     */     boolean actionTypeIsSet;
/* 464 */     Possible<AuditEntryInfoData> options = Possible.absent();
/*     */ 
/*     */     
/* 467 */     Possible<String> reason = Possible.absent();
/*     */     
/*     */     @JsonProperty("target_id")
/*     */     public void setTargetId(Optional<String> targetId) {
/* 471 */       this.targetId = targetId;
/*     */     }
/*     */     @JsonProperty("changes")
/*     */     public void setChanges(Possible<List<AuditLogChangeData>> changes) {
/* 475 */       this.changes = changes;
/*     */     }
/*     */     @JsonProperty("user_id")
/*     */     public void setUserId(Optional<Id> userId) {
/* 479 */       this.userId = userId;
/*     */     }
/*     */     @JsonProperty("id")
/*     */     public void setId(Id id) {
/* 483 */       this.id = id;
/*     */     }
/*     */     @JsonProperty("action_type")
/*     */     public void setActionType(int actionType) {
/* 487 */       this.actionType = actionType;
/* 488 */       this.actionTypeIsSet = true;
/*     */     }
/*     */     @JsonProperty("options")
/*     */     public void setOptions(Possible<AuditEntryInfoData> options) {
/* 492 */       this.options = options;
/*     */     }
/*     */     @JsonProperty("reason")
/*     */     public void setReason(Possible<String> reason) {
/* 496 */       this.reason = reason;
/*     */     }
/*     */     public Optional<String> targetId() {
/* 499 */       throw new UnsupportedOperationException();
/*     */     } public Possible<List<AuditLogChangeData>> changes() {
/* 501 */       throw new UnsupportedOperationException();
/*     */     } public Optional<Id> userId() {
/* 503 */       throw new UnsupportedOperationException();
/*     */     } public Id id() {
/* 505 */       throw new UnsupportedOperationException();
/*     */     } public int actionType() {
/* 507 */       throw new UnsupportedOperationException();
/*     */     } public Possible<AuditEntryInfoData> options() {
/* 509 */       throw new UnsupportedOperationException();
/*     */     } public Possible<String> reason() {
/* 511 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableAuditLogEntryData fromJson(Json json) {
/* 522 */     Builder builder = builder();
/* 523 */     if (json.targetId != null) {
/* 524 */       builder.targetId(json.targetId);
/*     */     }
/* 526 */     if (json.changes != null) {
/* 527 */       builder.changes(json.changes);
/*     */     }
/* 529 */     if (json.userId != null) {
/* 530 */       builder.userId(json.userId);
/*     */     }
/* 532 */     if (json.id != null) {
/* 533 */       builder.id(json.id);
/*     */     }
/* 535 */     if (json.actionTypeIsSet) {
/* 536 */       builder.actionType(json.actionType);
/*     */     }
/* 538 */     if (json.options != null) {
/* 539 */       builder.options(json.options);
/*     */     }
/* 541 */     if (json.reason != null) {
/* 542 */       builder.reason(json.reason);
/*     */     }
/* 544 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableAuditLogEntryData of(Optional<String> targetId, Possible<List<AuditLogChangeData>> changes, Optional<Id> userId, Id id, int actionType, Possible<AuditEntryInfoData> options, Possible<String> reason) {
/* 559 */     return new ImmutableAuditLogEntryData(targetId, changes, userId, id, actionType, options, reason);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableAuditLogEntryData copyOf(AuditLogEntryData instance) {
/* 570 */     if (instance instanceof ImmutableAuditLogEntryData) {
/* 571 */       return (ImmutableAuditLogEntryData)instance;
/*     */     }
/* 573 */     return builder()
/* 574 */       .from(instance)
/* 575 */       .build();
/*     */   }
/*     */   
/*     */   public boolean isChangesPresent() {
/* 579 */     return !this.changes_absent;
/*     */   }
/*     */   
/*     */   public List<AuditLogChangeData> changesOrElse(List<AuditLogChangeData> defaultValue) {
/* 583 */     return !this.changes_absent ? this.changes_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isUserIdPresent() {
/* 587 */     return this.userId_present;
/*     */   }
/*     */   
/*     */   public long userIdOrElse(long defaultValue) {
/* 591 */     return this.userId_present ? this.userId_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isOptionsPresent() {
/* 595 */     return !this.options_absent;
/*     */   }
/*     */   
/*     */   public AuditEntryInfoData optionsOrElse(AuditEntryInfoData defaultValue) {
/* 599 */     return !this.options_absent ? this.options_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isReasonPresent() {
/* 603 */     return !this.reason_absent;
/*     */   }
/*     */   
/*     */   public String reasonOrElse(String defaultValue) {
/* 607 */     return !this.reason_absent ? this.reason_value : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 626 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "AuditLogEntryData", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_ACTION_TYPE = 1L;
/*     */ 
/*     */ 
/*     */     
/* 639 */     private long initBits = 1L;
/*     */     
/* 641 */     private List<AuditLogChangeData> changes_list = null;
/* 642 */     private Optional<Id> userId_optional = Optional.empty();
/* 643 */     private Id id_id = null;
/* 644 */     private Possible<AuditEntryInfoData> options_possible = Possible.absent();
/* 645 */     private Possible<String> reason_possible = Possible.absent();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private String targetId;
/*     */ 
/*     */ 
/*     */     
/*     */     private int actionType;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(AuditLogEntryData instance) {
/* 660 */       Objects.requireNonNull(instance, "instance");
/* 661 */       Optional<String> targetIdOptional = instance.targetId();
/* 662 */       if (targetIdOptional.isPresent()) {
/* 663 */         targetId(targetIdOptional);
/*     */       }
/* 665 */       changes(instance.changes());
/* 666 */       userId(instance.userId());
/* 667 */       id(instance.id());
/* 668 */       actionType(instance.actionType());
/* 669 */       options(instance.options());
/* 670 */       reason(instance.reason());
/* 671 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder targetId(String targetId) {
/* 680 */       this.targetId = Objects.<String>requireNonNull(targetId, "targetId");
/* 681 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("target_id")
/*     */     public final Builder targetId(Optional<String> targetId) {
/* 691 */       this.targetId = targetId.orElse(null);
/* 692 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addChange(AuditLogChangeData element) {
/* 696 */       changes_getOrCreate().add(element);
/* 697 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addAllChanges(List<AuditLogChangeData> elements) {
/* 701 */       changes_getOrCreate().addAll(elements);
/* 702 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("changes")
/*     */     public Builder changes(Possible<List<AuditLogChangeData>> elements) {
/* 707 */       this.changes_list = null;
/* 708 */       elements.toOptional().ifPresent(e -> changes_getOrCreate().addAll(e));
/* 709 */       return this;
/*     */     }
/*     */     
/*     */     public Builder changes(List<AuditLogChangeData> elements) {
/* 713 */       this.changes_list = new ArrayList<>(elements);
/* 714 */       return this;
/*     */     }
/*     */     
/*     */     public Builder changes(Iterable<AuditLogChangeData> elements) {
/* 718 */       this.changes_list = (List<AuditLogChangeData>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/* 719 */       return this;
/*     */     }
/*     */     
/*     */     public Builder userId(String value) {
/* 723 */       this.userId_optional = Optional.of(Id.of(value));
/* 724 */       return this;
/*     */     }
/*     */     
/*     */     public Builder userId(long value) {
/* 728 */       this.userId_optional = Optional.of(Id.of(value));
/* 729 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("user_id")
/*     */     public Builder userId(Optional<Id> value) {
/* 734 */       this.userId_optional = value;
/* 735 */       return this;
/*     */     }
/*     */     
/*     */     public Builder id(String value) {
/* 739 */       this.id_id = Id.of(value);
/* 740 */       return this;
/*     */     }
/*     */     
/*     */     public Builder id(long value) {
/* 744 */       this.id_id = Id.of(value);
/* 745 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("id")
/*     */     public Builder id(Id value) {
/* 750 */       this.id_id = value;
/* 751 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("action_type")
/*     */     public final Builder actionType(int actionType) {
/* 761 */       this.actionType = actionType;
/* 762 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 763 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("options")
/*     */     public Builder options(Possible<AuditEntryInfoData> value) {
/* 768 */       this.options_possible = value;
/* 769 */       return this;
/*     */     }
/*     */     
/*     */     public Builder options(AuditEntryInfoData value) {
/* 773 */       this.options_possible = Possible.of(value);
/* 774 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("reason")
/*     */     public Builder reason(Possible<String> value) {
/* 779 */       this.reason_possible = value;
/* 780 */       return this;
/*     */     }
/*     */     
/*     */     public Builder reason(String value) {
/* 784 */       this.reason_possible = Possible.of(value);
/* 785 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableAuditLogEntryData build() {
/* 794 */       if (this.initBits != 0L) {
/* 795 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 797 */       return new ImmutableAuditLogEntryData(null, this.targetId, 
/*     */ 
/*     */           
/* 800 */           changes_build(), 
/* 801 */           userId_build(), 
/* 802 */           id_build(), this.actionType, 
/*     */           
/* 804 */           options_build(), 
/* 805 */           reason_build());
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 809 */       List<String> attributes = new ArrayList<>();
/* 810 */       if ((this.initBits & 0x1L) != 0L) attributes.add("actionType"); 
/* 811 */       return "Cannot build AuditLogEntryData, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Possible<List<AuditLogChangeData>> changes_build() {
/* 815 */       return (this.changes_list == null) ? Possible.absent() : 
/* 816 */         Possible.of(this.changes_list);
/*     */     }
/*     */     
/*     */     private List<AuditLogChangeData> changes_getOrCreate() {
/* 820 */       if (this.changes_list == null) {
/* 821 */         this.changes_list = new ArrayList<>();
/*     */       }
/* 823 */       return this.changes_list;
/*     */     }
/*     */     
/*     */     private Optional<Id> userId_build() {
/* 827 */       return this.userId_optional;
/*     */     }
/*     */     
/*     */     private Id id_build() {
/* 831 */       return this.id_id;
/*     */     }
/*     */     
/*     */     private Possible<AuditEntryInfoData> options_build() {
/* 835 */       return this.options_possible;
/*     */     }
/*     */     
/*     */     private Possible<String> reason_build() {
/* 839 */       return this.reason_possible;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableAuditLogEntryData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */