/*    */ package discord4j.discordjson.json;
/*    */ 
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ @JsonSerialize(as = ImmutableMessageInteractionData.class)
/*    */ @JsonDeserialize(as = ImmutableMessageInteractionData.class)
/*    */ @Immutable
/*    */ public interface MessageInteractionData
/*    */ {
/*    */   static ImmutableMessageInteractionData.Builder builder() {
/* 13 */     return ImmutableMessageInteractionData.builder();
/*    */   }
/*    */   
/*    */   String id();
/*    */   
/*    */   int type();
/*    */   
/*    */   String name();
/*    */   
/*    */   UserData user();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\MessageInteractionData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */