/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "MessageInteractionData", generator = "Immutables")
/*     */ public final class ImmutableMessageInteractionData
/*     */   implements MessageInteractionData
/*     */ {
/*     */   private final String id;
/*     */   private final int type;
/*     */   private final String name;
/*     */   private final UserData user;
/*     */   
/*     */   private ImmutableMessageInteractionData(String id, int type, String name, UserData user) {
/*  31 */     this.id = Objects.<String>requireNonNull(id, "id");
/*  32 */     this.type = type;
/*  33 */     this.name = Objects.<String>requireNonNull(name, "name");
/*  34 */     this.user = Objects.<UserData>requireNonNull(user, "user");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ImmutableMessageInteractionData(ImmutableMessageInteractionData original, String id, int type, String name, UserData user) {
/*  43 */     this.id = id;
/*  44 */     this.type = type;
/*  45 */     this.name = name;
/*  46 */     this.user = user;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("id")
/*     */   public String id() {
/*  55 */     return this.id;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("type")
/*     */   public int type() {
/*  64 */     return this.type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("name")
/*     */   public String name() {
/*  73 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("user")
/*     */   public UserData user() {
/*  82 */     return this.user;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableMessageInteractionData withId(String value) {
/*  92 */     String newValue = Objects.<String>requireNonNull(value, "id");
/*  93 */     if (this.id.equals(newValue)) return this; 
/*  94 */     return new ImmutableMessageInteractionData(this, newValue, this.type, this.name, this.user);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableMessageInteractionData withType(int value) {
/* 104 */     if (this.type == value) return this; 
/* 105 */     return new ImmutableMessageInteractionData(this, this.id, value, this.name, this.user);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableMessageInteractionData withName(String value) {
/* 115 */     String newValue = Objects.<String>requireNonNull(value, "name");
/* 116 */     if (this.name.equals(newValue)) return this; 
/* 117 */     return new ImmutableMessageInteractionData(this, this.id, this.type, newValue, this.user);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableMessageInteractionData withUser(UserData value) {
/* 127 */     if (this.user == value) return this; 
/* 128 */     UserData newValue = Objects.<UserData>requireNonNull(value, "user");
/* 129 */     return new ImmutableMessageInteractionData(this, this.id, this.type, this.name, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 138 */     if (this == another) return true; 
/* 139 */     return (another instanceof ImmutableMessageInteractionData && 
/* 140 */       equalTo(0, (ImmutableMessageInteractionData)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableMessageInteractionData another) {
/* 144 */     return (this.id.equals(another.id) && this.type == another.type && this.name
/*     */       
/* 146 */       .equals(another.name) && this.user
/* 147 */       .equals(another.user));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 156 */     int h = 5381;
/* 157 */     h += (h << 5) + this.id.hashCode();
/* 158 */     h += (h << 5) + this.type;
/* 159 */     h += (h << 5) + this.name.hashCode();
/* 160 */     h += (h << 5) + this.user.hashCode();
/* 161 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 170 */     return "MessageInteractionData{id=" + this.id + ", type=" + this.type + ", name=" + this.name + ", user=" + this.user + "}";
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "MessageInteractionData", generator = "Immutables")
/*     */   static final class Json
/*     */     implements MessageInteractionData
/*     */   {
/*     */     String id;
/*     */     
/*     */     int type;
/*     */     
/*     */     boolean typeIsSet;
/*     */     
/*     */     String name;
/*     */     
/*     */     UserData user;
/*     */ 
/*     */     
/*     */     @JsonProperty("id")
/*     */     public void setId(String id) {
/* 194 */       this.id = id;
/*     */     }
/*     */     @JsonProperty("type")
/*     */     public void setType(int type) {
/* 198 */       this.type = type;
/* 199 */       this.typeIsSet = true;
/*     */     }
/*     */     @JsonProperty("name")
/*     */     public void setName(String name) {
/* 203 */       this.name = name;
/*     */     }
/*     */     @JsonProperty("user")
/*     */     public void setUser(UserData user) {
/* 207 */       this.user = user;
/*     */     }
/*     */     public String id() {
/* 210 */       throw new UnsupportedOperationException();
/*     */     } public int type() {
/* 212 */       throw new UnsupportedOperationException();
/*     */     } public String name() {
/* 214 */       throw new UnsupportedOperationException();
/*     */     } public UserData user() {
/* 216 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableMessageInteractionData fromJson(Json json) {
/* 227 */     Builder builder = builder();
/* 228 */     if (json.id != null) {
/* 229 */       builder.id(json.id);
/*     */     }
/* 231 */     if (json.typeIsSet) {
/* 232 */       builder.type(json.type);
/*     */     }
/* 234 */     if (json.name != null) {
/* 235 */       builder.name(json.name);
/*     */     }
/* 237 */     if (json.user != null) {
/* 238 */       builder.user(json.user);
/*     */     }
/* 240 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableMessageInteractionData of(String id, int type, String name, UserData user) {
/* 252 */     return new ImmutableMessageInteractionData(id, type, name, user);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableMessageInteractionData copyOf(MessageInteractionData instance) {
/* 263 */     if (instance instanceof ImmutableMessageInteractionData) {
/* 264 */       return (ImmutableMessageInteractionData)instance;
/*     */     }
/* 266 */     return builder()
/* 267 */       .from(instance)
/* 268 */       .build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 284 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "MessageInteractionData", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_ID = 1L;
/*     */     
/*     */     private static final long INIT_BIT_TYPE = 2L;
/*     */     
/*     */     private static final long INIT_BIT_NAME = 4L;
/*     */     
/*     */     private static final long INIT_BIT_USER = 8L;
/*     */     
/* 300 */     private long initBits = 15L;
/*     */ 
/*     */ 
/*     */     
/*     */     private String id;
/*     */ 
/*     */     
/*     */     private int type;
/*     */ 
/*     */     
/*     */     private String name;
/*     */ 
/*     */     
/*     */     private UserData user;
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(MessageInteractionData instance) {
/* 318 */       Objects.requireNonNull(instance, "instance");
/* 319 */       id(instance.id());
/* 320 */       type(instance.type());
/* 321 */       name(instance.name());
/* 322 */       user(instance.user());
/* 323 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("id")
/*     */     public final Builder id(String id) {
/* 333 */       this.id = Objects.<String>requireNonNull(id, "id");
/* 334 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 335 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("type")
/*     */     public final Builder type(int type) {
/* 345 */       this.type = type;
/* 346 */       this.initBits &= 0xFFFFFFFFFFFFFFFDL;
/* 347 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("name")
/*     */     public final Builder name(String name) {
/* 357 */       this.name = Objects.<String>requireNonNull(name, "name");
/* 358 */       this.initBits &= 0xFFFFFFFFFFFFFFFBL;
/* 359 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("user")
/*     */     public final Builder user(UserData user) {
/* 369 */       this.user = Objects.<UserData>requireNonNull(user, "user");
/* 370 */       this.initBits &= 0xFFFFFFFFFFFFFFF7L;
/* 371 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableMessageInteractionData build() {
/* 380 */       if (this.initBits != 0L) {
/* 381 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 383 */       return new ImmutableMessageInteractionData(null, this.id, this.type, this.name, this.user);
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 387 */       List<String> attributes = new ArrayList<>();
/* 388 */       if ((this.initBits & 0x1L) != 0L) attributes.add("id"); 
/* 389 */       if ((this.initBits & 0x2L) != 0L) attributes.add("type"); 
/* 390 */       if ((this.initBits & 0x4L) != 0L) attributes.add("name"); 
/* 391 */       if ((this.initBits & 0x8L) != 0L) attributes.add("user"); 
/* 392 */       return "Cannot build MessageInteractionData, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableMessageInteractionData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */