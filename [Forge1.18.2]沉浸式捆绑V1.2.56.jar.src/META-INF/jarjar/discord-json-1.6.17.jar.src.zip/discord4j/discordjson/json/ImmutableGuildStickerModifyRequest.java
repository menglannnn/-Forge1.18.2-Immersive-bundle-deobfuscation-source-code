/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "GuildStickerModifyRequest", generator = "Immutables")
/*     */ public final class ImmutableGuildStickerModifyRequest
/*     */   implements GuildStickerModifyRequest
/*     */ {
/*     */   private final String name_value;
/*     */   private final boolean name_absent;
/*     */   private final String description_value;
/*     */   private final boolean description_absent;
/*     */   private final String tags_value;
/*     */   private final boolean tags_absent;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   
/*     */   private ImmutableGuildStickerModifyRequest(Possible<String> name, Possible<String> description, Possible<String> tags) {
/*  37 */     Possible<String> name$impl = name;
/*  38 */     Possible<String> description$impl = description;
/*  39 */     Possible<String> tags$impl = tags;
/*  40 */     this.name_value = name$impl.toOptional().orElse(null);
/*  41 */     this.name_absent = name$impl.isAbsent();
/*  42 */     this.description_value = description$impl.toOptional().orElse(null);
/*  43 */     this.description_absent = description$impl.isAbsent();
/*  44 */     this.tags_value = tags$impl.toOptional().orElse(null);
/*  45 */     this.tags_absent = tags$impl.isAbsent();
/*  46 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ImmutableGuildStickerModifyRequest(ImmutableGuildStickerModifyRequest original, Possible<String> name, Possible<String> description, Possible<String> tags) {
/*  54 */     Possible<String> name$impl = name;
/*  55 */     Possible<String> description$impl = description;
/*  56 */     Possible<String> tags$impl = tags;
/*  57 */     this.name_value = name$impl.toOptional().orElse(null);
/*  58 */     this.name_absent = name$impl.isAbsent();
/*  59 */     this.description_value = description$impl.toOptional().orElse(null);
/*  60 */     this.description_absent = description$impl.isAbsent();
/*  61 */     this.tags_value = tags$impl.toOptional().orElse(null);
/*  62 */     this.tags_absent = tags$impl.isAbsent();
/*  63 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  69 */   private volatile transient InitShim initShim = new InitShim();
/*     */   
/*     */   @Generated(from = "GuildStickerModifyRequest", generator = "Immutables")
/*     */   private final class InitShim {
/*     */     private String formatInitCycleMessage() {
/*  74 */       List<String> attributes = new ArrayList<>();
/*  75 */       return "Cannot build GuildStickerModifyRequest, attribute initializers form cycle " + attributes;
/*     */     }
/*     */ 
/*     */     
/*     */     private InitShim() {}
/*     */   }
/*     */ 
/*     */   
/*     */   @JsonProperty("name")
/*     */   public Possible<String> name() {
/*  85 */     return this.name_absent ? Possible.absent() : Possible.of(this.name_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("description")
/*     */   public Possible<String> description() {
/*  94 */     return this.description_absent ? Possible.absent() : Possible.of(this.description_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("tags")
/*     */   public Possible<String> tags() {
/* 103 */     return this.tags_absent ? Possible.absent() : Possible.of(this.tags_value);
/*     */   }
/*     */   
/*     */   public ImmutableGuildStickerModifyRequest withName(Possible<String> value) {
/* 107 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/* 108 */     return new ImmutableGuildStickerModifyRequest(this, newValue, description(), tags());
/*     */   }
/*     */   
/*     */   public ImmutableGuildStickerModifyRequest withName(String value) {
/* 112 */     Possible<String> newValue = Possible.of(value);
/* 113 */     return new ImmutableGuildStickerModifyRequest(this, newValue, description(), tags());
/*     */   }
/*     */   
/*     */   public ImmutableGuildStickerModifyRequest withDescription(Possible<String> value) {
/* 117 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/* 118 */     return new ImmutableGuildStickerModifyRequest(this, name(), newValue, tags());
/*     */   }
/*     */   
/*     */   public ImmutableGuildStickerModifyRequest withDescription(String value) {
/* 122 */     Possible<String> newValue = Possible.of(value);
/* 123 */     return new ImmutableGuildStickerModifyRequest(this, name(), newValue, tags());
/*     */   }
/*     */   
/*     */   public ImmutableGuildStickerModifyRequest withTags(Possible<String> value) {
/* 127 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/* 128 */     return new ImmutableGuildStickerModifyRequest(this, name(), description(), newValue);
/*     */   }
/*     */   
/*     */   public ImmutableGuildStickerModifyRequest withTags(String value) {
/* 132 */     Possible<String> newValue = Possible.of(value);
/* 133 */     return new ImmutableGuildStickerModifyRequest(this, name(), description(), newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 142 */     if (this == another) return true; 
/* 143 */     return (another instanceof ImmutableGuildStickerModifyRequest && 
/* 144 */       equalTo(0, (ImmutableGuildStickerModifyRequest)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableGuildStickerModifyRequest another) {
/* 148 */     return (name().equals(another.name()) && 
/* 149 */       description().equals(another.description()) && 
/* 150 */       tags().equals(another.tags()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 159 */     int h = 5381;
/* 160 */     h += (h << 5) + name().hashCode();
/* 161 */     h += (h << 5) + description().hashCode();
/* 162 */     h += (h << 5) + tags().hashCode();
/* 163 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 172 */     return "GuildStickerModifyRequest{name=" + 
/* 173 */       name().toString() + ", description=" + 
/* 174 */       description().toString() + ", tags=" + 
/* 175 */       tags().toString() + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "GuildStickerModifyRequest", generator = "Immutables")
/*     */   static final class Json
/*     */     implements GuildStickerModifyRequest
/*     */   {
/* 189 */     Possible<String> name = Possible.absent();
/*     */ 
/*     */     
/* 192 */     Possible<String> description = Possible.absent();
/*     */ 
/*     */     
/* 195 */     Possible<String> tags = Possible.absent();
/*     */     
/*     */     @JsonProperty("name")
/*     */     public void setName(Possible<String> name) {
/* 199 */       this.name = name;
/*     */     }
/*     */     @JsonProperty("description")
/*     */     public void setDescription(Possible<String> description) {
/* 203 */       this.description = description;
/*     */     }
/*     */     @JsonProperty("tags")
/*     */     public void setTags(Possible<String> tags) {
/* 207 */       this.tags = tags;
/*     */     }
/*     */     public Possible<String> name() {
/* 210 */       throw new UnsupportedOperationException();
/*     */     } public Possible<String> description() {
/* 212 */       throw new UnsupportedOperationException();
/*     */     } public Possible<String> tags() {
/* 214 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableGuildStickerModifyRequest fromJson(Json json) {
/* 225 */     Builder builder = builder();
/* 226 */     if (json.name != null) {
/* 227 */       builder.name(json.name);
/*     */     }
/* 229 */     if (json.description != null) {
/* 230 */       builder.description(json.description);
/*     */     }
/* 232 */     if (json.tags != null) {
/* 233 */       builder.tags(json.tags);
/*     */     }
/* 235 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableGuildStickerModifyRequest of(Possible<String> name, Possible<String> description, Possible<String> tags) {
/* 246 */     return new ImmutableGuildStickerModifyRequest(name, description, tags);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableGuildStickerModifyRequest copyOf(GuildStickerModifyRequest instance) {
/* 257 */     if (instance instanceof ImmutableGuildStickerModifyRequest) {
/* 258 */       return (ImmutableGuildStickerModifyRequest)instance;
/*     */     }
/* 260 */     return builder()
/* 261 */       .from(instance)
/* 262 */       .build();
/*     */   }
/*     */   
/*     */   public boolean isNamePresent() {
/* 266 */     return !this.name_absent;
/*     */   }
/*     */   
/*     */   public String nameOrElse(String defaultValue) {
/* 270 */     return !this.name_absent ? this.name_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isDescriptionPresent() {
/* 274 */     return !this.description_absent;
/*     */   }
/*     */   
/*     */   public String descriptionOrElse(String defaultValue) {
/* 278 */     return !this.description_absent ? this.description_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isTagsPresent() {
/* 282 */     return !this.tags_absent;
/*     */   }
/*     */   
/*     */   public String tagsOrElse(String defaultValue) {
/* 286 */     return !this.tags_absent ? this.tags_value : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 301 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "GuildStickerModifyRequest", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/* 313 */     private Possible<String> name_possible = Possible.absent();
/* 314 */     private Possible<String> description_possible = Possible.absent();
/* 315 */     private Possible<String> tags_possible = Possible.absent();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(GuildStickerModifyRequest instance) {
/* 328 */       Objects.requireNonNull(instance, "instance");
/* 329 */       name(instance.name());
/* 330 */       description(instance.description());
/* 331 */       tags(instance.tags());
/* 332 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("name")
/*     */     public Builder name(Possible<String> value) {
/* 337 */       this.name_possible = value;
/* 338 */       return this;
/*     */     }
/*     */     
/*     */     public Builder name(String value) {
/* 342 */       this.name_possible = Possible.of(value);
/* 343 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("description")
/*     */     public Builder description(Possible<String> value) {
/* 348 */       this.description_possible = value;
/* 349 */       return this;
/*     */     }
/*     */     
/*     */     public Builder description(String value) {
/* 353 */       this.description_possible = Possible.of(value);
/* 354 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("tags")
/*     */     public Builder tags(Possible<String> value) {
/* 359 */       this.tags_possible = value;
/* 360 */       return this;
/*     */     }
/*     */     
/*     */     public Builder tags(String value) {
/* 364 */       this.tags_possible = Possible.of(value);
/* 365 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableGuildStickerModifyRequest build() {
/* 374 */       return new ImmutableGuildStickerModifyRequest(null, name_build(), description_build(), tags_build());
/*     */     }
/*     */     
/*     */     private Possible<String> name_build() {
/* 378 */       return this.name_possible;
/*     */     }
/*     */     
/*     */     private Possible<String> description_build() {
/* 382 */       return this.description_possible;
/*     */     }
/*     */     
/*     */     private Possible<String> tags_build() {
/* 386 */       return this.tags_possible;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableGuildStickerModifyRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */