/*    */ package discord4j.discordjson.json;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonProperty;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import java.util.List;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ 
/*    */ @JsonSerialize(as = ImmutableAllowedMentionsData.class)
/*    */ @JsonDeserialize(as = ImmutableAllowedMentionsData.class)
/*    */ @Immutable
/*    */ public interface AllowedMentionsData
/*    */ {
/*    */   static ImmutableAllowedMentionsData.Builder builder() {
/* 17 */     return ImmutableAllowedMentionsData.builder();
/*    */   }
/*    */   
/*    */   Possible<List<String>> parse();
/*    */   
/*    */   Possible<List<String>> roles();
/*    */   
/*    */   Possible<List<String>> users();
/*    */   
/*    */   @JsonProperty("replied_user")
/*    */   Possible<Boolean> repliedUser();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\AllowedMentionsData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */