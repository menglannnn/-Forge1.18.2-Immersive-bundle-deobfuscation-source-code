/*    */ package discord4j.discordjson.json;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonProperty;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import discord4j.discordjson.Id;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import java.time.Instant;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ 
/*    */ 
/*    */ @JsonSerialize(as = ImmutableGuildScheduledEventCreateRequest.class)
/*    */ @JsonDeserialize(as = ImmutableGuildScheduledEventCreateRequest.class)
/*    */ @Immutable
/*    */ public interface GuildScheduledEventCreateRequest
/*    */ {
/*    */   static ImmutableGuildScheduledEventCreateRequest.Builder builder() {
/* 19 */     return ImmutableGuildScheduledEventCreateRequest.builder();
/*    */   }
/*    */   
/*    */   @JsonProperty("channel_id")
/*    */   Possible<Id> channelId();
/*    */   
/*    */   @JsonProperty("entity_metadata")
/*    */   Possible<GuildScheduledEventEntityMetadataData> entityMetadata();
/*    */   
/*    */   String name();
/*    */   
/*    */   @JsonProperty("privacy_level")
/*    */   int privacyLevel();
/*    */   
/*    */   @JsonProperty("scheduled_start_time")
/*    */   Instant scheduledStartTime();
/*    */   
/*    */   @JsonProperty("scheduled_end_time")
/*    */   Possible<Instant> scheduledEndTime();
/*    */   
/*    */   Possible<String> description();
/*    */   
/*    */   @JsonProperty("entity_type")
/*    */   int entityType();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\GuildScheduledEventCreateRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */