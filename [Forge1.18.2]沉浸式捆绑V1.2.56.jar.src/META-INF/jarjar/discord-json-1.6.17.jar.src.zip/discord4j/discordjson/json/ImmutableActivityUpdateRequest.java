/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "ActivityUpdateRequest", generator = "Immutables")
/*     */ public final class ImmutableActivityUpdateRequest
/*     */   implements ActivityUpdateRequest
/*     */ {
/*     */   private final String name;
/*     */   private final int type;
/*     */   private final String url;
/*     */   
/*     */   private ImmutableActivityUpdateRequest(String name, int type, Optional<String> url) {
/*  30 */     this.name = Objects.<String>requireNonNull(name, "name");
/*  31 */     this.type = type;
/*  32 */     this.url = url.orElse(null);
/*     */   }
/*     */   
/*     */   private ImmutableActivityUpdateRequest(ImmutableActivityUpdateRequest original, String name, int type, String url) {
/*  36 */     this.name = name;
/*  37 */     this.type = type;
/*  38 */     this.url = url;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("name")
/*     */   public String name() {
/*  47 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("type")
/*     */   public int type() {
/*  56 */     return this.type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("url")
/*     */   public Optional<String> url() {
/*  65 */     return Optional.ofNullable(this.url);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableActivityUpdateRequest withName(String value) {
/*  75 */     String newValue = Objects.<String>requireNonNull(value, "name");
/*  76 */     if (this.name.equals(newValue)) return this; 
/*  77 */     return new ImmutableActivityUpdateRequest(this, newValue, this.type, this.url);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableActivityUpdateRequest withType(int value) {
/*  87 */     if (this.type == value) return this; 
/*  88 */     return new ImmutableActivityUpdateRequest(this, this.name, value, this.url);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableActivityUpdateRequest withUrl(String value) {
/*  97 */     String newValue = Objects.<String>requireNonNull(value, "url");
/*  98 */     if (Objects.equals(this.url, newValue)) return this; 
/*  99 */     return new ImmutableActivityUpdateRequest(this, this.name, this.type, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableActivityUpdateRequest withUrl(Optional<String> optional) {
/* 109 */     String value = optional.orElse(null);
/* 110 */     if (Objects.equals(this.url, value)) return this; 
/* 111 */     return new ImmutableActivityUpdateRequest(this, this.name, this.type, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 120 */     if (this == another) return true; 
/* 121 */     return (another instanceof ImmutableActivityUpdateRequest && 
/* 122 */       equalTo(0, (ImmutableActivityUpdateRequest)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableActivityUpdateRequest another) {
/* 126 */     return (this.name.equals(another.name) && this.type == another.type && 
/*     */       
/* 128 */       Objects.equals(this.url, another.url));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 137 */     int h = 5381;
/* 138 */     h += (h << 5) + this.name.hashCode();
/* 139 */     h += (h << 5) + this.type;
/* 140 */     h += (h << 5) + Objects.hashCode(this.url);
/* 141 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 150 */     StringBuilder builder = new StringBuilder("ActivityUpdateRequest{");
/* 151 */     builder.append("name=").append(this.name);
/* 152 */     builder.append(", ");
/* 153 */     builder.append("type=").append(this.type);
/* 154 */     if (this.url != null) {
/* 155 */       builder.append(", ");
/* 156 */       builder.append("url=").append(this.url);
/*     */     } 
/* 158 */     return builder.append("}").toString();
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "ActivityUpdateRequest", generator = "Immutables")
/*     */   static final class Json
/*     */     implements ActivityUpdateRequest
/*     */   {
/*     */     String name;
/*     */     
/*     */     int type;
/*     */     boolean typeIsSet;
/* 173 */     Optional<String> url = Optional.empty();
/*     */     @JsonProperty("name")
/*     */     public void setName(String name) {
/* 176 */       this.name = name;
/*     */     }
/*     */     @JsonProperty("type")
/*     */     public void setType(int type) {
/* 180 */       this.type = type;
/* 181 */       this.typeIsSet = true;
/*     */     }
/*     */     @JsonProperty("url")
/*     */     public void setUrl(Optional<String> url) {
/* 185 */       this.url = url;
/*     */     }
/*     */     public String name() {
/* 188 */       throw new UnsupportedOperationException();
/*     */     } public int type() {
/* 190 */       throw new UnsupportedOperationException();
/*     */     } public Optional<String> url() {
/* 192 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableActivityUpdateRequest fromJson(Json json) {
/* 203 */     Builder builder = builder();
/* 204 */     if (json.name != null) {
/* 205 */       builder.name(json.name);
/*     */     }
/* 207 */     if (json.typeIsSet) {
/* 208 */       builder.type(json.type);
/*     */     }
/* 210 */     if (json.url != null) {
/* 211 */       builder.url(json.url);
/*     */     }
/* 213 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableActivityUpdateRequest of(String name, int type, Optional<String> url) {
/* 224 */     return new ImmutableActivityUpdateRequest(name, type, url);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableActivityUpdateRequest copyOf(ActivityUpdateRequest instance) {
/* 235 */     if (instance instanceof ImmutableActivityUpdateRequest) {
/* 236 */       return (ImmutableActivityUpdateRequest)instance;
/*     */     }
/* 238 */     return builder()
/* 239 */       .from(instance)
/* 240 */       .build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 255 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "ActivityUpdateRequest", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_NAME = 1L;
/*     */ 
/*     */     
/*     */     private static final long INIT_BIT_TYPE = 2L;
/*     */ 
/*     */     
/* 269 */     private long initBits = 3L;
/*     */ 
/*     */ 
/*     */     
/*     */     private String name;
/*     */ 
/*     */     
/*     */     private int type;
/*     */ 
/*     */     
/*     */     private String url;
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(ActivityUpdateRequest instance) {
/* 284 */       Objects.requireNonNull(instance, "instance");
/* 285 */       from(instance);
/* 286 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(Activity instance) {
/* 295 */       Objects.requireNonNull(instance, "instance");
/* 296 */       from(instance);
/* 297 */       return this;
/*     */     }
/*     */     
/*     */     private void from(Object object) {
/* 301 */       long bits = 0L;
/* 302 */       if (object instanceof ActivityUpdateRequest) {
/* 303 */         ActivityUpdateRequest instance = (ActivityUpdateRequest)object;
/* 304 */         if ((bits & 0x1L) == 0L) {
/* 305 */           name(instance.name());
/* 306 */           bits |= 0x1L;
/*     */         } 
/* 308 */         if ((bits & 0x2L) == 0L) {
/* 309 */           type(instance.type());
/* 310 */           bits |= 0x2L;
/*     */         } 
/* 312 */         Optional<String> urlOptional = instance.url();
/* 313 */         if (urlOptional.isPresent()) {
/* 314 */           url(urlOptional);
/*     */         }
/*     */       } 
/* 317 */       if (object instanceof Activity) {
/* 318 */         Activity instance = (Activity)object;
/* 319 */         if ((bits & 0x1L) == 0L) {
/* 320 */           name(instance.name());
/* 321 */           bits |= 0x1L;
/*     */         } 
/* 323 */         if ((bits & 0x2L) == 0L) {
/* 324 */           type(instance.type());
/* 325 */           bits |= 0x2L;
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("name")
/*     */     public final Builder name(String name) {
/* 337 */       this.name = Objects.<String>requireNonNull(name, "name");
/* 338 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 339 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("type")
/*     */     public final Builder type(int type) {
/* 349 */       this.type = type;
/* 350 */       this.initBits &= 0xFFFFFFFFFFFFFFFDL;
/* 351 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder url(String url) {
/* 360 */       this.url = Objects.<String>requireNonNull(url, "url");
/* 361 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("url")
/*     */     public final Builder url(Optional<String> url) {
/* 371 */       this.url = url.orElse(null);
/* 372 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableActivityUpdateRequest build() {
/* 381 */       if (this.initBits != 0L) {
/* 382 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 384 */       return new ImmutableActivityUpdateRequest(null, this.name, this.type, this.url);
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 388 */       List<String> attributes = new ArrayList<>();
/* 389 */       if ((this.initBits & 0x1L) != 0L) attributes.add("name"); 
/* 390 */       if ((this.initBits & 0x2L) != 0L) attributes.add("type"); 
/* 391 */       return "Cannot build ActivityUpdateRequest, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableActivityUpdateRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */