/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "PartialApplicationInfoData", generator = "Immutables")
/*     */ public final class ImmutablePartialApplicationInfoData
/*     */   implements PartialApplicationInfoData
/*     */ {
/*     */   private final String id;
/*     */   private final Integer flags_value;
/*     */   private final boolean flags_absent;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   private volatile transient InitShim initShim;
/*     */   
/*     */   private ImmutablePartialApplicationInfoData(String id, Possible<Integer> flags) {
/*  52 */     this.initShim = new InitShim(); this.id = Objects.<String>requireNonNull(id, "id"); Possible<Integer> flags$impl = flags; this.flags_value = flags$impl.toOptional().orElse(null); this.flags_absent = flags$impl.isAbsent(); this.initShim = null; } private ImmutablePartialApplicationInfoData(ImmutablePartialApplicationInfoData original, String id, Possible<Integer> flags) { this.initShim = new InitShim();
/*     */     this.id = id;
/*     */     Possible<Integer> flags$impl = flags;
/*     */     this.flags_value = flags$impl.toOptional().orElse(null);
/*     */     this.flags_absent = flags$impl.isAbsent();
/*  57 */     this.initShim = null; } @Generated(from = "PartialApplicationInfoData", generator = "Immutables") private final class InitShim { private InitShim() {} private String formatInitCycleMessage() { List<String> attributes = new ArrayList<>();
/*  58 */       return "Cannot build PartialApplicationInfoData, attribute initializers form cycle " + attributes; }
/*     */      }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("id")
/*     */   public String id() {
/*  68 */     return this.id;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("flags")
/*     */   public Possible<Integer> flags() {
/*  77 */     return this.flags_absent ? Possible.absent() : Possible.of(this.flags_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutablePartialApplicationInfoData withId(String value) {
/*  87 */     String newValue = Objects.<String>requireNonNull(value, "id");
/*  88 */     if (this.id.equals(newValue)) return this; 
/*  89 */     return new ImmutablePartialApplicationInfoData(this, newValue, flags());
/*     */   }
/*     */   
/*     */   public ImmutablePartialApplicationInfoData withFlags(Possible<Integer> value) {
/*  93 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/*  94 */     return new ImmutablePartialApplicationInfoData(this, this.id, newValue);
/*     */   }
/*     */   
/*     */   public ImmutablePartialApplicationInfoData withFlags(Integer value) {
/*  98 */     Possible<Integer> newValue = Possible.of(value);
/*  99 */     return new ImmutablePartialApplicationInfoData(this, this.id, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 108 */     if (this == another) return true; 
/* 109 */     return (another instanceof ImmutablePartialApplicationInfoData && 
/* 110 */       equalTo(0, (ImmutablePartialApplicationInfoData)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutablePartialApplicationInfoData another) {
/* 114 */     return (this.id.equals(another.id) && 
/* 115 */       flags().equals(another.flags()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 124 */     int h = 5381;
/* 125 */     h += (h << 5) + this.id.hashCode();
/* 126 */     h += (h << 5) + flags().hashCode();
/* 127 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 136 */     return "PartialApplicationInfoData{id=" + this.id + ", flags=" + 
/*     */       
/* 138 */       flags().toString() + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "PartialApplicationInfoData", generator = "Immutables")
/*     */   static final class Json
/*     */     implements PartialApplicationInfoData
/*     */   {
/*     */     String id;
/*     */ 
/*     */     
/* 153 */     Possible<Integer> flags = Possible.absent();
/*     */     
/*     */     @JsonProperty("id")
/*     */     public void setId(String id) {
/* 157 */       this.id = id;
/*     */     }
/*     */     @JsonProperty("flags")
/*     */     public void setFlags(Possible<Integer> flags) {
/* 161 */       this.flags = flags;
/*     */     }
/*     */     public String id() {
/* 164 */       throw new UnsupportedOperationException();
/*     */     } public Possible<Integer> flags() {
/* 166 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutablePartialApplicationInfoData fromJson(Json json) {
/* 177 */     Builder builder = builder();
/* 178 */     if (json.id != null) {
/* 179 */       builder.id(json.id);
/*     */     }
/* 181 */     if (json.flags != null) {
/* 182 */       builder.flags(json.flags);
/*     */     }
/* 184 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutablePartialApplicationInfoData of(String id, Possible<Integer> flags) {
/* 194 */     return new ImmutablePartialApplicationInfoData(id, flags);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutablePartialApplicationInfoData copyOf(PartialApplicationInfoData instance) {
/* 205 */     if (instance instanceof ImmutablePartialApplicationInfoData) {
/* 206 */       return (ImmutablePartialApplicationInfoData)instance;
/*     */     }
/* 208 */     return builder()
/* 209 */       .from(instance)
/* 210 */       .build();
/*     */   }
/*     */   
/*     */   public boolean isFlagsPresent() {
/* 214 */     return !this.flags_absent;
/*     */   }
/*     */   
/*     */   public Integer flagsOrElse(Integer defaultValue) {
/* 218 */     return !this.flags_absent ? this.flags_value : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 232 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "PartialApplicationInfoData", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_ID = 1L;
/*     */ 
/*     */ 
/*     */     
/* 245 */     private long initBits = 1L;
/*     */     
/* 247 */     private Possible<Integer> flags_possible = Possible.absent();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private String id;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(PartialApplicationInfoData instance) {
/* 261 */       Objects.requireNonNull(instance, "instance");
/* 262 */       id(instance.id());
/* 263 */       flags(instance.flags());
/* 264 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("id")
/*     */     public final Builder id(String id) {
/* 274 */       this.id = Objects.<String>requireNonNull(id, "id");
/* 275 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 276 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("flags")
/*     */     public Builder flags(Possible<Integer> value) {
/* 281 */       this.flags_possible = value;
/* 282 */       return this;
/*     */     }
/*     */     
/*     */     public Builder flags(Integer value) {
/* 286 */       this.flags_possible = Possible.of(value);
/* 287 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutablePartialApplicationInfoData build() {
/* 296 */       if (this.initBits != 0L) {
/* 297 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 299 */       return new ImmutablePartialApplicationInfoData(null, this.id, flags_build());
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 303 */       List<String> attributes = new ArrayList<>();
/* 304 */       if ((this.initBits & 0x1L) != 0L) attributes.add("id"); 
/* 305 */       return "Cannot build PartialApplicationInfoData, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Possible<Integer> flags_build() {
/* 309 */       return this.flags_possible;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutablePartialApplicationInfoData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */