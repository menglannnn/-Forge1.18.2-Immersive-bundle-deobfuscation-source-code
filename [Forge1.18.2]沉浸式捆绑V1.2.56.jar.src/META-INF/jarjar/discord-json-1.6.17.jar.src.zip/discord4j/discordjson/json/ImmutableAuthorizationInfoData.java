/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "AuthorizationInfoData", generator = "Immutables")
/*     */ public final class ImmutableAuthorizationInfoData
/*     */   implements AuthorizationInfoData
/*     */ {
/*     */   private final PartialApplicationInfoData application;
/*     */   private final List<String> scopes;
/*     */   private final String expires;
/*     */   private final UserData user_value;
/*     */   private final boolean user_absent;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   private volatile transient InitShim initShim;
/*     */   
/*     */   private ImmutableAuthorizationInfoData(PartialApplicationInfoData application, Iterable<String> scopes, String expires, Possible<UserData> user) {
/*  66 */     this.initShim = new InitShim(); this.application = Objects.<PartialApplicationInfoData>requireNonNull(application, "application"); this.scopes = createUnmodifiableList(false, createSafeList(scopes, true, false)); this.expires = Objects.<String>requireNonNull(expires, "expires"); Possible<UserData> user$impl = user; this.user_value = user$impl.toOptional().orElse(null); this.user_absent = user$impl.isAbsent(); this.initShim = null; } private ImmutableAuthorizationInfoData(ImmutableAuthorizationInfoData original, PartialApplicationInfoData application, List<String> scopes, String expires, Possible<UserData> user) { this.initShim = new InitShim(); this.application = application; this.scopes = scopes;
/*     */     this.expires = expires;
/*     */     Possible<UserData> user$impl = user;
/*     */     this.user_value = user$impl.toOptional().orElse(null);
/*     */     this.user_absent = user$impl.isAbsent();
/*  71 */     this.initShim = null; } @Generated(from = "AuthorizationInfoData", generator = "Immutables") private final class InitShim { private InitShim() {} private String formatInitCycleMessage() { List<String> attributes = new ArrayList<>();
/*  72 */       return "Cannot build AuthorizationInfoData, attribute initializers form cycle " + attributes; }
/*     */      }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("application")
/*     */   public PartialApplicationInfoData application() {
/*  82 */     return this.application;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("scopes")
/*     */   public List<String> scopes() {
/*  91 */     return this.scopes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("expires")
/*     */   public String expires() {
/* 100 */     return this.expires;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("user")
/*     */   public Possible<UserData> user() {
/* 109 */     return this.user_absent ? Possible.absent() : Possible.of(this.user_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableAuthorizationInfoData withApplication(PartialApplicationInfoData value) {
/* 119 */     if (this.application == value) return this; 
/* 120 */     PartialApplicationInfoData newValue = Objects.<PartialApplicationInfoData>requireNonNull(value, "application");
/* 121 */     return new ImmutableAuthorizationInfoData(this, newValue, this.scopes, this.expires, user());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableAuthorizationInfoData withScopes(String... elements) {
/* 130 */     List<String> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/* 131 */     return new ImmutableAuthorizationInfoData(this, this.application, newValue, this.expires, user());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableAuthorizationInfoData withScopes(Iterable<String> elements) {
/* 141 */     if (this.scopes == elements) return this; 
/* 142 */     List<String> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/* 143 */     return new ImmutableAuthorizationInfoData(this, this.application, newValue, this.expires, user());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableAuthorizationInfoData withExpires(String value) {
/* 153 */     String newValue = Objects.<String>requireNonNull(value, "expires");
/* 154 */     if (this.expires.equals(newValue)) return this; 
/* 155 */     return new ImmutableAuthorizationInfoData(this, this.application, this.scopes, newValue, user());
/*     */   }
/*     */   
/*     */   public ImmutableAuthorizationInfoData withUser(Possible<UserData> value) {
/* 159 */     Possible<UserData> newValue = Objects.<Possible<UserData>>requireNonNull(value);
/* 160 */     return new ImmutableAuthorizationInfoData(this, this.application, this.scopes, this.expires, newValue);
/*     */   }
/*     */   
/*     */   public ImmutableAuthorizationInfoData withUser(UserData value) {
/* 164 */     Possible<UserData> newValue = Possible.of(value);
/* 165 */     return new ImmutableAuthorizationInfoData(this, this.application, this.scopes, this.expires, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 174 */     if (this == another) return true; 
/* 175 */     return (another instanceof ImmutableAuthorizationInfoData && 
/* 176 */       equalTo(0, (ImmutableAuthorizationInfoData)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableAuthorizationInfoData another) {
/* 180 */     return (this.application.equals(another.application) && this.scopes
/* 181 */       .equals(another.scopes) && this.expires
/* 182 */       .equals(another.expires) && 
/* 183 */       user().equals(another.user()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 192 */     int h = 5381;
/* 193 */     h += (h << 5) + this.application.hashCode();
/* 194 */     h += (h << 5) + this.scopes.hashCode();
/* 195 */     h += (h << 5) + this.expires.hashCode();
/* 196 */     h += (h << 5) + user().hashCode();
/* 197 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 206 */     return "AuthorizationInfoData{application=" + this.application + ", scopes=" + this.scopes + ", expires=" + this.expires + ", user=" + 
/*     */ 
/*     */ 
/*     */       
/* 210 */       user().toString() + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "AuthorizationInfoData", generator = "Immutables")
/*     */   static final class Json
/*     */     implements AuthorizationInfoData
/*     */   {
/*     */     PartialApplicationInfoData application;
/*     */     
/* 224 */     List<String> scopes = Collections.emptyList();
/*     */     
/*     */     String expires;
/* 227 */     Possible<UserData> user = Possible.absent();
/*     */     
/*     */     @JsonProperty("application")
/*     */     public void setApplication(PartialApplicationInfoData application) {
/* 231 */       this.application = application;
/*     */     }
/*     */     @JsonProperty("scopes")
/*     */     public void setScopes(List<String> scopes) {
/* 235 */       this.scopes = scopes;
/*     */     }
/*     */     @JsonProperty("expires")
/*     */     public void setExpires(String expires) {
/* 239 */       this.expires = expires;
/*     */     }
/*     */     @JsonProperty("user")
/*     */     public void setUser(Possible<UserData> user) {
/* 243 */       this.user = user;
/*     */     }
/*     */     public PartialApplicationInfoData application() {
/* 246 */       throw new UnsupportedOperationException();
/*     */     } public List<String> scopes() {
/* 248 */       throw new UnsupportedOperationException();
/*     */     } public String expires() {
/* 250 */       throw new UnsupportedOperationException();
/*     */     } public Possible<UserData> user() {
/* 252 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableAuthorizationInfoData fromJson(Json json) {
/* 263 */     Builder builder = builder();
/* 264 */     if (json.application != null) {
/* 265 */       builder.application(json.application);
/*     */     }
/* 267 */     if (json.scopes != null) {
/* 268 */       builder.addAllScopes(json.scopes);
/*     */     }
/* 270 */     if (json.expires != null) {
/* 271 */       builder.expires(json.expires);
/*     */     }
/* 273 */     if (json.user != null) {
/* 274 */       builder.user(json.user);
/*     */     }
/* 276 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableAuthorizationInfoData of(PartialApplicationInfoData application, List<String> scopes, String expires, Possible<UserData> user) {
/* 288 */     return of(application, scopes, expires, user);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableAuthorizationInfoData of(PartialApplicationInfoData application, Iterable<String> scopes, String expires, Possible<UserData> user) {
/* 300 */     return new ImmutableAuthorizationInfoData(application, scopes, expires, user);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableAuthorizationInfoData copyOf(AuthorizationInfoData instance) {
/* 311 */     if (instance instanceof ImmutableAuthorizationInfoData) {
/* 312 */       return (ImmutableAuthorizationInfoData)instance;
/*     */     }
/* 314 */     return builder()
/* 315 */       .from(instance)
/* 316 */       .build();
/*     */   }
/*     */   
/*     */   public boolean isUserPresent() {
/* 320 */     return !this.user_absent;
/*     */   }
/*     */   
/*     */   public UserData userOrElse(UserData defaultValue) {
/* 324 */     return !this.user_absent ? this.user_value : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 340 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "AuthorizationInfoData", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_APPLICATION = 1L;
/*     */ 
/*     */     
/*     */     private static final long INIT_BIT_EXPIRES = 2L;
/*     */ 
/*     */     
/* 354 */     private long initBits = 3L;
/*     */     
/* 356 */     private Possible<UserData> user_possible = Possible.absent();
/*     */     private PartialApplicationInfoData application;
/* 358 */     private List<String> scopes = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private String expires;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(AuthorizationInfoData instance) {
/* 373 */       Objects.requireNonNull(instance, "instance");
/* 374 */       application(instance.application());
/* 375 */       addAllScopes(instance.scopes());
/* 376 */       expires(instance.expires());
/* 377 */       user(instance.user());
/* 378 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("application")
/*     */     public final Builder application(PartialApplicationInfoData application) {
/* 388 */       this.application = Objects.<PartialApplicationInfoData>requireNonNull(application, "application");
/* 389 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 390 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder addScope(String element) {
/* 399 */       this.scopes.add(Objects.<String>requireNonNull(element, "scopes element"));
/* 400 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder addScopes(String... elements) {
/* 409 */       for (String element : elements) {
/* 410 */         this.scopes.add(Objects.<String>requireNonNull(element, "scopes element"));
/*     */       }
/* 412 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("scopes")
/*     */     public final Builder scopes(Iterable<String> elements) {
/* 423 */       this.scopes.clear();
/* 424 */       return addAllScopes(elements);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder addAllScopes(Iterable<String> elements) {
/* 433 */       for (String element : elements) {
/* 434 */         this.scopes.add(Objects.<String>requireNonNull(element, "scopes element"));
/*     */       }
/* 436 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("expires")
/*     */     public final Builder expires(String expires) {
/* 446 */       this.expires = Objects.<String>requireNonNull(expires, "expires");
/* 447 */       this.initBits &= 0xFFFFFFFFFFFFFFFDL;
/* 448 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("user")
/*     */     public Builder user(Possible<UserData> value) {
/* 453 */       this.user_possible = value;
/* 454 */       return this;
/*     */     }
/*     */     
/*     */     public Builder user(UserData value) {
/* 458 */       this.user_possible = Possible.of(value);
/* 459 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableAuthorizationInfoData build() {
/* 468 */       if (this.initBits != 0L) {
/* 469 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 471 */       return new ImmutableAuthorizationInfoData(null, this.application, ImmutableAuthorizationInfoData.createUnmodifiableList(true, (List)this.scopes), this.expires, user_build());
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 475 */       List<String> attributes = new ArrayList<>();
/* 476 */       if ((this.initBits & 0x1L) != 0L) attributes.add("application"); 
/* 477 */       if ((this.initBits & 0x2L) != 0L) attributes.add("expires"); 
/* 478 */       return "Cannot build AuthorizationInfoData, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Possible<UserData> user_build() {
/* 482 */       return this.user_possible;
/*     */     }
/*     */     private Builder() {} }
/*     */   
/*     */   private static <T> List<T> createSafeList(Iterable<? extends T> iterable, boolean checkNulls, boolean skipNulls) {
/*     */     ArrayList<T> list;
/* 488 */     if (iterable instanceof Collection) {
/* 489 */       int size = ((Collection)iterable).size();
/* 490 */       if (size == 0) return Collections.emptyList(); 
/* 491 */       list = new ArrayList<>();
/*     */     } else {
/* 493 */       list = new ArrayList<>();
/*     */     } 
/* 495 */     for (T element : iterable) {
/* 496 */       if (skipNulls && element == null)
/* 497 */         continue;  if (checkNulls) Objects.requireNonNull(element, "element"); 
/* 498 */       list.add(element);
/*     */     } 
/* 500 */     return list;
/*     */   }
/*     */   
/*     */   private static <T> List<T> createUnmodifiableList(boolean clone, List<T> list) {
/* 504 */     switch (list.size()) { case 0:
/* 505 */         return Collections.emptyList();
/* 506 */       case 1: return Collections.singletonList(list.get(0)); }
/*     */     
/* 508 */     if (clone) {
/* 509 */       return Collections.unmodifiableList(new ArrayList<>(list));
/*     */     }
/* 511 */     if (list instanceof ArrayList) {
/* 512 */       ((ArrayList)list).trimToSize();
/*     */     }
/* 514 */     return Collections.unmodifiableList(list);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableAuthorizationInfoData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */