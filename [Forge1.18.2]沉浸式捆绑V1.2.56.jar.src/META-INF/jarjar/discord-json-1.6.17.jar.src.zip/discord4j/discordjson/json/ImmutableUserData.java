/*      */ package discord4j.discordjson.json;
/*      */ 
/*      */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*      */ import com.fasterxml.jackson.annotation.JsonCreator;
/*      */ import com.fasterxml.jackson.annotation.JsonProperty;
/*      */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*      */ import discord4j.discordjson.Id;
/*      */ import discord4j.discordjson.possible.Possible;
/*      */ import java.util.ArrayList;
/*      */ import java.util.List;
/*      */ import java.util.Objects;
/*      */ import java.util.Optional;
/*      */ import org.immutables.value.Generated;
/*      */ import reactor.util.annotation.Nullable;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ @Generated(from = "UserData", generator = "Immutables")
/*      */ public final class ImmutableUserData
/*      */   implements UserData
/*      */ {
/*      */   private final long id_value;
/*      */   private final String globalName;
/*      */   private final String username;
/*      */   private final String discriminator;
/*      */   private final String avatar;
/*      */   private final String banner_value;
/*      */   private final boolean banner_absent;
/*      */   private final Integer accentColor_value;
/*      */   private final boolean accentColor_absent;
/*      */   private final Boolean bot_value;
/*      */   private final boolean bot_absent;
/*      */   private final Boolean system_value;
/*      */   private final boolean system_absent;
/*      */   private final Boolean mfaEnabled_value;
/*      */   private final boolean mfaEnabled_absent;
/*      */   private final String locale_value;
/*      */   private final boolean locale_absent;
/*      */   private final Boolean verified_value;
/*      */   private final boolean verified_absent;
/*      */   private final String email_value;
/*      */   private final boolean email_absent;
/*      */   private final Long flags_value;
/*      */   private final boolean flags_absent;
/*      */   private final Integer premiumType_value;
/*      */   private final boolean premiumType_absent;
/*      */   private final Long publicFlags_value;
/*      */   private final boolean publicFlags_absent;
/*      */   private static final byte STAGE_INITIALIZING = -1;
/*      */   private static final byte STAGE_UNINITIALIZED = 0;
/*      */   private static final byte STAGE_INITIALIZED = 1;
/*      */   
/*      */   private ImmutableUserData(Id id, Optional<String> globalName, String username, String discriminator, Optional<String> avatar, Possible<Optional<String>> banner, Possible<Optional<Integer>> accentColor, Possible<Boolean> bot, Possible<Boolean> system, Possible<Boolean> mfaEnabled, Possible<String> locale, Possible<Boolean> verified, Possible<Optional<String>> email, Possible<Long> flags, Possible<Integer> premiumType, Possible<Long> publicFlags) {
/*   73 */     Id id$impl = id;
/*   74 */     this.globalName = globalName.orElse(null);
/*   75 */     this.username = Objects.<String>requireNonNull(username, "username");
/*   76 */     this.discriminator = Objects.<String>requireNonNull(discriminator, "discriminator");
/*   77 */     this.avatar = avatar.orElse(null);
/*   78 */     Possible<Optional<String>> banner$impl = banner;
/*   79 */     Possible<Optional<Integer>> accentColor$impl = accentColor;
/*   80 */     Possible<Boolean> bot$impl = bot;
/*   81 */     Possible<Boolean> system$impl = system;
/*   82 */     Possible<Boolean> mfaEnabled$impl = mfaEnabled;
/*   83 */     Possible<String> locale$impl = locale;
/*   84 */     Possible<Boolean> verified$impl = verified;
/*   85 */     Possible<Optional<String>> email$impl = email;
/*   86 */     Possible<Long> flags$impl = flags;
/*   87 */     Possible<Integer> premiumType$impl = premiumType;
/*   88 */     Possible<Long> publicFlags$impl = publicFlags;
/*   89 */     this.id_value = id$impl.asLong();
/*   90 */     this.banner_value = Possible.flatOpt(banner$impl).orElse(null);
/*   91 */     this.banner_absent = banner$impl.isAbsent();
/*   92 */     this.accentColor_value = Possible.flatOpt(accentColor$impl).orElse(null);
/*   93 */     this.accentColor_absent = accentColor$impl.isAbsent();
/*   94 */     this.bot_value = bot$impl.toOptional().orElse(null);
/*   95 */     this.bot_absent = bot$impl.isAbsent();
/*   96 */     this.system_value = system$impl.toOptional().orElse(null);
/*   97 */     this.system_absent = system$impl.isAbsent();
/*   98 */     this.mfaEnabled_value = mfaEnabled$impl.toOptional().orElse(null);
/*   99 */     this.mfaEnabled_absent = mfaEnabled$impl.isAbsent();
/*  100 */     this.locale_value = locale$impl.toOptional().orElse(null);
/*  101 */     this.locale_absent = locale$impl.isAbsent();
/*  102 */     this.verified_value = verified$impl.toOptional().orElse(null);
/*  103 */     this.verified_absent = verified$impl.isAbsent();
/*  104 */     this.email_value = Possible.flatOpt(email$impl).orElse(null);
/*  105 */     this.email_absent = email$impl.isAbsent();
/*  106 */     this.flags_value = flags$impl.toOptional().orElse(null);
/*  107 */     this.flags_absent = flags$impl.isAbsent();
/*  108 */     this.premiumType_value = premiumType$impl.toOptional().orElse(null);
/*  109 */     this.premiumType_absent = premiumType$impl.isAbsent();
/*  110 */     this.publicFlags_value = publicFlags$impl.toOptional().orElse(null);
/*  111 */     this.publicFlags_absent = publicFlags$impl.isAbsent();
/*  112 */     this.initShim = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ImmutableUserData(ImmutableUserData original, Id id, String globalName, String username, String discriminator, String avatar, Possible<Optional<String>> banner, Possible<Optional<Integer>> accentColor, Possible<Boolean> bot, Possible<Boolean> system, Possible<Boolean> mfaEnabled, Possible<String> locale, Possible<Boolean> verified, Possible<Optional<String>> email, Possible<Long> flags, Possible<Integer> premiumType, Possible<Long> publicFlags) {
/*  133 */     Id id$impl = id;
/*  134 */     this.globalName = globalName;
/*  135 */     this.username = username;
/*  136 */     this.discriminator = discriminator;
/*  137 */     this.avatar = avatar;
/*  138 */     Possible<Optional<String>> banner$impl = banner;
/*  139 */     Possible<Optional<Integer>> accentColor$impl = accentColor;
/*  140 */     Possible<Boolean> bot$impl = bot;
/*  141 */     Possible<Boolean> system$impl = system;
/*  142 */     Possible<Boolean> mfaEnabled$impl = mfaEnabled;
/*  143 */     Possible<String> locale$impl = locale;
/*  144 */     Possible<Boolean> verified$impl = verified;
/*  145 */     Possible<Optional<String>> email$impl = email;
/*  146 */     Possible<Long> flags$impl = flags;
/*  147 */     Possible<Integer> premiumType$impl = premiumType;
/*  148 */     Possible<Long> publicFlags$impl = publicFlags;
/*  149 */     this.id_value = id$impl.asLong();
/*  150 */     this.banner_value = Possible.flatOpt(banner$impl).orElse(null);
/*  151 */     this.banner_absent = banner$impl.isAbsent();
/*  152 */     this.accentColor_value = Possible.flatOpt(accentColor$impl).orElse(null);
/*  153 */     this.accentColor_absent = accentColor$impl.isAbsent();
/*  154 */     this.bot_value = bot$impl.toOptional().orElse(null);
/*  155 */     this.bot_absent = bot$impl.isAbsent();
/*  156 */     this.system_value = system$impl.toOptional().orElse(null);
/*  157 */     this.system_absent = system$impl.isAbsent();
/*  158 */     this.mfaEnabled_value = mfaEnabled$impl.toOptional().orElse(null);
/*  159 */     this.mfaEnabled_absent = mfaEnabled$impl.isAbsent();
/*  160 */     this.locale_value = locale$impl.toOptional().orElse(null);
/*  161 */     this.locale_absent = locale$impl.isAbsent();
/*  162 */     this.verified_value = verified$impl.toOptional().orElse(null);
/*  163 */     this.verified_absent = verified$impl.isAbsent();
/*  164 */     this.email_value = Possible.flatOpt(email$impl).orElse(null);
/*  165 */     this.email_absent = email$impl.isAbsent();
/*  166 */     this.flags_value = flags$impl.toOptional().orElse(null);
/*  167 */     this.flags_absent = flags$impl.isAbsent();
/*  168 */     this.premiumType_value = premiumType$impl.toOptional().orElse(null);
/*  169 */     this.premiumType_absent = premiumType$impl.isAbsent();
/*  170 */     this.publicFlags_value = publicFlags$impl.toOptional().orElse(null);
/*  171 */     this.publicFlags_absent = publicFlags$impl.isAbsent();
/*  172 */     this.initShim = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  178 */   private volatile transient InitShim initShim = new InitShim();
/*      */   
/*      */   @Generated(from = "UserData", generator = "Immutables")
/*      */   private final class InitShim {
/*      */     private String formatInitCycleMessage() {
/*  183 */       List<String> attributes = new ArrayList<>();
/*  184 */       return "Cannot build UserData, attribute initializers form cycle " + attributes;
/*      */     }
/*      */ 
/*      */     
/*      */     private InitShim() {}
/*      */   }
/*      */ 
/*      */   
/*      */   @JsonProperty("id")
/*      */   public Id id() {
/*  194 */     return Id.of(this.id_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("global_name")
/*      */   public Optional<String> globalName() {
/*  203 */     return Optional.ofNullable(this.globalName);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("username")
/*      */   public String username() {
/*  212 */     return this.username;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("discriminator")
/*      */   @Deprecated
/*      */   public String discriminator() {
/*  223 */     return this.discriminator;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("avatar")
/*      */   public Optional<String> avatar() {
/*  232 */     return Optional.ofNullable(this.avatar);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("banner")
/*      */   public Possible<Optional<String>> banner() {
/*  241 */     return this.banner_absent ? Possible.absent() : 
/*  242 */       Possible.of(Optional.ofNullable(this.banner_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("accent_color")
/*      */   public Possible<Optional<Integer>> accentColor() {
/*  251 */     return this.accentColor_absent ? Possible.absent() : 
/*  252 */       Possible.of(Optional.ofNullable(this.accentColor_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("bot")
/*      */   public Possible<Boolean> bot() {
/*  261 */     return this.bot_absent ? Possible.absent() : Possible.of(this.bot_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("system")
/*      */   public Possible<Boolean> system() {
/*  270 */     return this.system_absent ? Possible.absent() : Possible.of(this.system_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("mfa_enabled")
/*      */   public Possible<Boolean> mfaEnabled() {
/*  279 */     return this.mfaEnabled_absent ? Possible.absent() : Possible.of(this.mfaEnabled_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("locale")
/*      */   public Possible<String> locale() {
/*  288 */     return this.locale_absent ? Possible.absent() : Possible.of(this.locale_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("verified")
/*      */   public Possible<Boolean> verified() {
/*  297 */     return this.verified_absent ? Possible.absent() : Possible.of(this.verified_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("email")
/*      */   public Possible<Optional<String>> email() {
/*  306 */     return this.email_absent ? Possible.absent() : 
/*  307 */       Possible.of(Optional.ofNullable(this.email_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("flags")
/*      */   public Possible<Long> flags() {
/*  316 */     return this.flags_absent ? Possible.absent() : Possible.of(this.flags_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("premium_type")
/*      */   public Possible<Integer> premiumType() {
/*  325 */     return this.premiumType_absent ? Possible.absent() : Possible.of(this.premiumType_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("public_flags")
/*      */   public Possible<Long> publicFlags() {
/*  334 */     return this.publicFlags_absent ? Possible.absent() : Possible.of(this.publicFlags_value);
/*      */   }
/*      */   
/*      */   public ImmutableUserData withId(long value) {
/*  338 */     Id newValue = Id.of(value);
/*  339 */     return new ImmutableUserData(this, newValue, this.globalName, this.username, this.discriminator, this.avatar, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  346 */         banner(), 
/*  347 */         accentColor(), 
/*  348 */         bot(), 
/*  349 */         system(), 
/*  350 */         mfaEnabled(), 
/*  351 */         locale(), 
/*  352 */         verified(), 
/*  353 */         email(), 
/*  354 */         flags(), 
/*  355 */         premiumType(), 
/*  356 */         publicFlags());
/*      */   }
/*      */   
/*      */   public ImmutableUserData withId(String value) {
/*  360 */     Id newValue = Id.of(value);
/*  361 */     return new ImmutableUserData(this, newValue, this.globalName, this.username, this.discriminator, this.avatar, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  368 */         banner(), 
/*  369 */         accentColor(), 
/*  370 */         bot(), 
/*  371 */         system(), 
/*  372 */         mfaEnabled(), 
/*  373 */         locale(), 
/*  374 */         verified(), 
/*  375 */         email(), 
/*  376 */         flags(), 
/*  377 */         premiumType(), 
/*  378 */         publicFlags());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableUserData withGlobalName(String value) {
/*  387 */     String newValue = Objects.<String>requireNonNull(value, "globalName");
/*  388 */     if (Objects.equals(this.globalName, newValue)) return this; 
/*  389 */     return new ImmutableUserData(this, 
/*      */         
/*  391 */         id(), newValue, this.username, this.discriminator, this.avatar, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  396 */         banner(), 
/*  397 */         accentColor(), 
/*  398 */         bot(), 
/*  399 */         system(), 
/*  400 */         mfaEnabled(), 
/*  401 */         locale(), 
/*  402 */         verified(), 
/*  403 */         email(), 
/*  404 */         flags(), 
/*  405 */         premiumType(), 
/*  406 */         publicFlags());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableUserData withGlobalName(Optional<String> optional) {
/*  416 */     String value = optional.orElse(null);
/*  417 */     if (Objects.equals(this.globalName, value)) return this; 
/*  418 */     return new ImmutableUserData(this, 
/*      */         
/*  420 */         id(), value, this.username, this.discriminator, this.avatar, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  425 */         banner(), 
/*  426 */         accentColor(), 
/*  427 */         bot(), 
/*  428 */         system(), 
/*  429 */         mfaEnabled(), 
/*  430 */         locale(), 
/*  431 */         verified(), 
/*  432 */         email(), 
/*  433 */         flags(), 
/*  434 */         premiumType(), 
/*  435 */         publicFlags());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableUserData withUsername(String value) {
/*  445 */     String newValue = Objects.<String>requireNonNull(value, "username");
/*  446 */     if (this.username.equals(newValue)) return this; 
/*  447 */     return new ImmutableUserData(this, 
/*      */         
/*  449 */         id(), this.globalName, newValue, this.discriminator, this.avatar, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  454 */         banner(), 
/*  455 */         accentColor(), 
/*  456 */         bot(), 
/*  457 */         system(), 
/*  458 */         mfaEnabled(), 
/*  459 */         locale(), 
/*  460 */         verified(), 
/*  461 */         email(), 
/*  462 */         flags(), 
/*  463 */         premiumType(), 
/*  464 */         publicFlags());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public final ImmutableUserData withDiscriminator(String value) {
/*  475 */     String newValue = Objects.<String>requireNonNull(value, "discriminator");
/*  476 */     if (this.discriminator.equals(newValue)) return this; 
/*  477 */     return new ImmutableUserData(this, 
/*      */         
/*  479 */         id(), this.globalName, this.username, newValue, this.avatar, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  484 */         banner(), 
/*  485 */         accentColor(), 
/*  486 */         bot(), 
/*  487 */         system(), 
/*  488 */         mfaEnabled(), 
/*  489 */         locale(), 
/*  490 */         verified(), 
/*  491 */         email(), 
/*  492 */         flags(), 
/*  493 */         premiumType(), 
/*  494 */         publicFlags());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableUserData withAvatar(String value) {
/*  503 */     String newValue = Objects.<String>requireNonNull(value, "avatar");
/*  504 */     if (Objects.equals(this.avatar, newValue)) return this; 
/*  505 */     return new ImmutableUserData(this, 
/*      */         
/*  507 */         id(), this.globalName, this.username, this.discriminator, newValue, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  512 */         banner(), 
/*  513 */         accentColor(), 
/*  514 */         bot(), 
/*  515 */         system(), 
/*  516 */         mfaEnabled(), 
/*  517 */         locale(), 
/*  518 */         verified(), 
/*  519 */         email(), 
/*  520 */         flags(), 
/*  521 */         premiumType(), 
/*  522 */         publicFlags());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableUserData withAvatar(Optional<String> optional) {
/*  532 */     String value = optional.orElse(null);
/*  533 */     if (Objects.equals(this.avatar, value)) return this; 
/*  534 */     return new ImmutableUserData(this, 
/*      */         
/*  536 */         id(), this.globalName, this.username, this.discriminator, value, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  541 */         banner(), 
/*  542 */         accentColor(), 
/*  543 */         bot(), 
/*  544 */         system(), 
/*  545 */         mfaEnabled(), 
/*  546 */         locale(), 
/*  547 */         verified(), 
/*  548 */         email(), 
/*  549 */         flags(), 
/*  550 */         premiumType(), 
/*  551 */         publicFlags());
/*      */   }
/*      */   
/*      */   public ImmutableUserData withBanner(Possible<Optional<String>> value) {
/*  555 */     Possible<Optional<String>> newValue = Objects.<Possible<Optional<String>>>requireNonNull(value);
/*  556 */     return new ImmutableUserData(this, 
/*      */         
/*  558 */         id(), this.globalName, this.username, this.discriminator, this.avatar, newValue, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  564 */         accentColor(), 
/*  565 */         bot(), 
/*  566 */         system(), 
/*  567 */         mfaEnabled(), 
/*  568 */         locale(), 
/*  569 */         verified(), 
/*  570 */         email(), 
/*  571 */         flags(), 
/*  572 */         premiumType(), 
/*  573 */         publicFlags());
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public ImmutableUserData withBanner(@Nullable String value) {
/*  578 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/*  579 */     return new ImmutableUserData(this, 
/*      */         
/*  581 */         id(), this.globalName, this.username, this.discriminator, this.avatar, newValue, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  587 */         accentColor(), 
/*  588 */         bot(), 
/*  589 */         system(), 
/*  590 */         mfaEnabled(), 
/*  591 */         locale(), 
/*  592 */         verified(), 
/*  593 */         email(), 
/*  594 */         flags(), 
/*  595 */         premiumType(), 
/*  596 */         publicFlags());
/*      */   }
/*      */   
/*      */   public ImmutableUserData withBannerOrNull(@Nullable String value) {
/*  600 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/*  601 */     return new ImmutableUserData(this, 
/*      */         
/*  603 */         id(), this.globalName, this.username, this.discriminator, this.avatar, newValue, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  609 */         accentColor(), 
/*  610 */         bot(), 
/*  611 */         system(), 
/*  612 */         mfaEnabled(), 
/*  613 */         locale(), 
/*  614 */         verified(), 
/*  615 */         email(), 
/*  616 */         flags(), 
/*  617 */         premiumType(), 
/*  618 */         publicFlags());
/*      */   }
/*      */   
/*      */   public ImmutableUserData withAccentColor(Possible<Optional<Integer>> value) {
/*  622 */     Possible<Optional<Integer>> newValue = Objects.<Possible<Optional<Integer>>>requireNonNull(value);
/*  623 */     return new ImmutableUserData(this, 
/*      */         
/*  625 */         id(), this.globalName, this.username, this.discriminator, this.avatar, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  630 */         banner(), newValue, 
/*      */         
/*  632 */         bot(), 
/*  633 */         system(), 
/*  634 */         mfaEnabled(), 
/*  635 */         locale(), 
/*  636 */         verified(), 
/*  637 */         email(), 
/*  638 */         flags(), 
/*  639 */         premiumType(), 
/*  640 */         publicFlags());
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public ImmutableUserData withAccentColor(@Nullable Integer value) {
/*  645 */     Possible<Optional<Integer>> newValue = Possible.of(Optional.ofNullable(value));
/*  646 */     return new ImmutableUserData(this, 
/*      */         
/*  648 */         id(), this.globalName, this.username, this.discriminator, this.avatar, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  653 */         banner(), newValue, 
/*      */         
/*  655 */         bot(), 
/*  656 */         system(), 
/*  657 */         mfaEnabled(), 
/*  658 */         locale(), 
/*  659 */         verified(), 
/*  660 */         email(), 
/*  661 */         flags(), 
/*  662 */         premiumType(), 
/*  663 */         publicFlags());
/*      */   }
/*      */   
/*      */   public ImmutableUserData withAccentColorOrNull(@Nullable Integer value) {
/*  667 */     Possible<Optional<Integer>> newValue = Possible.of(Optional.ofNullable(value));
/*  668 */     return new ImmutableUserData(this, 
/*      */         
/*  670 */         id(), this.globalName, this.username, this.discriminator, this.avatar, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  675 */         banner(), newValue, 
/*      */         
/*  677 */         bot(), 
/*  678 */         system(), 
/*  679 */         mfaEnabled(), 
/*  680 */         locale(), 
/*  681 */         verified(), 
/*  682 */         email(), 
/*  683 */         flags(), 
/*  684 */         premiumType(), 
/*  685 */         publicFlags());
/*      */   }
/*      */   
/*      */   public ImmutableUserData withBot(Possible<Boolean> value) {
/*  689 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/*  690 */     return new ImmutableUserData(this, 
/*      */         
/*  692 */         id(), this.globalName, this.username, this.discriminator, this.avatar, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  697 */         banner(), 
/*  698 */         accentColor(), newValue, 
/*      */         
/*  700 */         system(), 
/*  701 */         mfaEnabled(), 
/*  702 */         locale(), 
/*  703 */         verified(), 
/*  704 */         email(), 
/*  705 */         flags(), 
/*  706 */         premiumType(), 
/*  707 */         publicFlags());
/*      */   }
/*      */   
/*      */   public ImmutableUserData withBot(Boolean value) {
/*  711 */     Possible<Boolean> newValue = Possible.of(value);
/*  712 */     return new ImmutableUserData(this, 
/*      */         
/*  714 */         id(), this.globalName, this.username, this.discriminator, this.avatar, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  719 */         banner(), 
/*  720 */         accentColor(), newValue, 
/*      */         
/*  722 */         system(), 
/*  723 */         mfaEnabled(), 
/*  724 */         locale(), 
/*  725 */         verified(), 
/*  726 */         email(), 
/*  727 */         flags(), 
/*  728 */         premiumType(), 
/*  729 */         publicFlags());
/*      */   }
/*      */   
/*      */   public ImmutableUserData withSystem(Possible<Boolean> value) {
/*  733 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/*  734 */     return new ImmutableUserData(this, 
/*      */         
/*  736 */         id(), this.globalName, this.username, this.discriminator, this.avatar, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  741 */         banner(), 
/*  742 */         accentColor(), 
/*  743 */         bot(), newValue, 
/*      */         
/*  745 */         mfaEnabled(), 
/*  746 */         locale(), 
/*  747 */         verified(), 
/*  748 */         email(), 
/*  749 */         flags(), 
/*  750 */         premiumType(), 
/*  751 */         publicFlags());
/*      */   }
/*      */   
/*      */   public ImmutableUserData withSystem(Boolean value) {
/*  755 */     Possible<Boolean> newValue = Possible.of(value);
/*  756 */     return new ImmutableUserData(this, 
/*      */         
/*  758 */         id(), this.globalName, this.username, this.discriminator, this.avatar, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  763 */         banner(), 
/*  764 */         accentColor(), 
/*  765 */         bot(), newValue, 
/*      */         
/*  767 */         mfaEnabled(), 
/*  768 */         locale(), 
/*  769 */         verified(), 
/*  770 */         email(), 
/*  771 */         flags(), 
/*  772 */         premiumType(), 
/*  773 */         publicFlags());
/*      */   }
/*      */   
/*      */   public ImmutableUserData withMfaEnabled(Possible<Boolean> value) {
/*  777 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/*  778 */     return new ImmutableUserData(this, 
/*      */         
/*  780 */         id(), this.globalName, this.username, this.discriminator, this.avatar, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  785 */         banner(), 
/*  786 */         accentColor(), 
/*  787 */         bot(), 
/*  788 */         system(), newValue, 
/*      */         
/*  790 */         locale(), 
/*  791 */         verified(), 
/*  792 */         email(), 
/*  793 */         flags(), 
/*  794 */         premiumType(), 
/*  795 */         publicFlags());
/*      */   }
/*      */   
/*      */   public ImmutableUserData withMfaEnabled(Boolean value) {
/*  799 */     Possible<Boolean> newValue = Possible.of(value);
/*  800 */     return new ImmutableUserData(this, 
/*      */         
/*  802 */         id(), this.globalName, this.username, this.discriminator, this.avatar, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  807 */         banner(), 
/*  808 */         accentColor(), 
/*  809 */         bot(), 
/*  810 */         system(), newValue, 
/*      */         
/*  812 */         locale(), 
/*  813 */         verified(), 
/*  814 */         email(), 
/*  815 */         flags(), 
/*  816 */         premiumType(), 
/*  817 */         publicFlags());
/*      */   }
/*      */   
/*      */   public ImmutableUserData withLocale(Possible<String> value) {
/*  821 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/*  822 */     return new ImmutableUserData(this, 
/*      */         
/*  824 */         id(), this.globalName, this.username, this.discriminator, this.avatar, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  829 */         banner(), 
/*  830 */         accentColor(), 
/*  831 */         bot(), 
/*  832 */         system(), 
/*  833 */         mfaEnabled(), newValue, 
/*      */         
/*  835 */         verified(), 
/*  836 */         email(), 
/*  837 */         flags(), 
/*  838 */         premiumType(), 
/*  839 */         publicFlags());
/*      */   }
/*      */   
/*      */   public ImmutableUserData withLocale(String value) {
/*  843 */     Possible<String> newValue = Possible.of(value);
/*  844 */     return new ImmutableUserData(this, 
/*      */         
/*  846 */         id(), this.globalName, this.username, this.discriminator, this.avatar, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  851 */         banner(), 
/*  852 */         accentColor(), 
/*  853 */         bot(), 
/*  854 */         system(), 
/*  855 */         mfaEnabled(), newValue, 
/*      */         
/*  857 */         verified(), 
/*  858 */         email(), 
/*  859 */         flags(), 
/*  860 */         premiumType(), 
/*  861 */         publicFlags());
/*      */   }
/*      */   
/*      */   public ImmutableUserData withVerified(Possible<Boolean> value) {
/*  865 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/*  866 */     return new ImmutableUserData(this, 
/*      */         
/*  868 */         id(), this.globalName, this.username, this.discriminator, this.avatar, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  873 */         banner(), 
/*  874 */         accentColor(), 
/*  875 */         bot(), 
/*  876 */         system(), 
/*  877 */         mfaEnabled(), 
/*  878 */         locale(), newValue, 
/*      */         
/*  880 */         email(), 
/*  881 */         flags(), 
/*  882 */         premiumType(), 
/*  883 */         publicFlags());
/*      */   }
/*      */   
/*      */   public ImmutableUserData withVerified(Boolean value) {
/*  887 */     Possible<Boolean> newValue = Possible.of(value);
/*  888 */     return new ImmutableUserData(this, 
/*      */         
/*  890 */         id(), this.globalName, this.username, this.discriminator, this.avatar, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  895 */         banner(), 
/*  896 */         accentColor(), 
/*  897 */         bot(), 
/*  898 */         system(), 
/*  899 */         mfaEnabled(), 
/*  900 */         locale(), newValue, 
/*      */         
/*  902 */         email(), 
/*  903 */         flags(), 
/*  904 */         premiumType(), 
/*  905 */         publicFlags());
/*      */   }
/*      */   
/*      */   public ImmutableUserData withEmail(Possible<Optional<String>> value) {
/*  909 */     Possible<Optional<String>> newValue = Objects.<Possible<Optional<String>>>requireNonNull(value);
/*  910 */     return new ImmutableUserData(this, 
/*      */         
/*  912 */         id(), this.globalName, this.username, this.discriminator, this.avatar, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  917 */         banner(), 
/*  918 */         accentColor(), 
/*  919 */         bot(), 
/*  920 */         system(), 
/*  921 */         mfaEnabled(), 
/*  922 */         locale(), 
/*  923 */         verified(), newValue, 
/*      */         
/*  925 */         flags(), 
/*  926 */         premiumType(), 
/*  927 */         publicFlags());
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public ImmutableUserData withEmail(@Nullable String value) {
/*  932 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/*  933 */     return new ImmutableUserData(this, 
/*      */         
/*  935 */         id(), this.globalName, this.username, this.discriminator, this.avatar, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  940 */         banner(), 
/*  941 */         accentColor(), 
/*  942 */         bot(), 
/*  943 */         system(), 
/*  944 */         mfaEnabled(), 
/*  945 */         locale(), 
/*  946 */         verified(), newValue, 
/*      */         
/*  948 */         flags(), 
/*  949 */         premiumType(), 
/*  950 */         publicFlags());
/*      */   }
/*      */   
/*      */   public ImmutableUserData withEmailOrNull(@Nullable String value) {
/*  954 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/*  955 */     return new ImmutableUserData(this, 
/*      */         
/*  957 */         id(), this.globalName, this.username, this.discriminator, this.avatar, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  962 */         banner(), 
/*  963 */         accentColor(), 
/*  964 */         bot(), 
/*  965 */         system(), 
/*  966 */         mfaEnabled(), 
/*  967 */         locale(), 
/*  968 */         verified(), newValue, 
/*      */         
/*  970 */         flags(), 
/*  971 */         premiumType(), 
/*  972 */         publicFlags());
/*      */   }
/*      */   
/*      */   public ImmutableUserData withFlags(Possible<Long> value) {
/*  976 */     Possible<Long> newValue = Objects.<Possible<Long>>requireNonNull(value);
/*  977 */     return new ImmutableUserData(this, 
/*      */         
/*  979 */         id(), this.globalName, this.username, this.discriminator, this.avatar, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  984 */         banner(), 
/*  985 */         accentColor(), 
/*  986 */         bot(), 
/*  987 */         system(), 
/*  988 */         mfaEnabled(), 
/*  989 */         locale(), 
/*  990 */         verified(), 
/*  991 */         email(), newValue, 
/*      */         
/*  993 */         premiumType(), 
/*  994 */         publicFlags());
/*      */   }
/*      */   
/*      */   public ImmutableUserData withFlags(Long value) {
/*  998 */     Possible<Long> newValue = Possible.of(value);
/*  999 */     return new ImmutableUserData(this, 
/*      */         
/* 1001 */         id(), this.globalName, this.username, this.discriminator, this.avatar, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1006 */         banner(), 
/* 1007 */         accentColor(), 
/* 1008 */         bot(), 
/* 1009 */         system(), 
/* 1010 */         mfaEnabled(), 
/* 1011 */         locale(), 
/* 1012 */         verified(), 
/* 1013 */         email(), newValue, 
/*      */         
/* 1015 */         premiumType(), 
/* 1016 */         publicFlags());
/*      */   }
/*      */   
/*      */   public ImmutableUserData withPremiumType(Possible<Integer> value) {
/* 1020 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/* 1021 */     return new ImmutableUserData(this, 
/*      */         
/* 1023 */         id(), this.globalName, this.username, this.discriminator, this.avatar, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1028 */         banner(), 
/* 1029 */         accentColor(), 
/* 1030 */         bot(), 
/* 1031 */         system(), 
/* 1032 */         mfaEnabled(), 
/* 1033 */         locale(), 
/* 1034 */         verified(), 
/* 1035 */         email(), 
/* 1036 */         flags(), newValue, 
/*      */         
/* 1038 */         publicFlags());
/*      */   }
/*      */   
/*      */   public ImmutableUserData withPremiumType(Integer value) {
/* 1042 */     Possible<Integer> newValue = Possible.of(value);
/* 1043 */     return new ImmutableUserData(this, 
/*      */         
/* 1045 */         id(), this.globalName, this.username, this.discriminator, this.avatar, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1050 */         banner(), 
/* 1051 */         accentColor(), 
/* 1052 */         bot(), 
/* 1053 */         system(), 
/* 1054 */         mfaEnabled(), 
/* 1055 */         locale(), 
/* 1056 */         verified(), 
/* 1057 */         email(), 
/* 1058 */         flags(), newValue, 
/*      */         
/* 1060 */         publicFlags());
/*      */   }
/*      */   
/*      */   public ImmutableUserData withPublicFlags(Possible<Long> value) {
/* 1064 */     Possible<Long> newValue = Objects.<Possible<Long>>requireNonNull(value);
/* 1065 */     return new ImmutableUserData(this, 
/*      */         
/* 1067 */         id(), this.globalName, this.username, this.discriminator, this.avatar, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1072 */         banner(), 
/* 1073 */         accentColor(), 
/* 1074 */         bot(), 
/* 1075 */         system(), 
/* 1076 */         mfaEnabled(), 
/* 1077 */         locale(), 
/* 1078 */         verified(), 
/* 1079 */         email(), 
/* 1080 */         flags(), 
/* 1081 */         premiumType(), newValue);
/*      */   }
/*      */ 
/*      */   
/*      */   public ImmutableUserData withPublicFlags(Long value) {
/* 1086 */     Possible<Long> newValue = Possible.of(value);
/* 1087 */     return new ImmutableUserData(this, 
/*      */         
/* 1089 */         id(), this.globalName, this.username, this.discriminator, this.avatar, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1094 */         banner(), 
/* 1095 */         accentColor(), 
/* 1096 */         bot(), 
/* 1097 */         system(), 
/* 1098 */         mfaEnabled(), 
/* 1099 */         locale(), 
/* 1100 */         verified(), 
/* 1101 */         email(), 
/* 1102 */         flags(), 
/* 1103 */         premiumType(), newValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean equals(Object another) {
/* 1113 */     if (this == another) return true; 
/* 1114 */     return (another instanceof ImmutableUserData && 
/* 1115 */       equalTo(0, (ImmutableUserData)another));
/*      */   }
/*      */   
/*      */   private boolean equalTo(int synthetic, ImmutableUserData another) {
/* 1119 */     return (Objects.equals(Long.valueOf(this.id_value), Long.valueOf(another.id_value)) && 
/* 1120 */       Objects.equals(this.globalName, another.globalName) && this.username
/* 1121 */       .equals(another.username) && this.discriminator
/* 1122 */       .equals(another.discriminator) && 
/* 1123 */       Objects.equals(this.avatar, another.avatar) && 
/* 1124 */       banner().equals(another.banner()) && 
/* 1125 */       accentColor().equals(another.accentColor()) && 
/* 1126 */       bot().equals(another.bot()) && 
/* 1127 */       system().equals(another.system()) && 
/* 1128 */       mfaEnabled().equals(another.mfaEnabled()) && 
/* 1129 */       locale().equals(another.locale()) && 
/* 1130 */       verified().equals(another.verified()) && 
/* 1131 */       email().equals(another.email()) && 
/* 1132 */       flags().equals(another.flags()) && 
/* 1133 */       premiumType().equals(another.premiumType()) && 
/* 1134 */       publicFlags().equals(another.publicFlags()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int hashCode() {
/* 1143 */     int h = 5381;
/* 1144 */     h += (h << 5) + Objects.hashCode(Long.valueOf(this.id_value));
/* 1145 */     h += (h << 5) + Objects.hashCode(this.globalName);
/* 1146 */     h += (h << 5) + this.username.hashCode();
/* 1147 */     h += (h << 5) + this.discriminator.hashCode();
/* 1148 */     h += (h << 5) + Objects.hashCode(this.avatar);
/* 1149 */     h += (h << 5) + banner().hashCode();
/* 1150 */     h += (h << 5) + accentColor().hashCode();
/* 1151 */     h += (h << 5) + bot().hashCode();
/* 1152 */     h += (h << 5) + system().hashCode();
/* 1153 */     h += (h << 5) + mfaEnabled().hashCode();
/* 1154 */     h += (h << 5) + locale().hashCode();
/* 1155 */     h += (h << 5) + verified().hashCode();
/* 1156 */     h += (h << 5) + email().hashCode();
/* 1157 */     h += (h << 5) + flags().hashCode();
/* 1158 */     h += (h << 5) + premiumType().hashCode();
/* 1159 */     h += (h << 5) + publicFlags().hashCode();
/* 1160 */     return h;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/* 1169 */     StringBuilder builder = new StringBuilder("UserData{");
/* 1170 */     builder.append("id=").append(Objects.toString(Long.valueOf(this.id_value)));
/* 1171 */     if (this.globalName != null) {
/* 1172 */       builder.append(", ");
/* 1173 */       builder.append("globalName=").append(this.globalName);
/*      */     } 
/* 1175 */     builder.append(", ");
/* 1176 */     builder.append("username=").append(this.username);
/* 1177 */     builder.append(", ");
/* 1178 */     builder.append("discriminator=").append(this.discriminator);
/* 1179 */     if (this.avatar != null) {
/* 1180 */       builder.append(", ");
/* 1181 */       builder.append("avatar=").append(this.avatar);
/*      */     } 
/* 1183 */     builder.append(", ");
/* 1184 */     builder.append("banner=").append(banner().toString());
/* 1185 */     builder.append(", ");
/* 1186 */     builder.append("accentColor=").append(accentColor().toString());
/* 1187 */     builder.append(", ");
/* 1188 */     builder.append("bot=").append(bot().toString());
/* 1189 */     builder.append(", ");
/* 1190 */     builder.append("system=").append(system().toString());
/* 1191 */     builder.append(", ");
/* 1192 */     builder.append("mfaEnabled=").append(mfaEnabled().toString());
/* 1193 */     builder.append(", ");
/* 1194 */     builder.append("locale=").append(locale().toString());
/* 1195 */     builder.append(", ");
/* 1196 */     builder.append("verified=").append(verified().toString());
/* 1197 */     builder.append(", ");
/* 1198 */     builder.append("email=").append(email().toString());
/* 1199 */     builder.append(", ");
/* 1200 */     builder.append("flags=").append(flags().toString());
/* 1201 */     builder.append(", ");
/* 1202 */     builder.append("premiumType=").append(premiumType().toString());
/* 1203 */     builder.append(", ");
/* 1204 */     builder.append("publicFlags=").append(publicFlags().toString());
/* 1205 */     return builder.append("}").toString();
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonDeserialize
/*      */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*      */   @Generated(from = "UserData", generator = "Immutables")
/*      */   static final class Json
/*      */     implements UserData
/*      */   {
/*      */     Id id;
/*      */     
/* 1218 */     Optional<String> globalName = Optional.empty();
/*      */     String username;
/*      */     String discriminator;
/* 1221 */     Optional<String> avatar = Optional.empty();
/*      */     
/* 1223 */     Possible<Optional<String>> banner = Possible.absent();
/*      */ 
/*      */     
/* 1226 */     Possible<Optional<Integer>> accentColor = Possible.absent();
/*      */ 
/*      */     
/* 1229 */     Possible<Boolean> bot = Possible.absent();
/*      */ 
/*      */     
/* 1232 */     Possible<Boolean> system = Possible.absent();
/*      */ 
/*      */     
/* 1235 */     Possible<Boolean> mfaEnabled = Possible.absent();
/*      */ 
/*      */     
/* 1238 */     Possible<String> locale = Possible.absent();
/*      */ 
/*      */     
/* 1241 */     Possible<Boolean> verified = Possible.absent();
/*      */ 
/*      */     
/* 1244 */     Possible<Optional<String>> email = Possible.absent();
/*      */ 
/*      */     
/* 1247 */     Possible<Long> flags = Possible.absent();
/*      */ 
/*      */     
/* 1250 */     Possible<Integer> premiumType = Possible.absent();
/*      */ 
/*      */     
/* 1253 */     Possible<Long> publicFlags = Possible.absent();
/*      */     
/*      */     @JsonProperty("id")
/*      */     public void setId(Id id) {
/* 1257 */       this.id = id;
/*      */     }
/*      */     @JsonProperty("global_name")
/*      */     public void setGlobalName(Optional<String> globalName) {
/* 1261 */       this.globalName = globalName;
/*      */     }
/*      */     @JsonProperty("username")
/*      */     public void setUsername(String username) {
/* 1265 */       this.username = username;
/*      */     }
/*      */     @JsonProperty("discriminator")
/*      */     public void setDiscriminator(String discriminator) {
/* 1269 */       this.discriminator = discriminator;
/*      */     }
/*      */     @JsonProperty("avatar")
/*      */     public void setAvatar(Optional<String> avatar) {
/* 1273 */       this.avatar = avatar;
/*      */     }
/*      */     @JsonProperty("banner")
/*      */     public void setBanner(Possible<Optional<String>> banner) {
/* 1277 */       this.banner = banner;
/*      */     }
/*      */     @JsonProperty("accent_color")
/*      */     public void setAccentColor(Possible<Optional<Integer>> accentColor) {
/* 1281 */       this.accentColor = accentColor;
/*      */     }
/*      */     @JsonProperty("bot")
/*      */     public void setBot(Possible<Boolean> bot) {
/* 1285 */       this.bot = bot;
/*      */     }
/*      */     @JsonProperty("system")
/*      */     public void setSystem(Possible<Boolean> system) {
/* 1289 */       this.system = system;
/*      */     }
/*      */     @JsonProperty("mfa_enabled")
/*      */     public void setMfaEnabled(Possible<Boolean> mfaEnabled) {
/* 1293 */       this.mfaEnabled = mfaEnabled;
/*      */     }
/*      */     @JsonProperty("locale")
/*      */     public void setLocale(Possible<String> locale) {
/* 1297 */       this.locale = locale;
/*      */     }
/*      */     @JsonProperty("verified")
/*      */     public void setVerified(Possible<Boolean> verified) {
/* 1301 */       this.verified = verified;
/*      */     }
/*      */     @JsonProperty("email")
/*      */     public void setEmail(Possible<Optional<String>> email) {
/* 1305 */       this.email = email;
/*      */     }
/*      */     @JsonProperty("flags")
/*      */     public void setFlags(Possible<Long> flags) {
/* 1309 */       this.flags = flags;
/*      */     }
/*      */     @JsonProperty("premium_type")
/*      */     public void setPremiumType(Possible<Integer> premiumType) {
/* 1313 */       this.premiumType = premiumType;
/*      */     }
/*      */     @JsonProperty("public_flags")
/*      */     public void setPublicFlags(Possible<Long> publicFlags) {
/* 1317 */       this.publicFlags = publicFlags;
/*      */     }
/*      */     public Id id() {
/* 1320 */       throw new UnsupportedOperationException();
/*      */     } public Optional<String> globalName() {
/* 1322 */       throw new UnsupportedOperationException();
/*      */     } public String username() {
/* 1324 */       throw new UnsupportedOperationException();
/*      */     } public String discriminator() {
/* 1326 */       throw new UnsupportedOperationException();
/*      */     } public Optional<String> avatar() {
/* 1328 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Optional<String>> banner() {
/* 1330 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Optional<Integer>> accentColor() {
/* 1332 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Boolean> bot() {
/* 1334 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Boolean> system() {
/* 1336 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Boolean> mfaEnabled() {
/* 1338 */       throw new UnsupportedOperationException();
/*      */     } public Possible<String> locale() {
/* 1340 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Boolean> verified() {
/* 1342 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Optional<String>> email() {
/* 1344 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Long> flags() {
/* 1346 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Integer> premiumType() {
/* 1348 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Long> publicFlags() {
/* 1350 */       throw new UnsupportedOperationException();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*      */   static ImmutableUserData fromJson(Json json) {
/* 1361 */     Builder builder = builder();
/* 1362 */     if (json.id != null) {
/* 1363 */       builder.id(json.id);
/*      */     }
/* 1365 */     if (json.globalName != null) {
/* 1366 */       builder.globalName(json.globalName);
/*      */     }
/* 1368 */     if (json.username != null) {
/* 1369 */       builder.username(json.username);
/*      */     }
/* 1371 */     if (json.discriminator != null) {
/* 1372 */       builder.discriminator(json.discriminator);
/*      */     }
/* 1374 */     if (json.avatar != null) {
/* 1375 */       builder.avatar(json.avatar);
/*      */     }
/* 1377 */     if (json.banner != null) {
/* 1378 */       builder.banner(json.banner);
/*      */     }
/* 1380 */     if (json.accentColor != null) {
/* 1381 */       builder.accentColor(json.accentColor);
/*      */     }
/* 1383 */     if (json.bot != null) {
/* 1384 */       builder.bot(json.bot);
/*      */     }
/* 1386 */     if (json.system != null) {
/* 1387 */       builder.system(json.system);
/*      */     }
/* 1389 */     if (json.mfaEnabled != null) {
/* 1390 */       builder.mfaEnabled(json.mfaEnabled);
/*      */     }
/* 1392 */     if (json.locale != null) {
/* 1393 */       builder.locale(json.locale);
/*      */     }
/* 1395 */     if (json.verified != null) {
/* 1396 */       builder.verified(json.verified);
/*      */     }
/* 1398 */     if (json.email != null) {
/* 1399 */       builder.email(json.email);
/*      */     }
/* 1401 */     if (json.flags != null) {
/* 1402 */       builder.flags(json.flags);
/*      */     }
/* 1404 */     if (json.premiumType != null) {
/* 1405 */       builder.premiumType(json.premiumType);
/*      */     }
/* 1407 */     if (json.publicFlags != null) {
/* 1408 */       builder.publicFlags(json.publicFlags);
/*      */     }
/* 1410 */     return builder.build();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableUserData of(Id id, Optional<String> globalName, String username, String discriminator, Optional<String> avatar, Possible<Optional<String>> banner, Possible<Optional<Integer>> accentColor, Possible<Boolean> bot, Possible<Boolean> system, Possible<Boolean> mfaEnabled, Possible<String> locale, Possible<Boolean> verified, Possible<Optional<String>> email, Possible<Long> flags, Possible<Integer> premiumType, Possible<Long> publicFlags) {
/* 1434 */     return new ImmutableUserData(id, globalName, username, discriminator, avatar, banner, accentColor, bot, system, mfaEnabled, locale, verified, email, flags, premiumType, publicFlags);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableUserData copyOf(UserData instance) {
/* 1445 */     if (instance instanceof ImmutableUserData) {
/* 1446 */       return (ImmutableUserData)instance;
/*      */     }
/* 1448 */     return builder()
/* 1449 */       .from(instance)
/* 1450 */       .build();
/*      */   }
/*      */   
/*      */   public boolean isBannerPresent() {
/* 1454 */     return !this.banner_absent;
/*      */   }
/*      */   
/*      */   public String bannerOrElse(String defaultValue) {
/* 1458 */     return !this.banner_absent ? this.banner_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isAccentColorPresent() {
/* 1462 */     return !this.accentColor_absent;
/*      */   }
/*      */   
/*      */   public Integer accentColorOrElse(Integer defaultValue) {
/* 1466 */     return !this.accentColor_absent ? this.accentColor_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isBotPresent() {
/* 1470 */     return !this.bot_absent;
/*      */   }
/*      */   
/*      */   public Boolean botOrElse(Boolean defaultValue) {
/* 1474 */     return !this.bot_absent ? this.bot_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isSystemPresent() {
/* 1478 */     return !this.system_absent;
/*      */   }
/*      */   
/*      */   public Boolean systemOrElse(Boolean defaultValue) {
/* 1482 */     return !this.system_absent ? this.system_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isMfaEnabledPresent() {
/* 1486 */     return !this.mfaEnabled_absent;
/*      */   }
/*      */   
/*      */   public Boolean mfaEnabledOrElse(Boolean defaultValue) {
/* 1490 */     return !this.mfaEnabled_absent ? this.mfaEnabled_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isLocalePresent() {
/* 1494 */     return !this.locale_absent;
/*      */   }
/*      */   
/*      */   public String localeOrElse(String defaultValue) {
/* 1498 */     return !this.locale_absent ? this.locale_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isVerifiedPresent() {
/* 1502 */     return !this.verified_absent;
/*      */   }
/*      */   
/*      */   public Boolean verifiedOrElse(Boolean defaultValue) {
/* 1506 */     return !this.verified_absent ? this.verified_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isEmailPresent() {
/* 1510 */     return !this.email_absent;
/*      */   }
/*      */   
/*      */   public String emailOrElse(String defaultValue) {
/* 1514 */     return !this.email_absent ? this.email_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isFlagsPresent() {
/* 1518 */     return !this.flags_absent;
/*      */   }
/*      */   
/*      */   public Long flagsOrElse(Long defaultValue) {
/* 1522 */     return !this.flags_absent ? this.flags_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isPremiumTypePresent() {
/* 1526 */     return !this.premiumType_absent;
/*      */   }
/*      */   
/*      */   public Integer premiumTypeOrElse(Integer defaultValue) {
/* 1530 */     return !this.premiumType_absent ? this.premiumType_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isPublicFlagsPresent() {
/* 1534 */     return !this.publicFlags_absent;
/*      */   }
/*      */   
/*      */   public Long publicFlagsOrElse(Long defaultValue) {
/* 1538 */     return !this.publicFlags_absent ? this.publicFlags_value : defaultValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Builder builder() {
/* 1566 */     return new Builder();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   @Generated(from = "UserData", generator = "Immutables")
/*      */   public static final class Builder
/*      */   {
/*      */     private static final long INIT_BIT_USERNAME = 1L;
/*      */ 
/*      */     
/*      */     private static final long INIT_BIT_DISCRIMINATOR = 2L;
/*      */ 
/*      */     
/* 1580 */     private long initBits = 3L;
/*      */     
/* 1582 */     private Id id_id = null;
/* 1583 */     private Possible<Optional<String>> banner_possible = Possible.absent();
/* 1584 */     private Possible<Optional<Integer>> accentColor_possible = Possible.absent();
/* 1585 */     private Possible<Boolean> bot_possible = Possible.absent();
/* 1586 */     private Possible<Boolean> system_possible = Possible.absent();
/* 1587 */     private Possible<Boolean> mfaEnabled_possible = Possible.absent();
/* 1588 */     private Possible<String> locale_possible = Possible.absent();
/* 1589 */     private Possible<Boolean> verified_possible = Possible.absent();
/* 1590 */     private Possible<Optional<String>> email_possible = Possible.absent();
/* 1591 */     private Possible<Long> flags_possible = Possible.absent();
/* 1592 */     private Possible<Integer> premiumType_possible = Possible.absent();
/* 1593 */     private Possible<Long> publicFlags_possible = Possible.absent();
/*      */ 
/*      */     
/*      */     private String globalName;
/*      */ 
/*      */     
/*      */     private String username;
/*      */ 
/*      */     
/*      */     private String discriminator;
/*      */ 
/*      */     
/*      */     private String avatar;
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder from(UserData instance) {
/* 1610 */       Objects.requireNonNull(instance, "instance");
/* 1611 */       id(instance.id());
/* 1612 */       Optional<String> globalNameOptional = instance.globalName();
/* 1613 */       if (globalNameOptional.isPresent()) {
/* 1614 */         globalName(globalNameOptional);
/*      */       }
/* 1616 */       username(instance.username());
/* 1617 */       discriminator(instance.discriminator());
/* 1618 */       Optional<String> avatarOptional = instance.avatar();
/* 1619 */       if (avatarOptional.isPresent()) {
/* 1620 */         avatar(avatarOptional);
/*      */       }
/* 1622 */       banner(instance.banner());
/* 1623 */       accentColor(instance.accentColor());
/* 1624 */       bot(instance.bot());
/* 1625 */       system(instance.system());
/* 1626 */       mfaEnabled(instance.mfaEnabled());
/* 1627 */       locale(instance.locale());
/* 1628 */       verified(instance.verified());
/* 1629 */       email(instance.email());
/* 1630 */       flags(instance.flags());
/* 1631 */       premiumType(instance.premiumType());
/* 1632 */       publicFlags(instance.publicFlags());
/* 1633 */       return this;
/*      */     }
/*      */     
/*      */     public Builder id(String value) {
/* 1637 */       this.id_id = Id.of(value);
/* 1638 */       return this;
/*      */     }
/*      */     
/*      */     public Builder id(long value) {
/* 1642 */       this.id_id = Id.of(value);
/* 1643 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("id")
/*      */     public Builder id(Id value) {
/* 1648 */       this.id_id = value;
/* 1649 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder globalName(String globalName) {
/* 1658 */       this.globalName = Objects.<String>requireNonNull(globalName, "globalName");
/* 1659 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("global_name")
/*      */     public final Builder globalName(Optional<String> globalName) {
/* 1669 */       this.globalName = globalName.orElse(null);
/* 1670 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("username")
/*      */     public final Builder username(String username) {
/* 1680 */       this.username = Objects.<String>requireNonNull(username, "username");
/* 1681 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 1682 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("discriminator")
/*      */     @Deprecated
/*      */     public final Builder discriminator(String discriminator) {
/* 1693 */       this.discriminator = Objects.<String>requireNonNull(discriminator, "discriminator");
/* 1694 */       this.initBits &= 0xFFFFFFFFFFFFFFFDL;
/* 1695 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder avatar(String avatar) {
/* 1704 */       this.avatar = Objects.<String>requireNonNull(avatar, "avatar");
/* 1705 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("avatar")
/*      */     public final Builder avatar(Optional<String> avatar) {
/* 1715 */       this.avatar = avatar.orElse(null);
/* 1716 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("banner")
/*      */     public Builder banner(Possible<Optional<String>> value) {
/* 1721 */       this.banner_possible = value;
/* 1722 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public Builder banner(@Nullable String value) {
/* 1727 */       this.banner_possible = Possible.of(Optional.ofNullable(value));
/* 1728 */       return this;
/*      */     }
/*      */     
/*      */     public Builder bannerOrNull(@Nullable String value) {
/* 1732 */       this.banner_possible = Possible.of(Optional.ofNullable(value));
/* 1733 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("accent_color")
/*      */     public Builder accentColor(Possible<Optional<Integer>> value) {
/* 1738 */       this.accentColor_possible = value;
/* 1739 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public Builder accentColor(@Nullable Integer value) {
/* 1744 */       this.accentColor_possible = Possible.of(Optional.ofNullable(value));
/* 1745 */       return this;
/*      */     }
/*      */     
/*      */     public Builder accentColorOrNull(@Nullable Integer value) {
/* 1749 */       this.accentColor_possible = Possible.of(Optional.ofNullable(value));
/* 1750 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("bot")
/*      */     public Builder bot(Possible<Boolean> value) {
/* 1755 */       this.bot_possible = value;
/* 1756 */       return this;
/*      */     }
/*      */     
/*      */     public Builder bot(Boolean value) {
/* 1760 */       this.bot_possible = Possible.of(value);
/* 1761 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("system")
/*      */     public Builder system(Possible<Boolean> value) {
/* 1766 */       this.system_possible = value;
/* 1767 */       return this;
/*      */     }
/*      */     
/*      */     public Builder system(Boolean value) {
/* 1771 */       this.system_possible = Possible.of(value);
/* 1772 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("mfa_enabled")
/*      */     public Builder mfaEnabled(Possible<Boolean> value) {
/* 1777 */       this.mfaEnabled_possible = value;
/* 1778 */       return this;
/*      */     }
/*      */     
/*      */     public Builder mfaEnabled(Boolean value) {
/* 1782 */       this.mfaEnabled_possible = Possible.of(value);
/* 1783 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("locale")
/*      */     public Builder locale(Possible<String> value) {
/* 1788 */       this.locale_possible = value;
/* 1789 */       return this;
/*      */     }
/*      */     
/*      */     public Builder locale(String value) {
/* 1793 */       this.locale_possible = Possible.of(value);
/* 1794 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("verified")
/*      */     public Builder verified(Possible<Boolean> value) {
/* 1799 */       this.verified_possible = value;
/* 1800 */       return this;
/*      */     }
/*      */     
/*      */     public Builder verified(Boolean value) {
/* 1804 */       this.verified_possible = Possible.of(value);
/* 1805 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("email")
/*      */     public Builder email(Possible<Optional<String>> value) {
/* 1810 */       this.email_possible = value;
/* 1811 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public Builder email(@Nullable String value) {
/* 1816 */       this.email_possible = Possible.of(Optional.ofNullable(value));
/* 1817 */       return this;
/*      */     }
/*      */     
/*      */     public Builder emailOrNull(@Nullable String value) {
/* 1821 */       this.email_possible = Possible.of(Optional.ofNullable(value));
/* 1822 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("flags")
/*      */     public Builder flags(Possible<Long> value) {
/* 1827 */       this.flags_possible = value;
/* 1828 */       return this;
/*      */     }
/*      */     
/*      */     public Builder flags(Long value) {
/* 1832 */       this.flags_possible = Possible.of(value);
/* 1833 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("premium_type")
/*      */     public Builder premiumType(Possible<Integer> value) {
/* 1838 */       this.premiumType_possible = value;
/* 1839 */       return this;
/*      */     }
/*      */     
/*      */     public Builder premiumType(Integer value) {
/* 1843 */       this.premiumType_possible = Possible.of(value);
/* 1844 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("public_flags")
/*      */     public Builder publicFlags(Possible<Long> value) {
/* 1849 */       this.publicFlags_possible = value;
/* 1850 */       return this;
/*      */     }
/*      */     
/*      */     public Builder publicFlags(Long value) {
/* 1854 */       this.publicFlags_possible = Possible.of(value);
/* 1855 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ImmutableUserData build() {
/* 1864 */       if (this.initBits != 0L) {
/* 1865 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*      */       }
/* 1867 */       return new ImmutableUserData(null, 
/*      */           
/* 1869 */           id_build(), this.globalName, this.username, this.discriminator, this.avatar, 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1874 */           banner_build(), 
/* 1875 */           accentColor_build(), 
/* 1876 */           bot_build(), 
/* 1877 */           system_build(), 
/* 1878 */           mfaEnabled_build(), 
/* 1879 */           locale_build(), 
/* 1880 */           verified_build(), 
/* 1881 */           email_build(), 
/* 1882 */           flags_build(), 
/* 1883 */           premiumType_build(), 
/* 1884 */           publicFlags_build());
/*      */     }
/*      */     
/*      */     private String formatRequiredAttributesMessage() {
/* 1888 */       List<String> attributes = new ArrayList<>();
/* 1889 */       if ((this.initBits & 0x1L) != 0L) attributes.add("username"); 
/* 1890 */       if ((this.initBits & 0x2L) != 0L) attributes.add("discriminator"); 
/* 1891 */       return "Cannot build UserData, some of required attributes are not set " + attributes;
/*      */     }
/*      */     
/*      */     private Id id_build() {
/* 1895 */       return this.id_id;
/*      */     }
/*      */     
/*      */     private Possible<Optional<String>> banner_build() {
/* 1899 */       return this.banner_possible;
/*      */     }
/*      */     
/*      */     private Possible<Optional<Integer>> accentColor_build() {
/* 1903 */       return this.accentColor_possible;
/*      */     }
/*      */     
/*      */     private Possible<Boolean> bot_build() {
/* 1907 */       return this.bot_possible;
/*      */     }
/*      */     
/*      */     private Possible<Boolean> system_build() {
/* 1911 */       return this.system_possible;
/*      */     }
/*      */     
/*      */     private Possible<Boolean> mfaEnabled_build() {
/* 1915 */       return this.mfaEnabled_possible;
/*      */     }
/*      */     
/*      */     private Possible<String> locale_build() {
/* 1919 */       return this.locale_possible;
/*      */     }
/*      */     
/*      */     private Possible<Boolean> verified_build() {
/* 1923 */       return this.verified_possible;
/*      */     }
/*      */     
/*      */     private Possible<Optional<String>> email_build() {
/* 1927 */       return this.email_possible;
/*      */     }
/*      */     
/*      */     private Possible<Long> flags_build() {
/* 1931 */       return this.flags_possible;
/*      */     }
/*      */     
/*      */     private Possible<Integer> premiumType_build() {
/* 1935 */       return this.premiumType_possible;
/*      */     }
/*      */     
/*      */     private Possible<Long> publicFlags_build() {
/* 1939 */       return this.publicFlags_possible;
/*      */     }
/*      */     
/*      */     private Builder() {}
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableUserData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */