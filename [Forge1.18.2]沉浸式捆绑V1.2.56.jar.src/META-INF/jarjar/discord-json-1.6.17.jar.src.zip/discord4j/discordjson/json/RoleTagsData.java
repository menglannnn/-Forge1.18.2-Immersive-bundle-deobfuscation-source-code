/*    */ package discord4j.discordjson.json;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonProperty;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import discord4j.discordjson.Id;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import java.util.Optional;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ 
/*    */ @JsonSerialize(as = ImmutableRoleTagsData.class)
/*    */ @JsonDeserialize(as = ImmutableRoleTagsData.class)
/*    */ @Immutable
/*    */ public interface RoleTagsData
/*    */ {
/*    */   static ImmutableRoleTagsData.Builder builder() {
/* 18 */     return ImmutableRoleTagsData.builder();
/*    */   }
/*    */   
/*    */   @JsonProperty("bot_id")
/*    */   Possible<Id> botId();
/*    */   
/*    */   @JsonProperty("integration_id")
/*    */   Possible<Id> integrationId();
/*    */   
/*    */   @JsonProperty("premium_subscriber")
/*    */   Possible<Optional<Void>> premiumSubscriber();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\RoleTagsData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */