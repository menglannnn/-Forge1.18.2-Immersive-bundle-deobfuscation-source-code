/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "DMCreateRequest", generator = "Immutables")
/*     */ public final class ImmutableDMCreateRequest
/*     */   implements DMCreateRequest
/*     */ {
/*     */   private final String recipientId;
/*     */   
/*     */   private ImmutableDMCreateRequest(String recipientId) {
/*  27 */     this.recipientId = Objects.<String>requireNonNull(recipientId, "recipientId");
/*     */   }
/*     */   
/*     */   private ImmutableDMCreateRequest(ImmutableDMCreateRequest original, String recipientId) {
/*  31 */     this.recipientId = recipientId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("recipient_id")
/*     */   public String recipientId() {
/*  40 */     return this.recipientId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableDMCreateRequest withRecipientId(String value) {
/*  50 */     String newValue = Objects.<String>requireNonNull(value, "recipientId");
/*  51 */     if (this.recipientId.equals(newValue)) return this; 
/*  52 */     return new ImmutableDMCreateRequest(this, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/*  61 */     if (this == another) return true; 
/*  62 */     return (another instanceof ImmutableDMCreateRequest && 
/*  63 */       equalTo(0, (ImmutableDMCreateRequest)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableDMCreateRequest another) {
/*  67 */     return this.recipientId.equals(another.recipientId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  76 */     int h = 5381;
/*  77 */     h += (h << 5) + this.recipientId.hashCode();
/*  78 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/*  87 */     return "DMCreateRequest{recipientId=" + this.recipientId + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "DMCreateRequest", generator = "Immutables")
/*     */   static final class Json
/*     */     implements DMCreateRequest
/*     */   {
/*     */     String recipientId;
/*     */ 
/*     */     
/*     */     @JsonProperty("recipient_id")
/*     */     public void setRecipientId(String recipientId) {
/* 104 */       this.recipientId = recipientId;
/*     */     }
/*     */     public String recipientId() {
/* 107 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableDMCreateRequest fromJson(Json json) {
/* 118 */     Builder builder = builder();
/* 119 */     if (json.recipientId != null) {
/* 120 */       builder.recipientId(json.recipientId);
/*     */     }
/* 122 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableDMCreateRequest of(String recipientId) {
/* 131 */     return new ImmutableDMCreateRequest(recipientId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableDMCreateRequest copyOf(DMCreateRequest instance) {
/* 142 */     if (instance instanceof ImmutableDMCreateRequest) {
/* 143 */       return (ImmutableDMCreateRequest)instance;
/*     */     }
/* 145 */     return builder()
/* 146 */       .from(instance)
/* 147 */       .build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 160 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "DMCreateRequest", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_RECIPIENT_ID = 1L;
/*     */ 
/*     */ 
/*     */     
/* 173 */     private long initBits = 1L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private String recipientId;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(DMCreateRequest instance) {
/* 188 */       Objects.requireNonNull(instance, "instance");
/* 189 */       recipientId(instance.recipientId());
/* 190 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("recipient_id")
/*     */     public final Builder recipientId(String recipientId) {
/* 200 */       this.recipientId = Objects.<String>requireNonNull(recipientId, "recipientId");
/* 201 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 202 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableDMCreateRequest build() {
/* 211 */       if (this.initBits != 0L) {
/* 212 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 214 */       return new ImmutableDMCreateRequest(null, this.recipientId);
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 218 */       List<String> attributes = new ArrayList<>();
/* 219 */       if ((this.initBits & 0x1L) != 0L) attributes.add("recipientId"); 
/* 220 */       return "Cannot build DMCreateRequest, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableDMCreateRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */