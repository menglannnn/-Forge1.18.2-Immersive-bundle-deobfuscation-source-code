/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "SessionStartLimitData", generator = "Immutables")
/*     */ public final class ImmutableSessionStartLimitData
/*     */   implements SessionStartLimitData
/*     */ {
/*     */   private final int total;
/*     */   private final int remaining;
/*     */   private final int resetAfter;
/*     */   private final Integer maxConcurrency_value;
/*     */   private final boolean maxConcurrency_absent;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   private volatile transient InitShim initShim;
/*     */   
/*     */   private ImmutableSessionStartLimitData(int total, int remaining, int resetAfter, Possible<Integer> maxConcurrency) {
/*  63 */     this.initShim = new InitShim(); this.total = total; this.remaining = remaining; this.resetAfter = resetAfter; Possible<Integer> maxConcurrency$impl = maxConcurrency; this.maxConcurrency_value = maxConcurrency$impl.toOptional().orElse(null); this.maxConcurrency_absent = maxConcurrency$impl.isAbsent(); this.initShim = null; } private ImmutableSessionStartLimitData(ImmutableSessionStartLimitData original, int total, int remaining, int resetAfter, Possible<Integer> maxConcurrency) { this.initShim = new InitShim(); this.total = total; this.remaining = remaining;
/*     */     this.resetAfter = resetAfter;
/*     */     Possible<Integer> maxConcurrency$impl = maxConcurrency;
/*     */     this.maxConcurrency_value = maxConcurrency$impl.toOptional().orElse(null);
/*     */     this.maxConcurrency_absent = maxConcurrency$impl.isAbsent();
/*  68 */     this.initShim = null; } @Generated(from = "SessionStartLimitData", generator = "Immutables") private final class InitShim { private InitShim() {} private String formatInitCycleMessage() { List<String> attributes = new ArrayList<>();
/*  69 */       return "Cannot build SessionStartLimitData, attribute initializers form cycle " + attributes; }
/*     */      }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("total")
/*     */   public int total() {
/*  79 */     return this.total;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("remaining")
/*     */   public int remaining() {
/*  88 */     return this.remaining;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("reset_after")
/*     */   public int resetAfter() {
/*  97 */     return this.resetAfter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("max_concurrency")
/*     */   public Possible<Integer> maxConcurrency() {
/* 106 */     return this.maxConcurrency_absent ? Possible.absent() : Possible.of(this.maxConcurrency_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableSessionStartLimitData withTotal(int value) {
/* 116 */     if (this.total == value) return this; 
/* 117 */     return new ImmutableSessionStartLimitData(this, value, this.remaining, this.resetAfter, maxConcurrency());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableSessionStartLimitData withRemaining(int value) {
/* 127 */     if (this.remaining == value) return this; 
/* 128 */     return new ImmutableSessionStartLimitData(this, this.total, value, this.resetAfter, maxConcurrency());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableSessionStartLimitData withResetAfter(int value) {
/* 138 */     if (this.resetAfter == value) return this; 
/* 139 */     return new ImmutableSessionStartLimitData(this, this.total, this.remaining, value, maxConcurrency());
/*     */   }
/*     */   
/*     */   public ImmutableSessionStartLimitData withMaxConcurrency(Possible<Integer> value) {
/* 143 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/* 144 */     return new ImmutableSessionStartLimitData(this, this.total, this.remaining, this.resetAfter, newValue);
/*     */   }
/*     */   
/*     */   public ImmutableSessionStartLimitData withMaxConcurrency(Integer value) {
/* 148 */     Possible<Integer> newValue = Possible.of(value);
/* 149 */     return new ImmutableSessionStartLimitData(this, this.total, this.remaining, this.resetAfter, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 158 */     if (this == another) return true; 
/* 159 */     return (another instanceof ImmutableSessionStartLimitData && 
/* 160 */       equalTo(0, (ImmutableSessionStartLimitData)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableSessionStartLimitData another) {
/* 164 */     return (this.total == another.total && this.remaining == another.remaining && this.resetAfter == another.resetAfter && 
/*     */ 
/*     */       
/* 167 */       maxConcurrency().equals(another.maxConcurrency()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 176 */     int h = 5381;
/* 177 */     h += (h << 5) + this.total;
/* 178 */     h += (h << 5) + this.remaining;
/* 179 */     h += (h << 5) + this.resetAfter;
/* 180 */     h += (h << 5) + maxConcurrency().hashCode();
/* 181 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 190 */     return "SessionStartLimitData{total=" + this.total + ", remaining=" + this.remaining + ", resetAfter=" + this.resetAfter + ", maxConcurrency=" + 
/*     */ 
/*     */ 
/*     */       
/* 194 */       maxConcurrency().toString() + "}";
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "SessionStartLimitData", generator = "Immutables")
/*     */   static final class Json
/*     */     implements SessionStartLimitData
/*     */   {
/*     */     int total;
/*     */     
/*     */     boolean totalIsSet;
/*     */     
/*     */     int remaining;
/*     */     
/*     */     boolean remainingIsSet;
/*     */     int resetAfter;
/*     */     boolean resetAfterIsSet;
/* 214 */     Possible<Integer> maxConcurrency = Possible.absent();
/*     */     
/*     */     @JsonProperty("total")
/*     */     public void setTotal(int total) {
/* 218 */       this.total = total;
/* 219 */       this.totalIsSet = true;
/*     */     }
/*     */     @JsonProperty("remaining")
/*     */     public void setRemaining(int remaining) {
/* 223 */       this.remaining = remaining;
/* 224 */       this.remainingIsSet = true;
/*     */     }
/*     */     @JsonProperty("reset_after")
/*     */     public void setResetAfter(int resetAfter) {
/* 228 */       this.resetAfter = resetAfter;
/* 229 */       this.resetAfterIsSet = true;
/*     */     }
/*     */     @JsonProperty("max_concurrency")
/*     */     public void setMaxConcurrency(Possible<Integer> maxConcurrency) {
/* 233 */       this.maxConcurrency = maxConcurrency;
/*     */     }
/*     */     public int total() {
/* 236 */       throw new UnsupportedOperationException();
/*     */     } public int remaining() {
/* 238 */       throw new UnsupportedOperationException();
/*     */     } public int resetAfter() {
/* 240 */       throw new UnsupportedOperationException();
/*     */     } public Possible<Integer> maxConcurrency() {
/* 242 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableSessionStartLimitData fromJson(Json json) {
/* 253 */     Builder builder = builder();
/* 254 */     if (json.totalIsSet) {
/* 255 */       builder.total(json.total);
/*     */     }
/* 257 */     if (json.remainingIsSet) {
/* 258 */       builder.remaining(json.remaining);
/*     */     }
/* 260 */     if (json.resetAfterIsSet) {
/* 261 */       builder.resetAfter(json.resetAfter);
/*     */     }
/* 263 */     if (json.maxConcurrency != null) {
/* 264 */       builder.maxConcurrency(json.maxConcurrency);
/*     */     }
/* 266 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableSessionStartLimitData of(int total, int remaining, int resetAfter, Possible<Integer> maxConcurrency) {
/* 278 */     return new ImmutableSessionStartLimitData(total, remaining, resetAfter, maxConcurrency);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableSessionStartLimitData copyOf(SessionStartLimitData instance) {
/* 289 */     if (instance instanceof ImmutableSessionStartLimitData) {
/* 290 */       return (ImmutableSessionStartLimitData)instance;
/*     */     }
/* 292 */     return builder()
/* 293 */       .from(instance)
/* 294 */       .build();
/*     */   }
/*     */   
/*     */   public boolean isMaxConcurrencyPresent() {
/* 298 */     return !this.maxConcurrency_absent;
/*     */   }
/*     */   
/*     */   public Integer maxConcurrencyOrElse(Integer defaultValue) {
/* 302 */     return !this.maxConcurrency_absent ? this.maxConcurrency_value : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 318 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "SessionStartLimitData", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_TOTAL = 1L;
/*     */ 
/*     */     
/*     */     private static final long INIT_BIT_REMAINING = 2L;
/*     */     
/*     */     private static final long INIT_BIT_RESET_AFTER = 4L;
/*     */     
/* 333 */     private long initBits = 7L;
/*     */     
/* 335 */     private Possible<Integer> maxConcurrency_possible = Possible.absent();
/*     */ 
/*     */ 
/*     */     
/*     */     private int total;
/*     */ 
/*     */ 
/*     */     
/*     */     private int remaining;
/*     */ 
/*     */     
/*     */     private int resetAfter;
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(SessionStartLimitData instance) {
/* 351 */       Objects.requireNonNull(instance, "instance");
/* 352 */       total(instance.total());
/* 353 */       remaining(instance.remaining());
/* 354 */       resetAfter(instance.resetAfter());
/* 355 */       maxConcurrency(instance.maxConcurrency());
/* 356 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("total")
/*     */     public final Builder total(int total) {
/* 366 */       this.total = total;
/* 367 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 368 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("remaining")
/*     */     public final Builder remaining(int remaining) {
/* 378 */       this.remaining = remaining;
/* 379 */       this.initBits &= 0xFFFFFFFFFFFFFFFDL;
/* 380 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("reset_after")
/*     */     public final Builder resetAfter(int resetAfter) {
/* 390 */       this.resetAfter = resetAfter;
/* 391 */       this.initBits &= 0xFFFFFFFFFFFFFFFBL;
/* 392 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("max_concurrency")
/*     */     public Builder maxConcurrency(Possible<Integer> value) {
/* 397 */       this.maxConcurrency_possible = value;
/* 398 */       return this;
/*     */     }
/*     */     
/*     */     public Builder maxConcurrency(Integer value) {
/* 402 */       this.maxConcurrency_possible = Possible.of(value);
/* 403 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableSessionStartLimitData build() {
/* 412 */       if (this.initBits != 0L) {
/* 413 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 415 */       return new ImmutableSessionStartLimitData(null, this.total, this.remaining, this.resetAfter, maxConcurrency_build());
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 419 */       List<String> attributes = new ArrayList<>();
/* 420 */       if ((this.initBits & 0x1L) != 0L) attributes.add("total"); 
/* 421 */       if ((this.initBits & 0x2L) != 0L) attributes.add("remaining"); 
/* 422 */       if ((this.initBits & 0x4L) != 0L) attributes.add("resetAfter"); 
/* 423 */       return "Cannot build SessionStartLimitData, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Possible<Integer> maxConcurrency_build() {
/* 427 */       return this.maxConcurrency_possible;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableSessionStartLimitData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */