/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "EmbedFieldData", generator = "Immutables")
/*     */ public final class ImmutableEmbedFieldData
/*     */   implements EmbedFieldData
/*     */ {
/*     */   private final String name;
/*     */   private final String value;
/*     */   private final Boolean inline_value;
/*     */   private final boolean inline_absent;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   private volatile transient InitShim initShim;
/*     */   
/*     */   private ImmutableEmbedFieldData(String name, String value, Possible<Boolean> inline) {
/*  58 */     this.initShim = new InitShim(); this.name = Objects.<String>requireNonNull(name, "name"); this.value = Objects.<String>requireNonNull(value, "value"); Possible<Boolean> inline$impl = inline; this.inline_value = inline$impl.toOptional().orElse(null); this.inline_absent = inline$impl.isAbsent(); this.initShim = null; } private ImmutableEmbedFieldData(ImmutableEmbedFieldData original, String name, String value, Possible<Boolean> inline) { this.initShim = new InitShim(); this.name = name;
/*     */     this.value = value;
/*     */     Possible<Boolean> inline$impl = inline;
/*     */     this.inline_value = inline$impl.toOptional().orElse(null);
/*     */     this.inline_absent = inline$impl.isAbsent();
/*  63 */     this.initShim = null; } @Generated(from = "EmbedFieldData", generator = "Immutables") private final class InitShim { private InitShim() {} private String formatInitCycleMessage() { List<String> attributes = new ArrayList<>();
/*  64 */       return "Cannot build EmbedFieldData, attribute initializers form cycle " + attributes; }
/*     */      }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("name")
/*     */   public String name() {
/*  74 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("value")
/*     */   public String value() {
/*  83 */     return this.value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("inline")
/*     */   public Possible<Boolean> inline() {
/*  92 */     return this.inline_absent ? Possible.absent() : Possible.of(this.inline_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableEmbedFieldData withName(String value) {
/* 102 */     String newValue = Objects.<String>requireNonNull(value, "name");
/* 103 */     if (this.name.equals(newValue)) return this; 
/* 104 */     return new ImmutableEmbedFieldData(this, newValue, this.value, inline());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableEmbedFieldData withValue(String value) {
/* 114 */     String newValue = Objects.<String>requireNonNull(value, "value");
/* 115 */     if (this.value.equals(newValue)) return this; 
/* 116 */     return new ImmutableEmbedFieldData(this, this.name, newValue, inline());
/*     */   }
/*     */   
/*     */   public ImmutableEmbedFieldData withInline(Possible<Boolean> value) {
/* 120 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/* 121 */     return new ImmutableEmbedFieldData(this, this.name, this.value, newValue);
/*     */   }
/*     */   
/*     */   public ImmutableEmbedFieldData withInline(Boolean value) {
/* 125 */     Possible<Boolean> newValue = Possible.of(value);
/* 126 */     return new ImmutableEmbedFieldData(this, this.name, this.value, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 135 */     if (this == another) return true; 
/* 136 */     return (another instanceof ImmutableEmbedFieldData && 
/* 137 */       equalTo(0, (ImmutableEmbedFieldData)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableEmbedFieldData another) {
/* 141 */     return (this.name.equals(another.name) && this.value
/* 142 */       .equals(another.value) && 
/* 143 */       inline().equals(another.inline()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 152 */     int h = 5381;
/* 153 */     h += (h << 5) + this.name.hashCode();
/* 154 */     h += (h << 5) + this.value.hashCode();
/* 155 */     h += (h << 5) + inline().hashCode();
/* 156 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 165 */     return "EmbedFieldData{name=" + this.name + ", value=" + this.value + ", inline=" + 
/*     */ 
/*     */       
/* 168 */       inline().toString() + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "EmbedFieldData", generator = "Immutables")
/*     */   static final class Json
/*     */     implements EmbedFieldData
/*     */   {
/*     */     String name;
/*     */     
/*     */     String value;
/*     */     
/* 184 */     Possible<Boolean> inline = Possible.absent();
/*     */     
/*     */     @JsonProperty("name")
/*     */     public void setName(String name) {
/* 188 */       this.name = name;
/*     */     }
/*     */     @JsonProperty("value")
/*     */     public void setValue(String value) {
/* 192 */       this.value = value;
/*     */     }
/*     */     @JsonProperty("inline")
/*     */     public void setInline(Possible<Boolean> inline) {
/* 196 */       this.inline = inline;
/*     */     }
/*     */     public String name() {
/* 199 */       throw new UnsupportedOperationException();
/*     */     } public String value() {
/* 201 */       throw new UnsupportedOperationException();
/*     */     } public Possible<Boolean> inline() {
/* 203 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableEmbedFieldData fromJson(Json json) {
/* 214 */     Builder builder = builder();
/* 215 */     if (json.name != null) {
/* 216 */       builder.name(json.name);
/*     */     }
/* 218 */     if (json.value != null) {
/* 219 */       builder.value(json.value);
/*     */     }
/* 221 */     if (json.inline != null) {
/* 222 */       builder.inline(json.inline);
/*     */     }
/* 224 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableEmbedFieldData of(String name, String value, Possible<Boolean> inline) {
/* 235 */     return new ImmutableEmbedFieldData(name, value, inline);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableEmbedFieldData copyOf(EmbedFieldData instance) {
/* 246 */     if (instance instanceof ImmutableEmbedFieldData) {
/* 247 */       return (ImmutableEmbedFieldData)instance;
/*     */     }
/* 249 */     return builder()
/* 250 */       .from(instance)
/* 251 */       .build();
/*     */   }
/*     */   
/*     */   public boolean isInlinePresent() {
/* 255 */     return !this.inline_absent;
/*     */   }
/*     */   
/*     */   public Boolean inlineOrElse(Boolean defaultValue) {
/* 259 */     return !this.inline_absent ? this.inline_value : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 274 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "EmbedFieldData", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_NAME = 1L;
/*     */ 
/*     */     
/*     */     private static final long INIT_BIT_VALUE = 2L;
/*     */ 
/*     */     
/* 288 */     private long initBits = 3L;
/*     */     
/* 290 */     private Possible<Boolean> inline_possible = Possible.absent();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private String name;
/*     */ 
/*     */ 
/*     */     
/*     */     private String value;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(EmbedFieldData instance) {
/* 305 */       Objects.requireNonNull(instance, "instance");
/* 306 */       name(instance.name());
/* 307 */       value(instance.value());
/* 308 */       inline(instance.inline());
/* 309 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("name")
/*     */     public final Builder name(String name) {
/* 319 */       this.name = Objects.<String>requireNonNull(name, "name");
/* 320 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 321 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("value")
/*     */     public final Builder value(String value) {
/* 331 */       this.value = Objects.<String>requireNonNull(value, "value");
/* 332 */       this.initBits &= 0xFFFFFFFFFFFFFFFDL;
/* 333 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("inline")
/*     */     public Builder inline(Possible<Boolean> value) {
/* 338 */       this.inline_possible = value;
/* 339 */       return this;
/*     */     }
/*     */     
/*     */     public Builder inline(Boolean value) {
/* 343 */       this.inline_possible = Possible.of(value);
/* 344 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableEmbedFieldData build() {
/* 353 */       if (this.initBits != 0L) {
/* 354 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 356 */       return new ImmutableEmbedFieldData(null, this.name, this.value, inline_build());
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 360 */       List<String> attributes = new ArrayList<>();
/* 361 */       if ((this.initBits & 0x1L) != 0L) attributes.add("name"); 
/* 362 */       if ((this.initBits & 0x2L) != 0L) attributes.add("value"); 
/* 363 */       return "Cannot build EmbedFieldData, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Possible<Boolean> inline_build() {
/* 367 */       return this.inline_possible;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableEmbedFieldData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */