/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.Id;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.stream.StreamSupport;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "EmojiData", generator = "Immutables")
/*     */ public final class ImmutableEmojiData
/*     */   implements EmojiData
/*     */ {
/*     */   private final long id_value;
/*     */   private final boolean id_present;
/*     */   private final String name;
/*     */   private final List<String> roles_value;
/*     */   private final boolean roles_absent;
/*     */   private final UserData user_value;
/*     */   private final boolean user_absent;
/*     */   private final Boolean requireColons_value;
/*     */   private final boolean requireColons_absent;
/*     */   private final Boolean managed_value;
/*     */   private final boolean managed_absent;
/*     */   private final Boolean available_value;
/*     */   private final boolean available_absent;
/*     */   private final Boolean animated_value;
/*     */   private final boolean animated_absent;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   
/*     */   private ImmutableEmojiData(Optional<Id> id, Optional<String> name, Possible<List<String>> roles, Possible<UserData> user, Possible<Boolean> requireColons, Possible<Boolean> managed, Possible<Boolean> available, Possible<Boolean> animated) {
/*  55 */     Optional<Id> id$impl = id;
/*  56 */     this.name = name.orElse(null);
/*  57 */     Possible<List<String>> roles$impl = roles;
/*  58 */     Possible<UserData> user$impl = user;
/*  59 */     Possible<Boolean> requireColons$impl = requireColons;
/*  60 */     Possible<Boolean> managed$impl = managed;
/*  61 */     Possible<Boolean> available$impl = available;
/*  62 */     Possible<Boolean> animated$impl = animated;
/*  63 */     this
/*     */       
/*  65 */       .id_value = ((Long)id$impl.<Long>map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  66 */     this.id_present = id$impl.isPresent();
/*  67 */     this.roles_value = roles$impl.toOptional().orElse(null);
/*  68 */     this.roles_absent = roles$impl.isAbsent();
/*  69 */     this.user_value = user$impl.toOptional().orElse(null);
/*  70 */     this.user_absent = user$impl.isAbsent();
/*  71 */     this.requireColons_value = requireColons$impl.toOptional().orElse(null);
/*  72 */     this.requireColons_absent = requireColons$impl.isAbsent();
/*  73 */     this.managed_value = managed$impl.toOptional().orElse(null);
/*  74 */     this.managed_absent = managed$impl.isAbsent();
/*  75 */     this.available_value = available$impl.toOptional().orElse(null);
/*  76 */     this.available_absent = available$impl.isAbsent();
/*  77 */     this.animated_value = animated$impl.toOptional().orElse(null);
/*  78 */     this.animated_absent = animated$impl.isAbsent();
/*  79 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ImmutableEmojiData(ImmutableEmojiData original, Optional<Id> id, String name, Possible<List<String>> roles, Possible<UserData> user, Possible<Boolean> requireColons, Possible<Boolean> managed, Possible<Boolean> available, Possible<Boolean> animated) {
/*  92 */     Optional<Id> id$impl = id;
/*  93 */     this.name = name;
/*  94 */     Possible<List<String>> roles$impl = roles;
/*  95 */     Possible<UserData> user$impl = user;
/*  96 */     Possible<Boolean> requireColons$impl = requireColons;
/*  97 */     Possible<Boolean> managed$impl = managed;
/*  98 */     Possible<Boolean> available$impl = available;
/*  99 */     Possible<Boolean> animated$impl = animated;
/* 100 */     this
/*     */       
/* 102 */       .id_value = ((Long)id$impl.<Long>map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/* 103 */     this.id_present = id$impl.isPresent();
/* 104 */     this.roles_value = roles$impl.toOptional().orElse(null);
/* 105 */     this.roles_absent = roles$impl.isAbsent();
/* 106 */     this.user_value = user$impl.toOptional().orElse(null);
/* 107 */     this.user_absent = user$impl.isAbsent();
/* 108 */     this.requireColons_value = requireColons$impl.toOptional().orElse(null);
/* 109 */     this.requireColons_absent = requireColons$impl.isAbsent();
/* 110 */     this.managed_value = managed$impl.toOptional().orElse(null);
/* 111 */     this.managed_absent = managed$impl.isAbsent();
/* 112 */     this.available_value = available$impl.toOptional().orElse(null);
/* 113 */     this.available_absent = available$impl.isAbsent();
/* 114 */     this.animated_value = animated$impl.toOptional().orElse(null);
/* 115 */     this.animated_absent = animated$impl.isAbsent();
/* 116 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 122 */   private volatile transient InitShim initShim = new InitShim();
/*     */   
/*     */   @Generated(from = "EmojiData", generator = "Immutables")
/*     */   private final class InitShim {
/*     */     private String formatInitCycleMessage() {
/* 127 */       List<String> attributes = new ArrayList<>();
/* 128 */       return "Cannot build EmojiData, attribute initializers form cycle " + attributes;
/*     */     }
/*     */ 
/*     */     
/*     */     private InitShim() {}
/*     */   }
/*     */ 
/*     */   
/*     */   @JsonProperty("id")
/*     */   public Optional<Id> id() {
/* 138 */     return this.id_present ? Optional.<Id>of(Id.of(this.id_value)) : Optional.<Id>empty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("name")
/*     */   public Optional<String> name() {
/* 147 */     return Optional.ofNullable(this.name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("roles")
/*     */   public Possible<List<String>> roles() {
/* 156 */     return this.roles_absent ? Possible.absent() : 
/* 157 */       Possible.of(this.roles_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("user")
/*     */   public Possible<UserData> user() {
/* 166 */     return this.user_absent ? Possible.absent() : Possible.of(this.user_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("require_colons")
/*     */   public Possible<Boolean> requireColons() {
/* 175 */     return this.requireColons_absent ? Possible.absent() : Possible.of(this.requireColons_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("managed")
/*     */   public Possible<Boolean> managed() {
/* 184 */     return this.managed_absent ? Possible.absent() : Possible.of(this.managed_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("available")
/*     */   public Possible<Boolean> available() {
/* 193 */     return this.available_absent ? Possible.absent() : Possible.of(this.available_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("animated")
/*     */   public Possible<Boolean> animated() {
/* 202 */     return this.animated_absent ? Possible.absent() : Possible.of(this.animated_value);
/*     */   }
/*     */   
/*     */   public ImmutableEmojiData withId(Optional<Id> value) {
/* 206 */     Optional<Id> newValue = Objects.<Optional<Id>>requireNonNull(value);
/* 207 */     return new ImmutableEmojiData(this, newValue, this.name, 
/*     */ 
/*     */ 
/*     */         
/* 211 */         roles(), 
/* 212 */         user(), 
/* 213 */         requireColons(), 
/* 214 */         managed(), 
/* 215 */         available(), 
/* 216 */         animated());
/*     */   }
/*     */   
/*     */   public ImmutableEmojiData withId(long value) {
/* 220 */     Optional<Id> newValue = Optional.of(Id.of(value));
/* 221 */     return new ImmutableEmojiData(this, newValue, this.name, 
/*     */ 
/*     */ 
/*     */         
/* 225 */         roles(), 
/* 226 */         user(), 
/* 227 */         requireColons(), 
/* 228 */         managed(), 
/* 229 */         available(), 
/* 230 */         animated());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableEmojiData withName(String value) {
/* 239 */     String newValue = Objects.<String>requireNonNull(value, "name");
/* 240 */     if (Objects.equals(this.name, newValue)) return this; 
/* 241 */     return new ImmutableEmojiData(this, 
/*     */         
/* 243 */         id(), newValue, 
/*     */         
/* 245 */         roles(), 
/* 246 */         user(), 
/* 247 */         requireColons(), 
/* 248 */         managed(), 
/* 249 */         available(), 
/* 250 */         animated());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableEmojiData withName(Optional<String> optional) {
/* 260 */     String value = optional.orElse(null);
/* 261 */     if (Objects.equals(this.name, value)) return this; 
/* 262 */     return new ImmutableEmojiData(this, 
/*     */         
/* 264 */         id(), value, 
/*     */         
/* 266 */         roles(), 
/* 267 */         user(), 
/* 268 */         requireColons(), 
/* 269 */         managed(), 
/* 270 */         available(), 
/* 271 */         animated());
/*     */   }
/*     */   
/*     */   public ImmutableEmojiData withRoles(Possible<List<String>> possible) {
/* 275 */     Possible<List<String>> newValue = Objects.<Possible<List<String>>>requireNonNull(possible);
/* 276 */     return new ImmutableEmojiData(this, 
/*     */         
/* 278 */         id(), this.name, newValue, 
/*     */ 
/*     */         
/* 281 */         user(), 
/* 282 */         requireColons(), 
/* 283 */         managed(), 
/* 284 */         available(), 
/* 285 */         animated());
/*     */   }
/*     */   
/*     */   public ImmutableEmojiData withRoles(Iterable<String> elements) {
/* 289 */     Possible<List<String>> newValue = Possible.of(
/* 290 */         StreamSupport.stream(((Iterable)Objects.<Iterable>requireNonNull(elements)).spliterator(), false).collect(Collectors.toList()));
/* 291 */     return new ImmutableEmojiData(this, 
/*     */         
/* 293 */         id(), this.name, newValue, 
/*     */ 
/*     */         
/* 296 */         user(), 
/* 297 */         requireColons(), 
/* 298 */         managed(), 
/* 299 */         available(), 
/* 300 */         animated());
/*     */   }
/*     */   
/*     */   @SafeVarargs
/*     */   public final ImmutableEmojiData withRoles(String... elements) {
/* 305 */     Possible<List<String>> newValue = Possible.of(Arrays.asList(elements));
/* 306 */     return new ImmutableEmojiData(this, 
/*     */         
/* 308 */         id(), this.name, newValue, 
/*     */ 
/*     */         
/* 311 */         user(), 
/* 312 */         requireColons(), 
/* 313 */         managed(), 
/* 314 */         available(), 
/* 315 */         animated());
/*     */   }
/*     */   
/*     */   public ImmutableEmojiData withUser(Possible<UserData> value) {
/* 319 */     Possible<UserData> newValue = Objects.<Possible<UserData>>requireNonNull(value);
/* 320 */     return new ImmutableEmojiData(this, 
/*     */         
/* 322 */         id(), this.name, 
/*     */         
/* 324 */         roles(), newValue, 
/*     */         
/* 326 */         requireColons(), 
/* 327 */         managed(), 
/* 328 */         available(), 
/* 329 */         animated());
/*     */   }
/*     */   
/*     */   public ImmutableEmojiData withUser(UserData value) {
/* 333 */     Possible<UserData> newValue = Possible.of(value);
/* 334 */     return new ImmutableEmojiData(this, 
/*     */         
/* 336 */         id(), this.name, 
/*     */         
/* 338 */         roles(), newValue, 
/*     */         
/* 340 */         requireColons(), 
/* 341 */         managed(), 
/* 342 */         available(), 
/* 343 */         animated());
/*     */   }
/*     */   
/*     */   public ImmutableEmojiData withRequireColons(Possible<Boolean> value) {
/* 347 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/* 348 */     return new ImmutableEmojiData(this, 
/*     */         
/* 350 */         id(), this.name, 
/*     */         
/* 352 */         roles(), 
/* 353 */         user(), newValue, 
/*     */         
/* 355 */         managed(), 
/* 356 */         available(), 
/* 357 */         animated());
/*     */   }
/*     */   
/*     */   public ImmutableEmojiData withRequireColons(Boolean value) {
/* 361 */     Possible<Boolean> newValue = Possible.of(value);
/* 362 */     return new ImmutableEmojiData(this, 
/*     */         
/* 364 */         id(), this.name, 
/*     */         
/* 366 */         roles(), 
/* 367 */         user(), newValue, 
/*     */         
/* 369 */         managed(), 
/* 370 */         available(), 
/* 371 */         animated());
/*     */   }
/*     */   
/*     */   public ImmutableEmojiData withManaged(Possible<Boolean> value) {
/* 375 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/* 376 */     return new ImmutableEmojiData(this, 
/*     */         
/* 378 */         id(), this.name, 
/*     */         
/* 380 */         roles(), 
/* 381 */         user(), 
/* 382 */         requireColons(), newValue, 
/*     */         
/* 384 */         available(), 
/* 385 */         animated());
/*     */   }
/*     */   
/*     */   public ImmutableEmojiData withManaged(Boolean value) {
/* 389 */     Possible<Boolean> newValue = Possible.of(value);
/* 390 */     return new ImmutableEmojiData(this, 
/*     */         
/* 392 */         id(), this.name, 
/*     */         
/* 394 */         roles(), 
/* 395 */         user(), 
/* 396 */         requireColons(), newValue, 
/*     */         
/* 398 */         available(), 
/* 399 */         animated());
/*     */   }
/*     */   
/*     */   public ImmutableEmojiData withAvailable(Possible<Boolean> value) {
/* 403 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/* 404 */     return new ImmutableEmojiData(this, 
/*     */         
/* 406 */         id(), this.name, 
/*     */         
/* 408 */         roles(), 
/* 409 */         user(), 
/* 410 */         requireColons(), 
/* 411 */         managed(), newValue, 
/*     */         
/* 413 */         animated());
/*     */   }
/*     */   
/*     */   public ImmutableEmojiData withAvailable(Boolean value) {
/* 417 */     Possible<Boolean> newValue = Possible.of(value);
/* 418 */     return new ImmutableEmojiData(this, 
/*     */         
/* 420 */         id(), this.name, 
/*     */         
/* 422 */         roles(), 
/* 423 */         user(), 
/* 424 */         requireColons(), 
/* 425 */         managed(), newValue, 
/*     */         
/* 427 */         animated());
/*     */   }
/*     */   
/*     */   public ImmutableEmojiData withAnimated(Possible<Boolean> value) {
/* 431 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/* 432 */     return new ImmutableEmojiData(this, 
/*     */         
/* 434 */         id(), this.name, 
/*     */         
/* 436 */         roles(), 
/* 437 */         user(), 
/* 438 */         requireColons(), 
/* 439 */         managed(), 
/* 440 */         available(), newValue);
/*     */   }
/*     */ 
/*     */   
/*     */   public ImmutableEmojiData withAnimated(Boolean value) {
/* 445 */     Possible<Boolean> newValue = Possible.of(value);
/* 446 */     return new ImmutableEmojiData(this, 
/*     */         
/* 448 */         id(), this.name, 
/*     */         
/* 450 */         roles(), 
/* 451 */         user(), 
/* 452 */         requireColons(), 
/* 453 */         managed(), 
/* 454 */         available(), newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 464 */     if (this == another) return true; 
/* 465 */     return (another instanceof ImmutableEmojiData && 
/* 466 */       equalTo(0, (ImmutableEmojiData)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableEmojiData another) {
/* 470 */     return (id().equals(another.id()) && 
/* 471 */       Objects.equals(this.name, another.name) && 
/* 472 */       Objects.equals(this.roles_value, another.roles_value) && 
/* 473 */       user().equals(another.user()) && 
/* 474 */       requireColons().equals(another.requireColons()) && 
/* 475 */       managed().equals(another.managed()) && 
/* 476 */       available().equals(another.available()) && 
/* 477 */       animated().equals(another.animated()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 486 */     int h = 5381;
/* 487 */     h += (h << 5) + id().hashCode();
/* 488 */     h += (h << 5) + Objects.hashCode(this.name);
/* 489 */     h += (h << 5) + Objects.hashCode(this.roles_value);
/* 490 */     h += (h << 5) + user().hashCode();
/* 491 */     h += (h << 5) + requireColons().hashCode();
/* 492 */     h += (h << 5) + managed().hashCode();
/* 493 */     h += (h << 5) + available().hashCode();
/* 494 */     h += (h << 5) + animated().hashCode();
/* 495 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 504 */     StringBuilder builder = new StringBuilder("EmojiData{");
/* 505 */     builder.append("id=").append(id().toString());
/* 506 */     if (this.name != null) {
/* 507 */       builder.append(", ");
/* 508 */       builder.append("name=").append(this.name);
/*     */     } 
/* 510 */     builder.append(", ");
/* 511 */     builder.append("roles=").append(Objects.toString(this.roles_value));
/* 512 */     builder.append(", ");
/* 513 */     builder.append("user=").append(user().toString());
/* 514 */     builder.append(", ");
/* 515 */     builder.append("requireColons=").append(requireColons().toString());
/* 516 */     builder.append(", ");
/* 517 */     builder.append("managed=").append(managed().toString());
/* 518 */     builder.append(", ");
/* 519 */     builder.append("available=").append(available().toString());
/* 520 */     builder.append(", ");
/* 521 */     builder.append("animated=").append(animated().toString());
/* 522 */     return builder.append("}").toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "EmojiData", generator = "Immutables")
/*     */   static final class Json
/*     */     implements EmojiData
/*     */   {
/* 535 */     Optional<Id> id = Optional.empty();
/*     */     
/* 537 */     Optional<String> name = Optional.empty();
/*     */     
/* 539 */     Possible<List<String>> roles = Possible.absent();
/*     */ 
/*     */     
/* 542 */     Possible<UserData> user = Possible.absent();
/*     */ 
/*     */     
/* 545 */     Possible<Boolean> requireColons = Possible.absent();
/*     */ 
/*     */     
/* 548 */     Possible<Boolean> managed = Possible.absent();
/*     */ 
/*     */     
/* 551 */     Possible<Boolean> available = Possible.absent();
/*     */ 
/*     */     
/* 554 */     Possible<Boolean> animated = Possible.absent();
/*     */     
/*     */     @JsonProperty("id")
/*     */     public void setId(Optional<Id> id) {
/* 558 */       this.id = id;
/*     */     }
/*     */     @JsonProperty("name")
/*     */     public void setName(Optional<String> name) {
/* 562 */       this.name = name;
/*     */     }
/*     */     @JsonProperty("roles")
/*     */     public void setRoles(Possible<List<String>> roles) {
/* 566 */       this.roles = roles;
/*     */     }
/*     */     @JsonProperty("user")
/*     */     public void setUser(Possible<UserData> user) {
/* 570 */       this.user = user;
/*     */     }
/*     */     @JsonProperty("require_colons")
/*     */     public void setRequireColons(Possible<Boolean> requireColons) {
/* 574 */       this.requireColons = requireColons;
/*     */     }
/*     */     @JsonProperty("managed")
/*     */     public void setManaged(Possible<Boolean> managed) {
/* 578 */       this.managed = managed;
/*     */     }
/*     */     @JsonProperty("available")
/*     */     public void setAvailable(Possible<Boolean> available) {
/* 582 */       this.available = available;
/*     */     }
/*     */     @JsonProperty("animated")
/*     */     public void setAnimated(Possible<Boolean> animated) {
/* 586 */       this.animated = animated;
/*     */     }
/*     */     public Optional<Id> id() {
/* 589 */       throw new UnsupportedOperationException();
/*     */     } public Optional<String> name() {
/* 591 */       throw new UnsupportedOperationException();
/*     */     } public Possible<List<String>> roles() {
/* 593 */       throw new UnsupportedOperationException();
/*     */     } public Possible<UserData> user() {
/* 595 */       throw new UnsupportedOperationException();
/*     */     } public Possible<Boolean> requireColons() {
/* 597 */       throw new UnsupportedOperationException();
/*     */     } public Possible<Boolean> managed() {
/* 599 */       throw new UnsupportedOperationException();
/*     */     } public Possible<Boolean> available() {
/* 601 */       throw new UnsupportedOperationException();
/*     */     } public Possible<Boolean> animated() {
/* 603 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableEmojiData fromJson(Json json) {
/* 614 */     Builder builder = builder();
/* 615 */     if (json.id != null) {
/* 616 */       builder.id(json.id);
/*     */     }
/* 618 */     if (json.name != null) {
/* 619 */       builder.name(json.name);
/*     */     }
/* 621 */     if (json.roles != null) {
/* 622 */       builder.roles(json.roles);
/*     */     }
/* 624 */     if (json.user != null) {
/* 625 */       builder.user(json.user);
/*     */     }
/* 627 */     if (json.requireColons != null) {
/* 628 */       builder.requireColons(json.requireColons);
/*     */     }
/* 630 */     if (json.managed != null) {
/* 631 */       builder.managed(json.managed);
/*     */     }
/* 633 */     if (json.available != null) {
/* 634 */       builder.available(json.available);
/*     */     }
/* 636 */     if (json.animated != null) {
/* 637 */       builder.animated(json.animated);
/*     */     }
/* 639 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableEmojiData of(Optional<Id> id, Optional<String> name, Possible<List<String>> roles, Possible<UserData> user, Possible<Boolean> requireColons, Possible<Boolean> managed, Possible<Boolean> available, Possible<Boolean> animated) {
/* 655 */     return new ImmutableEmojiData(id, name, roles, user, requireColons, managed, available, animated);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableEmojiData copyOf(EmojiData instance) {
/* 666 */     if (instance instanceof ImmutableEmojiData) {
/* 667 */       return (ImmutableEmojiData)instance;
/*     */     }
/* 669 */     return builder()
/* 670 */       .from(instance)
/* 671 */       .build();
/*     */   }
/*     */   
/*     */   public boolean isIdPresent() {
/* 675 */     return this.id_present;
/*     */   }
/*     */   
/*     */   public long idOrElse(long defaultValue) {
/* 679 */     return this.id_present ? this.id_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isRolesPresent() {
/* 683 */     return !this.roles_absent;
/*     */   }
/*     */   
/*     */   public List<String> rolesOrElse(List<String> defaultValue) {
/* 687 */     return !this.roles_absent ? this.roles_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isUserPresent() {
/* 691 */     return !this.user_absent;
/*     */   }
/*     */   
/*     */   public UserData userOrElse(UserData defaultValue) {
/* 695 */     return !this.user_absent ? this.user_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isRequireColonsPresent() {
/* 699 */     return !this.requireColons_absent;
/*     */   }
/*     */   
/*     */   public Boolean requireColonsOrElse(Boolean defaultValue) {
/* 703 */     return !this.requireColons_absent ? this.requireColons_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isManagedPresent() {
/* 707 */     return !this.managed_absent;
/*     */   }
/*     */   
/*     */   public Boolean managedOrElse(Boolean defaultValue) {
/* 711 */     return !this.managed_absent ? this.managed_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isAvailablePresent() {
/* 715 */     return !this.available_absent;
/*     */   }
/*     */   
/*     */   public Boolean availableOrElse(Boolean defaultValue) {
/* 719 */     return !this.available_absent ? this.available_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isAnimatedPresent() {
/* 723 */     return !this.animated_absent;
/*     */   }
/*     */   
/*     */   public Boolean animatedOrElse(Boolean defaultValue) {
/* 727 */     return !this.animated_absent ? this.animated_value : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 747 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "EmojiData", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/* 759 */     private Optional<Id> id_optional = Optional.empty();
/* 760 */     private List<String> roles_list = null;
/* 761 */     private Possible<UserData> user_possible = Possible.absent();
/* 762 */     private Possible<Boolean> requireColons_possible = Possible.absent();
/* 763 */     private Possible<Boolean> managed_possible = Possible.absent();
/* 764 */     private Possible<Boolean> available_possible = Possible.absent();
/* 765 */     private Possible<Boolean> animated_possible = Possible.absent();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private String name;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(EmojiData instance) {
/* 779 */       Objects.requireNonNull(instance, "instance");
/* 780 */       id(instance.id());
/* 781 */       Optional<String> nameOptional = instance.name();
/* 782 */       if (nameOptional.isPresent()) {
/* 783 */         name(nameOptional);
/*     */       }
/* 785 */       roles(instance.roles());
/* 786 */       user(instance.user());
/* 787 */       requireColons(instance.requireColons());
/* 788 */       managed(instance.managed());
/* 789 */       available(instance.available());
/* 790 */       animated(instance.animated());
/* 791 */       return this;
/*     */     }
/*     */     
/*     */     public Builder id(String value) {
/* 795 */       this.id_optional = Optional.of(Id.of(value));
/* 796 */       return this;
/*     */     }
/*     */     
/*     */     public Builder id(long value) {
/* 800 */       this.id_optional = Optional.of(Id.of(value));
/* 801 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("id")
/*     */     public Builder id(Optional<Id> value) {
/* 806 */       this.id_optional = value;
/* 807 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder name(String name) {
/* 816 */       this.name = Objects.<String>requireNonNull(name, "name");
/* 817 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("name")
/*     */     public final Builder name(Optional<String> name) {
/* 827 */       this.name = name.orElse(null);
/* 828 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addRole(String element) {
/* 832 */       roles_getOrCreate().add(element);
/* 833 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addAllRoles(List<String> elements) {
/* 837 */       roles_getOrCreate().addAll(elements);
/* 838 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("roles")
/*     */     public Builder roles(Possible<List<String>> elements) {
/* 843 */       this.roles_list = null;
/* 844 */       elements.toOptional().ifPresent(e -> roles_getOrCreate().addAll(e));
/* 845 */       return this;
/*     */     }
/*     */     
/*     */     public Builder roles(List<String> elements) {
/* 849 */       this.roles_list = new ArrayList<>(elements);
/* 850 */       return this;
/*     */     }
/*     */     
/*     */     public Builder roles(Iterable<String> elements) {
/* 854 */       this.roles_list = (List<String>)StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
/* 855 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("user")
/*     */     public Builder user(Possible<UserData> value) {
/* 860 */       this.user_possible = value;
/* 861 */       return this;
/*     */     }
/*     */     
/*     */     public Builder user(UserData value) {
/* 865 */       this.user_possible = Possible.of(value);
/* 866 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("require_colons")
/*     */     public Builder requireColons(Possible<Boolean> value) {
/* 871 */       this.requireColons_possible = value;
/* 872 */       return this;
/*     */     }
/*     */     
/*     */     public Builder requireColons(Boolean value) {
/* 876 */       this.requireColons_possible = Possible.of(value);
/* 877 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("managed")
/*     */     public Builder managed(Possible<Boolean> value) {
/* 882 */       this.managed_possible = value;
/* 883 */       return this;
/*     */     }
/*     */     
/*     */     public Builder managed(Boolean value) {
/* 887 */       this.managed_possible = Possible.of(value);
/* 888 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("available")
/*     */     public Builder available(Possible<Boolean> value) {
/* 893 */       this.available_possible = value;
/* 894 */       return this;
/*     */     }
/*     */     
/*     */     public Builder available(Boolean value) {
/* 898 */       this.available_possible = Possible.of(value);
/* 899 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("animated")
/*     */     public Builder animated(Possible<Boolean> value) {
/* 904 */       this.animated_possible = value;
/* 905 */       return this;
/*     */     }
/*     */     
/*     */     public Builder animated(Boolean value) {
/* 909 */       this.animated_possible = Possible.of(value);
/* 910 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableEmojiData build() {
/* 919 */       return new ImmutableEmojiData(null, 
/*     */           
/* 921 */           id_build(), this.name, 
/*     */           
/* 923 */           roles_build(), 
/* 924 */           user_build(), 
/* 925 */           requireColons_build(), 
/* 926 */           managed_build(), 
/* 927 */           available_build(), 
/* 928 */           animated_build());
/*     */     }
/*     */     
/*     */     private Optional<Id> id_build() {
/* 932 */       return this.id_optional;
/*     */     }
/*     */     
/*     */     private Possible<List<String>> roles_build() {
/* 936 */       return (this.roles_list == null) ? Possible.absent() : 
/* 937 */         Possible.of(this.roles_list);
/*     */     }
/*     */     
/*     */     private List<String> roles_getOrCreate() {
/* 941 */       if (this.roles_list == null) {
/* 942 */         this.roles_list = new ArrayList<>();
/*     */       }
/* 944 */       return this.roles_list;
/*     */     }
/*     */     
/*     */     private Possible<UserData> user_build() {
/* 948 */       return this.user_possible;
/*     */     }
/*     */     
/*     */     private Possible<Boolean> requireColons_build() {
/* 952 */       return this.requireColons_possible;
/*     */     }
/*     */     
/*     */     private Possible<Boolean> managed_build() {
/* 956 */       return this.managed_possible;
/*     */     }
/*     */     
/*     */     private Possible<Boolean> available_build() {
/* 960 */       return this.available_possible;
/*     */     }
/*     */     
/*     */     private Possible<Boolean> animated_build() {
/* 964 */       return this.animated_possible;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableEmojiData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */