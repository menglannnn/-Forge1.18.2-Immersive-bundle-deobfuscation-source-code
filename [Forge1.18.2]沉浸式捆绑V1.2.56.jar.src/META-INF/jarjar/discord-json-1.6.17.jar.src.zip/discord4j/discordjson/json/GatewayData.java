/*    */ package discord4j.discordjson.json;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonProperty;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ @JsonSerialize(as = ImmutableGatewayData.class)
/*    */ @JsonDeserialize(as = ImmutableGatewayData.class)
/*    */ @Immutable
/*    */ public interface GatewayData
/*    */ {
/*    */   static ImmutableGatewayData.Builder builder() {
/* 15 */     return ImmutableGatewayData.builder();
/*    */   }
/*    */   
/*    */   String url();
/*    */   
/*    */   Possible<Integer> shards();
/*    */   
/*    */   @JsonProperty("session_start_limit")
/*    */   Possible<SessionStartLimitData> sessionStartLimit();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\GatewayData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */