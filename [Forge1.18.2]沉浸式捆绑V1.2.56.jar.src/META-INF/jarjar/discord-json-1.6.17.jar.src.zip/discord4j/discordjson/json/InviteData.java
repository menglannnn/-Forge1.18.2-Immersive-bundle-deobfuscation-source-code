/*    */ package discord4j.discordjson.json;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonProperty;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import java.util.Optional;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ 
/*    */ @JsonSerialize(as = ImmutableInviteData.class)
/*    */ @JsonDeserialize(as = ImmutableInviteData.class)
/*    */ @Immutable
/*    */ public interface InviteData
/*    */ {
/*    */   static ImmutableInviteData.Builder builder() {
/* 17 */     return ImmutableInviteData.builder();
/*    */   }
/*    */   
/*    */   String code();
/*    */   
/*    */   Possible<PartialGuildData> guild();
/*    */   
/*    */   ChannelData channel();
/*    */   
/*    */   Possible<UserData> inviter();
/*    */   
/*    */   @JsonProperty("target_type")
/*    */   Possible<Integer> targetType();
/*    */   
/*    */   @JsonProperty("target_user")
/*    */   Possible<UserData> targetUser();
/*    */   
/*    */   @JsonProperty("approximate_presence_count")
/*    */   Possible<Integer> approximatePresenceCount();
/*    */   
/*    */   @JsonProperty("approximate_member_count")
/*    */   Possible<Integer> approximateMemberCount();
/*    */   
/*    */   @JsonProperty("expires_at")
/*    */   Possible<Optional<String>> expiresAt();
/*    */   
/*    */   @JsonProperty("guild_scheduled_event")
/*    */   Possible<GuildScheduledEventData> guildScheduledEvent();
/*    */   
/*    */   Possible<Integer> uses();
/*    */   
/*    */   @JsonProperty("max_uses")
/*    */   Possible<Integer> maxUses();
/*    */   
/*    */   @JsonProperty("max_age")
/*    */   Possible<Integer> maxAge();
/*    */   
/*    */   Possible<Boolean> temporary();
/*    */   
/*    */   @JsonProperty("created_at")
/*    */   Possible<String> createdAt();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\InviteData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */