/*      */ package discord4j.discordjson.json;
/*      */ 
/*      */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*      */ import com.fasterxml.jackson.annotation.JsonCreator;
/*      */ import com.fasterxml.jackson.annotation.JsonProperty;
/*      */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*      */ import discord4j.discordjson.Id;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.List;
/*      */ import java.util.Objects;
/*      */ import java.util.Optional;
/*      */ import org.immutables.value.Generated;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ @Generated(from = "GuildPreviewData", generator = "Immutables")
/*      */ public final class ImmutableGuildPreviewData
/*      */   implements GuildPreviewData
/*      */ {
/*      */   private final long id_value;
/*      */   private final String name;
/*      */   private final String icon;
/*      */   private final String splash;
/*      */   private final String discoverySplash;
/*      */   private final List<EmojiData> emojis;
/*      */   private final List<String> features;
/*      */   private final int approximateMemberCount;
/*      */   private final int approximatePresenceCount;
/*      */   private final String description;
/*      */   private static final byte STAGE_INITIALIZING = -1;
/*      */   private static final byte STAGE_UNINITIALIZED = 0;
/*      */   private static final byte STAGE_INITIALIZED = 1;
/*      */   
/*      */   private ImmutableGuildPreviewData(Id id, String name, Optional<String> icon, Optional<String> splash, Optional<String> discoverySplash, Iterable<? extends EmojiData> emojis, Iterable<String> features, int approximateMemberCount, int approximatePresenceCount, Optional<String> description) {
/*   51 */     Id id$impl = id;
/*   52 */     this.name = Objects.<String>requireNonNull(name, "name");
/*   53 */     this.icon = icon.orElse(null);
/*   54 */     this.splash = splash.orElse(null);
/*   55 */     this.discoverySplash = discoverySplash.orElse(null);
/*   56 */     this.emojis = createUnmodifiableList(false, createSafeList(emojis, true, false));
/*   57 */     this.features = createUnmodifiableList(false, createSafeList(features, true, false));
/*   58 */     this.approximateMemberCount = approximateMemberCount;
/*   59 */     this.approximatePresenceCount = approximatePresenceCount;
/*   60 */     this.description = description.orElse(null);
/*   61 */     this.id_value = id$impl.asLong();
/*   62 */     this.initShim = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ImmutableGuildPreviewData(ImmutableGuildPreviewData original, Id id, String name, String icon, String splash, String discoverySplash, List<EmojiData> emojis, List<String> features, int approximateMemberCount, int approximatePresenceCount, String description) {
/*   77 */     Id id$impl = id;
/*   78 */     this.name = name;
/*   79 */     this.icon = icon;
/*   80 */     this.splash = splash;
/*   81 */     this.discoverySplash = discoverySplash;
/*   82 */     this.emojis = emojis;
/*   83 */     this.features = features;
/*   84 */     this.approximateMemberCount = approximateMemberCount;
/*   85 */     this.approximatePresenceCount = approximatePresenceCount;
/*   86 */     this.description = description;
/*   87 */     this.id_value = id$impl.asLong();
/*   88 */     this.initShim = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   94 */   private volatile transient InitShim initShim = new InitShim();
/*      */   
/*      */   @Generated(from = "GuildPreviewData", generator = "Immutables")
/*      */   private final class InitShim {
/*      */     private String formatInitCycleMessage() {
/*   99 */       List<String> attributes = new ArrayList<>();
/*  100 */       return "Cannot build GuildPreviewData, attribute initializers form cycle " + attributes;
/*      */     }
/*      */ 
/*      */     
/*      */     private InitShim() {}
/*      */   }
/*      */ 
/*      */   
/*      */   @JsonProperty("id")
/*      */   public Id id() {
/*  110 */     return Id.of(this.id_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("name")
/*      */   public String name() {
/*  119 */     return this.name;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("icon")
/*      */   public Optional<String> icon() {
/*  128 */     return Optional.ofNullable(this.icon);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("splash")
/*      */   public Optional<String> splash() {
/*  137 */     return Optional.ofNullable(this.splash);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("discovery_splash")
/*      */   public Optional<String> discoverySplash() {
/*  146 */     return Optional.ofNullable(this.discoverySplash);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("emojis")
/*      */   public List<EmojiData> emojis() {
/*  155 */     return this.emojis;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("features")
/*      */   public List<String> features() {
/*  164 */     return this.features;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("approximate_member_count")
/*      */   public int approximateMemberCount() {
/*  173 */     return this.approximateMemberCount;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("approximate_presence_count")
/*      */   public int approximatePresenceCount() {
/*  182 */     return this.approximatePresenceCount;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("description")
/*      */   public Optional<String> description() {
/*  191 */     return Optional.ofNullable(this.description);
/*      */   }
/*      */   
/*      */   public ImmutableGuildPreviewData withId(long value) {
/*  195 */     Id newValue = Id.of(value);
/*  196 */     return new ImmutableGuildPreviewData(this, newValue, this.name, this.icon, this.splash, this.discoverySplash, this.emojis, this.features, this.approximateMemberCount, this.approximatePresenceCount, this.description);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutableGuildPreviewData withId(String value) {
/*  211 */     Id newValue = Id.of(value);
/*  212 */     return new ImmutableGuildPreviewData(this, newValue, this.name, this.icon, this.splash, this.discoverySplash, this.emojis, this.features, this.approximateMemberCount, this.approximatePresenceCount, this.description);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildPreviewData withName(String value) {
/*  233 */     String newValue = Objects.<String>requireNonNull(value, "name");
/*  234 */     if (this.name.equals(newValue)) return this; 
/*  235 */     return new ImmutableGuildPreviewData(this, 
/*      */         
/*  237 */         id(), newValue, this.icon, this.splash, this.discoverySplash, this.emojis, this.features, this.approximateMemberCount, this.approximatePresenceCount, this.description);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildPreviewData withIcon(String value) {
/*  255 */     String newValue = Objects.<String>requireNonNull(value, "icon");
/*  256 */     if (Objects.equals(this.icon, newValue)) return this; 
/*  257 */     return new ImmutableGuildPreviewData(this, 
/*      */         
/*  259 */         id(), this.name, newValue, this.splash, this.discoverySplash, this.emojis, this.features, this.approximateMemberCount, this.approximatePresenceCount, this.description);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildPreviewData withIcon(Optional<String> optional) {
/*  278 */     String value = optional.orElse(null);
/*  279 */     if (Objects.equals(this.icon, value)) return this; 
/*  280 */     return new ImmutableGuildPreviewData(this, 
/*      */         
/*  282 */         id(), this.name, value, this.splash, this.discoverySplash, this.emojis, this.features, this.approximateMemberCount, this.approximatePresenceCount, this.description);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildPreviewData withSplash(String value) {
/*  300 */     String newValue = Objects.<String>requireNonNull(value, "splash");
/*  301 */     if (Objects.equals(this.splash, newValue)) return this; 
/*  302 */     return new ImmutableGuildPreviewData(this, 
/*      */         
/*  304 */         id(), this.name, this.icon, newValue, this.discoverySplash, this.emojis, this.features, this.approximateMemberCount, this.approximatePresenceCount, this.description);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildPreviewData withSplash(Optional<String> optional) {
/*  323 */     String value = optional.orElse(null);
/*  324 */     if (Objects.equals(this.splash, value)) return this; 
/*  325 */     return new ImmutableGuildPreviewData(this, 
/*      */         
/*  327 */         id(), this.name, this.icon, value, this.discoverySplash, this.emojis, this.features, this.approximateMemberCount, this.approximatePresenceCount, this.description);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildPreviewData withDiscoverySplash(String value) {
/*  345 */     String newValue = Objects.<String>requireNonNull(value, "discoverySplash");
/*  346 */     if (Objects.equals(this.discoverySplash, newValue)) return this; 
/*  347 */     return new ImmutableGuildPreviewData(this, 
/*      */         
/*  349 */         id(), this.name, this.icon, this.splash, newValue, this.emojis, this.features, this.approximateMemberCount, this.approximatePresenceCount, this.description);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildPreviewData withDiscoverySplash(Optional<String> optional) {
/*  368 */     String value = optional.orElse(null);
/*  369 */     if (Objects.equals(this.discoverySplash, value)) return this; 
/*  370 */     return new ImmutableGuildPreviewData(this, 
/*      */         
/*  372 */         id(), this.name, this.icon, this.splash, value, this.emojis, this.features, this.approximateMemberCount, this.approximatePresenceCount, this.description);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildPreviewData withEmojis(EmojiData... elements) {
/*  390 */     List<EmojiData> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/*  391 */     return new ImmutableGuildPreviewData(this, 
/*      */         
/*  393 */         id(), this.name, this.icon, this.splash, this.discoverySplash, newValue, this.features, this.approximateMemberCount, this.approximatePresenceCount, this.description);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildPreviewData withEmojis(Iterable<? extends EmojiData> elements) {
/*  412 */     if (this.emojis == elements) return this; 
/*  413 */     List<EmojiData> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/*  414 */     return new ImmutableGuildPreviewData(this, 
/*      */         
/*  416 */         id(), this.name, this.icon, this.splash, this.discoverySplash, newValue, this.features, this.approximateMemberCount, this.approximatePresenceCount, this.description);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildPreviewData withFeatures(String... elements) {
/*  434 */     List<String> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/*  435 */     return new ImmutableGuildPreviewData(this, 
/*      */         
/*  437 */         id(), this.name, this.icon, this.splash, this.discoverySplash, this.emojis, newValue, this.approximateMemberCount, this.approximatePresenceCount, this.description);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildPreviewData withFeatures(Iterable<String> elements) {
/*  456 */     if (this.features == elements) return this; 
/*  457 */     List<String> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/*  458 */     return new ImmutableGuildPreviewData(this, 
/*      */         
/*  460 */         id(), this.name, this.icon, this.splash, this.discoverySplash, this.emojis, newValue, this.approximateMemberCount, this.approximatePresenceCount, this.description);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildPreviewData withApproximateMemberCount(int value) {
/*  479 */     if (this.approximateMemberCount == value) return this; 
/*  480 */     return new ImmutableGuildPreviewData(this, 
/*      */         
/*  482 */         id(), this.name, this.icon, this.splash, this.discoverySplash, this.emojis, this.features, value, this.approximatePresenceCount, this.description);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildPreviewData withApproximatePresenceCount(int value) {
/*  501 */     if (this.approximatePresenceCount == value) return this; 
/*  502 */     return new ImmutableGuildPreviewData(this, 
/*      */         
/*  504 */         id(), this.name, this.icon, this.splash, this.discoverySplash, this.emojis, this.features, this.approximateMemberCount, value, this.description);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildPreviewData withDescription(String value) {
/*  522 */     String newValue = Objects.<String>requireNonNull(value, "description");
/*  523 */     if (Objects.equals(this.description, newValue)) return this; 
/*  524 */     return new ImmutableGuildPreviewData(this, 
/*      */         
/*  526 */         id(), this.name, this.icon, this.splash, this.discoverySplash, this.emojis, this.features, this.approximateMemberCount, this.approximatePresenceCount, newValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableGuildPreviewData withDescription(Optional<String> optional) {
/*  545 */     String value = optional.orElse(null);
/*  546 */     if (Objects.equals(this.description, value)) return this; 
/*  547 */     return new ImmutableGuildPreviewData(this, 
/*      */         
/*  549 */         id(), this.name, this.icon, this.splash, this.discoverySplash, this.emojis, this.features, this.approximateMemberCount, this.approximatePresenceCount, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean equals(Object another) {
/*  567 */     if (this == another) return true; 
/*  568 */     return (another instanceof ImmutableGuildPreviewData && 
/*  569 */       equalTo(0, (ImmutableGuildPreviewData)another));
/*      */   }
/*      */   
/*      */   private boolean equalTo(int synthetic, ImmutableGuildPreviewData another) {
/*  573 */     return (Objects.equals(Long.valueOf(this.id_value), Long.valueOf(another.id_value)) && this.name
/*  574 */       .equals(another.name) && 
/*  575 */       Objects.equals(this.icon, another.icon) && 
/*  576 */       Objects.equals(this.splash, another.splash) && 
/*  577 */       Objects.equals(this.discoverySplash, another.discoverySplash) && this.emojis
/*  578 */       .equals(another.emojis) && this.features
/*  579 */       .equals(another.features) && this.approximateMemberCount == another.approximateMemberCount && this.approximatePresenceCount == another.approximatePresenceCount && 
/*      */ 
/*      */       
/*  582 */       Objects.equals(this.description, another.description));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int hashCode() {
/*  591 */     int h = 5381;
/*  592 */     h += (h << 5) + Objects.hashCode(Long.valueOf(this.id_value));
/*  593 */     h += (h << 5) + this.name.hashCode();
/*  594 */     h += (h << 5) + Objects.hashCode(this.icon);
/*  595 */     h += (h << 5) + Objects.hashCode(this.splash);
/*  596 */     h += (h << 5) + Objects.hashCode(this.discoverySplash);
/*  597 */     h += (h << 5) + this.emojis.hashCode();
/*  598 */     h += (h << 5) + this.features.hashCode();
/*  599 */     h += (h << 5) + this.approximateMemberCount;
/*  600 */     h += (h << 5) + this.approximatePresenceCount;
/*  601 */     h += (h << 5) + Objects.hashCode(this.description);
/*  602 */     return h;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/*  611 */     StringBuilder builder = new StringBuilder("GuildPreviewData{");
/*  612 */     builder.append("id=").append(Objects.toString(Long.valueOf(this.id_value)));
/*  613 */     builder.append(", ");
/*  614 */     builder.append("name=").append(this.name);
/*  615 */     if (this.icon != null) {
/*  616 */       builder.append(", ");
/*  617 */       builder.append("icon=").append(this.icon);
/*      */     } 
/*  619 */     if (this.splash != null) {
/*  620 */       builder.append(", ");
/*  621 */       builder.append("splash=").append(this.splash);
/*      */     } 
/*  623 */     if (this.discoverySplash != null) {
/*  624 */       builder.append(", ");
/*  625 */       builder.append("discoverySplash=").append(this.discoverySplash);
/*      */     } 
/*  627 */     builder.append(", ");
/*  628 */     builder.append("emojis=").append(this.emojis);
/*  629 */     builder.append(", ");
/*  630 */     builder.append("features=").append(this.features);
/*  631 */     builder.append(", ");
/*  632 */     builder.append("approximateMemberCount=").append(this.approximateMemberCount);
/*  633 */     builder.append(", ");
/*  634 */     builder.append("approximatePresenceCount=").append(this.approximatePresenceCount);
/*  635 */     if (this.description != null) {
/*  636 */       builder.append(", ");
/*  637 */       builder.append("description=").append(this.description);
/*      */     } 
/*  639 */     return builder.append("}").toString();
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonDeserialize
/*      */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*      */   @Generated(from = "GuildPreviewData", generator = "Immutables")
/*      */   static final class Json
/*      */     implements GuildPreviewData
/*      */   {
/*      */     Id id;
/*      */     
/*      */     String name;
/*  653 */     Optional<String> icon = Optional.empty();
/*  654 */     Optional<String> splash = Optional.empty();
/*  655 */     Optional<String> discoverySplash = Optional.empty();
/*  656 */     List<EmojiData> emojis = Collections.emptyList();
/*  657 */     List<String> features = Collections.emptyList();
/*      */     int approximateMemberCount;
/*      */     boolean approximateMemberCountIsSet;
/*      */     int approximatePresenceCount;
/*      */     boolean approximatePresenceCountIsSet;
/*  662 */     Optional<String> description = Optional.empty();
/*      */     @JsonProperty("id")
/*      */     public void setId(Id id) {
/*  665 */       this.id = id;
/*      */     }
/*      */     @JsonProperty("name")
/*      */     public void setName(String name) {
/*  669 */       this.name = name;
/*      */     }
/*      */     @JsonProperty("icon")
/*      */     public void setIcon(Optional<String> icon) {
/*  673 */       this.icon = icon;
/*      */     }
/*      */     @JsonProperty("splash")
/*      */     public void setSplash(Optional<String> splash) {
/*  677 */       this.splash = splash;
/*      */     }
/*      */     @JsonProperty("discovery_splash")
/*      */     public void setDiscoverySplash(Optional<String> discoverySplash) {
/*  681 */       this.discoverySplash = discoverySplash;
/*      */     }
/*      */     @JsonProperty("emojis")
/*      */     public void setEmojis(List<EmojiData> emojis) {
/*  685 */       this.emojis = emojis;
/*      */     }
/*      */     @JsonProperty("features")
/*      */     public void setFeatures(List<String> features) {
/*  689 */       this.features = features;
/*      */     }
/*      */     @JsonProperty("approximate_member_count")
/*      */     public void setApproximateMemberCount(int approximateMemberCount) {
/*  693 */       this.approximateMemberCount = approximateMemberCount;
/*  694 */       this.approximateMemberCountIsSet = true;
/*      */     }
/*      */     @JsonProperty("approximate_presence_count")
/*      */     public void setApproximatePresenceCount(int approximatePresenceCount) {
/*  698 */       this.approximatePresenceCount = approximatePresenceCount;
/*  699 */       this.approximatePresenceCountIsSet = true;
/*      */     }
/*      */     @JsonProperty("description")
/*      */     public void setDescription(Optional<String> description) {
/*  703 */       this.description = description;
/*      */     }
/*      */     public Id id() {
/*  706 */       throw new UnsupportedOperationException();
/*      */     } public String name() {
/*  708 */       throw new UnsupportedOperationException();
/*      */     } public Optional<String> icon() {
/*  710 */       throw new UnsupportedOperationException();
/*      */     } public Optional<String> splash() {
/*  712 */       throw new UnsupportedOperationException();
/*      */     } public Optional<String> discoverySplash() {
/*  714 */       throw new UnsupportedOperationException();
/*      */     } public List<EmojiData> emojis() {
/*  716 */       throw new UnsupportedOperationException();
/*      */     } public List<String> features() {
/*  718 */       throw new UnsupportedOperationException();
/*      */     } public int approximateMemberCount() {
/*  720 */       throw new UnsupportedOperationException();
/*      */     } public int approximatePresenceCount() {
/*  722 */       throw new UnsupportedOperationException();
/*      */     } public Optional<String> description() {
/*  724 */       throw new UnsupportedOperationException();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*      */   static ImmutableGuildPreviewData fromJson(Json json) {
/*  735 */     Builder builder = builder();
/*  736 */     if (json.id != null) {
/*  737 */       builder.id(json.id);
/*      */     }
/*  739 */     if (json.name != null) {
/*  740 */       builder.name(json.name);
/*      */     }
/*  742 */     if (json.icon != null) {
/*  743 */       builder.icon(json.icon);
/*      */     }
/*  745 */     if (json.splash != null) {
/*  746 */       builder.splash(json.splash);
/*      */     }
/*  748 */     if (json.discoverySplash != null) {
/*  749 */       builder.discoverySplash(json.discoverySplash);
/*      */     }
/*  751 */     if (json.emojis != null) {
/*  752 */       builder.addAllEmojis(json.emojis);
/*      */     }
/*  754 */     if (json.features != null) {
/*  755 */       builder.addAllFeatures(json.features);
/*      */     }
/*  757 */     if (json.approximateMemberCountIsSet) {
/*  758 */       builder.approximateMemberCount(json.approximateMemberCount);
/*      */     }
/*  760 */     if (json.approximatePresenceCountIsSet) {
/*  761 */       builder.approximatePresenceCount(json.approximatePresenceCount);
/*      */     }
/*  763 */     if (json.description != null) {
/*  764 */       builder.description(json.description);
/*      */     }
/*  766 */     return builder.build();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableGuildPreviewData of(Id id, String name, Optional<String> icon, Optional<String> splash, Optional<String> discoverySplash, List<EmojiData> emojis, List<String> features, int approximateMemberCount, int approximatePresenceCount, Optional<String> description) {
/*  784 */     return of(id, name, icon, splash, discoverySplash, emojis, features, approximateMemberCount, approximatePresenceCount, description);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableGuildPreviewData of(Id id, String name, Optional<String> icon, Optional<String> splash, Optional<String> discoverySplash, Iterable<? extends EmojiData> emojis, Iterable<String> features, int approximateMemberCount, int approximatePresenceCount, Optional<String> description) {
/*  802 */     return new ImmutableGuildPreviewData(id, name, icon, splash, discoverySplash, emojis, features, approximateMemberCount, approximatePresenceCount, description);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableGuildPreviewData copyOf(GuildPreviewData instance) {
/*  813 */     if (instance instanceof ImmutableGuildPreviewData) {
/*  814 */       return (ImmutableGuildPreviewData)instance;
/*      */     }
/*  816 */     return builder()
/*  817 */       .from(instance)
/*  818 */       .build();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Builder builder() {
/*  840 */     return new Builder();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   @Generated(from = "GuildPreviewData", generator = "Immutables")
/*      */   public static final class Builder
/*      */   {
/*      */     private static final long INIT_BIT_NAME = 1L;
/*      */ 
/*      */     
/*      */     private static final long INIT_BIT_APPROXIMATE_MEMBER_COUNT = 2L;
/*      */     
/*      */     private static final long INIT_BIT_APPROXIMATE_PRESENCE_COUNT = 4L;
/*      */     
/*  855 */     private long initBits = 7L;
/*      */     
/*  857 */     private Id id_id = null;
/*      */     private String name;
/*      */     private String icon;
/*      */     private String splash;
/*      */     private String discoverySplash;
/*  862 */     private List<EmojiData> emojis = new ArrayList<>();
/*  863 */     private List<String> features = new ArrayList<>();
/*      */ 
/*      */ 
/*      */     
/*      */     private int approximateMemberCount;
/*      */ 
/*      */ 
/*      */     
/*      */     private int approximatePresenceCount;
/*      */ 
/*      */ 
/*      */     
/*      */     private String description;
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder from(GuildPreviewData instance) {
/*  880 */       Objects.requireNonNull(instance, "instance");
/*  881 */       id(instance.id());
/*  882 */       name(instance.name());
/*  883 */       Optional<String> iconOptional = instance.icon();
/*  884 */       if (iconOptional.isPresent()) {
/*  885 */         icon(iconOptional);
/*      */       }
/*  887 */       Optional<String> splashOptional = instance.splash();
/*  888 */       if (splashOptional.isPresent()) {
/*  889 */         splash(splashOptional);
/*      */       }
/*  891 */       Optional<String> discoverySplashOptional = instance.discoverySplash();
/*  892 */       if (discoverySplashOptional.isPresent()) {
/*  893 */         discoverySplash(discoverySplashOptional);
/*      */       }
/*  895 */       addAllEmojis(instance.emojis());
/*  896 */       addAllFeatures(instance.features());
/*  897 */       approximateMemberCount(instance.approximateMemberCount());
/*  898 */       approximatePresenceCount(instance.approximatePresenceCount());
/*  899 */       Optional<String> descriptionOptional = instance.description();
/*  900 */       if (descriptionOptional.isPresent()) {
/*  901 */         description(descriptionOptional);
/*      */       }
/*  903 */       return this;
/*      */     }
/*      */     
/*      */     public Builder id(String value) {
/*  907 */       this.id_id = Id.of(value);
/*  908 */       return this;
/*      */     }
/*      */     
/*      */     public Builder id(long value) {
/*  912 */       this.id_id = Id.of(value);
/*  913 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("id")
/*      */     public Builder id(Id value) {
/*  918 */       this.id_id = value;
/*  919 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("name")
/*      */     public final Builder name(String name) {
/*  929 */       this.name = Objects.<String>requireNonNull(name, "name");
/*  930 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/*  931 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder icon(String icon) {
/*  940 */       this.icon = Objects.<String>requireNonNull(icon, "icon");
/*  941 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("icon")
/*      */     public final Builder icon(Optional<String> icon) {
/*  951 */       this.icon = icon.orElse(null);
/*  952 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder splash(String splash) {
/*  961 */       this.splash = Objects.<String>requireNonNull(splash, "splash");
/*  962 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("splash")
/*      */     public final Builder splash(Optional<String> splash) {
/*  972 */       this.splash = splash.orElse(null);
/*  973 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder discoverySplash(String discoverySplash) {
/*  982 */       this.discoverySplash = Objects.<String>requireNonNull(discoverySplash, "discoverySplash");
/*  983 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("discovery_splash")
/*      */     public final Builder discoverySplash(Optional<String> discoverySplash) {
/*  993 */       this.discoverySplash = discoverySplash.orElse(null);
/*  994 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addEmoji(EmojiData element) {
/* 1003 */       this.emojis.add(Objects.<EmojiData>requireNonNull(element, "emojis element"));
/* 1004 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addEmojis(EmojiData... elements) {
/* 1013 */       for (EmojiData element : elements) {
/* 1014 */         this.emojis.add(Objects.<EmojiData>requireNonNull(element, "emojis element"));
/*      */       }
/* 1016 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("emojis")
/*      */     public final Builder emojis(Iterable<? extends EmojiData> elements) {
/* 1027 */       this.emojis.clear();
/* 1028 */       return addAllEmojis(elements);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addAllEmojis(Iterable<? extends EmojiData> elements) {
/* 1037 */       for (EmojiData element : elements) {
/* 1038 */         this.emojis.add(Objects.<EmojiData>requireNonNull(element, "emojis element"));
/*      */       }
/* 1040 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addFeature(String element) {
/* 1049 */       this.features.add(Objects.<String>requireNonNull(element, "features element"));
/* 1050 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addFeatures(String... elements) {
/* 1059 */       for (String element : elements) {
/* 1060 */         this.features.add(Objects.<String>requireNonNull(element, "features element"));
/*      */       }
/* 1062 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("features")
/*      */     public final Builder features(Iterable<String> elements) {
/* 1073 */       this.features.clear();
/* 1074 */       return addAllFeatures(elements);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder addAllFeatures(Iterable<String> elements) {
/* 1083 */       for (String element : elements) {
/* 1084 */         this.features.add(Objects.<String>requireNonNull(element, "features element"));
/*      */       }
/* 1086 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("approximate_member_count")
/*      */     public final Builder approximateMemberCount(int approximateMemberCount) {
/* 1096 */       this.approximateMemberCount = approximateMemberCount;
/* 1097 */       this.initBits &= 0xFFFFFFFFFFFFFFFDL;
/* 1098 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("approximate_presence_count")
/*      */     public final Builder approximatePresenceCount(int approximatePresenceCount) {
/* 1108 */       this.approximatePresenceCount = approximatePresenceCount;
/* 1109 */       this.initBits &= 0xFFFFFFFFFFFFFFFBL;
/* 1110 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder description(String description) {
/* 1119 */       this.description = Objects.<String>requireNonNull(description, "description");
/* 1120 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("description")
/*      */     public final Builder description(Optional<String> description) {
/* 1130 */       this.description = description.orElse(null);
/* 1131 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ImmutableGuildPreviewData build() {
/* 1140 */       if (this.initBits != 0L) {
/* 1141 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*      */       }
/* 1143 */       return new ImmutableGuildPreviewData(null, 
/*      */           
/* 1145 */           id_build(), this.name, this.icon, this.splash, this.discoverySplash, ImmutableGuildPreviewData
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1150 */           .createUnmodifiableList(true, (List)this.emojis), ImmutableGuildPreviewData
/* 1151 */           .createUnmodifiableList(true, (List)this.features), this.approximateMemberCount, this.approximatePresenceCount, this.description);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private String formatRequiredAttributesMessage() {
/* 1158 */       List<String> attributes = new ArrayList<>();
/* 1159 */       if ((this.initBits & 0x1L) != 0L) attributes.add("name"); 
/* 1160 */       if ((this.initBits & 0x2L) != 0L) attributes.add("approximateMemberCount"); 
/* 1161 */       if ((this.initBits & 0x4L) != 0L) attributes.add("approximatePresenceCount"); 
/* 1162 */       return "Cannot build GuildPreviewData, some of required attributes are not set " + attributes;
/*      */     }
/*      */     
/*      */     private Id id_build() {
/* 1166 */       return this.id_id;
/*      */     }
/*      */     private Builder() {} }
/*      */   
/*      */   private static <T> List<T> createSafeList(Iterable<? extends T> iterable, boolean checkNulls, boolean skipNulls) {
/*      */     ArrayList<T> list;
/* 1172 */     if (iterable instanceof Collection) {
/* 1173 */       int size = ((Collection)iterable).size();
/* 1174 */       if (size == 0) return Collections.emptyList(); 
/* 1175 */       list = new ArrayList<>();
/*      */     } else {
/* 1177 */       list = new ArrayList<>();
/*      */     } 
/* 1179 */     for (T element : iterable) {
/* 1180 */       if (skipNulls && element == null)
/* 1181 */         continue;  if (checkNulls) Objects.requireNonNull(element, "element"); 
/* 1182 */       list.add(element);
/*      */     } 
/* 1184 */     return list;
/*      */   }
/*      */   
/*      */   private static <T> List<T> createUnmodifiableList(boolean clone, List<T> list) {
/* 1188 */     switch (list.size()) { case 0:
/* 1189 */         return Collections.emptyList();
/* 1190 */       case 1: return Collections.singletonList(list.get(0)); }
/*      */     
/* 1192 */     if (clone) {
/* 1193 */       return Collections.unmodifiableList(new ArrayList<>(list));
/*      */     }
/* 1195 */     if (list instanceof ArrayList) {
/* 1196 */       ((ArrayList)list).trimToSize();
/*      */     }
/* 1198 */     return Collections.unmodifiableList(list);
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableGuildPreviewData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */