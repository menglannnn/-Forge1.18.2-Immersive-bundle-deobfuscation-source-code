/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "ApplicationCommandPermissionsRequest", generator = "Immutables")
/*     */ public final class ImmutableApplicationCommandPermissionsRequest
/*     */   implements ApplicationCommandPermissionsRequest
/*     */ {
/*     */   private final List<ApplicationCommandPermissionsData> permissions;
/*     */   
/*     */   private ImmutableApplicationCommandPermissionsRequest(Iterable<? extends ApplicationCommandPermissionsData> permissions) {
/*  31 */     this.permissions = createUnmodifiableList(false, createSafeList(permissions, true, false));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private ImmutableApplicationCommandPermissionsRequest(ImmutableApplicationCommandPermissionsRequest original, List<ApplicationCommandPermissionsData> permissions) {
/*  37 */     this.permissions = permissions;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("permissions")
/*     */   public List<ApplicationCommandPermissionsData> permissions() {
/*  46 */     return this.permissions;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableApplicationCommandPermissionsRequest withPermissions(ApplicationCommandPermissionsData... elements) {
/*  55 */     List<ApplicationCommandPermissionsData> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/*  56 */     return new ImmutableApplicationCommandPermissionsRequest(this, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableApplicationCommandPermissionsRequest withPermissions(Iterable<? extends ApplicationCommandPermissionsData> elements) {
/*  66 */     if (this.permissions == elements) return this; 
/*  67 */     List<ApplicationCommandPermissionsData> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/*  68 */     return new ImmutableApplicationCommandPermissionsRequest(this, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/*  77 */     if (this == another) return true; 
/*  78 */     return (another instanceof ImmutableApplicationCommandPermissionsRequest && 
/*  79 */       equalTo(0, (ImmutableApplicationCommandPermissionsRequest)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableApplicationCommandPermissionsRequest another) {
/*  83 */     return this.permissions.equals(another.permissions);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  92 */     int h = 5381;
/*  93 */     h += (h << 5) + this.permissions.hashCode();
/*  94 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 103 */     return "ApplicationCommandPermissionsRequest{permissions=" + this.permissions + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "ApplicationCommandPermissionsRequest", generator = "Immutables")
/*     */   static final class Json
/*     */     implements ApplicationCommandPermissionsRequest
/*     */   {
/* 117 */     List<ApplicationCommandPermissionsData> permissions = Collections.emptyList();
/*     */     @JsonProperty("permissions")
/*     */     public void setPermissions(List<ApplicationCommandPermissionsData> permissions) {
/* 120 */       this.permissions = permissions;
/*     */     }
/*     */     public List<ApplicationCommandPermissionsData> permissions() {
/* 123 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableApplicationCommandPermissionsRequest fromJson(Json json) {
/* 134 */     Builder builder = builder();
/* 135 */     if (json.permissions != null) {
/* 136 */       builder.addAllPermissions(json.permissions);
/*     */     }
/* 138 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableApplicationCommandPermissionsRequest of(List<ApplicationCommandPermissionsData> permissions) {
/* 147 */     return of(permissions);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableApplicationCommandPermissionsRequest of(Iterable<? extends ApplicationCommandPermissionsData> permissions) {
/* 156 */     return new ImmutableApplicationCommandPermissionsRequest(permissions);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableApplicationCommandPermissionsRequest copyOf(ApplicationCommandPermissionsRequest instance) {
/* 167 */     if (instance instanceof ImmutableApplicationCommandPermissionsRequest) {
/* 168 */       return (ImmutableApplicationCommandPermissionsRequest)instance;
/*     */     }
/* 170 */     return builder()
/* 171 */       .from(instance)
/* 172 */       .build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 185 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "ApplicationCommandPermissionsRequest", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/* 197 */     private List<ApplicationCommandPermissionsData> permissions = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(ApplicationCommandPermissionsRequest instance) {
/* 211 */       Objects.requireNonNull(instance, "instance");
/* 212 */       addAllPermissions(instance.permissions());
/* 213 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder addPermission(ApplicationCommandPermissionsData element) {
/* 222 */       this.permissions.add(Objects.<ApplicationCommandPermissionsData>requireNonNull(element, "permissions element"));
/* 223 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder addPermissions(ApplicationCommandPermissionsData... elements) {
/* 232 */       for (ApplicationCommandPermissionsData element : elements) {
/* 233 */         this.permissions.add(Objects.<ApplicationCommandPermissionsData>requireNonNull(element, "permissions element"));
/*     */       }
/* 235 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("permissions")
/*     */     public final Builder permissions(Iterable<? extends ApplicationCommandPermissionsData> elements) {
/* 246 */       this.permissions.clear();
/* 247 */       return addAllPermissions(elements);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder addAllPermissions(Iterable<? extends ApplicationCommandPermissionsData> elements) {
/* 256 */       for (ApplicationCommandPermissionsData element : elements) {
/* 257 */         this.permissions.add(Objects.<ApplicationCommandPermissionsData>requireNonNull(element, "permissions element"));
/*     */       }
/* 259 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private Builder() {}
/*     */ 
/*     */     
/*     */     public ImmutableApplicationCommandPermissionsRequest build() {
/* 268 */       return new ImmutableApplicationCommandPermissionsRequest(null, ImmutableApplicationCommandPermissionsRequest.createUnmodifiableList(true, (List)this.permissions));
/*     */     }
/*     */   }
/*     */   
/*     */   private static <T> List<T> createSafeList(Iterable<? extends T> iterable, boolean checkNulls, boolean skipNulls) {
/*     */     ArrayList<T> list;
/* 274 */     if (iterable instanceof Collection) {
/* 275 */       int size = ((Collection)iterable).size();
/* 276 */       if (size == 0) return Collections.emptyList(); 
/* 277 */       list = new ArrayList<>();
/*     */     } else {
/* 279 */       list = new ArrayList<>();
/*     */     } 
/* 281 */     for (T element : iterable) {
/* 282 */       if (skipNulls && element == null)
/* 283 */         continue;  if (checkNulls) Objects.requireNonNull(element, "element"); 
/* 284 */       list.add(element);
/*     */     } 
/* 286 */     return list;
/*     */   }
/*     */   
/*     */   private static <T> List<T> createUnmodifiableList(boolean clone, List<T> list) {
/* 290 */     switch (list.size()) { case 0:
/* 291 */         return Collections.emptyList();
/* 292 */       case 1: return Collections.singletonList(list.get(0)); }
/*     */     
/* 294 */     if (clone) {
/* 295 */       return Collections.unmodifiableList(new ArrayList<>(list));
/*     */     }
/* 297 */     if (list instanceof ArrayList) {
/* 298 */       ((ArrayList)list).trimToSize();
/*     */     }
/* 300 */     return Collections.unmodifiableList(list);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableApplicationCommandPermissionsRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */