/*    */ package discord4j.discordjson.json;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonProperty;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import java.util.List;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ 
/*    */ @JsonSerialize(as = ImmutableAuditLogData.class)
/*    */ @JsonDeserialize(as = ImmutableAuditLogData.class)
/*    */ @Immutable
/*    */ public interface AuditLogData
/*    */ {
/*    */   static ImmutableAuditLogData.Builder builder() {
/* 16 */     return ImmutableAuditLogData.builder();
/*    */   }
/*    */   
/*    */   List<WebhookData> webhooks();
/*    */   
/*    */   List<UserData> users();
/*    */   
/*    */   @JsonProperty("audit_log_entries")
/*    */   List<AuditLogEntryData> auditLogEntries();
/*    */   
/*    */   List<IntegrationData> integrations();
/*    */   
/*    */   @JsonProperty("auto_moderation_rules")
/*    */   List<AutoModRuleData> autoModerationRules();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\AuditLogData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */