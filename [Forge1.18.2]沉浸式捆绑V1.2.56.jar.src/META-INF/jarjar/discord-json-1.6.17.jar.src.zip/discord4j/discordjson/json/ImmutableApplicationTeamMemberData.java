/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.Id;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "ApplicationTeamMemberData", generator = "Immutables")
/*     */ public final class ImmutableApplicationTeamMemberData
/*     */   implements ApplicationTeamMemberData
/*     */ {
/*     */   private final int membershipState;
/*     */   private final List<String> permissions;
/*     */   private final long teamId_value;
/*     */   private final UserData user;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   private volatile transient InitShim initShim;
/*     */   
/*     */   private ImmutableApplicationTeamMemberData(int membershipState, Iterable<String> permissions, Id teamId, UserData user) {
/*  64 */     this.initShim = new InitShim(); this.membershipState = membershipState; this.permissions = createUnmodifiableList(false, createSafeList(permissions, true, false)); Id teamId$impl = teamId; this.user = Objects.<UserData>requireNonNull(user, "user"); this.teamId_value = teamId$impl.asLong(); this.initShim = null; } private ImmutableApplicationTeamMemberData(ImmutableApplicationTeamMemberData original, int membershipState, List<String> permissions, Id teamId, UserData user) { this.initShim = new InitShim(); this.membershipState = membershipState;
/*     */     this.permissions = permissions;
/*     */     Id teamId$impl = teamId;
/*     */     this.user = user;
/*     */     this.teamId_value = teamId$impl.asLong();
/*  69 */     this.initShim = null; } @Generated(from = "ApplicationTeamMemberData", generator = "Immutables") private final class InitShim { private InitShim() {} private String formatInitCycleMessage() { List<String> attributes = new ArrayList<>();
/*  70 */       return "Cannot build ApplicationTeamMemberData, attribute initializers form cycle " + attributes; }
/*     */      }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("membership_state")
/*     */   public int membershipState() {
/*  80 */     return this.membershipState;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("permissions")
/*     */   public List<String> permissions() {
/*  89 */     return this.permissions;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("team_id")
/*     */   public Id teamId() {
/*  98 */     return Id.of(this.teamId_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("user")
/*     */   public UserData user() {
/* 107 */     return this.user;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableApplicationTeamMemberData withMembershipState(int value) {
/* 117 */     if (this.membershipState == value) return this; 
/* 118 */     return new ImmutableApplicationTeamMemberData(this, value, this.permissions, teamId(), this.user);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableApplicationTeamMemberData withPermissions(String... elements) {
/* 127 */     List<String> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/* 128 */     return new ImmutableApplicationTeamMemberData(this, this.membershipState, newValue, teamId(), this.user);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableApplicationTeamMemberData withPermissions(Iterable<String> elements) {
/* 138 */     if (this.permissions == elements) return this; 
/* 139 */     List<String> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/* 140 */     return new ImmutableApplicationTeamMemberData(this, this.membershipState, newValue, teamId(), this.user);
/*     */   }
/*     */   
/*     */   public ImmutableApplicationTeamMemberData withTeamId(long value) {
/* 144 */     Id newValue = Id.of(value);
/* 145 */     return new ImmutableApplicationTeamMemberData(this, this.membershipState, this.permissions, newValue, this.user);
/*     */   }
/*     */   
/*     */   public ImmutableApplicationTeamMemberData withTeamId(String value) {
/* 149 */     Id newValue = Id.of(value);
/* 150 */     return new ImmutableApplicationTeamMemberData(this, this.membershipState, this.permissions, newValue, this.user);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableApplicationTeamMemberData withUser(UserData value) {
/* 160 */     if (this.user == value) return this; 
/* 161 */     UserData newValue = Objects.<UserData>requireNonNull(value, "user");
/* 162 */     return new ImmutableApplicationTeamMemberData(this, this.membershipState, this.permissions, teamId(), newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 171 */     if (this == another) return true; 
/* 172 */     return (another instanceof ImmutableApplicationTeamMemberData && 
/* 173 */       equalTo(0, (ImmutableApplicationTeamMemberData)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableApplicationTeamMemberData another) {
/* 177 */     return (this.membershipState == another.membershipState && this.permissions
/* 178 */       .equals(another.permissions) && 
/* 179 */       Objects.equals(Long.valueOf(this.teamId_value), Long.valueOf(another.teamId_value)) && this.user
/* 180 */       .equals(another.user));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 189 */     int h = 5381;
/* 190 */     h += (h << 5) + this.membershipState;
/* 191 */     h += (h << 5) + this.permissions.hashCode();
/* 192 */     h += (h << 5) + Objects.hashCode(Long.valueOf(this.teamId_value));
/* 193 */     h += (h << 5) + this.user.hashCode();
/* 194 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 203 */     return "ApplicationTeamMemberData{membershipState=" + this.membershipState + ", permissions=" + this.permissions + ", teamId=" + 
/*     */ 
/*     */       
/* 206 */       Objects.toString(Long.valueOf(this.teamId_value)) + ", user=" + this.user + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "ApplicationTeamMemberData", generator = "Immutables")
/*     */   static final class Json
/*     */     implements ApplicationTeamMemberData
/*     */   {
/*     */     int membershipState;
/*     */     
/*     */     boolean membershipStateIsSet;
/*     */     
/* 222 */     List<String> permissions = Collections.emptyList(); Id teamId;
/*     */     UserData user;
/*     */     
/*     */     @JsonProperty("membership_state")
/*     */     public void setMembershipState(int membershipState) {
/* 227 */       this.membershipState = membershipState;
/* 228 */       this.membershipStateIsSet = true;
/*     */     }
/*     */     @JsonProperty("permissions")
/*     */     public void setPermissions(List<String> permissions) {
/* 232 */       this.permissions = permissions;
/*     */     }
/*     */     @JsonProperty("team_id")
/*     */     public void setTeamId(Id teamId) {
/* 236 */       this.teamId = teamId;
/*     */     }
/*     */     @JsonProperty("user")
/*     */     public void setUser(UserData user) {
/* 240 */       this.user = user;
/*     */     }
/*     */     public int membershipState() {
/* 243 */       throw new UnsupportedOperationException();
/*     */     } public List<String> permissions() {
/* 245 */       throw new UnsupportedOperationException();
/*     */     } public Id teamId() {
/* 247 */       throw new UnsupportedOperationException();
/*     */     } public UserData user() {
/* 249 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableApplicationTeamMemberData fromJson(Json json) {
/* 260 */     Builder builder = builder();
/* 261 */     if (json.membershipStateIsSet) {
/* 262 */       builder.membershipState(json.membershipState);
/*     */     }
/* 264 */     if (json.permissions != null) {
/* 265 */       builder.addAllPermissions(json.permissions);
/*     */     }
/* 267 */     if (json.teamId != null) {
/* 268 */       builder.teamId(json.teamId);
/*     */     }
/* 270 */     if (json.user != null) {
/* 271 */       builder.user(json.user);
/*     */     }
/* 273 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableApplicationTeamMemberData of(int membershipState, List<String> permissions, Id teamId, UserData user) {
/* 285 */     return of(membershipState, permissions, teamId, user);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableApplicationTeamMemberData of(int membershipState, Iterable<String> permissions, Id teamId, UserData user) {
/* 297 */     return new ImmutableApplicationTeamMemberData(membershipState, permissions, teamId, user);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableApplicationTeamMemberData copyOf(ApplicationTeamMemberData instance) {
/* 308 */     if (instance instanceof ImmutableApplicationTeamMemberData) {
/* 309 */       return (ImmutableApplicationTeamMemberData)instance;
/*     */     }
/* 311 */     return builder()
/* 312 */       .from(instance)
/* 313 */       .build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 329 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "ApplicationTeamMemberData", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_MEMBERSHIP_STATE = 1L;
/*     */ 
/*     */     
/*     */     private static final long INIT_BIT_USER = 2L;
/*     */ 
/*     */     
/* 343 */     private long initBits = 3L;
/*     */     
/* 345 */     private Id teamId_id = null;
/*     */     private int membershipState;
/* 347 */     private List<String> permissions = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private UserData user;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(ApplicationTeamMemberData instance) {
/* 362 */       Objects.requireNonNull(instance, "instance");
/* 363 */       membershipState(instance.membershipState());
/* 364 */       addAllPermissions(instance.permissions());
/* 365 */       teamId(instance.teamId());
/* 366 */       user(instance.user());
/* 367 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("membership_state")
/*     */     public final Builder membershipState(int membershipState) {
/* 377 */       this.membershipState = membershipState;
/* 378 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 379 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder addPermission(String element) {
/* 388 */       this.permissions.add(Objects.<String>requireNonNull(element, "permissions element"));
/* 389 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder addPermissions(String... elements) {
/* 398 */       for (String element : elements) {
/* 399 */         this.permissions.add(Objects.<String>requireNonNull(element, "permissions element"));
/*     */       }
/* 401 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("permissions")
/*     */     public final Builder permissions(Iterable<String> elements) {
/* 412 */       this.permissions.clear();
/* 413 */       return addAllPermissions(elements);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder addAllPermissions(Iterable<String> elements) {
/* 422 */       for (String element : elements) {
/* 423 */         this.permissions.add(Objects.<String>requireNonNull(element, "permissions element"));
/*     */       }
/* 425 */       return this;
/*     */     }
/*     */     
/*     */     public Builder teamId(String value) {
/* 429 */       this.teamId_id = Id.of(value);
/* 430 */       return this;
/*     */     }
/*     */     
/*     */     public Builder teamId(long value) {
/* 434 */       this.teamId_id = Id.of(value);
/* 435 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("team_id")
/*     */     public Builder teamId(Id value) {
/* 440 */       this.teamId_id = value;
/* 441 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("user")
/*     */     public final Builder user(UserData user) {
/* 451 */       this.user = Objects.<UserData>requireNonNull(user, "user");
/* 452 */       this.initBits &= 0xFFFFFFFFFFFFFFFDL;
/* 453 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableApplicationTeamMemberData build() {
/* 462 */       if (this.initBits != 0L) {
/* 463 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 465 */       return new ImmutableApplicationTeamMemberData(null, this.membershipState, ImmutableApplicationTeamMemberData.createUnmodifiableList(true, (List)this.permissions), teamId_build(), this.user);
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 469 */       List<String> attributes = new ArrayList<>();
/* 470 */       if ((this.initBits & 0x1L) != 0L) attributes.add("membershipState"); 
/* 471 */       if ((this.initBits & 0x2L) != 0L) attributes.add("user"); 
/* 472 */       return "Cannot build ApplicationTeamMemberData, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Id teamId_build() {
/* 476 */       return this.teamId_id;
/*     */     }
/*     */     private Builder() {} }
/*     */   
/*     */   private static <T> List<T> createSafeList(Iterable<? extends T> iterable, boolean checkNulls, boolean skipNulls) {
/*     */     ArrayList<T> list;
/* 482 */     if (iterable instanceof Collection) {
/* 483 */       int size = ((Collection)iterable).size();
/* 484 */       if (size == 0) return Collections.emptyList(); 
/* 485 */       list = new ArrayList<>();
/*     */     } else {
/* 487 */       list = new ArrayList<>();
/*     */     } 
/* 489 */     for (T element : iterable) {
/* 490 */       if (skipNulls && element == null)
/* 491 */         continue;  if (checkNulls) Objects.requireNonNull(element, "element"); 
/* 492 */       list.add(element);
/*     */     } 
/* 494 */     return list;
/*     */   }
/*     */   
/*     */   private static <T> List<T> createUnmodifiableList(boolean clone, List<T> list) {
/* 498 */     switch (list.size()) { case 0:
/* 499 */         return Collections.emptyList();
/* 500 */       case 1: return Collections.singletonList(list.get(0)); }
/*     */     
/* 502 */     if (clone) {
/* 503 */       return Collections.unmodifiableList(new ArrayList<>(list));
/*     */     }
/* 505 */     if (list instanceof ArrayList) {
/* 506 */       ((ArrayList)list).trimToSize();
/*     */     }
/* 508 */     return Collections.unmodifiableList(list);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableApplicationTeamMemberData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */