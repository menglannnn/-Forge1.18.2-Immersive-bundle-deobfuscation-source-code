/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.Id;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "ApplicationCommandPermissionsData", generator = "Immutables")
/*     */ public final class ImmutableApplicationCommandPermissionsData
/*     */   implements ApplicationCommandPermissionsData
/*     */ {
/*     */   private final long id_value;
/*     */   private final int type;
/*     */   private final boolean permission;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   
/*     */   private ImmutableApplicationCommandPermissionsData(Id id, int type, boolean permission) {
/*  31 */     Id id$impl = id;
/*  32 */     this.type = type;
/*  33 */     this.permission = permission;
/*  34 */     this.id_value = id$impl.asLong();
/*  35 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ImmutableApplicationCommandPermissionsData(ImmutableApplicationCommandPermissionsData original, Id id, int type, boolean permission) {
/*  43 */     Id id$impl = id;
/*  44 */     this.type = type;
/*  45 */     this.permission = permission;
/*  46 */     this.id_value = id$impl.asLong();
/*  47 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  53 */   private volatile transient InitShim initShim = new InitShim();
/*     */   
/*     */   @Generated(from = "ApplicationCommandPermissionsData", generator = "Immutables")
/*     */   private final class InitShim {
/*     */     private String formatInitCycleMessage() {
/*  58 */       List<String> attributes = new ArrayList<>();
/*  59 */       return "Cannot build ApplicationCommandPermissionsData, attribute initializers form cycle " + attributes;
/*     */     }
/*     */ 
/*     */     
/*     */     private InitShim() {}
/*     */   }
/*     */ 
/*     */   
/*     */   @JsonProperty("id")
/*     */   public Id id() {
/*  69 */     return Id.of(this.id_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("type")
/*     */   public int type() {
/*  78 */     return this.type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("permission")
/*     */   public boolean permission() {
/*  87 */     return this.permission;
/*     */   }
/*     */   
/*     */   public ImmutableApplicationCommandPermissionsData withId(long value) {
/*  91 */     Id newValue = Id.of(value);
/*  92 */     return new ImmutableApplicationCommandPermissionsData(this, newValue, this.type, this.permission);
/*     */   }
/*     */   
/*     */   public ImmutableApplicationCommandPermissionsData withId(String value) {
/*  96 */     Id newValue = Id.of(value);
/*  97 */     return new ImmutableApplicationCommandPermissionsData(this, newValue, this.type, this.permission);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableApplicationCommandPermissionsData withType(int value) {
/* 107 */     if (this.type == value) return this; 
/* 108 */     return new ImmutableApplicationCommandPermissionsData(this, id(), value, this.permission);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableApplicationCommandPermissionsData withPermission(boolean value) {
/* 118 */     if (this.permission == value) return this; 
/* 119 */     return new ImmutableApplicationCommandPermissionsData(this, id(), this.type, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 128 */     if (this == another) return true; 
/* 129 */     return (another instanceof ImmutableApplicationCommandPermissionsData && 
/* 130 */       equalTo(0, (ImmutableApplicationCommandPermissionsData)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableApplicationCommandPermissionsData another) {
/* 134 */     return (Objects.equals(Long.valueOf(this.id_value), Long.valueOf(another.id_value)) && this.type == another.type && this.permission == another.permission);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 145 */     int h = 5381;
/* 146 */     h += (h << 5) + Objects.hashCode(Long.valueOf(this.id_value));
/* 147 */     h += (h << 5) + this.type;
/* 148 */     h += (h << 5) + Boolean.hashCode(this.permission);
/* 149 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 158 */     return "ApplicationCommandPermissionsData{id=" + 
/* 159 */       Objects.toString(Long.valueOf(this.id_value)) + ", type=" + this.type + ", permission=" + this.permission + "}";
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "ApplicationCommandPermissionsData", generator = "Immutables")
/*     */   static final class Json
/*     */     implements ApplicationCommandPermissionsData
/*     */   {
/*     */     Id id;
/*     */     
/*     */     int type;
/*     */     
/*     */     boolean typeIsSet;
/*     */     
/*     */     boolean permission;
/*     */     boolean permissionIsSet;
/*     */     
/*     */     @JsonProperty("id")
/*     */     public void setId(Id id) {
/* 181 */       this.id = id;
/*     */     }
/*     */     @JsonProperty("type")
/*     */     public void setType(int type) {
/* 185 */       this.type = type;
/* 186 */       this.typeIsSet = true;
/*     */     }
/*     */     @JsonProperty("permission")
/*     */     public void setPermission(boolean permission) {
/* 190 */       this.permission = permission;
/* 191 */       this.permissionIsSet = true;
/*     */     }
/*     */     public Id id() {
/* 194 */       throw new UnsupportedOperationException();
/*     */     } public int type() {
/* 196 */       throw new UnsupportedOperationException();
/*     */     } public boolean permission() {
/* 198 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableApplicationCommandPermissionsData fromJson(Json json) {
/* 209 */     Builder builder = builder();
/* 210 */     if (json.id != null) {
/* 211 */       builder.id(json.id);
/*     */     }
/* 213 */     if (json.typeIsSet) {
/* 214 */       builder.type(json.type);
/*     */     }
/* 216 */     if (json.permissionIsSet) {
/* 217 */       builder.permission(json.permission);
/*     */     }
/* 219 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableApplicationCommandPermissionsData of(Id id, int type, boolean permission) {
/* 230 */     return new ImmutableApplicationCommandPermissionsData(id, type, permission);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableApplicationCommandPermissionsData copyOf(ApplicationCommandPermissionsData instance) {
/* 241 */     if (instance instanceof ImmutableApplicationCommandPermissionsData) {
/* 242 */       return (ImmutableApplicationCommandPermissionsData)instance;
/*     */     }
/* 244 */     return builder()
/* 245 */       .from(instance)
/* 246 */       .build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 261 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "ApplicationCommandPermissionsData", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_TYPE = 1L;
/*     */ 
/*     */     
/*     */     private static final long INIT_BIT_PERMISSION = 2L;
/*     */ 
/*     */     
/* 275 */     private long initBits = 3L;
/*     */     
/* 277 */     private Id id_id = null;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private int type;
/*     */ 
/*     */ 
/*     */     
/*     */     private boolean permission;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(ApplicationCommandPermissionsData instance) {
/* 292 */       Objects.requireNonNull(instance, "instance");
/* 293 */       id(instance.id());
/* 294 */       type(instance.type());
/* 295 */       permission(instance.permission());
/* 296 */       return this;
/*     */     }
/*     */     
/*     */     public Builder id(String value) {
/* 300 */       this.id_id = Id.of(value);
/* 301 */       return this;
/*     */     }
/*     */     
/*     */     public Builder id(long value) {
/* 305 */       this.id_id = Id.of(value);
/* 306 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("id")
/*     */     public Builder id(Id value) {
/* 311 */       this.id_id = value;
/* 312 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("type")
/*     */     public final Builder type(int type) {
/* 322 */       this.type = type;
/* 323 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 324 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("permission")
/*     */     public final Builder permission(boolean permission) {
/* 334 */       this.permission = permission;
/* 335 */       this.initBits &= 0xFFFFFFFFFFFFFFFDL;
/* 336 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableApplicationCommandPermissionsData build() {
/* 345 */       if (this.initBits != 0L) {
/* 346 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 348 */       return new ImmutableApplicationCommandPermissionsData(null, id_build(), this.type, this.permission);
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 352 */       List<String> attributes = new ArrayList<>();
/* 353 */       if ((this.initBits & 0x1L) != 0L) attributes.add("type"); 
/* 354 */       if ((this.initBits & 0x2L) != 0L) attributes.add("permission"); 
/* 355 */       return "Cannot build ApplicationCommandPermissionsData, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Id id_build() {
/* 359 */       return this.id_id;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableApplicationCommandPermissionsData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */