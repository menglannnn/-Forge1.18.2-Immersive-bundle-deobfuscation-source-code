/*    */ package discord4j.discordjson.json;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonProperty;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import java.util.List;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ 
/*    */ @JsonSerialize(as = ImmutableComponentData.class)
/*    */ @JsonDeserialize(as = ImmutableComponentData.class)
/*    */ @Immutable
/*    */ public interface ComponentData
/*    */ {
/*    */   static ImmutableComponentData.Builder builder() {
/* 17 */     return ImmutableComponentData.builder();
/*    */   }
/*    */   
/*    */   int type();
/*    */   
/*    */   Possible<List<ComponentData>> components();
/*    */   
/*    */   Possible<Integer> style();
/*    */   
/*    */   Possible<String> label();
/*    */   
/*    */   Possible<EmojiData> emoji();
/*    */   
/*    */   @JsonProperty("custom_id")
/*    */   Possible<String> customId();
/*    */   
/*    */   Possible<String> url();
/*    */   
/*    */   Possible<Boolean> disabled();
/*    */   
/*    */   Possible<String> placeholder();
/*    */   
/*    */   @JsonProperty("min_values")
/*    */   Possible<Integer> minValues();
/*    */   
/*    */   @JsonProperty("max_values")
/*    */   Possible<Integer> maxValues();
/*    */   
/*    */   @JsonProperty("min_length")
/*    */   Possible<Integer> minLength();
/*    */   
/*    */   @JsonProperty("max_length")
/*    */   Possible<Integer> maxLength();
/*    */   
/*    */   Possible<Boolean> required();
/*    */   
/*    */   Possible<String> value();
/*    */   
/*    */   Possible<List<String>> values();
/*    */   
/*    */   Possible<List<SelectOptionData>> options();
/*    */   
/*    */   @JsonProperty("channel_types")
/*    */   Possible<List<Integer>> channelTypes();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ComponentData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */