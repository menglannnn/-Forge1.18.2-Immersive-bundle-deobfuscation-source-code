/*    */ package discord4j.discordjson.json;
/*    */ 
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import java.util.List;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ 
/*    */ @JsonSerialize(as = ImmutableActivityPartyData.class)
/*    */ @JsonDeserialize(as = ImmutableActivityPartyData.class)
/*    */ @Immutable
/*    */ public interface ActivityPartyData
/*    */ {
/*    */   static ImmutableActivityPartyData.Builder builder() {
/* 16 */     return ImmutableActivityPartyData.builder();
/*    */   }
/*    */   
/*    */   Possible<String> id();
/*    */   
/*    */   Possible<List<Long>> size();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ActivityPartyData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */