/*    */ package discord4j.discordjson.json;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonProperty;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import discord4j.discordjson.Id;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ @JsonSerialize(as = ImmutableChannelMentionData.class)
/*    */ @JsonDeserialize(as = ImmutableChannelMentionData.class)
/*    */ @Immutable
/*    */ public interface ChannelMentionData
/*    */ {
/*    */   static ImmutableChannelMentionData.Builder builder() {
/* 15 */     return ImmutableChannelMentionData.builder();
/*    */   }
/*    */   
/*    */   Id id();
/*    */   
/*    */   @JsonProperty("guild_id")
/*    */   Id guildId();
/*    */   
/*    */   int type();
/*    */   
/*    */   String name();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ChannelMentionData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */