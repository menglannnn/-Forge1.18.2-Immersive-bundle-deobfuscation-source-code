/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "MessageActivityData", generator = "Immutables")
/*     */ public final class ImmutableMessageActivityData
/*     */   implements MessageActivityData
/*     */ {
/*     */   private final int type;
/*     */   private final String partyId_value;
/*     */   private final boolean partyId_absent;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   private volatile transient InitShim initShim;
/*     */   
/*     */   private ImmutableMessageActivityData(int type, Possible<String> partyId) {
/*  51 */     this.initShim = new InitShim(); this.type = type; Possible<String> partyId$impl = partyId; this.partyId_value = partyId$impl.toOptional().orElse(null); this.partyId_absent = partyId$impl.isAbsent(); this.initShim = null; } private ImmutableMessageActivityData(ImmutableMessageActivityData original, int type, Possible<String> partyId) { this.initShim = new InitShim();
/*     */     this.type = type;
/*     */     Possible<String> partyId$impl = partyId;
/*     */     this.partyId_value = partyId$impl.toOptional().orElse(null);
/*     */     this.partyId_absent = partyId$impl.isAbsent();
/*  56 */     this.initShim = null; } @Generated(from = "MessageActivityData", generator = "Immutables") private final class InitShim { private InitShim() {} private String formatInitCycleMessage() { List<String> attributes = new ArrayList<>();
/*  57 */       return "Cannot build MessageActivityData, attribute initializers form cycle " + attributes; }
/*     */      }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("type")
/*     */   public int type() {
/*  67 */     return this.type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("party_id")
/*     */   public Possible<String> partyId() {
/*  76 */     return this.partyId_absent ? Possible.absent() : Possible.of(this.partyId_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableMessageActivityData withType(int value) {
/*  86 */     if (this.type == value) return this; 
/*  87 */     return new ImmutableMessageActivityData(this, value, partyId());
/*     */   }
/*     */   
/*     */   public ImmutableMessageActivityData withPartyId(Possible<String> value) {
/*  91 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/*  92 */     return new ImmutableMessageActivityData(this, this.type, newValue);
/*     */   }
/*     */   
/*     */   public ImmutableMessageActivityData withPartyId(String value) {
/*  96 */     Possible<String> newValue = Possible.of(value);
/*  97 */     return new ImmutableMessageActivityData(this, this.type, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 106 */     if (this == another) return true; 
/* 107 */     return (another instanceof ImmutableMessageActivityData && 
/* 108 */       equalTo(0, (ImmutableMessageActivityData)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableMessageActivityData another) {
/* 112 */     return (this.type == another.type && 
/* 113 */       partyId().equals(another.partyId()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 122 */     int h = 5381;
/* 123 */     h += (h << 5) + this.type;
/* 124 */     h += (h << 5) + partyId().hashCode();
/* 125 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 134 */     return "MessageActivityData{type=" + this.type + ", partyId=" + 
/*     */       
/* 136 */       partyId().toString() + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "MessageActivityData", generator = "Immutables")
/*     */   static final class Json
/*     */     implements MessageActivityData
/*     */   {
/*     */     int type;
/*     */     
/*     */     boolean typeIsSet;
/*     */     
/* 152 */     Possible<String> partyId = Possible.absent();
/*     */     
/*     */     @JsonProperty("type")
/*     */     public void setType(int type) {
/* 156 */       this.type = type;
/* 157 */       this.typeIsSet = true;
/*     */     }
/*     */     @JsonProperty("party_id")
/*     */     public void setPartyId(Possible<String> partyId) {
/* 161 */       this.partyId = partyId;
/*     */     }
/*     */     public int type() {
/* 164 */       throw new UnsupportedOperationException();
/*     */     } public Possible<String> partyId() {
/* 166 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableMessageActivityData fromJson(Json json) {
/* 177 */     Builder builder = builder();
/* 178 */     if (json.typeIsSet) {
/* 179 */       builder.type(json.type);
/*     */     }
/* 181 */     if (json.partyId != null) {
/* 182 */       builder.partyId(json.partyId);
/*     */     }
/* 184 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableMessageActivityData of(int type, Possible<String> partyId) {
/* 194 */     return new ImmutableMessageActivityData(type, partyId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableMessageActivityData copyOf(MessageActivityData instance) {
/* 205 */     if (instance instanceof ImmutableMessageActivityData) {
/* 206 */       return (ImmutableMessageActivityData)instance;
/*     */     }
/* 208 */     return builder()
/* 209 */       .from(instance)
/* 210 */       .build();
/*     */   }
/*     */   
/*     */   public boolean isPartyIdPresent() {
/* 214 */     return !this.partyId_absent;
/*     */   }
/*     */   
/*     */   public String partyIdOrElse(String defaultValue) {
/* 218 */     return !this.partyId_absent ? this.partyId_value : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 232 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "MessageActivityData", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_TYPE = 1L;
/*     */ 
/*     */ 
/*     */     
/* 245 */     private long initBits = 1L;
/*     */     
/* 247 */     private Possible<String> partyId_possible = Possible.absent();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private int type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(MessageActivityData instance) {
/* 261 */       Objects.requireNonNull(instance, "instance");
/* 262 */       type(instance.type());
/* 263 */       partyId(instance.partyId());
/* 264 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("type")
/*     */     public final Builder type(int type) {
/* 274 */       this.type = type;
/* 275 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 276 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("party_id")
/*     */     public Builder partyId(Possible<String> value) {
/* 281 */       this.partyId_possible = value;
/* 282 */       return this;
/*     */     }
/*     */     
/*     */     public Builder partyId(String value) {
/* 286 */       this.partyId_possible = Possible.of(value);
/* 287 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableMessageActivityData build() {
/* 296 */       if (this.initBits != 0L) {
/* 297 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 299 */       return new ImmutableMessageActivityData(null, this.type, partyId_build());
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 303 */       List<String> attributes = new ArrayList<>();
/* 304 */       if ((this.initBits & 0x1L) != 0L) attributes.add("type"); 
/* 305 */       return "Cannot build MessageActivityData, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Possible<String> partyId_build() {
/* 309 */       return this.partyId_possible;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableMessageActivityData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */