/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "GuildStickerCreateRequest", generator = "Immutables")
/*     */ public final class ImmutableGuildStickerCreateRequest
/*     */   implements GuildStickerCreateRequest
/*     */ {
/*     */   private final String name;
/*     */   private final String description;
/*     */   private final String tags;
/*     */   private final String file;
/*     */   
/*     */   private ImmutableGuildStickerCreateRequest(String name, String description, String tags, String file) {
/*  31 */     this.name = Objects.<String>requireNonNull(name, "name");
/*  32 */     this.description = Objects.<String>requireNonNull(description, "description");
/*  33 */     this.tags = Objects.<String>requireNonNull(tags, "tags");
/*  34 */     this.file = Objects.<String>requireNonNull(file, "file");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ImmutableGuildStickerCreateRequest(ImmutableGuildStickerCreateRequest original, String name, String description, String tags, String file) {
/*  43 */     this.name = name;
/*  44 */     this.description = description;
/*  45 */     this.tags = tags;
/*  46 */     this.file = file;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("name")
/*     */   public String name() {
/*  55 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("description")
/*     */   public String description() {
/*  64 */     return this.description;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("tags")
/*     */   public String tags() {
/*  73 */     return this.tags;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("file")
/*     */   public String file() {
/*  82 */     return this.file;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableGuildStickerCreateRequest withName(String value) {
/*  92 */     String newValue = Objects.<String>requireNonNull(value, "name");
/*  93 */     if (this.name.equals(newValue)) return this; 
/*  94 */     return new ImmutableGuildStickerCreateRequest(this, newValue, this.description, this.tags, this.file);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableGuildStickerCreateRequest withDescription(String value) {
/* 104 */     String newValue = Objects.<String>requireNonNull(value, "description");
/* 105 */     if (this.description.equals(newValue)) return this; 
/* 106 */     return new ImmutableGuildStickerCreateRequest(this, this.name, newValue, this.tags, this.file);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableGuildStickerCreateRequest withTags(String value) {
/* 116 */     String newValue = Objects.<String>requireNonNull(value, "tags");
/* 117 */     if (this.tags.equals(newValue)) return this; 
/* 118 */     return new ImmutableGuildStickerCreateRequest(this, this.name, this.description, newValue, this.file);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableGuildStickerCreateRequest withFile(String value) {
/* 128 */     String newValue = Objects.<String>requireNonNull(value, "file");
/* 129 */     if (this.file.equals(newValue)) return this; 
/* 130 */     return new ImmutableGuildStickerCreateRequest(this, this.name, this.description, this.tags, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 139 */     if (this == another) return true; 
/* 140 */     return (another instanceof ImmutableGuildStickerCreateRequest && 
/* 141 */       equalTo(0, (ImmutableGuildStickerCreateRequest)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableGuildStickerCreateRequest another) {
/* 145 */     return (this.name.equals(another.name) && this.description
/* 146 */       .equals(another.description) && this.tags
/* 147 */       .equals(another.tags) && this.file
/* 148 */       .equals(another.file));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 157 */     int h = 5381;
/* 158 */     h += (h << 5) + this.name.hashCode();
/* 159 */     h += (h << 5) + this.description.hashCode();
/* 160 */     h += (h << 5) + this.tags.hashCode();
/* 161 */     h += (h << 5) + this.file.hashCode();
/* 162 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 171 */     return "GuildStickerCreateRequest{name=" + this.name + ", description=" + this.description + ", tags=" + this.tags + ", file=" + this.file + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "GuildStickerCreateRequest", generator = "Immutables")
/*     */   static final class Json
/*     */     implements GuildStickerCreateRequest
/*     */   {
/*     */     String name;
/*     */     
/*     */     String description;
/*     */     
/*     */     String tags;
/*     */     
/*     */     String file;
/*     */ 
/*     */     
/*     */     @JsonProperty("name")
/*     */     public void setName(String name) {
/* 194 */       this.name = name;
/*     */     }
/*     */     @JsonProperty("description")
/*     */     public void setDescription(String description) {
/* 198 */       this.description = description;
/*     */     }
/*     */     @JsonProperty("tags")
/*     */     public void setTags(String tags) {
/* 202 */       this.tags = tags;
/*     */     }
/*     */     @JsonProperty("file")
/*     */     public void setFile(String file) {
/* 206 */       this.file = file;
/*     */     }
/*     */     public String name() {
/* 209 */       throw new UnsupportedOperationException();
/*     */     } public String description() {
/* 211 */       throw new UnsupportedOperationException();
/*     */     } public String tags() {
/* 213 */       throw new UnsupportedOperationException();
/*     */     } public String file() {
/* 215 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableGuildStickerCreateRequest fromJson(Json json) {
/* 226 */     Builder builder = builder();
/* 227 */     if (json.name != null) {
/* 228 */       builder.name(json.name);
/*     */     }
/* 230 */     if (json.description != null) {
/* 231 */       builder.description(json.description);
/*     */     }
/* 233 */     if (json.tags != null) {
/* 234 */       builder.tags(json.tags);
/*     */     }
/* 236 */     if (json.file != null) {
/* 237 */       builder.file(json.file);
/*     */     }
/* 239 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableGuildStickerCreateRequest of(String name, String description, String tags, String file) {
/* 251 */     return new ImmutableGuildStickerCreateRequest(name, description, tags, file);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableGuildStickerCreateRequest copyOf(GuildStickerCreateRequest instance) {
/* 262 */     if (instance instanceof ImmutableGuildStickerCreateRequest) {
/* 263 */       return (ImmutableGuildStickerCreateRequest)instance;
/*     */     }
/* 265 */     return builder()
/* 266 */       .from(instance)
/* 267 */       .build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 283 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "GuildStickerCreateRequest", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_NAME = 1L;
/*     */     
/*     */     private static final long INIT_BIT_DESCRIPTION = 2L;
/*     */     
/*     */     private static final long INIT_BIT_TAGS = 4L;
/*     */     
/*     */     private static final long INIT_BIT_FILE = 8L;
/*     */     
/* 299 */     private long initBits = 15L;
/*     */ 
/*     */ 
/*     */     
/*     */     private String name;
/*     */ 
/*     */     
/*     */     private String description;
/*     */ 
/*     */     
/*     */     private String tags;
/*     */ 
/*     */     
/*     */     private String file;
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(GuildStickerCreateRequest instance) {
/* 317 */       Objects.requireNonNull(instance, "instance");
/* 318 */       name(instance.name());
/* 319 */       description(instance.description());
/* 320 */       tags(instance.tags());
/* 321 */       file(instance.file());
/* 322 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("name")
/*     */     public final Builder name(String name) {
/* 332 */       this.name = Objects.<String>requireNonNull(name, "name");
/* 333 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 334 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("description")
/*     */     public final Builder description(String description) {
/* 344 */       this.description = Objects.<String>requireNonNull(description, "description");
/* 345 */       this.initBits &= 0xFFFFFFFFFFFFFFFDL;
/* 346 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("tags")
/*     */     public final Builder tags(String tags) {
/* 356 */       this.tags = Objects.<String>requireNonNull(tags, "tags");
/* 357 */       this.initBits &= 0xFFFFFFFFFFFFFFFBL;
/* 358 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("file")
/*     */     public final Builder file(String file) {
/* 368 */       this.file = Objects.<String>requireNonNull(file, "file");
/* 369 */       this.initBits &= 0xFFFFFFFFFFFFFFF7L;
/* 370 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableGuildStickerCreateRequest build() {
/* 379 */       if (this.initBits != 0L) {
/* 380 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 382 */       return new ImmutableGuildStickerCreateRequest(null, this.name, this.description, this.tags, this.file);
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 386 */       List<String> attributes = new ArrayList<>();
/* 387 */       if ((this.initBits & 0x1L) != 0L) attributes.add("name"); 
/* 388 */       if ((this.initBits & 0x2L) != 0L) attributes.add("description"); 
/* 389 */       if ((this.initBits & 0x4L) != 0L) attributes.add("tags"); 
/* 390 */       if ((this.initBits & 0x8L) != 0L) attributes.add("file"); 
/* 391 */       return "Cannot build GuildStickerCreateRequest, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableGuildStickerCreateRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */