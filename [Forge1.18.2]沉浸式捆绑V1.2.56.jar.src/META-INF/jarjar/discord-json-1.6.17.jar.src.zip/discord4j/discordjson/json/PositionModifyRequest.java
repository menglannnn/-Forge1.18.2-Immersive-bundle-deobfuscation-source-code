/*    */ package discord4j.discordjson.json;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonProperty;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import java.util.Optional;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ 
/*    */ @JsonSerialize(as = ImmutablePositionModifyRequest.class)
/*    */ @JsonDeserialize(as = ImmutablePositionModifyRequest.class)
/*    */ @Immutable
/*    */ public interface PositionModifyRequest
/*    */ {
/*    */   static ImmutablePositionModifyRequest.Builder builder() {
/* 17 */     return ImmutablePositionModifyRequest.builder();
/*    */   }
/*    */   
/*    */   String id();
/*    */   
/*    */   int position();
/*    */   
/*    */   @JsonProperty("lock_permissions")
/*    */   Possible<Optional<Boolean>> lockPermissions();
/*    */   
/*    */   @JsonProperty("parent_id")
/*    */   Possible<Optional<String>> parentId();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\PositionModifyRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */