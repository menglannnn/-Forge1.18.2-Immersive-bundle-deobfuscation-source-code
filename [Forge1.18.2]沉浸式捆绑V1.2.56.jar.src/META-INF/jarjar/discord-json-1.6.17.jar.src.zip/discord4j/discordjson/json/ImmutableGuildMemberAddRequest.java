/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "GuildMemberAddRequest", generator = "Immutables")
/*     */ public final class ImmutableGuildMemberAddRequest
/*     */   implements GuildMemberAddRequest
/*     */ {
/*     */   private final String accessToken;
/*     */   private final String nick;
/*     */   private final List<String> roles;
/*     */   private final boolean mute;
/*     */   private final boolean deaf;
/*     */   
/*     */   private ImmutableGuildMemberAddRequest(String accessToken, String nick, Iterable<String> roles, boolean mute, boolean deaf) {
/*  39 */     this.accessToken = Objects.<String>requireNonNull(accessToken, "accessToken");
/*  40 */     this.nick = Objects.<String>requireNonNull(nick, "nick");
/*  41 */     this.roles = createUnmodifiableList(false, createSafeList(roles, true, false));
/*  42 */     this.mute = mute;
/*  43 */     this.deaf = deaf;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ImmutableGuildMemberAddRequest(ImmutableGuildMemberAddRequest original, String accessToken, String nick, List<String> roles, boolean mute, boolean deaf) {
/*  53 */     this.accessToken = accessToken;
/*  54 */     this.nick = nick;
/*  55 */     this.roles = roles;
/*  56 */     this.mute = mute;
/*  57 */     this.deaf = deaf;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("access_token")
/*     */   public String accessToken() {
/*  66 */     return this.accessToken;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("nick")
/*     */   public String nick() {
/*  75 */     return this.nick;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("roles")
/*     */   public List<String> roles() {
/*  84 */     return this.roles;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("mute")
/*     */   public boolean mute() {
/*  93 */     return this.mute;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("deaf")
/*     */   public boolean deaf() {
/* 102 */     return this.deaf;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableGuildMemberAddRequest withAccessToken(String value) {
/* 112 */     String newValue = Objects.<String>requireNonNull(value, "accessToken");
/* 113 */     if (this.accessToken.equals(newValue)) return this; 
/* 114 */     return new ImmutableGuildMemberAddRequest(this, newValue, this.nick, this.roles, this.mute, this.deaf);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableGuildMemberAddRequest withNick(String value) {
/* 124 */     String newValue = Objects.<String>requireNonNull(value, "nick");
/* 125 */     if (this.nick.equals(newValue)) return this; 
/* 126 */     return new ImmutableGuildMemberAddRequest(this, this.accessToken, newValue, this.roles, this.mute, this.deaf);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableGuildMemberAddRequest withRoles(String... elements) {
/* 135 */     List<String> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/* 136 */     return new ImmutableGuildMemberAddRequest(this, this.accessToken, this.nick, newValue, this.mute, this.deaf);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableGuildMemberAddRequest withRoles(Iterable<String> elements) {
/* 146 */     if (this.roles == elements) return this; 
/* 147 */     List<String> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/* 148 */     return new ImmutableGuildMemberAddRequest(this, this.accessToken, this.nick, newValue, this.mute, this.deaf);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableGuildMemberAddRequest withMute(boolean value) {
/* 158 */     if (this.mute == value) return this; 
/* 159 */     return new ImmutableGuildMemberAddRequest(this, this.accessToken, this.nick, this.roles, value, this.deaf);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableGuildMemberAddRequest withDeaf(boolean value) {
/* 169 */     if (this.deaf == value) return this; 
/* 170 */     return new ImmutableGuildMemberAddRequest(this, this.accessToken, this.nick, this.roles, this.mute, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 179 */     if (this == another) return true; 
/* 180 */     return (another instanceof ImmutableGuildMemberAddRequest && 
/* 181 */       equalTo(0, (ImmutableGuildMemberAddRequest)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableGuildMemberAddRequest another) {
/* 185 */     return (this.accessToken.equals(another.accessToken) && this.nick
/* 186 */       .equals(another.nick) && this.roles
/* 187 */       .equals(another.roles) && this.mute == another.mute && this.deaf == another.deaf);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 198 */     int h = 5381;
/* 199 */     h += (h << 5) + this.accessToken.hashCode();
/* 200 */     h += (h << 5) + this.nick.hashCode();
/* 201 */     h += (h << 5) + this.roles.hashCode();
/* 202 */     h += (h << 5) + Boolean.hashCode(this.mute);
/* 203 */     h += (h << 5) + Boolean.hashCode(this.deaf);
/* 204 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 213 */     return "GuildMemberAddRequest{accessToken=" + this.accessToken + ", nick=" + this.nick + ", roles=" + this.roles + ", mute=" + this.mute + ", deaf=" + this.deaf + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "GuildMemberAddRequest", generator = "Immutables")
/*     */   static final class Json
/*     */     implements GuildMemberAddRequest
/*     */   {
/*     */     String accessToken;
/*     */ 
/*     */ 
/*     */     
/*     */     String nick;
/*     */ 
/*     */     
/* 233 */     List<String> roles = Collections.emptyList(); boolean mute;
/*     */     boolean muteIsSet;
/*     */     boolean deaf;
/*     */     boolean deafIsSet;
/*     */     
/*     */     @JsonProperty("access_token")
/*     */     public void setAccessToken(String accessToken) {
/* 240 */       this.accessToken = accessToken;
/*     */     }
/*     */     @JsonProperty("nick")
/*     */     public void setNick(String nick) {
/* 244 */       this.nick = nick;
/*     */     }
/*     */     @JsonProperty("roles")
/*     */     public void setRoles(List<String> roles) {
/* 248 */       this.roles = roles;
/*     */     }
/*     */     @JsonProperty("mute")
/*     */     public void setMute(boolean mute) {
/* 252 */       this.mute = mute;
/* 253 */       this.muteIsSet = true;
/*     */     }
/*     */     @JsonProperty("deaf")
/*     */     public void setDeaf(boolean deaf) {
/* 257 */       this.deaf = deaf;
/* 258 */       this.deafIsSet = true;
/*     */     }
/*     */     public String accessToken() {
/* 261 */       throw new UnsupportedOperationException();
/*     */     } public String nick() {
/* 263 */       throw new UnsupportedOperationException();
/*     */     } public List<String> roles() {
/* 265 */       throw new UnsupportedOperationException();
/*     */     } public boolean mute() {
/* 267 */       throw new UnsupportedOperationException();
/*     */     } public boolean deaf() {
/* 269 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableGuildMemberAddRequest fromJson(Json json) {
/* 280 */     Builder builder = builder();
/* 281 */     if (json.accessToken != null) {
/* 282 */       builder.accessToken(json.accessToken);
/*     */     }
/* 284 */     if (json.nick != null) {
/* 285 */       builder.nick(json.nick);
/*     */     }
/* 287 */     if (json.roles != null) {
/* 288 */       builder.addAllRoles(json.roles);
/*     */     }
/* 290 */     if (json.muteIsSet) {
/* 291 */       builder.mute(json.mute);
/*     */     }
/* 293 */     if (json.deafIsSet) {
/* 294 */       builder.deaf(json.deaf);
/*     */     }
/* 296 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableGuildMemberAddRequest of(String accessToken, String nick, List<String> roles, boolean mute, boolean deaf) {
/* 309 */     return of(accessToken, nick, roles, mute, deaf);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableGuildMemberAddRequest of(String accessToken, String nick, Iterable<String> roles, boolean mute, boolean deaf) {
/* 322 */     return new ImmutableGuildMemberAddRequest(accessToken, nick, roles, mute, deaf);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableGuildMemberAddRequest copyOf(GuildMemberAddRequest instance) {
/* 333 */     if (instance instanceof ImmutableGuildMemberAddRequest) {
/* 334 */       return (ImmutableGuildMemberAddRequest)instance;
/*     */     }
/* 336 */     return builder()
/* 337 */       .from(instance)
/* 338 */       .build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 355 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "GuildMemberAddRequest", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_ACCESS_TOKEN = 1L;
/*     */     
/*     */     private static final long INIT_BIT_NICK = 2L;
/*     */     
/*     */     private static final long INIT_BIT_MUTE = 4L;
/*     */     
/*     */     private static final long INIT_BIT_DEAF = 8L;
/*     */     
/* 371 */     private long initBits = 15L;
/*     */     
/*     */     private String accessToken;
/*     */     private String nick;
/* 375 */     private List<String> roles = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private boolean mute;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private boolean deaf;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(GuildMemberAddRequest instance) {
/* 391 */       Objects.requireNonNull(instance, "instance");
/* 392 */       accessToken(instance.accessToken());
/* 393 */       nick(instance.nick());
/* 394 */       addAllRoles(instance.roles());
/* 395 */       mute(instance.mute());
/* 396 */       deaf(instance.deaf());
/* 397 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("access_token")
/*     */     public final Builder accessToken(String accessToken) {
/* 407 */       this.accessToken = Objects.<String>requireNonNull(accessToken, "accessToken");
/* 408 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 409 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("nick")
/*     */     public final Builder nick(String nick) {
/* 419 */       this.nick = Objects.<String>requireNonNull(nick, "nick");
/* 420 */       this.initBits &= 0xFFFFFFFFFFFFFFFDL;
/* 421 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder addRole(String element) {
/* 430 */       this.roles.add(Objects.<String>requireNonNull(element, "roles element"));
/* 431 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder addRoles(String... elements) {
/* 440 */       for (String element : elements) {
/* 441 */         this.roles.add(Objects.<String>requireNonNull(element, "roles element"));
/*     */       }
/* 443 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("roles")
/*     */     public final Builder roles(Iterable<String> elements) {
/* 454 */       this.roles.clear();
/* 455 */       return addAllRoles(elements);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder addAllRoles(Iterable<String> elements) {
/* 464 */       for (String element : elements) {
/* 465 */         this.roles.add(Objects.<String>requireNonNull(element, "roles element"));
/*     */       }
/* 467 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("mute")
/*     */     public final Builder mute(boolean mute) {
/* 477 */       this.mute = mute;
/* 478 */       this.initBits &= 0xFFFFFFFFFFFFFFFBL;
/* 479 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("deaf")
/*     */     public final Builder deaf(boolean deaf) {
/* 489 */       this.deaf = deaf;
/* 490 */       this.initBits &= 0xFFFFFFFFFFFFFFF7L;
/* 491 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableGuildMemberAddRequest build() {
/* 500 */       if (this.initBits != 0L) {
/* 501 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 503 */       return new ImmutableGuildMemberAddRequest(null, this.accessToken, this.nick, ImmutableGuildMemberAddRequest.createUnmodifiableList(true, (List)this.roles), this.mute, this.deaf);
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 507 */       List<String> attributes = new ArrayList<>();
/* 508 */       if ((this.initBits & 0x1L) != 0L) attributes.add("accessToken"); 
/* 509 */       if ((this.initBits & 0x2L) != 0L) attributes.add("nick"); 
/* 510 */       if ((this.initBits & 0x4L) != 0L) attributes.add("mute"); 
/* 511 */       if ((this.initBits & 0x8L) != 0L) attributes.add("deaf"); 
/* 512 */       return "Cannot build GuildMemberAddRequest, some of required attributes are not set " + attributes;
/*     */     }
/*     */     private Builder() {} }
/*     */   
/*     */   private static <T> List<T> createSafeList(Iterable<? extends T> iterable, boolean checkNulls, boolean skipNulls) {
/*     */     ArrayList<T> list;
/* 518 */     if (iterable instanceof Collection) {
/* 519 */       int size = ((Collection)iterable).size();
/* 520 */       if (size == 0) return Collections.emptyList(); 
/* 521 */       list = new ArrayList<>();
/*     */     } else {
/* 523 */       list = new ArrayList<>();
/*     */     } 
/* 525 */     for (T element : iterable) {
/* 526 */       if (skipNulls && element == null)
/* 527 */         continue;  if (checkNulls) Objects.requireNonNull(element, "element"); 
/* 528 */       list.add(element);
/*     */     } 
/* 530 */     return list;
/*     */   }
/*     */   
/*     */   private static <T> List<T> createUnmodifiableList(boolean clone, List<T> list) {
/* 534 */     switch (list.size()) { case 0:
/* 535 */         return Collections.emptyList();
/* 536 */       case 1: return Collections.singletonList(list.get(0)); }
/*     */     
/* 538 */     if (clone) {
/* 539 */       return Collections.unmodifiableList(new ArrayList<>(list));
/*     */     }
/* 541 */     if (list instanceof ArrayList) {
/* 542 */       ((ArrayList)list).trimToSize();
/*     */     }
/* 544 */     return Collections.unmodifiableList(list);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableGuildMemberAddRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */