/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "InviteCreateRequest", generator = "Immutables")
/*     */ public final class ImmutableInviteCreateRequest
/*     */   implements InviteCreateRequest
/*     */ {
/*     */   private final Integer maxAge_value;
/*     */   private final boolean maxAge_absent;
/*     */   private final Integer maxUses_value;
/*     */   private final boolean maxUses_absent;
/*     */   private final Boolean temporary_value;
/*     */   private final boolean temporary_absent;
/*     */   private final Boolean unique_value;
/*     */   private final boolean unique_absent;
/*     */   private final Integer targetType_value;
/*     */   private final boolean targetType_absent;
/*     */   private final String targetUserId_value;
/*     */   private final boolean targetUserId_absent;
/*     */   private final String targetApplicationId_value;
/*     */   private final boolean targetApplicationId_absent;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   
/*     */   private ImmutableInviteCreateRequest(Possible<Integer> maxAge, Possible<Integer> maxUses, Possible<Boolean> temporary, Possible<Boolean> unique, Possible<Integer> targetType, Possible<String> targetUserId, Possible<String> targetApplicationId) {
/*  48 */     Possible<Integer> maxAge$impl = maxAge;
/*  49 */     Possible<Integer> maxUses$impl = maxUses;
/*  50 */     Possible<Boolean> temporary$impl = temporary;
/*  51 */     Possible<Boolean> unique$impl = unique;
/*  52 */     Possible<Integer> targetType$impl = targetType;
/*  53 */     Possible<String> targetUserId$impl = targetUserId;
/*  54 */     Possible<String> targetApplicationId$impl = targetApplicationId;
/*  55 */     this.maxAge_value = maxAge$impl.toOptional().orElse(null);
/*  56 */     this.maxAge_absent = maxAge$impl.isAbsent();
/*  57 */     this.maxUses_value = maxUses$impl.toOptional().orElse(null);
/*  58 */     this.maxUses_absent = maxUses$impl.isAbsent();
/*  59 */     this.temporary_value = temporary$impl.toOptional().orElse(null);
/*  60 */     this.temporary_absent = temporary$impl.isAbsent();
/*  61 */     this.unique_value = unique$impl.toOptional().orElse(null);
/*  62 */     this.unique_absent = unique$impl.isAbsent();
/*  63 */     this.targetType_value = targetType$impl.toOptional().orElse(null);
/*  64 */     this.targetType_absent = targetType$impl.isAbsent();
/*  65 */     this.targetUserId_value = targetUserId$impl.toOptional().orElse(null);
/*  66 */     this.targetUserId_absent = targetUserId$impl.isAbsent();
/*  67 */     this.targetApplicationId_value = targetApplicationId$impl.toOptional().orElse(null);
/*  68 */     this.targetApplicationId_absent = targetApplicationId$impl.isAbsent();
/*  69 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ImmutableInviteCreateRequest(ImmutableInviteCreateRequest original, Possible<Integer> maxAge, Possible<Integer> maxUses, Possible<Boolean> temporary, Possible<Boolean> unique, Possible<Integer> targetType, Possible<String> targetUserId, Possible<String> targetApplicationId) {
/*  81 */     Possible<Integer> maxAge$impl = maxAge;
/*  82 */     Possible<Integer> maxUses$impl = maxUses;
/*  83 */     Possible<Boolean> temporary$impl = temporary;
/*  84 */     Possible<Boolean> unique$impl = unique;
/*  85 */     Possible<Integer> targetType$impl = targetType;
/*  86 */     Possible<String> targetUserId$impl = targetUserId;
/*  87 */     Possible<String> targetApplicationId$impl = targetApplicationId;
/*  88 */     this.maxAge_value = maxAge$impl.toOptional().orElse(null);
/*  89 */     this.maxAge_absent = maxAge$impl.isAbsent();
/*  90 */     this.maxUses_value = maxUses$impl.toOptional().orElse(null);
/*  91 */     this.maxUses_absent = maxUses$impl.isAbsent();
/*  92 */     this.temporary_value = temporary$impl.toOptional().orElse(null);
/*  93 */     this.temporary_absent = temporary$impl.isAbsent();
/*  94 */     this.unique_value = unique$impl.toOptional().orElse(null);
/*  95 */     this.unique_absent = unique$impl.isAbsent();
/*  96 */     this.targetType_value = targetType$impl.toOptional().orElse(null);
/*  97 */     this.targetType_absent = targetType$impl.isAbsent();
/*  98 */     this.targetUserId_value = targetUserId$impl.toOptional().orElse(null);
/*  99 */     this.targetUserId_absent = targetUserId$impl.isAbsent();
/* 100 */     this.targetApplicationId_value = targetApplicationId$impl.toOptional().orElse(null);
/* 101 */     this.targetApplicationId_absent = targetApplicationId$impl.isAbsent();
/* 102 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 108 */   private volatile transient InitShim initShim = new InitShim();
/*     */   
/*     */   @Generated(from = "InviteCreateRequest", generator = "Immutables")
/*     */   private final class InitShim {
/*     */     private String formatInitCycleMessage() {
/* 113 */       List<String> attributes = new ArrayList<>();
/* 114 */       return "Cannot build InviteCreateRequest, attribute initializers form cycle " + attributes;
/*     */     }
/*     */ 
/*     */     
/*     */     private InitShim() {}
/*     */   }
/*     */ 
/*     */   
/*     */   @JsonProperty("max_age")
/*     */   public Possible<Integer> maxAge() {
/* 124 */     return this.maxAge_absent ? Possible.absent() : Possible.of(this.maxAge_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("max_uses")
/*     */   public Possible<Integer> maxUses() {
/* 133 */     return this.maxUses_absent ? Possible.absent() : Possible.of(this.maxUses_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("temporary")
/*     */   public Possible<Boolean> temporary() {
/* 142 */     return this.temporary_absent ? Possible.absent() : Possible.of(this.temporary_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("unique")
/*     */   public Possible<Boolean> unique() {
/* 151 */     return this.unique_absent ? Possible.absent() : Possible.of(this.unique_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("target_type")
/*     */   public Possible<Integer> targetType() {
/* 160 */     return this.targetType_absent ? Possible.absent() : Possible.of(this.targetType_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("target_user_id")
/*     */   public Possible<String> targetUserId() {
/* 169 */     return this.targetUserId_absent ? Possible.absent() : Possible.of(this.targetUserId_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("target_application_id")
/*     */   public Possible<String> targetApplicationId() {
/* 178 */     return this.targetApplicationId_absent ? Possible.absent() : Possible.of(this.targetApplicationId_value);
/*     */   }
/*     */   
/*     */   public ImmutableInviteCreateRequest withMaxAge(Possible<Integer> value) {
/* 182 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/* 183 */     return new ImmutableInviteCreateRequest(this, newValue, 
/*     */ 
/*     */         
/* 186 */         maxUses(), 
/* 187 */         temporary(), 
/* 188 */         unique(), 
/* 189 */         targetType(), 
/* 190 */         targetUserId(), 
/* 191 */         targetApplicationId());
/*     */   }
/*     */   
/*     */   public ImmutableInviteCreateRequest withMaxAge(Integer value) {
/* 195 */     Possible<Integer> newValue = Possible.of(value);
/* 196 */     return new ImmutableInviteCreateRequest(this, newValue, 
/*     */ 
/*     */         
/* 199 */         maxUses(), 
/* 200 */         temporary(), 
/* 201 */         unique(), 
/* 202 */         targetType(), 
/* 203 */         targetUserId(), 
/* 204 */         targetApplicationId());
/*     */   }
/*     */   
/*     */   public ImmutableInviteCreateRequest withMaxUses(Possible<Integer> value) {
/* 208 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/* 209 */     return new ImmutableInviteCreateRequest(this, 
/*     */         
/* 211 */         maxAge(), newValue, 
/*     */         
/* 213 */         temporary(), 
/* 214 */         unique(), 
/* 215 */         targetType(), 
/* 216 */         targetUserId(), 
/* 217 */         targetApplicationId());
/*     */   }
/*     */   
/*     */   public ImmutableInviteCreateRequest withMaxUses(Integer value) {
/* 221 */     Possible<Integer> newValue = Possible.of(value);
/* 222 */     return new ImmutableInviteCreateRequest(this, 
/*     */         
/* 224 */         maxAge(), newValue, 
/*     */         
/* 226 */         temporary(), 
/* 227 */         unique(), 
/* 228 */         targetType(), 
/* 229 */         targetUserId(), 
/* 230 */         targetApplicationId());
/*     */   }
/*     */   
/*     */   public ImmutableInviteCreateRequest withTemporary(Possible<Boolean> value) {
/* 234 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/* 235 */     return new ImmutableInviteCreateRequest(this, 
/*     */         
/* 237 */         maxAge(), 
/* 238 */         maxUses(), newValue, 
/*     */         
/* 240 */         unique(), 
/* 241 */         targetType(), 
/* 242 */         targetUserId(), 
/* 243 */         targetApplicationId());
/*     */   }
/*     */   
/*     */   public ImmutableInviteCreateRequest withTemporary(Boolean value) {
/* 247 */     Possible<Boolean> newValue = Possible.of(value);
/* 248 */     return new ImmutableInviteCreateRequest(this, 
/*     */         
/* 250 */         maxAge(), 
/* 251 */         maxUses(), newValue, 
/*     */         
/* 253 */         unique(), 
/* 254 */         targetType(), 
/* 255 */         targetUserId(), 
/* 256 */         targetApplicationId());
/*     */   }
/*     */   
/*     */   public ImmutableInviteCreateRequest withUnique(Possible<Boolean> value) {
/* 260 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/* 261 */     return new ImmutableInviteCreateRequest(this, 
/*     */         
/* 263 */         maxAge(), 
/* 264 */         maxUses(), 
/* 265 */         temporary(), newValue, 
/*     */         
/* 267 */         targetType(), 
/* 268 */         targetUserId(), 
/* 269 */         targetApplicationId());
/*     */   }
/*     */   
/*     */   public ImmutableInviteCreateRequest withUnique(Boolean value) {
/* 273 */     Possible<Boolean> newValue = Possible.of(value);
/* 274 */     return new ImmutableInviteCreateRequest(this, 
/*     */         
/* 276 */         maxAge(), 
/* 277 */         maxUses(), 
/* 278 */         temporary(), newValue, 
/*     */         
/* 280 */         targetType(), 
/* 281 */         targetUserId(), 
/* 282 */         targetApplicationId());
/*     */   }
/*     */   
/*     */   public ImmutableInviteCreateRequest withTargetType(Possible<Integer> value) {
/* 286 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/* 287 */     return new ImmutableInviteCreateRequest(this, 
/*     */         
/* 289 */         maxAge(), 
/* 290 */         maxUses(), 
/* 291 */         temporary(), 
/* 292 */         unique(), newValue, 
/*     */         
/* 294 */         targetUserId(), 
/* 295 */         targetApplicationId());
/*     */   }
/*     */   
/*     */   public ImmutableInviteCreateRequest withTargetType(Integer value) {
/* 299 */     Possible<Integer> newValue = Possible.of(value);
/* 300 */     return new ImmutableInviteCreateRequest(this, 
/*     */         
/* 302 */         maxAge(), 
/* 303 */         maxUses(), 
/* 304 */         temporary(), 
/* 305 */         unique(), newValue, 
/*     */         
/* 307 */         targetUserId(), 
/* 308 */         targetApplicationId());
/*     */   }
/*     */   
/*     */   public ImmutableInviteCreateRequest withTargetUserId(Possible<String> value) {
/* 312 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/* 313 */     return new ImmutableInviteCreateRequest(this, 
/*     */         
/* 315 */         maxAge(), 
/* 316 */         maxUses(), 
/* 317 */         temporary(), 
/* 318 */         unique(), 
/* 319 */         targetType(), newValue, 
/*     */         
/* 321 */         targetApplicationId());
/*     */   }
/*     */   
/*     */   public ImmutableInviteCreateRequest withTargetUserId(String value) {
/* 325 */     Possible<String> newValue = Possible.of(value);
/* 326 */     return new ImmutableInviteCreateRequest(this, 
/*     */         
/* 328 */         maxAge(), 
/* 329 */         maxUses(), 
/* 330 */         temporary(), 
/* 331 */         unique(), 
/* 332 */         targetType(), newValue, 
/*     */         
/* 334 */         targetApplicationId());
/*     */   }
/*     */   
/*     */   public ImmutableInviteCreateRequest withTargetApplicationId(Possible<String> value) {
/* 338 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/* 339 */     return new ImmutableInviteCreateRequest(this, 
/*     */         
/* 341 */         maxAge(), 
/* 342 */         maxUses(), 
/* 343 */         temporary(), 
/* 344 */         unique(), 
/* 345 */         targetType(), 
/* 346 */         targetUserId(), newValue);
/*     */   }
/*     */ 
/*     */   
/*     */   public ImmutableInviteCreateRequest withTargetApplicationId(String value) {
/* 351 */     Possible<String> newValue = Possible.of(value);
/* 352 */     return new ImmutableInviteCreateRequest(this, 
/*     */         
/* 354 */         maxAge(), 
/* 355 */         maxUses(), 
/* 356 */         temporary(), 
/* 357 */         unique(), 
/* 358 */         targetType(), 
/* 359 */         targetUserId(), newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 369 */     if (this == another) return true; 
/* 370 */     return (another instanceof ImmutableInviteCreateRequest && 
/* 371 */       equalTo(0, (ImmutableInviteCreateRequest)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableInviteCreateRequest another) {
/* 375 */     return (maxAge().equals(another.maxAge()) && 
/* 376 */       maxUses().equals(another.maxUses()) && 
/* 377 */       temporary().equals(another.temporary()) && 
/* 378 */       unique().equals(another.unique()) && 
/* 379 */       targetType().equals(another.targetType()) && 
/* 380 */       targetUserId().equals(another.targetUserId()) && 
/* 381 */       targetApplicationId().equals(another.targetApplicationId()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 390 */     int h = 5381;
/* 391 */     h += (h << 5) + maxAge().hashCode();
/* 392 */     h += (h << 5) + maxUses().hashCode();
/* 393 */     h += (h << 5) + temporary().hashCode();
/* 394 */     h += (h << 5) + unique().hashCode();
/* 395 */     h += (h << 5) + targetType().hashCode();
/* 396 */     h += (h << 5) + targetUserId().hashCode();
/* 397 */     h += (h << 5) + targetApplicationId().hashCode();
/* 398 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 407 */     return "InviteCreateRequest{maxAge=" + 
/* 408 */       maxAge().toString() + ", maxUses=" + 
/* 409 */       maxUses().toString() + ", temporary=" + 
/* 410 */       temporary().toString() + ", unique=" + 
/* 411 */       unique().toString() + ", targetType=" + 
/* 412 */       targetType().toString() + ", targetUserId=" + 
/* 413 */       targetUserId().toString() + ", targetApplicationId=" + 
/* 414 */       targetApplicationId().toString() + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "InviteCreateRequest", generator = "Immutables")
/*     */   static final class Json
/*     */     implements InviteCreateRequest
/*     */   {
/* 428 */     Possible<Integer> maxAge = Possible.absent();
/*     */ 
/*     */     
/* 431 */     Possible<Integer> maxUses = Possible.absent();
/*     */ 
/*     */     
/* 434 */     Possible<Boolean> temporary = Possible.absent();
/*     */ 
/*     */     
/* 437 */     Possible<Boolean> unique = Possible.absent();
/*     */ 
/*     */     
/* 440 */     Possible<Integer> targetType = Possible.absent();
/*     */ 
/*     */     
/* 443 */     Possible<String> targetUserId = Possible.absent();
/*     */ 
/*     */     
/* 446 */     Possible<String> targetApplicationId = Possible.absent();
/*     */     
/*     */     @JsonProperty("max_age")
/*     */     public void setMaxAge(Possible<Integer> maxAge) {
/* 450 */       this.maxAge = maxAge;
/*     */     }
/*     */     @JsonProperty("max_uses")
/*     */     public void setMaxUses(Possible<Integer> maxUses) {
/* 454 */       this.maxUses = maxUses;
/*     */     }
/*     */     @JsonProperty("temporary")
/*     */     public void setTemporary(Possible<Boolean> temporary) {
/* 458 */       this.temporary = temporary;
/*     */     }
/*     */     @JsonProperty("unique")
/*     */     public void setUnique(Possible<Boolean> unique) {
/* 462 */       this.unique = unique;
/*     */     }
/*     */     @JsonProperty("target_type")
/*     */     public void setTargetType(Possible<Integer> targetType) {
/* 466 */       this.targetType = targetType;
/*     */     }
/*     */     @JsonProperty("target_user_id")
/*     */     public void setTargetUserId(Possible<String> targetUserId) {
/* 470 */       this.targetUserId = targetUserId;
/*     */     }
/*     */     @JsonProperty("target_application_id")
/*     */     public void setTargetApplicationId(Possible<String> targetApplicationId) {
/* 474 */       this.targetApplicationId = targetApplicationId;
/*     */     }
/*     */     public Possible<Integer> maxAge() {
/* 477 */       throw new UnsupportedOperationException();
/*     */     } public Possible<Integer> maxUses() {
/* 479 */       throw new UnsupportedOperationException();
/*     */     } public Possible<Boolean> temporary() {
/* 481 */       throw new UnsupportedOperationException();
/*     */     } public Possible<Boolean> unique() {
/* 483 */       throw new UnsupportedOperationException();
/*     */     } public Possible<Integer> targetType() {
/* 485 */       throw new UnsupportedOperationException();
/*     */     } public Possible<String> targetUserId() {
/* 487 */       throw new UnsupportedOperationException();
/*     */     } public Possible<String> targetApplicationId() {
/* 489 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableInviteCreateRequest fromJson(Json json) {
/* 500 */     Builder builder = builder();
/* 501 */     if (json.maxAge != null) {
/* 502 */       builder.maxAge(json.maxAge);
/*     */     }
/* 504 */     if (json.maxUses != null) {
/* 505 */       builder.maxUses(json.maxUses);
/*     */     }
/* 507 */     if (json.temporary != null) {
/* 508 */       builder.temporary(json.temporary);
/*     */     }
/* 510 */     if (json.unique != null) {
/* 511 */       builder.unique(json.unique);
/*     */     }
/* 513 */     if (json.targetType != null) {
/* 514 */       builder.targetType(json.targetType);
/*     */     }
/* 516 */     if (json.targetUserId != null) {
/* 517 */       builder.targetUserId(json.targetUserId);
/*     */     }
/* 519 */     if (json.targetApplicationId != null) {
/* 520 */       builder.targetApplicationId(json.targetApplicationId);
/*     */     }
/* 522 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableInviteCreateRequest of(Possible<Integer> maxAge, Possible<Integer> maxUses, Possible<Boolean> temporary, Possible<Boolean> unique, Possible<Integer> targetType, Possible<String> targetUserId, Possible<String> targetApplicationId) {
/* 537 */     return new ImmutableInviteCreateRequest(maxAge, maxUses, temporary, unique, targetType, targetUserId, targetApplicationId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableInviteCreateRequest copyOf(InviteCreateRequest instance) {
/* 548 */     if (instance instanceof ImmutableInviteCreateRequest) {
/* 549 */       return (ImmutableInviteCreateRequest)instance;
/*     */     }
/* 551 */     return builder()
/* 552 */       .from(instance)
/* 553 */       .build();
/*     */   }
/*     */   
/*     */   public boolean isMaxAgePresent() {
/* 557 */     return !this.maxAge_absent;
/*     */   }
/*     */   
/*     */   public Integer maxAgeOrElse(Integer defaultValue) {
/* 561 */     return !this.maxAge_absent ? this.maxAge_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isMaxUsesPresent() {
/* 565 */     return !this.maxUses_absent;
/*     */   }
/*     */   
/*     */   public Integer maxUsesOrElse(Integer defaultValue) {
/* 569 */     return !this.maxUses_absent ? this.maxUses_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isTemporaryPresent() {
/* 573 */     return !this.temporary_absent;
/*     */   }
/*     */   
/*     */   public Boolean temporaryOrElse(Boolean defaultValue) {
/* 577 */     return !this.temporary_absent ? this.temporary_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isUniquePresent() {
/* 581 */     return !this.unique_absent;
/*     */   }
/*     */   
/*     */   public Boolean uniqueOrElse(Boolean defaultValue) {
/* 585 */     return !this.unique_absent ? this.unique_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isTargetTypePresent() {
/* 589 */     return !this.targetType_absent;
/*     */   }
/*     */   
/*     */   public Integer targetTypeOrElse(Integer defaultValue) {
/* 593 */     return !this.targetType_absent ? this.targetType_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isTargetUserIdPresent() {
/* 597 */     return !this.targetUserId_absent;
/*     */   }
/*     */   
/*     */   public String targetUserIdOrElse(String defaultValue) {
/* 601 */     return !this.targetUserId_absent ? this.targetUserId_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isTargetApplicationIdPresent() {
/* 605 */     return !this.targetApplicationId_absent;
/*     */   }
/*     */   
/*     */   public String targetApplicationIdOrElse(String defaultValue) {
/* 609 */     return !this.targetApplicationId_absent ? this.targetApplicationId_value : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 628 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "InviteCreateRequest", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/* 640 */     private Possible<Integer> maxAge_possible = Possible.absent();
/* 641 */     private Possible<Integer> maxUses_possible = Possible.absent();
/* 642 */     private Possible<Boolean> temporary_possible = Possible.absent();
/* 643 */     private Possible<Boolean> unique_possible = Possible.absent();
/* 644 */     private Possible<Integer> targetType_possible = Possible.absent();
/* 645 */     private Possible<String> targetUserId_possible = Possible.absent();
/* 646 */     private Possible<String> targetApplicationId_possible = Possible.absent();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(InviteCreateRequest instance) {
/* 659 */       Objects.requireNonNull(instance, "instance");
/* 660 */       maxAge(instance.maxAge());
/* 661 */       maxUses(instance.maxUses());
/* 662 */       temporary(instance.temporary());
/* 663 */       unique(instance.unique());
/* 664 */       targetType(instance.targetType());
/* 665 */       targetUserId(instance.targetUserId());
/* 666 */       targetApplicationId(instance.targetApplicationId());
/* 667 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("max_age")
/*     */     public Builder maxAge(Possible<Integer> value) {
/* 672 */       this.maxAge_possible = value;
/* 673 */       return this;
/*     */     }
/*     */     
/*     */     public Builder maxAge(Integer value) {
/* 677 */       this.maxAge_possible = Possible.of(value);
/* 678 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("max_uses")
/*     */     public Builder maxUses(Possible<Integer> value) {
/* 683 */       this.maxUses_possible = value;
/* 684 */       return this;
/*     */     }
/*     */     
/*     */     public Builder maxUses(Integer value) {
/* 688 */       this.maxUses_possible = Possible.of(value);
/* 689 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("temporary")
/*     */     public Builder temporary(Possible<Boolean> value) {
/* 694 */       this.temporary_possible = value;
/* 695 */       return this;
/*     */     }
/*     */     
/*     */     public Builder temporary(Boolean value) {
/* 699 */       this.temporary_possible = Possible.of(value);
/* 700 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("unique")
/*     */     public Builder unique(Possible<Boolean> value) {
/* 705 */       this.unique_possible = value;
/* 706 */       return this;
/*     */     }
/*     */     
/*     */     public Builder unique(Boolean value) {
/* 710 */       this.unique_possible = Possible.of(value);
/* 711 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("target_type")
/*     */     public Builder targetType(Possible<Integer> value) {
/* 716 */       this.targetType_possible = value;
/* 717 */       return this;
/*     */     }
/*     */     
/*     */     public Builder targetType(Integer value) {
/* 721 */       this.targetType_possible = Possible.of(value);
/* 722 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("target_user_id")
/*     */     public Builder targetUserId(Possible<String> value) {
/* 727 */       this.targetUserId_possible = value;
/* 728 */       return this;
/*     */     }
/*     */     
/*     */     public Builder targetUserId(String value) {
/* 732 */       this.targetUserId_possible = Possible.of(value);
/* 733 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("target_application_id")
/*     */     public Builder targetApplicationId(Possible<String> value) {
/* 738 */       this.targetApplicationId_possible = value;
/* 739 */       return this;
/*     */     }
/*     */     
/*     */     public Builder targetApplicationId(String value) {
/* 743 */       this.targetApplicationId_possible = Possible.of(value);
/* 744 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableInviteCreateRequest build() {
/* 753 */       return new ImmutableInviteCreateRequest(null, 
/*     */           
/* 755 */           maxAge_build(), 
/* 756 */           maxUses_build(), 
/* 757 */           temporary_build(), 
/* 758 */           unique_build(), 
/* 759 */           targetType_build(), 
/* 760 */           targetUserId_build(), 
/* 761 */           targetApplicationId_build());
/*     */     }
/*     */     
/*     */     private Possible<Integer> maxAge_build() {
/* 765 */       return this.maxAge_possible;
/*     */     }
/*     */     
/*     */     private Possible<Integer> maxUses_build() {
/* 769 */       return this.maxUses_possible;
/*     */     }
/*     */     
/*     */     private Possible<Boolean> temporary_build() {
/* 773 */       return this.temporary_possible;
/*     */     }
/*     */     
/*     */     private Possible<Boolean> unique_build() {
/* 777 */       return this.unique_possible;
/*     */     }
/*     */     
/*     */     private Possible<Integer> targetType_build() {
/* 781 */       return this.targetType_possible;
/*     */     }
/*     */     
/*     */     private Possible<String> targetUserId_build() {
/* 785 */       return this.targetUserId_possible;
/*     */     }
/*     */     
/*     */     private Possible<String> targetApplicationId_build() {
/* 789 */       return this.targetApplicationId_possible;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableInviteCreateRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */