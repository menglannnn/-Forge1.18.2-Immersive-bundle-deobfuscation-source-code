/*    */ package discord4j.discordjson.json;
/*    */ 
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import discord4j.discordjson.Id;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ @JsonSerialize(as = ImmutableApplicationCommandPermissionsData.class)
/*    */ @JsonDeserialize(as = ImmutableApplicationCommandPermissionsData.class)
/*    */ @Immutable
/*    */ public interface ApplicationCommandPermissionsData
/*    */ {
/*    */   static ImmutableApplicationCommandPermissionsData.Builder builder() {
/* 14 */     return ImmutableApplicationCommandPermissionsData.builder();
/*    */   }
/*    */   
/*    */   Id id();
/*    */   
/*    */   int type();
/*    */   
/*    */   boolean permission();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ApplicationCommandPermissionsData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */