/*      */ package discord4j.discordjson.json;
/*      */ 
/*      */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*      */ import com.fasterxml.jackson.annotation.JsonCreator;
/*      */ import com.fasterxml.jackson.annotation.JsonProperty;
/*      */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*      */ import discord4j.discordjson.Id;
/*      */ import discord4j.discordjson.possible.Possible;
/*      */ import java.util.ArrayList;
/*      */ import java.util.List;
/*      */ import java.util.Objects;
/*      */ import java.util.Optional;
/*      */ import org.immutables.value.Generated;
/*      */ import reactor.util.annotation.Nullable;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ @Generated(from = "RoleTemplateData", generator = "Immutables")
/*      */ public final class ImmutableRoleTemplateData
/*      */   implements RoleTemplateData
/*      */ {
/*      */   private final long id_value;
/*      */   private final String name;
/*      */   private final int color;
/*      */   private final boolean hoist;
/*      */   private final long permissions;
/*      */   private final boolean mentionable;
/*      */   private final String icon_value;
/*      */   private final boolean icon_absent;
/*      */   private final String unicodeEmoji_value;
/*      */   private final boolean unicodeEmoji_absent;
/*      */   private final RoleTagsData tags_value;
/*      */   private final boolean tags_absent;
/*      */   private static final byte STAGE_INITIALIZING = -1;
/*      */   private static final byte STAGE_UNINITIALIZED = 0;
/*      */   private static final byte STAGE_INITIALIZED = 1;
/*      */   
/*      */   private ImmutableRoleTemplateData(Id id, String name, int color, boolean hoist, long permissions, boolean mentionable, Possible<Optional<String>> icon, Possible<Optional<String>> unicodeEmoji, Possible<RoleTagsData> tags) {
/*   51 */     Id id$impl = id;
/*   52 */     this.name = Objects.<String>requireNonNull(name, "name");
/*   53 */     this.color = color;
/*   54 */     this.hoist = hoist;
/*   55 */     this.permissions = permissions;
/*   56 */     this.mentionable = mentionable;
/*   57 */     Possible<Optional<String>> icon$impl = icon;
/*   58 */     Possible<Optional<String>> unicodeEmoji$impl = unicodeEmoji;
/*   59 */     Possible<RoleTagsData> tags$impl = tags;
/*   60 */     this.id_value = id$impl.asLong();
/*   61 */     this.icon_value = Possible.flatOpt(icon$impl).orElse(null);
/*   62 */     this.icon_absent = icon$impl.isAbsent();
/*   63 */     this.unicodeEmoji_value = Possible.flatOpt(unicodeEmoji$impl).orElse(null);
/*   64 */     this.unicodeEmoji_absent = unicodeEmoji$impl.isAbsent();
/*   65 */     this.tags_value = tags$impl.toOptional().orElse(null);
/*   66 */     this.tags_absent = tags$impl.isAbsent();
/*   67 */     this.initShim = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ImmutableRoleTemplateData(ImmutableRoleTemplateData original, Id id, String name, int color, boolean hoist, long permissions, boolean mentionable, Possible<Optional<String>> icon, Possible<Optional<String>> unicodeEmoji, Possible<RoleTagsData> tags) {
/*   81 */     Id id$impl = id;
/*   82 */     this.name = name;
/*   83 */     this.color = color;
/*   84 */     this.hoist = hoist;
/*   85 */     this.permissions = permissions;
/*   86 */     this.mentionable = mentionable;
/*   87 */     Possible<Optional<String>> icon$impl = icon;
/*   88 */     Possible<Optional<String>> unicodeEmoji$impl = unicodeEmoji;
/*   89 */     Possible<RoleTagsData> tags$impl = tags;
/*   90 */     this.id_value = id$impl.asLong();
/*   91 */     this.icon_value = Possible.flatOpt(icon$impl).orElse(null);
/*   92 */     this.icon_absent = icon$impl.isAbsent();
/*   93 */     this.unicodeEmoji_value = Possible.flatOpt(unicodeEmoji$impl).orElse(null);
/*   94 */     this.unicodeEmoji_absent = unicodeEmoji$impl.isAbsent();
/*   95 */     this.tags_value = tags$impl.toOptional().orElse(null);
/*   96 */     this.tags_absent = tags$impl.isAbsent();
/*   97 */     this.initShim = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  103 */   private volatile transient InitShim initShim = new InitShim();
/*      */   
/*      */   @Generated(from = "RoleTemplateData", generator = "Immutables")
/*      */   private final class InitShim {
/*      */     private String formatInitCycleMessage() {
/*  108 */       List<String> attributes = new ArrayList<>();
/*  109 */       return "Cannot build RoleTemplateData, attribute initializers form cycle " + attributes;
/*      */     }
/*      */ 
/*      */     
/*      */     private InitShim() {}
/*      */   }
/*      */ 
/*      */   
/*      */   @JsonProperty("id")
/*      */   public Id id() {
/*  119 */     return Id.of(this.id_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("name")
/*      */   public String name() {
/*  128 */     return this.name;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("color")
/*      */   public int color() {
/*  137 */     return this.color;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("hoist")
/*      */   public boolean hoist() {
/*  146 */     return this.hoist;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("permissions")
/*      */   public long permissions() {
/*  155 */     return this.permissions;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("mentionable")
/*      */   public boolean mentionable() {
/*  164 */     return this.mentionable;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("icon")
/*      */   public Possible<Optional<String>> icon() {
/*  173 */     return this.icon_absent ? Possible.absent() : 
/*  174 */       Possible.of(Optional.ofNullable(this.icon_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("unicode_emoji")
/*      */   public Possible<Optional<String>> unicodeEmoji() {
/*  183 */     return this.unicodeEmoji_absent ? Possible.absent() : 
/*  184 */       Possible.of(Optional.ofNullable(this.unicodeEmoji_value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("tags")
/*      */   public Possible<RoleTagsData> tags() {
/*  193 */     return this.tags_absent ? Possible.absent() : Possible.of(this.tags_value);
/*      */   }
/*      */   
/*      */   public ImmutableRoleTemplateData withId(long value) {
/*  197 */     Id newValue = Id.of(value);
/*  198 */     return new ImmutableRoleTemplateData(this, newValue, this.name, this.color, this.hoist, this.permissions, this.mentionable, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  206 */         icon(), 
/*  207 */         unicodeEmoji(), 
/*  208 */         tags());
/*      */   }
/*      */   
/*      */   public ImmutableRoleTemplateData withId(String value) {
/*  212 */     Id newValue = Id.of(value);
/*  213 */     return new ImmutableRoleTemplateData(this, newValue, this.name, this.color, this.hoist, this.permissions, this.mentionable, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  221 */         icon(), 
/*  222 */         unicodeEmoji(), 
/*  223 */         tags());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableRoleTemplateData withName(String value) {
/*  233 */     String newValue = Objects.<String>requireNonNull(value, "name");
/*  234 */     if (this.name.equals(newValue)) return this; 
/*  235 */     return new ImmutableRoleTemplateData(this, 
/*      */         
/*  237 */         id(), newValue, this.color, this.hoist, this.permissions, this.mentionable, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  243 */         icon(), 
/*  244 */         unicodeEmoji(), 
/*  245 */         tags());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableRoleTemplateData withColor(int value) {
/*  255 */     if (this.color == value) return this; 
/*  256 */     return new ImmutableRoleTemplateData(this, 
/*      */         
/*  258 */         id(), this.name, value, this.hoist, this.permissions, this.mentionable, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  264 */         icon(), 
/*  265 */         unicodeEmoji(), 
/*  266 */         tags());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableRoleTemplateData withHoist(boolean value) {
/*  276 */     if (this.hoist == value) return this; 
/*  277 */     return new ImmutableRoleTemplateData(this, 
/*      */         
/*  279 */         id(), this.name, this.color, value, this.permissions, this.mentionable, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  285 */         icon(), 
/*  286 */         unicodeEmoji(), 
/*  287 */         tags());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableRoleTemplateData withPermissions(long value) {
/*  297 */     if (this.permissions == value) return this; 
/*  298 */     return new ImmutableRoleTemplateData(this, 
/*      */         
/*  300 */         id(), this.name, this.color, this.hoist, value, this.mentionable, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  306 */         icon(), 
/*  307 */         unicodeEmoji(), 
/*  308 */         tags());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableRoleTemplateData withMentionable(boolean value) {
/*  318 */     if (this.mentionable == value) return this; 
/*  319 */     return new ImmutableRoleTemplateData(this, 
/*      */         
/*  321 */         id(), this.name, this.color, this.hoist, this.permissions, value, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  327 */         icon(), 
/*  328 */         unicodeEmoji(), 
/*  329 */         tags());
/*      */   }
/*      */   
/*      */   public ImmutableRoleTemplateData withIcon(Possible<Optional<String>> value) {
/*  333 */     Possible<Optional<String>> newValue = Objects.<Possible<Optional<String>>>requireNonNull(value);
/*  334 */     return new ImmutableRoleTemplateData(this, 
/*      */         
/*  336 */         id(), this.name, this.color, this.hoist, this.permissions, this.mentionable, newValue, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  343 */         unicodeEmoji(), 
/*  344 */         tags());
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public ImmutableRoleTemplateData withIcon(@Nullable String value) {
/*  349 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/*  350 */     return new ImmutableRoleTemplateData(this, 
/*      */         
/*  352 */         id(), this.name, this.color, this.hoist, this.permissions, this.mentionable, newValue, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  359 */         unicodeEmoji(), 
/*  360 */         tags());
/*      */   }
/*      */   
/*      */   public ImmutableRoleTemplateData withIconOrNull(@Nullable String value) {
/*  364 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/*  365 */     return new ImmutableRoleTemplateData(this, 
/*      */         
/*  367 */         id(), this.name, this.color, this.hoist, this.permissions, this.mentionable, newValue, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  374 */         unicodeEmoji(), 
/*  375 */         tags());
/*      */   }
/*      */   
/*      */   public ImmutableRoleTemplateData withUnicodeEmoji(Possible<Optional<String>> value) {
/*  379 */     Possible<Optional<String>> newValue = Objects.<Possible<Optional<String>>>requireNonNull(value);
/*  380 */     return new ImmutableRoleTemplateData(this, 
/*      */         
/*  382 */         id(), this.name, this.color, this.hoist, this.permissions, this.mentionable, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  388 */         icon(), newValue, 
/*      */         
/*  390 */         tags());
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public ImmutableRoleTemplateData withUnicodeEmoji(@Nullable String value) {
/*  395 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/*  396 */     return new ImmutableRoleTemplateData(this, 
/*      */         
/*  398 */         id(), this.name, this.color, this.hoist, this.permissions, this.mentionable, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  404 */         icon(), newValue, 
/*      */         
/*  406 */         tags());
/*      */   }
/*      */   
/*      */   public ImmutableRoleTemplateData withUnicodeEmojiOrNull(@Nullable String value) {
/*  410 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/*  411 */     return new ImmutableRoleTemplateData(this, 
/*      */         
/*  413 */         id(), this.name, this.color, this.hoist, this.permissions, this.mentionable, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  419 */         icon(), newValue, 
/*      */         
/*  421 */         tags());
/*      */   }
/*      */   
/*      */   public ImmutableRoleTemplateData withTags(Possible<RoleTagsData> value) {
/*  425 */     Possible<RoleTagsData> newValue = Objects.<Possible<RoleTagsData>>requireNonNull(value);
/*  426 */     return new ImmutableRoleTemplateData(this, 
/*      */         
/*  428 */         id(), this.name, this.color, this.hoist, this.permissions, this.mentionable, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  434 */         icon(), 
/*  435 */         unicodeEmoji(), newValue);
/*      */   }
/*      */ 
/*      */   
/*      */   public ImmutableRoleTemplateData withTags(RoleTagsData value) {
/*  440 */     Possible<RoleTagsData> newValue = Possible.of(value);
/*  441 */     return new ImmutableRoleTemplateData(this, 
/*      */         
/*  443 */         id(), this.name, this.color, this.hoist, this.permissions, this.mentionable, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  449 */         icon(), 
/*  450 */         unicodeEmoji(), newValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean equals(Object another) {
/*  460 */     if (this == another) return true; 
/*  461 */     return (another instanceof ImmutableRoleTemplateData && 
/*  462 */       equalTo(0, (ImmutableRoleTemplateData)another));
/*      */   }
/*      */   
/*      */   private boolean equalTo(int synthetic, ImmutableRoleTemplateData another) {
/*  466 */     return (Objects.equals(Long.valueOf(this.id_value), Long.valueOf(another.id_value)) && this.name
/*  467 */       .equals(another.name) && this.color == another.color && this.hoist == another.hoist && this.permissions == another.permissions && this.mentionable == another.mentionable && 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  472 */       icon().equals(another.icon()) && 
/*  473 */       unicodeEmoji().equals(another.unicodeEmoji()) && 
/*  474 */       tags().equals(another.tags()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int hashCode() {
/*  483 */     int h = 5381;
/*  484 */     h += (h << 5) + Objects.hashCode(Long.valueOf(this.id_value));
/*  485 */     h += (h << 5) + this.name.hashCode();
/*  486 */     h += (h << 5) + this.color;
/*  487 */     h += (h << 5) + Boolean.hashCode(this.hoist);
/*  488 */     h += (h << 5) + Long.hashCode(this.permissions);
/*  489 */     h += (h << 5) + Boolean.hashCode(this.mentionable);
/*  490 */     h += (h << 5) + icon().hashCode();
/*  491 */     h += (h << 5) + unicodeEmoji().hashCode();
/*  492 */     h += (h << 5) + tags().hashCode();
/*  493 */     return h;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/*  502 */     return "RoleTemplateData{id=" + 
/*  503 */       Objects.toString(Long.valueOf(this.id_value)) + ", name=" + this.name + ", color=" + this.color + ", hoist=" + this.hoist + ", permissions=" + this.permissions + ", mentionable=" + this.mentionable + ", icon=" + 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  509 */       icon().toString() + ", unicodeEmoji=" + 
/*  510 */       unicodeEmoji().toString() + ", tags=" + 
/*  511 */       tags().toString() + "}";
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonDeserialize
/*      */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*      */   @Generated(from = "RoleTemplateData", generator = "Immutables")
/*      */   static final class Json
/*      */     implements RoleTemplateData
/*      */   {
/*      */     Id id;
/*      */     
/*      */     String name;
/*      */     
/*      */     int color;
/*      */     
/*      */     boolean colorIsSet;
/*      */     boolean hoist;
/*      */     boolean hoistIsSet;
/*      */     long permissions;
/*      */     boolean permissionsIsSet;
/*      */     boolean mentionable;
/*      */     boolean mentionableIsSet;
/*  535 */     Possible<Optional<String>> icon = Possible.absent();
/*      */ 
/*      */     
/*  538 */     Possible<Optional<String>> unicodeEmoji = Possible.absent();
/*      */ 
/*      */     
/*  541 */     Possible<RoleTagsData> tags = Possible.absent();
/*      */     
/*      */     @JsonProperty("id")
/*      */     public void setId(Id id) {
/*  545 */       this.id = id;
/*      */     }
/*      */     @JsonProperty("name")
/*      */     public void setName(String name) {
/*  549 */       this.name = name;
/*      */     }
/*      */     @JsonProperty("color")
/*      */     public void setColor(int color) {
/*  553 */       this.color = color;
/*  554 */       this.colorIsSet = true;
/*      */     }
/*      */     @JsonProperty("hoist")
/*      */     public void setHoist(boolean hoist) {
/*  558 */       this.hoist = hoist;
/*  559 */       this.hoistIsSet = true;
/*      */     }
/*      */     @JsonProperty("permissions")
/*      */     public void setPermissions(long permissions) {
/*  563 */       this.permissions = permissions;
/*  564 */       this.permissionsIsSet = true;
/*      */     }
/*      */     @JsonProperty("mentionable")
/*      */     public void setMentionable(boolean mentionable) {
/*  568 */       this.mentionable = mentionable;
/*  569 */       this.mentionableIsSet = true;
/*      */     }
/*      */     @JsonProperty("icon")
/*      */     public void setIcon(Possible<Optional<String>> icon) {
/*  573 */       this.icon = icon;
/*      */     }
/*      */     @JsonProperty("unicode_emoji")
/*      */     public void setUnicodeEmoji(Possible<Optional<String>> unicodeEmoji) {
/*  577 */       this.unicodeEmoji = unicodeEmoji;
/*      */     }
/*      */     @JsonProperty("tags")
/*      */     public void setTags(Possible<RoleTagsData> tags) {
/*  581 */       this.tags = tags;
/*      */     }
/*      */     public Id id() {
/*  584 */       throw new UnsupportedOperationException();
/*      */     } public String name() {
/*  586 */       throw new UnsupportedOperationException();
/*      */     } public int color() {
/*  588 */       throw new UnsupportedOperationException();
/*      */     } public boolean hoist() {
/*  590 */       throw new UnsupportedOperationException();
/*      */     } public long permissions() {
/*  592 */       throw new UnsupportedOperationException();
/*      */     } public boolean mentionable() {
/*  594 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Optional<String>> icon() {
/*  596 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Optional<String>> unicodeEmoji() {
/*  598 */       throw new UnsupportedOperationException();
/*      */     } public Possible<RoleTagsData> tags() {
/*  600 */       throw new UnsupportedOperationException();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*      */   static ImmutableRoleTemplateData fromJson(Json json) {
/*  611 */     Builder builder = builder();
/*  612 */     if (json.id != null) {
/*  613 */       builder.id(json.id);
/*      */     }
/*  615 */     if (json.name != null) {
/*  616 */       builder.name(json.name);
/*      */     }
/*  618 */     if (json.colorIsSet) {
/*  619 */       builder.color(json.color);
/*      */     }
/*  621 */     if (json.hoistIsSet) {
/*  622 */       builder.hoist(json.hoist);
/*      */     }
/*  624 */     if (json.permissionsIsSet) {
/*  625 */       builder.permissions(json.permissions);
/*      */     }
/*  627 */     if (json.mentionableIsSet) {
/*  628 */       builder.mentionable(json.mentionable);
/*      */     }
/*  630 */     if (json.icon != null) {
/*  631 */       builder.icon(json.icon);
/*      */     }
/*  633 */     if (json.unicodeEmoji != null) {
/*  634 */       builder.unicodeEmoji(json.unicodeEmoji);
/*      */     }
/*  636 */     if (json.tags != null) {
/*  637 */       builder.tags(json.tags);
/*      */     }
/*  639 */     return builder.build();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableRoleTemplateData of(Id id, String name, int color, boolean hoist, long permissions, boolean mentionable, Possible<Optional<String>> icon, Possible<Optional<String>> unicodeEmoji, Possible<RoleTagsData> tags) {
/*  656 */     return new ImmutableRoleTemplateData(id, name, color, hoist, permissions, mentionable, icon, unicodeEmoji, tags);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableRoleTemplateData copyOf(RoleTemplateData instance) {
/*  667 */     if (instance instanceof ImmutableRoleTemplateData) {
/*  668 */       return (ImmutableRoleTemplateData)instance;
/*      */     }
/*  670 */     return builder()
/*  671 */       .from(instance)
/*  672 */       .build();
/*      */   }
/*      */   
/*      */   public boolean isIconPresent() {
/*  676 */     return !this.icon_absent;
/*      */   }
/*      */   
/*      */   public String iconOrElse(String defaultValue) {
/*  680 */     return !this.icon_absent ? this.icon_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isUnicodeEmojiPresent() {
/*  684 */     return !this.unicodeEmoji_absent;
/*      */   }
/*      */   
/*      */   public String unicodeEmojiOrElse(String defaultValue) {
/*  688 */     return !this.unicodeEmoji_absent ? this.unicodeEmoji_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isTagsPresent() {
/*  692 */     return !this.tags_absent;
/*      */   }
/*      */   
/*      */   public RoleTagsData tagsOrElse(RoleTagsData defaultValue) {
/*  696 */     return !this.tags_absent ? this.tags_value : defaultValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Builder builder() {
/*  717 */     return new Builder();
/*      */   }
/*      */ 
/*      */   
/*      */   @Generated(from = "RoleTemplateData", generator = "Immutables")
/*      */   public static final class Builder
/*      */   {
/*      */     private static final long INIT_BIT_NAME = 1L;
/*      */     
/*      */     private static final long INIT_BIT_COLOR = 2L;
/*      */     
/*      */     private static final long INIT_BIT_HOIST = 4L;
/*      */     
/*      */     private static final long INIT_BIT_PERMISSIONS = 8L;
/*      */     
/*      */     private static final long INIT_BIT_MENTIONABLE = 16L;
/*      */     
/*  734 */     private long initBits = 31L;
/*      */     
/*  736 */     private Id id_id = null;
/*  737 */     private Possible<Optional<String>> icon_possible = Possible.absent();
/*  738 */     private Possible<Optional<String>> unicodeEmoji_possible = Possible.absent();
/*  739 */     private Possible<RoleTagsData> tags_possible = Possible.absent();
/*      */ 
/*      */     
/*      */     private String name;
/*      */ 
/*      */     
/*      */     private int color;
/*      */     
/*      */     private boolean hoist;
/*      */     
/*      */     private long permissions;
/*      */     
/*      */     private boolean mentionable;
/*      */ 
/*      */     
/*      */     public final Builder from(RoleDataFields instance) {
/*  755 */       Objects.requireNonNull(instance, "instance");
/*  756 */       from(instance);
/*  757 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder from(RoleTemplateData instance) {
/*  766 */       Objects.requireNonNull(instance, "instance");
/*  767 */       from(instance);
/*  768 */       return this;
/*      */     }
/*      */     
/*      */     private void from(Object object) {
/*  772 */       long bits = 0L;
/*  773 */       if (object instanceof RoleDataFields) {
/*  774 */         RoleDataFields instance = (RoleDataFields)object;
/*  775 */         if ((bits & 0x1L) == 0L) {
/*  776 */           color(instance.color());
/*  777 */           bits |= 0x1L;
/*      */         } 
/*  779 */         if ((bits & 0x2L) == 0L) {
/*  780 */           permissions(instance.permissions());
/*  781 */           bits |= 0x2L;
/*      */         } 
/*  783 */         if ((bits & 0x4L) == 0L) {
/*  784 */           name(instance.name());
/*  785 */           bits |= 0x4L;
/*      */         } 
/*  787 */         if ((bits & 0x8L) == 0L) {
/*  788 */           icon(instance.icon());
/*  789 */           bits |= 0x8L;
/*      */         } 
/*  791 */         if ((bits & 0x10L) == 0L) {
/*  792 */           mentionable(instance.mentionable());
/*  793 */           bits |= 0x10L;
/*      */         } 
/*  795 */         if ((bits & 0x20L) == 0L) {
/*  796 */           id(instance.id());
/*  797 */           bits |= 0x20L;
/*      */         } 
/*  799 */         if ((bits & 0x40L) == 0L) {
/*  800 */           hoist(instance.hoist());
/*  801 */           bits |= 0x40L;
/*      */         } 
/*  803 */         if ((bits & 0x80L) == 0L) {
/*  804 */           unicodeEmoji(instance.unicodeEmoji());
/*  805 */           bits |= 0x80L;
/*      */         } 
/*  807 */         if ((bits & 0x100L) == 0L) {
/*  808 */           tags(instance.tags());
/*  809 */           bits |= 0x100L;
/*      */         } 
/*      */       } 
/*  812 */       if (object instanceof RoleTemplateData) {
/*  813 */         RoleTemplateData instance = (RoleTemplateData)object;
/*  814 */         if ((bits & 0x1L) == 0L) {
/*  815 */           color(instance.color());
/*  816 */           bits |= 0x1L;
/*      */         } 
/*  818 */         if ((bits & 0x2L) == 0L) {
/*  819 */           permissions(instance.permissions());
/*  820 */           bits |= 0x2L;
/*      */         } 
/*  822 */         if ((bits & 0x4L) == 0L) {
/*  823 */           name(instance.name());
/*  824 */           bits |= 0x4L;
/*      */         } 
/*  826 */         if ((bits & 0x8L) == 0L) {
/*  827 */           icon(instance.icon());
/*  828 */           bits |= 0x8L;
/*      */         } 
/*  830 */         if ((bits & 0x10L) == 0L) {
/*  831 */           mentionable(instance.mentionable());
/*  832 */           bits |= 0x10L;
/*      */         } 
/*  834 */         if ((bits & 0x20L) == 0L) {
/*  835 */           id(instance.id());
/*  836 */           bits |= 0x20L;
/*      */         } 
/*  838 */         if ((bits & 0x40L) == 0L) {
/*  839 */           hoist(instance.hoist());
/*  840 */           bits |= 0x40L;
/*      */         } 
/*  842 */         if ((bits & 0x80L) == 0L) {
/*  843 */           unicodeEmoji(instance.unicodeEmoji());
/*  844 */           bits |= 0x80L;
/*      */         } 
/*  846 */         if ((bits & 0x100L) == 0L) {
/*  847 */           tags(instance.tags());
/*  848 */           bits |= 0x100L;
/*      */         } 
/*      */       } 
/*      */     }
/*      */     
/*      */     public Builder id(String value) {
/*  854 */       this.id_id = Id.of(value);
/*  855 */       return this;
/*      */     }
/*      */     
/*      */     public Builder id(long value) {
/*  859 */       this.id_id = Id.of(value);
/*  860 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("id")
/*      */     public Builder id(Id value) {
/*  865 */       this.id_id = value;
/*  866 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("name")
/*      */     public final Builder name(String name) {
/*  876 */       this.name = Objects.<String>requireNonNull(name, "name");
/*  877 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/*  878 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("color")
/*      */     public final Builder color(int color) {
/*  888 */       this.color = color;
/*  889 */       this.initBits &= 0xFFFFFFFFFFFFFFFDL;
/*  890 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("hoist")
/*      */     public final Builder hoist(boolean hoist) {
/*  900 */       this.hoist = hoist;
/*  901 */       this.initBits &= 0xFFFFFFFFFFFFFFFBL;
/*  902 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("permissions")
/*      */     public final Builder permissions(long permissions) {
/*  912 */       this.permissions = permissions;
/*  913 */       this.initBits &= 0xFFFFFFFFFFFFFFF7L;
/*  914 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("mentionable")
/*      */     public final Builder mentionable(boolean mentionable) {
/*  924 */       this.mentionable = mentionable;
/*  925 */       this.initBits &= 0xFFFFFFFFFFFFFFEFL;
/*  926 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("icon")
/*      */     public Builder icon(Possible<Optional<String>> value) {
/*  931 */       this.icon_possible = value;
/*  932 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public Builder icon(@Nullable String value) {
/*  937 */       this.icon_possible = Possible.of(Optional.ofNullable(value));
/*  938 */       return this;
/*      */     }
/*      */     
/*      */     public Builder iconOrNull(@Nullable String value) {
/*  942 */       this.icon_possible = Possible.of(Optional.ofNullable(value));
/*  943 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("unicode_emoji")
/*      */     public Builder unicodeEmoji(Possible<Optional<String>> value) {
/*  948 */       this.unicodeEmoji_possible = value;
/*  949 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public Builder unicodeEmoji(@Nullable String value) {
/*  954 */       this.unicodeEmoji_possible = Possible.of(Optional.ofNullable(value));
/*  955 */       return this;
/*      */     }
/*      */     
/*      */     public Builder unicodeEmojiOrNull(@Nullable String value) {
/*  959 */       this.unicodeEmoji_possible = Possible.of(Optional.ofNullable(value));
/*  960 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("tags")
/*      */     public Builder tags(Possible<RoleTagsData> value) {
/*  965 */       this.tags_possible = value;
/*  966 */       return this;
/*      */     }
/*      */     
/*      */     public Builder tags(RoleTagsData value) {
/*  970 */       this.tags_possible = Possible.of(value);
/*  971 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ImmutableRoleTemplateData build() {
/*  980 */       if (this.initBits != 0L) {
/*  981 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*      */       }
/*  983 */       return new ImmutableRoleTemplateData(null, 
/*      */           
/*  985 */           id_build(), this.name, this.color, this.hoist, this.permissions, this.mentionable, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  991 */           icon_build(), 
/*  992 */           unicodeEmoji_build(), 
/*  993 */           tags_build());
/*      */     }
/*      */     
/*      */     private String formatRequiredAttributesMessage() {
/*  997 */       List<String> attributes = new ArrayList<>();
/*  998 */       if ((this.initBits & 0x1L) != 0L) attributes.add("name"); 
/*  999 */       if ((this.initBits & 0x2L) != 0L) attributes.add("color"); 
/* 1000 */       if ((this.initBits & 0x4L) != 0L) attributes.add("hoist"); 
/* 1001 */       if ((this.initBits & 0x8L) != 0L) attributes.add("permissions"); 
/* 1002 */       if ((this.initBits & 0x10L) != 0L) attributes.add("mentionable"); 
/* 1003 */       return "Cannot build RoleTemplateData, some of required attributes are not set " + attributes;
/*      */     }
/*      */     
/*      */     private Id id_build() {
/* 1007 */       return this.id_id;
/*      */     }
/*      */     
/*      */     private Possible<Optional<String>> icon_build() {
/* 1011 */       return this.icon_possible;
/*      */     }
/*      */     
/*      */     private Possible<Optional<String>> unicodeEmoji_build() {
/* 1015 */       return this.unicodeEmoji_possible;
/*      */     }
/*      */     
/*      */     private Possible<RoleTagsData> tags_build() {
/* 1019 */       return this.tags_possible;
/*      */     }
/*      */     
/*      */     private Builder() {}
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableRoleTemplateData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */