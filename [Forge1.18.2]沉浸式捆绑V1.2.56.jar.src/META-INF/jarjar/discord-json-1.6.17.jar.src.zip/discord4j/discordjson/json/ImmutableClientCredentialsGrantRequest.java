/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "ClientCredentialsGrantRequest", generator = "Immutables")
/*     */ public final class ImmutableClientCredentialsGrantRequest
/*     */   extends ClientCredentialsGrantRequest
/*     */ {
/*     */   private final long clientId;
/*     */   private final String clientSecret;
/*     */   private final String scope;
/*     */   
/*     */   private ImmutableClientCredentialsGrantRequest(long clientId, String clientSecret, String scope) {
/*  26 */     this.clientId = clientId;
/*  27 */     this.clientSecret = Objects.<String>requireNonNull(clientSecret, "clientSecret");
/*  28 */     this.scope = Objects.<String>requireNonNull(scope, "scope");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ImmutableClientCredentialsGrantRequest(ImmutableClientCredentialsGrantRequest original, long clientId, String clientSecret, String scope) {
/*  36 */     this.clientId = clientId;
/*  37 */     this.clientSecret = clientSecret;
/*  38 */     this.scope = scope;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long clientId() {
/*  46 */     return this.clientId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String clientSecret() {
/*  54 */     return this.clientSecret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String scope() {
/*  62 */     return this.scope;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableClientCredentialsGrantRequest withClientId(long value) {
/*  72 */     if (this.clientId == value) return this; 
/*  73 */     return new ImmutableClientCredentialsGrantRequest(this, value, this.clientSecret, this.scope);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableClientCredentialsGrantRequest withClientSecret(String value) {
/*  83 */     String newValue = Objects.<String>requireNonNull(value, "clientSecret");
/*  84 */     if (this.clientSecret.equals(newValue)) return this; 
/*  85 */     return new ImmutableClientCredentialsGrantRequest(this, this.clientId, newValue, this.scope);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableClientCredentialsGrantRequest withScope(String value) {
/*  95 */     String newValue = Objects.<String>requireNonNull(value, "scope");
/*  96 */     if (this.scope.equals(newValue)) return this; 
/*  97 */     return new ImmutableClientCredentialsGrantRequest(this, this.clientId, this.clientSecret, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 106 */     if (this == another) return true; 
/* 107 */     return (another instanceof ImmutableClientCredentialsGrantRequest && 
/* 108 */       equalTo(0, (ImmutableClientCredentialsGrantRequest)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableClientCredentialsGrantRequest another) {
/* 112 */     return (this.clientId == another.clientId && this.clientSecret
/* 113 */       .equals(another.clientSecret) && this.scope
/* 114 */       .equals(another.scope));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 123 */     int h = 5381;
/* 124 */     h += (h << 5) + Long.hashCode(this.clientId);
/* 125 */     h += (h << 5) + this.clientSecret.hashCode();
/* 126 */     h += (h << 5) + this.scope.hashCode();
/* 127 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableClientCredentialsGrantRequest of(long clientId, String clientSecret, String scope) {
/* 138 */     return new ImmutableClientCredentialsGrantRequest(clientId, clientSecret, scope);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableClientCredentialsGrantRequest copyOf(ClientCredentialsGrantRequest instance) {
/* 149 */     if (instance instanceof ImmutableClientCredentialsGrantRequest) {
/* 150 */       return (ImmutableClientCredentialsGrantRequest)instance;
/*     */     }
/* 152 */     return builder()
/* 153 */       .from(instance)
/* 154 */       .build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 169 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "ClientCredentialsGrantRequest", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_CLIENT_ID = 1L;
/*     */ 
/*     */     
/*     */     private static final long INIT_BIT_CLIENT_SECRET = 2L;
/*     */     
/*     */     private static final long INIT_BIT_SCOPE = 4L;
/*     */     
/* 184 */     private long initBits = 7L;
/*     */ 
/*     */ 
/*     */     
/*     */     private long clientId;
/*     */ 
/*     */ 
/*     */     
/*     */     private String clientSecret;
/*     */ 
/*     */ 
/*     */     
/*     */     private String scope;
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(ClientCredentialsGrantRequest instance) {
/* 201 */       Objects.requireNonNull(instance, "instance");
/* 202 */       clientId(instance.clientId());
/* 203 */       clientSecret(instance.clientSecret());
/* 204 */       scope(instance.scope());
/* 205 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder clientId(long clientId) {
/* 214 */       this.clientId = clientId;
/* 215 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 216 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder clientSecret(String clientSecret) {
/* 225 */       this.clientSecret = Objects.<String>requireNonNull(clientSecret, "clientSecret");
/* 226 */       this.initBits &= 0xFFFFFFFFFFFFFFFDL;
/* 227 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder scope(String scope) {
/* 236 */       this.scope = Objects.<String>requireNonNull(scope, "scope");
/* 237 */       this.initBits &= 0xFFFFFFFFFFFFFFFBL;
/* 238 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableClientCredentialsGrantRequest build() {
/* 247 */       if (this.initBits != 0L) {
/* 248 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 250 */       return new ImmutableClientCredentialsGrantRequest(null, this.clientId, this.clientSecret, this.scope);
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 254 */       List<String> attributes = new ArrayList<>();
/* 255 */       if ((this.initBits & 0x1L) != 0L) attributes.add("clientId"); 
/* 256 */       if ((this.initBits & 0x2L) != 0L) attributes.add("clientSecret"); 
/* 257 */       if ((this.initBits & 0x4L) != 0L) attributes.add("scope"); 
/* 258 */       return "Cannot build ClientCredentialsGrantRequest, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableClientCredentialsGrantRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */