/*    */ package discord4j.discordjson.json;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonProperty;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import java.util.Optional;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @JsonSerialize(as = ImmutableGuildEmbedModifyRequest.class)
/*    */ @JsonDeserialize(as = ImmutableGuildEmbedModifyRequest.class)
/*    */ @Deprecated
/*    */ @Immutable
/*    */ public interface GuildEmbedModifyRequest
/*    */ {
/*    */   static ImmutableGuildEmbedModifyRequest.Builder builder() {
/* 21 */     return ImmutableGuildEmbedModifyRequest.builder();
/*    */   }
/*    */   
/*    */   Possible<Boolean> enabled();
/*    */   
/*    */   @JsonProperty("channel_id")
/*    */   Possible<Optional<String>> channelId();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\GuildEmbedModifyRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */