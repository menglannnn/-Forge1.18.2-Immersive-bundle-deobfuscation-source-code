/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "TokenRevokeRequest", generator = "Immutables")
/*     */ public final class ImmutableTokenRevokeRequest
/*     */   extends TokenRevokeRequest
/*     */ {
/*     */   private final long clientId;
/*     */   private final String clientSecret;
/*     */   private final String token;
/*     */   
/*     */   private ImmutableTokenRevokeRequest(long clientId, String clientSecret, String token) {
/*  25 */     this.clientId = clientId;
/*  26 */     this.clientSecret = Objects.<String>requireNonNull(clientSecret, "clientSecret");
/*  27 */     this.token = Objects.<String>requireNonNull(token, "token");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ImmutableTokenRevokeRequest(ImmutableTokenRevokeRequest original, long clientId, String clientSecret, String token) {
/*  35 */     this.clientId = clientId;
/*  36 */     this.clientSecret = clientSecret;
/*  37 */     this.token = token;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long clientId() {
/*  45 */     return this.clientId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String clientSecret() {
/*  53 */     return this.clientSecret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String token() {
/*  61 */     return this.token;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableTokenRevokeRequest withClientId(long value) {
/*  71 */     if (this.clientId == value) return this; 
/*  72 */     return new ImmutableTokenRevokeRequest(this, value, this.clientSecret, this.token);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableTokenRevokeRequest withClientSecret(String value) {
/*  82 */     String newValue = Objects.<String>requireNonNull(value, "clientSecret");
/*  83 */     if (this.clientSecret.equals(newValue)) return this; 
/*  84 */     return new ImmutableTokenRevokeRequest(this, this.clientId, newValue, this.token);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableTokenRevokeRequest withToken(String value) {
/*  94 */     String newValue = Objects.<String>requireNonNull(value, "token");
/*  95 */     if (this.token.equals(newValue)) return this; 
/*  96 */     return new ImmutableTokenRevokeRequest(this, this.clientId, this.clientSecret, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 105 */     if (this == another) return true; 
/* 106 */     return (another instanceof ImmutableTokenRevokeRequest && 
/* 107 */       equalTo(0, (ImmutableTokenRevokeRequest)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableTokenRevokeRequest another) {
/* 111 */     return (this.clientId == another.clientId && this.clientSecret
/* 112 */       .equals(another.clientSecret) && this.token
/* 113 */       .equals(another.token));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 122 */     int h = 5381;
/* 123 */     h += (h << 5) + Long.hashCode(this.clientId);
/* 124 */     h += (h << 5) + this.clientSecret.hashCode();
/* 125 */     h += (h << 5) + this.token.hashCode();
/* 126 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableTokenRevokeRequest of(long clientId, String clientSecret, String token) {
/* 137 */     return new ImmutableTokenRevokeRequest(clientId, clientSecret, token);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableTokenRevokeRequest copyOf(TokenRevokeRequest instance) {
/* 148 */     if (instance instanceof ImmutableTokenRevokeRequest) {
/* 149 */       return (ImmutableTokenRevokeRequest)instance;
/*     */     }
/* 151 */     return builder()
/* 152 */       .from(instance)
/* 153 */       .build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 168 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "TokenRevokeRequest", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_CLIENT_ID = 1L;
/*     */ 
/*     */     
/*     */     private static final long INIT_BIT_CLIENT_SECRET = 2L;
/*     */     
/*     */     private static final long INIT_BIT_TOKEN = 4L;
/*     */     
/* 183 */     private long initBits = 7L;
/*     */ 
/*     */ 
/*     */     
/*     */     private long clientId;
/*     */ 
/*     */ 
/*     */     
/*     */     private String clientSecret;
/*     */ 
/*     */ 
/*     */     
/*     */     private String token;
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(TokenRevokeRequest instance) {
/* 200 */       Objects.requireNonNull(instance, "instance");
/* 201 */       clientId(instance.clientId());
/* 202 */       clientSecret(instance.clientSecret());
/* 203 */       token(instance.token());
/* 204 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder clientId(long clientId) {
/* 213 */       this.clientId = clientId;
/* 214 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 215 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder clientSecret(String clientSecret) {
/* 224 */       this.clientSecret = Objects.<String>requireNonNull(clientSecret, "clientSecret");
/* 225 */       this.initBits &= 0xFFFFFFFFFFFFFFFDL;
/* 226 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder token(String token) {
/* 235 */       this.token = Objects.<String>requireNonNull(token, "token");
/* 236 */       this.initBits &= 0xFFFFFFFFFFFFFFFBL;
/* 237 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableTokenRevokeRequest build() {
/* 246 */       if (this.initBits != 0L) {
/* 247 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 249 */       return new ImmutableTokenRevokeRequest(null, this.clientId, this.clientSecret, this.token);
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 253 */       List<String> attributes = new ArrayList<>();
/* 254 */       if ((this.initBits & 0x1L) != 0L) attributes.add("clientId"); 
/* 255 */       if ((this.initBits & 0x2L) != 0L) attributes.add("clientSecret"); 
/* 256 */       if ((this.initBits & 0x4L) != 0L) attributes.add("token"); 
/* 257 */       return "Cannot build TokenRevokeRequest, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableTokenRevokeRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */