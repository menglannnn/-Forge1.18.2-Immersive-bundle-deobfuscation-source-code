/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "NewsChannelFollowRequest", generator = "Immutables")
/*     */ public final class ImmutableNewsChannelFollowRequest
/*     */   implements NewsChannelFollowRequest
/*     */ {
/*     */   private final String webhookChannelId;
/*     */   
/*     */   private ImmutableNewsChannelFollowRequest(String webhookChannelId) {
/*  28 */     this.webhookChannelId = Objects.<String>requireNonNull(webhookChannelId, "webhookChannelId");
/*     */   }
/*     */   
/*     */   private ImmutableNewsChannelFollowRequest(ImmutableNewsChannelFollowRequest original, String webhookChannelId) {
/*  32 */     this.webhookChannelId = webhookChannelId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("webhook_channel_id")
/*     */   public String webhookChannelId() {
/*  41 */     return this.webhookChannelId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableNewsChannelFollowRequest withWebhookChannelId(String value) {
/*  51 */     String newValue = Objects.<String>requireNonNull(value, "webhookChannelId");
/*  52 */     if (this.webhookChannelId.equals(newValue)) return this; 
/*  53 */     return new ImmutableNewsChannelFollowRequest(this, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/*  62 */     if (this == another) return true; 
/*  63 */     return (another instanceof ImmutableNewsChannelFollowRequest && 
/*  64 */       equalTo(0, (ImmutableNewsChannelFollowRequest)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableNewsChannelFollowRequest another) {
/*  68 */     return this.webhookChannelId.equals(another.webhookChannelId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  77 */     int h = 5381;
/*  78 */     h += (h << 5) + this.webhookChannelId.hashCode();
/*  79 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/*  88 */     return "NewsChannelFollowRequest{webhookChannelId=" + this.webhookChannelId + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "NewsChannelFollowRequest", generator = "Immutables")
/*     */   static final class Json
/*     */     implements NewsChannelFollowRequest
/*     */   {
/*     */     String webhookChannelId;
/*     */ 
/*     */     
/*     */     @JsonProperty("webhook_channel_id")
/*     */     public void setWebhookChannelId(String webhookChannelId) {
/* 105 */       this.webhookChannelId = webhookChannelId;
/*     */     }
/*     */     public String webhookChannelId() {
/* 108 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableNewsChannelFollowRequest fromJson(Json json) {
/* 119 */     Builder builder = builder();
/* 120 */     if (json.webhookChannelId != null) {
/* 121 */       builder.webhookChannelId(json.webhookChannelId);
/*     */     }
/* 123 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableNewsChannelFollowRequest of(String webhookChannelId) {
/* 132 */     return new ImmutableNewsChannelFollowRequest(webhookChannelId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableNewsChannelFollowRequest copyOf(NewsChannelFollowRequest instance) {
/* 143 */     if (instance instanceof ImmutableNewsChannelFollowRequest) {
/* 144 */       return (ImmutableNewsChannelFollowRequest)instance;
/*     */     }
/* 146 */     return builder()
/* 147 */       .from(instance)
/* 148 */       .build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 161 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "NewsChannelFollowRequest", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_WEBHOOK_CHANNEL_ID = 1L;
/*     */ 
/*     */ 
/*     */     
/* 174 */     private long initBits = 1L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private String webhookChannelId;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(NewsChannelFollowRequest instance) {
/* 189 */       Objects.requireNonNull(instance, "instance");
/* 190 */       webhookChannelId(instance.webhookChannelId());
/* 191 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("webhook_channel_id")
/*     */     public final Builder webhookChannelId(String webhookChannelId) {
/* 201 */       this.webhookChannelId = Objects.<String>requireNonNull(webhookChannelId, "webhookChannelId");
/* 202 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 203 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableNewsChannelFollowRequest build() {
/* 212 */       if (this.initBits != 0L) {
/* 213 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 215 */       return new ImmutableNewsChannelFollowRequest(null, this.webhookChannelId);
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 219 */       List<String> attributes = new ArrayList<>();
/* 220 */       if ((this.initBits & 0x1L) != 0L) attributes.add("webhookChannelId"); 
/* 221 */       return "Cannot build NewsChannelFollowRequest, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableNewsChannelFollowRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */