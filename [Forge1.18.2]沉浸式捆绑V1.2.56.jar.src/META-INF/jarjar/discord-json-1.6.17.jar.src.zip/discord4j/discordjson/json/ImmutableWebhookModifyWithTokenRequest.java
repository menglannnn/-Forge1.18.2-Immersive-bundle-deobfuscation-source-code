/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "WebhookModifyWithTokenRequest", generator = "Immutables")
/*     */ public final class ImmutableWebhookModifyWithTokenRequest
/*     */   implements WebhookModifyWithTokenRequest
/*     */ {
/*     */   private final String name_value;
/*     */   private final boolean name_absent;
/*     */   private final String avatar_value;
/*     */   private final boolean avatar_absent;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   
/*     */   private ImmutableWebhookModifyWithTokenRequest(Possible<String> name, Possible<String> avatar) {
/*  34 */     Possible<String> name$impl = name;
/*  35 */     Possible<String> avatar$impl = avatar;
/*  36 */     this.name_value = name$impl.toOptional().orElse(null);
/*  37 */     this.name_absent = name$impl.isAbsent();
/*  38 */     this.avatar_value = avatar$impl.toOptional().orElse(null);
/*  39 */     this.avatar_absent = avatar$impl.isAbsent();
/*  40 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ImmutableWebhookModifyWithTokenRequest(ImmutableWebhookModifyWithTokenRequest original, Possible<String> name, Possible<String> avatar) {
/*  47 */     Possible<String> name$impl = name;
/*  48 */     Possible<String> avatar$impl = avatar;
/*  49 */     this.name_value = name$impl.toOptional().orElse(null);
/*  50 */     this.name_absent = name$impl.isAbsent();
/*  51 */     this.avatar_value = avatar$impl.toOptional().orElse(null);
/*  52 */     this.avatar_absent = avatar$impl.isAbsent();
/*  53 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  59 */   private volatile transient InitShim initShim = new InitShim();
/*     */   
/*     */   @Generated(from = "WebhookModifyWithTokenRequest", generator = "Immutables")
/*     */   private final class InitShim {
/*     */     private String formatInitCycleMessage() {
/*  64 */       List<String> attributes = new ArrayList<>();
/*  65 */       return "Cannot build WebhookModifyWithTokenRequest, attribute initializers form cycle " + attributes;
/*     */     }
/*     */ 
/*     */     
/*     */     private InitShim() {}
/*     */   }
/*     */ 
/*     */   
/*     */   @JsonProperty("name")
/*     */   public Possible<String> name() {
/*  75 */     return this.name_absent ? Possible.absent() : Possible.of(this.name_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("avatar")
/*     */   public Possible<String> avatar() {
/*  84 */     return this.avatar_absent ? Possible.absent() : Possible.of(this.avatar_value);
/*     */   }
/*     */   
/*     */   public ImmutableWebhookModifyWithTokenRequest withName(Possible<String> value) {
/*  88 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/*  89 */     return new ImmutableWebhookModifyWithTokenRequest(this, newValue, avatar());
/*     */   }
/*     */   
/*     */   public ImmutableWebhookModifyWithTokenRequest withName(String value) {
/*  93 */     Possible<String> newValue = Possible.of(value);
/*  94 */     return new ImmutableWebhookModifyWithTokenRequest(this, newValue, avatar());
/*     */   }
/*     */   
/*     */   public ImmutableWebhookModifyWithTokenRequest withAvatar(Possible<String> value) {
/*  98 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/*  99 */     return new ImmutableWebhookModifyWithTokenRequest(this, name(), newValue);
/*     */   }
/*     */   
/*     */   public ImmutableWebhookModifyWithTokenRequest withAvatar(String value) {
/* 103 */     Possible<String> newValue = Possible.of(value);
/* 104 */     return new ImmutableWebhookModifyWithTokenRequest(this, name(), newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 113 */     if (this == another) return true; 
/* 114 */     return (another instanceof ImmutableWebhookModifyWithTokenRequest && 
/* 115 */       equalTo(0, (ImmutableWebhookModifyWithTokenRequest)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableWebhookModifyWithTokenRequest another) {
/* 119 */     return (name().equals(another.name()) && 
/* 120 */       avatar().equals(another.avatar()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 129 */     int h = 5381;
/* 130 */     h += (h << 5) + name().hashCode();
/* 131 */     h += (h << 5) + avatar().hashCode();
/* 132 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 141 */     return "WebhookModifyWithTokenRequest{name=" + 
/* 142 */       name().toString() + ", avatar=" + 
/* 143 */       avatar().toString() + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "WebhookModifyWithTokenRequest", generator = "Immutables")
/*     */   static final class Json
/*     */     implements WebhookModifyWithTokenRequest
/*     */   {
/* 157 */     Possible<String> name = Possible.absent();
/*     */ 
/*     */     
/* 160 */     Possible<String> avatar = Possible.absent();
/*     */     
/*     */     @JsonProperty("name")
/*     */     public void setName(Possible<String> name) {
/* 164 */       this.name = name;
/*     */     }
/*     */     @JsonProperty("avatar")
/*     */     public void setAvatar(Possible<String> avatar) {
/* 168 */       this.avatar = avatar;
/*     */     }
/*     */     public Possible<String> name() {
/* 171 */       throw new UnsupportedOperationException();
/*     */     } public Possible<String> avatar() {
/* 173 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableWebhookModifyWithTokenRequest fromJson(Json json) {
/* 184 */     Builder builder = builder();
/* 185 */     if (json.name != null) {
/* 186 */       builder.name(json.name);
/*     */     }
/* 188 */     if (json.avatar != null) {
/* 189 */       builder.avatar(json.avatar);
/*     */     }
/* 191 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableWebhookModifyWithTokenRequest of(Possible<String> name, Possible<String> avatar) {
/* 201 */     return new ImmutableWebhookModifyWithTokenRequest(name, avatar);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableWebhookModifyWithTokenRequest copyOf(WebhookModifyWithTokenRequest instance) {
/* 212 */     if (instance instanceof ImmutableWebhookModifyWithTokenRequest) {
/* 213 */       return (ImmutableWebhookModifyWithTokenRequest)instance;
/*     */     }
/* 215 */     return builder()
/* 216 */       .from(instance)
/* 217 */       .build();
/*     */   }
/*     */   
/*     */   public boolean isNamePresent() {
/* 221 */     return !this.name_absent;
/*     */   }
/*     */   
/*     */   public String nameOrElse(String defaultValue) {
/* 225 */     return !this.name_absent ? this.name_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isAvatarPresent() {
/* 229 */     return !this.avatar_absent;
/*     */   }
/*     */   
/*     */   public String avatarOrElse(String defaultValue) {
/* 233 */     return !this.avatar_absent ? this.avatar_value : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 247 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "WebhookModifyWithTokenRequest", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/* 259 */     private Possible<String> name_possible = Possible.absent();
/* 260 */     private Possible<String> avatar_possible = Possible.absent();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(WebhookModifyWithTokenRequest instance) {
/* 273 */       Objects.requireNonNull(instance, "instance");
/* 274 */       name(instance.name());
/* 275 */       avatar(instance.avatar());
/* 276 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("name")
/*     */     public Builder name(Possible<String> value) {
/* 281 */       this.name_possible = value;
/* 282 */       return this;
/*     */     }
/*     */     
/*     */     public Builder name(String value) {
/* 286 */       this.name_possible = Possible.of(value);
/* 287 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("avatar")
/*     */     public Builder avatar(Possible<String> value) {
/* 292 */       this.avatar_possible = value;
/* 293 */       return this;
/*     */     }
/*     */     
/*     */     public Builder avatar(String value) {
/* 297 */       this.avatar_possible = Possible.of(value);
/* 298 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableWebhookModifyWithTokenRequest build() {
/* 307 */       return new ImmutableWebhookModifyWithTokenRequest(null, name_build(), avatar_build());
/*     */     }
/*     */     
/*     */     private Possible<String> name_build() {
/* 311 */       return this.name_possible;
/*     */     }
/*     */     
/*     */     private Possible<String> avatar_build() {
/* 315 */       return this.avatar_possible;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableWebhookModifyWithTokenRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */