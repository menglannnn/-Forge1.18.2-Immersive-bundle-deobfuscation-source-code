/*      */ package discord4j.discordjson.json;
/*      */ 
/*      */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*      */ import com.fasterxml.jackson.annotation.JsonCreator;
/*      */ import com.fasterxml.jackson.annotation.JsonProperty;
/*      */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*      */ import discord4j.discordjson.Id;
/*      */ import java.util.ArrayList;
/*      */ import java.util.List;
/*      */ import java.util.Objects;
/*      */ import java.util.Optional;
/*      */ import org.immutables.value.Generated;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ @Generated(from = "TemplateData", generator = "Immutables")
/*      */ public final class ImmutableTemplateData
/*      */   implements TemplateData
/*      */ {
/*      */   private final String code;
/*      */   private final String name;
/*      */   private final String description;
/*      */   private final int usageCount;
/*      */   private final long creatorId_value;
/*      */   private final UserData creator;
/*      */   private final String createdAt;
/*      */   private final String updatedAt;
/*      */   private final long sourceGuildId_value;
/*      */   private final SerializedSourceGuildData serializedSourceGuild;
/*      */   private final Boolean isDirty;
/*      */   private static final byte STAGE_INITIALIZING = -1;
/*      */   private static final byte STAGE_UNINITIALIZED = 0;
/*      */   private static final byte STAGE_INITIALIZED = 1;
/*      */   private volatile transient InitShim initShim;
/*      */   
/*      */   private ImmutableTemplateData(String code, String name, Optional<String> description, int usageCount, Id creatorId, UserData creator, String createdAt, String updatedAt, Id sourceGuildId, SerializedSourceGuildData serializedSourceGuild, Optional<Boolean> isDirty) {
/*   98 */     this.initShim = new InitShim(); this.code = Objects.<String>requireNonNull(code, "code"); this.name = Objects.<String>requireNonNull(name, "name"); this.description = description.orElse(null); this.usageCount = usageCount; Id creatorId$impl = creatorId; this.creator = Objects.<UserData>requireNonNull(creator, "creator"); this.createdAt = Objects.<String>requireNonNull(createdAt, "createdAt"); this.updatedAt = Objects.<String>requireNonNull(updatedAt, "updatedAt"); Id sourceGuildId$impl = sourceGuildId; this.serializedSourceGuild = Objects.<SerializedSourceGuildData>requireNonNull(serializedSourceGuild, "serializedSourceGuild"); this.isDirty = isDirty.orElse(null); this.creatorId_value = creatorId$impl.asLong(); this.sourceGuildId_value = sourceGuildId$impl.asLong(); this.initShim = null; } private ImmutableTemplateData(ImmutableTemplateData original, String code, String name, String description, int usageCount, Id creatorId, UserData creator, String createdAt, String updatedAt, Id sourceGuildId, SerializedSourceGuildData serializedSourceGuild, Boolean isDirty) { this.initShim = new InitShim(); this.code = code; this.name = name; this.description = description; this.usageCount = usageCount; Id creatorId$impl = creatorId; this.creator = creator; this.createdAt = createdAt; this.updatedAt = updatedAt; Id sourceGuildId$impl = sourceGuildId;
/*      */     this.serializedSourceGuild = serializedSourceGuild;
/*      */     this.isDirty = isDirty;
/*      */     this.creatorId_value = creatorId$impl.asLong();
/*      */     this.sourceGuildId_value = sourceGuildId$impl.asLong();
/*  103 */     this.initShim = null; } @Generated(from = "TemplateData", generator = "Immutables") private final class InitShim { private InitShim() {} private String formatInitCycleMessage() { List<String> attributes = new ArrayList<>();
/*  104 */       return "Cannot build TemplateData, attribute initializers form cycle " + attributes; }
/*      */      }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("code")
/*      */   public String code() {
/*  114 */     return this.code;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("name")
/*      */   public String name() {
/*  123 */     return this.name;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("description")
/*      */   public Optional<String> description() {
/*  132 */     return Optional.ofNullable(this.description);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("usage_count")
/*      */   public int usageCount() {
/*  141 */     return this.usageCount;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("creator_id")
/*      */   public Id creatorId() {
/*  150 */     return Id.of(this.creatorId_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("creator")
/*      */   public UserData creator() {
/*  159 */     return this.creator;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("created_at")
/*      */   public String createdAt() {
/*  168 */     return this.createdAt;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("updated_at")
/*      */   public String updatedAt() {
/*  177 */     return this.updatedAt;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("source_guild_id")
/*      */   public Id sourceGuildId() {
/*  186 */     return Id.of(this.sourceGuildId_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("serialized_source_guild")
/*      */   public SerializedSourceGuildData serializedSourceGuild() {
/*  195 */     return this.serializedSourceGuild;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("is_dirty")
/*      */   public Optional<Boolean> isDirty() {
/*  204 */     return Optional.ofNullable(this.isDirty);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableTemplateData withCode(String value) {
/*  214 */     String newValue = Objects.<String>requireNonNull(value, "code");
/*  215 */     if (this.code.equals(newValue)) return this; 
/*  216 */     return new ImmutableTemplateData(this, newValue, this.name, this.description, this.usageCount, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  222 */         creatorId(), this.creator, this.createdAt, this.updatedAt, 
/*      */ 
/*      */ 
/*      */         
/*  226 */         sourceGuildId(), this.serializedSourceGuild, this.isDirty);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableTemplateData withName(String value) {
/*  238 */     String newValue = Objects.<String>requireNonNull(value, "name");
/*  239 */     if (this.name.equals(newValue)) return this; 
/*  240 */     return new ImmutableTemplateData(this, this.code, newValue, this.description, this.usageCount, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  246 */         creatorId(), this.creator, this.createdAt, this.updatedAt, 
/*      */ 
/*      */ 
/*      */         
/*  250 */         sourceGuildId(), this.serializedSourceGuild, this.isDirty);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableTemplateData withDescription(String value) {
/*  261 */     String newValue = Objects.<String>requireNonNull(value, "description");
/*  262 */     if (Objects.equals(this.description, newValue)) return this; 
/*  263 */     return new ImmutableTemplateData(this, this.code, this.name, newValue, this.usageCount, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  269 */         creatorId(), this.creator, this.createdAt, this.updatedAt, 
/*      */ 
/*      */ 
/*      */         
/*  273 */         sourceGuildId(), this.serializedSourceGuild, this.isDirty);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableTemplateData withDescription(Optional<String> optional) {
/*  285 */     String value = optional.orElse(null);
/*  286 */     if (Objects.equals(this.description, value)) return this; 
/*  287 */     return new ImmutableTemplateData(this, this.code, this.name, value, this.usageCount, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  293 */         creatorId(), this.creator, this.createdAt, this.updatedAt, 
/*      */ 
/*      */ 
/*      */         
/*  297 */         sourceGuildId(), this.serializedSourceGuild, this.isDirty);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableTemplateData withUsageCount(int value) {
/*  309 */     if (this.usageCount == value) return this; 
/*  310 */     return new ImmutableTemplateData(this, this.code, this.name, this.description, value, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  316 */         creatorId(), this.creator, this.createdAt, this.updatedAt, 
/*      */ 
/*      */ 
/*      */         
/*  320 */         sourceGuildId(), this.serializedSourceGuild, this.isDirty);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutableTemplateData withCreatorId(long value) {
/*  326 */     Id newValue = Id.of(value);
/*  327 */     return new ImmutableTemplateData(this, this.code, this.name, this.description, this.usageCount, newValue, this.creator, this.createdAt, this.updatedAt, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  337 */         sourceGuildId(), this.serializedSourceGuild, this.isDirty);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutableTemplateData withCreatorId(String value) {
/*  343 */     Id newValue = Id.of(value);
/*  344 */     return new ImmutableTemplateData(this, this.code, this.name, this.description, this.usageCount, newValue, this.creator, this.createdAt, this.updatedAt, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  354 */         sourceGuildId(), this.serializedSourceGuild, this.isDirty);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableTemplateData withCreator(UserData value) {
/*  366 */     if (this.creator == value) return this; 
/*  367 */     UserData newValue = Objects.<UserData>requireNonNull(value, "creator");
/*  368 */     return new ImmutableTemplateData(this, this.code, this.name, this.description, this.usageCount, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  374 */         creatorId(), newValue, this.createdAt, this.updatedAt, 
/*      */ 
/*      */ 
/*      */         
/*  378 */         sourceGuildId(), this.serializedSourceGuild, this.isDirty);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableTemplateData withCreatedAt(String value) {
/*  390 */     String newValue = Objects.<String>requireNonNull(value, "createdAt");
/*  391 */     if (this.createdAt.equals(newValue)) return this; 
/*  392 */     return new ImmutableTemplateData(this, this.code, this.name, this.description, this.usageCount, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  398 */         creatorId(), this.creator, newValue, this.updatedAt, 
/*      */ 
/*      */ 
/*      */         
/*  402 */         sourceGuildId(), this.serializedSourceGuild, this.isDirty);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableTemplateData withUpdatedAt(String value) {
/*  414 */     String newValue = Objects.<String>requireNonNull(value, "updatedAt");
/*  415 */     if (this.updatedAt.equals(newValue)) return this; 
/*  416 */     return new ImmutableTemplateData(this, this.code, this.name, this.description, this.usageCount, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  422 */         creatorId(), this.creator, this.createdAt, newValue, 
/*      */ 
/*      */ 
/*      */         
/*  426 */         sourceGuildId(), this.serializedSourceGuild, this.isDirty);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutableTemplateData withSourceGuildId(long value) {
/*  432 */     Id newValue = Id.of(value);
/*  433 */     return new ImmutableTemplateData(this, this.code, this.name, this.description, this.usageCount, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  439 */         creatorId(), this.creator, this.createdAt, this.updatedAt, newValue, this.serializedSourceGuild, this.isDirty);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ImmutableTemplateData withSourceGuildId(String value) {
/*  449 */     Id newValue = Id.of(value);
/*  450 */     return new ImmutableTemplateData(this, this.code, this.name, this.description, this.usageCount, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  456 */         creatorId(), this.creator, this.createdAt, this.updatedAt, newValue, this.serializedSourceGuild, this.isDirty);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableTemplateData withSerializedSourceGuild(SerializedSourceGuildData value) {
/*  472 */     if (this.serializedSourceGuild == value) return this; 
/*  473 */     SerializedSourceGuildData newValue = Objects.<SerializedSourceGuildData>requireNonNull(value, "serializedSourceGuild");
/*  474 */     return new ImmutableTemplateData(this, this.code, this.name, this.description, this.usageCount, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  480 */         creatorId(), this.creator, this.createdAt, this.updatedAt, 
/*      */ 
/*      */ 
/*      */         
/*  484 */         sourceGuildId(), newValue, this.isDirty);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableTemplateData withIsDirty(boolean value) {
/*  495 */     Boolean newValue = Boolean.valueOf(value);
/*  496 */     if (Objects.equals(this.isDirty, newValue)) return this; 
/*  497 */     return new ImmutableTemplateData(this, this.code, this.name, this.description, this.usageCount, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  503 */         creatorId(), this.creator, this.createdAt, this.updatedAt, 
/*      */ 
/*      */ 
/*      */         
/*  507 */         sourceGuildId(), this.serializedSourceGuild, newValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableTemplateData withIsDirty(Optional<Boolean> optional) {
/*  519 */     Boolean value = optional.orElse(null);
/*  520 */     if (Objects.equals(this.isDirty, value)) return this; 
/*  521 */     return new ImmutableTemplateData(this, this.code, this.name, this.description, this.usageCount, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  527 */         creatorId(), this.creator, this.createdAt, this.updatedAt, 
/*      */ 
/*      */ 
/*      */         
/*  531 */         sourceGuildId(), this.serializedSourceGuild, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean equals(Object another) {
/*  542 */     if (this == another) return true; 
/*  543 */     return (another instanceof ImmutableTemplateData && 
/*  544 */       equalTo(0, (ImmutableTemplateData)another));
/*      */   }
/*      */   
/*      */   private boolean equalTo(int synthetic, ImmutableTemplateData another) {
/*  548 */     return (this.code.equals(another.code) && this.name
/*  549 */       .equals(another.name) && 
/*  550 */       Objects.equals(this.description, another.description) && this.usageCount == another.usageCount && 
/*      */       
/*  552 */       Objects.equals(Long.valueOf(this.creatorId_value), Long.valueOf(another.creatorId_value)) && this.creator
/*  553 */       .equals(another.creator) && this.createdAt
/*  554 */       .equals(another.createdAt) && this.updatedAt
/*  555 */       .equals(another.updatedAt) && 
/*  556 */       Objects.equals(Long.valueOf(this.sourceGuildId_value), Long.valueOf(another.sourceGuildId_value)) && this.serializedSourceGuild
/*  557 */       .equals(another.serializedSourceGuild) && 
/*  558 */       Objects.equals(this.isDirty, another.isDirty));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int hashCode() {
/*  567 */     int h = 5381;
/*  568 */     h += (h << 5) + this.code.hashCode();
/*  569 */     h += (h << 5) + this.name.hashCode();
/*  570 */     h += (h << 5) + Objects.hashCode(this.description);
/*  571 */     h += (h << 5) + this.usageCount;
/*  572 */     h += (h << 5) + Objects.hashCode(Long.valueOf(this.creatorId_value));
/*  573 */     h += (h << 5) + this.creator.hashCode();
/*  574 */     h += (h << 5) + this.createdAt.hashCode();
/*  575 */     h += (h << 5) + this.updatedAt.hashCode();
/*  576 */     h += (h << 5) + Objects.hashCode(Long.valueOf(this.sourceGuildId_value));
/*  577 */     h += (h << 5) + this.serializedSourceGuild.hashCode();
/*  578 */     h += (h << 5) + Objects.hashCode(this.isDirty);
/*  579 */     return h;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/*  588 */     StringBuilder builder = new StringBuilder("TemplateData{");
/*  589 */     builder.append("code=").append(this.code);
/*  590 */     builder.append(", ");
/*  591 */     builder.append("name=").append(this.name);
/*  592 */     if (this.description != null) {
/*  593 */       builder.append(", ");
/*  594 */       builder.append("description=").append(this.description);
/*      */     } 
/*  596 */     builder.append(", ");
/*  597 */     builder.append("usageCount=").append(this.usageCount);
/*  598 */     builder.append(", ");
/*  599 */     builder.append("creatorId=").append(Objects.toString(Long.valueOf(this.creatorId_value)));
/*  600 */     builder.append(", ");
/*  601 */     builder.append("creator=").append(this.creator);
/*  602 */     builder.append(", ");
/*  603 */     builder.append("createdAt=").append(this.createdAt);
/*  604 */     builder.append(", ");
/*  605 */     builder.append("updatedAt=").append(this.updatedAt);
/*  606 */     builder.append(", ");
/*  607 */     builder.append("sourceGuildId=").append(Objects.toString(Long.valueOf(this.sourceGuildId_value)));
/*  608 */     builder.append(", ");
/*  609 */     builder.append("serializedSourceGuild=").append(this.serializedSourceGuild);
/*  610 */     if (this.isDirty != null) {
/*  611 */       builder.append(", ");
/*  612 */       builder.append("isDirty=").append(this.isDirty);
/*      */     } 
/*  614 */     return builder.append("}").toString();
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonDeserialize
/*      */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*      */   @Generated(from = "TemplateData", generator = "Immutables")
/*      */   static final class Json
/*      */     implements TemplateData
/*      */   {
/*      */     String code;
/*      */     
/*      */     String name;
/*  628 */     Optional<String> description = Optional.empty();
/*      */     int usageCount;
/*      */     boolean usageCountIsSet;
/*      */     Id creatorId;
/*      */     UserData creator;
/*      */     String createdAt;
/*      */     String updatedAt;
/*      */     Id sourceGuildId;
/*      */     SerializedSourceGuildData serializedSourceGuild;
/*  637 */     Optional<Boolean> isDirty = Optional.empty();
/*      */     @JsonProperty("code")
/*      */     public void setCode(String code) {
/*  640 */       this.code = code;
/*      */     }
/*      */     @JsonProperty("name")
/*      */     public void setName(String name) {
/*  644 */       this.name = name;
/*      */     }
/*      */     @JsonProperty("description")
/*      */     public void setDescription(Optional<String> description) {
/*  648 */       this.description = description;
/*      */     }
/*      */     @JsonProperty("usage_count")
/*      */     public void setUsageCount(int usageCount) {
/*  652 */       this.usageCount = usageCount;
/*  653 */       this.usageCountIsSet = true;
/*      */     }
/*      */     @JsonProperty("creator_id")
/*      */     public void setCreatorId(Id creatorId) {
/*  657 */       this.creatorId = creatorId;
/*      */     }
/*      */     @JsonProperty("creator")
/*      */     public void setCreator(UserData creator) {
/*  661 */       this.creator = creator;
/*      */     }
/*      */     @JsonProperty("created_at")
/*      */     public void setCreatedAt(String createdAt) {
/*  665 */       this.createdAt = createdAt;
/*      */     }
/*      */     @JsonProperty("updated_at")
/*      */     public void setUpdatedAt(String updatedAt) {
/*  669 */       this.updatedAt = updatedAt;
/*      */     }
/*      */     @JsonProperty("source_guild_id")
/*      */     public void setSourceGuildId(Id sourceGuildId) {
/*  673 */       this.sourceGuildId = sourceGuildId;
/*      */     }
/*      */     @JsonProperty("serialized_source_guild")
/*      */     public void setSerializedSourceGuild(SerializedSourceGuildData serializedSourceGuild) {
/*  677 */       this.serializedSourceGuild = serializedSourceGuild;
/*      */     }
/*      */     @JsonProperty("is_dirty")
/*      */     public void setIsDirty(Optional<Boolean> isDirty) {
/*  681 */       this.isDirty = isDirty;
/*      */     }
/*      */     public String code() {
/*  684 */       throw new UnsupportedOperationException();
/*      */     } public String name() {
/*  686 */       throw new UnsupportedOperationException();
/*      */     } public Optional<String> description() {
/*  688 */       throw new UnsupportedOperationException();
/*      */     } public int usageCount() {
/*  690 */       throw new UnsupportedOperationException();
/*      */     } public Id creatorId() {
/*  692 */       throw new UnsupportedOperationException();
/*      */     } public UserData creator() {
/*  694 */       throw new UnsupportedOperationException();
/*      */     } public String createdAt() {
/*  696 */       throw new UnsupportedOperationException();
/*      */     } public String updatedAt() {
/*  698 */       throw new UnsupportedOperationException();
/*      */     } public Id sourceGuildId() {
/*  700 */       throw new UnsupportedOperationException();
/*      */     } public SerializedSourceGuildData serializedSourceGuild() {
/*  702 */       throw new UnsupportedOperationException();
/*      */     } public Optional<Boolean> isDirty() {
/*  704 */       throw new UnsupportedOperationException();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*      */   static ImmutableTemplateData fromJson(Json json) {
/*  715 */     Builder builder = builder();
/*  716 */     if (json.code != null) {
/*  717 */       builder.code(json.code);
/*      */     }
/*  719 */     if (json.name != null) {
/*  720 */       builder.name(json.name);
/*      */     }
/*  722 */     if (json.description != null) {
/*  723 */       builder.description(json.description);
/*      */     }
/*  725 */     if (json.usageCountIsSet) {
/*  726 */       builder.usageCount(json.usageCount);
/*      */     }
/*  728 */     if (json.creatorId != null) {
/*  729 */       builder.creatorId(json.creatorId);
/*      */     }
/*  731 */     if (json.creator != null) {
/*  732 */       builder.creator(json.creator);
/*      */     }
/*  734 */     if (json.createdAt != null) {
/*  735 */       builder.createdAt(json.createdAt);
/*      */     }
/*  737 */     if (json.updatedAt != null) {
/*  738 */       builder.updatedAt(json.updatedAt);
/*      */     }
/*  740 */     if (json.sourceGuildId != null) {
/*  741 */       builder.sourceGuildId(json.sourceGuildId);
/*      */     }
/*  743 */     if (json.serializedSourceGuild != null) {
/*  744 */       builder.serializedSourceGuild(json.serializedSourceGuild);
/*      */     }
/*  746 */     if (json.isDirty != null) {
/*  747 */       builder.isDirty(json.isDirty);
/*      */     }
/*  749 */     return builder.build();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableTemplateData of(String code, String name, Optional<String> description, int usageCount, Id creatorId, UserData creator, String createdAt, String updatedAt, Id sourceGuildId, SerializedSourceGuildData serializedSourceGuild, Optional<Boolean> isDirty) {
/*  768 */     return new ImmutableTemplateData(code, name, description, usageCount, creatorId, creator, createdAt, updatedAt, sourceGuildId, serializedSourceGuild, isDirty);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableTemplateData copyOf(TemplateData instance) {
/*  779 */     if (instance instanceof ImmutableTemplateData) {
/*  780 */       return (ImmutableTemplateData)instance;
/*      */     }
/*  782 */     return builder()
/*  783 */       .from(instance)
/*  784 */       .build();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Builder builder() {
/*  807 */     return new Builder();
/*      */   }
/*      */ 
/*      */   
/*      */   @Generated(from = "TemplateData", generator = "Immutables")
/*      */   public static final class Builder
/*      */   {
/*      */     private static final long INIT_BIT_CODE = 1L;
/*      */     
/*      */     private static final long INIT_BIT_NAME = 2L;
/*      */     
/*      */     private static final long INIT_BIT_USAGE_COUNT = 4L;
/*      */     
/*      */     private static final long INIT_BIT_CREATOR = 8L;
/*      */     
/*      */     private static final long INIT_BIT_CREATED_AT = 16L;
/*      */     
/*      */     private static final long INIT_BIT_UPDATED_AT = 32L;
/*      */     private static final long INIT_BIT_SERIALIZED_SOURCE_GUILD = 64L;
/*  826 */     private long initBits = 127L;
/*      */     
/*  828 */     private Id creatorId_id = null;
/*  829 */     private Id sourceGuildId_id = null;
/*      */     
/*      */     private String code;
/*      */     
/*      */     private String name;
/*      */     
/*      */     private String description;
/*      */     
/*      */     private int usageCount;
/*      */     
/*      */     private UserData creator;
/*      */     
/*      */     private String createdAt;
/*      */     
/*      */     private String updatedAt;
/*      */     
/*      */     private SerializedSourceGuildData serializedSourceGuild;
/*      */     
/*      */     private Boolean isDirty;
/*      */ 
/*      */     
/*      */     public final Builder from(TemplateData instance) {
/*  851 */       Objects.requireNonNull(instance, "instance");
/*  852 */       code(instance.code());
/*  853 */       name(instance.name());
/*  854 */       Optional<String> descriptionOptional = instance.description();
/*  855 */       if (descriptionOptional.isPresent()) {
/*  856 */         description(descriptionOptional);
/*      */       }
/*  858 */       usageCount(instance.usageCount());
/*  859 */       creatorId(instance.creatorId());
/*  860 */       creator(instance.creator());
/*  861 */       createdAt(instance.createdAt());
/*  862 */       updatedAt(instance.updatedAt());
/*  863 */       sourceGuildId(instance.sourceGuildId());
/*  864 */       serializedSourceGuild(instance.serializedSourceGuild());
/*  865 */       Optional<Boolean> isDirtyOptional = instance.isDirty();
/*  866 */       if (isDirtyOptional.isPresent()) {
/*  867 */         isDirty(isDirtyOptional);
/*      */       }
/*  869 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("code")
/*      */     public final Builder code(String code) {
/*  879 */       this.code = Objects.<String>requireNonNull(code, "code");
/*  880 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/*  881 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("name")
/*      */     public final Builder name(String name) {
/*  891 */       this.name = Objects.<String>requireNonNull(name, "name");
/*  892 */       this.initBits &= 0xFFFFFFFFFFFFFFFDL;
/*  893 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder description(String description) {
/*  902 */       this.description = Objects.<String>requireNonNull(description, "description");
/*  903 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("description")
/*      */     public final Builder description(Optional<String> description) {
/*  913 */       this.description = description.orElse(null);
/*  914 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("usage_count")
/*      */     public final Builder usageCount(int usageCount) {
/*  924 */       this.usageCount = usageCount;
/*  925 */       this.initBits &= 0xFFFFFFFFFFFFFFFBL;
/*  926 */       return this;
/*      */     }
/*      */     
/*      */     public Builder creatorId(String value) {
/*  930 */       this.creatorId_id = Id.of(value);
/*  931 */       return this;
/*      */     }
/*      */     
/*      */     public Builder creatorId(long value) {
/*  935 */       this.creatorId_id = Id.of(value);
/*  936 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("creator_id")
/*      */     public Builder creatorId(Id value) {
/*  941 */       this.creatorId_id = value;
/*  942 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("creator")
/*      */     public final Builder creator(UserData creator) {
/*  952 */       this.creator = Objects.<UserData>requireNonNull(creator, "creator");
/*  953 */       this.initBits &= 0xFFFFFFFFFFFFFFF7L;
/*  954 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("created_at")
/*      */     public final Builder createdAt(String createdAt) {
/*  964 */       this.createdAt = Objects.<String>requireNonNull(createdAt, "createdAt");
/*  965 */       this.initBits &= 0xFFFFFFFFFFFFFFEFL;
/*  966 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("updated_at")
/*      */     public final Builder updatedAt(String updatedAt) {
/*  976 */       this.updatedAt = Objects.<String>requireNonNull(updatedAt, "updatedAt");
/*  977 */       this.initBits &= 0xFFFFFFFFFFFFFFDFL;
/*  978 */       return this;
/*      */     }
/*      */     
/*      */     public Builder sourceGuildId(String value) {
/*  982 */       this.sourceGuildId_id = Id.of(value);
/*  983 */       return this;
/*      */     }
/*      */     
/*      */     public Builder sourceGuildId(long value) {
/*  987 */       this.sourceGuildId_id = Id.of(value);
/*  988 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("source_guild_id")
/*      */     public Builder sourceGuildId(Id value) {
/*  993 */       this.sourceGuildId_id = value;
/*  994 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("serialized_source_guild")
/*      */     public final Builder serializedSourceGuild(SerializedSourceGuildData serializedSourceGuild) {
/* 1004 */       this.serializedSourceGuild = Objects.<SerializedSourceGuildData>requireNonNull(serializedSourceGuild, "serializedSourceGuild");
/* 1005 */       this.initBits &= 0xFFFFFFFFFFFFFFBFL;
/* 1006 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder isDirty(boolean isDirty) {
/* 1015 */       this.isDirty = Boolean.valueOf(isDirty);
/* 1016 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("is_dirty")
/*      */     public final Builder isDirty(Optional<Boolean> isDirty) {
/* 1026 */       this.isDirty = isDirty.orElse(null);
/* 1027 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ImmutableTemplateData build() {
/* 1036 */       if (this.initBits != 0L) {
/* 1037 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*      */       }
/* 1039 */       return new ImmutableTemplateData(null, this.code, this.name, this.description, this.usageCount, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1045 */           creatorId_build(), this.creator, this.createdAt, this.updatedAt, 
/*      */ 
/*      */ 
/*      */           
/* 1049 */           sourceGuildId_build(), this.serializedSourceGuild, this.isDirty);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     private String formatRequiredAttributesMessage() {
/* 1055 */       List<String> attributes = new ArrayList<>();
/* 1056 */       if ((this.initBits & 0x1L) != 0L) attributes.add("code"); 
/* 1057 */       if ((this.initBits & 0x2L) != 0L) attributes.add("name"); 
/* 1058 */       if ((this.initBits & 0x4L) != 0L) attributes.add("usageCount"); 
/* 1059 */       if ((this.initBits & 0x8L) != 0L) attributes.add("creator"); 
/* 1060 */       if ((this.initBits & 0x10L) != 0L) attributes.add("createdAt"); 
/* 1061 */       if ((this.initBits & 0x20L) != 0L) attributes.add("updatedAt"); 
/* 1062 */       if ((this.initBits & 0x40L) != 0L) attributes.add("serializedSourceGuild"); 
/* 1063 */       return "Cannot build TemplateData, some of required attributes are not set " + attributes;
/*      */     }
/*      */     
/*      */     private Id creatorId_build() {
/* 1067 */       return this.creatorId_id;
/*      */     }
/*      */     
/*      */     private Id sourceGuildId_build() {
/* 1071 */       return this.sourceGuildId_id;
/*      */     }
/*      */     
/*      */     private Builder() {}
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableTemplateData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */