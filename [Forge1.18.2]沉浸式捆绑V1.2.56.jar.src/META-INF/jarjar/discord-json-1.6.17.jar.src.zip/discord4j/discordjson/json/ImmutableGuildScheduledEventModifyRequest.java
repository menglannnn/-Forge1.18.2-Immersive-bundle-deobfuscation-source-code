/*      */ package discord4j.discordjson.json;
/*      */ 
/*      */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*      */ import com.fasterxml.jackson.annotation.JsonCreator;
/*      */ import com.fasterxml.jackson.annotation.JsonProperty;
/*      */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*      */ import discord4j.discordjson.Id;
/*      */ import discord4j.discordjson.possible.Possible;
/*      */ import java.time.Instant;
/*      */ import java.util.ArrayList;
/*      */ import java.util.List;
/*      */ import java.util.Objects;
/*      */ import java.util.Optional;
/*      */ import org.immutables.value.Generated;
/*      */ import reactor.util.annotation.Nullable;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ @Generated(from = "GuildScheduledEventModifyRequest", generator = "Immutables")
/*      */ public final class ImmutableGuildScheduledEventModifyRequest
/*      */   implements GuildScheduledEventModifyRequest
/*      */ {
/*      */   private final long channelId_value;
/*      */   private final boolean channelId_absent;
/*      */   private final boolean channelId_isNull;
/*      */   private final GuildScheduledEventEntityMetadataData entityMetadata_value;
/*      */   private final boolean entityMetadata_absent;
/*      */   private final String name_value;
/*      */   private final boolean name_absent;
/*      */   private final Integer privacyLevel_value;
/*      */   private final boolean privacyLevel_absent;
/*      */   private final Instant scheduledStartTime_value;
/*      */   private final boolean scheduledStartTime_absent;
/*      */   private final Instant scheduledEndTime_value;
/*      */   private final boolean scheduledEndTime_absent;
/*      */   private final String description_value;
/*      */   private final boolean description_absent;
/*      */   private final Integer entityType_value;
/*      */   private final boolean entityType_absent;
/*      */   private final Integer status_value;
/*      */   private final boolean status_absent;
/*      */   private static final byte STAGE_INITIALIZING = -1;
/*      */   private static final byte STAGE_UNINITIALIZED = 0;
/*      */   private static final byte STAGE_INITIALIZED = 1;
/*      */   
/*      */   private ImmutableGuildScheduledEventModifyRequest(Possible<Optional<Id>> channelId, Possible<GuildScheduledEventEntityMetadataData> entityMetadata, Possible<String> name, Possible<Integer> privacyLevel, Possible<Instant> scheduledStartTime, Possible<Instant> scheduledEndTime, Possible<String> description, Possible<Integer> entityType, Possible<Integer> status) {
/*   60 */     Possible<Optional<Id>> channelId$impl = channelId;
/*   61 */     Possible<GuildScheduledEventEntityMetadataData> entityMetadata$impl = entityMetadata;
/*   62 */     Possible<String> name$impl = name;
/*   63 */     Possible<Integer> privacyLevel$impl = privacyLevel;
/*   64 */     Possible<Instant> scheduledStartTime$impl = scheduledStartTime;
/*   65 */     Possible<Instant> scheduledEndTime$impl = scheduledEndTime;
/*   66 */     Possible<String> description$impl = description;
/*   67 */     Possible<Integer> entityType$impl = entityType;
/*   68 */     Possible<Integer> status$impl = status;
/*   69 */     this
/*      */       
/*   71 */       .channelId_value = ((Long)Possible.flatOpt(channelId$impl).map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*   72 */     this.channelId_absent = channelId$impl.isAbsent();
/*   73 */     this.channelId_isNull = (!channelId$impl.isAbsent() && !((Optional)channelId$impl.get()).isPresent());
/*   74 */     this.entityMetadata_value = entityMetadata$impl.toOptional().orElse(null);
/*   75 */     this.entityMetadata_absent = entityMetadata$impl.isAbsent();
/*   76 */     this.name_value = name$impl.toOptional().orElse(null);
/*   77 */     this.name_absent = name$impl.isAbsent();
/*   78 */     this.privacyLevel_value = privacyLevel$impl.toOptional().orElse(null);
/*   79 */     this.privacyLevel_absent = privacyLevel$impl.isAbsent();
/*   80 */     this.scheduledStartTime_value = scheduledStartTime$impl.toOptional().orElse(null);
/*   81 */     this.scheduledStartTime_absent = scheduledStartTime$impl.isAbsent();
/*   82 */     this.scheduledEndTime_value = scheduledEndTime$impl.toOptional().orElse(null);
/*   83 */     this.scheduledEndTime_absent = scheduledEndTime$impl.isAbsent();
/*   84 */     this.description_value = description$impl.toOptional().orElse(null);
/*   85 */     this.description_absent = description$impl.isAbsent();
/*   86 */     this.entityType_value = entityType$impl.toOptional().orElse(null);
/*   87 */     this.entityType_absent = entityType$impl.isAbsent();
/*   88 */     this.status_value = status$impl.toOptional().orElse(null);
/*   89 */     this.status_absent = status$impl.isAbsent();
/*   90 */     this.initShim = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ImmutableGuildScheduledEventModifyRequest(ImmutableGuildScheduledEventModifyRequest original, Possible<Optional<Id>> channelId, Possible<GuildScheduledEventEntityMetadataData> entityMetadata, Possible<String> name, Possible<Integer> privacyLevel, Possible<Instant> scheduledStartTime, Possible<Instant> scheduledEndTime, Possible<String> description, Possible<Integer> entityType, Possible<Integer> status) {
/*  104 */     Possible<Optional<Id>> channelId$impl = channelId;
/*  105 */     Possible<GuildScheduledEventEntityMetadataData> entityMetadata$impl = entityMetadata;
/*  106 */     Possible<String> name$impl = name;
/*  107 */     Possible<Integer> privacyLevel$impl = privacyLevel;
/*  108 */     Possible<Instant> scheduledStartTime$impl = scheduledStartTime;
/*  109 */     Possible<Instant> scheduledEndTime$impl = scheduledEndTime;
/*  110 */     Possible<String> description$impl = description;
/*  111 */     Possible<Integer> entityType$impl = entityType;
/*  112 */     Possible<Integer> status$impl = status;
/*  113 */     this
/*      */       
/*  115 */       .channelId_value = ((Long)Possible.flatOpt(channelId$impl).map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  116 */     this.channelId_absent = channelId$impl.isAbsent();
/*  117 */     this.channelId_isNull = (!channelId$impl.isAbsent() && !((Optional)channelId$impl.get()).isPresent());
/*  118 */     this.entityMetadata_value = entityMetadata$impl.toOptional().orElse(null);
/*  119 */     this.entityMetadata_absent = entityMetadata$impl.isAbsent();
/*  120 */     this.name_value = name$impl.toOptional().orElse(null);
/*  121 */     this.name_absent = name$impl.isAbsent();
/*  122 */     this.privacyLevel_value = privacyLevel$impl.toOptional().orElse(null);
/*  123 */     this.privacyLevel_absent = privacyLevel$impl.isAbsent();
/*  124 */     this.scheduledStartTime_value = scheduledStartTime$impl.toOptional().orElse(null);
/*  125 */     this.scheduledStartTime_absent = scheduledStartTime$impl.isAbsent();
/*  126 */     this.scheduledEndTime_value = scheduledEndTime$impl.toOptional().orElse(null);
/*  127 */     this.scheduledEndTime_absent = scheduledEndTime$impl.isAbsent();
/*  128 */     this.description_value = description$impl.toOptional().orElse(null);
/*  129 */     this.description_absent = description$impl.isAbsent();
/*  130 */     this.entityType_value = entityType$impl.toOptional().orElse(null);
/*  131 */     this.entityType_absent = entityType$impl.isAbsent();
/*  132 */     this.status_value = status$impl.toOptional().orElse(null);
/*  133 */     this.status_absent = status$impl.isAbsent();
/*  134 */     this.initShim = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  140 */   private volatile transient InitShim initShim = new InitShim();
/*      */   
/*      */   @Generated(from = "GuildScheduledEventModifyRequest", generator = "Immutables")
/*      */   private final class InitShim {
/*      */     private String formatInitCycleMessage() {
/*  145 */       List<String> attributes = new ArrayList<>();
/*  146 */       return "Cannot build GuildScheduledEventModifyRequest, attribute initializers form cycle " + attributes;
/*      */     }
/*      */ 
/*      */     
/*      */     private InitShim() {}
/*      */   }
/*      */ 
/*      */   
/*      */   @JsonProperty("channel_id")
/*      */   public Possible<Optional<Id>> channelId() {
/*  156 */     if (this.channelId_absent)
/*  157 */       return Possible.absent(); 
/*  158 */     if (this.channelId_isNull) {
/*  159 */       return Possible.of(Optional.empty());
/*      */     }
/*  161 */     return Possible.of(Optional.of(Id.of(this.channelId_value)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("entity_metadata")
/*      */   public Possible<GuildScheduledEventEntityMetadataData> entityMetadata() {
/*  171 */     return this.entityMetadata_absent ? Possible.absent() : Possible.of(this.entityMetadata_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("name")
/*      */   public Possible<String> name() {
/*  180 */     return this.name_absent ? Possible.absent() : Possible.of(this.name_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("privacy_level")
/*      */   public Possible<Integer> privacyLevel() {
/*  189 */     return this.privacyLevel_absent ? Possible.absent() : Possible.of(this.privacyLevel_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("scheduled_start_time")
/*      */   public Possible<Instant> scheduledStartTime() {
/*  198 */     return this.scheduledStartTime_absent ? Possible.absent() : Possible.of(this.scheduledStartTime_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("scheduled_end_time")
/*      */   public Possible<Instant> scheduledEndTime() {
/*  207 */     return this.scheduledEndTime_absent ? Possible.absent() : Possible.of(this.scheduledEndTime_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("description")
/*      */   public Possible<String> description() {
/*  216 */     return this.description_absent ? Possible.absent() : Possible.of(this.description_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("entity_type")
/*      */   public Possible<Integer> entityType() {
/*  225 */     return this.entityType_absent ? Possible.absent() : Possible.of(this.entityType_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("status")
/*      */   public Possible<Integer> status() {
/*  234 */     return this.status_absent ? Possible.absent() : Possible.of(this.status_value);
/*      */   }
/*      */   
/*      */   public ImmutableGuildScheduledEventModifyRequest withChannelId(Possible<Optional<Id>> value) {
/*  238 */     Possible<Optional<Id>> newValue = Objects.<Possible<Optional<Id>>>requireNonNull(value);
/*  239 */     return new ImmutableGuildScheduledEventModifyRequest(this, newValue, 
/*      */ 
/*      */         
/*  242 */         entityMetadata(), 
/*  243 */         name(), 
/*  244 */         privacyLevel(), 
/*  245 */         scheduledStartTime(), 
/*  246 */         scheduledEndTime(), 
/*  247 */         description(), 
/*  248 */         entityType(), 
/*  249 */         status());
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public ImmutableGuildScheduledEventModifyRequest withChannelId(@Nullable Long value) {
/*  255 */     Possible<Optional<Id>> newValue = (value == null) ? Possible.of(Optional.empty()) : Possible.of(Optional.of(Id.of(value.longValue())));
/*  256 */     return new ImmutableGuildScheduledEventModifyRequest(this, newValue, 
/*      */ 
/*      */         
/*  259 */         entityMetadata(), 
/*  260 */         name(), 
/*  261 */         privacyLevel(), 
/*  262 */         scheduledStartTime(), 
/*  263 */         scheduledEndTime(), 
/*  264 */         description(), 
/*  265 */         entityType(), 
/*  266 */         status());
/*      */   }
/*      */ 
/*      */   
/*      */   public ImmutableGuildScheduledEventModifyRequest withChannelIdOrNull(@Nullable Long value) {
/*  271 */     Possible<Optional<Id>> newValue = (value == null) ? Possible.of(Optional.empty()) : Possible.of(Optional.of(Id.of(value.longValue())));
/*  272 */     return new ImmutableGuildScheduledEventModifyRequest(this, newValue, 
/*      */ 
/*      */         
/*  275 */         entityMetadata(), 
/*  276 */         name(), 
/*  277 */         privacyLevel(), 
/*  278 */         scheduledStartTime(), 
/*  279 */         scheduledEndTime(), 
/*  280 */         description(), 
/*  281 */         entityType(), 
/*  282 */         status());
/*      */   }
/*      */   
/*      */   public ImmutableGuildScheduledEventModifyRequest withEntityMetadata(Possible<GuildScheduledEventEntityMetadataData> value) {
/*  286 */     Possible<GuildScheduledEventEntityMetadataData> newValue = Objects.<Possible<GuildScheduledEventEntityMetadataData>>requireNonNull(value);
/*  287 */     return new ImmutableGuildScheduledEventModifyRequest(this, 
/*      */         
/*  289 */         channelId(), newValue, 
/*      */         
/*  291 */         name(), 
/*  292 */         privacyLevel(), 
/*  293 */         scheduledStartTime(), 
/*  294 */         scheduledEndTime(), 
/*  295 */         description(), 
/*  296 */         entityType(), 
/*  297 */         status());
/*      */   }
/*      */   
/*      */   public ImmutableGuildScheduledEventModifyRequest withEntityMetadata(GuildScheduledEventEntityMetadataData value) {
/*  301 */     Possible<GuildScheduledEventEntityMetadataData> newValue = Possible.of(value);
/*  302 */     return new ImmutableGuildScheduledEventModifyRequest(this, 
/*      */         
/*  304 */         channelId(), newValue, 
/*      */         
/*  306 */         name(), 
/*  307 */         privacyLevel(), 
/*  308 */         scheduledStartTime(), 
/*  309 */         scheduledEndTime(), 
/*  310 */         description(), 
/*  311 */         entityType(), 
/*  312 */         status());
/*      */   }
/*      */   
/*      */   public ImmutableGuildScheduledEventModifyRequest withName(Possible<String> value) {
/*  316 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/*  317 */     return new ImmutableGuildScheduledEventModifyRequest(this, 
/*      */         
/*  319 */         channelId(), 
/*  320 */         entityMetadata(), newValue, 
/*      */         
/*  322 */         privacyLevel(), 
/*  323 */         scheduledStartTime(), 
/*  324 */         scheduledEndTime(), 
/*  325 */         description(), 
/*  326 */         entityType(), 
/*  327 */         status());
/*      */   }
/*      */   
/*      */   public ImmutableGuildScheduledEventModifyRequest withName(String value) {
/*  331 */     Possible<String> newValue = Possible.of(value);
/*  332 */     return new ImmutableGuildScheduledEventModifyRequest(this, 
/*      */         
/*  334 */         channelId(), 
/*  335 */         entityMetadata(), newValue, 
/*      */         
/*  337 */         privacyLevel(), 
/*  338 */         scheduledStartTime(), 
/*  339 */         scheduledEndTime(), 
/*  340 */         description(), 
/*  341 */         entityType(), 
/*  342 */         status());
/*      */   }
/*      */   
/*      */   public ImmutableGuildScheduledEventModifyRequest withPrivacyLevel(Possible<Integer> value) {
/*  346 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/*  347 */     return new ImmutableGuildScheduledEventModifyRequest(this, 
/*      */         
/*  349 */         channelId(), 
/*  350 */         entityMetadata(), 
/*  351 */         name(), newValue, 
/*      */         
/*  353 */         scheduledStartTime(), 
/*  354 */         scheduledEndTime(), 
/*  355 */         description(), 
/*  356 */         entityType(), 
/*  357 */         status());
/*      */   }
/*      */   
/*      */   public ImmutableGuildScheduledEventModifyRequest withPrivacyLevel(Integer value) {
/*  361 */     Possible<Integer> newValue = Possible.of(value);
/*  362 */     return new ImmutableGuildScheduledEventModifyRequest(this, 
/*      */         
/*  364 */         channelId(), 
/*  365 */         entityMetadata(), 
/*  366 */         name(), newValue, 
/*      */         
/*  368 */         scheduledStartTime(), 
/*  369 */         scheduledEndTime(), 
/*  370 */         description(), 
/*  371 */         entityType(), 
/*  372 */         status());
/*      */   }
/*      */   
/*      */   public ImmutableGuildScheduledEventModifyRequest withScheduledStartTime(Possible<Instant> value) {
/*  376 */     Possible<Instant> newValue = Objects.<Possible<Instant>>requireNonNull(value);
/*  377 */     return new ImmutableGuildScheduledEventModifyRequest(this, 
/*      */         
/*  379 */         channelId(), 
/*  380 */         entityMetadata(), 
/*  381 */         name(), 
/*  382 */         privacyLevel(), newValue, 
/*      */         
/*  384 */         scheduledEndTime(), 
/*  385 */         description(), 
/*  386 */         entityType(), 
/*  387 */         status());
/*      */   }
/*      */   
/*      */   public ImmutableGuildScheduledEventModifyRequest withScheduledStartTime(Instant value) {
/*  391 */     Possible<Instant> newValue = Possible.of(value);
/*  392 */     return new ImmutableGuildScheduledEventModifyRequest(this, 
/*      */         
/*  394 */         channelId(), 
/*  395 */         entityMetadata(), 
/*  396 */         name(), 
/*  397 */         privacyLevel(), newValue, 
/*      */         
/*  399 */         scheduledEndTime(), 
/*  400 */         description(), 
/*  401 */         entityType(), 
/*  402 */         status());
/*      */   }
/*      */   
/*      */   public ImmutableGuildScheduledEventModifyRequest withScheduledEndTime(Possible<Instant> value) {
/*  406 */     Possible<Instant> newValue = Objects.<Possible<Instant>>requireNonNull(value);
/*  407 */     return new ImmutableGuildScheduledEventModifyRequest(this, 
/*      */         
/*  409 */         channelId(), 
/*  410 */         entityMetadata(), 
/*  411 */         name(), 
/*  412 */         privacyLevel(), 
/*  413 */         scheduledStartTime(), newValue, 
/*      */         
/*  415 */         description(), 
/*  416 */         entityType(), 
/*  417 */         status());
/*      */   }
/*      */   
/*      */   public ImmutableGuildScheduledEventModifyRequest withScheduledEndTime(Instant value) {
/*  421 */     Possible<Instant> newValue = Possible.of(value);
/*  422 */     return new ImmutableGuildScheduledEventModifyRequest(this, 
/*      */         
/*  424 */         channelId(), 
/*  425 */         entityMetadata(), 
/*  426 */         name(), 
/*  427 */         privacyLevel(), 
/*  428 */         scheduledStartTime(), newValue, 
/*      */         
/*  430 */         description(), 
/*  431 */         entityType(), 
/*  432 */         status());
/*      */   }
/*      */   
/*      */   public ImmutableGuildScheduledEventModifyRequest withDescription(Possible<String> value) {
/*  436 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/*  437 */     return new ImmutableGuildScheduledEventModifyRequest(this, 
/*      */         
/*  439 */         channelId(), 
/*  440 */         entityMetadata(), 
/*  441 */         name(), 
/*  442 */         privacyLevel(), 
/*  443 */         scheduledStartTime(), 
/*  444 */         scheduledEndTime(), newValue, 
/*      */         
/*  446 */         entityType(), 
/*  447 */         status());
/*      */   }
/*      */   
/*      */   public ImmutableGuildScheduledEventModifyRequest withDescription(String value) {
/*  451 */     Possible<String> newValue = Possible.of(value);
/*  452 */     return new ImmutableGuildScheduledEventModifyRequest(this, 
/*      */         
/*  454 */         channelId(), 
/*  455 */         entityMetadata(), 
/*  456 */         name(), 
/*  457 */         privacyLevel(), 
/*  458 */         scheduledStartTime(), 
/*  459 */         scheduledEndTime(), newValue, 
/*      */         
/*  461 */         entityType(), 
/*  462 */         status());
/*      */   }
/*      */   
/*      */   public ImmutableGuildScheduledEventModifyRequest withEntityType(Possible<Integer> value) {
/*  466 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/*  467 */     return new ImmutableGuildScheduledEventModifyRequest(this, 
/*      */         
/*  469 */         channelId(), 
/*  470 */         entityMetadata(), 
/*  471 */         name(), 
/*  472 */         privacyLevel(), 
/*  473 */         scheduledStartTime(), 
/*  474 */         scheduledEndTime(), 
/*  475 */         description(), newValue, 
/*      */         
/*  477 */         status());
/*      */   }
/*      */   
/*      */   public ImmutableGuildScheduledEventModifyRequest withEntityType(Integer value) {
/*  481 */     Possible<Integer> newValue = Possible.of(value);
/*  482 */     return new ImmutableGuildScheduledEventModifyRequest(this, 
/*      */         
/*  484 */         channelId(), 
/*  485 */         entityMetadata(), 
/*  486 */         name(), 
/*  487 */         privacyLevel(), 
/*  488 */         scheduledStartTime(), 
/*  489 */         scheduledEndTime(), 
/*  490 */         description(), newValue, 
/*      */         
/*  492 */         status());
/*      */   }
/*      */   
/*      */   public ImmutableGuildScheduledEventModifyRequest withStatus(Possible<Integer> value) {
/*  496 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/*  497 */     return new ImmutableGuildScheduledEventModifyRequest(this, 
/*      */         
/*  499 */         channelId(), 
/*  500 */         entityMetadata(), 
/*  501 */         name(), 
/*  502 */         privacyLevel(), 
/*  503 */         scheduledStartTime(), 
/*  504 */         scheduledEndTime(), 
/*  505 */         description(), 
/*  506 */         entityType(), newValue);
/*      */   }
/*      */ 
/*      */   
/*      */   public ImmutableGuildScheduledEventModifyRequest withStatus(Integer value) {
/*  511 */     Possible<Integer> newValue = Possible.of(value);
/*  512 */     return new ImmutableGuildScheduledEventModifyRequest(this, 
/*      */         
/*  514 */         channelId(), 
/*  515 */         entityMetadata(), 
/*  516 */         name(), 
/*  517 */         privacyLevel(), 
/*  518 */         scheduledStartTime(), 
/*  519 */         scheduledEndTime(), 
/*  520 */         description(), 
/*  521 */         entityType(), newValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean equals(Object another) {
/*  531 */     if (this == another) return true; 
/*  532 */     return (another instanceof ImmutableGuildScheduledEventModifyRequest && 
/*  533 */       equalTo(0, (ImmutableGuildScheduledEventModifyRequest)another));
/*      */   }
/*      */   
/*      */   private boolean equalTo(int synthetic, ImmutableGuildScheduledEventModifyRequest another) {
/*  537 */     return (channelId().equals(another.channelId()) && 
/*  538 */       entityMetadata().equals(another.entityMetadata()) && 
/*  539 */       name().equals(another.name()) && 
/*  540 */       privacyLevel().equals(another.privacyLevel()) && 
/*  541 */       scheduledStartTime().equals(another.scheduledStartTime()) && 
/*  542 */       scheduledEndTime().equals(another.scheduledEndTime()) && 
/*  543 */       description().equals(another.description()) && 
/*  544 */       entityType().equals(another.entityType()) && 
/*  545 */       status().equals(another.status()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int hashCode() {
/*  554 */     int h = 5381;
/*  555 */     h += (h << 5) + channelId().hashCode();
/*  556 */     h += (h << 5) + entityMetadata().hashCode();
/*  557 */     h += (h << 5) + name().hashCode();
/*  558 */     h += (h << 5) + privacyLevel().hashCode();
/*  559 */     h += (h << 5) + scheduledStartTime().hashCode();
/*  560 */     h += (h << 5) + scheduledEndTime().hashCode();
/*  561 */     h += (h << 5) + description().hashCode();
/*  562 */     h += (h << 5) + entityType().hashCode();
/*  563 */     h += (h << 5) + status().hashCode();
/*  564 */     return h;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/*  573 */     return "GuildScheduledEventModifyRequest{channelId=" + 
/*  574 */       channelId().toString() + ", entityMetadata=" + 
/*  575 */       entityMetadata().toString() + ", name=" + 
/*  576 */       name().toString() + ", privacyLevel=" + 
/*  577 */       privacyLevel().toString() + ", scheduledStartTime=" + 
/*  578 */       scheduledStartTime().toString() + ", scheduledEndTime=" + 
/*  579 */       scheduledEndTime().toString() + ", description=" + 
/*  580 */       description().toString() + ", entityType=" + 
/*  581 */       entityType().toString() + ", status=" + 
/*  582 */       status().toString() + "}";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonDeserialize
/*      */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*      */   @Generated(from = "GuildScheduledEventModifyRequest", generator = "Immutables")
/*      */   static final class Json
/*      */     implements GuildScheduledEventModifyRequest
/*      */   {
/*  596 */     Possible<Optional<Id>> channelId = Possible.absent();
/*      */ 
/*      */     
/*  599 */     Possible<GuildScheduledEventEntityMetadataData> entityMetadata = Possible.absent();
/*      */ 
/*      */     
/*  602 */     Possible<String> name = Possible.absent();
/*      */ 
/*      */     
/*  605 */     Possible<Integer> privacyLevel = Possible.absent();
/*      */ 
/*      */     
/*  608 */     Possible<Instant> scheduledStartTime = Possible.absent();
/*      */ 
/*      */     
/*  611 */     Possible<Instant> scheduledEndTime = Possible.absent();
/*      */ 
/*      */     
/*  614 */     Possible<String> description = Possible.absent();
/*      */ 
/*      */     
/*  617 */     Possible<Integer> entityType = Possible.absent();
/*      */ 
/*      */     
/*  620 */     Possible<Integer> status = Possible.absent();
/*      */     
/*      */     @JsonProperty("channel_id")
/*      */     public void setChannelId(Possible<Optional<Id>> channelId) {
/*  624 */       this.channelId = channelId;
/*      */     }
/*      */     @JsonProperty("entity_metadata")
/*      */     public void setEntityMetadata(Possible<GuildScheduledEventEntityMetadataData> entityMetadata) {
/*  628 */       this.entityMetadata = entityMetadata;
/*      */     }
/*      */     @JsonProperty("name")
/*      */     public void setName(Possible<String> name) {
/*  632 */       this.name = name;
/*      */     }
/*      */     @JsonProperty("privacy_level")
/*      */     public void setPrivacyLevel(Possible<Integer> privacyLevel) {
/*  636 */       this.privacyLevel = privacyLevel;
/*      */     }
/*      */     @JsonProperty("scheduled_start_time")
/*      */     public void setScheduledStartTime(Possible<Instant> scheduledStartTime) {
/*  640 */       this.scheduledStartTime = scheduledStartTime;
/*      */     }
/*      */     @JsonProperty("scheduled_end_time")
/*      */     public void setScheduledEndTime(Possible<Instant> scheduledEndTime) {
/*  644 */       this.scheduledEndTime = scheduledEndTime;
/*      */     }
/*      */     @JsonProperty("description")
/*      */     public void setDescription(Possible<String> description) {
/*  648 */       this.description = description;
/*      */     }
/*      */     @JsonProperty("entity_type")
/*      */     public void setEntityType(Possible<Integer> entityType) {
/*  652 */       this.entityType = entityType;
/*      */     }
/*      */     @JsonProperty("status")
/*      */     public void setStatus(Possible<Integer> status) {
/*  656 */       this.status = status;
/*      */     }
/*      */     public Possible<Optional<Id>> channelId() {
/*  659 */       throw new UnsupportedOperationException();
/*      */     } public Possible<GuildScheduledEventEntityMetadataData> entityMetadata() {
/*  661 */       throw new UnsupportedOperationException();
/*      */     } public Possible<String> name() {
/*  663 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Integer> privacyLevel() {
/*  665 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Instant> scheduledStartTime() {
/*  667 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Instant> scheduledEndTime() {
/*  669 */       throw new UnsupportedOperationException();
/*      */     } public Possible<String> description() {
/*  671 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Integer> entityType() {
/*  673 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Integer> status() {
/*  675 */       throw new UnsupportedOperationException();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*      */   static ImmutableGuildScheduledEventModifyRequest fromJson(Json json) {
/*  686 */     Builder builder = builder();
/*  687 */     if (json.channelId != null) {
/*  688 */       builder.channelId(json.channelId);
/*      */     }
/*  690 */     if (json.entityMetadata != null) {
/*  691 */       builder.entityMetadata(json.entityMetadata);
/*      */     }
/*  693 */     if (json.name != null) {
/*  694 */       builder.name(json.name);
/*      */     }
/*  696 */     if (json.privacyLevel != null) {
/*  697 */       builder.privacyLevel(json.privacyLevel);
/*      */     }
/*  699 */     if (json.scheduledStartTime != null) {
/*  700 */       builder.scheduledStartTime(json.scheduledStartTime);
/*      */     }
/*  702 */     if (json.scheduledEndTime != null) {
/*  703 */       builder.scheduledEndTime(json.scheduledEndTime);
/*      */     }
/*  705 */     if (json.description != null) {
/*  706 */       builder.description(json.description);
/*      */     }
/*  708 */     if (json.entityType != null) {
/*  709 */       builder.entityType(json.entityType);
/*      */     }
/*  711 */     if (json.status != null) {
/*  712 */       builder.status(json.status);
/*      */     }
/*  714 */     return builder.build();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableGuildScheduledEventModifyRequest of(Possible<Optional<Id>> channelId, Possible<GuildScheduledEventEntityMetadataData> entityMetadata, Possible<String> name, Possible<Integer> privacyLevel, Possible<Instant> scheduledStartTime, Possible<Instant> scheduledEndTime, Possible<String> description, Possible<Integer> entityType, Possible<Integer> status) {
/*  731 */     return new ImmutableGuildScheduledEventModifyRequest(channelId, entityMetadata, name, privacyLevel, scheduledStartTime, scheduledEndTime, description, entityType, status);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableGuildScheduledEventModifyRequest copyOf(GuildScheduledEventModifyRequest instance) {
/*  742 */     if (instance instanceof ImmutableGuildScheduledEventModifyRequest) {
/*  743 */       return (ImmutableGuildScheduledEventModifyRequest)instance;
/*      */     }
/*  745 */     return builder()
/*  746 */       .from(instance)
/*  747 */       .build();
/*      */   }
/*      */   
/*      */   public boolean isChannelIdPresent() {
/*  751 */     return !this.channelId_absent;
/*      */   }
/*      */   
/*      */   public long channelIdOrElse(long defaultValue) {
/*  755 */     return !this.channelId_absent ? this.channelId_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isEntityMetadataPresent() {
/*  759 */     return !this.entityMetadata_absent;
/*      */   }
/*      */   
/*      */   public GuildScheduledEventEntityMetadataData entityMetadataOrElse(GuildScheduledEventEntityMetadataData defaultValue) {
/*  763 */     return !this.entityMetadata_absent ? this.entityMetadata_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isNamePresent() {
/*  767 */     return !this.name_absent;
/*      */   }
/*      */   
/*      */   public String nameOrElse(String defaultValue) {
/*  771 */     return !this.name_absent ? this.name_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isPrivacyLevelPresent() {
/*  775 */     return !this.privacyLevel_absent;
/*      */   }
/*      */   
/*      */   public Integer privacyLevelOrElse(Integer defaultValue) {
/*  779 */     return !this.privacyLevel_absent ? this.privacyLevel_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isScheduledStartTimePresent() {
/*  783 */     return !this.scheduledStartTime_absent;
/*      */   }
/*      */   
/*      */   public Instant scheduledStartTimeOrElse(Instant defaultValue) {
/*  787 */     return !this.scheduledStartTime_absent ? this.scheduledStartTime_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isScheduledEndTimePresent() {
/*  791 */     return !this.scheduledEndTime_absent;
/*      */   }
/*      */   
/*      */   public Instant scheduledEndTimeOrElse(Instant defaultValue) {
/*  795 */     return !this.scheduledEndTime_absent ? this.scheduledEndTime_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isDescriptionPresent() {
/*  799 */     return !this.description_absent;
/*      */   }
/*      */   
/*      */   public String descriptionOrElse(String defaultValue) {
/*  803 */     return !this.description_absent ? this.description_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isEntityTypePresent() {
/*  807 */     return !this.entityType_absent;
/*      */   }
/*      */   
/*      */   public Integer entityTypeOrElse(Integer defaultValue) {
/*  811 */     return !this.entityType_absent ? this.entityType_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isStatusPresent() {
/*  815 */     return !this.status_absent;
/*      */   }
/*      */   
/*      */   public Integer statusOrElse(Integer defaultValue) {
/*  819 */     return !this.status_absent ? this.status_value : defaultValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Builder builder() {
/*  840 */     return new Builder();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Generated(from = "GuildScheduledEventModifyRequest", generator = "Immutables")
/*      */   public static final class Builder
/*      */   {
/*  852 */     private Possible<Optional<Id>> channelId_possible = Possible.absent();
/*  853 */     private Possible<GuildScheduledEventEntityMetadataData> entityMetadata_possible = Possible.absent();
/*  854 */     private Possible<String> name_possible = Possible.absent();
/*  855 */     private Possible<Integer> privacyLevel_possible = Possible.absent();
/*  856 */     private Possible<Instant> scheduledStartTime_possible = Possible.absent();
/*  857 */     private Possible<Instant> scheduledEndTime_possible = Possible.absent();
/*  858 */     private Possible<String> description_possible = Possible.absent();
/*  859 */     private Possible<Integer> entityType_possible = Possible.absent();
/*  860 */     private Possible<Integer> status_possible = Possible.absent();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder from(GuildScheduledEventModifyRequest instance) {
/*  873 */       Objects.requireNonNull(instance, "instance");
/*  874 */       channelId(instance.channelId());
/*  875 */       entityMetadata(instance.entityMetadata());
/*  876 */       name(instance.name());
/*  877 */       privacyLevel(instance.privacyLevel());
/*  878 */       scheduledStartTime(instance.scheduledStartTime());
/*  879 */       scheduledEndTime(instance.scheduledEndTime());
/*  880 */       description(instance.description());
/*  881 */       entityType(instance.entityType());
/*  882 */       status(instance.status());
/*  883 */       return this;
/*      */     }
/*      */     
/*      */     public Builder channelId(String value) {
/*  887 */       this.channelId_possible = Possible.of(Optional.of(Id.of(value)));
/*  888 */       return this;
/*      */     }
/*      */     
/*      */     public Builder channelId(long value) {
/*  892 */       this.channelId_possible = Possible.of(Optional.of(Id.of(value)));
/*  893 */       return this;
/*      */     }
/*      */     
/*      */     public Builder channelId(Id value) {
/*  897 */       this.channelId_possible = Possible.of(Optional.of(value));
/*  898 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("channel_id")
/*      */     public Builder channelId(Possible<Optional<Id>> value) {
/*  903 */       this.channelId_possible = value;
/*  904 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("entity_metadata")
/*      */     public Builder entityMetadata(Possible<GuildScheduledEventEntityMetadataData> value) {
/*  909 */       this.entityMetadata_possible = value;
/*  910 */       return this;
/*      */     }
/*      */     
/*      */     public Builder entityMetadata(GuildScheduledEventEntityMetadataData value) {
/*  914 */       this.entityMetadata_possible = Possible.of(value);
/*  915 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("name")
/*      */     public Builder name(Possible<String> value) {
/*  920 */       this.name_possible = value;
/*  921 */       return this;
/*      */     }
/*      */     
/*      */     public Builder name(String value) {
/*  925 */       this.name_possible = Possible.of(value);
/*  926 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("privacy_level")
/*      */     public Builder privacyLevel(Possible<Integer> value) {
/*  931 */       this.privacyLevel_possible = value;
/*  932 */       return this;
/*      */     }
/*      */     
/*      */     public Builder privacyLevel(Integer value) {
/*  936 */       this.privacyLevel_possible = Possible.of(value);
/*  937 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("scheduled_start_time")
/*      */     public Builder scheduledStartTime(Possible<Instant> value) {
/*  942 */       this.scheduledStartTime_possible = value;
/*  943 */       return this;
/*      */     }
/*      */     
/*      */     public Builder scheduledStartTime(Instant value) {
/*  947 */       this.scheduledStartTime_possible = Possible.of(value);
/*  948 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("scheduled_end_time")
/*      */     public Builder scheduledEndTime(Possible<Instant> value) {
/*  953 */       this.scheduledEndTime_possible = value;
/*  954 */       return this;
/*      */     }
/*      */     
/*      */     public Builder scheduledEndTime(Instant value) {
/*  958 */       this.scheduledEndTime_possible = Possible.of(value);
/*  959 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("description")
/*      */     public Builder description(Possible<String> value) {
/*  964 */       this.description_possible = value;
/*  965 */       return this;
/*      */     }
/*      */     
/*      */     public Builder description(String value) {
/*  969 */       this.description_possible = Possible.of(value);
/*  970 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("entity_type")
/*      */     public Builder entityType(Possible<Integer> value) {
/*  975 */       this.entityType_possible = value;
/*  976 */       return this;
/*      */     }
/*      */     
/*      */     public Builder entityType(Integer value) {
/*  980 */       this.entityType_possible = Possible.of(value);
/*  981 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("status")
/*      */     public Builder status(Possible<Integer> value) {
/*  986 */       this.status_possible = value;
/*  987 */       return this;
/*      */     }
/*      */     
/*      */     public Builder status(Integer value) {
/*  991 */       this.status_possible = Possible.of(value);
/*  992 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ImmutableGuildScheduledEventModifyRequest build() {
/* 1001 */       return new ImmutableGuildScheduledEventModifyRequest(null, 
/*      */           
/* 1003 */           channelId_build(), 
/* 1004 */           entityMetadata_build(), 
/* 1005 */           name_build(), 
/* 1006 */           privacyLevel_build(), 
/* 1007 */           scheduledStartTime_build(), 
/* 1008 */           scheduledEndTime_build(), 
/* 1009 */           description_build(), 
/* 1010 */           entityType_build(), 
/* 1011 */           status_build());
/*      */     }
/*      */     
/*      */     private Possible<Optional<Id>> channelId_build() {
/* 1015 */       return this.channelId_possible;
/*      */     }
/*      */     
/*      */     private Possible<GuildScheduledEventEntityMetadataData> entityMetadata_build() {
/* 1019 */       return this.entityMetadata_possible;
/*      */     }
/*      */     
/*      */     private Possible<String> name_build() {
/* 1023 */       return this.name_possible;
/*      */     }
/*      */     
/*      */     private Possible<Integer> privacyLevel_build() {
/* 1027 */       return this.privacyLevel_possible;
/*      */     }
/*      */     
/*      */     private Possible<Instant> scheduledStartTime_build() {
/* 1031 */       return this.scheduledStartTime_possible;
/*      */     }
/*      */     
/*      */     private Possible<Instant> scheduledEndTime_build() {
/* 1035 */       return this.scheduledEndTime_possible;
/*      */     }
/*      */     
/*      */     private Possible<String> description_build() {
/* 1039 */       return this.description_possible;
/*      */     }
/*      */     
/*      */     private Possible<Integer> entityType_build() {
/* 1043 */       return this.entityType_possible;
/*      */     }
/*      */     
/*      */     private Possible<Integer> status_build() {
/* 1047 */       return this.status_possible;
/*      */     }
/*      */     
/*      */     private Builder() {}
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableGuildScheduledEventModifyRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */