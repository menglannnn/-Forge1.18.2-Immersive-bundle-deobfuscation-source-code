/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "IntegrationModifyRequest", generator = "Immutables")
/*     */ public final class ImmutableIntegrationModifyRequest
/*     */   implements IntegrationModifyRequest
/*     */ {
/*     */   private final Integer expireBehavior_value;
/*     */   private final boolean expireBehavior_absent;
/*     */   private final Integer expireGracePeriod_value;
/*     */   private final boolean expireGracePeriod_absent;
/*     */   private final Boolean enableEmoticons_value;
/*     */   private final boolean enableEmoticons_absent;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   
/*     */   private ImmutableIntegrationModifyRequest(Possible<Integer> expireBehavior, Possible<Integer> expireGracePeriod, Possible<Boolean> enableEmoticons) {
/*  37 */     Possible<Integer> expireBehavior$impl = expireBehavior;
/*  38 */     Possible<Integer> expireGracePeriod$impl = expireGracePeriod;
/*  39 */     Possible<Boolean> enableEmoticons$impl = enableEmoticons;
/*  40 */     this.expireBehavior_value = expireBehavior$impl.toOptional().orElse(null);
/*  41 */     this.expireBehavior_absent = expireBehavior$impl.isAbsent();
/*  42 */     this.expireGracePeriod_value = expireGracePeriod$impl.toOptional().orElse(null);
/*  43 */     this.expireGracePeriod_absent = expireGracePeriod$impl.isAbsent();
/*  44 */     this.enableEmoticons_value = enableEmoticons$impl.toOptional().orElse(null);
/*  45 */     this.enableEmoticons_absent = enableEmoticons$impl.isAbsent();
/*  46 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ImmutableIntegrationModifyRequest(ImmutableIntegrationModifyRequest original, Possible<Integer> expireBehavior, Possible<Integer> expireGracePeriod, Possible<Boolean> enableEmoticons) {
/*  54 */     Possible<Integer> expireBehavior$impl = expireBehavior;
/*  55 */     Possible<Integer> expireGracePeriod$impl = expireGracePeriod;
/*  56 */     Possible<Boolean> enableEmoticons$impl = enableEmoticons;
/*  57 */     this.expireBehavior_value = expireBehavior$impl.toOptional().orElse(null);
/*  58 */     this.expireBehavior_absent = expireBehavior$impl.isAbsent();
/*  59 */     this.expireGracePeriod_value = expireGracePeriod$impl.toOptional().orElse(null);
/*  60 */     this.expireGracePeriod_absent = expireGracePeriod$impl.isAbsent();
/*  61 */     this.enableEmoticons_value = enableEmoticons$impl.toOptional().orElse(null);
/*  62 */     this.enableEmoticons_absent = enableEmoticons$impl.isAbsent();
/*  63 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  69 */   private volatile transient InitShim initShim = new InitShim();
/*     */   
/*     */   @Generated(from = "IntegrationModifyRequest", generator = "Immutables")
/*     */   private final class InitShim {
/*     */     private String formatInitCycleMessage() {
/*  74 */       List<String> attributes = new ArrayList<>();
/*  75 */       return "Cannot build IntegrationModifyRequest, attribute initializers form cycle " + attributes;
/*     */     }
/*     */ 
/*     */     
/*     */     private InitShim() {}
/*     */   }
/*     */ 
/*     */   
/*     */   @JsonProperty("expire_behavior")
/*     */   public Possible<Integer> expireBehavior() {
/*  85 */     return this.expireBehavior_absent ? Possible.absent() : Possible.of(this.expireBehavior_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("expire_grace_period")
/*     */   public Possible<Integer> expireGracePeriod() {
/*  94 */     return this.expireGracePeriod_absent ? Possible.absent() : Possible.of(this.expireGracePeriod_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("enable_emoticons")
/*     */   public Possible<Boolean> enableEmoticons() {
/* 103 */     return this.enableEmoticons_absent ? Possible.absent() : Possible.of(this.enableEmoticons_value);
/*     */   }
/*     */   
/*     */   public ImmutableIntegrationModifyRequest withExpireBehavior(Possible<Integer> value) {
/* 107 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/* 108 */     return new ImmutableIntegrationModifyRequest(this, newValue, expireGracePeriod(), enableEmoticons());
/*     */   }
/*     */   
/*     */   public ImmutableIntegrationModifyRequest withExpireBehavior(Integer value) {
/* 112 */     Possible<Integer> newValue = Possible.of(value);
/* 113 */     return new ImmutableIntegrationModifyRequest(this, newValue, expireGracePeriod(), enableEmoticons());
/*     */   }
/*     */   
/*     */   public ImmutableIntegrationModifyRequest withExpireGracePeriod(Possible<Integer> value) {
/* 117 */     Possible<Integer> newValue = Objects.<Possible<Integer>>requireNonNull(value);
/* 118 */     return new ImmutableIntegrationModifyRequest(this, expireBehavior(), newValue, enableEmoticons());
/*     */   }
/*     */   
/*     */   public ImmutableIntegrationModifyRequest withExpireGracePeriod(Integer value) {
/* 122 */     Possible<Integer> newValue = Possible.of(value);
/* 123 */     return new ImmutableIntegrationModifyRequest(this, expireBehavior(), newValue, enableEmoticons());
/*     */   }
/*     */   
/*     */   public ImmutableIntegrationModifyRequest withEnableEmoticons(Possible<Boolean> value) {
/* 127 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/* 128 */     return new ImmutableIntegrationModifyRequest(this, expireBehavior(), expireGracePeriod(), newValue);
/*     */   }
/*     */   
/*     */   public ImmutableIntegrationModifyRequest withEnableEmoticons(Boolean value) {
/* 132 */     Possible<Boolean> newValue = Possible.of(value);
/* 133 */     return new ImmutableIntegrationModifyRequest(this, expireBehavior(), expireGracePeriod(), newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 142 */     if (this == another) return true; 
/* 143 */     return (another instanceof ImmutableIntegrationModifyRequest && 
/* 144 */       equalTo(0, (ImmutableIntegrationModifyRequest)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableIntegrationModifyRequest another) {
/* 148 */     return (expireBehavior().equals(another.expireBehavior()) && 
/* 149 */       expireGracePeriod().equals(another.expireGracePeriod()) && 
/* 150 */       enableEmoticons().equals(another.enableEmoticons()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 159 */     int h = 5381;
/* 160 */     h += (h << 5) + expireBehavior().hashCode();
/* 161 */     h += (h << 5) + expireGracePeriod().hashCode();
/* 162 */     h += (h << 5) + enableEmoticons().hashCode();
/* 163 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 172 */     return "IntegrationModifyRequest{expireBehavior=" + 
/* 173 */       expireBehavior().toString() + ", expireGracePeriod=" + 
/* 174 */       expireGracePeriod().toString() + ", enableEmoticons=" + 
/* 175 */       enableEmoticons().toString() + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "IntegrationModifyRequest", generator = "Immutables")
/*     */   static final class Json
/*     */     implements IntegrationModifyRequest
/*     */   {
/* 189 */     Possible<Integer> expireBehavior = Possible.absent();
/*     */ 
/*     */     
/* 192 */     Possible<Integer> expireGracePeriod = Possible.absent();
/*     */ 
/*     */     
/* 195 */     Possible<Boolean> enableEmoticons = Possible.absent();
/*     */     
/*     */     @JsonProperty("expire_behavior")
/*     */     public void setExpireBehavior(Possible<Integer> expireBehavior) {
/* 199 */       this.expireBehavior = expireBehavior;
/*     */     }
/*     */     @JsonProperty("expire_grace_period")
/*     */     public void setExpireGracePeriod(Possible<Integer> expireGracePeriod) {
/* 203 */       this.expireGracePeriod = expireGracePeriod;
/*     */     }
/*     */     @JsonProperty("enable_emoticons")
/*     */     public void setEnableEmoticons(Possible<Boolean> enableEmoticons) {
/* 207 */       this.enableEmoticons = enableEmoticons;
/*     */     }
/*     */     public Possible<Integer> expireBehavior() {
/* 210 */       throw new UnsupportedOperationException();
/*     */     } public Possible<Integer> expireGracePeriod() {
/* 212 */       throw new UnsupportedOperationException();
/*     */     } public Possible<Boolean> enableEmoticons() {
/* 214 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableIntegrationModifyRequest fromJson(Json json) {
/* 225 */     Builder builder = builder();
/* 226 */     if (json.expireBehavior != null) {
/* 227 */       builder.expireBehavior(json.expireBehavior);
/*     */     }
/* 229 */     if (json.expireGracePeriod != null) {
/* 230 */       builder.expireGracePeriod(json.expireGracePeriod);
/*     */     }
/* 232 */     if (json.enableEmoticons != null) {
/* 233 */       builder.enableEmoticons(json.enableEmoticons);
/*     */     }
/* 235 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableIntegrationModifyRequest of(Possible<Integer> expireBehavior, Possible<Integer> expireGracePeriod, Possible<Boolean> enableEmoticons) {
/* 246 */     return new ImmutableIntegrationModifyRequest(expireBehavior, expireGracePeriod, enableEmoticons);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableIntegrationModifyRequest copyOf(IntegrationModifyRequest instance) {
/* 257 */     if (instance instanceof ImmutableIntegrationModifyRequest) {
/* 258 */       return (ImmutableIntegrationModifyRequest)instance;
/*     */     }
/* 260 */     return builder()
/* 261 */       .from(instance)
/* 262 */       .build();
/*     */   }
/*     */   
/*     */   public boolean isExpireBehaviorPresent() {
/* 266 */     return !this.expireBehavior_absent;
/*     */   }
/*     */   
/*     */   public Integer expireBehaviorOrElse(Integer defaultValue) {
/* 270 */     return !this.expireBehavior_absent ? this.expireBehavior_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isExpireGracePeriodPresent() {
/* 274 */     return !this.expireGracePeriod_absent;
/*     */   }
/*     */   
/*     */   public Integer expireGracePeriodOrElse(Integer defaultValue) {
/* 278 */     return !this.expireGracePeriod_absent ? this.expireGracePeriod_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isEnableEmoticonsPresent() {
/* 282 */     return !this.enableEmoticons_absent;
/*     */   }
/*     */   
/*     */   public Boolean enableEmoticonsOrElse(Boolean defaultValue) {
/* 286 */     return !this.enableEmoticons_absent ? this.enableEmoticons_value : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 301 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "IntegrationModifyRequest", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/* 313 */     private Possible<Integer> expireBehavior_possible = Possible.absent();
/* 314 */     private Possible<Integer> expireGracePeriod_possible = Possible.absent();
/* 315 */     private Possible<Boolean> enableEmoticons_possible = Possible.absent();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(IntegrationModifyRequest instance) {
/* 328 */       Objects.requireNonNull(instance, "instance");
/* 329 */       expireBehavior(instance.expireBehavior());
/* 330 */       expireGracePeriod(instance.expireGracePeriod());
/* 331 */       enableEmoticons(instance.enableEmoticons());
/* 332 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("expire_behavior")
/*     */     public Builder expireBehavior(Possible<Integer> value) {
/* 337 */       this.expireBehavior_possible = value;
/* 338 */       return this;
/*     */     }
/*     */     
/*     */     public Builder expireBehavior(Integer value) {
/* 342 */       this.expireBehavior_possible = Possible.of(value);
/* 343 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("expire_grace_period")
/*     */     public Builder expireGracePeriod(Possible<Integer> value) {
/* 348 */       this.expireGracePeriod_possible = value;
/* 349 */       return this;
/*     */     }
/*     */     
/*     */     public Builder expireGracePeriod(Integer value) {
/* 353 */       this.expireGracePeriod_possible = Possible.of(value);
/* 354 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("enable_emoticons")
/*     */     public Builder enableEmoticons(Possible<Boolean> value) {
/* 359 */       this.enableEmoticons_possible = value;
/* 360 */       return this;
/*     */     }
/*     */     
/*     */     public Builder enableEmoticons(Boolean value) {
/* 364 */       this.enableEmoticons_possible = Possible.of(value);
/* 365 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableIntegrationModifyRequest build() {
/* 374 */       return new ImmutableIntegrationModifyRequest(null, expireBehavior_build(), expireGracePeriod_build(), enableEmoticons_build());
/*     */     }
/*     */     
/*     */     private Possible<Integer> expireBehavior_build() {
/* 378 */       return this.expireBehavior_possible;
/*     */     }
/*     */     
/*     */     private Possible<Integer> expireGracePeriod_build() {
/* 382 */       return this.expireGracePeriod_possible;
/*     */     }
/*     */     
/*     */     private Possible<Boolean> enableEmoticons_build() {
/* 386 */       return this.enableEmoticons_possible;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableIntegrationModifyRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */