/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import org.immutables.value.Generated;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ @Generated(from = "GuildEmbedModifyRequest", generator = "Immutables")
/*     */ public final class ImmutableGuildEmbedModifyRequest
/*     */   implements GuildEmbedModifyRequest
/*     */ {
/*     */   private final Boolean enabled_value;
/*     */   private final boolean enabled_absent;
/*     */   private final String channelId_value;
/*     */   private final boolean channelId_absent;
/*     */   private static final byte STAGE_INITIALIZING = -1;
/*     */   private static final byte STAGE_UNINITIALIZED = 0;
/*     */   private static final byte STAGE_INITIALIZED = 1;
/*     */   
/*     */   private ImmutableGuildEmbedModifyRequest(Possible<Boolean> enabled, Possible<Optional<String>> channelId) {
/*  37 */     Possible<Boolean> enabled$impl = enabled;
/*  38 */     Possible<Optional<String>> channelId$impl = channelId;
/*  39 */     this.enabled_value = enabled$impl.toOptional().orElse(null);
/*  40 */     this.enabled_absent = enabled$impl.isAbsent();
/*  41 */     this.channelId_value = Possible.flatOpt(channelId$impl).orElse(null);
/*  42 */     this.channelId_absent = channelId$impl.isAbsent();
/*  43 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ImmutableGuildEmbedModifyRequest(ImmutableGuildEmbedModifyRequest original, Possible<Boolean> enabled, Possible<Optional<String>> channelId) {
/*  50 */     Possible<Boolean> enabled$impl = enabled;
/*  51 */     Possible<Optional<String>> channelId$impl = channelId;
/*  52 */     this.enabled_value = enabled$impl.toOptional().orElse(null);
/*  53 */     this.enabled_absent = enabled$impl.isAbsent();
/*  54 */     this.channelId_value = Possible.flatOpt(channelId$impl).orElse(null);
/*  55 */     this.channelId_absent = channelId$impl.isAbsent();
/*  56 */     this.initShim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  62 */   private volatile transient InitShim initShim = new InitShim();
/*     */   
/*     */   @Generated(from = "GuildEmbedModifyRequest", generator = "Immutables")
/*     */   private final class InitShim {
/*     */     private String formatInitCycleMessage() {
/*  67 */       List<String> attributes = new ArrayList<>();
/*  68 */       return "Cannot build GuildEmbedModifyRequest, attribute initializers form cycle " + attributes;
/*     */     }
/*     */ 
/*     */     
/*     */     private InitShim() {}
/*     */   }
/*     */ 
/*     */   
/*     */   @JsonProperty("enabled")
/*     */   public Possible<Boolean> enabled() {
/*  78 */     return this.enabled_absent ? Possible.absent() : Possible.of(this.enabled_value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("channel_id")
/*     */   public Possible<Optional<String>> channelId() {
/*  87 */     return this.channelId_absent ? Possible.absent() : 
/*  88 */       Possible.of(Optional.ofNullable(this.channelId_value));
/*     */   }
/*     */   
/*     */   public ImmutableGuildEmbedModifyRequest withEnabled(Possible<Boolean> value) {
/*  92 */     Possible<Boolean> newValue = Objects.<Possible<Boolean>>requireNonNull(value);
/*  93 */     return new ImmutableGuildEmbedModifyRequest(this, newValue, channelId());
/*     */   }
/*     */   
/*     */   public ImmutableGuildEmbedModifyRequest withEnabled(Boolean value) {
/*  97 */     Possible<Boolean> newValue = Possible.of(value);
/*  98 */     return new ImmutableGuildEmbedModifyRequest(this, newValue, channelId());
/*     */   }
/*     */   
/*     */   public ImmutableGuildEmbedModifyRequest withChannelId(Possible<Optional<String>> value) {
/* 102 */     Possible<Optional<String>> newValue = Objects.<Possible<Optional<String>>>requireNonNull(value);
/* 103 */     return new ImmutableGuildEmbedModifyRequest(this, enabled(), newValue);
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public ImmutableGuildEmbedModifyRequest withChannelId(@Nullable String value) {
/* 108 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/* 109 */     return new ImmutableGuildEmbedModifyRequest(this, enabled(), newValue);
/*     */   }
/*     */   
/*     */   public ImmutableGuildEmbedModifyRequest withChannelIdOrNull(@Nullable String value) {
/* 113 */     Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
/* 114 */     return new ImmutableGuildEmbedModifyRequest(this, enabled(), newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 123 */     if (this == another) return true; 
/* 124 */     return (another instanceof ImmutableGuildEmbedModifyRequest && 
/* 125 */       equalTo(0, (ImmutableGuildEmbedModifyRequest)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableGuildEmbedModifyRequest another) {
/* 129 */     return (enabled().equals(another.enabled()) && 
/* 130 */       channelId().equals(another.channelId()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 139 */     int h = 5381;
/* 140 */     h += (h << 5) + enabled().hashCode();
/* 141 */     h += (h << 5) + channelId().hashCode();
/* 142 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 151 */     return "GuildEmbedModifyRequest{enabled=" + 
/* 152 */       enabled().toString() + ", channelId=" + 
/* 153 */       channelId().toString() + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "GuildEmbedModifyRequest", generator = "Immutables")
/*     */   static final class Json
/*     */     implements GuildEmbedModifyRequest
/*     */   {
/* 167 */     Possible<Boolean> enabled = Possible.absent();
/*     */ 
/*     */     
/* 170 */     Possible<Optional<String>> channelId = Possible.absent();
/*     */     
/*     */     @JsonProperty("enabled")
/*     */     public void setEnabled(Possible<Boolean> enabled) {
/* 174 */       this.enabled = enabled;
/*     */     }
/*     */     @JsonProperty("channel_id")
/*     */     public void setChannelId(Possible<Optional<String>> channelId) {
/* 178 */       this.channelId = channelId;
/*     */     }
/*     */     public Possible<Boolean> enabled() {
/* 181 */       throw new UnsupportedOperationException();
/*     */     } public Possible<Optional<String>> channelId() {
/* 183 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableGuildEmbedModifyRequest fromJson(Json json) {
/* 194 */     Builder builder = builder();
/* 195 */     if (json.enabled != null) {
/* 196 */       builder.enabled(json.enabled);
/*     */     }
/* 198 */     if (json.channelId != null) {
/* 199 */       builder.channelId(json.channelId);
/*     */     }
/* 201 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableGuildEmbedModifyRequest of(Possible<Boolean> enabled, Possible<Optional<String>> channelId) {
/* 211 */     return new ImmutableGuildEmbedModifyRequest(enabled, channelId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableGuildEmbedModifyRequest copyOf(GuildEmbedModifyRequest instance) {
/* 222 */     if (instance instanceof ImmutableGuildEmbedModifyRequest) {
/* 223 */       return (ImmutableGuildEmbedModifyRequest)instance;
/*     */     }
/* 225 */     return builder()
/* 226 */       .from(instance)
/* 227 */       .build();
/*     */   }
/*     */   
/*     */   public boolean isEnabledPresent() {
/* 231 */     return !this.enabled_absent;
/*     */   }
/*     */   
/*     */   public Boolean enabledOrElse(Boolean defaultValue) {
/* 235 */     return !this.enabled_absent ? this.enabled_value : defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isChannelIdPresent() {
/* 239 */     return !this.channelId_absent;
/*     */   }
/*     */   
/*     */   public String channelIdOrElse(String defaultValue) {
/* 243 */     return !this.channelId_absent ? this.channelId_value : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 257 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "GuildEmbedModifyRequest", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/* 269 */     private Possible<Boolean> enabled_possible = Possible.absent();
/* 270 */     private Possible<Optional<String>> channelId_possible = Possible.absent();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(GuildEmbedModifyRequest instance) {
/* 283 */       Objects.requireNonNull(instance, "instance");
/* 284 */       enabled(instance.enabled());
/* 285 */       channelId(instance.channelId());
/* 286 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("enabled")
/*     */     public Builder enabled(Possible<Boolean> value) {
/* 291 */       this.enabled_possible = value;
/* 292 */       return this;
/*     */     }
/*     */     
/*     */     public Builder enabled(Boolean value) {
/* 296 */       this.enabled_possible = Possible.of(value);
/* 297 */       return this;
/*     */     }
/*     */     
/*     */     @JsonProperty("channel_id")
/*     */     public Builder channelId(Possible<Optional<String>> value) {
/* 302 */       this.channelId_possible = value;
/* 303 */       return this;
/*     */     }
/*     */     
/*     */     @Deprecated
/*     */     public Builder channelId(@Nullable String value) {
/* 308 */       this.channelId_possible = Possible.of(Optional.ofNullable(value));
/* 309 */       return this;
/*     */     }
/*     */     
/*     */     public Builder channelIdOrNull(@Nullable String value) {
/* 313 */       this.channelId_possible = Possible.of(Optional.ofNullable(value));
/* 314 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableGuildEmbedModifyRequest build() {
/* 323 */       return new ImmutableGuildEmbedModifyRequest(null, enabled_build(), channelId_build());
/*     */     }
/*     */     
/*     */     private Possible<Boolean> enabled_build() {
/* 327 */       return this.enabled_possible;
/*     */     }
/*     */     
/*     */     private Possible<Optional<String>> channelId_build() {
/* 331 */       return this.channelId_possible;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableGuildEmbedModifyRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */