/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "PartialChannelCreateRequest", generator = "Immutables")
/*     */ public final class ImmutablePartialChannelCreateRequest
/*     */   implements PartialChannelCreateRequest
/*     */ {
/*     */   private final String name;
/*     */   private final int type;
/*     */   
/*     */   private ImmutablePartialChannelCreateRequest(String name, int type) {
/*  29 */     this.name = Objects.<String>requireNonNull(name, "name");
/*  30 */     this.type = type;
/*     */   }
/*     */   
/*     */   private ImmutablePartialChannelCreateRequest(ImmutablePartialChannelCreateRequest original, String name, int type) {
/*  34 */     this.name = name;
/*  35 */     this.type = type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("name")
/*     */   public String name() {
/*  44 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("type")
/*     */   public int type() {
/*  53 */     return this.type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutablePartialChannelCreateRequest withName(String value) {
/*  63 */     String newValue = Objects.<String>requireNonNull(value, "name");
/*  64 */     if (this.name.equals(newValue)) return this; 
/*  65 */     return new ImmutablePartialChannelCreateRequest(this, newValue, this.type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutablePartialChannelCreateRequest withType(int value) {
/*  75 */     if (this.type == value) return this; 
/*  76 */     return new ImmutablePartialChannelCreateRequest(this, this.name, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/*  85 */     if (this == another) return true; 
/*  86 */     return (another instanceof ImmutablePartialChannelCreateRequest && 
/*  87 */       equalTo(0, (ImmutablePartialChannelCreateRequest)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutablePartialChannelCreateRequest another) {
/*  91 */     return (this.name.equals(another.name) && this.type == another.type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 101 */     int h = 5381;
/* 102 */     h += (h << 5) + this.name.hashCode();
/* 103 */     h += (h << 5) + this.type;
/* 104 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 113 */     return "PartialChannelCreateRequest{name=" + this.name + ", type=" + this.type + "}";
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "PartialChannelCreateRequest", generator = "Immutables")
/*     */   static final class Json
/*     */     implements PartialChannelCreateRequest
/*     */   {
/*     */     String name;
/*     */     
/*     */     int type;
/*     */     
/*     */     boolean typeIsSet;
/*     */ 
/*     */     
/*     */     @JsonProperty("name")
/*     */     public void setName(String name) {
/* 133 */       this.name = name;
/*     */     }
/*     */     @JsonProperty("type")
/*     */     public void setType(int type) {
/* 137 */       this.type = type;
/* 138 */       this.typeIsSet = true;
/*     */     }
/*     */     public String name() {
/* 141 */       throw new UnsupportedOperationException();
/*     */     } public int type() {
/* 143 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutablePartialChannelCreateRequest fromJson(Json json) {
/* 154 */     Builder builder = builder();
/* 155 */     if (json.name != null) {
/* 156 */       builder.name(json.name);
/*     */     }
/* 158 */     if (json.typeIsSet) {
/* 159 */       builder.type(json.type);
/*     */     }
/* 161 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutablePartialChannelCreateRequest of(String name, int type) {
/* 171 */     return new ImmutablePartialChannelCreateRequest(name, type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutablePartialChannelCreateRequest copyOf(PartialChannelCreateRequest instance) {
/* 182 */     if (instance instanceof ImmutablePartialChannelCreateRequest) {
/* 183 */       return (ImmutablePartialChannelCreateRequest)instance;
/*     */     }
/* 185 */     return builder()
/* 186 */       .from(instance)
/* 187 */       .build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 201 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "PartialChannelCreateRequest", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/*     */     private static final long INIT_BIT_NAME = 1L;
/*     */ 
/*     */     
/*     */     private static final long INIT_BIT_TYPE = 2L;
/*     */ 
/*     */     
/* 215 */     private long initBits = 3L;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private String name;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private int type;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(PartialChannelCreateRequest instance) {
/* 231 */       Objects.requireNonNull(instance, "instance");
/* 232 */       name(instance.name());
/* 233 */       type(instance.type());
/* 234 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("name")
/*     */     public final Builder name(String name) {
/* 244 */       this.name = Objects.<String>requireNonNull(name, "name");
/* 245 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 246 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("type")
/*     */     public final Builder type(int type) {
/* 256 */       this.type = type;
/* 257 */       this.initBits &= 0xFFFFFFFFFFFFFFFDL;
/* 258 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutablePartialChannelCreateRequest build() {
/* 267 */       if (this.initBits != 0L) {
/* 268 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*     */       }
/* 270 */       return new ImmutablePartialChannelCreateRequest(null, this.name, this.type);
/*     */     }
/*     */     
/*     */     private String formatRequiredAttributesMessage() {
/* 274 */       List<String> attributes = new ArrayList<>();
/* 275 */       if ((this.initBits & 0x1L) != 0L) attributes.add("name"); 
/* 276 */       if ((this.initBits & 0x2L) != 0L) attributes.add("type"); 
/* 277 */       return "Cannot build PartialChannelCreateRequest, some of required attributes are not set " + attributes;
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutablePartialChannelCreateRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */