/*      */ package discord4j.discordjson.json;
/*      */ 
/*      */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*      */ import com.fasterxml.jackson.annotation.JsonCreator;
/*      */ import com.fasterxml.jackson.annotation.JsonProperty;
/*      */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*      */ import discord4j.discordjson.Id;
/*      */ import discord4j.discordjson.possible.Possible;
/*      */ import java.util.ArrayList;
/*      */ import java.util.List;
/*      */ import java.util.Objects;
/*      */ import java.util.Optional;
/*      */ import org.immutables.value.Generated;
/*      */ import reactor.util.annotation.Nullable;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ @Generated(from = "WebhookData", generator = "Immutables")
/*      */ public final class ImmutableWebhookData
/*      */   implements WebhookData
/*      */ {
/*      */   private final long id_value;
/*      */   private final int type;
/*      */   private final long guildId_value;
/*      */   private final boolean guildId_absent;
/*      */   private final boolean guildId_isNull;
/*      */   private final long channelId_value;
/*      */   private final boolean channelId_present;
/*      */   private final UserData user_value;
/*      */   private final boolean user_absent;
/*      */   private final String name;
/*      */   private final String avatar;
/*      */   private final String token_value;
/*      */   private final boolean token_absent;
/*      */   private final long applicationId_value;
/*      */   private final boolean applicationId_present;
/*      */   private final WebhookPartialGuildData sourceGuild_value;
/*      */   private final boolean sourceGuild_absent;
/*      */   private final WebhookPartialChannelData sourceChannel_value;
/*      */   private final boolean sourceChannel_absent;
/*      */   private static final byte STAGE_INITIALIZING = -1;
/*      */   private static final byte STAGE_UNINITIALIZED = 0;
/*      */   private static final byte STAGE_INITIALIZED = 1;
/*      */   
/*      */   private ImmutableWebhookData(Id id, int type, Possible<Optional<Id>> guildId, Optional<Id> channelId, Possible<UserData> user, Optional<String> name, Optional<String> avatar, Possible<String> token, Optional<Id> applicationId, Possible<WebhookPartialGuildData> sourceGuild, Possible<WebhookPartialChannelData> sourceChannel) {
/*   60 */     Id id$impl = id;
/*   61 */     this.type = type;
/*   62 */     Possible<Optional<Id>> guildId$impl = guildId;
/*   63 */     Optional<Id> channelId$impl = channelId;
/*   64 */     Possible<UserData> user$impl = user;
/*   65 */     this.name = name.orElse(null);
/*   66 */     this.avatar = avatar.orElse(null);
/*   67 */     Possible<String> token$impl = token;
/*   68 */     Optional<Id> applicationId$impl = applicationId;
/*   69 */     Possible<WebhookPartialGuildData> sourceGuild$impl = sourceGuild;
/*   70 */     Possible<WebhookPartialChannelData> sourceChannel$impl = sourceChannel;
/*   71 */     this.id_value = id$impl.asLong();
/*   72 */     this
/*      */       
/*   74 */       .guildId_value = ((Long)Possible.flatOpt(guildId$impl).map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*   75 */     this.guildId_absent = guildId$impl.isAbsent();
/*   76 */     this.guildId_isNull = (!guildId$impl.isAbsent() && !((Optional)guildId$impl.get()).isPresent());
/*   77 */     this
/*      */       
/*   79 */       .channelId_value = ((Long)channelId$impl.<Long>map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*   80 */     this.channelId_present = channelId$impl.isPresent();
/*   81 */     this.user_value = user$impl.toOptional().orElse(null);
/*   82 */     this.user_absent = user$impl.isAbsent();
/*   83 */     this.token_value = token$impl.toOptional().orElse(null);
/*   84 */     this.token_absent = token$impl.isAbsent();
/*   85 */     this
/*      */       
/*   87 */       .applicationId_value = ((Long)applicationId$impl.<Long>map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*   88 */     this.applicationId_present = applicationId$impl.isPresent();
/*   89 */     this.sourceGuild_value = sourceGuild$impl.toOptional().orElse(null);
/*   90 */     this.sourceGuild_absent = sourceGuild$impl.isAbsent();
/*   91 */     this.sourceChannel_value = sourceChannel$impl.toOptional().orElse(null);
/*   92 */     this.sourceChannel_absent = sourceChannel$impl.isAbsent();
/*   93 */     this.initShim = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ImmutableWebhookData(ImmutableWebhookData original, Id id, int type, Possible<Optional<Id>> guildId, Optional<Id> channelId, Possible<UserData> user, String name, String avatar, Possible<String> token, Optional<Id> applicationId, Possible<WebhookPartialGuildData> sourceGuild, Possible<WebhookPartialChannelData> sourceChannel) {
/*  109 */     Id id$impl = id;
/*  110 */     this.type = type;
/*  111 */     Possible<Optional<Id>> guildId$impl = guildId;
/*  112 */     Optional<Id> channelId$impl = channelId;
/*  113 */     Possible<UserData> user$impl = user;
/*  114 */     this.name = name;
/*  115 */     this.avatar = avatar;
/*  116 */     Possible<String> token$impl = token;
/*  117 */     Optional<Id> applicationId$impl = applicationId;
/*  118 */     Possible<WebhookPartialGuildData> sourceGuild$impl = sourceGuild;
/*  119 */     Possible<WebhookPartialChannelData> sourceChannel$impl = sourceChannel;
/*  120 */     this.id_value = id$impl.asLong();
/*  121 */     this
/*      */       
/*  123 */       .guildId_value = ((Long)Possible.flatOpt(guildId$impl).map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  124 */     this.guildId_absent = guildId$impl.isAbsent();
/*  125 */     this.guildId_isNull = (!guildId$impl.isAbsent() && !((Optional)guildId$impl.get()).isPresent());
/*  126 */     this
/*      */       
/*  128 */       .channelId_value = ((Long)channelId$impl.<Long>map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  129 */     this.channelId_present = channelId$impl.isPresent();
/*  130 */     this.user_value = user$impl.toOptional().orElse(null);
/*  131 */     this.user_absent = user$impl.isAbsent();
/*  132 */     this.token_value = token$impl.toOptional().orElse(null);
/*  133 */     this.token_absent = token$impl.isAbsent();
/*  134 */     this
/*      */       
/*  136 */       .applicationId_value = ((Long)applicationId$impl.<Long>map(Id::asLong).orElse(Long.valueOf(0L))).longValue();
/*  137 */     this.applicationId_present = applicationId$impl.isPresent();
/*  138 */     this.sourceGuild_value = sourceGuild$impl.toOptional().orElse(null);
/*  139 */     this.sourceGuild_absent = sourceGuild$impl.isAbsent();
/*  140 */     this.sourceChannel_value = sourceChannel$impl.toOptional().orElse(null);
/*  141 */     this.sourceChannel_absent = sourceChannel$impl.isAbsent();
/*  142 */     this.initShim = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  148 */   private volatile transient InitShim initShim = new InitShim();
/*      */   
/*      */   @Generated(from = "WebhookData", generator = "Immutables")
/*      */   private final class InitShim {
/*      */     private String formatInitCycleMessage() {
/*  153 */       List<String> attributes = new ArrayList<>();
/*  154 */       return "Cannot build WebhookData, attribute initializers form cycle " + attributes;
/*      */     }
/*      */ 
/*      */     
/*      */     private InitShim() {}
/*      */   }
/*      */ 
/*      */   
/*      */   @JsonProperty("id")
/*      */   public Id id() {
/*  164 */     return Id.of(this.id_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("type")
/*      */   public int type() {
/*  173 */     return this.type;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("guild_id")
/*      */   public Possible<Optional<Id>> guildId() {
/*  182 */     if (this.guildId_absent)
/*  183 */       return Possible.absent(); 
/*  184 */     if (this.guildId_isNull) {
/*  185 */       return Possible.of(Optional.empty());
/*      */     }
/*  187 */     return Possible.of(Optional.of(Id.of(this.guildId_value)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("channel_id")
/*      */   public Optional<Id> channelId() {
/*  197 */     return this.channelId_present ? Optional.<Id>of(Id.of(this.channelId_value)) : Optional.<Id>empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("user")
/*      */   public Possible<UserData> user() {
/*  206 */     return this.user_absent ? Possible.absent() : Possible.of(this.user_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("name")
/*      */   public Optional<String> name() {
/*  215 */     return Optional.ofNullable(this.name);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("avatar")
/*      */   public Optional<String> avatar() {
/*  224 */     return Optional.ofNullable(this.avatar);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("token")
/*      */   public Possible<String> token() {
/*  233 */     return this.token_absent ? Possible.absent() : Possible.of(this.token_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("application_id")
/*      */   public Optional<Id> applicationId() {
/*  242 */     return this.applicationId_present ? Optional.<Id>of(Id.of(this.applicationId_value)) : Optional.<Id>empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("source_guild")
/*      */   public Possible<WebhookPartialGuildData> sourceGuild() {
/*  251 */     return this.sourceGuild_absent ? Possible.absent() : Possible.of(this.sourceGuild_value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JsonProperty("source_channel")
/*      */   public Possible<WebhookPartialChannelData> sourceChannel() {
/*  260 */     return this.sourceChannel_absent ? Possible.absent() : Possible.of(this.sourceChannel_value);
/*      */   }
/*      */   
/*      */   public ImmutableWebhookData withId(long value) {
/*  264 */     Id newValue = Id.of(value);
/*  265 */     return new ImmutableWebhookData(this, newValue, this.type, 
/*      */ 
/*      */ 
/*      */         
/*  269 */         guildId(), 
/*  270 */         channelId(), 
/*  271 */         user(), this.name, this.avatar, 
/*      */ 
/*      */         
/*  274 */         token(), 
/*  275 */         applicationId(), 
/*  276 */         sourceGuild(), 
/*  277 */         sourceChannel());
/*      */   }
/*      */   
/*      */   public ImmutableWebhookData withId(String value) {
/*  281 */     Id newValue = Id.of(value);
/*  282 */     return new ImmutableWebhookData(this, newValue, this.type, 
/*      */ 
/*      */ 
/*      */         
/*  286 */         guildId(), 
/*  287 */         channelId(), 
/*  288 */         user(), this.name, this.avatar, 
/*      */ 
/*      */         
/*  291 */         token(), 
/*  292 */         applicationId(), 
/*  293 */         sourceGuild(), 
/*  294 */         sourceChannel());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableWebhookData withType(int value) {
/*  304 */     if (this.type == value) return this; 
/*  305 */     return new ImmutableWebhookData(this, 
/*      */         
/*  307 */         id(), value, 
/*      */         
/*  309 */         guildId(), 
/*  310 */         channelId(), 
/*  311 */         user(), this.name, this.avatar, 
/*      */ 
/*      */         
/*  314 */         token(), 
/*  315 */         applicationId(), 
/*  316 */         sourceGuild(), 
/*  317 */         sourceChannel());
/*      */   }
/*      */   
/*      */   public ImmutableWebhookData withGuildId(Possible<Optional<Id>> value) {
/*  321 */     Possible<Optional<Id>> newValue = Objects.<Possible<Optional<Id>>>requireNonNull(value);
/*  322 */     return new ImmutableWebhookData(this, 
/*      */         
/*  324 */         id(), this.type, newValue, 
/*      */ 
/*      */         
/*  327 */         channelId(), 
/*  328 */         user(), this.name, this.avatar, 
/*      */ 
/*      */         
/*  331 */         token(), 
/*  332 */         applicationId(), 
/*  333 */         sourceGuild(), 
/*  334 */         sourceChannel());
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public ImmutableWebhookData withGuildId(@Nullable Long value) {
/*  340 */     Possible<Optional<Id>> newValue = (value == null) ? Possible.of(Optional.empty()) : Possible.of(Optional.of(Id.of(value.longValue())));
/*  341 */     return new ImmutableWebhookData(this, 
/*      */         
/*  343 */         id(), this.type, newValue, 
/*      */ 
/*      */         
/*  346 */         channelId(), 
/*  347 */         user(), this.name, this.avatar, 
/*      */ 
/*      */         
/*  350 */         token(), 
/*  351 */         applicationId(), 
/*  352 */         sourceGuild(), 
/*  353 */         sourceChannel());
/*      */   }
/*      */ 
/*      */   
/*      */   public ImmutableWebhookData withGuildIdOrNull(@Nullable Long value) {
/*  358 */     Possible<Optional<Id>> newValue = (value == null) ? Possible.of(Optional.empty()) : Possible.of(Optional.of(Id.of(value.longValue())));
/*  359 */     return new ImmutableWebhookData(this, 
/*      */         
/*  361 */         id(), this.type, newValue, 
/*      */ 
/*      */         
/*  364 */         channelId(), 
/*  365 */         user(), this.name, this.avatar, 
/*      */ 
/*      */         
/*  368 */         token(), 
/*  369 */         applicationId(), 
/*  370 */         sourceGuild(), 
/*  371 */         sourceChannel());
/*      */   }
/*      */   
/*      */   public ImmutableWebhookData withChannelId(Optional<Id> value) {
/*  375 */     Optional<Id> newValue = Objects.<Optional<Id>>requireNonNull(value);
/*  376 */     return new ImmutableWebhookData(this, 
/*      */         
/*  378 */         id(), this.type, 
/*      */         
/*  380 */         guildId(), newValue, 
/*      */         
/*  382 */         user(), this.name, this.avatar, 
/*      */ 
/*      */         
/*  385 */         token(), 
/*  386 */         applicationId(), 
/*  387 */         sourceGuild(), 
/*  388 */         sourceChannel());
/*      */   }
/*      */   
/*      */   public ImmutableWebhookData withChannelId(long value) {
/*  392 */     Optional<Id> newValue = Optional.of(Id.of(value));
/*  393 */     return new ImmutableWebhookData(this, 
/*      */         
/*  395 */         id(), this.type, 
/*      */         
/*  397 */         guildId(), newValue, 
/*      */         
/*  399 */         user(), this.name, this.avatar, 
/*      */ 
/*      */         
/*  402 */         token(), 
/*  403 */         applicationId(), 
/*  404 */         sourceGuild(), 
/*  405 */         sourceChannel());
/*      */   }
/*      */   
/*      */   public ImmutableWebhookData withUser(Possible<UserData> value) {
/*  409 */     Possible<UserData> newValue = Objects.<Possible<UserData>>requireNonNull(value);
/*  410 */     return new ImmutableWebhookData(this, 
/*      */         
/*  412 */         id(), this.type, 
/*      */         
/*  414 */         guildId(), 
/*  415 */         channelId(), newValue, this.name, this.avatar, 
/*      */ 
/*      */ 
/*      */         
/*  419 */         token(), 
/*  420 */         applicationId(), 
/*  421 */         sourceGuild(), 
/*  422 */         sourceChannel());
/*      */   }
/*      */   
/*      */   public ImmutableWebhookData withUser(UserData value) {
/*  426 */     Possible<UserData> newValue = Possible.of(value);
/*  427 */     return new ImmutableWebhookData(this, 
/*      */         
/*  429 */         id(), this.type, 
/*      */         
/*  431 */         guildId(), 
/*  432 */         channelId(), newValue, this.name, this.avatar, 
/*      */ 
/*      */ 
/*      */         
/*  436 */         token(), 
/*  437 */         applicationId(), 
/*  438 */         sourceGuild(), 
/*  439 */         sourceChannel());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableWebhookData withName(String value) {
/*  448 */     String newValue = Objects.<String>requireNonNull(value, "name");
/*  449 */     if (Objects.equals(this.name, newValue)) return this; 
/*  450 */     return new ImmutableWebhookData(this, 
/*      */         
/*  452 */         id(), this.type, 
/*      */         
/*  454 */         guildId(), 
/*  455 */         channelId(), 
/*  456 */         user(), newValue, this.avatar, 
/*      */ 
/*      */         
/*  459 */         token(), 
/*  460 */         applicationId(), 
/*  461 */         sourceGuild(), 
/*  462 */         sourceChannel());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableWebhookData withName(Optional<String> optional) {
/*  472 */     String value = optional.orElse(null);
/*  473 */     if (Objects.equals(this.name, value)) return this; 
/*  474 */     return new ImmutableWebhookData(this, 
/*      */         
/*  476 */         id(), this.type, 
/*      */         
/*  478 */         guildId(), 
/*  479 */         channelId(), 
/*  480 */         user(), value, this.avatar, 
/*      */ 
/*      */         
/*  483 */         token(), 
/*  484 */         applicationId(), 
/*  485 */         sourceGuild(), 
/*  486 */         sourceChannel());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableWebhookData withAvatar(String value) {
/*  495 */     String newValue = Objects.<String>requireNonNull(value, "avatar");
/*  496 */     if (Objects.equals(this.avatar, newValue)) return this; 
/*  497 */     return new ImmutableWebhookData(this, 
/*      */         
/*  499 */         id(), this.type, 
/*      */         
/*  501 */         guildId(), 
/*  502 */         channelId(), 
/*  503 */         user(), this.name, newValue, 
/*      */ 
/*      */         
/*  506 */         token(), 
/*  507 */         applicationId(), 
/*  508 */         sourceGuild(), 
/*  509 */         sourceChannel());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ImmutableWebhookData withAvatar(Optional<String> optional) {
/*  519 */     String value = optional.orElse(null);
/*  520 */     if (Objects.equals(this.avatar, value)) return this; 
/*  521 */     return new ImmutableWebhookData(this, 
/*      */         
/*  523 */         id(), this.type, 
/*      */         
/*  525 */         guildId(), 
/*  526 */         channelId(), 
/*  527 */         user(), this.name, value, 
/*      */ 
/*      */         
/*  530 */         token(), 
/*  531 */         applicationId(), 
/*  532 */         sourceGuild(), 
/*  533 */         sourceChannel());
/*      */   }
/*      */   
/*      */   public ImmutableWebhookData withToken(Possible<String> value) {
/*  537 */     Possible<String> newValue = Objects.<Possible<String>>requireNonNull(value);
/*  538 */     return new ImmutableWebhookData(this, 
/*      */         
/*  540 */         id(), this.type, 
/*      */         
/*  542 */         guildId(), 
/*  543 */         channelId(), 
/*  544 */         user(), this.name, this.avatar, newValue, 
/*      */ 
/*      */ 
/*      */         
/*  548 */         applicationId(), 
/*  549 */         sourceGuild(), 
/*  550 */         sourceChannel());
/*      */   }
/*      */   
/*      */   public ImmutableWebhookData withToken(String value) {
/*  554 */     Possible<String> newValue = Possible.of(value);
/*  555 */     return new ImmutableWebhookData(this, 
/*      */         
/*  557 */         id(), this.type, 
/*      */         
/*  559 */         guildId(), 
/*  560 */         channelId(), 
/*  561 */         user(), this.name, this.avatar, newValue, 
/*      */ 
/*      */ 
/*      */         
/*  565 */         applicationId(), 
/*  566 */         sourceGuild(), 
/*  567 */         sourceChannel());
/*      */   }
/*      */   
/*      */   public ImmutableWebhookData withApplicationId(Optional<Id> value) {
/*  571 */     Optional<Id> newValue = Objects.<Optional<Id>>requireNonNull(value);
/*  572 */     return new ImmutableWebhookData(this, 
/*      */         
/*  574 */         id(), this.type, 
/*      */         
/*  576 */         guildId(), 
/*  577 */         channelId(), 
/*  578 */         user(), this.name, this.avatar, 
/*      */ 
/*      */         
/*  581 */         token(), newValue, 
/*      */         
/*  583 */         sourceGuild(), 
/*  584 */         sourceChannel());
/*      */   }
/*      */   
/*      */   public ImmutableWebhookData withApplicationId(long value) {
/*  588 */     Optional<Id> newValue = Optional.of(Id.of(value));
/*  589 */     return new ImmutableWebhookData(this, 
/*      */         
/*  591 */         id(), this.type, 
/*      */         
/*  593 */         guildId(), 
/*  594 */         channelId(), 
/*  595 */         user(), this.name, this.avatar, 
/*      */ 
/*      */         
/*  598 */         token(), newValue, 
/*      */         
/*  600 */         sourceGuild(), 
/*  601 */         sourceChannel());
/*      */   }
/*      */   
/*      */   public ImmutableWebhookData withSourceGuild(Possible<WebhookPartialGuildData> value) {
/*  605 */     Possible<WebhookPartialGuildData> newValue = Objects.<Possible<WebhookPartialGuildData>>requireNonNull(value);
/*  606 */     return new ImmutableWebhookData(this, 
/*      */         
/*  608 */         id(), this.type, 
/*      */         
/*  610 */         guildId(), 
/*  611 */         channelId(), 
/*  612 */         user(), this.name, this.avatar, 
/*      */ 
/*      */         
/*  615 */         token(), 
/*  616 */         applicationId(), newValue, 
/*      */         
/*  618 */         sourceChannel());
/*      */   }
/*      */   
/*      */   public ImmutableWebhookData withSourceGuild(WebhookPartialGuildData value) {
/*  622 */     Possible<WebhookPartialGuildData> newValue = Possible.of(value);
/*  623 */     return new ImmutableWebhookData(this, 
/*      */         
/*  625 */         id(), this.type, 
/*      */         
/*  627 */         guildId(), 
/*  628 */         channelId(), 
/*  629 */         user(), this.name, this.avatar, 
/*      */ 
/*      */         
/*  632 */         token(), 
/*  633 */         applicationId(), newValue, 
/*      */         
/*  635 */         sourceChannel());
/*      */   }
/*      */   
/*      */   public ImmutableWebhookData withSourceChannel(Possible<WebhookPartialChannelData> value) {
/*  639 */     Possible<WebhookPartialChannelData> newValue = Objects.<Possible<WebhookPartialChannelData>>requireNonNull(value);
/*  640 */     return new ImmutableWebhookData(this, 
/*      */         
/*  642 */         id(), this.type, 
/*      */         
/*  644 */         guildId(), 
/*  645 */         channelId(), 
/*  646 */         user(), this.name, this.avatar, 
/*      */ 
/*      */         
/*  649 */         token(), 
/*  650 */         applicationId(), 
/*  651 */         sourceGuild(), newValue);
/*      */   }
/*      */ 
/*      */   
/*      */   public ImmutableWebhookData withSourceChannel(WebhookPartialChannelData value) {
/*  656 */     Possible<WebhookPartialChannelData> newValue = Possible.of(value);
/*  657 */     return new ImmutableWebhookData(this, 
/*      */         
/*  659 */         id(), this.type, 
/*      */         
/*  661 */         guildId(), 
/*  662 */         channelId(), 
/*  663 */         user(), this.name, this.avatar, 
/*      */ 
/*      */         
/*  666 */         token(), 
/*  667 */         applicationId(), 
/*  668 */         sourceGuild(), newValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean equals(Object another) {
/*  678 */     if (this == another) return true; 
/*  679 */     return (another instanceof ImmutableWebhookData && 
/*  680 */       equalTo(0, (ImmutableWebhookData)another));
/*      */   }
/*      */   
/*      */   private boolean equalTo(int synthetic, ImmutableWebhookData another) {
/*  684 */     return (Objects.equals(Long.valueOf(this.id_value), Long.valueOf(another.id_value)) && this.type == another.type && 
/*      */       
/*  686 */       guildId().equals(another.guildId()) && 
/*  687 */       channelId().equals(another.channelId()) && 
/*  688 */       user().equals(another.user()) && 
/*  689 */       Objects.equals(this.name, another.name) && 
/*  690 */       Objects.equals(this.avatar, another.avatar) && 
/*  691 */       token().equals(another.token()) && 
/*  692 */       applicationId().equals(another.applicationId()) && 
/*  693 */       sourceGuild().equals(another.sourceGuild()) && 
/*  694 */       sourceChannel().equals(another.sourceChannel()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int hashCode() {
/*  703 */     int h = 5381;
/*  704 */     h += (h << 5) + Objects.hashCode(Long.valueOf(this.id_value));
/*  705 */     h += (h << 5) + this.type;
/*  706 */     h += (h << 5) + guildId().hashCode();
/*  707 */     h += (h << 5) + channelId().hashCode();
/*  708 */     h += (h << 5) + user().hashCode();
/*  709 */     h += (h << 5) + Objects.hashCode(this.name);
/*  710 */     h += (h << 5) + Objects.hashCode(this.avatar);
/*  711 */     h += (h << 5) + token().hashCode();
/*  712 */     h += (h << 5) + applicationId().hashCode();
/*  713 */     h += (h << 5) + sourceGuild().hashCode();
/*  714 */     h += (h << 5) + sourceChannel().hashCode();
/*  715 */     return h;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/*  724 */     StringBuilder builder = new StringBuilder("WebhookData{");
/*  725 */     builder.append("id=").append(Objects.toString(Long.valueOf(this.id_value)));
/*  726 */     builder.append(", ");
/*  727 */     builder.append("type=").append(this.type);
/*  728 */     builder.append(", ");
/*  729 */     builder.append("guildId=").append(guildId().toString());
/*  730 */     builder.append(", ");
/*  731 */     builder.append("channelId=").append(channelId().toString());
/*  732 */     builder.append(", ");
/*  733 */     builder.append("user=").append(user().toString());
/*  734 */     if (this.name != null) {
/*  735 */       builder.append(", ");
/*  736 */       builder.append("name=").append(this.name);
/*      */     } 
/*  738 */     if (this.avatar != null) {
/*  739 */       builder.append(", ");
/*  740 */       builder.append("avatar=").append(this.avatar);
/*      */     } 
/*  742 */     builder.append(", ");
/*  743 */     builder.append("token=").append(token().toString());
/*  744 */     builder.append(", ");
/*  745 */     builder.append("applicationId=").append(applicationId().toString());
/*  746 */     builder.append(", ");
/*  747 */     builder.append("sourceGuild=").append(sourceGuild().toString());
/*  748 */     builder.append(", ");
/*  749 */     builder.append("sourceChannel=").append(sourceChannel().toString());
/*  750 */     return builder.append("}").toString();
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonDeserialize
/*      */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*      */   @Generated(from = "WebhookData", generator = "Immutables")
/*      */   static final class Json
/*      */     implements WebhookData
/*      */   {
/*      */     Id id;
/*      */     
/*      */     int type;
/*      */     
/*      */     boolean typeIsSet;
/*  766 */     Possible<Optional<Id>> guildId = Possible.absent();
/*      */ 
/*      */     
/*  769 */     Optional<Id> channelId = Optional.empty();
/*      */ 
/*      */     
/*  772 */     Possible<UserData> user = Possible.absent();
/*      */     
/*  774 */     Optional<String> name = Optional.empty();
/*  775 */     Optional<String> avatar = Optional.empty();
/*      */     
/*  777 */     Possible<String> token = Possible.absent();
/*      */ 
/*      */     
/*  780 */     Optional<Id> applicationId = Optional.empty();
/*      */ 
/*      */     
/*  783 */     Possible<WebhookPartialGuildData> sourceGuild = Possible.absent();
/*      */ 
/*      */     
/*  786 */     Possible<WebhookPartialChannelData> sourceChannel = Possible.absent();
/*      */     
/*      */     @JsonProperty("id")
/*      */     public void setId(Id id) {
/*  790 */       this.id = id;
/*      */     }
/*      */     @JsonProperty("type")
/*      */     public void setType(int type) {
/*  794 */       this.type = type;
/*  795 */       this.typeIsSet = true;
/*      */     }
/*      */     @JsonProperty("guild_id")
/*      */     public void setGuildId(Possible<Optional<Id>> guildId) {
/*  799 */       this.guildId = guildId;
/*      */     }
/*      */     @JsonProperty("channel_id")
/*      */     public void setChannelId(Optional<Id> channelId) {
/*  803 */       this.channelId = channelId;
/*      */     }
/*      */     @JsonProperty("user")
/*      */     public void setUser(Possible<UserData> user) {
/*  807 */       this.user = user;
/*      */     }
/*      */     @JsonProperty("name")
/*      */     public void setName(Optional<String> name) {
/*  811 */       this.name = name;
/*      */     }
/*      */     @JsonProperty("avatar")
/*      */     public void setAvatar(Optional<String> avatar) {
/*  815 */       this.avatar = avatar;
/*      */     }
/*      */     @JsonProperty("token")
/*      */     public void setToken(Possible<String> token) {
/*  819 */       this.token = token;
/*      */     }
/*      */     @JsonProperty("application_id")
/*      */     public void setApplicationId(Optional<Id> applicationId) {
/*  823 */       this.applicationId = applicationId;
/*      */     }
/*      */     @JsonProperty("source_guild")
/*      */     public void setSourceGuild(Possible<WebhookPartialGuildData> sourceGuild) {
/*  827 */       this.sourceGuild = sourceGuild;
/*      */     }
/*      */     @JsonProperty("source_channel")
/*      */     public void setSourceChannel(Possible<WebhookPartialChannelData> sourceChannel) {
/*  831 */       this.sourceChannel = sourceChannel;
/*      */     }
/*      */     public Id id() {
/*  834 */       throw new UnsupportedOperationException();
/*      */     } public int type() {
/*  836 */       throw new UnsupportedOperationException();
/*      */     } public Possible<Optional<Id>> guildId() {
/*  838 */       throw new UnsupportedOperationException();
/*      */     } public Optional<Id> channelId() {
/*  840 */       throw new UnsupportedOperationException();
/*      */     } public Possible<UserData> user() {
/*  842 */       throw new UnsupportedOperationException();
/*      */     } public Optional<String> name() {
/*  844 */       throw new UnsupportedOperationException();
/*      */     } public Optional<String> avatar() {
/*  846 */       throw new UnsupportedOperationException();
/*      */     } public Possible<String> token() {
/*  848 */       throw new UnsupportedOperationException();
/*      */     } public Optional<Id> applicationId() {
/*  850 */       throw new UnsupportedOperationException();
/*      */     } public Possible<WebhookPartialGuildData> sourceGuild() {
/*  852 */       throw new UnsupportedOperationException();
/*      */     } public Possible<WebhookPartialChannelData> sourceChannel() {
/*  854 */       throw new UnsupportedOperationException();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*      */   static ImmutableWebhookData fromJson(Json json) {
/*  865 */     Builder builder = builder();
/*  866 */     if (json.id != null) {
/*  867 */       builder.id(json.id);
/*      */     }
/*  869 */     if (json.typeIsSet) {
/*  870 */       builder.type(json.type);
/*      */     }
/*  872 */     if (json.guildId != null) {
/*  873 */       builder.guildId(json.guildId);
/*      */     }
/*  875 */     if (json.channelId != null) {
/*  876 */       builder.channelId(json.channelId);
/*      */     }
/*  878 */     if (json.user != null) {
/*  879 */       builder.user(json.user);
/*      */     }
/*  881 */     if (json.name != null) {
/*  882 */       builder.name(json.name);
/*      */     }
/*  884 */     if (json.avatar != null) {
/*  885 */       builder.avatar(json.avatar);
/*      */     }
/*  887 */     if (json.token != null) {
/*  888 */       builder.token(json.token);
/*      */     }
/*  890 */     if (json.applicationId != null) {
/*  891 */       builder.applicationId(json.applicationId);
/*      */     }
/*  893 */     if (json.sourceGuild != null) {
/*  894 */       builder.sourceGuild(json.sourceGuild);
/*      */     }
/*  896 */     if (json.sourceChannel != null) {
/*  897 */       builder.sourceChannel(json.sourceChannel);
/*      */     }
/*  899 */     return builder.build();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableWebhookData of(Id id, int type, Possible<Optional<Id>> guildId, Optional<Id> channelId, Possible<UserData> user, Optional<String> name, Optional<String> avatar, Possible<String> token, Optional<Id> applicationId, Possible<WebhookPartialGuildData> sourceGuild, Possible<WebhookPartialChannelData> sourceChannel) {
/*  918 */     return new ImmutableWebhookData(id, type, guildId, channelId, user, name, avatar, token, applicationId, sourceGuild, sourceChannel);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImmutableWebhookData copyOf(WebhookData instance) {
/*  929 */     if (instance instanceof ImmutableWebhookData) {
/*  930 */       return (ImmutableWebhookData)instance;
/*      */     }
/*  932 */     return builder()
/*  933 */       .from(instance)
/*  934 */       .build();
/*      */   }
/*      */   
/*      */   public boolean isGuildIdPresent() {
/*  938 */     return !this.guildId_absent;
/*      */   }
/*      */   
/*      */   public long guildIdOrElse(long defaultValue) {
/*  942 */     return !this.guildId_absent ? this.guildId_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isChannelIdPresent() {
/*  946 */     return this.channelId_present;
/*      */   }
/*      */   
/*      */   public long channelIdOrElse(long defaultValue) {
/*  950 */     return this.channelId_present ? this.channelId_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isUserPresent() {
/*  954 */     return !this.user_absent;
/*      */   }
/*      */   
/*      */   public UserData userOrElse(UserData defaultValue) {
/*  958 */     return !this.user_absent ? this.user_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isTokenPresent() {
/*  962 */     return !this.token_absent;
/*      */   }
/*      */   
/*      */   public String tokenOrElse(String defaultValue) {
/*  966 */     return !this.token_absent ? this.token_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isApplicationIdPresent() {
/*  970 */     return this.applicationId_present;
/*      */   }
/*      */   
/*      */   public long applicationIdOrElse(long defaultValue) {
/*  974 */     return this.applicationId_present ? this.applicationId_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isSourceGuildPresent() {
/*  978 */     return !this.sourceGuild_absent;
/*      */   }
/*      */   
/*      */   public WebhookPartialGuildData sourceGuildOrElse(WebhookPartialGuildData defaultValue) {
/*  982 */     return !this.sourceGuild_absent ? this.sourceGuild_value : defaultValue;
/*      */   }
/*      */   
/*      */   public boolean isSourceChannelPresent() {
/*  986 */     return !this.sourceChannel_absent;
/*      */   }
/*      */   
/*      */   public WebhookPartialChannelData sourceChannelOrElse(WebhookPartialChannelData defaultValue) {
/*  990 */     return !this.sourceChannel_absent ? this.sourceChannel_value : defaultValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Builder builder() {
/* 1013 */     return new Builder();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Generated(from = "WebhookData", generator = "Immutables")
/*      */   public static final class Builder
/*      */   {
/*      */     private static final long INIT_BIT_TYPE = 1L;
/*      */ 
/*      */ 
/*      */     
/* 1026 */     private long initBits = 1L;
/*      */     
/* 1028 */     private Id id_id = null;
/* 1029 */     private Possible<Optional<Id>> guildId_possible = Possible.absent();
/* 1030 */     private Optional<Id> channelId_optional = Optional.empty();
/* 1031 */     private Possible<UserData> user_possible = Possible.absent();
/* 1032 */     private Possible<String> token_possible = Possible.absent();
/* 1033 */     private Optional<Id> applicationId_optional = Optional.empty();
/* 1034 */     private Possible<WebhookPartialGuildData> sourceGuild_possible = Possible.absent();
/* 1035 */     private Possible<WebhookPartialChannelData> sourceChannel_possible = Possible.absent();
/*      */ 
/*      */ 
/*      */     
/*      */     private int type;
/*      */ 
/*      */ 
/*      */     
/*      */     private String name;
/*      */ 
/*      */     
/*      */     private String avatar;
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder from(WebhookData instance) {
/* 1051 */       Objects.requireNonNull(instance, "instance");
/* 1052 */       id(instance.id());
/* 1053 */       type(instance.type());
/* 1054 */       guildId(instance.guildId());
/* 1055 */       channelId(instance.channelId());
/* 1056 */       user(instance.user());
/* 1057 */       Optional<String> nameOptional = instance.name();
/* 1058 */       if (nameOptional.isPresent()) {
/* 1059 */         name(nameOptional);
/*      */       }
/* 1061 */       Optional<String> avatarOptional = instance.avatar();
/* 1062 */       if (avatarOptional.isPresent()) {
/* 1063 */         avatar(avatarOptional);
/*      */       }
/* 1065 */       token(instance.token());
/* 1066 */       applicationId(instance.applicationId());
/* 1067 */       sourceGuild(instance.sourceGuild());
/* 1068 */       sourceChannel(instance.sourceChannel());
/* 1069 */       return this;
/*      */     }
/*      */     
/*      */     public Builder id(String value) {
/* 1073 */       this.id_id = Id.of(value);
/* 1074 */       return this;
/*      */     }
/*      */     
/*      */     public Builder id(long value) {
/* 1078 */       this.id_id = Id.of(value);
/* 1079 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("id")
/*      */     public Builder id(Id value) {
/* 1084 */       this.id_id = value;
/* 1085 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("type")
/*      */     public final Builder type(int type) {
/* 1095 */       this.type = type;
/* 1096 */       this.initBits &= 0xFFFFFFFFFFFFFFFEL;
/* 1097 */       return this;
/*      */     }
/*      */     
/*      */     public Builder guildId(String value) {
/* 1101 */       this.guildId_possible = Possible.of(Optional.of(Id.of(value)));
/* 1102 */       return this;
/*      */     }
/*      */     
/*      */     public Builder guildId(long value) {
/* 1106 */       this.guildId_possible = Possible.of(Optional.of(Id.of(value)));
/* 1107 */       return this;
/*      */     }
/*      */     
/*      */     public Builder guildId(Id value) {
/* 1111 */       this.guildId_possible = Possible.of(Optional.of(value));
/* 1112 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("guild_id")
/*      */     public Builder guildId(Possible<Optional<Id>> value) {
/* 1117 */       this.guildId_possible = value;
/* 1118 */       return this;
/*      */     }
/*      */     
/*      */     public Builder channelId(String value) {
/* 1122 */       this.channelId_optional = Optional.of(Id.of(value));
/* 1123 */       return this;
/*      */     }
/*      */     
/*      */     public Builder channelId(long value) {
/* 1127 */       this.channelId_optional = Optional.of(Id.of(value));
/* 1128 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("channel_id")
/*      */     public Builder channelId(Optional<Id> value) {
/* 1133 */       this.channelId_optional = value;
/* 1134 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("user")
/*      */     public Builder user(Possible<UserData> value) {
/* 1139 */       this.user_possible = value;
/* 1140 */       return this;
/*      */     }
/*      */     
/*      */     public Builder user(UserData value) {
/* 1144 */       this.user_possible = Possible.of(value);
/* 1145 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder name(String name) {
/* 1154 */       this.name = Objects.<String>requireNonNull(name, "name");
/* 1155 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("name")
/*      */     public final Builder name(Optional<String> name) {
/* 1165 */       this.name = name.orElse(null);
/* 1166 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Builder avatar(String avatar) {
/* 1175 */       this.avatar = Objects.<String>requireNonNull(avatar, "avatar");
/* 1176 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @JsonProperty("avatar")
/*      */     public final Builder avatar(Optional<String> avatar) {
/* 1186 */       this.avatar = avatar.orElse(null);
/* 1187 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("token")
/*      */     public Builder token(Possible<String> value) {
/* 1192 */       this.token_possible = value;
/* 1193 */       return this;
/*      */     }
/*      */     
/*      */     public Builder token(String value) {
/* 1197 */       this.token_possible = Possible.of(value);
/* 1198 */       return this;
/*      */     }
/*      */     
/*      */     public Builder applicationId(String value) {
/* 1202 */       this.applicationId_optional = Optional.of(Id.of(value));
/* 1203 */       return this;
/*      */     }
/*      */     
/*      */     public Builder applicationId(long value) {
/* 1207 */       this.applicationId_optional = Optional.of(Id.of(value));
/* 1208 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("application_id")
/*      */     public Builder applicationId(Optional<Id> value) {
/* 1213 */       this.applicationId_optional = value;
/* 1214 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("source_guild")
/*      */     public Builder sourceGuild(Possible<WebhookPartialGuildData> value) {
/* 1219 */       this.sourceGuild_possible = value;
/* 1220 */       return this;
/*      */     }
/*      */     
/*      */     public Builder sourceGuild(WebhookPartialGuildData value) {
/* 1224 */       this.sourceGuild_possible = Possible.of(value);
/* 1225 */       return this;
/*      */     }
/*      */     
/*      */     @JsonProperty("source_channel")
/*      */     public Builder sourceChannel(Possible<WebhookPartialChannelData> value) {
/* 1230 */       this.sourceChannel_possible = value;
/* 1231 */       return this;
/*      */     }
/*      */     
/*      */     public Builder sourceChannel(WebhookPartialChannelData value) {
/* 1235 */       this.sourceChannel_possible = Possible.of(value);
/* 1236 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ImmutableWebhookData build() {
/* 1245 */       if (this.initBits != 0L) {
/* 1246 */         throw new IllegalStateException(formatRequiredAttributesMessage());
/*      */       }
/* 1248 */       return new ImmutableWebhookData(null, 
/*      */           
/* 1250 */           id_build(), this.type, 
/*      */           
/* 1252 */           guildId_build(), 
/* 1253 */           channelId_build(), 
/* 1254 */           user_build(), this.name, this.avatar, 
/*      */ 
/*      */           
/* 1257 */           token_build(), 
/* 1258 */           applicationId_build(), 
/* 1259 */           sourceGuild_build(), 
/* 1260 */           sourceChannel_build());
/*      */     }
/*      */     
/*      */     private String formatRequiredAttributesMessage() {
/* 1264 */       List<String> attributes = new ArrayList<>();
/* 1265 */       if ((this.initBits & 0x1L) != 0L) attributes.add("type"); 
/* 1266 */       return "Cannot build WebhookData, some of required attributes are not set " + attributes;
/*      */     }
/*      */     
/*      */     private Id id_build() {
/* 1270 */       return this.id_id;
/*      */     }
/*      */     
/*      */     private Possible<Optional<Id>> guildId_build() {
/* 1274 */       return this.guildId_possible;
/*      */     }
/*      */     
/*      */     private Optional<Id> channelId_build() {
/* 1278 */       return this.channelId_optional;
/*      */     }
/*      */     
/*      */     private Possible<UserData> user_build() {
/* 1282 */       return this.user_possible;
/*      */     }
/*      */     
/*      */     private Possible<String> token_build() {
/* 1286 */       return this.token_possible;
/*      */     }
/*      */     
/*      */     private Optional<Id> applicationId_build() {
/* 1290 */       return this.applicationId_optional;
/*      */     }
/*      */     
/*      */     private Possible<WebhookPartialGuildData> sourceGuild_build() {
/* 1294 */       return this.sourceGuild_possible;
/*      */     }
/*      */     
/*      */     private Possible<WebhookPartialChannelData> sourceChannel_build() {
/* 1298 */       return this.sourceChannel_possible;
/*      */     }
/*      */     
/*      */     private Builder() {}
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableWebhookData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */