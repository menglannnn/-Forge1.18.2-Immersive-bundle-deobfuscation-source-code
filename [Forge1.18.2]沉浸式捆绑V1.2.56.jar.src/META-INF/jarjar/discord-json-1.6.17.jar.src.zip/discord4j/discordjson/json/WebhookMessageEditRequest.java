/*    */ package discord4j.discordjson.json;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonProperty;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import discord4j.discordjson.possible.Possible;
/*    */ import java.util.List;
/*    */ import java.util.Optional;
/*    */ import org.immutables.value.Value.Immutable;
/*    */ 
/*    */ 
/*    */ @JsonSerialize(as = ImmutableWebhookMessageEditRequest.class)
/*    */ @JsonDeserialize(as = ImmutableWebhookMessageEditRequest.class)
/*    */ @Immutable
/*    */ public interface WebhookMessageEditRequest
/*    */ {
/*    */   static ImmutableWebhookMessageEditRequest.Builder builder() {
/* 18 */     return ImmutableWebhookMessageEditRequest.builder();
/*    */   }
/*    */   
/*    */   Possible<Optional<String>> content();
/*    */   
/*    */   Possible<Optional<List<EmbedData>>> embeds();
/*    */   
/*    */   @JsonProperty("allowed_mentions")
/*    */   Possible<Optional<AllowedMentionsData>> allowedMentions();
/*    */   
/*    */   Possible<Optional<List<AttachmentData>>> attachments();
/*    */   
/*    */   Possible<List<ComponentData>> components();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\WebhookMessageEditRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */