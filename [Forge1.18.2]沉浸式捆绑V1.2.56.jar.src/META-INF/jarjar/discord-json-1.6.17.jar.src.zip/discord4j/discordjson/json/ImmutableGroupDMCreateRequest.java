/*     */ package discord4j.discordjson.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import org.immutables.value.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Generated(from = "GroupDMCreateRequest", generator = "Immutables")
/*     */ public final class ImmutableGroupDMCreateRequest
/*     */   implements GroupDMCreateRequest
/*     */ {
/*     */   private final List<String> accessTokens;
/*     */   private final Map<String, String> nicks;
/*     */   
/*     */   private ImmutableGroupDMCreateRequest(Iterable<String> accessTokens, Map<String, ? extends String> nicks) {
/*  35 */     this.accessTokens = createUnmodifiableList(false, createSafeList(accessTokens, true, false));
/*  36 */     this.nicks = createUnmodifiableMap(true, false, nicks);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ImmutableGroupDMCreateRequest(ImmutableGroupDMCreateRequest original, List<String> accessTokens, Map<String, String> nicks) {
/*  43 */     this.accessTokens = accessTokens;
/*  44 */     this.nicks = nicks;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("access_tokens")
/*     */   public List<String> accessTokens() {
/*  53 */     return this.accessTokens;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonProperty("nicks")
/*     */   public Map<String, String> nicks() {
/*  62 */     return this.nicks;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableGroupDMCreateRequest withAccessTokens(String... elements) {
/*  71 */     List<String> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
/*  72 */     return new ImmutableGroupDMCreateRequest(this, newValue, this.nicks);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableGroupDMCreateRequest withAccessTokens(Iterable<String> elements) {
/*  82 */     if (this.accessTokens == elements) return this; 
/*  83 */     List<String> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
/*  84 */     return new ImmutableGroupDMCreateRequest(this, newValue, this.nicks);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ImmutableGroupDMCreateRequest withNicks(Map<String, ? extends String> entries) {
/*  95 */     if (this.nicks == entries) return this; 
/*  96 */     Map<String, String> newValue = createUnmodifiableMap(true, false, entries);
/*  97 */     return new ImmutableGroupDMCreateRequest(this, this.accessTokens, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 106 */     if (this == another) return true; 
/* 107 */     return (another instanceof ImmutableGroupDMCreateRequest && 
/* 108 */       equalTo(0, (ImmutableGroupDMCreateRequest)another));
/*     */   }
/*     */   
/*     */   private boolean equalTo(int synthetic, ImmutableGroupDMCreateRequest another) {
/* 112 */     return (this.accessTokens.equals(another.accessTokens) && this.nicks
/* 113 */       .equals(another.nicks));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 122 */     int h = 5381;
/* 123 */     h += (h << 5) + this.accessTokens.hashCode();
/* 124 */     h += (h << 5) + this.nicks.hashCode();
/* 125 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 134 */     return "GroupDMCreateRequest{accessTokens=" + this.accessTokens + ", nicks=" + this.nicks + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonDeserialize
/*     */   @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE)
/*     */   @Generated(from = "GroupDMCreateRequest", generator = "Immutables")
/*     */   static final class Json
/*     */     implements GroupDMCreateRequest
/*     */   {
/* 149 */     List<String> accessTokens = Collections.emptyList();
/* 150 */     Map<String, String> nicks = Collections.emptyMap();
/*     */     @JsonProperty("access_tokens")
/*     */     public void setAccessTokens(List<String> accessTokens) {
/* 153 */       this.accessTokens = accessTokens;
/*     */     }
/*     */     @JsonProperty("nicks")
/*     */     public void setNicks(Map<String, String> nicks) {
/* 157 */       this.nicks = nicks;
/*     */     }
/*     */     public List<String> accessTokens() {
/* 160 */       throw new UnsupportedOperationException();
/*     */     } public Map<String, String> nicks() {
/* 162 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
/*     */   static ImmutableGroupDMCreateRequest fromJson(Json json) {
/* 173 */     Builder builder = builder();
/* 174 */     if (json.accessTokens != null) {
/* 175 */       builder.addAllAccessTokens(json.accessTokens);
/*     */     }
/* 177 */     if (json.nicks != null) {
/* 178 */       builder.putAllNicks(json.nicks);
/*     */     }
/* 180 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableGroupDMCreateRequest of(List<String> accessTokens, Map<String, String> nicks) {
/* 190 */     return of(accessTokens, nicks);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableGroupDMCreateRequest of(Iterable<String> accessTokens, Map<String, ? extends String> nicks) {
/* 200 */     return new ImmutableGroupDMCreateRequest(accessTokens, nicks);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImmutableGroupDMCreateRequest copyOf(GroupDMCreateRequest instance) {
/* 211 */     if (instance instanceof ImmutableGroupDMCreateRequest) {
/* 212 */       return (ImmutableGroupDMCreateRequest)instance;
/*     */     }
/* 214 */     return builder()
/* 215 */       .from(instance)
/* 216 */       .build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 230 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated(from = "GroupDMCreateRequest", generator = "Immutables")
/*     */   public static final class Builder
/*     */   {
/* 242 */     private List<String> accessTokens = new ArrayList<>();
/* 243 */     private Map<String, String> nicks = new LinkedHashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder from(GroupDMCreateRequest instance) {
/* 257 */       Objects.requireNonNull(instance, "instance");
/* 258 */       addAllAccessTokens(instance.accessTokens());
/* 259 */       putAllNicks(instance.nicks());
/* 260 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder addAccessToken(String element) {
/* 269 */       this.accessTokens.add(Objects.<String>requireNonNull(element, "accessTokens element"));
/* 270 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder addAccessTokens(String... elements) {
/* 279 */       for (String element : elements) {
/* 280 */         this.accessTokens.add(Objects.<String>requireNonNull(element, "accessTokens element"));
/*     */       }
/* 282 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("access_tokens")
/*     */     public final Builder accessTokens(Iterable<String> elements) {
/* 293 */       this.accessTokens.clear();
/* 294 */       return addAllAccessTokens(elements);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder addAllAccessTokens(Iterable<String> elements) {
/* 303 */       for (String element : elements) {
/* 304 */         this.accessTokens.add(Objects.<String>requireNonNull(element, "accessTokens element"));
/*     */       }
/* 306 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder putNick(String key, String value) {
/* 316 */       this.nicks.put(
/* 317 */           Objects.<String>requireNonNull(key, "nicks key"), 
/* 318 */           Objects.<String>requireNonNull(value, "nicks value"));
/* 319 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder putNick(Map.Entry<String, ? extends String> entry) {
/* 328 */       String k = entry.getKey();
/* 329 */       String v = entry.getValue();
/* 330 */       this.nicks.put(
/* 331 */           Objects.<String>requireNonNull(k, "nicks key"), 
/* 332 */           Objects.<String>requireNonNull(v, "nicks value"));
/* 333 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonProperty("nicks")
/*     */     public final Builder nicks(Map<String, ? extends String> entries) {
/* 343 */       this.nicks.clear();
/* 344 */       return putAllNicks(entries);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder putAllNicks(Map<String, ? extends String> entries) {
/* 353 */       for (Map.Entry<String, ? extends String> e : entries.entrySet()) {
/* 354 */         String k = e.getKey();
/* 355 */         String v = e.getValue();
/* 356 */         this.nicks.put(
/* 357 */             Objects.<String>requireNonNull(k, "nicks key"), 
/* 358 */             Objects.<String>requireNonNull(v, "nicks value"));
/*     */       } 
/* 360 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImmutableGroupDMCreateRequest build() {
/* 369 */       return new ImmutableGroupDMCreateRequest(null, ImmutableGroupDMCreateRequest.createUnmodifiableList(true, (List)this.accessTokens), ImmutableGroupDMCreateRequest.createUnmodifiableMap(false, false, (Map)this.nicks));
/*     */     }
/*     */     private Builder() {} }
/*     */   
/*     */   private static <T> List<T> createSafeList(Iterable<? extends T> iterable, boolean checkNulls, boolean skipNulls) {
/*     */     ArrayList<T> list;
/* 375 */     if (iterable instanceof Collection) {
/* 376 */       int size = ((Collection)iterable).size();
/* 377 */       if (size == 0) return Collections.emptyList(); 
/* 378 */       list = new ArrayList<>();
/*     */     } else {
/* 380 */       list = new ArrayList<>();
/*     */     } 
/* 382 */     for (T element : iterable) {
/* 383 */       if (skipNulls && element == null)
/* 384 */         continue;  if (checkNulls) Objects.requireNonNull(element, "element"); 
/* 385 */       list.add(element);
/*     */     } 
/* 387 */     return list;
/*     */   }
/*     */   
/*     */   private static <T> List<T> createUnmodifiableList(boolean clone, List<T> list) {
/* 391 */     switch (list.size()) { case 0:
/* 392 */         return Collections.emptyList();
/* 393 */       case 1: return Collections.singletonList(list.get(0)); }
/*     */     
/* 395 */     if (clone) {
/* 396 */       return Collections.unmodifiableList(new ArrayList<>(list));
/*     */     }
/* 398 */     if (list instanceof ArrayList) {
/* 399 */       ((ArrayList)list).trimToSize();
/*     */     }
/* 401 */     return Collections.unmodifiableList(list);
/*     */   }
/*     */   private static <K, V> Map<K, V> createUnmodifiableMap(boolean checkNulls, boolean skipNulls, Map<? extends K, ? extends V> map) {
/*     */     Map.Entry<? extends K, ? extends V> e;
/*     */     K k;
/*     */     V v;
/* 407 */     switch (map.size()) { case 0:
/* 408 */         return Collections.emptyMap();
/*     */       case 1:
/* 410 */         e = map.entrySet().iterator().next();
/* 411 */         k = e.getKey();
/* 412 */         v = e.getValue();
/* 413 */         if (checkNulls) {
/* 414 */           Objects.requireNonNull(k, "key");
/* 415 */           Objects.requireNonNull(v, "value");
/*     */         } 
/* 417 */         if (skipNulls && (k == null || v == null)) {
/* 418 */           return Collections.emptyMap();
/*     */         }
/* 420 */         return Collections.singletonMap(k, v); }
/*     */ 
/*     */     
/* 423 */     Map<K, V> linkedMap = new LinkedHashMap<>(map.size());
/* 424 */     if (skipNulls || checkNulls) {
/* 425 */       for (Map.Entry<? extends K, ? extends V> entry : map.entrySet()) {
/* 426 */         K k1 = entry.getKey();
/* 427 */         V v1 = entry.getValue();
/* 428 */         if (skipNulls)
/* 429 */         { if (k1 == null || v1 == null)
/* 430 */             continue;  } else if (checkNulls)
/* 431 */         { Objects.requireNonNull(k1, "key");
/* 432 */           Objects.requireNonNull(v1, "value"); }
/*     */         
/* 434 */         linkedMap.put(k1, v1);
/*     */       } 
/*     */     } else {
/* 437 */       linkedMap.putAll(map);
/*     */     } 
/* 439 */     return Collections.unmodifiableMap(linkedMap);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord-json-1.6.17.jar!\discord4j\discordjson\json\ImmutableGroupDMCreateRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */